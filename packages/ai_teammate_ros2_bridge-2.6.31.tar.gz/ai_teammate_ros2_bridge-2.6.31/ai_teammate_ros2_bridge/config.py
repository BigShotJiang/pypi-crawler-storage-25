# AI Teammate Device Bridge v2 — Configuration & shared state
import logging
import os
import threading
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("bridge")

# Load .env — search CWD first, then package parent (editable install)
_env_candidates = [
    Path.cwd() / ".env",
    Path(__file__).resolve().parent.parent / ".env",
]
for env_file in _env_candidates:
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            if "=" in line and not line.startswith("#"):
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip())
        break

DEVICE_ID = os.environ.get("DEVICE_ID", "")
GATEWAY_URL = os.environ.get("GATEWAY_URL", "")
API_KEY = os.environ.get("API_KEY", "")

# Phase 4.12 — phone relay fallback (mDNS auto-discovery).
# When set, bridge falls back to a phone running the AI Teammate relay if the
# primary GATEWAY_URL is unreachable. The fingerprint identifies which phone
# this robot is paired with (mDNS responses with a different fingerprint are
# ignored). Token is the per-robot secret issued by the phone via QR.
RELAY_FINGERPRINT = os.environ.get("RELAY_FINGERPRINT", "")
RELAY_TOKEN = os.environ.get("RELAY_TOKEN", "")
GATEWAY_FAILOVER_TIMEOUT = float(os.environ.get("GATEWAY_FAILOVER_TIMEOUT", "10"))
GATEWAY_PRIMARY_RECHECK_INTERVAL = float(
    os.environ.get("GATEWAY_PRIMARY_RECHECK_INTERVAL", "300")
)
MODE = os.environ.get("CONNECTION_MODE", "rclpy")
INTERVAL = float(os.environ.get("STATUS_REPORT_INTERVAL", "1.0"))
CMD_VEL_TOPIC = os.environ.get("CMD_VEL_TOPIC", "/cmd_vel")
IMU_TOPIC = os.environ.get("IMU_TOPIC", "/imu/data")
ODOM_TOPIC = os.environ.get("ODOM_TOPIC", "/odom")
SCAN_TOPIC = os.environ.get("SCAN_TOPIC", "/scan")

# Obstacle
OBSTACLE_DISTANCE = float(os.environ.get("OBSTACLE_DISTANCE", "0.4"))
OBSTACLE_WAIT_TIMEOUT = float(os.environ.get("OBSTACLE_WAIT_TIMEOUT", "30"))

# Detection cooldown
DETECT_COOLDOWN = float(os.environ.get("DETECT_COOLDOWN_SEC", "2.0"))

# Keyframe capture
KF_MAX_BUFFER = int(os.environ.get("KF_MAX_BUFFER", "20"))
KF_BATCH_SIZE = int(os.environ.get("KF_BATCH_SIZE", "10"))
KF_MIN_DISPLACEMENT = float(os.environ.get("KF_MIN_DISPLACEMENT", "0.3"))
KF_MIN_ROTATION = float(os.environ.get("KF_MIN_ROTATION", "0.26"))
KF_MIN_INTERVAL = float(os.environ.get("KF_MIN_INTERVAL", "2.0"))
KF_WIFI_SCAN_INTERVAL = float(os.environ.get("KF_WIFI_SCAN_INTERVAL", "10.0"))  # (deprecated, kept for backcompat)
KF_WIFI_SCAN_FALLBACK_INTERVAL = float(os.environ.get("KF_WIFI_SCAN_FALLBACK_INTERVAL", "30.0"))
KF_WIFI_STATIONARY_INTERVAL = float(os.environ.get("KF_WIFI_STATIONARY_INTERVAL", "5.0"))
KF_WIFI_CACHE_MAX_AGE = float(os.environ.get("KF_WIFI_CACHE_MAX_AGE", "3.0"))
KF_WIFI_STATIONARY_THRESHOLD = float(os.environ.get("KF_WIFI_STATIONARY_THRESHOLD", "0.01"))
KF_WIFI_STATIONARY_MIN_DWELL = float(os.environ.get("KF_WIFI_STATIONARY_MIN_DWELL", "3.0"))
KF_WIFI_STABLE_THRESHOLD = float(os.environ.get("KF_WIFI_STABLE_THRESHOLD", "0.6"))
KF_WIFI_HISTORY_MAXLEN = int(os.environ.get("KF_WIFI_HISTORY_MAXLEN", "12"))
KF_THUMB_WIDTH = 160
KF_THUMB_HEIGHT = 120
KF_THUMB_QUALITY = 40

# Locations / fingerprints file paths
LOCATIONS_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)) or ".", "locations.json")
FINGERPRINTS_FILE = os.path.join(os.path.dirname(os.path.dirname(__file__)) or ".", "fingerprints.json")

# ── Shared mutable state ──

_ros2_cache: dict = {}
_ros2_lock = threading.Lock()
_ros2_node = None
_cmd_vel_pub = None
_cmd_vel_stamped = False  # True if topic uses TwistStamped (Jazzy+)
_ros2_owner = None  # current spin thread that owns _ros2_node (identity guard against restart races)
_estop_event = threading.Event()


def make_cmd_vel_msg(linear_x: float = 0.0, angular_z: float = 0.0):
    """Create Twist or TwistStamped based on detected topic type.

    Shared helper used by bridge device_bridge.py and skills motion.py.
    """
    import time as _time
    if _cmd_vel_stamped:
        from geometry_msgs.msg import TwistStamped
        from builtin_interfaces.msg import Time
        msg = TwistStamped()
        now = _time.time()
        msg.header.stamp = Time(sec=int(now), nanosec=int((now % 1) * 1e9))
        msg.header.frame_id = "base_link"
        msg.twist.linear.x = float(linear_x)
        msg.twist.angular.z = float(angular_z)
    else:
        from geometry_msgs.msg import Twist
        msg = Twist()
        msg.linear.x = float(linear_x)
        msg.angular.z = float(angular_z)
    return msg

# Gateway context (populated from welcome message)
_gw_context: dict = {}

# WS reference for service requests (set in ws_client.run())
_ws_ref = None
_service_futures: dict = {}

# Subprocess management
_subprocesses: dict[str, object] = {"slam": None, "nav2": None}

# Keyframe state
_keyframe_buffer: list = []
_last_kf_pose: dict | None = None
_last_kf_ts: float = 0.0
_kf_capture_active: bool = False
_kf_total_captured: int = 0
_kf_last_upload_ts: float = 0.0
_kf_wifi_cache: dict | None = None
_kf_wifi_cache_ts: float = 0.0
_kf_scan_history = None  # collections.deque[(ts, {bssid: signal})], initialized on first use
_kf_stopped_since_ts: float = 0.0
_kf_last_stationary_scan_ts: float = 0.0
# Accumulates {pose, wifi} summaries across the current mapping session —
# cleared on SLAM_START, uploaded with the map bundle for downstream map merge.
_map_session_fingerprints: list = []

# Detection rate limit
_detect_last_ts: float = 0.0

# Calibration (loaded from Gateway welcome or local .env)
ROTATION_SCALE = float(os.environ.get("ROTATION_SCALE", "1.0"))
DISTANCE_SCALE = float(os.environ.get("DISTANCE_SCALE", "1.0"))

# MQTT (optional — telemetry publishing)
MQTT_BROKER = os.environ.get("MQTT_BROKER", "")  # empty = disabled
MQTT_PORT = int(os.environ.get("MQTT_PORT", "1883"))
MQTT_USER = os.environ.get("MQTT_USER", "robot_bridge")
MQTT_PASS = os.environ.get("MQTT_PASS", "")
FLEET_ID = os.environ.get("FLEET_ID", "")  # for fleet broadcast subscribe
_mqtt_client = None  # set in ws_client if MQTT_BROKER configured
_mqtt_fleet_subscribed = False  # track if fleet topic subscribed
_mqtt_session_subscribed = False  # track if session topic subscribed
