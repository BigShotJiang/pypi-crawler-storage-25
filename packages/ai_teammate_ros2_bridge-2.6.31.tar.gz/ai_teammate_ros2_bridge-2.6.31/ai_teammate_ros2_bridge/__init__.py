"""AI Teammate ROS2 Bridge — rclpy native device bridge"""

__version__ = "2.6.31"

from .ws_client import DeviceBridge

__all__ = ["DeviceBridge", "__version__"]
