"""
TmuxSessionEffector: Effector that runs commands in a tmux pane via the dev daemon.

E = ⟨ι, e_execute, e_dryrun, e_undo⟩ where e_execute POSTs to the dev daemon's
Unix-socket JSON API and captures the command output.

This is the ONLY component that may mutate world state (Invariant E1).
"""

import http.client
import json
import logging
import os
import socket
import uuid
from datetime import datetime
from types import MappingProxyType

from atomicguard.domain.interfaces import EffectorInterface, Idempotency
from atomicguard.domain.models import (
    Artifact,
    ArtifactId,
    ArtifactStatus,
    ContextSnapshot,
)

logger = logging.getLogger(__name__)


class _UnixHTTPConnection(http.client.HTTPConnection):
    """HTTPConnection subclass that connects via a Unix domain socket."""

    def __init__(self, socket_path: str) -> None:
        super().__init__("localhost")
        self._socket_path = socket_path

    def connect(self) -> None:
        self.sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        self.sock.connect(self._socket_path)


class TmuxSessionEffector(EffectorInterface):
    """Runs a command in a tmux pane via the dev daemon's Unix-socket API.

    The plan artifact's content is the command string to execute.
    Session and pane are constructor parameters — the *where* is fixed
    at wiring time, the *what* comes from the generator.
    """

    def __init__(
        self,
        *,
        session: str,
        pane: str = "1.1",
        socket_path: str = "~/.local/run/dev.sock",
        timeout: int = 30,
        idempotent: bool = False,
    ):
        self._session = session
        self._pane = pane
        self._socket_path = os.path.expanduser(socket_path)
        self._timeout = timeout
        self._idempotent = idempotent

    @property
    def idempotency(self) -> Idempotency:
        return (
            Idempotency.IDEMPOTENT if self._idempotent else Idempotency.NON_IDEMPOTENT
        )

    def execute(self, plan: Artifact) -> Artifact:
        """Run the command in plan.content via the dev daemon."""
        command = plan.content
        logger.info(
            "TmuxSessionEffector: running %r in %s:%s",
            command,
            self._session,
            self._pane,
        )

        conn: _UnixHTTPConnection | None = None
        try:
            conn = _UnixHTTPConnection(self._socket_path)
            body = json.dumps({"command": command, "timeout_ms": self._timeout * 1000})
            path = f"/sessions/{self._session}/panes/{self._pane}/run"
            conn.request(
                "POST",
                path,
                body=body,
                headers={
                    "Content-Type": "application/json",
                },
            )
            response = conn.getresponse()
            data = json.loads(response.read().decode())

            stdout = data.get("stdout", "")
            exit_code = data.get("exit_code", -2)
            duration_ms = data.get("duration_ms", 0)
            marker_id = data.get("marker_id", "")
            stderr = data.get("stderr", "")
        except (OSError, json.JSONDecodeError, KeyError, ValueError) as exc:
            stdout = ""
            stderr = f"dev daemon error: {exc}"
            exit_code = -2
            duration_ms = 0
            marker_id = ""
        finally:
            if conn is not None:
                conn.close()

        return Artifact(
            artifact_id=ArtifactId(str(uuid.uuid4())),
            workflow_id=plan.workflow_id,
            content=stdout,
            previous_attempt_id=None,
            parent_action_pair_id=None,
            action_pair_id=plan.action_pair_id,
            created_at=datetime.now().isoformat(),
            attempt_number=plan.attempt_number,
            status=ArtifactStatus.PENDING,
            guard_result=None,
            context=ContextSnapshot(
                workflow_id=plan.workflow_id,
                specification=plan.context.specification if plan.context else "",
                constraints="",
                feedback_history=(),
            ),
            metadata=MappingProxyType(
                {
                    "exit_code": str(exit_code),
                    "stderr": stderr,
                    "command": command,
                    "session": self._session,
                    "pane": self._pane,
                    "marker_id": marker_id,
                    "duration_ms": str(duration_ms),
                }
            ),
        )

    def undo(self, plan: Artifact) -> bool:  # noqa: ARG002
        """No generic tmux undo — session teardown is out of scope."""
        return False
