"""
WorkflowEffector: Effector that executes a child workflow.

Wraps a workflow executor factory as an EffectorInterface, enabling
a meta-workflow to dispatch to pre-compiled task workflows.

See docs/design/notes/hierarchical_workflow_dispatch.md for the formal model.

Note: This effector receives a factory callable rather than importing
from the application layer directly, preserving the hexagonal boundary
(infrastructure does not import application).
"""

import json
import logging
import uuid
from collections.abc import Callable
from datetime import datetime
from types import MappingProxyType
from typing import TYPE_CHECKING

from atomicguard.domain.interfaces import EffectorInterface, Idempotency
from atomicguard.domain.models import (
    Artifact,
    ArtifactId,
    ArtifactStatus,
    ContextSnapshot,
    WorkflowStatus,
)

if TYPE_CHECKING:
    from atomicguard.domain.models import WorkflowResult

logger = logging.getLogger(__name__)

# Factory type: (workflow_name, specification) → WorkflowResult
WorkflowFactory = Callable[[str, str], "WorkflowResult"]


class WorkflowEffector(EffectorInterface):
    """Effector that executes a pre-compiled child workflow.

    The plan artifact's content encodes which workflow to run:
        Line 1: workflow name (key into the factory's catalogue)
        Lines 2+: specification string (key=value pairs)

    The factory callable is injected by the caller (typically the
    meta-workflow builder), keeping this class decoupled from the
    application layer.
    """

    def __init__(self, workflow_factory: WorkflowFactory):
        """
        Args:
            workflow_factory: Callable that takes (workflow_name, specification)
                and returns a WorkflowResult. The caller is responsible for
                building the orchestrator with the appropriate registries and DAG.
        """
        self._factory = workflow_factory

    @property
    def idempotency(self) -> Idempotency:
        # Conservative: child workflows may contain non-idempotent effectors
        return Idempotency.NON_IDEMPOTENT

    def execute(self, plan: Artifact) -> Artifact:
        """Execute a child workflow named in the plan artifact."""
        workflow_name, specification = self._parse_plan(plan.content)

        logger.info(
            "WorkflowEffector: dispatching to %r with spec=%r",
            workflow_name,
            specification[:100],
        )

        result = self._factory(workflow_name, specification)

        # Build human-readable summary
        summary_lines = [
            f"Workflow: {workflow_name}",
            f"Status: {result.status.value}",
        ]
        if result.failed_step:
            summary_lines.append(f"Failed step: {result.failed_step}")
        if result.escalation_feedback:
            summary_lines.append(f"Escalation: {result.escalation_feedback}")
        for ap_id, artifact in result.artifacts.items():
            exit_code = artifact.metadata.get("exit_code", "")
            status = "PASS" if artifact.is_accepted() else "FAIL"
            summary_lines.append(f"  {ap_id}: {status} (exit={exit_code})")
        summary = "\n".join(summary_lines)

        # Build metadata
        meta: dict[str, str] = {
            "workflow_status": result.status.value,
            "child_workflow": workflow_name,
        }
        if result.failed_step:
            meta["failed_step"] = result.failed_step
        if result.escalation_feedback:
            meta["escalation_feedback"] = result.escalation_feedback
        meta["child_artifacts"] = json.dumps(
            {ap_id: a.artifact_id for ap_id, a in result.artifacts.items()}
        )

        return Artifact(
            artifact_id=ArtifactId(str(uuid.uuid4())),
            workflow_id=plan.workflow_id,
            content=summary,
            previous_attempt_id=None,
            parent_action_pair_id=None,
            action_pair_id=plan.action_pair_id,
            created_at=datetime.now().isoformat(),
            attempt_number=plan.attempt_number,
            status=ArtifactStatus.ACCEPTED
            if result.status == WorkflowStatus.SUCCESS
            else ArtifactStatus.REJECTED,
            guard_result=None,
            context=ContextSnapshot(
                workflow_id=plan.workflow_id,
                specification=specification,
                constraints="",
                feedback_history=(),
            ),
            metadata=MappingProxyType(meta),
        )

    @staticmethod
    def _parse_plan(content: str) -> tuple[str, str]:
        """Parse plan artifact content into (workflow_name, specification)."""
        lines = content.strip().splitlines()
        if not lines:
            raise ValueError(
                "Empty plan artifact — expected workflow name on first line"
            )
        workflow_name = lines[0].strip()
        specification = "\n".join(lines[1:]).strip() if len(lines) > 1 else ""
        return workflow_name, specification
