"""
BashCommandExecutor: Effector that runs shell commands.

E = ⟨ι, e_execute, e_dryrun, e_undo⟩ where e_execute runs the plan
artifact's content as a shell command via subprocess.run().

This is the ONLY component that may mutate world state (Invariant E1).
"""

import logging
import subprocess
import uuid
from datetime import datetime
from types import MappingProxyType

from atomicguard.domain.interfaces import EffectorInterface, Idempotency
from atomicguard.domain.models import (
    Artifact,
    ArtifactId,
    ArtifactStatus,
    ContextSnapshot,
)

logger = logging.getLogger(__name__)


class BashCommandExecutor(EffectorInterface):
    """Runs a shell command (the plan artifact content) and captures output.

    The plan artifact's content is the command string to execute.
    Returns an execution artifact with stdout as content and
    stderr/exit_code in metadata.
    """

    def __init__(
        self,
        *,
        timeout: int = 30,
        cwd: str | None = None,
        undo_command: str | None = None,
        idempotent: bool = True,
    ):
        self._timeout = timeout
        self._cwd = cwd
        self._undo_command = undo_command
        self._idempotent = idempotent

    @property
    def idempotency(self) -> Idempotency:
        return (
            Idempotency.IDEMPOTENT if self._idempotent else Idempotency.NON_IDEMPOTENT
        )

    def execute(self, plan: Artifact) -> Artifact:
        """Run the command in plan.content, return execution artifact."""
        command = plan.content
        logger.info("BashCommandExecutor: running %r", command)

        try:
            result = subprocess.run(
                command,
                shell=True,  # noqa: S602
                capture_output=True,
                text=True,
                timeout=self._timeout,
                cwd=self._cwd,
            )
            stdout = result.stdout
            stderr = result.stderr
            exit_code = result.returncode
        except subprocess.TimeoutExpired:
            stdout = ""
            stderr = f"Command timed out after {self._timeout}s"
            exit_code = -1
        except Exception as exc:
            stdout = ""
            stderr = str(exc)
            exit_code = -2

        return Artifact(
            artifact_id=ArtifactId(str(uuid.uuid4())),
            workflow_id=plan.workflow_id,
            content=stdout,
            previous_attempt_id=None,
            parent_action_pair_id=None,
            action_pair_id=plan.action_pair_id,
            created_at=datetime.now().isoformat(),
            attempt_number=plan.attempt_number,
            status=ArtifactStatus.PENDING,
            guard_result=None,
            context=ContextSnapshot(
                workflow_id=plan.workflow_id,
                specification=plan.context.specification if plan.context else "",
                constraints="",
                feedback_history=(),
            ),
            metadata=MappingProxyType(
                {
                    "exit_code": str(exit_code),
                    "stderr": stderr,
                    "command": command,
                }
            ),
        )

    def undo(self, plan: Artifact) -> bool:  # noqa: ARG002
        """Run the undo command if configured."""
        if self._undo_command is None:
            return False

        logger.info("BashCommandExecutor: running undo %r", self._undo_command)
        try:
            result = subprocess.run(
                self._undo_command,
                shell=True,  # noqa: S602
                capture_output=True,
                text=True,
                timeout=self._timeout,
                cwd=self._cwd,
            )
            return result.returncode == 0
        except Exception:
            logger.exception("Undo command failed")
            return False

    @property
    def has_undo(self) -> bool:
        return self._undo_command is not None
