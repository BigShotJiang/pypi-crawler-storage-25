"""Effector implementations (Definition 6a)."""
