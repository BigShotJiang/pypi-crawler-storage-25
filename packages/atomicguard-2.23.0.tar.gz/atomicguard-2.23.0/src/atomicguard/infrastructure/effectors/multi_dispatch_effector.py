"""
MultiDispatchEffector: Effector that dispatches multiple child workflows.

Wraps a WorkflowFactory (same type as WorkflowEffector) but iterates over
a JSON list of dispatch entries in the plan artifact, executing one child
workflow per entry. Used for Tier 2 → Tier 3 dispatch in hierarchical
task networks where an analysis step finds N issues and each issue
triggers a separate TDD fix workflow.

Plan artifact format (JSON array):
    [
        {"workflow": "tdd_fix", "spec": "issue description..."},
        {"workflow": "tdd_fix", "spec": "another issue..."},
        ...
    ]

Returns a composite artifact summarising all child results, with per-issue
status in metadata.
"""

import json
import logging
import uuid
from datetime import datetime
from types import MappingProxyType

from atomicguard.domain.interfaces import EffectorInterface, Idempotency
from atomicguard.domain.models import (
    Artifact,
    ArtifactId,
    ArtifactStatus,
    ContextSnapshot,
    WorkflowStatus,
)
from atomicguard.infrastructure.effectors.workflow_effector import WorkflowFactory

logger = logging.getLogger(__name__)


class MultiDispatchEffector(EffectorInterface):
    """Effector that dispatches multiple child workflows from a JSON plan.

    Each entry in the plan's JSON array triggers one child workflow via the
    injected factory. Results are collected into a composite artifact.

    Preserves graph immutability (Invariant 2): the parent workflow graph
    is fixed; the effector executes N child workflows as one atomic operation.
    """

    def __init__(
        self,
        workflow_factory: WorkflowFactory,
        max_issues: int = 10,
    ):
        """
        Args:
            workflow_factory: Callable (workflow_name, specification) → WorkflowResult.
            max_issues: Maximum number of issues to dispatch. Caps human review load.
        """
        self._factory = workflow_factory
        self._max_issues = max_issues

    @property
    def idempotency(self) -> Idempotency:
        return Idempotency.NON_IDEMPOTENT

    def execute(self, plan: Artifact) -> Artifact:
        """Execute one child workflow per entry in the plan's JSON array."""
        entries = self._parse_plan(plan.content)
        truncated = entries[: self._max_issues]

        if len(entries) > self._max_issues:
            logger.warning(
                "MultiDispatchEffector: %d issues found, capping at %d",
                len(entries),
                self._max_issues,
            )

        results: list[dict[str, str | int | None]] = []
        for i, entry in enumerate(truncated):
            workflow_name = entry["workflow"]
            spec = entry["spec"]
            logger.info(
                "MultiDispatchEffector: dispatching %d/%d → %r",
                i + 1,
                len(truncated),
                workflow_name,
            )
            result = self._factory(workflow_name, spec)
            results.append(
                {
                    "index": i,
                    "workflow": workflow_name,
                    "spec": spec[:200],
                    "status": result.status.value,
                    "failed_step": result.failed_step,
                }
            )

        # Determine overall status
        statuses = [r["status"] for r in results]
        all_success = all(s == WorkflowStatus.SUCCESS.value for s in statuses)
        any_escalation = any(s == WorkflowStatus.ESCALATION.value for s in statuses)

        # Build summary
        summary_lines = [
            f"Dispatched {len(results)} child workflow(s):",
        ]
        for r in results:
            status_icon = "PASS" if r["status"] == "success" else "FAIL"
            spec_preview = str(r["spec"])[:80]
            summary_lines.append(f"  [{status_icon}] {r['workflow']}: {spec_preview}")

        succeeded = sum(1 for s in statuses if s == WorkflowStatus.SUCCESS.value)
        summary_lines.append(f"\n{succeeded}/{len(results)} succeeded")

        meta: dict[str, str] = {
            "dispatch_count": str(len(results)),
            "succeeded_count": str(succeeded),
            "total_issues": str(len(entries)),
            "dispatch_results": json.dumps(results),
        }

        if any_escalation:
            meta["workflow_status"] = "escalation"
        elif all_success:
            meta["workflow_status"] = "success"
        else:
            meta["workflow_status"] = "failed"

        return Artifact(
            artifact_id=ArtifactId(str(uuid.uuid4())),
            workflow_id=plan.workflow_id,
            content="\n".join(summary_lines),
            previous_attempt_id=None,
            parent_action_pair_id=None,
            action_pair_id=plan.action_pair_id,
            created_at=datetime.now().isoformat(),
            attempt_number=plan.attempt_number,
            status=ArtifactStatus.ACCEPTED if all_success else ArtifactStatus.REJECTED,
            guard_result=None,
            context=ContextSnapshot(
                workflow_id=plan.workflow_id,
                specification="",
                constraints="",
                feedback_history=(),
            ),
            metadata=MappingProxyType(meta),
        )

    @staticmethod
    def _parse_plan(content: str) -> list[dict[str, str]]:
        """Parse plan artifact content as a JSON array of dispatch entries."""
        content = content.strip()
        if not content:
            raise ValueError(
                "Empty plan artifact — expected JSON array of dispatch entries"
            )
        try:
            entries = json.loads(content)
        except json.JSONDecodeError as e:
            raise ValueError(f"Plan artifact is not valid JSON: {e}") from e

        if not isinstance(entries, list):
            raise ValueError(
                f"Plan artifact must be a JSON array, got {type(entries).__name__}"
            )

        for i, entry in enumerate(entries):
            if not isinstance(entry, dict):
                raise ValueError(f"Entry {i} is not a JSON object")
            if "workflow" not in entry:
                raise ValueError(f"Entry {i} missing 'workflow' field")
            if "spec" not in entry:
                raise ValueError(f"Entry {i} missing 'spec' field")

        return entries
