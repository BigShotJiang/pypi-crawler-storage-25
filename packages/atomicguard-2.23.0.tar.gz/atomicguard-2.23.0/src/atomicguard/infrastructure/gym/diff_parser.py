"""Git diff parser for extracting change-type observation features.

Parses unified diff strings to extract:
- File categories (source/test/config/docs) from paths
- Lines changed count
- Language from file extensions

These features are used as per-instance observation constants in the RL
state, enabling the policy to learn different AP orderings for different
types of code changes.
"""

from __future__ import annotations

import re

# File extension → language encoding
_EXTENSION_TO_LANGUAGE: dict[str, int] = {
    ".py": 1,  # python
    ".pyw": 1,
    ".pyi": 1,
    ".go": 2,  # go
    ".js": 3,  # javascript
    ".jsx": 3,
    ".mjs": 3,
    ".cjs": 3,
    ".ts": 4,  # typescript
    ".tsx": 4,
    ".mts": 4,
    ".cts": 4,
}

# Patterns for file category detection
_CONFIG_PATTERNS: tuple[str, ...] = (
    "setup.py",
    "setup.cfg",
    "pyproject.toml",
    "package.json",
    "tsconfig.json",
    "go.mod",
    "go.sum",
    "Makefile",
    "Dockerfile",
    "docker-compose",
    ".yml",
    ".yaml",
    ".toml",
    ".cfg",
    ".ini",
    ".conf",
    ".json",
    ".lock",
    "justfile",
    "Justfile",
    ".env",
)

_DOCS_PATTERNS: tuple[str, ...] = (
    ".md",
    ".rst",
    ".txt",
    "README",
    "CHANGELOG",
    "LICENSE",
    "CONTRIBUTING",
    "docs/",
    "doc/",
)

# Regex to match diff file headers: --- a/path or +++ b/path
_DIFF_FILE_RE = re.compile(r"^(?:\+\+\+|---) [ab]/(.+)$", re.MULTILINE)

# Regex to match hunk headers: @@ -start,count +start,count @@
_HUNK_RE = re.compile(r"^@@ -\d+(?:,\d+)? \+\d+(?:,\d+)? @@", re.MULTILINE)


def _classify_file(path: str) -> int:
    """Classify a file path into a category.

    Returns:
        0=unknown, 1=source, 2=test, 3=config, 4=docs.
    """
    lower = path.lower()
    basename = lower.rsplit("/", 1)[-1]

    # Test files
    if (
        basename.startswith("test_")
        or basename.endswith("_test.py")
        or basename.endswith("_test.go")
        or basename.endswith(".test.js")
        or basename.endswith(".test.ts")
        or basename.endswith(".test.tsx")
        or basename.endswith(".test.jsx")
        or basename.endswith(".spec.js")
        or basename.endswith(".spec.ts")
        or basename.endswith(".spec.tsx")
        or "tests/" in lower
        or "/test/" in lower
        or "/__tests__/" in lower
    ):
        return 2  # test

    # Docs
    for pattern in _DOCS_PATTERNS:
        if pattern in lower:
            return 4  # docs

    # Config
    for pattern in _CONFIG_PATTERNS:
        if lower.endswith(pattern) or basename == pattern.lower():
            return 3  # config

    # Source (any recognized programming language extension)
    for ext in _EXTENSION_TO_LANGUAGE:
        if lower.endswith(ext):
            return 1  # source

    return 0  # unknown


def _detect_language(path: str) -> int:
    """Detect language from file extension.

    Returns:
        0=unknown, 1=python, 2=go, 3=javascript, 4=typescript, 5=mixed.
    """
    lower = path.lower()
    for ext, lang in _EXTENSION_TO_LANGUAGE.items():
        if lower.endswith(ext):
            return lang
    return 0  # unknown


def _count_changed_lines(diff: str) -> int:
    """Count the number of added/removed lines in a unified diff."""
    count = 0
    for line in diff.splitlines():
        if (line.startswith("+") and not line.startswith("+++")) or (
            line.startswith("-") and not line.startswith("---")
        ):
            count += 1
    return count


def _encode_change_size(lines_changed: int) -> int:
    """Encode line count into change size category.

    Returns:
        0=unknown, 1=small (<10), 2=medium (<100), 3=large (100+).
    """
    if lines_changed <= 0:
        return 0
    if lines_changed < 10:
        return 1
    if lines_changed < 100:
        return 2
    return 3


def parse_diff(diff: str) -> dict[str, int]:
    """Parse a git diff string and extract change-type features.

    Args:
        diff: A unified diff string (output of ``git diff``).

    Returns:
        Dict with keys:
        - ``file_category``: 0=unknown, 1=source, 2=test, 3=config, 4=docs
        - ``change_size``: 0=unknown, 1=small, 2=medium, 3=large
        - ``language``: 0=unknown, 1=python, 2=go, 3=javascript, 4=typescript, 5=mixed
    """
    if not diff or not diff.strip():
        return {"file_category": 0, "change_size": 0, "language": 0}

    # Extract file paths from diff headers
    files = _DIFF_FILE_RE.findall(diff)
    # Deduplicate (--- and +++ both match the same file in renames)
    unique_files = list(dict.fromkeys(files))

    if not unique_files:
        return {"file_category": 0, "change_size": 0, "language": 0}

    # Aggregate file categories
    categories: set[int] = set()
    languages: set[int] = set()

    for path in unique_files:
        cat = _classify_file(path)
        if cat:
            categories.add(cat)
        lang = _detect_language(path)
        if lang:
            languages.add(lang)

    # Determine dominant file category (pick the most common non-zero, or first)
    if len(categories) == 1:
        file_category = categories.pop()
    elif len(categories) > 1:
        # Mixed: prefer source > test > config > docs
        for priority in (1, 2, 3, 4):
            if priority in categories:
                file_category = priority
                break
        else:
            file_category = 0
    else:
        file_category = 0

    # Determine language
    if len(languages) == 1:
        language = languages.pop()
    elif len(languages) > 1:
        language = 5  # mixed
    else:
        language = 0

    # Count changed lines
    lines_changed = _count_changed_lines(diff)
    change_size = _encode_change_size(lines_changed)

    return {
        "file_category": file_category,
        "change_size": change_size,
        "language": language,
    }
