"""PreCommitGym — pre-commit quality gate gym.

Proves that the gym abstraction generalises beyond benchmark TDD.
Uses deterministic subprocess-based APs (format, lint, typecheck,
test) and stochastic LLM-based fix APs (type fix, test fix) with a
commit-readiness gate as the goal AP.  The RL agent learns optimal
check-fix-recheck sequences per change type.

Each instance runs inside a Docker container (``python:3.12-slim``
with ruff, mypy, pytest pre-installed) for isolation.  The container
is started once per ``build_environment`` call and reused across
episodes for that instance.
"""

from __future__ import annotations

import json
import logging
import shutil
import subprocess
import tempfile
from pathlib import Path
from typing import Any

from atomicguard.domain.gym import GymInstance, GymInterface, GymManifest
from atomicguard.domain.interfaces import (
    ArtifactDAGInterface,
    EnvironmentInterface,
)
from atomicguard.domain.rl.reward import RewardFunctionInterface

logger = logging.getLogger(__name__)

_DATA_DIR = Path(__file__).parent / "precommit_data"

# Docker image for isolated subprocess execution.
PRECOMMIT_DOCKER_IMAGE = "atomicguard-precommit:latest"

# Dockerfile content for building the precommit image.
_DOCKERFILE = """\
FROM python:3.12-slim
RUN pip install --no-cache-dir ruff mypy pytest
WORKDIR /workspace
"""

# AP ID → subprocess command template.
# ``{target}`` is replaced with the target file path at build time.
# When running inside Docker, paths are relative to /workspace.
_AP_COMMANDS: dict[str, list[str]] = {
    # Check APs — detect issues (exit 0 = clean)
    "ap_format": ["ruff", "format", "--diff", "{target}"],
    "ap_lint_check": ["ruff", "check", "{target}"],
    "ap_typecheck": ["mypy", "--ignore-missing-imports", "{target}"],
    "ap_unit_test": ["python", "-m", "pytest", "{test_target}", "-x", "-q"],
    # Deterministic fix APs — auto-fix tools (exit 0 = fix succeeded)
    "ap_fix_format": ["ruff", "format", "{target}"],
    "ap_fix_lint": ["ruff", "check", "--fix", "{target}"],
    # Goal AP
    "ap_commit_ready": ["echo", "ok"],
}

# LLM fix APs use LLMContainerFixGenerator — these are the verification
# commands run *after* the LLM writes corrected code to the container.
_AP_VERIFY_COMMANDS: dict[str, list[str]] = {
    "ap_fix_lint_llm": ["ruff", "check", "{target}"],
    "ap_fix_types": ["mypy", "--ignore-missing-imports", "{target}"],
    "ap_fix_tests": ["python", "-m", "pytest", "{test_target}", "-x", "-q"],
}

# APs that use LLMContainerFixGenerator instead of SubprocessGenerator.
_LLM_FIX_APS: frozenset[str] = frozenset(_AP_VERIFY_COMMANDS)

VALID_CONSTRAINT_MODES = ("unconstrained", "physical_only", "preserve")


def _docker_available() -> bool:
    """Check if Docker is available on the host."""
    try:
        result = subprocess.run(
            ["docker", "info"],
            capture_output=True,
            timeout=10,
        )
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False


def _ensure_docker_image() -> None:
    """Build the precommit Docker image if it doesn't exist."""
    result = subprocess.run(
        ["docker", "image", "inspect", PRECOMMIT_DOCKER_IMAGE],
        capture_output=True,
    )
    if result.returncode == 0:
        return
    logger.info("Building Docker image %s...", PRECOMMIT_DOCKER_IMAGE)
    tmpdir = Path(tempfile.mkdtemp(prefix="precommit_docker_"))
    try:
        dockerfile = tmpdir / "Dockerfile"
        dockerfile.write_text(_DOCKERFILE)
        subprocess.run(
            ["docker", "build", "-t", PRECOMMIT_DOCKER_IMAGE, str(tmpdir)],
            check=True,
            capture_output=True,
        )
    finally:
        shutil.rmtree(tmpdir, ignore_errors=True)


def _start_container(instance_dir: Path) -> str:
    """Start a Docker container with instance_dir mounted at /workspace.

    Returns the container ID.
    """
    result = subprocess.run(
        [
            "docker",
            "run",
            "-d",
            "--rm",
            "-v",
            f"{instance_dir}:/workspace",
            "-w",
            "/workspace",
            PRECOMMIT_DOCKER_IMAGE,
            "sleep",
            "3600",
        ],
        capture_output=True,
        text=True,
        check=True,
    )
    container_id = result.stdout.strip()
    logger.debug("Started container %s for %s", container_id[:12], instance_dir)
    return container_id


def _stop_container(container_id: str) -> None:
    """Stop and remove a Docker container."""
    try:
        subprocess.run(
            ["docker", "stop", "--time", "3", container_id],
            capture_output=True,
            timeout=10,
        )
    except (subprocess.TimeoutExpired, FileNotFoundError) as e:
        logger.debug("Failed to stop container %s: %s", container_id[:12], e)


class PreCommitGym(GymInterface):
    """Pre-commit quality gate gym.

    Provides 15 synthetic Python modules with known lint, format,
    type, and test issues.  Each instance runs inside a Docker
    container for isolation.

    Args:
        constraint_mode: How ``requires`` constraints are handled.
            ``"unconstrained"`` for free exploration (default for training),
            ``"physical_only"`` for physical preconditions only,
            ``"preserve"`` for exact workflow JSON constraints.
        workflow_file: WorkflowOrchestrator JSON filename inside ``precommit_data/``.
            Defaults to ``"workflow_training.json"`` (fix-only, no check APs).
            Use ``"workflow.json"`` for the full check+fix production workflow.
        ap_context_file: AP context JSON filename inside ``precommit_data/``.
            Defaults to ``"ap_context_training.json"`` (prompts without upstream
            check artifact references). Use ``"ap_context.json"`` for the full
            check+fix context.
        model: LLM model ID for stochastic fix APs.
        provider: LLM provider (``"ollama"``, ``"openrouter"``, etc.).
        base_url: LLM API base URL.
        api_key: LLM API key.
        llm_timeout: Timeout in seconds for LLM calls and verify commands.
    """

    def __init__(
        self,
        constraint_mode: str = "preserve",
        *,
        workflow_file: str = "workflow_training.json",
        ap_context_file: str = "ap_context_training.json",
        model: str = "qwen3-coder-next",
        provider: str = "ollama",
        base_url: str = "http://localhost:11434/v1",
        api_key: str = "ollama",
        llm_timeout: int = 120,
        action_pair_cls: type | None = None,
        workflow_cls: type | None = None,
        agent_cls: type | None = None,
        **_kwargs: Any,
    ) -> None:
        """
        Args:
            constraint_mode: How ``requires`` constraints are handled.
            workflow_file: WorkflowOrchestrator JSON filename.
            ap_context_file: AP context JSON filename.
            model: LLM model ID for stochastic fix APs.
            provider: LLM provider.
            base_url: LLM API base URL.
            api_key: LLM API key.
            llm_timeout: Timeout in seconds for LLM calls and verify commands.
            action_pair_cls: Class to instantiate for each action pair.
                Must be provided — typically ``ActionPair`` from the application
                layer.  Inject an alternative for testing or custom behaviour.
            workflow_cls: Class to instantiate for the workflow pool.
                Must be provided — typically ``WorkflowOrchestrator`` from the application
                layer.  Inject an alternative for testing or custom behaviour.
            agent_cls: Agent class passed through to ``TrainingEnvironment``.
                Must be provided — typically ``DualStateAgent`` from the
                application layer.
        """
        if constraint_mode not in VALID_CONSTRAINT_MODES:
            raise ValueError(
                f"Unknown constraint_mode: {constraint_mode!r}. "
                f"Valid: {', '.join(VALID_CONSTRAINT_MODES)}"
            )
        self._constraint_mode = constraint_mode
        self._workflow_file = workflow_file
        self._ap_context_file = ap_context_file
        self._model = model
        self._provider = provider
        self._base_url = base_url
        self._api_key = api_key
        self._llm_timeout = llm_timeout
        self._action_pair_cls: type | None = action_pair_cls
        self._workflow_cls: type | None = workflow_cls
        self._agent_cls: type | None = agent_cls
        self._instances: list[GymInstance] | None = None
        self._ap_ids: tuple[str, ...] | None = None
        self._use_docker: bool | None = None
        self._containers: list[str] = []
        self._instance_dirs: list[Path] = []

    def _should_use_docker(self) -> bool:
        """Determine whether to use Docker (cached)."""
        if self._use_docker is None:
            self._use_docker = _docker_available()
            if self._use_docker:
                try:
                    _ensure_docker_image()
                except (subprocess.CalledProcessError, FileNotFoundError):
                    logger.warning(
                        "Docker image build failed, falling back to host execution"
                    )
                    self._use_docker = False
        return self._use_docker

    def _load_instances(self) -> list[GymInstance]:
        """Load synthetic pre-commit instances."""
        from atomicguard.infrastructure.gym.precommit_data.dataset import (
            get_precommit_instances,
        )

        raw = get_precommit_instances()
        return [
            GymInstance(
                instance_id=inst.instance_id,
                specification=inst.description,
                tier=inst.tier,
                context={
                    "module_content": inst.module_content,
                    "test_content": inst.test_content,
                    "issues": sorted(inst.issues),
                },
            )
            for inst in raw
        ]

    def get_instances(self, limit: int | None = None) -> list[GymInstance]:
        if self._instances is None:
            self._instances = self._load_instances()
        instances = self._instances
        if limit is not None:
            instances = instances[:limit]
        return instances

    def _load_workflow_config(self) -> dict[str, Any]:
        with open(_DATA_DIR / self._workflow_file) as f:
            result: dict[str, Any] = json.load(f)
            return result

    def _load_ap_context(self) -> dict[str, Any]:
        with open(_DATA_DIR / self._ap_context_file) as f:
            result: dict[str, Any] = json.load(f)
            return result

    def _validate_constraint_mode(self, config: dict[str, Any]) -> None:
        if self._constraint_mode != "unconstrained":
            return
        action_pairs = config.get("action_pairs", {})
        for ap_id, ap_def in action_pairs.items():
            requires = ap_def.get("requires", [])
            if requires:
                raise ValueError(
                    f"constraint_mode='unconstrained' but AP {ap_id!r} has "
                    f"non-empty requires: {requires}."
                )

    def _setup_instance_dir(self, instance: GymInstance) -> Path:
        """Write instance files to a temp directory and return the path."""
        tmpdir = Path(tempfile.mkdtemp(prefix=f"precommit_{instance.instance_id}_"))
        self._instance_dirs.append(tmpdir)

        module_content = instance.context.get("module_content", "")
        test_content = instance.context.get("test_content", "")

        module_path = tmpdir / "module.py"
        module_path.write_text(module_content)

        test_path = tmpdir / "test_module.py"
        if test_content:
            test_path.write_text(test_content)
        else:
            # Trivial passing test so ap_unit_test never errors on missing file
            test_path.write_text("def test_placeholder():\n    pass\n")

        return tmpdir

    def _build_workflow_for_instance(
        self,
        instance: GymInstance,
        artifact_dag: ArtifactDAGInterface,
    ) -> tuple[Any, Path]:
        """Build a WorkflowOrchestrator and instance dir for a GymInstance.

        Shared setup used by both ``build_environment()`` and
        ``build_action_pair_pool_from_file()``.

        Returns:
            ``(workflow, instance_dir)`` tuple.
        """
        if self._action_pair_cls is None or self._workflow_cls is None:
            raise RuntimeError(
                "PreCommitGym requires action_pair_cls and workflow_cls to be injected "
                "at construction time. Pass them as keyword arguments:\n\n"
                "    from atomicguard.application.action_pair import ActionPair\n"
                "    from atomicguard.application.workflow import WorkflowOrchestrator\n"
                "    gym = PreCommitGym(action_pair_cls=ActionPair, workflow_cls=WorkflowOrchestrator)"
            )
        ActionPair = self._action_pair_cls  # noqa: N806
        WorkflowOrchestrator = self._workflow_cls  # noqa: N806
        from atomicguard.domain.interfaces import GuardInterface
        from atomicguard.domain.prompts import PromptTemplate
        from atomicguard.infrastructure.generators import SubprocessGenerator
        from atomicguard.infrastructure.guards import (
            AllPassedGuard,
            ContainerSubprocessGuard,
            DiffEmptyGuard,
            ExitCodeGuard,
        )
        from atomicguard.infrastructure.gym.precommit_generators import (
            LLMContainerFixGenerator,
        )

        config = self._load_workflow_config()
        self._validate_constraint_mode(config)
        ap_context_data = self._load_ap_context()

        # Set up instance files on disk
        instance_dir = self._setup_instance_dir(instance)

        # Docker isolation: start a container if Docker is available
        use_docker = self._should_use_docker()
        container_id: str | None = None
        if use_docker:
            container_id = _start_container(instance_dir)
            self._containers.append(container_id)
            # Inside Docker, files are at /workspace/
            target_path = "/workspace/module.py"
            test_target_path = "/workspace/test_module.py"
        else:
            target_path = str(instance_dir / "module.py")
            test_target_path = str(instance_dir / "test_module.py")

        rmax = config.get("rmax", 1)
        workflow = WorkflowOrchestrator(artifact_dag=artifact_dag, rmax=rmax)

        action_pairs = config.get("action_pairs", {})
        for ap_id, ap_def in action_pairs.items():
            # LLM fix APs: generator calls LLM + writes file; guard runs the verify command
            if ap_id in _LLM_FIX_APS:
                verify_cmd_template = _AP_VERIFY_COMMANDS[ap_id]
                verify_command = [
                    part.replace("{target}", target_path).replace(
                        "{test_target}", test_target_path
                    )
                    for part in verify_cmd_template
                ]
                generator: SubprocessGenerator | LLMContainerFixGenerator = (
                    LLMContainerFixGenerator(
                        model=self._model,
                        provider=self._provider,
                        base_url=self._base_url,
                        api_key=self._api_key,
                        container_id=container_id,
                        target_path=target_path,
                        timeout=self._llm_timeout,
                    )
                )
                guard: GuardInterface = ContainerSubprocessGuard(
                    command=verify_command,
                    container_id=container_id,
                    timeout=self._llm_timeout,
                )
            else:
                # Deterministic APs use SubprocessGenerator + metadata-based guard
                cmd_template = _AP_COMMANDS.get(ap_id, ["echo", "unknown-ap"])
                command = [
                    part.replace("{target}", target_path).replace(
                        "{test_target}", test_target_path
                    )
                    for part in cmd_template
                ]
                generator = SubprocessGenerator(
                    command=command,
                    cwd=str(instance_dir),
                    docker_container_id=container_id,
                )
                guard_name = ap_def.get("guard", "exit_code")
                if guard_name == "diff_empty":
                    guard = DiffEmptyGuard()
                elif guard_name == "all_passed":
                    guard = AllPassedGuard()
                else:
                    guard = ExitCodeGuard()

            # Build prompt template
            ctx = ap_context_data.get(ap_id, {})
            template = PromptTemplate(
                role=ctx.get("role", ""),
                constraints=ctx.get("constraints", ""),
                task=ctx.get("task", ""),
                feedback_wrapper=ctx.get("feedback_wrapper"),
            )

            action_pair = ActionPair(
                generator=generator,
                guard=guard,
                prompt_template=template,
            )

            requires = tuple(ap_def.get("requires", []))
            artifact_type = ap_def.get("artifact_type")
            goal = ap_def.get("goal", False)

            # Artifact context from AP context JSON
            artifact_context = ctx.get("artifact_context")

            workflow.add_step(
                ap_id,
                action_pair,
                requires=requires,
                artifact_type=artifact_type,
                artifact_context=artifact_context,
                goal=goal,
            )

        return workflow, instance_dir

    def build_environment(
        self,
        instance: GymInstance,
        reward_fn: RewardFunctionInterface,
        artifact_dag: ArtifactDAGInterface,
        *,
        max_steps: int | None = None,
        enable_backtracking: bool = False,
        max_selections_per_ap: int | None = None,
    ) -> EnvironmentInterface:
        """Build a training environment for one pre-commit instance.

        Writes the instance's module and test files to a temp directory,
        optionally starts a Docker container, then wires up subprocess-based
        APs to operate on those files.
        """
        from atomicguard.infrastructure.rl.environment import TrainingEnvironment

        workflow, instance_dir = self._build_workflow_for_instance(
            instance, artifact_dag
        )

        # Capture original file content for episode reset (files are mutated by LLM fix APs)
        original_module = instance.context.get("module_content", "")
        original_test = instance.context.get("test_content", "")
        if not original_test:
            original_test = "def test_placeholder():\n    pass\n"

        def _reset_instance_files() -> None:
            """Write original (broken) files back to disk/container before each episode."""
            module_path = instance_dir / "module.py"
            test_path = instance_dir / "test_module.py"
            module_path.write_text(original_module)
            test_path.write_text(original_test)
            logger.debug("Reset instance files for %s", instance.instance_id)

        if self._agent_cls is None:
            raise RuntimeError(
                "PreCommitGym requires agent_cls to be injected at construction time.\n"
                "Pass it as a keyword argument:\n\n"
                "    from atomicguard.application.agent import DualStateAgent\n"
                "    gym = PreCommitGym(..., agent_cls=DualStateAgent)"
            )
        return TrainingEnvironment(
            workflow=workflow,
            specification=instance.specification,
            reward_fn=reward_fn,
            max_steps=max_steps,
            artifact_dag=artifact_dag,
            enable_backtracking=enable_backtracking,
            max_selections_per_ap=max_selections_per_ap,
            on_reset=_reset_instance_files,
            agent_cls=self._agent_cls,
        )

    def _prepare_instance_for_file(
        self, file_path: Path
    ) -> tuple[GymInstance, Path | None, Path]:
        """Read a source file and create the shared artefacts needed by
        both ``build_environment_from_file`` and
        ``build_action_pair_pool_from_file``.

        Extracts the three repeated blocks:
        1. File read + project-root walk (``pyproject.toml``).
        2. ``GymInstance`` construction.
        3. DAG temp-dir creation and tracking for cleanup.

        Args:
            file_path: Real source file to process.

        Returns:
            ``(instance, project_root, dag_tmpdir)`` where *project_root*
            is ``None`` when no ``pyproject.toml`` was found.
        """
        content = file_path.read_text()

        # Find project root (dir containing pyproject.toml) for config copy.
        project_root: Path | None = None
        candidate = file_path.resolve().parent
        while candidate.parent != candidate:
            if (candidate / "pyproject.toml").exists():
                project_root = candidate
                break
            candidate = candidate.parent

        instance = GymInstance(
            instance_id=file_path.name,
            specification=f"Fix pre-commit issues in {file_path.name}",
            tier=0,
            context={
                "module_content": content,
                "test_content": "",
                "issues": [],
            },
        )

        dag_tmpdir = Path(tempfile.mkdtemp(prefix=f"precommit_dag_{file_path.name}_"))
        self._instance_dirs.append(dag_tmpdir)

        return instance, project_root, dag_tmpdir

    @staticmethod
    def _copy_project_config(project_root: Path | None, instance_dir: Path) -> None:
        """Copy ruff/mypy config files from *project_root* into *instance_dir*.

        No-op when *project_root* is ``None``.
        """
        if project_root is None:
            return
        for cfg_file in ("pyproject.toml", "mypy.ini", "setup.cfg", ".mypy.ini"):
            src = project_root / cfg_file
            if src.exists():
                shutil.copy2(src, instance_dir / cfg_file)

    def build_environment_from_file(
        self,
        file_path: Path,
        reward_fn: RewardFunctionInterface,
        *,
        max_steps: int | None = None,
        enable_backtracking: bool = False,
        max_selections_per_ap: int | None = None,
    ) -> tuple[object, Path]:
        """Build a single-episode environment from a real source file.

        Reads ``file_path``, wraps it in a ``GymInstance``, sets up a
        temporary instance directory, and returns a ready-to-run
        ``TrainingEnvironment`` alongside the instance directory path.

        After a successful episode, the caller can read the fixed file
        content from ``instance_dir / "module.py"``.

        No ``on_reset`` callback is wired — this environment is for a
        single production episode, not multi-episode training.

        Args:
            file_path: Real source file to fix.
            reward_fn: Reward function for the episode.
            max_steps: Step budget (None = auto from workflow config).
            enable_backtracking: Allow backtracking in the episode.
            max_selections_per_ap: Max AP selections per episode.

        Returns:
            ``(env, instance_dir)`` tuple.
        """
        from atomicguard.infrastructure.persistence.filesystem import (
            FilesystemArtifactDAG,
        )

        instance, project_root, dag_tmpdir = self._prepare_instance_for_file(file_path)

        # Snapshot the instance_dirs count so we can find which dir
        # build_environment creates internally.
        # _prepare_instance_for_file already appended dag_tmpdir, so subtract 1.
        dirs_before = len(self._instance_dirs) - 1

        artifact_dag = FilesystemArtifactDAG(str(dag_tmpdir))

        env = self.build_environment(
            instance=instance,
            reward_fn=reward_fn,
            artifact_dag=artifact_dag,
            max_steps=max_steps,
            enable_backtracking=enable_backtracking,
            max_selections_per_ap=max_selections_per_ap,
        )

        # build_environment called _setup_instance_dir which appended the new
        # temp dir.  That is the dir Docker has bind-mounted at /workspace.
        instance_dir = self._instance_dirs[dirs_before]

        # Copy project ruff/mypy config so Docker sees the same ruleset as the
        # host pre-commit hook.  The container uses a bind mount so files
        # written here are immediately visible inside the running container.
        self._copy_project_config(project_root, instance_dir)

        return env, instance_dir

    def build_action_pair_pool_from_file(
        self,
        file_path: Path,
    ) -> tuple[Any, Path, str]:
        """Build an ActionPairPoolInterface (WorkflowOrchestrator) from a real source file.

        Unlike ``build_environment_from_file`` which returns a
        ``TrainingEnvironment`` (RL training abstraction), this returns the
        raw ``WorkflowOrchestrator`` for use with ``WorkflowOrchestrator.execute()`` — getting retry,
        backtracking, cascade invalidation, and escalation from the
        production framework.

        Args:
            file_path: Real source file to fix.

        Returns:
            ``(workflow, instance_dir, specification)`` tuple where
            *workflow* implements ``ActionPairPoolInterface``.
        """
        from atomicguard.infrastructure.persistence.filesystem import (
            FilesystemArtifactDAG,
        )

        instance, project_root, dag_tmpdir = self._prepare_instance_for_file(file_path)

        artifact_dag = FilesystemArtifactDAG(str(dag_tmpdir))

        workflow, instance_dir = self._build_workflow_for_instance(
            instance, artifact_dag
        )

        # Copy project config so guards see the same ruleset as the host.
        self._copy_project_config(project_root, instance_dir)

        return workflow, instance_dir, instance.specification

    def get_workflow_definition(self) -> Any:
        """Return the gym's WorkflowDefinition from its JSON config.

        Pure read — same result every call, independent of any file or
        policy.  Pass the result to ``PolicyExporter.export()`` to
        derive policy-ordered ``requires`` edges, then pass the exported
        definition to ``build_orchestrator_from_definition()``.
        """
        from atomicguard.domain.models import ActionPairDefinition, WorkflowDefinition

        config = self._load_workflow_config()
        action_pairs_raw = config.get("action_pairs", {})
        ap_defs = tuple(
            ActionPairDefinition(
                ap_id=ap_id,
                requires=tuple(ap_def.get("requires", [])),
                artifact_type=ap_def.get("artifact_type", ""),
                goal=ap_def.get("goal", False),
                guard=ap_def.get("guard", ""),
            )
            for ap_id, ap_def in action_pairs_raw.items()
        )
        return WorkflowDefinition(
            slug="precommit_python",
            name="PreCommit Python",
            description="Pre-commit quality gate workflow",
            rmax=config.get("rmax", 1),
            action_pairs=ap_defs,
        )

    def prepare_instance(self, file_path: Path) -> Any:
        """Prepare a real source file for policy execution.

        Creates a temp directory, copies the file, and returns a
        ``GymInstanceContext`` with the instance directory path and
        specification string.

        This method is the ``prepare_instance`` step of the three-phase
        production lifecycle::

            base_def = gym.get_workflow_definition()
            exported_def = PolicyExporter(policy).export(base_def)
            ctx = gym.prepare_instance(file_path)
            executor = gym.build_orchestrator_from_definition(exported_def)
            result = executor.execute(ctx.specification)
        """
        from atomicguard.domain.gym import GymInstanceContext
        from atomicguard.infrastructure.persistence.filesystem import (
            FilesystemArtifactDAG,
        )

        instance, project_root, dag_tmpdir = self._prepare_instance_for_file(file_path)
        artifact_dag = FilesystemArtifactDAG(str(dag_tmpdir))

        # Set up Docker / instance files — reuse existing workflow build for side effects,
        # but only take the instance_dir from it.
        _workflow, instance_dir = self._build_workflow_for_instance(
            instance, artifact_dag
        )
        self._copy_project_config(project_root, instance_dir)

        # Store artifact_dag on instance for later use by build_orchestrator_from_definition
        self._last_artifact_dag = artifact_dag
        self._last_instance = instance

        return GymInstanceContext(
            instance_dir=instance_dir,
            specification=instance.specification,
        )

    def build_orchestrator_from_definition(self, definition: Any) -> Any:
        """Build a WorkflowExecutorInterface from a (possibly reordered) definition.

        The gym owns the registry wiring (generators, guards, Docker);
        the caller owns the definition (possibly policy-reordered via
        ``PolicyExporter.export()``).

        Must be called after ``prepare_instance()`` which sets up the
        Docker container and instance files that generators/guards use.
        """
        if self._action_pair_cls is None or self._workflow_cls is None:
            raise RuntimeError(
                "PreCommitGym requires action_pair_cls and workflow_cls to be injected "
                "at construction time."
            )
        ActionPair = self._action_pair_cls  # noqa: N806
        WorkflowOrchestrator = self._workflow_cls  # noqa: N806
        from atomicguard.domain.interfaces import GuardInterface
        from atomicguard.domain.prompts import PromptTemplate
        from atomicguard.infrastructure.generators import SubprocessGenerator
        from atomicguard.infrastructure.guards import (
            AllPassedGuard,
            ContainerSubprocessGuard,
            DiffEmptyGuard,
            ExitCodeGuard,
        )
        from atomicguard.infrastructure.gym.precommit_generators import (
            LLMContainerFixGenerator,
        )

        # Reuse last artifact dag and instance from prepare_instance()
        if not hasattr(self, "_last_artifact_dag") or not hasattr(
            self, "_last_instance"
        ):
            raise RuntimeError(
                "build_orchestrator_from_definition() must be called after prepare_instance()."
            )
        artifact_dag = self._last_artifact_dag

        config = self._load_workflow_config()
        ap_context_data = self._load_ap_context()

        use_docker = self._should_use_docker()
        container_id = self._containers[-1] if use_docker and self._containers else None
        instance_dir = self._instance_dirs[-1] if self._instance_dirs else None
        if instance_dir is None:
            raise RuntimeError(
                "No instance directory available. Call prepare_instance() first."
            )

        if use_docker:
            target_path = "/workspace/module.py"
            test_target_path = "/workspace/test_module.py"
        else:
            target_path = str(instance_dir / "module.py")
            test_target_path = str(instance_dir / "test_module.py")

        workflow = WorkflowOrchestrator(artifact_dag=artifact_dag, rmax=definition.rmax)

        # Build AP id → requires mapping from the exported definition
        definition_requires: dict[str, tuple[str, ...]] = {
            ap.ap_id: ap.requires for ap in definition.action_pairs
        }

        action_pairs_raw = config.get("action_pairs", {})
        # Iterate in definition order to respect policy ordering
        definition_ap_ids = [ap.ap_id for ap in definition.action_pairs]
        # Fall back to config order for APs not in definition
        all_ap_ids = definition_ap_ids + [
            ap_id for ap_id in action_pairs_raw if ap_id not in set(definition_ap_ids)
        ]

        for ap_id in all_ap_ids:
            if ap_id not in action_pairs_raw:
                continue
            ap_def = action_pairs_raw[ap_id]

            if ap_id in _LLM_FIX_APS:
                verify_cmd_template = _AP_VERIFY_COMMANDS[ap_id]
                verify_command = [
                    part.replace("{target}", target_path).replace(
                        "{test_target}", test_target_path
                    )
                    for part in verify_cmd_template
                ]
                generator: SubprocessGenerator | LLMContainerFixGenerator = (
                    LLMContainerFixGenerator(
                        model=self._model,
                        provider=self._provider,
                        base_url=self._base_url,
                        api_key=self._api_key,
                        container_id=container_id,
                        target_path=target_path,
                        timeout=self._llm_timeout,
                    )
                )
                guard: GuardInterface = ContainerSubprocessGuard(
                    command=verify_command,
                    container_id=container_id,
                    timeout=self._llm_timeout,
                )
            else:
                cmd_template = _AP_COMMANDS.get(ap_id, ["echo", "unknown-ap"])
                command = [
                    part.replace("{target}", target_path).replace(
                        "{test_target}", test_target_path
                    )
                    for part in cmd_template
                ]
                generator = SubprocessGenerator(
                    command=command,
                    cwd=str(instance_dir),
                    docker_container_id=container_id,
                )
                guard_name = ap_def.get("guard", "exit_code")
                if guard_name == "diff_empty":
                    guard = DiffEmptyGuard()
                elif guard_name == "all_passed":
                    guard = AllPassedGuard()
                else:
                    guard = ExitCodeGuard()

            ctx = ap_context_data.get(ap_id, {})
            template = PromptTemplate(
                role=ctx.get("role", ""),
                constraints=ctx.get("constraints", ""),
                task=ctx.get("task", ""),
                feedback_wrapper=ctx.get("feedback_wrapper"),
            )
            action_pair = ActionPair(
                generator=generator,
                guard=guard,
                prompt_template=template,
            )

            # Use requires from the exported definition (policy ordering) if present,
            # otherwise fall back to the JSON config requires.
            requires = definition_requires.get(ap_id, tuple(ap_def.get("requires", [])))
            artifact_type = ap_def.get("artifact_type")
            goal = ap_def.get("goal", False)
            artifact_context = ctx.get("artifact_context")

            workflow.add_step(
                ap_id,
                action_pair,
                requires=requires,
                artifact_type=artifact_type,
                artifact_context=artifact_context,
                goal=goal,
            )

        return workflow

    def get_fixed_content(self, instance_dir: Path) -> str:
        """Read the fixed file content from an instance directory.

        After a successful policy episode, the fixed code lives at
        ``instance_dir / "module.py"``.
        """
        return (instance_dir / "module.py").read_text()

    def get_ap_ids(self) -> tuple[str, ...]:
        if self._ap_ids is None:
            config = self._load_workflow_config()
            self._ap_ids = tuple(config.get("action_pairs", {}).keys())
        return self._ap_ids

    def get_manifest(self) -> GymManifest:
        instances = self.get_instances()
        ap_ids = self.get_ap_ids()

        config = self._load_workflow_config()
        action_pairs = config.get("action_pairs", {})
        goal_aps = tuple(
            ap_id for ap_id, ap_def in action_pairs.items() if ap_def.get("goal", False)
        )

        tiers = tuple(sorted({inst.tier for inst in instances}))

        return GymManifest(
            name="precommit_python",
            description=(
                f"Pre-commit quality gate gym: {len(instances)} synthetic Python "
                f"modules across {len(tiers)} tiers. "
                f"4 deterministic check APs, 2 deterministic fix APs (ruff), "
                f"3 stochastic LLM fix APs (ruff non-auto-fixable, mypy, pytest), 1 goal AP."
            ),
            ap_ids=ap_ids,
            goal_aps=goal_aps,
            instance_count=len(instances),
            tiers=tiers,
            requires_docker=True,
            requires_llm=True,
            languages=("python",),
        )

    def cleanup(self) -> None:
        """Stop all containers and remove temp directories.

        Call this when the gym is no longer needed (e.g. after training
        completes).
        """
        for cid in self._containers:
            _stop_container(cid)
        self._containers.clear()

        for d in self._instance_dirs:
            shutil.rmtree(d, ignore_errors=True)
        self._instance_dirs.clear()

    def __del__(self) -> None:
        # Guard against __del__ being called when __init__ raised
        if hasattr(self, "_containers"):
            self.cleanup()
