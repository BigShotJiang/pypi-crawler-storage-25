"""LLM-based fix generator for Docker-isolated pre-commit checks.

Reads the current file from the container, asks the LLM to fix it given
guard feedback from an upstream check AP, and writes the fixed code back
to the container.  Returns the fixed code as the artifact content.

Verification (mypy, pytest, ruff) is the guard's responsibility —
``ContainerSubprocessGuard`` runs the verify command independently on
every attempt.  This generator never calls verification tools.

Domain-specific to the pre-commit gym — couples LLM calls with Docker
exec and file writes.  If this proves reusable, promote to
``infrastructure/generators/``.
"""

from __future__ import annotations

import asyncio
import logging
import subprocess
import uuid
from datetime import UTC, datetime
from types import MappingProxyType
from typing import Any

from atomicguard.domain.interfaces import GeneratorInterface
from atomicguard.domain.models import (
    ActionPairId,
    Artifact,
    ArtifactId,
    ArtifactStatus,
    Context,
    ContextSnapshot,
    WorkflowId,
)
from atomicguard.domain.prompts import PromptTemplate
from atomicguard.infrastructure.llm.factory import create_llm_model

logger = logging.getLogger(__name__)


class LLMContainerFixGenerator(GeneratorInterface):
    """LLM-based fix generator for Docker-isolated pre-commit checks.

    Responsibilities (generation only — no sensing):
    - First attempt (no guard feedback): return an empty artifact.
      The guard (``ContainerSubprocessGuard``) will run the verify command
      and return pass/fail with tool output as feedback.
    - Retry (feedback present): call the LLM with the guard's error output,
      write the corrected code back to the container, return an artifact
      whose content is the fixed code.

    The guard runs on every attempt — including the first — so the DSA
    loop always gets fresh sensing without the generator ever calling a
    verification tool.

    Args:
        model: LLM model ID (e.g. ``"qwen3-coder-next"``).
        provider: LLM provider (``"ollama"``, ``"openrouter"``, etc.).
        base_url: LLM API base URL.
        api_key: LLM API key.
        container_id: Docker container ID.  ``None`` = host-only fallback.
        target_path: Absolute path to the file to fix (inside container
            or on host).
        timeout: Subprocess timeout for file I/O operations in seconds.
    """

    def __init__(
        self,
        *,
        model: str,
        provider: str,
        base_url: str,
        api_key: str,
        container_id: str | None,
        target_path: str,
        timeout: int = 120,
        **_kwargs: Any,
    ) -> None:
        self._model = model
        self._provider = provider
        self._base_url = base_url
        self._api_key = api_key
        self._container_id = container_id
        self._target_path = target_path
        self._timeout = timeout

    def _read_file(self) -> str:
        """Read the target file from the container or host."""
        if self._container_id:
            result = subprocess.run(
                ["docker", "exec", self._container_id, "cat", self._target_path],
                capture_output=True,
                text=True,
                timeout=10,
            )
            return result.stdout
        from pathlib import Path

        return Path(self._target_path).read_text()

    def _write_file(self, content: str) -> None:
        """Write fixed content to the target file in the container or host."""
        if self._container_id:
            subprocess.run(
                [
                    "docker",
                    "exec",
                    "-i",
                    self._container_id,
                    "bash",
                    "-c",
                    f"cat > {self._target_path}",
                ],
                input=content,
                capture_output=True,
                text=True,
                timeout=10,
            )
        else:
            from pathlib import Path

            Path(self._target_path).write_text(content)

    def _call_llm(self, prompt: str) -> str:
        """Call the LLM and return the plain text response."""
        from pydantic_ai import Agent

        ai_model = create_llm_model(
            provider=self._provider,
            model=self._model,
            base_url=self._base_url,
            api_key=self._api_key,
            timeout=float(self._timeout),
        )
        agent: Agent[None, str] = Agent(
            ai_model,
            output_type=str,
            retries=0,
        )

        try:
            try:
                result = asyncio.run(agent.run(prompt))
            except RuntimeError:
                # Already inside a running event loop — run in a thread
                import concurrent.futures

                with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                    result = pool.submit(asyncio.run, agent.run(prompt)).result(
                        timeout=self._timeout
                    )
            return result.output
        except Exception:
            logger.exception("LLM call failed for fix generator")
            return ""

    def generate(
        self,
        context: Context,
        template: PromptTemplate,
        action_pair_id: str = "unknown",
        workflow_id: str = "unknown",
        workflow_ref: str | None = None,
    ) -> Artifact:
        """DSA feedback loop: no-op on first attempt, LLM-fix on retry.

        Attempt 1 (no feedback): return an empty artifact.  The guard
        (``ContainerSubprocessGuard``) will run the verify command and
        inject error output as feedback if the code is not clean.

        Attempt 2+ (feedback present): the guard's error output is in
        ``context.feedback_history``.  The LLM receives that feedback via
        the rendered prompt (``feedback_wrapper``), generates fixed code,
        which is written back to the container.  The artifact content is
        the fixed code.  The guard then re-runs the verify command.
        """
        # First attempt — no feedback yet, guard will do the sensing
        if not context.feedback_history:
            logger.debug(
                "LLMContainerFixGenerator.generate [%s]: no feedback → no-op (guard will sense)",
                action_pair_id,
            )
            return self._make_artifact(
                content="",
                workflow_id=workflow_id,
                action_pair_id=action_pair_id,
                context=context,
                workflow_ref=workflow_ref,
            )

        logger.debug(
            "LLMContainerFixGenerator.generate [%s]: feedback_history len=%d → calling LLM",
            action_pair_id,
            len(context.feedback_history),
        )
        # Retry — LLM fixes using guard feedback injected via feedback_wrapper
        try:
            current_content = self._read_file()
        except (subprocess.TimeoutExpired, FileNotFoundError, OSError) as exc:
            current_content = ""
            logger.warning("Failed to read target file: %s", exc)

        # template.render() applies feedback_wrapper with the guard's error output
        rendered = template.render(context)
        prompt = (
            f"{rendered}\n\n"
            f"Current file content:\n```python\n{current_content}\n```\n\n"
            f"Return ONLY the complete corrected file content. "
            f"No explanation, no markdown fences, no commentary."
        )

        fixed_code = self._call_llm(prompt)

        if not fixed_code.strip():
            return self._make_artifact(
                content="LLM returned empty response — no fix applied",
                workflow_id=workflow_id,
                action_pair_id=action_pair_id,
                context=context,
                workflow_ref=workflow_ref,
            )

        # Strip markdown fences if the LLM wrapped the output
        cleaned = fixed_code.strip()
        if cleaned.startswith("```"):
            lines = cleaned.split("\n")
            lines = lines[1:-1] if lines[-1].strip() == "```" else lines[1:]
            cleaned = "\n".join(lines)

        try:
            self._write_file(cleaned)
        except (subprocess.TimeoutExpired, OSError) as exc:
            logger.warning("Failed to write fixed file: %s", exc)
            return self._make_artifact(
                content=f"Failed to write fix: {exc}",
                workflow_id=workflow_id,
                action_pair_id=action_pair_id,
                context=context,
                workflow_ref=workflow_ref,
            )

        return self._make_artifact(
            content=cleaned,
            workflow_id=workflow_id,
            action_pair_id=action_pair_id,
            context=context,
            workflow_ref=workflow_ref,
        )

    def _make_artifact(
        self,
        *,
        content: str,
        workflow_id: str,
        action_pair_id: str,
        context: Context,
        workflow_ref: str | None,
    ) -> Artifact:
        now = datetime.now(tz=UTC).isoformat()
        ctx_snapshot = ContextSnapshot(
            workflow_id=workflow_id,
            specification=context.specification,
            constraints=context.ambient.constraints,
            feedback_history=(),
        )
        return Artifact(
            artifact_id=ArtifactId(str(uuid.uuid4())),
            workflow_id=WorkflowId(workflow_id),
            content=content,
            previous_attempt_id=None,
            parent_action_pair_id=None,
            action_pair_id=ActionPairId(action_pair_id),
            created_at=now,
            attempt_number=1,
            status=ArtifactStatus.PENDING,
            guard_result=None,
            context=ctx_snapshot,
            workflow_ref=workflow_ref,
            metadata=MappingProxyType({}),
        )
