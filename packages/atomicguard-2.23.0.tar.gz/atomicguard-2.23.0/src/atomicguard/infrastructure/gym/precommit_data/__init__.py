"""Pre-commit gym data: workflow, AP context, and synthetic dataset."""
