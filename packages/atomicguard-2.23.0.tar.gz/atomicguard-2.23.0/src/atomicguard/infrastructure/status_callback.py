"""
Status callback implementations for reporting step-level progress.

- ``QueueStatusCallback`` — writes ``JobStatus`` updates to a ``JobQueueInterface``.
  Used by ``atomicguard runner start`` to persist progress.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from atomicguard.domain.interfaces import JobQueueInterface, StatusCallbackInterface
from atomicguard.domain.runner import JobState, JobStatus, StepResult

if TYPE_CHECKING:
    from atomicguard.domain.models import WorkflowResult


class QueueStatusCallback(StatusCallbackInterface):
    """Reports step progress to a JobQueueInterface.

    Accumulates ``StepResult`` entries and writes a full ``JobStatus``
    after each step event, so any status reader sees the complete history.
    """

    def __init__(self, queue: JobQueueInterface) -> None:
        self._queue = queue
        self._step_results: dict[str, list[StepResult]] = {}

    def on_step_start(self, job_id: str, ap_id: str, attempt: int) -> None:
        """Report that a step has started."""
        self._queue.report_status(
            JobStatus(
                job_id=job_id,
                state=JobState.RUNNING,
                current_step=ap_id,
                step_results=self._all_results(),
            )
        )

    def on_step_complete(
        self,
        job_id: str,
        ap_id: str,
        attempt: int,
        passed: bool,
        feedback: str | None,
    ) -> None:
        """Report that a step has completed."""
        result = StepResult(
            ap_id=ap_id,
            attempt=attempt,
            passed=passed,
            feedback=feedback or "",
        )
        self._step_results.setdefault(ap_id, []).append(result)
        self._queue.report_status(
            JobStatus(
                job_id=job_id,
                state=JobState.RUNNING,
                current_step=ap_id,
                step_results=self._all_results(),
            )
        )

    def on_run_complete(self, job_id: str, result: WorkflowResult) -> None:
        """Report that the workflow run has completed."""
        from atomicguard.domain.models import WorkflowStatus

        state = (
            JobState.COMPLETED
            if result.status == WorkflowStatus.SUCCESS
            else JobState.FAILED
        )
        self._queue.report_status(
            JobStatus(
                job_id=job_id,
                state=state,
                step_results=self._all_results(),
                error=result.failed_step,
            )
        )

    def on_review_paused(self, job_id: str, ap_id: str) -> None:
        """Report that the job is paused waiting for human review."""
        self._queue.report_status(
            JobStatus(
                job_id=job_id,
                state=JobState.PAUSED,
                current_step=ap_id,
                step_results=self._all_results(),
            )
        )

    def on_review_resumed(self, job_id: str, ap_id: str) -> None:
        """Report that the job has resumed after human review."""
        self._queue.report_status(
            JobStatus(
                job_id=job_id,
                state=JobState.RUNNING,
                current_step=ap_id,
                step_results=self._all_results(),
            )
        )

    def _all_results(self) -> tuple[StepResult, ...]:
        """Flatten all accumulated step results into a single tuple."""
        all_results: list[StepResult] = []
        for results in self._step_results.values():
            all_results.extend(results)
        return tuple(all_results)
