"""Named policy registry for AtomicGuard.

Stores trained policy entries in ``~/.atomicguard/policies.json`` so that
``atomicguard run --policy <name>`` works without specifying a full path.
"""

from __future__ import annotations

import json
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from atomicguard.domain.models import PolicyEntry

REGISTRY_PATH = Path.home() / ".atomicguard" / "policies.json"


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------


def load_registry() -> dict[str, PolicyEntry]:
    if not REGISTRY_PATH.exists():
        return {}
    data: dict[str, Any] = json.loads(REGISTRY_PATH.read_text())
    return {
        name: PolicyEntry(**{**entry, "ap_ids": tuple(entry.get("ap_ids", []))})
        for name, entry in data.get("policies", {}).items()
    }


def save_registry(entries: dict[str, PolicyEntry]) -> None:
    REGISTRY_PATH.parent.mkdir(parents=True, exist_ok=True)
    payload = {"policies": {name: asdict(e) for name, e in entries.items()}}
    REGISTRY_PATH.write_text(json.dumps(payload, indent=2) + "\n")


# ---------------------------------------------------------------------------
# Checkpoint validation
# ---------------------------------------------------------------------------


def validate_checkpoint(path: Path) -> tuple[str, dict[str, Any]]:
    """Validate a checkpoint directory and extract training metadata.

    Args:
        path: Path to a run directory (with ``latest/`` symlink) or directly
              to a checkpoint directory containing ``qtable.npz``.

    Returns:
        ``(resolved_checkpoint_str, training_config)``

    Raises:
        ValueError: If the path is not a valid checkpoint directory.
    """
    from atomicguard.tools.export_workflow import load_training_artifacts

    resolved = path.resolve()

    # Prefer latest/ child if present
    latest = resolved / "latest"
    checkpoint_dir = latest.resolve() if latest.exists() else resolved

    try:
        _policy, training_config, metadata = load_training_artifacts(checkpoint_dir)
    except FileNotFoundError as exc:
        raise ValueError(str(exc)) from exc
    except Exception as exc:
        raise ValueError(
            f"Failed to load checkpoint at {checkpoint_dir}: {exc}"
        ) from exc

    return str(checkpoint_dir), training_config


# ---------------------------------------------------------------------------
# CRUD helpers
# ---------------------------------------------------------------------------


def register(path: Path, name: str | None, force: bool) -> PolicyEntry:
    """Register a policy in the registry.

    Args:
        path: Path to the run/checkpoint directory.
        name: Friendly name. Defaults to the run directory's base name.
        force: If True, overwrite an existing entry with the same name.

    Returns:
        The newly created ``PolicyEntry``.

    Raises:
        ValueError: If the checkpoint is invalid or the name already exists
                    (and ``force`` is False).
    """
    checkpoint_str, training_config = validate_checkpoint(path)

    resolved_name = name or path.resolve().name

    entries = load_registry()
    if resolved_name in entries and not force:
        raise ValueError(
            f"Policy {resolved_name!r} is already registered. Use --force to overwrite."
        )

    entry = PolicyEntry(
        name=resolved_name,
        path=str(path.resolve()),
        checkpoint=checkpoint_str,
        gym=training_config.get("gym", ""),
        model=training_config.get("model", ""),
        provider=training_config.get("provider", ""),
        ap_ids=tuple(training_config.get("ap_ids", [])),
        total_episodes=int(training_config.get("total_episodes", 0)),
        registered_at=datetime.now(UTC).strftime("%Y-%m-%dT%H:%M:%SZ"),
    )

    entries[resolved_name] = entry
    save_registry(entries)
    return entry


def remove(name: str) -> None:
    """Remove a policy entry by name.

    Raises:
        KeyError: If the name is not found.
    """
    entries = load_registry()
    if name not in entries:
        raise KeyError(name)
    del entries[name]
    save_registry(entries)


def get(name: str) -> PolicyEntry:
    """Look up a policy entry by name.

    Raises:
        KeyError: If the name is not found.
    """
    entries = load_registry()
    if name not in entries:
        raise KeyError(name)
    return entries[name]


def list_all() -> list[PolicyEntry]:
    """Return all registered policies sorted by name."""
    return sorted(load_registry().values(), key=lambda e: e.name)
