"""
SQLiteJobQueue: file-based persistent queue implementing JobQueueInterface.

Enables decoupled execution — one process submits jobs (``atomicguard run
--queue``), another picks them up (``atomicguard runner start``).

Schema:
    jobs — one row per submitted RunJob (JSON payload + state tracking)
    job_statuses — latest JobStatus per job (JSON payload)

Claim uses ``UPDATE ... WHERE state = 'queued' ... LIMIT 1`` with
``RETURNING`` to atomically dequeue.  SQLite's implicit write lock
prevents double-claim without explicit row-level locking.
"""

from __future__ import annotations

import dataclasses
import json
import sqlite3
from datetime import UTC, datetime
from pathlib import Path
from typing import TYPE_CHECKING, Any

from atomicguard.domain.interfaces import JobQueueInterface

if TYPE_CHECKING:
    from atomicguard.domain.models import ActionPairDefinition
from atomicguard.domain.runner import JobState, JobStatus, RunJob, StepResult


class SQLiteJobQueue(JobQueueInterface):
    """File-based job queue backed by SQLite.

    Thread-safe via SQLite's built-in serialized threading mode.
    Multiple processes can submit/claim against the same DB file.
    """

    def __init__(self, db_path: str | Path) -> None:
        self._db_path = str(db_path)
        self._ensure_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path, timeout=10)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS jobs (
                    job_id       TEXT PRIMARY KEY,
                    state        TEXT NOT NULL DEFAULT 'queued',
                    payload      TEXT NOT NULL,
                    submitted_at TEXT NOT NULL,
                    claimed_at   TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_jobs_state
                    ON jobs (state, submitted_at);

                CREATE TABLE IF NOT EXISTS job_statuses (
                    job_id     TEXT PRIMARY KEY,
                    payload    TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                """
            )

    def submit(self, job: RunJob) -> str:
        """Insert job into the queue."""
        payload = json.dumps(_run_job_to_dict(job))
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO jobs (job_id, state, payload, submitted_at) "
                "VALUES (?, 'queued', ?, ?)",
                (job.job_id, payload, job.submitted_at.isoformat()),
            )
        return job.job_id

    def claim(self) -> RunJob | None:
        """Atomically claim the oldest queued job (FIFO).

        Uses SELECT then UPDATE with a ``state = 'queued'`` guard.
        If a concurrent process claims the same row first, the UPDATE
        matches 0 rows and we return None instead of double-claiming.
        """
        with self._connect() as conn:
            row = conn.execute(
                "SELECT job_id, payload FROM jobs "
                "WHERE state = 'queued' "
                "ORDER BY submitted_at ASC "
                "LIMIT 1",
            ).fetchone()
            if row is None:
                return None

            cur = conn.execute(
                "UPDATE jobs SET state = 'claimed', claimed_at = ? "
                "WHERE job_id = ? AND state = 'queued'",
                (datetime.now(UTC).isoformat(), row["job_id"]),
            )
            if cur.rowcount == 0:
                return None  # lost the race — another process claimed it
            return _dict_to_run_job(json.loads(row["payload"]))

    def report_status(self, status: JobStatus) -> None:
        """Store or update job status, and sync state to jobs table."""
        payload = json.dumps(_job_status_to_dict(status))
        now = datetime.now(UTC).isoformat()
        with self._connect() as conn:
            conn.execute(
                "INSERT OR REPLACE INTO job_statuses (job_id, payload, updated_at) "
                "VALUES (?, ?, ?)",
                (status.job_id, payload, now),
            )
            # Sync notable states back to the jobs table so queries
            # on jobs.state reflect paused, resumed, and terminal states.
            if status.state in (
                JobState.RUNNING,
                JobState.PAUSED,
                JobState.COMPLETED,
                JobState.FAILED,
                JobState.CANCELLED,
            ):
                conn.execute(
                    "UPDATE jobs SET state = ? WHERE job_id = ?",
                    (status.state.value, status.job_id),
                )

    def get_status(self, job_id: str) -> JobStatus | None:
        """Get the latest reported status for a job."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT payload FROM job_statuses WHERE job_id = ?",
                (job_id,),
            ).fetchone()
            if row is None:
                return None
            return _dict_to_job_status(json.loads(row["payload"]))

    def cancel(self, job_id: str) -> bool:
        """Cancel a QUEUED or PAUSED job.

        Also syncs the cancellation to ``job_statuses`` immediately so that
        ``get_status()`` reflects the new state without waiting for the runner
        to call ``report_status()``.
        """
        with self._connect() as conn:
            cur = conn.execute(
                "UPDATE jobs SET state = 'cancelled' "
                "WHERE job_id = ? AND state IN ('queued', 'paused')",
                (job_id,),
            )
            if cur.rowcount == 0:
                return False
            now = datetime.now(UTC).isoformat()
            payload = json.dumps(
                {
                    "job_id": job_id,
                    "state": "cancelled",
                    "current_step": None,
                    "step_results": [],
                    "error": "Cancelled by user",
                    "updated_at": now,
                }
            )
            conn.execute(
                "INSERT OR REPLACE INTO job_statuses (job_id, payload, updated_at) "
                "VALUES (?, ?, ?)",
                (job_id, payload, now),
            )
            return True

    def list_jobs(self, state: JobState | None = None) -> list[RunJob]:
        """List jobs, optionally filtered by state.

        Not part of JobQueueInterface — convenience for the runner CLI.
        """
        with self._connect() as conn:
            if state is not None:
                rows = conn.execute(
                    "SELECT payload FROM jobs WHERE state = ? ORDER BY submitted_at ASC",
                    (state.value,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT payload FROM jobs ORDER BY submitted_at ASC"
                ).fetchall()
        return [_dict_to_run_job(json.loads(r["payload"])) for r in rows]


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------

# Fields in ActionPairDefinition whose type is tuple[str, ...]
_AP_TUPLE_FIELDS: set[str] | None = None
# Fields whose type is dict[str, tuple[str, ...]]
_AP_DICT_TUPLE_FIELDS: set[str] | None = None


def _get_ap_field_types() -> tuple[set[str], set[str]]:
    """Inspect ActionPairDefinition fields once to find tuple and dict-of-tuple fields."""
    global _AP_TUPLE_FIELDS, _AP_DICT_TUPLE_FIELDS  # noqa: PLW0603
    if _AP_TUPLE_FIELDS is not None and _AP_DICT_TUPLE_FIELDS is not None:
        return _AP_TUPLE_FIELDS, _AP_DICT_TUPLE_FIELDS

    import typing

    from atomicguard.domain.models import ActionPairDefinition

    tuple_fields: set[str] = set()
    dict_tuple_fields: set[str] = set()

    for f in dataclasses.fields(ActionPairDefinition):
        origin = typing.get_origin(f.type)
        args = typing.get_args(f.type)
        if f.type is tuple or (origin is tuple and args and args[0] is str):
            tuple_fields.add(f.name)
        elif origin is dict and len(args) == 2:
            # Check for dict[str, tuple[str, ...]]
            val_origin = typing.get_origin(args[1])
            if val_origin is tuple:
                dict_tuple_fields.add(f.name)

    _AP_TUPLE_FIELDS = tuple_fields
    _AP_DICT_TUPLE_FIELDS = dict_tuple_fields
    return tuple_fields, dict_tuple_fields


def _dict_to_ap_definition(d: dict[str, Any]) -> ActionPairDefinition:
    """Deserialize an ActionPairDefinition, converting lists back to tuples.

    Uses ``dataclasses.fields()`` to discover which fields are typed as
    ``tuple[str, ...]`` or ``dict[str, tuple[str, ...]]`` so that new
    tuple fields added to ActionPairDefinition are handled automatically.
    """
    from atomicguard.domain.models import ActionPairDefinition

    tuple_fields, dict_tuple_fields = _get_ap_field_types()
    coerced: dict[str, Any] = {}
    for k, v in d.items():
        if k in tuple_fields and isinstance(v, list):
            coerced[k] = tuple(v)
        elif k in dict_tuple_fields and isinstance(v, dict):
            coerced[k] = {dk: tuple(dv) for dk, dv in v.items()}
        else:
            coerced[k] = v
    return ActionPairDefinition(**coerced)


def _run_job_to_dict(job: RunJob) -> dict[str, Any]:
    """Serialize a RunJob to a JSON-compatible dict."""
    d = dataclasses.asdict(job)
    d["submitted_at"] = job.submitted_at.isoformat()
    return d


def _dict_to_run_job(d: dict[str, Any]) -> RunJob:
    """Deserialize a RunJob from a dict."""
    from atomicguard.domain.models import APContextEntry

    # Reconstruct WorkflowDefinition
    wf_data = d["workflow_definition"]
    from atomicguard.domain.models import WorkflowDefinition

    aps = tuple(_dict_to_ap_definition(ap) for ap in wf_data.get("action_pairs", ()))

    policy_derived_requires = tuple(
        tuple(edge) for edge in wf_data.get("policy_derived_requires", ())
    )

    workflow_def = WorkflowDefinition(
        slug=wf_data["slug"],
        name=wf_data["name"],
        description=wf_data.get("description", ""),
        specification=wf_data.get("specification"),
        constraints=wf_data.get("constraints", ""),
        model=wf_data.get("model", ""),
        provider=wf_data.get("provider", ""),
        rmax=wf_data.get("rmax", 3),
        action_pairs=aps,
        source_policy_slug=wf_data.get("source_policy_slug", ""),
        policy_derived_requires=policy_derived_requires,
    )

    # Reconstruct AP context
    ap_context: dict[str, APContextEntry] = {}
    for ap_id, ctx_data in d.get("ap_context", {}).items():
        if isinstance(ctx_data, dict):
            ap_context[ap_id] = APContextEntry(**ctx_data)
        else:
            ap_context[ap_id] = ctx_data

    return RunJob(
        job_id=d["job_id"],
        workflow_definition=workflow_def,
        ap_context=ap_context,
        specification=d["specification"],
        model=d["model"],
        provider=d["provider"],
        submitted_at=datetime.fromisoformat(d["submitted_at"]),
        metadata=d.get("metadata", {}),
    )


def _job_status_to_dict(status: JobStatus) -> dict[str, Any]:
    """Serialize a JobStatus to a JSON-compatible dict."""
    return {
        "job_id": status.job_id,
        "state": status.state.value,
        "current_step": status.current_step,
        "step_results": [dataclasses.asdict(sr) for sr in status.step_results],
        "error": status.error,
        "updated_at": status.updated_at.isoformat(),
    }


def _dict_to_job_status(d: dict[str, Any]) -> JobStatus:
    """Deserialize a JobStatus from a dict."""
    step_results = tuple(
        StepResult(
            ap_id=sr["ap_id"],
            attempt=sr["attempt"],
            passed=sr["passed"],
            feedback=sr.get("feedback", ""),
            artifact_id=sr.get("artifact_id"),
            started_at=(
                datetime.fromisoformat(sr["started_at"])
                if sr.get("started_at")
                else None
            ),
            finished_at=(
                datetime.fromisoformat(sr["finished_at"])
                if sr.get("finished_at")
                else None
            ),
        )
        for sr in d.get("step_results", ())
    )
    return JobStatus(
        job_id=d["job_id"],
        state=JobState(d["state"]),
        current_step=d.get("current_step"),
        step_results=step_results,
        error=d.get("error"),
        updated_at=datetime.fromisoformat(d["updated_at"]),
    )
