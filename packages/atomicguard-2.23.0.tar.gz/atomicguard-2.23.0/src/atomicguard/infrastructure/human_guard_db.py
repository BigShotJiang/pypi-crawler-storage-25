"""
DB-polling human guard resolver for web-based review.

Writes pending reviews to a SQLite database and polls for decisions.
The web dashboard reads the same DB to display review cards and submit
decisions.  This keeps the runner and web server decoupled — they share
only the DB file.

The ``pending_reviews`` table lives in the web DB (separate from the
runner's job queue DB) so each concern owns its own storage.
"""

from __future__ import annotations

import sqlite3
import uuid
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from atomicguard.domain.interfaces import HumanReviewerInterface
from atomicguard.domain.models import Artifact
from atomicguard.domain.runner import ReviewDecision


class DBPollingHumanReviewer(HumanReviewerInterface):
    """Resolves human reviews by polling a SQLite ``pending_reviews`` table.

    ``request_review`` inserts a row with ``status = 'pending'``.
    ``poll_decision`` checks for ``status IN ('approved', 'rejected')``
    and returns the decision when found, or ``None`` if still pending.

    The web dashboard provides the UI for reviewers to approve/reject.
    """

    def __init__(self, db_path: str | Path) -> None:
        self._db_path = str(db_path)
        self._ensure_schema()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self._db_path, timeout=10)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA busy_timeout=5000")
        conn.row_factory = sqlite3.Row
        return conn

    def _ensure_schema(self) -> None:
        with self._connect() as conn:
            conn.executescript(
                """
                CREATE TABLE IF NOT EXISTS pending_reviews (
                    review_id        TEXT PRIMARY KEY,
                    job_id           TEXT NOT NULL,
                    ap_id            TEXT NOT NULL,
                    artifact_id      TEXT NOT NULL,
                    artifact_content TEXT NOT NULL,
                    prompt           TEXT NOT NULL DEFAULT '',
                    status           TEXT NOT NULL DEFAULT 'pending',
                    feedback         TEXT,
                    created_at       TEXT NOT NULL,
                    resolved_at      TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_pending_reviews_status
                    ON pending_reviews (status);
                CREATE INDEX IF NOT EXISTS idx_pending_reviews_job
                    ON pending_reviews (job_id);
                """
            )

    def request_review(
        self,
        job_id: str,
        ap_id: str,
        artifact: Artifact,
        prompt: str,
    ) -> str:
        review_id = str(uuid.uuid4())
        now = datetime.now(UTC).isoformat()
        with self._connect() as conn:
            conn.execute(
                "INSERT INTO pending_reviews "
                "(review_id, job_id, ap_id, artifact_id, artifact_content, "
                " prompt, status, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, 'pending', ?)",
                (
                    review_id,
                    job_id,
                    ap_id,
                    artifact.artifact_id,
                    artifact.content,
                    prompt,
                    now,
                ),
            )
        return review_id

    def poll_decision(
        self, review_id: str, timeout: float | None = None
    ) -> ReviewDecision | None:
        """Check if the review has been decided.

        Returns ``None`` if the review is still pending.  The caller
        (``HumanReviewAdapter``) retries with its own poll interval.

        The ``timeout`` parameter is accepted for interface compliance
        but not used — the caller controls retry timing.
        """
        with self._connect() as conn:
            row = conn.execute(
                "SELECT status, feedback FROM pending_reviews WHERE review_id = ?",
                (review_id,),
            ).fetchone()

        if row is None:
            return None

        status = row["status"]
        if status == "pending":
            return None

        approved = status == "approved"
        feedback = row["feedback"] or ("Approved" if approved else "Rejected")
        return ReviewDecision(approved=approved, feedback=feedback)

    # ------------------------------------------------------------------
    # Web-facing helpers (called by routes, not by the runner)
    # ------------------------------------------------------------------

    def list_pending(self, job_id: str | None = None) -> list[dict[str, Any]]:
        """List pending reviews, optionally filtered by job_id."""
        with self._connect() as conn:
            if job_id:
                rows = conn.execute(
                    "SELECT * FROM pending_reviews "
                    "WHERE job_id = ? ORDER BY created_at DESC",
                    (job_id,),
                ).fetchall()
            else:
                rows = conn.execute(
                    "SELECT * FROM pending_reviews ORDER BY created_at DESC"
                ).fetchall()
        return [dict(r) for r in rows]

    def list_pending_only(self) -> list[dict[str, Any]]:
        """List only unresolved reviews."""
        with self._connect() as conn:
            rows = conn.execute(
                "SELECT * FROM pending_reviews "
                "WHERE status = 'pending' ORDER BY created_at ASC"
            ).fetchall()
        return [dict(r) for r in rows]

    def get_review(self, review_id: str) -> dict[str, Any] | None:
        """Get a single review by ID."""
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM pending_reviews WHERE review_id = ?",
                (review_id,),
            ).fetchone()
        return dict(row) if row else None

    def submit_decision(
        self, review_id: str, approved: bool, feedback: str = ""
    ) -> bool:
        """Submit a decision for a pending review.

        Returns True if the review was updated, False if it was already
        decided or doesn't exist.
        """
        now = datetime.now(UTC).isoformat()
        status = "approved" if approved else "rejected"
        with self._connect() as conn:
            cur = conn.execute(
                "UPDATE pending_reviews "
                "SET status = ?, feedback = ?, resolved_at = ? "
                "WHERE review_id = ? AND status = 'pending'",
                (status, feedback, now, review_id),
            )
            return cur.rowcount > 0
