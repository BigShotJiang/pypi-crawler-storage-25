"""
Human review adapter.

A ``GuardInterface`` implementation that delegates review decisions to a
``HumanReviewerInterface``.  This is the substitution boundary between
CLI (stdin) and web (DB-polled) human review.
"""

from __future__ import annotations

import time
from typing import Any

from atomicguard.domain.exceptions import ReviewTimeout
from atomicguard.domain.interfaces import (
    GuardInterface,
    HumanReviewerInterface,
    PauseCallback,
)
from atomicguard.domain.models import Artifact, GuardResult


class HumanReviewAdapter(GuardInterface):
    """Guard that requests human review via a reviewer.

    The reviewer handles the mechanics (stdin, DB polling, cloud API)
    while this guard adapts the result to a ``GuardResult``.

    Optional ``on_pause`` / ``on_resume`` callbacks let the runner
    report ``PAUSED`` / ``RUNNING`` state to the job queue without
    coupling the guard to queue infrastructure.
    """

    def __init__(
        self,
        reviewer: HumanReviewerInterface,
        job_id: str,
        prompt_title: str = "Review this artifact",
        poll_interval: float = 2.0,
        max_wait: float | None = None,
        on_pause: PauseCallback | None = None,
        on_resume: PauseCallback | None = None,
    ) -> None:
        self._reviewer = reviewer
        self._job_id = job_id
        self._prompt_title = prompt_title
        self._poll_interval = poll_interval
        self._max_wait = max_wait
        self._on_pause = on_pause
        self._on_resume = on_resume

    def validate(self, artifact: Artifact, **deps: Any) -> GuardResult:  # noqa: ARG002
        """Request review and block until a decision is available.

        For stdin reviewers, ``poll_decision`` blocks until input and
        returns immediately.  For DB-backed reviewers, ``poll_decision``
        blocks up to ``poll_interval`` seconds per call.

        Raises:
            ReviewTimeout: If ``max_wait`` is set and the review is
                not decided within that many seconds.
        """
        review_id = self._reviewer.request_review(
            job_id=self._job_id,
            ap_id=artifact.action_pair_id,
            artifact=artifact,
            prompt=self._prompt_title,
        )

        if self._on_pause is not None:
            self._on_pause(artifact.action_pair_id, review_id)

        deadline = (
            (time.monotonic() + self._max_wait) if self._max_wait is not None else None
        )

        while True:
            decision = self._reviewer.poll_decision(
                review_id, timeout=self._poll_interval
            )
            if decision is not None:
                if self._on_resume is not None:
                    self._on_resume(artifact.action_pair_id, review_id)
                return GuardResult(
                    passed=decision.approved,
                    feedback=decision.feedback,
                )
            if deadline is not None and time.monotonic() >= deadline:
                raise ReviewTimeout(review_id, self._max_wait)  # type: ignore[arg-type]
