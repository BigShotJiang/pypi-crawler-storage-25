"""DiffEmptyGuard — checks that formatter diff output is empty.

Used with ``ruff format --diff`` (or similar formatters).  When the
diff output is empty the code is already correctly formatted.
"""

from __future__ import annotations

from typing import Any

from atomicguard.domain.interfaces import GuardInterface
from atomicguard.domain.models import Artifact, GuardResult


class DiffEmptyGuard(GuardInterface):
    """Checks that formatter diff output is empty (no changes needed).

    Passes when ``artifact.content`` is empty or contains only
    whitespace — meaning the formatter found nothing to change.

    When the diff is non-empty, the diff content is returned as
    feedback showing what formatting changes are needed.
    """

    def __init__(self, **kwargs: Any) -> None:
        pass

    def validate(self, artifact: Artifact, **dependencies: Artifact) -> GuardResult:  # noqa: ARG002
        content = (artifact.content or "").strip()

        if not content:
            return GuardResult(
                passed=True,
                feedback="",
                guard_name="DiffEmptyGuard",
            )

        return GuardResult(
            passed=False,
            feedback=f"Formatting changes needed:\n{content}",
            guard_name="DiffEmptyGuard",
        )
