"""AllPassedGuard — passes only when all dependency artifacts passed their guards.

Use as the guard for aggregator APs (e.g. ``ap_commit_ready``) that
should only succeed when every upstream check has passed.  The guard
inspects each dependency artifact's ``guard_result.passed`` field.
"""

from __future__ import annotations

from typing import Any

from atomicguard.domain.interfaces import GuardInterface
from atomicguard.domain.models import Artifact, GuardResult


class AllPassedGuard(GuardInterface):
    """Passes only when all dependency artifacts have ``guard_result.passed == True``.

    Use as the guard for aggregator APs (e.g. ``ap_commit_ready``) that
    should only succeed when all upstream checks have passed.
    """

    def __init__(self, **kwargs: Any) -> None:
        pass

    def validate(self, artifact: Artifact, **dependencies: Artifact) -> GuardResult:  # noqa: ARG002
        failed = [
            name
            for name, dep in dependencies.items()
            if dep.guard_result is None or not dep.guard_result.passed
        ]
        if not failed:
            return GuardResult(
                passed=True,
                feedback="",
                guard_name="AllPassedGuard",
            )
        return GuardResult(
            passed=False,
            feedback=f"Not all checks passed. Failed: {', '.join(sorted(failed))}",
            guard_name="AllPassedGuard",
        )
