"""ContainerSubprocessGuard — runs a command (optionally in Docker) and checks exit code.

Purely sensing: executes a subprocess, observes the exit code and output,
returns pass/fail with output as feedback.  Never mutates files or state.
"""

from __future__ import annotations

import logging
import subprocess
from typing import Any

from atomicguard.domain.interfaces import GuardInterface
from atomicguard.domain.models import Artifact, GuardResult

logger = logging.getLogger(__name__)


class ContainerSubprocessGuard(GuardInterface):
    """Runs a command in a Docker container (or host) and passes if exit code is 0.

    Does NOT read from artifact metadata — it runs the command itself on
    every call, providing fresh sensing of the current container state.

    Args:
        command: Command to run as a list of strings.
        container_id: Docker container ID.  ``None`` = run on host.
        timeout: Subprocess timeout in seconds.
    """

    def __init__(
        self,
        command: list[str],
        container_id: str | None = None,
        timeout: int = 30,
        **_kwargs: Any,
    ) -> None:
        self._command = command
        self._container_id = container_id
        self._timeout = timeout

    def validate(self, artifact: Artifact, **dependencies: Artifact) -> GuardResult:  # noqa: ARG002
        if self._container_id:
            cmd = ["docker", "exec", self._container_id] + self._command
        else:
            cmd = self._command

        logger.debug(
            "ContainerSubprocessGuard.validate: container_id=%r cmd=%s",
            self._container_id,
            " ".join(cmd),
        )

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=self._timeout,
            )
            output = result.stdout
            if result.stderr:
                output = f"{output}\n{result.stderr}" if output else result.stderr
            output = output.strip()

            logger.debug(
                "ContainerSubprocessGuard.validate: returncode=%d stdout=%r stderr=%r",
                result.returncode,
                result.stdout[:500] if result.stdout else "",
                result.stderr[:500] if result.stderr else "",
            )

            if result.returncode == 0:
                return GuardResult(
                    passed=True, feedback="", guard_name="ContainerSubprocessGuard"
                )

            return GuardResult(
                passed=False,
                feedback=output or f"Command exited with code {result.returncode}",
                guard_name="ContainerSubprocessGuard",
            )
        except subprocess.TimeoutExpired:
            logger.debug(
                "ContainerSubprocessGuard.validate: timed out after %ds", self._timeout
            )
            return GuardResult(
                passed=False,
                feedback=f"Command timed out after {self._timeout}s",
                guard_name="ContainerSubprocessGuard",
            )
