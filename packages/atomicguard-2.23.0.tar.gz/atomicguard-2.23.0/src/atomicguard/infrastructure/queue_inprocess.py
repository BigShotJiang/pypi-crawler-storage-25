"""
InProcessJobQueue: synchronous passthrough implementation of JobQueueInterface.

This lets ``atomicguard run`` use the full JobQueueInterface without any
queue infrastructure.  submit() stores the job; claim() returns it
immediately; report_status() stores status locally.

When swapping in ``SQLiteJobQueue`` or ``CloudJobQueue`` later, zero
application-layer code changes are needed — only the queue backend.
"""

from __future__ import annotations

from atomicguard.domain.interfaces import JobQueueInterface
from atomicguard.domain.runner import JobState, JobStatus, RunJob


class InProcessJobQueue(JobQueueInterface):
    """Synchronous passthrough queue for single-process execution."""

    def __init__(self) -> None:
        self._pending: RunJob | None = None
        self._statuses: dict[str, JobStatus] = {}
        self._jobs: dict[str, RunJob] = {}
        self._states: dict[str, str] = {}

    def submit(self, job: RunJob) -> str:
        """Store the job for immediate claim."""
        self._pending = job
        self._jobs[job.job_id] = job
        self._states[job.job_id] = "queued"
        return job.job_id

    def claim(self) -> RunJob | None:
        """Return the pending job and clear it."""
        job = self._pending
        self._pending = None
        if job is not None:
            self._states[job.job_id] = "claimed"
        return job

    def report_status(self, status: JobStatus) -> None:
        """Store status locally."""
        self._statuses[status.job_id] = status
        self._states[status.job_id] = status.state.value

    def get_status(self, job_id: str) -> JobStatus | None:
        """Return stored status for the given job."""
        return self._statuses.get(job_id)

    def list_jobs(self, state: JobState | None = None) -> list[RunJob]:
        """List jobs, optionally filtered by state.

        Not part of JobQueueInterface — convenience for the web UI (same
        pattern as SQLiteJobQueue.list_jobs).
        """
        if state is None:
            return list(self._jobs.values())
        return [
            j for j in self._jobs.values() if self._states.get(j.job_id) == state.value
        ]

    def cancel(self, job_id: str) -> bool:
        """Cancel a QUEUED or PAUSED job."""
        if self._states.get(job_id) not in ("queued", "paused"):
            return False
        self._states[job_id] = "cancelled"
        return True
