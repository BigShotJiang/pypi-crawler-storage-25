"""
Concrete reward function implementations for RL workflow discovery.

Each strategy implements ``RewardFunctionInterface`` and shapes guard
verdicts into scalar reward that teaches the agent which AP sequences
(workflows) solve the task efficiently.

See ``docs/design/plans/the_policy_is_planning.md`` §4 for design
rationale and strategy selection guidance.
"""

from __future__ import annotations

import time

from atomicguard.domain.rl.models import Phase
from atomicguard.domain.rl.reward import RewardFunctionInterface, RewardSignal


class MazeReward(RewardFunctionInterface):
    """Maze-style reward inspired by classic Q-learning grid worlds.

    Every step costs something — passing a non-goal guard costs a little,
    failing a guard costs a lot, and reaching the goal pays handsomely.
    This teaches the agent to find the *shortest* successful path.

    Reward structure:
        - Goal AP satisfied (terminal + guard_passed): ``+goal_reward``
        - Guard passes (not goal): ``step_penalty`` (negative, e.g. -1)
        - Guard fails: ``fail_penalty`` (negative, e.g. -5)

    No separate timeout penalty — an agent that exhausts its step budget
    accumulates enough step/fail penalties to be punished naturally.

    Args:
        goal_reward: Reward when the goal AP is satisfied. Default 100.0.
        step_penalty: Cost per successful (non-goal) step. Default -1.0.
        fail_penalty: Cost per failed step. Default -5.0.
    """

    def __init__(
        self,
        goal_reward: float = 100.0,
        step_penalty: float = -1.0,
        fail_penalty: float = -5.0,
    ) -> None:
        self._goal_reward = goal_reward
        self._step_penalty = step_penalty
        self._fail_penalty = fail_penalty

    def compute(  # noqa: ARG002
        self,
        guard_passed: bool,
        tokens_used: int,
        retries_used: int,
        terminal: bool,
        action: int | None = None,
        satisfied: frozenset[str] | None = None,
        available: frozenset[str] | None = None,
    ) -> RewardSignal:
        if terminal and guard_passed:
            value = self._goal_reward
        elif guard_passed:
            value = self._step_penalty
        else:
            value = self._fail_penalty

        return RewardSignal(
            value=value,
            guard_passed=guard_passed,
            tokens_used=tokens_used,
            retries_used=retries_used,
            terminal=terminal,
        )


class SparseBinaryReward(RewardFunctionInterface):
    """Strategy 1: Sparse Binary.

    +1 when all APs satisfied at episode end (terminal + guard_passed).
    -1 on timeout (terminal + not guard_passed).
    0 for all intermediate steps.

    Unbiased baseline — no shaping, no bias. Use to measure whether
    denser strategies actually help learning.

    Args:
        success_reward: Reward for terminal success. Default 1.0.
        failure_reward: Reward for terminal failure. Default -1.0.
    """

    def __init__(
        self, success_reward: float = 1.0, failure_reward: float = -1.0
    ) -> None:
        self._success = success_reward
        self._failure = failure_reward

    def compute(  # noqa: ARG002
        self,
        guard_passed: bool,
        tokens_used: int,
        retries_used: int,
        terminal: bool,
        action: int | None = None,
        satisfied: frozenset[str] | None = None,
        available: frozenset[str] | None = None,
    ) -> RewardSignal:
        if terminal and guard_passed:
            value = self._success
        elif terminal:
            value = self._failure
        else:
            value = 0.0

        return RewardSignal(
            value=value,
            guard_passed=guard_passed,
            tokens_used=tokens_used,
            retries_used=retries_used,
            terminal=terminal,
        )


class StepReward(RewardFunctionInterface):
    """Strategy 2: Step Reward.

    +step_reward each time an AP guard passes (newly satisfied).
    -step_penalty per step taken (time cost).
    Additional terminal bonus/penalty on episode end.

    Dense signal — learns faster than sparse, but can bias toward
    greedy local picks (satisfy easiest AP first).

    Args:
        step_reward: Reward per newly satisfied AP. Default 1.0.
        step_penalty: Cost per step taken. Default 0.1.
        terminal_bonus: Bonus for completing all APs. Default 5.0.
        terminal_penalty: Penalty for budget exhaustion. Default -5.0.
    """

    def __init__(
        self,
        step_reward: float = 1.0,
        step_penalty: float = 0.1,
        terminal_bonus: float = 5.0,
        terminal_penalty: float = -5.0,
    ) -> None:
        self._step_reward = step_reward
        self._step_penalty = step_penalty
        self._terminal_bonus = terminal_bonus
        self._terminal_penalty = terminal_penalty

    def compute(  # noqa: ARG002
        self,
        guard_passed: bool,
        tokens_used: int,
        retries_used: int,
        terminal: bool,
        action: int | None = None,
        satisfied: frozenset[str] | None = None,
        available: frozenset[str] | None = None,
    ) -> RewardSignal:
        value = -self._step_penalty

        if guard_passed:
            value += self._step_reward

        if terminal and guard_passed:
            value += self._terminal_bonus
        elif terminal:
            value += self._terminal_penalty

        return RewardSignal(
            value=value,
            guard_passed=guard_passed,
            tokens_used=tokens_used,
            retries_used=retries_used,
            terminal=terminal,
        )


class EfficiencyPenaltyReward(RewardFunctionInterface):
    """Strategy 3: Efficiency Penalty.

    Like StepReward plus explicit penalties for waste:
    - Attempting already-satisfied APs (redundant_penalty)
    - Invalid actions (invalid_penalty)
    - Failed guard checks (failure_penalty)

    Teaches the agent what *not* to do. Risk: too much penalty
    can make the agent overly conservative.

    Args:
        step_reward: Reward per newly satisfied AP. Default 1.0.
        step_penalty: Cost per step. Default 0.1.
        redundant_penalty: Extra cost for re-selecting satisfied AP. Default 0.5.
        invalid_penalty: Cost for invalid action index. Default 0.5.
        failure_penalty: Extra cost when guard fails. Default 0.2.
        terminal_bonus: Bonus for completing all APs. Default 5.0.
        terminal_penalty: Penalty for budget exhaustion. Default -5.0.
    """

    def __init__(
        self,
        step_reward: float = 1.0,
        step_penalty: float = 0.1,
        redundant_penalty: float = 0.5,
        invalid_penalty: float = 0.5,
        failure_penalty: float = 0.2,
        terminal_bonus: float = 5.0,
        terminal_penalty: float = -5.0,
    ) -> None:
        self._step_reward = step_reward
        self._step_penalty = step_penalty
        self._redundant_penalty = redundant_penalty
        self._invalid_penalty = invalid_penalty
        self._failure_penalty = failure_penalty
        self._terminal_bonus = terminal_bonus
        self._terminal_penalty = terminal_penalty
        self._prev_satisfied: frozenset[str] = frozenset()

    def compute(
        self,
        guard_passed: bool,
        tokens_used: int,
        retries_used: int,
        terminal: bool,
        action: int | None = None,
        satisfied: frozenset[str] | None = None,
        available: frozenset[str] | None = None,
    ) -> RewardSignal:
        value = -self._step_penalty

        if guard_passed:
            # Check if this is a *newly* satisfied AP
            if satisfied is None or satisfied != self._prev_satisfied:
                value += self._step_reward
        else:
            # Guard failed — determine why
            if satisfied is not None and action is not None and available is not None:
                ap_list = sorted(available)
                if action < 0 or action >= len(ap_list):
                    value -= self._invalid_penalty
                elif ap_list[action] in (satisfied or frozenset()):
                    value -= self._redundant_penalty
                else:
                    value -= self._failure_penalty
            else:
                value -= self._failure_penalty

        if terminal and guard_passed:
            value += self._terminal_bonus
        elif terminal:
            value += self._terminal_penalty

        # Track state for next call — reset on terminal so the next
        # episode starts clean (consistent with PhasedShapingReward and
        # PotentialBasedShapingReward).
        if terminal:
            self._prev_satisfied = frozenset()
        else:
            self._prev_satisfied = satisfied if satisfied is not None else frozenset()

        return RewardSignal(
            value=value,
            guard_passed=guard_passed,
            tokens_used=tokens_used,
            retries_used=retries_used,
            terminal=terminal,
        )


class PotentialBasedShapingReward(RewardFunctionInterface):
    """Strategy 5: Potential-Based Shaping.

    Base reward from guard pass/fail, plus a shaping bonus:
    ``gamma * Φ(s') - Φ(s)`` where ``Φ(s) = |satisfied| / N`` and
    N is the total number of action pairs (constant across the episode).

    Using a constant denominator is required by the theoretical guarantee
    (Ng, Harada & Russell, 1999): Φ must be a pure function of state.
    When ``available`` shrinks due to dependency masking, dividing by
    ``|available|`` makes Φ depend on the action space — not just the
    state — which breaks the optimality-preservation proof.

    Args:
        total_action_pairs: Total number of action pairs in the pool.
            Used as constant denominator for the potential function.
            When not provided, falls back to ``|available|`` (legacy
            behaviour, not recommended for workflows with dependencies).
        base_reward: Reward when guard passes. Default 0.0.
        base_penalty: Penalty when guard fails. Default 0.0.
        gamma: Discount factor for shaping (matches training gamma). Default 0.99.
        terminal_bonus: Bonus for completing all APs. Default 1.0.
        terminal_penalty: Penalty for budget exhaustion. Default -1.0.
    """

    def __init__(
        self,
        total_action_pairs: int | None = None,
        base_reward: float = 0.0,
        base_penalty: float = 0.0,
        gamma: float = 0.99,
        terminal_bonus: float = 1.0,
        terminal_penalty: float = -1.0,
    ) -> None:
        self._total_action_pairs = total_action_pairs
        self._base_reward = base_reward
        self._base_penalty = base_penalty
        self._gamma = gamma
        self._terminal_bonus = terminal_bonus
        self._terminal_penalty = terminal_penalty
        self._prev_potential: float = 0.0

    def _potential(
        self, satisfied: frozenset[str] | None, available: frozenset[str] | None
    ) -> float:
        """Φ(s) = |satisfied| / N where N is the total AP count."""
        if satisfied is None:
            return 0.0
        denominator = self._total_action_pairs
        if denominator is None:
            # Legacy fallback: use |available| when total not provided
            if available is None or len(available) == 0:
                return 0.0
            denominator = len(available)
        if denominator == 0:
            return 0.0
        return len(satisfied) / denominator

    def compute(  # noqa: ARG002
        self,
        guard_passed: bool,
        tokens_used: int,
        retries_used: int,
        terminal: bool,
        action: int | None = None,
        satisfied: frozenset[str] | None = None,
        available: frozenset[str] | None = None,
    ) -> RewardSignal:
        # Base reward
        value = self._base_reward if guard_passed else self._base_penalty

        # Terminal bonus/penalty
        if terminal and guard_passed:
            value += self._terminal_bonus
        elif terminal:
            value += self._terminal_penalty

        # Potential-based shaping: γΦ(s') - Φ(s)
        current_potential = self._potential(satisfied, available)
        shaping = self._gamma * current_potential - self._prev_potential
        value += shaping

        # Track for next step
        if terminal:
            self._prev_potential = 0.0
        else:
            self._prev_potential = current_potential

        return RewardSignal(
            value=value,
            guard_passed=guard_passed,
            tokens_used=tokens_used,
            retries_used=retries_used,
            terminal=terminal,
        )


class PhasedShapingReward(RewardFunctionInterface):
    """Strategy 7: Phased Shaping.

    Wraps any base ``RewardFunctionInterface`` and modulates the reward
    based on which workflow phase the selected action pair belongs to.

    Phases are ordered groups of APs (e.g. Discovery → Analysis →
    Generation → Validation). The *active phase* is the first phase
    whose APs are not all satisfied. Actions in the active phase get
    a bonus; actions in future phases get a reduced multiplier.

    This guides the agent through a logical progression without
    completely blocking exploration — future-phase APs still get some
    reward, just less.

    Composes with any base reward (PotentialBasedShapingReward
    recommended as the base for principled dense signal + phased
    guidance).

    Args:
        base_reward_fn: Wrapped reward function that computes raw reward.
        phases: Ordered list of Phase objects defining the progression.
        in_phase_bonus: Bonus added when the selected AP is in the active phase.
        out_of_phase_multiplier: Multiplier (0–1) applied to base reward for
            future-phase APs. Lower values discourage premature attempts.
        attempt_penalty: Fixed penalty subtracted when a future-phase AP is
            attempted. Ensures non-zero negative signal even when the base
            reward is ~0.
        phase_threshold: Fraction (0–1) of a phase's APs that must be
            satisfied before the phase is considered complete. Default 1.0
            requires all APs; 0.8 allows advancing after 80%.
    """

    def __init__(
        self,
        base_reward_fn: RewardFunctionInterface,
        phases: list[Phase],
        in_phase_bonus: float = 0.5,
        out_of_phase_multiplier: float = 0.2,
        attempt_penalty: float = 0.3,
        phase_threshold: float = 1.0,
        ap_ids: tuple[str, ...] | None = None,
    ) -> None:
        self._base = base_reward_fn
        self._phases = phases
        self._in_phase_bonus = in_phase_bonus
        self._out_of_phase_multiplier = out_of_phase_multiplier
        self._attempt_penalty = attempt_penalty
        self._phase_threshold = phase_threshold
        self._ap_ids = ap_ids
        self._prev_satisfied: frozenset[str] = frozenset()

    def _active_phase_index(self, satisfied: frozenset[str]) -> int:
        """Return index of the first phase not sufficiently satisfied.

        A phase is considered complete when the fraction of its APs that
        are satisfied meets or exceeds ``phase_threshold``.
        """
        for i, phase in enumerate(self._phases):
            completed = len(phase.ap_ids & satisfied) / len(phase.ap_ids)
            if completed < self._phase_threshold:
                return i
        return len(self._phases)  # all phases complete

    def configure_ap_pool(
        self, ap_ids: tuple[str, ...], required_count: int | None = None
    ) -> None:
        """Set the AP pool ordering after construction.

        Must be called before training starts so that ``action`` indices
        are resolved correctly. Also propagates ``total_action_pairs``
        to the base reward function if it is a PotentialBasedShapingReward.

        Args:
            ap_ids: Ordered tuple of AP IDs (the action space).
            required_count: Number of APs required for completion.
                For group-aware workflows, this is
                ``len(non_grouped_aps) + len(groups)`` (e.g. 12 not 14).
                If None, uses ``len(ap_ids)``.
        """
        self._ap_ids = ap_ids
        if isinstance(self._base, PotentialBasedShapingReward):
            self._base._total_action_pairs = required_count or len(ap_ids)

    def _ap_phase_index(self, ap_id: str) -> int | None:
        """Return the phase index the AP belongs to, or None."""
        for i, phase in enumerate(self._phases):
            if ap_id in phase.ap_ids:
                return i
        return None

    def compute(
        self,
        guard_passed: bool,
        tokens_used: int,
        retries_used: int,
        terminal: bool,
        action: int | None = None,
        satisfied: frozenset[str] | None = None,
        available: frozenset[str] | None = None,
    ) -> RewardSignal:
        # Delegate to base reward function
        base_signal = self._base.compute(
            guard_passed=guard_passed,
            tokens_used=tokens_used,
            retries_used=retries_used,
            terminal=terminal,
            action=action,
            satisfied=satisfied,
            available=available,
        )

        # If we can't determine the action's phase, return base reward
        if action is None or satisfied is None:
            return base_signal

        # Resolve action index to AP ID. When ap_ids is provided (the
        # ordered AP pool from the environment), use it directly. This is
        # correct because `action` is an index into the pool, NOT into the
        # (smaller, variable) available set. Legacy fallback uses
        # sorted(available) for backwards compatibility with tests.
        if self._ap_ids is not None:
            if action < 0 or action >= len(self._ap_ids):
                return base_signal
            selected_ap = self._ap_ids[action]
        else:
            if available is None:
                return base_signal
            ap_list = sorted(available)
            if action < 0 or action >= len(ap_list):
                return base_signal
            selected_ap = ap_list[action]
        ap_phase = self._ap_phase_index(selected_ap)

        # AP not in any defined phase — return base reward unmodified
        if ap_phase is None:
            return base_signal

        # Determine active phase from pre-action state. The environment
        # passes post-action satisfied, so we track the previous step's
        # satisfied set to know the state the agent decided from.
        active_phase = self._active_phase_index(self._prev_satisfied)
        value = base_signal.value

        if ap_phase == active_phase:
            # Active phase: add bonus to encourage in-order execution
            value += self._in_phase_bonus
        elif ap_phase > active_phase:
            # Future phase: reduce reward and apply penalty to discourage
            # premature attempts. The penalty ensures a non-zero negative
            # signal even when the base reward is ~0.
            value *= self._out_of_phase_multiplier
            value -= self._attempt_penalty
        # Past phase (ap_phase < active_phase): keep base reward as-is

        # Track state for next call
        if terminal:
            self._prev_satisfied = frozenset()
        else:
            self._prev_satisfied = satisfied

        return RewardSignal(
            value=value,
            guard_passed=guard_passed,
            tokens_used=tokens_used,
            retries_used=retries_used,
            terminal=terminal,
        )


class TimePenaltyReward(RewardFunctionInterface):
    """Wraps a base reward and penalises steps proportional to wall-clock duration.

    Designed for the pre-commit gym where slow checks (Docker builds,
    integration tests) should be run last.  The penalty teaches the
    agent to order fast checks before slow ones.

    Wall-clock measurement is infrastructure — the domain interface is
    unchanged.

    Usage::

        base = MazeReward()
        reward = TimePenaltyReward(base, time_weight=0.01)
        # ... use reward in TrainingEnvironment ...

    Args:
        base_reward: Wrapped reward function that computes the raw reward.
        time_weight: Multiplier for the wall-clock penalty.  Each second
            of wall time subtracts ``time_weight`` from the reward.
            Default 0.01 (1 second = -0.01 penalty).
    """

    def __init__(
        self,
        base_reward: RewardFunctionInterface,
        time_weight: float = 0.01,
    ) -> None:
        self._base = base_reward
        self._time_weight = time_weight
        self._step_start: float | None = None

    def mark_step_start(self) -> None:
        """Record the wall-clock start of the current step.

        Call this before the environment executes the action pair.
        If not called, no time penalty is applied.
        """
        self._step_start = time.monotonic()

    def compute(
        self,
        guard_passed: bool,
        tokens_used: int,
        retries_used: int,
        terminal: bool,
        action: int | None = None,
        satisfied: frozenset[str] | None = None,
        available: frozenset[str] | None = None,
    ) -> RewardSignal:
        base_signal = self._base.compute(
            guard_passed=guard_passed,
            tokens_used=tokens_used,
            retries_used=retries_used,
            terminal=terminal,
            action=action,
            satisfied=satisfied,
            available=available,
        )

        # Compute wall-clock penalty
        time_penalty = 0.0
        if self._step_start is not None:
            elapsed = time.monotonic() - self._step_start
            time_penalty = elapsed * self._time_weight
            self._step_start = None

        return RewardSignal(
            value=base_signal.value - time_penalty,
            guard_passed=guard_passed,
            tokens_used=tokens_used,
            retries_used=retries_used,
            terminal=terminal,
        )
