"""
CommandTemplateGenerator: Deterministic generator that resolves {spec.*} placeholders.

For command-based APs, the task field in the prompt template IS the command
template. The generator resolves {spec.*} placeholders from the specification
and returns the resolved command string as the artifact content.
"""

import re
import uuid
from datetime import datetime

from atomicguard.domain.interfaces import GeneratorInterface
from atomicguard.domain.models import (
    ActionPairId,
    Artifact,
    ArtifactId,
    ArtifactStatus,
    Context,
    ContextSnapshot,
    WorkflowId,
)
from atomicguard.domain.prompts import PromptTemplate


class CommandTemplateGenerator(GeneratorInterface):
    """Resolves {spec.*} placeholders in the task template from the specification.

    The specification string is parsed as key=value pairs (one per line) or
    used as-is if no placeholders exist in the template.
    """

    def generate(
        self,
        context: Context,
        template: PromptTemplate,
        action_pair_id: str = "unknown",
        workflow_id: str = "unknown",
        workflow_ref: str | None = None,
    ) -> Artifact:
        command = template.task

        # Resolve {spec.*} placeholders from the specification
        placeholders = re.findall(r"\{spec\.(\w+)\}", command)
        if placeholders:
            spec_values = self._parse_specification(context.specification)
            for key in placeholders:
                if key not in spec_values:
                    msg = f"Missing specification key: spec.{key}"
                    raise KeyError(msg)
                command = command.replace(f"{{spec.{key}}}", spec_values[key])

        return Artifact(
            artifact_id=ArtifactId(str(uuid.uuid4())),
            workflow_id=WorkflowId(workflow_id),
            content=command,
            previous_attempt_id=None,
            parent_action_pair_id=None,
            action_pair_id=ActionPairId(action_pair_id),
            created_at=datetime.now().isoformat(),
            attempt_number=1,
            status=ArtifactStatus.PENDING,
            guard_result=None,
            context=ContextSnapshot(
                workflow_id=workflow_id,
                specification=context.specification,
                constraints=context.ambient.constraints if context.ambient else "",
                feedback_history=(),
            ),
            workflow_ref=workflow_ref,
        )

    @staticmethod
    def _parse_specification(spec: str) -> dict[str, str]:
        """Parse specification as key=value pairs (one per line)."""
        result = {}
        for line in spec.strip().splitlines():
            line = line.strip()
            if "=" in line:
                key, _, value = line.partition("=")
                result[key.strip()] = value.strip()
        return result
