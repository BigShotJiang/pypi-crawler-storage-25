"""
Stdin-based human guard resolver for CLI use.

Blocks on stdin to get human approval/rejection. Used by the runner
daemon when executing locally (no web dashboard).
"""

from __future__ import annotations

import uuid

from atomicguard.domain.interfaces import HumanReviewerInterface
from atomicguard.domain.models import Artifact
from atomicguard.domain.runner import ReviewDecision


class StdinHumanReviewer(HumanReviewerInterface):
    """Resolves human reviews via stdin prompts.

    ``request_review`` stores the review metadata. ``poll_decision``
    blocks on stdin (using rich prompts) and returns the decision
    immediately — no actual polling loop needed for stdin.
    """

    def __init__(self) -> None:
        self._pending: dict[str, _PendingReview] = {}

    def request_review(
        self,
        job_id: str,
        ap_id: str,
        artifact: Artifact,
        prompt: str,
    ) -> str:
        review_id = str(uuid.uuid4())
        self._pending[review_id] = _PendingReview(
            job_id=job_id,
            ap_id=ap_id,
            artifact=artifact,
            prompt=prompt,
        )
        return review_id

    def poll_decision(
        self, review_id: str, timeout: float | None = None
    ) -> ReviewDecision | None:
        """Block on stdin until the user approves or rejects.

        The ``timeout`` parameter is accepted for interface compliance
        but ignored — stdin blocks until the user responds.
        """
        review = self._pending.pop(review_id, None)
        if review is None:
            return None

        return _prompt_for_decision(review)


class _PendingReview:
    """Internal storage for a pending review request."""

    __slots__ = ("job_id", "ap_id", "artifact", "prompt")

    def __init__(
        self,
        job_id: str,
        ap_id: str,
        artifact: Artifact,
        prompt: str,
    ) -> None:
        self.job_id = job_id
        self.ap_id = ap_id
        self.artifact = artifact
        self.prompt = prompt


def _prompt_for_decision(review: _PendingReview) -> ReviewDecision:
    """Display artifact and prompt for human approval via stdin."""
    from rich.console import Console
    from rich.prompt import Prompt
    from rich.syntax import Syntax

    console = Console()

    console.print("\n[bold yellow]═══ HUMAN REVIEW REQUIRED ═══[/bold yellow]")
    console.print(f"[dim]Action Pair: {review.ap_id}[/dim]")
    console.print(f"[dim]Artifact ID: {review.artifact.artifact_id}[/dim]\n")

    if review.prompt:
        console.print(f"[bold]{review.prompt}[/bold]\n")

    console.print(
        Syntax(review.artifact.content, "python", theme="monokai", line_numbers=True)
    )

    decision = Prompt.ask(
        "\n[bold]Approve this artifact?[/bold]",
        choices=["y", "n"],
    )

    if decision == "y":
        return ReviewDecision(approved=True, feedback="Human approved")

    feedback = Prompt.ask("[bold]Rejection reason[/bold]")
    return ReviewDecision(approved=False, feedback=f"Human rejected: {feedback}")
