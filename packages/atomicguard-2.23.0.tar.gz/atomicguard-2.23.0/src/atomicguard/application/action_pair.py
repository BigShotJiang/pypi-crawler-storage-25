"""
ActionPair: Atomic generation-verification transaction.

Paper Definition 6a: A = ⟨ρ, a_gen, G_pre, E, G_post⟩
Degenerate case (no effector): A = ⟨ρ, a_gen, G⟩
Precondition ρ is handled at the WorkflowOrchestrator level.
"""

from dataclasses import replace

from atomicguard.domain.interfaces import (
    ActionPairInterface,
    EffectorInterface,
    FailurePhase,
    GeneratorInterface,
    GuardInterface,
)
from atomicguard.domain.models import ActionPairResult, Artifact, Context, GuardResult
from atomicguard.domain.prompts import PromptTemplate


class ActionPair(ActionPairInterface):
    """
    Atomic generation-verification transaction.

    Couples a generator with a guard (and optionally a pre-guard and
    effector) to form an indivisible unit.

    Four-phase execution (when effector is present):
        1. a_gen = generator.generate(context)
        2. G_pre(a_gen) → if fail, return (safe to retry, no side effects)
        3. a_exec = E.execute(a_gen) → world state mutated
        4. G_post(a_exec) → final verdict

    Degenerate case (no effector, no pre_guard):
        1. a_gen = generator.generate(context)
        2. G(a_gen) → verdict
    """

    def __init__(
        self,
        generator: GeneratorInterface,
        guard: GuardInterface,
        prompt_template: PromptTemplate,
        pre_guard: GuardInterface | None = None,
        effector: EffectorInterface | None = None,
    ):
        """
        Args:
            generator: The artifact generator
            guard: The post-guard validator (G_post, or sole guard in degenerate case)
            prompt_template: Structured prompt template for generation
            pre_guard: Optional pre-execution validator (G_pre)
            effector: Optional world-state mutator (E)
        """
        self._generator = generator
        self._guard = guard
        self._prompt_template = prompt_template
        self._pre_guard = pre_guard
        self._effector = effector

    @property
    def generator(self) -> GeneratorInterface:
        """Access the generator (read-only)."""
        return self._generator

    @property
    def guard(self) -> GuardInterface:
        """Access the (post-)guard (read-only)."""
        return self._guard

    @property
    def pre_guard(self) -> GuardInterface | None:
        """Access the pre-guard (read-only)."""
        return self._pre_guard

    @property
    def effector(self) -> EffectorInterface | None:
        """Access the effector (read-only)."""
        return self._effector

    def execute(
        self,
        context: Context,
        dependencies: dict[str, Artifact] | None = None,
        action_pair_id: str = "unknown",
        workflow_id: str = "unknown",
        artifact_type: str | None = None,
    ) -> ActionPairResult:
        """
        Execute the four-phase transaction (Definition 6a).

        Returns:
            ActionPairResult with a_gen, optional a_exec, guard_result,
            and failure_phase.
        """
        dependencies = dependencies or {}

        # Phase 1: Generate
        a_gen = self._generator.generate(
            context, self._prompt_template, action_pair_id, workflow_id
        )

        # Tag artifact with semantic type if specified and not already set
        if artifact_type and not a_gen.artifact_type:
            a_gen = replace(a_gen, artifact_type=artifact_type)

        # Generator error check — short-circuit before guards/effector
        generator_error = a_gen.metadata.get("generator_error")
        if generator_error:
            generator_error_kind = a_gen.metadata.get("generator_error_kind")
            is_fatal = (
                generator_error_kind == "fatal_file_size"
                or self._is_context_too_long_error(generator_error)
                or self._is_fatal_api_error(generator_error)
            )
            return ActionPairResult(
                a_gen=a_gen,
                guard_result=GuardResult(
                    passed=False,
                    feedback=generator_error,
                    fatal=is_fatal,
                    guard_name="GeneratorValidation",
                ),
                failure_phase=FailurePhase.POST_GUARD,
            )

        # Phase 2: Pre-guard (G_pre) — no side effects, safe to retry
        if self._pre_guard is not None:
            pre_result = self._pre_guard.validate(a_gen, **dependencies)
            if not pre_result.passed:
                return ActionPairResult(
                    a_gen=a_gen,
                    guard_result=pre_result,
                    failure_phase=FailurePhase.PRE_GUARD,
                )

        # Phase 3: Effector (E) — world state mutation
        a_exec: Artifact | None = None
        if self._effector is not None:
            try:
                a_exec = self._effector.execute(a_gen)
            except Exception as exc:
                return ActionPairResult(
                    a_gen=a_gen,
                    guard_result=GuardResult(
                        passed=False,
                        feedback=f"Effector execution failed: {exc}",
                        fatal=False,
                        guard_name="EffectorExecution",
                    ),
                    failure_phase=FailurePhase.EFFECTOR,
                )

        # Phase 4: Post-guard (G_post) — validates a_exec or a_gen
        target = a_exec if a_exec is not None else a_gen
        result = self._guard.validate(target, **dependencies)

        return ActionPairResult(
            a_gen=a_gen,
            guard_result=result,
            a_exec=a_exec,
            failure_phase=FailurePhase.PASSED
            if result.passed
            else FailurePhase.POST_GUARD,
        )

    @staticmethod
    def _is_fatal_api_error(error: str) -> bool:
        """Detect fatal API configuration errors."""
        patterns = [
            "is not a valid model",
            "model not found",
            "model_not_found",
            "invalid api key",
            "incorrect api key",
            "invalid_api_key",
            "authentication failed",
            "permission denied",
            "access denied",
            "status_code: 400",
            "status_code: 401",
            "status_code: 403",
        ]
        error_lower = error.lower()
        return any(p in error_lower for p in patterns)

    @staticmethod
    def _is_context_too_long_error(error: str) -> bool:
        """Detect LLM context length errors."""
        patterns = [
            "context_length_exceeded",
            "maximum context length",
            "too many tokens",
            "context too long",
            "exceeds the model's maximum",
            "token limit",
            "max_tokens",
        ]
        error_lower = error.lower()
        return any(p in error_lower for p in patterns)
