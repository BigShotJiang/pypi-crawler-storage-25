"""
WorkflowRunner: thin service that composes build_orchestrator + execute.

This is the primary entry point for callers that want a single call
rather than manually building and executing an orchestrator.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from atomicguard.application.builder import build_orchestrator

if TYPE_CHECKING:
    from atomicguard.application.workflow import StepCallback
    from atomicguard.domain.interfaces import (
        ArtifactDAGInterface,
        GeneratorInterface,
        GuardInterface,
    )
    from atomicguard.domain.models import (
        APContextEntry,
        WorkflowDefinition,
        WorkflowResult,
    )


class WorkflowRunner:
    """Service that builds and executes a workflow in one call.

    Contains no logic of its own — it is purely the composition of
    ``build_orchestrator()`` + ``orchestrator.execute()``.  Both can
    be used independently when finer control is needed.
    """

    def run(
        self,
        definition: WorkflowDefinition,
        specification: str,
        ap_context: dict[str, APContextEntry],
        generator_registry: dict[str, GeneratorInterface],
        guard_registry: dict[str, GuardInterface],
        artifact_dag: ArtifactDAGInterface,
        step_callback: StepCallback | None = None,
    ) -> WorkflowResult:
        """Build an orchestrator from the definition and execute it.

        Args:
            definition: Declarative workflow specification.
            specification: The user-supplied task prompt.
            ap_context: Prompt template context keyed by ``ap_id``.
            generator_registry: Map of generator name → concrete instance.
            guard_registry: Map of guard name → concrete instance.
            artifact_dag: Artifact storage implementation.
            step_callback: Optional callback for step-level progress.

        Returns:
            The workflow execution result.
        """
        orchestrator = build_orchestrator(
            definition=definition,
            ap_context=ap_context,
            generator_registry=generator_registry,
            guard_registry=guard_registry,
            artifact_dag=artifact_dag,
            step_callback=step_callback,
        )
        return orchestrator.execute(specification)
