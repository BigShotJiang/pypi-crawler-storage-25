"""
WorkflowOrchestrator: Orchestrates ActionPair execution across multiple steps.

Owns WorkflowState and infers preconditions from step dependencies.

Extension 09: Supports escalation via informed backtracking when
stagnation is detected, including cascade invalidation of dependent steps.
Supports guard-specific escalation routing via escalation_by_guard (Definition 45).
"""

import logging
import uuid
from collections import defaultdict, deque
from collections.abc import Callable
from types import MappingProxyType
from typing import Any, Protocol

from atomicguard.application.action_pair import ActionPair
from atomicguard.application.agent import DualStateAgent
from atomicguard.domain.exceptions import (
    EscalationRequired,
    RmaxExhausted,
    StagnationDetected,
)
from atomicguard.domain.interfaces import (
    ActionPairInfo,
    ActionPairPoolInterface,
    ArtifactDAGInterface,
    WorkflowExecutorInterface,
)
from atomicguard.domain.models import (
    Artifact,
    GuardId,
    GuardResult,
    WorkflowResult,
    WorkflowState,
    WorkflowStatus,
    WorkflowStep,
)


class AgentFactory(Protocol):
    """Protocol for creating step agents.

    Allows WorkflowOrchestrator to construct agents without hardcoding
    which agent class to use. Agent selection becomes a
    config/registry concern via dependency injection.
    """

    def create_agent(
        self,
        action_pair: ActionPair,
        artifact_dag: Any,
        rmax: int,
        constraints: str,
        action_pair_id: str,
        workflow_id: str,
        r_patience: int | None,
        e_max: int,
        escalate_feedback_to: list[str],
        escalate_feedback_by_guard: dict[str, list[str]],
    ) -> Any: ...


logger = logging.getLogger(__name__)

# Callback type: (ap_id, artifact, guard_result) -> None
StepCallback = Callable[[str, "Artifact", "GuardResult"], None]


class WorkflowOrchestrator(ActionPairPoolInterface, WorkflowExecutorInterface):
    """
    Orchestrates ActionPair execution.

    Owns WorkflowState and infers preconditions from requires.
    Implements WorkflowEnvironmentInterface for RL training environments.
    """

    def __init__(
        self,
        artifact_dag: ArtifactDAGInterface,
        rmax: int = 3,
        constraints: str = "",
        agent_factory: AgentFactory | None = None,
        step_callback: StepCallback | None = None,
    ):
        """
        Args:
            artifact_dag: Repository for storing artifacts
            rmax: Maximum retries per step
            constraints: Global constraints for the ambient environment
            agent_factory: Optional factory for creating step agents.
                If None, defaults to DualStateAgent construction.
            step_callback: Optional callback invoked after each step completes
                (both pass and fail). Signature:
                ``(ap_id: str, artifact: Artifact, guard_result: GuardResult) -> None``
        """
        self._dag = artifact_dag
        self._rmax = rmax
        self._constraints = constraints
        self._agent_factory = agent_factory
        self._step_callback = step_callback
        self._steps: list[WorkflowStep] = []
        self._steps_by_id: dict[str, WorkflowStep] = {}
        self._workflow_state = WorkflowState()
        self._artifacts: dict[str, Artifact] = {}
        # Extension 09: Escalation tracking
        self._escalation_count: dict[str, int] = defaultdict(int)  # step_id -> count
        self._escalation_context: dict[str, str] = {}  # step_id -> failure_summary
        self._escalation_feedback: dict[str, list[str]] = defaultdict(
            list
        )  # step_id -> failure summaries

    def add_step(
        self,
        guard_id: str,
        action_pair: ActionPair,
        requires: tuple[str, ...] = (),
        deps: tuple[str, ...] | None = None,
        r_patience: int | None = None,
        e_max: int = 1,
        escalate_feedback_to: tuple[str, ...] = (),
        escalate_feedback_by_guard: dict[str, tuple[str, ...]] | None = None,
        requires_any: tuple[tuple[str, ...], ...] = (),
        group: str | None = None,
        artifact_type: str | None = None,
        artifact_context: str | None = None,
        required: bool = True,
        goal: bool = False,
    ) -> "WorkflowOrchestrator":
        """
        Register a step. Precondition inferred from requires.

        Args:
            guard_id: Unique identifier for this step (e.g., 'g_test', 'g_impl')
            action_pair: The generator-guard pair for this step
            requires: Guard IDs that must be satisfied before this step
            deps: Artifact dependencies to pass to guard (defaults to requires)
            r_patience: Consecutive similar failures before escalation (Extension 09).
                        If None, escalation is disabled for this step.
            e_max: Maximum escalation attempts before FAIL (Extension 09, default: 1)
            escalate_feedback_to: Upstream steps to receive failure context on stagnation.
                Cascade invalidation automatically re-runs all dependent steps; this
                controls WHICH steps receive the failure summary for informed regeneration.
            escalate_feedback_by_guard: Per-guard feedback routing (Definition 45).
                Overrides escalate_feedback_to for specific guards.
            requires_any: OR-group dependencies. Each tuple is an OR-group;
                at least one member of each group must be satisfied.
            group: Variant group name. APs in the same group are alternatives;
                once one is satisfied, others are excluded from available.
            artifact_type: Semantic type tag for the artifact produced by this step
                (e.g. "patch", "localization"). Used for type-based dependency lookup.
            artifact_context: How consumers should present this step's artifact.
                Rendered in the DEPENDENCIES section of downstream prompts.
            required: Whether this step must be satisfied for workflow completion
                (default: True). Optional steps participate but don't block the goal.
            goal: Whether this step is a goal/exit state. When any goal AP is
                satisfied, the episode is complete. Multiple APs can be goals.

        Returns:
            Self for fluent chaining
        """
        if deps is None:
            deps = requires

        # Extension 09: Validate r_patience < rmax invariant (Definition 44)
        if r_patience is not None and r_patience >= self._rmax:
            raise ValueError(
                f"r_patience ({r_patience}) must be < rmax ({self._rmax}). "
                f"Extension 09 invariant: 1 < r_patience < rmax"
            )

        self._steps.append(
            WorkflowStep(
                guard_id=guard_id,
                action_pair=action_pair,
                requires=requires,
                deps=deps,
                r_patience=r_patience,
                e_max=e_max,
                escalate_feedback_to=escalate_feedback_to,
                escalate_feedback_by_guard=MappingProxyType(
                    escalate_feedback_by_guard or {}
                ),
                requires_any=requires_any,
                group=group,
                artifact_type=artifact_type,
                artifact_context=artifact_context,
                required=required,
                goal=goal,
            )
        )
        self._steps_by_id[guard_id] = self._steps[-1]
        return self  # Fluent

    def execute(
        self, specification: str, workflow_id: str | None = None
    ) -> WorkflowResult:
        """
        Execute the workflow until completion or failure.

        Extension 09: Supports escalation via informed backtracking.

        Args:
            specification: The task specification
            workflow_id: Optional workflow ID to reuse (for resume).
                If None, a fresh UUID is generated.

        Returns:
            WorkflowResult with success status and artifacts
        """
        workflow_id = workflow_id or str(uuid.uuid4())

        # Extension 09: Validate escalate_feedback_to targets exist before execution
        step_ids = {s.guard_id for s in self._steps}
        for s in self._steps:
            for target in s.escalate_feedback_to:
                if target not in step_ids:
                    raise ValueError(
                        f"Escalate feedback target '{target}' not found in workflow steps"
                    )

        while not self._is_goal_state():
            step = self._find_applicable()

            if step is None:
                return WorkflowResult(
                    status=WorkflowStatus.FAILED,
                    artifacts=self._artifacts,
                    failed_step="No applicable step",
                )

            # Extract dependencies (keys match action_pair_ids from workflow.json)
            dependencies = {
                gid: self._artifacts[gid] for gid in step.deps if gid in self._artifacts
            }

            # Extension 09: Get any injected failure context
            effective_constraints = self._constraints
            if step.guard_id in self._escalation_context:
                failure_ctx = self._escalation_context.pop(step.guard_id)
                effective_constraints = f"{self._constraints}\n\n{failure_ctx}"
                logger.info(
                    "[%s] Re-running with injected failure context from escalation",
                    step.guard_id,
                )

            # Build artifact context strings for dependencies
            dep_artifact_contexts: dict[str, str] = {}
            for gid in step.deps:
                if gid in self._artifacts and gid in self._steps_by_id:
                    ac = self._steps_by_id[gid].artifact_context
                    if ac is not None:
                        dep_artifact_contexts[gid] = ac

            # Execute via stateless agent (factory-created or default DualStateAgent)
            if self._agent_factory is not None:
                agent = self._agent_factory.create_agent(
                    action_pair=step.action_pair,
                    artifact_dag=self._dag,
                    rmax=self._rmax,
                    constraints=effective_constraints,
                    action_pair_id=step.guard_id,
                    workflow_id=workflow_id,
                    r_patience=step.r_patience,
                    e_max=step.e_max,
                    escalate_feedback_to=list(step.escalate_feedback_to),
                    escalate_feedback_by_guard={
                        k: list(v) for k, v in step.escalate_feedback_by_guard.items()
                    },
                )
            else:
                agent = DualStateAgent(
                    action_pair=step.action_pair,
                    artifact_dag=self._dag,
                    rmax=self._rmax,
                    constraints=effective_constraints,
                    action_pair_id=step.guard_id,
                    workflow_id=workflow_id,
                    r_patience=step.r_patience,
                    e_max=step.e_max,
                    escalate_feedback_to=list(step.escalate_feedback_to),
                    escalate_feedback_by_guard={
                        k: list(v) for k, v in step.escalate_feedback_by_guard.items()
                    },
                    artifact_type=step.artifact_type,
                    dependency_artifact_contexts=dep_artifact_contexts or None,
                    artifact_context=step.artifact_context,
                )

            try:
                # Get escalation feedback accumulated for this step
                step_escalation_feedback = tuple(
                    self._escalation_feedback.get(step.guard_id, [])
                )
                artifact = agent.execute(
                    specification,
                    dependencies,
                    escalation_feedback=step_escalation_feedback,
                )
                self._artifacts[step.guard_id] = artifact
                self._workflow_state = self._workflow_state.with_satisfied(
                    GuardId(step.guard_id), artifact.artifact_id
                )

                # Invoke step callback on success
                if (
                    self._step_callback is not None
                    and artifact.guard_result is not None
                ):
                    self._step_callback(step.guard_id, artifact, artifact.guard_result)

            except StagnationDetected as e:
                # Level 2: WorkflowOrchestrator backtracking
                if self._escalation_count[step.guard_id] < step.e_max:
                    logger.info(
                        "[%s] Escalation %d/%d triggered. Targets: %s",
                        step.guard_id,
                        self._escalation_count[step.guard_id] + 1,
                        step.e_max,
                        e.escalate_to,
                    )

                    # Store escalation feedback for this step and targets
                    if e.failure_summary:
                        self._escalation_feedback[step.guard_id].append(
                            e.failure_summary
                        )
                        for target_id in e.escalate_to:
                            self._escalation_feedback[target_id].append(
                                e.failure_summary
                            )

                    # Definition 47: Cascade Invalidation - invalidate ALL targets
                    for target_id in e.escalate_to:
                        self._invalidate_dependents(target_id)
                        # Definition 48: Context Injection for each target
                        if e.failure_summary:
                            self._inject_failure_context(target_id, e.failure_summary)

                    self._escalation_count[step.guard_id] += 1

                    continue  # Re-run from earliest invalidated step
                else:
                    # e_max exceeded - promote to human escalation
                    return WorkflowResult(
                        status=WorkflowStatus.ESCALATION,
                        artifacts=self._artifacts,
                        failed_step=step.guard_id,
                        escalation_feedback=(
                            f"Automated escalation exhausted ({step.e_max} attempts). "
                            f"Failure summary: {e.failure_summary}"
                        ),
                    )

            except EscalationRequired as e:
                # Level 4: Human intervention (fatal guard)
                return WorkflowResult(
                    status=WorkflowStatus.ESCALATION,
                    artifacts=self._artifacts,
                    failed_step=step.guard_id,
                    escalation_artifact=e.artifact,
                    escalation_feedback=e.feedback,
                )

            except RmaxExhausted as e:
                return WorkflowResult(
                    status=WorkflowStatus.FAILED,
                    artifacts=self._artifacts,
                    failed_step=step.guard_id,
                    provenance=tuple(e.provenance),
                )

        return WorkflowResult(status=WorkflowStatus.SUCCESS, artifacts=self._artifacts)

    def resume_from(
        self,
        workflow_id: str,
        failed_step: str | None = None,
        resolution: GuardResult | None = None,
    ) -> None:
        """Hydrate orchestrator state from a previous execution in the DAG.

        Reads the repository for the given workflow_id, restores satisfied
        steps and their artifacts, and optionally applies a resolution
        (guard verdict) to the failed step.

        After calling this, ``execute(spec, workflow_id=workflow_id)`` will
        skip already-satisfied steps and resume from the first unsatisfied one.

        Args:
            workflow_id: The workflow_id of the previous execution to resume.
            failed_step: The step that triggered escalation (optional).
            resolution: A GuardResult resolving the failed step (optional).
                If ``resolution.passed`` is True, the step is marked satisfied.
                If ``resolution.passed`` is False, ``resolution.feedback`` is
                injected as escalation feedback for the step's next attempt.
        """
        previous_artifacts = self._dag.get_by_workflow(workflow_id)

        # Restore satisfied steps from accepted artifacts
        for artifact in previous_artifacts:
            ap_id = artifact.action_pair_id
            if ap_id in self._steps_by_id and artifact.is_accepted():
                self._workflow_state = self._workflow_state.with_satisfied(
                    GuardId(ap_id), artifact.artifact_id
                )
                self._artifacts[ap_id] = artifact

        # Apply resolution to the failed step
        if failed_step and resolution and failed_step in self._steps_by_id:
            if resolution.passed:
                # Human approved: find the artifact and mark step satisfied
                for artifact in previous_artifacts:
                    if artifact.action_pair_id == failed_step:
                        self._workflow_state = self._workflow_state.with_satisfied(
                            GuardId(failed_step), artifact.artifact_id
                        )
                        self._artifacts[failed_step] = artifact
                        break
            elif resolution.feedback:
                # Human rejected: inject feedback for next attempt
                self._escalation_feedback[failed_step].append(resolution.feedback)

    def _invalidate_dependents(self, target_id: str) -> None:
        """Mark target and all transitive dependents as unsatisfied (Definition 47).

        When escalating to an upstream step, all steps that depend on it
        (directly or transitively) must be invalidated so they re-execute
        with fresh artifacts.

        Args:
            target_id: The action_pair_id to invalidate (and its dependents)
        """
        to_invalidate = self._get_transitive_dependents(target_id)
        to_invalidate.add(target_id)  # Include target itself

        for step_id in to_invalidate:
            if self._workflow_state.is_satisfied(GuardId(step_id)):
                logger.debug("[%s] Cascade invalidation", step_id)
                self._workflow_state = self._workflow_state.with_unsatisfied(
                    GuardId(step_id)
                )
                self._artifacts.pop(step_id, None)

    def _get_transitive_dependents(self, target_id: str) -> set[str]:
        """Find all steps that transitively depend on target_id (Definition 47).

        Uses BFS to find all steps that have target_id in their requires chain.

        Args:
            target_id: The action_pair_id to find dependents for

        Returns:
            Set of guard_ids that depend on target (directly or transitively)
        """
        dependents: set[str] = set()
        queue: deque[str] = deque([target_id])

        while queue:
            current = queue.popleft()
            for step in self._steps:
                if step.guard_id in dependents:
                    continue
                # Check AND deps
                if current in step.requires:
                    dependents.add(step.guard_id)
                    queue.append(step.guard_id)
                    continue
                # Check OR-group deps
                for or_group in step.requires_any:
                    if current in or_group:
                        dependents.add(step.guard_id)
                        queue.append(step.guard_id)
                        break

        return dependents

    def _inject_failure_context(self, target_id: str, summary: str) -> None:
        """Add failure summary to constraints for target re-execution (Definition 48).

        The failure summary describes what went wrong in downstream steps,
        enabling the upstream generator to produce output that avoids
        the same failure patterns.

        Args:
            target_id: The action_pair_id to inject context for
            summary: The failure summary to inject
        """
        self._escalation_context[target_id] = summary
        logger.debug(
            "[%s] Failure context injected for re-execution",
            target_id,
        )

    def _precondition_met(self, step: WorkflowStep) -> bool:
        """Precondition: all AND deps satisfied + all OR-groups have a satisfied member."""
        if not all(
            self._workflow_state.is_satisfied(GuardId(req)) for req in step.requires
        ):
            return False
        for or_group in step.requires_any:
            if not any(self._workflow_state.is_satisfied(GuardId(m)) for m in or_group):
                return False
        return True

    def _find_applicable(self) -> WorkflowStep | None:
        """Find first step not done and with precondition met.

        Skips group members whose group already has a satisfied member.
        """
        satisfied_groups = self._get_satisfied_groups()
        for step in self._steps:
            if self._workflow_state.is_satisfied(GuardId(step.guard_id)):
                continue
            if step.group and step.group in satisfied_groups:
                continue
            if self._precondition_met(step):
                return step
        return None

    def _get_satisfied_groups(self) -> set[str]:
        """Return set of group names that have at least one satisfied member."""
        groups: set[str] = set()
        for step in self._steps:
            if step.group and self._workflow_state.is_satisfied(GuardId(step.guard_id)):
                groups.add(step.group)
        return groups

    def _is_goal_state(self) -> bool:
        """Check if workflow is complete.

        All required non-grouped steps must be satisfied, plus at least one
        member of each required variant group (groups with at least one
        required member).
        """
        groups_needed: set[str] = set()
        for step in self._steps:
            if step.group:
                if step.required:
                    groups_needed.add(step.group)
            elif step.required and not self._workflow_state.is_satisfied(
                GuardId(step.guard_id)
            ):
                return False
        return groups_needed <= self._get_satisfied_groups()

    def get_workflow_definition(self) -> dict:
        """Build workflow definition dict for W_ref computation.

        Returns a serializable dict representing the workflow structure.
        Used for W_ref computation (Definition 11).

        Returns:
            Dict with steps, rmax, and constraints for hashing.
        """
        return {
            "steps": [
                {
                    "guard_id": step.guard_id,
                    "requires": list(step.requires),
                    "deps": list(step.deps),
                }
                for step in self._steps
            ],
            "rmax": self._rmax,
            "constraints": self._constraints,
        }

    def get_step(self, guard_id: str) -> WorkflowStep:
        """Get a workflow step by guard_id.

        Args:
            guard_id: The identifier of the step to retrieve.

        Returns:
            The WorkflowStep with the given guard_id.

        Raises:
            KeyError: If no step with the given guard_id exists.
        """
        for step in self._steps:
            if step.guard_id == guard_id:
                return step
        raise KeyError(f"Step not found: {guard_id}")

    # -- ActionPairPoolInterface --

    def get_available_action_pair_count(self) -> int:
        """Return the number of available action pairs in the pool."""
        return len(self._steps)

    def get_max_retries(self) -> int:
        """Return the maximum retry count (rmax) per action pair."""
        return self._rmax

    def get_available_action_pairs(self) -> tuple[ActionPairInfo, ...]:
        """Return the pool of action pairs the agent can choose from."""
        return tuple(
            ActionPairInfo(
                action_pair_id=step.guard_id,
                action_pair=step.action_pair,
                requires=step.requires,
                escalate_feedback_to=step.escalate_feedback_to,
                r_patience=step.r_patience,
                requires_any=step.requires_any,
                group=step.group,
                artifact_type=step.artifact_type,
                artifact_context=step.artifact_context,
                required=step.required,
                goal=step.goal,
            )
            for step in self._steps
        )

    def get_satisfied_action_pairs(self) -> tuple[str, ...]:
        """Return IDs of action pairs whose guards have passed."""
        return self._workflow_state.get_satisfied_guards()
