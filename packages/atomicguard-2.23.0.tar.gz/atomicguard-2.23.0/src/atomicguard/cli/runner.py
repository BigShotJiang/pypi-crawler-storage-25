"""
``atomicguard runner`` — long-running daemon that polls a job queue.

Subcommands:

- ``start`` — Poll a SQLiteJobQueue for jobs, execute them, report status.
- ``register`` — Register with Agentia Cloud (placeholder — requires
  ``atomicguard-cloud``).
"""

from __future__ import annotations

import logging
import os
import signal
import sys
import time
from typing import TYPE_CHECKING

import click

if TYPE_CHECKING:
    from atomicguard.domain.runner import RunJob
    from atomicguard.infrastructure.queue_sqlite import SQLiteJobQueue

logger = logging.getLogger(__name__)


@click.group()
def runner_group() -> None:
    """Manage workflow runners."""


@runner_group.command("start")
@click.option(
    "--queue",
    "queue_url",
    required=True,
    type=str,
    help="Queue URL. Format: sqlite:///path/to/jobs.db",
)
@click.option(
    "--poll-interval",
    default=2.0,
    show_default=True,
    type=float,
    help="Seconds between queue polls.",
)
@click.option(
    "--api-key",
    default=None,
    type=str,
    help="API key (overrides LLM_API_KEY environment variable).",
)
@click.option(
    "--base-url",
    default="",
    type=str,
    help="API base URL (for ollama/openai providers).",
)
@click.option(
    "--review-db",
    default=None,
    type=str,
    help="Review DB path for web-based human review (replaces stdin prompts).",
)
@click.option(
    "-v",
    "--verbose",
    is_flag=True,
    default=False,
    help="Enable verbose (DEBUG) logging.",
)
def runner_start(
    queue_url: str,
    poll_interval: float,
    api_key: str | None,
    base_url: str,
    review_db: str | None,
    verbose: bool,
) -> None:
    """Start a runner that polls for jobs and executes them."""
    log_level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    from atomicguard.cli._queue import parse_queue_url

    db_path = parse_queue_url(queue_url)
    click.echo(f"Runner starting — queue: {db_path}")
    click.echo(f"Poll interval: {poll_interval}s")
    if review_db:
        click.echo(f"Review DB: {review_db} (web-based human review)")
    else:
        click.echo("Human review: stdin (interactive)")
    click.echo("Press Ctrl+C to stop.\n")

    from atomicguard.infrastructure.queue_sqlite import SQLiteJobQueue

    queue = SQLiteJobQueue(db_path)

    # Graceful shutdown
    shutdown_requested = False

    def _handle_signal(_signum: int, _frame: object) -> None:
        nonlocal shutdown_requested
        shutdown_requested = True
        click.echo("\nShutdown requested — finishing current job...")

    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    resolved_api_key = api_key or os.environ.get("LLM_API_KEY", "")

    jobs_executed = 0
    while not shutdown_requested:
        job = queue.claim()
        if job is None:
            time.sleep(poll_interval)
            continue

        jobs_executed += 1
        click.echo(f"[Job {jobs_executed}] Claimed: {job.job_id}")
        click.echo(f"  Workflow: {job.workflow_definition.name}")
        click.echo(f"  Model: {job.model} ({job.provider})")

        _execute_job(
            queue=queue,
            job=job,
            api_key=resolved_api_key,
            base_url=base_url,
            review_db=review_db,
        )

    click.echo(f"\nRunner stopped. Executed {jobs_executed} job(s).")
    sys.exit(0)


def _execute_job(
    *,
    queue: SQLiteJobQueue,
    job: RunJob,
    api_key: str,
    base_url: str,
    review_db: str | None = None,
) -> None:
    """Execute a single job and report status to the queue."""
    from atomicguard.domain.runner import JobState, JobStatus

    # Report running
    queue.report_status(JobStatus(job_id=job.job_id, state=JobState.RUNNING))

    try:
        # Build registries from the job's model/provider
        from atomicguard.infrastructure.registries import (
            build_generator_registry,
            build_guard_registry,
        )

        generator_registry = build_generator_registry(
            model=job.model,
            provider=job.provider,
            api_key=api_key,
            base_url=base_url,
        )
        from atomicguard.infrastructure.persistence.memory import InMemoryArtifactDAG

        artifact_dag = InMemoryArtifactDAG()

        # Build status callback that writes to queue
        from atomicguard.infrastructure.status_callback import QueueStatusCallback

        status_cb = QueueStatusCallback(queue)

        # Pause/resume callbacks for human review gates
        def _on_review_pause(ap_id: str, _review_id: str) -> None:
            click.echo(f"  [PAUSED] {ap_id} — waiting for human review")
            status_cb.on_review_paused(job.job_id, ap_id)

        def _on_review_resume(ap_id: str, _review_id: str) -> None:
            click.echo(f"  [RESUMED] {ap_id} — review decision received")
            status_cb.on_review_resumed(job.job_id, ap_id)

        # Choose human reviewer: DB-backed (for web review) or stdin
        from atomicguard.domain.interfaces import HumanReviewerInterface

        reviewer: HumanReviewerInterface
        if review_db:
            from atomicguard.infrastructure.human_guard_db import (
                DBPollingHumanReviewer,
            )

            reviewer = DBPollingHumanReviewer(review_db)
        else:
            from atomicguard.infrastructure.human_guard_stdin import (
                StdinHumanReviewer,
            )

            reviewer = StdinHumanReviewer()

        guard_registry = build_guard_registry(
            human_reviewer=reviewer,
            job_id=job.job_id,
            on_review_pause=_on_review_pause,
            on_review_resume=_on_review_resume,
        )

        # Step callback for stdout + queue status
        def _step_callback(ap_id: str, _artifact: object, guard_result: object) -> None:
            from atomicguard.domain.models import GuardResult as GR

            if isinstance(guard_result, GR):
                label = "PASS" if guard_result.passed else "FAIL"
                click.echo(f"  [{label}] {ap_id}")
                # Also report to queue
                status_cb.on_step_complete(
                    job_id=job.job_id,
                    ap_id=ap_id,
                    attempt=0,  # TODO: step_callback doesn't carry attempt info yet
                    passed=guard_result.passed,
                    feedback=guard_result.feedback or "",
                )

        # Execute
        from atomicguard.application.runner import WorkflowRunner

        runner = WorkflowRunner()
        result = runner.run(
            definition=job.workflow_definition,
            specification=job.specification,
            ap_context=job.ap_context,
            generator_registry=generator_registry,
            guard_registry=guard_registry,
            artifact_dag=artifact_dag,
            step_callback=_step_callback,
        )

        # Report completion
        status_cb.on_run_complete(job.job_id, result)

        status_label = click.style(
            result.status.value,
            fg="green" if result.status.value == "success" else "red",
        )
        click.echo(f"  Result: {status_label}")
        if result.failed_step:
            click.echo(f"  Failed step: {result.failed_step}")

    except Exception:
        logger.exception("Job %s failed with exception", job.job_id)
        queue.report_status(
            JobStatus(
                job_id=job.job_id,
                state=JobState.FAILED,
                error="Runner exception — see runner logs.",
            )
        )
        click.echo(click.style("  FAILED (exception)", fg="red"))


@runner_group.command("register")
def runner_register() -> None:
    """Register this runner with Agentia Cloud.

    Requires the ``atomicguard-cloud`` package. This is a placeholder
    that prints installation instructions.
    """
    click.echo(
        "Cloud runner registration requires the atomicguard-cloud package.\n"
        "Install it with: pip install atomicguard-cloud\n"
        "Then run: atomicguard runner register --token <cloud-token>"
    )
    sys.exit(1)
