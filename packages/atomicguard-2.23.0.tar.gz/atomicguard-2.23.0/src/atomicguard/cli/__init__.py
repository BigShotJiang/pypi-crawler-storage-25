"""
AtomicGuard CLI — command-line interface for workflow execution.

Entry point: ``atomicguard run``
"""
