"""Shared CLI utilities for queue URL parsing."""

from __future__ import annotations

from pathlib import Path

import click


def parse_queue_url(url: str) -> Path:
    """Parse a queue URL into a SQLite database path.

    Currently supports ``sqlite:///path/to/db`` format.
    """
    if url.startswith("sqlite:///"):
        return Path(url[len("sqlite:///") :])
    if url.startswith("sqlite://"):
        return Path(url[len("sqlite://") :])
    raise click.BadParameter(
        f"Unsupported queue URL: {url!r}. Use sqlite:///path/to/jobs.db"
    )
