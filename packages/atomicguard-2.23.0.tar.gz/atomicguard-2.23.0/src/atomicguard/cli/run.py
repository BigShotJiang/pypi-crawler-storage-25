"""
``atomicguard run`` — one-shot workflow execution from the command line.

Loads a WorkflowDefinition from JSON, builds registries, and executes
via InProcessJobQueue + WorkflowRunner.  Streams step progress to stdout.

With ``--queue sqlite:///path``, submits the job to a SQLiteJobQueue
for pickup by ``atomicguard runner start``.
"""

from __future__ import annotations

import json
import logging
import os
import sys
import uuid
from pathlib import Path
from typing import TYPE_CHECKING

import click

if TYPE_CHECKING:
    from atomicguard.domain.models import APContextEntry, WorkflowDefinition
    from atomicguard.domain.runner import RunJob

logger = logging.getLogger(__name__)


def _load_workflow_definition(path: Path) -> WorkflowDefinition:
    """Load a WorkflowDefinition from a JSON file.

    Reuses the existing ``_ap_dict_to_definition`` helper from the
    persistence layer for faithful field parsing.
    """
    from atomicguard.domain.models import WorkflowDefinition
    from atomicguard.infrastructure.persistence.sqlite import (
        _ap_dict_to_definition,
        _slugify,
    )

    data = json.loads(path.read_text())
    name = data.get("name", path.stem)
    slug = _slugify(name)

    aps = [
        _ap_dict_to_definition(ap_id, ap_data)
        for ap_id, ap_data in data.get("action_pairs", {}).items()
    ]

    return WorkflowDefinition(
        slug=slug,
        name=name,
        description=data.get("description", ""),
        specification=data.get("specification"),
        constraints=data.get("constraints", ""),
        model=data.get("model", ""),
        provider=data.get("provider", ""),
        rmax=data.get("rmax", 3),
        action_pairs=tuple(aps),
    )


def _load_ap_context(
    path: Path | None, definition: WorkflowDefinition
) -> dict[str, APContextEntry]:
    """Load AP context entries from a JSON file.

    If no path is provided, tries to find ``ap_context.json`` alongside
    the workflow JSON.  Returns empty contexts for any APs not found.
    """
    from atomicguard.domain.models import APContextEntry

    if path is None:
        return {
            ap.ap_id: APContextEntry(ap_id=ap.ap_id) for ap in definition.action_pairs
        }

    data = json.loads(path.read_text())
    context: dict[str, APContextEntry] = {}
    for ap_id, entry_data in data.items():
        context[ap_id] = APContextEntry(
            ap_id=ap_id,
            role=entry_data.get("role", ""),
            constraints=entry_data.get("constraints", ""),
            task=entry_data.get("task", ""),
            feedback_wrapper=entry_data.get("feedback_wrapper", ""),
            escalation_feedback_wrapper=entry_data.get(
                "escalation_feedback_wrapper", ""
            ),
            feedback_mode=entry_data.get("feedback_mode", "inline"),
            artifact_context=entry_data.get("artifact_context", ""),
        )

    # Fill in any APs not in the context file with empty entries
    for ap_def in definition.action_pairs:
        if ap_def.ap_id not in context:
            context[ap_def.ap_id] = APContextEntry(ap_id=ap_def.ap_id)

    return context


@click.command("run")
@click.option(
    "--workflow",
    required=True,
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    help="Path to workflow definition JSON.",
)
@click.option(
    "--specification",
    required=True,
    type=str,
    help="Task specification (the user prompt).",
)
@click.option(
    "--model",
    required=True,
    type=str,
    help="Model ID (e.g. qwen2.5-coder:14b).",
)
@click.option(
    "--provider",
    required=True,
    type=click.Choice(["ollama", "openrouter", "openai", "huggingface"]),
    help="LLM provider.",
)
@click.option(
    "--ap-context",
    "ap_context_path",
    default=None,
    type=click.Path(exists=True, dir_okay=False, path_type=Path),
    help="Path to AP context JSON (optional).",
)
@click.option(
    "--api-key",
    default=None,
    type=str,
    help="API key (overrides environment variable).",
)
@click.option(
    "--base-url",
    default="",
    type=str,
    help="API base URL (for ollama/openai providers).",
)
@click.option(
    "--queue",
    "queue_url",
    default=None,
    type=str,
    help="Submit to a queue instead of executing in-process. Format: sqlite:///path/to/jobs.db",
)
@click.option(
    "-v",
    "--verbose",
    is_flag=True,
    default=False,
    help="Enable verbose (DEBUG) logging.",
)
def run_command(
    workflow: Path,
    specification: str,
    model: str,
    provider: str,
    ap_context_path: Path | None,
    api_key: str | None,
    base_url: str,
    queue_url: str | None,
    verbose: bool,
) -> None:
    """Execute a workflow from the command line."""
    # Configure logging
    log_level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

    click.echo(f"Loading workflow: {workflow}")
    definition = _load_workflow_definition(workflow)
    click.echo(f"  Name: {definition.name}")
    click.echo(f"  Action pairs: {len(definition.action_pairs)}")
    click.echo(f"  rmax: {definition.rmax}")

    # Load AP context
    ap_context = _load_ap_context(ap_context_path, definition)

    # Build the RunJob
    from atomicguard.domain.runner import RunJob

    job = RunJob(
        job_id=str(uuid.uuid4()),
        workflow_definition=definition,
        ap_context=ap_context,
        specification=specification,
        model=model,
        provider=provider,
    )

    # --queue: submit to external queue and exit
    if queue_url is not None:
        _submit_to_queue(queue_url, job)
        return

    # No --queue: execute in-process (original behavior)
    _execute_in_process(
        job=job,
        definition=definition,
        specification=specification,
        ap_context=ap_context,
        model=model,
        provider=provider,
        api_key=api_key,
        base_url=base_url,
    )


def _submit_to_queue(queue_url: str, job: RunJob) -> None:
    """Submit job to SQLite queue and exit."""
    from atomicguard.cli._queue import parse_queue_url
    from atomicguard.infrastructure.queue_sqlite import SQLiteJobQueue

    db_path = parse_queue_url(queue_url)
    queue = SQLiteJobQueue(db_path)
    queue.submit(job)
    click.echo(f"\nJob submitted to queue: {db_path}")
    click.echo(f"  Job ID: {job.job_id}")
    click.echo(f"Run 'atomicguard runner start --queue {queue_url}' to execute.")


def _execute_in_process(
    *,
    job: RunJob,
    definition: WorkflowDefinition,
    specification: str,
    ap_context: dict[str, APContextEntry],
    model: str,
    provider: str,
    api_key: str | None,
    base_url: str,
) -> None:
    """Execute workflow in-process (no external queue)."""
    # Resolve API key from option or environment
    resolved_api_key = api_key or os.environ.get("LLM_API_KEY", "")

    # Build registries
    click.echo(f"\nModel: {model} ({provider})")
    from atomicguard.infrastructure.registries import (
        build_generator_registry,
        build_guard_registry,
    )

    generator_registry = build_generator_registry(
        model=model,
        provider=provider,
        api_key=resolved_api_key,
        base_url=base_url,
    )
    guard_registry = build_guard_registry()

    # Build artifact DAG
    from atomicguard.infrastructure.persistence.memory import InMemoryArtifactDAG

    artifact_dag = InMemoryArtifactDAG()

    # Submit to in-process queue
    from atomicguard.domain.runner import JobState, JobStatus
    from atomicguard.infrastructure.queue_inprocess import InProcessJobQueue

    queue = InProcessJobQueue()
    queue.submit(job)

    # Step progress callback
    def _step_callback(ap_id: str, _artifact: object, guard_result: object) -> None:
        from atomicguard.domain.models import GuardResult as GR

        if isinstance(guard_result, GR):
            status = "PASS" if guard_result.passed else "FAIL"
            click.echo(f"  [{status}] {ap_id}")
            if guard_result.feedback and not guard_result.passed:
                fb = guard_result.feedback
                if len(fb) > 200:
                    fb = fb[:200] + "..."
                click.echo(f"         {fb}")

    # Execute
    click.echo("\nExecuting workflow...")
    click.echo("-" * 40)

    from atomicguard.application.runner import WorkflowRunner

    claimed = queue.claim()
    if claimed is None:
        click.echo("ERROR: No job in queue", err=True)
        sys.exit(1)

    runner = WorkflowRunner()
    result = runner.run(
        definition=definition,
        specification=specification,
        ap_context=ap_context,
        generator_registry=generator_registry,
        guard_registry=guard_registry,
        artifact_dag=artifact_dag,
        step_callback=_step_callback,
    )

    # Report final status
    click.echo("-" * 40)
    click.echo(f"\nResult: {result.status.value}")
    if result.failed_step:
        click.echo(f"Failed step: {result.failed_step}")
    if result.escalation_feedback:
        click.echo(f"Escalation: {result.escalation_feedback}")

    queue.report_status(
        JobStatus(
            job_id=job.job_id,
            state=JobState.COMPLETED
            if result.status.value == "success"
            else JobState.FAILED,
            error=result.failed_step,
        )
    )

    if result.status.value != "success":
        sys.exit(1)
