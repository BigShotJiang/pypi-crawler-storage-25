"""Export training traces from artifact DAGs to JSONL for fine-tuning.

Walks RL training output directories, extracts accepted artifacts with their
provenance chains, formats them into OpenAI-compatible message sequences,
and writes deduplicated JSONL output.

Usage::

    uv run python -m atomicguard.tools export-training \\
        --runs-dir output/rl_training \\
        --output training_data.jsonl \\
        --ap-context path/to/ap_context.json \\
        --filter combined

"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from atomicguard.domain.extraction import (
    HighValuePredicate,
    RefinementPredicate,
    StatusPredicate,
    extract,
)
from atomicguard.domain.models import Artifact, ArtifactStatus

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass(frozen=True)
class TrainingExample:
    """A single fine-tuning example in OpenAI message format."""

    messages: tuple[dict[str, str], ...]  # (system, user, assistant)
    instance_id: str
    action_pair_id: str
    content_hash: str  # sha256(instance_id:ap_id:content)[:16]
    provenance_length: int  # length of retry chain (for dedup preference)


# ---------------------------------------------------------------------------
# Message construction
# ---------------------------------------------------------------------------


def build_system_message(role: str, constraints: str) -> str:
    """Build system message from prompt template fields.

    Args:
        role: The role section of the prompt template.
        constraints: The constraints section of the prompt template.

    Returns:
        Combined system message string.
    """
    parts = [p for p in [role.strip(), constraints.strip()] if p]
    return "\n\n".join(parts)


def build_user_message(
    specification: str,
    dependency_contents: dict[str, str],
    feedback_history: tuple[tuple[str, str], ...],
    task_template: str,
) -> str:
    """Build user message with specification, dependencies, and feedback.

    For first-attempt artifacts, feedback_history is empty. For refinement
    traces, feedback is included to teach the model to learn from guard output.

    Args:
        specification: The problem statement / specification.
        dependency_contents: Map of action_pair_id -> artifact content.
        feedback_history: Tuple of (artifact_content, feedback) pairs.
        task_template: The task section from the prompt template.

    Returns:
        Rendered user message string.
    """
    # Substitute {specification} in task template
    rendered = task_template.replace("{specification}", specification)

    # Substitute dependency contents (keyed by ap_id).
    # This handles both legacy {ap_*} placeholders in historical templates
    # and any remaining inline references in exported training data.
    for dep_id, content in dependency_contents.items():
        rendered = rendered.replace(f"{{{dep_id}}}", content)

    parts = [rendered.strip()]

    # Add feedback history for refinement traces
    if feedback_history:
        feedback_parts = []
        for i, (_artifact_content, feedback) in enumerate(feedback_history):
            feedback_parts.append(f"--- Attempt {i + 1} ---\n{feedback}")
        parts.append("# RETRY HISTORY\n" + "\n\n".join(feedback_parts))

    return "\n\n".join(parts)


def format_training_example(
    system_msg: str,
    user_msg: str,
    assistant_content: str,
    instance_id: str,
    action_pair_id: str,
    provenance_length: int,
) -> TrainingExample:
    """Assemble a TrainingExample with content-based dedup hash.

    Args:
        system_msg: System message content.
        user_msg: User message content.
        assistant_content: Assistant (model output) content.
        instance_id: SWE-bench instance identifier.
        action_pair_id: Action pair that produced this artifact.
        provenance_length: Length of the retry chain.

    Returns:
        A TrainingExample ready for JSONL export.
    """
    hash_input = f"{instance_id}:{action_pair_id}:{assistant_content}"
    content_hash = hashlib.sha256(hash_input.encode()).hexdigest()[:16]

    messages = (
        {"role": "system", "content": system_msg},
        {"role": "user", "content": user_msg},
        {"role": "assistant", "content": assistant_content},
    )

    return TrainingExample(
        messages=messages,
        instance_id=instance_id,
        action_pair_id=action_pair_id,
        content_hash=content_hash,
        provenance_length=provenance_length,
    )


# ---------------------------------------------------------------------------
# Multi-run discovery
# ---------------------------------------------------------------------------


def discover_artifact_dags(
    runs_dir: Path,
    run_filter: list[str] | None = None,
) -> list[tuple[str, str, Path]]:
    """Walk training output to find artifact DAG directories.

    Expected structure: ``{runs_dir}/{run_name}/artifact_dags/{instance_id}/``

    Args:
        runs_dir: Root directory containing training runs.
        run_filter: If provided, only include runs whose names match.

    Returns:
        List of (run_name, instance_id, dag_path) tuples.
    """
    results: list[tuple[str, str, Path]] = []

    if not runs_dir.is_dir():
        logger.warning("Runs directory does not exist: %s", runs_dir)
        return results

    for run_dir in sorted(runs_dir.iterdir()):
        if not run_dir.is_dir():
            continue
        run_name = run_dir.name
        if run_filter and run_name not in run_filter:
            continue

        dag_root = run_dir / "artifact_dags"
        if not dag_root.is_dir():
            continue

        for instance_dir in sorted(dag_root.iterdir()):
            if not instance_dir.is_dir():
                continue
            # Check for index.json to confirm it's a valid DAG
            if (instance_dir / "index.json").exists():
                results.append((run_name, instance_dir.name, instance_dir))

    return results


# ---------------------------------------------------------------------------
# Trace extraction
# ---------------------------------------------------------------------------


def _resolve_prompt_key(action_pair_id: str, prompts: dict[str, Any]) -> str | None:
    """Try to match an action_pair_id to a prompt template key.

    Strategy:
    1. Exact match
    2. Strip common suffixes (_django, _pt_django) and retry

    Args:
        action_pair_id: The AP ID to look up.
        prompts: Dict of prompt template key -> PromptTemplate.

    Returns:
        Matching key or None.
    """
    if action_pair_id in prompts:
        return action_pair_id

    # Try stripping common suffixes
    for suffix in ("_pt_django", "_django"):
        stripped = action_pair_id.removesuffix(suffix)
        if stripped != action_pair_id and stripped in prompts:
            return stripped

    return None


def _resolve_dependency_contents(
    artifact: Artifact,
    dag: Any,
) -> dict[str, str]:
    """Resolve dependency artifact contents from the DAG.

    Args:
        artifact: The artifact whose dependencies to resolve.
        dag: The artifact DAG.

    Returns:
        Dict of action_pair_id -> artifact content.
    """
    contents: dict[str, str] = {}
    for ap_id, artifact_id in artifact.context.dependency_artifacts:
        try:
            dep_artifact = dag.get_artifact(artifact_id)
            contents[ap_id] = dep_artifact.content
        except KeyError:
            logger.debug("Dependency artifact %s not found, skipping", artifact_id)
    return contents


def extract_traces_from_dag(
    dag: Any,
    prompts: dict[str, Any],
    instance_id: str,
    filter_mode: str = "combined",
    min_rejections: int = 2,
) -> list[TrainingExample]:
    """Extract training examples from a single artifact DAG.

    Args:
        dag: A loaded ArtifactDAGInterface (e.g. FilesystemArtifactDAG).
        prompts: Dict of prompt key -> PromptTemplate.
        instance_id: The SWE-bench instance ID.
        filter_mode: One of 'all', 'refinement', 'high_value', 'combined'.
        min_rejections: Minimum rejections for high_value filter.

    Returns:
        List of TrainingExample objects.
    """
    # Check if this DAG has any guard data (non-PENDING artifacts)
    all_artifacts = dag.get_all()
    has_guard_data = any(a.status != ArtifactStatus.PENDING for a in all_artifacts)
    if not has_guard_data:
        logger.debug(
            "Skipping DAG for %s: all artifacts are PENDING (no guard data)",
            instance_id,
        )
        return []

    # Get accepted artifacts
    accepted = extract(dag, StatusPredicate(ArtifactStatus.ACCEPTED))
    if not accepted:
        return []

    # Apply filter predicates
    if filter_mode == "refinement":
        refinement_pred = RefinementPredicate(dag)
        accepted = [a for a in accepted if refinement_pred.matches(a)]
    elif filter_mode == "high_value":
        high_value_pred = HighValuePredicate(dag, min_rejections=min_rejections)
        accepted = [a for a in accepted if high_value_pred.matches(a)]
    elif filter_mode == "combined":
        # Keep all accepted, mark refinements for later oversampling
        pass
    # 'all' keeps everything

    examples: list[TrainingExample] = []
    for artifact in accepted:
        # Resolve prompt template
        prompt_key = _resolve_prompt_key(artifact.action_pair_id, prompts)
        if prompt_key is None:
            logger.debug(
                "No prompt template for AP '%s' (instance %s), skipping",
                artifact.action_pair_id,
                instance_id,
            )
            continue

        template = prompts[prompt_key]

        # Get provenance chain
        provenance = dag.get_provenance(artifact.artifact_id)
        provenance_length = len(provenance)

        # Build feedback history from rejected artifacts in provenance
        feedback_history: list[tuple[str, str]] = []
        for prev in provenance:
            if prev.artifact_id == artifact.artifact_id:
                continue
            if prev.status == ArtifactStatus.REJECTED and prev.guard_result:
                feedback_history.append((prev.content, prev.guard_result.feedback))

        # Resolve dependency contents
        dep_contents = _resolve_dependency_contents(artifact, dag)

        # Build messages
        system_msg = build_system_message(template.role, template.constraints)
        user_msg = build_user_message(
            specification=artifact.context.specification,
            dependency_contents=dep_contents,
            feedback_history=tuple(feedback_history),
            task_template=template.task,
        )

        example = format_training_example(
            system_msg=system_msg,
            user_msg=user_msg,
            assistant_content=artifact.content,
            instance_id=instance_id,
            action_pair_id=artifact.action_pair_id,
            provenance_length=provenance_length,
        )
        examples.append(example)

    return examples


# ---------------------------------------------------------------------------
# Post-processing
# ---------------------------------------------------------------------------


def deduplicate(examples: list[TrainingExample]) -> list[TrainingExample]:
    """Remove duplicate examples, preferring those with longest provenance.

    Keyed on content_hash. When duplicates exist, the example with the
    longest provenance_length is kept (more feedback context).

    Args:
        examples: List of training examples (may contain duplicates).

    Returns:
        Deduplicated list.
    """
    best: dict[str, TrainingExample] = {}
    for ex in examples:
        existing = best.get(ex.content_hash)
        if existing is None or ex.provenance_length > existing.provenance_length:
            best[ex.content_hash] = ex
    return list(best.values())


def oversample_refinements(
    examples: list[TrainingExample],
    factor: int = 3,
) -> list[TrainingExample]:
    """Repeat refinement traces (provenance_length > 1) by a factor.

    This upweights examples where the model learned from guard feedback,
    making the fine-tuned model better at incorporating feedback.

    Args:
        examples: List of training examples.
        factor: How many times to repeat refinement traces.

    Returns:
        New list with refinement traces repeated.
    """
    result: list[TrainingExample] = []
    for ex in examples:
        if ex.provenance_length > 1:
            result.extend([ex] * factor)
        else:
            result.append(ex)
    return result


# ---------------------------------------------------------------------------
# JSONL output
# ---------------------------------------------------------------------------


def write_jsonl(examples: list[TrainingExample], output_path: Path) -> int:
    """Write training examples as JSONL (one JSON object per line).

    Each line contains ``{"messages": [{"role": ..., "content": ...}, ...]}``.

    Args:
        examples: List of training examples.
        output_path: Path to write JSONL to.

    Returns:
        Number of examples written.
    """
    with open(output_path, "w") as f:
        for ex in examples:
            line = json.dumps({"messages": list(ex.messages)}, ensure_ascii=False)
            f.write(line + "\n")
    return len(examples)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> None:
    """CLI entry point for training trace export."""
    parser = argparse.ArgumentParser(
        description="Export training traces from artifact DAGs to JSONL.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument(
        "--runs-dir",
        type=Path,
        required=True,
        help="Root directory containing RL training runs",
    )
    parser.add_argument(
        "--output",
        type=Path,
        required=True,
        help="Output JSONL file path",
    )
    parser.add_argument(
        "--ap-context",
        type=Path,
        required=True,
        help="Path to ap_context.json file",
    )
    parser.add_argument(
        "--filter",
        choices=["all", "refinement", "high_value", "combined"],
        default="combined",
        dest="filter_mode",
        help="Filter mode: all, refinement, high_value, or combined (default: combined)",
    )
    parser.add_argument(
        "--oversample-refinement",
        type=int,
        default=3,
        help="Oversampling factor for refinement traces (default: 3)",
    )
    parser.add_argument(
        "--min-rejections",
        type=int,
        default=2,
        help="Minimum rejections for high_value filter (default: 2)",
    )
    parser.add_argument(
        "--runs",
        type=str,
        default=None,
        help="Comma-separated list of run names to include (default: all)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Print statistics without writing output",
    )

    args = parser.parse_args()
    logging.basicConfig(
        level=logging.INFO,
        format="%(levelname)s: %(message)s",
    )

    # Load AP context
    from atomicguard.domain.prompts import PromptTemplate

    if not args.ap_context.exists():
        logger.error("AP context file not found: %s", args.ap_context)
        sys.exit(1)
    raw_context: dict[str, Any] = json.loads(args.ap_context.read_text())
    ap_context: dict[str, PromptTemplate] = {
        ap_id: PromptTemplate(
            role=entry.get("role", ""),
            constraints=entry.get("constraints", ""),
            task=entry.get("task", ""),
            feedback_wrapper=entry.get("feedback_wrapper"),
            escalation_feedback_wrapper=entry.get("escalation_feedback_wrapper"),
        )
        for ap_id, entry in raw_context.get("action_pairs", raw_context).items()
        if isinstance(entry, dict)
    }
    logger.info("Loaded %d prompt templates from %s", len(ap_context), args.ap_context)

    # Parse run filter
    run_filter = None
    if args.runs:
        run_filter = [r.strip() for r in args.runs.split(",")]

    # Discover DAGs
    dag_entries = discover_artifact_dags(args.runs_dir, run_filter)
    logger.info("Found %d artifact DAGs across runs", len(dag_entries))

    if not dag_entries:
        logger.warning("No artifact DAGs found. Check --runs-dir path.")
        sys.exit(0)

    # Extract traces
    from atomicguard.infrastructure.persistence.filesystem import FilesystemArtifactDAG

    all_examples: list[TrainingExample] = []

    for run_name, instance_id, dag_path in dag_entries:
        try:
            dag = FilesystemArtifactDAG(str(dag_path))
            examples = extract_traces_from_dag(
                dag=dag,
                prompts=ap_context,
                instance_id=instance_id,
                filter_mode=args.filter_mode,
                min_rejections=args.min_rejections,
            )
            all_examples.extend(examples)
        except Exception:
            logger.exception("Error processing %s/%s", run_name, instance_id)

    logger.info("Extracted %d raw training examples", len(all_examples))

    # Deduplicate
    deduped = deduplicate(all_examples)
    logger.info("After deduplication: %d examples", len(deduped))

    # Oversample refinements (for 'combined' mode)
    if args.filter_mode == "combined" and args.oversample_refinement > 1:
        final = oversample_refinements(deduped, factor=args.oversample_refinement)
        refinement_count = sum(1 for ex in deduped if ex.provenance_length > 1)
        logger.info(
            "After oversampling (%dx for %d refinement traces): %d examples",
            args.oversample_refinement,
            refinement_count,
            len(final),
        )
    else:
        final = deduped

    # Stats
    ap_counts: dict[str, int] = {}
    for ex in final:
        ap_counts[ex.action_pair_id] = ap_counts.get(ex.action_pair_id, 0) + 1

    logger.info("Examples by action pair:")
    for ap_id, count in sorted(ap_counts.items()):
        logger.info("  %s: %d", ap_id, count)

    provenance_dist: dict[int, int] = {}
    for ex in deduped:
        provenance_dist[ex.provenance_length] = (
            provenance_dist.get(ex.provenance_length, 0) + 1
        )
    logger.info("Provenance length distribution (before oversampling):")
    for length, count in sorted(provenance_dist.items()):
        logger.info("  length %d: %d examples", length, count)

    if args.dry_run:
        logger.info("Dry run — no output written.")
        return

    # Write JSONL
    args.output.parent.mkdir(parents=True, exist_ok=True)
    written = write_jsonl(final, args.output)
    logger.info("Wrote %d examples to %s", written, args.output)
