"""Entry point for ``python -m atomicguard.tools``.

Supports subcommands:
- ``export-workflow`` (default): Export Q-table to workflow JSON.
- ``export-training``: Export training traces to JSONL.

For backward compatibility, running without a subcommand defaults to
``export-workflow``.
"""

import sys

_SUBCOMMANDS = {"export-workflow", "export-training"}


def _main() -> None:
    if len(sys.argv) >= 2 and sys.argv[1] in _SUBCOMMANDS:
        subcmd = sys.argv.pop(1)
    else:
        subcmd = "export-workflow"

    if subcmd == "export-training":
        from atomicguard.tools.export_training import main

        main()
    else:
        from atomicguard.tools.export_workflow import main

        main()


_main()
