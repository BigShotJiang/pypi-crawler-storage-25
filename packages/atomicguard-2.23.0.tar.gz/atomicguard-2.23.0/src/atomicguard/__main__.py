"""Entry point for ``python -m atomicguard``.

Subcommands:
- ``run``: Execute a workflow from JSON definition.
- ``apply``: Apply a trained RL policy to real source files.
- ``policy``: Manage the named policy registry.
"""

from __future__ import annotations

import logging
import os
import sys
from pathlib import Path

import click


def _configure_logging(debug: bool) -> None:
    level = logging.DEBUG if debug else logging.INFO
    root = logging.getLogger()
    root.setLevel(level)
    fmt = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    sh = logging.StreamHandler()
    sh.setLevel(level)
    sh.setFormatter(fmt)
    root.addHandler(sh)
    for name in ("httpx", "httpcore", "openai", "urllib3"):
        logging.getLogger(name).setLevel(logging.WARNING)


@click.group()
def cli() -> None:
    """AtomicGuard — guard-railed workflow execution for LLM code generation."""


def _resolve_policy(name_or_path: str) -> Path:
    """Resolve a policy name or path to a checkpoint directory Path."""
    p = Path(name_or_path)
    if p.exists():
        return p
    from atomicguard.infrastructure.policy_registry import get

    try:
        entry = get(name_or_path)
        return Path(entry.checkpoint)
    except KeyError as exc:
        raise click.BadParameter(
            f"{name_or_path!r} is neither an existing path nor a registered policy name.\n"
            "Run `atomicguard policy list` to see registered policies."
        ) from exc


@cli.command("apply")
@click.option(
    "--policy",
    required=True,
    type=str,
    help="Path to trained checkpoint directory, or a registered policy name.",
)
@click.option(
    "--path",
    "target",
    required=True,
    type=click.Path(exists=True, path_type=Path),
    help="File or directory to fix.",
)
@click.option(
    "--gym",
    "gym_name",
    default="precommit_python",
    show_default=True,
    help="Gym whose AP vocabulary the policy was trained on.",
)
@click.option(
    "--model", default=None, help="LLM model ID (default: from training_config.json)."
)
@click.option(
    "--provider",
    default=None,
    help="LLM provider (default: from training_config.json).",
)
@click.option(
    "--base-url",
    default="http://localhost:11434/v1",
    show_default=True,
    help="LLM API base URL.",
)
@click.option(
    "--api-key",
    default=None,
    help="LLM API key (default: LLM_API_KEY env var).",
)
@click.option(
    "--dry-run",
    is_flag=True,
    help="Show what would be fixed without writing changes.",
)
@click.option("--debug", is_flag=True, help="Enable verbose logging.")
def apply(
    policy: str,
    target: Path,
    gym_name: str,
    model: str | None,
    provider: str | None,
    base_url: str,
    api_key: str | None,
    dry_run: bool,
    debug: bool,
) -> None:
    """Apply a trained RL policy to source files."""
    from atomicguard.run_policy import FileStatus, run_policy_on_path

    _configure_logging(debug)

    policy_path = _resolve_policy(policy)
    resolved_api_key = api_key or os.environ.get("LLM_API_KEY", "")

    if dry_run:
        click.echo(click.style("Dry-run mode — no files will be written.", fg="yellow"))

    click.echo(f"Policy:  {policy_path}")
    click.echo(f"Target:  {target}")
    click.echo(f"Gym:     {gym_name}")

    results = run_policy_on_path(
        policy_path=policy_path,
        target_path=target,
        gym_name=gym_name,
        model=model,
        provider=provider,
        base_url=base_url,
        api_key=resolved_api_key,
        dry_run=dry_run,
    )

    # ------------------------------------------------------------------ #
    # Results table                                                         #
    # ------------------------------------------------------------------ #
    click.echo("")
    fixed = failed = 0
    for r in results:
        if r.status == FileStatus.FIXED:
            label = click.style("FIXED ", fg="green")
            fixed += 1
        else:
            label = click.style("FAILED", fg="red")
            failed += 1

        extra = ""
        if r.steps:
            extra += f"  steps={r.steps}"
        if r.message:
            extra += f"  ({r.message})"
        if dry_run and r.status == FileStatus.FIXED:
            extra += "  [dry-run, not written]"

        rel = r.file
        if target.is_dir() and r.file.is_relative_to(target):
            rel = r.file.relative_to(target)
        click.echo(f"  {label}  {rel}{extra}")

    click.echo("")
    click.echo(
        f"Summary: {len(results)} files — "
        f"{click.style(str(fixed) + ' fixed', fg='green')}, "
        f"{click.style(str(failed) + ' failed', fg='red' if failed else 'bright_black')}"
    )

    if failed:
        sys.exit(1)


@cli.group()
def policy() -> None:
    """Manage the named policy registry."""


@policy.command("register")
@click.argument("path", type=click.Path(path_type=Path))
@click.option(
    "--name", default=None, help="Friendly name (default: run directory basename)."
)
@click.option(
    "--force", is_flag=True, help="Overwrite an existing entry with the same name."
)
def policy_register(path: Path, name: str | None, force: bool) -> None:
    """Register a trained policy checkpoint under a friendly name."""
    from atomicguard.infrastructure.policy_registry import register

    try:
        entry = register(path, name=name, force=force)
    except ValueError as exc:
        click.echo(click.style(f"Error: {exc}", fg="red"), err=True)
        raise SystemExit(1) from exc

    click.echo(f"Registered {click.style(entry.name, fg='green')} → {entry.checkpoint}")


@policy.command("list")
def policy_list() -> None:
    """List all registered policies."""
    from atomicguard.infrastructure.policy_registry import list_all

    entries = list_all()
    if not entries:
        click.echo(
            "No policies registered. Use `atomicguard policy register <PATH>` to add one."
        )
        return

    # Fixed-width columns: NAME(25) | GYM(22) | MODEL(30) | EPISODES(8) | PATH
    header = f"{'NAME':<25}  {'GYM':<22}  {'MODEL':<30}  {'EP':>6}  PATH"
    click.echo(click.style(header, bold=True))
    click.echo("-" * len(header))
    for e in entries:
        click.echo(
            f"{e.name:<25}  {e.gym:<22}  {e.model:<30}  {e.total_episodes:>6}  {e.checkpoint}"
        )


@policy.command("show")
@click.argument("name")
def policy_show(name: str) -> None:
    """Show all fields for a single registered policy."""
    from atomicguard.infrastructure.policy_registry import get

    try:
        e = get(name)
    except KeyError as exc:
        click.echo(
            click.style(f"Error: policy {name!r} not found.", fg="red"), err=True
        )
        raise SystemExit(1) from exc

    click.echo(f"name:             {e.name}")
    click.echo(f"path:             {e.path}")
    click.echo(f"checkpoint:       {e.checkpoint}")
    click.echo(f"gym:              {e.gym}")
    click.echo(f"model:            {e.model}")
    click.echo(f"provider:         {e.provider}")
    click.echo(f"total_episodes:   {e.total_episodes}")
    click.echo(f"registered_at:    {e.registered_at}")
    click.echo(f"ap_ids ({len(e.ap_ids)}):")
    for ap_id in e.ap_ids:
        click.echo(f"  - {ap_id}")


@policy.command("remove")
@click.argument("name")
def policy_remove(name: str) -> None:
    """Remove a registered policy by name."""
    from atomicguard.infrastructure.policy_registry import remove

    try:
        remove(name)
    except KeyError as exc:
        click.echo(
            click.style(f"Error: policy {name!r} not found.", fg="red"), err=True
        )
        raise SystemExit(1) from exc

    click.echo(f"Removed policy {click.style(name, fg='yellow')}.")


def _register_commands() -> None:
    """Register subcommands from the cli package."""
    from atomicguard.cli.run import run_command
    from atomicguard.cli.runner import runner_group

    cli.add_command(run_command, "run")
    cli.add_command(runner_group, "runner")


_register_commands()


if __name__ == "__main__":
    cli()
