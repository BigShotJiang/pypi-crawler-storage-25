"""
Gym domain port and value objects.

A Gym bundles everything needed to train and evaluate an RL policy
for a specific domain: AP vocabulary, task instances, workflow config,
and environment construction.

The ``GymInterface`` is a domain port — concrete gyms implement it
in infrastructure (e.g. ``BenchmarkGym``).  The training layer
(``Trainer``) does not depend on gyms — it drives ``EnvironmentInterface``,
which gyms produce via ``build_environment()``.

Pure data and ABCs — no framework dependencies.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from pathlib import Path

    from atomicguard.domain.interfaces import (
        ActionPairPoolInterface,
        ArtifactDAGInterface,
        EnvironmentInterface,
        WorkflowExecutorInterface,
    )
    from atomicguard.domain.models import WorkflowDefinition
    from atomicguard.domain.rl.reward import RewardFunctionInterface


@dataclass(frozen=True)
class GymInstance:
    """A single task in a gym.

    Generalises BenchmarkInstance.  Each gym domain adds its own
    fields via the ``context`` dict (e.g. reference_tests, git_diff).
    """

    instance_id: str
    specification: str
    tier: int = 1
    context: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class GymManifest:
    """Describes a gym's capabilities — metadata for the CLI, dashboard,
    and policy library provenance."""

    name: str  # e.g. "benchmark_tdd_v3"
    description: str
    ap_ids: tuple[str, ...]  # AP vocabulary
    goal_aps: tuple[str, ...]
    instance_count: int
    tiers: tuple[int, ...]
    requires_docker: bool = False
    requires_llm: bool = True
    languages: tuple[str, ...] = ("python",)


@dataclass(frozen=True)
class GymInstanceContext:
    """Context produced by preparing a real source file for policy execution.

    Replaces the anonymous ``(ActionPairPoolInterface, Path, str)`` tuple
    from ``build_action_pair_pool_from_file()``.
    """

    instance_dir: Path
    specification: str


class GymInterface(ABC):
    """Port: a gym provides instances and builds environments.

    The gym owns the wiring concern — it knows which workflow JSON,
    AP context, guard registry, and generator registry to use.
    """

    @abstractmethod
    def get_instances(self, limit: int | None = None) -> list[GymInstance]:
        """Return available task instances."""

    @abstractmethod
    def build_environment(
        self,
        instance: GymInstance,
        reward_fn: RewardFunctionInterface,
        artifact_dag: ArtifactDAGInterface,
        *,
        max_steps: int | None = None,
        enable_backtracking: bool = False,
        max_selections_per_ap: int | None = None,
    ) -> EnvironmentInterface:
        """Build a training environment for one instance."""

    @abstractmethod
    def build_action_pair_pool_from_file(
        self, file_path: Path
    ) -> tuple[ActionPairPoolInterface, Path, str]:
        """Build a raw ActionPairPool from a real source file.

        Deprecated: use ``get_workflow_definition()`` + ``prepare_instance()``
        + ``build_orchestrator_from_definition()`` for the policy-ordered
        production lifecycle.

        Used by ``run_policy`` to obtain an ``ActionPairPoolInterface``
        for use with ``execute()`` — providing retry, backtracking, cascade
        invalidation, and escalation from the production framework.

        Args:
            file_path: Real source file to process.

        Returns:
            ``(action_pair_pool, instance_dir, specification)`` tuple.
        """

    @abstractmethod
    def get_workflow_definition(self) -> WorkflowDefinition:
        """Return the gym's workflow definition.

        Pure read of the gym's JSON config — same result every call,
        independent of any file or policy.  The caller may pass this to
        ``PolicyExporter.export()`` to reorder ``requires`` edges before
        building an executor.
        """

    @abstractmethod
    def build_orchestrator_from_definition(
        self, definition: WorkflowDefinition
    ) -> WorkflowExecutorInterface:
        """Build a workflow executor from a (possibly reordered) definition.

        The gym owns registry wiring; the caller owns the definition.
        Pass a ``PolicyExporter``-derived definition to apply the policy's
        learned ordering.

        Args:
            definition: Workflow definition, possibly with policy-derived
                ``requires`` edges from ``PolicyExporter.export()``.

        Returns:
            A :class:`WorkflowExecutorInterface` ready to call ``execute()``.
        """

    def prepare_instance(self, file_path: Path) -> GymInstanceContext:
        """Prepare a real source file for policy execution.

        Creates a temp directory, copies the file, and returns a
        :class:`GymInstanceContext` with the instance directory and
        specification string.

        Only file-processing gyms (e.g. ``PreCommitGym``) override this.
        Dataset-backed gyms (e.g. ``BenchmarkGym``) leave the default,
        which raises ``NotImplementedError``.

        Args:
            file_path: Real source file to process.

        Returns:
            :class:`GymInstanceContext` with ``instance_dir`` and
            ``specification``.
        """
        raise NotImplementedError(
            f"{type(self).__name__} does not support prepare_instance(). "
            "Only file-processing gyms implement this method."
        )

    @abstractmethod
    def get_ap_ids(self) -> tuple[str, ...]:
        """Return the AP vocabulary for this gym."""

    @abstractmethod
    def get_manifest(self) -> GymManifest:
        """Return gym metadata."""

    @abstractmethod
    def get_fixed_content(self, instance_dir: Path) -> str:
        """Return the fixed file content from the instance directory.

        Used by ``run_policy`` to read the corrected file after the policy has
        run, before writing it back to the source tree.
        """

    def get_file_glob_patterns(self) -> tuple[str, ...]:
        """Return glob patterns for files this gym can process.

        Derived from ``GymManifest.languages``.  Override for custom patterns.
        """
        _LANG_GLOBS: dict[str, str] = {
            "python": "*.py",
            "go": "*.go",
            "javascript": "*.js",
            "typescript": "*.ts",
            "rust": "*.rs",
            "java": "*.java",
        }
        manifest = self.get_manifest()
        return tuple(_LANG_GLOBS.get(lang, f"*.{lang}") for lang in manifest.languages)

    @abstractmethod
    def cleanup(self) -> None:
        """Release resources (containers, temp dirs). No-op by default."""
