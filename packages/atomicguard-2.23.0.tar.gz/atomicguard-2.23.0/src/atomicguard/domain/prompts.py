"""
Prompt and task definitions for the Dual-State Framework.

This module provides:
- PromptTemplate: Structured prompt rendering
- StepDefinition: Single workflow step specification
- TaskDefinition: Complete task with multiple steps

These are domain structures (schemas) only. Actual task content should be
defined by the calling application (e.g., benchmarks), not hardcoded here.
"""

import logging
from dataclasses import dataclass
from typing import TYPE_CHECKING

logger = logging.getLogger(__name__)

if TYPE_CHECKING:
    from atomicguard.domain.models import Context


# =============================================================================
# PROMPT TEMPLATE (moved from models.py)
# =============================================================================


@dataclass(frozen=True)
class PromptTemplate:
    """Structured prompt template for generator.

    Prompt templates are the single source of truth for what context
    each generator needs. Dependency artifacts are rendered via the
    producer-driven artifact_context (δ) mechanism in the DEPENDENCIES
    section — see Definition 2a in domain_notation.md.

    Supported placeholders:
    - {specification}: Context specification (problem statement)
    - {constraints}: Ambient constraints
    - {feedback}: Latest rejection feedback
    """

    role: str
    constraints: str
    task: str
    feedback_wrapper: str | None = (
        None  # Template for wrapping retry feedback (optional)
    )
    escalation_feedback_wrapper: str | None = None  # Template for escalation feedback
    feedback_mode: str = "inline"  # "inline" or "chat"

    def render(self, context: "Context") -> str:
        """Render prompt with context including dependency artifacts.

        Args:
            context: Execution context with specification and dependencies

        Returns:
            Rendered prompt string ready for the LLM
        """
        parts = self._render_parts(context, include_feedback=True)
        return "\n\n".join(parts)

    def render_without_feedback(self, context: "Context") -> str:
        """Render prompt excluding RETRY HISTORY and ESCALATION HISTORY sections.

        Used by chat-mode generators that send feedback as multi-turn
        message history instead of inline prompt sections.

        Args:
            context: Execution context with specification and dependencies

        Returns:
            Rendered prompt string without feedback sections
        """
        parts = self._render_parts(context, include_feedback=False)
        return "\n\n".join(parts)

    def _render_parts(self, context: "Context", *, include_feedback: bool) -> list[str]:
        """Build prompt sections, optionally including feedback history.

        Args:
            context: Execution context with specification and dependencies
            include_feedback: If True, include RETRY HISTORY and ESCALATION HISTORY

        Returns:
            List of prompt sections to be joined
        """
        # Substitute standard placeholders in template sections
        role = self._substitute_standard(self.role, context)
        constraints = self._substitute_standard(self.constraints, context)
        task = self._substitute_standard(self.task, context)

        parts = [
            f"# ROLE\n{role}",
            f"# CONSTRAINTS\n{constraints}",
        ]

        # Add ambient constraints (already processed context)
        if context.ambient.constraints:
            parts.append(f"# CONTEXT\n{context.ambient.constraints}")

        # Add dependency artifacts as structured sections (Definition 2a).
        # Only deps with an artifact_context (δ) are rendered.
        if context.dependency_artifacts and context.ambient.repository:
            artifact_context_map = dict(context.dependency_artifact_contexts)
            type_map = dict(context.dependency_types)
            dep_parts = []
            for key, artifact_id in context.dependency_artifacts:
                try:
                    artifact = context.ambient.repository.get_artifact(artifact_id)
                    artifact_context = artifact_context_map.get(key)
                    if artifact_context:
                        artifact_type = type_map.get(key, key)
                        dep_parts.append(
                            f"## Context: {artifact_type}\n"
                            f"{artifact_context}\n\n"
                            f"{artifact.content}"
                        )
                except KeyError:
                    logger.debug(
                        "Dependency artifact %s not found, skipping", artifact_id
                    )
            if dep_parts:
                parts.append("# DEPENDENCIES\n" + "\n\n".join(dep_parts))

        if include_feedback:
            # Add escalation feedback if present AND wrapper is defined
            if context.escalation_feedback and self.escalation_feedback_wrapper:
                parts.append("# ESCALATION HISTORY (Prior Cycles)")
                for i, feedback in enumerate(context.escalation_feedback):
                    wrapped = self.escalation_feedback_wrapper.format(feedback=feedback)
                    parts.append(f"--- Escalation Cycle {i + 1} ---\n{wrapped}")

            # Add feedback history (renamed section)
            if context.feedback_history:
                if self.feedback_wrapper is None:
                    raise ValueError(
                        "feedback_wrapper must be defined when feedback_history is present. "
                        "Add feedback_wrapper to your PromptTemplate."
                    )
                parts.append("# RETRY HISTORY (Current Cycle)")
                for i, (_artifact_content, feedback) in enumerate(
                    context.feedback_history
                ):
                    wrapped = self.feedback_wrapper.format(feedback=feedback)
                    parts.append(f"--- Attempt {i + 1} ---\n{wrapped}")

        parts.append(f"# TASK\n{task}")
        return parts

    @staticmethod
    def _substitute_standard(text: str, context: "Context") -> str:
        """Substitute standard placeholders in text.

        Supported: {specification}, {constraints}, {feedback}.

        Args:
            text: Template text with placeholders
            context: Execution context

        Returns:
            Text with placeholders substituted
        """
        result = text.replace("{specification}", context.specification)
        result = result.replace("{constraints}", context.ambient.constraints or "")

        if context.feedback_history:
            latest_feedback = context.feedback_history[-1][1]
            result = result.replace("{feedback}", latest_feedback)
        else:
            result = result.replace("{feedback}", "")

        return result


# =============================================================================
# TASK DEFINITIONS (DS-PDDL semantic layer)
# =============================================================================


@dataclass(frozen=True)
class StepDefinition:
    """Single workflow step specification."""

    step_id: str  # e.g., "g_test", "g_impl"
    prompt: str  # Prompt template with {placeholders}
    guard: str  # Guard type: "syntax", "dynamic_test", "human", etc.
    requires: tuple[str, ...] = ()  # Step IDs this depends on


@dataclass(frozen=True)
class TaskDefinition:
    """Complete task definition with multiple workflow steps."""

    task_id: str  # e.g., "tdd_stack"
    name: str  # Human-readable name
    specification: str  # High-level task description (Ψ)
    steps: tuple[StepDefinition, ...]  # Ordered workflow steps

    def get_step(self, step_id: str) -> StepDefinition | None:
        """Get a step by ID."""
        for step in self.steps:
            if step.step_id == step_id:
                return step
        return None
