"""
Domain exceptions for the Dual-State Framework.

These represent business rule violations in the domain layer.
"""

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from atomicguard.domain.models import Artifact


class RmaxExhausted(Exception):
    """
    Raised when maximum retry attempts are exhausted.

    This is a domain exception representing the business rule that
    generation must succeed within r_max attempts.
    """

    def __init__(self, message: str, provenance: list[tuple["Artifact", str]]):
        """
        Args:
            message: Human-readable error message
            provenance: List of (artifact, feedback) tuples for each failed attempt
        """
        super().__init__(message)
        self.provenance = provenance


class EscalationRequired(Exception):
    """
    Raised when guard returns ⊥_fatal (Level 4 recovery: human intervention).

    This indicates a non-recoverable failure that should not be retried.
    The workflow should surface to caller for human review.
    """

    def __init__(
        self,
        artifact: "Artifact",
        feedback: str,
    ):
        """
        Args:
            artifact: The artifact that triggered escalation
            feedback: Human-readable feedback explaining the fatal condition
        """
        super().__init__(feedback)
        self.artifact = artifact
        self.feedback = feedback


class StagnationDetected(Exception):
    """Raised when r_patience consecutive similar failures detected (Definition 44).

    Triggers workflow-level escalation to upstream action pairs (Level 2 recovery).
    Distinct from EscalationRequired which triggers human intervention (Level 4).
    """

    def __init__(
        self,
        artifact: "Artifact",
        feedback: str,
        escalate_to: list[str],
        failure_summary: str,
        stagnant_guard: str | None = None,
    ):
        """
        Args:
            artifact: The artifact that triggered stagnation detection
            feedback: Latest guard feedback
            escalate_to: ALL target action_pair_ids to re-invoke (Definition 45)
            failure_summary: Summarized failure context for injection (Definition 48)
            stagnant_guard: Name of the sub-guard that caused stagnation (for composite guards)
        """
        super().__init__(feedback)
        self.artifact = artifact
        self.feedback = feedback
        self.escalate_to = escalate_to  # List of all targets to invalidate
        self.failure_summary = failure_summary
        self.stagnant_guard = stagnant_guard


class ReviewTimeout(Exception):
    """Raised when a human review is not decided within ``max_wait`` seconds.

    Prevents the runner from blocking indefinitely when a review is
    abandoned.  The caller can catch this and treat the artifact as
    rejected (fail the guard) or escalate.
    """

    def __init__(self, review_id: str, max_wait: float) -> None:
        super().__init__(f"Review {review_id} was not decided within {max_wait}s")
        self.review_id = review_id
        self.max_wait = max_wait
