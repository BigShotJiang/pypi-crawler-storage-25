"""
Runner domain types for the workflow execution protocol.

Defines the data structures that flow between job submitters (CLI, web)
and job executors (in-process, self-hosted runner, cloud runner).
"""

from dataclasses import dataclass, field
from datetime import UTC, datetime
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from atomicguard.domain.models import APContextEntry, WorkflowDefinition


class JobState(Enum):
    """Lifecycle states of a RunJob."""

    QUEUED = "queued"
    CLAIMED = "claimed"
    RUNNING = "running"
    PAUSED = "paused"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


@dataclass(frozen=True)
class StepResult:
    """Outcome of a single action pair execution attempt."""

    ap_id: str
    attempt: int
    passed: bool
    feedback: str = ""
    artifact_id: str | None = None
    started_at: datetime | None = None
    finished_at: datetime | None = None


@dataclass(frozen=True)
class RunJob:
    """Submitted to the queue by CLI or web.

    The API key is NOT in the job — it lives in the runner's environment.
    """

    job_id: str
    workflow_definition: "WorkflowDefinition"
    ap_context: dict[str, "APContextEntry"]
    specification: str
    model: str
    provider: str
    submitted_at: datetime = field(default_factory=lambda: datetime.now(UTC))
    metadata: dict[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class ReviewDecision:
    """Human reviewer's decision on a pending review.

    Returned by ``HumanReviewerInterface.poll_decision()`` when
    a decision is available.
    """

    approved: bool
    feedback: str = ""


@dataclass(frozen=True)
class JobStatus:
    """Reported back by the runner."""

    job_id: str
    state: JobState
    current_step: str | None = None
    step_results: tuple[StepResult, ...] = ()
    error: str | None = None
    updated_at: datetime = field(default_factory=lambda: datetime.now(UTC))
