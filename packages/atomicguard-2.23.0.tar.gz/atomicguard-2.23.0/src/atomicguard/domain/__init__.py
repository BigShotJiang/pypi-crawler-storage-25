"""
Domain layer for the Dual-State Framework.

Contains core business logic with no external dependencies.
"""

from atomicguard.domain.exceptions import (
    EscalationRequired,
    RmaxExhausted,
    StagnationDetected,
)
from atomicguard.domain.interfaces import (
    ArtifactDAGInterface,
    GeneratorInterface,
    GuardInterface,
    PolicyInterface,
)
from atomicguard.domain.models import (
    ActionPairId,
    AmbientEnvironment,
    Artifact,
    ArtifactId,
    ArtifactStatus,
    Context,
    ContextSnapshot,
    FeedbackEntry,
    GuardId,
    GuardResult,
    SubGuardOutcome,
    WorkflowId,
    WorkflowResult,
    WorkflowState,
    WorkflowStatus,
)
from atomicguard.domain.prompts import (
    PromptTemplate,
    StepDefinition,
    TaskDefinition,
)

__all__ = [
    # ID types
    "ArtifactId",
    "ActionPairId",
    "WorkflowId",
    "GuardId",
    # Models
    "Artifact",
    "ArtifactStatus",
    "ContextSnapshot",
    "FeedbackEntry",
    "Context",
    "AmbientEnvironment",
    "GuardResult",
    "SubGuardOutcome",
    "WorkflowState",
    "WorkflowResult",
    "WorkflowStatus",
    # Prompts and Tasks (structures only, no content)
    "PromptTemplate",
    "StepDefinition",
    "TaskDefinition",
    # Interfaces
    "GeneratorInterface",
    "GuardInterface",
    "ArtifactDAGInterface",
    "PolicyInterface",
    # Exceptions
    "RmaxExhausted",
    "EscalationRequired",
    "StagnationDetected",
]
