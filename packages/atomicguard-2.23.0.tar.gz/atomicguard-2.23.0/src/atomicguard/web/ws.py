"""WebSocket connection management for real-time updates."""

from __future__ import annotations

from fastapi import WebSocket


class ConnectionManager:
    """Manage WebSocket connections by channel.

    Channels are string identifiers (e.g. "run:42", "nav-metrics")
    that group related connections for targeted broadcasts.
    """

    def __init__(self) -> None:
        self.channels: dict[str, list[WebSocket]] = {}

    async def connect(self, channel: str, ws: WebSocket) -> None:
        """Accept a WebSocket and add it to a channel."""
        await ws.accept()
        self.channels.setdefault(channel, []).append(ws)

    def disconnect(self, channel: str, ws: WebSocket) -> None:
        """Remove a WebSocket from a channel."""
        conns = self.channels.get(channel, [])
        if ws in conns:
            conns.remove(ws)
        # Clean up empty channels
        if channel in self.channels and not self.channels[channel]:
            del self.channels[channel]

    async def broadcast(self, channel: str, html: str) -> None:
        """Push an HTML fragment to all connections on a channel."""
        dead: list[WebSocket] = []
        for ws in self.channels.get(channel, []):
            try:
                await ws.send_text(html)
            except Exception:
                dead.append(ws)
        for ws in dead:
            self.disconnect(channel, ws)

    @property
    def active_connections(self) -> int:
        """Total number of active WebSocket connections across all channels."""
        return sum(len(conns) for conns in self.channels.values())


# Singleton instance for the application
manager = ConnectionManager()
