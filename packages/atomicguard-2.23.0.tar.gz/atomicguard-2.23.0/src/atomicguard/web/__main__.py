"""Entry point for ``python -m atomicguard.web``."""

from .server import main

main()
