"""Discover and load RL training runs for dashboard visualisation."""

from __future__ import annotations

import contextlib
import json
import logging
from dataclasses import dataclass, field
from datetime import UTC, datetime
from pathlib import Path

import numpy as np

logger = logging.getLogger(__name__)


@dataclass
class EpisodeInfo:
    """Per-episode metrics from episode_log.jsonl."""

    episode: int
    reward: float
    steps: int
    epsilon: float
    satisfied: int | None = None
    total_aps: int | None = None
    all_satisfied: bool | None = None
    duration_secs: float | None = None
    tokens: int | None = None
    backtracks: int | None = None
    execution_ms: float | None = None
    started_at: str | None = None
    finished_at: str | None = None
    instance_id: str | None = None
    workflow_id: str | None = None


@dataclass
class CheckpointInfo:
    """Parsed checkpoint metadata."""

    name: str
    episode: int
    mean_reward: float
    epsilon: float


@dataclass
class ProgressInfo:
    """Live training progress from progress.json."""

    episode: int
    step: int
    max_steps: int
    satisfied: int
    total_aps: int
    timestamp: str


@dataclass
class PolicyInfo:
    """Extracted Q-table and policy data for visualisation."""

    ap_ids: list[str]
    num_states: int
    num_actions: int
    q_table: list[list[float]]  # JSON-serialisable 2D list
    visit_counts: list[list[int]]
    greedy_actions: list[int]  # argmax per state
    total_visits: int


@dataclass
class StepLogEntry:
    """Per-step data from step_log.jsonl."""

    episode: int
    step: int
    ap_id: str
    guard_passed: bool
    reward: float
    is_backtrack: bool
    terminal: bool
    satisfied: list[str]
    step_duration_ms: float | None = None
    instance_id: str | None = None
    workflow_id: str | None = None


@dataclass
class TrainingRun:
    """A single discovered RL training run."""

    slug: str
    display_name: str
    path: Path
    modified_at: datetime | None = None

    # From training_summary.json
    model: str | None = None
    provider: str | None = None
    arm: str | None = None
    reward: str | None = None
    episodes: int = 0
    gamma: float = 0.0
    alpha: float = 0.0
    epsilon_initial: float = 0.0
    epsilon_final: float = 0.0
    epsilon_decay: float = 0.0
    instances: int = 0
    language: str | None = None
    training_mean_reward: float = 0.0
    eval_mean_reward: float = 0.0
    eval_success_rate: float = 0.0
    ap_ids: list[str] = field(default_factory=list)

    # Instance IDs from artifact_dags directory listing or training_config
    instance_ids: list[str] = field(default_factory=list)

    # Setup duration (from training_config.json)
    setup_duration_secs: float | None = None

    # Live progress (from progress.json)
    progress: ProgressInfo | None = None

    # Checkpoint progression
    checkpoints: list[CheckpointInfo] = field(default_factory=list)

    # Per-episode log (from episode_log.jsonl)
    episode_log: list[EpisodeInfo] = field(default_factory=list)

    # Whether step_log.jsonl exists (enables per-episode DAG view)
    has_step_log: bool = False

    @property
    def is_in_progress(self) -> bool:
        """True when training is actively running (progress.json exists and is not stale/idle)."""
        return self.progress is not None

    @property
    def is_terminated(self) -> bool:
        """True when a run was explicitly killed (progress.json has status=terminated)."""
        progress_path = self.path / "progress.json"
        if not progress_path.exists():
            return False
        try:
            data = json.loads(progress_path.read_text())
            return bool(data.get("status") == "terminated")
        except (json.JSONDecodeError, OSError):
            return False

    @property
    def completed_episodes(self) -> int:
        """Number of episodes recorded in the episode log."""
        return len(self.episode_log)

    @property
    def best_reward(self) -> float | None:
        """Highest single-episode reward from the episode log."""
        if not self.episode_log:
            return None
        return max(ep.reward for ep in self.episode_log)

    @property
    def mean_reward_so_far(self) -> float | None:
        """Running mean reward across all logged episodes."""
        if not self.episode_log:
            return None
        return sum(ep.reward for ep in self.episode_log) / len(self.episode_log)

    @property
    def reward_description(self) -> str:
        """Human-readable description of the reward strategy."""
        _DESCRIPTIONS = {
            "sparse": "Sparse Binary — +1 terminal success, -1 timeout, 0 intermediate.",
            "step": "Step Reward — +r per newly satisfied AP, -p per step.",
            "efficiency": "Efficiency Penalty — step reward + penalties for waste.",
            "potential-based": "Potential-Based Shaping — γΦ(s')−Φ(s), preserves optimal policy.",
            "phased": "Phased Shaping — potential-based + phase ordering bonuses (Discovery→Analysis→Generation→Validation).",
        }
        return _DESCRIPTIONS.get(self.reward or "", self.reward or "—")


def _is_run_dir(path: Path) -> bool:
    """Return True if *path* looks like a training run directory."""
    return (
        (path / "training_summary.json").exists()
        or (path / "episode_log.jsonl").exists()
        or (path / "training_config.json").exists()
        or (path / "final").is_dir()
        or (path / "latest").exists()
    )


def discover_training_runs(output_dir: Path) -> list[TrainingRun]:
    """Scan output directory for RL training runs.

    Looks for directories containing checkpoint subdirectories with
    ``metadata.json`` + ``qtable.npz`` files.  Also checks for
    ``training_summary.json`` at the top level.

    Convention: ``output/rl_training/{run_name}/``
    """
    runs: list[TrainingRun] = []
    if not output_dir.is_dir():
        return runs

    # Look for rl_training directories specifically, and also scan
    # all top-level output dirs for training_summary.json
    candidates: list[Path] = []

    rl_dir = output_dir / "rl_training"
    if rl_dir.is_dir():
        for child in sorted(rl_dir.iterdir()):
            if child.is_dir():
                # Check if this dir is a run itself or a group containing runs
                if _is_run_dir(child):
                    candidates.append(child)
                else:
                    # Scan one level deeper (e.g., openrouter_smoke/qwen3-coder-next/)
                    for grandchild in sorted(child.iterdir()):
                        if grandchild.is_dir():
                            candidates.append(grandchild)

    # Also scan top-level for any dir with training_summary.json
    for child in sorted(output_dir.iterdir()):
        if (
            child.is_dir()
            and (child / "training_summary.json").exists()
            and child not in candidates
        ):
            candidates.append(child)

    for run_dir in candidates:
        run = _load_training_run(run_dir)
        if run is not None:
            runs.append(run)

    runs.sort(key=lambda r: (r.modified_at is not None, r.modified_at), reverse=True)
    return runs


def _load_training_run(run_dir: Path) -> TrainingRun | None:
    """Attempt to load a training run from a directory."""
    # Must have at least one checkpoint, training_summary.json, or episode_log.jsonl
    has_summary = (run_dir / "training_summary.json").exists()
    has_episode_log = (run_dir / "episode_log.jsonl").exists()
    has_checkpoints = any(
        (d / "metadata.json").exists()
        for d in run_dir.iterdir()
        if d.is_dir() and d.name.startswith("checkpoint_")
    )

    has_config = (run_dir / "training_config.json").exists()

    if (
        not has_summary
        and not has_checkpoints
        and not has_episode_log
        and not has_config
    ):
        return None

    slug = run_dir.name
    display_name = slug.replace("_", " ").title()

    # Get modification time
    modified_at = None
    try:
        mtime = run_dir.stat().st_mtime
        for name in ("training_summary.json", "latest"):
            candidate = run_dir / name
            with contextlib.suppress(OSError):
                mtime = max(mtime, candidate.stat().st_mtime)
        modified_at = datetime.fromtimestamp(mtime, tz=UTC)
    except OSError:
        logger.debug("Failed to stat training run directory %s", run_dir)

    run = TrainingRun(
        slug=slug,
        display_name=display_name,
        path=run_dir,
        modified_at=modified_at,
    )

    # Load training summary (or fall back to training_config for in-progress runs)
    summary_path = run_dir / "training_summary.json"
    config_path = run_dir / "training_config.json"
    meta_path = summary_path if summary_path.exists() else config_path
    if meta_path.exists():
        try:
            data = json.loads(meta_path.read_text())
            run.model = data.get("model")
            run.provider = data.get("provider")
            run.arm = data.get("arm")
            run.reward = data.get("reward")
            run.episodes = data.get("episodes", 0)
            run.gamma = data.get("gamma", 0.0)
            run.alpha = data.get("alpha", 0.0)
            run.epsilon_initial = data.get("epsilon_initial", 0.0)
            run.epsilon_final = data.get("epsilon_final", 0.0)
            run.epsilon_decay = data.get("epsilon_decay", 0.0)
            run.instances = data.get("instances", 0)
            run.language = data.get("language")
            run.training_mean_reward = data.get("training_mean_reward", 0.0)
            run.eval_mean_reward = data.get("eval_mean_reward", 0.0)
            run.eval_success_rate = data.get("eval_success_rate", 0.0)
            run.ap_ids = data.get("ap_ids", [])
            run.setup_duration_secs = data.get("setup_duration_secs")
        except (json.JSONDecodeError, OSError):
            logger.debug("Failed to load training metadata from %s", meta_path)

    # Load live progress
    run.progress = _load_progress(run_dir)

    # Load checkpoint progression
    run.checkpoints = _load_checkpoints(run_dir)

    # Load per-episode log
    run.episode_log = _load_episode_log(run_dir)

    # Check for step_log.jsonl (enables per-episode DAG view)
    run.has_step_log = (run_dir / "step_log.jsonl").exists()

    # Discover instance_ids from training_config or artifact_dags directory
    run.instance_ids = _discover_instance_ids(run_dir)

    # If training_summary.json hasn't been written yet (training still
    # in progress), derive the episode count from the live log.
    if run.episodes == 0 and run.episode_log:
        run.episodes = run.episode_log[-1].episode

    return run


def _discover_instance_ids(run_dir: Path) -> list[str]:
    """Discover instance IDs from training_config.json or artifact_dags/ listing."""
    # Try training_config.json first (may have explicit instance_ids)
    config_path = run_dir / "training_config.json"
    if config_path.exists():
        try:
            data = json.loads(config_path.read_text())
            ids = data.get("instance_ids")
            if ids:
                return sorted(ids)
        except (json.JSONDecodeError, OSError):
            logger.debug("Failed to load instance IDs from %s", config_path)

    # Fallback: list artifact_dags/ subdirectories
    dag_dir = run_dir / "artifact_dags"
    if dag_dir.is_dir():
        return sorted(d.name for d in dag_dir.iterdir() if d.is_dir())

    return []


def _load_checkpoints(run_dir: Path) -> list[CheckpointInfo]:
    """Load checkpoint metadata from all checkpoint_NNNNNN dirs."""
    checkpoints: list[CheckpointInfo] = []

    for child in sorted(run_dir.iterdir()):
        if not child.is_dir():
            continue
        # Accept checkpoint_NNNNNN and "final"
        if not (child.name.startswith("checkpoint_") or child.name == "final"):
            continue
        meta_path = child / "metadata.json"
        if not meta_path.exists():
            continue

        try:
            data = json.loads(meta_path.read_text())
            checkpoints.append(
                CheckpointInfo(
                    name=child.name,
                    episode=data.get("total_episodes", 0),
                    mean_reward=data.get("mean_reward", 0.0),
                    epsilon=data.get("epsilon", 0.0),
                )
            )
        except (json.JSONDecodeError, OSError):
            continue

    # Sort by episode number
    checkpoints.sort(key=lambda c: c.episode)
    return checkpoints


def _load_episode_log(run_dir: Path) -> list[EpisodeInfo]:
    """Load per-episode metrics from episode_log.jsonl."""
    log_path = run_dir / "episode_log.jsonl"
    if not log_path.exists():
        return []

    episodes: list[EpisodeInfo] = []
    try:
        for line in log_path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                episodes.append(
                    EpisodeInfo(
                        episode=data.get("episode", 0),
                        reward=data.get("reward", 0.0),
                        steps=data.get("steps", 0),
                        epsilon=data.get("epsilon", 0.0),
                        satisfied=data.get("satisfied"),
                        total_aps=data.get("total_aps"),
                        all_satisfied=data.get("all_satisfied"),
                        duration_secs=data.get("duration_secs"),
                        tokens=data.get("tokens"),
                        backtracks=data.get("backtracks"),
                        execution_ms=data.get("execution_ms"),
                        started_at=data.get("started_at"),
                        finished_at=data.get("finished_at"),
                        instance_id=data.get("instance_id"),
                        workflow_id=data.get("workflow_id"),
                    )
                )
            except (json.JSONDecodeError, KeyError):
                continue
    except OSError:
        logger.debug("Failed to read episode log %s", log_path)

    return episodes


def _load_progress(run_dir: Path) -> ProgressInfo | None:
    """Load live training progress from progress.json.

    Returns None if the file doesn't exist, is idle, or is stale (> 60s).
    """
    progress_path = run_dir / "progress.json"
    if not progress_path.exists():
        return None

    try:
        data = json.loads(progress_path.read_text())
    except (json.JSONDecodeError, OSError):
        return None

    if data.get("status") in ("idle", "terminated"):
        return None

    if "episode" not in data:
        return None

    return ProgressInfo(
        episode=data["episode"],
        step=data.get("step", 0),
        max_steps=data.get("max_steps", 0),
        satisfied=data.get("satisfied", 0),
        total_aps=data.get("total_aps", 0),
        timestamp=data.get("timestamp", ""),
    )


def load_policy_info(run_dir: Path) -> PolicyInfo | None:
    """Load Q-table from the latest checkpoint for visualisation.

    Returns None if no valid checkpoint is found.
    """
    # Find the best checkpoint: "latest" symlink, then "final", then last numbered
    qtable_path = None
    for candidate_name in ("latest", "final"):
        candidate = run_dir / candidate_name
        if candidate.exists() and (candidate / "qtable.npz").exists():
            qtable_path = candidate / "qtable.npz"
            break

    if qtable_path is None:
        # Find last numbered checkpoint
        numbered = sorted(
            (
                d
                for d in run_dir.iterdir()
                if d.is_dir()
                and d.name.startswith("checkpoint_")
                and (d / "qtable.npz").exists()
            ),
            key=lambda d: d.name,
        )
        if numbered:
            qtable_path = numbered[-1] / "qtable.npz"

    if qtable_path is None:
        return None

    return _load_qtable_as_policy_info(qtable_path)


def load_policy_info_from_checkpoint(checkpoint_dir: Path) -> PolicyInfo | None:
    """Load Q-table from a *specific* checkpoint directory.

    Unlike :func:`load_policy_info`, this does not search the run root for
    the "best" checkpoint — it loads exactly from *checkpoint_dir/qtable.npz*.
    Use this when you already know which checkpoint to display (e.g. on the
    policy detail page where the PolicyRecord stores the checkpoint path).

    Returns None if the checkpoint has no valid Q-table.
    """
    qtable_path = checkpoint_dir / "qtable.npz"
    if not qtable_path.exists():
        return None
    return _load_qtable_as_policy_info(qtable_path)


def _load_qtable_as_policy_info(qtable_path: Path) -> PolicyInfo | None:
    """Shared loader: parse a qtable.npz file into a PolicyInfo."""
    try:
        data = np.load(qtable_path, allow_pickle=True)
        q_table = data["Q"]
        visit_count = data["visit_count"]
        ap_ids = [str(x) for x in data["ap_ids"]] if "ap_ids" in data else []

        num_states, num_actions = q_table.shape

        # For visualisation, only include states that have been visited
        # or a reasonable subset if the state space is huge
        max_display_states = min(num_states, 64)

        # Find the most-visited states
        state_total_visits = visit_count.sum(axis=1)
        if num_states > max_display_states:
            top_indices = np.argsort(state_total_visits)[-max_display_states:]
            top_indices = np.sort(top_indices)
        else:
            top_indices = np.arange(num_states)

        q_subset = q_table[top_indices].tolist()
        visit_subset = visit_count[top_indices].astype(int).tolist()
        greedy = [int(np.argmax(q_table[i])) for i in top_indices]
        total_visits = int(visit_count.sum())

        return PolicyInfo(
            ap_ids=ap_ids,
            num_states=num_states,
            num_actions=num_actions,
            q_table=q_subset,
            visit_counts=visit_subset,
            greedy_actions=greedy,
            total_visits=total_visits,
        )
    except (OSError, KeyError, ValueError):
        return None


def load_episode_steps(run_dir: Path, episode: int) -> list[StepLogEntry]:
    """Load per-step data for a single episode from step_log.jsonl."""
    log_path = run_dir / "step_log.jsonl"
    if not log_path.exists():
        return []

    steps: list[StepLogEntry] = []
    try:
        for line in log_path.read_text().splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
                if data.get("episode") != episode:
                    continue
                steps.append(
                    StepLogEntry(
                        episode=data["episode"],
                        step=data["step"],
                        ap_id=data.get("ap_id", ""),
                        guard_passed=data.get("guard_passed", False),
                        reward=data.get("reward", 0.0),
                        is_backtrack=data.get("is_backtrack", False),
                        terminal=data.get("terminal", False),
                        satisfied=data.get("satisfied", []),
                        step_duration_ms=data.get("step_duration_ms"),
                        instance_id=data.get("instance_id"),
                        workflow_id=data.get("workflow_id"),
                    )
                )
            except (json.JSONDecodeError, KeyError):
                continue
    except OSError:
        logger.debug("Failed to read step log %s", log_path)

    steps.sort(key=lambda s: s.step)
    return steps


def _strip_common_prefix(labels: list[str]) -> list[str]:
    """Strip common AP prefix for shorter display labels."""
    if not labels or len(labels) < 2:
        return labels
    prefix = labels[0]
    for label in labels[1:]:
        while not label.startswith(prefix):
            prefix = prefix[:-1]
        if not prefix:
            return labels
    # Snap to last underscore
    snap = prefix.rfind("_")
    if snap > 0:
        prefix = prefix[: snap + 1]
    else:
        return labels
    return [label[len(prefix) :] for label in labels]


def build_episode_graph(
    steps: list[StepLogEntry],
) -> dict:
    """Convert step log entries into Cytoscape-compatible nodes and edges.

    Returns ``{"nodes": [...], "edges": [...]}`` suitable for
    Cytoscape.js initialisation.
    """
    if not steps:
        return {"nodes": [], "edges": []}

    # Build short labels for AP names
    unique_aps = sorted({s.ap_id for s in steps})
    short_map = dict(zip(unique_aps, _strip_common_prefix(unique_aps), strict=True))

    nodes = []
    edges = []

    for s in steps:
        short_label = short_map.get(s.ap_id, s.ap_id)
        status = "accepted" if s.guard_passed else "rejected"
        nodes.append(
            {
                "data": {
                    "id": f"step_{s.step}",
                    "label": f"{short_label} #{s.step}",
                    "type": "artifact",
                    "status": status,
                    "is_backtrack": s.is_backtrack,
                    "ap_id": s.ap_id,
                    "reward": s.reward,
                    "guard_passed": s.guard_passed,
                    "terminal": s.terminal,
                    "satisfied": s.satisfied,
                    "step_num": s.step,
                    "step_duration_ms": s.step_duration_ms,
                }
            }
        )

    for i in range(len(steps) - 1):
        edge_type = "backtrack" if steps[i + 1].is_backtrack else "sequential"
        edges.append(
            {
                "data": {
                    "id": f"e_{steps[i].step}_{steps[i + 1].step}",
                    "source": f"step_{steps[i].step}",
                    "target": f"step_{steps[i + 1].step}",
                    "type": edge_type,
                }
            }
        )

    return {"nodes": nodes, "edges": edges}
