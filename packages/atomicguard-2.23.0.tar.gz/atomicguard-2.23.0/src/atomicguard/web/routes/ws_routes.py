"""WebSocket routes for real-time nav metric updates."""

from __future__ import annotations

import asyncio
import json
import logging
from pathlib import Path
from typing import Any

from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from ..ws import manager

logger = logging.getLogger(__name__)

router = APIRouter()

NAV_METRICS_CHANNEL = "nav-metrics"
_NAV_POLL_INTERVAL = 30  # seconds — matches the old setInterval cadence


def _read_spark_latest(output_dir: Path | None) -> dict[str, Any] | None:
    """Read the last line of spark_monitor/metrics.jsonl."""
    if not output_dir:
        return None
    f = output_dir / "spark_monitor" / "metrics.jsonl"
    if not f.exists():
        return None
    try:
        last = ""
        for line in f.read_text().splitlines():
            if line.strip():
                last = line.strip()
        return json.loads(last) if last else None
    except Exception:
        return None


def _read_ollama_latest(output_dir: Path | None) -> dict[str, Any] | None:
    """Read ollama requests.jsonl and compute summary stats."""
    if not output_dir:
        return None
    f = output_dir / "ollama_monitor" / "requests.jsonl"
    if not f.exists():
        return None
    try:
        requests: list[dict[str, Any]] = []
        for line in f.read_text().splitlines():
            line = line.strip()
            if line:
                try:
                    requests.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
        if not requests:
            return None
        total = len(requests)
        errors = sum(1 for r in requests if r.get("status", 0) >= 400)
        durations = [r.get("duration_s", 0) for r in requests]
        avg = round(sum(durations) / len(durations), 1) if durations else 0
        return {"count": total, "avg_latency": avg, "error_count": errors}
    except Exception:
        return None


def _pill_class(value: float, thresholds: tuple[float, float] = (50, 80)) -> str:
    """Return CSS pill class based on threshold."""
    low, high = thresholds
    if value >= high:
        return "pill-red"
    if value >= low:
        return "pill-yellow"
    return "pill-green"


def _render_spark_pills(spark: dict[str, Any]) -> str:
    """Render Spark nav pills as HTML fragment."""
    gpu = spark.get("gpu_util", 0)
    ram_used = spark.get("ram_used_mb", 0)
    ram_total = spark.get("ram_total_mb", 1)
    ram_pct = round(ram_used / ram_total * 100) if ram_total else 0
    return (
        f'<span class="nav-spark-pill {_pill_class(gpu)}" id="nav-gpu">'
        f"GPU {gpu}%</span>"
        f'<span class="nav-spark-pill {_pill_class(ram_pct)}" id="nav-ram">'
        f"RAM {ram_pct}%</span>"
    )


def _latency_pill_class(avg: float) -> str:
    if avg <= 60:
        return "pill-green"
    if avg <= 120:
        return "pill-yellow"
    return "pill-red"


def _render_ollama_pills(ollama: dict[str, Any]) -> str:
    """Render Ollama nav pills as HTML fragment."""
    count = ollama.get("count", 0)
    avg = ollama.get("avg_latency", 0)
    errors = ollama.get("error_count", 0)
    html = (
        f'<span class="nav-spark-pill pill-muted" id="nav-ollama-count">'
        f"{count} req</span>"
        f'<span class="nav-spark-pill {_latency_pill_class(avg)}" '
        f'id="nav-ollama-latency">{avg}s avg</span>'
    )
    if errors > 0:
        err_class = "pill-yellow" if errors <= 5 else "pill-red"
        html += (
            f'<span class="nav-spark-pill {err_class}" '
            f'id="nav-ollama-errors">{errors} err</span>'
        )
    return html


def render_nav_metrics(output_dir: Path | None) -> str:
    """Render the full nav-metrics HTML fragment for WebSocket broadcast.

    Returns an HTML string with id="nav-metrics-ws" that HTMX will swap
    into the DOM via the ws extension's swap mechanism.
    """
    spark = _read_spark_latest(output_dir)
    ollama = _read_ollama_latest(output_dir)

    parts: list[str] = []
    if spark:
        parts.append(
            f'<a href="/spark/" class="nav-metrics-group" id="nav-spark" '
            f'title="DGX Spark — click for details">'
            f'<span class="nav-metrics-label">Spark</span>'
            f"{_render_spark_pills(spark)}</a>"
        )
    if ollama:
        parts.append(
            f'<a href="/ollama/" class="nav-metrics-group" '
            f'id="nav-ollama" title="Ollama requests — click for details">'
            f'<span class="nav-metrics-label">Ollama</span>'
            f"{_render_ollama_pills(ollama)}</a>"
        )

    # Wrap in the swap target div — HTMX ws extension matches by id
    return (
        f'<div class="nav-metrics-row" id="nav-metrics-ws" '
        f'hx-ext="ws" ws-connect="/ws/nav-metrics">'
        f"{''.join(parts)}</div>"
    )


@router.websocket("/ws/run/{run_id}")
async def ws_run_status(websocket: WebSocket, run_id: int) -> None:
    """WebSocket endpoint for live run status updates.

    Clients subscribe to a run-specific channel. The run launcher
    can broadcast updates via ``manager.broadcast(f"run:{run_id}", html)``.
    Falls back to polling the DB for status changes.
    """
    channel = f"run:{run_id}"
    await manager.connect(channel, websocket)
    try:
        # Keep connection alive — broadcasts arrive from the run monitor
        while True:
            # Wait for any client messages (e.g. pings) to detect disconnects
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(channel, websocket)
    except Exception:
        manager.disconnect(channel, websocket)


@router.websocket("/ws/nav-metrics")
async def ws_nav_metrics(websocket: WebSocket) -> None:
    """WebSocket endpoint for live nav-pill metric updates.

    Pushes HTML fragments every 30s. HTMX ws extension swaps them by id.
    """
    await manager.connect(NAV_METRICS_CHANNEL, websocket)
    output_dir = getattr(websocket.app.state, "output_dir", None)
    try:
        while True:
            # Push current metrics immediately on connect, then every interval
            html = render_nav_metrics(output_dir)
            await websocket.send_text(html)
            await asyncio.sleep(_NAV_POLL_INTERVAL)
    except WebSocketDisconnect:
        manager.disconnect(NAV_METRICS_CHANNEL, websocket)
    except Exception:
        manager.disconnect(NAV_METRICS_CHANNEL, websocket)
