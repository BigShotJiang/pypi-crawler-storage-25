"""Routes for the Guard Library and Generator Library."""

from __future__ import annotations

import json
import logging
from dataclasses import replace
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from atomicguard.domain.interfaces import GymRepositoryInterface
from atomicguard.domain.models import GeneratorLibraryEntry, GuardLibraryEntry

from ..dependencies import get_gym_repo

logger = logging.getLogger(__name__)

# HTML routes
guards_router = APIRouter(prefix="/guards", tags=["guard-library"])
generators_router = APIRouter(prefix="/generators", tags=["generator-library"])

# REST API routes
guards_api_router = APIRouter(prefix="/api/guards", tags=["guard-library-api"])
generators_api_router = APIRouter(
    prefix="/api/generators", tags=["generator-library-api"]
)

VALID_STOCHASTICITY = frozenset({"deterministic", "stochastic"})
VALID_MECHANISMS = frozenset(
    {"llm_pydantic", "llm_plaintext", "subprocess", "disk", "echo"}
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _guard_to_dict(entry: GuardLibraryEntry) -> dict[str, Any]:
    return {
        "guard_id": entry.guard_id,
        "class_name": entry.class_name,
        "name": entry.name,
        "description": entry.description,
        "domain": entry.domain,
        "input_types": list(entry.input_types),
        "stochasticity": entry.stochasticity,
        "can_fatal": entry.can_fatal,
        "requires_runtime": list(entry.requires_runtime),
        "parameter_schema": entry.parameter_schema,
        "tags": list(entry.tags),
        "example_config": entry.example_config,
        "notes": entry.notes,
    }


def _generator_to_dict(entry: GeneratorLibraryEntry) -> dict[str, Any]:
    return {
        "generator_id": entry.generator_id,
        "class_name": entry.class_name,
        "name": entry.name,
        "description": entry.description,
        "domain": entry.domain,
        "output_type": entry.output_type,
        "mechanism": entry.mechanism,
        "stochasticity": entry.stochasticity,
        "language": entry.language,
        "requires_runtime": list(entry.requires_runtime),
        "parameter_schema": entry.parameter_schema,
        "tags": list(entry.tags),
        "example_config": entry.example_config,
        "notes": entry.notes,
    }


def _guard_ctx(request: Request) -> dict[str, Any]:
    return {"request": request, "nav_active": "guard_library"}


def _generator_ctx(request: Request) -> dict[str, Any]:
    return {"request": request, "nav_active": "generator_library"}


# ---------------------------------------------------------------------------
# Guard Library — HTML routes
# ---------------------------------------------------------------------------


@guards_router.get("/", response_class=HTMLResponse)
async def guard_library_list(
    request: Request,
    domain: str = "",
    stochasticity: str = "",
    can_fatal: str = "",
    search: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Guard Library list page with filters."""
    all_entries = gym_repo.list_all_guards()
    entries = list(all_entries)

    if domain:
        entries = [e for e in entries if e.domain == domain]
    if stochasticity:
        entries = [e for e in entries if e.stochasticity == stochasticity]
    if can_fatal == "true":
        entries = [e for e in entries if e.can_fatal]
    elif can_fatal == "false":
        entries = [e for e in entries if not e.can_fatal]
    if search:
        q = search.lower()
        entries = [
            e
            for e in entries
            if q in e.guard_id.lower()
            or q in e.name.lower()
            or q in e.description.lower()
            or q in e.class_name.lower()
        ]

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "guard_library.html",
        {
            **_guard_ctx(request),
            "entries": entries,
            "filters": {
                "domain": domain,
                "stochasticity": stochasticity,
                "can_fatal": can_fatal,
                "search": search,
            },
            "domains": sorted({e.domain for e in all_entries}),
        },
    )


@guards_router.get("/{guard_id}/", response_class=HTMLResponse)
async def guard_library_detail(
    request: Request,
    guard_id: str,
    edit: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Guard Library detail/edit page."""
    try:
        entry = gym_repo.get_guard(guard_id)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Guard '{guard_id}' not found"
        ) from exc

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "guard_library_detail.html",
        {
            **_guard_ctx(request),
            "entry": entry,
            "breadcrumbs": [("Guards", "/guards/"), (entry.guard_id, "")],
            "edit_mode": edit == "1",
        },
    )


@guards_router.post("/", response_class=HTMLResponse)
async def guard_library_create(
    guard_id: str = Form(...),
    class_name: str = Form(""),
    name: str = Form(""),
    description: str = Form(""),
    domain: str = Form("core"),
    stochasticity: str = Form("deterministic"),
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Create a new Guard Library entry."""
    if not guard_id or not guard_id.strip():
        raise HTTPException(status_code=400, detail="guard_id must not be empty")
    if stochasticity not in VALID_STOCHASTICITY:
        raise HTTPException(
            status_code=400,
            detail=f"stochasticity must be one of {sorted(VALID_STOCHASTICITY)}",
        )

    entry = GuardLibraryEntry(
        guard_id=guard_id,
        class_name=class_name,
        name=name,
        description=description,
        domain=domain,
        stochasticity=stochasticity,
    )
    gym_repo.save_guard(entry)
    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/guards/{guard_id}/"},
    )


@guards_router.put("/{guard_id}/", response_class=HTMLResponse)
async def guard_library_update(
    guard_id: str,
    class_name: str = Form(""),
    name: str = Form(""),
    description: str = Form(""),
    domain: str = Form("core"),
    stochasticity: str = Form("deterministic"),
    can_fatal: str = Form(""),
    input_types: str = Form(""),
    requires_runtime: str = Form(""),
    parameter_schema_json: str = Form("{}"),
    example_config_json: str = Form("{}"),
    tags: str = Form(""),
    notes: str = Form(""),
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Update an existing Guard Library entry."""
    try:
        existing = gym_repo.get_guard(guard_id)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Guard '{guard_id}' not found"
        ) from exc

    if stochasticity not in VALID_STOCHASTICITY:
        raise HTTPException(
            status_code=400,
            detail=f"stochasticity must be one of {sorted(VALID_STOCHASTICITY)}",
        )

    try:
        parameter_schema = json.loads(parameter_schema_json)
        if not isinstance(parameter_schema, dict):
            parameter_schema = existing.parameter_schema
    except Exception:
        parameter_schema = existing.parameter_schema

    try:
        example_config = json.loads(example_config_json)
        if not isinstance(example_config, dict):
            example_config = existing.example_config
    except Exception:
        example_config = existing.example_config

    parsed_input_types = tuple(t.strip() for t in input_types.split(",") if t.strip())
    parsed_requires_runtime = tuple(
        t.strip() for t in requires_runtime.split(",") if t.strip()
    )
    parsed_tags = tuple(t.strip() for t in tags.split(",") if t.strip())
    parsed_can_fatal = can_fatal.lower() in ("1", "true", "on", "yes")

    updated = replace(
        existing,
        class_name=class_name,
        name=name,
        description=description,
        domain=domain,
        stochasticity=stochasticity,
        can_fatal=parsed_can_fatal,
        input_types=parsed_input_types,
        requires_runtime=parsed_requires_runtime,
        parameter_schema=parameter_schema,
        example_config=example_config,
        tags=parsed_tags,
        notes=notes,
    )
    gym_repo.save_guard(updated)
    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/guards/{guard_id}/"},
    )


@guards_router.delete("/{guard_id}/", response_class=HTMLResponse)
async def guard_library_delete(
    guard_id: str,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Delete a Guard Library entry."""
    try:
        gym_repo.delete_guard(guard_id)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Guard '{guard_id}' not found"
        ) from exc
    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": "/guards/"},
    )


@guards_router.post("/bulk-delete")
async def guard_library_bulk_delete(
    request: Request,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> RedirectResponse:
    """Bulk delete Guard Library entries."""
    form = await request.form()
    guard_ids = [str(v) for v in form.getlist("guard_ids")]
    for guard_id in guard_ids:
        try:
            gym_repo.delete_guard(guard_id)
        except KeyError:
            continue
    return RedirectResponse(url="/guards/", status_code=303)


@guards_router.post("/import-seed", response_class=HTMLResponse)
async def guard_library_import_seed(
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Import guards from the seed guard_library.json file."""
    seed_path = Path(__file__).resolve().parents[2] / "schemas" / "guard_library.json"
    if not seed_path.exists():
        raise HTTPException(status_code=404, detail="Guard library seed file not found")

    data = json.loads(seed_path.read_text())
    for guard_id, fields in data.items():
        entry = GuardLibraryEntry(
            guard_id=guard_id,
            class_name=fields.get("class_name", ""),
            name=fields.get("name", ""),
            description=fields.get("description", ""),
            domain=fields.get("domain", "core"),
            input_types=tuple(fields.get("input_types", [])),
            stochasticity=fields.get("stochasticity", "deterministic"),
            can_fatal=bool(fields.get("can_fatal", False)),
            requires_runtime=tuple(fields.get("requires_runtime", [])),
            parameter_schema=fields.get("parameter_schema", {}),
            tags=tuple(fields.get("tags", [])),
            example_config=fields.get("example_config", {}),
            notes=fields.get("notes", ""),
        )
        gym_repo.save_guard(entry)

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": "/guards/"},
    )


# ---------------------------------------------------------------------------
# Generator Library — HTML routes
# ---------------------------------------------------------------------------


@generators_router.get("/", response_class=HTMLResponse)
async def generator_library_list(
    request: Request,
    domain: str = "",
    mechanism: str = "",
    stochasticity: str = "",
    search: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Generator Library list page with filters."""
    all_entries = gym_repo.list_all_generators()
    entries = list(all_entries)

    if domain:
        entries = [e for e in entries if e.domain == domain]
    if mechanism:
        entries = [e for e in entries if e.mechanism == mechanism]
    if stochasticity:
        entries = [e for e in entries if e.stochasticity == stochasticity]
    if search:
        q = search.lower()
        entries = [
            e
            for e in entries
            if q in e.generator_id.lower()
            or q in e.name.lower()
            or q in e.description.lower()
            or q in e.class_name.lower()
        ]

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "generator_library.html",
        {
            **_generator_ctx(request),
            "entries": entries,
            "filters": {
                "domain": domain,
                "mechanism": mechanism,
                "stochasticity": stochasticity,
                "search": search,
            },
            "domains": sorted({e.domain for e in all_entries}),
            "mechanisms": sorted({e.mechanism for e in all_entries}),
        },
    )


@generators_router.get("/{generator_id}/", response_class=HTMLResponse)
async def generator_library_detail(
    request: Request,
    generator_id: str,
    edit: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Generator Library detail/edit page."""
    try:
        entry = gym_repo.get_generator(generator_id)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Generator '{generator_id}' not found"
        ) from exc

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "generator_library_detail.html",
        {
            **_generator_ctx(request),
            "entry": entry,
            "breadcrumbs": [("Generators", "/generators/"), (entry.generator_id, "")],
            "edit_mode": edit == "1",
        },
    )


@generators_router.post("/", response_class=HTMLResponse)
async def generator_library_create(
    generator_id: str = Form(...),
    class_name: str = Form(""),
    name: str = Form(""),
    description: str = Form(""),
    domain: str = Form("core"),
    output_type: str = Form(""),
    mechanism: str = Form("llm_pydantic"),
    stochasticity: str = Form("stochastic"),
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Create a new Generator Library entry."""
    if not generator_id or not generator_id.strip():
        raise HTTPException(status_code=400, detail="generator_id must not be empty")
    if stochasticity not in VALID_STOCHASTICITY:
        raise HTTPException(
            status_code=400,
            detail=f"stochasticity must be one of {sorted(VALID_STOCHASTICITY)}",
        )
    if mechanism not in VALID_MECHANISMS:
        raise HTTPException(
            status_code=400,
            detail=f"mechanism must be one of {sorted(VALID_MECHANISMS)}",
        )

    entry = GeneratorLibraryEntry(
        generator_id=generator_id,
        class_name=class_name,
        name=name,
        description=description,
        domain=domain,
        output_type=output_type,
        mechanism=mechanism,
        stochasticity=stochasticity,
    )
    gym_repo.save_generator(entry)
    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/generators/{generator_id}/"},
    )


@generators_router.put("/{generator_id}/", response_class=HTMLResponse)
async def generator_library_update(
    generator_id: str,
    class_name: str = Form(""),
    name: str = Form(""),
    description: str = Form(""),
    domain: str = Form("core"),
    output_type: str = Form(""),
    mechanism: str = Form("llm_pydantic"),
    stochasticity: str = Form("stochastic"),
    language: str = Form(""),
    requires_runtime: str = Form(""),
    parameter_schema_json: str = Form("{}"),
    example_config_json: str = Form("{}"),
    tags: str = Form(""),
    notes: str = Form(""),
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Update an existing Generator Library entry."""
    try:
        existing = gym_repo.get_generator(generator_id)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Generator '{generator_id}' not found"
        ) from exc

    if stochasticity not in VALID_STOCHASTICITY:
        raise HTTPException(
            status_code=400,
            detail=f"stochasticity must be one of {sorted(VALID_STOCHASTICITY)}",
        )
    if mechanism not in VALID_MECHANISMS:
        raise HTTPException(
            status_code=400,
            detail=f"mechanism must be one of {sorted(VALID_MECHANISMS)}",
        )

    try:
        parameter_schema = json.loads(parameter_schema_json)
        if not isinstance(parameter_schema, dict):
            parameter_schema = existing.parameter_schema
    except Exception:
        parameter_schema = existing.parameter_schema

    try:
        example_config = json.loads(example_config_json)
        if not isinstance(example_config, dict):
            example_config = existing.example_config
    except Exception:
        example_config = existing.example_config

    parsed_requires_runtime = tuple(
        t.strip() for t in requires_runtime.split(",") if t.strip()
    )
    parsed_tags = tuple(t.strip() for t in tags.split(",") if t.strip())

    updated = replace(
        existing,
        class_name=class_name,
        name=name,
        description=description,
        domain=domain,
        output_type=output_type,
        mechanism=mechanism,
        stochasticity=stochasticity,
        language=language or None,
        requires_runtime=parsed_requires_runtime,
        parameter_schema=parameter_schema,
        example_config=example_config,
        tags=parsed_tags,
        notes=notes,
    )
    gym_repo.save_generator(updated)
    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/generators/{generator_id}/"},
    )


@generators_router.delete("/{generator_id}/", response_class=HTMLResponse)
async def generator_library_delete(
    generator_id: str,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Delete a Generator Library entry."""
    try:
        gym_repo.delete_generator(generator_id)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Generator '{generator_id}' not found"
        ) from exc
    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": "/generators/"},
    )


@generators_router.post("/bulk-delete")
async def generator_library_bulk_delete(
    request: Request,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> RedirectResponse:
    """Bulk delete Generator Library entries."""
    form = await request.form()
    generator_ids = [str(v) for v in form.getlist("generator_ids")]
    for generator_id in generator_ids:
        try:
            gym_repo.delete_generator(generator_id)
        except KeyError:
            continue
    return RedirectResponse(url="/generators/", status_code=303)


@generators_router.post("/import-seed", response_class=HTMLResponse)
async def generator_library_import_seed(
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Import generators from the seed generator_library.json file."""
    seed_path = (
        Path(__file__).resolve().parents[2] / "schemas" / "generator_library.json"
    )
    if not seed_path.exists():
        raise HTTPException(
            status_code=404, detail="Generator library seed file not found"
        )

    data = json.loads(seed_path.read_text())
    for generator_id, fields in data.items():
        entry = GeneratorLibraryEntry(
            generator_id=generator_id,
            class_name=fields.get("class_name", ""),
            name=fields.get("name", ""),
            description=fields.get("description", ""),
            domain=fields.get("domain", "core"),
            output_type=fields.get("output_type", ""),
            mechanism=fields.get("mechanism", "llm_pydantic"),
            stochasticity=fields.get("stochasticity", "stochastic"),
            language=fields.get("language"),
            requires_runtime=tuple(fields.get("requires_runtime", [])),
            parameter_schema=fields.get("parameter_schema", {}),
            tags=tuple(fields.get("tags", [])),
            example_config=fields.get("example_config", {}),
            notes=fields.get("notes", ""),
        )
        gym_repo.save_generator(entry)

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": "/generators/"},
    )


# ---------------------------------------------------------------------------
# Guard Library — REST API
# ---------------------------------------------------------------------------


@guards_api_router.get("/", response_class=JSONResponse)
async def api_list_guards(
    domain: str = "",
    stochasticity: str = "",
    search: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """List all Guard Library entries as JSON."""
    entries = list(gym_repo.list_all_guards())
    if domain:
        entries = [e for e in entries if e.domain == domain]
    if stochasticity:
        entries = [e for e in entries if e.stochasticity == stochasticity]
    if search:
        q = search.lower()
        entries = [
            e
            for e in entries
            if q in e.guard_id.lower()
            or q in e.name.lower()
            or q in e.description.lower()
        ]
    return JSONResponse([_guard_to_dict(e) for e in entries])


@guards_api_router.get("/search", response_class=HTMLResponse)
async def api_search_guards_html(
    request: Request,
    q: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Return guard autocomplete dropdown as an HTML fragment."""
    entries = list(gym_repo.list_all_guards())
    if q:
        ql = q.lower()
        entries = [
            e
            for e in entries
            if ql in e.guard_id.lower()
            or ql in e.name.lower()
            or ql in e.description.lower()
        ]
    guards = [_guard_to_dict(e) for e in entries[:10]]
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/guard_autocomplete.html",
        {"request": request, "guards": guards},
    )


@guards_api_router.get("/{guard_id}", response_class=JSONResponse)
async def api_get_guard(
    guard_id: str,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Get a single Guard Library entry as JSON."""
    try:
        entry = gym_repo.get_guard(guard_id)
    except KeyError:
        raise HTTPException(
            status_code=404, detail=f"Guard '{guard_id}' not found"
        ) from None
    return JSONResponse(_guard_to_dict(entry))


@guards_api_router.post("/", response_class=JSONResponse, status_code=201)
async def api_create_guard(
    request: Request,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Create a new Guard Library entry from JSON body."""
    body = await request.json()
    guard_id = body.get("guard_id", "")
    if not guard_id:
        raise HTTPException(status_code=400, detail="guard_id must not be empty")
    stochasticity = body.get("stochasticity", "deterministic")
    if stochasticity not in VALID_STOCHASTICITY:
        raise HTTPException(
            status_code=400,
            detail=f"stochasticity must be one of {sorted(VALID_STOCHASTICITY)}",
        )

    entry = GuardLibraryEntry(
        guard_id=guard_id,
        class_name=body.get("class_name", ""),
        name=body.get("name", ""),
        description=body.get("description", ""),
        domain=body.get("domain", "core"),
        input_types=tuple(body.get("input_types", [])),
        stochasticity=stochasticity,
        can_fatal=bool(body.get("can_fatal", False)),
        requires_runtime=tuple(body.get("requires_runtime", [])),
        parameter_schema=body.get("parameter_schema", {}),
        tags=tuple(body.get("tags", [])),
        example_config=body.get("example_config", {}),
        notes=body.get("notes", ""),
    )
    gym_repo.save_guard(entry)
    return JSONResponse(_guard_to_dict(entry), status_code=201)


@guards_api_router.put("/{guard_id}", response_class=JSONResponse)
async def api_update_guard(
    guard_id: str,
    request: Request,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Update a Guard Library entry from JSON body."""
    try:
        existing = gym_repo.get_guard(guard_id)
    except KeyError:
        raise HTTPException(
            status_code=404, detail=f"Guard '{guard_id}' not found"
        ) from None

    body = await request.json()
    stochasticity = body.get("stochasticity", existing.stochasticity)
    if stochasticity not in VALID_STOCHASTICITY:
        raise HTTPException(
            status_code=400,
            detail=f"stochasticity must be one of {sorted(VALID_STOCHASTICITY)}",
        )

    updated = replace(
        existing,
        class_name=body.get("class_name", existing.class_name),
        name=body.get("name", existing.name),
        description=body.get("description", existing.description),
        domain=body.get("domain", existing.domain),
        input_types=tuple(body.get("input_types", list(existing.input_types))),
        stochasticity=stochasticity,
        can_fatal=bool(body.get("can_fatal", existing.can_fatal)),
        requires_runtime=tuple(
            body.get("requires_runtime", list(existing.requires_runtime))
        ),
        parameter_schema=body.get("parameter_schema", existing.parameter_schema),
        tags=tuple(body.get("tags", list(existing.tags))),
        example_config=body.get("example_config", existing.example_config),
        notes=body.get("notes", existing.notes),
    )
    gym_repo.save_guard(updated)
    return JSONResponse(_guard_to_dict(updated))


@guards_api_router.delete("/{guard_id}", status_code=204)
async def api_delete_guard(
    guard_id: str,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> None:
    """Delete a Guard Library entry."""
    try:
        gym_repo.delete_guard(guard_id)
    except KeyError:
        raise HTTPException(
            status_code=404, detail=f"Guard '{guard_id}' not found"
        ) from None


# ---------------------------------------------------------------------------
# Generator Library — REST API
# ---------------------------------------------------------------------------


@generators_api_router.get("/", response_class=JSONResponse)
async def api_list_generators(
    domain: str = "",
    mechanism: str = "",
    stochasticity: str = "",
    search: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """List all Generator Library entries as JSON."""
    entries = list(gym_repo.list_all_generators())
    if domain:
        entries = [e for e in entries if e.domain == domain]
    if mechanism:
        entries = [e for e in entries if e.mechanism == mechanism]
    if stochasticity:
        entries = [e for e in entries if e.stochasticity == stochasticity]
    if search:
        q = search.lower()
        entries = [
            e
            for e in entries
            if q in e.generator_id.lower()
            or q in e.name.lower()
            or q in e.description.lower()
        ]
    return JSONResponse([_generator_to_dict(e) for e in entries])


@generators_api_router.get("/search", response_class=HTMLResponse)
async def api_search_generators_html(
    request: Request,
    q: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Return generator autocomplete dropdown as an HTML fragment."""
    entries = list(gym_repo.list_all_generators())
    if q:
        ql = q.lower()
        entries = [
            e
            for e in entries
            if ql in e.generator_id.lower()
            or ql in e.name.lower()
            or ql in e.description.lower()
        ]
    generators = [_generator_to_dict(e) for e in entries[:10]]
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/generator_autocomplete.html",
        {"request": request, "generators": generators},
    )


@generators_api_router.get("/validate", response_class=HTMLResponse)
async def api_validate_generator_html(
    request: Request,
    value: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Return generator info chip + warning state as HTML fragment."""
    generator = None
    has_registry = True
    if value:
        all_entries = list(gym_repo.list_all_generators())
        has_registry = bool(all_entries)
        match = next((e for e in all_entries if e.generator_id == value), None)
        if match:
            generator = _generator_to_dict(match)
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/generator_info_chip.html",
        {
            "request": request,
            "generator": generator,
            "show_warning": value and not generator and has_registry,
        },
    )


@generators_api_router.get("/{generator_id}", response_class=JSONResponse)
async def api_get_generator(
    generator_id: str,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Get a single Generator Library entry as JSON."""
    try:
        entry = gym_repo.get_generator(generator_id)
    except KeyError:
        raise HTTPException(
            status_code=404, detail=f"Generator '{generator_id}' not found"
        ) from None
    return JSONResponse(_generator_to_dict(entry))


@generators_api_router.post("/", response_class=JSONResponse, status_code=201)
async def api_create_generator(
    request: Request,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Create a new Generator Library entry from JSON body."""
    body = await request.json()
    generator_id = body.get("generator_id", "")
    if not generator_id:
        raise HTTPException(status_code=400, detail="generator_id must not be empty")
    stochasticity = body.get("stochasticity", "stochastic")
    mechanism = body.get("mechanism", "llm_pydantic")
    if stochasticity not in VALID_STOCHASTICITY:
        raise HTTPException(
            status_code=400,
            detail=f"stochasticity must be one of {sorted(VALID_STOCHASTICITY)}",
        )
    if mechanism not in VALID_MECHANISMS:
        raise HTTPException(
            status_code=400,
            detail=f"mechanism must be one of {sorted(VALID_MECHANISMS)}",
        )

    entry = GeneratorLibraryEntry(
        generator_id=generator_id,
        class_name=body.get("class_name", ""),
        name=body.get("name", ""),
        description=body.get("description", ""),
        domain=body.get("domain", "core"),
        output_type=body.get("output_type", ""),
        mechanism=mechanism,
        stochasticity=stochasticity,
        language=body.get("language"),
        requires_runtime=tuple(body.get("requires_runtime", [])),
        parameter_schema=body.get("parameter_schema", {}),
        tags=tuple(body.get("tags", [])),
        example_config=body.get("example_config", {}),
        notes=body.get("notes", ""),
    )
    gym_repo.save_generator(entry)
    return JSONResponse(_generator_to_dict(entry), status_code=201)


@generators_api_router.put("/{generator_id}", response_class=JSONResponse)
async def api_update_generator(
    generator_id: str,
    request: Request,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Update a Generator Library entry from JSON body."""
    try:
        existing = gym_repo.get_generator(generator_id)
    except KeyError:
        raise HTTPException(
            status_code=404, detail=f"Generator '{generator_id}' not found"
        ) from None

    body = await request.json()
    stochasticity = body.get("stochasticity", existing.stochasticity)
    mechanism = body.get("mechanism", existing.mechanism)
    if stochasticity not in VALID_STOCHASTICITY:
        raise HTTPException(
            status_code=400,
            detail=f"stochasticity must be one of {sorted(VALID_STOCHASTICITY)}",
        )
    if mechanism not in VALID_MECHANISMS:
        raise HTTPException(
            status_code=400,
            detail=f"mechanism must be one of {sorted(VALID_MECHANISMS)}",
        )

    updated = replace(
        existing,
        class_name=body.get("class_name", existing.class_name),
        name=body.get("name", existing.name),
        description=body.get("description", existing.description),
        domain=body.get("domain", existing.domain),
        output_type=body.get("output_type", existing.output_type),
        mechanism=mechanism,
        stochasticity=stochasticity,
        language=body.get("language", existing.language),
        requires_runtime=tuple(
            body.get("requires_runtime", list(existing.requires_runtime))
        ),
        parameter_schema=body.get("parameter_schema", existing.parameter_schema),
        tags=tuple(body.get("tags", list(existing.tags))),
        example_config=body.get("example_config", existing.example_config),
        notes=body.get("notes", existing.notes),
    )
    gym_repo.save_generator(updated)
    return JSONResponse(_generator_to_dict(updated))


@generators_api_router.delete("/{generator_id}", status_code=204)
async def api_delete_generator(
    generator_id: str,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> None:
    """Delete a Generator Library entry."""
    try:
        gym_repo.delete_generator(generator_id)
    except KeyError:
        raise HTTPException(
            status_code=404, detail=f"Generator '{generator_id}' not found"
        ) from None
