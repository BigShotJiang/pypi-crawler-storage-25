"""DB-backed workflow routes — read-only views, editor, and run submission."""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import replace
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request, UploadFile
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from atomicguard.domain.interfaces import (
    APContextRepositoryInterface,
    GymRepositoryInterface,
    PolicyRepositoryInterface,
    WorkflowRepositoryInterface,
)
from atomicguard.domain.models import (
    ActionPairDefinition,
    APContextEntry,
    WorkflowDefinition,
)

from ..dependencies import (
    get_ap_context_repo,
    get_gym_repo,
    get_policy_repo,
    get_workflow_repo,
)
from ..utils import slugify

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/workflows", tags=["workflows"])


def _ctx(request: Request) -> dict[str, Any]:
    """Base template context."""
    return {
        "request": request,
        "config_loader": request.app.state.config_loader,
        "nav_active": "workflows",
    }


def _build_ap_context_dict(
    ctx_repo: APContextRepositoryInterface,
) -> dict[str, dict[str, str]]:
    """Build ap_context dict from DB for graph extraction."""
    ap_context_dict: dict[str, dict[str, str]] = {}
    try:
        all_contexts = ctx_repo.list_contexts()
        for ap_id, entry in all_contexts.items():
            ap_context_dict[ap_id] = {
                "role": entry.role,
                "task": entry.task,
                "constraints": entry.constraints,
                "feedback_wrapper": entry.feedback_wrapper,
                "escalation_feedback_wrapper": entry.escalation_feedback_wrapper,
                "artifact_context": entry.artifact_context,
            }
    except RuntimeError:
        logger.debug("AP context repository not available, returning empty dict")
    return ap_context_dict


def _detect_cycle(
    ap_id: str,
    requires: list[str],
    all_aps: dict[str, list[str]],
) -> bool:
    """Return True if adding requires to ap_id would create a cycle."""
    visited: set[str] = set()

    def _dfs(current: str) -> bool:
        if current == ap_id:
            return True
        if current in visited:
            return False
        visited.add(current)
        return any(_dfs(dep) for dep in all_aps.get(current, []))

    return any(_dfs(req) for req in requires)


# ─── Read-Only Routes ───────────────────────────────────────


@router.get("/", response_class=HTMLResponse)
async def workflow_list(
    request: Request,
    q: str = "",
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """List all workflows from the database, with optional search filter."""
    workflows = repo.list_workflows()

    if q:
        q_lower = q.lower()
        workflows = [
            w
            for w in workflows
            if q_lower in w.name.lower()
            or q_lower in w.slug.lower()
            or q_lower in (w.description or "").lower()
        ]

    workflows.sort(key=lambda w: w.name.lower())

    templates = request.app.state.templates

    if request.headers.get("HX-Request"):
        return templates.TemplateResponse(
            "partials/workflow_cards.html",
            {**_ctx(request), "workflows": workflows, "q": q},
        )

    return templates.TemplateResponse(
        "workflow_list.html",
        {**_ctx(request), "workflows": workflows, "q": q},
    )


@router.get("/compare", response_class=HTMLResponse)
async def workflow_compare(
    request: Request,
    left: str = "",
    right: str = "",
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
    ctx_repo: APContextRepositoryInterface = Depends(get_ap_context_repo),
) -> HTMLResponse:
    """Side-by-side workflow comparison view."""
    from atomicguard.visualization.workflow_config_exporter import (
        _extract_ap_context,
        _extract_graph,
    )

    workflows = repo.list_workflows()

    left_data: dict[str, Any] | None = None
    right_data: dict[str, Any] | None = None
    ap_context_dict = _build_ap_context_dict(ctx_repo)

    for side_slug, label in [(left, "left"), (right, "right")]:
        if not side_slug:
            continue
        try:
            wf_json = repo.export_to_json(side_slug)
            nodes, edges = _extract_graph(wf_json)
            prompt_data = _extract_ap_context(wf_json, ap_context_dict)
            data = {
                "slug": side_slug,
                "name": wf_json.get("name", side_slug),
                "nodes_json": json.dumps(nodes),
                "edges_json": json.dumps(edges),
                "prompts_json": json.dumps(prompt_data),
                "ap_count": len(wf_json.get("action_pairs", {})),
                "rmax": wf_json.get("rmax", 3),
                "model": wf_json.get("model", ""),
            }
            if label == "left":
                left_data = data
            else:
                right_data = data
        except KeyError:
            logger.warning("Workflow %s not found for comparison", side_slug)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "workflow_compare.html",
        {
            **_ctx(request),
            "breadcrumbs": [("Workflows", "/workflows/"), ("Compare", "")],
            "workflows": workflows,
            "left_slug": left,
            "right_slug": right,
            "left": left_data,
            "right": right_data,
        },
    )


@router.get("/{slug}/", response_class=HTMLResponse)
async def workflow_detail(
    request: Request,
    slug: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
    ctx_repo: APContextRepositoryInterface = Depends(get_ap_context_repo),
) -> HTMLResponse:
    """WorkflowOrchestrator detail with Cytoscape topology viewer, backed by DB."""
    from atomicguard.visualization.workflow_config_exporter import (
        _extract_ap_context,
        _extract_graph,
    )

    try:
        workflow_json = repo.export_to_json(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{slug}' not found"
        ) from exc

    ap_context_dict = _build_ap_context_dict(ctx_repo)
    nodes, edges = _extract_graph(workflow_json)
    prompt_data = _extract_ap_context(workflow_json, ap_context_dict)

    wf_name = workflow_json.get("name", slug)
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "workflow_detail.html",
        {
            **_ctx(request),
            "breadcrumbs": [("Workflows", "/workflows/"), (wf_name, "")],
            "slug": slug,
            "workflow": workflow_json,
            "nodes_json": json.dumps(nodes),
            "edges_json": json.dumps(edges),
            "prompts_json": json.dumps(prompt_data),
        },
    )


# ─── Run Submission ─────────────────────────────────────────


@router.post("/{slug}/run", response_model=None)
async def workflow_run(
    request: Request,
    slug: str,
    specification: str = Form(...),
    model: str = Form(...),
    provider: str = Form(...),
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
    ctx_repo: APContextRepositoryInterface = Depends(get_ap_context_repo),
) -> RedirectResponse | HTMLResponse:
    """Submit a workflow run to the job queue.

    Creates a RunJob from the workflow definition + AP context and
    submits it to ``app.state.job_queue``.  Redirects to the run
    detail page on success.
    """
    queue = getattr(request.app.state, "job_queue", None)
    if queue is None:
        raise HTTPException(
            status_code=503,
            detail="Job queue not configured. Start the server with --queue-db.",
        )

    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{slug}' not found"
        ) from exc

    # Build AP context from DB
    all_contexts = ctx_repo.list_contexts()
    ap_context: dict[str, APContextEntry] = {}
    for ap_def in workflow.action_pairs:
        if ap_def.ap_id in all_contexts:
            ap_context[ap_def.ap_id] = all_contexts[ap_def.ap_id]
        else:
            ap_context[ap_def.ap_id] = APContextEntry(ap_id=ap_def.ap_id)

    from atomicguard.domain.runner import RunJob

    job = RunJob(
        job_id=str(uuid.uuid4()),
        workflow_definition=workflow,
        ap_context=ap_context,
        specification=specification.strip(),
        model=model.strip(),
        provider=provider.strip(),
    )
    queue.submit(job)

    logger.info("Job %s submitted for workflow %s", job.job_id, slug)

    if request.headers.get("HX-Request"):
        return HTMLResponse(
            content="",
            status_code=200,
            headers={"HX-Redirect": f"/runs/{job.job_id}/"},
        )
    return RedirectResponse(f"/runs/{job.job_id}/", status_code=303)


# ─── Editor Routes ──────────────────────────────────────────


def _load_greedy_ordering_from_provenance(
    slug: str, policy_repo: PolicyRepositoryInterface
) -> list[str]:
    """Resolve checkpoint path from policy slug, extract greedy ordering."""
    from pathlib import Path

    from ..policy_loader import extract_greedy_ordering as _extract_greedy

    try:
        policy = policy_repo.get_policy_by_slug(slug)
        return _extract_greedy(Path(policy.path))
    except Exception:
        return []


@router.get("/{slug}/edit", response_class=HTMLResponse)
async def workflow_edit(
    request: Request,
    slug: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
    ctx_repo: APContextRepositoryInterface = Depends(get_ap_context_repo),
    policy_repo: PolicyRepositoryInterface = Depends(get_policy_repo),
) -> HTMLResponse:
    """WorkflowOrchestrator editor with interactive Cytoscape and HTMX sidebar forms."""
    from atomicguard.visualization.workflow_config_exporter import (
        _extract_ap_context,
        _extract_graph,
    )

    try:
        workflow = repo.get_workflow(slug)
        workflow_json = repo.export_to_json(slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Workflow '{slug}' not found"
        ) from exc

    ap_context_dict = _build_ap_context_dict(ctx_repo)
    nodes, edges = _extract_graph(workflow_json)
    prompt_data = _extract_ap_context(workflow_json, ap_context_dict)

    # Load greedy ordering for RL-exported workflows
    greedy_ordering: list[str] = []
    if workflow.source_policy_slug:
        greedy_ordering = _load_greedy_ordering_from_provenance(
            workflow.source_policy_slug, policy_repo
        )

    # Per-edge provenance: set of (source, target) pairs from policy export
    policy_derived_edges = {(src, tgt) for src, tgt in workflow.policy_derived_requires}

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "workflow_editor.html",
        {
            **_ctx(request),
            "slug": slug,
            "workflow": workflow,
            "workflow_json": workflow_json,
            "nodes_json": json.dumps(nodes),
            "edges_json": json.dumps(edges),
            "prompts_json": json.dumps(prompt_data),
            "ap_context_dict": ap_context_dict,
            "greedy_ordering": greedy_ordering,
            "policy_derived_edges": json.dumps(list(policy_derived_edges)),
        },
    )


# ─── WorkflowOrchestrator CRUD ──────────────────────────────────────────


@router.put("/{slug}/meta", response_class=HTMLResponse)
async def workflow_update_meta(
    request: Request,
    slug: str,
    name: str = Form(...),
    description: str = Form(""),
    model: str = Form(""),
    provider: str = Form(""),
    rmax: int = Form(3),
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Update workflow metadata (name, description, model, etc.)."""
    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    updated = replace(
        workflow,
        name=name.strip(),
        description=description.strip(),
        model=model.strip(),
        provider=provider.strip(),
        rmax=rmax,
    )
    repo.save_workflow(updated)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/workflow_meta_form.html",
        {**_ctx(request), "slug": slug, "workflow": updated, "saved": True},
    )


@router.post("/{slug}/clone")
async def workflow_clone(
    slug: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> RedirectResponse:
    """Clone a workflow with a new slug."""
    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    new_name = f"{workflow.name} (copy)"
    new_slug = slugify(new_name)

    # Ensure unique slug
    existing_slugs = {w.slug for w in repo.list_workflows()}
    counter = 2
    base_slug = new_slug
    while new_slug in existing_slugs:
        new_slug = f"{base_slug}-{counter}"
        counter += 1

    cloned = replace(workflow, slug=new_slug, name=new_name)
    repo.save_workflow(cloned)
    return RedirectResponse(f"/workflows/{new_slug}/edit", status_code=303)


@router.delete("/{slug}/")
async def workflow_delete(
    slug: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Delete a workflow. Returns HTMX redirect."""
    try:
        repo.delete_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": "/workflows/"},
    )


@router.get("/{slug}/export")
async def workflow_export(
    slug: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> JSONResponse:
    """Export workflow as JSON file download."""
    try:
        workflow_json = repo.export_to_json(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    return JSONResponse(
        content=workflow_json,
        headers={
            "Content-Disposition": f'attachment; filename="{slug}.json"',
        },
    )


@router.post("/new", response_model=None)
async def workflow_new(
    request: Request,
    name: str = Form(...),
    description: str = Form(""),
    model: str = Form(""),
    provider: str = Form(""),
    rmax: int = Form(3),
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> RedirectResponse | HTMLResponse:
    """Create a new empty workflow and redirect to the editor."""
    name = name.strip()
    if not name:
        raise HTTPException(status_code=400, detail="Name is required")

    slug = slugify(name)
    existing_slugs = {w.slug for w in repo.list_workflows()}
    counter = 2
    base_slug = slug
    while slug in existing_slugs:
        slug = f"{base_slug}-{counter}"
        counter += 1

    workflow = WorkflowDefinition(
        slug=slug,
        name=name,
        description=description.strip(),
        model=model.strip(),
        provider=provider.strip(),
        rmax=rmax,
    )
    repo.save_workflow(workflow)

    if request.headers.get("HX-Request"):
        return HTMLResponse(
            content="",
            status_code=200,
            headers={"HX-Redirect": f"/workflows/{slug}/edit"},
        )
    return RedirectResponse(f"/workflows/{slug}/edit", status_code=303)


@router.post("/import", response_model=None)
async def workflow_import(
    request: Request,
    file: UploadFile,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> RedirectResponse | HTMLResponse:
    """Import a workflow from a JSON file upload."""
    content = await file.read()
    try:
        data = json.loads(content)
    except json.JSONDecodeError as exc:
        raise HTTPException(status_code=400, detail="Invalid JSON") from exc

    slug = repo.import_from_json(data)

    if request.headers.get("HX-Request"):
        return HTMLResponse(
            content="",
            status_code=200,
            headers={"HX-Redirect": f"/workflows/{slug}/edit"},
        )

    return RedirectResponse(f"/workflows/{slug}/edit", status_code=303)


# ─── Action Pair CRUD ───────────────────────────────────────


@router.get("/{slug}/aps/{ap_id}/form", response_class=HTMLResponse)
async def ap_form_get(
    request: Request,
    slug: str,
    ap_id: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Return AP edit form as an HTMX partial."""
    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    ap = None
    for a in workflow.action_pairs:
        if a.ap_id == ap_id:
            ap = a
            break

    if ap is None:
        raise HTTPException(status_code=404, detail=f"AP '{ap_id}' not found")

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/ap_form.html",
        {
            **_ctx(request),
            "slug": slug,
            "ap": ap,
            "all_ap_ids": [a.ap_id for a in workflow.action_pairs],
        },
    )


@router.post("/{slug}/aps/", response_model=None)
async def ap_add(
    request: Request,
    slug: str,
    ap_id: str = Form(...),
    generator: str = Form(""),
    guard: str = Form("syntax"),
    guards_raw: str = Form(""),
    description: str = Form(""),
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse | JSONResponse:
    """Add a new action pair to a workflow."""
    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    ap_id = ap_id.strip()
    if not ap_id:
        raise HTTPException(status_code=400, detail="AP ID is required")

    existing_ids = {ap.ap_id for ap in workflow.action_pairs}
    if ap_id in existing_ids:
        raise HTTPException(status_code=400, detail=f"AP '{ap_id}' already exists")

    # Pre-fill from catalogue defaults when form fields are empty
    catalogue_guards: list[str] | None = None
    catalogue_guard = guard
    try:
        catalogue_entry = gym_repo.get_action_pair(ap_id)
        if not generator:
            generator = catalogue_entry.generator
        if not description:
            description = catalogue_entry.description
        # Pre-fill guard stack from catalogue
        if catalogue_entry.guards and len(catalogue_entry.guards) > 1:
            # Catalogue has a composite guard stack — use it unless form overrides
            catalogue_guards = list(catalogue_entry.guards)
            catalogue_guard = "composite"
        elif guard == "syntax" and catalogue_entry.guard:
            catalogue_guard = catalogue_entry.guard
    except KeyError:
        logger.debug("AP '%s' not in catalogue — using form values as-is", ap_id)

    # guards_raw from form takes priority over catalogue
    if guards_raw.strip():
        parsed_guards = [g.strip() for g in guards_raw.split(",") if g.strip()]
        if len(parsed_guards) == 1:
            # Single guard — no need for composite wrapper
            final_guards = None
            final_guard = parsed_guards[0]
        else:
            final_guards = parsed_guards
            final_guard = "composite"
    elif catalogue_guards:
        final_guards = catalogue_guards
        final_guard = catalogue_guard
    else:
        final_guards = None
        final_guard = catalogue_guard

    new_ap = ActionPairDefinition(
        ap_id=ap_id,
        generator=generator.strip(),
        guard=final_guard,
        guards=final_guards,
        description=description.strip(),
    )
    updated = replace(
        workflow,
        action_pairs=workflow.action_pairs + (new_ap,),
    )
    repo.save_workflow(updated)

    if request.headers.get("HX-Request"):
        return JSONResponse(
            content={
                "ap_id": new_ap.ap_id,
                "generator": new_ap.generator,
                "guard": new_ap.guard,
                "guards": list(new_ap.guards) if new_ap.guards else None,
                "description": new_ap.description,
            },
            headers={"HX-Trigger": "apCreated"},
        )

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/workflows/{slug}/edit"},
    )


@router.put("/{slug}/aps/{ap_id}", response_class=HTMLResponse)
async def ap_update(
    request: Request,
    slug: str,
    ap_id: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Update an action pair's properties."""
    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    form = await request.form()

    # Find the AP to update
    ap_index = None
    for i, ap in enumerate(workflow.action_pairs):
        if ap.ap_id == ap_id:
            ap_index = i
            break

    if ap_index is None:
        raise HTTPException(status_code=404, detail=f"AP '{ap_id}' not found")

    old_ap = workflow.action_pairs[ap_index]

    # Parse requires from comma-separated string
    requires_str = str(form.get("requires", "")).strip()
    requires = tuple(r.strip() for r in requires_str.split(",") if r.strip())

    # Parse escalation targets
    escalate_str = str(form.get("escalate_feedback_to", "")).strip()
    escalate_to = tuple(e.strip() for e in escalate_str.split(",") if e.strip())

    # Cycle detection for requires
    all_aps_deps = {ap.ap_id: list(ap.requires) for ap in workflow.action_pairs}
    all_aps_deps[ap_id] = list(requires)
    if _detect_cycle(ap_id, list(requires), all_aps_deps):
        raise HTTPException(
            status_code=400,
            detail=f"Adding requires {requires} to '{ap_id}' would create a cycle",
        )

    # Parse composite guards from guards_raw field
    guards_raw_str = str(form.get("guards_raw", "")).strip()
    guards = None
    guard_val = str(form.get("guard", old_ap.guard)).strip()
    if guards_raw_str:
        guards = [g.strip() for g in guards_raw_str.split(",") if g.strip()]
        guard_val = "composite"

    updated_ap = replace(
        old_ap,
        generator=str(form.get("generator", old_ap.generator)).strip(),
        guard=guard_val,
        guards=guards if guards else old_ap.guards,
        description=str(form.get("description", old_ap.description)).strip(),
        r_patience=int(str(form["r_patience"])) if form.get("r_patience") else None,
        e_max=int(str(form.get("e_max", old_ap.e_max))),
        requires=requires,
        escalate_feedback_to=escalate_to,
        goal=form.get("goal") == "on",
    )

    aps = list(workflow.action_pairs)
    aps[ap_index] = updated_ap
    updated_workflow = replace(workflow, action_pairs=tuple(aps))
    repo.save_workflow(updated_workflow)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/ap_form.html",
        {
            **_ctx(request),
            "slug": slug,
            "ap": updated_ap,
            "all_ap_ids": [a.ap_id for a in updated_workflow.action_pairs],
            "saved": True,
        },
    )


@router.delete("/{slug}/aps/{ap_id}", response_class=HTMLResponse)
async def ap_delete(
    slug: str,
    ap_id: str,
    repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Remove an action pair from a workflow."""
    try:
        workflow = repo.get_workflow(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404) from exc

    aps = [ap for ap in workflow.action_pairs if ap.ap_id != ap_id]
    if len(aps) == len(workflow.action_pairs):
        raise HTTPException(status_code=404, detail=f"AP '{ap_id}' not found")

    updated = replace(workflow, action_pairs=tuple(aps))
    repo.save_workflow(updated)

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/workflows/{slug}/edit"},
    )


# ─── AP Context CRUD ────────────────────────────────────────


@router.get("/api/context/{ap_id}/form", response_class=HTMLResponse)
async def ap_context_form(
    request: Request,
    ap_id: str,
    ctx_repo: APContextRepositoryInterface = Depends(get_ap_context_repo),
) -> HTMLResponse:
    """Return the AP context edit form as an HTMX partial."""
    try:
        entry = ctx_repo.get_context(ap_id)
    except KeyError:
        entry = APContextEntry(ap_id=ap_id)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/ap_context_form.html",
        {**_ctx(request), "entry": entry, "ap_id": ap_id},
    )


@router.put("/api/context/{ap_id}", response_class=HTMLResponse)
async def ap_context_update(
    request: Request,
    ap_id: str,
    role: str = Form(""),
    task: str = Form(""),
    constraints: str = Form(""),
    feedback_wrapper: str = Form(""),
    escalation_feedback_wrapper: str = Form(""),
    artifact_context: str = Form(""),
    ctx_repo: APContextRepositoryInterface = Depends(get_ap_context_repo),
) -> HTMLResponse:
    """Update AP context."""
    entry = APContextEntry(
        ap_id=ap_id,
        role=role.strip(),
        task=task.strip(),
        constraints=constraints.strip(),
        feedback_wrapper=feedback_wrapper.strip(),
        escalation_feedback_wrapper=escalation_feedback_wrapper.strip(),
        artifact_context=artifact_context.strip(),
    )
    ctx_repo.save_context(entry)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/ap_context_form.html",
        {**_ctx(request), "entry": entry, "ap_id": ap_id, "saved": True},
    )
