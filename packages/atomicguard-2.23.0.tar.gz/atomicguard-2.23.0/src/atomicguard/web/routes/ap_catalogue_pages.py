"""Routes for the AP Catalogue — global source of truth for AP definitions."""

from __future__ import annotations

import json
import logging
from dataclasses import replace
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

from atomicguard.domain.interfaces import (
    GymRepositoryInterface,
    WorkflowRepositoryInterface,
)
from atomicguard.domain.models import APCatalogueEntry

from ..dependencies import get_gym_repo, get_workflow_repo

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/aps", tags=["ap-catalogue"])


def _load_valid_domains_from_schema() -> frozenset[str]:
    """Read valid domain values from ap_catalogue.schema.json at module load time."""
    schema_path = (
        Path(__file__).resolve().parents[2] / "schemas" / "ap_catalogue.schema.json"
    )
    try:
        schema = json.loads(schema_path.read_text())
        domains = schema["$defs"]["APCatalogueEntry"]["properties"]["domain"]["enum"]
        return frozenset(domains)
    except (FileNotFoundError, KeyError, json.JSONDecodeError):
        logger.warning("Failed to read domains from schema, using fallback")
        return frozenset({"generic", "django", "precommit"})


VALID_DOMAINS = _load_valid_domains_from_schema()
VALID_STOCHASTICITY = frozenset({"deterministic", "stochastic"})


def _validate_ap_entry(ap_id: str, domain: str, stochasticity: str) -> list[str]:
    """Validate AP entry fields. Returns list of error messages."""
    errors: list[str] = []
    if not ap_id or not ap_id.strip():
        errors.append("ap_id must not be empty")
    if domain and domain not in VALID_DOMAINS:
        errors.append(f"domain must be one of {sorted(VALID_DOMAINS)}, got '{domain}'")
    if stochasticity and stochasticity not in VALID_STOCHASTICITY:
        errors.append(
            f"stochasticity must be one of {sorted(VALID_STOCHASTICITY)}, got '{stochasticity}'"
        )
    return errors


def _ap_to_dict(entry: APCatalogueEntry) -> dict[str, Any]:
    """Serialize an APCatalogueEntry to a JSON-friendly dict."""
    return {
        "ap_id": entry.ap_id,
        "name": entry.name,
        "description": entry.description,
        "generator": entry.generator,
        "generator_config": entry.generator_config,
        "guard": entry.guard,
        "guards": list(entry.guards),
        "guard_config": entry.guard_config,
        "domain": entry.domain,
        "language": entry.language,
        "stochasticity": entry.stochasticity,
        "artifact_type": entry.artifact_type,
        "tags": list(entry.tags),
        "typical_requires": list(entry.typical_requires),
        "typical_consumers": list(entry.typical_consumers),
        "default_role": entry.default_role,
        "default_task": entry.default_task,
        "default_constraints": entry.default_constraints,
        "default_feedback_wrapper": entry.default_feedback_wrapper,
        "default_escalation_feedback_wrapper": entry.default_escalation_feedback_wrapper,
    }


def _ctx(request: Request) -> dict[str, Any]:
    return {
        "request": request,
        "nav_active": "ap_catalogue",
    }


# ─── List ──────────────────────────────────────────────────


@router.get("/", response_class=HTMLResponse)
async def ap_catalogue_list(
    request: Request,
    domain: str = "",
    language: str = "",
    stochasticity: str = "",
    search: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """AP Catalogue list page with filters."""
    all_entries = gym_repo.list_all_action_pairs()
    entries = list(all_entries)

    if domain:
        entries = [e for e in entries if e.domain == domain]
    if language:
        entries = [e for e in entries if e.language == language]
    if stochasticity:
        entries = [e for e in entries if e.stochasticity == stochasticity]
    if search:
        q = search.lower()
        entries = [
            e
            for e in entries
            if q in e.ap_id.lower() or q in e.name.lower() or q in e.description.lower()
        ]

    templates = request.app.state.templates
    ctx = {
        **_ctx(request),
        "entries": entries,
        "filters": {
            "domain": domain,
            "language": language,
            "stochasticity": stochasticity,
            "search": search,
        },
        "domains": sorted({e.domain for e in all_entries}),
        "languages": sorted({e.language for e in all_entries if e.language}),
    }

    if request.headers.get("HX-Request"):
        return templates.TemplateResponse("partials/ap_catalogue_table.html", ctx)

    return templates.TemplateResponse("ap_catalogue.html", ctx)


# ─── Detail ────────────────────────────────────────────────


@router.get("/{ap_id}/", response_class=HTMLResponse)
async def ap_catalogue_detail(
    request: Request,
    ap_id: str,
    edit: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
    wf_repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """AP Catalogue detail/edit page."""
    try:
        entry = gym_repo.get_action_pair(ap_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"AP '{ap_id}' not found") from exc

    # Workflows referencing this AP
    all_workflows = wf_repo.list_workflows()
    referencing_workflows = []
    for w in all_workflows:
        try:
            wf = wf_repo.get_workflow(w.slug)
            if any(ap.ap_id == ap_id for ap in wf.action_pairs):
                referencing_workflows.append(w)
        except KeyError:
            continue  # Workflow deleted between list and get

    # Gyms referencing this AP
    all_gyms = gym_repo.list_gyms()
    referencing_gyms = []
    for g in all_gyms:
        aps = gym_repo.get_action_pairs(g.slug)
        if any(a.ap_id == ap_id for a in aps):
            referencing_gyms.append(g)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "ap_catalogue_detail.html",
        {
            **_ctx(request),
            "entry": entry,
            "referencing_workflows": referencing_workflows,
            "referencing_gyms": referencing_gyms,
            "breadcrumbs": [("APs", "/aps/"), (entry.ap_id, "")],
            "edit_mode": edit == "1",
        },
    )


# ─── Create ────────────────────────────────────────────────


@router.post("/", response_class=HTMLResponse)
async def ap_catalogue_create(
    ap_id: str = Form(...),
    name: str = Form(""),
    description: str = Form(""),
    generator: str = Form(""),
    guard: str = Form(""),
    domain: str = Form("generic"),
    language: str = Form(""),
    stochasticity: str = Form("stochastic"),
    artifact_type: str = Form(""),
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Create a new AP catalogue entry."""
    errors = _validate_ap_entry(ap_id, domain, stochasticity)
    if errors:
        raise HTTPException(status_code=400, detail="; ".join(errors))

    entry = APCatalogueEntry(
        ap_id=ap_id,
        name=name,
        description=description,
        generator=generator,
        guard=guard,
        domain=domain,
        language=language or None,
        stochasticity=stochasticity,
        artifact_type=artifact_type,
    )
    gym_repo.save_action_pair(entry)
    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/aps/{ap_id}/"},
    )


# ─── Update ────────────────────────────────────────────────


@router.put("/{ap_id}/", response_class=HTMLResponse)
async def ap_catalogue_update(
    ap_id: str,
    name: str = Form(""),
    description: str = Form(""),
    generator: str = Form(""),
    guard: str = Form(""),
    guards_json: str = Form("[]"),
    domain: str = Form("generic"),
    language: str = Form(""),
    stochasticity: str = Form("stochastic"),
    artifact_type: str = Form(""),
    default_role: str = Form(""),
    default_task: str = Form(""),
    default_constraints: str = Form(""),
    default_feedback_wrapper: str = Form(""),
    default_escalation_feedback_wrapper: str = Form(""),
    tags: str = Form(""),
    guard_config_json: str = Form("{}"),
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Update an existing AP catalogue entry."""
    try:
        existing = gym_repo.get_action_pair(ap_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"AP '{ap_id}' not found") from exc

    try:
        guards_list = tuple(json.loads(guards_json))
    except Exception:
        guards_list = existing.guards

    try:
        guard_config = json.loads(guard_config_json)
        if not isinstance(guard_config, dict):
            guard_config = existing.guard_config
    except Exception:
        guard_config = existing.guard_config

    parsed_tags = tuple(t.strip() for t in tags.split(",") if t.strip())

    # Validate entry
    errors = _validate_ap_entry(ap_id, domain, stochasticity)
    if errors:
        raise HTTPException(status_code=400, detail="; ".join(errors))

    updated = replace(
        existing,
        name=name,
        description=description,
        generator=generator,
        guard=guard,
        guards=guards_list,
        guard_config=guard_config,
        domain=domain,
        language=language or None,
        stochasticity=stochasticity,
        artifact_type=artifact_type,
        tags=parsed_tags,
        default_role=default_role,
        default_task=default_task,
        default_constraints=default_constraints,
        default_feedback_wrapper=default_feedback_wrapper,
        default_escalation_feedback_wrapper=default_escalation_feedback_wrapper,
    )
    gym_repo.save_action_pair(updated)
    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/aps/{ap_id}/"},
    )


# ─── Delete ────────────────────────────────────────────────


@router.delete("/{ap_id}/", response_class=HTMLResponse)
async def ap_catalogue_delete(
    ap_id: str,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Delete an AP catalogue entry."""
    try:
        gym_repo.delete_action_pair(ap_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=f"AP '{ap_id}' not found") from exc
    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": "/aps/"},
    )


# ─── Bulk Delete ──────────────────────────────────────────


@router.post("/bulk-delete", response_model=None)
async def ap_catalogue_bulk_delete(
    request: Request,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> RedirectResponse | HTMLResponse:
    """Bulk delete AP catalogue entries."""
    form = await request.form()
    ap_ids = [str(v) for v in form.getlist("ap_ids")]
    for ap_id in ap_ids:
        try:
            gym_repo.delete_action_pair(ap_id)
        except KeyError:
            continue  # Skip already-deleted entries

    if request.headers.get("HX-Request"):
        # Return updated table partial instead of redirect
        all_entries = gym_repo.list_all_action_pairs()
        entries = list(all_entries)
        templates = request.app.state.templates
        return templates.TemplateResponse(
            "partials/ap_catalogue_table.html",
            {
                **_ctx(request),
                "entries": entries,
                "filters": {
                    "domain": "",
                    "language": "",
                    "stochasticity": "",
                    "search": "",
                },
            },
        )

    return RedirectResponse(url="/aps/", status_code=303)


# ─── Seed Import ──────────────────────────────────────────


@router.post("/import-seed", response_class=HTMLResponse)
async def ap_catalogue_import_seed(
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Import APs from the seed catalogue JSON."""
    seed_path = Path(__file__).resolve().parents[2] / "schemas" / "ap_catalogue.json"
    if not seed_path.exists():
        raise HTTPException(status_code=404, detail="Seed file not found")

    data = json.loads(seed_path.read_text())
    for ap_id, fields in data.items():
        entry = APCatalogueEntry(
            ap_id=ap_id,
            name=fields.get("name", ""),
            description=fields.get("description", ""),
            generator=fields.get("generator", ""),
            guard=fields.get("guard", ""),
            domain=fields.get("domain", "generic"),
            language=fields.get("language"),
            stochasticity=fields.get("stochasticity", "stochastic"),
            artifact_type=fields.get("artifact_type", ""),
            tags=tuple(fields.get("tags", [])),
            typical_requires=tuple(fields.get("typical_requires", [])),
            typical_consumers=tuple(fields.get("typical_consumers", [])),
        )
        gym_repo.save_action_pair(entry)

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": "/aps/"},
    )


# ─── API Lookup ───────────────────────────────────────────


@router.get("/api/lookup", response_class=JSONResponse)
async def ap_lookup(
    ap_id: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Lightweight JSON lookup for AP catalogue defaults."""
    try:
        entry = gym_repo.get_action_pair(ap_id)
        return JSONResponse(
            {
                "found": True,
                "generator": entry.generator,
                "guard": entry.guard,
                "description": entry.description,
            }
        )
    except KeyError:
        return JSONResponse({"found": False})


# ─── REST API ────────────────────────────────────────────


api_router = APIRouter(prefix="/api/aps", tags=["ap-catalogue-api"])


@api_router.get("/", response_class=JSONResponse)
async def api_list_aps(
    domain: str = "",
    language: str = "",
    stochasticity: str = "",
    search: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """List all AP catalogue entries as JSON."""
    entries = list(gym_repo.list_all_action_pairs())
    if domain:
        entries = [e for e in entries if e.domain == domain]
    if language:
        entries = [e for e in entries if e.language == language]
    if stochasticity:
        entries = [e for e in entries if e.stochasticity == stochasticity]
    if search:
        q = search.lower()
        entries = [
            e
            for e in entries
            if q in e.ap_id.lower() or q in e.name.lower() or q in e.description.lower()
        ]
    return JSONResponse([_ap_to_dict(e) for e in entries])


@api_router.get("/lookup", response_class=JSONResponse)
async def api_lookup_ap(
    ap_id: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Lightweight JSON lookup for AP catalogue defaults.

    Used by the workflow editor JS to pre-fill the Add AP dialog from
    the catalogue when a known AP ID is typed.
    """
    try:
        entry = gym_repo.get_action_pair(ap_id)
        return JSONResponse(
            {
                "found": True,
                "generator": entry.generator,
                "guard": entry.guard,
                "guards": list(entry.guards),
                "description": entry.description,
            }
        )
    except KeyError:
        return JSONResponse({"found": False})


@api_router.get("/{ap_id}", response_class=JSONResponse)
async def api_get_ap(
    ap_id: str,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Get a single AP catalogue entry as JSON."""
    try:
        entry = gym_repo.get_action_pair(ap_id)
    except KeyError:
        raise HTTPException(status_code=404, detail=f"AP '{ap_id}' not found") from None
    return JSONResponse(_ap_to_dict(entry))


@api_router.post("/", response_class=JSONResponse, status_code=201)
async def api_create_ap(
    request: Request,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Create a new AP catalogue entry from JSON body."""
    body = await request.json()
    ap_id = body.get("ap_id", "")
    domain = body.get("domain", "generic")
    stochasticity = body.get("stochasticity", "stochastic")

    errors = _validate_ap_entry(ap_id, domain, stochasticity)
    if errors:
        raise HTTPException(status_code=400, detail="; ".join(errors))

    entry = APCatalogueEntry(
        ap_id=ap_id,
        name=body.get("name", ""),
        description=body.get("description", ""),
        generator=body.get("generator", ""),
        generator_config=body.get("generator_config", {}),
        guard=body.get("guard", ""),
        guards=tuple(body.get("guards", [])),
        guard_config=body.get("guard_config", {}),
        domain=domain,
        language=body.get("language"),
        stochasticity=stochasticity,
        artifact_type=body.get("artifact_type", ""),
        tags=tuple(body.get("tags", [])),
        typical_requires=tuple(body.get("typical_requires", [])),
        typical_consumers=tuple(body.get("typical_consumers", [])),
        default_role=body.get("default_role", ""),
        default_task=body.get("default_task", ""),
        default_constraints=body.get("default_constraints", ""),
        default_feedback_wrapper=body.get("default_feedback_wrapper", ""),
        default_escalation_feedback_wrapper=body.get(
            "default_escalation_feedback_wrapper", ""
        ),
    )
    gym_repo.save_action_pair(entry)
    return JSONResponse(_ap_to_dict(entry), status_code=201)


@api_router.put("/{ap_id}", response_class=JSONResponse)
async def api_update_ap(
    ap_id: str,
    request: Request,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Update an AP catalogue entry from JSON body."""
    try:
        existing = gym_repo.get_action_pair(ap_id)
    except KeyError:
        raise HTTPException(status_code=404, detail=f"AP '{ap_id}' not found") from None

    body = await request.json()
    domain = body.get("domain", existing.domain)
    stochasticity = body.get("stochasticity", existing.stochasticity)

    errors = _validate_ap_entry(ap_id, domain, stochasticity)
    if errors:
        raise HTTPException(status_code=400, detail="; ".join(errors))

    updated = replace(
        existing,
        name=body.get("name", existing.name),
        description=body.get("description", existing.description),
        generator=body.get("generator", existing.generator),
        generator_config=body.get("generator_config", existing.generator_config),
        guard=body.get("guard", existing.guard),
        guards=tuple(body.get("guards", list(existing.guards))),
        guard_config=body.get("guard_config", existing.guard_config),
        domain=domain,
        language=body.get("language", existing.language),
        stochasticity=stochasticity,
        artifact_type=body.get("artifact_type", existing.artifact_type),
        tags=tuple(body.get("tags", list(existing.tags))),
        typical_requires=tuple(
            body.get("typical_requires", list(existing.typical_requires))
        ),
        typical_consumers=tuple(
            body.get("typical_consumers", list(existing.typical_consumers))
        ),
        default_role=body.get("default_role", existing.default_role),
        default_task=body.get("default_task", existing.default_task),
        default_constraints=body.get(
            "default_constraints", existing.default_constraints
        ),
        default_feedback_wrapper=body.get(
            "default_feedback_wrapper", existing.default_feedback_wrapper
        ),
        default_escalation_feedback_wrapper=body.get(
            "default_escalation_feedback_wrapper",
            existing.default_escalation_feedback_wrapper,
        ),
    )
    gym_repo.save_action_pair(updated)
    return JSONResponse(_ap_to_dict(updated))


@api_router.get("/distinct/{field}", response_class=JSONResponse)
async def ap_distinct_values(
    field: str,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Return distinct non-empty values for a given field across all AP entries."""
    allowed = {"generator", "language", "artifact_type", "guard"}
    if field not in allowed:
        raise HTTPException(
            status_code=400, detail=f"Field must be one of {sorted(allowed)}"
        )
    entries = gym_repo.list_all_action_pairs()
    values = sorted({getattr(e, field, None) or "" for e in entries} - {""})
    return JSONResponse({"values": values})


@api_router.get("/tags", response_class=JSONResponse)
async def ap_tags(
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> JSONResponse:
    """Return all distinct tags used across AP entries."""
    entries = gym_repo.list_all_action_pairs()
    all_tags = sorted({t for e in entries for t in e.tags})
    return JSONResponse({"tags": all_tags})


@api_router.get("/tags/search", response_class=HTMLResponse)
async def ap_tags_search_html(
    request: Request,
    q: str = "",
    exclude: str = "",
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """Return tag autocomplete dropdown as an HTML fragment."""
    entries = gym_repo.list_all_action_pairs()
    all_tags = sorted({t for e in entries for t in e.tags})
    excluded = {t.strip() for t in exclude.split(",") if t.strip()}
    if q:
        ql = q.lower()
        tags = [t for t in all_tags if ql in t and t not in excluded]
    else:
        tags = [t for t in all_tags if t not in excluded]
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "partials/tag_autocomplete.html",
        {"request": request, "tags": tags[:8]},
    )


@api_router.delete("/{ap_id}", status_code=204)
async def api_delete_ap(
    ap_id: str,
    gym_repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> None:
    """Delete an AP catalogue entry."""
    try:
        gym_repo.delete_action_pair(ap_id)
    except KeyError:
        raise HTTPException(status_code=404, detail=f"AP '{ap_id}' not found") from None
