"""Training run management routes — list, detail, import, new, start."""

from __future__ import annotations

import datetime as dt
import json
import logging
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from atomicguard.domain.interfaces import (
    PolicyRepositoryInterface,
    TrainingRunRepositoryInterface,
    WorkflowRepositoryInterface,
)
from atomicguard.domain.models import TrainingRunRecord

from ..dependencies import get_policy_repo, get_training_repo, get_workflow_repo
from ..rl_loader import TrainingRun, discover_training_runs
from ..utils import slugify

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/training", tags=["training"])

AVAILABLE_REWARDS = ["sparse", "step", "efficiency", "potential-based", "maze"]
AVAILABLE_ARMS = [
    "singleshot",
    "s1_direct",
    "s1_tdd",
    "s1_tdd_verified",
    "s1_tdd_behavior",
    "s1_decomposed",
    "s1_decomposed_lite",
    "s1_tdd_review",
    "s1_tdd_review_backtrack",
    "s1_tdd_rule_backtrack",
    "adaptive_backtrack",
    "s1_tdd_eval",
    "s1_decomposed_lite_eval",
    "singleshot_eval",
]


def _now_iso() -> str:
    return dt.datetime.now(dt.UTC).isoformat()


def _ctx(request: Request) -> dict[str, Any]:
    return {
        "request": request,
        "config_loader": getattr(request.app.state, "config_loader", None),
        "nav_active": "training",
    }


def _fs_run_to_record(fs_run: TrainingRun) -> TrainingRunRecord:
    """Convert a filesystem-discovered TrainingRun to a TrainingRunRecord."""
    if fs_run.is_terminated:
        status = "terminated"
    elif fs_run.is_in_progress:
        status = "in_progress"
    else:
        status = "complete"

    return TrainingRunRecord(
        id=0,
        slug=fs_run.slug,
        display_name=fs_run.display_name,
        path=str(fs_run.path),
        model=fs_run.model or "",
        provider=fs_run.provider or "",
        arm=fs_run.arm or "",
        reward=fs_run.reward or "",
        episodes=fs_run.episodes,
        gamma=fs_run.gamma,
        alpha=fs_run.alpha,
        epsilon_initial=fs_run.epsilon_initial,
        epsilon_final=fs_run.epsilon_final,
        epsilon_decay=fs_run.epsilon_decay,
        instances=fs_run.instances,
        language=fs_run.language,
        training_mean_reward=fs_run.training_mean_reward,
        eval_mean_reward=fs_run.eval_mean_reward,
        eval_success_rate=fs_run.eval_success_rate,
        ap_ids=tuple(fs_run.ap_ids),
        status=status,
        completed_episodes=fs_run.completed_episodes,
        created_at=fs_run.modified_at.isoformat() if fs_run.modified_at else "",
        updated_at=fs_run.modified_at.isoformat() if fs_run.modified_at else "",
    )


def _merge_filesystem_runs(
    db_runs: list[TrainingRunRecord],
    output_dir: Any,
    status_filter: str | None = None,
) -> list[TrainingRunRecord]:
    """Merge filesystem-discovered runs that are missing from the DB."""
    from pathlib import Path

    if not output_dir:
        return db_runs

    try:
        fs_runs = discover_training_runs(Path(output_dir))
    except Exception:
        logger.debug("Failed to discover filesystem training runs", exc_info=True)
        return db_runs

    db_slugs = {r.slug for r in db_runs}
    merged = list(db_runs)

    for fs_run in fs_runs:
        if fs_run.slug in db_slugs:
            continue
        record = _fs_run_to_record(fs_run)
        if status_filter and record.status != status_filter:
            continue
        merged.append(record)

    return merged


# ─── List ──────────────────────────────────────────────────


@router.get("/", response_class=HTMLResponse)
async def training_list(
    request: Request,
    status: str = "",
    repo: TrainingRunRepositoryInterface = Depends(get_training_repo),
) -> HTMLResponse:
    """List training runs with optional status filter."""
    runs = repo.list_runs(status=status or None, limit=100)

    # Merge filesystem-discovered runs not yet imported into the DB
    output_dir = getattr(request.app.state, "output_dir", None)
    runs = _merge_filesystem_runs(runs, output_dir, status_filter=status or None)

    # Sort by most recent first (created_at is ISO 8601, so string sort works)
    runs.sort(key=lambda r: r.created_at or "", reverse=True)

    templates = request.app.state.templates
    ctx = {
        **_ctx(request),
        "runs": runs,
        "status_filter": status,
    }
    if request.headers.get("HX-Request"):
        return templates.TemplateResponse("partials/training_cards.html", ctx)
    return templates.TemplateResponse("training_list.html", ctx)


# ─── Detail ────────────────────────────────────────────────


def _find_fs_run(request: Request, slug: str) -> TrainingRun | None:
    """Look up a TrainingRun view model by slug via filesystem discovery."""
    output_dir = getattr(request.app.state, "output_dir", None)
    if not output_dir:
        return None
    try:
        fs_runs = discover_training_runs(output_dir)
    except Exception:
        return None
    return next((r for r in fs_runs if r.slug == slug), None)


@router.get("/{slug}/", response_class=HTMLResponse)
async def training_detail(
    request: Request,
    slug: str,
    policy_repo: PolicyRepositoryInterface = Depends(get_policy_repo),
    wf_repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Training run detail with charts, episode log, and Q-table heatmaps.

    Uses the filesystem TrainingRun view model (web layer) as the primary
    data source — it has computed properties the template needs
    (reward_description, mean_reward_so_far, episode_log, checkpoints).
    The DB is only consulted for supplementary data (linked policies).
    """
    from ..rl_loader import load_policy_info

    run = _find_fs_run(request, slug)
    if run is None:
        raise HTTPException(status_code=404, detail="Training run not found")

    # Load policy data for Q-table heatmap
    policy_info = load_policy_info(run.path)

    # Load phases, max_steps, setup_duration from training config
    phases: list[dict[str, Any]] = []
    max_steps: int = 0
    setup_duration_secs: float | None = run.setup_duration_secs
    config_path = run.path / "training_config.json"
    if config_path.exists():
        config = json.loads(config_path.read_text())
        phases = config.get("phases", [])
        max_steps = config.get("max_steps", 0)

    # Build checkpoint chart data
    checkpoint_data = [
        {
            "episode": c.episode,
            "mean_reward": c.mean_reward,
            "epsilon": c.epsilon,
            "name": c.name,
        }
        for c in run.checkpoints
    ]

    # Build per-episode chart data
    episode_data = [
        {
            "episode": e.episode,
            "reward": e.reward,
            "steps": e.steps,
            "epsilon": e.epsilon,
            "satisfied": e.satisfied,
            "total_aps": e.total_aps,
            "all_satisfied": e.all_satisfied,
            "duration_secs": e.duration_secs,
            "execution_ms": e.execution_ms,
            "tokens": e.tokens,
            "backtracks": e.backtracks,
            "started_at": e.started_at,
            "finished_at": e.finished_at,
        }
        for e in run.episode_log
    ]

    # Compute completion rate
    episodes_with_status = [e for e in run.episode_log if e.all_satisfied is not None]
    completed_episodes = sum(1 for e in episodes_with_status if e.all_satisfied)
    completion_rate = (
        completed_episodes / len(episodes_with_status) if episodes_with_status else None
    )

    # Find linked policies (DB supplementary data)
    policies = policy_repo.list_policies(limit=100)
    linked_policies = [p for p in policies if p.training_run_slug == slug]

    # Workflows for export dialog
    workflows = wf_repo.list_workflows()

    # Best checkpoint for export button
    best_checkpoint = (
        max(run.checkpoints, key=lambda c: c.mean_reward) if run.checkpoints else None
    )

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "rl_detail.html",
        {
            **_ctx(request),
            "breadcrumbs": [("Training", "/training/"), (run.display_name, "")],
            "run": run,
            "checkpoint_data_json": json.dumps(checkpoint_data),
            "episode_data_json": json.dumps(episode_data),
            "phases": phases,
            "max_steps": max_steps,
            "setup_duration_secs": setup_duration_secs,
            "progress": run.progress,
            "progress_json": json.dumps(
                {
                    "episode": run.progress.episode,
                    "step": run.progress.step,
                    "max_steps": run.progress.max_steps,
                    "satisfied": run.progress.satisfied,
                    "total_aps": run.progress.total_aps,
                    "timestamp": run.progress.timestamp,
                }
            )
            if run.progress
            else "null",
            "completion_rate": completion_rate,
            "completed_episodes": completed_episodes,
            "total_episodes_tracked": len(episodes_with_status),
            "linked_policies": linked_policies,
            "policy_info": policy_info,
            "policy_json": json.dumps(
                {
                    "ap_ids": policy_info.ap_ids,
                    "num_states": policy_info.num_states,
                    "num_actions": policy_info.num_actions,
                    "q_table": policy_info.q_table,
                    "visit_counts": policy_info.visit_counts,
                    "greedy_actions": policy_info.greedy_actions,
                    "total_visits": policy_info.total_visits,
                }
            )
            if policy_info
            else "null",
            "workflows": workflows,
            "best_checkpoint": best_checkpoint,
        },
    )


# ─── Export Best Policy to Workflow ────────────────────────


@router.post("/{slug}/export-best-policy", response_class=HTMLResponse)
async def export_best_policy(
    request: Request,
    slug: str,
    base_workflow_slug: str = Form(...),
    workflow_name: str = Form(""),
    wf_repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Export the best checkpoint from a training run to a new editable workflow."""
    from dataclasses import replace

    from ..policy_loader import export_policy_to_workflow, load_tabular_policy

    run = _find_fs_run(request, slug)
    if run is None:
        raise HTTPException(status_code=404, detail="Training run not found")

    # Find the best checkpoint (highest mean_reward)
    if not run.checkpoints:
        raise HTTPException(status_code=400, detail="No checkpoints found for this run")

    best_cp = max(run.checkpoints, key=lambda c: c.mean_reward)
    checkpoint_path = run.path / best_cp.name

    try:
        tab_policy = load_tabular_policy(str(checkpoint_path))
    except (FileNotFoundError, ValueError) as exc:
        raise HTTPException(
            status_code=400, detail=f"Cannot load policy: {exc}"
        ) from exc

    try:
        base_workflow = wf_repo.get_workflow(base_workflow_slug)
    except KeyError as exc:
        raise HTTPException(
            status_code=404, detail=f"Base workflow '{base_workflow_slug}' not found"
        ) from exc

    exported = export_policy_to_workflow(tab_policy, base_workflow)

    name = workflow_name.strip() or f"{run.display_name} — best policy"
    new_slug = slugify(name)

    existing = {w.slug for w in wf_repo.list_workflows()}
    base_slug = new_slug
    counter = 2
    while new_slug in existing:
        new_slug = f"{base_slug}-{counter}"
        counter += 1

    exported_with_provenance = replace(
        exported,
        slug=new_slug,
        name=name,
        source_policy_slug=f"training:{slug}/{best_cp.name}",
    )
    wf_repo.save_workflow(exported_with_provenance)

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/workflows/{new_slug}/edit"},
    )


# ─── Import from filesystem ───────────────────────────────


@router.post("/import", response_class=HTMLResponse)
async def training_import(
    request: Request,
    repo: TrainingRunRepositoryInterface = Depends(get_training_repo),
) -> RedirectResponse:
    """Scan filesystem and import discovered training runs."""
    output_dir = getattr(request.app.state, "output_dir", None)
    if not output_dir:
        raise HTTPException(status_code=400, detail="No output directory configured")

    from pathlib import Path

    from ..rl_loader import discover_training_runs

    fs_runs = discover_training_runs(output_dir)
    imported = 0
    for fs_run in fs_runs:
        try:
            repo.import_from_filesystem(str(fs_run.path))
            imported += 1
        except Exception:
            logger.exception("Failed to import training run from %s", fs_run.path)

    # Also scan for policies
    policy_repo = get_policy_repo()
    policy_repo.scan_checkpoints(str(Path(output_dir)))

    return RedirectResponse(url="/training/", status_code=303)


# ─── New form ──────────────────────────────────────────────


@router.get("/new", response_class=HTMLResponse)
async def training_new_form(
    request: Request,
    gym: str = "",
    wf_repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> HTMLResponse:
    """Show the new training run configuration form."""
    workflows = wf_repo.list_workflows()
    # Gym names for the optional gym selector
    try:
        from atomicguard.gym import GYM_REGISTRY

        available_gyms = sorted(GYM_REGISTRY.keys())
    except Exception:
        available_gyms = []

    # Load gym instances when a gym is selected
    gym_instances: list[dict[str, str | int]] = []
    if gym:
        try:
            from atomicguard.gym import GYM_REGISTRY

            if gym in GYM_REGISTRY:
                gym_obj = GYM_REGISTRY[gym](arm=gym)  # type: ignore[call-arg]
                gym_instances = [
                    {"instance_id": inst.instance_id, "tier": inst.tier}
                    for inst in gym_obj.get_instances()
                ]
        except Exception:
            logger.debug("Failed to load gym instances for %s", gym, exc_info=True)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "training_new.html",
        {
            **_ctx(request),
            "workflows": workflows,
            "available_arms": AVAILABLE_ARMS,
            "available_rewards": AVAILABLE_REWARDS,
            "available_gyms": available_gyms,
            "selected_gym": gym,
            "gym_instances": gym_instances,
        },
    )


# ─── Create ────────────────────────────────────────────────


@router.post("/", response_class=HTMLResponse)
async def training_create(
    model: str = Form(""),
    provider: str = Form("openrouter"),
    base_url: str = Form(""),
    arm: str = Form("s1_tdd_rule_backtrack"),
    reward: str = Form("potential-based"),
    episodes: int = Form(100),
    max_steps: int = Form(0),
    gamma: float = Form(0.95),
    epsilon: float = Form(0.3),
    epsilon_decay: float = Form(0.995),
    alpha: float = Form(0.2),
    instances: int = Form(10),
    instance_ids: str = Form(""),
    checkpoint_interval: int = Form(5),
    language: str = Form("python"),
    gym: str = Form(""),
    repo: TrainingRunRepositoryInterface = Depends(get_training_repo),
) -> HTMLResponse:
    """Create and start a training run as a subprocess."""
    from ..training_launcher import launch_training

    timestamp = dt.datetime.now(dt.UTC).strftime("%Y%m%d_%H%M%S")
    slug = f"train_{timestamp}"
    checkpoint_dir = f"output/rl_training/{slug}"

    gym_slug = gym.strip() or None

    run = TrainingRunRecord(
        id=0,
        slug=slug,
        display_name=slug.replace("_", " ").title(),
        path=checkpoint_dir,
        model=model.strip(),
        provider=provider.strip(),
        arm=arm.strip(),
        reward=reward.strip(),
        episodes=episodes,
        gamma=gamma,
        alpha=alpha,
        epsilon_initial=epsilon,
        epsilon_final=epsilon,
        epsilon_decay=epsilon_decay,
        instances=instances,
        language=language.strip() or None,
        gym_slug=gym_slug,
        status="in_progress",
        created_at=_now_iso(),
        updated_at=_now_iso(),
    )
    run_id = repo.create_run(run)

    try:
        launch_training(
            run_id=run_id,
            repo=repo,
            model=model.strip(),
            provider=provider.strip(),
            base_url=base_url.strip(),
            arm=arm.strip(),
            reward=reward.strip(),
            episodes=episodes,
            max_steps=max_steps,
            gamma=gamma,
            epsilon=epsilon,
            epsilon_decay=epsilon_decay,
            alpha=alpha,
            instances=instances,
            language=language.strip(),
            checkpoint_dir=checkpoint_dir,
            gym_slug=gym_slug,
            checkpoint_interval=checkpoint_interval,
            instance_ids=[s.strip() for s in instance_ids.split(",") if s.strip()]
            if instance_ids.strip()
            else None,
        )
    except Exception as exc:
        repo.update_run(run_id, status="terminated", updated_at=_now_iso())
        raise HTTPException(status_code=500, detail=str(exc)) from exc

    return HTMLResponse(
        content="",
        status_code=200,
        headers={"HX-Redirect": f"/training/{slug}/"},
    )


# ─── Episode detail (rich artifact DAG view) ─────────────


@router.get("/{slug}/episode/{episode}/", response_class=HTMLResponse)
async def training_episode_detail(
    request: Request,
    slug: str,
    episode: int,
) -> HTMLResponse:
    """Episode detail with artifact DAG and step sequence.

    Uses the filesystem TrainingRun view model (web layer) to access
    episode log, instance_ids, and step log data.  The rich artifact
    DAG viewer is loaded from the filesystem via DAGReader.
    """
    from ..dependencies import create_dag_reader
    from ..rl_loader import build_episode_graph, load_episode_steps

    run = _find_fs_run(request, slug)
    if run is None:
        raise HTTPException(status_code=404, detail="Training run not found")

    steps = load_episode_steps(run.path, episode)
    graph = build_episode_graph(steps)

    # Find episode summary from episode_log
    episode_info = next((e for e in run.episode_log if e.episode == episode), None)

    # --- Load rich artifact DAG data ---
    nodes_json = "[]"
    edges_json = "[]"
    artifacts_json = "{}"
    runs_json = "[]"
    instance_id: str | None = None
    dag_mode: str | None = None
    has_dag_data = False

    # Determine instance_id: from episode_info first, then sequential rotation
    if episode_info and episode_info.instance_id:
        instance_id = episode_info.instance_id
    elif run.instance_ids:
        idx = (episode - 1) % len(run.instance_ids)
        instance_id = run.instance_ids[idx]

    if instance_id:
        dag_dir = run.path / "artifact_dags" / instance_id
        if dag_dir.is_dir():
            try:
                reader = create_dag_reader(dag_dir)

                workflow_id = episode_info.workflow_id if episode_info else None
                time_start = None
                time_end = None

                if workflow_id:
                    dag_mode = "per_episode"
                elif (
                    episode_info
                    and episode_info.started_at
                    and episode_info.finished_at
                ):
                    from datetime import datetime

                    time_start = datetime.fromisoformat(
                        episode_info.started_at
                    ).timestamp()
                    time_end = datetime.fromisoformat(
                        episode_info.finished_at
                    ).timestamp()
                    dag_mode = "time_filtered"
                else:
                    dag_mode = "full_instance"

                vis_data = reader.get_visualization_data_for_episode(
                    workflow_id=workflow_id,
                    time_start=time_start,
                    time_end=time_end,
                )

                if vis_data.nodes:
                    nodes_json = json.dumps(vis_data.nodes)
                    edges_json = json.dumps(vis_data.edges)
                    artifacts_json = json.dumps(vis_data.artifacts)
                    runs_json = json.dumps(vis_data.runs)
                    has_dag_data = True
            except Exception:
                logger.exception("Failed to load DAG for %s episode %d", slug, episode)

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "rl_episode.html",
        {
            **_ctx(request),
            "breadcrumbs": [
                ("Training", "/training/"),
                (run.display_name, f"/training/{slug}/"),
                (f"Episode {episode}", ""),
            ],
            "run": run,
            "episode": episode,
            "episode_info": episode_info,
            "steps": steps,
            "graph_json": json.dumps(graph),
            "instance_id": instance_id,
            "dag_mode": dag_mode,
            "has_dag_data": has_dag_data,
            "nodes_json": nodes_json,
            "edges_json": edges_json,
            "artifacts_json": artifacts_json,
            "runs_json": runs_json,
            "all_ap_ids_json": json.dumps(run.ap_ids),
        },
    )
