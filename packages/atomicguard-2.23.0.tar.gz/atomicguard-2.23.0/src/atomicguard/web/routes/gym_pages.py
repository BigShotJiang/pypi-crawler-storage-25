"""Gym catalogue routes — list, detail, fork workflow."""

from __future__ import annotations

import json
import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

from atomicguard.domain.interfaces import (
    GymRepositoryInterface,
    TrainingRunRepositoryInterface,
    WorkflowRepositoryInterface,
)

from ..dependencies import get_gym_repo, get_training_repo, get_workflow_repo
from ..utils import slugify

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/gyms", tags=["gyms"])


def _ctx(request: Request) -> dict[str, Any]:
    return {
        "request": request,
        "config_loader": getattr(request.app.state, "config_loader", None),
        "nav_active": "gym",
    }


# ─── List ──────────────────────────────────────────────────


@router.get("/", response_class=HTMLResponse)
async def gym_list(
    request: Request,
    repo: GymRepositoryInterface = Depends(get_gym_repo),
) -> HTMLResponse:
    """List all registered gyms."""
    gyms = repo.list_gyms()
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "gym_list.html",
        {**_ctx(request), "gyms": gyms},
    )


# ─── Detail ────────────────────────────────────────────────


@router.get("/{slug}/", response_class=HTMLResponse)
async def gym_detail(
    request: Request,
    slug: str,
    tier: int = 0,
    repo: GymRepositoryInterface = Depends(get_gym_repo),
    training_repo: TrainingRunRepositoryInterface = Depends(get_training_repo),
) -> HTMLResponse:
    """Gym detail with AP vocabulary, instances, and linked training runs."""
    try:
        gym = repo.get_gym(slug)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Gym not found") from exc

    action_pairs = repo.get_action_pairs(slug)
    instances = repo.get_instances(slug)

    # Filter by tier if specified
    if tier > 0:
        instances = [i for i in instances if i.tier == tier]

    # Find linked training runs
    all_runs = training_repo.list_runs(limit=200)
    linked_runs = [r for r in all_runs if r.gym_slug == slug]

    templates = request.app.state.templates
    return templates.TemplateResponse(
        "gym_detail.html",
        {
            **_ctx(request),
            "gym": gym,
            "action_pairs": action_pairs,
            "instances": instances,
            "linked_runs": linked_runs,
            "tier_filter": tier,
            "breadcrumbs": [("Gym", "/gyms/"), (gym.name, "")],
            "ap_data_json": json.dumps(
                [
                    {
                        "ap_id": ap.ap_id,
                        "name": ap.name,
                        "generator": ap.generator,
                        "guard": ap.guard,
                        "stochasticity": ap.stochasticity,
                        "tags": list(ap.tags),
                    }
                    for ap in action_pairs
                ]
            ),
        },
    )


# ─── Fork Workflow ─────────────────────────────────────────


@router.post("/{slug}/fork-workflow")
async def fork_gym_workflow(
    slug: str,
    wf_repo: WorkflowRepositoryInterface = Depends(get_workflow_repo),
) -> RedirectResponse:
    """Fork a gym's built-in workflow into the editable workflow DB."""
    try:
        from atomicguard.gym import GYM_REGISTRY
    except ImportError as exc:
        raise HTTPException(
            status_code=500, detail="Gym registry not available"
        ) from exc

    if slug not in GYM_REGISTRY:
        raise HTTPException(
            status_code=404, detail=f"Gym '{slug}' not found in registry"
        )

    try:
        gym_cls = GYM_REGISTRY[slug]
        gym_instance = gym_cls(arm=slug)  # type: ignore[call-arg]
        workflow_def = gym_instance.get_workflow_definition()
    except Exception as exc:
        raise HTTPException(
            status_code=500, detail=f"Failed to load gym workflow: {exc}"
        ) from exc

    # Generate unique slug
    new_slug = slugify(f"{slug}-fork")
    existing = {w.slug for w in wf_repo.list_workflows()}
    base_slug = new_slug
    counter = 2
    while new_slug in existing:
        new_slug = f"{base_slug}-{counter}"
        counter += 1

    from dataclasses import replace

    forked = replace(
        workflow_def,
        slug=new_slug,
        name=f"{workflow_def.name} (fork)",
    )
    wf_repo.save_workflow(forked)

    return RedirectResponse(f"/workflows/{new_slug}/edit", status_code=303)
