"""SSR page routes for the dashboard."""

from __future__ import annotations

import json
import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import HTMLResponse

from ..discovery import ExperimentDiscovery
from ..experiment_locator import ExperimentLocator

logger = logging.getLogger(__name__)

router = APIRouter()


def _ctx(request: Request, slug: str | None = None) -> dict[str, Any]:
    """Base template context with shared state."""
    app = request.app
    ctx: dict[str, Any] = {
        "request": request,
        "config_loader": app.state.config_loader,
        "nav_active": "runs",
    }
    if slug:
        ctx["experiment_slug"] = slug
        entry = app.state.experiments.get(slug)
        if entry:
            ctx["experiment_name"] = entry.display_name
    return ctx


def _rescan_experiments(request: Request) -> None:
    """Merge newly discovered experiments into app state."""
    output_dir = getattr(request.app.state, "output_dir", None)
    if not output_dir or not output_dir.is_dir():
        return
    locator = ExperimentLocator(output_dir / "experiments")
    for entry in locator.discover():
        request.app.state.experiments[entry.slug] = entry
        if entry.slug not in request.app.state.discoveries:
            request.app.state.discoveries[entry.slug] = ExperimentDiscovery(
                entry.artifact_dags_path
            )


def _get_discovery(request: Request, slug: str) -> Any:
    """Return the ExperimentDiscovery for *slug* or raise 404."""
    discovery = request.app.state.discoveries.get(slug)
    if discovery is None:
        raise HTTPException(status_code=404, detail=f"Experiment '{slug}' not found")
    return discovery


def _get_experiment(request: Request, slug: str) -> Any:
    """Return the ExperimentEntry for *slug* or raise 404."""
    entry = request.app.state.experiments.get(slug)
    if entry is None:
        raise HTTPException(status_code=404, detail=f"Experiment '{slug}' not found")
    return entry


# -- Experiment list (homepage) ------------------------------------------------


@router.get("/", response_class=HTMLResponse)
async def experiment_list(request: Request) -> HTMLResponse:
    """Home page: list all discovered experiments."""
    _rescan_experiments(request)
    experiments = sorted(
        request.app.state.experiments.values(),
        key=lambda e: (e.modified_at is not None, e.modified_at),
        reverse=True,
    )
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "experiment_list.html",
        {**_ctx(request), "experiments": experiments},
    )


# -- Experiment detail (merged stats + grid) -----------------------------------


@router.get("/experiments/{slug}/", response_class=HTMLResponse)
async def experiment_detail(request: Request, slug: str) -> HTMLResponse:
    """Stats cards + instance x arm grid for a single experiment."""
    entry = _get_experiment(request, slug)
    discovery = _get_discovery(request, slug)
    instances = discovery.get_instance_infos()
    summary = discovery.get_summary()
    arm_names = summary.arm_names
    templates = request.app.state.templates

    # Build set of completed (instance_id, arm) from results.jsonl
    completed_runs: set[tuple[str, str]] = set()
    fatal_runs: set[tuple[str, str]] = set()
    results_path = entry.artifact_dags_path.parent / "results.jsonl"
    if results_path.exists():
        try:
            for line in results_path.read_text().splitlines():
                if line.strip():
                    r = json.loads(line)
                    completed_runs.add((r["instance_id"], r["arm"]))
                    if r.get("fatal"):
                        fatal_runs.add((r["instance_id"], r["arm"]))
        except (json.JSONDecodeError, OSError, KeyError):
            logger.debug("Failed to parse results file %s", results_path)

    # Build status grid
    grid_data = []
    for inst in instances:
        row: dict[str, Any] = {
            "instance_id": inst.instance_id,
            "short_name": inst.short_name,
            "arms": {},
        }
        for arm in arm_names:
            dag_path = discovery.get_dag_path(inst.instance_id, arm)
            index_path = dag_path / "index.json"
            if arm in inst.arms and index_path.exists():
                try:
                    idx = json.loads(index_path.read_text())
                    artifacts = idx.get("artifacts", {})
                    action_pairs = idx.get("action_pairs", {})
                    artifact_count = len(artifacts)

                    config_loader = request.app.state.config_loader
                    full_eval_ap = config_loader.get_full_eval_action_pair(arm)

                    if full_eval_ap is None:
                        status = "na"
                    else:
                        ap_artifact_ids = action_pairs.get(full_eval_ap, [])
                        has_accepted = any(
                            artifacts[aid].get("status") == "accepted"
                            for aid in ap_artifact_ids
                            if aid in artifacts
                        )
                        if has_accepted:
                            status = "success"
                        elif (inst.instance_id, arm) not in completed_runs:
                            status = "in_progress"
                        elif (inst.instance_id, arm) in fatal_runs:
                            status = "fatal"
                        else:
                            status = "failed"

                    row["arms"][arm] = {
                        "status": status,
                        "artifact_count": artifact_count,
                    }
                except (json.JSONDecodeError, OSError):
                    row["arms"][arm] = {"status": "error", "artifact_count": 0}
            else:
                row["arms"][arm] = None
        grid_data.append(row)

    # Render NOTES.md if present
    notes_html = None
    if entry.notes_path and entry.notes_path.exists():
        import markdown  # type: ignore[import-untyped]

        notes_html = markdown.markdown(
            entry.notes_path.read_text(),
            extensions=["fenced_code", "tables"],
        )

    ctx = {
        **_ctx(request, slug),
        "summary": summary,
        "grid_data": grid_data,
        "arm_names": arm_names,
        "notes_html": notes_html,
    }

    if request.headers.get("HX-Request"):
        return templates.TemplateResponse("partials/experiment_content.html", ctx)

    return templates.TemplateResponse("experiment.html", ctx)


# -- DAG viewer ----------------------------------------------------------------


@router.get("/experiments/{slug}/{arm}/{instance}/", response_class=HTMLResponse)
async def dag_viewer(
    request: Request, slug: str, arm: str, instance: str
) -> HTMLResponse:
    """DAG viewer page for a specific instance/arm within an experiment."""
    from atomicguard.web.dependencies import create_dag_reader
    from atomicguard.web.discovery import parse_short_name

    discovery = _get_discovery(request, slug)
    dag_path = discovery.get_dag_path(instance, arm)
    if not (dag_path / "index.json").exists():
        raise HTTPException(status_code=404, detail="DAG not found")

    reader = create_dag_reader(dag_path)
    data = reader.get_visualization_data()
    templates = request.app.state.templates

    short_name = parse_short_name(instance)
    return templates.TemplateResponse(
        "dag_viewer.html",
        {
            **_ctx(request, slug),
            "breadcrumbs": [
                ("Experiments", "/"),
                (slug, f"/experiments/{slug}/"),
                (f"{short_name} / {arm}", ""),
            ],
            "instance": instance,
            "arm": arm,
            "short_name": short_name,
            "data": data,
            "nodes_json": json.dumps(data.nodes),
            "edges_json": json.dumps(data.edges),
            "artifacts_json": json.dumps(data.artifacts),
            "runs_json": json.dumps(data.runs),
        },
    )


# -- Docs routes ---------------------------------------------------------------


def _render_doc(request: Request, filename: str, title: str) -> HTMLResponse:
    """Render a markdown file from the docs directory as HTML."""
    import markdown

    docs_dir = request.app.state.docs_dir
    md_path = docs_dir / filename
    if not md_path.exists():
        raise HTTPException(status_code=404, detail=f"Doc '{filename}' not found")

    doc_html = markdown.markdown(
        md_path.read_text(),
        extensions=["fenced_code", "tables"],
    )
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "docs_page.html",
        {**_ctx(request), "title": title, "doc_html": doc_html},
    )


@router.get("/docs/experiments/", response_class=HTMLResponse)
async def docs_experiments(request: Request) -> HTMLResponse:
    """Render docs/experiments.md."""
    return _render_doc(request, "experiments.md", "Experiment Tracker")


@router.get("/docs/models/", response_class=HTMLResponse)
async def docs_models(request: Request) -> HTMLResponse:
    """Render docs/models.md."""
    return _render_doc(request, "models.md", "Model Reference")


@router.get("/docs/rewards/", response_class=HTMLResponse)
async def docs_rewards(request: Request) -> HTMLResponse:
    """Render reward strategy reference."""
    import markdown

    docs_dir = request.app.state.docs_dir
    md_path = docs_dir / "design" / "plans" / "the_policy_is_planning.md"
    if not md_path.exists():
        raise HTTPException(status_code=404, detail="Reward docs not found")
    doc_html = markdown.markdown(
        md_path.read_text(), extensions=["fenced_code", "tables"]
    )
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "docs_page.html",
        {**_ctx(request), "title": "Reward Strategies", "doc_html": doc_html},
    )


# -- Config routes (unchanged) -------------------------------------------------


@router.get("/config/", response_class=HTMLResponse)
async def config_index(request: Request) -> HTMLResponse:
    """List of workflow config variants."""
    ctx = _ctx(request)
    config_loader = ctx["config_loader"]
    variants = config_loader.list_variants()
    templates = request.app.state.templates

    variant_infos = []
    for v in variants:
        cfg = config_loader.get_config(v)
        variant_infos.append(
            {
                "name": v,
                "display_name": cfg.get("name", v) if cfg else v,
                "description": cfg.get("description", "") if cfg else "",
                "step_count": len(cfg.get("action_pairs", {})) if cfg else 0,
            }
        )

    return templates.TemplateResponse(
        "config_index.html",
        {**ctx, "variants": variant_infos},
    )


@router.get("/config/{variant}", response_class=HTMLResponse)
async def config_detail(request: Request, variant: str) -> HTMLResponse:
    """Config topology viewer for a workflow variant."""
    config_loader = request.app.state.config_loader
    result = config_loader.get_config_graph(variant)
    if result is None:
        raise HTTPException(status_code=404, detail="Config not found")

    nodes, edges, prompt_data = result
    config = config_loader.get_config(variant)
    templates = request.app.state.templates

    return templates.TemplateResponse(
        "config_detail.html",
        {
            **_ctx(request),
            "variant": variant,
            "config": config,
            "nodes_json": json.dumps(nodes),
            "edges_json": json.dumps(edges),
            "prompts_json": json.dumps(prompt_data),
        },
    )
