"""Ollama request metrics monitor routes."""

from __future__ import annotations

import json
import logging
from collections import defaultdict
from pathlib import Path
from typing import Any

from fastapi import APIRouter, Request
from fastapi.responses import HTMLResponse, JSONResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/ollama")


def _ctx(request: Request) -> dict[str, Any]:
    """Base template context."""
    return {"request": request}


def _load_ollama_requests(output_dir: Path | None) -> list[dict[str, Any]]:
    """Load requests from ollama_monitor/requests.jsonl."""
    if not output_dir:
        return []
    requests_file = Path(output_dir) / "ollama_monitor" / "requests.jsonl"
    if not requests_file.exists():
        return []
    requests: list[dict[str, Any]] = []
    for line in requests_file.read_text().splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            requests.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return requests


def _aggregate_ollama(requests: list[dict[str, Any]]) -> dict[str, Any]:
    """Compute summary stats, per-minute rate buckets, and latency histogram."""
    if not requests:
        return {
            "total": 0,
            "success_count": 0,
            "error_count": 0,
            "success_rate": 0,
            "avg_latency": 0,
            "min_latency": 0,
            "max_latency": 0,
            "rate_buckets": [],
            "latency_histogram": [0, 0, 0, 0, 0],
        }

    total = len(requests)
    success_count = sum(1 for r in requests if r.get("status", 0) < 400)
    error_count = total - success_count
    success_rate = round(success_count / total * 100, 1) if total else 0

    durations = [r.get("duration_s", 0) for r in requests]
    avg_latency = round(sum(durations) / len(durations), 1) if durations else 0
    min_latency = round(min(durations), 1) if durations else 0
    max_latency = round(max(durations), 1) if durations else 0

    # Per-minute rate buckets: truncate ts to minute
    minute_buckets: dict[str, dict[str, int]] = defaultdict(
        lambda: {"count": 0, "error_count": 0}
    )
    for r in requests:
        ts = r.get("ts", "")
        # Truncate to minute: "2026-03-02T12:14:11Z" → "2026-03-02T12:14"
        minute_key = ts[:16] if len(ts) >= 16 else ts
        minute_buckets[minute_key]["count"] += 1
        if r.get("status", 0) >= 400:
            minute_buckets[minute_key]["error_count"] += 1

    rate_buckets = [
        {"ts": k, "count": v["count"], "error_count": v["error_count"]}
        for k, v in sorted(minute_buckets.items())
    ]

    # Latency histogram: [0-30s, 30-60s, 60-120s, 120-300s, 300s+]
    histogram = [0, 0, 0, 0, 0]
    for d in durations:
        if d < 30:
            histogram[0] += 1
        elif d < 60:
            histogram[1] += 1
        elif d < 120:
            histogram[2] += 1
        elif d < 300:
            histogram[3] += 1
        else:
            histogram[4] += 1

    return {
        "total": total,
        "success_count": success_count,
        "error_count": error_count,
        "success_rate": success_rate,
        "avg_latency": avg_latency,
        "min_latency": min_latency,
        "max_latency": max_latency,
        "rate_buckets": rate_buckets,
        "latency_histogram": histogram,
    }


@router.get("/", response_class=HTMLResponse)
async def ollama_monitor(request: Request) -> HTMLResponse:
    """Ollama request metrics monitor page."""
    output_dir = getattr(request.app.state, "output_dir", None)
    requests_data = _load_ollama_requests(output_dir)
    stats = _aggregate_ollama(requests_data)
    templates = request.app.state.templates
    return templates.TemplateResponse(
        "ollama_monitor.html",
        {
            **_ctx(request),
            "requests_json": json.dumps(requests_data),
            "stats_json": json.dumps(stats),
            "stats": stats,
        },
    )


@router.get("/api/metrics", response_class=JSONResponse)
async def ollama_api_metrics(request: Request) -> JSONResponse:
    """Return ollama requests + aggregated stats as JSON."""
    output_dir = getattr(request.app.state, "output_dir", None)
    requests_data = _load_ollama_requests(output_dir)
    stats = _aggregate_ollama(requests_data)
    return JSONResponse(content={"requests": requests_data, "stats": stats})
