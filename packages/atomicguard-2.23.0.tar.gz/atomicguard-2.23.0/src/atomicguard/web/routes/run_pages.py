"""Run management and human review routes.

Provides:
- ``/runs/`` — list of jobs from the queue DB
- ``/runs/{job_id}/`` — job detail with step timeline
- ``/runs/{job_id}/timeline`` — HTMX partial for polling timeline updates
- ``/reviews/`` — pending human reviews
- ``/reviews/{review_id}/`` — review detail with artifact
- ``/reviews/{review_id}/decide`` — POST to approve/reject
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Form, HTTPException, Request
from fastapi.responses import HTMLResponse, RedirectResponse

logger = logging.getLogger(__name__)

router = APIRouter(tags=["runs"])


def _ctx(request: Request) -> dict[str, Any]:
    return {
        "request": request,
        "config_loader": getattr(request.app.state, "config_loader", None),
        "nav_active": "runs",
    }


# ---------------------------------------------------------------------------
# Runs
# ---------------------------------------------------------------------------


@router.get("/runs/", response_class=HTMLResponse)
async def run_list(request: Request, status: str | None = None) -> HTMLResponse:
    """List jobs from the queue DB."""
    templates = request.app.state.templates
    queue = getattr(request.app.state, "job_queue", None)

    jobs: list[dict[str, Any]] = []
    if queue is not None:
        from atomicguard.domain.runner import JobState

        try:
            filter_state = JobState(status) if status else None
        except ValueError:
            filter_state = None
        raw_jobs = queue.list_jobs(state=filter_state)
        for j in raw_jobs:
            job_status = queue.get_status(j.job_id)
            jobs.append(
                {
                    "job_id": j.job_id,
                    "workflow_name": j.workflow_definition.name,
                    "model": j.model,
                    "provider": j.provider,
                    "specification": (
                        j.specification[:120] + "..."
                        if len(j.specification) > 120
                        else j.specification
                    ),
                    "submitted_at": j.submitted_at.isoformat()[:19],
                    "state": (job_status.state.value if job_status else "queued"),
                    "current_step": (job_status.current_step if job_status else None),
                    "step_count": (len(job_status.step_results) if job_status else 0),
                }
            )

    ctx = _ctx(request)
    ctx["jobs"] = jobs
    ctx["status_filter"] = status
    return templates.TemplateResponse("run_list.html", ctx)


@router.get("/runs/{job_id}/", response_class=HTMLResponse)
async def run_detail(request: Request, job_id: str) -> HTMLResponse:
    """Job detail with step timeline and pending reviews."""
    templates = request.app.state.templates
    queue = getattr(request.app.state, "job_queue", None)
    resolver = getattr(request.app.state, "review_resolver", None)

    if queue is None:
        raise HTTPException(status_code=503, detail="Job queue not configured")

    job_status = queue.get_status(job_id)

    # Find the job metadata
    all_jobs = queue.list_jobs()
    job_meta = None
    for j in all_jobs:
        if j.job_id == job_id:
            job_meta = j
            break

    if job_meta is None:
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")

    # Get pending reviews for this job
    reviews: list[dict[str, Any]] = []
    if resolver is not None:
        reviews = resolver.list_pending(job_id=job_id)

    ctx = _ctx(request)
    ctx["job_id"] = job_id
    ctx["job"] = {
        "workflow_name": job_meta.workflow_definition.name,
        "model": job_meta.model,
        "provider": job_meta.provider,
        "specification": job_meta.specification,
        "submitted_at": job_meta.submitted_at.isoformat()[:19],
    }
    ctx["status"] = {
        "state": job_status.state.value if job_status else "queued",
        "current_step": job_status.current_step if job_status else None,
        "error": job_status.error if job_status else None,
        "step_results": [
            {
                "ap_id": sr.ap_id,
                "attempt": sr.attempt,
                "passed": sr.passed,
                "feedback": sr.feedback,
                "artifact_id": sr.artifact_id,
            }
            for sr in (job_status.step_results if job_status else ())
        ],
    }
    ctx["reviews"] = reviews
    return templates.TemplateResponse("run_detail.html", ctx)


@router.post("/runs/{job_id}/cancel")
async def run_cancel(request: Request, job_id: str) -> RedirectResponse:
    """Cancel a QUEUED or PAUSED job."""
    queue = getattr(request.app.state, "job_queue", None)
    if queue is None:
        raise HTTPException(status_code=503, detail="Job queue not configured")
    if not any(j.job_id == job_id for j in queue.list_jobs()):
        raise HTTPException(status_code=404, detail=f"Job {job_id} not found")
    if not queue.cancel(job_id):
        raise HTTPException(
            status_code=409,
            detail="Job cannot be cancelled: not in QUEUED or PAUSED state",
        )
    return RedirectResponse(url=f"/runs/{job_id}/", status_code=303)


@router.get("/runs/{job_id}/timeline", response_class=HTMLResponse)
async def run_timeline_partial(request: Request, job_id: str) -> HTMLResponse:
    """HTMX partial — returns just the timeline for polling updates."""
    templates = request.app.state.templates
    queue = getattr(request.app.state, "job_queue", None)
    resolver = getattr(request.app.state, "review_resolver", None)

    status = None
    if queue is not None:
        status = queue.get_status(job_id)

    reviews: list[dict[str, Any]] = []
    if resolver is not None:
        reviews = resolver.list_pending(job_id=job_id)

    ctx = {
        "request": request,
        "job_id": job_id,
        "status": {
            "state": status.state.value if status else "queued",
            "current_step": status.current_step if status else None,
            "error": status.error if status else None,
            "step_results": [
                {
                    "ap_id": sr.ap_id,
                    "attempt": sr.attempt,
                    "passed": sr.passed,
                    "feedback": sr.feedback,
                    "artifact_id": sr.artifact_id,
                }
                for sr in (status.step_results if status else ())
            ],
        },
        "reviews": reviews,
    }
    return templates.TemplateResponse("partials/run_timeline.html", ctx)


# ---------------------------------------------------------------------------
# Reviews
# ---------------------------------------------------------------------------


@router.get("/reviews/", response_class=HTMLResponse)
async def review_list(request: Request) -> HTMLResponse:
    """List all pending reviews across all jobs."""
    templates = request.app.state.templates
    resolver = getattr(request.app.state, "review_resolver", None)

    reviews: list[dict[str, Any]] = []
    if resolver is not None:
        reviews = resolver.list_pending_only()

    ctx = _ctx(request)
    ctx["reviews"] = reviews
    return templates.TemplateResponse("review_list.html", ctx)


@router.get("/reviews/{review_id}/", response_class=HTMLResponse)
async def review_detail(request: Request, review_id: str) -> HTMLResponse:
    """Review detail with artifact content and approve/reject form."""
    templates = request.app.state.templates
    resolver = getattr(request.app.state, "review_resolver", None)

    if resolver is None:
        raise HTTPException(status_code=503, detail="Review resolver not configured")

    review = resolver.get_review(review_id)
    if review is None:
        raise HTTPException(status_code=404, detail="Review not found")

    ctx = _ctx(request)
    ctx["review"] = review
    return templates.TemplateResponse("review_detail.html", ctx)


@router.post("/reviews/{review_id}/decide")
async def review_decide(
    request: Request,
    review_id: str,
    decision: str = Form(...),
    feedback: str = Form(""),
) -> RedirectResponse:
    """Submit a decision for a pending review."""
    resolver = getattr(request.app.state, "review_resolver", None)

    if resolver is None:
        raise HTTPException(status_code=503, detail="Review resolver not configured")

    approved = decision == "approve"
    updated = resolver.submit_decision(review_id, approved=approved, feedback=feedback)

    if not updated:
        raise HTTPException(
            status_code=409,
            detail="Review already decided or not found",
        )

    # Redirect back to the review's job detail if we can find it
    review = resolver.get_review(review_id)
    if review:
        return RedirectResponse(
            url=f"/runs/{review['job_id']}/",
            status_code=303,
        )
    return RedirectResponse(url="/reviews/", status_code=303)
