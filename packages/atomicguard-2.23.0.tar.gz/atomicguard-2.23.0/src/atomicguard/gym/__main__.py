"""Entry point for ``python -m atomicguard.gym``.

Subcommands:
- ``list``:     List available gyms with manifests.
- ``train``:    Train an RL policy on a gym.
- ``evaluate``: Evaluate a trained policy on a gym (greedy).
- ``export``:   Export Q-table to workflow JSON (delegates to atomicguard.tools).
"""

from __future__ import annotations

import json
import logging
import os
import time
from datetime import UTC, datetime
from pathlib import Path

import click

from atomicguard.domain.gym import GymInterface
from atomicguard.domain.interfaces import TrainingObserverInterface
from atomicguard.domain.rl.reward import RewardFunctionInterface
from atomicguard.gym import GYM_REGISTRY

logger = logging.getLogger("atomicguard.gym")


def _configure_logging(debug: bool, log_file: Path | None = None) -> None:
    """Set up logging for training runs."""
    level = logging.DEBUG if debug else logging.INFO
    root = logging.getLogger()
    root.setLevel(level)

    fmt = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    sh = logging.StreamHandler()
    sh.setLevel(level)
    sh.setFormatter(fmt)
    root.addHandler(sh)

    if log_file:
        log_file.parent.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(log_file, mode="a")
        fh.setLevel(level)
        fh.setFormatter(fmt)
        root.addHandler(fh)

    for name in ("httpx", "httpcore", "openai", "urllib3"):
        logging.getLogger(name).setLevel(logging.WARNING)


def _get_reward_fn(reward_name: str) -> RewardFunctionInterface:
    """Build a reward function by name."""
    from atomicguard.infrastructure.rl.rewards import (
        EfficiencyPenaltyReward,
        MazeReward,
        PotentialBasedShapingReward,
        SparseBinaryReward,
        StepReward,
    )

    reward_map: dict[str, tuple] = {
        "sparse": (SparseBinaryReward, {}),
        "step": (StepReward, {}),
        "efficiency": (EfficiencyPenaltyReward, {}),
        "potential-based": (PotentialBasedShapingReward, {"terminal_bonus": 5.0}),
        "maze": (MazeReward, {}),
    }
    if reward_name not in reward_map:
        raise click.BadParameter(
            f"Unknown reward: {reward_name}. Valid: {', '.join(reward_map)}"
        )
    cls, kwargs = reward_map[reward_name]
    result: RewardFunctionInterface = cls(**kwargs)
    return result


def _truncate_episode_log(log_path: Path, start_episode: int) -> int:
    """Remove stale entries from episode log on resume."""
    if not log_path.exists():
        return 0
    kept: list[str] = []
    removed = 0
    with open(log_path) as f:
        for line in f:
            line = line.rstrip("\n")
            if not line:
                continue
            should_remove = False
            try:
                entry = json.loads(line)
                if entry.get("episode", 0) >= start_episode:
                    should_remove = True
            except (json.JSONDecodeError, TypeError):
                should_remove = False  # keep unparseable lines
            if should_remove:
                removed += 1
            else:
                kept.append(line)
    if removed:
        with open(log_path, "w") as f:
            for line in kept:
                f.write(line + "\n")
    return removed


def _default_db_path() -> Path:
    """Default SQLite DB path shared with the web UI."""
    return Path.home() / ".atomicguard" / "web.db"


def _create_observer(
    *,
    db_path: Path | None,
    no_db: bool,
) -> TrainingObserverInterface | None:
    """Create a TrainingObserverInterface implementation.

    Returns SqliteTrainingObserver if DB is available, None otherwise.
    This function is the CLI's composition root for observer wiring.
    """
    if no_db:
        return None

    resolved = db_path or _default_db_path()
    try:
        from atomicguard.infrastructure.persistence.sqlite import (
            SQLiteConnection,
            SqliteTrainingObserver,
            SQLiteTrainingRunRepository,
        )

        resolved.parent.mkdir(parents=True, exist_ok=True)
        conn = SQLiteConnection(resolved)
        conn.init_schema()
        repo = SQLiteTrainingRunRepository(conn)
        return SqliteTrainingObserver(repo)
    except Exception:
        logger.debug("Failed to initialise DB observer at %s", resolved, exc_info=True)
        return None


@click.group()
def cli() -> None:
    """AtomicGuard Gym — train, evaluate, and manage RL policies."""


def _instantiate_gym(
    gym_cls: type[GymInterface], gym_name: str, **kwargs: object
) -> GymInterface:
    """Instantiate a gym class, passing ``arm`` only if accepted."""
    import inspect

    sig = inspect.signature(gym_cls.__init__)
    if "arm" in sig.parameters:
        return gym_cls(arm=gym_name, **kwargs)  # type: ignore[call-arg]
    # Filter out kwargs not in constructor signature
    valid = {k for k in sig.parameters if k != "self"}
    filtered = {k: v for k, v in kwargs.items() if k in valid}
    return gym_cls(**filtered)


@cli.command("list")
def list_gyms() -> None:
    """List available gyms with manifests."""
    for gym_name, gym_cls in sorted(GYM_REGISTRY.items()):
        try:
            gym = _instantiate_gym(gym_cls, gym_name)
            manifest = gym.get_manifest()
            docker = "yes" if manifest.requires_docker else "no"
            llm = "yes" if manifest.requires_llm else "no"
            click.echo(
                f"  {manifest.name:<25s} "
                f"APs={len(manifest.ap_ids):<3d} "
                f"instances={manifest.instance_count:<3d} "
                f"tiers={list(manifest.tiers)}  "
                f"docker={docker}  llm={llm}"
            )
            click.echo(f"    {manifest.description}")
        except Exception as e:
            click.echo(f"  {gym_name:<25s} (error: {e})")


@cli.command()
@click.option(
    "--gym",
    "gym_name",
    required=True,
    type=click.Choice(sorted(GYM_REGISTRY)),
    help="Gym name",
)
@click.option("--model", default=None, help="Model ID")
@click.option("--provider", default=None, help="LLM provider")
@click.option("--base-url", default="", help="API base URL")
@click.option("--api-key", default=None, help="API key (default: LLM_API_KEY env)")
@click.option(
    "--reward",
    default="potential-based",
    type=click.Choice(["sparse", "step", "efficiency", "potential-based", "maze"]),
    help="Reward strategy",
)
@click.option("--episodes", default=100, type=int, help="Training episodes")
@click.option("--max-steps", default=0, type=int, help="Max steps per episode (0=auto)")
@click.option("--gamma", default=0.95, type=float, help="Discount factor")
@click.option("--epsilon", default=0.3, type=float, help="Initial exploration rate")
@click.option(
    "--epsilon-decay", default=0.995, type=float, help="Epsilon decay per episode"
)
@click.option("--alpha", default=0.2, type=float, help="Q-learning step size")
@click.option("--instances", default=0, type=int, help="Limit instances (0=all)")
@click.option("--checkpoint-dir", default=None, help="Output dir for checkpoints")
@click.option(
    "--checkpoint-interval", default=5, type=int, help="Save every N episodes"
)
@click.option("--resume", is_flag=True, help="Resume from latest checkpoint")
@click.option(
    "--output-mode",
    default="tool",
    type=click.Choice(["tool", "prompted", "native"]),
    help="Structured output mode",
)
@click.option(
    "--constraint-mode",
    default="preserve",
    type=click.Choice(["unconstrained", "physical_only", "preserve"]),
    help="Workflow requires constraint mode",
)
@click.option(
    "--max-selections-per-ap",
    default=0,
    type=int,
    help="Max AP selections per episode (0=unlimited)",
)
@click.option(
    "--enable-backtracking/--no-backtracking", default=True, help="Enable backtracking"
)
@click.option(
    "--instance-ids",
    default="",
    help="Comma-separated instance IDs to include (empty=all)",
)
@click.option(
    "--llm-timeout",
    default=120,
    type=int,
    help="LLM call timeout in seconds (for stochastic fix APs)",
)
@click.option("--debug", is_flag=True, help="Debug logging")
@click.option(
    "--db-path",
    default=None,
    type=click.Path(path_type=Path),
    help="SQLite DB path for live progress (default: ~/.atomicguard/web.db)",
)
@click.option(
    "--no-db",
    is_flag=True,
    help="Disable DB persistence (overrides --db-path)",
)
def train(  # noqa: PLR0913
    gym_name: str,
    model: str | None,
    provider: str | None,
    base_url: str,
    api_key: str | None,
    reward: str,
    episodes: int,
    max_steps: int,
    gamma: float,
    epsilon: float,
    epsilon_decay: float,
    alpha: float,
    instances: int,
    checkpoint_dir: str | None,
    checkpoint_interval: int,
    resume: bool,
    output_mode: str,
    constraint_mode: str,
    max_selections_per_ap: int,
    enable_backtracking: bool,
    instance_ids: str,
    llm_timeout: int,
    debug: bool,
    db_path: Path | None,
    no_db: bool,
) -> None:
    """Train an RL policy on a gym."""
    from atomicguard.infrastructure.persistence.filesystem import FilesystemArtifactDAG
    from atomicguard.infrastructure.rl.checkpoint import (
        CheckpointMetadata,
        load_checkpoint,
        save_checkpoint,
    )
    from atomicguard.infrastructure.rl.environment import (
        MultiInstanceEnvironment,
        TrainingEnvironment,
    )
    from atomicguard.infrastructure.rl.policy import TabularPolicy
    from atomicguard.infrastructure.rl.replay_buffer import ReplayBuffer
    from atomicguard.training.trainer import (
        EpisodeMetrics,
        StepInfo,
        Trainer,
        TrainingConfig,
    )

    api_key = api_key or os.environ.get("LLM_API_KEY", "")
    model = model or "qwen3-coder-next"
    provider = provider or "ollama"

    checkpoint_path = Path(checkpoint_dir or f"output/rl_training/{gym_name}")
    checkpoint_path.mkdir(parents=True, exist_ok=True)
    _configure_logging(debug, log_file=checkpoint_path / "training.log")

    # Instantiate gym — inject application classes to satisfy DDD boundary
    from atomicguard.application.action_pair import ActionPair
    from atomicguard.application.agent import DualStateAgent
    from atomicguard.application.workflow import WorkflowOrchestrator

    gym_cls = GYM_REGISTRY[gym_name]
    gym = _instantiate_gym(
        gym_cls,
        gym_name,
        model=model,
        provider=provider,
        base_url=base_url,
        api_key=api_key,
        output_mode=output_mode,
        constraint_mode=constraint_mode,
        llm_timeout=llm_timeout,
        action_pair_cls=ActionPair,
        workflow_cls=WorkflowOrchestrator,
        agent_cls=DualStateAgent,
    )

    # Load instances
    gym_instances = gym.get_instances(limit=instances if instances > 0 else None)
    if instance_ids:
        allowed = {s.strip() for s in instance_ids.split(",") if s.strip()}
        gym_instances = [i for i in gym_instances if i.instance_id in allowed]
    click.echo(f"Gym: {gym_name} ({len(gym_instances)} instances)")

    # Build environments
    reward_fn = _get_reward_fn(reward)
    click.echo("Building training environments...")
    setup_t0 = time.perf_counter()
    environments: list[TrainingEnvironment] = []

    for inst in gym_instances:
        dag_dir = checkpoint_path / "artifact_dags" / inst.instance_id
        dag_dir.mkdir(parents=True, exist_ok=True)
        artifact_dag = FilesystemArtifactDAG(str(dag_dir))

        env = gym.build_environment(
            instance=inst,
            reward_fn=reward_fn,
            artifact_dag=artifact_dag,
            max_steps=max_steps if max_steps > 0 else None,
            enable_backtracking=enable_backtracking,
            max_selections_per_ap=max_selections_per_ap
            if max_selections_per_ap > 0
            else None,
        )
        assert isinstance(env, TrainingEnvironment)
        environments.append(env)

    setup_duration_secs = time.perf_counter() - setup_t0
    multi_env = MultiInstanceEnvironment(environments, rotation="sequential")

    # AP vocabulary
    ap_ids = gym.get_ap_ids()
    num_aps = len(ap_ids)
    ep_stats = environments[0].get_episode_stats()
    goal_count = ep_stats.get("goal_aps", 0)
    required_aps = ep_stats.get("required_aps", num_aps)
    if goal_count:
        click.echo(f"  AP vocabulary ({num_aps} APs, {goal_count} goal): {ap_ids}")
    else:
        click.echo(
            f"  AP vocabulary ({num_aps} APs, {required_aps} required): {ap_ids}"
        )

    # Policy + buffer
    policy = TabularPolicy(
        num_action_pairs=num_aps,
        action_pair_ids=ap_ids,
        epsilon=epsilon,
        alpha=alpha,
    )
    buffer = ReplayBuffer(capacity=50_000)
    training_config = TrainingConfig(
        num_episodes=episodes,
        max_steps_per_episode=max_steps if max_steps > 0 else max(2 * num_aps, 1),
        gamma=gamma,
        checkpoint_interval=checkpoint_interval,
    )

    # Resume
    start_episode = 0
    if resume:
        latest = checkpoint_path / "latest"
        if latest.exists():
            click.echo(f"Resuming from checkpoint: {latest}")
            meta = load_checkpoint(latest, policy)
            start_episode = meta.total_episodes
            if meta.env_state is not None:
                multi_env.set_state(meta.env_state)
                click.echo("  Restored environment state from checkpoint")
            click.echo(
                f"  Resumed at episode {start_episode}, "
                f"epsilon={policy.epsilon:.4f}, "
                f"mean_reward={meta.mean_reward:.3f}"
            )
        else:
            click.echo("No checkpoint found, starting fresh.")

    # Truncate stale log entries on resume
    episode_log_path = checkpoint_path / "episode_log.jsonl"
    step_log_path = checkpoint_path / "step_log.jsonl"
    if resume and start_episode > 0:
        removed = _truncate_episode_log(episode_log_path, start_episode)
        if removed:
            click.echo(f"  Removed {removed} stale episode log entries")
        removed_steps = _truncate_episode_log(step_log_path, start_episode)
        if removed_steps:
            click.echo(f"  Removed {removed_steps} stale step log entries")

    # Callbacks
    instance_id_list = [inst.instance_id for inst in gym_instances]
    progress_path = checkpoint_path / "progress.json"

    def on_checkpoint(episode: int, mean_reward: float) -> None:
        policy.decay_epsilon(epsilon_decay**checkpoint_interval)
        ckpt_dir = checkpoint_path / f"checkpoint_{episode:06d}"
        meta = CheckpointMetadata(
            epoch=0,
            total_episodes=episode,
            mean_reward=mean_reward,
            checkpoint_path=str(ckpt_dir),
            epsilon=policy.epsilon,
            env_state=multi_env.get_state(),
        )
        save_checkpoint(ckpt_dir, policy, meta)
        latest = checkpoint_path / "latest"
        latest.unlink(missing_ok=True)
        latest.symlink_to(ckpt_dir.name)
        click.echo(
            f"  Checkpoint at episode {episode}: "
            f"mean_reward={mean_reward:.3f}, epsilon={policy.epsilon:.4f}"
        )

    def on_step(info: StepInfo) -> None:
        ep_stats = multi_env.get_episode_stats()
        inst_idx = int(ep_stats.get("instance_index", 0))
        inst_id = (
            instance_id_list[inst_idx] if inst_idx < len(instance_id_list) else None
        )
        progress_path.write_text(
            json.dumps(
                {
                    "episode": info.episode,
                    "step": info.step,
                    "max_steps": info.max_steps,
                    "satisfied": len(info.satisfied_after),
                    "total_aps": required_aps,
                    "timestamp": datetime.now(tz=UTC).isoformat(),
                }
            )
        )
        ap_id = (
            ap_ids[info.action]
            if info.action < len(ap_ids)
            else f"action_{info.action}"
        )
        is_backtrack = ap_id in info.satisfied_before
        entry = json.dumps(
            {
                "episode": info.episode,
                "step": info.step,
                "ap_id": ap_id,
                "guard_passed": info.guard_passed,
                "reward": round(info.reward_value, 6),
                "is_backtrack": is_backtrack,
                "terminal": info.terminal,
                "satisfied": sorted(info.satisfied_after),
                "step_duration_ms": round(info.step_duration_ms, 1),
                "instance_id": inst_id,
            }
        )
        with open(step_log_path, "a") as f:
            f.write(entry + "\n")

    def on_episode(metrics: EpisodeMetrics) -> None:
        progress_path.write_text(json.dumps({"status": "idle"}))
        ep_stats = multi_env.get_episode_stats()
        inst_idx = int(ep_stats.get("instance_index", 0))
        inst_id = (
            instance_id_list[inst_idx] if inst_idx < len(instance_id_list) else None
        )
        entry = json.dumps(
            {
                "episode": metrics.episode,
                "reward": round(metrics.reward, 6),
                "steps": metrics.steps,
                "epsilon": round(policy.epsilon, 6),
                "satisfied": metrics.satisfied_count,
                "total_aps": metrics.total_aps,
                "all_satisfied": metrics.all_satisfied,
                "duration_secs": round(metrics.duration_secs, 3),
                "tokens": metrics.tokens_used,
                "backtracks": metrics.backtrack_count,
                "execution_ms": round(metrics.execution_duration_ms, 1),
                "started_at": metrics.started_at,
                "finished_at": metrics.finished_at,
                "instance_id": inst_id,
            }
        )
        with open(episode_log_path, "a") as f:
            f.write(entry + "\n")

        # Persist to DB via observer
        if observer is not None and observer_run_id is not None:
            from atomicguard.domain.models import TrainingEpisodeRecord

            observer.on_episode_complete(
                TrainingEpisodeRecord(
                    id=0,
                    training_run_id=observer_run_id,
                    episode=metrics.episode,
                    reward=metrics.reward,
                    steps=metrics.steps,
                    epsilon=policy.epsilon,
                    satisfied=metrics.satisfied_count,
                    total_aps=metrics.total_aps,
                    all_satisfied=metrics.all_satisfied,
                    duration_secs=metrics.duration_secs,
                    tokens=metrics.tokens_used,
                    backtracks=metrics.backtrack_count,
                    instance_id=inst_id,
                )
            )

    # Write training config
    training_config_data = {
        "gym": gym_name,
        "model": model,
        "provider": provider,
        "arm": getattr(gym, "_arm_variant", gym_name),
        "reward": reward,
        "episodes": episodes,
        "max_steps": training_config.max_steps_per_episode,
        "gamma": gamma,
        "alpha": alpha,
        "epsilon_initial": epsilon,
        "epsilon_decay": epsilon_decay,
        "instances": len(gym_instances),
        "language": "python",
        "ap_ids": list(ap_ids),
        "instance_ids": instance_id_list,
        "enable_backtracking": enable_backtracking,
        "max_selections_per_ap": max_selections_per_ap
        if max_selections_per_ap > 0
        else None,
        "constraint_mode": constraint_mode,
        "setup_duration_secs": round(setup_duration_secs, 2),
        "llm_timeout": llm_timeout,
    }
    config_path = checkpoint_path / "training_config.json"
    with open(config_path, "w") as f:
        json.dump(training_config_data, f, indent=2)

    # Initialise training observer (DB persistence)
    observer = _create_observer(db_path=db_path, no_db=no_db)
    observer_run_id: int | None = None
    if observer is not None:
        from atomicguard.domain.models import TrainingRunRecord

        slug = checkpoint_path.name
        run_record = TrainingRunRecord(
            id=0,
            slug=slug,
            display_name=slug.replace("_", " ").title(),
            path=str(checkpoint_path),
            model=model or "",
            provider=provider or "",
            arm=str(training_config_data.get("arm", "")),
            reward=reward,
            episodes=episodes,
            gamma=gamma,
            alpha=alpha,
            epsilon_initial=epsilon,
            epsilon_decay=epsilon_decay,
            instances=len(gym_instances),
            language="python",
            gym_slug=gym_name,
            ap_ids=tuple(ap_ids),
            status="in_progress",
        )
        observer_run_id = observer.on_run_started(run_record)
        click.echo(f"  DB persistence: {db_path or _default_db_path()}")

    # Train
    click.echo(f"\nTraining ({episodes} episodes, start={start_episode})...")
    click.echo(f"  Reward: {reward}, gamma={gamma}, alpha={alpha}")
    click.echo(f"  Epsilon: {epsilon} -> decay={epsilon_decay}/episode")
    click.echo(
        f"  Checkpoints: every {checkpoint_interval} episodes -> {checkpoint_path}"
    )

    trainer = Trainer(
        environment=multi_env,
        policy=policy,
        replay_buffer=buffer,
        config=training_config,
    )

    try:
        metrics = trainer.train(
            on_checkpoint=on_checkpoint,
            on_episode=on_episode,
            on_step=on_step,
            start_episode=start_episode,
        )

        click.echo("\nTraining complete:")
        click.echo(f"  Mean reward: {metrics['mean_reward']:.3f}")
        click.echo(f"  Final epsilon: {policy.epsilon:.4f}")
        click.echo(f"  Replay buffer size: {len(buffer)}")

        # Final save
        final_dir = checkpoint_path / "final"
        final_meta = CheckpointMetadata(
            epoch=0,
            total_episodes=start_episode + len(metrics["episode_rewards"]),
            mean_reward=metrics["mean_reward"],
            checkpoint_path=str(final_dir),
            epsilon=policy.epsilon,
        )
        save_checkpoint(final_dir, policy, final_meta)

        latest = checkpoint_path / "latest"
        latest.unlink(missing_ok=True)
        latest.symlink_to("final")
        click.echo(f"  Final policy saved to {final_dir}")

        # Quick eval
        click.echo("\nEvaluating (greedy, 3 episodes)...")
        eval_metrics = trainer.evaluate(num_episodes=min(3, len(gym_instances)))
        click.echo(f"  Mean reward: {eval_metrics['mean_reward']:.3f}")
        click.echo(f"  Success rate: {eval_metrics['success_rate']:.0%}")

        # Save summary
        summary = {
            "gym": gym_name,
            "model": model,
            "provider": provider,
            "arm": getattr(gym, "_arm_variant", gym_name),
            "reward": reward,
            "episodes": episodes,
            "gamma": gamma,
            "alpha": alpha,
            "epsilon_initial": epsilon,
            "epsilon_final": policy.epsilon,
            "epsilon_decay": epsilon_decay,
            "instances": len(gym_instances),
            "training_mean_reward": metrics["mean_reward"],
            "eval_mean_reward": eval_metrics["mean_reward"],
            "eval_success_rate": eval_metrics["success_rate"],
            "ap_ids": list(ap_ids),
        }
        summary_path = checkpoint_path / "training_summary.json"
        with open(summary_path, "w") as f:
            json.dump(summary, f, indent=2)
        click.echo(f"  Summary saved to {summary_path}")

        # Notify observer of successful completion
        if observer is not None and observer_run_id is not None:
            observer.on_run_complete(
                observer_run_id,
                training_mean_reward=metrics["mean_reward"],
                eval_mean_reward=eval_metrics["mean_reward"],
                eval_success_rate=eval_metrics["success_rate"],
            )

        click.echo("\nDone.")
    except BaseException:
        if observer is not None and observer_run_id is not None:
            observer.on_run_failed(observer_run_id)
        raise
    finally:
        gym.cleanup()


@cli.command()
@click.option(
    "--gym",
    "gym_name",
    required=True,
    type=click.Choice(sorted(GYM_REGISTRY)),
    help="Gym name",
)
@click.option(
    "--checkpoint",
    required=True,
    type=click.Path(exists=True, path_type=Path),
    help="Checkpoint dir",
)
@click.option("--model", default=None, help="Model ID (default: from checkpoint)")
@click.option(
    "--provider", default=None, help="LLM provider (default: from checkpoint)"
)
@click.option("--base-url", default="", help="API base URL")
@click.option("--api-key", default=None, help="API key")
@click.option(
    "--output-mode",
    default="tool",
    type=click.Choice(["tool", "prompted", "native"]),
    help="Structured output mode",
)
@click.option("--debug", is_flag=True, help="Debug logging")
def evaluate(  # noqa: PLR0913
    gym_name: str,
    checkpoint: Path,
    model: str | None,
    provider: str | None,
    base_url: str,
    api_key: str | None,
    output_mode: str,
    debug: bool,
) -> None:
    """Evaluate a trained policy on a gym (greedy)."""
    from atomicguard.infrastructure.persistence.filesystem import FilesystemArtifactDAG
    from atomicguard.tools.export_workflow import load_training_artifacts

    _configure_logging(debug)
    api_key = api_key or os.environ.get("LLM_API_KEY", "")

    policy, training_config, _metadata = load_training_artifacts(
        checkpoint, greedy=True
    )
    ap_ids = tuple(training_config.get("ap_ids", []))
    if not ap_ids:
        raise ValueError(
            "training_config.json missing 'ap_ids'. "
            "Re-run training to generate a valid checkpoint."
        )

    model = model or training_config.get("model", "qwen3-coder-next")
    provider = provider or training_config.get("provider", "ollama")
    reward_name = training_config.get("reward", "potential-based")
    max_steps = training_config.get("max_steps", 0)
    enable_backtracking = training_config.get("enable_backtracking", True)
    max_selections_per_ap = training_config.get("max_selections_per_ap") or 0
    num_instances = training_config.get("instances", 9)

    click.echo(f"Evaluating policy: {checkpoint}")
    click.echo(f"  Gym: {gym_name}, Model: {model} ({provider})")

    # Instantiate gym — inject application classes to satisfy DDD boundary
    from atomicguard.application.action_pair import ActionPair
    from atomicguard.application.agent import DualStateAgent
    from atomicguard.application.workflow import WorkflowOrchestrator

    gym_cls = GYM_REGISTRY[gym_name]
    gym = _instantiate_gym(
        gym_cls,
        gym_name,
        model=model,
        provider=provider,
        base_url=base_url,
        api_key=api_key,
        output_mode=output_mode,
        action_pair_cls=ActionPair,
        workflow_cls=WorkflowOrchestrator,
        agent_cls=DualStateAgent,
    )

    gym_instances = gym.get_instances(limit=num_instances)
    reward_fn = _get_reward_fn(reward_name)

    eval_dir = checkpoint / "eval"
    if (checkpoint / "latest").exists():
        eval_dir = (checkpoint / "latest").resolve() / "eval"
    eval_dir.mkdir(parents=True, exist_ok=True)

    max_steps_per_ep = max_steps if max_steps > 0 else max(2 * len(ap_ids), 1)

    click.echo(f"\nRunning greedy evaluation on {len(gym_instances)} instances...\n")

    results: list[dict] = []
    total_success = 0

    for inst in gym_instances:
        dag_dir = eval_dir / "artifact_dags" / inst.instance_id
        dag_dir.mkdir(parents=True, exist_ok=True)
        artifact_dag = FilesystemArtifactDAG(str(dag_dir))

        env = gym.build_environment(
            instance=inst,
            reward_fn=reward_fn,
            artifact_dag=artifact_dag,
            max_steps=max_steps if max_steps > 0 else None,
            enable_backtracking=enable_backtracking,
            max_selections_per_ap=max_selections_per_ap
            if max_selections_per_ap > 0
            else None,
        )

        state = env.reset()
        total_reward = 0.0
        steps = 0
        path_parts: list[str] = []

        for _step in range(max_steps_per_ep):
            action = policy.select_action(state)
            ap_id = ap_ids[action] if action < len(ap_ids) else f"action_{action}"
            state, reward_signal, done = env.execute_step(action)
            total_reward += reward_signal.value
            steps += 1
            passed = ap_id in state.satisfied
            path_parts.append(ap_id if passed else f"{ap_id}\u2717")
            if done:
                break

        ep_stats = env.get_episode_stats()
        success = bool(
            ep_stats.get("goal_reached", False) or ep_stats.get("all_satisfied", False)
        )
        if success:
            total_success += 1

        results.append(
            {
                "instance_id": inst.instance_id,
                "success": success,
                "steps": steps,
                "reward": total_reward,
                "path": path_parts,
            }
        )

        status = (
            click.style("PASS", fg="green")
            if success
            else click.style("FAIL", fg="red")
        )
        path_str = " \u2192 ".join(path_parts[-6:])
        if len(path_parts) > 6:
            path_str = "... \u2192 " + path_str
        click.echo(
            f"  {inst.instance_id:<35s} {status}  steps={steps:<3d} "
            f"reward={total_reward:<8.1f} {path_str}"
        )

    click.echo(f"\nResults: {total_success}/{len(gym_instances)} solved")
    if results:
        mean_reward = sum(r["reward"] for r in results) / len(results)
        click.echo(f"Mean reward: {mean_reward:.3f}")

    # Save eval results
    eval_results_path = eval_dir / "eval_results.json"
    eval_results_path.write_text(
        json.dumps(
            {
                "gym": gym_name,
                "model": model,
                "provider": provider,
                "solved": total_success,
                "total": len(gym_instances),
                "success_rate": total_success / len(gym_instances)
                if gym_instances
                else 0,
                "mean_reward": sum(r["reward"] for r in results) / len(results)
                if results
                else 0,
                "instances": [
                    {
                        "instance_id": r["instance_id"],
                        "success": r["success"],
                        "steps": r["steps"],
                        "reward": round(r["reward"], 3),
                        "path": r["path"],
                    }
                    for r in results
                ],
            },
            indent=2,
        )
        + "\n"
    )
    click.echo(f"Eval results saved to {eval_results_path}")


@cli.command()
@click.option(
    "--checkpoint",
    required=True,
    type=click.Path(exists=True, path_type=Path),
    help="Checkpoint dir",
)
def export(checkpoint: Path) -> None:
    """Export Q-table to workflow JSON."""
    from atomicguard.tools.export_workflow import (
        extract_greedy_ordering,
        infer_dependencies,
        load_training_artifacts,
    )

    policy, training_config, metadata = load_training_artifacts(checkpoint)
    ap_ids = tuple(training_config.get("ap_ids", []))
    if not ap_ids:
        raise ValueError(
            "training_config.json missing 'ap_ids'. "
            "Re-run training to generate a valid checkpoint."
        )

    click.echo(f"Loaded Q-table with {len(ap_ids)} APs: {list(ap_ids)}")

    ordering = extract_greedy_ordering(policy, ap_ids)
    click.echo("\nGreedy policy ordering:")
    for i, ap_id in enumerate(ordering, 1):
        click.echo(f"  {i}. {ap_id}")

    click.echo("\nQ-values from empty state:")
    q_row = policy.Q[0]
    for idx, ap_id in enumerate(ap_ids):
        click.echo(f"  {ap_id}: {q_row[idx]:.4f}")

    deps = infer_dependencies(policy, ap_ids)
    click.echo("\nInferred dependencies:")
    has_deps = False
    for ap_id, dep_list in deps.items():
        if dep_list:
            click.echo(f"  {ap_id} requires {dep_list}")
            has_deps = True
    if not has_deps:
        click.echo("  (none)")


if __name__ == "__main__":
    cli()
