"""Unified gym CLI — ``python -m atomicguard.gym``.

Provides ``train``, ``evaluate``, ``list``, and ``export`` subcommands
for gym-based RL training and policy evaluation.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from atomicguard.domain.gym import GymInterface

from atomicguard.infrastructure.gym import PreCommitGym

# Maps gym name → (class, default arm).
# The gym name is passed as the ``arm`` kwarg to the constructor.
GYM_REGISTRY: dict[str, type[GymInterface]] = {
    "precommit_python": PreCommitGym,
}

__all__ = ["GYM_REGISTRY"]
