"""Word built-in style lookup utilities.

Thin API over the style definitions in word_builtin_defs.py.
"""

from __future__ import annotations

from typing import List, Optional

from tokenmoulds.styles.word_builtin_defs import (  # noqa: F401
    BUILTIN_STYLE_COUNT,
    BUILTIN_STYLES,
    BuiltinStyleDef,
    LINKED_STYLES,
    StyleCategory,
    StyleType,
    TABLE_STYLE_BASES,
)


def get_builtin_styles_by_category(category: StyleCategory) -> List[BuiltinStyleDef]:
    """Get all built-in styles in a category."""
    return [s for s in BUILTIN_STYLES if s.category == category]


def get_builtin_styles_by_type(style_type: StyleType) -> List[BuiltinStyleDef]:
    """Get all built-in styles of a type."""
    return [s for s in BUILTIN_STYLES if s.style_type == style_type]


def get_builtin_style(style_id: str) -> Optional[BuiltinStyleDef]:
    """Get a built-in style by ID."""
    for style in BUILTIN_STYLES:
        if style.style_id == style_id:
            return style
    return None
