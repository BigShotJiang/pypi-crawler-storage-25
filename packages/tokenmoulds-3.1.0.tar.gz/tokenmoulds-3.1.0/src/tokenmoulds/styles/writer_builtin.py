"""ODF Writer built-in style lookup utilities.

Thin re-export layer over writer_builtin_defs.py.
"""

from __future__ import annotations

from tokenmoulds.styles.writer_builtin_defs import (  # noqa: F401
    OdfBuiltinStyleDef,
    OdfStyleCategory,
    OdfStyleFamily,
    WRITER_BUILTIN_STYLE_COUNT,
    WRITER_BUILTIN_STYLES,
)
