"""Slide layout geometry mixin for the PowerPoint emitter.

Handles layout placeholder positioning, semantic region mapping, and
cross-aspect-ratio scaling of slide layouts.
"""

from __future__ import annotations

from lxml import etree

from tokenmoulds.dtcg.layout_recipe_resolver import (
    get_semantic_layout_spec_for_pptx_layout_number,
)
from tokenmoulds.emitters.ooxml_base import A_NS
from tokenmoulds.emitters.pptx_shape_helpers import (
    PRESENTATIONML_NS,
    find_shape_by_placeholder,
    set_shape_rect,
)


class PowerPointLayoutMixin:
    """Mixin providing slide layout geometry and scaling."""

    @staticmethod
    def _layout_number_from_entry_path(entry_path: str) -> int | None:
        """Return the numeric PPTX layout number from an archive entry path."""
        prefix = "ppt/slideLayouts/slideLayout"
        suffix = ".xml"
        if not (entry_path.startswith(prefix) and entry_path.endswith(suffix)):
            return None
        try:
            return int(entry_path[len(prefix) : -len(suffix)])
        except ValueError:
            return None

    def _resolved_regions_for_layout(
        self, layout_name: str
    ) -> dict[str, tuple[int, int, int, int]]:
        """Return resolved EMU regions for the requested layout name."""
        layout = self.document.presentation_layout  # type: ignore[attr-defined]
        if layout_name == layout.layout_name and layout.regions:
            return layout.regions
        return getattr(layout, "layout_regions", {}).get(layout_name, {})

    def _customize_slide_layout_ssot(self, entry_path: str, data: bytes) -> bytes:
        """Scale bundled layouts and patch semantic layout placeholder geometry."""
        from tokenmoulds.design.layout_defaults import (
            SLIDE_16_9_HEIGHT_EMU,
            SLIDE_16_9_WIDTH_EMU,
        )

        root = etree.fromstring(data)
        slide_width, slide_height = self._get_slide_dimensions_emu()
        if slide_width != SLIDE_16_9_WIDTH_EMU or slide_height != SLIDE_16_9_HEIGHT_EMU:
            self._scale_layout_geometry(
                root,
                target_width=slide_width,
                target_height=slide_height,
                base_width=SLIDE_16_9_WIDTH_EMU,
                base_height=SLIDE_16_9_HEIGHT_EMU,
            )

        layout_number = self._layout_number_from_entry_path(entry_path)
        semantic_spec = (
            get_semantic_layout_spec_for_pptx_layout_number(layout_number)
            if layout_number is not None
            else None
        )
        if semantic_spec is not None:
            if semantic_spec.pptx_base_type is not None:
                root.set("type", semantic_spec.pptx_base_type)
            common_slide = root.find(f"{{{PRESENTATIONML_NS}}}cSld")
            if common_slide is not None:
                common_slide.set("name", semantic_spec.display_name)
            region_positions = self._resolved_regions_for_layout(semantic_spec.name)
            for region_name, (ph_type, ph_idx) in semantic_spec.placeholder_map.items():
                rect = region_positions.get(region_name)
                if rect is None:
                    continue
                shape = find_shape_by_placeholder(root, ph_type=ph_type, ph_idx=ph_idx)
                if shape is None:
                    continue
                set_shape_rect(shape, rect)
        return self._serialize_tree(root)  # type: ignore[attr-defined]

    def _get_slide_dimensions_emu(self) -> tuple[int, int]:
        """Return emitted slide dimensions from presentation layout."""
        from tokenmoulds.design.layout_defaults import (
            SLIDE_16_9_HEIGHT_EMU,
            SLIDE_16_9_WIDTH_EMU,
        )

        layout = self.document.presentation_layout  # type: ignore[attr-defined]
        slide_width = int(getattr(layout, "slide_width", 0) or 0)
        slide_height = int(getattr(layout, "slide_height", 0) or 0)
        if slide_width <= 0 or slide_height <= 0:
            return SLIDE_16_9_WIDTH_EMU, SLIDE_16_9_HEIGHT_EMU
        return slide_width, slide_height

    @staticmethod
    def _scale_layout_geometry(
        root: etree._Element,
        *,
        target_width: int,
        target_height: int,
        base_width: int,
        base_height: int,
    ) -> None:
        """Scale absolute layout transforms from the template base slide size."""

        def scale_emu(
            value: str | None, numerator: int, denominator: int
        ) -> str | None:
            if value is None:
                return None
            try:
                emu = int(value)
            except ValueError:
                return value
            return str((emu * numerator + (denominator // 2)) // denominator)

        for xfrm in root.findall(f".//{{{A_NS}}}xfrm"):
            for child_name, x_ratio, y_ratio in (
                ("off", (target_width, base_width), (target_height, base_height)),
                ("ext", (target_width, base_width), (target_height, base_height)),
                ("chOff", (target_width, base_width), (target_height, base_height)),
                ("chExt", (target_width, base_width), (target_height, base_height)),
            ):
                child = xfrm.find(f"{{{A_NS}}}{child_name}")
                if child is None:
                    continue
                scaled_x = scale_emu(child.get("x"), *x_ratio)
                scaled_y = scale_emu(child.get("y"), *y_ratio)
                scaled_cx = scale_emu(child.get("cx"), *x_ratio)
                scaled_cy = scale_emu(child.get("cy"), *y_ratio)
                if scaled_x is not None:
                    child.set("x", scaled_x)
                if scaled_y is not None:
                    child.set("y", scaled_y)
                if scaled_cx is not None:
                    child.set("cx", scaled_cx)
                if scaled_cy is not None:
                    child.set("cy", scaled_cy)
