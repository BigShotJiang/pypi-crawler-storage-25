"""Shared color utilities for TokenMoulds.

Lightweight imports (models, parser) are loaded eagerly so that
``from tokenmoulds.colors import parse_color`` always works.

Heavy imports that pull in numpy / Pillow / etc. are loaded lazily on
first attribute access so that the package remains importable even when
optional dependencies are not installed.
"""

from __future__ import annotations

import importlib
from typing import TYPE_CHECKING

# Lightweight – always available
from .models import Color
from .parser import parse_color, hex_to_ooxml_rgb, hex_to_ooxml_argb

if TYPE_CHECKING:
    # Let type-checkers see everything without lazy-loading
    from .analysis import summarize_palette as summarize_palette
    from .service import (
        ColorNormalizer as ColorNormalizer,
        ColorNormalization as ColorNormalization,
        ColorEngine as ColorEngine,
        NormalizedImage as NormalizedImage,
    )
    from .spaces import (
        ColorSpaceConverter as ColorSpaceConverter,
        ColorSpaceResult as ColorSpaceResult,
    )
    from .accessibility import (
        contrast_ratio as contrast_ratio,
        ensure_contrast as ensure_contrast,
        generate_tints as generate_tints,
        generate_shades as generate_shades,
    )
    from .colorblind import simulate_palette as simulate_colorblind_palette
    from .palette import (
        ThemeSlot as ThemeSlot,
        TransformType as TransformType,
        ColorVariant as ColorVariant,
        ThemePalette as ThemePalette,
        generate_palette as generate_palette,
    )

__all__ = [
    "Color",
    "parse_color",
    "hex_to_ooxml_rgb",
    "hex_to_ooxml_argb",
    "summarize_palette",
    "ColorNormalizer",
    "ColorNormalization",
    "ColorEngine",
    "NormalizedImage",
    "ColorSpaceConverter",
    "ColorSpaceResult",
    "contrast_ratio",
    "ensure_contrast",
    "generate_tints",
    "generate_shades",
    "simulate_colorblind_palette",
    # Palette generation
    "ThemeSlot",
    "TransformType",
    "ColorVariant",
    "ThemePalette",
    "generate_palette",
]

# Mapping from public name -> (submodule, real attribute name)
_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "summarize_palette": (".analysis", "summarize_palette"),
    "ColorNormalizer": (".service", "ColorNormalizer"),
    "ColorNormalization": (".service", "ColorNormalization"),
    "ColorEngine": (".service", "ColorEngine"),
    "NormalizedImage": (".service", "NormalizedImage"),
    "ColorSpaceConverter": (".spaces", "ColorSpaceConverter"),
    "ColorSpaceResult": (".spaces", "ColorSpaceResult"),
    "contrast_ratio": (".accessibility", "contrast_ratio"),
    "ensure_contrast": (".accessibility", "ensure_contrast"),
    "generate_tints": (".accessibility", "generate_tints"),
    "generate_shades": (".accessibility", "generate_shades"),
    "simulate_colorblind_palette": (".colorblind", "simulate_palette"),
    "ThemeSlot": (".palette", "ThemeSlot"),
    "TransformType": (".palette", "TransformType"),
    "ColorVariant": (".palette", "ColorVariant"),
    "ThemePalette": (".palette", "ThemePalette"),
    "generate_palette": (".palette", "generate_palette"),
}


def __getattr__(name: str) -> object:
    if name in _LAZY_IMPORTS:
        module_path, attr = _LAZY_IMPORTS[name]
        module = importlib.import_module(module_path, __package__)
        value = getattr(module, attr)
        # Cache on the module so subsequent access is fast
        globals()[name] = value
        return value
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
