import contextlib
import json
import os
import platform
import re
import shutil
import socket
import sqlite3
import sys
from collections.abc import Callable, Sequence
from datetime import timedelta
from pathlib import Path
from typing import Any

from prescribe._util import _MISSING, mapping_value, sha256_bytes
from prescribe.adapters import adapter_for_path
from prescribe.asset_helpers import (
    AssetDestinationState,
    asset_destination_state,
    asset_diff,
    asset_entries,
    asset_extra_paths,
    asset_replace_diff,
    format_permissions,
    unsafe_asset_replace_reason,
)
from prescribe.atomic import atomic_write_bytes, permission_bits
from prescribe.backups import copy_to_recovery_backup, move_to_backup, restore_backup
from prescribe.claims import (
    Claim,
    ClaimConflict,
    ClaimResolver,
    check_claim_conflicts,
    check_claim_conflicts_against,
    claim_key,
    compute_claims,
    detect_internal_claim_conflicts,
    persist_claims,
)
from prescribe.core import DesiredState, Planner, detect_conflict
from prescribe.core.apply import apply_operations
from prescribe.core.conflict import (
    ConflictResult,
    FileFingerprint,
    file_fingerprint,
)
from prescribe.core.planner import PlannedOperation
from prescribe.core.result import OrchestrationResult
from prescribe.document import Adapter, Document
from prescribe.encoding import decode_utf8_bytes, read_utf8_text
from prescribe.fs_safety import (
    ensure_safe_asset_source_path,
    ensure_safe_managed_write_path,
)
from prescribe.lock_heartbeat import LockHeartbeat, LockLostError
from prescribe.rollback import ConflictResolver, perform_rollback
from prescribe.shell import render_shell_block
from prescribe.spec import AssetTarget, EnvTarget, FileTarget, ShellTarget, Spec
from prescribe.state import StateStore
from prescribe.state.sqlite import ChangeBatchRecord


class _DeferredClaimConflict(Exception):
    def __init__(self, conflict: ClaimConflict) -> None:
        super().__init__("claim conflict while committing state")
        self.conflict = conflict


class _ReservationConflict(Exception):
    def __init__(self, claim: Claim, existing_owner: str) -> None:
        super().__init__("claim reservation conflict")
        self.claim = claim
        self.existing_owner = existing_owner


class _PostWriteStateError(Exception):
    pass


class InterruptedWorkError(Exception):
    def __init__(self, attempts: list[Any]) -> None:
        super().__init__("interrupted prescribe operation detected")
        self.attempts = attempts


PLATFORM_MATCHERS: dict[str, Callable[[], bool]] = {
    "linux": lambda: sys.platform.startswith("linux"),
    "macos": lambda: sys.platform == "darwin",
    "windows": lambda: sys.platform == "win32",
    "wsl": lambda: sys.platform.startswith("linux") and _is_wsl(),
}


def current_arch() -> str:
    return _normalize_arch(platform.machine())


def current_machine() -> str:
    override = os.environ.get("PRESCRIBE_MACHINE")
    if override:
        return override
    return socket.gethostname().split(".")[0]


def platform_matches(selectors: list[str]) -> bool:
    if not selectors:
        return True
    return any(PLATFORM_MATCHERS.get(selector, lambda: False)() for selector in selectors)


def arch_matches(selectors: list[str]) -> bool:
    if not selectors:
        return True
    arch = current_arch()
    return any(_normalize_arch(selector) == arch or selector == "all" for selector in selectors)


def _normalize_arch(value: str) -> str:
    normalized = value.strip().lower().replace("-", "_")
    if normalized in {"amd64", "x64"}:
        return "x86_64"
    if normalized in {"aarch64", "arm64e"}:
        return "arm64"
    if normalized in {"i386", "i686", "x86_32"}:
        return "x86"
    if normalized.startswith("armv7"):
        return "armv7"
    return normalized


def _is_wsl() -> bool:
    try:
        return "microsoft" in Path("/proc/version").read_text(encoding="utf-8", errors="replace").lower()
    except OSError:
        return False


def machine_matches(selectors: list[str]) -> bool:
    if not selectors:
        return True
    machine = current_machine()
    return any(selector == machine or selector == "all" for selector in selectors)


def condition_matches(
    *,
    target: FileTarget | EnvTarget | ShellTarget | AssetTarget,
    tags: set[str] | None = None,
    skip_tags: set[str] | None = None,
) -> bool:
    """Check all gating conditions for a target. True = should process."""
    return condition_skip_reason(target=target, tags=tags, skip_tags=skip_tags) is None


def condition_skip_reason(
    *,
    target: FileTarget | EnvTarget | ShellTarget | AssetTarget,
    tags: set[str] | None = None,
    skip_tags: set[str] | None = None,
) -> str | None:
    if not platform_matches(target.platforms):
        return "platform did not match"
    if not arch_matches(getattr(target, "arch", [])):
        return "architecture did not match"
    if not machine_matches(target.machine):
        return "machine did not match"

    target_tags = getattr(target, "tags", None) or []
    if tags is not None and not (tags & set(target_tags)):
        return "tags did not match"
    if skip_tags is not None and (skip_tags & set(target_tags)):
        return "skip-tags matched"

    if hasattr(target, "if_command_exists"):
        for cmd in getattr(target, "if_command_exists", []):
            if shutil.which(cmd) is None:
                return f"command not found: {cmd}"

    if hasattr(target, "if_env_missing") and getattr(target, "if_env_missing", False):
        name = getattr(target, "name", None)
        if name and name in os.environ:
            return f"env var already set: {name}"

    return None


def _spec_hash(spec: Spec) -> bytes:
    """Compute a deterministic content hash for a Spec object."""
    data = {
        "id": spec.id,
        "files": [
            {
                "path": str(f.path),
                "format": f.format,
                "data": f.data,
                "delete": f.delete,
                "managed_block_id": f.managed_block_id,
                "lines": f.lines,
            }
            for f in spec.files
        ],
        "env": [{"name": e.name, "value": e.value} for e in spec.env],
        "shell": [{"path": str(s.path), "managed_block_id": s.managed_block_id} for s in spec.shell],
        "assets": [
            {
                "source": a.source,
                "dest": str(a.dest),
                "mode": a.mode,
                "delete_extra": a.delete_extra,
                "paths": [str(path) for path in a.paths],
                "replace": a.replace,
                "max_displace_bytes": a.max_displace_bytes,
                "allow_binary": a.allow_binary,
            }
            for a in spec.assets
        ],
    }
    return sha256_bytes(json.dumps(data, sort_keys=True, default=str).encode())


class Orchestrator:
    def __init__(
        self,
        state_store: StateStore,
        *,
        _materialize_fn: Callable[..., None] | None = None,
        lock_ttl: timedelta = timedelta(seconds=30),
        lock_heartbeat_interval: timedelta = timedelta(seconds=10),
    ) -> None:
        self.state_store = state_store
        self.planner = Planner()
        self._materialize_fn = _materialize_fn
        self._lock_ttl = lock_ttl
        self._lock_heartbeat_interval = lock_heartbeat_interval

    def run(
        self,
        spec: Path | str | Spec,
        *,
        tool_version: str | None = None,
        dry_run: bool = False,
        tags: set[str] | None = None,
        skip_tags: set[str] | None = None,
        diff: bool = False,
        explain_skips: bool = False,
        claim_resolver: ClaimResolver | None = None,
        file_skip_reasons: dict[int, str] | None = None,
    ) -> list[OrchestrationResult]:
        from prescribe.spec import SpecLoader

        if isinstance(spec, (Path, str)):
            spec_path = Path(spec)
            spec_obj = SpecLoader().load(spec_path)
            spec_hash = sha256_bytes(spec_path.read_bytes())
        else:
            spec_obj = spec
            spec_hash = _spec_hash(spec_obj)

        claims = _active_claims(spec_obj, tags=tags, skip_tags=skip_tags, file_skip_reasons=file_skip_reasons)
        claim_conflicts = detect_internal_claim_conflicts(claims)
        if claim_conflicts:
            return [_claim_conflict_result(claim_conflicts[0])]

        if dry_run:
            claim_check = check_claim_conflicts_against(
                self.state_store.claims_for_dry_run(),
                claims,
                resolver=claim_resolver,
            )
            if claim_check.conflicts:
                return [_claim_conflict_result(claim_check.conflicts[0])]
            return self._run_all(
                run_id=None,
                spec_hash=spec_hash,
                spec=spec_obj,
                dry_run=True,
                tags=tags,
                skip_tags=skip_tags,
                diff=diff,
                explain_skips=explain_skips,
                file_skip_reasons=file_skip_reasons,
            )

        self.state_store.initialize()
        lock_owner = _lock_owner()
        lock = self.state_store.acquire_lock("global", owner=lock_owner, ttl=self._lock_ttl)
        if not lock.acquired:
            return [
                OrchestrationResult(
                    status="error",
                    applied=False,
                    changed=False,
                    error=f"another prescribe write is active: {lock.owner} until {lock.expires_at.isoformat()}",
                )
            ]
        try:
            with LockHeartbeat(
                self.state_store,
                name="global",
                owner=lock_owner,
                token=lock.token,
                ttl=self._lock_ttl,
                interval=self._lock_heartbeat_interval,
            ) as heartbeat:
                unfinished = self.state_store.unfinished_target_attempts()
                if unfinished:
                    raise InterruptedWorkError(unfinished)
                heartbeat.require_current()
                claim_check = check_claim_conflicts(
                    self.state_store,
                    claims,
                    resolver=claim_resolver,
                )
                if claim_check.conflicts:
                    return [_claim_conflict_result(claim_check.conflicts[0])]
                heartbeat.require_current()
                with self.state_store.transaction() as connection:
                    run = self.state_store.start_run(
                        spec_hash=spec_hash,
                        tool_version=tool_version,
                        platform=sys.platform,
                        host=current_machine(),
                        command="apply",
                        cwd=Path.cwd(),
                        connection=connection,
                    )
                    self._reserve_claims(run.id, lock.token or lock_owner, claims, connection=connection)
                    self._record_target_attempts(run.id, claims, connection=connection)
                heartbeat.require_current()
                results = self._run_all(
                    run_id=run.id,
                    spec_hash=spec_hash,
                    spec=spec_obj,
                    dry_run=False,
                    tags=tags,
                    skip_tags=skip_tags,
                    diff=diff,
                    explain_skips=explain_skips,
                    file_skip_reasons=file_skip_reasons,
                    require_current=heartbeat.require_current,
                )
                heartbeat.require_current()
                with self.state_store.transaction() as connection:
                    successful_ids = _successful_target_ids(spec_obj, results)
                    successful_claims = [claim for claim in claims if claim.target_id in successful_ids]
                    failed_ids = {claim.target_id for claim in claims if claim.target_id is not None} - successful_ids
                    self.state_store.update_target_attempts(
                        run_id=run.id,
                        target_ids=successful_ids,
                        phase="succeeded",
                        connection=connection,
                    )
                    self.state_store.update_target_attempts(
                        run_id=run.id,
                        target_ids=failed_ids,
                        phase="failed",
                        connection=connection,
                    )
                    claim_conflicts = persist_claims(
                        self.state_store,
                        successful_claims,
                        resolver=lambda conflict: claim_key(conflict.claim) in claim_check.take_keys,
                        connection=connection,
                    )
                    if claim_conflicts:
                        raise _DeferredClaimConflict(claim_conflicts[0])
                    self._record_target_runs(run.id, spec_obj, results, connection=connection)
                    status = (
                        "failed" if any(result.status in {"error", "conflict"} for result in results) else "completed"
                    )
                    reservation_status = "promoted" if status == "completed" else "failed"
                    self.state_store.release_claim_reservations(
                        run_id=run.id,
                        token=lock.token or lock_owner,
                        status=reservation_status,
                        connection=connection,
                    )
                    self.state_store.finish_run(run.id, status=status, connection=connection)
                return results
        except LockLostError as exc:
            return [
                OrchestrationResult(
                    status="error",
                    applied=False,
                    changed=True,
                    error=str(exc),
                )
            ]
        except _PostWriteStateError as exc:
            return [
                OrchestrationResult(
                    status="error",
                    applied=False,
                    changed=True,
                    error=str(exc),
                )
            ]
        except _DeferredClaimConflict as exc:
            return [_claim_conflict_result(exc.conflict)]
        except _ReservationConflict as exc:
            return [
                OrchestrationResult(
                    status="error",
                    applied=False,
                    changed=False,
                    error=(
                        "claim reservation conflict: "
                        f"{exc.claim.target_type} {exc.claim.subject} {exc.claim.address} "
                        f"is reserved by {exc.existing_owner}"
                    ),
                )
            ]
        except InterruptedWorkError as exc:
            return [_interrupted_work_result(exc.attempts)]
        finally:
            self.state_store.release_lock("global", owner=lock_owner, token=lock.token)

    def recover_interrupted(
        self,
        *,
        dry_run: bool = False,
        force: bool = False,
    ) -> OrchestrationResult:
        self.state_store.initialize()
        attempts = self.state_store.unfinished_target_attempts()
        if not attempts:
            return OrchestrationResult(status="noop", applied=False, changed=False, dry_run=dry_run)
        if dry_run or not force:
            return OrchestrationResult(
                status="dry-run" if dry_run else "error",
                applied=False,
                changed=True,
                dry_run=dry_run,
                error=_interrupted_work_message(attempts),
            )
        with self.state_store.transaction() as connection:
            self.state_store.update_target_attempt_ids(
                {attempt.id for attempt in attempts},
                phase="interrupted",
                error="force-cleared by recover_interrupted",
                connection=connection,
            )
            self.state_store.expire_claim_reservations_for_attempts(attempts, connection=connection)
        return OrchestrationResult(status="applied", applied=True, changed=True)

    def _reserve_claims(
        self,
        run_id: int,
        token: str,
        claims: list[Claim],
        *,
        connection: sqlite3.Connection,
    ) -> None:
        for claim in claims:
            reservation = self.state_store.reserve_claim(
                target_type=claim.target_type,
                subject=claim.subject,
                address=claim.address,
                owner_id=claim.owner_id,
                run_id=run_id,
                token=token,
                connection=connection,
            )
            if reservation.token != token or reservation.owner_id != claim.owner_id:
                raise _ReservationConflict(claim, reservation.owner_id)

    def _record_target_attempts(
        self,
        run_id: int,
        claims: list[Claim],
        *,
        connection: sqlite3.Connection,
    ) -> None:
        for claim in claims:
            self.state_store.record_target_attempt(
                run_id=run_id,
                target_type=claim.target_type,
                target_id=claim.target_id,
                subject=claim.subject,
                address=claim.address,
                owner_id=claim.owner_id,
                phase="attempting",
                connection=connection,
            )

    def _record_target_runs(
        self,
        run_id: int,
        spec: Spec,
        results: list[OrchestrationResult],
        *,
        connection: sqlite3.Connection | None = None,
    ) -> None:
        spec_run = self.state_store.record_spec_run(
            run_id=run_id,
            spec_path=spec.path,
            spec_hash=None,
            order_index=0,
            valid=True,
            connection=connection,
        )
        for result, (target_type, target) in zip(results, _iter_targets_for_ledger(spec), strict=False):
            self.state_store.record_target_run(
                run_id=run_id,
                spec_run_id=spec_run.id,
                target_type=target_type,
                path_or_name=_target_label(target_type, target),
                status=result.status,
                changed=result.changed,
                skip_reason=result.skip_reason,
                connection=connection,
            )

    def _run_all(
        self,
        run_id: int | None,
        spec_hash: bytes,
        spec: Spec,
        *,
        dry_run: bool = False,
        tags: set[str] | None = None,
        skip_tags: set[str] | None = None,
        diff: bool = False,
        explain_skips: bool = False,
        file_skip_reasons: dict[int, str] | None = None,
        connection: sqlite3.Connection | None = None,
        require_current: Callable[[], None] | None = None,
    ) -> list[OrchestrationResult]:
        results: list[OrchestrationResult] = []

        # ── files ──
        # Resolve active vs skipped, but produce results in spec.files order
        # so that CLI/JSON pairing stays aligned.
        active_files, skipped_files = _resolve_active_files(spec.files, tags=tags, skip_tags=skip_tags)
        for file_target in spec.files:
            directory_skip_reason = (file_skip_reasons or {}).get(id(file_target))
            if directory_skip_reason is not None or file_target in skipped_files or file_target not in active_files:
                reason = condition_skip_reason(target=file_target, tags=tags, skip_tags=skip_tags)
                if directory_skip_reason is not None:
                    reason = directory_skip_reason
                elif reason is None:
                    winner = _active_file_for_path(active_files, file_target.path)
                    reason = _priority_skip_reason(file_target, winner)
                results.append(
                    OrchestrationResult(
                        status="skipped",
                        applied=False,
                        changed=False,
                        skipped=True,
                        skip_reason=reason if explain_skips else None,
                    )
                )
                continue
            if not dry_run and require_current is not None:
                require_current()
            results.append(
                self._handle_file(
                    run_id,
                    spec_hash,
                    file_target,
                    dry_run=dry_run,
                    tags=tags,
                    skip_tags=skip_tags,
                    diff=diff,
                    explain_skips=explain_skips,
                    connection=connection,
                    require_current=require_current,
                )
            )
            if not dry_run and require_current is not None:
                require_current()

        # ── env ──
        resolved_env, materialize_names = self._resolve_env(spec.env, tags=tags, skip_tags=skip_tags)

        # Materialize env vars to OS-level store
        materialize_errors: list[str] = []
        if not dry_run and materialize_names:
            if require_current is not None:
                require_current()
            mat_env = {k: v for k, v in resolved_env.items() if k in materialize_names}
            materialize_errors.extend(self._do_materialize(mat_env))
            if require_current is not None:
                require_current()

        # Produce an env result so callers can inspect resolved vars
        # even when there are no [[files]] or [[shell]] targets
        if spec.env and not spec.files and not spec.shell and not spec.assets:
            results.append(
                OrchestrationResult(
                    status="error" if materialize_errors else ("applied" if not dry_run else "dry-run"),
                    applied=not dry_run and not materialize_errors,
                    changed=bool(resolved_env),
                    env_vars=resolved_env,
                    dry_run=dry_run,
                    error=_materialize_error_message(materialize_errors) if materialize_errors else None,
                )
            )

        # ── shell blocks ──
        for shell_target in spec.shell:
            shell_type = _shell_type_for_target(shell_target)
            shell_env, _ = self._resolve_env(
                spec.env,
                tags=tags,
                skip_tags=skip_tags,
                shell_type=shell_type,
                include_current_path=False,
            )
            result = self._handle_shell(
                run_id,
                spec_hash,
                shell_target,
                shell_env,
                dry_run=dry_run,
                tags=tags,
                skip_tags=skip_tags,
                diff=diff,
                explain_skips=explain_skips,
                connection=connection,
                require_current=require_current,
            )
            result.env_vars = shell_env
            results.append(result)

        # ── assets ──
        for asset_target in spec.assets:
            if not dry_run and require_current is not None:
                require_current()
            results.append(
                self._handle_asset(
                    run_id,
                    spec_hash,
                    asset_target,
                    dry_run=dry_run,
                    tags=tags,
                    skip_tags=skip_tags,
                    diff=diff,
                    explain_skips=explain_skips,
                    connection=connection,
                    require_current=require_current,
                )
            )
            if not dry_run and require_current is not None:
                require_current()

        # Attach env vars and materialize errors to all results for convenience
        for r in results:
            if not r.env_vars:
                r.env_vars = resolved_env
            if materialize_errors:
                r.materialize_errors = materialize_errors

        if materialize_errors and not (spec.env and not spec.files and not spec.shell and not spec.assets):
            results.append(
                OrchestrationResult(
                    status="error",
                    applied=False,
                    changed=False,
                    error=_materialize_error_message(materialize_errors),
                    env_vars=resolved_env,
                    materialize_errors=materialize_errors,
                )
            )

        return results

    # ── asset handling ────────────────────────────────

    def _handle_asset(
        self,
        run_id: int | None,
        spec_hash: bytes,
        target: AssetTarget,
        *,
        dry_run: bool = False,
        tags: set[str] | None = None,
        skip_tags: set[str] | None = None,
        diff: bool = False,
        explain_skips: bool = False,
        connection: sqlite3.Connection | None = None,
        require_current: Callable[[], None] | None = None,
    ) -> OrchestrationResult:
        if not condition_matches(target=target, tags=tags, skip_tags=skip_tags):
            return OrchestrationResult(
                status="skipped",
                applied=False,
                changed=False,
                skipped=True,
                skip_reason=condition_skip_reason(target=target, tags=tags, skip_tags=skip_tags)
                if explain_skips
                else None,
            )

        try:
            entries = asset_entries(target)
            if not entries:
                return OrchestrationResult(
                    status="error",
                    applied=False,
                    changed=False,
                    error=f"asset source matched no files: {target.source}",
                )

            replace_extras: list[Path] = []
            if target.replace:
                replace_extras = asset_extra_paths(target, entries)
                unsafe = unsafe_asset_replace_reason(target, replace_extras)
                if unsafe is not None:
                    return OrchestrationResult(status="error", applied=False, changed=False, error=unsafe)
            for source, dest in entries:
                ensure_safe_asset_source_path(source)
                ensure_safe_managed_write_path(dest, operation="asset write")

            changed = False
            diffs: list[str] = []
            for source, dest in entries:
                source_bytes = source.read_bytes()
                source_text = decode_utf8_bytes(source_bytes, path=source)
                current = asset_destination_state(dest)
                if current.text == source_text and not current.is_symlink and current.hardlink_count <= 1:
                    if run_id is not None and not dry_run:
                        stat = dest.stat()
                        self.state_store.record_checked(
                            run_id=run_id,
                            path=dest,
                            content_hash=sha256_bytes(dest.read_bytes()),
                            size=stat.st_size,
                            mtime_ns=stat.st_mtime_ns,
                            format="asset",
                            spec_hash=spec_hash,
                            summary="no changes",
                            connection=connection,
                        )
                    continue

                conflict = None
                if dry_run and run_id is None:
                    with self.state_store.dry_run_connection() as read_conn:
                        if read_conn is not None:
                            conflict = self._asset_conflict(dest, connection=read_conn)
                else:
                    conflict = self._asset_conflict(dest, connection=connection)
                if conflict is not None:
                    if run_id is not None and not dry_run:
                        self._record_conflict(run_id, conflict, connection=connection)
                    return OrchestrationResult(
                        status="conflict",
                        applied=False,
                        changed=True,
                        conflict=conflict,
                        dry_run=dry_run,
                    )

                changed = True
                if diff:
                    diffs.append(asset_diff(dest, current.text, source_text))
                if not dry_run:
                    if require_current is not None:
                        require_current()
                    self._apply_asset(
                        run_id=run_id,
                        spec_hash=spec_hash,
                        source_bytes=source_bytes,
                        source_permissions=permission_bits(source),
                        dest=dest,
                        original=current,
                        connection=connection,
                        require_current=require_current,
                    )

            if target.replace and replace_extras:
                changed = True
                if diff:
                    diffs.append(asset_replace_diff(replace_extras))
                if not dry_run:
                    for extra in replace_extras:
                        if require_current is not None:
                            require_current()
                        self._displace_asset_extra(
                            run_id=run_id,
                            target=target,
                            path=extra,
                            connection=connection,
                            require_current=require_current,
                        )

            if not changed:
                return OrchestrationResult(
                    status="dry-run" if dry_run else "noop",
                    applied=False,
                    changed=False,
                    dry_run=dry_run,
                )
            return OrchestrationResult(
                status="dry-run" if dry_run else "applied",
                applied=not dry_run,
                changed=True,
                dry_run=dry_run,
                diff="".join(diffs) if diffs else None,
            )
        except _PostWriteStateError:
            raise
        except LockLostError:
            raise
        except Exception as exc:
            if run_id is not None:
                self.state_store.record_event(
                    run_id=run_id,
                    event_type="error",
                    path=target.dest,
                    changed=False,
                    summary=str(exc),
                    details=f"{exc.__class__.__name__}: {exc}",
                    connection=connection,
                )
            return OrchestrationResult(status="error", applied=False, changed=False, error=str(exc))

    def _asset_conflict(
        self,
        dest: Path,
        *,
        connection: sqlite3.Connection | None = None,
    ) -> ConflictResult | None:
        snapshot = self.state_store.latest_snapshot(dest, connection=connection)
        if snapshot is None or not dest.exists():
            return None
        baseline = file_fingerprint(
            snapshot.path,
            snapshot.hash_algo,
            snapshot.content_hash,
            snapshot.size,
            snapshot.mtime_ns,
        )
        current = _current_fingerprint(dest)
        return detect_conflict(baseline, current)

    def _apply_asset(
        self,
        *,
        run_id: int | None,
        spec_hash: bytes,
        source_bytes: bytes,
        source_permissions: int,
        dest: Path,
        original: AssetDestinationState,
        connection: sqlite3.Connection | None = None,
        require_current: Callable[[], None] | None = None,
    ) -> None:
        if run_id is None:
            raise RuntimeError("run_id is None in _apply_asset")
        original_exists = original.exists
        dest.parent.mkdir(parents=True, exist_ok=True)
        permissions = original.permissions if original.permissions is not None else source_permissions
        source_text = decode_utf8_bytes(source_bytes, path=dest)
        if require_current is not None:
            require_current()
        if original_exists and dest.exists():
            self._record_recovery_backup(
                run_id=run_id,
                path=dest,
                target_kind="asset",
                operation="asset-write",
                connection=connection,
            )
            if require_current is not None:
                require_current()
        atomic_write_bytes(dest, source_bytes, permissions=permissions)
        stat = dest.stat()
        content_hash = sha256_bytes(dest.read_bytes())
        try:
            existing_baseline = self.state_store.original_baseline(dest, connection=connection)
            if existing_baseline is None:
                self.state_store.record_baseline(
                    run_id=run_id,
                    path=dest,
                    content_text=original.text or "",
                    format="asset",
                    original_exists=original_exists,
                    connection=connection,
                )
            self.state_store.record_checkpoint(
                run_id=run_id,
                path=dest,
                content_text=source_text,
                format="asset",
                original_exists=original_exists,
                connection=connection,
            )
            self.state_store.record_snapshot(
                run_id=run_id,
                path=dest,
                content_hash=content_hash,
                size=stat.st_size,
                mtime_ns=stat.st_mtime_ns,
                format="asset",
                spec_hash=spec_hash,
                connection=connection,
            )
            self.state_store.record_change_batch(
                run_id=run_id,
                path=dest,
                operations=[
                    {
                        "kind": "replace_file",
                        "key": "file",
                        "value": source_text,
                        "before_value": original.text,
                        "before_exists": original_exists,
                        "before_is_symlink": original.is_symlink,
                        "before_symlink_target": original.symlink_target,
                        "before_hardlink_count": original.hardlink_count,
                        "before_permissions": format_permissions(original.permissions),
                        "after_permissions": format_permissions(permission_bits(dest)),
                        "reason": "asset materialized",
                    }
                ],
                original_exists=original_exists,
                format="asset",
                connection=connection,
            )
            self.state_store.record_event(
                run_id=run_id,
                event_type="applied",
                path=dest,
                changed=True,
                summary="materialized asset",
                connection=connection,
            )
        except Exception as exc:
            raise _PostWriteStateError(f"state recording failed after writing {dest}: {exc}") from exc

    def _displace_asset_extra(
        self,
        *,
        run_id: int | None,
        target: AssetTarget,
        path: Path,
        connection: sqlite3.Connection | None = None,
        require_current: Callable[[], None] | None = None,
    ) -> None:
        if run_id is None:
            raise RuntimeError("run_id is None in _displace_asset_extra")
        backup_path: Path | None = None
        backup_id: int | None = None
        try:
            if require_current is not None:
                require_current()
            backup_path, content_hash, size, mtime_ns, file_type = move_to_backup(
                state_store=self.state_store,
                run_id=run_id,
                path=path,
            )
            backup_record = self.state_store.record_asset_backup(
                run_id=run_id,
                target_dest=target.dest,
                original_path=path,
                backup_path=backup_path,
                content_hash=content_hash,
                size=size,
                mtime_ns=mtime_ns,
                file_type=file_type,
                connection=connection,
            )
            backup_id = backup_record.id
            self.state_store.record_change_batch(
                run_id=run_id,
                path=path,
                operations=[
                    {
                        "kind": "displace_file",
                        "key": "file",
                        "value": None,
                        "before_value": str(backup_path),
                        "before_exists": True,
                        "reason": "asset replace displaced extra file",
                    }
                ],
                original_exists=True,
                format="asset-displaced",
                connection=connection,
            )
            self.state_store.record_event(
                run_id=run_id,
                event_type="displaced",
                path=path,
                changed=True,
                summary=f"moved extra asset to backup {backup_path}",
                connection=connection,
            )
        except Exception:
            if backup_path is not None and backup_path.exists() and not path.exists() and not path.is_symlink():
                restore_backup(backup_path=backup_path, original_path=path)
                if backup_id is not None:
                    self.state_store.mark_asset_backup_restored(backup_id, connection=connection)
            raise

    # ── file handling ─────────────────────────────────

    def _handle_file(
        self,
        run_id: int | None,
        spec_hash: bytes,
        target: FileTarget,
        *,
        dry_run: bool = False,
        tags: set[str] | None = None,
        skip_tags: set[str] | None = None,
        diff: bool = False,
        explain_skips: bool = False,
        connection: sqlite3.Connection | None = None,
        require_current: Callable[[], None] | None = None,
    ) -> OrchestrationResult:
        if not condition_matches(target=target, tags=tags, skip_tags=skip_tags):
            return OrchestrationResult(
                status="skipped",
                applied=False,
                changed=False,
                skipped=True,
                skip_reason=condition_skip_reason(target=target, tags=tags, skip_tags=skip_tags)
                if explain_skips
                else None,
            )

        adapter = adapter_for_path(target.path, fmt=target.format)

        try:
            ensure_safe_managed_write_path(target.path, operation="file target")
            if not target.path.exists():
                return self._process_new_file(
                    run_id,
                    spec_hash,
                    target,
                    adapter,
                    dry_run=dry_run,
                    diff=diff,
                    connection=connection,
                    require_current=require_current,
                )
            return self._process_existing_file(
                run_id,
                spec_hash,
                target,
                adapter,
                dry_run=dry_run,
                diff=diff,
                connection=connection,
                require_current=require_current,
            )
        except _PostWriteStateError:
            raise
        except LockLostError:
            raise
        except Exception as exc:
            if run_id is not None:
                self.state_store.record_event(
                    run_id=run_id,
                    event_type="error",
                    path=target.path,
                    changed=False,
                    summary=str(exc),
                    details=f"{exc.__class__.__name__}: {exc}",
                    connection=connection,
                )
            return OrchestrationResult(status="error", applied=False, changed=False, error=str(exc))

    def _process_new_file(
        self,
        run_id: int | None,
        spec_hash: bytes,
        target: FileTarget,
        adapter: Adapter,
        *,
        dry_run: bool = False,
        diff: bool = False,
        connection: sqlite3.Connection | None = None,
        require_current: Callable[[], None] | None = None,
    ) -> OrchestrationResult:
        document = _empty_document(target.path, target.format)
        plan = self.planner.plan(document, _file_desired(target))
        if not plan.changed:
            return OrchestrationResult(
                status="dry-run" if dry_run else "noop",
                applied=False,
                changed=False,
                dry_run=dry_run,
            )

        diff_text = _maybe_diff_new(plan, adapter, target.path) if diff else None

        if dry_run:
            return OrchestrationResult(status="dry-run", applied=False, changed=True, dry_run=True, diff=diff_text)

        if require_current is not None:
            require_current()
        if target.path.exists():
            if run_id is None:
                raise RuntimeError("run_id is None in _process_new_file")
            conflict = ConflictResult(
                path=target.path,
                changed=True,
                reason="file appeared during orchestration",
                baseline_fingerprint=None,
                current_fingerprint=_current_fingerprint(target.path),
            )
            self._record_conflict(run_id, conflict, connection=connection)
            return OrchestrationResult(status="conflict", applied=False, changed=True, conflict=conflict)

        original_exists = target.path.exists()
        return self._apply_and_record(
            run_id=run_id,
            spec_hash=spec_hash,
            target=target,
            document=document,
            operations=plan.operations,
            original_exists=original_exists,
            adapter=adapter,
            event_type="created",
            connection=connection,
            original_text=None,
            require_current=require_current,
        )

    def _process_existing_file(
        self,
        run_id: int | None,
        spec_hash: bytes,
        target: FileTarget,
        adapter: Adapter,
        *,
        dry_run: bool = False,
        diff: bool = False,
        connection: sqlite3.Connection | None = None,
        require_current: Callable[[], None] | None = None,
    ) -> OrchestrationResult:
        before = _current_fingerprint(target.path)
        document = adapter.load(target.path)
        plan = self.planner.plan(document, _file_desired(target))
        managed_conflict: ConflictResult | None = None
        if run_id is not None:
            ctx = self.state_store.connect() if connection is None else contextlib.nullcontext(connection)
            with ctx as read_conn:
                managed_conflict = self._check_managed_conflict(document, plan, target, before, read_conn)
        elif dry_run:
            with self.state_store.dry_run_connection() as read_conn:
                if read_conn is not None:
                    managed_conflict = self._check_managed_conflict(document, plan, target, before, read_conn)

        if managed_conflict is not None:
            if run_id is not None and not dry_run:
                self._record_conflict(run_id, managed_conflict, connection=connection)
            return OrchestrationResult(
                status="conflict",
                applied=False,
                changed=True,
                conflict=managed_conflict,
                dry_run=dry_run,
            )

        if not plan.changed:
            if run_id is not None and not dry_run:
                self.state_store.record_checked(
                    run_id=run_id,
                    path=target.path,
                    content_hash=before.content_hash,
                    size=before.size,
                    mtime_ns=before.mtime_ns,
                    format=target.format,
                    spec_hash=spec_hash,
                    summary="no changes",
                    connection=connection,
                )
            return OrchestrationResult(
                status="dry-run" if dry_run else "noop",
                applied=False,
                changed=False,
                dry_run=dry_run,
            )

        diff_text = _maybe_diff(document, plan, adapter, target.path) if diff else None

        after = _current_fingerprint(target.path)
        conflict = detect_conflict(before, after)
        if conflict is not None:
            if run_id is not None and not dry_run:
                self._record_conflict(run_id, conflict, connection=connection)
            return OrchestrationResult(
                status="conflict", applied=False, changed=True, conflict=conflict, dry_run=dry_run
            )

        if dry_run:
            return OrchestrationResult(status="dry-run", applied=False, changed=True, dry_run=True, diff=diff_text)

        if require_current is not None:
            require_current()
        original_text = read_utf8_text(target.path)
        return self._apply_and_record(
            run_id=run_id,
            spec_hash=spec_hash,
            target=target,
            document=document,
            operations=plan.operations,
            original_exists=True,
            adapter=adapter,
            event_type="applied",
            connection=connection,
            original_text=original_text,
            require_current=require_current,
        )

    # ── env resolution ────────────────────────────────

    def _resolve_env(
        self,
        env_targets: list[EnvTarget],
        *,
        tags: set[str] | None = None,
        skip_tags: set[str] | None = None,
        shell_type: str | None = None,
        include_current_path: bool = True,
    ) -> tuple[dict[str, str], set[str]]:
        """Filter, merge, and resolve env targets into a flat name→value dict.

        Merging rules for duplicate names:
        - value: last one wins
        - prepend: accumulated in spec order (earlier entries prepend first)
        - append: accumulated in spec order
        - path_prepend/path_append: forwarded to PATH construction
        - materialize: True if any entry says True

        Returns (resolved_dict, materialize_names).
        """
        path_prepends: dict[str, list[str]] = {}
        path_appends: dict[str, list[str]] = {}
        resolved: dict[str, str] = {}
        materialize_names: set[str] = set()

        # Build a local env context: os.environ + progressively resolved values
        local_env: dict[str, str] = dict(os.environ)

        for et in env_targets:
            if not condition_matches(target=et, tags=tags, skip_tags=skip_tags):
                continue
            if shell_type is not None and et.shells and shell_type not in et.shells:
                continue

            if et.materialize:
                materialize_names.add(et.name)

            if et.path_prepend:
                expanded_entries = [_expand_tilde(e) for e in et.path_prepend]
                path_prepends.setdefault(et.name, []).extend(expanded_entries)
                path_prepends.setdefault("PATH", []).extend(expanded_entries)
            if et.path_append:
                expanded_entries = [_expand_tilde(e) for e in et.path_append]
                path_appends.setdefault(et.name, []).extend(expanded_entries)
                path_appends.setdefault("PATH", []).extend(expanded_entries)

            # Collect prepend/append for PATH
            if et.prepend:
                expanded_prepends = [_expand_tilde(e) for e in et.prepend]
                path_prepends.setdefault("PATH", []).extend(expanded_prepends)
            if et.append:
                expanded_appends = [_expand_tilde(e) for e in et.append]
                path_appends.setdefault("PATH", []).extend(expanded_appends)

            # Value: last one wins. Expand against local_env so later entries
            # can reference earlier ones (e.g., CARGO_HOME → PATH prepend)
            if et.value is not None:
                expanded = _expandvars(et.value, local_env)
                expanded = _expand_tilde(expanded)
                resolved[et.name] = expanded
                local_env[et.name] = expanded

        # Build PATH from prepends + existing + appends
        if "PATH" in path_prepends or "PATH" in path_appends:
            current_path = local_env.get("PATH", "")
            current_entries = [p for p in current_path.split(os.pathsep) if p] if include_current_path else []

            prepend_entries = path_prepends.get("PATH", [])
            append_entries = path_appends.get("PATH", [])

            # Deduplicate prepend entries: keep first occurrence
            seen: set[str] = set()
            deduped_prepends: list[str] = []
            for entry in prepend_entries:
                expanded = _normalize_path_entry(_expandvars(entry, local_env))
                if expanded not in seen:
                    seen.add(expanded)
                    deduped_prepends.append(expanded)

            # Deduplicate append entries
            deduped_appends: list[str] = []
            for entry in append_entries:
                expanded = _normalize_path_entry(_expandvars(entry, local_env))
                if expanded not in seen:
                    seen.add(expanded)
                    deduped_appends.append(expanded)

            deduped_current: list[str] = []
            for entry in current_entries:
                if entry not in seen:
                    seen.add(entry)
                    deduped_current.append(entry)

            new_path = deduped_prepends + deduped_current + deduped_appends
            resolved["PATH"] = os.pathsep.join(new_path)

        return resolved, materialize_names

    # ── shell handling ────────────────────────────────

    def _handle_shell(
        self,
        run_id: int | None,
        spec_hash: bytes,
        target: ShellTarget,
        resolved_env: dict[str, str],
        *,
        dry_run: bool = False,
        tags: set[str] | None = None,
        skip_tags: set[str] | None = None,
        diff: bool = False,
        explain_skips: bool = False,
        connection: sqlite3.Connection | None = None,
        require_current: Callable[[], None] | None = None,
    ) -> OrchestrationResult:
        if not condition_matches(target=target, tags=tags, skip_tags=skip_tags):
            return OrchestrationResult(
                status="skipped",
                applied=False,
                changed=False,
                skipped=True,
                skip_reason=condition_skip_reason(target=target, tags=tags, skip_tags=skip_tags)
                if explain_skips
                else None,
            )

        rendered = render_shell_block(
            shell_type=_shell_type_for_target(target),
            env_vars=dict(resolved_env),
            managed_block_id=target.managed_block_id,
        )

        return self._apply_shell_block(
            run_id=run_id,
            spec_hash=spec_hash,
            target=target,
            rendered_lines=rendered,
            dry_run=dry_run,
            diff=diff,
            connection=connection,
            require_current=require_current,
        )

    def _apply_shell_block(
        self,
        run_id: int | None,
        spec_hash: bytes,
        target: ShellTarget,
        rendered_lines: list[str],
        *,
        dry_run: bool = False,
        diff: bool = False,
        connection: sqlite3.Connection | None = None,
        require_current: Callable[[], None] | None = None,
    ) -> OrchestrationResult:
        """Apply a shell block using the LINE adapter + managed block pattern."""
        adapter = adapter_for_path(target.path, fmt="line")

        try:
            ensure_safe_managed_write_path(target.path, operation="shell target")
            document = adapter.load(target.path) if target.path.exists() else _empty_document(target.path, "line")

            desired = DesiredState(
                path=target.path,
                format="line",
                managed_block_id=target.managed_block_id,
                lines=rendered_lines,
            )

            plan = self.planner.plan(document, desired)

            if not plan.changed:
                if run_id is not None and not dry_run:
                    self.state_store.record_checked(
                        run_id=run_id,
                        path=target.path,
                        content_hash=sha256_bytes(target.path.read_bytes()),
                        size=target.path.stat().st_size,
                        mtime_ns=target.path.stat().st_mtime_ns,
                        format="line",
                        spec_hash=spec_hash,
                        summary="no changes",
                        connection=connection,
                    )
                return OrchestrationResult(
                    status="dry-run" if dry_run else "noop",
                    applied=False,
                    changed=False,
                    dry_run=dry_run,
                )

            diff_text = _maybe_diff(document, plan, adapter, target.path) if diff else None

            if dry_run:
                return OrchestrationResult(status="dry-run", applied=False, changed=True, dry_run=True, diff=diff_text)

            if run_id is None:
                raise RuntimeError("run_id is None in _apply_shell_block")
            if require_current is not None:
                require_current()
            original_text = read_utf8_text(target.path) if target.path.exists() else ""
            original_exists = target.path.exists()

            return self._apply_and_record(
                run_id=run_id,
                spec_hash=spec_hash,
                target=target,
                document=document,
                operations=plan.operations,
                original_exists=original_exists,
                adapter=adapter,
                event_type="applied",
                connection=connection,
                original_text=original_text if original_exists else None,
                require_current=require_current,
            )
        except _PostWriteStateError:
            raise
        except LockLostError:
            raise
        except Exception as exc:
            if run_id is not None:
                self.state_store.record_event(
                    run_id=run_id,
                    event_type="error",
                    path=target.path,
                    changed=False,
                    summary=str(exc),
                    details=f"{exc.__class__.__name__}: {exc}",
                    connection=connection,
                )
            return OrchestrationResult(status="error", applied=False, changed=False, error=str(exc))

    # ── rollback ──────────────────────────────────────

    def _do_materialize(self, env_vars: dict[str, str]) -> list[str]:
        """Write env vars to the OS-level persistent store.

        Returns a list of error strings (empty if successful).
        """
        from prescribe.materialize import materialize

        try:
            if self._materialize_fn is not None:
                self._materialize_fn(env_vars=env_vars, dry_run=False)
            else:
                materialize(env_vars=env_vars, dry_run=False)
        except Exception as exc:
            return [str(exc)]
        return []

    def rollback(
        self,
        target_path: Path | str,
        *,
        dry_run: bool = False,
        original: bool = False,
        conflict_resolver: ConflictResolver = None,
    ) -> OrchestrationResult:
        path = Path(target_path)
        lock_owner = _lock_owner()
        if not dry_run:
            lock = self.state_store.acquire_lock("global", owner=lock_owner, ttl=self._lock_ttl)
            if not lock.acquired:
                return OrchestrationResult(
                    status="error",
                    applied=False,
                    changed=False,
                    error=f"another prescribe write is active: {lock.owner} until {lock.expires_at.isoformat()}",
                )
        if not dry_run:
            self.state_store.initialize()

        try:
            if not dry_run:
                with LockHeartbeat(
                    self.state_store,
                    name="global",
                    owner=lock_owner,
                    token=lock.token,
                    ttl=self._lock_ttl,
                    interval=self._lock_heartbeat_interval,
                ) as heartbeat:
                    heartbeat.require_current()
                    result = perform_rollback(
                        path,
                        self.state_store,
                        dry_run=False,
                        original=original,
                        resolver=conflict_resolver,
                        require_current=heartbeat.require_current,
                    )
                    heartbeat.require_current()
                    return result
            with self.state_store.dry_run_connection() as read_conn:
                if read_conn is None:
                    return OrchestrationResult(status="noop", applied=False, changed=False, dry_run=True)
                return perform_rollback(
                    path,
                    self.state_store,
                    dry_run=True,
                    original=original,
                    resolver=conflict_resolver,
                    connection=read_conn,
                )
        except LockLostError as exc:
            return OrchestrationResult(status="error", applied=False, changed=True, error=str(exc))
        except Exception as exc:
            return OrchestrationResult(status="error", applied=False, changed=True, error=str(exc))
        finally:
            if not dry_run:
                self.state_store.release_lock("global", owner=lock_owner, token=lock.token)

    # ── conflict helpers ──────────────────────────────

    def _check_managed_conflict(
        self,
        document: Document,
        plan: Any,
        target: FileTarget,
        current_fingerprint: "FileFingerprint",
        connection: sqlite3.Connection,
    ) -> ConflictResult | None:
        managed_state = _managed_state_from_batches(self.state_store.change_batches(target.path, connection=connection))
        snapshot = self.state_store.latest_snapshot(target.path, connection=connection)
        baseline = (
            file_fingerprint(
                snapshot.path,
                snapshot.hash_algo,
                snapshot.content_hash,
                snapshot.size,
                snapshot.mtime_ns,
            )
            if snapshot is not None
            else None
        )
        return _detect_managed_conflict(
            document,
            plan.operations,
            managed_state,
            baseline_fingerprint=baseline,
            current_fingerprint=current_fingerprint,
        )

    def _record_conflict(
        self,
        run_id: int,
        conflict: ConflictResult,
        *,
        connection: sqlite3.Connection | None = None,
    ) -> None:
        self.state_store.record_event(
            run_id=run_id,
            event_type="conflict",
            path=conflict.path,
            changed=True,
            summary=conflict.reason,
            details=_conflict_details(conflict),
            connection=connection,
        )

    def _apply_and_record(
        self,
        *,
        run_id: int | None,
        spec_hash: bytes,
        target: FileTarget | ShellTarget,
        document: Document,
        operations: list[PlannedOperation],
        original_exists: bool,
        adapter: Adapter,
        event_type: str,
        connection: sqlite3.Connection | None = None,
        original_text: str | None = None,
        require_current: Callable[[], None] | None = None,
    ) -> OrchestrationResult:
        if run_id is None:
            raise RuntimeError("run_id is None in _apply_and_record")
        if require_current is not None:
            require_current()
        if original_exists and target.path.exists():
            self._record_recovery_backup(
                run_id=run_id,
                path=target.path,
                target_kind="shell" if isinstance(target, ShellTarget) else "file",
                operation=event_type,
                connection=connection,
            )
            if require_current is not None:
                require_current()
        apply_operations(document, operations)
        adapter.dump(document, target.path)
        new_bytes = target.path.read_bytes()
        written_text = decode_utf8_bytes(new_bytes, path=target.path)
        new_stat = target.path.stat()
        new_hash = sha256_bytes(new_bytes)
        try:
            existing_baseline = self.state_store.original_baseline(target.path, connection=connection)
            if existing_baseline is None:
                self.state_store.record_baseline(
                    run_id=run_id,
                    path=target.path,
                    content_text=original_text or "",
                    format=getattr(target, "format", "line"),
                    original_exists=original_exists,
                    connection=connection,
                )
            self.state_store.record_checkpoint(
                run_id=run_id,
                path=target.path,
                content_text=written_text,
                format=getattr(target, "format", "line"),
                original_exists=original_exists,
                connection=connection,
            )
            self.state_store.record_snapshot(
                run_id=run_id,
                path=target.path,
                content_hash=new_hash,
                size=new_stat.st_size,
                mtime_ns=new_stat.st_mtime_ns,
                format=getattr(target, "format", "line"),
                spec_hash=spec_hash,
                connection=connection,
            )
            self.state_store.record_change_batch(
                run_id=run_id,
                path=target.path,
                operations=[_operation_to_data(op) for op in operations],
                original_exists=original_exists,
                format=getattr(target, "format", "line"),
                connection=connection,
            )
            self.state_store.record_event(
                run_id=run_id,
                event_type=event_type,
                path=target.path,
                changed=True,
                summary=f"{event_type} with {len(operations)} ops",
                connection=connection,
            )
        except Exception as exc:
            raise _PostWriteStateError(f"state recording failed after writing {target.path}: {exc}") from exc
        return OrchestrationResult(status="applied", applied=True, changed=True)

    def _record_recovery_backup(
        self,
        *,
        run_id: int,
        path: Path,
        target_kind: str,
        operation: str,
        connection: sqlite3.Connection | None = None,
    ) -> None:
        backup_path, content_hash, size, mtime_ns, content_text = copy_to_recovery_backup(
            state_store=self.state_store,
            run_id=run_id,
            path=path,
        )
        self.state_store.record_recovery_backup(
            run_id=run_id,
            target_path=path,
            target_kind=target_kind,
            operation=operation,
            backup_path=backup_path,
            content_hash=content_hash,
            size=size,
            mtime_ns=mtime_ns,
            content_text=content_text,
            connection=connection,
        )


# ── module-level helpers ──────────────────────────────────


def _file_desired(target: FileTarget) -> DesiredState:
    return DesiredState(
        path=target.path,
        format=target.format,
        data=target.data,
        delete=target.delete,
        managed_block_id=target.managed_block_id,
        lines=target.lines,
    )


def _shell_type_for_target(target: ShellTarget) -> str:
    render_shells = target.shells if target.shells else ["bash"]
    return render_shells[0]


def _empty_document(path: Path, fmt: str) -> Document:
    if fmt in {"toml", "yaml", "jsonc"}:
        return Document(path=path, format=fmt, root={})
    if fmt == "line":
        from prescribe.adapters.line import LineDocument, preferred_newline

        return Document(path=path, format="line", root=LineDocument(path=path, newline=preferred_newline(path)))
    raise ValueError(f"unsupported format for empty document: {fmt}")


def _current_fingerprint(path: Path) -> FileFingerprint:
    stat = path.stat()
    content_hash = sha256_bytes(path.read_bytes())
    return file_fingerprint(path, "sha256", content_hash, stat.st_size, stat.st_mtime_ns)


def _conflict_details(conflict: ConflictResult) -> str:
    baseline = _fingerprint_details(conflict.baseline_fingerprint)
    current = _fingerprint_details(conflict.current_fingerprint)
    return f"baseline={baseline}; current={current}"


def _fingerprint_details(fingerprint: FileFingerprint | None) -> str:
    if fingerprint is None:
        return "none"
    return (
        f"path={fingerprint.path} "
        f"algo={fingerprint.hash_algo} "
        f"hash={fingerprint.content_hash.hex()} "
        f"size={fingerprint.size} "
        f"mtime_ns={fingerprint.mtime_ns}"
    )


def _managed_state_from_batches(
    batches: list[ChangeBatchRecord],
) -> dict[str, dict[str, Any]]:
    state: dict[str, dict[str, Any]] = {}
    for batch in batches:
        for operation in batch.operations:
            key = operation.get("key")
            if key is None:
                continue
            kind = operation.get("kind")
            if kind in {"set", "update", "replace_block"}:
                state[str(key)] = {"exists": True, "value": operation.get("value")}
                continue
            if kind in {"delete", "delete_block"}:
                state[str(key)] = {"exists": False, "value": None}
    return state


def _detect_managed_conflict(
    document: Document,
    operations: list[PlannedOperation],
    managed_state: dict[str, dict[str, Any]],
    *,
    baseline_fingerprint: FileFingerprint | None,
    current_fingerprint: FileFingerprint,
) -> ConflictResult | None:
    for operation in operations:
        if operation.key is None:
            continue
        key = str(operation.key)
        if key not in managed_state:
            continue
        expected = managed_state[key]
        current = _current_operation_state(document, key)
        if current != expected:
            return ConflictResult(
                path=document.path,
                changed=True,
                reason=f"managed key {key!r} changed externally",
                baseline_fingerprint=baseline_fingerprint,
                current_fingerprint=current_fingerprint,
            )
    return None


def _current_operation_state(document: Document, key: str) -> dict[str, Any]:
    if getattr(document, "format", None) == "line":
        block = document.root.block(key)
        if block is None:
            return {"exists": False, "value": None}
        return {"exists": True, "value": [line.rstrip("\r\n") for line in block.lines]}

    value = mapping_value(document.root, key)
    if value is _MISSING:
        return {"exists": False, "value": None}
    return {"exists": True, "value": _jsonable(value)}


def _operation_to_data(operation: PlannedOperation) -> dict[str, Any]:
    return {
        "kind": operation.kind,
        "key": operation.key,
        "value": _jsonable(operation.value),
        "before_value": _jsonable(operation.before_value),
        "before_exists": operation.before_exists,
        "created_parent_keys": list(operation.created_parent_keys),
        "reason": operation.reason,
    }


def _jsonable(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _jsonable(inner) for key, inner in value.items()}
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, tuple):
        return [_jsonable(item) for item in value]
    return value


# ── diff helpers ───────────────────────────────────────────


def _expandvars(value: str, env: dict[str, str]) -> str:
    """Expand $VAR and ${VAR} in a string using the given env dict."""

    def replacer(match: re.Match[str]) -> str:
        var = match.group(1) or match.group(2)
        return env.get(var, f"${var}")

    return re.sub(r"\$([A-Za-z_][A-Za-z0-9_]*)|\$\{([^}]+)\}", replacer, value)


def _expand_tilde(value: str) -> str:
    """Expand ~ to home directory."""
    if value == "~" or value.startswith("~/"):
        home = Path(os.environ.get("HOME") or Path.home())
        return str(home / value[2:]) if value.startswith("~/") else str(home)
    return value


def _normalize_path_entry(value: str) -> str:
    if "$" in value or value.startswith("!"):
        return value
    return str(Path(value))


def _resolve_active_files(
    file_targets: list[FileTarget],
    *,
    tags: set[str] | None = None,
    skip_tags: set[str] | None = None,
) -> tuple[list[FileTarget], list[FileTarget]]:
    """Partition and deduplicate files.

    Returns (active, skipped) where active is deduplicated by priority.
    skipped contains files that didn't pass condition_matches.
    """
    active_candidates: list[FileTarget] = []
    skipped: list[FileTarget] = []

    for ft in file_targets:
        if condition_matches(target=ft, tags=tags, skip_tags=skip_tags):
            active_candidates.append(ft)
        else:
            skipped.append(ft)

    # Deduplicate active candidates by path: lowest priority, first-in-spec breaks ties
    seen: dict[Path, FileTarget] = {}
    for ft in active_candidates:
        existing = seen.get(ft.path)
        if existing is None or ft.priority < existing.priority:
            seen[ft.path] = ft

    return list(seen.values()), skipped


def _active_file_for_path(active_files: list[FileTarget], path: Path) -> FileTarget | None:
    for file_target in active_files:
        if file_target.path == path:
            return file_target
    return None


def _priority_skip_reason(target: FileTarget, winner: FileTarget | None) -> str:
    if winner is None:
        return "lower priority target selected"
    return (
        "lower priority target selected "
        f"(winner path {winner.path}, winner priority {winner.priority}; skipped priority {target.priority})"
    )


def _lock_owner() -> str:
    return f"{current_machine()}:{os.getpid()}"


def _active_claims(
    spec: Spec,
    *,
    tags: set[str] | None,
    skip_tags: set[str] | None,
    file_skip_reasons: dict[int, str] | None = None,
) -> list[Claim]:
    active_files, _ = _resolve_active_files(spec.files, tags=tags, skip_tags=skip_tags)
    skipped_file_ids = set(file_skip_reasons or ())
    active_ids = {id(target) for target in active_files if id(target) not in skipped_file_ids}
    for env_target in spec.env:
        if condition_matches(target=env_target, tags=tags, skip_tags=skip_tags):
            active_ids.add(id(env_target))
    for shell_target in spec.shell:
        if condition_matches(target=shell_target, tags=tags, skip_tags=skip_tags):
            active_ids.add(id(shell_target))
    for asset_target in spec.assets:
        if condition_matches(target=asset_target, tags=tags, skip_tags=skip_tags):
            active_ids.add(id(asset_target))
    return compute_claims(spec, include=lambda target: id(target) in active_ids)


def _claim_conflict_result(conflict: ClaimConflict) -> OrchestrationResult:
    if conflict.message is not None:
        return OrchestrationResult(status="error", applied=False, changed=False, error=conflict.message)
    claim = conflict.claim
    return OrchestrationResult(
        status="error",
        applied=False,
        changed=False,
        error=(
            "claim conflict: "
            f"{claim.target_type} {claim.subject} {claim.address} is managed by {conflict.existing_owner}"
        ),
    )


def _interrupted_work_result(attempts: list[Any]) -> OrchestrationResult:
    return OrchestrationResult(
        status="error",
        applied=False,
        changed=False,
        error=_interrupted_work_message(attempts),
    )


def _interrupted_work_message(attempts: list[Any]) -> str:
    preview = "; ".join(
        f"run={attempt.run_id} target={attempt.target_type} {attempt.subject} {attempt.address} "
        f"phase={attempt.phase}"
        for attempt in attempts[:3]
    )
    suffix = "" if len(attempts) <= 3 else f"; +{len(attempts) - 3} more"
    return (
        "interrupted prescribe operation detected; normal writes are blocked until recovery is resolved. "
        f"{preview}{suffix}"
    )


def _materialize_error_message(errors: list[str]) -> str:
    return "materialize failed: " + "; ".join(errors)


def _successful_target_ids(
    spec: Spec,
    results: list[OrchestrationResult],
) -> set[str]:
    successful_ids: set[str] = set()
    if spec.env and not any(result.materialize_errors for result in results):
        successful_ids.update(f"env[{index}]" for index, _target in enumerate(spec.env))
    targets = _iter_targets_for_ledger(spec)
    for result, (target_type, target) in zip(results, targets, strict=False):
        if result.status in {"error", "conflict", "skipped", "dry-run"}:
            continue
        target_id = _target_id_for_claim(target_type, target, spec)
        if target_id is not None:
            successful_ids.add(target_id)
    return successful_ids


def _target_id_for_claim(target_type: str, target: object, spec: Spec) -> str | None:
    if isinstance(target, FileTarget):
        return _indexed_target_id("files", target, spec.files)
    if isinstance(target, ShellTarget):
        return _indexed_target_id("shell", target, spec.shell)
    if isinstance(target, AssetTarget):
        return _indexed_target_id("assets", target, spec.assets)
    if isinstance(target, EnvTarget):
        return _indexed_target_id("env", target, spec.env)
    return None


def _indexed_target_id(section: str, target: object, targets: Sequence[object]) -> str | None:
    for index, candidate in enumerate(targets):
        if candidate is target:
            return f"{section}[{index}]"
    return None


def _iter_targets_for_ledger(spec: Spec) -> list[tuple[str, object]]:
    targets: list[tuple[str, object]] = [("file", target) for target in spec.files]
    if spec.env and not spec.files and not spec.shell and not spec.assets:
        targets.append(("env", spec.env[0]))
    targets.extend(("shell", target) for target in spec.shell)
    targets.extend(("asset", target) for target in spec.assets)
    return targets


def _target_label(target_type: str, target: object) -> str:
    if isinstance(target, EnvTarget):
        return target.name
    if isinstance(target, AssetTarget):
        return str(target.dest)
    if isinstance(target, (FileTarget, ShellTarget)):
        return str(target.path)
    return ""


def _maybe_diff(
    document: Document,
    plan: Any,
    adapter: Adapter,
    path: Path,
) -> str | None:
    """Generate a diff for an existing file if it would change."""
    from prescribe.diff import diff_file

    return diff_file(document=document, plan=plan.operations, adapter=adapter, path=path)


def _maybe_diff_new(
    plan: Any,
    adapter: Adapter,
    path: Path,
) -> str | None:
    """Generate a diff for a new file."""
    from prescribe.diff import diff_new_file

    return diff_new_file(plan=plan.operations, adapter=adapter, path=path)
