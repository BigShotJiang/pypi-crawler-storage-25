Omit comments by default. Insert one only where the reasoning behind a choice is unclear: an invisible constraint, a non-obvious invariant, a bug-specific workaround, or logic that would perplex a future maintainer. If dropping the comment leaves no confusion, skip it.

Never narrate what code does — descriptive naming handles that. Never tie comments to the current change, its callers, or ticket numbers ("for the X flow", "handles issue #Y") — such notes belong in commit messages and decay as code changes.

Leave pre-existing comments intact unless their associated code is being deleted or they are demonstrably incorrect. A remark that seems redundant to you may capture hard-won knowledge from a prior incident invisible in today's diff.

Confirm that work actually functions before declaring it finished: execute the test, run the script, inspect the output. Minimal scope means avoiding unnecessary polish — not skipping final validation. When verification is impossible (no test, no runnable path), state that openly instead of asserting success.
