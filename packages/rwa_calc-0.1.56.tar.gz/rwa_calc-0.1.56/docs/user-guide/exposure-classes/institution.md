# Institution Exposures

**Institution exposures** are claims on banks, investment firms, and other regulated financial institutions.

## Definition

Institution exposures include:

| Entity Type | Description |
|-------------|-------------|
| Credit institutions | Banks, building societies |
| Investment firms | Broker-dealers, asset managers |
| Central counterparties (CCPs) | Clearing houses |
| Financial holding companies | Bank holding companies |
| Insurance companies | Subject to certain conditions |

## Risk Weights (SA)

Institution risk weights range from 20% (CQS 1) to 150% (CQS 6). Under CRR Art. 120 Table 3, CQS 2 receives **50%**. Basel 3.1 ECRA (PRA PS1/26 Art. 120 Table 3) reduces CQS 2 to **30%**.

Under CRR, unrated institutions receive **40%** via the sovereign-derived approach (Art. 121, Table 5). Under Basel 3.1, this is replaced by the **Standardised Credit Risk Assessment Approach (SCRA)** based on capital adequacy (Grade A: 40%, Grade A enhanced: 30%, Grade B: 75%, Grade C: 150%). Grade A enhanced requires CET1 ≥ 14% and leverage ratio ≥ 5%.

!!! warning "Code Divergence"
    The code currently uses 30% for CRR CQS 2 (labelled "UK deviation"). PDF verification of UK
    onshored CRR Art. 120 Table 3 confirms CQS 2 = **50%**. The 30% value is correct for Basel 3.1
    ECRA only. See D1.30 in the docs implementation plan.

> **Details:** See [Key Differences — Institution Exposures](../../framework-comparison/key-differences.md#institution-exposures) for the complete ECRA/SCRA comparison tables.

## IRB Treatment

F-IRB uses supervisory LGD (45% senior, 75% subordinated) with PD floors of 0.03% (CRR) / 0.05% (Basel 3.1). Institution correlation uses the corporate formula.

!!! warning "Basel 3.1"
    A-IRB is **no longer permitted** for institution exposures under Basel 3.1. Only SA or F-IRB may be used.

> **Details:** See [IRB Approach](../methodology/irb-approach.md) for the full formula and parameter details.

## Short-Term Exposures

### Table 4 — General Short-Term Preferential (Art. 120(2))

Rated institution exposures with original maturity ≤ 3 months receive preferential
treatment under Table 4. Trade finance exposures (movement of goods) with original
maturity ≤ 6 months also qualify (Art. 120(2A)).

| CQS | Standard RW (>3m) | Table 4 RW (≤3m) |
|-----|-------------------|-------------------|
| CQS 1 | 20% | 20% |
| CQS 2 | 30% | 20% |
| CQS 3 | 50% | 20% |
| CQS 4-5 | 100% | 50% |
| CQS 6 | 150% | 150% |

### Table 4A — Short-Term ECAI Assessment (Art. 120(2B))

Where an institution has a specific **short-term credit assessment** from a nominated
ECAI (as opposed to a long-term rating applied to a short-term exposure), Table 4A
applies:

| Short-Term CQS | Risk Weight |
|----------------|-------------|
| CQS 1 | 20% |
| CQS 2 | 50% |
| CQS 3 | 100% |
| Others | 150% |

!!! warning "Not Yet Implemented — Schema Gap"
    The `has_short_term_ecai` schema field does not exist. The calculator cannot
    distinguish Table 4A exposures (specific short-term ECAI) from Table 4 exposures
    (long-term ECAI applied to short-term tenor). All short-term institution exposures
    currently receive Table 4 weights, which **understates risk** for CQS 2 (20% applied
    vs correct 50%) and CQS 3 (20% vs 100%). See D3.8 in the docs implementation plan
    and [B31 SA Risk Weights spec](../../specifications/basel31/sa-risk-weights.md#ecra-short-term-ecai-art-1202b-table-4a).

### Art. 120(3) — Interaction Rules

The interaction between Table 4 and Table 4A is governed by Art. 120(3):

- **(a)** No short-term assessment → Table 4 applies
- **(b)** Short-term assessment yields more favourable or equal RW → Table 4A for that exposure only; other short-term exposures still use Table 4
- **(c)** Short-term assessment yields less favourable RW → Table 4 preferential treatment withdrawn; all unrated short-term claims against that obligor receive the Table 4A weight

## Interbank Exposures

### Due From Banks

| Exposure Type | Treatment |
|---------------|-----------|
| Nostro balances | Standard institution RW |
| Interbank loans | Standard institution RW |
| Money market placements | May qualify for short-term |
| Repo/reverse repo | CRM treatment may apply |

### Trade Finance

| Item | CCF | Risk Weight |
|------|-----|-------------|
| Documentary credits | 20% | Institution RW |
| Standby LCs | 50-100% | Institution RW |
| Guarantees | 100% | Institution RW |

## Covered Bonds

Covered bonds issued by institutions receive preferential treatment under Art. 129. Rated bonds range from 10% (CQS 1) to 100% (CQS 6) per Table 6A/Table 7. Unrated bonds derive their RW from the issuing institution's senior unsecured RW via Art. 129(5), producing values from 10% to 100%. PRA PS1/26 retains the same rated table — the BCBS CRE20 reductions (CQS 2→15%, CQS 4–6→50%) were not adopted.

> **Details:** See [Key Differences — Covered Bonds](../../framework-comparison/key-differences.md#covered-bonds-art-129) for the full CQS table and CRR vs Basel 3.1 comparison.

## Central Counterparties (CCPs)

### Qualifying CCPs (QCCPs)

| Exposure Type | Risk Weight |
|---------------|-------------|
| Trade exposures | 2% |
| Default fund contributions | Risk-sensitive calculation |

### Non-QCCPs

| Exposure Type | Treatment |
|---------------|-----------|
| Trade exposures | Bilateral institution RW |
| Default fund contributions | 1250% (or deduction) |

## CRM for Institutions

### Bank Guarantees

Exposures guaranteed by better-rated institutions:

```python
if guarantee.type == "INSTITUTION" and guarantee.cqs < counterparty.cqs:
    # Substitution approach
    guaranteed_rw = institution_risk_weight(guarantee.cqs)
```

### Bank Collateral

Bonds issued by institutions as collateral:

| Collateral Rating | Haircut (1-5yr) |
|-------------------|-----------------|
| CQS 1-2 | 4% |
| CQS 3 | 6% |
| CQS 4+ | Not eligible |

## Calculation Examples

**Example 1: Rated Bank**
- £25m placement with Deutsche Bank
- Rating: A+ (CQS 2)
- Maturity: 6 months

```python
# CQS 2 institution under CRR (Art. 120 Table 3)
Risk_Weight = 50%
EAD = £25,000,000
RWA = £25,000,000 × 50% = £12,500,000
# Under Basel 3.1 ECRA: 30% → RWA = £7,500,000
```

**Example 2: Unrated Bank (Basel 3.1)**
- £10m loan to regional bank
- No external rating
- SCRA assessment: CET1 = 16%, Leverage = 6%

```python
# SCRA Grade A
Risk_Weight = 40%
RWA = £10,000,000 × 40% = £4,000,000
```

**Example 3: Short-Term**
- £50m overnight placement
- Counterparty: CQS 3 bank
- Original maturity: 1 day

```python
# Short-term preferential treatment
Risk_Weight = 20%  # vs. standard 50%
RWA = £50,000,000 × 20% = £10,000,000
```

## Subordinated Debt

Exposures to subordinated debt of institutions:

| Instrument Type | CRR | Basel 3.1 |
|-----------------|-----|-----------|
| Tier 2 instruments | Institution RW + premium | 150% |
| AT1 instruments | Institution RW + premium | 150% |
| Equity-like | 150% | 250% |

## Regulatory References

| Topic | CRR Article | BCBS CRE |
|-------|-------------|----------|
| Institution definition | Art. 119 | CRE20.15-20 |
| Risk weights | Art. 119-121 | CRE20.21-25 |
| Short-term treatment | Art. 119(2) | CRE20.26 |
| Covered bonds | Art. 129 | CRE20.27-30 |
| CCPs | Art. 300-311 | CRE54 |

## Next Steps

- [Corporate Exposures](corporate.md)
- [Standardised Approach](../methodology/standardised-approach.md)
- [Credit Risk Mitigation](../methodology/crm.md)
