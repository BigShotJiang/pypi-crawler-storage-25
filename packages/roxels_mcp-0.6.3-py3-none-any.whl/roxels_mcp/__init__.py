"""Roxels MCP Server — AI-agent-friendly tools for the Roxels platform."""
