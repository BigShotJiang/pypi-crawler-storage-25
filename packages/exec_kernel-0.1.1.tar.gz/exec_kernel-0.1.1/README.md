# Autonomous Ventures Exec-Kernel

Deterministic task lifecycle enforcement for multi-agent systems.

Full documentation: [kernel/README.md](kernel/README.md)

## Quick Start

```bash
pip install exec-kernel
```

See [kernel/README.md](kernel/README.md) for CLI usage, Python API, configuration, and architecture docs.

## Publishing

```bash
# TestPyPI (default)
./scripts/publish.sh test

# Live PyPI
./scripts/publish.sh live
```

The publish script automatically loads environment variables from `.env` if present.

### Setup

1. **Create a PyPI account** at [pypi.org/account/register/](https://pypi.org/account/register/)
2. **Generate API tokens:**
   - Production: [pypi.org/manage/account/token/](https://pypi.org/manage/account/token/)
   - TestPyPI: [test.pypi.org/manage/account/token/](https://test.pypi.org/manage/account/token/)
3. **Configure tokens:**

```bash
cp .env.example .env
# Edit .env with your tokens
./scripts/publish.sh       # publish to TestPyPI
./scripts/publish.sh live  # publish to production
```

### CI/CD

The [GitHub Actions publish workflow](.github/workflows/publish.yml) uses **OpenID Connect trusted publishing** — no manual tokens required. Publishing triggers automatically on GitHub Releases.
