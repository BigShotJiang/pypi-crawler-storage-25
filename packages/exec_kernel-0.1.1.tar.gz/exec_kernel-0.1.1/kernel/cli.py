"""CLI entrypoint for the execution kernel."""

from __future__ import annotations

import argparse
import logging
import sys

from kernel.lifecycle import TaskState, InvalidTransitionError, validate_transition
from kernel.loop_detector import LoopDetector, LoopDetectionError, WorkNode
from kernel.budget import BudgetTracker, BudgetExceededError
from kernel.paperclip_adapter import IdleEnforcementError, PaperclipAdapter

logger = logging.getLogger(__name__)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="exec-kernel",
        description="Deterministic task lifecycle enforcement engine",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    validate_p = sub.add_parser("validate", help="Validate a state transition")
    validate_p.add_argument("current", type=str, help="Current state")
    validate_p.add_argument("target", type=str, help="Target state")

    check_loop_p = sub.add_parser("check-loop", help="Check if a new task would create a loop")
    check_loop_p.add_argument("task_id", type=str, help="New task ID")
    check_loop_p.add_argument("agent_id", type=str, help="Agent creating the task")
    check_loop_p.add_argument("task_type", type=str, help="Type of the new task")
    check_loop_p.add_argument("--parent-task-id", type=str, default=None, help="Parent task ID")
    check_loop_p.add_argument("--created-by-task-id", type=str, default=None, help="Created by task ID")
    check_loop_p.add_argument("--max-depth", type=int, default=10, help="Maximum allowed depth")

    budget_p = sub.add_parser("check-budget", help="Check budget state for a task")
    budget_p.add_argument("task_id", type=str, help="Task ID")
    budget_p.add_argument("--steps", type=int, default=0, help="Steps taken so far")
    budget_p.add_argument("--max-steps", type=int, default=50, help="Maximum steps allowed")
    budget_p.add_argument("--duration", type=int, default=0, help="Elapsed duration in seconds")
    budget_p.add_argument("--max-duration", type=int, default=1800, help="Max duration in seconds")

    sleep_p = sub.add_parser("sleep", help="Enter no-op idle sleep (no tasks available)")
    sleep_p.add_argument("--timeout", type=int, default=30, help="Sleep timeout in seconds")
    sleep_p.add_argument("--agent-id", type=str, default=None, help="Agent identifier")
    sleep_p.add_argument("--api-url", type=str, default=None, help="Paperclip API URL")

    return parser


def cmd_validate(args: argparse.Namespace) -> None:
    try:
        current = TaskState(args.current)
        target = TaskState(args.target)
    except ValueError as e:
        print(f"Invalid state: {e}", file=sys.stderr)
        sys.exit(1)

    try:
        reason = validate_transition(current, target)
        print(f"VALID: {reason}")
        sys.exit(0)
    except InvalidTransitionError as e:
        print(f"INVALID: {e.reason}")
        sys.exit(1)


def cmd_check_loop(args: argparse.Namespace) -> None:
    detector = LoopDetector(max_depth=args.max_depth)
    node = WorkNode(
        task_id=args.task_id,
        agent_id=args.agent_id,
        task_type=args.task_type,
        parent_task_id=args.parent_task_id,
        created_by_task_id=args.created_by_task_id,
    )
    detector.register_node(node)

    try:
        depth = detector.check_new_task(
            task_id=node.task_id,
            agent_id=node.agent_id,
            task_type=node.task_type,
            parent_task_id=node.parent_task_id,
            created_by_task_id=node.created_by_task_id,
        )
        print(f"ALLOWED: depth={depth}")
        sys.exit(0)
    except LoopDetectionError as e:
        print(f"DENIED: [{e.loop_type}] {e}")
        sys.exit(1)


def cmd_check_budget(args: argparse.Namespace) -> None:
    tracker = BudgetTracker()
    budget_config = {
        "max_steps": args.max_steps,
        "max_depth": 10,
        "max_duration_seconds": args.max_duration,
    }
    state = tracker.start_task(args.task_id, budget_config)
    for _ in range(args.steps):
        state.record_step()

    try:
        state.check_all()
        elapsed = args.duration
        steps = args.steps
        print(f"OK: {steps} steps, {elapsed}s elapsed (max {args.max_steps} steps, {args.max_duration}s)")
        sys.exit(0)
    except BudgetExceededError as e:
        print(f"EXCEEDED: [{e.budget_type}] {e}")
        sys.exit(1)


def cmd_sleep(args: argparse.Namespace) -> None:
    """Enter no-op idle sleep — log state, do not generate tasks."""
    adapter = PaperclipAdapter(
        api_url=args.api_url,
        agent_id=args.agent_id,
        idle_timeout_seconds=args.timeout,
    )
    result = adapter.sleep()
    print(f"SLEEP:{result['status']} agent={result['agent_id']} "
          f"reason={result['reason']} timeout={result['sleep_seconds']}s")
    # Verify no task creation is possible while idle
    from kernel.paperclip_adapter import TaskAdmission
    probe_admission = TaskAdmission(
        consumer="test",
        pain_point="testing idle guard",
        expected_value="verify enforcement",
        validation_path="unit test",
    )
    try:
        adapter.create_task("idle-probe", "probe", admission=probe_admission)
        print("ERROR: create_task succeeded while idle (guard missing)", file=sys.stderr)
        sys.exit(1)
    except IdleEnforcementError:
        pass
    sys.exit(0)


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "validate":
        cmd_validate(args)
    elif args.command == "check-loop":
        cmd_check_loop(args)
    elif args.command == "check-budget":
        cmd_check_budget(args)
    elif args.command == "sleep":
        cmd_sleep(args)
    else:
        parser.print_help()
        sys.exit(1)


if __name__ == "__main__":
    main()
