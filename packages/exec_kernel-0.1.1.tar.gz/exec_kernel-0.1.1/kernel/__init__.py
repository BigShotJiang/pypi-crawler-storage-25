"""Execution Kernel — deterministic task lifecycle enforcement."""

from kernel.lifecycle import (
    TaskState,
    TaskLifecycle,
    InvalidTransitionError,
    validate_transition,
    is_terminal,
)
from kernel.loop_detector import LoopDetector, LoopDetectionError, WorkNode
from kernel.budget import BudgetTracker, BudgetExceededError, TaskBudget
from kernel.config import load_config
from kernel.paperclip_adapter import (
    PaperclipAdapter,
    IdleEnforcementError,
    TaskAdmissionError,
    TaskAdmission,
)

from kernel.memory_hooks import MemoryHook, MemoryHookConfig

__all__ = [
    "TaskState",
    "TaskLifecycle",
    "InvalidTransitionError",
    "validate_transition",
    "is_terminal",
    "LoopDetector",
    "LoopDetectionError",
    "WorkNode",
    "BudgetTracker",
    "BudgetExceededError",
    "TaskBudget",
    "load_config",
    "PaperclipAdapter",
    "IdleEnforcementError",
    "TaskAdmissionError",
    "TaskAdmission",
    "MemoryHook",
    "MemoryHookConfig",
]

__version__ = "0.1.1"
