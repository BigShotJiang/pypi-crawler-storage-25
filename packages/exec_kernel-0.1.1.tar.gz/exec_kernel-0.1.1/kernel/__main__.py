"""Entry point for ``python -m kernel``."""
from kernel.cli import main

main()
