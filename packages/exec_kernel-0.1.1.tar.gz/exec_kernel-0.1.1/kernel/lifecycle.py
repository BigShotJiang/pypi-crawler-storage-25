"""Task lifecycle state machine with deterministic transition validation."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class TaskState(str, Enum):
    TODO = "todo"
    IN_PROGRESS = "in_progress"
    IN_REVIEW = "in_review"
    DONE = "done"
    BLOCKED = "blocked"
    CANCELLED = "cancelled"
    BACKLOG = "backlog"


class InvalidTransitionError(ValueError):
    """Raised when a lifecycle transition is not allowed."""

    def __init__(self, current: TaskState, target: TaskState, reason: str) -> None:
        self.current = current
        self.target = target
        self.reason = reason
        super().__init__(f"Cannot transition from {current.value} to {target.value}: {reason}")


TRANSITION_TABLE: dict[TaskState, dict[TaskState, str]] = {
    TaskState.BACKLOG: {
        TaskState.TODO: "Ready for work",
    },
    TaskState.TODO: {
        TaskState.IN_PROGRESS: "Work started",
        TaskState.CANCELLED: "Cancelled before start",
        TaskState.BLOCKED: "Blocked before start",
    },
    TaskState.IN_PROGRESS: {
        TaskState.DONE: "Work completed",
        TaskState.BLOCKED: "Blocked during work",
        TaskState.CANCELLED: "Cancelled during work",
        TaskState.IN_REVIEW: "Sent for review",
    },
    TaskState.IN_REVIEW: {
        TaskState.DONE: "Review approved",
        TaskState.IN_PROGRESS: "Changes requested",
        TaskState.BLOCKED: "Blocked during review",
        TaskState.CANCELLED: "Cancelled during review",
    },
    TaskState.BLOCKED: {
        TaskState.IN_PROGRESS: "Unblocked, resuming work",
        TaskState.CANCELLED: "Cancelled while blocked",
        TaskState.TODO: "Unblocked, needs fresh start",
    },
    TaskState.DONE: {},
    TaskState.CANCELLED: {},
}

TERMINAL_STATES = {TaskState.DONE, TaskState.CANCELLED}


def validate_transition(current: TaskState, target: TaskState) -> str:
    """Validate a state transition. Returns the reason string if valid.

    Raises InvalidTransitionError if the transition is not allowed.
    """
    if current not in TRANSITION_TABLE:
        raise InvalidTransitionError(current, target, f"Unknown current state: {current}")

    allowed = TRANSITION_TABLE[current]
    if target not in allowed:
        if current == target:
            raise InvalidTransitionError(current, target, "Transition to same state is not allowed")
        raise InvalidTransitionError(current, target, f"No valid transition from {current.value} to {target.value}")

    return allowed[target]


def is_terminal(state: TaskState) -> bool:
    """Check if a state is terminal (no outgoing transitions)."""
    return state in TERMINAL_STATES


@dataclass
class TaskLifecycle:
    task_id: str
    current_state: TaskState = TaskState.TODO
    transition_history: list[tuple[TaskState, TaskState, str, str]] = field(default_factory=list)

    def transition(self, target: TaskState, actor: str = "system") -> str:
        """Execute a validated state transition.

        Returns the reason string on success.
        Raises InvalidTransitionError if the transition is not allowed.
        """
        if is_terminal(self.current_state):
            raise InvalidTransitionError(
                self.current_state, target,
                f"Cannot transition from terminal state {self.current_state.value}"
            )

        reason = validate_transition(self.current_state, target)
        self.transition_history.append((self.current_state, target, reason, actor))
        self.current_state = target
        return reason

    def can_transition_to(self, target: TaskState) -> bool:
        """Check if a transition is possible without raising."""
        try:
            validate_transition(self.current_state, target)
            return True
        except InvalidTransitionError:
            return False
