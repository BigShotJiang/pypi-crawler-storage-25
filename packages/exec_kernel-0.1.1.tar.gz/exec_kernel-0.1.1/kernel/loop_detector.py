"""Detection and prevention of self-generated work loops."""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from typing import Optional


class LoopDetectionError(ValueError):
    """Raised when a work generation attempt would create a loop."""

    def __init__(self, message: str, loop_type: str) -> None:
        self.loop_type = loop_type
        super().__init__(message)


@dataclass
class WorkNode:
    task_id: str
    agent_id: str
    task_type: str
    parent_task_id: Optional[str] = None
    created_by_task_id: Optional[str] = None
    depth: int = 0


class LoopDetector:
    """Detects and prevents self-generated work loops.

    Tracks the work generation graph and enforces depth/cycle/identity limits.
    """

    def __init__(self, max_depth: int = 10, max_heap_size: int = 1000) -> None:
        self.max_depth = max_depth
        self.nodes: dict[str, WorkNode] = {}
        self.completed_heap: OrderedDict[str, bool] = OrderedDict()
        self._max_heap_size = max_heap_size

    def register_node(self, node: WorkNode) -> None:
        """Register a task node in the work graph."""
        self.nodes[node.task_id] = node

    def check_new_task(
        self,
        task_id: str,
        agent_id: str,
        task_type: str,
        parent_task_id: Optional[str] = None,
        created_by_task_id: Optional[str] = None,
    ) -> int:
        """Check if creating a new task is allowed.

        Returns the computed depth on success.
        Raises LoopDetectionError if the creation would create a loop.
        """
        depth = 0
        if parent_task_id and parent_task_id in self.nodes:
            depth = self.nodes[parent_task_id].depth + 1

        if depth > self.max_depth:
            raise LoopDetectionError(
                f"Task depth {depth} exceeds maximum {self.max_depth}. "
                f"Chain: {self._build_chain(parent_task_id)}",
                loop_type="depth_exceeded",
            )

        if self._would_create_cycle(task_id, created_by_task_id):
            raise LoopDetectionError(
                f"Creating task {task_id} would introduce a cycle in the work graph. "
                f"Agent {agent_id} would be creating work that traces back to itself.",
                loop_type="cycle_detected",
            )

        if self._is_identity_loop(agent_id, task_type, parent_task_id):
            raise LoopDetectionError(
                f"Agent {agent_id} is creating a {task_type} task for itself "
                f"while currently executing the same task type. "
                f"This appears to be a self-referential identity loop.",
                loop_type="identity_loop",
            )

        if task_id in self.completed_heap:
            raise LoopDetectionError(
                f"Task {task_id} was already completed and is in the "
                f"recently-completed heap. Re-processing detected.",
                loop_type="reprocess_detected",
            )

        return depth

    def mark_completed(self, task_id: str) -> None:
        """Mark a task as completed in the bounded heap."""
        self.completed_heap[task_id] = True
        if len(self.completed_heap) > self._max_heap_size:
            oldest = next(iter(self.completed_heap))
            del self.completed_heap[oldest]

    def _would_create_cycle(self, task_id: str, created_by_task_id: Optional[str]) -> bool:
        """Check if adding this task would create a cycle in the work graph."""
        if not created_by_task_id:
            return False

        visited: set[str] = set()
        stack = [created_by_task_id]

        while stack:
            current = stack.pop()
            if current == task_id:
                return True
            if current in visited:
                continue
            visited.add(current)
            node = self.nodes.get(current)
            if node and node.created_by_task_id:
                stack.append(node.created_by_task_id)

        return False

    def _is_identity_loop(self, agent_id: str, task_type: str, parent_task_id: Optional[str]) -> bool:
        """Check if an agent is about to create a task of the same type it's
        currently executing — a self-referential identity loop."""
        if not parent_task_id:
            return False

        parent = self.nodes.get(parent_task_id)
        if not parent:
            return False

        return parent.agent_id == agent_id and parent.task_type == task_type

    def _build_chain(self, task_id: Optional[str]) -> str:
        """Build a human-readable chain from task_id to root."""
        chain: list[str] = []
        current = task_id
        while current:
            node = self.nodes.get(current)
            if not node:
                chain.append(current)
                break
            chain.append(f"{node.task_id}({node.task_type})")
            current = node.parent_task_id
        return " -> ".join(reversed(chain))
