"""Execution budget enforcement for tasks."""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Optional


class BudgetExceededError(ValueError):
    """Raised when a task exceeds its execution budget."""

    def __init__(self, message: str, budget_type: str) -> None:
        self.budget_type = budget_type
        super().__init__(message)


@dataclass
class TaskBudget:
    max_steps: int = 50
    max_depth: int = 10
    max_duration_seconds: int = 1800

    @classmethod
    def from_config(cls, config: Optional[dict] = None) -> TaskBudget:
        if not config:
            return cls()
        return cls(
            max_steps=config.get("max_steps", 50),
            max_depth=config.get("max_depth", 10),
            max_duration_seconds=config.get("max_duration_seconds", 1800),
        )


@dataclass
class BudgetState:
    task_id: str
    budget: TaskBudget
    steps_taken: int = 0
    depth_reached: int = 0
    started_at: Optional[datetime] = None

    def record_step(self) -> None:
        self.steps_taken += 1

    def record_depth(self, depth: int) -> None:
        if depth > self.depth_reached:
            self.depth_reached = depth

    def start_timer(self) -> None:
        self.started_at = datetime.now(timezone.utc)

    def check_steps(self) -> None:
        if self.steps_taken > self.budget.max_steps:
            raise BudgetExceededError(
                f"Task {self.task_id} exceeded step budget: "
                f"{self.steps_taken} steps taken, max {self.budget.max_steps}",
                budget_type="steps",
            )

    def check_depth(self, proposed_depth: int) -> None:
        if proposed_depth > self.budget.max_depth:
            raise BudgetExceededError(
                f"Task {self.task_id} exceeded depth budget: "
                f"proposed depth {proposed_depth}, max {self.budget.max_depth}",
                budget_type="depth",
            )

    def check_duration(self) -> None:
        if self.started_at is None:
            return
        elapsed = (datetime.now(timezone.utc) - self.started_at).total_seconds()
        if elapsed > self.budget.max_duration_seconds:
            raise BudgetExceededError(
                f"Task {self.task_id} exceeded duration budget: "
                f"{elapsed:.0f}s elapsed, max {self.budget.max_duration_seconds}s",
                budget_type="duration",
            )

    def check_all(self) -> None:
        self.check_steps()
        self.check_duration()


class BudgetTracker:
    """Tracks and enforces execution budgets across all active tasks."""

    def __init__(self) -> None:
        self._states: dict[str, BudgetState] = {}

    def start_task(self, task_id: str, budget_config: Optional[dict] = None) -> BudgetState:
        budget = TaskBudget.from_config(budget_config)
        state = BudgetState(task_id=task_id, budget=budget)
        state.start_timer()
        self._states[task_id] = state
        return state

    def get_state(self, task_id: str) -> Optional[BudgetState]:
        return self._states.get(task_id)

    def record_step(self, task_id: str) -> None:
        state = self._states.get(task_id)
        if state:
            state.record_step()
            state.check_steps()

    def check(self, task_id: str) -> None:
        state = self._states.get(task_id)
        if state:
            state.check_all()

    def end_task(self, task_id: str) -> None:
        self._states.pop(task_id, None)
