"""Configuration loading for the execution kernel."""

from __future__ import annotations

import os
from pathlib import Path
from typing import Any, Optional

import yaml


DEFAULT_CONFIG_PATHS = [
    Path(".exec-kernel.yml"),
    Path("~/.exec-kernel.yml").expanduser(),
    Path("/etc/exec-kernel.yml"),
]

DEFAULT_CONFIG: dict[str, Any] = {
    "lifecycle": {
        "max_depth": 10,
        "max_heap_size": 1000,
    },
    "budget": {
        "max_steps": 50,
        "max_depth": 10,
        "max_duration_seconds": 1800,
    },
    "paperclip": {
        "api_url": os.environ.get("PAPERCLIP_API_URL", "http://127.0.0.1:3100"),
    },
}


def load_config(path: Optional[Path] = None) -> dict[str, Any]:
    """Load configuration from a YAML file, merging with defaults.

    Args:
        path: Optional explicit path. If not provided, searches DEFAULT_CONFIG_PATHS.

    Returns:
        Merged configuration dict.
    """
    config = dict(DEFAULT_CONFIG)

    paths_to_try = [path] if path else DEFAULT_CONFIG_PATHS
    for config_path in paths_to_try:
        if config_path and config_path.exists():
            with open(config_path) as f:
                user_config = yaml.safe_load(f)
            if user_config:
                _deep_merge(config, user_config)
            break

    return config


def _deep_merge(base: dict, override: dict) -> None:
    """Deep-merge override into base, mutating base."""
    for key, value in override.items():
        if key in base and isinstance(base[key], dict) and isinstance(value, dict):
            _deep_merge(base[key], value)
        else:
            base[key] = value
