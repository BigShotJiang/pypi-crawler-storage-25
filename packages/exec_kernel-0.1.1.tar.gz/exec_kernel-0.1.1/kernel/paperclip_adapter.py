"""Paperclip API adapter for the execution kernel.

Translates kernel state machine actions into Paperclip API calls.
Enforces idle/no-op sleep on empty queue — no speculative task generation.
Enforces structured admission schema on all new tasks.
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass
from typing import Any, Optional

import requests

from kernel.lifecycle import TaskState, validate_transition, InvalidTransitionError

logger = logging.getLogger(__name__)


class IdleEnforcementError(RuntimeError):
    """Raised when an operation is attempted while the adapter is in idle mode."""

    def __init__(self, operation: str) -> None:
        super().__init__(
            f"Cannot {operation} while in idle mode. "
            f"No speculative execution or self-generated busywork allowed."
        )


class TaskAdmissionError(RuntimeError):
    """Raised when a task fails the structured admission schema check."""


@dataclass
class TaskAdmission:
    """Structured admission schema for all new tasks.

    Every task must declare:
      consumer        — who benefits from this work
      pain_point      — what problem it solves
      expected_value  — the measurable outcome
      validation_path — how success will be verified
      origin_category — where this task originates (demand, unmet_need, etc.)
      origin_evidence — supporting evidence for the origin
    """

    consumer: str
    pain_point: str
    expected_value: str
    validation_path: str
    origin_category: Optional[str] = None
    origin_evidence: Optional[str] = None

    def is_complete(self) -> bool:
        return all([
            bool(self.consumer),
            bool(self.pain_point),
            bool(self.expected_value),
            bool(self.validation_path),
        ])

    def to_dict(self) -> dict[str, str]:
        d: dict[str, str] = {
            "consumer": self.consumer,
            "pain_point": self.pain_point,
            "expected_value": self.expected_value,
            "validation_path": self.validation_path,
        }
        if self.origin_category:
            d["origin_category"] = self.origin_category
        if self.origin_evidence:
            d["origin_evidence"] = self.origin_evidence
        return d


class PaperclipAdapter:
    """Adapter that maps kernel actions to Paperclip API calls.

    Idle mode: when ``sleep()`` has been called, the adapter enters an
    enforcement state that prevents ``create_task()`` from generating new
    work. This enforces the "no tasks → sleep → do not generate" invariant.
    """

    def __init__(
        self,
        api_url: Optional[str] = None,
        api_key: Optional[str] = None,
        agent_id: Optional[str] = None,
        company_id: Optional[str] = None,
        run_id: Optional[str] = None,
        idle_timeout_seconds: int = 30,
    ) -> None:
        self.api_url = api_url or os.environ.get("PAPERCLIP_API_URL", "")
        self.api_key = api_key or os.environ.get("PAPERCLIP_API_KEY", "")
        self.agent_id = agent_id or os.environ.get("PAPERCLIP_AGENT_ID", "")
        self.company_id = company_id or os.environ.get("PAPERCLIP_COMPANY_ID", "")
        self.run_id = run_id or os.environ.get("PAPERCLIP_RUN_ID", "")
        self.idle_timeout_seconds = idle_timeout_seconds
        self._session = requests.Session()
        self._session.headers.update({
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
        })
        if self.run_id:
            self._session.headers["X-Paperclip-Run-Id"] = self.run_id
        self._idle = False

    def _headers(self) -> dict[str, str]:
        headers: dict[str, str] = {}
        if self.run_id:
            headers["X-Paperclip-Run-Id"] = self.run_id
        return headers

    def checkout(self, issue_id: str) -> dict[str, Any]:
        """Checkout a task, transitioning it to in_progress."""
        url = f"{self.api_url}/api/issues/{issue_id}/checkout"
        resp = self._session.post(
            url,
            json={
                "agentId": self.agent_id,
                "expectedStatuses": ["todo", "backlog", "blocked", "in_review"],
            },
        )
        if resp.status_code == 409:
            raise RuntimeError(f"Task {issue_id} is owned by another agent: {resp.text}")
        resp.raise_for_status()
        return resp.json()

    def transition_task(
        self,
        issue_id: str,
        current_state: TaskState,
        target_state: TaskState,
        comment: Optional[str] = None,
    ) -> dict[str, Any]:
        """Validate and apply a lifecycle transition via the Paperclip API."""
        validate_transition(current_state, target_state)

        payload: dict[str, Any] = {"status": target_state.value}
        if comment:
            payload["comment"] = comment

        url = f"{self.api_url}/api/issues/{issue_id}"
        resp = self._session.patch(url, json=payload, headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def sleep(self) -> dict[str, Any]:
        """Enter idle sleep mode.

        Logs the current idle state and returns without side effects.
        No tasks are created and no speculative work is performed.
        """
        self._idle = True
        logger.info(
            "AGENT_SLEEP agent=%s reason=no_tasks timeout=%ds",
            self.agent_id,
            self.idle_timeout_seconds,
        )
        return {
            "status": "idle",
            "agent_id": self.agent_id,
            "reason": "no_tasks",
            "sleep_seconds": self.idle_timeout_seconds,
        }

    def wake(self) -> dict[str, Any]:
        """Exit idle sleep mode and resume normal operation."""
        self._idle = False
        logger.info("AGENT_WAKE agent=%s", self.agent_id)
        return {
            "status": "active",
            "agent_id": self.agent_id,
        }

    @property
    def is_idle(self) -> bool:
        """Check whether the adapter is currently in idle sleep mode."""
        return self._idle

    def create_task(
        self,
        title: str,
        task_type: str,
        admission: TaskAdmission,
        parent_id: Optional[str] = None,
        goal_id: Optional[str] = None,
        assignee_agent_id: Optional[str] = None,
        description: Optional[str] = None,
    ) -> dict[str, Any]:
        """Create a new task in Paperclip.

        Every task requires a ``TaskAdmission`` — the structured admission
        schema ``{consumer, pain_point, expected_value, validation_path}``
        — that is validated before creation proceeds.

        Raises:
            IdleEnforcementError: if called while in idle sleep mode.
            TaskAdmissionError: if the admission schema is incomplete.
        """
        if not admission.is_complete():
            missing = []
            if not admission.consumer:
                missing.append("consumer")
            if not admission.pain_point:
                missing.append("pain_point")
            if not admission.expected_value:
                missing.append("expected_value")
            if not admission.validation_path:
                missing.append("validation_path")
            raise TaskAdmissionError(
                f"Cannot create task '{title}': admission schema incomplete "
                f"(missing: {', '.join(missing)})"
            )

        if self._idle:
            raise IdleEnforcementError(f"create_task('{title}')")

        admission_block = json.dumps(admission.to_dict(), indent=2)
        full_description = (
            f"{description or ''}\n\n"
            f"---\n"
            f"### Admission Schema\n"
            f"```json\n{admission_block}\n```"
        ).strip()

        payload: dict[str, Any] = {
            "title": title,
            "description": full_description,
            "status": "todo",
            "assigneeAgentId": assignee_agent_id or self.agent_id,
        }
        if parent_id:
            payload["parentId"] = parent_id
        if goal_id:
            payload["goalId"] = goal_id

        url = f"{self.api_url}/api/companies/{self.company_id}/issues"
        resp = self._session.post(url, json=payload, headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def add_comment(self, issue_id: str, body: str) -> dict[str, Any]:
        """Add a comment to an issue."""
        url = f"{self.api_url}/api/issues/{issue_id}/comments"
        resp = self._session.post(url, json={"body": body}, headers=self._headers())
        resp.raise_for_status()
        return resp.json()
