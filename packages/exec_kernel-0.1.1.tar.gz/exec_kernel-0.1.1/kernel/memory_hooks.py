"""Lifecycle transition memory hooks.

Writes LESSON / BLOCKED_PATHWAY entries to StrategicMemory when the
execution kernel reaches terminal or blocked states.

Per ADR-020:
  - Every completed task SHOULD write a LESSON to strategic memory.
  - Agents MUST write a BLOCKED_PATHWAY when exhausting retries on a task.
"""

from __future__ import annotations

import logging
from typing import Any, Optional

from kernel.lifecycle import TaskState

logger = logging.getLogger(__name__)


class MemoryHookConfig:
    """Configuration for memory hooks.

    Attributes:
        enabled: Master switch.  Set False to disable all memory hooks.
        lesson_on_done: Write LESSON when a task transitions to DONE.
        blocked_pathway_on_blocked: Write BLOCKED_PATHWAY on BLOCKED.
        memory_store_path: Path to the StrategicMemory JSONL file.
            If None, uses the default from ``StrategicMemoryStore``.
        default_agent_id: Agent ID to record in memory entries when
            the caller does not supply one.
        memory_tags: Default tags attached to every memory entry written
            by the hook.
    """

    def __init__(
        self,
        enabled: bool = True,
        lesson_on_done: bool = True,
        blocked_pathway_on_blocked: bool = True,
        memory_store_path: Optional[str] = None,
        default_agent_id: str = "kernel",
        memory_tags: Optional[list[str]] = None,
    ):
        self.enabled = enabled
        self.lesson_on_done = lesson_on_done
        self.blocked_pathway_on_blocked = blocked_pathway_on_blocked
        self.memory_store_path = memory_store_path
        self.default_agent_id = default_agent_id
        self.memory_tags = memory_tags or ["kernel", "lifecycle"]


class MemoryHook:
    """Hook that writes to StrategicMemory on lifecycle transitions.

    Usage:
        hook = MemoryHook()
        hook.on_transition("task-123", TaskState.IN_PROGRESS, TaskState.DONE,
                           metadata={"summary": "Deployed successfully"})
    """

    def __init__(self, config: Optional[MemoryHookConfig] = None):
        self.config = config or MemoryHookConfig()
        self._store: Any = None

    @property
    def store(self) -> Any:
        if self._store is None:
            import importlib
            mod = importlib.import_module("engine.memory.store")
            cls = getattr(mod, "StrategicMemoryStore")
            self._store = cls(path=self.config.memory_store_path)
        return self._store

    def on_transition(
        self,
        task_id: str,
        from_state: TaskState,
        to_state: TaskState,
        actor: str = "system",
        metadata: Optional[dict[str, Any]] = None,
    ) -> Optional[str]:
        """Handle a lifecycle transition.

        Returns the ISO timestamp of the written memory entry, or None
        if no entry was written.
        """
        if not self.config.enabled:
            return None

        metadata = metadata or {}
        agent_id = metadata.get("agent_id", self.config.default_agent_id)
        mission_id = metadata.get("mission_id")

        if to_state == TaskState.DONE and self.config.lesson_on_done:
            return self._write_lesson(task_id, actor, metadata, agent_id, mission_id)

        if to_state == TaskState.BLOCKED and self.config.blocked_pathway_on_blocked:
            return self._write_blocked_pathway(task_id, actor, metadata, agent_id, mission_id)

        return None

    def _write_lesson(
        self,
        task_id: str,
        actor: str,
        metadata: dict[str, Any],
        agent_id: str,
        mission_id: Optional[str],
    ) -> str:
        description = metadata.get(
            "summary",
            f"Task {task_id} completed by {actor}",
        )
        outcome = metadata.get(
            "outcome",
            "Task reached DONE state successfully.",
        )
        ts = self.store.record_lesson(
            description=description,
            outcome=outcome,
            tags=self.config.memory_tags + metadata.get("tags", []),
            agent_id=agent_id,
            mission_id=mission_id,
        )
        logger.info(
            "MEMORY_HOOK lesson agent=%s task=%s ts=%s",
            agent_id, task_id, ts,
        )
        return ts

    def _write_blocked_pathway(
        self,
        task_id: str,
        actor: str,
        metadata: dict[str, Any],
        agent_id: str,
        mission_id: Optional[str],
    ) -> str:
        description = metadata.get(
            "summary",
            f"Task {task_id} blocked during {actor}",
        )
        blocker = metadata.get(
            "blocker",
            "Unknown blocker — task transitioned to BLOCKED",
        )
        workaround = metadata.get("workaround_attempted")
        ts = self.store.record_blocked_pathway(
            description=description,
            blocker=blocker,
            workaround_attempted=workaround,
            tags=self.config.memory_tags + metadata.get("tags", []),
            agent_id=agent_id,
            mission_id=mission_id,
        )
        logger.info(
            "MEMORY_HOOK blocked_pathway agent=%s task=%s ts=%s",
            agent_id, task_id, ts,
        )
        return ts
