"""Tests for kernel lifecycle memory hooks."""

import sys
import tempfile
from pathlib import Path

import pytest

from kernel.lifecycle import TaskState
from kernel.memory_hooks import MemoryHook, MemoryHookConfig


# Ensure stripe is importable (it's needed by engine.__init__)
import types
stripe_mock = types.ModuleType("stripe")
stripe_mock.Charge = type("Charge", (), {"create": lambda **kw: {"id": "mock_charge"}})
stripe_mock.api_key = None
sys.modules["stripe"] = stripe_mock


@pytest.fixture
def memory_path():
    with tempfile.NamedTemporaryFile(suffix=".jsonl", delete=False) as f:
        path = Path(f.name)
    yield path
    if path.exists():
        path.unlink()


@pytest.fixture
def hook(memory_path):
    config = MemoryHookConfig(
        enabled=True,
        memory_store_path=str(memory_path),
        default_agent_id="test-agent",
        memory_tags=["test", "lifecycle"],
    )
    return MemoryHook(config=config)


class TestMemoryHook:

    def test_done_transition_writes_lesson(self, hook):
        ts = hook.on_transition(
            task_id="task-1",
            from_state=TaskState.IN_PROGRESS,
            to_state=TaskState.DONE,
            actor="test-actor",
            metadata={"summary": "Deployed service X", "outcome": "All checks passed"},
        )
        assert ts is not None
        entries = hook.store.query()
        assert len(entries) == 1
        assert entries[0].kind.value == "lesson"
        assert entries[0].agent_id == "test-agent"

    def test_blocked_transition_writes_blocked_pathway(self, hook):
        ts = hook.on_transition(
            task_id="task-2",
            from_state=TaskState.IN_PROGRESS,
            to_state=TaskState.BLOCKED,
            actor="test-actor",
            metadata={
                "summary": "API rate limit reached",
                "blocker": "Rate limit exceeded on provider X",
                "workaround_attempted": "Retried with exponential backoff, all 3 attempts failed",
            },
        )
        assert ts is not None
        entries = hook.store.query()
        assert len(entries) == 1
        assert entries[0].kind.value == "blocked_pathway"
        assert "Rate limit" in str(entries[0].content.blocker)

    def test_no_write_when_disabled(self, memory_path):
        config = MemoryHookConfig(
            enabled=False,
            memory_store_path=str(memory_path),
        )
        disabled = MemoryHook(config=config)
        ts = disabled.on_transition(
            task_id="task-3",
            from_state=TaskState.IN_PROGRESS,
            to_state=TaskState.DONE,
        )
        assert ts is None
        assert disabled.store.count() == 0

    def test_irrelevant_transition_does_nothing(self, hook):
        ts = hook.on_transition(
            task_id="task-4",
            from_state=TaskState.TODO,
            to_state=TaskState.IN_PROGRESS,
        )
        assert ts is None
        assert hook.store.count() == 0

    def test_lesson_with_mission_id(self, hook):
        ts = hook.on_transition(
            task_id="task-5",
            from_state=TaskState.IN_PROGRESS,
            to_state=TaskState.DONE,
            metadata={"mission_id": "mission-alpha", "summary": "Done"},
        )
        assert ts is not None
        entries = hook.store.query()
        assert entries[0].mission_id == "mission-alpha"

    def test_blocked_with_custom_tags(self, hook):
        ts = hook.on_transition(
            task_id="task-6",
            from_state=TaskState.IN_PROGRESS,
            to_state=TaskState.BLOCKED,
            metadata={"tags": ["infra", "network"]},
        )
        assert ts is not None
        entries = hook.store.query()
        assert "infra" in entries[0].tags
        assert "network" in entries[0].tags
        assert "test" in entries[0].tags

    def test_review_transition_does_nothing(self, hook):
        ts = hook.on_transition(
            task_id="task-7",
            from_state=TaskState.IN_PROGRESS,
            to_state=TaskState.IN_REVIEW,
        )
        assert ts is None
        assert hook.store.count() == 0

    def test_cancelled_transition_does_nothing(self, hook):
        ts = hook.on_transition(
            task_id="task-8",
            from_state=TaskState.IN_PROGRESS,
            to_state=TaskState.CANCELLED,
        )
        assert ts is None
        assert hook.store.count() == 0
