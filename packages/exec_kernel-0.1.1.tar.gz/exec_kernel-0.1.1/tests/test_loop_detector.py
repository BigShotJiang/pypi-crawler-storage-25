"""Tests for kernel.loop_detector module."""
import pytest
from kernel.loop_detector import LoopDetector, WorkNode, LoopDetectionError


def test_loop_detector_allows_first_task():
    detector = LoopDetector(max_depth=10)
    depth = detector.check_new_task("task-1", "agent-1", "feature")
    assert depth == 0


def test_loop_detector_detects_depth_exceeded():
    detector = LoopDetector(max_depth=1)
    detector.register_node(WorkNode(task_id="task-1", agent_id="agent-1", task_type="feature-a", depth=0))
    depth_2 = detector.check_new_task("task-2", "agent-1", task_type="feature-b", parent_task_id="task-1")
    assert depth_2 == 1
    detector.register_node(WorkNode(task_id="task-2", agent_id="agent-1", task_type="feature-b", parent_task_id="task-1", depth=depth_2))
    with pytest.raises(LoopDetectionError) as exc_info:
        detector.check_new_task("task-3", "agent-1", task_type="feature-c", parent_task_id="task-2")
    assert exc_info.value.loop_type == "depth_exceeded"


def test_work_node():
    node = WorkNode(task_id="task-x", agent_id="agent-x", task_type="test")
    assert node.task_id == "task-x"
    assert node.agent_id == "agent-x"
    assert node.task_type == "test"