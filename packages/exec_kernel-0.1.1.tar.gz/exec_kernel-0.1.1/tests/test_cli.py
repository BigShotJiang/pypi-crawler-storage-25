"""Tests for the execution kernel CLI."""

import sys
from argparse import Namespace

import pytest

from kernel.cli import build_parser, cmd_validate, cmd_check_loop, cmd_check_budget, cmd_sleep


class TestBuildParser:
    def test_parser_created(self):
        parser = build_parser()
        assert parser is not None

    def test_validate_subcommand(self):
        parser = build_parser()
        args = parser.parse_args(["validate", "todo", "in_progress"])
        assert args.command == "validate"
        assert args.current == "todo"
        assert args.target == "in_progress"

    def test_check_loop_subcommand(self):
        parser = build_parser()
        args = parser.parse_args([
            "check-loop", "task-1", "agent-1", "feature",
            "--parent-task-id", "parent-1",
        ])
        assert args.command == "check-loop"
        assert args.task_id == "task-1"
        assert args.agent_id == "agent-1"
        assert args.task_type == "feature"
        assert args.parent_task_id == "parent-1"

    def test_check_budget_subcommand(self):
        parser = build_parser()
        args = parser.parse_args([
            "check-budget", "task-1",
            "--steps", "5", "--max-steps", "10",
        ])
        assert args.command == "check-budget"
        assert args.task_id == "task-1"
        assert args.steps == 5
        assert args.max_steps == 10

    def test_parser_requires_command(self):
        parser = build_parser()
        with pytest.raises(SystemExit):
            parser.parse_args([])


class TestCmdValidate:
    def test_valid_transition_exit_zero(self):
        args = Namespace(current="todo", target="in_progress")
        with pytest.raises(SystemExit) as exc:
            cmd_validate(args)
        assert exc.value.code == 0

    def test_invalid_transition_exit_nonzero(self):
        args = Namespace(current="todo", target="done")
        with pytest.raises(SystemExit) as exc:
            cmd_validate(args)
        assert exc.value.code != 0


class TestCmdCheckLoop:
    def test_allowed_creation(self):
        args = Namespace(
            task_id="child-1",
            agent_id="agent-1",
            task_type="feature",
            parent_task_id=None,
            created_by_task_id=None,
            max_depth=10,
        )
        with pytest.raises(SystemExit) as exc:
            cmd_check_loop(args)
        assert exc.value.code == 0


class TestCmdCheckBudget:
    def test_budget_ok(self):
        args = Namespace(
            task_id="task-1",
            steps=3,
            max_steps=10,
            duration=5,
            max_duration=60,
        )
        with pytest.raises(SystemExit) as exc:
            cmd_check_budget(args)
        assert exc.value.code == 0


class TestCmdSleep:
    def test_sleep_exits_zero(self):
        args = Namespace(
            timeout=30,
            agent_id="test-agent",
            api_url=None,
        )
        with pytest.raises(SystemExit) as exc:
            cmd_sleep(args)
        assert exc.value.code == 0

    def test_sleep_parser_created(self):
        parser = build_parser()
        args = parser.parse_args(["sleep"])
        assert args.command == "sleep"
        assert args.timeout == 30  # default

    def test_sleep_custom_timeout(self):
        parser = build_parser()
        args = parser.parse_args(["sleep", "--timeout", "60"])
        assert args.command == "sleep"
        assert args.timeout == 60

    def test_sleep_with_agent_id(self):
        parser = build_parser()
        args = parser.parse_args(["sleep", "--agent-id", "coder-1"])
        assert args.command == "sleep"
        assert args.agent_id == "coder-1"
