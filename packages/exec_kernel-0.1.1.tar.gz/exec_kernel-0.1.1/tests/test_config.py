"""Tests for configuration loading."""

from pathlib import Path
from kernel.config import load_config, DEFAULT_CONFIG


class TestLoadConfig:
    def test_returns_defaults_when_no_file(self):
        config = load_config(path=Path("/nonexistent/path.yml"))
        assert config["lifecycle"]["max_depth"] == 10
        assert config["lifecycle"]["max_heap_size"] == 1000
        assert config["budget"]["max_steps"] == 50
        assert config["budget"]["max_depth"] == 10
        assert config["budget"]["max_duration_seconds"] == 1800

    def test_default_structure(self):
        assert "lifecycle" in DEFAULT_CONFIG
        assert "budget" in DEFAULT_CONFIG
        assert "paperclip" in DEFAULT_CONFIG

    def test_paperclip_api_url_default(self):
        assert DEFAULT_CONFIG["paperclip"]["api_url"] is not None

    def test_merge_overrides_lifecycle(self, tmp_path):
        cfg = tmp_path / "exec-kernel.yml"
        cfg.write_text("lifecycle:\n  max_depth: 5\n")
        config = load_config(path=cfg)
        assert config["lifecycle"]["max_depth"] == 5
        assert config["lifecycle"]["max_heap_size"] == 1000

    def test_merge_overrides_multiple_keys(self, tmp_path):
        cfg = tmp_path / "exec-kernel.yml"
        cfg.write_text("budget:\n  max_steps: 10\n  max_duration_seconds: 60\n")
        config = load_config(path=cfg)
        assert config["budget"]["max_steps"] == 10
        assert config["budget"]["max_duration_seconds"] == 60
        assert config["budget"]["max_depth"] == 10
