"""Tests for budget enforcement."""

import time

import pytest

from kernel.budget import BudgetTracker, TaskBudget, BudgetState, BudgetExceededError


class TestTaskBudget:
    def test_default_config(self):
        budget = TaskBudget()
        assert budget.max_steps == 50
        assert budget.max_depth == 10
        assert budget.max_duration_seconds == 1800

    def test_custom_config(self):
        budget = TaskBudget.from_config({
            "max_steps": 10,
            "max_depth": 3,
            "max_duration_seconds": 60,
        })
        assert budget.max_steps == 10
        assert budget.max_depth == 3
        assert budget.max_duration_seconds == 60

    def test_from_empty_config(self):
        budget = TaskBudget.from_config({})
        assert budget.max_steps == 50


class TestBudgetState:
    def test_step_budget_exceeded(self):
        budget = TaskBudget(max_steps=3)
        state = BudgetState(task_id="test", budget=budget)
        state.record_step()
        state.record_step()
        state.record_step()
        state.record_step()
        with pytest.raises(BudgetExceededError) as exc:
            state.check_steps()
        assert exc.value.budget_type == "steps"

    def test_step_budget_ok(self):
        budget = TaskBudget(max_steps=5)
        state = BudgetState(task_id="test", budget=budget)
        state.record_step()
        state.record_step()
        state.check_steps()

    def test_depth_budget_exceeded(self):
        budget = TaskBudget(max_depth=3)
        state = BudgetState(task_id="test", budget=budget)
        with pytest.raises(BudgetExceededError) as exc:
            state.check_depth(4)
        assert exc.value.budget_type == "depth"

    def test_depth_budget_ok(self):
        budget = TaskBudget(max_depth=5)
        state = BudgetState(task_id="test", budget=budget)
        state.check_depth(3)

    def test_duration_budget_exceeded(self):
        budget = TaskBudget(max_duration_seconds=1)
        state = BudgetState(task_id="test", budget=budget)
        state.start_timer()
        time.sleep(1.1)
        with pytest.raises(BudgetExceededError) as exc:
            state.check_duration()
        assert exc.value.budget_type == "duration"

    def test_duration_budget_ok(self):
        budget = TaskBudget(max_duration_seconds=10)
        state = BudgetState(task_id="test", budget=budget)
        state.start_timer()
        state.check_duration()

    def test_depth_recording(self):
        budget = TaskBudget(max_depth=10)
        state = BudgetState(task_id="test", budget=budget)
        state.record_depth(3)
        assert state.depth_reached == 3
        state.record_depth(1)
        assert state.depth_reached == 3
        state.record_depth(5)
        assert state.depth_reached == 5


class TestBudgetTracker:
    def test_start_and_check(self):
        tracker = BudgetTracker()
        state = tracker.start_task("task-1")
        assert state is not None
        assert state.task_id == "task-1"

    def test_record_step_and_check(self):
        tracker = BudgetTracker()
        tracker.start_task("task-1", {"max_steps": 3})
        tracker.record_step("task-1")
        tracker.record_step("task-1")
        tracker.check("task-1")

    def test_record_step_exceeds_budget(self):
        tracker = BudgetTracker()
        tracker.start_task("task-1", {"max_steps": 2})
        tracker.record_step("task-1")
        tracker.record_step("task-1")
        with pytest.raises(BudgetExceededError):
            tracker.record_step("task-1")

    def test_get_state_nonexistent(self):
        tracker = BudgetTracker()
        assert tracker.get_state("nonexistent") is None

    def test_end_task(self):
        tracker = BudgetTracker()
        tracker.start_task("task-1")
        assert tracker.get_state("task-1") is not None
        tracker.end_task("task-1")
        assert tracker.get_state("task-1") is None

    def test_record_step_nonexistent(self):
        tracker = BudgetTracker()
        tracker.record_step("nonexistent")
