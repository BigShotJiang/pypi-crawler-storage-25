"""Tests for kernel.lifecycle module."""
import pytest
from kernel.lifecycle import TaskLifecycle, TaskState, validate_transition, is_terminal, InvalidTransitionError


def test_initial_state():
    t = TaskLifecycle(task_id="test-1")
    assert t.current_state == TaskState.TODO


def test_valid_transitions():
    t = TaskLifecycle(task_id="test-2")
    t.transition(TaskState.IN_PROGRESS)
    assert t.current_state == TaskState.IN_PROGRESS
    t.transition(TaskState.DONE)
    assert t.current_state == TaskState.DONE


def test_invalid_transition():
    t = TaskLifecycle(task_id="test-3")
    with pytest.raises(InvalidTransitionError):
        t.transition(TaskState.DONE)


def test_validate_transition_valid():
    assert validate_transition(TaskState.TODO, TaskState.IN_PROGRESS) == "Work started"


def test_validate_transition_invalid():
    with pytest.raises(InvalidTransitionError):
        validate_transition(TaskState.TODO, TaskState.DONE)


def test_is_terminal():
    assert is_terminal(TaskState.DONE) is True
    assert is_terminal(TaskState.CANCELLED) is True
    assert is_terminal(TaskState.IN_PROGRESS) is False
    assert is_terminal(TaskState.TODO) is False


def test_can_transition_to():
    t = TaskLifecycle(task_id="test")
    assert t.can_transition_to(TaskState.IN_PROGRESS) is True
    assert t.can_transition_to(TaskState.DONE) is False


def test_terminal_state_blocks_transition():
    t = TaskLifecycle(task_id="test")
    t.transition(TaskState.IN_PROGRESS)
    t.transition(TaskState.DONE)
    with pytest.raises(InvalidTransitionError):
        t.transition(TaskState.IN_PROGRESS)