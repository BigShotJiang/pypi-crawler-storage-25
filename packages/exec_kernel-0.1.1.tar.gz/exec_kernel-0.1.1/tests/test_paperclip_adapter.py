"""Tests for the Paperclip API adapter."""

import json
import logging
from unittest.mock import MagicMock, patch

import pytest

from kernel.lifecycle import TaskState, InvalidTransitionError
from kernel.paperclip_adapter import (
    IdleEnforcementError,
    PaperclipAdapter,
    TaskAdmission,
    TaskAdmissionError,
)


@pytest.fixture
def adapter():
    return PaperclipAdapter(
        api_url="http://test:3100",
        api_key="test-key",
        agent_id="agent-1",
        company_id="comp-1",
        run_id="run-1",
    )


@pytest.fixture
def valid_admission():
    return TaskAdmission(
        consumer="external devs",
        pain_point="no data pipeline",
        expected_value="save 2h/week",
        validation_path="beta user interview",
    )


class TestInit:
    def test_uses_provided_values(self):
        a = PaperclipAdapter(
            api_url="http://custom:3100",
            api_key="key",
            agent_id="aid",
            company_id="cid",
            run_id="rid",
        )
        assert a.api_url == "http://custom:3100"
        assert a.api_key == "key"
        assert a.agent_id == "aid"
        assert a.company_id == "cid"
        assert a.run_id == "rid"

    def test_session_headers_set(self, adapter):
        assert adapter._session.headers["Authorization"] == "Bearer test-key"
        assert adapter._session.headers["Content-Type"] == "application/json"


class TestTransitionTask:
    def test_valid_transition_calls_patch(self, adapter):
        with patch.object(adapter._session, "patch") as mock_patch:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = {"status": "in_progress"}
            mock_patch.return_value = mock_resp

            result = adapter.transition_task(
                "issue-1", TaskState.TODO, TaskState.IN_PROGRESS,
                comment="Starting work",
            )

            mock_patch.assert_called_once()
            call_kwargs = mock_patch.call_args[1]
            assert call_kwargs["json"]["status"] == "in_progress"
            assert call_kwargs["json"]["comment"] == "Starting work"
            assert result == {"status": "in_progress"}

    def test_invalid_transition_raises(self, adapter):
        with pytest.raises(InvalidTransitionError):
            adapter.transition_task("issue-1", TaskState.TODO, TaskState.DONE)

    def test_run_id_header_included(self, adapter):
        with patch.object(adapter._session, "patch") as mock_patch:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = {}
            mock_patch.return_value = mock_resp

            adapter.transition_task("issue-1", TaskState.IN_PROGRESS, TaskState.DONE)

            _, kwargs = mock_patch.call_args
            headers = kwargs.get("headers", {})
            assert headers.get("X-Paperclip-Run-Id") == "run-1"

    def test_checkout_calls_post(self, adapter):
        with patch.object(adapter._session, "post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.status_code = 200
            mock_resp.json.return_value = {"status": "in_progress"}
            mock_post.return_value = mock_resp

            result = adapter.checkout("issue-1")

            mock_post.assert_called_once_with(
                "http://test:3100/api/issues/issue-1/checkout",
                json={"agentId": "agent-1", "expectedStatuses": ["todo", "backlog", "blocked", "in_review"]},
            )
            assert result == {"status": "in_progress"}

    def test_checkout_409_raises(self, adapter):
        with patch.object(adapter._session, "post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.status_code = 409
            mock_resp.text = "Conflict"
            mock_post.return_value = mock_resp

            with pytest.raises(RuntimeError, match="owned by another agent"):
                adapter.checkout("issue-1")

    def test_create_task_calls_post(self, adapter, valid_admission):
        with patch.object(adapter._session, "post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.status_code = 201
            mock_resp.json.return_value = {"id": "new-issue", "status": "todo"}
            mock_post.return_value = mock_resp

            result = adapter.create_task(
                title="Test task",
                task_type="feature",
                admission=valid_admission,
                parent_id="parent-1",
                goal_id="goal-1",
                assignee_agent_id="agent-2",
            )

            mock_post.assert_called_once()
            _, kwargs = mock_post.call_args
            assert kwargs["json"]["title"] == "Test task"
            assert kwargs["json"]["parentId"] == "parent-1"
            assert kwargs["json"]["goalId"] == "goal-1"
            assert kwargs["json"]["assigneeAgentId"] == "agent-2"
            assert kwargs["json"]["status"] == "todo"
            # Description should contain the admission schema
            assert "Admission Schema" in kwargs["json"]["description"]
            assert "consumer" in kwargs["json"]["description"]
            assert result == {"id": "new-issue", "status": "todo"}

    def test_create_task_raises_when_admission_incomplete(self, adapter):
        incomplete = TaskAdmission(
            consumer="",
            pain_point="some pain",
            expected_value="",
            validation_path="",
        )
        with pytest.raises(TaskAdmissionError) as exc:
            adapter.create_task("bad-task", "feature", admission=incomplete)
        assert "admission schema incomplete" in str(exc.value)
        assert "consumer" in str(exc.value)
        assert "expected_value" in str(exc.value)
        assert "validation_path" in str(exc.value)

    def test_create_task_stores_admission_in_description(self, adapter, valid_admission):
        with patch.object(adapter._session, "post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.status_code = 201
            mock_resp.json.return_value = {"id": "new-issue", "status": "todo"}
            mock_post.return_value = mock_resp

            adapter.create_task(
                title="Task with desc",
                task_type="feature",
                admission=valid_admission,
                description="Original description",
            )

            _, kwargs = mock_post.call_args
            desc = kwargs["json"]["description"]
            assert "Original description" in desc
            assert "Admission Schema" in desc
            assert "external devs" in desc
            assert "no data pipeline" in desc
            assert "Admission Schema" in desc  # markdown heading
            assert "```json" in desc

            # Verify the embedded JSON is valid and contains all 4 fields
            json_start = desc.index("```json\n") + len("```json\n")
            json_end = desc.index("\n```", json_start)
            embedded = json.loads(desc[json_start:json_end])
            assert embedded["consumer"] == "external devs"
            assert embedded["pain_point"] == "no data pipeline"
            assert embedded["expected_value"] == "save 2h/week"
            assert embedded["validation_path"] == "beta user interview"

    def test_add_comment_calls_post(self, adapter):
        with patch.object(adapter._session, "post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.status_code = 201
            mock_resp.json.return_value = {"id": "comment-1"}
            mock_post.return_value = mock_resp

            result = adapter.add_comment("issue-1", "A test comment")

            mock_post.assert_called_once_with(
                "http://test:3100/api/issues/issue-1/comments",
                json={"body": "A test comment"},
                headers={"X-Paperclip-Run-Id": "run-1"},
            )
            assert result == {"id": "comment-1"}


class TestIdleHandling:
    """No-op sleep on empty queue — no speculative task generation."""

    def test_sleep_returns_idle_status(self, adapter):
        result = adapter.sleep()
        assert result["status"] == "idle"
        assert result["reason"] == "no_tasks"
        assert result["sleep_seconds"] == 30
        assert adapter.is_idle is True

    def test_sleep_logs_state(self, adapter, caplog):
        caplog.set_level(logging.INFO)
        adapter.sleep()
        assert "AGENT_SLEEP" in caplog.text
        assert "agent-1" in caplog.text
        assert "no_tasks" in caplog.text

    def test_wake_exits_idle(self, adapter):
        adapter.sleep()
        assert adapter.is_idle is True

        result = adapter.wake()
        assert result["status"] == "active"
        assert adapter.is_idle is False

    def test_wake_logs_state(self, adapter, caplog):
        caplog.set_level(logging.INFO)
        adapter.sleep()
        adapter.wake()
        assert "AGENT_WAKE" in caplog.text

    def test_create_task_raises_when_idle(self, adapter, valid_admission):
        adapter.sleep()
        with pytest.raises(IdleEnforcementError) as exc:
            adapter.create_task("idle-task", "feature", admission=valid_admission)
        assert "idle mode" in str(exc.value)

    def test_create_task_succeeds_when_active(self, adapter, valid_admission):
        with patch.object(adapter._session, "post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.status_code = 201
            mock_resp.json.return_value = {"id": "new-issue", "status": "todo"}
            mock_post.return_value = mock_resp

            result = adapter.create_task("active-task", "feature", admission=valid_admission)
            assert result["status"] == "todo"

    def test_sleep_then_wake_then_create_succeeds(self, adapter, valid_admission):
        adapter.sleep()
        with pytest.raises(IdleEnforcementError):
            adapter.create_task("blocked", "feature", admission=valid_admission)

        adapter.wake()
        with patch.object(adapter._session, "post") as mock_post:
            mock_resp = MagicMock()
            mock_resp.status_code = 201
            mock_resp.json.return_value = {"id": "ok", "status": "todo"}
            mock_post.return_value = mock_resp

            result = adapter.create_task("after-wake", "feature", admission=valid_admission)
            assert result["status"] == "todo"

    def test_idle_property_fresh_is_false(self, adapter):
        assert adapter.is_idle is False

    def test_double_sleep_is_idempotent(self, adapter):
        adapter.sleep()
        assert adapter.is_idle is True
        adapter.sleep()
        assert adapter.is_idle is True  # still idle

    def test_default_idle_timeout(self):
        a = PaperclipAdapter(
            api_url="http://test:3100",
            api_key="test-key",
            agent_id="agent-1",
            company_id="comp-1",
            run_id="run-1",
        )
        assert a.idle_timeout_seconds == 30

    def test_custom_idle_timeout(self):
        a = PaperclipAdapter(
            api_url="http://test:3100",
            api_key="test-key",
            agent_id="agent-1",
            company_id="comp-1",
            run_id="run-1",
            idle_timeout_seconds=60,
        )
        assert a.idle_timeout_seconds == 60


class TestTaskAdmission:
    def test_is_complete_with_all_fields(self):
        a = TaskAdmission(
            consumer="devs",
            pain_point="manual work",
            expected_value="automation",
            validation_path="user test",
        )
        assert a.is_complete() is True

    def test_is_complete_missing_fields(self):
        a = TaskAdmission(
            consumer="",
            pain_point="manual work",
            expected_value="",
            validation_path="",
        )
        assert a.is_complete() is False

    def test_to_dict_returns_admission_fields(self):
        a = TaskAdmission(
            consumer="devs",
            pain_point="manual work",
            expected_value="automation",
            validation_path="user test",
        )
        d = a.to_dict()
        assert d == {
            "consumer": "devs",
            "pain_point": "manual work",
            "expected_value": "automation",
            "validation_path": "user test",
        }
