# pharm0-contracts (Python)

Shared schemas + Python types for the Pharm0 platform, lab, and web repos.

## Install

```bash
uv add pharm0-contracts
# or: pip install pharm0-contracts
```

## What's in this package

- **JSON Schemas** — `fidelity_report.schema.json`, `provenance_row.schema.json`
  bundled inside the wheel at `pharm0_contracts/schemas/`. Draft 2020-12.
- **OpenAPI-derived types** — regenerated from `../../openapi/*.yaml` on
  release (do not hand-edit files under `src/pharm0_contracts/generated/`).

## Usage

### Schemas

```python
from pharm0_contracts import (
    __version__,
    fidelity_report_schema,
    provenance_row_schema,
    load_schema,
)

# Direct module-level constants (eagerly loaded at import)
print(fidelity_report_schema["title"])
# → 'Pharm0 fidelity-report.json'

# Dynamic loading
schema = load_schema("provenance_row")

# Example: validate with jsonschema
import jsonschema
jsonschema.Draft202012Validator(fidelity_report_schema).validate(report_dict)
```

### OpenAPI types (future release)

```python
from pharm0_contracts.platform import AgentInvocation  # noqa  (post-generate)
```

## Versioning

See the root [CHANGELOG.md](../../CHANGELOG.md). Breaking changes require a
major version bump.
