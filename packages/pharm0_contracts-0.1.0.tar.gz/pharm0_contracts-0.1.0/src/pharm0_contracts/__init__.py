"""Pharm0 Contracts — Python bindings generated from OpenAPI + proto schemas.

Run `make generate` at repo root to regenerate types from the spec sources.
"""

from __future__ import annotations

import json
from importlib.resources import files
from typing import Any

__version__ = "0.1.0"

__all__ = [
    "__version__",
    "load_schema",
    "fidelity_report_schema",
    "provenance_row_schema",
]


def load_schema(name: str) -> dict[str, Any]:
    """Load a JSON Schema bundled with this package.

    Args:
        name: Schema identifier. Accepted values: 'fidelity_report',
            'provenance_row'. Extensions (.schema.json) are added if missing.

    Returns:
        Parsed JSON Schema as a dict (Draft 2020-12).

    Raises:
        FileNotFoundError: if `name` does not match a bundled schema.
    """
    fname = name if name.endswith(".schema.json") else f"{name}.schema.json"
    resource = files("pharm0_contracts").joinpath("schemas", fname)
    return json.loads(resource.read_text(encoding="utf-8"))


# Eagerly load the canonical schemas at import time so consumers can
# reference them as module constants when dynamic loading isn't needed.
fidelity_report_schema = load_schema("fidelity_report")
provenance_row_schema = load_schema("provenance_row")
