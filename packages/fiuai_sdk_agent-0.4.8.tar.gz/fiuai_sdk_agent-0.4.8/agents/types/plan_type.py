# -- coding: utf-8 --
# Project: fiuai-sdk-agent
# Created Date: 2025-01-30
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Any, Dict, Set, Tuple, Literal, Union
from datetime import datetime
from enum import StrEnum

from ...utils.errors import FiuaiAgentError
from .event_type import EventType
from ...agents.types.agent_type import ExpertType


# checkpoint 安全的 JSON 类型, 避免存入 Pydantic/自定义对象导致反序列化失败
JsonSafeData = Union[str, int, float, bool, None, Dict[str, Any], List[Any]]

PLAN_SCHEMA_VERSION = 1


class PlanStepStatus(StrEnum):
    """计划步骤状态"""
    TODO = "todo"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"
    RETRYING = "retrying"


class PlanStatus(StrEnum):
    """计划状态"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"
    NOT_STARTED = "not_started"


class PlanType(StrEnum):
    """计划类型"""
    SEQUENTIAL = "Sequential"
    PARALLEL = "Parallel"


class PlanStrategy(StrEnum):
    """计划生成策略"""
    SOP = "sop"
    LLM_DYNAMIC = "llm"


class StepMessage(BaseModel):
    """步骤消息"""
    event_type: EventType = Field(description="事件类型")
    data: JsonSafeData = Field(description="事件数据, 必须是 JSON 安全类型")


class PlanStep(BaseModel):
    """计划步骤"""
    step_index: int = Field(description="步骤序号,从0开始", default=0)
    step_id: str = Field(description="步骤id", default="")
    name: str = Field(description="步骤名称代号")
    description: str = Field(description="步骤描述, 用于前端展示")
    status: PlanStepStatus = Field(description="步骤状态", default=PlanStepStatus.TODO)
    start_time: Optional[datetime] = Field(description="步骤开始时间", default=None)
    end_time: Optional[datetime] = Field(description="步骤结束时间", default=None)
    expert_type: Optional[ExpertType] = Field(
        description="执行该步骤的 Expert 类型",
        default=None
    )

    result: Optional[Dict[str, Any]] = Field(
        default=None,
        description="步骤执行结果, replan 时需要回顾",
    )
    message: Optional[str] = Field(
        default=None,
        description="Expert 对本步执行结果的自然语言概括, 供下游步骤和 replan 参考",
    )
    error: Optional[str] = Field(
        default=None,
        description="错误信息",
    )
    replan_checkpoint: bool = Field(
        default=False,
        description="此步骤完成后是否触发 replan 检查",
    )

    # 跨步骤数据依赖声明 (Plan 依赖解析器使用)
    required_context: List[str] = Field(
        default_factory=list,
        description="执行前必须存在的 context key 列表 (由前置步骤 provides_context 提供)",
    )
    provides_context: List[str] = Field(
        default_factory=list,
        description="执行后产出的 context key 列表 (供后续步骤 required_context 引用)",
    )

    # TODO: 步骤依赖 — 当前仅预留字段, 执行引擎尚未支持并行调度
    depends_on: List[str] = Field(
        default_factory=list,
        description="前置依赖步骤的 name 列表, 空列表表示无依赖 (预留, 当前未启用)",
    )

    retry_count: int = Field(
        default=0,
        description="已重试次数",
    )
    max_retries: int = Field(
        default=0,
        description="最大重试次数, 0 表示不重试",
    )

    # 运行时数据, model_dump() 时排除, 不进入 checkpoint
    messages: List[StepMessage] = Field(
        description="步骤消息,用作agent上下文, 前端通过chunk和其他类型接收",
        default=[],
        exclude=True,
    )


class PlanStateMachine:
    """计划状态机，负责管理状态转换规则和校验"""

    PLAN_TRANSITIONS: Dict[PlanStatus, Set[PlanStatus]] = {
        PlanStatus.NOT_STARTED: {PlanStatus.PENDING, PlanStatus.RUNNING},
        PlanStatus.PENDING: {PlanStatus.RUNNING, PlanStatus.FAILED, PlanStatus.CANCELLED},
        PlanStatus.RUNNING: {PlanStatus.COMPLETED, PlanStatus.FAILED, PlanStatus.CANCELLED},
        PlanStatus.COMPLETED: set(),
        PlanStatus.FAILED: set(),
        PlanStatus.CANCELLED: set(),
    }

    STEP_TRANSITIONS: Dict[PlanStepStatus, Set[PlanStepStatus]] = {
        PlanStepStatus.TODO: {PlanStepStatus.RUNNING, PlanStepStatus.SKIPPED},
        # RUNNING -> SKIPPED: 用户取消等场景下中止当前步骤 (与 step_execute cancel 路径一致)
        PlanStepStatus.RUNNING: {
            PlanStepStatus.COMPLETED,
            PlanStepStatus.FAILED,
            PlanStepStatus.SKIPPED,
        },
        PlanStepStatus.COMPLETED: set(),
        PlanStepStatus.FAILED: {PlanStepStatus.RETRYING, PlanStepStatus.SKIPPED},
        PlanStepStatus.SKIPPED: set(),
        PlanStepStatus.RETRYING: {PlanStepStatus.RUNNING},
    }

    @classmethod
    def can_transition_plan(
        cls,
        from_status: PlanStatus,
        to_status: PlanStatus
    ) -> bool:
        valid_transitions = cls.PLAN_TRANSITIONS.get(from_status, set())
        return to_status in valid_transitions

    @classmethod
    def can_transition_step(
        cls,
        from_status: PlanStepStatus,
        to_status: PlanStepStatus
    ) -> bool:
        valid_transitions = cls.STEP_TRANSITIONS.get(from_status, set())
        return to_status in valid_transitions

    @classmethod
    def get_valid_plan_transitions(cls, current_status: PlanStatus) -> Set[PlanStatus]:
        return cls.PLAN_TRANSITIONS.get(current_status, set())

    @classmethod
    def get_valid_step_transitions(cls, current_status: PlanStepStatus) -> Set[PlanStepStatus]:
        return cls.STEP_TRANSITIONS.get(current_status, set())

    @classmethod
    def validate_plan_transition(
        cls,
        from_status: PlanStatus,
        to_status: PlanStatus
    ) -> Tuple[bool, Optional[str]]:
        if from_status == to_status:
            return True, None

        if cls.can_transition_plan(from_status, to_status):
            return True, None

        valid_transitions = cls.get_valid_plan_transitions(from_status)
        error_msg = (
            f"Invalid plan state transition: {from_status.value} -> {to_status.value}. "
            f"Valid transitions from {from_status.value} are: "
            f"{[s.value for s in valid_transitions]}"
        )
        return False, error_msg

    @classmethod
    def validate_step_transition(
        cls,
        from_status: PlanStepStatus,
        to_status: PlanStepStatus
    ) -> Tuple[bool, Optional[str]]:
        if from_status == to_status:
            return True, None

        if cls.can_transition_step(from_status, to_status):
            return True, None

        valid_transitions = cls.get_valid_step_transitions(from_status)
        error_msg = (
            f"Invalid step state transition: {from_status.value} -> {to_status.value}. "
            f"Valid transitions from {from_status.value} are: "
            f"{[s.value for s in valid_transitions]}"
        )
        return False, error_msg

    @classmethod
    def is_plan_terminal_state(cls, status: PlanStatus) -> bool:
        return status in {PlanStatus.COMPLETED, PlanStatus.FAILED, PlanStatus.CANCELLED}

    @classmethod
    def is_step_terminal_state(cls, status: PlanStepStatus) -> bool:
        return status in {
            PlanStepStatus.COMPLETED,
            PlanStepStatus.FAILED,
            PlanStepStatus.SKIPPED
        }


class BasePlan(BaseModel):
    """计划基类"""
    model_config = ConfigDict(extra="ignore")

    schema_version: int = Field(default=PLAN_SCHEMA_VERSION, description="Schema 版本号")
    title: str = Field(description="计划标题")
    plan_id: str = Field(description="计划id")
    goal: str = Field(default="", description="原始任务目标, replan 时需要回顾")
    plan_type: PlanType = Field(description="计划类型", default=PlanType.SEQUENTIAL)
    strategy: PlanStrategy = Field(default=PlanStrategy.SOP, description="计划生成策略")
    failed_on_step_fail: bool = Field(description="是否某个步骤失败就判定任务失败", default=False)
    status: PlanStatus = Field(description="计划状态", default=PlanStatus.NOT_STARTED)
    steps: List[PlanStep] = Field(description="计划步骤列表", default=[])
    start_time: datetime = Field(description="计划开始时间", default_factory=datetime.now)
    end_time: Optional[datetime] = Field(description="计划结束时间", default=None)
    current_step_index: int = Field(description="当前步骤序号,从0开始", default=0)
    current_step_id: str = Field(description="当前步骤id", default="")
    summary: str = Field(description="计划汇总消息, 用于前端展示", default="")
    metadata: Dict[str, Any] = Field(default_factory=dict, description="扩展元数据")
    summary_prompt: Optional[str] = Field(
        default=None,
        description="任务总结 system prompt 覆盖, None 时用默认通用 prompt",
    )

    # runtime
    current_step_names: List[str] = Field(description="当前步骤名称列表", default=[])
    total_step_count: int = Field(description="总步骤数", default=0)
    passed_step_count: int = Field(description="已运行步骤数", default=0)

    def _validate(self) -> bool:
        """验证计划数据 (允许同名步骤, 用于 rewind 后多轮同名步骤并存)"""
        return True

    def _lookup_step_by_name(self, step_name: str) -> Optional[PlanStep]:
        """根据步骤名称获取步骤 (多轮同名时取最后一次匹配, 与 rewind 后读最新结果一致)"""
        found: Optional[PlanStep] = None
        for step in self.steps:
            if step.name == step_name:
                found = step
        return found

    def _lookup_step_by_id(self, step_id: str) -> Optional[PlanStep]:
        """根据步骤ID获取步骤"""
        for step in self.steps:
            if step.step_id == step_id:
                return step
        return None

    def _lookup_current_step(self) -> PlanStep:
        """获取当前步骤"""
        if self.current_step_index >= len(self.steps):
            raise IndexError(f"Current step index {self.current_step_index} out of range")
        return self.steps[self.current_step_index]

    def get_current_step_status(self) -> PlanStepStatus:
        """获取当前步骤状态"""
        if self.current_step_index >= len(self.steps):
            return PlanStepStatus.TODO
        return self.steps[self.current_step_index].status

    def add_step(
        self,
        name: str,
        description: str,
        step_id: str,
        expert_type: Optional[ExpertType] = None,
        replan_checkpoint: bool = False,
        depends_on: Optional[List[str]] = None,
    ) -> None:
        """在末尾追加步骤(支持动态添加)"""
        last_step_id = len(self.steps)
        step = PlanStep(
            name=name,
            description=description,
            status=PlanStepStatus.TODO,
            step_id=step_id,
            step_index=last_step_id,
            start_time=None,
            end_time=None,
            expert_type=expert_type,
            replan_checkpoint=replan_checkpoint,
            depends_on=depends_on or [],
        )
        self.steps.append(step)
        self.total_step_count = len(self.steps)

    def insert_step_at(
        self,
        index: int,
        name: str,
        description: str,
        step_id: str,
        expert_type: Optional[ExpertType] = None,
        replan_checkpoint: bool = False,
        depends_on: Optional[List[str]] = None,
    ) -> None:
        """在指定位置插入步骤, 后续步骤自动重新索引"""
        index = max(0, min(index, len(self.steps)))
        step = PlanStep(
            name=name,
            description=description,
            status=PlanStepStatus.TODO,
            step_id=step_id,
            step_index=index,
            start_time=None,
            end_time=None,
            expert_type=expert_type,
            replan_checkpoint=replan_checkpoint,
            depends_on=depends_on or [],
        )
        self.steps.insert(index, step)
        for i in range(index + 1, len(self.steps)):
            self.steps[i].step_index = i
        self.total_step_count = len(self.steps)

    def transition_plan_status(self, to_status: PlanStatus) -> None:
        """切换计划状态(使用状态机校验)"""
        is_valid, error_msg = PlanStateMachine.validate_plan_transition(
            from_status=self.status,
            to_status=to_status
        )
        if not is_valid:
            raise FiuaiAgentError(f"Invalid plan state transition: {error_msg}")

        self.status = to_status
        if to_status in {PlanStatus.COMPLETED, PlanStatus.FAILED, PlanStatus.CANCELLED}:
            self.end_time = datetime.now()

    def transition_step_status(self, step_index: int, to_status: PlanStepStatus) -> None:
        """切换步骤状态(使用状态机校验)"""
        if step_index >= len(self.steps):
            raise IndexError(f"Step index {step_index} out of range")

        step = self.steps[step_index]
        is_valid, error_msg = PlanStateMachine.validate_step_transition(
            from_status=step.status,
            to_status=to_status
        )
        if not is_valid:
            raise FiuaiAgentError(f"Invalid step state transition: {error_msg}")

        step.status = to_status
        if to_status == PlanStepStatus.RUNNING and step.start_time is None:
            step.start_time = datetime.now()
        elif to_status in {PlanStepStatus.COMPLETED, PlanStepStatus.FAILED, PlanStepStatus.SKIPPED}:
            step.end_time = datetime.now()

        self.steps[step_index] = step

    def start(self) -> None:
        """启动计划, 初始化状态, 并启动第一个步骤"""
        if len(self.steps) == 0:
            raise ValueError("plan steps is empty")

        self.transition_plan_status(PlanStatus.RUNNING)

        self.current_step_index = 0
        self.current_step_names = [self.steps[self.current_step_index].name]
        self.current_step_id = self.steps[self.current_step_index].step_id
        self.start_time = datetime.now()
        self.total_step_count = len(self.steps)

        self.transition_step_status(0, PlanStepStatus.RUNNING)

    def set_plan_to_failed(self, message: str = "") -> None:
        """设置计划为失败, 同时将所有非终态步骤标记为终态 (RUNNING→FAILED, TODO→SKIPPED)"""
        for i, step in enumerate(self.steps):
            if step.status == PlanStepStatus.RUNNING:
                self.transition_step_status(i, PlanStepStatus.FAILED)
            elif step.status == PlanStepStatus.TODO:
                self.transition_step_status(i, PlanStepStatus.SKIPPED)
        self.transition_plan_status(PlanStatus.FAILED)
        self.summary = message

    def set_plan_to_completed(self, message: str = "") -> None:
        """设置计划为完成"""
        self.transition_plan_status(PlanStatus.COMPLETED)
        self.summary = message

    def set_plan_to_cancelled(self, message: str = "") -> None:
        """设置计划为取消"""
        self.transition_plan_status(PlanStatus.CANCELLED)
        self.summary = message

    def _step_validate(self) -> Optional[str]:
        """验证step数据, 返回错误信息"""
        if self.status == PlanStatus.NOT_STARTED:
            return "plan is not started"
        return None

    def _to_safe_data(self, data: Any) -> JsonSafeData:
        """将任意数据转为 JSON 安全类型, 防止 checkpoint 反序列化失败"""
        if isinstance(data, BaseModel):
            return data.model_dump()
        if isinstance(data, (str, int, float, bool, type(None))):
            return data
        if isinstance(data, dict):
            return data
        if isinstance(data, list):
            return data
        return str(data)

    def add_step_message(self, data: Any, event_type: EventType = EventType.CHUNK) -> None:
        """添加当前步骤的消息, 作为上下文"""
        err = self._step_validate()
        if err:
            raise FiuaiAgentError(f"step {self.current_step_index} is not valid when add message: {err}")

        safe_data = self._to_safe_data(data)
        message = StepMessage(event_type=event_type, data=safe_data)
        if self.current_step_index < len(self.steps):
            self.steps[self.current_step_index].messages.append(message)

    def close_current_step(
        self,
        status: Literal[PlanStepStatus.COMPLETED, PlanStepStatus.FAILED, PlanStepStatus.SKIPPED] = PlanStepStatus.COMPLETED,
    ) -> None:
        """关闭当前步骤(纯数据操作, 使用状态机校验)"""
        err = self._step_validate()
        if err:
            raise FiuaiAgentError(f"step {self.current_step_index} is not valid when close step: {err}")

        self.transition_step_status(self.current_step_index, status)
        self.passed_step_count += 1

    def start_next_step(self) -> bool:
        """启动下一个步骤 (设为 RUNNING), 返回是否成功(False 表示没有下一步)"""
        next_step_index = self.current_step_index + 1
        if next_step_index >= len(self.steps):
            return False

        self.transition_step_status(next_step_index, PlanStepStatus.RUNNING)

        next_step = self.steps[next_step_index]
        self.current_step_index = next_step_index
        self.current_step_names = [next_step.name]
        self.current_step_id = next_step.step_id

        return True

    def advance_to_next_step(self) -> bool:
        """前进到下一个步骤, 但不启动 (保持 TODO 状态), 用于 step 失败后让 replan 决策"""
        next_step_index = self.current_step_index + 1
        if next_step_index >= len(self.steps):
            return False

        next_step = self.steps[next_step_index]
        self.current_step_index = next_step_index
        self.current_step_names = [next_step.name]
        self.current_step_id = next_step.step_id

        return True

    def is_all_steps_completed(self) -> bool:
        """检查是否所有步骤都已完成(含动态添加的步骤)"""
        if len(self.steps) == 0:
            return True

        for step in self.steps:
            if not PlanStateMachine.is_step_terminal_state(step.status):
                return False

        return True
