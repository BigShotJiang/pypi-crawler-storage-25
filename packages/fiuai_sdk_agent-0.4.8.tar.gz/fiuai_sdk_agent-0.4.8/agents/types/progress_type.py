# -- coding: utf-8 --
# Project: fiuai-sdk-agent
# Created Date: 2026-03-13
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
Progress 事件类型 — 瞬态活动指示 (结构化状态, 非流式文本)

前端按 progress_type 渲染图标 + 短文案 + 可选进度条; 流式文本用 EventType.CHUNK + ChunkPurpose.
"""

from enum import StrEnum
from typing import Optional

from pydantic import BaseModel, Field


class ProgressType(StrEnum):
    """活动类型 (前端可按类型渲染不同图标)"""
    ACTION = "action"       # 通用操作
    QUERY = "query"         # 数据查询
    SEARCH = "search"       # 搜索/检索
    REASON = "reason"       # AI 推理
    VALIDATE = "validate"   # 校验
    FETCH = "fetch"         # 获取外部数据
    BUILD = "build"         # 构建/生成
    RUN = "run"             # 执行/提交


class ProgressData(BaseModel):
    """PROGRESS 事件 payload"""
    progress_type: str = Field(description="ProgressType 枚举值")
    message: str = Field(description="可读描述")
    current: Optional[int] = Field(default=None, description="当前进度 (可选)")
    total: Optional[int] = Field(default=None, description="总数 (可选)")
    detail: Optional[str] = Field(default=None, description="补充细节 (可选, 如商品名)")
    progress_id: Optional[str] = Field(
        default=None,
        description="关联标识, 相同 id 表示更新同一条进度 (前端替换/追加); 不传则独立展示",
    )
    done: bool = Field(
        default=False,
        description="True 表示该 progress_id 对应进度已结束, 前端可收起/移除",
    )
