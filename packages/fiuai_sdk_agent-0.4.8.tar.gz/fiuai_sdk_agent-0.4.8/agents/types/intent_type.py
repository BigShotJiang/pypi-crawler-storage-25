# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2025-12-01
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
意图类型与用户意图模型

IntentType: 用户意图大类, 决定 AgentMode (QUERY / TASK)
UserIntent: 结构化意图, 包含分类结果和匹配的 Capability
"""

from enum import StrEnum
from typing import Any, Dict, Optional

from pydantic import BaseModel, Field


class IntentType(StrEnum):
    """
    用户意图大类 — 决定执行模式

    QUERY: 问数/查询/分析 → AgentMode.QUERY (含旧 DATA / IDP)
    TASK: 业务操作 → AgentMode.TASK
    CHAT: 闲聊/通用问答 → AgentMode.QUERY
    DEMO: 演示 (仅测试用)
    """

    QUERY = "query"
    TASK = "task"
    CHAT = "chat"
    DEMO = "demo"

    # === 兼容旧值 (渐进迁移, 避免存量数据/日志/配置报错) ===
    DATA = "data"
    IDP = "idp"


class UserIntent(BaseModel):
    """
    用户意图模型

    Attributes:
        intent_type: 意图大类
        capability: 匹配的 Capability name (如 "data_query", "tax_declaration")
        user_input: 用户原始输入
        description: 意图描述 / 判断原因
    """

    intent_type: IntentType = Field(..., description="意图类型")
    capability: Optional[str] = Field(
        default=None,
        description="匹配的 Capability name, None 表示未匹配到具体能力",
    )
    user_input: str = Field(..., description="用户原始输入")
    description: str = Field(
        ..., description="意图描述, 和判断原因, 类似简单的深度思考"
    )
    params: Optional[Dict[str, Any]] = Field(
        default=None,
        description="调用方传入的上下文 (如 form_data), 供 Plan 创建时按模式分支",
    )
