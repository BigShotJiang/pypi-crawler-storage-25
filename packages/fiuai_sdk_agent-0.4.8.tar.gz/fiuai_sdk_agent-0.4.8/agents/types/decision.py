# -- coding: utf-8 --
# Project: fiuai-sdk-agent
# Created Date: 2026-02-04
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2026 FiuAI

"""
Decision 类型定义

核心语义: Decision = Pending Decision
系统运行到分叉点, 需要外部(用户/其他系统)做出选择, 系统才能继续

系统视角 vs 工程视角:
- 系统视角: Decision 是一个"待决策"状态
- 工程视角: LangGraph interrupt, Graph 暂停等待
"""

from enum import StrEnum
from typing import Optional, Dict, List, Any
from datetime import datetime
from pydantic import BaseModel, Field


class DecisionType(StrEnum):
    """
    决策类型
    
    不同类型决定前端显示不同的 UI
    """
    # 确认/取消(二选一)
    CONFIRM = "confirm"
    # 多选一
    SELECT = "select"
    # 需要输入数据
    INPUT = "input"
    # 审批流(可能有多级)
    APPROVAL = "approval"
    # 等待外部事件(如支付回调)
    WAIT = "wait"


class DecisionOption(BaseModel):
    """
    决策选项
    
    每个选项代表用户可以做出的一个选择
    """
    option_id: str = Field(description="选项 ID")
    label: str = Field(description="显示标签")
    description: Optional[str] = Field(default=None, description="选项描述")
    action: str = Field(description="决策后的动作标识")
    enabled: bool = Field(default=True, description="是否可用")
    is_default: bool = Field(default=False, description="是否默认选项")
    requires_input: bool = Field(
        default=False,
        description="选此项时前端需展示文本输入框, 用户输入通过 DecisionResult.input_data 回传",
    )
    input_placeholder: Optional[str] = Field(
        default=None,
        description="输入框 placeholder (requires_input=True 时生效)",
    )


class Decision(BaseModel):
    """
    待决策
    
    核心语义: 系统运行到分叉点, 需要外部做出选择
    
    工程映射:
    - 发出 Decision -> EventPublisher.interrupt(decision)
    - Graph 暂停 -> LangGraph interrupt()
    - 用户响应 -> DecisionResult
    - 继续执行 -> Resume
    """
    decision_id: str = Field(description="决策 ID")
    decision_type: DecisionType = Field(description="决策类型")
    title: str = Field(description="标题")
    description: str = Field(description="描述")
    options: List[DecisionOption] = Field(description="选项列表")
    
    # 关联数据(如需要用户确认/编辑的表单数据)
    payload: Optional[Dict[str, Any]] = Field(default=None, description="关联数据")
    payload_editable: bool = Field(default=False, description="payload 是否可编辑")
    
    # 超时策略
    timeout_seconds: Optional[int] = Field(default=None, description="超时时间(秒)")
    timeout_action: Optional[str] = Field(default=None, description="超时后自动选择的选项")
    
    # 来源追溯
    source_node: Optional[str] = Field(default=None, description="发出决策的节点")
    source_step_id: Optional[str] = Field(default=None, description="发出决策的步骤 ID")

    # Artifact 关联与确认风格
    artifact_ref: Optional[str] = Field(
        default=None,
        description="关联的 Artifact.artifact_id, 前端据此将 Decision UI 渲染在 Artifact 面板内",
    )
    confirm_style: str = Field(
        default="normal",
        description="确认风格: normal=普通点击, cautious=二次确认(大额/不可逆场景)",
    )

    # 决策附言 (notes): 允许用户在做决策时附带文字补充说明
    notes_enabled: bool = Field(
        default=False,
        description="是否在 Decision UI 中展示「补充说明」输入框",
    )
    notes_placeholder: Optional[str] = Field(
        default=None,
        description="补充说明输入框的 placeholder 文案",
    )
    notes_max_length: Optional[int] = Field(
        default=None,
        description="补充说明的最大字符数, 供前端校验",
    )


class DecisionResult(BaseModel):
    """
    决策结果
    
    用户/系统做出决策后的响应
    """
    decision_id: str = Field(description="决策 ID")
    selected_option: str = Field(description="选中的选项 ID")
    input_data: Optional[Dict[str, Any]] = Field(default=None, description="用户输入的数据")
    notes: Optional[str] = Field(
        default=None,
        description="用户附带的补充说明 (与 selected_option 并列, notes_enabled 时前端可提交)",
    )
    artifact_id: Optional[str] = Field(
        default=None,
        description=(
            "前端可选回传: 上一轮 Decision 关联的 Artifact.artifact_id "
            "(对应 Decision.artifact_ref). 后端在下一次发出 Decision 时, "
            "可据此复用同一个 artifact_ref, 让前端复用同一个 Artifact + Decision 渲染组件"
        ),
    )
    decided_by: str = Field(description="决策者: user | system | timeout | external")
    decided_at: datetime = Field(default_factory=datetime.now, description="决策时间")


# ============================================================================
# 便捷工厂函数
# ============================================================================

def create_confirm_decision(
    decision_id: str,
    title: str,
    description: str,
    payload: Optional[Dict[str, Any]] = None,
    payload_editable: bool = False,
    confirm_label: str = "确认",
    cancel_label: str = "取消",
    artifact_ref: Optional[str] = None,
    confirm_style: str = "normal",
    notes_enabled: bool = False,
    notes_placeholder: Optional[str] = None,
    notes_max_length: Optional[int] = None,
) -> Decision:
    """
    创建确认/取消类型的决策

    Args:
        decision_id: 决策 ID
        title: 标题
        description: 描述
        payload: 关联数据
        payload_editable: payload 是否可编辑
        confirm_label: 确认按钮文字
        cancel_label: 取消按钮文字
        artifact_ref: 关联的 Artifact.artifact_id, 前端将按钮渲染在对应 Artifact 面板内
        confirm_style: normal=普通点击, cautious=二次确认
        notes_enabled: 是否展示补充说明输入框
        notes_placeholder: 补充说明 placeholder
        notes_max_length: 补充说明最大字符数
    """
    return Decision(
        decision_id=decision_id,
        decision_type=DecisionType.CONFIRM,
        title=title,
        description=description,
        options=[
            DecisionOption(
                option_id="confirm",
                label=confirm_label,
                action="proceed",
                is_default=True,
            ),
            DecisionOption(
                option_id="cancel",
                label=cancel_label,
                action="cancel",
            ),
        ],
        payload=payload,
        payload_editable=payload_editable,
        artifact_ref=artifact_ref,
        confirm_style=confirm_style,
        notes_enabled=notes_enabled,
        notes_placeholder=notes_placeholder,
        notes_max_length=notes_max_length,
    )


def create_select_decision(
    decision_id: str,
    title: str,
    description: str,
    options: List[Dict[str, str]],
    payload: Optional[Dict[str, Any]] = None,
    artifact_ref: Optional[str] = None,
    confirm_style: str = "normal",
    notes_enabled: bool = False,
    notes_placeholder: Optional[str] = None,
    notes_max_length: Optional[int] = None,
    allow_other: bool = False,
    other_label: str = "其他",
    other_placeholder: str = "请输入...",
) -> Decision:
    """
    创建多选一类型的决策

    Args:
        decision_id: 决策 ID
        title: 标题
        description: 描述
        options: 选项列表, 每个选项是 {"id": "...", "label": "...", "action": "...", "requires_input": bool, "input_placeholder": str}
        payload: 关联数据
        artifact_ref: 关联的 Artifact.artifact_id
        confirm_style: normal=普通点击, cautious=二次确认
        notes_enabled: 是否展示补充说明输入框
        notes_placeholder: 补充说明 placeholder
        notes_max_length: 补充说明最大字符数
        allow_other: 是否允许"其他"选项 (会追加一个 requires_input=True 的选项)
        other_label: "其他"选项的显示标签
        other_placeholder: "其他"选项的输入框 placeholder
    """
    decision_options = [
        DecisionOption(
            option_id=opt.get("id", opt.get("label", "")),
            label=opt.get("label", ""),
            action=opt.get("action", opt.get("id", "")),
            description=opt.get("description"),
            requires_input=opt.get("requires_input", False),
            input_placeholder=opt.get("input_placeholder"),
        )
        for opt in options
    ]
    
    if allow_other:
        decision_options.append(
            DecisionOption(
                option_id="__other__",
                label=other_label,
                action="other",
                requires_input=True,
                input_placeholder=other_placeholder,
            )
        )
    
    return Decision(
        decision_id=decision_id,
        decision_type=DecisionType.SELECT,
        title=title,
        description=description,
        options=decision_options,
        payload=payload,
        artifact_ref=artifact_ref,
        confirm_style=confirm_style,
        notes_enabled=notes_enabled,
        notes_placeholder=notes_placeholder,
        notes_max_length=notes_max_length,
    )


def create_input_decision(
    decision_id: str,
    title: str,
    description: str,
    payload: Optional[Dict[str, Any]] = None,
    submit_label: str = "提交",
    cancel_label: str = "取消",
    artifact_ref: Optional[str] = None,
    confirm_style: str = "normal",
    notes_enabled: bool = False,
    notes_placeholder: Optional[str] = None,
    notes_max_length: Optional[int] = None,
) -> Decision:
    """
    创建需要输入数据类型的决策

    Args:
        decision_id: 决策 ID
        title: 标题
        description: 描述
        payload: 表单初始数据/schema
        submit_label: 提交按钮文字
        cancel_label: 取消按钮文字
        artifact_ref: 关联的 Artifact.artifact_id
        confirm_style: normal=普通点击, cautious=二次确认
        notes_enabled: 是否展示补充说明输入框
        notes_placeholder: 补充说明 placeholder
        notes_max_length: 补充说明最大字符数
    """
    return Decision(
        decision_id=decision_id,
        decision_type=DecisionType.INPUT,
        title=title,
        description=description,
        options=[
            DecisionOption(
                option_id="submit",
                label=submit_label,
                action="submit",
                is_default=True,
            ),
            DecisionOption(
                option_id="cancel",
                label=cancel_label,
                action="cancel",
            ),
        ],
        payload=payload,
        payload_editable=True,
        artifact_ref=artifact_ref,
        confirm_style=confirm_style,
        notes_enabled=notes_enabled,
        notes_placeholder=notes_placeholder,
        notes_max_length=notes_max_length,
    )
