# -- coding: utf-8 --
# Project: fiuai-sdk-agent
# Created Date: 2025-01-30
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
Event 类型定义

设计原则:
- EventType 表示"行为语义"(前端怎么处理), 保持稳定(枚举谨慎扩容)
- EventContext 表示"路由目标"(消息显示在哪里)
- data 是类型化对象, 不是字符串
"""

from enum import StrEnum
from typing import Any, Optional, Dict
from datetime import datetime
from pydantic import BaseModel, Field, field_validator

from fiuai_sdk_python.utils.ids import gen_id


# Redis Stream 配置
TASK_EVENT_STREAM_KEY_PREFIX = "task:events"


class EventType(StrEnum):
    """
    事件类型枚举
    
    设计原则: EventType 表示前端的"处理行为", 而非"内容类型"
    - 内容类型通过 artifact_type 扩展
    - 决策类型通过 decision_type 扩展
    """
    # 流式文本(前端增量渲染)
    CHUNK = "chunk"
    # 计划更新(前端更新 Plan 组件)
    PLAN = "plan"
    # 待决策(前端显示决策 UI, 系统暂停等待)
    INTERRUPT = "interrupt"
    # 任务终态(前端处理结束逻辑)
    TASK = "task"
    # SSE 流结束(前端断开连接, 传输层语义)
    STREAM_END = "stream_end"
    # 内容展示(前端渲染各类内容)
    ARTIFACT = "artifact"
    # 瞬态进度状态(前端渲染活动指示器, 不记录对话历史)
    PROGRESS = "progress"
    # 任务建议卡片(前端渲染可操作按钮, 点击弹 modal 提交后跳转 Task 页面)
    TASK_CARD = "task_card"
    # 导航跳转(语义 route_id + route_params; 前端解析为 GET 打开页面)
    REDIRECT = "redirect"
    # 心跳(传输层, 不进入业务逻辑)
    HEARTBEAT = "heartbeat"
    # 用户输入 (持久化进事件流, SSE 不下发, history 完整返回; 用于审计与回放)
    USER_INPUT = "user_input"


class EventContext(BaseModel):
    """
    事件路由上下文
    
    决定消息显示在哪里:
    - 有 plan_id + step_id -> 显示在 Plan 组件的特定 Step
    - 有 plan_id -> 显示在 Plan 组件
    - 无 context -> 显示在主窗口
    """
    plan_id: Optional[str] = Field(default=None, description="关联的计划 ID")
    step_id: Optional[str] = Field(default=None, description="关联的步骤 ID")
    step_index: Optional[int] = Field(default=None, description="步骤索引")
    step_status: Optional[str] = Field(default=None, description="步骤状态")


class Event(BaseModel):
    """
    事件基类
    
    结构简化:
    - data 是类型化对象, 不是字符串
    - context 统一承载路由信息
    - 删除 metadata, tags, ttl 等冗余字段
    """
    id: str = Field(default_factory=gen_id, description="事件 ID")
    type: EventType = Field(description="事件类型")
    timestamp: datetime = Field(default_factory=datetime.now, description="时间戳")
    data: Any = Field(description="事件数据(类型化)")
    context: Optional[EventContext] = Field(default=None, description="路由上下文")


# ============================================================================
# 各事件类型的数据结构
# ============================================================================

class ChunkPurpose(StrEnum):
    """CHUNK 文本的意图"""
    REPLY = "reply"       # 正式回复 (默认; 主窗口终态内容)
    THINKING = "thinking"  # 思考/推理过程 (可折叠; Step 内过程文本)
    WARNING = "warning"   # 警告文本 (可折叠; Step 内警告文本)
    SUMMARY = "summary"   # 步骤总结 (Step 内结论文本)


class ChunkData(BaseModel):
    """
    CHUNK 事件数据

    流式文本块, 前端增量渲染; purpose 决定渲染位置与样式.
    animate=True 时前端可做 typewriter 等渐进呈现, 由展示层控制节奏.
    """
    content: str = Field(description="文本内容")
    done: bool = Field(default=False, description="True 表示这段文本结束")
    purpose: str = Field(
        default=ChunkPurpose.REPLY,
        description="文本意图: reply/thinking/warning/summary",
    )
    animate: bool = Field(
        default=False,
        description="True 时建议前端做渐进呈现 (如 typewriter), 由前端控制节奏",
    )


class TaskStatus(StrEnum):
    """任务状态"""
    SUCCESS = "success"
    FAILED = "failed"
    CANCELLED = "cancelled"
    WARNING = "warning"


class TaskData(BaseModel):
    """
    TASK 事件数据
    
    任务终态, 前端处理结束逻辑 (业务层语义)
    """
    status: TaskStatus = Field(description="任务状态")
    message: str = Field(default="", description="状态消息")


class StreamEndStatus(StrEnum):
    """SSE 流结束状态"""
    SUCCESS = "success"
    ERROR = "error"


class StreamEndData(BaseModel):
    """
    STREAM_END 事件数据
    
    传输层语义: SSE 流结束, 前端断开连接
    """
    status: StreamEndStatus = Field(description="流结束状态")
    message: str = Field(default="", description="结束消息")


class RedirectTrigger(StrEnum):
    """REDIRECT 触发方式: 用户点击按钮跳转, 或前端自动跳转 (如倒计时)"""

    BUTTON = "button"
    AUTO = "auto"


class RedirectData(BaseModel):
    """
    REDIRECT 事件数据

    仅使用语义路由: 前端根据 route_id 在白名单内解析, 用 route_params 拼路径或 query 后导航.
    表达 GET 打开页面意图, 不承担 POST 提交语义. 参数须 JSON 安全 (str/int/bool/null/list/dict).
    """

    route_id: str = Field(
        description="语义路由 ID (点分), 与前端注册表一致, 如 doc_center.invoice.issue",
    )
    route_params: Dict[str, Any] = Field(
        default_factory=dict,
        description="结构化参数, 由该 route_id 的契约定义",
    )
    description: str = Field(description="跳转说明文案 (用户可见)")
    trigger: RedirectTrigger = Field(
        default=RedirectTrigger.BUTTON,
        description="button=展示按钮后跳转; auto=自动跳转 (可配合 delay)",
    )
    label: str = Field(
        default="",
        description="trigger=button 时按钮文案; auto 时可空",
    )
    delay: int = Field(
        default=0,
        ge=0,
        description="trigger=auto 时建议延迟秒数, 0 表示立即; button 模式忽略",
    )

    @field_validator("route_id", mode="before")
    @classmethod
    def _normalize_route_id(cls, v: Any) -> str:
        if v is None:
            raise ValueError("route_id is required")
        s = str(v).strip()
        if not s:
            raise ValueError("route_id must be non-empty")
        return s


class UserInputData(BaseModel):
    """
    USER_INPUT 事件数据

    用户输入快照, 写入事件流仅用于回放/审计;
    SSE 端按 role==user 过滤不下发, history 接口完整返回。
    """
    content: str = Field(description="用户输入文本")
    source: str = Field(
        default="submit",
        description="来源: submit (新任务/对话) | resume (HITL 应答) | 其他扩展",
    )


class TaskCardData(BaseModel):
    """
    TASK_CARD 事件数据
    
    任务建议卡片, 前端渲染为可操作按钮 (我猜你想... 点击执行)
    """
    task_name: str = Field(description="任务名称 (POST /task 的 task_name)")
    capability: str = Field(description="Capability 标识")
    title: str = Field(description="卡片标题, 与 Capability.display_name 对齐 (如 开票规划)")
    description: str = Field(
        description="与 title 同义的短文案, 前端可自行加前缀展示 (如 检测到您想进行: + description)",
    )
    suggested_context: Dict[str, Any] = Field(
        default_factory=dict,
        description="从对话中提取的上下文 (前端可用于预填 form)",
    )


# ============================================================================
# 兼容性: 旧版 EventData 格式(用于 Redis Stream 序列化)
# ============================================================================

class EventData(BaseModel):
    """
    事件序列化格式(用于 Redis Stream)
    
    保持与旧版兼容的字段结构, 但内部使用新的类型系统
    """
    event_id: str = Field(description="事件 ID")
    timestamp: datetime = Field(default_factory=datetime.now, description="事件时间")
    event_type: str = Field(description="事件类型")
    plan_id: Optional[str] = Field(default=None, description="计划 ID")
    step_id: Optional[str] = Field(default=None, description="步骤 ID")
    step_index: Optional[int] = Field(default=None, description="步骤索引")
    step_status: Optional[str] = Field(default=None, description="步骤状态")
    data: Any = Field(description="事件数据")
    role: Optional[str] = Field(
        default=None,
        description="发布者角色 (assistant/user/system); envelope 字段, 不属于 Event 本体",
    )
    tags: Optional[Dict[str, Any]] = Field(default=None, description="事件标签")
    ttl: Optional[int] = Field(default=None, description="消息 TTL (秒)")
    
    @classmethod
    def from_event(cls, event: Event) -> "EventData":
        """从 Event 转换为 EventData(序列化格式)"""
        context = event.context or EventContext()
        return cls(
            event_id=event.id,
            timestamp=event.timestamp,
            event_type=event.type.value,
            plan_id=context.plan_id,
            step_id=context.step_id,
            step_index=context.step_index,
            step_status=context.step_status,
            data=event.data.model_dump() if isinstance(event.data, BaseModel) else event.data,
        )
