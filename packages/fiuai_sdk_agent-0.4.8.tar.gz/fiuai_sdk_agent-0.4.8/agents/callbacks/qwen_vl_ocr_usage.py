# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2026-03-24
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
阿里云百炼 Qwen-VL-OCR 用量与费用模拟

依据官方文档的图像缩放与 Token 估算公式, 以及按百万 Token 的单价做费用估算:
https://help.aliyun.com/zh/model-studio/qwen-vl-ocr

说明:
- 估算值用于预算/对账参考; 计费以 API 返回的 usage 为准
- qwen-vl-ocr / qwen-vl-ocr-latest / qwen-vl-ocr-2025-11-20 等: 每 Token 对应 32x32 像素
- 更早快照版: 每 Token 对应 28x28 像素
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from decimal import Decimal, ROUND_HALF_UP
from enum import Enum
from typing import Any, Mapping, Optional, Tuple

from fiuai_sdk_agent.utils.money import quantize_rate_per_1k_yuan


class QwenVlOcrDeployRegion(str, Enum):
    """文档中的部署地域, 单价不同 (元/百万 Token, CNY)"""

    CN_MAINLAND = "cn_mainland"  # 北京, 中国内地表
    GLOBAL_US = "global_us"  # 弗吉尼亚全球部署
    INTL_SG = "intl_sg"  # 新加坡国际部署


# 文档表格: 中国内地 稳定版 qwen-vl-ocr (与 2025-11-20 能力对齐)
PRICE_INPUT_PER_MILLION_CNY: dict[QwenVlOcrDeployRegion, Decimal] = {
    QwenVlOcrDeployRegion.CN_MAINLAND: Decimal("0.3"),
    QwenVlOcrDeployRegion.GLOBAL_US: Decimal("0.514"),
    QwenVlOcrDeployRegion.INTL_SG: Decimal("0.514"),
}
PRICE_OUTPUT_PER_MILLION_CNY: dict[QwenVlOcrDeployRegion, Decimal] = {
    QwenVlOcrDeployRegion.CN_MAINLAND: Decimal("0.5"),
    QwenVlOcrDeployRegion.GLOBAL_US: Decimal("1.174"),
    QwenVlOcrDeployRegion.INTL_SG: Decimal("1.174"),
}

# 文档默认的 min_pixels / max_pixels (OpenAI 兼容示例与 DashScope 一致)
DEFAULT_MIN_PIXELS = 32 * 32 * 3
DEFAULT_MAX_PIXELS = 32 * 32 * 8192


def ocr_token_prices_per_thousand_yuan(
    region: QwenVlOcrDeployRegion,
) -> Tuple[float, float]:
    """
    将文档「元/百万 Token」折算为 llm_usage_log 使用的「元/千 Token」, 与 cost_cny_from_tokens_per_1k 一致
    """
    inp = float(PRICE_INPUT_PER_MILLION_CNY[region] / Decimal(1000))
    out = float(PRICE_OUTPUT_PER_MILLION_CNY[region] / Decimal(1000))
    return quantize_rate_per_1k_yuan(inp), quantize_rate_per_1k_yuan(out)


def build_ocr_usage_remark(
    *,
    original_width_px: Optional[int] = None,
    original_height_px: Optional[int] = None,
    original_byte_length: Optional[int] = None,
    ocr_region: Optional[QwenVlOcrDeployRegion] = None,
) -> str:
    """
    写入 llm_usage_log.remark 的约定格式 (分号分隔键值, 便于检索与人工阅读)

    至少包含 billing=qwen_vl_ocr; 原始数据尺寸在可用时写入 original_wxh_px / original_bytes
    """
    parts: list[str] = ["billing=qwen_vl_ocr"]
    if ocr_region is not None:
        parts.append(f"ocr_region={ocr_region.value}")
    if original_width_px is not None and original_height_px is not None:
        parts.append(f"original_wxh_px={int(original_width_px)}x{int(original_height_px)}")
    if original_byte_length is not None:
        parts.append(f"original_bytes={int(original_byte_length)}")
    return ";".join(parts)


def smart_resize_bar_dims(
    height: int,
    width: int,
    min_pixels: int = DEFAULT_MIN_PIXELS,
    max_pixels: int = DEFAULT_MAX_PIXELS,
    align: int = 32,
) -> Tuple[int, int]:
    """
    文档「手动估算图像 Token」中的缩放逻辑, 得到 h_bar, w_bar (对齐到 align 像素)
    """
    if height <= 0 or width <= 0:
        raise ValueError("height and width must be positive")
    h_bar = round(height / align) * align
    w_bar = round(width / align) * align
    if h_bar * w_bar > max_pixels:
        beta = math.sqrt((height * width) / max_pixels)
        h_bar = math.floor(height / beta / align) * align
        w_bar = math.floor(width / beta / align) * align
    elif h_bar * w_bar < min_pixels:
        beta = math.sqrt(min_pixels / (height * width))
        h_bar = math.ceil(height * beta / align) * align
        w_bar = math.ceil(width * beta / align) * align
    return int(h_bar), int(w_bar)


def image_tokens_from_bar_dims(
    h_bar: int,
    w_bar: int,
    token_pixel_side: int = 32,
) -> int:
    """
    图像 Token 数 = (h_bar * w_bar) / token_pixel_side^2 + 2
    +2 为 <|vision_bos|> 与 <|vision_eos|> 文档说明各计 1 Token
    """
    if token_pixel_side not in (28, 32):
        raise ValueError("token_pixel_side must be 28 or 32 per Aliyun doc")
    token_pixels = token_pixel_side * token_pixel_side
    return int((h_bar * w_bar) / token_pixels) + 2


def estimate_image_tokens_for_ocr(
    height: int,
    width: int,
    *,
    min_pixels: int = DEFAULT_MIN_PIXELS,
    max_pixels: int = DEFAULT_MAX_PIXELS,
    align: int = 32,
    token_pixel_side: int = 32,
) -> int:
    """
    单图: 原图尺寸 -> 文档预处理后的视觉 Token 估算 (不含文本 prompt)
    token_pixel_side=32: qwen-vl-ocr / latest / 2025-11-20
    token_pixel_side=28: 文档中「其他模型」784 像素/Token
    """
    h_bar, w_bar = smart_resize_bar_dims(
        height, width, min_pixels=min_pixels, max_pixels=max_pixels, align=align
    )
    return image_tokens_from_bar_dims(h_bar, w_bar, token_pixel_side=token_pixel_side)


def _cost_from_million_scale(token_count: int, price_per_million: Decimal) -> Decimal:
    if token_count <= 0:
        return Decimal("0")
    return (Decimal(int(token_count)) * price_per_million / Decimal(1_000_000)).quantize(
        Decimal("0.000001"), rounding=ROUND_HALF_UP
    )


def ocr_cost_cny_from_usage(
    prompt_tokens: int,
    completion_tokens: int,
    region: QwenVlOcrDeployRegion = QwenVlOcrDeployRegion.CN_MAINLAND,
) -> Tuple[float, float, float]:
    """
    按 API usage (或等价总 Token) 计算费用 (元), 与文档「计费」段落一致

    Returns:
        (input_cost, output_cost, total_cost)
    """
    pin = PRICE_INPUT_PER_MILLION_CNY[region]
    pout = PRICE_OUTPUT_PER_MILLION_CNY[region]
    input_d = _cost_from_million_scale(prompt_tokens, pin)
    output_d = _cost_from_million_scale(completion_tokens, pout)
    total_d = (input_d + output_d).quantize(Decimal("0.000001"), rounding=ROUND_HALF_UP)
    return float(input_d), float(output_d), float(total_d)


@dataclass(frozen=True)
class QwenVlOcrSimulatedBill:
    """单次调用的模拟账单 (估算或基于 usage)"""

    region: QwenVlOcrDeployRegion
    prompt_tokens: int
    completion_tokens: int
    image_tokens_estimated: Optional[int]
    input_cost_cny: float
    output_cost_cny: float
    total_cost_cny: float


def simulate_from_image_size(
    height: int,
    width: int,
    text_prompt_tokens: int,
    completion_tokens: int,
    *,
    region: QwenVlOcrDeployRegion = QwenVlOcrDeployRegion.CN_MAINLAND,
    min_pixels: int = DEFAULT_MIN_PIXELS,
    max_pixels: int = DEFAULT_MAX_PIXELS,
    token_pixel_side: int = 32,
) -> QwenVlOcrSimulatedBill:
    """
    无 API 时: 用图像尺寸估算 image_tokens, 加上文本 prompt Token 得到总输入 Token 再算价
    """
    img_tok = estimate_image_tokens_for_ocr(
        height,
        width,
        min_pixels=min_pixels,
        max_pixels=max_pixels,
        token_pixel_side=token_pixel_side,
    )
    prompt_total = max(0, int(img_tok) + max(0, int(text_prompt_tokens)))
    ic, oc, tt = ocr_cost_cny_from_usage(prompt_total, completion_tokens, region=region)
    return QwenVlOcrSimulatedBill(
        region=region,
        prompt_tokens=prompt_total,
        completion_tokens=max(0, int(completion_tokens)),
        image_tokens_estimated=img_tok,
        input_cost_cny=ic,
        output_cost_cny=oc,
        total_cost_cny=tt,
    )


def simulate_from_openai_compatible_usage(
    usage: Mapping[str, Any],
    *,
    region: QwenVlOcrDeployRegion = QwenVlOcrDeployRegion.CN_MAINLAND,
    image_tokens_hint: Optional[int] = None,
) -> QwenVlOcrSimulatedBill:
    """
    从 OpenAI 兼容响应中的 usage 字典构造模拟账单 (实际用量)

    兼容键: prompt_tokens, completion_tokens;
    可选 prompt_tokens_details.image_tokens 作为 image_tokens_hint 的补充
    """
    prompt_tokens = int(usage.get("prompt_tokens") or 0)
    completion_tokens = int(usage.get("completion_tokens") or 0)
    details = usage.get("prompt_tokens_details") or {}
    if isinstance(details, Mapping):
        it = details.get("image_tokens")
        if it is not None:
            image_tokens_hint = int(it)
    ic, oc, tt = ocr_cost_cny_from_usage(prompt_tokens, completion_tokens, region=region)
    return QwenVlOcrSimulatedBill(
        region=region,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        image_tokens_estimated=image_tokens_hint,
        input_cost_cny=ic,
        output_cost_cny=oc,
        total_cost_cny=tt,
    )


def simulate_from_dashscope_usage(
    usage: Mapping[str, Any],
    *,
    region: QwenVlOcrDeployRegion = QwenVlOcrDeployRegion.CN_MAINLAND,
) -> QwenVlOcrSimulatedBill:
    """
    DashScope 原生响应 usage 字段 (文档示例): input_tokens, output_tokens, image_tokens
    """
    prompt_tokens = int(usage.get("input_tokens") or usage.get("prompt_tokens") or 0)
    completion_tokens = int(usage.get("output_tokens") or usage.get("completion_tokens") or 0)
    image_tokens_hint: Optional[int] = None
    it = usage.get("image_tokens")
    if it is not None:
        image_tokens_hint = int(it)
    ic, oc, tt = ocr_cost_cny_from_usage(prompt_tokens, completion_tokens, region=region)
    return QwenVlOcrSimulatedBill(
        region=region,
        prompt_tokens=prompt_tokens,
        completion_tokens=completion_tokens,
        image_tokens_estimated=image_tokens_hint,
        input_cost_cny=ic,
        output_cost_cny=oc,
        total_cost_cny=tt,
    )
