# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2025-01-30
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from typing import Any, Callable, List, Optional, TYPE_CHECKING
from datetime import datetime
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_result
from sqlalchemy import func

from fiuai_sdk_agent.utils.logger import get_logger
from fiuai_sdk_agent.utils.money import (
    cost_cny_from_tokens_per_1k,
    quantize_rate_per_1k_yuan,
)
from fiuai_sdk_python.utils.ids import gen_id

from fiuai_sdk_agent.agents.callbacks.types import LLMUsageLog
from fiuai_sdk_agent.pkg.llm.price_config import get_model_price_config

if TYPE_CHECKING:
    from fiuai_sdk_agent.agents.callbacks.qwen_vl_ocr_usage import QwenVlOcrDeployRegion

logger = get_logger(__name__)

# 调用方注入的 session factory, 返回 sqlalchemy.orm.Session
SessionFactory = Callable[[], Any]

# 兼容旧版: 尝试加载 pkg.db 作为 fallback
try:
    from pkg.db import get_db_manager
    _LEGACY_DB_AVAILABLE = True
except ImportError:
    _LEGACY_DB_AVAILABLE = False
    get_db_manager = None


def _get_legacy_session() -> Any:
    """从 pkg.db 获取 session (兼容旧版, 无 session_factory 时 fallback)"""
    if not _LEGACY_DB_AVAILABLE or get_db_manager is None:
        return None
    db_manager = get_db_manager()
    if db_manager.engine is None:
        logger.warning("Database engine not initialized, please call init_db_from_settings first")
        return None
    return db_manager.get_session()


def _normalize_selected_model_type(value: Optional[str]) -> str:
    s = (value or "").strip()
    return s if s else "unknown"


def _normalize_remark(value: Optional[str]) -> Optional[str]:
    s = (value or "").strip()
    return s if s else None


def _build_log_entry(
    task_id: Optional[str],
    task_name: Optional[str],
    agent_name: Optional[str],
    caller: Optional[str],
    model: Optional[str],
    selected_model_type: str,
    input_token: int,
    output_token: int,
    start_time: Optional[datetime],
    end_time: Optional[datetime],
    user_id: Optional[str],
    auth_tenant_id: Optional[str],
    auth_company_id: Optional[str],
    remark: Optional[str] = None,
    ocr_region: Optional["QwenVlOcrDeployRegion"] = None,
) -> LLMUsageLog:
    """构建 LLMUsageLog 记录对象; ocr_region 非空时按 Qwen-VL-OCR 文档单价计费, 忽略 model 在 price_config 中的条目"""
    input_price = 0.0
    output_price = 0.0
    input_cost = 0.0
    output_cost = 0.0

    if ocr_region is not None:
        from fiuai_sdk_agent.agents.callbacks.qwen_vl_ocr_usage import (
            ocr_token_prices_per_thousand_yuan,
        )

        input_price, output_price = ocr_token_prices_per_thousand_yuan(ocr_region)
        input_cost = cost_cny_from_tokens_per_1k(input_token, input_price)
        output_cost = cost_cny_from_tokens_per_1k(output_token, output_price)
    else:
        price_config = get_model_price_config()
        price = price_config.get_price(model) if model else None
        if price:
            input_price = quantize_rate_per_1k_yuan(price.input_price_per_1k)
            output_price = quantize_rate_per_1k_yuan(price.output_price_per_1k)
            input_cost = cost_cny_from_tokens_per_1k(input_token, input_price)
            output_cost = cost_cny_from_tokens_per_1k(output_token, output_price)

    now = datetime.now()
    record_time = int(now.timestamp() * 1000)
    start_time_ms = int(start_time.timestamp() * 1000) if start_time else record_time
    end_time_ms = int(end_time.timestamp() * 1000) if end_time else record_time

    return LLMUsageLog(
        name=gen_id(),
        creation=now,
        modified=now,
        owner=user_id or "",
        task_id=task_id or "",
        task_name=task_name or "",
        agent_name=agent_name or "",
        caller=caller or "",
        record_time=record_time,
        model=model or "",
        selected_model_type=selected_model_type,
        input_token=input_token,
        input_price=input_price,
        input_cost=input_cost,
        output_token=output_token,
        output_price=output_price,
        output_cost=output_cost,
        user_id=user_id or "",
        auth_tenant_id=auth_tenant_id or "",
        auth_company_id=auth_company_id or "",
        start_time=start_time_ms,
        end_time=end_time_ms,
        remark=_normalize_remark(remark),
    )


@retry(
    stop=stop_after_attempt(3),
    wait=wait_exponential(multiplier=1, min=4, max=15),
    retry=retry_if_result(lambda result: result is False)
)
async def write_llm_usage_log(
    task_id: Optional[str] = None,
    task_name: Optional[str] = None,
    agent_name: Optional[str] = None,
    caller: Optional[str] = None,
    model: Optional[str] = None,
    input_token: int = 0,
    output_token: int = 0,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    user_id: Optional[str] = None,
    auth_tenant_id: Optional[str] = None,
    auth_company_id: Optional[str] = None,
    selected_model_type: str = "unknown",
    remark: Optional[str] = None,
    ocr_region: Optional["QwenVlOcrDeployRegion"] = None,
    session_factory: Optional[SessionFactory] = None,
) -> bool:
    """
    异步写入 LLM 使用日志到数据库

    session_factory 由调用方注入, 返回 sqlalchemy.orm.Session 实例。
    未传入时 fallback 到 pkg.db (兼容旧版)。

    Args:
        task_id: 任务 ID
        task_name: 任务名称
        agent_name: Agent 名称
        caller: 调用者标识 (agent 内的具体操作)
        model: 模型名称
        input_token: 输入 token 数
        output_token: 输出 token 数
        start_time: 开始时间
        end_time: 结束时间
        user_id: 用户 ID
        auth_tenant_id: 租户 ID
        auth_company_id: 公司 ID
        selected_model_type: 用户选择的模型模式 (unknown|auto|high|normal 等)
        remark: 备注 (如 OCR 原始宽高/字节)
        ocr_region: 若设置则按 Qwen-VL-OCR 地域单价计费, 与 price_config 解耦
        session_factory: 可选的 session 工厂函数, 返回 sqlalchemy.orm.Session

    Returns:
        bool: 写入是否成功
    """
    try:
        session = session_factory() if session_factory else _get_legacy_session()
        if session is None:
            logger.warning("No database session available, skipping llm_usage_log write")
            return False

        smt = _normalize_selected_model_type(selected_model_type)
        log_entry = _build_log_entry(
            task_id=task_id,
            task_name=task_name,
            agent_name=agent_name,
            caller=caller,
            model=model,
            selected_model_type=smt,
            input_token=input_token,
            output_token=output_token,
            start_time=start_time,
            end_time=end_time,
            user_id=user_id,
            auth_tenant_id=auth_tenant_id,
            auth_company_id=auth_company_id,
            remark=remark,
            ocr_region=ocr_region,
        )

        logger.info(
            "[write_llm_usage_log] insert: name=%s task_id=%s agent_name=%s caller=%s model=%s "
            "selected_model_type=%s input_token=%s output_token=%s input_cost=%.6f output_cost=%.6f",
            log_entry.name, task_id, agent_name, caller, model, smt,
            input_token, output_token, log_entry.input_cost, log_entry.output_cost,
        )

        try:
            session.add(log_entry)
            session.commit()
            logger.info(
                "[write_llm_usage_log] success: name=%s task_id=%s model=%s",
                log_entry.name, task_id, model,
            )
            return True
        except Exception as e:
            session.rollback()
            raise e
        finally:
            session.close()

    except Exception as e:
        logger.error(
            "[write_llm_usage_log] exception: %s, task_id=%s, model=%s",
            e, task_id, model,
        )
        import traceback
        logger.error("[write_llm_usage_log] traceback: %s", traceback.format_exc())
        return False


async def write_llm_usage_log_qwen_vl_ocr(
    *,
    region: "QwenVlOcrDeployRegion",
    input_token: int,
    output_token: int,
    model: Optional[str] = None,
    task_id: Optional[str] = None,
    task_name: Optional[str] = None,
    agent_name: Optional[str] = None,
    caller: Optional[str] = None,
    start_time: Optional[datetime] = None,
    end_time: Optional[datetime] = None,
    user_id: Optional[str] = None,
    auth_tenant_id: Optional[str] = None,
    auth_company_id: Optional[str] = None,
    selected_model_type: str = "unknown",
    original_width_px: Optional[int] = None,
    original_height_px: Optional[int] = None,
    original_byte_length: Optional[int] = None,
    remark_extra: Optional[str] = None,
    session_factory: Optional[SessionFactory] = None,
) -> bool:
    """
    Qwen-VL-OCR 专用写入: 按地域 OCR 单价计费, remark 自动带上 billing 与原始数据尺寸

    model 仅作展示 (如 qwen-vl-ocr-latest), 计费以 region 为准
    """
    from fiuai_sdk_agent.agents.callbacks.qwen_vl_ocr_usage import build_ocr_usage_remark

    remark = build_ocr_usage_remark(
        original_width_px=original_width_px,
        original_height_px=original_height_px,
        original_byte_length=original_byte_length,
        ocr_region=region,
    )
    extra = (remark_extra or "").strip()
    if extra:
        remark = f"{remark};{extra}"
    return await write_llm_usage_log(
        task_id=task_id,
        task_name=task_name,
        agent_name=agent_name,
        caller=caller,
        model=model or "",
        input_token=input_token,
        output_token=output_token,
        start_time=start_time,
        end_time=end_time,
        user_id=user_id,
        auth_tenant_id=auth_tenant_id,
        auth_company_id=auth_company_id,
        selected_model_type=selected_model_type,
        remark=remark,
        ocr_region=region,
        session_factory=session_factory,
    )


def _llm_usage_effective_ts_ms():
    """record_time 为空时用 creation 转毫秒, 与时间筛选/排序一致"""
    epoch_ms = func.floor(func.extract("epoch", LLMUsageLog.creation) * 1000)
    return func.coalesce(LLMUsageLog.record_time, epoch_ms)


def _apply_llm_usage_time_range(q, record_time_from_ms: Optional[int], record_time_to_ms: Optional[int]):
    if record_time_from_ms is None and record_time_to_ms is None:
        return q
    eff = _llm_usage_effective_ts_ms()
    if record_time_from_ms is not None:
        q = q.filter(eff >= record_time_from_ms)
    if record_time_to_ms is not None:
        q = q.filter(eff <= record_time_to_ms)
    return q


def list_llm_usage_log(
    task_id: Optional[str] = None,
    user_id: Optional[str] = None,
    auth_tenant_id: Optional[str] = None,
    auth_company_id: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
    order_by_desc: bool = True,
    record_time_from_ms: Optional[int] = None,
    record_time_to_ms: Optional[int] = None,
    sort_by: str = "creation",
    session_factory: Optional[SessionFactory] = None,
) -> List[LLMUsageLog]:
    """
    查询 LLM 使用日志列表 (ORM 操作, 非 Frappe)

    session_factory 未传时 fallback 到 pkg.db.get_db_manager().get_session()。

    Args:
        record_time_from_ms / record_time_to_ms: 按有效时间戳毫秒筛选 (无 record_time 时用 creation)
        sort_by: creation | record_time (record_time 行为同上 coalesce)
        order_by_desc: 是否降序
    """
    session = session_factory() if session_factory else _get_legacy_session()
    if session is None:
        logger.warning("No database session available for list_llm_usage_log")
        return []

    try:
        q = session.query(LLMUsageLog)
        if task_id:
            q = q.filter(LLMUsageLog.task_id == task_id)
        if user_id:
            q = q.filter(LLMUsageLog.user_id == user_id)
        if auth_tenant_id:
            q = q.filter(LLMUsageLog.auth_tenant_id == auth_tenant_id)
        if auth_company_id:
            q = q.filter(LLMUsageLog.auth_company_id == auth_company_id)
        q = _apply_llm_usage_time_range(q, record_time_from_ms, record_time_to_ms)
        if sort_by == "record_time":
            eff = _llm_usage_effective_ts_ms()
            q = q.order_by(eff.desc() if order_by_desc else eff.asc())
        else:
            if order_by_desc:
                q = q.order_by(LLMUsageLog.creation.desc())
            else:
                q = q.order_by(LLMUsageLog.creation.asc())
        q = q.offset(offset).limit(limit)
        return list(q.all())
    except Exception as e:
        logger.error("list_llm_usage_log error: %s", e)
        raise
    finally:
        session.close()


def count_llm_usage_log(
    task_id: Optional[str] = None,
    user_id: Optional[str] = None,
    auth_tenant_id: Optional[str] = None,
    auth_company_id: Optional[str] = None,
    record_time_from_ms: Optional[int] = None,
    record_time_to_ms: Optional[int] = None,
    session_factory: Optional[SessionFactory] = None,
) -> int:
    """
    与 list_llm_usage_log 相同筛选条件下的记录总数 (用于分页)
    """
    session = session_factory() if session_factory else _get_legacy_session()
    if session is None:
        logger.warning("No database session available for count_llm_usage_log")
        return 0

    try:
        q = session.query(func.count(LLMUsageLog.name))
        if task_id:
            q = q.filter(LLMUsageLog.task_id == task_id)
        if user_id:
            q = q.filter(LLMUsageLog.user_id == user_id)
        if auth_tenant_id:
            q = q.filter(LLMUsageLog.auth_tenant_id == auth_tenant_id)
        if auth_company_id:
            q = q.filter(LLMUsageLog.auth_company_id == auth_company_id)
        q = _apply_llm_usage_time_range(q, record_time_from_ms, record_time_to_ms)
        row = q.scalar()
        return int(row or 0)
    except Exception as e:
        logger.error("count_llm_usage_log error: %s", e)
        raise
    finally:
        session.close()
