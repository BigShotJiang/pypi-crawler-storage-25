# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2025-01-30
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from .log_writer import (
    write_llm_usage_log,
    write_llm_usage_log_qwen_vl_ocr,
    list_llm_usage_log,
    count_llm_usage_log,
)
from .types import LLMUsageLog, SelectedModelType, DEFAULT_SELECTED_MODEL_TYPE
from .db_log_callback import LLMDatabaseLogCallback
from .qwen_vl_ocr_usage import (
    QwenVlOcrDeployRegion,
    QwenVlOcrSimulatedBill,
    build_ocr_usage_remark,
    estimate_image_tokens_for_ocr,
    ocr_cost_cny_from_usage,
    ocr_token_prices_per_thousand_yuan,
    simulate_from_dashscope_usage,
    simulate_from_image_size,
    simulate_from_openai_compatible_usage,
    smart_resize_bar_dims,
)

__all__ = [
    "write_llm_usage_log",
    "write_llm_usage_log_qwen_vl_ocr",
    "list_llm_usage_log",
    "count_llm_usage_log",
    "LLMUsageLog",
    "SelectedModelType",
    "DEFAULT_SELECTED_MODEL_TYPE",
    "LLMDatabaseLogCallback",
    "QwenVlOcrDeployRegion",
    "QwenVlOcrSimulatedBill",
    "build_ocr_usage_remark",
    "estimate_image_tokens_for_ocr",
    "ocr_token_prices_per_thousand_yuan",
    "ocr_cost_cny_from_usage",
    "simulate_from_dashscope_usage",
    "simulate_from_image_size",
    "simulate_from_openai_compatible_usage",
    "smart_resize_bar_dims",
]
