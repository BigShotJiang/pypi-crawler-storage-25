# -- coding: utf-8 --
# Project: fiuai-ai
# Created Date: 2026-03-24
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""金额与按 token 计费时的十进制量化, 避免 float 写入 DB 后出现长尾小数"""

from decimal import Decimal, ROUND_HALF_UP

# 人民币费用量化到微元级足够对账与展示; 与 llm_usage_log 常见显示精度一致
_COST_QUANT = Decimal("0.000001")
_RATE_QUANT = Decimal("0.000001")


def quantize_cost_cny(value: float) -> float:
    """将已是「元」的浮点金额量化为稳定十进制再转 float, 供 ORM Float 列写入"""
    d = Decimal(str(value)).quantize(_COST_QUANT, rounding=ROUND_HALF_UP)
    return float(d)


def cost_cny_from_tokens_per_1k(token_count: int, price_per_1k: float) -> float:
    """
    按「元/千 token」计算单行费用: (token / 1000) * price, 用 Decimal 避免二进制误差

    token_count 或 price 非正时返回 0.0
    """
    if token_count <= 0 or price_per_1k <= 0:
        return 0.0
    d = (
        Decimal(int(token_count)) * Decimal(str(price_per_1k)) / Decimal(1000)
    ).quantize(_COST_QUANT, rounding=ROUND_HALF_UP)
    return float(d)


def quantize_rate_per_1k_yuan(value: float) -> float:
    """单价(元/千 token) 入库前量化, 减少配置 float 带来的噪声"""
    if value <= 0:
        return 0.0
    d = Decimal(str(value)).quantize(_RATE_QUANT, rounding=ROUND_HALF_UP)
    return float(d)
