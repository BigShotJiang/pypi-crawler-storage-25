# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-05-05
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
ChatOpenAIThinking - 支持思考链 (reasoning_content) 捕获的 ChatOpenAI 子类

适用场景:
- 阿里云 DashScope OpenAI 兼容接口 (qwen3-max / qwen3.6-* / deepseek-r1 等)
- 任何返回 OpenAI Chat Completions 非标准 `reasoning_content` 字段的 vendor

实现说明:
langchain-openai (1.1.6) 的 `_convert_dict_to_message` / `_convert_delta_to_message_chunk`
仅识别 OpenAI 官方字段, 不会保留非标准 `reasoning_content`. 本子类在结果出口处补一次提取,
把 reasoning 写入 `AIMessage(Chunk).additional_kwargs[REASONING_KEY]`, 业务侧无需感知差异.

Hook 点 (与 langchain-openai 内部约定耦合, 升级时需校对):
- 非流式: `_create_chat_result(response, generation_info)`
- 流式  : `_convert_chunk_to_generation_chunk(chunk, default_chunk_class, base_generation_info)`
"""

from typing import Any, Mapping, Optional

import openai
from langchain_core.messages import AIMessage, AIMessageChunk
from langchain_core.outputs import ChatGenerationChunk, ChatResult
from langchain_openai import ChatOpenAI


# 写入 AIMessage.additional_kwargs 的统一 key, 业务层读取也用此常量
REASONING_KEY = "reasoning_content"


def _extract_reasoning_from_message_dict(message_dict: Mapping[str, Any]) -> str:
    """
    从 choices[].message dict 中抽取 reasoning_content (容错: 缺失返回空串)
    """
    if not isinstance(message_dict, Mapping):
        return ""
    val = message_dict.get(REASONING_KEY)
    if not val:
        return ""
    return val if isinstance(val, str) else str(val)


def _extract_reasoning_from_response_obj(response: Any) -> str:
    """
    从 openai.BaseModel 响应对象中抽取 reasoning_content (兜底, 防止 dump 丢字段)
    """
    if not isinstance(response, openai.BaseModel):
        return ""
    choices = getattr(response, "choices", None)
    if not choices:
        return ""
    msg = getattr(choices[0], "message", None)
    if msg is None:
        return ""
    val = getattr(msg, REASONING_KEY, None)
    if not val:
        return ""
    return val if isinstance(val, str) else str(val)


class ChatOpenAIThinking(ChatOpenAI):
    """
    ChatOpenAI 子类, 把 vendor 返回的 reasoning_content 透传到 additional_kwargs

    使用方式与 ChatOpenAI 完全一致, 业务层只需:
        text = chunk.additional_kwargs.get("reasoning_content", "")
    或对非流式:
        text = response.additional_kwargs.get("reasoning_content", "")
    """

    def _create_chat_result(
        self,
        response: Any,
        generation_info: Optional[dict] = None,
    ) -> ChatResult:
        result = super()._create_chat_result(response, generation_info)

        if not result.generations:
            return result

        # 优先从 dump 的 dict 取, 兜底从原始对象取
        response_dict = (
            response if isinstance(response, dict) else response.model_dump()
        )
        choices = response_dict.get("choices") or []
        reasoning = ""
        if choices:
            reasoning = _extract_reasoning_from_message_dict(
                choices[0].get("message") or {}
            )
        if not reasoning:
            reasoning = _extract_reasoning_from_response_obj(response)

        if reasoning:
            msg = result.generations[0].message
            if isinstance(msg, AIMessage):
                msg.additional_kwargs[REASONING_KEY] = reasoning

        return result

    def _convert_chunk_to_generation_chunk(
        self,
        chunk: dict,
        default_chunk_class: type,
        base_generation_info: Optional[dict],
    ) -> Optional[ChatGenerationChunk]:
        generation_chunk = super()._convert_chunk_to_generation_chunk(
            chunk, default_chunk_class, base_generation_info
        )
        if generation_chunk is None:
            return None

        choices = (
            chunk.get("choices", [])
            or chunk.get("chunk", {}).get("choices", [])
        )
        if not choices:
            return generation_chunk

        delta = choices[0].get("delta") or {}
        reasoning_delta = delta.get(REASONING_KEY)
        if not reasoning_delta:
            return generation_chunk

        if not isinstance(reasoning_delta, str):
            reasoning_delta = str(reasoning_delta)

        msg = generation_chunk.message
        if isinstance(msg, AIMessageChunk):
            # 单个 chunk 只放本次 delta; 多个 chunk 累计由 AIMessageChunk.__add__
            # (langchain_core.utils._merge.merge_dicts) 自动按 str 拼接
            msg.additional_kwargs[REASONING_KEY] = reasoning_delta

        return generation_chunk
