# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-05-05
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
Chat 模型元数据解析器注册 (SDK 弱依赖业务层)

SDK 不维护模型注册表, 仅暴露 callable hook:
- 业务层 (如 agents.llm_config.models.chat) 启动期通过 register_chat_model_metadata_resolver
  注入解析函数 (model_id_str → ChatModelMetadata or None)
- LLMManager.get_llm 调用 resolve_chat_model_metadata 取元数据;
  未注册或解析返回 None 时, 回退到 LLMModel.value 作为 api_model_id 且 thinking_mode="none"
"""

from typing import Callable, Optional, Union

from .types import ChatModelMetadata, LLMModel

# 解析器签名: 入参为模型 id 字符串 (LLMModel.value), 返回元数据或 None
ChatModelMetadataResolver = Callable[[str], Optional[ChatModelMetadata]]


_resolver: Optional[ChatModelMetadataResolver] = None


def register_chat_model_metadata_resolver(
    resolver: Optional[ChatModelMetadataResolver],
) -> None:
    """
    注册 / 清空模型元数据解析器

    业务层在 bootstrap 阶段调用一次; 传 None 可显式清空 (主要用于测试)
    """
    global _resolver
    _resolver = resolver


def resolve_chat_model_metadata(
    model: Union[LLMModel, str],
) -> ChatModelMetadata:
    """
    查询模型元数据, 不可解析时回退默认值 (api_model_id=入参 value, thinking_mode="none")
    """
    model_id = model.value if isinstance(model, LLMModel) else str(model)

    if _resolver is not None:
        try:
            meta = _resolver(model_id)
        except Exception:
            meta = None
        if meta is not None:
            return meta

    return ChatModelMetadata(api_model_id=model_id)
