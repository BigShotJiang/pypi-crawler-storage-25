# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-05-05
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
Thinking 流式/非流式 helper

为 thinking 模型 (qwen3-max-thinking / deepseek-r1 等) 提供统一的:
- 思考链 (reasoning_content) 累积
- 可选的 ChunkPurpose.THINKING 事件广播 (流/非流统一语义)
- 同步累积主回复内容 (content)

依赖:
- llm 推荐使用 ChatOpenAIThinking (子类) 实例, 否则 reasoning_content 不会被捕获
- publisher 鸭子类型, 须提供 .chunk(content: str, done: bool, purpose: str) 方法
  (业务层 EventPublisher.chunk 即满足此契约, SDK 不强依赖)

调用方可任意组合 emit_thinking / emit_reply 控制广播粒度:
- 仅静默累积 reasoning, 自己处理: emit_thinking=False, emit_reply=False, publisher=None
- 仅广播 thinking 不广播 reply: emit_thinking=True, emit_reply=False
- 全部广播: 默认行为
"""

from typing import Any, List, Optional, Protocol, Tuple

from langchain_core.messages import AIMessage, BaseMessage

from fiuai_sdk_agent.agents.types.event_type import ChunkPurpose

from .chat_openai_thinking import REASONING_KEY


class ChunkPublisher(Protocol):
    """
    EventPublisher 的最小子集鸭子类型 (业务层 EventPublisher 自然满足)
    """

    def chunk(
        self,
        content: str,
        done: bool = False,
        purpose: str = ChunkPurpose.REPLY,
        animate: bool = False,
    ) -> None: ...


def _coerce_text(value: Any) -> str:
    """把 chunk.content / additional_kwargs[reasoning_content] 标准化为 str"""
    if value is None or value == "":
        return ""
    return value if isinstance(value, str) else str(value)


async def astream_with_thinking_publish(
    llm: Any,
    messages: List[BaseMessage],
    publisher: Optional[ChunkPublisher] = None,
    *,
    emit_thinking: bool = True,
    emit_reply: bool = True,
    animate: bool = False,
) -> Tuple[str, str]:
    """
    流式调用 LLM, 同步累积 reply 与 reasoning, 按需广播 THINKING / REPLY chunk

    Args:
        llm: 已配置 streaming=True 的 ChatOpenAI(Thinking) 实例
        messages: LangChain 消息列表 (与 llm.astream 入参一致)
        publisher: 可选事件发布器 (满足 ChunkPublisher 协议); 为 None 时不广播
        emit_thinking: True 且 publisher 非空时, 广播 thinking 增量为 ChunkPurpose.THINKING
        emit_reply: True 且 publisher 非空时, 广播主回复增量为 ChunkPurpose.REPLY
        animate: 透传给 publisher.chunk(animate=...)

    Returns:
        (content_text, reasoning_text) 完整累积文本
    """
    content_parts: List[str] = []
    reasoning_parts: List[str] = []

    can_emit_reply = emit_reply and publisher is not None
    can_emit_thinking = emit_thinking and publisher is not None

    async for chunk in llm.astream(messages):
        text = _coerce_text(getattr(chunk, "content", ""))
        if text:
            content_parts.append(text)
            if can_emit_reply:
                publisher.chunk(text, done=False, purpose=ChunkPurpose.REPLY, animate=animate)

        kwargs = getattr(chunk, "additional_kwargs", None) or {}
        rtext = _coerce_text(kwargs.get(REASONING_KEY))
        if rtext:
            reasoning_parts.append(rtext)
            if can_emit_thinking:
                publisher.chunk(rtext, done=False, purpose=ChunkPurpose.THINKING, animate=animate)

    if can_emit_thinking and reasoning_parts:
        publisher.chunk("", done=True, purpose=ChunkPurpose.THINKING)
    if can_emit_reply and content_parts:
        publisher.chunk("", done=True, purpose=ChunkPurpose.REPLY)

    return "".join(content_parts), "".join(reasoning_parts)


async def ainvoke_with_thinking_publish(
    llm: Any,
    messages: List[BaseMessage],
    publisher: Optional[ChunkPublisher] = None,
    *,
    emit_thinking: bool = True,
    emit_reply: bool = False,
    animate: bool = False,
    **invoke_kwargs: Any,
) -> Tuple[AIMessage, str]:
    """
    非流式调用 LLM, 一次性广播 thinking / reply (与流式 done=True 收尾语义一致)

    非流式没有增量, emit_thinking=True 时仅在响应到达后发一条 done=True 的 THINKING chunk;
    emit_reply 默认 False (非流式回复一般由调用方决定如何呈现).

    Args:
        llm: ChatOpenAI(Thinking) 实例 (建议 streaming=False)
        messages: 消息列表
        publisher: 可选事件发布器
        emit_thinking: True 且 publisher 非空时, 把 reasoning 一次性发为 done=True 的 THINKING chunk
        emit_reply: True 且 publisher 非空时, 把主回复一次性发为 done=True 的 REPLY chunk
        animate: 透传给 publisher.chunk(animate=...)
        **invoke_kwargs: 透传给 llm.ainvoke (如 tools=[...])

    Returns:
        (response_message, reasoning_text)
    """
    response = await llm.ainvoke(messages, **invoke_kwargs)

    if not isinstance(response, AIMessage):
        # 兜底: 非 AIMessage (理论不会发生) 时只返回原值
        return response, ""

    reasoning_text = _coerce_text(
        (response.additional_kwargs or {}).get(REASONING_KEY)
    )

    if publisher is not None:
        if emit_thinking and reasoning_text:
            publisher.chunk(
                reasoning_text,
                done=True,
                purpose=ChunkPurpose.THINKING,
                animate=animate,
            )
        if emit_reply:
            content_text = _coerce_text(response.content)
            if content_text:
                publisher.chunk(
                    content_text,
                    done=True,
                    purpose=ChunkPurpose.REPLY,
                    animate=animate,
                )

    return response, reasoning_text
