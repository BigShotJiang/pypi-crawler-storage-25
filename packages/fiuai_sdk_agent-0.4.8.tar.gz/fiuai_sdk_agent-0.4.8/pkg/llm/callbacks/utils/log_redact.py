# -- coding: utf-8 --
# Project: fiuai-sdk-agent
# Created Date: 2026-04-30
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2026 FiuAI

"""LLM 日志脱敏与模型类型判断 (避免 OCR 等多模态请求中的二进制字段撑爆日志)."""

from __future__ import annotations

from typing import Any, Dict, Optional

from fiuai_sdk_agent.pkg.llm.types import LLMModel


def invocation_model_id(kwargs: Optional[Dict[str, Any]]) -> str:
    """从 LangChain callback kwargs 解析 invocation model id."""
    if not kwargs:
        return ""
    inv = kwargs.get("invocation_params") or {}
    if not isinstance(inv, dict):
        return ""
    mid = inv.get("model") or inv.get("model_name") or ""
    return str(mid).strip()


def is_ocr_like_chat_model(model_id: str) -> bool:
    """
    是否为 OCR / 强视觉类 chat 模型 (消息体常含内联二进制 data 字段).

    与 agents/llm_config 中 vision+ocr 及百炼 qwen-vl-ocr 系列对齐.
    """
    mid = (model_id or "").strip().lower()
    if not mid:
        return False
    if mid == LLMModel.OCR.value.lower():
        return True
    if "qwen-vl-ocr" in mid:
        return True
    if "vl-ocr" in mid:
        return True
    return False


def redact_message_data_keys_inplace(obj: Any) -> None:
    """
    原地递归删除 dict 中名为 data 的键 (典型为 base64 图片字节).

    仅应在已 model_dump 的副本上调用, 勿作用于原始 Message 对象.
    """
    if isinstance(obj, dict):
        if "data" in obj:
            del obj["data"]
        for _k, v in list(obj.items()):
            redact_message_data_keys_inplace(v)
    elif isinstance(obj, list):
        for item in obj:
            redact_message_data_keys_inplace(item)
