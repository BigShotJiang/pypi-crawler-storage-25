# -- coding: utf-8 --
# Project: callbacks
# Created Date: 2025 12 We
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
LLM 调试回调: LLM_TRACING 打印到控制台, LLM_LOGGING 写入 LOG_PATH/llm.log.

每条请求写两条记录: event=llm_start 含 messages (请求体 JSON), event=llm_end 含 response (完整结果) 与 response_text (助手正文便于检索).
OCR 等多模态模型会去掉消息/响应 JSON 中的 data 键, 避免 base64 撑爆日志.
"""

import os
import json
import threading
from typing import Dict, Any, List, Optional
from datetime import datetime

from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import BaseMessage
from langchain_core.outputs import LLMResult

from ..settings import get_llm_settings
from .utils.log_redact import (
    invocation_model_id,
    is_ocr_like_chat_model,
    redact_message_data_keys_inplace,
)

# 文件写入锁，确保线程安全
_log_file_lock = threading.Lock()


def _extract_llm_response_text(serialized_response: Dict[str, Any]) -> str:
    """从 LLMResult.model_dump 结构中抽取 assistant 文本, 便于检索日志."""
    parts: List[str] = []
    for gen_list in serialized_response.get("generations") or []:
        if not isinstance(gen_list, list):
            continue
        for g in gen_list:
            if not isinstance(g, dict):
                continue
            msg = g.get("message")
            if isinstance(msg, dict):
                content = msg.get("content")
                if isinstance(content, str) and content.strip():
                    parts.append(content.strip())
                elif isinstance(content, list):
                    for block in content:
                        if isinstance(block, dict) and block.get("type") == "text":
                            t = block.get("text")
                            if isinstance(t, str) and t.strip():
                                parts.append(t.strip())
            elif isinstance(msg, str) and msg.strip():
                parts.append(msg.strip())
            elif isinstance(g.get("text"), str) and g["text"].strip():
                parts.append(g["text"].strip())
    return "\n".join(parts) if parts else ""


def _get_log_path() -> Optional[str]:
    """
    获取日志文件路径
    
    Returns:
        日志文件完整路径，如果配置不存在则返回 None
    """
    try:
        settings = get_llm_settings()
        log_path = settings.LOG_PATH
        
        if not log_path:
            return None
        
        # 确保日志目录存在
        if not os.path.exists(log_path):
            os.makedirs(log_path, exist_ok=True)
        
        return os.path.join(log_path, "llm.log")
    except Exception:
        # 如果无法获取配置，返回 None
        return None


def _write_log(data: Dict[str, Any]) -> None:
    """
    写入日志到文件
    
    Args:
        data: 要写入的日志数据
    """
    log_file = _get_log_path()
    if not log_file:
        return
    
    try:
        with _log_file_lock:
            # 添加时间戳
            log_entry = {
                "timestamp": datetime.now().isoformat(),
                **data
            }
            
            # 追加写入文件
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(log_entry, ensure_ascii=False) + "\n")
    except Exception:
        # 忽略写入错误，避免影响主流程
        pass


class LLMDebugCallback(BaseCallbackHandler):
    """
    调试回调函数
    
    当 LLM_TRACING 为 true 时，打印调试信息
    当 LLM_LOGGING 为 true 时，将日志写入文件
    
    写入内容:
    - llm_start: messages 为完整请求消息 (JSON); OCR 模型会剔除各层 data 键
    - llm_end: response 为完整 LLMResult (JSON); response_text 为助手回复纯文本; OCR 同上脱敏
    """

    def __init__(self) -> None:
        super().__init__()
        # run_id -> model_id, 供 on_llm_end 在 kwargs 无 model 时关联本次调用
        self._model_by_run_id: Dict[str, str] = {}

    def on_chat_model_start(
        self, serialized: Dict[str, Any], messages: List[List[BaseMessage]], **kwargs
    ) -> None:
        """
        LLM 开始调用时触发
        """
        settings = get_llm_settings()
        
        # 获取 task_id
        task_id = kwargs.get("task_id")
        run_id = str(kwargs.get("run_id") or "")
        model_id = invocation_model_id(kwargs)
        if run_id:
            self._model_by_run_id[run_id] = model_id

        try:
            # 序列化消息: messages 是 List[List[BaseMessage]]，需要遍历序列化
            serialized_messages = [
                [msg.model_dump(mode="json") for msg in msg_list]
                for msg_list in messages
            ]
            if is_ocr_like_chat_model(model_id):
                redact_message_data_keys_inplace(serialized_messages)

            log_data = {
                "event": "llm_start",
                "task_id": task_id,
                "model": model_id,
                "serialized": serialized,
                "messages": serialized_messages,
            }
            
            # 如果开启追踪，打印到控制台
            if settings.LLM_TRACING:
                print(json.dumps(log_data, ensure_ascii=False, indent=2))
            
            # 如果开启日志记录，写入文件
            if settings.LLM_LOGGING:
                _write_log(log_data)
                
        except Exception as e:
            # 记录序列化错误
            if settings.LLM_TRACING:
                print(f"LLM start callback error: {str(e)}")
            if settings.LLM_LOGGING:
                _write_log({
                    "event": "llm_start_error",
                    "error": str(e),
                    "task_id": task_id,
                })

    def on_llm_end(self, response: LLMResult, **kwargs) -> None:
        """
        LLM 调用结束时触发
        """
        settings = get_llm_settings()
        
        # 获取 task_id
        task_id = kwargs.get("task_id")
        run_id = str(kwargs.get("run_id") or "")
        model_from_inv = invocation_model_id(kwargs)
        stored_model = self._model_by_run_id.pop(run_id, "") if run_id else ""
        model_id = model_from_inv or stored_model

        try:
            # 序列化LLM响应: 使用 model_dump 方法
            serialized_response = response.model_dump(mode="json")
            if is_ocr_like_chat_model(model_id):
                redact_message_data_keys_inplace(serialized_response)

            # 提取token使用信息
            # LLMResult 的 token_usage 在 llm_output 中
            llm_output = serialized_response.get("llm_output", {})
            token_usage = llm_output.get("token_usage", {}) if isinstance(llm_output, dict) else {}
            completion_tokens = token_usage.get("completion_tokens", 0)
            prompt_tokens = token_usage.get("prompt_tokens", 0)
            total_tokens = token_usage.get("total_tokens", 0)
            
            response_text = _extract_llm_response_text(serialized_response)

            log_data = {
                "event": "llm_end",
                "task_id": task_id,
                "model": model_id,
                "response": serialized_response,
                "response_text": response_text,
                "token_usage": {
                    "completion_tokens": completion_tokens,
                    "prompt_tokens": prompt_tokens,
                    "total_tokens": total_tokens,
                },
            }
            
            # 如果开启追踪，打印到控制台
            if settings.LLM_TRACING:
                print(json.dumps(log_data, ensure_ascii=False, indent=2))
            
            # 如果开启日志记录，写入文件
            if settings.LLM_LOGGING:
                _write_log(log_data)
                
        except Exception as e:
            # 记录序列化错误
            if settings.LLM_TRACING:
                print(f"LLM end callback error: {str(e)}")
            if settings.LLM_LOGGING:
                _write_log({
                    "event": "llm_end_error",
                    "error": str(e),
                    "task_id": task_id,
                })


