# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-04-08
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2026 FiuAI

"""
单次补全输出 token 上限: 同时兼容 max_tokens (旧) 与 max_completion_tokens (新).

归一规则:
- 两者均传入非 None: 原样使用 (可不同)
- 仅其一传入: 另一字段补成相同整数
- 均未传入: 两者均使用 default_cap
"""

from typing import Optional, Tuple

# 与 OpenAI chat.completions 常用默认对齐; Manager 与 LLMConfig 共用
DEFAULT_MAX_OUTPUT_TOKENS = 4096


def _non_negative_int(name: str, value: int) -> int:
    if value < 0:
        raise ValueError(f"{name} must be >= 0, got {value}")
    return value


def resolve_max_output_token_pair(
    max_tokens: Optional[int],
    max_completion_tokens: Optional[int],
    *,
    default_cap: int = DEFAULT_MAX_OUTPUT_TOKENS,
) -> Tuple[int, int]:
    """
    解析并返回 (max_tokens, max_completion_tokens), 二者均为非负 int.

    Args:
        max_tokens: 旧字段; None 表示调用方未提供
        max_completion_tokens: 新字段; None 表示调用方未提供
        default_cap: 两者均未提供时的默认值

    Raises:
        ValueError: 提供的值为负数
    """
    d = _non_negative_int("default_cap", int(default_cap))
    if max_tokens is not None and max_completion_tokens is not None:
        return (
            _non_negative_int("max_tokens", int(max_tokens)),
            _non_negative_int("max_completion_tokens", int(max_completion_tokens)),
        )
    if max_tokens is not None:
        v = _non_negative_int("max_tokens", int(max_tokens))
        return (v, v)
    if max_completion_tokens is not None:
        v = _non_negative_int("max_completion_tokens", int(max_completion_tokens))
        return (v, v)
    return (d, d)
