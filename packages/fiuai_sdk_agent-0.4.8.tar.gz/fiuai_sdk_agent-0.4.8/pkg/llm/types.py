# -- coding: utf-8 --
# Project: llm
# Created Date: 2025-01-29
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from typing import Optional, List, Dict, Any, Literal
from dataclasses import dataclass
from enum import StrEnum
from pydantic import BaseModel, Field
from langchain_core.callbacks import BaseCallbackHandler


# 思考模式枚举
# - none   : 无思考能力 (普通对话模型)
# - hybrid : 混合思考模式, 通过 enable_thinking 开关切换 (qwen3-max, qwen3.6-*, deepseek-v3.x)
# - always : 仅思考模式, 始终在回复前思考且无法关闭 (deepseek-r1)
ThinkingMode = Literal["none", "hybrid", "always"]


class LLMModel(StrEnum):
    """
    平台支持的对话/补全模型 (SDK 内逻辑 id)

    用户在前端手动选模时传入的字符串须等于某个成员的 value,
    否则在解析层 (如 LLMModel.parse_model_id / LLMModelResolver.resolve) 会抛 ValueError

    注意:
    - 大部分成员的 value 直接对应实际 API 的 model 字段
    - 部分 *-thinking 后缀成员是「逻辑 id」, 实际 API 仍走基础模型 + enable_thinking=True;
      真实 API id 在业务层 ChatModelEntry.api_model_id 注册, 通过 LLMManager.get_llm 解析
    """
    QWEN_TURBO = "qwen-turbo"
    QWEN_PLUS = "qwen-plus"
    QWEN_MAX = "qwen-max"
    QWEN_INTENT = "qwen-intent"
    OCR = "qwen-vl-plus"
    # 阿里云 Qwen 新一代
    QWEN3_MAX = "qwen3-max"
    QWEN3_MAX_THINKING = "qwen3-max-thinking"          # 逻辑 id, API 仍走 qwen3-max + enable_thinking=True
    QWEN3_6_PLUS = "qwen3.6-plus"
    QWEN3_6_PLUS_THINKING = "qwen3.6-plus-thinking"  # 逻辑 id, API 仍走 qwen3.6-plus + enable_thinking=True
    QWEN3_6_FLASH = "qwen3.6-flash"
    # DeepSeek 系列
    DS_V32 = "deepseek-v3.2-exp"
    DS_V4_PRO = "deepseek-v4"
    DS_V4_FLASH = "deepseek-v4-flash"
    DS_R1 = "deepseek-r1"
    DS_R1_THINKING = "deepseek-r1-thinking"            # 逻辑 id, API 仍走 deepseek-r1
    EMBEDDING = "embedding"
    MAXBAI_EMBEDDING = "maxbai_embedding"

    @classmethod
    def parse_model_id(cls, model_id: str) -> "LLMModel":
        """
        校验并解析用户手动选择的模型 id

        model_id 必须等于本枚举某一成员的 value (与 API 请求中的 model 字段一致),
        不是成员名、也不是 auto/high/normal 等档位字符串

        Args:
            model_id: 前端或 header 传入的模型名字符串

        Returns:
            对应的 LLMModel

        Raises:
            ValueError: 空字符串, 或无法匹配任一成员的 value
        """
        mid = (model_id or "").strip()
        if not mid:
            raise ValueError("model_id must be non-empty for explicit LLMModel parse")
        try:
            return cls(mid)
        except ValueError as e:
            known = ", ".join(repr(m.value) for m in cls)
            raise ValueError(
                f"Unknown LLM model id {model_id!r}; must match LLMModel enum value: {known}"
            ) from e

    def get_vendor_name(self) -> str:
        """
        Get the vendor name

        默认走阿里云 DashScope OpenAI 兼容接口 (vendor="ali"); deepseek 系列同走 DashScope,
        与现有 DS_V32 行为一致 (走 DeepSeek 官方 API 由调用方按需切换 vendor)
        """
        match self:
            case LLMModel.MAXBAI_EMBEDDING:
                return "local"
            case _:
                return "ali"



@dataclass
class LLMRequestConfig:
    """
    单个 LLM 请求配置
    
    用于多模型并发调用场景
    """
    model: LLMModel
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    max_completion_tokens: Optional[int] = None
    top_p: Optional[float] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    streaming: bool = False
    max_retries: Optional[int] = None
    timeout: Optional[int] = None
    callbacks: Optional[List[BaseCallbackHandler]] = None
    # 可选：为每个请求指定唯一标识
    request_id: Optional[str] = None


@dataclass
class LLMResponse:
    """
    LLM 响应结果
    
    用于多模型并发调用的返回结果
    """
    request_id: Optional[str]
    model: LLMModel
    content: Any  # 响应内容，类型取决于调用方式
    success: bool
    error: Optional[str] = None
    token_usage: Optional[Dict[str, int]] = None
    metadata: Optional[Dict[str, Any]] = None


class LLMVendor(BaseModel):
    """
    LLM Vendor配置
    """
    name: str = Field(..., description="LLM提供者名称")
    base_url: str = Field(..., description="Base URL")
    api_key: str = Field(..., description="API Key")
    timeout: Optional[int] = Field(default=600, description="超时时间(秒)")
    temperature: Optional[float] = Field(default=0.7, description="温度参数")
    max_tokens: Optional[int] = Field(default=None, description="最大生成 token 数 (旧 API); 与 max_completion_tokens 仅填一时会互相补齐为相同值")
    max_completion_tokens: Optional[int] = Field(
        default=None,
        description="最大生成 token 数 (新 API); 均未配置时二者默认相同, 见 DEFAULT_MAX_OUTPUT_TOKENS",
    )


@dataclass(frozen=True)
class ChatModelMetadata:
    """
    SDK 视角的对话模型元数据 (SDK 不维护模型表, 仅约定数据结构)

    业务层 (如 agents.llm_config.models.chat) 注册解析器后, SDK 通过 callable
    在 LLMManager.get_llm 阶段查询本结构, 决定:
    - 实际 API model 字段 (api_model_id, 区别于 SDK 逻辑 LLMModel.value)
    - 是否使用 ChatOpenAIThinking 子类 (thinking_mode in ("hybrid", "always"))
    - 是否自动注入 extra_body={"enable_thinking": True} (default_enable_thinking)
    - thinking 思考链最大 token 数 (default_thinking_budget, 阿里云 thinking_budget 字段)

    未注册或 resolver 未返回时, 回退到 LLMModel.value 作为 api_model_id, thinking_mode="none"
    """

    api_model_id: str
    thinking_mode: ThinkingMode = "none"
    default_enable_thinking: bool = False
    default_thinking_budget: Optional[int] = None
