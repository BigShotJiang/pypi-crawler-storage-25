# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-03-17
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
LLMModelResolver - 模型偏好解析器

将请求级 llm_model_type (auto/high/normal/unknown/具体模型 id) 解析为 LLMModel

规则:
- high / normal: 读子类配置的 HIGH_MODEL / NORMAL_MODEL
- auto / 空: 读子类配置的 DEFAULT_MODEL (基类提供平台默认)
- unknown: 读 DEFAULT_MODEL
- 其他字符串: 用户手动选模, 须为 types.LLMModel 某成员的 value, 否则抛 ValueError (见 LLMModel.parse_model_id)
"""

from typing import ClassVar

from .types import LLMModel

# 预设 tier 常量 (与 core/runtime.py 中一致, 此处冗余定义避免跨层依赖)
_TIER_AUTO = "auto"
_TIER_HIGH = "high"
_TIER_NORMAL = "normal"
_TIER_UNKNOWN = "unknown"


class LLMModelResolver:
    """
    模型偏好解析器基类

    业务侧应通过 agents.llm_config.resolvers 提供具体子类 (PlatformDefaultResolver / DataResolver / ...)
    SDK 基类此处仅给一个保底 (兼容老调用), 业务 Expert 与 RuntimeFactory 默认走 PlatformDefaultResolver

    子类需覆盖 HIGH_MODEL / NORMAL_MODEL / DEFAULT_MODEL
    """

    HIGH_MODEL: ClassVar[LLMModel] = LLMModel.QWEN_MAX
    NORMAL_MODEL: ClassVar[LLMModel] = LLMModel.QWEN_PLUS
    DEFAULT_MODEL: ClassVar[LLMModel] = LLMModel.QWEN_PLUS

    @classmethod
    def resolve(cls, llm_model_type: str) -> LLMModel:
        """
        将模型档位或模型名字符串解析为 LLMModel

        Args:
            llm_model_type: 档位 (auto/high/normal/unknown) 或用户选择的 LLMModel.value

        Returns:
            对应的 LLMModel

        Raises:
            ValueError: 既非已知档位, 也无法通过 LLMModel.parse_model_id 解析
        """
        raw = (llm_model_type or "").strip()

        if not raw or raw == _TIER_AUTO:
            return cls.DEFAULT_MODEL

        if raw == _TIER_HIGH:
            return cls.HIGH_MODEL

        if raw == _TIER_NORMAL:
            return cls.NORMAL_MODEL

        if raw == _TIER_UNKNOWN:
            return cls.DEFAULT_MODEL

        # 用户手动选模: 必须是 fiuai_sdk_agent.pkg.llm.types.LLMModel 中注册的 value
        try:
            return LLMModel.parse_model_id(raw)
        except ValueError as e:
            valid_tiers = f"{_TIER_AUTO!r}, {_TIER_HIGH!r}, {_TIER_NORMAL!r}, {_TIER_UNKNOWN!r}"
            raise ValueError(
                f"Invalid llm_model_type {raw!r}: use tier ({valid_tiers}) "
                f"or a registered LLMModel id (see LLMModel in types.py). {e}"
            ) from e
