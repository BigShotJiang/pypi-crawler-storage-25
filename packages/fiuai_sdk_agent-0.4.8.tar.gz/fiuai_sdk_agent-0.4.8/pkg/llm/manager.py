# -- coding: utf-8 --
# Project: llm
# Created Date: 2025-01-29
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from typing import Optional, List, Dict, Any, Callable
import json

from langchain_openai import ChatOpenAI
from langchain_core.callbacks import BaseCallbackHandler
from langchain_core.messages import BaseMessage


from fiuai_sdk_python.auth import get_auth_data, get_current_user_id, get_current_tenant_id, get_current_company
from .vendor import get_llm_vendor
from .types import LLMRequestConfig, LLMResponse, LLMModel
from .callbacks.agent_callback import AgentLLMCallback
from .chat_openai_thinking import ChatOpenAIThinking
from .model_metadata import resolve_chat_model_metadata
from .token_limits import DEFAULT_MAX_OUTPUT_TOKENS, resolve_max_output_token_pair

# 兼容旧名: 与 max_tokens / max_completion_tokens 默认相同
DEFAULT_MAX_COMPLETION_TOKENS = DEFAULT_MAX_OUTPUT_TOKENS

# 惰性加载, 避免 pkg.llm.manager → agents → agent → manager 的循环导入
_LLM_DATABASE_LOG_CALLBACK_CLS: Optional[type] = None


def _get_llm_database_log_callback_cls() -> type:
    global _LLM_DATABASE_LOG_CALLBACK_CLS
    if _LLM_DATABASE_LOG_CALLBACK_CLS is None:
        from fiuai_sdk_agent.agents.callbacks.db_log_callback import (
            LLMDatabaseLogCallback,
        )

        _LLM_DATABASE_LOG_CALLBACK_CLS = LLMDatabaseLogCallback
    return _LLM_DATABASE_LOG_CALLBACK_CLS


class LLMManager:
    """
    LLM 管理器
    
    负责管理 LLM 实例的创建、缓存和配置
    """

    @staticmethod
    def _normalize_selected_model_type(value: Optional[str]) -> str:
        """与 log_writer 一致: 空则 unknown, 供 llm_usage_log.selected_model_type"""
        s = (value or "").strip()
        return s if s else "unknown"

    def __init__(
        self,
        agent_name: str,
        agent_semantic: str,
        task_id: Optional[str] = None,
        task_name: Optional[str] = None,
        thread_id: Optional[str] = None,
        default_llm_model: Optional[LLMModel] = None,
        default_llm_config: Optional[Dict[str, Any]] = None,
        enable_db_log: bool = True,
        db_session_factory: Optional[Callable] = None,
        selected_model_type: str = "unknown",
    ):
        """
        初始化 LLM 管理器
        
        Args:
            agent_name: Agent 名称
            agent_semantic: Agent 语义描述
            task_id: 任务 ID（用于日志统计）
            task_name: 任务名称（用于日志统计）
            thread_id: 线程 ID（用于日志统计）
            default_llm_model: 默认 LLM 模型
            default_llm_config: 默认 LLM 配置
            enable_db_log: 是否启用数据库日志(写入 llm_usage_log), 默认 True;
                          db_session_factory 未传入时自动 fallback 到 pkg.db
            db_session_factory: 数据库 session 工厂, 返回 sqlalchemy.orm.Session (可选)
            selected_model_type: 无请求上下文时写入 llm_usage_log 的档位; 有上下文时以请求头 x-fiuai-model (AuthData.model) 为准
        """
        self.agent_name = agent_name
        self.agent_semantic = agent_semantic
        self.task_id = task_id or ""
        self.task_name = task_name or ""
        self.thread_id = thread_id or ""
        self._selected_model_type = self._normalize_selected_model_type(selected_model_type)
        # 默认配置
        self._default_llm_model = default_llm_model
        self._default_llm_config = default_llm_config or {
            "temperature": 0.3,
            "max_tokens": DEFAULT_MAX_OUTPUT_TOKENS,
            "max_completion_tokens": DEFAULT_MAX_OUTPUT_TOKENS,
            "top_p": 1.0,
            "frequency_penalty": 0.0,
            "presence_penalty": 0.0,
            "streaming": False,
            "max_retries": 3,
            "timeout": 600,
        }
        
        # LLM 实例缓存
        self._llm_cache: Dict[str, ChatOpenAI] = {}
        
        # 默认 callbacks（包含 agent 统计 callback），从 SDK 当前上下文取 auth
        _auth = get_auth_data()
        _user_id = get_current_user_id() if _auth else "system"
        _tenant_id = get_current_tenant_id() if _auth else ""
        _company_id = get_current_company() if _auth else ""
        self._default_callbacks: List[BaseCallbackHandler] = [
            AgentLLMCallback(
                agent_name=self.agent_name,
                agent_semantic=self.agent_semantic,
                user_id=_user_id or "system",
                auth_tenant_id=_tenant_id or "",
                auth_company_id=_company_id or "",
                task_id=self.task_id,
                task_name=self.task_name,
                thread_id=self.thread_id,
            )
        ]
        
        # 数据库日志回调: 将 LLM token 使用写入 llm_usage_log 表
        if enable_db_log:
            DbLogCb = _get_llm_database_log_callback_cls()
            self._default_callbacks.append(
                DbLogCb(
                    task_id=self.task_id,
                    task_name=self.task_name,
                    agent_name=self.agent_name,
                    user_id=_user_id or "system",
                    auth_tenant_id=_tenant_id or "",
                    auth_company_id=_company_id or "",
                    session_factory=db_session_factory,
                    selected_model_type=self._selected_model_type,
                )
            )


    @property
    def selected_model_type(self) -> str:
        return self._selected_model_type

    def set_selected_model_type(self, value: str) -> None:
        """无 SDK 认证上下文时用于 llm_usage_log; 有上下文时仍以 x-fiuai-model 为准"""
        self._selected_model_type = self._normalize_selected_model_type(value)

    def _selected_model_type_for_usage_log(self) -> str:
        """优先 AuthData.model (HTTP x-fiuai-model), 否则 _selected_model_type"""
        auth = get_auth_data()
        if auth is not None:
            return auth.model or "unknown"
        return "unknown"

    def _sync_callbacks_runtime(
        self,
        final_callbacks: List[BaseCallbackHandler],
        model_str: str,
        caller: str,
    ) -> None:
        for cb in final_callbacks:
            if isinstance(cb, AgentLLMCallback):
                cb.model = model_str
                cb.caller = caller
            elif isinstance(cb, _get_llm_database_log_callback_cls()):
                cb.model = model_str
                cb.caller = caller
                cb.selected_model_type = self._selected_model_type_for_usage_log()
            elif hasattr(cb, "caller") and hasattr(cb, "model"):
                cb.model = model_str
                cb.caller = caller

    def set_default_callbacks(self, callbacks: List[BaseCallbackHandler]) -> None:
        """
        设置默认 callbacks
        
        Args:
            callbacks: Callback 列表，会替换现有的默认 callbacks
        """
        self._default_callbacks = callbacks
    
    def add_default_callback(self, callback: BaseCallbackHandler) -> None:
        """
        添加默认 callback
        
        Args:
            callback: 要添加的 callback
        """
        if callback not in self._default_callbacks:
            self._default_callbacks.append(callback)
    
    def get_default_llm(
        self,
        callbacks: Optional[List[BaseCallbackHandler]] = None,
        caller: str = "common",
        **override_config
    ) -> ChatOpenAI:
        """
        获取默认 LLM 实例（使用默认配置）
        
        Args:
            callbacks: 可选的 callback 列表，如果提供则覆盖默认 callbacks
            caller: 调用者标识，表示 agent 做什么操作，默认值 "common"
            **override_config: 可选的配置覆盖参数
            
        Returns:
            ChatOpenAI 实例
            
        Raises:
            ValueError: 如果未定义默认模型
        """
        if self._default_llm_model is None:
            raise ValueError(
                f"LLMManager 未定义默认 LLM 模型。"
                "请在初始化时设置 default_llm_model 或使用 get_llm() 方法。"
            )
        
        mt_e, mct_e = self._caller_token_inputs_from_mapping(override_config)
        oc_wo = {
            k: v
            for k, v in override_config.items()
            if k not in ("max_tokens", "max_completion_tokens")
        }
        config = {**self._default_llm_config, **oc_wo}
        mt_r, mct_r = resolve_max_output_token_pair(
            mt_e,
            mct_e,
            default_cap=self._default_output_token_cap(),
        )
        config["max_tokens"] = mt_r
        config["max_completion_tokens"] = mct_r

        return self.get_llm(
            model=self._default_llm_model,
            callbacks=callbacks,
            caller=caller,
            **config
        )
    
    @staticmethod
    def _caller_token_inputs_from_mapping(mapping: Dict[str, Any]) -> tuple[Optional[int], Optional[int]]:
        """从 override 映射读取调用方是否传入 max_* (值为 None 视为未填)"""
        mt_e: Optional[int] = None
        if "max_tokens" in mapping:
            v = mapping["max_tokens"]
            if v is not None:
                mt_e = int(v)
        mct_e: Optional[int] = None
        if "max_completion_tokens" in mapping:
            v = mapping["max_completion_tokens"]
            if v is not None:
                mct_e = int(v)
        return mt_e, mct_e

    def _default_output_token_cap(self) -> int:
        cfg = self._default_llm_config
        if cfg.get("max_completion_tokens") is not None:
            return int(cfg["max_completion_tokens"])
        if cfg.get("max_tokens") is not None:
            return int(cfg["max_tokens"])
        return DEFAULT_MAX_OUTPUT_TOKENS

    def get_llm(
        self,
        model: LLMModel,
        callbacks: Optional[List[BaseCallbackHandler]] = None,
        caller: str = "common",
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        max_completion_tokens: Optional[int] = None,
        top_p: Optional[float] = None,
        frequency_penalty: Optional[float] = None,
        presence_penalty: Optional[float] = None,
        streaming: Optional[bool] = None,
        max_retries: Optional[int] = None,
        timeout: Optional[int] = None,
        use_cache: bool = True,
        enable_thinking: Optional[bool] = None,
        thinking_budget: Optional[int] = None,
        extra_body: Optional[Dict[str, Any]] = None,
    ) -> ChatOpenAI:
        """
        创建或获取 LLM 实例

        Args:
            model: LLM 模型 (SDK 内逻辑 id, 真实 API model 字段由 metadata 决定)
            callbacks: 可选的 callback 列表，如果提供则覆盖默认 callbacks
            caller: 调用者标识，表示 agent 做什么操作，默认值 "common"
            temperature: 温度参数
            max_tokens: 最大生成 token 数 (旧 API 字段); 仅传其一则另一字段自动补成相同值
            max_completion_tokens: 最大生成 token 数 (新 API 字段); 均未传时二者用默认相同值
            top_p: Top-p 参数
            frequency_penalty: 频率惩罚
            presence_penalty: 存在惩罚
            streaming: 是否流式输出
            max_retries: 最大重试次数
            timeout: 超时时间（秒）
            use_cache: 是否使用缓存
            enable_thinking: 显式控制 thinking 开关 (仅对 hybrid 模式有效);
                None=用模型 metadata.default_enable_thinking; True/False=显式覆盖
            thinking_budget: 思考链最大 token 数 (阿里云 thinking_budget, 透传 extra_body);
                None=用 metadata.default_thinking_budget; 解析后 ≤0 视为不下发
                仅在最终 enable_thinking=True 或 thinking_mode=always 时生效
            extra_body: 透传给 ChatOpenAI 的 extra_body
                (与 enable_thinking / thinking_budget 自动注入合并, extra_body 显式覆盖优先)

        Returns:
            ChatOpenAI 实例 (thinking 模型为 ChatOpenAIThinking 子类, reasoning_content
            会写入 AIMessage(Chunk).additional_kwargs[REASONING_KEY])
        """
        mt_r, mct_r = resolve_max_output_token_pair(
            max_tokens,
            max_completion_tokens,
            default_cap=self._default_output_token_cap(),
        )

        # 模型元数据 (api_model_id / thinking_mode / default_enable_thinking / default_thinking_budget)
        meta = resolve_chat_model_metadata(model)
        is_thinking_model = meta.thinking_mode in ("hybrid", "always")

        # 计算最终 extra_body (调用方显式覆盖优先, 自动注入兜底)
        merged_extra_body: Dict[str, Any] = {}
        # 1) enable_thinking
        thinking_will_be_on = False
        if is_thinking_model:
            if meta.thinking_mode == "always":
                # always 模式 vendor 始终思考, 无需 enable_thinking; budget 仍可生效
                thinking_will_be_on = True
            else:  # hybrid
                wants_thinking = (
                    enable_thinking
                    if enable_thinking is not None
                    else meta.default_enable_thinking
                )
                if wants_thinking:
                    merged_extra_body["enable_thinking"] = True
                    thinking_will_be_on = True
                elif enable_thinking is False:
                    merged_extra_body["enable_thinking"] = False
        # 2) thinking_budget (仅在思考被启用时下发)
        if thinking_will_be_on:
            budget = (
                thinking_budget
                if thinking_budget is not None
                else meta.default_thinking_budget
            )
            if budget is not None and budget > 0:
                merged_extra_body["thinking_budget"] = int(budget)
        # 3) 调用方显式 extra_body 优先覆盖前两步自动值
        if extra_body:
            merged_extra_body.update(extra_body)

        # 使用默认配置填充未提供的参数
        config = {
            "temperature": temperature if temperature is not None else self._default_llm_config.get("temperature", 0.3),
            "max_tokens": mt_r,
            "max_completion_tokens": mct_r,
            "top_p": top_p if top_p is not None else self._default_llm_config.get("top_p", 1.0),
            "frequency_penalty": frequency_penalty if frequency_penalty is not None else self._default_llm_config.get("frequency_penalty", 0.0),
            "presence_penalty": presence_penalty if presence_penalty is not None else self._default_llm_config.get("presence_penalty", 0.0),
            "streaming": streaming if streaming is not None else self._default_llm_config.get("streaming", False),
            "max_retries": max_retries if max_retries is not None else self._default_llm_config.get("max_retries", 3),
            "timeout": timeout if timeout is not None else self._default_llm_config.get("timeout", 600),
        }

        # 缓存 key 包含 api_model_id + extra_body, 避免 thinking on/off 复用同一实例
        cache_key_parts = {
            **config,
            "_api_model_id": meta.api_model_id,
            "_thinking_mode": meta.thinking_mode,
            "_extra_body": merged_extra_body,
        }
        cache_key = f"{model.value if hasattr(model, 'value') else str(model)}:{json.dumps(cache_key_parts, sort_keys=True)}"

        model_str = model.value if hasattr(model, "value") else str(model)
        final_callbacks_early = callbacks if callbacks is not None else self._default_callbacks
        if use_cache and cache_key in self._llm_cache:
            self._sync_callbacks_runtime(final_callbacks_early, model_str, caller)
            return self._llm_cache[cache_key]

        # 获取 vendor 配置
        vendor_config = get_llm_vendor(model.get_vendor_name())

        final_callbacks = final_callbacks_early

        self._sync_callbacks_runtime(final_callbacks, model_str, caller)

        # thinking 模型走子类, 透传 reasoning_content 到 additional_kwargs
        chat_cls: type[ChatOpenAI] = (
            ChatOpenAIThinking if is_thinking_model else ChatOpenAI
        )

        chat_kwargs: Dict[str, Any] = dict(
            model=meta.api_model_id,
            base_url=vendor_config.base_url,
            api_key=vendor_config.api_key,
            temperature=config["temperature"],
            top_p=config["top_p"],
            frequency_penalty=config["frequency_penalty"],
            presence_penalty=config["presence_penalty"],
            max_tokens=config["max_tokens"],
            max_completion_tokens=config["max_completion_tokens"],
            streaming=config["streaming"],
            max_retries=config["max_retries"],
            request_timeout=config["timeout"],
            callbacks=final_callbacks if final_callbacks else None,
        )
        if merged_extra_body:
            chat_kwargs["extra_body"] = merged_extra_body

        llm = chat_cls(**chat_kwargs)

        # 缓存实例
        if use_cache:
            self._llm_cache[cache_key] = llm

        return llm
    
    def get_statistics(self) -> Dict[str, Any]:
        """
        获取 LLM 使用统计信息
        
        Returns:
            Dict[str, Any]: 统计信息字典
        """
        stats = []
        for callback in self._default_callbacks:
            if isinstance(callback, AgentLLMCallback):
                stats.append(callback.get_statistics())
        
        return {
            "agent_name": self.agent_name,
            "agent_semantic": self.agent_semantic,
            "task_id": self.task_id,
            "callbacks": stats,
        }
    
    def clear_cache(self) -> None:
        """清空 LLM 实例缓存"""
        self._llm_cache.clear()
    
    async def invoke_llms_parallel(
        self,
        messages: List[BaseMessage],
        llm_configs: List[LLMRequestConfig],
        return_exceptions: bool = False,
    ) -> List[LLMResponse]:
        """
        并发调用多个 LLM 模型，返回所有结果
        
        这是一个框架方法，暂时未实现具体逻辑。
        未来实现时，将支持：
        - 并发调用多个模型
        - 统一的消息输入
        - 独立的配置和 callback
        - 错误处理和超时控制
        - Token 使用统计
        
        Args:
            messages: 输入消息列表（所有模型共享）
            llm_configs: LLM 配置列表，每个配置对应一个模型调用
            return_exceptions: 是否在结果中包含异常（而不是抛出）
            
        Returns:
            List[LLMResponse]: 所有模型的响应结果列表，顺序与 llm_configs 一致
            
        Raises:
            NotImplementedError: 方法尚未实现
        """
        # TODO: 实现多模型并发调用逻辑
        # 1. 为每个配置创建 LLM 实例
        # 2. 使用 asyncio.gather 或类似机制并发调用
        # 3. 收集所有结果，包括成功和失败的
        # 4. 统计每个模型的 token 使用情况
        # 5. 返回统一格式的结果列表
        
        raise NotImplementedError(
            "invoke_llms_parallel 方法尚未实现。"
            "这是一个预留框架，用于支持多模型并发调用功能。"
        )
    
    async def invoke_llms_batch(
        self,
        message_batches: List[List[BaseMessage]],
        llm_configs: List[LLMRequestConfig],
        return_exceptions: bool = False,
    ) -> List[List[LLMResponse]]:
        """
        批量并发调用多个 LLM 模型
        
        与 invoke_llms_parallel 的区别：
        - invoke_llms_parallel: 所有模型使用相同的消息
        - invoke_llms_batch: 每个模型使用不同的消息批次
        
        这是一个框架方法，暂时未实现具体逻辑。
        
        Args:
            message_batches: 消息批次列表，每个批次对应一个模型
            llm_configs: LLM 配置列表，每个配置对应一个模型调用
            return_exceptions: 是否在结果中包含异常（而不是抛出）
            
        Returns:
            List[List[LLMResponse]]: 每个模型的响应结果列表
            
        Raises:
            NotImplementedError: 方法尚未实现
            ValueError: 如果 message_batches 和 llm_configs 长度不匹配
        """
        if len(message_batches) != len(llm_configs):
            raise ValueError(
                f"message_batches 和 llm_configs 长度不匹配: "
                f"{len(message_batches)} != {len(llm_configs)}"
            )
        
        # TODO: 实现批量多模型并发调用逻辑
        # 1. 为每个配置创建 LLM 实例
        # 2. 使用 asyncio.gather 并发调用，每个模型使用对应的消息批次
        # 3. 收集所有结果
        # 4. 返回统一格式的结果列表
        
        raise NotImplementedError(
            "invoke_llms_batch 方法尚未实现。"
            "这是一个预留框架，用于支持批量多模型并发调用功能。"
        )

