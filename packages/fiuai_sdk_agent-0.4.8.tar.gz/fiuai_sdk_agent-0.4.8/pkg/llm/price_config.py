# -- coding: utf-8 --
# Project: llm
# Created Date: 2025-01-29
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

from typing import Dict, Optional
from dataclasses import dataclass

from fiuai_sdk_agent.utils.money import cost_cny_from_tokens_per_1k, quantize_cost_cny



@dataclass
class ModelPrice:
    """
    模型价格配置
    
    价格单位：元/千 token
    """
    input_price_per_1k: float  # 输入价格（元/千 token）
    output_price_per_1k: float  # 输出价格（元/千 token）
    currency: str = "CNY"  # 货币单位


class ModelPriceConfig:
    """
    模型价格配置管理器

    SDK 不内置任何价格数据, 价格表必须由业务侧 (如 agents.llm_config.bootstrap_llm)
    通过 update_prices / set_price 注入, 后续可扩展为从数据库加载
    """

    # SDK 侧不再内置默认价格 (业务侧 agents.llm_config.pricing.PRICE_TABLE 启动时注入)
    _default_prices: Dict[str, ModelPrice] = {}

    _instance: Optional['ModelPriceConfig'] = None
    _prices: Dict[str, ModelPrice] = {}

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._prices = cls._default_prices.copy()
        return cls._instance
    
    def get_price(self, model_name: str) -> Optional[ModelPrice]:
        """
        获取模型价格配置
        
        Args:
            model_name: 模型名称
            
        Returns:
            ModelPrice 或 None（如果未找到）
        """
        return self._prices.get(model_name)
    
    def set_price(self, model_name: str, price: ModelPrice) -> None:
        """
        设置模型价格配置
        
        Args:
            model_name: 模型名称
            price: 价格配置
        """
        self._prices[model_name] = price
    
    def update_prices(self, prices: Dict[str, ModelPrice]) -> None:
        """
        批量更新价格配置
        
        Args:
            prices: 价格配置字典
        """
        self._prices.update(prices)
    
    def reload_from_database(self) -> None:
        """
        从数据库重新加载价格配置
        
        这是一个预留方法，未来实现时将从数据库加载价格配置
        """
        # TODO: 从数据库加载价格配置
        # 1. 连接数据库
        # 2. 查询模型价格表
        # 3. 更新 _prices 字典
        # 4. 可选：设置缓存过期时间
        pass
    
    def calculate_cost(
        self,
        model_name: str,
        prompt_tokens: int,
        completion_tokens: int
    ) -> Optional[float]:
        """
        计算费用
        
        Args:
            model_name: 模型名称
            prompt_tokens: 输入 token 数
            completion_tokens: 输出 token 数
            
        Returns:
            费用（元），如果模型未配置价格则返回 None
        """
        price = self.get_price(model_name)
        if price is None:
            return None
        
        input_cost = cost_cny_from_tokens_per_1k(prompt_tokens, price.input_price_per_1k)
        output_cost = cost_cny_from_tokens_per_1k(completion_tokens, price.output_price_per_1k)
        return quantize_cost_cny(input_cost + output_cost)


# 全局单例实例
_model_price_config: Optional[ModelPriceConfig] = None


def get_model_price_config() -> ModelPriceConfig:
    """
    获取模型价格配置单例
    
    Returns:
        ModelPriceConfig 实例
    """
    global _model_price_config
    if _model_price_config is None:
        _model_price_config = ModelPriceConfig()
    return _model_price_config

