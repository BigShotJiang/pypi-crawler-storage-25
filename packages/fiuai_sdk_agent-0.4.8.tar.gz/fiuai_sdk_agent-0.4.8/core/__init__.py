# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-02-04
# Author: liming
# Email: lmlala@aliyun.com
# Copyright (c) 2026 FiuAI

"""
Core - 核心抽象层

包含 SDK 的核心抽象类:
- AgentRuntime: 泛型运行时上下文容器
- SkillRegistry: Skill 注册中心
- PlanEngine: Plan 引擎抽象基类
- EventBus: 事件总线抽象基类
"""

from .runtime import (
    AgentRuntime,
    LLM_MODEL_AUTO,
    LLM_MODEL_HIGH,
    LLM_MODEL_NORMAL,
    LLM_MODEL_UNKNOWN,
)
from .skill import SkillRegistry, SkillDefinition
from .plan import PlanEngine
from .event import EventBus
from .knowledge import KnowledgeRegistry, DomainKnowledge
from .sub_agent import (
    PlatformHintSpec,
    SubAgentDefinition,
    SubAgentOutput,
    SubAgentRegistry,
    flatten_sub_agent_tool_results,
    register_tool_arg_coalescer,
)

__all__ = [
    "AgentRuntime",
    "LLM_MODEL_AUTO",
    "LLM_MODEL_HIGH",
    "LLM_MODEL_NORMAL",
    "LLM_MODEL_UNKNOWN",
    "SkillRegistry",
    "SkillDefinition",
    "PlanEngine",
    "EventBus",
    "KnowledgeRegistry",
    "DomainKnowledge",
    "PlatformHintSpec",
    "SubAgentDefinition",
    "SubAgentOutput",
    "SubAgentRegistry",
    "flatten_sub_agent_tool_results",
    "register_tool_arg_coalescer",
]
