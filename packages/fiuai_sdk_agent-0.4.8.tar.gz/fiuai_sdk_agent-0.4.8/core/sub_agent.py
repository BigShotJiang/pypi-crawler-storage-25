# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-03-21
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
SubAgent - 三层架构第三层: 最小自治执行单元

设计要点:
- 比 Expert 轻 (无 Graph, 无 Plan 管理), 比 Skill 重 (有 LLM 决策)
- 持有 3-5 个 focused tools, 通过 LLM Function Calling 选择并执行
- 由 Expert 路由 (SOP 确定性 / Dynamic LLM 选择)
- 独立的 system_prompt 和 knowledge 片段

层级关系:
    L1 Supervisor → 意图路由 → L2 Expert
    L2 Expert → 能力路由 → L3 SubAgent
    L3 SubAgent → LLM 选择 → L4 Tool/Skill

成功完成时 SubAgentOutput.result 约定为「与 Handler 步骤结果一致」的扁平 dict:
    由 flatten_sub_agent_tool_results 从 tool 链规整得到; 失败或 HITL 时可为 {"tool_results": [...]}.

使用示例:
    # 定义 SubAgent
    tax_code_agent = SubAgentDefinition(
        name="tax_code",
        description="税编推理、税率确定",
        domain="tax",
        system_prompt="你是税编推理专家...",
        tools=["classify_tax_code", "verify_and_enrich_items"],
    )
    SubAgentRegistry.register(tax_code_agent)

    # Expert 中使用
    sub_agent = SubAgentRegistry.get("tax", "tax_code")
    result = await sub_agent.execute(task, context, runtime)
"""

import json
from typing import Any, Callable, Dict, List, Optional, TYPE_CHECKING

from pydantic import BaseModel, Field

from ..utils.logger import get_logger

from fiuai_sdk_agent.pkg.llm.manager import DEFAULT_MAX_COMPLETION_TOKENS

if TYPE_CHECKING:
    from .runtime import AgentRuntime

logger = get_logger(__name__)

# tool_name -> (tool_args, execution_context) -> merged tool_args
# 业务层通过 register_tool_arg_coalescer 注册, 避免 SDK 硬编码领域字段
_TOOL_ARG_COALESCERS: Dict[str, Callable[[Dict[str, Any], Dict[str, Any]], Dict[str, Any]]] = {}


def register_tool_arg_coalescer(
    tool_name: str,
    fn: Callable[[Dict[str, Any], Dict[str, Any]], Dict[str, Any]],
) -> None:
    """注册工具参数合并函数: 在 SubAgent 执行 skill/tool 前用上下文补全 LLM 漏填字段"""
    _TOOL_ARG_COALESCERS[tool_name] = fn
    logger.debug("Registered tool arg coalescer for '%s'", tool_name)


def flatten_sub_agent_tool_results(
    tool_results: List[Any],
) -> Optional[Dict[str, Any]]:
    """
    将一轮工具调用链的条目列表规整为单一 dict, 供 Expert step.result 与 Handler 对齐.

    规则与具体业务工具名无关, 仅依赖 LLM 编排的常见管线顺序:
    - 收集所有无 error 且含 dict 型 result 的条目, 按调用顺序保留
    - 仅一条: 返回该 result
    - 多条: 优先返回「从后往前第一个非空 dict」(通常为最终产出); 若皆空则返回最后一条的 result

    无法规整时返回 None, 调用方应保留原始 {"tool_results": ...} 结构.
    """
    candidates: List[Dict[str, Any]] = []
    for entry in tool_results or []:
        if not isinstance(entry, dict) or entry.get("error"):
            continue
        inner = entry.get("result")
        if isinstance(inner, dict):
            candidates.append(inner)
    if not candidates:
        return None
    if len(candidates) == 1:
        return candidates[0]
    for inner in reversed(candidates):
        if inner:
            return inner
    return candidates[-1]


class SubAgentOutput(BaseModel):
    """SubAgent 执行结果"""

    success: bool = Field(description="是否成功")
    result: Any = Field(default=None, description="执行结果")
    message: str = Field(default="", description="结果说明")
    error: Optional[str] = Field(default=None, description="错误信息")

    # HITL
    need_user_input: bool = Field(
        default=False, description="是否需要用户补充信息"
    )
    user_input_question: Optional[str] = Field(
        default=None, description="追问问题"
    )
    user_input_options: Optional[List[Dict[str, Any]]] = Field(
        default=None, description="用户可选项"
    )
    user_input_context: Optional[Dict[str, Any]] = Field(
        default=None, description="传递给前端的上下文"
    )

    # 跨域需求信号 (runtime fallback, 非主路径)
    needs_enrichment: Optional[Dict[str, Any]] = Field(
        default=None,
        description="跨域补充需求信号, 如 {domain: 'tax', query: 'get rates for X'}",
    )


def _extract_hitl_signal(
    result_entry: Dict[str, Any],
) -> Optional[Dict[str, Any]]:
    """
    从 tool 执行结果中检测 HITL 信号

    协议: skill/tool 结果 dict 中含 need_user_input=True 时,
    SubAgent 立即 short-circuit 并将信号向上冒泡
    """
    inner = result_entry.get("result")
    if not isinstance(inner, dict):
        return None
    if not inner.get("need_user_input"):
        return None
    return {
        "question": inner.get("user_input_question", ""),
        "options": inner.get("user_input_options"),
        "context": inner.get("user_input_context"),
    }


class PlatformHintSpec(BaseModel):
    """
    SubAgent 声明需注入的 doctype 字段摘录 (依赖 PlatformKnowledge).

    fields 为 None 时: 取该 doctype 下带 field_prompt 的字段 (条数由 format 侧上限约束).
    fields 非空时: 仅输出白名单中的字段 (仍受 only_has_prompt 过滤).
    """

    doctype: str = Field(description="Doctype 名称")
    fields: Optional[List[str]] = Field(
        default=None,
        description="字段名白名单, None 表示自动选取带 field_prompt 的字段",
    )


class SubAgentDefinition(BaseModel):
    """
    SubAgent 定义 - 三层架构中的最小自治执行单元

    Attributes:
        name: 唯一标识 (域内唯一, 如 "tax_code", "invoice")
        description: 给上层 LLM 看的能力描述
        domain: 所属领域 (如 "tax", "platform")
        system_prompt: SubAgent 自身的 LLM 系统提示
        tools: 显式声明的 tool/skill 名称列表 (运行时从 Registry 按名获取)
        knowledge_keys: 预留, 从 DomainKnowledge 注入的字段名 (由业务层增强管线消费)
        platform_hints: 需拼入 system_prompt 的 doctype 字段摘录声明
        inject_platform_api_rules: 是否拼入平台 API 数据规则 (多租户/name 主键等)
        inject_user_profile: 是否由业务层增强管线拼入当前用户公司画像 (纳税人类型等)
        max_rounds: LLM tool-calling 最大轮数
    """

    name: str
    description: str
    domain: str
    system_prompt: str
    tools: List[str] = Field(default_factory=list)
    knowledge_keys: List[str] = Field(default_factory=list)
    platform_hints: List[PlatformHintSpec] = Field(default_factory=list)
    inject_platform_api_rules: bool = Field(
        default=False,
        description="执行前是否附加平台 API 与数据口径说明",
    )
    inject_user_profile: bool = Field(
        default=False,
        description="执行前是否附加当前用户公司画像 (纳税人类型/主体类型/国家等)",
    )
    max_rounds: int = Field(default=3, ge=1, le=10)

    def to_tool_schema(self) -> dict:
        """导出为 OpenAI Tool Schema, 供 Expert LLM 选择 SubAgent"""
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": {
                    "type": "object",
                    "properties": {
                        "task": {
                            "type": "string",
                            "description": "要执行的任务描述",
                        },
                        "context": {
                            "type": "object",
                            "description": "任务相关的上下文信息",
                        },
                    },
                    "required": ["task"],
                },
            },
        }

    def _collect_tool_schemas(self) -> List[dict]:
        """从全局 Registry 按名称收集 tool/skill 的 OpenAI schema"""
        from .skill import SkillRegistry

        schemas: List[dict] = []
        seen: set[str] = set()

        for tool_name in self.tools:
            if tool_name in seen:
                continue
            seen.add(tool_name)

            skill = SkillRegistry.get(tool_name)
            if skill:
                schemas.append(skill.to_openai_tool())
                continue

            # 延迟导入业务层 ToolRegistry, 保持 SDK 层不硬依赖
            try:
                from agents.tools.registry import ToolRegistry
                tool_def = ToolRegistry.get(tool_name)
                if tool_def:
                    schemas.append(tool_def.to_openai_tool())
                    continue
            except ImportError:
                pass

            logger.warning(
                f"SubAgent '{self.name}': tool '{tool_name}' not found in any registry"
            )

        return schemas

    async def execute(
        self,
        task: str,
        context: Dict[str, Any],
        runtime: "AgentRuntime",
    ) -> SubAgentOutput:
        """
        LLM Function Calling 从 self.tools 中选择并执行

        context 包含: previous_steps, task_context, user_profile 等
        SubAgent 的 LLM 负责理解 context 并构造正确的 tool 输入

        Args:
            task: 任务描述
            context: 上下文信息
            runtime: AgentRuntime 实例

        Returns:
            SubAgentOutput
        """
        from langchain_core.messages import (
            HumanMessage,
            SystemMessage,
            ToolMessage,
        )
        from .skill import SkillRegistry

        all_tools = self._collect_tool_schemas()
        if not all_tools:
            logger.warning(
                f"SubAgent '{self.name}': no tools resolved, returning empty"
            )
            return SubAgentOutput(
                success=True,
                result={"tool_results": []},
                message=f"SubAgent '{self.name}' has no available tools",
            )

        context_text = ""
        if context:
            context_text = (
                f"\n\n上下文信息:\n"
                f"{json.dumps(context, ensure_ascii=False, default=str)[:3000]}"
            )

        messages = [
            SystemMessage(content=self.system_prompt),
            HumanMessage(content=f"任务: {task}{context_text}"),
        ]


        # 复用 runtime.llm_manager 已按 Expert resolver 解析过的默认模型,
        # 与 expert.get_model() 保持一致, 避免基类 resolver 与 Expert 自定义脱钩
        llm = runtime.llm_manager.get_default_llm(
            temperature=0.1,
            max_completion_tokens=DEFAULT_MAX_COMPLETION_TOKENS,
            streaming=False,
            caller=f"sub_agent.{self.name}",
        )

        results: List[Dict[str, Any]] = []

        for round_idx in range(self.max_rounds):
            response = await llm.ainvoke(messages, tools=all_tools)

            if not hasattr(response, "tool_calls") or not response.tool_calls:
                logger.info(
                    f"SubAgent '{self.name}': LLM finished after {round_idx} rounds"
                )
                break

            for tool_call in response.tool_calls:
                tool_name = tool_call["name"]
                tool_args = tool_call.get("args", {})

                logger.info(
                    f"SubAgent '{self.name}': LLM selected '{tool_name}' "
                    f"(round {round_idx + 1})"
                )

                result_entry = await self._execute_single_tool(
                    tool_name, tool_args, runtime, context
                )
                results.append(result_entry)

                hitl = _extract_hitl_signal(result_entry)
                if hitl:
                    logger.info(
                        f"SubAgent '{self.name}': tool '{tool_name}' "
                        f"requests user input, breaking loop"
                    )
                    return SubAgentOutput(
                        success=True,
                        result={"tool_results": results},
                        need_user_input=True,
                        user_input_question=hitl.get("question"),
                        user_input_options=hitl.get("options"),
                        user_input_context=hitl.get("context"),
                        message=(
                            f"SubAgent '{self.name}': "
                            f"'{tool_name}' needs user input"
                        ),
                    )

            # 将结果反馈给 LLM
            messages.append(response)
            round_results = results[len(results) - len(response.tool_calls):]
            for tool_call, r in zip(response.tool_calls, round_results):
                tool_call_id = (
                    tool_call.get("id")
                    if isinstance(tool_call, dict)
                    else getattr(tool_call, "id", "")
                )
                result_text = json.dumps(
                    r, ensure_ascii=False, default=str
                )[:1500]
                messages.append(
                    ToolMessage(tool_call_id=tool_call_id, content=result_text)
                )

        has_error = any(r.get("error") for r in results)
        tool_names = [r.get("tool", "unknown") for r in results]

        if has_error:
            result_payload: Any = {"tool_results": results}
        else:
            flat = flatten_sub_agent_tool_results(results)
            result_payload = (
                flat if flat is not None else {"tool_results": results}
            )

        return SubAgentOutput(
            success=not has_error,
            result=result_payload,
            message=(
                f"SubAgent '{self.name}' 完成, 调用了: {', '.join(tool_names)}"
                if results
                else f"SubAgent '{self.name}' 完成 (无工具调用)"
            ),
            error=(
                "; ".join(r["error"] for r in results if r.get("error"))
                if has_error
                else None
            ),
        )

    async def _execute_single_tool(
        self,
        tool_name: str,
        tool_args: Dict[str, Any],
        runtime: "AgentRuntime",
        execution_context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """执行单个 tool/skill, 返回结构化结果"""
        from .skill import SkillRegistry

        merged_args: Dict[str, Any] = dict(tool_args or {})
        coalescer = _TOOL_ARG_COALESCERS.get(tool_name)
        if coalescer and execution_context is not None:
            merged_args = coalescer(merged_args, execution_context)

        skill = SkillRegistry.get(tool_name)
        if skill:
            try:
                result = await skill.execute(merged_args, runtime)
                return {
                    "tool": tool_name,
                    "type": "skill",
                    "result": (
                        result.model_dump()
                        if hasattr(result, "model_dump")
                        else result
                    ),
                }
            except Exception as e:
                logger.error(
                    f"SubAgent '{self.name}': skill '{tool_name}' error: {e}",
                    exc_info=True,
                )
                return {"tool": tool_name, "type": "skill", "error": str(e)}

        try:
            from agents.tools.registry import ToolRegistry

            tool_def = ToolRegistry.get(tool_name)
            if tool_def:
                try:
                    result = await tool_def.func(**merged_args)
                    return {"tool": tool_name, "type": "tool", "result": result}
                except Exception as e:
                    logger.error(
                        f"SubAgent '{self.name}': tool '{tool_name}' error: {e}",
                        exc_info=True,
                    )
                    return {"tool": tool_name, "type": "tool", "error": str(e)}
        except ImportError:
            pass

        error_msg = f"Tool/Skill '{tool_name}' not found"
        logger.warning(f"SubAgent '{self.name}': {error_msg}")
        return {"tool": tool_name, "error": error_msg}


class SubAgentRegistry:
    """
    SubAgent 注册中心

    按 domain 组织, 支持跨域共享 (通过 shared_domains)
    """

    _registry: Dict[str, Dict[str, SubAgentDefinition]] = {}

    @classmethod
    def register(cls, definition: SubAgentDefinition) -> None:
        """注册 SubAgent 定义"""
        domain = definition.domain
        if domain not in cls._registry:
            cls._registry[domain] = {}

        if definition.name in cls._registry[domain]:
            logger.warning(
                f"SubAgent '{definition.name}' in domain '{domain}' "
                f"already registered, overwriting"
            )

        cls._registry[domain][definition.name] = definition
        logger.debug(
            f"Registered SubAgent: {definition.name} "
            f"(domain={domain}, tools={definition.tools})"
        )

    @classmethod
    def get(cls, domain: str, name: str) -> Optional[SubAgentDefinition]:
        """按 domain + name 获取 SubAgent"""
        domain_agents = cls._registry.get(domain)
        if not domain_agents:
            return None
        return domain_agents.get(name)

    @classmethod
    def get_by_domain(cls, domain: str) -> List[SubAgentDefinition]:
        """获取指定 domain 下的所有 SubAgent"""
        domain_agents = cls._registry.get(domain)
        if not domain_agents:
            return []
        return list(domain_agents.values())

    @classmethod
    def get_schemas_by_domain(cls, domain: str) -> List[dict]:
        """导出指定 domain 下所有 SubAgent 的 OpenAI Tool Schema"""
        return [sa.to_tool_schema() for sa in cls.get_by_domain(domain)]

    @classmethod
    def get_multi_domain(cls, domains: List[str]) -> List[SubAgentDefinition]:
        """获取多个 domain 下的所有 SubAgent (用于 shared_domains)"""
        result: List[SubAgentDefinition] = []
        seen: set[str] = set()
        for domain in domains:
            for sa in cls.get_by_domain(domain):
                key = f"{sa.domain}:{sa.name}"
                if key not in seen:
                    seen.add(key)
                    result.append(sa)
        return result

    @classmethod
    def get_all_domains(cls) -> List[str]:
        """获取所有已注册的 domain 列表"""
        return list(cls._registry.keys())

    @classmethod
    def clear(cls) -> None:
        """清空所有注册 (主要用于测试)"""
        cls._registry.clear()

    @classmethod
    def count(cls, domain: Optional[str] = None) -> int:
        """获取注册数量"""
        if domain:
            return len(cls._registry.get(domain, {}))
        return sum(len(d) for d in cls._registry.values())
