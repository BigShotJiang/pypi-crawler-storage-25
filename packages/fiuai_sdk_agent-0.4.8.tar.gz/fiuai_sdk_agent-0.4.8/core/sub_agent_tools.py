# -- coding: utf-8 --
# Project: fiuai_sdk_agent
# Created Date: 2026-03-21
# Author: liming
# Agent: Cursor
# Email: lmlala@aliyun.com
# Copyright (c) 2025 FiuAI

"""
SubAgent Dynamic Tool Binding — LangGraph 工具绑定辅助

为 SubAgent 提供 LangGraph 原生的 Tool 绑定能力:
- resolve_sub_agent_tools(): 从 Registry 解析 SubAgent 的工具列表
- create_sub_agent_tool_node(): 创建绑定特定工具集的 LangGraph 节点

这使得每个 SubAgent 在 Graph 中拥有独立的工具上下文,
避免不同 SubAgent 的工具互相干扰。

使用方式 (中期, Graph 内使用):
    tools = resolve_sub_agent_tools(tax_code_agent)
    graph.add_node("tax_code_agent", create_react_agent(model, tools=tools))
"""

from typing import Any, Callable, Dict, List, Optional

from .sub_agent import SubAgentDefinition
from ..utils.logger import get_logger

logger = get_logger(__name__)


def resolve_sub_agent_tools(
    definition: SubAgentDefinition,
) -> List[Dict[str, Any]]:
    """
    解析 SubAgent 声明的工具, 返回 OpenAI Tool Schema 列表

    从 SkillRegistry 和 ToolRegistry 按名称查找,
    适用于 LangGraph Dynamic Tool Binding 场景

    Args:
        definition: SubAgent 定义

    Returns:
        OpenAI Tool Schema 列表
    """
    return definition._collect_tool_schemas()


def resolve_sub_agent_callables(
    definition: SubAgentDefinition,
) -> Dict[str, Callable]:
    """
    解析 SubAgent 声明的工具, 返回 name -> callable 映射

    适用于需要直接调用工具的场景

    Args:
        definition: SubAgent 定义

    Returns:
        {tool_name: async_callable} 映射
    """
    from .skill import SkillRegistry

    callables: Dict[str, Callable] = {}

    for tool_name in definition.tools:
        skill = SkillRegistry.get(tool_name)
        if skill:
            callables[tool_name] = skill.func
            continue

        try:
            from agents.tools.registry import ToolRegistry
            tool_def = ToolRegistry.get(tool_name)
            if tool_def:
                callables[tool_name] = tool_def.func
                continue
        except ImportError:
            pass

        logger.warning(
            f"resolve_sub_agent_callables: tool '{tool_name}' "
            f"not found for SubAgent '{definition.name}'"
        )

    return callables


def get_tool_binding_summary(
    definition: SubAgentDefinition,
) -> Dict[str, Any]:
    """
    获取 SubAgent 的工具绑定摘要 (用于调试/日志)

    Returns:
        {"name": str, "domain": str, "tools": [...], "resolved": int, "missing": [...]}
    """
    schemas = resolve_sub_agent_tools(definition)
    resolved_names = {s["function"]["name"] for s in schemas}
    missing = [t for t in definition.tools if t not in resolved_names]

    return {
        "name": definition.name,
        "domain": definition.domain,
        "tools": definition.tools,
        "resolved": len(schemas),
        "missing": missing,
    }
