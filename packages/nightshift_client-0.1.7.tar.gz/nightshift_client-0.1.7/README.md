# nightshift-client

`nightshift-client` is the client-side Python package for the Nightshift tracker.

## Installation

```bash
cd nightshift-client
pip install -e .
```

## Python API

```python
from nightshift_client import NightshiftClient

client = NightshiftClient(repo_path=".", identity="user@example.com")
```

### Issue Creation

```python
issue_id = client.create_issue("Fix the bug", "Detailed description here")
client.push()
```

### Monitoring State

```python
state = client.check_state(issue_id)
# Returns: "open", "working", "waiting:question", "waiting:review", 
#          "waiting:human-review", "suspended:*", "closed", etc.
```

### Q&A Flow

```python
question = client.get_pending_question(issue_id)
if question:
    client.post_answer(issue_id, "The answer is 42")
    client.push()
```

### Remote Commands

Trigger orchestration commands on the nightshift host via tracker comments.
These post `@nightshift <command>` comments that the watcher scans and executes.

```python
# Accept completed work (merge agent branch to master)
client.accept(issue_id)

# Reject work (discard agent branch)
client.reject(issue_id)

# Request revisions with feedback
client.revise(issue_id, "Please add error handling for the edge case")

# Resume a suspended session
client.resume(issue_id)
client.resume(issue_id, prompt="Continue from where you left off")
```

**Protocol:** Each method posts a comment (e.g., `@nightshift accept`) and pushes.
The watcher scans for these comments during sync and executes the corresponding
CLI command. Result comments (`✓ Accepted` or `✗ Failed: ...`) are posted back.

### Sync

```python
client.push()  # Push local changes to remote
client.pull()  # Pull remote changes
```

## CLI usage

```bash
nightshift-client daemon status --repo .
nightshift-client daemon start --repo .
nightshift-client daemon stop --repo .
```
