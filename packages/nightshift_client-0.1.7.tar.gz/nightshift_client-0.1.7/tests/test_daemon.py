"""Tests for TrackerWriterDaemon."""

from unittest.mock import patch

from nightshift_client._daemon import _GitBugTrackerAdapter


class TestGitBugTrackerAdapter:
    """Tests for _GitBugTrackerAdapter."""

    def test_daemon_passes_identity_to_gitbug(self):
        """_GitBugTrackerAdapter passes identity to GitBug."""
        with patch("nightshift_client._daemon.GitBug") as mock_gitbug_cls:
            _GitBugTrackerAdapter(repo_path="/repo")

        mock_gitbug_cls.assert_called_once_with(
            "/repo", identity="nightshift-daemon"
        )
