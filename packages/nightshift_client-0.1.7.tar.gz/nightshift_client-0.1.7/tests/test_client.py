"""Tests for NightshiftClient."""

from unittest.mock import MagicMock, patch

import pytest

from nightshift_client import NightshiftClient
from nightshift_client.exceptions import AuthError


@pytest.fixture
def mock_gitbug():
    """Fixture that patches GitBug to prevent subprocess calls."""
    with patch("nightshift_client.GitBug") as mock_cls:
        mock_instance = MagicMock()
        mock_cls.return_value = mock_instance
        yield mock_instance


class TestClientInit:
    """Tests for NightshiftClient initialization."""

    def test_client_init_requires_identity(self):
        """NightshiftClient raises AuthError when identity is not provided."""
        with pytest.raises(AuthError, match="identity"):
            NightshiftClient(repo_path="/repo", identity="")

        with pytest.raises(AuthError, match="identity"):
            NightshiftClient(repo_path="/repo", identity=None)

    def test_client_init_stores_identity(self):
        """NightshiftClient stores identity and repo_path."""
        with patch("nightshift_client.GitBug"):
            client = NightshiftClient(repo_path="/repo", identity="user@example.com")
        assert client.repo_path == "/repo"
        assert client.identity == "user@example.com"

    def test_client_passes_identity_to_gitbug(self):
        """NightshiftClient passes identity to GitBug."""
        with patch("nightshift_client.GitBug") as mock_gitbug_cls:
            NightshiftClient(repo_path="/repo", identity="user@example.com")

        mock_gitbug_cls.assert_called_once_with(
            repo_path="/repo", identity="nightshift-client"
        )


class TestCreateIssue:
    """Tests for NightshiftClient.create_issue()."""

    def test_create_issue_returns_id(self, mock_gitbug):
        """create_issue() returns the issue ID from GitBug."""
        mock_gitbug.add.return_value = "abc123def456"
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        issue_id = client.create_issue("Test title", "Test body")

        assert issue_id == "abc123def456"
        mock_gitbug.add.assert_called_once()

    def test_create_issue_adds_nightshift_label(self, mock_gitbug):
        """create_issue() automatically adds 'nightshift' label."""
        mock_gitbug.add.return_value = "abc123"
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        client.create_issue("Title", "Body")

        call_args = mock_gitbug.add.call_args
        labels = call_args.kwargs.get("labels", [])
        assert "nightshift" in labels

    def test_create_issue_adds_nightshift_to_existing_labels(self, mock_gitbug):
        """create_issue() adds 'nightshift' to user-provided labels."""
        mock_gitbug.add.return_value = "abc123"
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        client.create_issue("Title", "Body", labels=["bug", "urgent"])

        labels = mock_gitbug.add.call_args.kwargs.get("labels", [])
        assert "nightshift" in labels
        assert "bug" in labels
        assert "urgent" in labels

    def test_create_issue_does_not_duplicate_nightshift_label(self, mock_gitbug):
        """create_issue() doesn't duplicate 'nightshift' if already present."""
        mock_gitbug.add.return_value = "abc123"
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        client.create_issue("Title", "Body", labels=["nightshift", "bug"])

        labels = mock_gitbug.add.call_args.kwargs.get("labels", [])
        assert labels.count("nightshift") == 1


class TestPush:
    """Tests for NightshiftClient.push()."""

    def test_push_calls_gitbug(self, mock_gitbug):
        """push() delegates to GitBug.push()."""
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        client.push()

        mock_gitbug.push.assert_called_once()


class TestPull:
    """Tests for NightshiftClient.pull()."""

    def test_pull_fetches_changes(self, mock_gitbug):
        """pull() delegates to GitBug.pull()."""
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        client.pull()

        mock_gitbug.pull.assert_called_once()


class TestCheckState:
    """Tests for NightshiftClient.check_state()."""

    def test_check_state_returns_status(self, mock_gitbug):
        """check_state() returns the state derived from labels."""
        mock_issue = {
            "id": "abc123",
            "labels": ["nightshift", "status:working"],
            "comments": [],
        }
        mock_gitbug.show.return_value = mock_issue
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        state = client.check_state("abc123")

        assert state == "working"

    def test_check_state_fetches_first(self, mock_gitbug):
        """check_state() calls pull() before reading state."""
        call_order = []
        mock_issue = {
            "id": "abc123",
            "labels": ["nightshift"],
            "comments": [],
        }

        def track_pull():
            call_order.append("pull")

        def track_show(issue_id):
            call_order.append("show")
            return mock_issue

        mock_gitbug.pull.side_effect = track_pull
        mock_gitbug.show.side_effect = track_show
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        client.check_state("abc123")

        assert call_order == ["pull", "show"]


class TestGetIssueInfo:
    """Tests for NightshiftClient.get_issue_info()."""

    def test_get_issue_info_returns_dict(self, mock_gitbug):
        """get_issue_info() returns dict with expected keys."""
        mock_issue = {
            "id": "abc123",
            "labels": ["nightshift", "status:reviewing"],
            "comments": [],
            "create_time": "2026-04-29T10:00:00Z",
            "edit_time": "2026-04-29T12:00:00Z",
        }
        mock_gitbug.show.return_value = mock_issue
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        info = client.get_issue_info("abc123")

        assert isinstance(info, dict)
        assert info["state"] == "reviewing"
        assert info["labels"] == ["nightshift", "status:reviewing"]
        assert "last_comment" in info
        assert "updated_at" in info

    def test_get_issue_info_includes_last_comment(self, mock_gitbug):
        """get_issue_info() includes the last comment text."""
        mock_issue = {
            "id": "abc123",
            "labels": ["nightshift"],
            "comments": [
                {"message": "First comment", "timestamp": "2026-04-29T10:00:00Z"},
                {"message": "Latest comment", "timestamp": "2026-04-29T12:00:00Z"},
            ],
            "create_time": "2026-04-29T09:00:00Z",
            "edit_time": "2026-04-29T12:00:00Z",
        }
        mock_gitbug.show.return_value = mock_issue
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        info = client.get_issue_info("abc123")

        assert info["last_comment"] == "Latest comment"


class TestGetPendingQuestion:
    """Tests for NightshiftClient.get_pending_question()."""

    def test_get_pending_question_returns_text(self, mock_gitbug):
        """get_pending_question() returns question text when needs-human-input label present."""
        mock_issue = {
            "id": "abc123",
            "labels": ["nightshift", "needs-human-input"],
            "comments": [
                {"message": "First comment", "timestamp": "2026-04-29T10:00:00Z"},
                {"message": "What is the API key?", "timestamp": "2026-04-29T12:00:00Z"},
            ],
        }
        mock_gitbug.show.return_value = mock_issue
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        question = client.get_pending_question("abc123")

        assert question == "What is the API key?"

    def test_get_pending_question_none_if_no_question(self, mock_gitbug):
        """get_pending_question() returns None when no needs-human-input label."""
        mock_issue = {
            "id": "abc123",
            "labels": ["nightshift", "status:working"],
            "comments": [
                {"message": "Some comment", "timestamp": "2026-04-29T10:00:00Z"},
            ],
        }
        mock_gitbug.show.return_value = mock_issue
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        question = client.get_pending_question("abc123")

        assert question is None


class TestPostAnswer:
    """Tests for NightshiftClient.post_answer()."""

    def test_post_answer_adds_comment(self, mock_gitbug):
        """post_answer() adds comment via GitBug."""
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        client.post_answer("abc123", "The API key is 12345")

        mock_gitbug.comment.assert_called_once_with("abc123", "The API key is 12345")

    def test_post_answer_uses_identity(self, mock_gitbug):
        """post_answer() uses the configured identity (no explicit identity param needed)."""
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        client.post_answer("abc123", "Answer here")

        mock_gitbug.comment.assert_called_once()
        assert client.identity == "user@example.com"


class TestReadFile:
    """Tests for NightshiftClient.read_file()."""

    def test_read_file_returns_content(self, tmp_path, mock_gitbug):
        """read_file() returns the file contents relative to repo_path."""
        repo = tmp_path / "repo"
        repo.mkdir()
        (repo / "notes.txt").write_text("hello world", encoding="utf-8")
        client = NightshiftClient(repo_path=repo, identity="user@example.com")

        content = client.read_file("notes.txt")

        assert content == "hello world"

    def test_read_file_raises_on_missing(self, tmp_path, mock_gitbug):
        """read_file() raises FileNotFoundError for missing files."""
        repo = tmp_path / "repo"
        repo.mkdir()
        client = NightshiftClient(repo_path=repo, identity="user@example.com")

        with pytest.raises(FileNotFoundError):
            client.read_file("missing.txt")

    def test_read_file_raises_on_escape_attempt(self, tmp_path, mock_gitbug):
        """read_file() rejects paths outside repo_path."""
        repo = tmp_path / "repo"
        repo.mkdir()
        outside = tmp_path / "outside.txt"
        outside.write_text("secret", encoding="utf-8")
        client = NightshiftClient(repo_path=repo, identity="user@example.com")

        with pytest.raises(FileNotFoundError):
            client.read_file("../outside.txt")


class TestCancel:
    """Tests for NightshiftClient.cancel()."""

    def test_cancel_adds_label(self, mock_gitbug):
        """cancel() adds the status:cancelled label without waiting."""
        client = NightshiftClient(repo_path="/repo", identity="user@example.com")

        client.cancel("abc123")

        mock_gitbug.label.assert_called_once_with("abc123", "status:cancelled")
