"""Tests for git-bug CLI wrapper."""

import subprocess
from unittest.mock import MagicMock, patch

import pytest

from nightshift_client._gitbug import GitBug
from nightshift_client.exceptions import TrackerError


class TestGitBugAdd:
    """Tests for GitBug.add()."""

    def test_add_creates_issue_then_labels(self):
        """add() calls bug new without -l, then calls label() for each label."""
        gb = GitBug(repo_path="/repo")

        call_sequence = []

        def track_calls(*args, **kwargs):
            cmd = args[0]
            call_sequence.append(cmd)
            mock_result = MagicMock()
            mock_result.returncode = 0
            mock_result.stderr = ""
            if "new" in cmd and "bug" in cmd:
                mock_result.stdout = "abc123def456\n"
            else:
                mock_result.stdout = ""
            return mock_result

        with patch("subprocess.run", side_effect=track_calls):
            issue_id = gb.add("Test title", "Test body", ["bug", "urgent"])

        assert issue_id == "abc123def456"
        assert len(call_sequence) == 3

        new_cmd = call_sequence[0]
        assert new_cmd[0] == "git-bug"
        assert "bug" in new_cmd
        assert "new" in new_cmd
        assert "-t" in new_cmd
        assert "Test title" in new_cmd
        assert "-m" in new_cmd
        assert "Test body" in new_cmd
        assert "-l" not in new_cmd

        label_cmd_1 = call_sequence[1]
        assert "label" in label_cmd_1
        assert "new" in label_cmd_1
        assert "abc123def456" in label_cmd_1
        assert "bug" in label_cmd_1

        label_cmd_2 = call_sequence[2]
        assert "label" in label_cmd_2
        assert "new" in label_cmd_2
        assert "abc123def456" in label_cmd_2
        assert "urgent" in label_cmd_2

    def test_gitbug_add_without_labels(self):
        """add() works without labels."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "def789\n"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            issue_id = gb.add("Title", "Body")

        assert issue_id == "def789"
        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert "new" in cmd
        assert "-l" not in cmd

    def test_gitbug_add_raises_on_failure(self):
        """add() raises TrackerError on CLI failure."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = "git-bug: error\n"

        with patch("subprocess.run", return_value=mock_result):
            with pytest.raises(TrackerError, match="git-bug.*failed"):
                gb.add("Title", "Body")


class TestGitBugIdentity:
    """Tests for identity configuration."""

    def test_identity_created_on_init(self):
        """GitBug with identity param calls git-bug user new/adopt."""
        call_sequence = []

        def track_calls(*args, **kwargs):
            cmd = args[0]
            call_sequence.append(cmd)
            mock_result = MagicMock()
            mock_result.returncode = 0
            mock_result.stderr = ""
            if "user" in cmd and "ls" in cmd:
                mock_result.stdout = ""
            else:
                mock_result.stdout = ""
            return mock_result

        with patch("subprocess.run", side_effect=track_calls):
            GitBug(repo_path="/repo", identity="nightshift-bot")

        assert len(call_sequence) == 2
        ls_cmd = call_sequence[0]
        assert "user" in ls_cmd
        assert "ls" in ls_cmd

        new_cmd = call_sequence[1]
        assert "user" in new_cmd
        assert "new" in new_cmd
        assert "-n" in new_cmd
        assert "nightshift-bot" in new_cmd

    def test_identity_new_uses_non_interactive_flag(self):
        """git-bug user new is called with --non-interactive flag."""
        call_sequence = []

        def track_calls(*args, **kwargs):
            cmd = args[0]
            call_sequence.append(cmd)
            mock_result = MagicMock()
            mock_result.returncode = 0
            mock_result.stderr = ""
            if "user" in cmd and "ls" in cmd:
                mock_result.stdout = ""
            else:
                mock_result.stdout = ""
            return mock_result

        with patch("subprocess.run", side_effect=track_calls):
            GitBug(repo_path="/repo", identity="nightshift-bot")

        new_cmd = call_sequence[1]
        assert "user" in new_cmd
        assert "new" in new_cmd
        assert "--non-interactive" in new_cmd

    def test_identity_adopted_if_exists(self):
        """GitBug adopts existing identity instead of creating new."""
        call_sequence = []

        def track_calls(*args, **kwargs):
            cmd = args[0]
            call_sequence.append(cmd)
            mock_result = MagicMock()
            mock_result.returncode = 0
            mock_result.stderr = ""
            if "user" in cmd and "ls" in cmd:
                mock_result.stdout = "nightshift-bot\nother-user\n"
            else:
                mock_result.stdout = ""
            return mock_result

        with patch("subprocess.run", side_effect=track_calls):
            GitBug(repo_path="/repo", identity="nightshift-bot")

        assert len(call_sequence) == 2
        adopt_cmd = call_sequence[1]
        assert "user" in adopt_cmd
        assert "adopt" in adopt_cmd
        assert "nightshift-bot" in adopt_cmd

    def test_no_identity_skips_setup(self):
        """GitBug without identity param does not call user commands."""
        with patch("subprocess.run") as mock_run:
            GitBug(repo_path="/repo")

        mock_run.assert_not_called()


class TestGitBugComment:
    """Tests for GitBug.comment()."""

    def test_gitbug_comment_adds_comment(self):
        """comment() adds a comment to an issue."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            gb.comment("abc123", "My comment text")

        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "git-bug"
        assert "comment" in cmd
        assert "new" in cmd
        assert "abc123" in cmd
        assert "-m" in cmd
        assert "My comment text" in cmd

    def test_gitbug_comment_raises_on_failure(self):
        """comment() raises TrackerError on CLI failure."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = "error\n"

        with patch("subprocess.run", return_value=mock_result):
            with pytest.raises(TrackerError, match="Failed to add comment"):
                gb.comment("abc123", "Comment")


class TestGitBugLabel:
    """Tests for GitBug.label()."""

    def test_gitbug_label_adds_label(self):
        """label() adds a label to an issue."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            gb.label("abc123", "nightshift")

        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "git-bug"
        assert "label" in cmd
        assert "new" in cmd
        assert "abc123" in cmd
        assert "nightshift" in cmd

    def test_gitbug_label_ignores_already_set(self):
        """label() ignores 'already set' errors (rc=1 with specific message)."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 1
        mock_result.stdout = ""
        mock_result.stderr = "label already set\n"

        with patch("subprocess.run", return_value=mock_result):
            gb.label("abc123", "nightshift")


class TestGitBugRetry:
    """Tests for lock retry behavior."""

    def test_gitbug_retry_on_lock(self):
        """Operations retry on lock contention with exponential backoff."""
        gb = GitBug(repo_path="/repo")

        locked_result = MagicMock()
        locked_result.returncode = 1
        locked_result.stdout = ""
        locked_result.stderr = "already locked by the process pid 12345\n"

        success_result = MagicMock()
        success_result.returncode = 0
        success_result.stdout = "abc123\n"
        success_result.stderr = ""

        with patch("subprocess.run", side_effect=[locked_result, success_result]) as mock_run:
            with patch("time.sleep") as mock_sleep:
                issue_id = gb.add("Title", "Body")

        assert issue_id == "abc123"
        assert mock_run.call_count == 2
        mock_sleep.assert_called_once_with(1)

    def test_gitbug_retry_exponential_backoff(self):
        """Lock retries use exponential backoff (1, 2, 4, 8...)."""
        gb = GitBug(repo_path="/repo")

        locked_result = MagicMock()
        locked_result.returncode = 1
        locked_result.stdout = ""
        locked_result.stderr = "already locked by the process pid 999\n"

        success_result = MagicMock()
        success_result.returncode = 0
        success_result.stdout = "xyz789\n"
        success_result.stderr = ""

        with patch(
            "subprocess.run",
            side_effect=[locked_result, locked_result, locked_result, success_result],
        ) as mock_run:
            with patch("time.sleep") as mock_sleep:
                issue_id = gb.add("Title", "Body")

        assert issue_id == "xyz789"
        assert mock_run.call_count == 4
        assert mock_sleep.call_count == 3
        mock_sleep.assert_any_call(1)
        mock_sleep.assert_any_call(2)
        mock_sleep.assert_any_call(4)

    def test_gitbug_retry_exhausted(self):
        """Raises TrackerError after all retries exhausted."""
        gb = GitBug(repo_path="/repo")

        locked_result = MagicMock()
        locked_result.returncode = 1
        locked_result.stdout = ""
        locked_result.stderr = "already locked by the process pid 999\n"

        with patch("subprocess.run", return_value=locked_result):
            with patch("time.sleep"):
                with pytest.raises(TrackerError, match="lock contention"):
                    gb.add("Title", "Body")


class TestGitBugTimeout:
    """Tests for timeout handling."""

    def test_gitbug_timeout_raises_tracker_error(self):
        """Timeout raises TrackerError."""
        gb = GitBug(repo_path="/repo")

        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("git-bug", 30)):
            with pytest.raises(TrackerError, match="timed out"):
                gb.add("Title", "Body")


class TestGitBugSync:
    """Tests for push/pull sync operations."""

    def test_push_uses_git_not_gitbug(self):
        """push() calls git push with refs/bugs/* and refs/identities/* refspecs."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            gb.push()

        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "git"
        assert cmd[1] == "push"
        assert cmd[2] == "origin"
        assert "refs/bugs/*:refs/bugs/*" in cmd
        assert "refs/identities/*:refs/identities/*" in cmd
        assert "git-bug" not in cmd
        assert mock_run.call_args[1]["cwd"] == "/repo"

    def test_push_uses_specified_remote(self):
        """push(remote="yoga14") passes "yoga14" to git push."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            gb.push(remote="yoga14")

        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "git"
        assert cmd[1] == "push"
        assert cmd[2] == "yoga14"
        assert "refs/bugs/*:refs/bugs/*" in cmd
        assert "refs/identities/*:refs/identities/*" in cmd

    def test_push_raises_on_failure(self):
        """push() raises TrackerError on git push failure."""
        gb = GitBug(repo_path="/repo")

        with patch("subprocess.run", side_effect=subprocess.CalledProcessError(1, "git", stderr="error")):
            with pytest.raises(TrackerError, match="git push failed"):
                gb.push()

    def test_push_raises_on_timeout(self):
        """push() raises TrackerError on timeout."""
        gb = GitBug(repo_path="/repo")

        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("git", 30)):
            with pytest.raises(TrackerError, match="timed out"):
                gb.push()

    def test_pull_uses_git_not_gitbug(self):
        """pull() calls git fetch with refs/bugs/* and refs/identities/* refspecs."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            gb.pull()

        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "git"
        assert cmd[1] == "fetch"
        assert cmd[2] == "origin"
        assert "refs/bugs/*:refs/bugs/*" in cmd
        assert "refs/identities/*:refs/identities/*" in cmd
        assert "git-bug" not in cmd
        assert mock_run.call_args[1]["cwd"] == "/repo"

    def test_pull_uses_specified_remote(self):
        """pull(remote="yoga14") passes "yoga14" to git fetch."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            gb.pull(remote="yoga14")

        mock_run.assert_called_once()
        cmd = mock_run.call_args[0][0]
        assert cmd[0] == "git"
        assert cmd[1] == "fetch"
        assert cmd[2] == "yoga14"
        assert "refs/bugs/*:refs/bugs/*" in cmd
        assert "refs/identities/*:refs/identities/*" in cmd

    def test_pull_raises_on_failure(self):
        """pull() raises TrackerError on git fetch failure."""
        gb = GitBug(repo_path="/repo")

        with patch("subprocess.run", side_effect=subprocess.CalledProcessError(1, "git", stderr="error")):
            with pytest.raises(TrackerError, match="git fetch failed"):
                gb.pull()

    def test_pull_raises_on_timeout(self):
        """pull() raises TrackerError on timeout."""
        gb = GitBug(repo_path="/repo")

        with patch("subprocess.run", side_effect=subprocess.TimeoutExpired("git", 30)):
            with pytest.raises(TrackerError, match="timed out"):
                gb.pull()


class TestGitBugList:
    """Tests for listing issues."""

    def test_gitbug_list_returns_issues(self):
        """list() returns parsed issue dicts from git-bug bug ls."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = '[{"id": "abc123", "title": "Bug one"}, {"id": "def456", "title": "Bug two"}]'
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            issues = gb.list()

        assert len(issues) == 2
        assert issues[0]["id"] == "abc123"
        assert issues[1]["title"] == "Bug two"
        cmd = mock_run.call_args[0][0]
        assert cmd == ["git-bug", "bug", "-f", "json"]

    def test_gitbug_list_with_label_filter(self):
        """list(labels=["foo"]) passes label filter to git-bug."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = '[{"id": "abc123", "title": "Labeled bug"}]'
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            issues = gb.list(labels=["nightshift", "urgent"])

        assert len(issues) == 1
        cmd = mock_run.call_args[0][0]
        assert "git-bug" in cmd
        assert "label:nightshift" in cmd
        assert "label:urgent" in cmd

    def test_gitbug_list_empty_returns_empty_list(self):
        """list() returns empty list when no issues."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = ""
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result):
            issues = gb.list()

        assert issues == []

    def test_gitbug_list_handles_invalid_json(self):
        """list() raises TrackerError on invalid JSON output."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "not valid json"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result):
            with pytest.raises(TrackerError, match="parse"):
                gb.list()


class TestGitBugShow:
    """Tests for showing issue details."""

    def test_gitbug_show_returns_issue(self):
        """show() returns parsed issue dict from git-bug bug show."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = '{"id": "abc123", "title": "Test issue", "labels": ["nightshift"]}'
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result) as mock_run:
            issue = gb.show("abc123")

        assert issue["id"] == "abc123"
        assert issue["title"] == "Test issue"
        assert issue["labels"] == ["nightshift"]
        cmd = mock_run.call_args[0][0]
        assert cmd == ["git-bug", "bug", "show", "abc123", "-f", "json"]

    def test_gitbug_show_handles_invalid_json(self):
        """show() raises TrackerError on invalid JSON output."""
        gb = GitBug(repo_path="/repo")
        mock_result = MagicMock()
        mock_result.returncode = 0
        mock_result.stdout = "not valid json"
        mock_result.stderr = ""

        with patch("subprocess.run", return_value=mock_result):
            with pytest.raises(TrackerError, match="parse"):
                gb.show("abc123")
