"""Tests for package metadata and installation."""

from importlib import metadata


def test_package_importable():
    import nightshift_client

    assert nightshift_client.__name__ == "nightshift_client"
    assert hasattr(nightshift_client, "NightshiftClient")


def test_version_defined():
    assert metadata.version("nightshift-client")


def test_cli_entry_point():
    entry_points = metadata.entry_points(group="console_scripts")
    entry_point = next(ep for ep in entry_points if ep.name == "nightshift-client")

    assert entry_point.value == "nightshift_client.cli:main"
    assert entry_point.load().__name__ == "main"
