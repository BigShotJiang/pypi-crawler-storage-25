#!/usr/bin/env python3
"""
AIBrain Workflow: Learning Extractor — automatically grow the brain from activity.

Scans recent activity and extracts learnings into aibrain memories. Works for
any user, any domain. Runs daily or after significant work sessions.

What it extracts:
  1. Error → Fix patterns: when something broke and was fixed, save the pattern
  2. Corrections: when a value/approach was wrong and corrected, save the lesson
  3. Decisions: significant choices with rationale, save for future reference
  4. Discoveries: new facts learned about systems, APIs, tools
  5. Recurring patterns: things that keep happening the same way

Sources it reads:
  - pattern_bus_events table (domain events from all systems)
  - memories table (recent memories that look like findings/fixes)
  - git log (recent commit messages with "fix", "revert", "correct")

Usage:
    python learning_extractor.py                # Full extraction
    python learning_extractor.py --dry-run      # Preview what would be saved
    python learning_extractor.py --since 24     # Hours to look back (default: 24)
    python learning_extractor.py --source git   # Only extract from git
"""

import argparse
import json
import os
import re
import sqlite3
import subprocess
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute

from aibrain_db import AIBRAIN_ROOT, get_db as _canonical_get_db
CONFIG = {}
cfg_path = AIBRAIN_ROOT / "config.json"
if cfg_path.exists():
    try:
        CONFIG = json.loads(cfg_path.read_text(encoding="utf-8"))
    except Exception:
        pass


def _find_db():
    """Find the best DB, checking both old and new names."""
    for name in ["aibrain.db"]:
        p = Path(CONFIG.get("db_path", str(AIBRAIN_ROOT / name)))
        if p.exists():
            return str(p)
    # Check configured path
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    return str(AIBRAIN_ROOT / "aibrain.db")


DB_PATH = _find_db()


def get_db():
    return _canonical_get_db()


# ---------------------------------------------------------------------------
# Learning extraction from pattern_bus_events
# ---------------------------------------------------------------------------

def extract_from_events(hours: int = 24) -> list:
    """Extract learnings from pattern_bus_events."""
    learnings = []
    conn = get_db()

    # Check if pattern_bus_events exists
    tables = [r[0] for r in conn.execute(
        "SELECT name FROM sqlite_master WHERE type='table'").fetchall()]
    if "pattern_bus_events" not in tables:
        return learnings

    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()

    # Look for error → resolution pairs
    events = conn.execute("""
        SELECT event_type, key, value, metadata, domain, timestamp
        FROM pattern_bus_events
        WHERE timestamp > ?
        ORDER BY timestamp
    """, (cutoff,)).fetchall()

    # Group events by domain and key to find patterns
    domain_events = {}
    for e in events:
        d = e["domain"] or "unknown"
        if d not in domain_events:
            domain_events[d] = []
        domain_events[d].append(dict(e))

    # Extract fix patterns: error followed by resolution
    for domain, evts in domain_events.items():
        errors = [e for e in evts if "error" in (e["event_type"] or "").lower()
                  or "fail" in (e["event_type"] or "").lower()]
        fixes = [e for e in evts if "fix" in (e["event_type"] or "").lower()
                 or "resolve" in (e["event_type"] or "").lower()
                 or "success" in (e["event_type"] or "").lower()]

        for error in errors:
            # Find a fix that came after this error with the same key
            matching_fix = next(
                (f for f in fixes if f["key"] == error["key"]
                 and f["timestamp"] > error["timestamp"]),
                None
            )
            if matching_fix:
                learnings.append({
                    "type": "pattern",
                    "name": f"fix_{domain}_{error['key'][:40]}",
                    "content": (
                        f"Error→Fix in {domain}: {error['key']} failed "
                        f"({error['value'][:200] if error['value'] else 'no detail'}), "
                        f"resolved by: {matching_fix['value'][:200] if matching_fix['value'] else 'no detail'}"
                    ),
                    "tags": f"learning,fix,{domain},auto-extracted",
                    "importance": 0.6,
                    "source": "events",
                })

    # Extract significant decisions (high-value events)
    for domain, evts in domain_events.items():
        decisions = [e for e in evts if "decision" in (e["event_type"] or "").lower()
                     or "config" in (e["event_type"] or "").lower()
                     or "deploy" in (e["event_type"] or "").lower()]
        for d in decisions:
            learnings.append({
                "type": "decision",
                "name": f"decision_{domain}_{d['key'][:40]}",
                "content": (
                    f"Decision in {domain}: {d['key']} = {d['value'][:300] if d['value'] else 'N/A'}. "
                    f"Context: {d['metadata'][:200] if d['metadata'] else 'none'}"
                ),
                "tags": f"learning,decision,{domain},auto-extracted",
                "importance": 0.5,
                "source": "events",
            })

    return learnings


# ---------------------------------------------------------------------------
# Learning extraction from recent memories (corrections, findings)
# ---------------------------------------------------------------------------

def extract_from_memories(hours: int = 24) -> list:
    """Find recent memories that contain corrections or discoveries."""
    learnings = []
    conn = get_db()

    cutoff = (datetime.now(timezone.utc) - timedelta(hours=hours)).strftime("%Y-%m-%d %H:%M:%S")

    # Look for memories that indicate corrections or learnings
    correction_keywords = [
        "was wrong", "corrected", "actually", "not a regression",
        "false positive", "FP", "root cause", "lesson learned",
        "discovered", "turns out", "realized", "fix", "bug"
    ]

    recent = conn.execute("""
        SELECT id, name, type, content, tags, created, importance
        FROM memories
        WHERE active=1 AND created > ? AND memory_class IN ('episodic', 'semantic')
        ORDER BY created DESC
        LIMIT 100
    """, (cutoff,)).fetchall()

    for m in recent:
        content_lower = (m["content"] or "").lower()
        name_lower = (m["name"] or "").lower()

        # Check if this memory contains correction/learning signals
        signals = [kw for kw in correction_keywords if kw.lower() in content_lower]
        if signals and "auto-extracted" not in (m["tags"] or ""):
            # This memory IS a learning — flag it as high importance if not already
            if (m["importance"] or 0.5) < 0.7:
                conn.execute(
                    "UPDATE memories SET importance=0.7, updated=datetime('now') WHERE id=?",
                    (m["id"],)
                )
                learnings.append({
                    "type": "boost",
                    "name": m["name"],
                    "content": f"Boosted importance of memory '{m['name']}' (signals: {', '.join(signals[:3])})",
                    "tags": "learning,importance-boost,auto-extracted",
                    "importance": 0.7,
                    "source": "memory-scan",
                    "existing_id": m["id"],
                })

    conn.commit()
    return learnings


# ---------------------------------------------------------------------------
# Learning extraction from git log
# ---------------------------------------------------------------------------

def extract_from_git(hours: int = 24) -> list:
    """Extract learnings from recent git commit messages."""
    learnings = []

    # Find git repos to scan
    repos = []
    # Scan configured repos or auto-discover from projects directory
    scan_names = CONFIG.get("git_scan_repos", [])
    for name in scan_names:
        repo_path = AIBRAIN_ROOT.parent / name if AIBRAIN_ROOT.name != name else AIBRAIN_ROOT
        if (repo_path / ".git").exists():
            repos.append(repo_path)
    # Always include the aibrain root itself
    if (AIBRAIN_ROOT / ".git").exists() and AIBRAIN_ROOT not in repos:
        repos.append(AIBRAIN_ROOT)

    # Also check home/projects
    projects = Path.home() / "projects"
    if projects.exists():
        for d in projects.iterdir():
            if d.is_dir() and (d / ".git").exists() and d not in repos:
                repos.append(d)

    since = f"{hours} hours ago"

    for repo in repos:
        try:
            result = subprocess.run(
                ["git", "log", f"--since={since}", "--oneline", "--no-merges"],
                cwd=str(repo), capture_output=True, text=True, timeout=10
            )
            if result.returncode != 0:
                continue

            for line in result.stdout.strip().split("\n"):
                if not line.strip():
                    continue

                commit_hash = line[:7]
                msg = line[8:].strip() if len(line) > 8 else ""
                msg_lower = msg.lower()

                # Extract fix/revert/security patterns
                if any(kw in msg_lower for kw in ["fix", "revert", "security", "vulnerability",
                                                    "regression", "hotfix", "patch", "correct"]):
                    learnings.append({
                        "type": "pattern",
                        "name": f"git_{repo.name}_{commit_hash}",
                        "content": (
                            f"Fix/change in {repo.name}: {msg}. "
                            f"Commit: {commit_hash}"
                        ),
                        "tags": f"learning,git,{repo.name},auto-extracted",
                        "importance": 0.5,
                        "source": "git",
                    })

        except (subprocess.TimeoutExpired, FileNotFoundError):
            continue

    return learnings


# ---------------------------------------------------------------------------
# Deduplication — don't save what we already know
# ---------------------------------------------------------------------------

def deduplicate(learnings: list, conn: sqlite3.Connection) -> list:
    """Remove learnings that are already stored (by name prefix match)."""
    if not learnings:
        return learnings

    existing = set()
    for row in conn.execute(
        "SELECT name FROM memories WHERE active=1 AND tags LIKE '%auto-extracted%'"  # noqa:like-wildcard-injection — hardcoded static substrings, no user input
    ).fetchall():
        existing.add(row[0])

    return [l for l in learnings if l["name"] not in existing and l.get("type") != "boost"]


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def run(hours: int = 24, dry_run: bool = False, source: str = "all") -> dict:
    """Run the learning extractor."""
    all_learnings = []

    if source in ("all", "events"):
        all_learnings.extend(extract_from_events(hours))
    if source in ("all", "memories"):
        all_learnings.extend(extract_from_memories(hours))
    if source in ("all", "git"):
        all_learnings.extend(extract_from_git(hours))

    # Deduplicate against existing memories
    conn = get_db()
    new_learnings = deduplicate(all_learnings, conn)
    boosts = [l for l in all_learnings if l.get("type") == "boost"]

    if dry_run:
        print(f"\n=== Learning Extractor (DRY RUN) — last {hours}h ===")
        print(f"  Found: {len(all_learnings)} total, {len(new_learnings)} new, {len(boosts)} boosts")
        for l in new_learnings:
            print(f"  [{l['source']:12s}] {l['name'][:50]}")
            print(f"    {l['content'][:100]}...")
        for b in boosts:
            print(f"  [BOOST      ] {b['name'][:50]} (importance → 0.7)")
        return {"found": len(all_learnings), "new": len(new_learnings), "boosts": len(boosts), "saved": 0}

    # Save new learnings to DB
    saved = 0
    for l in new_learnings:
        try:
            conn.execute("""
                INSERT INTO memories (name, type, memory_class, tags, content, importance, created, updated, active)
                VALUES (?, ?, 'semantic', ?, ?, ?, datetime('now'), datetime('now'), 1)
            """, (l["name"], l["type"], l["tags"], l["content"], l["importance"]))
            saved += 1
        except Exception as e:
            print(f"  Warning: could not save '{l['name']}': {e}", file=sys.stderr)

    conn.commit()

    print(f"\n=== Learning Extractor — last {hours}h ===")
    print(f"  Scanned: events={source in ('all', 'events')}, "
          f"memories={source in ('all', 'memories')}, "
          f"git={source in ('all', 'git')}")
    print(f"  Found: {len(all_learnings)} total")
    print(f"  New:   {len(new_learnings)} saved to aibrain.db")
    print(f"  Boosts: {len(boosts)} memory importance increases")

    return {"found": len(all_learnings), "new": len(new_learnings),
            "boosts": len(boosts), "saved": saved}


def main():
    parser = argparse.ArgumentParser(
        description="AIBrain Learning Extractor — automatically grow the brain from activity"
    )
    parser.add_argument("--dry-run", action="store_true", help="Preview without saving")
    parser.add_argument("--since", type=int, default=24, help="Hours to look back (default: 24)")
    parser.add_argument("--source", choices=["all", "events", "memories", "git"],
                        default="all", help="Which sources to extract from")
    args = parser.parse_args()

    result = run(hours=args.since, dry_run=args.dry_run, source=args.source)
    sys.exit(0 if result["saved"] >= 0 else 1)


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='learning_extractor',
        action=_workflow_entry,
        task_type='judgment',
        actor='cli',
    )
