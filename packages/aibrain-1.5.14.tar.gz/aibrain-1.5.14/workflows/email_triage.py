#!/usr/bin/env python3
"""AIBrain Workflow: Email Triage — categorize unread emails, send priority summary."""

import sys, io

# P0-1 backfill (2026-04-11): route workflow execution through the harness
from aibrain.core.workflow_base import workflow_execute
if sys.stdout.encoding and sys.stdout.encoding.lower() not in ("utf-8", "utf8"):
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

import argparse
import datetime
import email
import imaplib
import json
import os
import re
import smtplib
import sqlite3
import sys
import urllib.request
from email.header import decode_header
from email.mime.text import MIMEText
from pathlib import Path

# ---------------------------------------------------------------------------
# Config & DB helpers
# ---------------------------------------------------------------------------

from aibrain_db import AIBRAIN_ROOT, get_db as _aibrain_get_db
_cfg_path = AIBRAIN_ROOT / "config.json"
CONFIG = json.loads(_cfg_path.read_text()) if _cfg_path.exists() else {}
def _find_db():
    """Find best DB path, checking both new and legacy names."""
    for name in ["aibrain.db"]:
        p = AIBRAIN_ROOT / name
        if p.exists():
            return str(p)
    configured = CONFIG.get("db_path")
    if configured and Path(configured).exists():
        return configured
    mem_db = AIBRAIN_ROOT / "memory" / "memory.db"
    if mem_db.exists():
        return str(mem_db)
    return str(AIBRAIN_ROOT / "aibrain.db")

MEMORY_DB = CONFIG.get("db_path", _find_db())
API_BASE = os.environ.get("AIBRAIN_API", "http://localhost:8001/api/agent")


def _load_email_creds():
    """Load email credentials from .decker_env (defensive quote stripping)."""
    creds = {}
    env_file = Path.home() / ".decker_env"
    if not env_file.exists():
        return creds
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if "=" in line and not line.startswith("#"):
            k, v = line.split("=", 1)
            creds[k.strip()] = v.strip().strip('"').strip("'")
    return creds


def log_activity(action, detail="", status="ok"):
    try:
        data = json.dumps({
            "action": action, "category": "email",
            "detail": detail, "status": status,
        }).encode()
        req = urllib.request.Request(
            f"{API_BASE}/activity", data=data,
            headers={"Content-Type": "application/json"},
        )
        urllib.request.urlopen(req, timeout=5)
    except Exception:
        pass


URGENT_KEYWORDS = {"urgent", "asap", "critical", "emergency", "down", "security", "breach", "outage"}
ACTION_KEYWORDS = {"action", "review", "approve", "confirm", "please", "request", "deadline", "respond"}
NEWSLETTER_SENDERS = {"noreply", "newsletter", "digest", "updates", "notification", "mailer", "no-reply"}

MAX_EMAILS = 100

MAX_RETRIES = 3
RETRY_BACKOFF = [2, 5, 10]


def get_db():
    db = _aibrain_get_db()
    db.execute("PRAGMA journal_mode=wal")
    db.row_factory = sqlite3.Row
    return db


def load_state(name):
    try:
        db = get_db()
        row = db.execute(
            "SELECT content FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        db.close()
        return json.loads(row["content"]) if row else {}
    except Exception:
        return {}


def save_state(name, state):
    db = get_db()
    try:
        now = datetime.datetime.now().isoformat()
        existing = db.execute(
            "SELECT id FROM memories WHERE name=? AND active=1",
            (f"workflow_state:{name}",),
        ).fetchone()
        if existing:
            db.execute("UPDATE memories SET content=?, updated=? WHERE id=?",
                       (json.dumps(state), now, existing["id"]))
        else:
            db.execute(
                "INSERT INTO memories (name,type,tags,content,created,updated,active) VALUES (?,?,?,?,?,?,1)",
                (f"workflow_state:{name}", "reference", "workflow,state",
                 json.dumps(state), now, now),
            )
        db.commit()
    except Exception:
        db.rollback()
        raise
    finally:
        db.close()


def send_email(to, subject, body, dry_run=False):
    if dry_run:
        print(f"TO: {to}\nSUBJECT: {subject}\n\n{body}")
        return
    # Prefer .decker_env creds, fall back to config.json
    creds = _load_email_creds()
    agent_email = creds.get("GMAIL_ADDRESS") or CONFIG.get("agent_email", "")
    agent_password = creds.get("GMAIL_APP_PASSWORD") or CONFIG.get("agent_email_password",
                     CONFIG.get("email_app_password", ""))
    if not agent_email or not agent_password:
        print("Error: no SMTP credentials available for send_email", file=sys.stderr)
        return
    smtp_host = CONFIG.get("agent_smtp_host", CONFIG.get("email_smtp_host", "smtp.gmail.com"))
    msg = MIMEText(body, "plain")
    msg["From"] = agent_email
    msg["To"] = to
    msg["Subject"] = subject
    import time as _time
    for attempt in range(MAX_RETRIES):
        try:
            with smtplib.SMTP_SSL(smtp_host, 465, timeout=15) as s:
                s.login(agent_email, agent_password)
                s.send_message(msg)
            return  # success
        except smtplib.SMTPAuthenticationError as e:
            print(f"SMTP auth failed (not retryable): {e}", file=sys.stderr)
            return
        except Exception as e:
            if attempt >= MAX_RETRIES - 1:
                print(f"SMTP send failed after {MAX_RETRIES} attempts: {e}", file=sys.stderr)
                return
            _time.sleep(RETRY_BACKOFF[min(attempt, len(RETRY_BACKOFF) - 1)])


# ---------------------------------------------------------------------------
# Email classification
# ---------------------------------------------------------------------------

def decode_mime_header(header):
    if not header:
        return ""
    parts = decode_header(header)
    decoded = []
    for part, charset in parts:
        if isinstance(part, bytes):
            decoded.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            decoded.append(str(part))
    return " ".join(decoded)


def get_body(msg):
    """Extract plain text body from email message."""
    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            if ct == "text/plain":
                payload = part.get_payload(decode=True)
                if payload:
                    charset = part.get_content_charset() or "utf-8"
                    return payload.decode(charset, errors="replace")[:500]
    else:
        payload = msg.get_payload(decode=True)
        if payload:
            charset = msg.get_content_charset() or "utf-8"
            return payload.decode(charset, errors="replace")[:500]
    return ""


def classify_email(sender, subject, body):
    """Classify email into: urgent, action, fyi, spam."""
    sender_lower = sender.lower()
    subject_lower = subject.lower()
    body_lower = body.lower()[:300]
    all_text = f"{subject_lower} {body_lower}"

    # Urgent
    if any(kw in all_text for kw in URGENT_KEYWORDS):
        return "urgent"

    # Action required
    if any(kw in all_text for kw in ACTION_KEYWORDS) or "?" in subject:
        return "action"

    # Newsletter / FYI
    if any(kw in sender_lower for kw in NEWSLETTER_SENDERS):
        return "fyi"
    if any(kw in subject_lower for kw in {"weekly", "digest", "newsletter", "update", "report"}):
        return "fyi"

    # Default to FYI
    return "fyi"


def fetch_unread(imap_host, email_addr, password, max_count=MAX_EMAILS):
    """Connect via IMAP and fetch unread emails."""
    emails = []
    try:
        mail = imaplib.IMAP4_SSL(imap_host, 993)
        mail.login(email_addr, password)
        mail.select("INBOX", readonly=True)  # read-only — never modify

        _, data = mail.search(None, "UNSEEN")
        msg_ids = data[0].split()

        if len(msg_ids) > max_count:
            msg_ids = msg_ids[-max_count:]  # most recent N

        for mid in msg_ids:
            _, msg_data = mail.fetch(mid, "(RFC822)")
            raw = msg_data[0][1]
            msg = email.message_from_bytes(raw)

            sender = decode_mime_header(msg.get("From", ""))
            subject = decode_mime_header(msg.get("Subject", ""))
            date = msg.get("Date", "")
            body = get_body(msg)
            category = classify_email(sender, subject, body)

            # Extract just the email address from sender
            match = re.search(r"[\w.+-]+@[\w.-]+", sender)
            sender_email = match.group(0) if match else sender

            emails.append({
                "sender": sender,
                "sender_email": sender_email,
                "subject": subject,
                "date": date,
                "body_preview": body[:150],
                "category": category,
                "uid": mid.decode(),
            })

        mail.logout()
    except imaplib.IMAP4.error as e:
        print(f"IMAP error: {e}", file=sys.stderr)
        # One retry
        try:
            import time
            time.sleep(5)
            mail = imaplib.IMAP4_SSL(imap_host, 993)
            mail.login(email_addr, password)
            mail.select("INBOX", readonly=True)
            _, data = mail.search(None, "UNSEEN")
            # ... simplified retry — just get count
            count = len(data[0].split())
            emails = [{"note": f"Retry got count: {count} unread. Full fetch failed."}]
            mail.logout()
        except Exception:
            pass
    except Exception as e:
        print(f"Email error: {e}", file=sys.stderr)

    return emails


def format_triage(emails):
    now = datetime.datetime.now()
    categorized = {"urgent": [], "action": [], "fyi": [], "spam": []}
    for e in emails:
        if "category" in e:
            categorized[e["category"]].append(e)

    lines = [
        f"EMAIL TRIAGE — {now.strftime('%A %B %d, %Y %I:%M %p')}",
        f"Total unread: {len(emails)}",
        "=" * 50,
        "",
    ]

    # Urgent first
    if categorized["urgent"]:
        lines.append(f"🔴 URGENT ({len(categorized['urgent'])})")
        for e in categorized["urgent"]:
            lines.append(f"  From: {e['sender_email']}")
            lines.append(f"  Subject: {e['subject']}")
            lines.append(f"  Preview: {e['body_preview']}")
            lines.append("")

    # Action required
    if categorized["action"]:
        lines.append(f"🟡 ACTION REQUIRED ({len(categorized['action'])})")
        for e in categorized["action"]:
            lines.append(f"  From: {e['sender_email']}")
            lines.append(f"  Subject: {e['subject']}")
            lines.append("")

    # FYI
    if categorized["fyi"]:
        lines.append(f"🔵 FYI / NEWSLETTERS ({len(categorized['fyi'])})")
        for e in categorized["fyi"][:5]:  # show top 5
            lines.append(f"  {e['sender_email']:30s}  {e['subject'][:50]}")
        if len(categorized["fyi"]) > 5:
            lines.append(f"  ... and {len(categorized['fyi']) - 5} more")
        lines.append("")

    if not any(categorized.values()):
        lines.append("Inbox zero! No unread emails.")
        lines.append("")

    if len(emails) >= MAX_EMAILS:
        lines.append(f"Note: capped at {MAX_EMAILS} emails. More may be unread.")
        lines.append("")

    lines.append("—\nPowered by AIBrain (read-only triage — no emails modified)")
    return "\n".join(lines)


def format_multi_triage(all_results):
    """Format consolidated triage across multiple email accounts."""
    now = datetime.datetime.now()
    total = sum(len(r["emails"]) for r in all_results)

    lines = [
        f"EMAIL TRIAGE — {now.strftime('%A %B %d, %Y %I:%M %p')}",
        f"Accounts checked: {len(all_results)} | Total unread: {total}",
        "=" * 50,
        "",
    ]

    # Merge all emails with account labels
    all_emails = []
    for result in all_results:
        for e in result["emails"]:
            e["_account"] = result["label"]
            all_emails.append(e)

    categorized = {"urgent": [], "action": [], "fyi": [], "spam": []}
    for e in all_emails:
        if "category" in e:
            categorized[e["category"]].append(e)

    if categorized["urgent"]:
        lines.append(f"URGENT ({len(categorized['urgent'])})")
        for e in categorized["urgent"]:
            lines.append(f"  [{e['_account']}] From: {e['sender_email']}")
            lines.append(f"  Subject: {e['subject']}")
            lines.append(f"  Preview: {e['body_preview']}")
            lines.append("")

    if categorized["action"]:
        lines.append(f"ACTION REQUIRED ({len(categorized['action'])})")
        for e in categorized["action"]:
            lines.append(f"  [{e['_account']}] {e['sender_email']:30s}  {e['subject'][:50]}")
        lines.append("")

    if categorized["fyi"]:
        lines.append(f"FYI / NEWSLETTERS ({len(categorized['fyi'])})")
        for e in categorized["fyi"][:10]:
            lines.append(f"  [{e['_account']}] {e['sender_email']:30s}  {e['subject'][:50]}")
        if len(categorized["fyi"]) > 10:
            lines.append(f"  ... and {len(categorized['fyi']) - 10} more")
        lines.append("")

    if not any(categorized.values()):
        lines.append("Inbox zero across all accounts!")
        lines.append("")

    # Per-account summary
    lines.append("ACCOUNT SUMMARY:")
    for r in all_results:
        lines.append(f"  {r['label']:20s} {len(r['emails']):3d} unread")
    lines.append("")

    lines.append("---\nPowered by AIBrain (read-only triage — no emails modified)")
    return "\n".join(lines)


def main():
    parser = argparse.ArgumentParser(description="AIBrain Email Triage — multi-account")
    parser.add_argument("--dry-run", action="store_true", help="Print instead of emailing summary")
    args = parser.parse_args()

    # Build list of accounts to check
    accounts = []

    # Primary agent email (always checked if configured)
    agent_email = CONFIG.get("agent_email", "")
    agent_password = CONFIG.get("agent_email_password", CONFIG.get("email_app_password", ""))
    agent_imap = CONFIG.get("agent_imap_host", CONFIG.get("email_imap_host", "imap.gmail.com"))
    if agent_email and agent_password:
        accounts.append({
            "label": "agent",
            "email": agent_email,
            "password": agent_password,
            "imap_host": agent_imap,
        })

    # Additional monitored accounts from email_accounts array
    for acct in CONFIG.get("email_accounts", []):
        if acct.get("monitor") and acct.get("email") and acct.get("app_password"):
            accounts.append({
                "label": acct.get("label", acct["email"].split("@")[0]),
                "email": acct["email"],
                "password": acct["app_password"],
                "imap_host": acct.get("imap_host", "imap.gmail.com"),
            })

    if not accounts:
        print("Error: no email accounts configured. Set agent_email or email_accounts in config.json", file=sys.stderr)
        sys.exit(1)

    # Fetch from all accounts
    all_results = []
    for acct in accounts:
        print(f"Checking {acct['label']} ({acct['email']})...")
        emails = fetch_unread(acct["imap_host"], acct["email"], acct["password"])
        all_results.append({"label": acct["label"], "email": acct["email"], "emails": emails})
        print(f"  {len(emails)} unread")

    total = sum(len(r["emails"]) for r in all_results)
    if total == 0:
        print("No unread emails across all accounts.")
        save_state("email_triage", {
            "last_run": datetime.datetime.now().isoformat(),
            "accounts_checked": len(accounts),
            "unread_count": 0,
        })
        return

    # Format consolidated report
    if len(all_results) > 1:
        triage = format_multi_triage(all_results)
    else:
        triage = format_triage(all_results[0]["emails"])

    email_to = CONFIG.get("email_to", agent_email)

    if args.dry_run:
        print(triage)
    elif email_to:
        all_emails = [e for r in all_results for e in r["emails"]]
        urgent_count = len([e for e in all_emails if e.get("category") == "urgent"])
        acct_label = f" ({len(accounts)} accounts)" if len(accounts) > 1 else ""
        subject_prefix = f"[{urgent_count} URGENT] " if urgent_count else ""
        send_email(email_to, f"{subject_prefix}Email Triage — {total} unread{acct_label}", triage)
        print(f"Sent triage summary ({total} emails from {len(accounts)} accounts) to {email_to}")
    else:
        print(triage)

    save_state("email_triage", {
        "last_run": datetime.datetime.now().isoformat(),
        "accounts_checked": len(accounts),
        "unread_count": total,
        "urgent": len([e for r in all_results for e in r["emails"] if e.get("category") == "urgent"]),
        "action": len([e for r in all_results for e in r["emails"] if e.get("category") == "action"]),
        "per_account": {r["label"]: len(r["emails"]) for r in all_results},
    })

    urgent_count = len([e for r in all_results for e in r["emails"] if e.get("category") == "urgent"])
    log_activity("email_triage_run",
                 f"accounts={len(accounts)} unread={total} urgent={urgent_count}")


if __name__ == "__main__":
    # P0-1 backfill: entry point routes through harness via workflow_execute
    def _workflow_entry():
        main()
    workflow_execute(
        workflow_name='email_triage',
        action=_workflow_entry,
        task_type='simple',
        actor='cli',
    )
