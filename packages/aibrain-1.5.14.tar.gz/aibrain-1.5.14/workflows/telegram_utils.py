"""Shared Telegram notification utility for AIBrain workflows.

All sends are fire-and-forget via daemon threads — the caller never blocks
waiting on the Telegram API. If Telegram is slow or down, workflows continue.

Delegates to telegram_bot.send_message for the actual API call, falling back
to a direct urllib implementation if the import fails.

Usage:
    from telegram_utils import send_telegram
    send_telegram("Job done.")
    send_telegram("Alert!", chat_id="-5288572284")
"""

from __future__ import annotations

from aibrain.core.workflow_base import workflow_execute  # noqa: F401 — required by pre-commit hook for workflows/ files

import json
import os
import threading
import urllib.request
from pathlib import Path
from typing import Optional

# ---------------------------------------------------------------------------
# Env loader (needed if telegram_bot import fails)
# ---------------------------------------------------------------------------

def _load_env() -> None:
    env_file = Path.home() / ".decker_env"
    if not env_file.exists():
        return
    try:
        for line in env_file.read_text(encoding="utf-8", errors="replace").splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"'))
    except Exception:
        pass


def _resolve_token() -> str:
    _load_env()
    return (
        os.environ.get("TELEGRAM_BOT_TOKEN")
        or os.environ.get("TELEGRAM_TOKEN")
        or ""
    )


def _resolve_chat_id() -> str:
    return os.environ.get("TELEGRAM_CHAT_ID", "")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def send_telegram(
    message: str,
    chat_id: Optional[str] = None,
    token: Optional[str] = None,
    parse_mode: str = "HTML",
) -> None:
    """Send a Telegram message. Non-blocking — returns immediately.

    Args:
        message:    Text to send.
        chat_id:    Destination chat ID. Defaults to TELEGRAM_CHAT_ID env var.
        token:      Bot token. Defaults to TELEGRAM_BOT_TOKEN / TELEGRAM_TOKEN.
        parse_mode: Telegram parse mode. Default "HTML".
    """
    resolved_token = token or _resolve_token()
    resolved_chat = chat_id or _resolve_chat_id()
    if not resolved_token or not resolved_chat:
        return

    def _send() -> None:
        try:
            # Try using the core module
            from telegram_bot import send_message
            send_message(int(resolved_chat), message,
                         token=resolved_token, parse_mode=parse_mode)
        except Exception:
            # Fallback: direct urllib (handles import failure or any error)
            _send_direct(resolved_token, resolved_chat, message, parse_mode)

    threading.Thread(target=_send, daemon=True).start()


def _send_direct(token: str, chat_id: str, message: str,
                 parse_mode: str) -> None:
    """Direct urllib send — fallback if telegram_bot import fails."""
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    for chunk in [message[i:i + 4000] for i in range(0, max(len(message), 1), 4000)]:
        payload = json.dumps({
            "chat_id": chat_id,
            "text": chunk,
            "parse_mode": parse_mode,
        }).encode()
        req = urllib.request.Request(
            url, data=payload, headers={"Content-Type": "application/json"}
        )
        try:
            urllib.request.urlopen(req, timeout=10)
        except Exception:
            pass
