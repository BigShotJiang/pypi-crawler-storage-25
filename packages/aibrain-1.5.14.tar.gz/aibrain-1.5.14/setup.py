from setuptools import setup, find_packages

# Explicit package discovery that excludes backend/dist/ (PyInstaller sidecar bundle).
# Cannot use pyproject.toml find exclude for this because the hyphen in
# 'aibrain-backend' makes the path an invalid Python identifier — setuptools
# traverses it anyway. find_packages() with an explicit exclude pattern is
# the reliable escape hatch.

packages = find_packages(
    exclude=[
        "backend.dist",
        "backend.dist.*",
        "backend.dist.aibrain*",
        "backend.dist.aibrain*.*",
    ]
) + ["backend", "backend.auth"]

# Deduplicate while preserving order
seen = set()
unique_packages = []
for p in packages:
    if p not in seen:
        seen.add(p)
        unique_packages.append(p)

setup(
    packages=unique_packages,
    author="Matthew McKee",
    author_email="decker.ops@gmail.com",
)
