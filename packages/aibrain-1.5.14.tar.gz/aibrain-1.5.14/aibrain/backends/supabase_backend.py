"""
AIBrain Supabase pgvector memory backend.

Stores AIBrain episodic and semantic memories in Supabase using the pgvector
extension for vector similarity search, instead of the default SQLite store.

Usage example::

    from aibrain.backends.supabase_backend import SupabaseMemoryBackend

    backend = SupabaseMemoryBackend(
        url="https://your-project.supabase.co",
        key="your-anon-or-service-role-key",
        table_prefix="aibrain",   # optional, default "aibrain"
        embedding_dim=384,         # optional, default 384 (MiniLM)
    )

    # Store a memory
    backend.store(
        memory_id="mem_001",
        content="Paris is the capital of France.",
        embedding=[0.1, 0.2, ...],  # 384-dim list[float]
        metadata={"type": "fact", "source": "user"},
        table="episodic",
    )

    # Semantic search
    results = backend.search(
        query_embedding=[0.1, 0.2, ...],
        top_k=5,
        table="episodic",
        threshold=0.7,
    )

    # Stats
    print(backend.stats())
    # {'episodic_count': 1, 'semantic_count': 0}

Before using this backend, run the SQL migration in:
    aibrain/backends/migrations/supabase_init.sql

against your Supabase project (SQL editor or psql).
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

try:
    from supabase import create_client, Client
except ImportError as exc:
    raise ImportError(
        "The Supabase backend requires the 'supabase' package.\n"
        "Install it with:  pip install aibrain[supabase]"
    ) from exc


class SupabaseMemoryBackend:
    """
    AIBrain memory backend backed by Supabase + pgvector.

    Tables managed (all prefixed):
      - ``{prefix}_episodic``  — raw memories, written on every store()
      - ``{prefix}_semantic``  — consolidated/dream-cycle memories

    Both tables carry a 384-dim (or configurable) pgvector ``embedding`` column
    with an HNSW index for sub-millisecond ANN search.

    Parameters
    ----------
    url:
        Supabase project URL, e.g. ``https://abc123.supabase.co``.
    key:
        Supabase anon key or service-role key.  Use service-role for
        server-side agents that need unrestricted access.
    table_prefix:
        Prefix for all managed tables.  Default ``"aibrain"``.
    embedding_dim:
        Dimensionality of the embedding vectors.  Must match whatever
        embedding model you're using (MiniLM default = 384).
    """

    def __init__(
        self,
        url: str,
        key: str,
        table_prefix: str = "aibrain",
        embedding_dim: int = 384,
    ) -> None:
        if not url or not key:
            raise ValueError("Both 'url' and 'key' must be non-empty strings.")

        try:
            self._client: Client = create_client(url, key)
        except Exception as exc:
            raise RuntimeError(
                f"Failed to create Supabase client for {url!r}: {exc}"
            ) from exc

        self._prefix = table_prefix
        self._dim = embedding_dim
        self._episodic_table = f"{table_prefix}_episodic"
        self._semantic_table = f"{table_prefix}_semantic"

        self._ensure_tables()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _table(self, name: str) -> str:
        """Resolve logical table name ('episodic'|'semantic') to prefixed name."""
        if name in ("episodic", "semantic"):
            return f"{self._prefix}_{name}"
        # Already prefixed or custom — pass through
        return name

    def _ensure_tables(self) -> None:
        """
        Validate that the required tables exist by running a lightweight probe.

        We don't CREATE tables from Python — that would require DDL rights and
        bypasses pgvector extension setup.  Instead we probe with a LIMIT 0
        SELECT so users get a clear error if they forgot to run the migration.
        """
        for logical in ("episodic", "semantic"):
            tbl = self._table(logical)
            try:
                self._client.table(tbl).select("id").limit(0).execute()
            except Exception as exc:
                raise RuntimeError(
                    f"Table '{tbl}' not found in Supabase. "
                    "Run the migration first:\n"
                    "  aibrain/backends/migrations/supabase_init.sql\n"
                    f"Original error: {exc}"
                ) from exc

    @staticmethod
    def _now_iso() -> str:
        return datetime.now(timezone.utc).isoformat()

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def store(
        self,
        memory_id: str,
        content: str,
        embedding: list[float],
        metadata: dict | None = None,
        table: str = "episodic",
    ) -> None:
        """
        Upsert a memory record into the specified table.

        Parameters
        ----------
        memory_id:
            Stable, caller-supplied identifier (e.g. ``"mem_<uuid>"``).
        content:
            Raw text content of the memory.
        embedding:
            Dense vector of length ``embedding_dim``.
        metadata:
            Arbitrary JSON-serialisable dict stored in a jsonb column.
        table:
            ``"episodic"`` (default) or ``"semantic"``.
        """
        tbl = self._table(table)
        if metadata is None:
            metadata = {}

        row: dict[str, Any] = {
            "id": memory_id,
            "content": content,
            "embedding": embedding,
            "metadata" if table == "episodic" else "metadata": metadata,
            "created_at": self._now_iso(),
        }

        # semantic table has different columns
        if table == "semantic":
            row = {
                "id": memory_id,
                "content": content,
                "embedding": embedding,
                "source_ids": metadata.get("source_ids", []),
                "consolidation_score": float(metadata.get("consolidation_score", 0.0)),
                "created_at": self._now_iso(),
            }

        try:
            self._client.table(tbl).upsert(row, on_conflict="id").execute()
        except Exception as exc:
            raise RuntimeError(f"store() failed on table '{tbl}': {exc}") from exc

    def search(
        self,
        query_embedding: list[float],
        top_k: int = 10,
        table: str = "episodic",
        threshold: float = 0.7,
    ) -> list[dict]:
        """
        Vector similarity search using cosine distance via pgvector.

        Calls the Supabase RPC function ``match_{table}`` (created by the
        migration SQL) which executes::

            SELECT *, 1 - (embedding <=> query_embedding) AS similarity
            FROM {table}
            WHERE 1 - (embedding <=> query_embedding) >= threshold
            ORDER BY embedding <=> query_embedding
            LIMIT top_k;

        Parameters
        ----------
        query_embedding:
            Query vector of length ``embedding_dim``.
        top_k:
            Maximum number of results.
        table:
            ``"episodic"`` (default) or ``"semantic"``.
        threshold:
            Minimum cosine similarity score in [0, 1].  Records below this
            are excluded.

        Returns
        -------
        list[dict]
            Each dict contains all columns from the table plus ``similarity``
            (float in [0, 1], higher = more similar).
        """
        tbl = self._table(table)
        fn_name = f"match_{tbl}"

        try:
            response = self._client.rpc(
                fn_name,
                {
                    "query_embedding": query_embedding,
                    "match_count": top_k,
                    "match_threshold": threshold,
                },
            ).execute()
        except Exception as exc:
            raise RuntimeError(
                f"search() RPC '{fn_name}' failed: {exc}\n"
                "Ensure the migration SQL was applied (match_* functions are created there)."
            ) from exc

        return response.data or []

    def get(self, memory_id: str, table: str = "episodic") -> dict | None:
        """
        Fetch a single memory by its ID.

        Returns ``None`` if not found.
        """
        tbl = self._table(table)
        try:
            response = (
                self._client.table(tbl)
                .select("*")
                .eq("id", memory_id)
                .limit(1)
                .execute()
            )
        except Exception as exc:
            raise RuntimeError(f"get() failed on table '{tbl}': {exc}") from exc

        if response.data:
            return response.data[0]
        return None

    def delete(self, memory_id: str, table: str = "episodic") -> None:
        """
        Delete a memory record by ID.

        Silently succeeds if the record does not exist.
        """
        tbl = self._table(table)
        try:
            self._client.table(tbl).delete().eq("id", memory_id).execute()
        except Exception as exc:
            raise RuntimeError(f"delete() failed on table '{tbl}': {exc}") from exc

    def list_memories(
        self,
        table: str = "episodic",
        limit: int = 100,
        offset: int = 0,
    ) -> list[dict]:
        """
        List memories with pagination, ordered by creation time (newest first).

        Parameters
        ----------
        table:
            ``"episodic"`` or ``"semantic"``.
        limit:
            Max records to return (capped at 1000 to protect quota).
        offset:
            Row offset for pagination.
        """
        tbl = self._table(table)
        limit = min(limit, 1000)
        try:
            response = (
                self._client.table(tbl)
                .select("*")
                .order("created_at", desc=True)
                .range(offset, offset + limit - 1)
                .execute()
            )
        except Exception as exc:
            raise RuntimeError(f"list_memories() failed on table '{tbl}': {exc}") from exc

        return response.data or []

    def stats(self) -> dict:
        """
        Return row counts for both tables.

        Returns
        -------
        dict
            ``{"episodic_count": int, "semantic_count": int}``
        """
        result: dict[str, int] = {}
        for logical in ("episodic", "semantic"):
            tbl = self._table(logical)
            try:
                response = (
                    self._client.table(tbl)
                    .select("id", count="exact")
                    .limit(0)
                    .execute()
                )
                result[f"{logical}_count"] = response.count or 0
            except Exception as exc:
                raise RuntimeError(f"stats() failed on table '{tbl}': {exc}") from exc

        return result
