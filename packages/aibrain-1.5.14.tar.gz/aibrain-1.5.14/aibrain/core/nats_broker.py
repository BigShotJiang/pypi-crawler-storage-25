"""
nats_broker.py -- NATS JetStream inter-agent messaging client.

Replaces the custom HTTP broker (broker.py on VPS port 8765) with a proper
message bus. Uses nats-py (pip install nats-py) for async pub/sub with
JetStream persistence.

Architecture:
  - NATS server runs on VPS (76.13.198.228:4222) with JetStream enabled
  - Each agent connects with a shared token (NATS_TOKEN in ~/.decker_env)
  - Messages route via subjects: neuro.inbox, case.inbox, broadcast.all, etc.
  - JetStream streams persist messages to disk (survive restarts, replay missed)
  - Auto-reconnect with exponential backoff (built into nats-py)

Usage:
    from aibrain.core.nats_broker import NATSBroker

    broker = NATSBroker(server="nats://76.13.198.228:4222",
                        token="<token>", agent_id="neuro")
    await broker.connect()
    await broker.send("case", "hello from neuro")
    msgs = await broker.recv(timeout=5.0)
    await broker.close()

    # Sync wrapper for hooks (non-async callers):
    from aibrain.core.nats_broker import send_sync, recv_sync
    send_sync("case", "hello from hook")
    msgs = recv_sync(timeout=2.0)
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Lazy import of nats -- fail gracefully if not installed
# ---------------------------------------------------------------------------

_nats = None
_nats_errors = None


def _ensure_nats():
    """Import nats-py on first use. Raises ImportError with install hint."""
    global _nats, _nats_errors
    if _nats is not None:
        return
    try:
        import nats as _nats_mod
        import nats.errors as _nats_err_mod
        _nats = _nats_mod
        _nats_errors = _nats_err_mod
    except ImportError:
        raise ImportError(
            "nats-py is required for NATS broker. Install with: pip install nats-py"
        )


# ---------------------------------------------------------------------------
# Config loader
# ---------------------------------------------------------------------------

def _load_env_token() -> str:
    """Load NATS_TOKEN from environment or ~/.decker_env."""
    token = os.environ.get("NATS_TOKEN", "")
    if token:
        return token
    for env_file in [Path.home() / ".decker_env", Path.home() / ".aibrain_env"]:
        if env_file.exists():
            try:
                for line in env_file.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith("NATS_TOKEN=") and not line.startswith("#"):
                        return line.split("=", 1)[1].strip().strip('"')
            except Exception:
                pass
    return ""


def _default_server() -> str:
    """Default NATS server URL from env or hardcoded."""
    return os.environ.get("NATS_URL", "nats://76.13.198.228:4222")


# ---------------------------------------------------------------------------
# Stream / subject constants
# ---------------------------------------------------------------------------

STREAM_AGENT_MSGS = "AGENT_MSGS"
STREAM_HEARTBEATS = "HEARTBEATS"

SUBJECT_INBOX_PREFIX = ""  # e.g., "neuro.inbox"
SUBJECT_BROADCAST = "broadcast.all"
SUBJECT_DECKER = "decker.inbox"
SUBJECT_HEARTBEAT = "agent.heartbeat"

# All inbox subjects that AGENT_MSGS stream captures
_AGENT_MSG_SUBJECTS = [
    "neuro.inbox",
    "case.inbox",
    "decker.inbox",
    "broadcast.all",
]


def _inbox_subject(agent_id: str) -> str:
    return f"{agent_id}.inbox"


# ---------------------------------------------------------------------------
# NATSBroker -- the primary client class
# ---------------------------------------------------------------------------

class NATSBroker:
    """Async NATS JetStream client for inter-agent messaging.

    Handles connection lifecycle, stream provisioning, publish, subscribe,
    and heartbeat. Designed for two agents (Neuro + Case) but scales to N.
    """

    def __init__(
        self,
        server: str | None = None,
        token: str | None = None,
        agent_id: str = "neuro",
        stream_name: str = STREAM_AGENT_MSGS,
        max_msgs: int = 1000,
        max_bytes: int = 100 * 1024 * 1024,  # 100 MB
        max_age: int = 7 * 24 * 3600,  # 7 days in seconds
    ):
        _ensure_nats()
        self.server = server or _default_server()
        self.token = token or _load_env_token()
        self.agent_id = agent_id
        self.stream_name = stream_name
        self.max_msgs = max_msgs
        self.max_bytes = max_bytes
        self.max_age = max_age

        self._nc = None  # nats.NATS connection
        self._js = None  # JetStream context
        self._sub = None  # Pull subscription for receiving
        self._broadcast_sub = None  # Pull subscription for broadcast

    @property
    def is_connected(self) -> bool:
        return self._nc is not None and self._nc.is_connected

    # ------------------------------------------------------------------
    # Connect / Disconnect
    # ------------------------------------------------------------------

    async def connect(self) -> None:
        """Connect to NATS server and ensure JetStream streams exist."""
        if self.is_connected:
            return

        nc = await _nats.connect(
            servers=[self.server],
            token=self.token,
            name=f"aibrain-{self.agent_id}",
            # Auto-reconnect settings
            allow_reconnect=True,
            max_reconnect_attempts=-1,  # infinite
            reconnect_time_wait=2,  # seconds between attempts
            # Callbacks
            error_cb=self._on_error,
            disconnected_cb=self._on_disconnect,
            reconnected_cb=self._on_reconnect,
            closed_cb=self._on_closed,
        )
        self._nc = nc
        self._js = nc.jetstream()

        # Ensure the AGENT_MSGS stream exists (idempotent)
        await self._ensure_stream(
            name=self.stream_name,
            subjects=_AGENT_MSG_SUBJECTS,
            max_msgs=self.max_msgs,
            max_bytes=self.max_bytes,
            max_age=self.max_age,
        )

        # Ensure HEARTBEATS stream
        await self._ensure_stream(
            name=STREAM_HEARTBEATS,
            subjects=[SUBJECT_HEARTBEAT],
            max_msgs=100,
            max_bytes=10 * 1024 * 1024,  # 10 MB
            max_age=3600,  # 1 hour
        )

        # Create durable pull consumers for this agent's inbox + broadcast
        inbox_subj = _inbox_subject(self.agent_id)
        consumer_name = f"{self.agent_id}-inbox"
        try:
            self._sub = await self._js.pull_subscribe(
                inbox_subj,
                durable=consumer_name,
                stream=self.stream_name,
            )
        except Exception as e:
            logger.warning("Failed to create inbox consumer %s: %s", consumer_name, e)

        broadcast_consumer = f"{self.agent_id}-broadcast"
        try:
            self._broadcast_sub = await self._js.pull_subscribe(
                SUBJECT_BROADCAST,
                durable=broadcast_consumer,
                stream=self.stream_name,
            )
        except Exception as e:
            logger.warning("Failed to create broadcast consumer %s: %s", broadcast_consumer, e)

        logger.info("Connected to NATS at %s as %s", self.server, self.agent_id)

    async def close(self) -> None:
        """Gracefully disconnect."""
        if self._nc and not self._nc.is_closed:
            await self._nc.drain()
            self._nc = None
            self._js = None
            self._sub = None
            self._broadcast_sub = None
            logger.info("Disconnected from NATS")

    # ------------------------------------------------------------------
    # Stream provisioning (idempotent)
    # ------------------------------------------------------------------

    async def _ensure_stream(
        self,
        name: str,
        subjects: list[str],
        max_msgs: int,
        max_bytes: int,
        max_age: int,
    ) -> None:
        """Create or update a JetStream stream."""
        from nats.js.api import StreamConfig, RetentionPolicy

        config = StreamConfig(
            name=name,
            subjects=subjects,
            retention=RetentionPolicy.LIMITS,
            max_msgs=max_msgs,
            max_bytes=max_bytes,
            max_age=max_age * 1_000_000_000,  # nanoseconds
            num_replicas=1,
        )
        try:
            await self._js.find_stream_name_by_subject(subjects[0])
            # Stream exists -- update config
            await self._js.update_stream(config)
            logger.debug("Updated stream %s", name)
        except _nats_errors.NotFoundError:
            await self._js.add_stream(config)
            logger.info("Created stream %s with subjects %s", name, subjects)
        except Exception as e:
            # Stream may exist with compatible config -- log and continue
            logger.warning("Stream ensure for %s: %s", name, e)

    # ------------------------------------------------------------------
    # Publish (send)
    # ------------------------------------------------------------------

    async def send(
        self,
        to_agent: str,
        msg: str,
        *,
        msg_type: str = "text",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Send a message to a specific agent's inbox."""
        if not self.is_connected:
            raise RuntimeError("Not connected to NATS. Call connect() first.")
        payload = self._build_payload(to_agent, msg, msg_type, metadata)
        subject = _inbox_subject(to_agent)
        ack = await self._js.publish(subject, payload)
        logger.debug("Sent to %s (seq=%d)", subject, ack.seq)

    async def broadcast(
        self,
        msg: str,
        *,
        msg_type: str = "text",
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Broadcast a message to all agents."""
        if not self.is_connected:
            raise RuntimeError("Not connected to NATS. Call connect() first.")
        payload = self._build_payload("all", msg, msg_type, metadata)
        ack = await self._js.publish(SUBJECT_BROADCAST, payload)
        logger.debug("Broadcast (seq=%d)", ack.seq)

    async def send_to_decker(
        self,
        msg: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Send a message to Decker (picked up by Telegram relay)."""
        if not self.is_connected:
            raise RuntimeError("Not connected to NATS. Call connect() first.")
        payload = self._build_payload("decker", msg, "text", metadata)
        ack = await self._js.publish(SUBJECT_DECKER, payload)
        logger.debug("Sent to decker (seq=%d)", ack.seq)

    async def heartbeat(self) -> None:
        """Publish a heartbeat to the heartbeat subject."""
        if not self.is_connected:
            return
        payload = json.dumps({
            "agent_id": self.agent_id,
            "ts": datetime.now(timezone.utc).isoformat(),
            "status": "alive",
        }).encode("utf-8")
        try:
            await self._js.publish(SUBJECT_HEARTBEAT, payload)
        except Exception as e:
            logger.debug("Heartbeat publish failed: %s", e)

    def _build_payload(
        self,
        to: str,
        msg: str,
        msg_type: str,
        metadata: dict[str, Any] | None,
    ) -> bytes:
        return json.dumps({
            "from": self.agent_id,
            "to": to,
            "msg": msg,
            "ts": datetime.now(timezone.utc).isoformat(),
            "type": msg_type,
            "metadata": metadata or {},
        }, ensure_ascii=False).encode("utf-8")

    # ------------------------------------------------------------------
    # Receive (consume)
    # ------------------------------------------------------------------

    async def recv(
        self,
        timeout: float = 5.0,
        batch: int = 10,
    ) -> list[dict]:
        """Pull messages from this agent's inbox + broadcast.

        Returns a list of message dicts. Each message is auto-acked.
        Returns [] on timeout (non-blocking -- caller decides retry).
        """
        if not self.is_connected:
            raise RuntimeError("Not connected to NATS. Call connect() first.")

        results: list[dict] = []

        for sub in (self._sub, self._broadcast_sub):
            if sub is None:
                continue
            try:
                msgs = await sub.fetch(batch=batch, timeout=timeout)
                for msg in msgs:
                    try:
                        data = json.loads(msg.data.decode("utf-8"))
                        results.append(data)
                    except (json.JSONDecodeError, UnicodeDecodeError) as e:
                        logger.warning("Malformed message: %s", e)
                    await msg.ack()
            except _nats_errors.TimeoutError:
                pass  # No messages available -- normal
            except Exception as e:
                logger.warning("Error fetching from %s: %s", sub.subject, e)

        return results

    # ------------------------------------------------------------------
    # Callbacks
    # ------------------------------------------------------------------

    async def _on_error(self, e: Exception) -> None:
        logger.error("NATS error: %s", e)

    async def _on_disconnect(self) -> None:
        logger.warning("Disconnected from NATS -- will auto-reconnect")

    async def _on_reconnect(self) -> None:
        logger.info("Reconnected to NATS at %s", self.server)

    async def _on_closed(self) -> None:
        logger.info("NATS connection closed")


# ---------------------------------------------------------------------------
# Sync convenience wrappers (for broker_hook.py and other non-async callers)
# ---------------------------------------------------------------------------

_default_broker: NATSBroker | None = None


def _get_or_create_loop() -> asyncio.AbstractEventLoop:
    """Get the running event loop or create a new one."""
    try:
        loop = asyncio.get_running_loop()
        return loop
    except RuntimeError:
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        return loop


def _run_sync(coro):
    """Run an async coroutine synchronously."""
    try:
        loop = asyncio.get_running_loop()
        # Already in an async context -- create a task (shouldn't happen in hook)
        raise RuntimeError("Cannot use sync wrappers inside an async context")
    except RuntimeError:
        pass
    loop = asyncio.new_event_loop()
    try:
        return loop.run_until_complete(coro)
    finally:
        loop.run_until_complete(loop.shutdown_asyncgens())
        loop.close()


async def _get_default_broker(
    agent_id: str | None = None,
    server: str | None = None,
    token: str | None = None,
) -> NATSBroker:
    """Get or create the default singleton broker."""
    global _default_broker
    if _default_broker is not None and _default_broker.is_connected:
        return _default_broker

    _agent_id = agent_id or os.environ.get("PEER_AGENT_ID", "neuro")
    broker = NATSBroker(
        server=server or _default_server(),
        token=token or _load_env_token(),
        agent_id=_agent_id,
    )
    await broker.connect()
    _default_broker = broker
    return broker


def send_sync(
    to_agent: str,
    msg: str,
    *,
    agent_id: str | None = None,
    msg_type: str = "text",
    metadata: dict[str, Any] | None = None,
) -> None:
    """Send a message synchronously. For use in hooks and scripts."""
    async def _do():
        broker = await _get_default_broker(agent_id=agent_id)
        await broker.send(to_agent, msg, msg_type=msg_type, metadata=metadata)
    _run_sync(_do())


def recv_sync(
    timeout: float = 2.0,
    batch: int = 10,
    *,
    agent_id: str | None = None,
) -> list[dict]:
    """Receive messages synchronously. For use in hooks and scripts."""
    async def _do():
        broker = await _get_default_broker(agent_id=agent_id)
        return await broker.recv(timeout=timeout, batch=batch)
    return _run_sync(_do())


def broadcast_sync(
    msg: str,
    *,
    agent_id: str | None = None,
    msg_type: str = "text",
    metadata: dict[str, Any] | None = None,
) -> None:
    """Broadcast a message synchronously."""
    async def _do():
        broker = await _get_default_broker(agent_id=agent_id)
        await broker.broadcast(msg, msg_type=msg_type, metadata=metadata)
    _run_sync(_do())


def send_to_decker_sync(
    msg: str,
    *,
    agent_id: str | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Send to Decker synchronously."""
    async def _do():
        broker = await _get_default_broker(agent_id=agent_id)
        await broker.send_to_decker(msg, metadata=metadata)
    _run_sync(_do())


def close_sync() -> None:
    """Close the default broker synchronously."""
    global _default_broker
    if _default_broker is not None:
        _run_sync(_default_broker.close())
        _default_broker = None
