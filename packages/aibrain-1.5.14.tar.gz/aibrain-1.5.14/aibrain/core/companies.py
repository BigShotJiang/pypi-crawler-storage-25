"""
companies.py — Companies feature for AIBrain.

Create and manage AI agent teams that learn and improve over time.
Multi-agent orchestration backed by persistent brain memory.

Usage:
    from aibrain.core.companies import create_company, hire_agent, create_task

    company = create_company("Marketing Team", mission="Scale content to 1M reach")
    ceo = hire_agent(company["id"], "CEO", role="ceo")
    task = create_task(company["id"], "Write 5 LinkedIn posts", assignee=ceo["id"])
"""

import json
import logging
import secrets
import sqlite3
import threading
from datetime import datetime
from pathlib import Path
from typing import Optional

log = logging.getLogger("aibrain.companies")


# ---------------------------------------------------------------------------
# Fix 5: Import-time integrity check
# ---------------------------------------------------------------------------

def _validate_harness_integrity() -> None:
    """Verify DB schema has required columns before any operation.

    Runs at module import time. Raises ImportError if the DB exists but is
    missing columns that the review gate and quality enforcement depend on.

    Falsifiability: this check is proven wrong if a DB passes it but a
    subsequent complete_task() call raises sqlite3.OperationalError on one
    of the named columns. That would mean this check is incomplete and the
    missing column must be added to the set below.

    Skips silently if the DB doesn't exist yet (fresh install — schema
    created on first write).
    """
    try:
        from aibrain_db import AIBRAIN_ROOT
        db_path = AIBRAIN_ROOT / "aibrain.db"
        if not db_path.exists():
            return  # fresh install — schema will be created on first use

        db = sqlite3.connect(str(db_path))
        db.row_factory = sqlite3.Row

        # Required columns in company_issues for review gate + quality enforcement
        required_issue_columns = {
            "priority", "status", "quality_score", "self_score",
            "eval_score", "quality_verified", "quality_flagged",
        }
        # Required columns in execution_log for honest audit trail
        required_log_columns = {
            "cost_cents", "cost_cents_actual", "cost_cents_equivalent",
            "quality_score", "self_score", "divergence", "flagged",
        }

        def _existing_columns(table: str) -> set:
            rows = db.execute(f"PRAGMA table_info({table})").fetchall()
            return {r["name"] for r in rows}

        def _table_exists(table: str) -> bool:
            row = db.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                (table,),
            ).fetchone()
            return row is not None

        # If company_issues doesn't exist yet, the schema hasn't been
        # initialised for this DB (e.g. a partial/legacy DB in AIBRAIN_ROOT).
        # Skip the hard-missing check — schema will be created on first write.
        if not _table_exists("company_issues"):
            db.close()
            return

        issues_cols = _existing_columns("company_issues")
        log_cols = _existing_columns("execution_log")
        db.close()

        missing_issues = required_issue_columns - issues_cols
        missing_log = required_log_columns - log_cols

        # Missing review_required and eval columns are auto-migrated in
        # complete_task() — only hard-fail on columns that cannot be
        # auto-added without data loss.
        hard_missing = {c for c in missing_issues if c in {"priority", "status"}}

        if hard_missing:
            raise ImportError(
                f"aibrain.core.companies: company_issues table is missing "
                f"critical columns: {hard_missing}. "
                f"Run: python -m aibrain doctor --fix"
            )

        if missing_issues or missing_log:
            log.debug(
                "companies integrity: soft-missing columns will be auto-migrated "
                "(issues=%s, log=%s)", missing_issues, missing_log
            )

    except ImportError:
        raise  # re-raise ImportError from hard_missing check
    except Exception as e:
        # Non-fatal: DB may be locked, inaccessible on first import, etc.
        log.debug("_validate_harness_integrity skipped: %s", e)


_validate_harness_integrity()


# ---------------------------------------------------------------------------
# Thread-local checkout context
# ---------------------------------------------------------------------------
#
# When an agent calls checkout_task(), we stash the task ID and company ID in
# thread-local storage so that any harness.execute() call made during the
# checkout → work → complete window can link its execution_log row back to
# the specific company_issue it's servicing. Without this, the harness has
# no way to know which company issue it's working on and every row lands
# with entity_type='task' (the generic fallback).
#
# v1.4 P0-2 fix: Internal audit 2026-04-11 found 100% of execution_log rows
# stamped entity_type='task', zero linkage to company_issues. Root cause:
# checkout_task returned the task dict but never stashed the issue ID
# anywhere the harness could read it. This thread-local is the missing wire.
#
# Nested checkouts: the new checkout shadows the previous one on the same
# thread. Complete of the outer task clears the stash entirely (both id and
# company_id get set to None). This matches the "last checkout wins" model
# used elsewhere in the codebase for per-thread context.
#
# Thread safety: threading.local() gives each thread its own attribute
# namespace, so two worker threads running parallel checkouts never cross-
# contaminate each other's linkage.
_current_issue = threading.local()


def _get_current_issue_id() -> Optional[str]:
    """Return the currently-checked-out task ID on this thread, or None.

    Used by aibrain.core.harness.execute to stamp execution_log rows with
    entity_type='company_issue' and the correct entity_id when a harness
    call happens inside a checkout → complete window.
    """
    return getattr(_current_issue, "id", None)


def _get_current_company_id() -> Optional[str]:
    """Return the currently-checked-out company ID on this thread, or None."""
    return getattr(_current_issue, "company_id", None)


def _get_db():
    """Get database connection via the canonical resolver — see aibrain_db.AIBRAIN_ROOT.

    text_factory is set defensively so a corrupted row (non-UTF-8 byte in any
    TEXT column) does NOT crash the entire query — the bad bytes are replaced
    with the Unicode replacement character (U+FFFD) and the rest of the row
    comes back intact. Surfaced 2026-04-12 by Case reporting a UTF-8 decode
    error on one agent's capabilities field that was breaking list_agents()
    on his side. Pattern #11 — fix the hole at the connection layer so every
    query benefits, not bail the water in list_agents alone.
    """
    from aibrain_db import AIBRAIN_ROOT
    db_path = AIBRAIN_ROOT / "aibrain.db"
    db = sqlite3.connect(str(db_path))
    db.row_factory = sqlite3.Row
    db.text_factory = lambda b: b.decode("utf-8", errors="replace") if isinstance(b, (bytes, bytearray)) else b
    db.execute("PRAGMA journal_mode=WAL")
    db.execute("PRAGMA busy_timeout=5000")
    return db


# ---------------------------------------------------------------------------
# Companies
# ---------------------------------------------------------------------------

def create_company(name: str, mission: str = "") -> dict:
    """Create a new company."""
    db = _get_db()
    company_id = secrets.token_urlsafe(8)

    # Check tier limits
    try:
        from aibrain_licensing import get_license
        lic = get_license()
        existing = db.execute("SELECT COUNT(*) FROM companies WHERE status='active'").fetchone()[0]
        limits = json.loads(db.execute("SELECT value FROM config WHERE key='companies_tier_limits'").fetchone()[0])
        max_companies = limits.get(f"{lic.tier}_companies", 1)
        if existing >= max_companies:
            db.close()
            return {"error": f"Company limit reached ({existing}/{max_companies}). Upgrade to Pro for unlimited companies."}
    except Exception:
        pass

    db.execute(
        "INSERT INTO companies (id, name, mission) VALUES (?, ?, ?)",
        (company_id, name, mission)
    )
    db.commit()

    result = dict(db.execute("SELECT * FROM companies WHERE id=?", (company_id,)).fetchone())
    db.close()

    log.info("Company created: %s (%s)", name, company_id)
    return result


def list_companies(status: str = None) -> list:
    """List all companies."""
    db = _get_db()
    if status:
        rows = db.execute("SELECT * FROM companies WHERE status=? ORDER BY created_at DESC", (status,)).fetchall()
    else:
        rows = db.execute("SELECT * FROM companies ORDER BY created_at DESC").fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_company(company_id: str) -> Optional[dict]:
    """Get company details with agent count and task stats."""
    db = _get_db()
    company = db.execute("SELECT * FROM companies WHERE id=?", (company_id,)).fetchone()
    if not company:
        db.close()
        return None

    result = dict(company)
    result["agent_count"] = db.execute(
        "SELECT COUNT(*) FROM company_agents WHERE company_id=? AND status != 'terminated'",
        (company_id,)
    ).fetchone()[0]
    result["active_tasks"] = db.execute(
        "SELECT COUNT(*) FROM company_issues WHERE company_id=? AND status IN ('todo','in_progress','in_review')",
        (company_id,)
    ).fetchone()[0]
    result["completed_tasks"] = db.execute(
        "SELECT COUNT(*) FROM company_issues WHERE company_id=? AND status='done'",
        (company_id,)
    ).fetchone()[0]

    db.close()
    return result


# ---------------------------------------------------------------------------
# Agents
# ---------------------------------------------------------------------------

def hire_agent(company_id: str, name: str, role: str = "general",
               title: str = "", reports_to: str = None,
               model: str = "auto", capabilities: str = "") -> dict:
    """Hire a new agent for a company."""
    db = _get_db()
    agent_id = secrets.token_urlsafe(8)

    # Check tier limits
    try:
        from aibrain_licensing import get_license
        lic = get_license()
        existing = db.execute(
            "SELECT COUNT(*) FROM company_agents WHERE company_id=? AND status != 'terminated'",
            (company_id,)
        ).fetchone()[0]
        limits = json.loads(db.execute("SELECT value FROM config WHERE key='companies_tier_limits'").fetchone()[0])
        max_agents = limits.get(f"{lic.tier}_agents_per_company", 2)
        if existing >= max_agents:
            db.close()
            return {"error": f"Agent limit reached ({existing}/{max_agents}). Upgrade to Pro for more agents."}
    except Exception:
        pass

    # Map role to harness task type and authority
    role_config = {
        "ceo": {"task_type": "complex", "authority": "admin"},
        "manager": {"task_type": "judgment", "authority": "elevated"},
        "general": {"task_type": "simple", "authority": "standard"},
    }
    config = role_config.get(role, role_config["general"])

    db.execute("""
        INSERT INTO company_agents
        (id, company_id, name, role, title, reports_to, model, task_type, authority, capabilities)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (agent_id, company_id, name, role, title or name, reports_to, model,
          config["task_type"], config["authority"], capabilities))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_agents WHERE id=?", (agent_id,)).fetchone())
    db.close()

    log.info("Agent hired: %s (%s) for company %s", name, role, company_id)
    return result


def list_agents(company_id: str, status: str = None) -> list:
    """List all agents in a company."""
    db = _get_db()
    if status:
        rows = db.execute(
            "SELECT * FROM company_agents WHERE company_id=? AND status=? ORDER BY role, name",
            (company_id, status)
        ).fetchall()
    else:
        rows = db.execute(
            "SELECT * FROM company_agents WHERE company_id=? AND status != 'terminated' ORDER BY role, name",
            (company_id,)
        ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_agent(agent_id: str) -> Optional[dict]:
    """Get agent details."""
    db = _get_db()
    agent = db.execute("SELECT * FROM company_agents WHERE id=?", (agent_id,)).fetchone()
    db.close()
    return dict(agent) if agent else None


# ---------------------------------------------------------------------------
# Tasks / Issues
# ---------------------------------------------------------------------------

def create_task(company_id: str, title: str, description: str = "",
                assignee_agent_id: str = None, priority: str = "medium",
                parent_id: str = None, project: str = "",
                auto_route: bool = True) -> dict:
    """Create a task/issue for a company.

    When auto_route is True (default), uses SelRoute-inspired scoring to
    assign a primary agent (highest fitness) and a secondary agent (reviewer/QA).
    If assignee_agent_id is explicitly provided, it becomes the primary but
    a secondary is still assigned automatically.
    """
    # --- SelRoute agent routing ---
    secondary_agent_id = None
    if auto_route:
        try:
            from aibrain.core.task_router import route_task
            routing = route_task(
                company_id, title, description,
                explicit_assignee=assignee_agent_id,
            )
            if not assignee_agent_id and routing.get("primary"):
                assignee_agent_id = routing["primary"]
            secondary_agent_id = routing.get("secondary")
        except Exception as e:
            log.debug("Task routing failed (non-fatal): %s", e)

    db = _get_db()
    task_id = secrets.token_urlsafe(8)

    # Get next issue number for this company
    max_num = db.execute(
        "SELECT COALESCE(MAX(issue_number), 0) FROM company_issues WHERE company_id=?",
        (company_id,)
    ).fetchone()[0]
    issue_number = max_num + 1

    db.execute("""
        INSERT INTO company_issues
        (id, company_id, parent_id, title, description, assignee_agent_id, priority, project, issue_number)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (task_id, company_id, parent_id, title, description,
          assignee_agent_id, priority, project, issue_number))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())
    db.close()

    # Attach routing metadata (not persisted in DB, returned to caller)
    if secondary_agent_id:
        result["secondary_agent_id"] = secondary_agent_id

    log.info("Task created: #%d %s (company %s, primary=%s, secondary=%s)",
             issue_number, title, company_id, assignee_agent_id, secondary_agent_id)
    return result


def list_tasks(
    company_id: str,
    status: str = None,
    assignee: str = None,
    limit: int = None,
    offset: int = 0,
) -> list:
    """List tasks for a company.

    When limit is provided, returns a dict {"tasks": [...], "total": N}.
    When limit is None (default), returns a plain list for backward compatibility.
    """
    db = _get_db()
    where = "WHERE company_id=?"
    params: list = [company_id]

    if status:
        where += " AND status=?"
        params.append(status)
    if assignee:
        where += " AND assignee_agent_id=?"
        params.append(assignee)

    order = " ORDER BY priority, created_at DESC"

    if limit is not None:
        total = db.execute(
            f"SELECT COUNT(*) FROM company_issues {where}", params
        ).fetchone()[0]
        rows = db.execute(
            f"SELECT * FROM company_issues {where}{order} LIMIT ? OFFSET ?",
            params + [limit, offset],
        ).fetchall()
        db.close()
        return {"tasks": [dict(r) for r in rows], "total": total}

    rows = db.execute(
        f"SELECT * FROM company_issues {where}{order}", params
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


def get_task(task_id: str) -> dict | None:
    """Fetch a single task by ID. Returns dict or None if not found."""
    db = _get_db()
    row = db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone()
    db.close()
    return dict(row) if row else None


def update_task(task_id: str, **kwargs) -> dict:
    """Update allowed fields on a task and return the updated dict.

    Allowed fields: status, priority, assignee_agent_id.
    Unknown keys are silently ignored to prevent SQL injection.
    Raises ValueError if task_id not found.
    """
    allowed = {"status", "priority", "assignee_agent_id"}
    updates = {k: v for k, v in kwargs.items() if k in allowed}
    if not updates:
        task = get_task(task_id)
        if task is None:
            raise ValueError(f"Task {task_id} not found")
        return task

    set_clause = ", ".join(f"{col}=?" for col in updates)
    values = list(updates.values()) + [task_id]

    db = _get_db()
    db.execute(
        f"UPDATE company_issues SET {set_clause}, updated_at=datetime('now') WHERE id=?",
        values,
    )
    db.commit()
    db.close()

    task = get_task(task_id)
    if task is None:
        raise ValueError(f"Task {task_id} not found")
    return task


def recover_stale_tasks(company_id: str, stale_minutes: int = 60) -> int:
    """Reset tasks stuck in_progress for >stale_minutes back to todo.

    Returns the number of tasks recovered.
    Tasks are considered stale if updated_at has not changed in stale_minutes.
    """
    db = _get_db()
    cur = db.execute("""
        UPDATE company_issues
        SET status='todo', updated_at=datetime('now')
        WHERE company_id=?
          AND status='in_progress'
          AND updated_at < datetime('now', ? || ' minutes')
    """, (company_id, f"-{stale_minutes}"))
    count = cur.rowcount
    db.commit()
    db.close()
    if count:
        log.info("Recovered %d stale in-progress task(s) for company %s", count, company_id)
    return count


def _recover_stale_tasks_for_db(task_id: str, stale_minutes: int = 60) -> None:
    """Internal helper: recover stale tasks in the same company as task_id."""
    try:
        db = _get_db()
        row = db.execute("SELECT company_id FROM company_issues WHERE id=?", (task_id,)).fetchone()
        db.close()
        if row:
            recover_stale_tasks(row["company_id"], stale_minutes)
    except Exception as e:
        log.debug("Stale task recovery failed: %s", e)


def checkout_task(task_id: str, agent_id: str) -> dict:
    """Atomically claim a task. Returns 409-equivalent if already claimed.

    Uses a single atomic UPDATE with rowcount check to eliminate TOCTOU race.
    """
    # Recover any stale in-progress tasks before claiming
    _recover_stale_tasks_for_db(task_id)

    db = _get_db()
    cur = db.execute("""
        UPDATE company_issues
        SET status='in_progress', assignee_agent_id=?, started_at=datetime('now'), updated_at=datetime('now')
        WHERE id=? AND status IN ('backlog', 'todo', 'blocked')
    """, (agent_id, task_id))
    db.commit()

    if cur.rowcount == 0:
        # Either task doesn't exist or is already in_progress/done — fetch to disambiguate
        task = db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone()
        db.close()
        if not task:
            return {"error": "Task not found"}
        task = dict(task)
        if task["status"] == "in_progress":
            # Idempotent: same agent re-checking out their own task is fine.
            # Stash the thread-local so the harness can still link to it.
            if task["assignee_agent_id"] == agent_id:
                _current_issue.id = task["id"]
                _current_issue.company_id = task.get("company_id")
                return task
            return {"error": "Task already claimed by another agent",
                    "claimed_by": task["assignee_agent_id"]}
        return {"error": f"Cannot claim task in status '{task['status']}'"}

    result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())
    db.close()

    # Stash on thread-local so harness.execute can read it. Nested checkouts
    # shadow the previous one on the same thread — this is intentional.
    _current_issue.id = result["id"]
    _current_issue.company_id = result.get("company_id")

    # Emit company.task.checkout event — fire-and-forget
    try:
        from aibrain.core.event_bus import emit as _bus_emit, EventTypes as _ET
        _bus_emit(_ET.COMPANY_TASK_CHECKOUT, {
            "task_id": task_id,
            "agent_id": agent_id,
            "title": result.get("title", ""),
            "priority": result.get("priority", ""),
        }, actor=agent_id)
    except Exception:
        pass

    return result


def complete_task(task_id: str, quality_score: float = None, cost_cents: Optional[int] = None,
                  output: object = None, repo_path: str = None,
                  test_cmd: str = None, work_output: object = None,
                  require_verification: bool = False,
                  require_review: bool = False,
                  notes: str = None) -> dict:
    """Mark a task as done with honest quality evaluation AND verification.

    The caller-supplied quality_score is stored as self_score. The system
    runs automated checks to produce an independent eval_score. Both are
    recorded so divergence can be tracked over time.

    If ``work_output`` is supplied, the task goes through
    :func:`aibrain.core.task_verification.verify_and_complete` first:
      - Acceptance criteria are parsed from the task description.
      - Each criterion is checked against work_output.
      - Follow-up tasks are created for any gaps or TODO/follow-up hints.
      - If ``require_verification=True`` and verification fails, the task
        is NOT marked done; the verification result is returned instead.

    If ``require_review=True`` (or the task was flagged via set_review_required()),
    the task output is evaluated by the Special Liaison (intel_agent_v2) review
    gate before completion. If the review returns FAIL, a TaskReviewFailed
    exception is raised — the caller must fix the work and retry.

    Backward compat: if ``work_output`` is not supplied, behavior is
    unchanged except a debug warning is logged.

    Args:
        task_id: Task to complete.
        quality_score: Caller's self-assessment (stored as self_score, NOT used as final score).
        cost_cents: Cost of the work.
        output: Task output for automated quality checks (legacy param).
        repo_path: Git repo path for commit verification.
        test_cmd: Test command for test-pass verification.
        work_output: Structured completion output for acceptance-criteria verification.
        require_verification: If True and verification fails, refuse to mark done.
        require_review: If True, gates completion on Special Liaison review passing.
                        Tasks with priority=high or priority=critical auto-require review.
        notes: Optional free-text metadata stored in a dedicated ``notes`` column on
               ``company_issues``. Intended for supersession metadata such as
               "superseded by task <new_id>" when a task is renamed/restructured.
               The column is added idempotently on first use; callers that omit
               this kwarg see no change in behaviour.
    """
    from aibrain.core.harness import evaluate_task_quality, HarnessConfig

    # ─── Fix 1: Hard pre-condition — DB layer, not a flag ─────────
    # For high/critical tasks, output MUST be provided before any other
    # logic runs. This is not a flag the caller can toggle; it fires at
    # the application layer before the review gate, before quality eval,
    # before the DB write.
    #
    # Rationale: complete_task(task_id) with no output on a high/critical
    # task used to flow through to review_task() with an empty string, which
    # reliably returned FAIL — but that's a review failure, not a structural
    # rejection. The pattern the mandate identified is callers bypassing the
    # review entirely by catching TaskReviewFailed and retrying with a fake
    # output. The DB-layer guard eliminates that path: if priority is high
    # or critical and no output is provided, the call is dead on arrival.
    #
    # Falsifiability: verified by test_complete_task_hard_gate_no_output
    # (to be added). If that test passes, this guard is live.
    _priority_for_gate = "medium"
    try:
        _db_gate = _get_db()
        _gate_row = _db_gate.execute(
            "SELECT priority FROM company_issues WHERE id=?", (task_id,)
        ).fetchone()
        _db_gate.close()
        if _gate_row:
            _priority_for_gate = _gate_row["priority"] or "medium"
    except Exception as _gate_err:
        log.debug("priority pre-check failed (non-fatal): %s", _gate_err)

    if work_output is None and _priority_for_gate in ("high", "critical"):
        raise ValueError(
            f"complete_task({task_id}): work_output is required for {_priority_for_gate} tasks. "
            "Describe what was done and provide at least one verification result."
        )

    # ─── Medium/low tasks without work_output — stub + cap quality ─
    # Agents that call complete_task() without work_output on medium/low tasks
    # can still proceed, but we make the gap explicit and prevent inflated scores.
    if work_output is None:
        work_output = "[No work_output provided — verification skipped]"
        if quality_score is not None and quality_score > 0.5:
            quality_score = 0.5
            log.warning(
                "complete_task(%s): quality_score capped at 0.5 — no work_output provided",
                task_id,
            )

    # ─── Special Liaison review gate ─────────────────────────────
    # Auto-require review for high/critical tasks even if caller didn't pass require_review=True.
    _review_output = work_output if work_output is not None else output
    _effective_require_review = require_review
    if not _effective_require_review:
        try:
            db = _get_db()
            task_row = db.execute(
                "SELECT priority, review_required FROM company_issues WHERE id=?", (task_id,)
            ).fetchone()
            db.close()
            if task_row:
                priority = task_row["priority"] or "medium"
                # Migration-safe: review_required column may not exist yet
                try:
                    review_flag = task_row["review_required"]
                except (IndexError, KeyError):
                    review_flag = 0
                if priority in ("high", "critical") or review_flag:
                    _effective_require_review = True
        except Exception as e:
            log.debug("review gate priority check failed (non-fatal): %s", e)

    if _effective_require_review:
        # ── New architecture (V2): check for Agent-based liaison verdict ──
        # review_task() (regex checks) is now a PRE-FILTER only, called by
        # Neuro before spawning the real Agent-based review. The completion
        # gate checks execution_log for a PASS verdict written by
        # record_liaison_verdict() AFTER the Agent tool review ran.
        #
        # Flow:
        #   1. Neuro calls review_task(task_id, output) — regex pre-filter
        #   2. Neuro spawns Agent tool with Special Liaison persona
        #   3. Agent returns verdict; Neuro calls record_liaison_verdict()
        #   4. complete_task() sees the PASS row here and proceeds
        #
        # If no PASS row exists → TaskReviewFailed (forces proper review first).
        _liaison_pass = False
        _liaison_score = None
        try:
            _db_liaison = _get_db()
            _liaison_row = _db_liaison.execute(
                """SELECT quality_score FROM execution_log
                   WHERE entity_id=? AND actor='special_liaison' AND success=1
                   ORDER BY created_at DESC LIMIT 1""",
                (task_id,),
            ).fetchone()
            _db_liaison.close()
            if _liaison_row:
                _liaison_pass = True
                _liaison_score = _liaison_row["quality_score"]
        except Exception as _ck_err:
            log.debug("Liaison verdict check failed (non-fatal): %s", _ck_err)

        if not _liaison_pass:
            raise TaskReviewFailed(
                f"Task {task_id} requires Special Liaison review before completion. "
                f"Run review_task() as a pre-filter, then spawn the Agent-based "
                f"Special Liaison review, then call record_liaison_verdict() with "
                f"the verdict. complete_task() will proceed once a PASS entry "
                f"exists in execution_log for this task."
            )

        # PASS confirmed — use liaison score as quality_score if caller didn't supply one
        if quality_score is None and _liaison_score is not None:
            quality_score = _liaison_score

    # ─── Verification step (new) ──────────────────────────────
    verification_result = None
    effective_work_output = work_output if work_output is not None else output
    if effective_work_output is not None:
        try:
            from aibrain.core.task_verification import verify_and_complete as _verify
            verification_result = _verify(task_id, effective_work_output)
            if require_verification and not verification_result["verified"]:
                # Do NOT mark done — return verification result with gaps.
                # Do NOT clear the thread-local: the task is still checked
                # out and further harness calls on this thread should still
                # link to it.
                log.warning(
                    "Task %s verification FAILED (status=%s, gaps=%d, follow_ups=%d) — "
                    "not marking complete",
                    task_id,
                    verification_result["verification_status"],
                    len(verification_result["gaps"]),
                    len(verification_result["follow_up_tasks"]),
                )
                return {
                    "task_id": task_id,
                    "status": "not_completed",
                    "reason": "verification_failed",
                    "verification": verification_result,
                }
        except Exception as e:
            log.warning("Verification step failed (non-fatal): %s", e)
    else:
        log.debug(
            "complete_task(%s) called without work_output — "
            "verify-and-followup skipped (backward compat)",
            task_id,
        )

    # Run honest evaluation
    checks_to_run = ["output_no_error", "output_substantive"]
    if repo_path:
        checks_to_run.append("git_committed")
    if test_cmd:
        checks_to_run.append("tests_pass")

    eval_result = evaluate_task_quality(
        output=output,
        task_name=f"task:{task_id}",
        self_score=quality_score,
        run_checks=checks_to_run,
        repo_path=repo_path,
        test_cmd=test_cmd,
    )

    eval_score = eval_result["eval_score"]
    verified = eval_result["verified"]
    flagged = eval_result["flagged"]

    # If no output provided and no automated checks possible, mark as unverified
    # and use self_score if provided, otherwise mark as unknown
    if output is None and quality_score is not None:
        final_score = quality_score
        verified = False
    elif output is None and quality_score is None:
        final_score = None
        verified = False
    else:
        final_score = eval_score

    # ─── Fix 2: Reject explicitly fabricated zero quality scores ──
    # A caller who passes quality_score=0.0 is either reporting a failed task
    # (which should not be marked done) or fabricating a placeholder. Either
    # way, storing quality_score=0.0 for a completed task is dishonest —
    # it pollutes the quality signal and looks identical to "no measurement."
    #
    # This guard rejects only the case where:
    #   (a) caller explicitly passed quality_score=0.0, AND
    #   (b) no real eval_score was measured from output (output is None)
    #
    # It does NOT reject quality_score=None (honest "could not measure") —
    # that's the correct value when no output was provided for a low-priority
    # task. The honest-rubric design explicitly supports NULL for unmeasurable
    # tasks. Only fabricated zeros are rejected.
    #
    # Falsifiability: SELECT COUNT(*) FROM company_issues WHERE status='done'
    # AND quality_score = 0.0 AND eval_score IS NULL should return 0 after
    # all calls pass through this guard.
    if quality_score is not None and quality_score == 0.0 and output is None:
        raise TaskReviewFailed(
            f"Task {task_id}: quality_score=0.0 with no output is rejected. "
            f"A score of 0.0 on a completed task is either a fabricated placeholder "
            f"or a failed task (which should not be marked done). "
            f"Either provide output so the system can measure quality honestly, "
            f"or omit quality_score (None = 'could not measure' is acceptable)."
        )

    db = _get_db()

    # Ensure eval columns exist (migration-safe)
    try:
        db.execute("SELECT self_score FROM company_issues LIMIT 0")
    except Exception:
        for col, coltype in [("self_score", "REAL"), ("eval_score", "REAL"),
                             ("quality_verified", "INTEGER DEFAULT 0"),
                             ("quality_flagged", "INTEGER DEFAULT 0"),
                             ("quality_detail", "TEXT DEFAULT ''")]:
            try:
                db.execute(f"ALTER TABLE company_issues ADD COLUMN {col} {coltype}")
            except Exception:
                pass
        db.commit()

    # Ensure notes column exists (idempotent — added for supersession metadata support)
    try:
        db.execute("ALTER TABLE company_issues ADD COLUMN notes TEXT")
        db.commit()
    except Exception:
        pass  # Column already exists — safe to ignore

    db.execute("""
        UPDATE company_issues
        SET status='done', completed_at=datetime('now'), updated_at=datetime('now'),
            quality_score=?, cost_cents=?, self_score=?, eval_score=?,
            quality_verified=?, quality_flagged=?, quality_detail=?, notes=?
        WHERE id=?
    """, (final_score, cost_cents, quality_score, eval_score if output is not None else None,
          1 if verified else 0, 1 if flagged else 0,
          eval_result["detail"] if output is not None else "unverified: no output provided",
          notes,
          task_id))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())
    db.close()

    # Memory Lifecycle v1.6: sweep related plan-state memories on task completion
    try:
        from aibrain.core.memory_lifecycle_hooks import sweep_related_memories
        _sweep_db = _get_db()
        sweep_related_memories(result, _sweep_db)
        _sweep_db.close()
    except Exception as _sweep_err:
        log.debug("Memory lifecycle sweep failed (non-fatal): %s", _sweep_err)

    # Record to evolution_outcomes for learning
    try:
        _record_quality_evolution(task_id, eval_result)
    except Exception as e:
        log.debug("Quality evolution record failed: %s", e)

    # Emit company.task.complete event (also fires TASK_COMPLETED for legacy compat)
    try:
        from aibrain.core.event_bus import emit as bus_emit, EventTypes
        _assignee = result.get("assignee_agent_id")
        _payload = {
            "task_id": task_id,
            "eval_score": eval_score if output is not None else None,
            "self_score": quality_score,
            "verified": verified,
            "flagged": flagged,
            "title": result.get("title", ""),
            "verification_status": (
                verification_result["verification_status"]
                if verification_result else None
            ),
            "follow_up_count": (
                len(verification_result["follow_up_tasks"])
                if verification_result else 0
            ),
        }
        bus_emit(EventTypes.COMPANY_TASK_COMPLETE, _payload, actor=_assignee)
        # Legacy event kept for existing subscribers
        bus_emit(EventTypes.TASK_COMPLETED, _payload, actor=_assignee)
    except Exception:
        pass  # Event emission never blocks task completion

    # Attach verification result to the return payload so callers see
    # which follow-ups were queued.
    if verification_result:
        result["verification"] = verification_result
        result["follow_up_tasks"] = verification_result["follow_up_tasks"]

    # Clear the thread-local checkout context IF this is the task currently
    # checked out on this thread. Guards against the case where complete_task
    # is called for a different task than the one currently stashed (e.g.
    # orchestrator code completing tasks out-of-band from the worker thread).
    if getattr(_current_issue, "id", None) == task_id:
        _current_issue.id = None
        _current_issue.company_id = None

    return result


def _record_quality_evolution(task_id: str, eval_result: dict):
    """Store quality evaluation in evolution_outcomes for pattern detection."""
    db = _get_db()
    try:
        db.execute("""
            CREATE TABLE IF NOT EXISTS evolution_outcomes (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                source TEXT, source_id TEXT, action TEXT,
                result TEXT, details TEXT, failure_reason TEXT,
                duration_seconds REAL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        db.execute("""
            INSERT INTO evolution_outcomes (source, source_id, action, result, details)
            VALUES (?, ?, ?, ?, ?)
        """, [
            "quality_eval", task_id, "complete_task",
            "flagged" if eval_result["flagged"] else "verified" if eval_result["verified"] else "unverified",
            json.dumps({
                "eval_score": eval_result["eval_score"],
                "self_score": eval_result["self_score"],
                "divergence": eval_result["divergence"],
                "checks": eval_result["checks"],
                "verified": eval_result["verified"],
            }),
        ])
        db.commit()
    except Exception as e:
        log.debug("Evolution record failed: %s", e)
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Special Liaison Review Gate
# ---------------------------------------------------------------------------

class TaskReviewFailed(Exception):
    """Raised by complete_task() when the Special Liaison review returns FAIL.

    The caller must fix the work and retry complete_task().
    The exception message contains the critique from the review.
    """


def review_task(task_id: str, output: str, reviewer: str = "special_liaison") -> dict:
    """Evaluate task output via the Special Liaison (intel_agent_v2) review gate.

    Checks the output against:
      (a) Acceptance criteria extracted from the task description
      (b) V2 discipline compliance — falsifiability of claims, absence of weasel
          words, evidence of adversarial self-critique

    Returns:
        {
            "verdict": "PASS" | "FAIL",
            "score": 0.0 – 1.0,
            "critique": "<explanation>",
            "reviewer": "special_liaison",
            "task_id": task_id,
            "checks": {<named check>: bool, ...}
        }

    The review is logged to execution_log with actor="special_liaison" so it
    appears in the audit trail alongside normal harness executions.
    Falsifiability of this function's own verdict: if all named checks pass
    and no weasel words are detected, verdict=PASS. If any check fails,
    verdict=FAIL. The score is (passing checks) / (total checks).
    """
    import re
    import secrets as _secrets
    import time

    t_start = time.monotonic()

    # ── 1. Fetch task details ─────────────────────────────────────
    db = _get_db()
    task_row = db.execute(
        "SELECT title, description, priority FROM company_issues WHERE id=?", (task_id,)
    ).fetchone()
    db.close()

    if not task_row:
        # Task not found — can't review, FAIL defensively
        return {
            "verdict": "FAIL",
            "score": 0.0,
            "critique": f"Task {task_id} not found — cannot evaluate.",
            "reviewer": reviewer,
            "task_id": task_id,
            "checks": {},
        }

    title = task_row["title"] or ""
    description = task_row["description"] or ""
    output_str = output or ""

    # ── 2. Extract acceptance criteria from description ───────────
    # Criteria are numbered lines, bullet points, or lines starting with "- "
    # e.g. "1. Do X\n2. Do Y" or "- criterion A\n- criterion B"
    criteria = []
    for line in description.splitlines():
        stripped = line.strip()
        # Numbered: "1." / "1)" / "Step 1:"
        if re.match(r"^\d+[\.\)]\s+\S", stripped):
            criteria.append(re.sub(r"^\d+[\.\)]\s+", "", stripped))
        # Bullet: "- " or "* "
        elif re.match(r"^[-\*]\s+\S", stripped):
            criteria.append(re.sub(r"^[-\*]\s+", "", stripped))

    # ── 3. Run named checks ───────────────────────────────────────
    checks: dict[str, bool] = {}

    # Check A: output is non-empty / substantive
    checks["output_substantive"] = len(output_str.strip()) >= 20

    # Check B: no weasel words (V2 discipline — "should work", "probably", "seems")
    weasel_pattern = re.compile(
        r"\b(should work|probably fix|seems correct|might work|appears to work"
        r"|hopefully|should be fine|likely works|it seems|probably done)\b",
        re.IGNORECASE,
    )
    checks["no_weasel_words"] = not bool(weasel_pattern.search(output_str))

    # Check C: falsifiable claim present — output contains a verification command,
    # file path, test result, or explicit "verified by" statement
    falsifiability_pattern = re.compile(
        r"(verified|verification|confirmed|test pass|exit 0|grep|SELECT|assert"
        r"|PASS|FAIL|output:|result:|checked|`[^`]+`|\$ [a-z])",
        re.IGNORECASE,
    )
    checks["falsifiable_claim"] = bool(falsifiability_pattern.search(output_str))

    # Check D: acceptance criteria coverage — each criterion keyword appears in output
    if criteria:
        covered = 0
        for criterion in criteria:
            # Extract the first 4 significant words as a keyword probe
            words = [w for w in re.split(r"\W+", criterion.lower()) if len(w) > 3][:4]
            if words and any(w in output_str.lower() for w in words):
                covered += 1
        checks["criteria_coverage"] = (covered / len(criteria)) >= 0.5
    else:
        # No explicit criteria — skip this check (not penalised)
        checks["criteria_coverage"] = True

    # Check E: adversarial critique signal — output acknowledges limitations,
    # edge cases, or explicitly names what was NOT done / what could fail
    adversarial_pattern = re.compile(
        r"(caveat|limitation|edge case|not cover|does not|won't|cannot|known issue"
        r"|open question|follow.?up|gap|risk|falsified if|would fail if|honest.?null)",
        re.IGNORECASE,
    )
    checks["adversarial_critique"] = bool(adversarial_pattern.search(output_str))

    # ── 4. Score and verdict ──────────────────────────────────────
    # Weight: output_substantive is a hard gate (0 score if absent).
    # Other checks each contribute equally to the remaining score.
    if not checks["output_substantive"]:
        score = 0.0
        critique_parts = ["Output is empty or trivially short — cannot evaluate."]
    else:
        scored_checks = {k: v for k, v in checks.items() if k != "output_substantive"}
        passing = sum(1 for v in scored_checks.values() if v)
        total = len(scored_checks)
        score = round(passing / total, 2) if total else 1.0

        critique_parts = []
        if not checks["no_weasel_words"]:
            critique_parts.append(
                "Weasel words detected — replace with verified observable claims."
            )
        if not checks["falsifiable_claim"]:
            critique_parts.append(
                "No falsifiability signal — add a verification command, test result, or explicit"
                " 'verified by' statement."
            )
        if not checks.get("criteria_coverage", True):
            critique_parts.append(
                "Acceptance criteria coverage below 50% — address missing criteria explicitly."
            )
        if not checks["adversarial_critique"]:
            critique_parts.append(
                "No adversarial self-critique found — state what this does NOT cover or what"
                " could still fail."
            )

    # PASS threshold: score >= 0.6 (3 of 4 scored checks pass)
    verdict = "PASS" if score >= 0.6 else "FAIL"
    critique = " | ".join(critique_parts) if critique_parts else "All checks passed."

    # ── Real Special Liaison review goes through Claude Code subscription ──
    # review_task() is a regex pre-filter only. The full LLM review is done
    # via Agent tool spawn by Neuro, NOT via the Anthropic API directly.
    #
    # Flow:
    #   1. Neuro calls review_task(task_id, output) — regex pre-filter (this fn)
    #   2. Neuro spawns Agent tool with intel_agent_v2 / Special Liaison persona
    #   3. Agent returns verdict; Neuro calls record_liaison_verdict(task_id, ...)
    #   4. complete_task() checks execution_log for the PASS row and proceeds
    #
    # No API calls here. No anthropic import. Cost = $0 for this fn.

    duration_ms = int((time.monotonic() - t_start) * 1000)

    # ── 5. Log to execution_log ───────────────────────────────────
    # review_task() is regex-only (pre-filter). Cost = 0, task_type = deterministic.
    # The real Agent-based review is recorded via record_liaison_verdict().
    try:
        db = _get_db()
        run_id = _secrets.token_urlsafe(8)
        db.execute("""
            INSERT INTO execution_log
            (id, run_id, actor, action, entity_type, entity_id,
             detail, quality_score, success, duration_ms,
             cost_cents, cost_cents_actual, cost_cents_equivalent,
             task_type, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        """, (
            _secrets.token_urlsafe(8), run_id,
            reviewer,                           # actor = "special_liaison"
            f"review_prefilter:{task_id}",      # pre-filter pass, not full review
            "company_issue", task_id,
            json.dumps({
                "verdict": verdict, "score": score,
                "critique": critique, "checks": checks,
                "title": title,
                "llm_ran": False,               # regex-only, no LLM
            }),
            score,
            1 if verdict == "PASS" else 0,
            duration_ms,
            0,                # cost_cents: $0 — regex pre-filter
            0,                # cost_cents_actual: $0
            None,             # cost_cents_equivalent
            "deterministic",  # regex-only check
        ))
        db.commit()
        db.close()
    except Exception as e:
        log.debug("review_task execution_log write failed (non-fatal): %s", e)

    log.info(
        "Special Liaison review: task=%s verdict=%s score=%.2f critique=%s",
        task_id, verdict, score, critique,
    )

    return {
        "verdict": verdict,
        "score": score,
        "critique": critique,
        "reviewer": reviewer,
        "task_id": task_id,
        "checks": checks,
    }


def set_review_required(task_id: str, required: bool = True) -> dict:
    """Mark a task as requiring Special Liaison review before completion.

    High-priority and critical tasks auto-require review without calling this
    function. Use set_review_required() to explicitly gate any other task.

    Returns the updated task dict, or {"error": "..."} if task not found.
    """
    db = _get_db()

    # Migration-safe: add review_required column if it doesn't exist yet
    try:
        db.execute("SELECT review_required FROM company_issues LIMIT 0")
    except Exception:
        try:
            db.execute(
                "ALTER TABLE company_issues ADD COLUMN review_required INTEGER DEFAULT 0"
            )
            db.commit()
            log.info("Migration: added review_required column to company_issues")
        except Exception as e:
            log.debug("review_required migration failed (non-fatal): %s", e)

    cur = db.execute(
        "UPDATE company_issues SET review_required=?, updated_at=datetime('now') WHERE id=?",
        (1 if required else 0, task_id),
    )
    db.commit()

    if cur.rowcount == 0:
        db.close()
        return {"error": f"Task {task_id} not found"}

    result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())
    db.close()
    log.info("Task %s review_required set to %s", task_id, required)
    return result


def flag_review_pending(task_id: str) -> dict:
    """Write review_pending=1 to company_issues for the given task.

    Signals that Neuro (CEO) must spawn a Special Liaison Agent review before
    the task can be completed. Does NOT block completion on its own — the gate
    lives in complete_task() which checks execution_log for a PASS verdict
    from record_liaison_verdict().

    Use this as a visual marker so list_tasks() output shows which tasks are
    awaiting liaison review.

    Returns the updated task dict, or {"error": "..."} if task not found.
    """
    db = _get_db()

    # Migration-safe: add review_pending column if it doesn't exist yet
    try:
        db.execute("SELECT review_pending FROM company_issues LIMIT 0")
    except Exception:
        try:
            db.execute(
                "ALTER TABLE company_issues ADD COLUMN review_pending INTEGER DEFAULT 0"
            )
            db.commit()
            log.info("Migration: added review_pending column to company_issues")
        except Exception as e:
            log.debug("review_pending migration failed (non-fatal): %s", e)

    cur = db.execute(
        "UPDATE company_issues SET review_pending=1, updated_at=datetime('now') WHERE id=?",
        (task_id,),
    )
    db.commit()

    if cur.rowcount == 0:
        db.close()
        return {"error": f"Task {task_id} not found"}

    result = dict(db.execute("SELECT * FROM company_issues WHERE id=?", (task_id,)).fetchone())
    db.close()
    log.info("Task %s flagged review_pending=1", task_id)
    return result


def record_liaison_verdict(task_id: str, verdict: str, score: float,
                           critique: str) -> dict:
    """Record the Special Liaison Agent verdict to execution_log.

    Called by Neuro AFTER the Agent-based Special Liaison review runs and
    returns a verdict. Writes an execution_log row with actor='special_liaison'
    and success=1 (PASS) or success=0 (FAIL).

    Once a PASS row exists for task_id, complete_task() will allow completion
    for high/critical tasks. No PASS row → complete_task() raises TaskReviewFailed.

    Also clears review_pending flag on the task if set.

    Args:
        task_id: The task that was reviewed.
        verdict: "PASS" or "FAIL".
        score: Quality score 0.0–1.0 from the liaison agent.
        critique: Explanation from the liaison agent.

    Returns:
        The execution_log row dict, or {"error": "..."} on failure.

    Falsifiability: after calling this with verdict="PASS", the query
        SELECT * FROM execution_log
        WHERE entity_id=<task_id> AND actor='special_liaison' AND success=1
    must return exactly one row (or more if called multiple times).
    """
    import secrets as _secrets
    import time

    if verdict not in ("PASS", "FAIL"):
        return {"error": f"Invalid verdict '{verdict}' — must be 'PASS' or 'FAIL'"}

    success = 1 if verdict == "PASS" else 0
    run_id = _secrets.token_urlsafe(8)
    try:
        db = _get_db()
        db.execute("""
            INSERT INTO execution_log
            (run_id, actor, action, entity_type, entity_id,
             detail, quality_score, success, duration_ms,
             cost_cents, cost_cents_actual,
             task_type, verdict, critique, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, datetime('now'))
        """, (
            run_id,
            "special_liaison",
            f"agent_review:{task_id}",
            "company_issue", task_id,
            json.dumps({"verdict": verdict, "score": score, "critique": critique}),
            score,
            success,
            0,
            0,
            0,
            "judgment",
            verdict,
            critique,
        ))

        # Clear review_pending flag if the column exists
        try:
            db.execute(
                "UPDATE company_issues SET review_pending=0, updated_at=datetime('now') WHERE id=?",
                (task_id,),
            )
        except Exception:
            pass  # column may not exist on older schemas — non-fatal

        db.commit()
        result = dict(db.execute(
            "SELECT * FROM execution_log WHERE entity_id=? AND actor='special_liaison' ORDER BY id DESC LIMIT 1", (task_id,)
        ).fetchone())
        db.close()
    except Exception as e:
        log.warning("record_liaison_verdict failed: %s", e)
        return {"error": str(e)}

    log.info(
        "Liaison verdict recorded: task=%s verdict=%s score=%.2f",
        task_id, verdict, score,
    )
    return result


# ---------------------------------------------------------------------------
# Approvals
# ---------------------------------------------------------------------------

def request_approval(company_id: str, approval_type: str,
                     agent_id: str, payload: dict) -> dict:
    """Request board approval for an action."""
    db = _get_db()
    approval_id = secrets.token_urlsafe(8)

    db.execute("""
        INSERT INTO company_approvals (id, company_id, type, requested_by_agent_id, payload)
        VALUES (?, ?, ?, ?, ?)
    """, (approval_id, company_id, approval_type, agent_id, json.dumps(payload)))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_approvals WHERE id=?", (approval_id,)).fetchone())
    db.close()

    log.info("Approval requested: %s (company %s)", approval_type, company_id)
    return result


def approve(approval_id: str, note: str = "") -> dict:
    """Approve a pending request."""
    db = _get_db()
    db.execute("""
        UPDATE company_approvals
        SET status='approved', decision_note=?, decided_at=datetime('now')
        WHERE id=? AND status IN ('pending', 'revision_requested')
    """, (note, approval_id))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_approvals WHERE id=?", (approval_id,)).fetchone())
    db.close()
    return result


def reject(approval_id: str, note: str = "") -> dict:
    """Reject a pending request."""
    db = _get_db()
    db.execute("""
        UPDATE company_approvals
        SET status='rejected', decision_note=?, decided_at=datetime('now')
        WHERE id=? AND status IN ('pending', 'revision_requested')
    """, (note, approval_id))
    db.commit()

    result = dict(db.execute("SELECT * FROM company_approvals WHERE id=?", (approval_id,)).fetchone())
    db.close()
    return result


def pending_approvals(company_id: str) -> list:
    """List pending approvals for a company."""
    db = _get_db()
    rows = db.execute(
        "SELECT * FROM company_approvals WHERE company_id=? AND status IN ('pending','revision_requested') ORDER BY created_at",
        (company_id,)
    ).fetchall()
    db.close()
    return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def cli_main(args: list):
    """Handle company CLI commands."""
    if not args:
        print("Usage:")
        print("  aibrain company create <name> [--mission <text>]")
        print("  aibrain company list")
        print("  aibrain company status <name_or_id>")
        print("  aibrain agent hire <name> --company <id> [--role ceo|manager|general]")
        print("  aibrain agent list --company <id>")
        print("  aibrain task create <title> --company <id> [--assign <agent_id>]")
        print("  aibrain task list --company <id>")
        print("  aibrain inbox --company <id>")
        print("  aibrain approve <approval_id>")
        print("  aibrain reject <approval_id>")
        return

    subcmd = args[0]

    if subcmd == "create":
        name = args[1] if len(args) > 1 else input("Company name: ")
        mission = ""
        if "--mission" in args:
            idx = args.index("--mission")
            mission = args[idx + 1] if idx + 1 < len(args) else ""
        result = create_company(name, mission)
        if "error" in result:
            print(f"Error: {result['error']}")
        else:
            print(f"Company '{name}' created (ID: {result['id']})")

    elif subcmd == "list":
        companies = list_companies()
        if not companies:
            print("No companies. Create one: aibrain company create <name>")
        else:
            print(f"\n{'Name':<25} {'Status':<10} {'Agents':>7} {'ID'}")
            print("-" * 55)
            for c in companies:
                db = _get_db()
                agents = db.execute("SELECT COUNT(*) FROM company_agents WHERE company_id=?", (c['id'],)).fetchone()[0]
                db.close()
                print(f"{c['name']:<25} {c['status']:<10} {agents:>7} {c['id']}")

    elif subcmd == "status":
        company_ref = args[1] if len(args) > 1 else ""
        db = _get_db()
        company = db.execute("SELECT * FROM companies WHERE id=? OR name=?", (company_ref, company_ref)).fetchone()
        db.close()
        if not company:
            print(f"Company '{company_ref}' not found")
            return
        info = get_company(company["id"])
        print(f"\n  {info['name']} ({info['status']})")
        print(f"  Mission: {info.get('mission', '-')}")
        print(f"  Agents: {info['agent_count']}")
        print(f"  Active tasks: {info['active_tasks']}")
        print(f"  Completed: {info['completed_tasks']}")

    else:
        print(f"Unknown company command: {subcmd}")


# ---------------------------------------------------------------------------
# Teams
# ---------------------------------------------------------------------------

def _ensure_teams_table():
    """Create teams table if missing."""
    db = _get_db()
    db.execute("""
        CREATE TABLE IF NOT EXISTS teams (
            id TEXT PRIMARY KEY,
            company_id TEXT NOT NULL,
            name TEXT NOT NULL,
            agent_ids TEXT DEFAULT '[]',
            task_ids TEXT DEFAULT '[]',
            process TEXT DEFAULT 'sequential',
            status TEXT DEFAULT 'ready',
            last_run TEXT,
            last_result TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (company_id) REFERENCES companies(id)
        )
    """)
    db.commit()
    db.close()


_ensure_teams_table()


def _ensure_review_required_column():
    """Add review_required column to company_issues if it doesn't exist.

    Migration-safe: runs at module import. No-ops if column already present.
    """
    try:
        db = _get_db()
        db.execute("SELECT review_required FROM company_issues LIMIT 0")
        db.close()
    except Exception:
        try:
            db = _get_db()
            db.execute(
                "ALTER TABLE company_issues ADD COLUMN review_required INTEGER DEFAULT 0"
            )
            db.commit()
            db.close()
            log.info("Migration: added review_required column to company_issues")
        except Exception as e:
            log.debug("review_required column migration failed: %s", e)


_ensure_review_required_column()


def create_team(company_id: str, name: str, agent_ids: list = None,
                task_ids: list = None, process: str = "sequential") -> dict:
    """Create a team within a company from selected agents and tasks.

    If agent_ids is None, uses all company agents.
    If task_ids is None, uses all pending/todo tasks.
    """
    db = _get_db()

    # Verify company exists
    company = db.execute("SELECT id FROM companies WHERE id=?", (company_id,)).fetchone()
    if not company:
        db.close()
        return {"error": "Company not found"}

    # Resolve agent IDs — default to all company agents
    if agent_ids is None:
        rows = db.execute(
            "SELECT id FROM company_agents WHERE company_id=? AND status != 'terminated'",
            (company_id,)
        ).fetchall()
        agent_ids = [r["id"] for r in rows]

    # Resolve task IDs — default to all pending/todo tasks
    if task_ids is None:
        rows = db.execute(
            "SELECT id FROM company_issues WHERE company_id=? AND status IN ('backlog','todo','in_progress')",
            (company_id,)
        ).fetchall()
        task_ids = [r["id"] for r in rows]

    team_id = secrets.token_urlsafe(8)
    now = datetime.now().isoformat()

    db.execute("""
        INSERT INTO teams (id, company_id, name, agent_ids, task_ids, process, created_at)
        VALUES (?, ?, ?, ?, ?, ?, ?)
    """, (team_id, company_id, name, json.dumps(agent_ids), json.dumps(task_ids), process, now))
    db.commit()

    result = dict(db.execute("SELECT * FROM teams WHERE id=?", (team_id,)).fetchone())
    db.close()

    # Parse JSON fields for the response
    result["agent_ids"] = json.loads(result.get("agent_ids") or "[]")
    result["task_ids"] = json.loads(result.get("task_ids") or "[]")

    log.info("Team created: %s (%s) for company %s", name, team_id, company_id)
    return result


def list_teams(company_id: str) -> list:
    """List all teams for a company."""
    db = _get_db()
    rows = db.execute(
        "SELECT * FROM teams WHERE company_id=? ORDER BY created_at DESC",
        (company_id,)
    ).fetchall()
    db.close()
    teams = []
    for r in rows:
        t = dict(r)
        t["agent_ids"] = json.loads(t.get("agent_ids") or "[]")
        t["task_ids"] = json.loads(t.get("task_ids") or "[]")
        teams.append(t)
    return teams


def get_team(team_id: str) -> Optional[dict]:
    """Get team details including agent and task info."""
    db = _get_db()
    row = db.execute("SELECT * FROM teams WHERE id=?", (team_id,)).fetchone()
    if not row:
        db.close()
        return None

    result = dict(row)
    result["agent_ids"] = json.loads(result.get("agent_ids") or "[]")
    result["task_ids"] = json.loads(result.get("task_ids") or "[]")

    # Enrich with agent details
    agents = []
    for aid in result["agent_ids"]:
        agent = db.execute("SELECT id, name, role, title, status FROM company_agents WHERE id=?", (aid,)).fetchone()
        if agent:
            agents.append(dict(agent))
    result["agents"] = agents

    # Enrich with task details
    tasks = []
    for tid in result["task_ids"]:
        task = db.execute("SELECT id, title, status, priority, quality_score FROM company_issues WHERE id=?", (tid,)).fetchone()
        if task:
            tasks.append(dict(task))
    result["tasks"] = tasks

    # Parse last_result if present
    if result.get("last_result"):
        try:
            result["last_result"] = json.loads(result["last_result"])
        except (json.JSONDecodeError, TypeError):
            pass

    db.close()
    return result


def delete_team(team_id: str) -> bool:
    """Delete a team."""
    db = _get_db()
    existing = db.execute("SELECT id FROM teams WHERE id=?", (team_id,)).fetchone()
    if not existing:
        db.close()
        return False
    db.execute("DELETE FROM teams WHERE id=?", (team_id,))
    db.commit()
    db.close()
    log.info("Team deleted: %s", team_id)
    return True


def run_team(company_id: str, team_id: str, inputs: dict = None) -> dict:
    """Execute a team — assembles Agent/Task objects, creates Team, calls kickoff().

    Stores results back to the company tasks (updates status, stores output).
    """
    db = _get_db()
    team_row = db.execute(
        "SELECT * FROM teams WHERE id=? AND company_id=?",
        (team_id, company_id)
    ).fetchone()
    if not team_row:
        db.close()
        return {"error": "Team not found"}

    team_data = dict(team_row)
    agent_ids = json.loads(team_data.get("agent_ids") or "[]")
    task_ids = json.loads(team_data.get("task_ids") or "[]")
    process = team_data.get("process", "sequential")

    # Mark team as running
    db.execute("UPDATE teams SET status='running' WHERE id=?", (team_id,))
    db.commit()
    db.close()

    try:
        from aibrain.core.agents import Agent, Task, Team

        # Build Agent objects from DB
        agent_map = {}
        agents = []
        for aid in agent_ids:
            db_agent = get_agent(aid)
            if not db_agent:
                continue
            agent = Agent(
                id=db_agent["id"],
                role=db_agent.get("role", "general"),
                goal=db_agent.get("title", db_agent.get("name", "")),
                llm=db_agent.get("model", "auto"),
                backstory=db_agent.get("capabilities", ""),
            )
            agents.append(agent)
            agent_map[aid] = agent

        # Build Task objects from DB
        tasks = []
        for tid in task_ids:
            db2 = _get_db()
            db_task = db2.execute("SELECT * FROM company_issues WHERE id=?", (tid,)).fetchone()
            db2.close()
            if not db_task:
                continue
            db_task = dict(db_task)
            assignee = agent_map.get(db_task.get("assignee_agent_id", ""))
            task = Task(
                id=db_task["id"],
                description=db_task.get("title", ""),
                expected_output=db_task.get("description", "Complete the task successfully"),
                agent=assignee,
            )
            tasks.append(task)

        if not agents:
            db = _get_db()
            db.execute("UPDATE teams SET status='failed', last_run=datetime('now') WHERE id=?", (team_id,))
            db.commit()
            db.close()
            return {"error": "No valid agents found for this team"}

        if not tasks:
            db = _get_db()
            db.execute("UPDATE teams SET status='failed', last_run=datetime('now') WHERE id=?", (team_id,))
            db.commit()
            db.close()
            return {"error": "No valid tasks found for this team"}

        # Create and run the Team
        company = get_company(company_id)
        team = Team(
            name=company.get("name", "team") + "/" + team_data.get("name", "team"),
            agents=agents,
            tasks=tasks,
            process=process,
            memory=True,
        )

        team_output = team.kickoff(inputs=inputs or {})

        # Store results back
        result_dict = team_output.model_dump()
        db = _get_db()

        # Update task statuses with quality scores
        for task_out in team_output.task_outputs:
            if task_out.task_id:
                db.execute("""
                    UPDATE company_issues
                    SET status='done', quality_score=?, completed_at=datetime('now'), updated_at=datetime('now')
                    WHERE id=?
                """, (task_out.quality, task_out.task_id))

        # Update team record
        db.execute("""
            UPDATE teams SET status='completed', last_run=datetime('now'), last_result=?
            WHERE id=?
        """, (json.dumps(result_dict), team_id))
        db.commit()
        db.close()

        log.info("Team run completed: %s (success=%s)", team_id, team_output.success)
        return result_dict

    except Exception as e:
        log.error("Team run failed: %s — %s", team_id, e)
        db = _get_db()
        db.execute("""
            UPDATE teams SET status='failed', last_run=datetime('now'),
            last_result=? WHERE id=?
        """, (json.dumps({"error": str(e)}), team_id))
        db.commit()
        db.close()
        return {"error": str(e), "success": False}
