"""
retrolearn_scanner.py — Retroactive learning from Claude Code session JSONL history.

Scans ~/.claude*/projects/**/*.jsonl session files and extracts three-signal
learning moments (corrections, praise, self_reflection) using the same patterns
as realtime_learner.py. Writes extracted memories into the brain DB.

Key design decisions:
- Streaming line-by-line reads — handles >100MB session files without OOM.
- Path-based dedup — once a file is scanned, its path is recorded in a
  retrolearn_log table so re-runs skip it cleanly.
- Secrets filter applied per extracted memory before any DB write.
- All memories tagged with source_agent='retrolearn_user_install' for provenance.
- Graceful per-line try/except — malformed/truncated JSONL never aborts a scan.

Usage:
    from aibrain.core.retrolearn_scanner import retrolearn_all, find_session_files
    files = find_session_files()
    result = retrolearn_all(files, dry_run=False)
"""

from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable


# ---------------------------------------------------------------------------
# Environment bootstrapping — load ~/.decker_env so downstream code
# (aibrain_licensing, secrets, etc.) has the env vars it needs.
# Must run BEFORE any lazy imports of aibrain_licensing which raises
# ValueError at import time when AIBRAIN_SIGNING_KEY is missing.
# ---------------------------------------------------------------------------

def _load_decker_env() -> None:
    """Parse ~/.decker_env and set any missing env vars in os.environ.

    Handles both ``export VAR=val`` and bare ``VAR=val`` lines.
    Skips comments and blank lines. Values may be optionally quoted
    with single or double quotes.
    """
    env_file = Path.home() / ".decker_env"
    if not env_file.exists():
        return
    try:
        for line in env_file.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            # Strip leading 'export ' if present
            if line.startswith("export "):
                line = line[len("export "):]
            if "=" not in line:
                continue
            key, val = line.split("=", 1)
            key = key.strip()
            val = val.strip().strip('"').strip("'")
            if key and key not in os.environ:
                os.environ[key] = val
    except OSError:
        pass


def _require_signing_key() -> None:
    """Verify AIBRAIN_SIGNING_KEY is available. Raises RuntimeError if not.

    Call this AFTER _load_decker_env() and BEFORE any memory writes to
    fail fast instead of silently skipping writes and marking files as
    processed.
    """
    if not os.environ.get("AIBRAIN_SIGNING_KEY"):
        raise RuntimeError(
            "AIBRAIN_SIGNING_KEY is not set. Memory writes will fail. "
            "Set it in ~/.decker_env or export it before running "
            "learn-from-history. Aborting to avoid marking files as "
            "processed without actually writing memories."
        )

# ---------------------------------------------------------------------------
# Signal patterns — mirrors realtime_learner.LEARNING_SIGNALS
# (local copy avoids cross-import issues; source of truth is realtime_learner)
# ---------------------------------------------------------------------------

import re

_SIGNALS: dict[str, dict] = {
    "correction": {
        "patterns": [
            re.compile(p, re.IGNORECASE)
            for p in [
                r"was wrong",
                r"actually[,:]?\s",
                r"turns out",
                r"realized",
                r"correction:",
                r"corrected",
                r"I was wrong",
                r"misidentified",
                r"false positive",
            ]
        ],
        "roles": ("human", "user", "assistant"),
    },
    "self_reflection": {
        "patterns": [
            re.compile(p, re.IGNORECASE)
            for p in [
                r"\bi should have\b",
                r"\blet me reconsider\b",
                r"\bon second thought\b",
                r"\bi realize(?:d)? (?:now|that|i)\b",
                r"\bi was wrong about\b",
                r"\bactually,? (?:that|this|i)'?s not\b",
                r"\blet me correct myself\b",
                r"\bwait,? (?:that|this)'?s not right\b",
                r"\bi need to rethink\b",
                r"\bthat doesn'?t (?:actually )?work because\b",
                r"\bhmm,? actually\b",
                r"\bi missed that\b",
            ]
        ],
        "roles": ("assistant",),
    },
    "praise": {
        "patterns": [
            re.compile(p, re.IGNORECASE)
            for p in [
                r"\byes[!,.]? exactly\b",
                r"\bperfect[!,.]?\b",
                r"\bgreat work\b",
                r"\bwell done\b",
                r"\bgood job\b",
                r"\bgood call\b",
                r"\bnicely done\b",
                r"\bthat'?s (?:it|right|exactly right|perfect)\b",
                r"\bspot on\b",
                r"\bbeautiful[!.]",
                r"\bbrilliant[!.]",
                r"\blove (?:it|that)[!.]",
                r"\bkeep doing (?:that|this)\b",
                r"\bexcellent work\b",
                r"\bnice catch\b",
            ]
        ],
        "roles": ("human", "user"),
    },
}

_IMPORTANCE_MAP = {
    "correction": 0.8,
    "self_reflection": 0.75,
    "praise": 0.8,
}

_TYPE_MAP = {
    "correction": "correction",
    "self_reflection": "self_reflection",
    "praise": "praise",
}

# ---------------------------------------------------------------------------
# Retrolearn log table DDL — dedup by scanned file path
# ---------------------------------------------------------------------------

_RETROLEARN_DDL = """
CREATE TABLE IF NOT EXISTS retrolearn_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    file_path TEXT NOT NULL UNIQUE,
    scanned_at TEXT NOT NULL,
    memories_extracted INTEGER DEFAULT 0,
    secrets_skipped INTEGER DEFAULT 0
);
"""


def _ensure_retrolearn_table(db_path: Path) -> None:
    """Create retrolearn_log table if it doesn't exist."""
    conn = sqlite3.connect(str(db_path))
    try:
        conn.executescript(_RETROLEARN_DDL)
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def find_session_files(base_dirs: list[Path] | None = None) -> list[Path]:
    """Find all .jsonl session files under ~/.claude*/projects/.

    Args:
        base_dirs: Override discovery directories. Defaults to all .claude*
                   directories under Path.home().

    Returns:
        Sorted list of .jsonl file paths (sorted by path string).
    """
    home = Path.home()

    if base_dirs is None:
        # Match ~/.claude, ~/.claude-sindecker, etc.
        base_dirs = [p for p in home.iterdir() if p.is_dir() and p.name.startswith(".claude")]

    results: list[Path] = []
    for base in base_dirs:
        projects_dir = base / "projects"
        if not projects_dir.is_dir():
            continue
        for p in projects_dir.rglob("*.jsonl"):
            if p.is_file():
                results.append(p)

    return sorted(results)


def count_turns(jsonl_path: Path) -> tuple[int, int]:
    """Count total lines and user-turn lines in a session JSONL file.

    Handles malformed lines gracefully. Does not load the full file into memory.

    Returns:
        (total_lines, user_turn_count)
    """
    total = 0
    user_turns = 0
    try:
        with jsonl_path.open("r", encoding="utf-8", errors="replace") as fh:
            for raw in fh:
                total += 1
                try:
                    obj = json.loads(raw)
                    role = _extract_role(obj)
                    if role in ("human", "user"):
                        user_turns += 1
                except (json.JSONDecodeError, TypeError):
                    pass
    except OSError:
        pass
    return total, user_turns


def is_already_scanned(jsonl_path: Path, db_path: Path | None = None) -> bool:
    """Check if this file was already retrolearned (dedup by path in retrolearn_log).

    Args:
        jsonl_path: Path to the session file to check.
        db_path: Brain DB path. Defaults to canonical AIBRAIN_ROOT / aibrain.db.

    Returns:
        True if already scanned (skip it), False if new.
    """
    resolved = str(jsonl_path.resolve())
    db = _resolve_db_path(db_path)
    if not db.exists():
        return False
    try:
        _ensure_retrolearn_table(db)
        conn = sqlite3.connect(str(db))
        try:
            row = conn.execute(
                "SELECT id FROM retrolearn_log WHERE file_path = ?", (resolved,)
            ).fetchone()
            return row is not None
        finally:
            conn.close()
    except sqlite3.Error:
        return False


def scan_file(
    jsonl_path: Path,
    signals: list[str] | None = None,
    dry_run: bool = False,
    secrets_filter=None,
) -> dict:
    """Extract learning signals from a single session JSONL file.

    Args:
        jsonl_path: Path to the .jsonl session file.
        signals: Which signal types to extract. Defaults to all three:
                 ["correction", "praise", "self_reflection"].
        dry_run: If True, extract but do not write to DB.
        secrets_filter: Optional callable(text) -> RedactionResult. If None,
                        imports from aibrain.core.secrets_filter.

    Returns:
        {
            "extracted": int,          # memories written (or would-be if dry_run)
            "skipped_secrets": int,    # turns dropped entirely due to secrets
            "memories": [list of memory dicts],
            "by_signal": {signal: count},
        }
    """
    if signals is None:
        signals = ["correction", "praise", "self_reflection"]

    # Lazy-import secrets filter to avoid circular imports
    if secrets_filter is None:
        try:
            from aibrain.core.secrets_filter import redact_secrets
            secrets_filter = redact_secrets
        except ImportError:
            secrets_filter = None

    active_signals = {k: v for k, v in _SIGNALS.items() if k in signals}

    extracted_memories: list[dict] = []
    skipped_secrets = 0
    seen_hashes: set[str] = set()
    by_signal: dict[str, int] = {s: 0 for s in signals}

    try:
        with jsonl_path.open("r", encoding="utf-8", errors="replace") as fh:
            for raw in fh:
                # Per-line guard — malformed JSONL never aborts the scan
                try:
                    obj = json.loads(raw)
                except (json.JSONDecodeError, ValueError):
                    continue

                role = _extract_role(obj)
                if role not in ("human", "user", "assistant"):
                    continue

                text = _extract_text(obj)
                if not text or len(text) < 40:
                    continue

                # Apply secrets filter BEFORE extraction — if the raw turn has
                # a secret in it, redact first so the extracted snippet is clean
                if secrets_filter is not None:
                    result = secrets_filter(text)
                    if not result.was_clean:
                        # If more than 2 secrets found, skip the whole turn to
                        # avoid storing context that's mostly credential material
                        if result.count > 2:
                            skipped_secrets += 1
                            continue
                        text = result.text  # use redacted version

                # Check each signal type
                for sig_name, sig_def in active_signals.items():
                    # Role restriction
                    if role not in sig_def["roles"]:
                        continue

                    for pat in sig_def["patterns"]:
                        m = pat.search(text)
                        if not m:
                            continue

                        # Extract a ~200-char window around the match
                        start = max(0, m.start() - 80)
                        end = min(len(text), m.end() + 120)
                        snippet = text[start:end].strip()

                        # Dedup by snippet hash
                        h = hashlib.md5(snippet[:200].encode()).hexdigest()[:10]
                        if h in seen_hashes:
                            break
                        seen_hashes.add(h)

                        # Apply secrets filter to the snippet itself
                        if secrets_filter is not None:
                            r2 = secrets_filter(snippet)
                            if r2.count > 2:
                                skipped_secrets += 1
                                break
                            snippet = r2.text

                        mem = {
                            "name": f"retrolearn_{sig_name}_{h}",
                            "type": _TYPE_MAP[sig_name],
                            "content": snippet,
                            "importance": _IMPORTANCE_MAP[sig_name],
                            "tags": f"retrolearn,{sig_name},session_history,auto-extracted",
                            "source_agent": "retrolearn_user_install",
                            "session_file": str(jsonl_path),
                        }
                        extracted_memories.append(mem)
                        by_signal[sig_name] = by_signal.get(sig_name, 0) + 1
                        break  # one match per signal per line is enough

    except OSError as e:
        print(f"[retrolearn] Warning: could not read {jsonl_path}: {e}", file=sys.stderr)

    return {
        "extracted": len(extracted_memories),
        "skipped_secrets": skipped_secrets,
        "memories": extracted_memories,
        "by_signal": by_signal,
    }


def retrolearn_all(
    files: list[Path],
    dry_run: bool = False,
    progress_callback: Callable[[int, int, Path], None] | None = None,
    max_age_days: int | None = None,
    db_path: Path | None = None,
) -> dict:
    """Scan all session files and write extracted memories to the brain DB.

    Args:
        files: List of .jsonl paths to process (from find_session_files()).
        dry_run: If True, extract but do not write to DB or mark as scanned.
        progress_callback: Optional callable(current_idx, total, current_file).
        max_age_days: If set, skip files older than this many days.
        db_path: Brain DB path. Defaults to canonical resolution.

    Returns:
        {
            "files_scanned": int,
            "files_skipped_dedup": int,
            "files_skipped_age": int,
            "total_extracted": int,
            "total_secrets_skipped": int,
            "by_signal": {signal: count},
            "errors": [str],
        }
    """
    from datetime import timedelta

    # Bootstrap environment from ~/.decker_env so AIBRAIN_SIGNING_KEY
    # and other vars are available for downstream imports.
    _load_decker_env()

    # Fail fast if signing key is still missing — writing memories will
    # silently fail and we'd mark files as processed for nothing.
    if not dry_run:
        _require_signing_key()

    resolved_db = _resolve_db_path(db_path)

    if not dry_run and resolved_db.exists():
        _ensure_retrolearn_table(resolved_db)

    total = len(files)
    files_scanned = 0
    files_skipped_dedup = 0
    files_skipped_age = 0
    total_extracted = 0
    total_secrets_skipped = 0
    by_signal: dict[str, int] = {"correction": 0, "praise": 0, "self_reflection": 0}
    errors: list[str] = []

    # Lazy-import secrets filter once
    try:
        from aibrain.core.secrets_filter import redact_secrets as _secrets_filter
    except ImportError:
        _secrets_filter = None

    # Age cutoff
    cutoff = None
    if max_age_days is not None:
        cutoff = datetime.now(timezone.utc).timestamp() - (max_age_days * 86400)

    for idx, fpath in enumerate(files):
        if progress_callback:
            progress_callback(idx, total, fpath)

        # Age filter
        if cutoff is not None:
            try:
                if fpath.stat().st_mtime < cutoff:
                    files_skipped_age += 1
                    continue
            except OSError:
                pass

        # Dedup check
        if not dry_run and is_already_scanned(fpath, resolved_db):
            files_skipped_dedup += 1
            continue

        # Scan
        try:
            result = scan_file(fpath, dry_run=dry_run, secrets_filter=_secrets_filter)
        except Exception as e:
            errors.append(f"{fpath}: {e}")
            continue

        files_scanned += 1
        total_extracted += result["extracted"]
        total_secrets_skipped += result["skipped_secrets"]
        for sig, cnt in result["by_signal"].items():
            by_signal[sig] = by_signal.get(sig, 0) + cnt

        # Write memories + mark as scanned.
        # CRITICAL: only mark as scanned if writes actually succeeded.
        # If _write_memories raises (e.g. missing signing key), we must
        # NOT mark the file — otherwise it will never be retried.
        if not dry_run and result["memories"]:
            try:
                _write_memories(result["memories"], resolved_db)
            except RuntimeError as e:
                # Fatal write failure — stop processing entirely.
                # Don't mark this or any subsequent file as scanned.
                errors.append(f"{fpath}: {e}")
                break
            _mark_scanned(fpath, resolved_db, result["extracted"], result["skipped_secrets"])
        elif not dry_run and result["extracted"] == 0:
            # Mark as scanned even if nothing extracted so we don't re-scan
            _mark_scanned(fpath, resolved_db, 0, result["skipped_secrets"])

    return {
        "files_scanned": files_scanned,
        "files_skipped_dedup": files_skipped_dedup,
        "files_skipped_age": files_skipped_age,
        "total_extracted": total_extracted,
        "total_secrets_skipped": total_secrets_skipped,
        "by_signal": by_signal,
        "errors": errors,
    }


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _resolve_db_path(db_path: Path | None = None) -> Path:
    """Return canonical brain DB path."""
    if db_path is not None:
        return Path(db_path)
    try:
        from aibrain_db import AIBRAIN_ROOT, DB_PATH
        return Path(DB_PATH)
    except ImportError:
        return Path.home() / "aibrain" / "aibrain.db"


def _extract_role(obj: dict) -> str:
    """Extract the role string from a session JSONL object."""
    # Claude Code session format: {role: "human"|"assistant", ...}
    # Or nested: {message: {role: "...", ...}}
    role = obj.get("role", "")
    if not role:
        inner = obj.get("message", {})
        if isinstance(inner, dict):
            role = inner.get("role", "")
    return role.lower()


def _extract_text(obj: dict) -> str:
    """Extract readable text from a session JSONL object."""
    # Try top-level content first
    content = obj.get("content")
    if isinstance(content, str):
        return content

    # Nested message object
    inner = obj.get("message", {})
    if isinstance(inner, dict):
        content = inner.get("content")
        if isinstance(content, str):
            return content
        if isinstance(content, list):
            parts = []
            for block in content:
                if isinstance(block, dict) and block.get("type") == "text":
                    parts.append(block.get("text", ""))
            return "\n".join(parts)

    # List content at top level
    if isinstance(content, list):
        parts = []
        for block in content:
            if isinstance(block, dict) and block.get("type") == "text":
                parts.append(block.get("text", ""))
        return "\n".join(parts)

    return ""


def _write_memories(memories: list[dict], db_path: Path) -> int:
    """Write extracted memories into the brain DB using create_memory.

    Returns the number of memories successfully written.
    Raises RuntimeError if ALL writes fail with the same root cause
    (e.g. missing signing key) so the caller can avoid marking the
    file as processed.
    """
    written = 0
    fatal_error: Exception | None = None
    try:
        import aibrain_db
        for mem in memories:
            try:
                aibrain_db.create_memory(
                    name=mem["name"],
                    mem_type=mem["type"],
                    content=mem["content"],
                    tags=mem["tags"],
                    importance=mem["importance"],
                    source_agent=mem["source_agent"],
                )
                written += 1
            except (ValueError, RuntimeError) as e:
                # Signing key / licensing errors are fatal — every
                # subsequent write will fail the same way.
                fatal_error = e
                break
            except Exception as e:
                # Individual write failures are non-fatal; log and continue
                print(
                    f"[retrolearn] Warning: failed to write memory '{mem['name']}': {e}",
                    file=sys.stderr,
                )
    except ImportError:
        # Fallback: raw SQLite write if aibrain_db unavailable
        _write_memories_raw(memories, db_path)
        written = len(memories)

    if fatal_error is not None:
        raise RuntimeError(
            f"Memory writes failed — {fatal_error}. "
            f"Only {written}/{len(memories)} written before failure."
        ) from fatal_error

    return written


def _write_memories_raw(memories: list[dict], db_path: Path) -> None:
    """Raw SQLite fallback for writing memories when aibrain_db is unavailable."""
    conn = sqlite3.connect(str(db_path))
    try:
        now = datetime.now(timezone.utc).isoformat()
        for mem in memories:
            try:
                conn.execute(
                    """INSERT OR IGNORE INTO memories
                       (name, type, content, tags, importance, source_agent, created, updated, active)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 1)""",
                    (
                        mem["name"], mem["type"], mem["content"],
                        mem["tags"], mem["importance"], mem["source_agent"],
                        now, now,
                    ),
                )
            except sqlite3.Error:
                pass
        conn.commit()
    finally:
        conn.close()


def _mark_scanned(
    fpath: Path,
    db_path: Path,
    memories_extracted: int,
    secrets_skipped: int,
) -> None:
    """Record this file in retrolearn_log so it's skipped on future runs."""
    _ensure_retrolearn_table(db_path)
    conn = sqlite3.connect(str(db_path))
    try:
        now = datetime.now(timezone.utc).isoformat()
        conn.execute(
            """INSERT OR REPLACE INTO retrolearn_log
               (file_path, scanned_at, memories_extracted, secrets_skipped)
               VALUES (?, ?, ?, ?)""",
            (str(fpath.resolve()), now, memories_extracted, secrets_skipped),
        )
        conn.commit()
    except sqlite3.Error as e:
        print(f"[retrolearn] Warning: could not mark {fpath} as scanned: {e}", file=sys.stderr)
    finally:
        conn.close()
