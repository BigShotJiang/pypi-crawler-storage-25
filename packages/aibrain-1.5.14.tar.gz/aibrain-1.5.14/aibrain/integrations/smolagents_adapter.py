"""
aibrain.integrations.smolagents_adapter — HuggingFace smolagents memory tool
backed by AIBrain.

smolagents agents use tools for everything, including memory.  This adapter
provides AIBrain-backed memory as a smolagents Tool so agents can read and
write persistent memories the same way they use any other tool.

smolagents is imported at call time only — no hard dependency.

Usage:
    from aibrain.integrations.smolagents_adapter import (
        AIBrainMemoryStoreTool,
        AIBrainMemorySearchTool,
    )
    from smolagents import CodeAgent, HfApiModel

    model = HfApiModel()
    agent = CodeAgent(
        tools=[
            AIBrainMemoryStoreTool(user_id="smol-alice"),
            AIBrainMemorySearchTool(user_id="smol-alice"),
        ],
        model=model,
    )
    agent.run("Remember that Alice prefers metric units.")
    agent.run("What units does Alice prefer?")
"""

from __future__ import annotations

from typing import Any, Optional


class AIBrainMemoryStoreTool:
    """smolagents Tool: store a fact in AIBrain persistent memory.

    Inherits from smolagents.Tool at instantiation time.

    Parameters:
        user_id:   Scope memories to this user.
        agent_id:  Scope memories to this agent.
        db_path:   Override path to aibrain.db.
    """

    name = "memory_store"
    description = (
        "Store a fact or piece of information in persistent memory so it can be "
        "recalled in future sessions. Use this to remember user preferences, "
        "decisions, project context, or anything the agent should not forget."
    )
    inputs = {
        "content": {
            "type": "string",
            "description": "The text to remember.",
        }
    }
    output_type = "string"

    def __new__(cls, *args: Any, **kwargs: Any) -> "AIBrainMemoryStoreTool":
        try:
            from smolagents import Tool as _Tool  # type: ignore[import]
        except ImportError:
            raise ImportError(
                "smolagents is required for AIBrainMemoryStoreTool. "
                "Install it with: pip install smolagents"
            )
        if _Tool not in cls.__bases__:
            cls.__bases__ = (_Tool, *cls.__bases__)
        return super().__new__(cls)

    def __init__(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
    ) -> None:
        if hasattr(self, "_brain"):
            return
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = agent_id

    def forward(self, content: str) -> str:  # type: ignore[override]
        """Store content in AIBrain.

        Args:
            content: Text to store.

        Returns:
            Confirmation string.
        """
        results = self._brain.add(
            content,
            user_id=self._user_id,
            agent_id=self._agent_id,
            infer=True,
        )
        stored = len([r for r in results if r.get("event") != "SKIP"])
        if stored:
            return f"Stored {stored} memory fact(s)."
        return "Memory already known — no new facts stored."


class AIBrainMemorySearchTool:
    """smolagents Tool: search AIBrain persistent memory.

    Parameters:
        user_id:   Scope memories to this user.
        agent_id:  Scope memories to this agent.
        db_path:   Override path to aibrain.db.
        top_k:     Max memories to return (default 5).
    """

    name = "memory_search"
    description = (
        "Search persistent memory for facts relevant to a query. "
        "Use this to recall user preferences, past decisions, or project context "
        "from previous sessions."
    )
    inputs = {
        "query": {
            "type": "string",
            "description": "Natural-language question to search memory for.",
        }
    }
    output_type = "string"

    def __new__(cls, *args: Any, **kwargs: Any) -> "AIBrainMemorySearchTool":
        try:
            from smolagents import Tool as _Tool  # type: ignore[import]
        except ImportError:
            raise ImportError(
                "smolagents is required for AIBrainMemorySearchTool. "
                "Install it with: pip install smolagents"
            )
        if _Tool not in cls.__bases__:
            cls.__bases__ = (_Tool, *cls.__bases__)
        return super().__new__(cls)

    def __init__(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
        top_k: int = 5,
    ) -> None:
        if hasattr(self, "_brain"):
            return
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = agent_id
        self._top_k = top_k

    def forward(self, query: str) -> str:  # type: ignore[override]
        """Search memory and return formatted results.

        Args:
            query: Natural-language query.

        Returns:
            Newline-joined memory strings, or a "nothing found" message.
        """
        results = self._brain.search(
            query,
            user_id=self._user_id,
            agent_id=self._agent_id,
            limit=self._top_k,
        )
        texts = [r.get("memory", "") for r in results if r.get("memory")]
        if not texts:
            return "No relevant memories found."
        return "\n".join(f"- {t}" for t in texts)
