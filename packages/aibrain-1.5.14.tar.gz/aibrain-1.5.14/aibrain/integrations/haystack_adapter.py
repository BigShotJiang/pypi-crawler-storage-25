"""
aibrain.integrations.haystack_adapter — Haystack memory component backed by AIBrain.

Implements Haystack's component interface so AIBrain can serve as the retrieval
backend for ConversationalAgent pipelines.  Haystack is imported at call time
only — no hard dependency.

Haystack v2 uses a component-based pipeline.  This adapter provides:
  - AIBrainMemoryRetriever: a pipeline component that retrieves memories
  - AIBrainMemoryWriter:    a pipeline component that stores new memories

Usage:
    from aibrain.integrations.haystack_adapter import (
        AIBrainMemoryRetriever,
        AIBrainMemoryWriter,
    )
    from haystack import Pipeline

    retriever = AIBrainMemoryRetriever(user_id="haystack-project")
    writer = AIBrainMemoryWriter(user_id="haystack-project")

    # Build a retrieval-augmented pipeline
    pipe = Pipeline()
    pipe.add_component("memory_retriever", retriever)
    # ... add other components

    result = pipe.run({"memory_retriever": {"query": "What does the user prefer?"}})
    docs = result["memory_retriever"]["documents"]
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional


class AIBrainMemoryRetriever:
    """Haystack v2 component: retrieves AIBrain memories as Haystack Documents.

    Parameters:
        user_id:   Scope memories to this user.
        agent_id:  Scope memories to this agent.
        db_path:   Override path to aibrain.db.
        top_k:     Max documents to retrieve (default 5).
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
        top_k: int = 5,
    ) -> None:
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = agent_id
        self._top_k = top_k

    def _make_document(self, mem: dict) -> Any:
        """Wrap an AIBrain memory dict as a Haystack Document."""
        try:
            from haystack.dataclasses import Document  # type: ignore[import]
        except ImportError:
            try:
                from haystack.schema import Document  # type: ignore[import]
            except ImportError:
                raise ImportError(
                    "haystack-ai is required for AIBrainMemoryRetriever. "
                    "Install it with: pip install haystack-ai"
                )
        return Document(
            content=mem.get("memory", ""),
            id=str(mem.get("id", "")),
            score=mem.get("score"),
            meta={
                "aibrain_id": mem.get("id"),
                "reason": mem.get("reason", ""),
            },
        )

    def run(self, query: str, top_k: Optional[int] = None) -> Dict[str, List[Any]]:
        """Retrieve memories relevant to query.

        Args:
            query: Natural-language query string.
            top_k: Override default top_k for this call.

        Returns:
            Dict with ``documents`` key containing list of Haystack Documents.
        """
        limit = top_k if top_k is not None else self._top_k
        results = self._brain.search(
            query,
            user_id=self._user_id,
            agent_id=self._agent_id,
            limit=limit,
        )
        return {"documents": [self._make_document(r) for r in results]}

    # Haystack v2 component protocol
    @classmethod
    def from_dict(cls, data: dict) -> "AIBrainMemoryRetriever":
        return cls(**data.get("init_parameters", {}))

    def to_dict(self) -> dict:
        return {
            "type": f"{self.__class__.__module__}.{self.__class__.__name__}",
            "init_parameters": {
                "user_id": self._user_id,
                "agent_id": self._agent_id,
                "top_k": self._top_k,
            },
        }


class AIBrainMemoryWriter:
    """Haystack v2 component: writes documents/strings into AIBrain memory.

    Parameters:
        user_id:   Scope memories to this user.
        agent_id:  Scope memories to this agent.
        db_path:   Override path to aibrain.db.
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
    ) -> None:
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = agent_id

    def run(
        self,
        documents: Optional[List[Any]] = None,
        content: Optional[str] = None,
    ) -> Dict[str, int]:
        """Write documents or raw text into AIBrain.

        Args:
            documents: List of Haystack Document objects.
            content:   Raw string to store (alternative to documents).

        Returns:
            Dict with ``written`` count.
        """
        written = 0

        if content:
            results = self._brain.add(
                content,
                user_id=self._user_id,
                agent_id=self._agent_id,
            )
            written += len([r for r in results if r.get("event") != "SKIP"])

        if documents:
            for doc in documents:
                text = getattr(doc, "content", None) or str(doc)
                if not text:
                    continue
                results = self._brain.add(
                    text,
                    user_id=self._user_id,
                    agent_id=self._agent_id,
                )
                written += len([r for r in results if r.get("event") != "SKIP"])

        return {"written": written}

    @classmethod
    def from_dict(cls, data: dict) -> "AIBrainMemoryWriter":
        return cls(**data.get("init_parameters", {}))

    def to_dict(self) -> dict:
        return {
            "type": f"{self.__class__.__module__}.{self.__class__.__name__}",
            "init_parameters": {
                "user_id": self._user_id,
                "agent_id": self._agent_id,
            },
        }
