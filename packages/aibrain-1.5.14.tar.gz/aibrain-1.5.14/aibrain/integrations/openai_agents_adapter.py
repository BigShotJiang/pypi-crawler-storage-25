"""
aibrain.integrations.openai_agents_adapter — OpenAI Agents SDK memory backed
by AIBrain.

The OpenAI Agents SDK (openai-agents, aka "Swarm v2") passes context via a
typed RunContext / dependency injection pattern similar to PydanticAI.

This adapter provides:
  - ``AIBrainContext``: a dataclass to use as the RunContext type
  - ``memory_search_tool``: an Agent tool function for semantic memory recall
  - ``memory_store_tool``:  an Agent tool function for memory writes

OpenAI Agents SDK is imported at call time only — no hard dependency.

Usage:
    from aibrain.integrations.openai_agents_adapter import (
        AIBrainContext,
        memory_search_tool,
        memory_store_tool,
    )
    from agents import Agent, Runner

    agent = Agent(
        name="assistant",
        instructions="You are a helpful assistant with persistent memory.",
        tools=[memory_search_tool, memory_store_tool],
    )

    ctx = AIBrainContext(user_id="openai-alice")
    result = Runner.run_sync(agent, "What do you remember about me?", context=ctx)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, List, Optional


@dataclass
class AIBrainContext:
    """Run context for OpenAI Agents SDK agents that need persistent memory.

    Pass an instance as the ``context`` argument to ``Runner.run_sync()`` /
    ``Runner.run()``.  The memory tools below read/write through this context.

    Parameters:
        user_id:   Scope memories to this user.
        agent_id:  Scope memories to this agent.
        db_path:   Override path to aibrain.db.
        k:         Max memories per search (default 5).
    """

    user_id: Optional[str] = None
    agent_id: Optional[str] = None
    db_path: Optional[str] = None
    k: int = 5
    _brain: Any = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=self.db_path) if self.db_path else Brain()

    def search(self, query: str, limit: Optional[int] = None) -> List[dict]:
        return self._brain.search(
            query,
            user_id=self.user_id,
            agent_id=self.agent_id,
            limit=limit or self.k,
        )

    def save(self, content: str, metadata: Optional[dict] = None) -> List[dict]:
        return self._brain.add(
            content,
            user_id=self.user_id,
            agent_id=self.agent_id,
            metadata=metadata,
            infer=True,
        )

    def recall_as_str(self, query: str) -> str:
        results = self.search(query)
        return "\n".join(r.get("memory", "") for r in results if r.get("memory"))


# ------------------------------------------------------------------
# Tool functions — register these with Agent(tools=[...])
# ------------------------------------------------------------------

def memory_search_tool(ctx: Any, query: str) -> str:
    """Search persistent memory for facts relevant to the query.

    Args:
        ctx:   RunContext with .context: AIBrainContext.
        query: Natural-language question.

    Returns:
        Newline-joined memory strings, or "No relevant memories found."
    """
    brain_ctx: AIBrainContext = getattr(ctx, "context", ctx)
    text = brain_ctx.recall_as_str(query)
    return text or "No relevant memories found."


def memory_store_tool(ctx: Any, content: str) -> str:
    """Store a fact or piece of information in persistent memory.

    Args:
        ctx:     RunContext with .context: AIBrainContext.
        content: Text to memorise.

    Returns:
        Confirmation string.
    """
    brain_ctx: AIBrainContext = getattr(ctx, "context", ctx)
    results = brain_ctx.save(content)
    stored = len([r for r in results if r.get("event") != "SKIP"])
    if stored:
        return f"Stored {stored} memory fact(s)."
    return "Memory already known — no new facts stored."


# Attach OpenAI Agents SDK metadata when SDK is available
def _register_tools() -> None:
    """Attempt to decorate tools with @function_tool if SDK is available."""
    try:
        from agents import function_tool  # type: ignore[import]
        globals()["memory_search_tool"] = function_tool(memory_search_tool)
        globals()["memory_store_tool"] = function_tool(memory_store_tool)
    except (ImportError, Exception):
        pass  # SDK not installed — tools still usable as plain callables


_register_tools()
