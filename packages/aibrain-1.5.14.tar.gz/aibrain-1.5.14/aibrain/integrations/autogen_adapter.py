"""
aibrain.integrations.autogen_adapter — AutoGen TeachableAgent memory backed by AIBrain.

Implements the AutoGen teachable-agent pattern: memories are stored after each
conversation and recalled at the start of each turn.  AutoGen is imported at
call time only — no hard dependency.

Usage:
    from aibrain.integrations.autogen_adapter import AIBrainTeachableAgent

    agent = AIBrainTeachableAgent(
        name="assistant",
        system_message="You are a helpful assistant.",
        llm_config={"model": "gpt-4o", "api_key": "sk-..."},
        aibrain_user_id="autogen-alice",
    )

    # Memories persist across multiple initiate_chat() sessions
    agent.initiate_chat(user_proxy, message="My project uses Python 3.11.")
"""

from __future__ import annotations

from typing import Any, Optional


class AIBrainTeachableAgent:
    """AutoGen-compatible ConversableAgent with AIBrain persistent memory.

    Wraps AutoGen's ``ConversableAgent`` (or ``AssistantAgent``) at runtime,
    injecting AIBrain memory recall into the system prompt on every turn and
    persisting conversation output afterwards.

    AutoGen is imported lazily — ``autogen`` or ``pyautogen`` must be installed
    separately.

    Parameters:
        name:            Agent name (required by AutoGen).
        system_message:  Base system prompt.
        llm_config:      AutoGen LLM config dict.
        aibrain_user_id: Scope memories to this user.
        aibrain_agent_id: Scope memories to this agent role.
        db_path:         Override path to aibrain.db.
        k:               Number of memories to recall per turn (default 5).
        **kwargs:        Any extra kwargs forwarded to ConversableAgent.
    """

    def __new__(cls, *args: Any, **kwargs: Any) -> "AIBrainTeachableAgent":
        try:
            import autogen as _ag  # type: ignore[import]
        except ImportError:
            try:
                import pyautogen as _ag  # type: ignore[import]
            except ImportError:
                raise ImportError(
                    "AutoGen is required for AIBrainTeachableAgent. "
                    "Install it with: pip install pyautogen"
                )
        cls._autogen_module = _ag
        return super().__new__(cls)

    def __init__(
        self,
        name: str = "assistant",
        system_message: str = "You are a helpful assistant.",
        llm_config: Optional[dict] = None,
        aibrain_user_id: Optional[str] = None,
        aibrain_agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
        k: int = 5,
        **kwargs: Any,
    ) -> None:
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = aibrain_user_id
        self._agent_id = aibrain_agent_id or name
        self._k = k
        self._base_system_message = system_message
        self._name = name
        self._llm_config = llm_config or {}
        self._kwargs = kwargs

        ag = self.__class__._autogen_module
        self._agent = ag.ConversableAgent(
            name=name,
            system_message=self._build_system_message(""),
            llm_config=llm_config,
            **kwargs,
        )

    def _build_system_message(self, query: str) -> str:
        """Build system message with relevant AIBrain memories prepended."""
        if not query:
            return self._base_system_message

        results = self._brain.search(
            query,
            user_id=self._user_id,
            agent_id=self._agent_id,
            limit=self._k,
        )
        memories = [r.get("memory", "") for r in results if r.get("memory")]

        if not memories:
            return self._base_system_message

        memory_block = "\n".join(f"- {m}" for m in memories)
        return (
            f"{self._base_system_message}\n\n"
            f"[Relevant memories from past sessions]\n{memory_block}"
        )

    def save_conversation(self, messages: list[dict]) -> None:
        """Persist conversation messages into AIBrain memory.

        Args:
            messages: List of AutoGen message dicts with 'role' and 'content'.
        """
        for msg in messages:
            content = msg.get("content", "")
            role = msg.get("role", "unknown")
            if content:
                self._brain.add(
                    f"[{role}] {content}",
                    user_id=self._user_id,
                    agent_id=self._agent_id,
                )

    def initiate_chat(
        self,
        recipient: Any,
        message: str,
        **kwargs: Any,
    ) -> Any:
        """Start a conversation with memory-enriched system prompt.

        Recalls relevant memories before starting, then saves the conversation.
        Proxies to the underlying ConversableAgent.initiate_chat().

        Args:
            recipient: The other AutoGen agent.
            message:   Opening message.
            **kwargs:  Extra kwargs passed to initiate_chat().
        """
        # Refresh system message with memories relevant to opening message
        self._agent.update_system_message(self._build_system_message(message))

        result = self._agent.initiate_chat(recipient, message=message, **kwargs)

        # Persist the conversation
        try:
            history = self._agent.chat_messages.get(recipient, [])
            self.save_conversation(history)
        except Exception:
            pass  # Non-critical — don't break agent execution

        return result

    # Proxy attribute access to the underlying AutoGen agent
    def __getattr__(self, name: str) -> Any:
        if name.startswith("_"):
            raise AttributeError(name)
        return getattr(self._agent, name)
