"""
aibrain.integrations.semantic_kernel_adapter — Semantic Kernel memory plugin
backed by AIBrain.

Implements the SK TextMemoryPlugin interface so AIBrain can serve as the
persistent memory backend for any Semantic Kernel kernel.

Semantic Kernel is imported at call time only — no hard dependency.

Usage:
    from aibrain.integrations.semantic_kernel_adapter import AIBrainMemoryPlugin
    import semantic_kernel as sk

    kernel = sk.Kernel()
    kernel.add_plugin(
        AIBrainMemoryPlugin(user_id="sk-alice"),
        plugin_name="memory",
    )

    # Use within SK functions or prompts
    await kernel.invoke("memory", "save",
        input="Alice prefers dark mode",
        collection="preferences",
    )
    result = await kernel.invoke("memory", "recall",
        input="What does Alice prefer?",
        collection="preferences",
    )
"""

from __future__ import annotations

import asyncio
from typing import Any, Optional


class AIBrainMemoryPlugin:
    """Semantic Kernel TextMemoryPlugin interface backed by AIBrain.

    Provides ``save`` and ``recall`` SK kernel functions.  The ``collection``
    parameter is mapped to AIBrain's ``agent_id`` so memories are namespaced
    by collection.

    Parameters:
        user_id:     Scope memories to this user.
        db_path:     Override path to aibrain.db.
        relevance:   Minimum similarity score 0-1 (default 0.0 — return all).
        limit:       Max memories returned per recall (default 5).
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        db_path: Optional[str] = None,
        relevance: float = 0.0,
        limit: int = 5,
    ) -> None:
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._relevance = relevance
        self._limit = limit

    # ------------------------------------------------------------------
    # TextMemoryPlugin interface (sync + async)
    # ------------------------------------------------------------------

    def save(
        self,
        input: str,
        collection: str = "default",
        key: Optional[str] = None,
        **kwargs: Any,
    ) -> str:
        """Store text in a named collection.

        Args:
            input:      Text to memorise.
            collection: Maps to AIBrain agent_id namespace.
            key:        Ignored — AIBrain assigns its own IDs.

        Returns:
            "saved" on success.
        """
        self._brain.add(
            input,
            user_id=self._user_id,
            agent_id=collection,
        )
        return "saved"

    async def save_async(
        self,
        input: str,
        collection: str = "default",
        key: Optional[str] = None,
        **kwargs: Any,
    ) -> str:
        """Async variant of save (runs sync version in thread executor)."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, lambda: self.save(input, collection, key)
        )

    def recall(
        self,
        input: str,
        collection: str = "default",
        relevance: Optional[float] = None,
        limit: Optional[int] = None,
        **kwargs: Any,
    ) -> str:
        """Retrieve memories relevant to a query.

        Args:
            input:      Natural-language query.
            collection: Namespace (maps to AIBrain agent_id).
            relevance:  Override minimum score threshold.
            limit:      Override max result count.

        Returns:
            Newline-joined memory strings.
        """
        results = self._brain.search(
            input,
            user_id=self._user_id,
            agent_id=collection,
            limit=limit or self._limit,
        )

        min_score = relevance if relevance is not None else self._relevance
        texts = [
            r.get("memory", "")
            for r in results
            if r.get("memory") and r.get("score", 1.0) >= min_score
        ]
        return "\n".join(texts)

    async def recall_async(
        self,
        input: str,
        collection: str = "default",
        relevance: Optional[float] = None,
        limit: Optional[int] = None,
        **kwargs: Any,
    ) -> str:
        """Async variant of recall."""
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, lambda: self.recall(input, collection, relevance, limit)
        )

    def remove(self, collection: str = "default", key: str = "", **kwargs: Any) -> str:
        """Remove a memory by key (best-effort — AIBrain uses soft-delete).

        Without a numeric ID, this performs a search and deletes the closest
        match to the key string.
        """
        results = self._brain.search(key, user_id=self._user_id, agent_id=collection, limit=1)
        if results:
            self._brain.delete(results[0]["id"])
            return "removed"
        return "not_found"

    async def remove_async(self, collection: str = "default", key: str = "", **kwargs: Any) -> str:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, lambda: self.remove(collection, key))
