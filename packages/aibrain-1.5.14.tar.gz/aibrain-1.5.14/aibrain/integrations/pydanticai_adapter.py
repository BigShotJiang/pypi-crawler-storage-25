"""
aibrain.integrations.pydanticai_adapter — PydanticAI dependency injection for
AIBrain persistent memory.

PydanticAI uses a typed dependency injection system.  This adapter provides
``AIBrainDep`` as a typed dependency that agents receive via their ``deps``
parameter.

PydanticAI is imported at call time only — no hard dependency.

Usage:
    from aibrain.integrations.pydanticai_adapter import AIBrainDep, make_system_prompt
    from pydantic_ai import Agent

    agent = Agent(
        "openai:gpt-4o",
        deps_type=AIBrainDep,
        system_prompt=make_system_prompt,
    )

    async def main():
        dep = AIBrainDep(user_id="pydanticai-alice")
        result = await agent.run("What do you know about my preferences?", deps=dep)
        # Save the result back into memory
        dep.save(result.data)
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, List, Optional


@dataclass
class AIBrainDep:
    """PydanticAI dependency that carries an AIBrain Brain instance.

    Inject this as ``deps`` when calling ``agent.run()``.  The agent can
    read memory via ``deps.search()`` and write via ``deps.save()``.

    Parameters:
        user_id:   Scope memories to this user.
        agent_id:  Scope memories to this agent.
        db_path:   Override path to aibrain.db.
        k:         Max memories per search (default 5).
    """

    user_id: Optional[str] = None
    agent_id: Optional[str] = None
    db_path: Optional[str] = None
    k: int = 5
    _brain: Any = field(default=None, init=False, repr=False)

    def __post_init__(self) -> None:
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=self.db_path) if self.db_path else Brain()

    # ------------------------------------------------------------------
    # Memory operations (called from agent tools or system prompts)
    # ------------------------------------------------------------------

    def save(
        self,
        content: str,
        metadata: Optional[dict] = None,
    ) -> List[dict]:
        """Store a memory.

        Args:
            content:  Text to memorise.
            metadata: Optional metadata dict.

        Returns:
            List of stored/updated memory dicts.
        """
        return self._brain.add(
            content,
            user_id=self.user_id,
            agent_id=self.agent_id,
            metadata=metadata,
            infer=True,
        )

    def search(self, query: str, limit: Optional[int] = None) -> List[dict]:
        """Semantic search over memories.

        Args:
            query: Natural-language query.
            limit: Override default k.

        Returns:
            List of memory dicts with id, memory, score fields.
        """
        return self._brain.search(
            query,
            user_id=self.user_id,
            agent_id=self.agent_id,
            limit=limit or self.k,
        )

    def recall_as_str(self, query: str, limit: Optional[int] = None) -> str:
        """Retrieve memories as a newline-joined string for prompt injection.

        Args:
            query: Natural-language query.
            limit: Override default k.

        Returns:
            Newline-joined memory texts, or empty string if none.
        """
        results = self.search(query, limit=limit)
        return "\n".join(r.get("memory", "") for r in results if r.get("memory"))

    def get_all(self, limit: int = 100) -> List[dict]:
        """List all memories for this user/agent."""
        return self._brain.get_all(
            user_id=self.user_id,
            agent_id=self.agent_id,
            limit=limit,
        )


def make_system_prompt(ctx: Any) -> str:
    """PydanticAI system_prompt callback that injects memory context.

    Pass this as ``system_prompt=make_system_prompt`` to Agent().  It will
    load top memories at each call using the user_message as the query.
    Falls back to loading recent memories if no user message is available.

    Args:
        ctx: PydanticAI RunContext with ctx.deps: AIBrainDep.

    Returns:
        Memory context string (empty if no memories stored yet).
    """
    dep: AIBrainDep = ctx.deps
    # Use run_context user message if available, otherwise fall back to general recall
    query = getattr(ctx, "user_prompt", None) or "recent context and preferences"
    memories = dep.recall_as_str(query)
    if not memories:
        return ""
    return f"[Relevant memories]\n{memories}"


def memory_tool_factory(dep: AIBrainDep) -> Callable:
    """Build a PydanticAI-compatible tool function for memory search.

    Usage::

        from pydantic_ai import Agent
        dep = AIBrainDep(user_id="alice")
        agent = Agent("openai:gpt-4o", deps_type=AIBrainDep)
        agent.tool(memory_tool_factory(dep))

    Returns:
        An async tool function ``search_memory(query: str) -> str``.
    """
    async def search_memory(ctx: Any, query: str) -> str:
        """Search persistent memory for relevant facts."""
        d: AIBrainDep = ctx.deps
        return d.recall_as_str(query)

    return search_memory
