"""
aibrain.integrations.google_adk_adapter — Google Agent Development Kit (ADK)
memory service backed by AIBrain.

Google ADK provides a ``BaseMemoryService`` interface that agents use for
session memory storage and retrieval.  This adapter implements that interface
using AIBrain as the backend.

Google ADK is imported at call time only — no hard dependency.

Usage:
    from aibrain.integrations.google_adk_adapter import AIBrainMemoryService
    from google.adk.agents import Agent

    memory_service = AIBrainMemoryService(user_id="adk-alice")

    agent = Agent(
        name="my_agent",
        model="gemini-2.0-flash",
        memory_service=memory_service,
    )
"""

from __future__ import annotations

from typing import Any, List, Optional


class AIBrainMemoryService:
    """Google ADK BaseMemoryService backed by AIBrain.

    Subclasses ``google.adk.memory.BaseMemoryService`` at runtime so the
    Google ADK import is only required when this class is instantiated.

    Parameters:
        user_id:   Scope memories to this user.
        agent_id:  Scope memories to this agent.
        db_path:   Override path to aibrain.db.
        k:         Max memories per search (default 5).
    """

    def __new__(cls, *args: Any, **kwargs: Any) -> "AIBrainMemoryService":
        # Try to subclass ADK BaseMemoryService if available
        try:
            from google.adk.memory import BaseMemoryService as _Base  # type: ignore[import]
            if _Base not in cls.__bases__:
                cls.__bases__ = (_Base, *cls.__bases__)
        except ImportError:
            # ADK not installed — class works as a standalone duck-typed impl
            pass
        return super().__new__(cls)

    def __init__(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
        k: int = 5,
    ) -> None:
        if hasattr(self, "_brain"):
            return
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = agent_id
        self._k = k

    # ------------------------------------------------------------------
    # Google ADK BaseMemoryService interface
    # ------------------------------------------------------------------

    def add_session_to_memory(self, session: Any) -> None:
        """Ingest a completed ADK session into AIBrain memory.

        Args:
            session: A google.adk.sessions.Session (or duck-typed equivalent).
                     Events are extracted and stored as individual memories.
        """
        try:
            events = getattr(session, "events", []) or []
            for event in events:
                content = getattr(event, "content", None)
                if not content:
                    continue
                # ADK content may be a string or a Content object
                text = getattr(content, "parts", None)
                if text:
                    # Extract text from Content.parts
                    joined = " ".join(
                        getattr(p, "text", "") for p in text if hasattr(p, "text")
                    )
                else:
                    joined = str(content)

                author = getattr(event, "author", "unknown")
                if joined.strip():
                    self._brain.add(
                        f"[{author}] {joined.strip()}",
                        user_id=self._user_id,
                        agent_id=self._agent_id,
                    )
        except Exception:
            # Non-critical — never break agent execution
            pass

    def search_memory(
        self,
        query: str,
        app_name: Optional[str] = None,
        user_id: Optional[str] = None,
        **kwargs: Any,
    ) -> Any:
        """Search memories relevant to a query.

        Returns a ``SearchMemoryResponse`` (or plain dict if ADK not installed).

        Args:
            query:    Natural-language query.
            app_name: Ignored — AIBrain uses user_id for scoping.
            user_id:  Override default user scope.
        """
        results = self._brain.search(
            query,
            user_id=user_id or self._user_id,
            agent_id=self._agent_id,
            limit=self._k,
        )

        try:
            from google.adk.memory import SearchMemoryResponse, MemoryResult  # type: ignore[import]
            memory_results = [
                MemoryResult(
                    session_id=str(r.get("id", "")),
                    events=[r.get("memory", "")],
                )
                for r in results if r.get("memory")
            ]
            return SearchMemoryResponse(memories=memory_results)
        except ImportError:
            # Return a plain dict if ADK is not installed
            return {
                "memories": [
                    {"session_id": str(r.get("id", "")), "content": r.get("memory", "")}
                    for r in results
                ]
            }

    # Convenience helpers (not part of ADK interface)

    def save(self, content: str, metadata: Optional[dict] = None) -> List[dict]:
        """Directly store a fact (convenience — bypasses session ingestion)."""
        return self._brain.add(
            content,
            user_id=self._user_id,
            agent_id=self._agent_id,
            metadata=metadata,
            infer=True,
        )

    def recall_as_str(self, query: str) -> str:
        """Retrieve relevant memories as a newline-joined string."""
        results = self._brain.search(
            query, user_id=self._user_id, agent_id=self._agent_id, limit=self._k
        )
        return "\n".join(r.get("memory", "") for r in results if r.get("memory"))
