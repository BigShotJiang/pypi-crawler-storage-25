"""
aibrain.integrations.metagpt_adapter — MetaGPT role-based agent memory backed
by AIBrain.

MetaGPT uses roles (Engineer, ProductManager, etc.) that process messages via
an action loop.  Each role has a ``memory`` attribute (a ``Memory`` instance)
that holds short-term history.  This adapter subclasses MetaGPT's ``Memory``
class so it also persists to AIBrain's cross-session store.

MetaGPT is imported at call time only — no hard dependency.

Usage:
    from aibrain.integrations.metagpt_adapter import AIBrainRoleMemory
    from metagpt.roles import Engineer

    engineer = Engineer()
    engineer.memory = AIBrainRoleMemory(
        role="engineer",
        user_id="project-alpha",
    )

    # Short-term history is stored in-process AND persisted to AIBrain
    # so the role remembers context across multi-session runs.
"""

from __future__ import annotations

from typing import Any, Iterable, List, Optional


class AIBrainRoleMemory:
    """MetaGPT Memory subclass with AIBrain cross-session persistence.

    Subclasses ``metagpt.memory.Memory`` at runtime so MetaGPT is only
    required when this class is instantiated.

    In-session storage: delegates to the MetaGPT Memory superclass (list-
    based short-term buffer).  Cross-session persistence: every message
    written to the buffer is also stored in AIBrain.

    Parameters:
        role:      Role name (used as agent_id for memory scoping).
        user_id:   Project or user scope for memory.
        db_path:   Override path to aibrain.db.
        k:         Max memories retrieved per semantic search (default 5).
    """

    def __new__(cls, *args: Any, **kwargs: Any) -> "AIBrainRoleMemory":
        try:
            from metagpt.memory import Memory as _Memory  # type: ignore[import]
            if _Memory not in cls.__bases__:
                cls.__bases__ = (_Memory, *cls.__bases__)
        except ImportError:
            raise ImportError(
                "metagpt is required for AIBrainRoleMemory. "
                "Install it with: pip install metagpt"
            )
        return super().__new__(cls)

    def __init__(
        self,
        role: Optional[str] = None,
        user_id: Optional[str] = None,
        db_path: Optional[str] = None,
        k: int = 5,
        **kwargs: Any,
    ) -> None:
        if hasattr(self, "_brain"):
            return
        try:
            super().__init__(**kwargs)
        except Exception:
            pass

        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = role
        self._k = k

    def add(self, message: Any) -> None:  # type: ignore[override]
        """Add a message to short-term memory and persist to AIBrain."""
        try:
            super().add(message)
        except Exception:
            pass

        content = getattr(message, "content", None) or str(message)
        if content:
            self._brain.add(
                content,
                user_id=self._user_id,
                agent_id=self._agent_id,
            )

    def add_batch(self, messages: Iterable[Any]) -> None:  # type: ignore[override]
        """Add multiple messages."""
        for msg in messages:
            self.add(msg)

    def search(self, query: str, limit: Optional[int] = None) -> List[dict]:
        """Semantic search over cross-session AIBrain memory.

        Returns AIBrain memory dicts (not MetaGPT Message objects).

        Args:
            query: Natural-language query.
            limit: Override default k.

        Returns:
            List of memory dicts with id, memory, score fields.
        """
        return self._brain.search(
            query,
            user_id=self._user_id,
            agent_id=self._agent_id,
            limit=limit or self._k,
        )

    def recall_as_str(self, query: str) -> str:
        """Retrieve cross-session memories as a newline-joined string."""
        results = self.search(query)
        return "\n".join(r.get("memory", "") for r in results if r.get("memory"))
