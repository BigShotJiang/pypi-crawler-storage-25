"""
aibrain.integrations.langchain_memory — LangChain-core-compatible memory backed by AIBrain.

Drop-in replacements for LangChain's BaseMemory and BaseChatMessageHistory that
store and retrieve conversation context via AIBrain's Brain API.

LangChain is imported lazily at class instantiation — install it with::

    pip install aibrain[langchain]

Usage
-----

Basic chain usage (requires langchain + langchain-openai)::

    from aibrain.integrations.langchain_memory import AIBrainMemory
    from langchain.chains import ConversationChain
    from langchain_openai import ChatOpenAI

    memory = AIBrainMemory(session_id="user-123", top_k=10)
    chain = ConversationChain(llm=ChatOpenAI(), memory=memory)
    chain.predict(input="My favourite colour is blue")
    chain.predict(input="What is my favourite colour?")

LangGraph / LCEL usage::

    from aibrain.integrations.langchain_memory import AIBrainChatMessageHistory
    from langchain_core.runnables.history import RunnableWithMessageHistory

    history = AIBrainChatMessageHistory(session_id="user-123")

    # With RunnableWithMessageHistory:
    runnable_with_history = RunnableWithMessageHistory(
        runnable,
        lambda session_id: AIBrainChatMessageHistory(session_id=session_id),
    )
"""

from __future__ import annotations

import uuid
from typing import Any, List

# ---------------------------------------------------------------------------
# Availability flag — set at import time, no hard crash.
# ---------------------------------------------------------------------------

_LANGCHAIN_AVAILABLE = False
_LANGCHAIN_IMPORT_ERROR: Exception | None = None

try:
    from langchain_core.memory import BaseMemory  # type: ignore[import]
    from langchain_core.chat_history import BaseChatMessageHistory  # type: ignore[import]
    from langchain_core.messages import (  # type: ignore[import]
        BaseMessage,
        HumanMessage,
        AIMessage,
        messages_from_dict,
        messages_to_dict,
    )
    from pydantic import Field, PrivateAttr  # type: ignore[import]

    _LANGCHAIN_AVAILABLE = True
except ImportError as _e:
    _LANGCHAIN_IMPORT_ERROR = _e


# ---------------------------------------------------------------------------
# Helper — raise a clear error if langchain-core is missing.
# ---------------------------------------------------------------------------

def _require_langchain() -> None:
    if not _LANGCHAIN_AVAILABLE:
        raise ImportError(
            "langchain-core is required for this class. "
            "Install it with:  pip install aibrain[langchain]\n"
            f"Original error: {_LANGCHAIN_IMPORT_ERROR}"
        )


# ---------------------------------------------------------------------------
# AIBrainMemory — BaseMemory implementation
# ---------------------------------------------------------------------------

class AIBrainMemory:
    """LangChain BaseMemory backed by AIBrain.

    Stores each conversation turn as an AIBrain memory and retrieves relevant
    prior context on every call to ``load_memory_variables``.

    Parameters
    ----------
    session_id:
        Unique identifier for this conversation session.  Defaults to a fresh
        UUID so each instance is isolated by default.
    top_k:
        Number of relevant memories to retrieve per turn.
    human_prefix:
        Label prepended to human turns in the formatted history string.
    ai_prefix:
        Label prepended to AI turns in the formatted history string.
    memory_key:
        The key injected into the chain's input dict (default ``"history"``).
    db_path:
        Optional explicit path to ``aibrain.db``; auto-detected when omitted.
    """

    # ------------------------------------------------------------------
    # Pydantic-style class attributes (set as instance attrs in __init__)
    # ------------------------------------------------------------------
    session_id: str
    top_k: int
    human_prefix: str
    ai_prefix: str
    memory_key: str

    def __new__(cls, *args: Any, **kwargs: Any) -> "AIBrainMemory":
        """Inject BaseMemory as a parent on first instantiation."""
        _require_langchain()
        if BaseMemory not in cls.__bases__:  # type: ignore[name-defined]
            cls.__bases__ = (BaseMemory, *cls.__bases__)  # type: ignore[name-defined]
        return super().__new__(cls)

    def __init__(
        self,
        session_id: str | None = None,
        top_k: int = 10,
        human_prefix: str = "Human",
        ai_prefix: str = "AI",
        memory_key: str = "history",
        db_path: str | None = None,
        **kwargs: Any,
    ) -> None:
        # Avoid double-init when BaseMemory calls __init__ again
        if hasattr(self, "_brain"):
            return

        # Defer BaseMemory init (it expects no positional args and may call super)
        try:
            super().__init__(**kwargs)  # type: ignore[call-arg]
        except TypeError:
            pass

        self.session_id = session_id or str(uuid.uuid4())
        self.top_k = top_k
        self.human_prefix = human_prefix
        self.ai_prefix = ai_prefix
        self.memory_key = memory_key

        # Initialise the AIBrain Brain client
        from aibrain.core.memory_api import Brain  # type: ignore[import]

        self._brain = Brain(db_path=db_path) if db_path else Brain()

    # ------------------------------------------------------------------
    # BaseMemory interface
    # ------------------------------------------------------------------

    @property
    def memory_variables(self) -> list[str]:
        """Variables this memory provides to the chain."""
        return [self.memory_key]

    def load_memory_variables(self, inputs: dict[str, Any]) -> dict[str, str]:
        """Retrieve relevant memories for the current input.

        Searches AIBrain for context related to the first non-empty input
        value, then formats the results as a newline-separated history string.

        Returns
        -------
        dict
            ``{memory_key: "<formatted history string>"}``
        """
        # Use the first non-empty input value as the search query
        query = next((v for v in inputs.values() if isinstance(v, str) and v), "")
        if not query:
            return {self.memory_key: ""}

        results = self._brain.search(
            query,
            user_id=self.session_id,
            limit=self.top_k,
        )

        lines: list[str] = []
        for r in results:
            mem = r.get("memory", "")
            if mem:
                lines.append(mem)

        return {self.memory_key: "\n".join(lines)}

    def save_context(self, inputs: dict[str, Any], outputs: dict[str, str]) -> None:
        """Persist the human input and AI output as AIBrain memories.

        Each turn is stored as a single formatted string so retrieval brings
        back the full exchange, preserving conversational coherence.
        """
        human_input = next(
            (v for v in inputs.values() if isinstance(v, str)), ""
        )
        ai_output = next(
            (v for v in outputs.values() if isinstance(v, str)), ""
        )

        if not human_input and not ai_output:
            return

        text = f"{self.human_prefix}: {human_input}\n{self.ai_prefix}: {ai_output}"
        self._brain.add(
            text,
            user_id=self.session_id,
            infer=False,  # Store turn verbatim — no fact extraction on dialog
        )

    def clear(self) -> None:
        """Clear session memories.

        AIBrain uses soft-delete semantics; this calls ``delete_all`` scoped
        to the current session_id so the memories are deactivated but retained
        for audit.
        """
        try:
            self._brain.delete_all(user_id=self.session_id)
        except Exception:
            pass  # delete_all may not exist on all Brain versions — fail silently


# ---------------------------------------------------------------------------
# AIBrainChatMessageHistory — BaseChatMessageHistory implementation
# ---------------------------------------------------------------------------

class AIBrainChatMessageHistory:
    """LangChain BaseChatMessageHistory backed by AIBrain.

    Stores chat messages as AIBrain memories and reconstructs a
    ``list[BaseMessage]`` on retrieval.  Designed for use with
    ``RunnableWithMessageHistory`` in LangGraph / LCEL pipelines.

    Parameters
    ----------
    session_id:
        Unique identifier for this chat thread.  Defaults to a fresh UUID.
    db_path:
        Optional explicit path to ``aibrain.db``; auto-detected when omitted.
    top_k:
        Maximum number of past messages to load per retrieval.
    """

    def __new__(cls, *args: Any, **kwargs: Any) -> "AIBrainChatMessageHistory":
        """Inject BaseChatMessageHistory as a parent on first instantiation."""
        _require_langchain()
        if BaseChatMessageHistory not in cls.__bases__:  # type: ignore[name-defined]
            cls.__bases__ = (BaseChatMessageHistory, *cls.__bases__)  # type: ignore[name-defined]
        return super().__new__(cls)

    def __init__(
        self,
        session_id: str | None = None,
        db_path: str | None = None,
        top_k: int = 50,
        **kwargs: Any,
    ) -> None:
        if hasattr(self, "_brain"):
            return

        try:
            super().__init__(**kwargs)  # type: ignore[call-arg]
        except TypeError:
            pass

        self.session_id = session_id or str(uuid.uuid4())
        self.top_k = top_k

        from aibrain.core.memory_api import Brain  # type: ignore[import]

        self._brain = Brain(db_path=db_path) if db_path else Brain()

    # ------------------------------------------------------------------
    # BaseChatMessageHistory interface
    # ------------------------------------------------------------------

    @property
    def messages(self) -> list[Any]:
        """Return stored messages as a list of BaseMessage objects.

        Searches AIBrain for memories tagged with this session, then
        reconstructs HumanMessage / AIMessage objects from stored prefixes.

        The returned list is ordered oldest-first so it reads naturally in a
        chain prompt.
        """
        results = self._brain.search(
            f"session:{self.session_id}",
            user_id=self.session_id,
            limit=self.top_k,
        )

        msgs: list[Any] = []
        for r in results:
            raw = r.get("memory", "")
            if not raw:
                continue
            # Parse the "Human: ...\nAI: ..." format stored by add_message
            if raw.startswith("__human__:"):
                content = raw[len("__human__:"):].strip()
                msgs.append(HumanMessage(content=content))  # type: ignore[name-defined]
            elif raw.startswith("__ai__:"):
                content = raw[len("__ai__:"):].strip()
                msgs.append(AIMessage(content=content))  # type: ignore[name-defined]

        return msgs

    def add_message(self, message: Any) -> None:
        """Add a single BaseMessage to AIBrain storage.

        Human and AI messages are tagged with a prefix so they can be
        round-tripped back to typed objects via ``messages``.
        """
        # Determine type from class name to avoid hard isinstance coupling
        cls_name = type(message).__name__.lower()
        if "human" in cls_name:
            prefix = "__human__"
        elif "ai" in cls_name or "assistant" in cls_name:
            prefix = "__ai__"
        else:
            prefix = f"__{cls_name}__"

        content = getattr(message, "content", str(message))
        text = f"{prefix}: {content}\nsession:{self.session_id}"

        self._brain.add(
            text,
            user_id=self.session_id,
            infer=False,
        )

    def clear(self) -> None:
        """Remove all messages for this session from AIBrain."""
        try:
            self._brain.delete_all(user_id=self.session_id)
        except Exception:
            pass
