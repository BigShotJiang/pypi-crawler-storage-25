"""
aibrain.integrations.dspy_adapter — DSPy memory module backed by AIBrain.

DSPy does not have a native memory interface — it treats history through
``dspy.History`` (a list of past inputs/outputs) and retrieval through
``dspy.Retrieve``.  This adapter provides:

  - ``AIBrainRM``:     a DSPy Retrieve module backed by AIBrain
  - ``AIBrainMemory``: a lightweight module to save/recall across sessions

DSPy is imported at call time only — no hard dependency.

Usage:
    from aibrain.integrations.dspy_adapter import AIBrainRM, AIBrainMemory
    import dspy

    # Use as a retrieval module in any DSPy program
    dspy.settings.configure(rm=AIBrainRM(user_id="dspy-alice"))

    class RAGProgram(dspy.Module):
        def __init__(self):
            self.retrieve = dspy.Retrieve(k=5)
            self.generate = dspy.ChainOfThought("context, question -> answer")

        def forward(self, question):
            context = self.retrieve(question).passages
            return self.generate(context=context, question=question)

    # Or use AIBrainMemory directly within any module
    memory = AIBrainMemory(user_id="dspy-alice")
    memory.save("Alice prefers metric units")
    recall = memory.recall("What units?")
"""

from __future__ import annotations

from typing import Any, List, Optional


class AIBrainRM:
    """DSPy Retrieve module backed by AIBrain.

    Implements the DSPy retrieval model interface (``__call__`` returns
    a ``Prediction`` with a ``passages`` list).

    DSPy is imported lazily.

    Parameters:
        user_id:   Scope memories to this user.
        agent_id:  Scope memories to this agent.
        db_path:   Override path to aibrain.db.
        k:         Default number of passages to return (default 5).
    """

    def __new__(cls, *args: Any, **kwargs: Any) -> "AIBrainRM":
        try:
            import dspy as _dspy  # type: ignore[import]
            # Subclass dspy.Retrieve if possible for full DSPy compat
            retrieve_cls = getattr(_dspy, "Retrieve", None)
            if retrieve_cls and retrieve_cls not in cls.__bases__:
                # Only inject if we haven't already
                pass  # DSPy Retrieve needs k at __init__ — manage via __call__
            cls._dspy = _dspy
        except ImportError:
            raise ImportError(
                "dspy-ai is required for AIBrainRM. "
                "Install it with: pip install dspy-ai"
            )
        return super().__new__(cls)

    def __init__(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
        k: int = 5,
    ) -> None:
        if hasattr(self, "_brain"):
            return
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = agent_id
        self.k = k

    def __call__(self, query_or_queries: Any, k: Optional[int] = None) -> Any:
        """Retrieve passages matching one or more queries.

        Args:
            query_or_queries: A single query string or list of strings.
            k:                Override default k.

        Returns:
            dspy.Prediction with a ``passages`` attribute (list of strings).
        """
        dspy = self.__class__._dspy
        limit = k or self.k

        if isinstance(query_or_queries, (list, tuple)):
            all_passages: List[str] = []
            seen: set = set()
            for q in query_or_queries:
                for r in self._brain.search(q, user_id=self._user_id, agent_id=self._agent_id, limit=limit):
                    text = r.get("memory", "")
                    if text and text not in seen:
                        all_passages.append(text)
                        seen.add(text)
            passages = all_passages[:limit]
        else:
            results = self._brain.search(
                query_or_queries,
                user_id=self._user_id,
                agent_id=self._agent_id,
                limit=limit,
            )
            passages = [r.get("memory", "") for r in results if r.get("memory")]

        return dspy.Prediction(passages=passages)

    def forward(self, query_or_queries: Any, k: Optional[int] = None) -> Any:
        """Alias for __call__ (DSPy module convention)."""
        return self(query_or_queries, k=k)


class AIBrainMemory:
    """Lightweight memory helper for use within DSPy modules.

    Not a DSPy Module subclass — a plain helper that any DSPy program can
    call to persist and recall facts across sessions.

    Parameters:
        user_id:   Scope memories to this user.
        agent_id:  Scope memories to this agent.
        db_path:   Override path to aibrain.db.
        k:         Max memories per recall (default 5).
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
        k: int = 5,
    ) -> None:
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = agent_id
        self._k = k

    def save(self, content: str, metadata: Optional[dict] = None) -> List[dict]:
        """Persist content to AIBrain.

        Args:
            content:  Text to memorise.
            metadata: Optional metadata dict.

        Returns:
            List of stored/updated memory dicts.
        """
        return self._brain.add(
            content,
            user_id=self._user_id,
            agent_id=self._agent_id,
            metadata=metadata,
            infer=True,
        )

    def recall(self, query: str, limit: Optional[int] = None) -> List[str]:
        """Retrieve relevant memories as a list of strings.

        Args:
            query: Natural-language query.
            limit: Override default k.

        Returns:
            List of memory text strings.
        """
        results = self._brain.search(
            query,
            user_id=self._user_id,
            agent_id=self._agent_id,
            limit=limit or self._k,
        )
        return [r.get("memory", "") for r in results if r.get("memory")]

    def recall_as_str(self, query: str, limit: Optional[int] = None) -> str:
        """Recall as a newline-joined string for prompt injection."""
        return "\n".join(self.recall(query, limit=limit))
