"""
aibrain.integrations.agno_adapter — Agno (fka phidata) memory backend using AIBrain.

Implements Agno's Memory base class so that any Agno Agent can use AIBrain as
its persistent memory store.  Agno is imported at call time only.

Usage:
    from aibrain.integrations.agno_adapter import AIBrainAgnoMemory
    from agno.agent import Agent

    agent = Agent(
        model="gpt-4o",
        memory=AIBrainAgnoMemory(user_id="agno-alice"),
        # Agent now remembers users, goals, and decisions across sessions
    )
"""

from __future__ import annotations

from typing import Any, List, Optional


class AIBrainAgnoMemory:
    """Agno-compatible Memory class backed by AIBrain.

    Agno's Memory interface (as of agno ≥0.1) exposes:
        - add_memory(content, user_id, ...)
        - search_memory(query, user_id, ...)
        - get_memories(user_id, ...)

    This adapter maps those calls to AIBrain's Brain API.

    Parameters:
        user_id:   Default user scope (can be overridden per-call).
        agent_id:  Default agent scope.
        db_path:   Override path to aibrain.db.
        k:         Max memories per search (default 5).
    """

    def __init__(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        db_path: Optional[str] = None,
        k: int = 5,
    ) -> None:
        from aibrain.core.memory_api import Brain

        self._brain = Brain(db_path=db_path) if db_path else Brain()
        self._user_id = user_id
        self._agent_id = agent_id
        self._k = k

    # ------------------------------------------------------------------
    # Agno Memory interface
    # ------------------------------------------------------------------

    def add_memory(
        self,
        content: str,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        metadata: Optional[dict] = None,
        **kwargs: Any,
    ) -> List[dict]:
        """Store a memory.

        Args:
            content:  Text to memorise.
            user_id:  Override default user scope.
            agent_id: Override default agent scope.
            metadata: Optional metadata dict.

        Returns:
            List of stored/updated memory dicts.
        """
        return self._brain.add(
            content,
            user_id=user_id or self._user_id,
            agent_id=agent_id or self._agent_id,
            metadata=metadata,
            infer=True,
        )

    def search_memory(
        self,
        query: str,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: Optional[int] = None,
        **kwargs: Any,
    ) -> List[dict]:
        """Semantic search over memories.

        Args:
            query:    Natural-language query.
            user_id:  Override default user scope.
            agent_id: Override default agent scope.
            limit:    Max results.

        Returns:
            List of memory dicts with id, memory, score fields.
        """
        return self._brain.search(
            query,
            user_id=user_id or self._user_id,
            agent_id=agent_id or self._agent_id,
            limit=limit or self._k,
        )

    def get_memories(
        self,
        user_id: Optional[str] = None,
        agent_id: Optional[str] = None,
        limit: int = 100,
        **kwargs: Any,
    ) -> List[dict]:
        """List all memories for a user/agent.

        Returns:
            List of memory dicts.
        """
        return self._brain.get_all(
            user_id=user_id or self._user_id,
            agent_id=agent_id or self._agent_id,
            limit=limit,
        )

    def delete_memory(
        self,
        memory_id: int,
        **kwargs: Any,
    ) -> bool:
        """Delete a memory by ID (soft-delete).

        Returns:
            True if deleted, False if not found.
        """
        return self._brain.delete(memory_id)

    def clear(self, user_id: Optional[str] = None, agent_id: Optional[str] = None) -> None:
        """Clear is a no-op — AIBrain uses soft-delete, not hard wipe."""
        pass

    # Agno may also call these as properties / alternate spellings
    def save(self, content: str, **kwargs: Any) -> List[dict]:
        """Alias for add_memory (some Agno versions use .save())."""
        return self.add_memory(content, **kwargs)

    def search(self, query: str, **kwargs: Any) -> List[dict]:
        """Alias for search_memory."""
        return self.search_memory(query, **kwargs)
