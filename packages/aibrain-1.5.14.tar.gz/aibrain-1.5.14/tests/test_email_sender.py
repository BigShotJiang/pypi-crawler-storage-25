"""Tests for aibrain.core.email_sender.

Three required scenarios:
    1. Missing RESEND_API_KEY → returns False, no crash
    2. Happy path with mocked requests.post → correct JSON body sent
    3. Trial expiry email body contains the days_remaining number
"""

import os
import sys
import unittest
from unittest.mock import MagicMock, patch

# Ensure project root is importable regardless of where pytest is invoked.
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from aibrain.core.email_sender import (
    _send_via_resend,
    send_trial_expiry_alert,
    send_welcome_email,
)


class TestEmailSenderNoApiKey(unittest.TestCase):
    """_send_via_resend returns False when RESEND_API_KEY is not set."""

    def test_send_welcome_email_no_api_key(self):
        """With RESEND_API_KEY unset, send_welcome_email returns False and does not raise."""
        env = {k: v for k, v in os.environ.items() if k != "RESEND_API_KEY"}
        with patch.dict(os.environ, env, clear=True):
            result = send_welcome_email("user@example.com", name="Tester")
        self.assertFalse(result)


class TestSendViaResendMock(unittest.TestCase):
    """Correct JSON body is posted to the Resend API."""

    def test_send_via_resend_mock(self):
        """Mock requests.post — verify the payload has all required fields."""
        mock_response = MagicMock()
        mock_response.status_code = 200

        env_patch = {"RESEND_API_KEY": "re_test_key123", "RESEND_FROM_EMAIL": "hello@myaibrain.org"}

        with patch.dict(os.environ, env_patch):
            with patch("requests.post", return_value=mock_response) as mock_post:
                result = _send_via_resend(
                    to="user@example.com",
                    subject="Test subject",
                    html="<p>Test</p>",
                )

        self.assertTrue(result)
        mock_post.assert_called_once()

        # Inspect the JSON body passed to requests.post
        call_kwargs = mock_post.call_args
        payload = call_kwargs.kwargs.get("json") or call_kwargs.args[1] if len(call_kwargs.args) > 1 else call_kwargs.kwargs["json"]

        self.assertEqual(payload["from"], "hello@myaibrain.org")
        self.assertEqual(payload["to"], ["user@example.com"])
        self.assertEqual(payload["subject"], "Test subject")
        self.assertIn("html", payload)

        # Verify the Authorization header uses Bearer scheme
        headers = call_kwargs.kwargs.get("headers", {})
        self.assertIn("Bearer re_test_key123", headers.get("Authorization", ""))


class TestTrialExpiryBody(unittest.TestCase):
    """Trial expiry email body contains the days_remaining number."""

    def test_send_trial_expiry_includes_days(self):
        """The generated email subject and HTML body both mention days_remaining."""
        captured = {}

        def fake_post(url, headers, json, timeout):
            captured["subject"] = json["subject"]
            captured["html"] = json["html"]
            mock = MagicMock()
            mock.status_code = 200
            return mock

        env_patch = {"RESEND_API_KEY": "re_test_key123"}

        with patch.dict(os.environ, env_patch):
            with patch("requests.post", side_effect=fake_post):
                result = send_trial_expiry_alert("user@example.com", days_remaining=3)

        self.assertTrue(result)
        self.assertIn("3", captured["subject"])
        self.assertIn("3", captured["html"])


if __name__ == "__main__":
    unittest.main()
