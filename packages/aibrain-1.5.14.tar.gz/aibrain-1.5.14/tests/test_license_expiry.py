"""
test_license_expiry.py — Subscription license expiry + renewal system tests.

Covers:
  1. VALID state returned for an active license
  2. INVALID state returned after valid_until passes
  3. Grace period: still VALID during 3-day window after valid_until
  4. Machine binding: second activation on different fingerprint returns INVALID
  5. Late renewal: valid_until extended after successful payment
  6. Endpoint unreachable: validate_key fails open (does not block)

All network calls are mocked. No Stripe SDK required.
"""

import os
import sys
import sqlite3
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

# ── env setup BEFORE any aibrain import ────────────────────────────────────
os.environ.setdefault("AIBRAIN_SIGNING_KEY", "test-signing-key-expiry-tests")
os.environ.setdefault("AIBRAIN_COOKIE_INSECURE", "1")

_TMP_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_TMP_DB.close()
os.environ["AIBRAIN_DB"] = _TMP_DB.name

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(REPO_ROOT / "backend"))

import aibrain_db
import aibrain_licensing

# ── helpers ────────────────────────────────────────────────────────────────

def _iso(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _future(days: int = 10) -> str:
    return _iso(datetime.utcnow() + timedelta(days=days))


def _past(days: int = 1) -> str:
    return _iso(datetime.utcnow() - timedelta(days=days))


def _grace_future(days: int = 2) -> str:
    """A grace_until that is still in the future."""
    return _iso(datetime.utcnow() + timedelta(days=days))


def _grace_past(days: int = 1) -> str:
    """A grace_until that has already elapsed."""
    return _iso(datetime.utcnow() - timedelta(days=days))


def _make_server_response(
    state: str = "VALID",
    valid_until: str = None,
    days_remaining: int = 10,
    grace_period: bool = False,
    machine_fingerprint: str = None,
) -> dict:
    return {
        "state": state,
        "valid_until": valid_until or _future(10),
        "days_remaining": days_remaining,
        "grace_period": grace_period,
        "machine_fingerprint": machine_fingerprint,
    }


def _gen_key(tier: str = "pro") -> str:
    return aibrain_licensing.generate_key(
        tier=tier,
        email="test@example.com",
        stripe_customer_id="cus_test",
        stripe_sub_id="sub_test",
    )


# ── fixtures ───────────────────────────────────────────────────────────────

@pytest.fixture(autouse=True)
def reset_license_cache():
    """Bust the in-memory license cache between tests."""
    aibrain_licensing.reset_cache()
    yield
    aibrain_licensing.reset_cache()


# ── Test 1: VALID state returned for an active license ────────────────────

def test_valid_state_active_license():
    """validate_key returns valid=True when server reports state=VALID."""
    key = _gen_key()
    server_resp = _make_server_response(state="VALID", days_remaining=20)

    with patch.object(aibrain_licensing, "_check_server_license_state", return_value=server_resp):
        lic = aibrain_licensing.validate_key(key)

    assert lic.valid is True, f"Expected valid, got reason: {lic.reason}"
    assert lic.tier == "pro"


# ── Test 2: INVALID state returned after valid_until passes ───────────────

def test_invalid_state_after_valid_until_expires():
    """validate_key returns valid=False when server reports state=INVALID and grace has passed."""
    key = _gen_key()
    server_resp = _make_server_response(
        state="INVALID",
        valid_until=_past(5),
        days_remaining=0,
        grace_period=False,
        machine_fingerprint=None,
    )
    # grace_until is NOT set in this response — expired hard
    server_resp["grace_until"] = _grace_past(2)

    with patch.object(aibrain_licensing, "_check_server_license_state", return_value=server_resp):
        lic = aibrain_licensing.validate_key(key)

    assert lic.valid is False
    assert lic.tier == "free"
    assert "expired" in lic.reason.lower() or "renew" in lic.reason.lower()


# ── Test 3: Grace period — still VALID during 3-day window ────────────────

def test_grace_period_still_valid():
    """When state=INVALID but grace_until is in the future, validate_key returns valid=True."""
    key = _gen_key()
    server_resp = _make_server_response(
        state="INVALID",
        valid_until=_past(1),
        days_remaining=0,
        grace_period=True,
        machine_fingerprint=None,
    )
    # Grace window still open
    server_resp["grace_until"] = _grace_future(2)

    with patch.object(aibrain_licensing, "_check_server_license_state", return_value=server_resp):
        lic = aibrain_licensing.validate_key(key)

    assert lic.valid is True, f"Expected valid during grace, got: {lic.reason}"
    assert lic.tier == "pro"


# ── Test 4: Machine binding — reject different fingerprint ─────────────────

def test_machine_binding_rejects_different_fingerprint():
    """validate_key returns valid=False when server's stored fingerprint differs."""
    key = _gen_key()
    server_resp = _make_server_response(
        state="VALID",
        machine_fingerprint="original_machine_hash_abc123",
    )

    # Simulate current machine having a DIFFERENT fingerprint
    with patch.object(aibrain_licensing, "_machine_fingerprint_hash", return_value="different_machine_hash_xyz999"):
        with patch.object(aibrain_licensing, "_check_server_license_state", return_value=server_resp):
            lic = aibrain_licensing.validate_key(key)

    assert lic.valid is False
    assert "bound to a different machine" in lic.reason.lower() or "machine" in lic.reason.lower()
    assert lic.tier == "free"


# ── Test 5: Late renewal — valid_until extended after payment ──────────────

def test_late_renewal_extends_valid_until():
    """After payment_succeeded, _extend_license_state_by_subscription_id sets valid_until to now+31d."""
    conn = aibrain_db.get_db()
    # Create a user and an expired license_state row
    user_id = "usr_expiry_test_renew"
    sub_id = "sub_expiry_renew_001"
    conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.execute(
        "INSERT INTO users (id, email, password_hash) VALUES (?, ?, 'x')",
        (user_id, "renew-test@example.com"),
    )
    conn.execute("DELETE FROM license_state WHERE user_id = ?", (user_id,))
    expired_until = _past(3)
    conn.execute(
        """INSERT INTO license_state
           (user_id, tier, stripe_subscription_id, state, valid_until, grace_until, updated_at)
           VALUES (?, 'pro', ?, 'INVALID', ?, ?, datetime('now'))""",
        (user_id, sub_id, expired_until, _past(0)),
    )
    conn.commit()

    # Import the renewal helper from main
    sys.path.insert(0, str(REPO_ROOT / "backend"))
    try:
        # We import and call the helper directly rather than through the full HTTP stack
        # because the full stack requires all middleware (auth, rate-limit, etc.)
        from main import _extend_license_state_by_subscription_id
        updated = _extend_license_state_by_subscription_id(sub_id)
    except ImportError:
        pytest.skip("backend/main.py not importable in this test env — skip")
        return

    assert updated is True, "Expected the license_state row to be updated"

    row = conn.execute(
        "SELECT state, valid_until FROM license_state WHERE user_id = ?", (user_id,)
    ).fetchone()
    assert row is not None
    assert row["state"] == "VALID"

    # valid_until should be approximately now+31d
    new_valid = datetime.fromisoformat(row["valid_until"].replace("Z", ""))
    expected_min = datetime.utcnow() + timedelta(days=30)
    assert new_valid > expected_min, f"valid_until {new_valid} should be > {expected_min}"

    # Cleanup
    conn.execute("DELETE FROM license_state WHERE user_id = ?", (user_id,))
    conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()


# ── Test 6: Endpoint unreachable — validate_key fails open ────────────────

def test_endpoint_unreachable_fails_open():
    """When server is unreachable (None response), validate_key should NOT block a valid key."""
    key = _gen_key()

    # _check_server_license_state returns None when server is unreachable
    with patch.object(aibrain_licensing, "_check_server_license_state", return_value=None):
        lic = aibrain_licensing.validate_key(key)

    # Key is cryptographically valid and server is unreachable → fail open
    assert lic.valid is True, (
        f"validate_key must fail open when server is unreachable, got: {lic.reason}"
    )
    assert lic.tier == "pro"


# ── Test 7: Grace period set on subscription cancellation (DB helper) ──────

def test_grace_period_set_on_cancellation():
    """_set_grace_period_by_subscription_id must update grace_until without immediately INVALIDating."""
    conn = aibrain_db.get_db()
    user_id = "usr_expiry_cancel_test"
    sub_id = "sub_cancel_grace_001"
    conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.execute(
        "INSERT INTO users (id, email, password_hash) VALUES (?, ?, 'x')",
        (user_id, "cancel-test@example.com"),
    )
    conn.execute("DELETE FROM license_state WHERE user_id = ?", (user_id,))
    conn.execute(
        """INSERT INTO license_state
           (user_id, tier, stripe_subscription_id, state, valid_until, updated_at)
           VALUES (?, 'pro', ?, 'VALID', ?, datetime('now'))""",
        (user_id, sub_id, _future(20)),
    )
    conn.commit()

    try:
        from main import _set_grace_period_by_subscription_id
        updated = _set_grace_period_by_subscription_id(sub_id)
    except ImportError:
        pytest.skip("backend/main.py not importable — skip")
        return

    assert updated is True

    row = conn.execute(
        "SELECT state, valid_until, grace_until FROM license_state WHERE user_id = ?",
        (user_id,),
    ).fetchone()
    assert row is not None
    # state should NOT be immediately INVALID after cancellation
    assert row["state"] == "VALID", "State must remain VALID — grace period set, not immediate INVALID"
    # grace_until must be set: it is valid_until + 3d.
    # Since valid_until was set to now+20d, grace_until should be ~now+23d.
    assert row["grace_until"] is not None
    grace_dt = datetime.fromisoformat(row["grace_until"].replace("Z", ""))
    assert grace_dt > datetime.utcnow(), "grace_until must be in the future"
    # grace_until = valid_until (now+20d) + 3d = now+23d; allow ±1d tolerance
    expected_grace = datetime.utcnow() + timedelta(days=22)
    expected_max = datetime.utcnow() + timedelta(days=25)
    assert grace_dt >= expected_grace, f"grace_until {grace_dt} should be >= now+22d"
    assert grace_dt <= expected_max, f"grace_until {grace_dt} should be <= now+25d"

    # Cleanup
    conn.execute("DELETE FROM license_state WHERE user_id = ?", (user_id,))
    conn.execute("DELETE FROM users WHERE id = ?", (user_id,))
    conn.commit()
