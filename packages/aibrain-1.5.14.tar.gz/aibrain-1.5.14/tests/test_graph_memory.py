"""
tests/test_graph_memory.py — Graph memory tests for AIBrain.

Tests: add_relation, auto_link, find_path, contradiction edge, get_neighbors depth.
Uses an isolated in-memory SQLite DB — never touches the real aibrain.db.
"""

import sqlite3
import sys
import uuid
from pathlib import Path

import pytest

# Ensure project root importable
_root = Path(__file__).resolve().parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from aibrain.core.graph_memory import (
    AUTO_LINK_THRESHOLD,
    VALID_RELATION_TYPES,
    _ensure_schema,
    _overlap_score,
    _tokenize,
    add_relation,
    auto_link,
    find_path,
    get_neighbors,
    get_relations,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

def _make_db() -> sqlite3.Connection:
    """Create an isolated in-memory SQLite DB with the memories + graph tables."""
    db = sqlite3.connect(":memory:")
    db.row_factory = sqlite3.Row

    # Minimal memories table (matches aibrain_db schema)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            memory_class TEXT DEFAULT 'semantic',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
            name, tags, content, content=memories, content_rowid=id
        );

        CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END;
    """)

    _ensure_schema(db)
    return db


def _add_memory(db: sqlite3.Connection, name: str, content: str) -> int:
    """Insert a test memory and return its ID."""
    db.execute(
        "INSERT INTO memories (name, content, active) VALUES (?, ?, 1)",
        (name, content),
    )
    db.commit()
    return db.execute("SELECT last_insert_rowid()").fetchone()[0]


# ---------------------------------------------------------------------------
# test_add_relation
# ---------------------------------------------------------------------------

def test_add_relation():
    """add_relation stores a relation; get_relations returns it correctly."""
    db = _make_db()

    m1 = _add_memory(db, "Memory A", "Python is a programming language used for data science")
    m2 = _add_memory(db, "Memory B", "Data science uses Python and statistics for analysis")

    rel_id = add_relation(m1, m2, "supports", weight=0.8, db=db)

    assert rel_id is not None
    assert len(rel_id) == 36  # UUID format

    relations = get_relations(m1, direction="outbound", db=db)
    assert len(relations) == 1
    r = relations[0]
    assert r["from_memory_id"] == m1
    assert r["to_memory_id"] == m2
    assert r["relation_type"] == "supports"
    assert abs(r["weight"] - 0.8) < 0.001
    assert r["direction"] == "outbound"

    # Inbound from m2's perspective
    in_rels = get_relations(m2, direction="inbound", db=db)
    assert len(in_rels) == 1
    assert in_rels[0]["from_memory_id"] == m1
    assert in_rels[0]["direction"] == "inbound"


def test_add_relation_invalid_type():
    """add_relation raises ValueError for unknown relation types."""
    db = _make_db()
    m1 = _add_memory(db, "A", "alpha beta gamma delta")
    m2 = _add_memory(db, "B", "epsilon zeta theta iota")

    with pytest.raises(ValueError, match="Invalid relation_type"):
        add_relation(m1, m2, "unknown_type", db=db)


def test_add_relation_deduplication():
    """Inserting the same (from, to, type) triple twice is idempotent."""
    db = _make_db()
    m1 = _add_memory(db, "A", "machine learning algorithms neural networks")
    m2 = _add_memory(db, "B", "deep learning neural networks training")

    rel1 = add_relation(m1, m2, "related_to", db=db)
    rel2 = add_relation(m1, m2, "related_to", db=db)  # duplicate — should not raise

    # Both return same relation id (OR IGNORE means second call returns existing row)
    assert rel1 == rel2

    # Only one row in DB
    count = db.execute("SELECT COUNT(*) FROM memory_relations").fetchone()[0]
    assert count == 1


# ---------------------------------------------------------------------------
# test_auto_link
# ---------------------------------------------------------------------------

def test_auto_link():
    """auto_link creates related_to edges for memories with sufficient keyword overlap."""
    db = _make_db()

    # Seed several memories with overlapping content
    _add_memory(db, "ML intro", "machine learning algorithms train neural network models classify data")
    _add_memory(db, "Deep learning", "deep learning neural network layers train backpropagation classify images")
    _add_memory(db, "NLP basics", "natural language processing text classification machine learning train")
    _add_memory(db, "Computer vision", "image classification convolutional neural network train feature extraction")

    # The new memory to auto-link
    new_content = "neural network training machine learning algorithms classification"
    new_id = _add_memory(db, "New memory", new_content)

    created = auto_link(new_id, new_content, top_n=3, db=db)

    # Should have created at least 1 edge (our seed memories have heavy overlap)
    assert created >= 1

    # All created relations should be 'related_to' with weight >= threshold
    rels = db.execute(
        "SELECT * FROM memory_relations WHERE from_memory_id=?", (new_id,)
    ).fetchall()
    assert len(rels) == created
    for rel in rels:
        assert rel["relation_type"] == "related_to"
        assert rel["weight"] >= AUTO_LINK_THRESHOLD


def test_auto_link_no_edges_below_threshold():
    """auto_link creates no edges when content has zero overlap with existing memories."""
    db = _make_db()

    # Seed memories on a completely different topic
    _add_memory(db, "Cooking", "recipes baking flour sugar butter eggs cake")
    _add_memory(db, "Gardening", "plants watering soil fertilizer pruning flowers")

    new_content = "quantum mechanics wave function superposition entanglement particles"
    new_id = _add_memory(db, "Physics", new_content)

    created = auto_link(new_id, new_content, top_n=3, db=db)
    assert created == 0


# ---------------------------------------------------------------------------
# test_find_path
# ---------------------------------------------------------------------------

def test_find_path():
    """find_path returns BFS shortest path through a 3-hop chain."""
    db = _make_db()

    # Build: A -> B -> C -> D
    a = _add_memory(db, "A", "alpha")
    b = _add_memory(db, "B", "beta")
    c = _add_memory(db, "C", "gamma")
    d = _add_memory(db, "D", "delta")

    add_relation(a, b, "related_to", db=db)
    add_relation(b, c, "supports", db=db)
    add_relation(c, d, "refines", db=db)

    path = find_path(a, d, max_depth=3, db=db)
    assert path is not None
    assert path[0] == a
    assert path[-1] == d
    assert len(path) == 4  # A -> B -> C -> D


def test_find_path_direct():
    """find_path returns [from, to] for direct neighbors."""
    db = _make_db()
    m1 = _add_memory(db, "X", "xray")
    m2 = _add_memory(db, "Y", "yellow")
    add_relation(m1, m2, "caused_by", db=db)

    path = find_path(m1, m2, max_depth=2, db=db)
    assert path == [m1, m2]


def test_find_path_no_path():
    """find_path returns None when no path exists within max_depth."""
    db = _make_db()
    m1 = _add_memory(db, "Isolated A", "completely isolated memory one")
    m2 = _add_memory(db, "Isolated B", "completely isolated memory two")
    # No relation added between them

    path = find_path(m1, m2, max_depth=3, db=db)
    assert path is None


def test_find_path_same_node():
    """find_path with same from/to returns [id]."""
    db = _make_db()
    m1 = _add_memory(db, "Self", "self-referential memory")

    path = find_path(m1, m1, max_depth=3, db=db)
    assert path == [m1]


# ---------------------------------------------------------------------------
# test_contradiction_relation
# ---------------------------------------------------------------------------

def test_contradiction_relation():
    """Adding a 'contradicts' edge is stored and retrieved with correct type."""
    db = _make_db()

    m1 = _add_memory(db, "Claim A", "The sky is always blue during daytime")
    m2 = _add_memory(db, "Claim B", "The sky appears red orange during sunset sunrise")

    rel_id = add_relation(m1, m2, "contradicts", weight=0.9, db=db)
    assert rel_id is not None

    # Check both directions via get_relations
    all_rels = get_relations(m1, direction="both", db=db)
    assert len(all_rels) == 1
    assert all_rels[0]["relation_type"] == "contradicts"
    assert abs(all_rels[0]["weight"] - 0.9) < 0.001

    # Verify all 5 relation types are accepted
    m3 = _add_memory(db, "Claim C", "additional related claim memory content here")
    for rtype in VALID_RELATION_TYPES:
        add_relation(m1, m3, rtype, db=db)  # idempotent — re-inserts are ignored

    db.close()


# ---------------------------------------------------------------------------
# test_get_neighbors_depth
# ---------------------------------------------------------------------------

def test_get_neighbors_depth():
    """depth=1 returns only direct neighbors; depth=2 returns 2-hop as well."""
    db = _make_db()

    # Build: center -> hop1a, center -> hop1b, hop1a -> hop2
    center = _add_memory(db, "Center", "central knowledge node graph")
    hop1a = _add_memory(db, "Hop1A", "first hop direct neighbor")
    hop1b = _add_memory(db, "Hop1B", "another first hop neighbor")
    hop2 = _add_memory(db, "Hop2", "second hop indirect neighbor")

    add_relation(center, hop1a, "related_to", db=db)
    add_relation(center, hop1b, "supports", db=db)
    add_relation(hop1a, hop2, "refines", db=db)

    # Depth=1: only direct neighbors
    neighbors_d1 = get_neighbors(center, depth=1, db=db)
    neighbor_ids_d1 = {n["id"] for n in neighbors_d1}
    assert hop1a in neighbor_ids_d1
    assert hop1b in neighbor_ids_d1
    assert hop2 not in neighbor_ids_d1, "hop2 should not appear at depth=1"

    # Depth=2: direct + 2-hop
    neighbors_d2 = get_neighbors(center, depth=2, db=db)
    neighbor_ids_d2 = {n["id"] for n in neighbors_d2}
    assert hop1a in neighbor_ids_d2
    assert hop1b in neighbor_ids_d2
    assert hop2 in neighbor_ids_d2, "hop2 should appear at depth=2"

    # hop and relation_type are set
    hop2_node = next(n for n in neighbors_d2 if n["id"] == hop2)
    assert hop2_node["hop"] == 2


def test_get_neighbors_relation_type_filter():
    """get_neighbors with relation_types filter only returns matching edge types."""
    db = _make_db()

    root = _add_memory(db, "Root", "root node memory graph")
    supports_target = _add_memory(db, "Supports Target", "evidence supporting root claim")
    contradicts_target = _add_memory(db, "Contradicts Target", "contradicting alternative claim")

    add_relation(root, supports_target, "supports", db=db)
    add_relation(root, contradicts_target, "contradicts", db=db)

    # Filter to only 'supports'
    neighbors = get_neighbors(root, depth=1, relation_types=["supports"], db=db)
    ids = {n["id"] for n in neighbors}
    assert supports_target in ids
    assert contradicts_target not in ids


# ---------------------------------------------------------------------------
# Tokenizer unit tests
# ---------------------------------------------------------------------------

def test_tokenize_basic():
    """_tokenize extracts keywords >= 4 chars, excluding stopwords."""
    tokens = _tokenize("The quick brown fox jumps over the lazy dog")
    assert "quick" in tokens
    assert "brown" in tokens
    assert "jumps" in tokens
    assert "the" not in tokens   # stopword, also < 4 chars... but stopword wins
    assert "that" not in tokens  # stopword
    assert "with" not in tokens  # stopword
    # 3-char words are excluded by the >= 4 char filter
    assert "fox" not in tokens
    assert "dog" not in tokens


def test_overlap_score_identical():
    a = {"python", "machine", "learning", "data"}
    assert _overlap_score(a, a) == 1.0


def test_overlap_score_disjoint():
    a = {"python", "machine", "learning"}
    b = {"cooking", "baking", "flour"}
    assert _overlap_score(a, b) == 0.0


def test_overlap_score_partial():
    a = {"python", "machine", "learning", "data"}
    b = {"python", "machine", "cooking", "flour"}
    score = _overlap_score(a, b)
    assert 0.0 < score < 1.0
    # intersection=2 {python,machine}, union=6
    assert abs(score - 2 / 6) < 0.001
