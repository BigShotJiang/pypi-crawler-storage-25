"""Comprehensive auth tests — user accounts for myaibrain.org.

Covers the acceptance criteria for task 17Szyq5Vee9:
- Signup with password, bcrypt hashing verified
- Login with correct/wrong password (including rate limit)
- Logout invalidates session
- OAuth callback creates / links accounts
- Account linking adds method to existing user
- 2FA setup + verify + disable (with password reauth)
- Login with 2FA requires TOTP
- Password reset single-use + 15 min expiry
- Rate limit blocks after 5 failed logins
- Session in HttpOnly cookie
- Email verification flow
- /auth/me returns subscription state
- Dashboard shows correct subscription state (license_state row)

All tests use a temp SQLite DB — no production data touched. External HTTP
(SMTP, OAuth) is mocked via in-module hooks. No real network calls.
"""

import os
import sqlite3
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

# Set AIBRAIN_DB BEFORE any imports that open the database.
_TMP_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_TMP_DB.close()
os.environ["AIBRAIN_DB"] = _TMP_DB.name
os.environ["AIBRAIN_COOKIE_INSECURE"] = "1"  # allow non-HTTPS in tests
os.environ["AIBRAIN_BASE_URL"] = "http://testserver"
os.environ["MYAIBRAIN_SITE_URL"] = "http://testsite"

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(REPO_ROOT / "backend"))

# Initialize the schema in our temp DB via the auth.db helper (which respects
# AIBRAIN_DB env var).
from auth.db import get_conn  # noqa: E402
import aibrain_db  # noqa: E402

_conn = get_conn()
# Pre-create execution_log with the full schema (including the 'actor' column
# added in commit ae85b25) so _migrate_schema's index creation succeeds on a
# fresh DB.  _init_schema uses CREATE TABLE IF NOT EXISTS, so this is a no-op
# once the table already exists.
_conn.execute("""
    CREATE TABLE IF NOT EXISTS execution_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id TEXT,
        actor TEXT,
        action TEXT NOT NULL,
        entity_type TEXT,
        entity_id TEXT,
        detail TEXT,
        quality_score REAL,
        model_used TEXT,
        cost_cents INTEGER DEFAULT 0,
        duration_ms INTEGER DEFAULT 0,
        before_state TEXT,
        after_state TEXT,
        success INTEGER DEFAULT 0,
        error TEXT,
        task_type TEXT,
        authority TEXT,
        retries INTEGER DEFAULT 0,
        created_at TEXT DEFAULT (datetime('now'))
    )
""")
aibrain_db._init_schema(_conn)
aibrain_db._migrate_schema(_conn)
_conn.commit()
_conn.close()

# Now import the test client + auth modules
from fastapi import FastAPI  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402

from auth import oauth, password as pwd, sessions, totp  # noqa: E402
from auth_routes import router as auth_router, _ip_rate_reset  # noqa: E402
from auth.email_sender import enable_test_capture, disable_test_capture  # noqa: E402


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


@pytest.fixture(scope="module", autouse=True)
def _pin_auth_db():
    """Re-pin AIBRAIN_DB to this module's temp DB before any test runs.

    Other test modules (test_stripe_webhook, test_auth_e2e, etc.) set
    os.environ["AIBRAIN_DB"] at module-level during pytest collection.
    Because collection finishes before tests start, the env var is left
    pointing at the LAST module that wrote it — not necessarily this one.
    This fixture restores the correct path at module-test-execution time
    so that auth.db.get_conn() and auth_routes both use _TMP_DB.
    """
    os.environ["AIBRAIN_DB"] = _TMP_DB.name
    yield
    # No teardown needed — _restore_auth_env_after_session in conftest
    # handles session-level cleanup.


@pytest.fixture(scope="module")
def app():
    _app = FastAPI()
    _app.include_router(auth_router)
    return _app


@pytest.fixture(scope="module")
def client(app):
    return TestClient(app)


@pytest.fixture(autouse=True)
def _clean_db():
    """Wipe user + session tables between tests for isolation."""
    conn = get_conn()
    # Whitelist of tables we clear between tests — never user-controlled.
    _TABLES_TO_CLEAR = frozenset({
        "sessions", "oauth_links", "oauth_states",
        "password_reset_tokens", "email_verification_tokens",
        "login_attempts", "license_state",
    })
    _STATEMENTS = {
        "sessions": "DELETE FROM sessions",
        "oauth_links": "DELETE FROM oauth_links",
        "oauth_states": "DELETE FROM oauth_states",
        "password_reset_tokens": "DELETE FROM password_reset_tokens",
        "email_verification_tokens": "DELETE FROM email_verification_tokens",
        "login_attempts": "DELETE FROM login_attempts",
        "license_state": "DELETE FROM license_state",
    }
    for t in _TABLES_TO_CLEAR:
        try:
            conn.execute(_STATEMENTS[t])
        except sqlite3.OperationalError:
            pass
    # LIKE pattern is a literal test-only domain — no user input can reach here.
    conn.execute(
        r"DELETE FROM users WHERE email LIKE ? ESCAPE '\'",
        (r"%@test.invalid",),
    )
    conn.close()

    # Reset in-memory IP rate limiter between tests to prevent cross-test
    # accumulation from the fixed "testclient" IP used by TestClient.
    _ip_rate_reset()

    # Email capture on for every test
    inbox = enable_test_capture()
    # Clear OAuth mock
    oauth.clear_mock_exchange()
    yield inbox
    disable_test_capture()
    oauth.clear_mock_exchange()


def _signup(client, email="a@test.invalid", password="supersecret123"):  # noqa:hardcoded-secret — test fixture, not a real credential
    return client.post("/auth/signup", json={"email": email, "password": password})


def _login(client, email="a@test.invalid", password="supersecret123", totp_code=None):  # noqa:hardcoded-secret — test fixture
    body = {"email": email, "password": password}
    if totp_code is not None:
        body["totp"] = totp_code
    return client.post("/auth/login", json=body)


# ---------------------------------------------------------------------------
# 1. Signup
# ---------------------------------------------------------------------------

def test_signup_with_password(client):
    r = _signup(client)
    assert r.status_code == 200, r.text
    data = r.json()
    assert data["email"] == "a@test.invalid"
    assert data["email_verified"] is False
    assert "user_id" in data
    # Session cookie set
    assert sessions.COOKIE_NAME in r.cookies


def test_signup_uses_bcrypt(client):
    _signup(client, email="bcrypt@test.invalid")
    conn = get_conn()
    row = conn.execute(
        "SELECT password_hash FROM users WHERE email = ?", ("bcrypt@test.invalid",)
    ).fetchone()
    conn.close()
    assert row is not None
    assert pwd.is_bcrypt_hash(row["password_hash"])
    # Cost factor 12 — bcrypt hash format: $2b$12$...
    assert "$12$" in row["password_hash"]


def test_signup_duplicate_rejected(client):
    _signup(client, email="dup@test.invalid")
    r = _signup(client, email="dup@test.invalid")
    assert r.status_code == 409


def test_signup_sends_verification_email(client):
    inbox = enable_test_capture()
    _signup(client, email="vemail@test.invalid")
    # Inbox should contain one message
    assert any(m["to"] == "vemail@test.invalid" for m in inbox)
    msg = next(m for m in inbox if m["to"] == "vemail@test.invalid")
    assert "verify" in msg["subject"].lower()
    assert "verify-email?token=" in msg["body"]  # noqa:hardcoded-secret — URL fragment, not a credential


def test_signup_weak_password_rejected(client):
    r = client.post("/auth/signup", json={"email": "weak@test.invalid", "password": "short"})
    assert r.status_code == 400


# ---------------------------------------------------------------------------
# 2. Login / Logout
# ---------------------------------------------------------------------------

def test_login_correct_password(client):
    _signup(client, email="login@test.invalid")
    # Fresh client (no cookie) to force real login
    r = _login(client, email="login@test.invalid")
    assert r.status_code == 200
    assert sessions.COOKIE_NAME in r.cookies


def test_login_wrong_password(client):
    _signup(client, email="wrong@test.invalid")
    r = client.post("/auth/login", json={"email": "wrong@test.invalid", "password": "notrightpassword"})
    assert r.status_code == 401


def test_login_unknown_email(client):
    r = client.post("/auth/login", json={"email": "ghost@test.invalid", "password": "supersecret123"})
    assert r.status_code == 401


def test_logout_invalidates_session(client):
    _signup(client, email="logout@test.invalid")
    # TestClient persists cookies; check /auth/me works first
    r = client.get("/auth/me")
    assert r.status_code == 200
    # Logout
    r = client.post("/auth/logout", json={})
    assert r.status_code == 200
    # /auth/me should now 401
    client.cookies.clear()
    r = client.get("/auth/me")
    assert r.status_code == 401


def test_session_cookie_is_httponly(client):
    r = _signup(client, email="cookie@test.invalid")
    # httponly is set on the server but TestClient strips the attr, so verify
    # by checking the raw Set-Cookie header.
    set_cookie = r.headers.get("set-cookie", "")
    assert "httponly" in set_cookie.lower()


# ---------------------------------------------------------------------------
# 3. Rate limit
# ---------------------------------------------------------------------------

def test_rate_limit_blocks_after_5_failed(client):
    _signup(client, email="rl@test.invalid")
    client.post("/auth/logout", json={})
    for _ in range(5):
        r = client.post("/auth/login", json={"email": "rl@test.invalid", "password": "wrongpassword1"})
        assert r.status_code == 401
    # 6th attempt — should be rate limited
    r = client.post("/auth/login", json={"email": "rl@test.invalid", "password": "wrongpassword1"})
    assert r.status_code == 429


# ---------------------------------------------------------------------------
# 4. Password reset
# ---------------------------------------------------------------------------

def test_password_reset_flow(client):
    _signup(client, email="reset@test.invalid")
    client.post("/auth/logout", json={})
    inbox = enable_test_capture()

    r = client.post("/auth/password/reset/request", json={"email": "reset@test.invalid"})
    assert r.status_code == 200

    msg = next(m for m in inbox if m["to"] == "reset@test.invalid")
    # Extract token from body
    import re
    m = re.search(r"token=([A-Za-z0-9_\-]+)", msg["body"])
    assert m, "No token in reset email"
    token = m.group(1)

    # Confirm reset
    r = client.post(
        "/auth/password/reset/confirm",
        json={"token": token, "new_password": "brandnewpass987"},
    )
    assert r.status_code == 200

    # Log in with new password
    r = client.post("/auth/login", json={"email": "reset@test.invalid", "password": "brandnewpass987"})
    assert r.status_code == 200

    # Token should be single-use
    r = client.post(
        "/auth/password/reset/confirm",
        json={"token": token, "new_password": "anotherpass123"},
    )
    assert r.status_code == 400


def test_password_reset_token_expired(client):
    _signup(client, email="expired@test.invalid")
    conn = get_conn()
    user_id = conn.execute(
        "SELECT id FROM users WHERE email = ?", ("expired@test.invalid",)
    ).fetchone()["id"]
    # Manually insert an already-expired token
    conn.execute(
        "INSERT INTO password_reset_tokens (token, user_id, created_at, expires_at) "
        "VALUES (?, ?, ?, ?)",
        (
            "expired-token-xyz", user_id,
            (datetime.now(timezone.utc) - timedelta(hours=1)).strftime("%Y-%m-%d %H:%M:%S"),
            (datetime.now(timezone.utc) - timedelta(minutes=30)).strftime("%Y-%m-%d %H:%M:%S"),
        ),
    )
    conn.close()

    r = client.post(
        "/auth/password/reset/confirm",
        json={"token": "expired-token-xyz", "new_password": "newvalidpass123"},
    )
    assert r.status_code == 400


def test_password_reset_nonexistent_email_no_leak(client):
    # Should return 200 even though no account exists.
    r = client.post("/auth/password/reset/request", json={"email": "nobody@test.invalid"})
    assert r.status_code == 200


# ---------------------------------------------------------------------------
# 5. Email verification
# ---------------------------------------------------------------------------

def test_email_verification_flow(client):
    inbox = enable_test_capture()
    _signup(client, email="verify@test.invalid")
    # Extract token from email
    msg = next(m for m in inbox if m["to"] == "verify@test.invalid")
    import re
    m = re.search(r"verify-email\?token=([A-Za-z0-9_\-]+)", msg["body"])
    assert m
    token = m.group(1)

    r = client.get(f"/auth/verify-email?token={token}")
    assert r.status_code == 200
    assert r.json()["status"] == "verified"

    # /auth/me should now show verified
    r = client.get("/auth/me")
    assert r.status_code == 200
    assert r.json()["email_verified"] is True


# ---------------------------------------------------------------------------
# 6. 2FA (TOTP)
# ---------------------------------------------------------------------------

def test_2fa_setup_and_verify(client):
    _signup(client, email="tfa@test.invalid")
    r = client.post("/auth/2fa/setup", json={"password": "supersecret123"})
    assert r.status_code == 200
    secret = r.json()["secret"]
    assert "otpauth_uri" in r.json()

    # Generate current code and verify
    code = totp.current_code(secret)
    r = client.post("/auth/2fa/verify", json={"code": code})
    assert r.status_code == 200

    # /auth/me should show 2FA enabled
    r = client.get("/auth/me")
    assert r.json()["totp_enabled"] is True


def test_login_with_2fa_requires_totp(client):
    _signup(client, email="tfalogin@test.invalid")
    r = client.post("/auth/2fa/setup", json={"password": "supersecret123"})
    secret = r.json()["secret"]
    code = totp.current_code(secret)
    client.post("/auth/2fa/verify", json={"code": code})
    client.post("/auth/logout", json={})
    client.cookies.clear()

    # Login without TOTP — should return totp_required
    r = client.post(
        "/auth/login",
        json={"email": "tfalogin@test.invalid", "password": "supersecret123"},
    )
    assert r.status_code == 200
    assert r.json()["status"] == "totp_required"

    # Login with bad TOTP
    r = client.post(
        "/auth/login",
        json={"email": "tfalogin@test.invalid", "password": "supersecret123", "totp": "000000"},
    )
    assert r.status_code == 401

    # Login with good TOTP
    good = totp.current_code(secret)
    r = client.post(
        "/auth/login",
        json={"email": "tfalogin@test.invalid", "password": "supersecret123", "totp": good},
    )
    assert r.status_code == 200
    assert "user_id" in r.json()


def test_2fa_disable_requires_password(client):
    _signup(client, email="tfadisable@test.invalid")
    r = client.post("/auth/2fa/setup", json={"password": "supersecret123"})
    secret = r.json()["secret"]
    client.post("/auth/2fa/verify", json={"code": totp.current_code(secret)})

    # Disable with wrong password
    r = client.post("/auth/2fa/disable", json={"password": "wrong"})
    assert r.status_code == 401

    # Disable with correct password
    r = client.post("/auth/2fa/disable", json={"password": "supersecret123"})
    assert r.status_code == 200


def test_totp_algorithm_tolerates_clock_skew():
    # Unit test — ±1 step tolerance
    secret = totp.generate_secret()
    import time
    t = time.time()
    # Current
    assert totp.verify_code(secret, totp.current_code(secret, now=t), now=t)
    # One step back
    assert totp.verify_code(secret, totp.current_code(secret, now=t - 30), now=t)
    # One step forward
    assert totp.verify_code(secret, totp.current_code(secret, now=t + 30), now=t)
    # Two steps — rejected
    assert not totp.verify_code(secret, totp.current_code(secret, now=t - 60), now=t)


# ---------------------------------------------------------------------------
# 7. OAuth
# ---------------------------------------------------------------------------

def test_oauth_provider_button_hidden_without_env(client):
    # No env vars set — provider disabled
    for key in ("GITHUB_OAUTH_CLIENT_ID", "GITHUB_OAUTH_CLIENT_SECRET"):
        os.environ.pop(key, None)
    r = client.get("/auth/oauth/providers")
    assert r.status_code == 200
    assert "github" not in r.json()["enabled"]
    assert "github" in r.json()["supported"]


def test_oauth_start_hidden_without_config(client):
    for key in ("GOOGLE_OAUTH_CLIENT_ID", "GOOGLE_OAUTH_CLIENT_SECRET"):
        os.environ.pop(key, None)
    r = client.get("/auth/oauth/google/start", follow_redirects=False)
    assert r.status_code == 503


def test_oauth_callback_creates_new_account(client):
    # Mock provider exchange
    os.environ["GITHUB_OAUTH_CLIENT_ID"] = "test-id"
    os.environ["GITHUB_OAUTH_CLIENT_SECRET"] = "test-secret"
    oauth.set_mock_exchange(lambda p, c: ("12345", "newoauthuser@test.invalid"))

    # Initiate flow to get state
    r = client.get("/auth/oauth/github/start", follow_redirects=False)
    assert r.status_code == 302
    loc = r.headers["location"]
    assert "github.com" in loc
    import urllib.parse
    qs = urllib.parse.parse_qs(urllib.parse.urlparse(loc).query)
    state = qs["state"][0]

    # Simulate provider callback
    r = client.get(f"/auth/oauth/github/callback?code=fakecode&state={state}", follow_redirects=False)
    assert r.status_code == 302

    # User should exist
    conn = get_conn()
    user = conn.execute(
        "SELECT * FROM users WHERE email = ?", ("newoauthuser@test.invalid",)
    ).fetchone()
    assert user is not None
    link = conn.execute(
        "SELECT * FROM oauth_links WHERE user_id = ? AND provider = ?",
        (user["id"], "github"),
    ).fetchone()
    conn.close()
    assert link is not None


def test_oauth_callback_links_to_existing_email(client):
    # Sign up with password, then OAuth callback with same email.
    os.environ["GITHUB_OAUTH_CLIENT_ID"] = "test-id"
    os.environ["GITHUB_OAUTH_CLIENT_SECRET"] = "test-secret"
    _signup(client, email="existing@test.invalid")
    client.cookies.clear()

    oauth.set_mock_exchange(lambda p, c: ("67890", "existing@test.invalid"))

    r = client.get("/auth/oauth/github/start", follow_redirects=False)
    import urllib.parse
    state = urllib.parse.parse_qs(urllib.parse.urlparse(r.headers["location"]).query)["state"][0]

    r = client.get(f"/auth/oauth/github/callback?code=fakecode&state={state}", follow_redirects=False)
    assert r.status_code == 302

    conn = get_conn()
    # Only one user — no duplicate
    count = conn.execute(
        "SELECT COUNT(*) FROM users WHERE email = ?", ("existing@test.invalid",)
    ).fetchone()[0]
    assert count == 1
    # Link row exists
    link = conn.execute(
        "SELECT * FROM oauth_links WHERE provider_user_id = ?", ("67890",)
    ).fetchone()
    conn.close()
    assert link is not None


def test_oauth_link_adds_method_to_logged_in_user(client):
    # Sign up, then link GitHub as a second method.
    os.environ["GITHUB_OAUTH_CLIENT_ID"] = "test-id"
    os.environ["GITHUB_OAUTH_CLIENT_SECRET"] = "test-secret"
    _signup(client, email="linker@test.invalid")

    oauth.set_mock_exchange(lambda p, c: ("link-uid", "linker@test.invalid"))
    r = client.post("/auth/oauth/github/link", json={})
    assert r.status_code == 200
    url = r.json()["authorize_url"]
    import urllib.parse
    state = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["state"][0]

    r = client.get(f"/auth/oauth/github/callback?code=fakecode&state={state}", follow_redirects=False)
    assert r.status_code == 302

    # /auth/me should show github linked
    r = client.get("/auth/me")
    assert r.json()["linked_methods"]["github"] is True
    assert r.json()["linked_methods"]["password"] is True


def test_oauth_invalid_state_rejected(client):
    os.environ["GITHUB_OAUTH_CLIENT_ID"] = "test-id"
    os.environ["GITHUB_OAUTH_CLIENT_SECRET"] = "test-secret"
    r = client.get("/auth/oauth/github/callback?code=x&state=bogus", follow_redirects=False)
    assert r.status_code == 400


# ---------------------------------------------------------------------------
# 8. Dashboard / license_state
# ---------------------------------------------------------------------------

def test_me_shows_subscription_state(client):
    _signup(client, email="sub@test.invalid")
    # Insert a license_state row
    conn = get_conn()
    user_id = conn.execute(
        "SELECT id FROM users WHERE email = ?", ("sub@test.invalid",)
    ).fetchone()["id"]
    conn.execute(
        "INSERT INTO license_state (user_id, tier, license_key, stripe_customer_id, "
        "stripe_subscription_id, valid_until, updated_at) "
        "VALUES (?, 'pro', 'AIBR-ABCDEF1234567890XYZ', 'cus_test', 'sub_test', "
        "'2099-01-01 00:00:00', datetime('now'))",
        (user_id,),
    )
    conn.close()

    r = client.get("/auth/me")
    data = r.json()
    assert data["license"]["tier"] == "pro"
    # License key masked (first 4 + last 4)
    masked = data["license"]["license_key_masked"]
    assert masked.startswith("AIBR")
    assert masked.endswith("0XYZ")
    assert "*" in masked
    assert data["license"]["stripe_customer_id"] == "cus_test"


def test_me_returns_linked_methods(client):
    _signup(client, email="methods@test.invalid")
    r = client.get("/auth/me")
    data = r.json()
    assert data["linked_methods"]["password"] is True
    assert data["linked_methods"]["github"] is False
    assert data["linked_methods"]["google"] is False
    assert data["linked_methods"]["microsoft"] is False


# ---------------------------------------------------------------------------
# 9. bcrypt direct test
# ---------------------------------------------------------------------------

def test_bcrypt_hash_verify_roundtrip():
    h = pwd.hash_password("hello world 123")
    assert pwd.is_bcrypt_hash(h)
    assert pwd.verify_password("hello world 123", h)
    assert not pwd.verify_password("wrong", h)
