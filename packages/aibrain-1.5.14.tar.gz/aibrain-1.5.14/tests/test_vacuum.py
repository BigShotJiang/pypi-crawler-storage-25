"""
tests/test_vacuum.py — vacuum_memories_vec() unit tests.

Two tests:
  test_vacuum_removes_orphans — insert memory + vec row, delete memory, run
      vacuum, verify vec row is gone.
  test_vacuum_keeps_valid — insert memory + vec row, run vacuum, verify vec
      row is preserved.

These tests open an in-memory SQLite DB with the plain memories and a stub
memories_vec table (standard SQLite, no sqlite-vec extension required) so
they run cleanly in CI without the native extension installed.
"""

import sqlite3
import struct
import sys
from pathlib import Path

import pytest

# Ensure project root is importable (mirrors pattern in other test files)
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_db() -> sqlite3.Connection:
    """Return an in-memory SQLite DB with a minimal memories table and a plain
    memories_vec shadow table (not a vec0 virtual table — just a regular table
    with the same schema for testing the DELETE logic)."""
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript("""
        CREATE TABLE memories (
            id      INTEGER PRIMARY KEY AUTOINCREMENT,
            name    TEXT,
            content TEXT,
            active  INTEGER NOT NULL DEFAULT 1
        );

        -- Plain shadow table (mirrors memories_vec columns used by vacuum).
        -- Real production uses a vec0 virtual table, but the DELETE SQL is
        -- identical, so this is a faithful unit test of the helper logic.
        CREATE TABLE memories_vec (
            memory_id INTEGER PRIMARY KEY,
            embedding BLOB
        );
    """)
    conn.commit()
    return conn


def _insert_memory(conn, name="test", content="hello") -> int:
    """Insert a row in memories and return its id."""
    cur = conn.execute(
        "INSERT INTO memories (name, content) VALUES (?, ?)", (name, content)
    )
    conn.commit()
    return cur.lastrowid


def _insert_vec(conn, memory_id: int):
    """Insert a dummy embedding row in memories_vec."""
    dummy_emb = struct.pack("4f", 0.1, 0.2, 0.3, 0.4)
    conn.execute(
        "INSERT OR REPLACE INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
        (memory_id, dummy_emb),
    )
    conn.commit()


def _vec_exists(conn, memory_id: int) -> bool:
    row = conn.execute(
        "SELECT 1 FROM memories_vec WHERE memory_id = ?", (memory_id,)
    ).fetchone()
    return row is not None


# ---------------------------------------------------------------------------
# Import the helper under test
# ---------------------------------------------------------------------------

from aibrain_db import vacuum_memories_vec, _vacuum_memories_vec_conn  # noqa: E402


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_vacuum_removes_orphans():
    """Orphan vec rows (memory deleted) are removed by vacuum."""
    conn = _make_db()

    mem_id = _insert_memory(conn, name="orphan_test", content="will be deleted")
    _insert_vec(conn, mem_id)

    assert _vec_exists(conn, mem_id), "vec row should exist before delete"

    # Delete the memory — vec row becomes an orphan
    conn.execute("DELETE FROM memories WHERE id = ?", (mem_id,))
    conn.commit()

    # Run vacuum using the internal conn-level helper
    deleted = _vacuum_memories_vec_conn(conn)
    conn.commit()

    assert deleted == 1, f"expected 1 deleted, got {deleted}"
    assert not _vec_exists(conn, mem_id), "orphan vec row should be gone after vacuum"


def test_vacuum_keeps_valid():
    """Vec rows whose memory still exists are preserved by vacuum."""
    conn = _make_db()

    mem_id = _insert_memory(conn, name="valid_test", content="still alive")
    _insert_vec(conn, mem_id)

    assert _vec_exists(conn, mem_id), "vec row should exist before vacuum"

    deleted = _vacuum_memories_vec_conn(conn)
    conn.commit()

    assert deleted == 0, f"expected 0 deleted, got {deleted}"
    assert _vec_exists(conn, mem_id), "valid vec row must survive vacuum"


def test_vacuum_memories_vec_public_api():
    """vacuum_memories_vec(db=conn) public API returns correct dict."""
    conn = _make_db()

    # Insert two memories, two vec rows, then delete one memory
    id_keep = _insert_memory(conn, name="keep", content="staying")
    id_drop = _insert_memory(conn, name="drop", content="going away")
    _insert_vec(conn, id_keep)
    _insert_vec(conn, id_drop)

    conn.execute("DELETE FROM memories WHERE id = ?", (id_drop,))
    conn.commit()

    result = vacuum_memories_vec(db=conn)

    assert isinstance(result, dict)
    assert result.get("deleted") == 1, f"unexpected result: {result}"
    assert "error" not in result
    assert _vec_exists(conn, id_keep), "valid row must survive"
    assert not _vec_exists(conn, id_drop), "orphan row must be removed"
