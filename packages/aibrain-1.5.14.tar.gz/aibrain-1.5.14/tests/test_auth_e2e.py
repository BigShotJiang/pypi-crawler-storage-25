"""End-to-end test for user accounts — exercises the full happy path from
acceptance criteria #10.

Flow:
  1. Sign up with email+password
  2. Verify email
  3. Log in with password
  4. Buy Pro (simulated: insert license_state row directly — the Stripe
     webhook is tested separately in test_stripe_webhook.py)
  5. Dashboard shows Pro + masked license key + valid_until
  6. Link GitHub (mocked OAuth exchange)
  7. Log out, log in via GitHub — same account
  8. Enable 2FA
  9. Log out, log in with password + TOTP
 10. Cancel via Stripe portal (simulated: wipe license_state)

Uses a dedicated temp DB and the same mocking pattern as test_auth_accounts.
"""

import os
import re
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import pytest

# Dedicated temp DB so we don't collide with test_auth_accounts.
_TMP_DB = tempfile.NamedTemporaryFile(suffix=".db", delete=False)
_TMP_DB.close()
os.environ["AIBRAIN_DB"] = _TMP_DB.name
os.environ["AIBRAIN_COOKIE_INSECURE"] = "1"
os.environ["AIBRAIN_BASE_URL"] = "http://testserver"
os.environ["MYAIBRAIN_SITE_URL"] = "http://testsite"

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))
sys.path.insert(0, str(REPO_ROOT / "backend"))

from auth.db import get_conn  # noqa: E402
import aibrain_db  # noqa: E402

_conn = get_conn()
# Pre-create execution_log with the full schema (including the 'actor' column
# added in commit ae85b25) so _migrate_schema's index creation succeeds on a
# fresh DB.  _init_schema uses CREATE TABLE IF NOT EXISTS, so this is a no-op
# once the table already exists.
_conn.execute("""
    CREATE TABLE IF NOT EXISTS execution_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id TEXT,
        actor TEXT,
        action TEXT NOT NULL,
        entity_type TEXT,
        entity_id TEXT,
        detail TEXT,
        quality_score REAL,
        model_used TEXT,
        cost_cents INTEGER DEFAULT 0,
        duration_ms INTEGER DEFAULT 0,
        before_state TEXT,
        after_state TEXT,
        success INTEGER DEFAULT 0,
        error TEXT,
        task_type TEXT,
        authority TEXT,
        retries INTEGER DEFAULT 0,
        created_at TEXT DEFAULT (datetime('now'))
    )
""")
aibrain_db._init_schema(_conn)
aibrain_db._migrate_schema(_conn)
_conn.commit()
_conn.close()

from fastapi import FastAPI  # noqa: E402
from fastapi.testclient import TestClient  # noqa: E402
from auth import oauth, totp  # noqa: E402
from auth.email_sender import enable_test_capture  # noqa: E402
from auth_routes import router as auth_router, _ip_rate_reset  # noqa: E402


@pytest.fixture(scope="module", autouse=True)
def _pin_auth_db():
    """Re-pin AIBRAIN_DB to this module's temp DB before any test runs.

    Other test modules set os.environ["AIBRAIN_DB"] at module-level during
    pytest collection. Because collection finishes before tests start, the env
    var may point at a different module's DB by test-execution time.
    This fixture restores the correct path so auth.db.get_conn() uses _TMP_DB.
    """
    os.environ["AIBRAIN_DB"] = _TMP_DB.name
    yield


@pytest.fixture(scope="module")
def client():
    app = FastAPI()
    app.include_router(auth_router)
    yield TestClient(app)


def test_end_to_end_account_flow(client):
    # Reset in-memory IP rate store before e2e run to prevent cross-test pollution.
    _ip_rate_reset()
    inbox = enable_test_capture()
    os.environ["GITHUB_OAUTH_CLIENT_ID"] = "test-id"
    os.environ["GITHUB_OAUTH_CLIENT_SECRET"] = "test-secret"

    EMAIL = "e2e@test.invalid"
    PASS = "endtoendtest123"

    # 1. Sign up
    r = client.post("/auth/signup", json={"email": EMAIL, "password": PASS})
    assert r.status_code == 200, r.text
    user_id = r.json()["user_id"]
    assert r.json()["email_verified"] is False

    # 2. Verify email
    msg = next(m for m in inbox if m["to"] == EMAIL and "verify" in m["subject"].lower())
    m = re.search(r"verify-email\?token=([A-Za-z0-9_\-]+)", msg["body"])
    assert m
    r = client.get(f"/auth/verify-email?token={m.group(1)}")
    assert r.status_code == 200

    r = client.get("/auth/me")
    assert r.status_code == 200
    assert r.json()["email_verified"] is True

    # 3. Log out and log in again to prove password works
    client.post("/auth/logout", json={})
    client.cookies.clear()
    r = client.post("/auth/login", json={"email": EMAIL, "password": PASS})
    assert r.status_code == 200

    # 4. "Buy Pro" — simulate the stripe webhook writing a license_state row.
    conn = get_conn()
    conn.execute(
        "INSERT OR REPLACE INTO license_state "
        "(user_id, tier, license_key, stripe_customer_id, stripe_subscription_id, valid_until, updated_at) "
        "VALUES (?, 'pro', 'AIBR-E2E-ABCDEF1234567890XYZ', 'cus_e2e', 'sub_e2e', '2099-01-01 00:00:00', datetime('now'))",
        (user_id,),
    )
    conn.close()

    # 5. Dashboard shows Pro + masked key + valid_until
    r = client.get("/auth/me")
    data = r.json()
    assert data["license"]["tier"] == "pro"
    assert data["license"]["license_key_masked"].startswith("AIBR")
    assert "*" in data["license"]["license_key_masked"]
    assert data["license"]["valid_until"] == "2099-01-01 00:00:00"

    # 6. Link GitHub from dashboard
    oauth.set_mock_exchange(lambda p, c: ("gh-e2e-123", EMAIL))
    r = client.post("/auth/oauth/github/link", json={})
    assert r.status_code == 200
    url = r.json()["authorize_url"]
    import urllib.parse
    state = urllib.parse.parse_qs(urllib.parse.urlparse(url).query)["state"][0]

    r = client.get(f"/auth/oauth/github/callback?code=fake&state={state}", follow_redirects=False)
    assert r.status_code == 302

    r = client.get("/auth/me")
    assert r.json()["linked_methods"]["github"] is True
    assert r.json()["linked_methods"]["password"] is True

    # 7. Log out, log in via GitHub (fresh cookies), should land on same account
    client.post("/auth/logout", json={})
    client.cookies.clear()

    r = client.get("/auth/oauth/github/start", follow_redirects=False)
    state2 = urllib.parse.parse_qs(urllib.parse.urlparse(r.headers["location"]).query)["state"][0]
    r = client.get(f"/auth/oauth/github/callback?code=fake2&state={state2}", follow_redirects=False)
    assert r.status_code == 302

    r = client.get("/auth/me")
    assert r.status_code == 200
    assert r.json()["user_id"] == user_id  # same account
    assert r.json()["license"]["tier"] == "pro"  # same subscription

    # 8. Enable 2FA (need password reauth)
    r = client.post("/auth/2fa/setup", json={"password": PASS})
    assert r.status_code == 200
    secret = r.json()["secret"]
    r = client.post("/auth/2fa/verify", json={"code": totp.current_code(secret)})
    assert r.status_code == 200

    # 9. Log out, log in with password, should require TOTP
    client.post("/auth/logout", json={})
    client.cookies.clear()

    r = client.post("/auth/login", json={"email": EMAIL, "password": PASS})
    assert r.status_code == 200
    assert r.json().get("status") == "totp_required"

    r = client.post(
        "/auth/login",
        json={"email": EMAIL, "password": PASS, "totp": totp.current_code(secret)},
    )
    assert r.status_code == 200
    assert r.json()["user_id"] == user_id

    # 10. Cancel via Stripe portal — simulate expiry by clearing license_state.
    # (Real cancel goes through Stripe; webhook runs; 31-day loop expires.)
    conn = get_conn()
    conn.execute("DELETE FROM license_state WHERE user_id = ?", (user_id,))
    conn.close()
    r = client.get("/auth/me")
    assert r.json()["license"]["tier"] == "free"
