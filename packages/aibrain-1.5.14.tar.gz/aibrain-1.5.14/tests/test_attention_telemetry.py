"""
Tests for CLS Step 4 attention telemetry.

Verifies:
1. memory search triggers an attention_log row
2. memory_recall triggers an attention_log row
3. attention_log write failure is fail-open (search still returns results)

Design note: each test gets its own isolated DB via the isolated_db fixture.
We query via the same aibrain_db.get_db() that log_attention() writes to,
so we don't need separate connections.
"""

import os
import sqlite3
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


@pytest.fixture()
def isolated_db(tmp_path, monkeypatch):
    """Fresh temp DB for one test — patches aibrain_db + attention_telemetry."""
    db_path = str(tmp_path / "test_attention.db")
    monkeypatch.setenv("AIBRAIN_DB", db_path)
    monkeypatch.setenv("AIBRAIN_ROOT", str(tmp_path))

    import aibrain_db

    # Fully reset the module state to point at the temp DB
    if aibrain_db._conn is not None:
        try:
            aibrain_db._conn.close()
        except Exception:
            pass
    aibrain_db._conn = None
    aibrain_db.DB_PATH = Path(db_path)
    aibrain_db.AIBRAIN_ROOT = tmp_path

    # Reset attention_telemetry singleton so it doesn't write to a stale DB
    try:
        import aibrain.core.attention_telemetry as at
        at.reset_connection()
    except Exception:
        pass

    # Apply the full schema + migrations on the temp DB
    conn = aibrain_db.get_db()

    yield aibrain_db, conn

    # Teardown
    try:
        conn.close()
    except Exception:
        pass
    aibrain_db._conn = None


def _store_memory(aibrain_db, content: str = "test memory") -> int:
    """Insert a minimal memory row so search_memories has something to find."""
    conn = aibrain_db.get_db()
    cur = conn.execute(
        "INSERT INTO memories (name, content, type, active, status, importance) "
        "VALUES (?, ?, 'user', 1, 'active', 0.8)",
        (content[:50], content),
    )
    conn.commit()
    return cur.lastrowid


def _count_attention_rows(aibrain_db) -> int:
    return aibrain_db.get_db().execute("SELECT COUNT(*) FROM attention_log").fetchone()[0]


# ---------------------------------------------------------------------------
# Test 1: search logs attention
# ---------------------------------------------------------------------------

def test_search_logs_attention(isolated_db):
    """search_memories() must insert a row into attention_log."""
    adb, _conn = isolated_db

    _store_memory(adb, "neural network training loop")

    before = _count_attention_rows(adb)
    results = adb.search_memories("neural network", limit=5)
    after = _count_attention_rows(adb)

    assert after > before, (
        f"Expected at least 1 new attention_log row after search, "
        f"got before={before} after={after} results_count={len(results)}"
    )


# ---------------------------------------------------------------------------
# Test 2: recall logs attention
# ---------------------------------------------------------------------------

def test_recall_logs_attention(isolated_db):
    """memory_recall() must insert a row with query_type='recall'."""
    adb, _conn = isolated_db

    _store_memory(adb, "deployment configuration guide")

    from aibrain.core.memory_recall import memory_recall

    before = _count_attention_rows(adb)
    results = memory_recall("deployment config", limit=5, mode="default")
    after = _count_attention_rows(adb)

    assert after > before, (
        f"Expected at least 1 new attention_log row after recall, "
        f"got before={before} after={after} results_count={len(results)}"
    )

    # Verify the telemetry layer wrote a 'recall' query_type row
    recall_rows = adb.get_db().execute(
        "SELECT query_type FROM attention_log WHERE query_type = 'recall'"
    ).fetchall()
    all_rows = adb.get_db().execute(
        "SELECT id, query_type FROM attention_log"
    ).fetchall()
    assert len(recall_rows) >= 1, (
        f"Expected at least one attention_log row with query_type='recall'. "
        f"All rows: {[(dict(r)['id'], dict(r)['query_type']) for r in all_rows]}"
    )


# ---------------------------------------------------------------------------
# Test 3: telemetry failure is fail-open
# ---------------------------------------------------------------------------

def test_telemetry_doesnt_break_search(isolated_db):
    """If attention_log write fails, search_memories still returns results."""
    adb, _conn = isolated_db

    _store_memory(adb, "fail-open test memory content")

    # Make log_attention raise on every call
    with patch.object(adb, "log_attention", side_effect=RuntimeError("simulated telemetry failure")):
        # Also patch attention_telemetry.log_retrieval
        try:
            import aibrain.core.attention_telemetry as at
            with patch.object(at, "log_retrieval", side_effect=RuntimeError("simulated")):
                results = adb.search_memories("fail-open test", limit=5)
        except (ImportError, AttributeError):
            results = adb.search_memories("fail-open test", limit=5)

    assert isinstance(results, list), (
        f"search_memories should return a list, got {type(results)}"
    )
    assert len(results) > 0, (
        "search_memories should return results even when telemetry raises. "
        "Check that _log_attention is wrapped in try/except."
    )
