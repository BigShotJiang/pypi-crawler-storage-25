"""
tests/test_routing_settings.py — Unit tests for aibrain.core.routing_settings.

Covers:
  - test_default_settings: fresh load with no file → mode="auto", no budget
  - test_save_load: round-trip through JSON file
  - test_should_use_superworker_auto: auto mode, judgment/complex → True
  - test_should_use_superworker_never: never_superworker → always False
  - test_fast_mode_overrides: fast_mode=True → False regardless of task_type
  - test_deep_mode_overrides: deep_mode=True → True regardless of task_type
  - test_manual_mode: manual, no flags → False
  - test_budget_exceeded: mock DB with cost > budget → returns True
  - test_budget_not_exceeded: spend < cap → returns False
  - test_budget_none_cap: no cap configured → always False
  - test_budget_db_unavailable: DB missing → fail-open (False)
"""
from __future__ import annotations

import json
import sqlite3
import tempfile
from datetime import datetime
from pathlib import Path

import pytest

from aibrain.core.routing_settings import (
    VALID_MODES,
    RoutingSettings,
    check_budget_exceeded,
    get_today_spend_cents,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_settings_file(tmp_path: Path, data: dict) -> Path:
    """Write a routing.json file to tmp_path."""
    p = tmp_path / "routing.json"
    p.write_text(json.dumps(data), encoding="utf-8")
    return p


def _make_test_db(tmp_path: Path, today_cents: int) -> Path:
    """
    Create a minimal aibrain.db with execution_log containing one row
    with cost_cents_equivalent=today_cents for today's date.
    """
    db_path = tmp_path / "aibrain.db"
    db = sqlite3.connect(str(db_path))
    db.execute(
        """
        CREATE TABLE execution_log (
            id INTEGER PRIMARY KEY,
            action TEXT,
            cost_cents_equivalent INTEGER,
            created_at TEXT
        )
        """
    )
    now_iso = datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
    db.execute(
        "INSERT INTO execution_log (action, cost_cents_equivalent, created_at) VALUES (?, ?, ?)",
        ("test_action", today_cents, now_iso),
    )
    db.commit()
    db.close()
    return db_path


# ---------------------------------------------------------------------------
# Fixture: isolated settings path
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _isolate_settings(tmp_path, monkeypatch):
    """Redirect SETTINGS_PATH to a temp dir so tests never touch ~/.aibrain/routing.json."""
    import aibrain.core.routing_settings as rs_mod
    monkeypatch.setattr(rs_mod, "SETTINGS_PATH", tmp_path / "routing.json")
    yield


# ---------------------------------------------------------------------------
# Tests: RoutingSettings defaults and persistence
# ---------------------------------------------------------------------------

class TestDefaultSettings:
    def test_default_settings(self):
        """Load with no file → mode='auto', no budget, no per-invocation flags."""
        rs = RoutingSettings.load()
        assert rs.mode == "auto"
        assert rs.token_budget_per_day_cents is None
        assert rs.fast_mode is False
        assert rs.deep_mode is False

    def test_valid_modes_constant(self):
        """VALID_MODES must contain all four routing modes."""
        assert set(VALID_MODES) == {"auto", "always_superworker", "never_superworker", "manual"}


class TestSaveLoad:
    def test_save_load_round_trip(self, tmp_path):
        """Save non-default settings, load, verify round-trip."""
        rs = RoutingSettings(
            mode="always_superworker",
            token_budget_per_day_cents=500,
            fast_mode=False,
            deep_mode=True,
        )
        rs.save()
        loaded = RoutingSettings.load()
        assert loaded.mode == "always_superworker"
        assert loaded.token_budget_per_day_cents == 500
        assert loaded.fast_mode is False
        assert loaded.deep_mode is True

    def test_corrupt_file_falls_back_to_defaults(self, tmp_path):
        """Corrupt JSON → load returns defaults without raising."""
        import aibrain.core.routing_settings as rs_mod
        rs_mod.SETTINGS_PATH.write_text("{not valid json", encoding="utf-8")
        rs = RoutingSettings.load()
        assert rs.mode == "auto"

    def test_unknown_keys_ignored(self, tmp_path):
        """Extra keys in routing.json don't crash load (forward-compat)."""
        import aibrain.core.routing_settings as rs_mod
        rs_mod.SETTINGS_PATH.write_text(
            json.dumps({"mode": "auto", "future_key": "whatever"}),
            encoding="utf-8",
        )
        rs = RoutingSettings.load()
        assert rs.mode == "auto"


# ---------------------------------------------------------------------------
# Tests: should_use_superworker logic
# ---------------------------------------------------------------------------

class TestShouldUseSuperworker:
    def test_auto_mode_judgment_true(self):
        rs = RoutingSettings(mode="auto")
        assert rs.should_use_superworker("judgment") is True

    def test_auto_mode_complex_true(self):
        rs = RoutingSettings(mode="auto")
        assert rs.should_use_superworker("complex") is True

    def test_auto_mode_simple_false(self):
        rs = RoutingSettings(mode="auto")
        assert rs.should_use_superworker("simple") is False

    def test_auto_mode_deterministic_false(self):
        rs = RoutingSettings(mode="auto")
        assert rs.should_use_superworker("deterministic") is False

    def test_always_superworker_all_types(self):
        rs = RoutingSettings(mode="always_superworker")
        for task_type in ("deterministic", "simple", "judgment", "complex"):
            assert rs.should_use_superworker(task_type) is True, task_type

    def test_never_superworker_all_types(self):
        rs = RoutingSettings(mode="never_superworker")
        for task_type in ("deterministic", "simple", "judgment", "complex"):
            assert rs.should_use_superworker(task_type) is False, task_type

    def test_manual_mode_no_flags_false(self):
        """manual mode, no flags → always False (single-worker default)."""
        rs = RoutingSettings(mode="manual", fast_mode=False, deep_mode=False)
        assert rs.should_use_superworker("judgment") is False

    def test_fast_mode_overrides_auto(self):
        """fast_mode=True beats auto mode for judgment tasks → False."""
        rs = RoutingSettings(mode="auto", fast_mode=True, deep_mode=False)
        assert rs.should_use_superworker("judgment") is False

    def test_fast_mode_overrides_always_superworker(self):
        """fast_mode=True beats always_superworker → False."""
        rs = RoutingSettings(mode="always_superworker", fast_mode=True, deep_mode=False)
        assert rs.should_use_superworker("complex") is False

    def test_deep_mode_overrides_never_superworker(self):
        """deep_mode=True beats never_superworker → True."""
        rs = RoutingSettings(mode="never_superworker", fast_mode=False, deep_mode=True)
        assert rs.should_use_superworker("simple") is True

    def test_deep_mode_beats_fast_mode(self):
        """deep_mode has higher priority than fast_mode → True."""
        rs = RoutingSettings(mode="auto", fast_mode=True, deep_mode=True)
        assert rs.should_use_superworker("simple") is True

    def test_reset_restores_defaults(self):
        rs = RoutingSettings(mode="always_superworker", token_budget_per_day_cents=999)
        rs.reset()
        assert rs.mode == "auto"
        assert rs.token_budget_per_day_cents is None
        assert rs.fast_mode is False
        assert rs.deep_mode is False


# ---------------------------------------------------------------------------
# Tests: Budget enforcement
# ---------------------------------------------------------------------------

class TestBudgetExceeded:
    def test_no_cap_never_exceeded(self, tmp_path):
        """token_budget_per_day_cents=None → always False regardless of spend."""
        rs = RoutingSettings(token_budget_per_day_cents=None)
        db_path = _make_test_db(tmp_path, today_cents=999999)
        assert check_budget_exceeded(rs, db_path=db_path) is False

    def test_spend_below_cap_not_exceeded(self, tmp_path):
        """Spend < cap → False."""
        rs = RoutingSettings(token_budget_per_day_cents=1000)
        db_path = _make_test_db(tmp_path, today_cents=500)
        assert check_budget_exceeded(rs, db_path=db_path) is False

    def test_spend_equal_cap_exceeded(self, tmp_path):
        """Spend == cap → True (boundary: equal triggers the gate)."""
        rs = RoutingSettings(token_budget_per_day_cents=1000)
        db_path = _make_test_db(tmp_path, today_cents=1000)
        assert check_budget_exceeded(rs, db_path=db_path) is True

    def test_spend_above_cap_exceeded(self, tmp_path):
        """Spend > cap → True."""
        rs = RoutingSettings(token_budget_per_day_cents=500)
        db_path = _make_test_db(tmp_path, today_cents=750)
        assert check_budget_exceeded(rs, db_path=db_path) is True

    def test_db_unavailable_fail_open(self, tmp_path):
        """DB path missing → fail-open: returns False (never block on missing signal)."""
        rs = RoutingSettings(token_budget_per_day_cents=100)
        missing_db = tmp_path / "nonexistent.db"
        assert check_budget_exceeded(rs, db_path=missing_db) is False

    def test_get_today_spend_no_db(self, tmp_path):
        """DB does not exist → get_today_spend_cents returns None."""
        result = get_today_spend_cents(db_path=tmp_path / "nope.db")
        assert result is None

    def test_get_today_spend_zero_rows(self, tmp_path):
        """DB exists but no rows for today → returns 0."""
        db_path = tmp_path / "aibrain.db"
        db = sqlite3.connect(str(db_path))
        db.execute(
            """
            CREATE TABLE execution_log (
                id INTEGER PRIMARY KEY,
                action TEXT,
                cost_cents_equivalent INTEGER,
                created_at TEXT
            )
            """
        )
        db.commit()
        db.close()
        result = get_today_spend_cents(db_path=db_path)
        assert result == 0

    def test_get_today_spend_old_schema_returns_none(self, tmp_path):
        """Schema without cost_cents_equivalent → returns None (schema guard)."""
        db_path = tmp_path / "aibrain.db"
        db = sqlite3.connect(str(db_path))
        db.execute("CREATE TABLE execution_log (id INTEGER PRIMARY KEY, action TEXT)")
        db.commit()
        db.close()
        result = get_today_spend_cents(db_path=db_path)
        assert result is None
