"""
Tests for memory decay in consolidation workflow.

Verifies that storage_strength is updated continuously via the Ebbinghaus
forgetting curve (memory_decay.compute_decay_score), replacing the old
30-day linear cliff.
"""

import math
import os
import sqlite3
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from workflows.memory_consolidation import (
    decay_memories,
    DECAY_FLOOR,
)


@pytest.fixture()
def db():
    """Create a test DB with the memories schema (includes memory_history)."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_decaytest_")
    os.close(fd)

    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'project',
            memory_class TEXT DEFAULT 'semantic',
            tags TEXT DEFAULT '',
            content TEXT DEFAULT '',
            importance REAL DEFAULT 0.5,
            confidence REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            created TEXT DEFAULT (datetime('now')),
            updated TEXT DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1,
            storage_strength REAL DEFAULT 1.0,
            status TEXT DEFAULT 'active',
            consolidated_from TEXT
        );
        CREATE TABLE IF NOT EXISTS memory_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            memory_id INTEGER,
            action TEXT,
            created TEXT DEFAULT (datetime('now'))
        );
    """)
    conn.commit()

    yield conn

    conn.close()
    try:
        os.unlink(path)
    except OSError:
        pass
    for ext in ("-wal", "-shm"):
        try:
            os.unlink(path + ext)
        except OSError:
            pass


def _insert_memory(db, name, storage_strength=1.0, last_accessed=None, created=None,
                   importance=0.5, access_count=0):
    """Helper to insert a test memory."""
    db.execute("""
        INSERT INTO memories (name, type, content, storage_strength, last_accessed,
                              created, updated, active, status, importance, access_count)
        VALUES (?, 'project', 'test content', ?, ?, ?, datetime('now'), 1, 'active', ?, ?)
    """, (name, storage_strength, last_accessed, created or "2026-01-01 00:00:00",
          importance, access_count))
    db.commit()
    return db.execute("SELECT last_insert_rowid()").fetchone()[0]


class TestDecayMemories:
    """Test the decay_memories function with the Ebbinghaus curve."""

    def test_stale_memories_get_lower_strength(self, db):
        """Memories last accessed long ago should receive low storage_strength."""
        # Memory from Jan 2025 — ~15 months ago. Ebbinghaus will assign low retention.
        _insert_memory(db, "stale_mem", storage_strength=5.0,
                       last_accessed="2025-01-01 00:00:00", importance=0.5, access_count=0)

        decayed = decay_memories(db, dry_run=False)
        assert decayed >= 1

        row = db.execute(
            "SELECT storage_strength FROM memories WHERE name='stale_mem'"
        ).fetchone()
        # Stale memory should have low strength, above the floor.
        assert row["storage_strength"] < 5.0
        assert row["storage_strength"] >= DECAY_FLOOR

    def test_recent_memories_get_higher_strength(self, db):
        """Memories accessed very recently should receive high storage_strength (near 10.0)."""
        # last_accessed = now → elapsed_days ≈ 0 → retention ≈ 1.0 → strength ≈ 10.0
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        _insert_memory(db, "fresh_mem", storage_strength=1.0,
                       last_accessed=now_str, importance=0.5, access_count=5)

        decay_memories(db, dry_run=False)

        row = db.execute(
            "SELECT storage_strength FROM memories WHERE name='fresh_mem'"
        ).fetchone()
        # Fresh memory: retention near 1.0 → strength near 10.0
        assert row["storage_strength"] > 5.0

    def test_null_last_accessed_falls_back_to_created(self, db):
        """Memories with NULL last_accessed decay based on created date."""
        _insert_memory(db, "never_accessed", storage_strength=8.0,
                       last_accessed=None, created="2025-01-01 00:00:00")

        decayed = decay_memories(db, dry_run=False)
        assert decayed >= 1

        row = db.execute(
            "SELECT storage_strength FROM memories WHERE name='never_accessed'"
        ).fetchone()
        # Old never-accessed memory: should decay significantly from 8.0
        assert row["storage_strength"] < 8.0
        assert row["storage_strength"] >= DECAY_FLOOR

    def test_floor_is_respected(self, db):
        """Decay should not push storage_strength below DECAY_FLOOR."""
        _insert_memory(db, "very_old", storage_strength=0.15,
                       last_accessed="2020-01-01 00:00:00")

        decay_memories(db, dry_run=False)

        row = db.execute(
            "SELECT storage_strength FROM memories WHERE name='very_old'"
        ).fetchone()
        assert row["storage_strength"] >= DECAY_FLOOR

    def test_strength_is_continuous_not_bimodal(self, db):
        """storage_strength should span [0.1, 10.0] continuously, not just 0 or 1."""
        # Insert memories from 3 different ages — all should get distinct strengths.
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        _insert_memory(db, "age_1d",  storage_strength=5.0, last_accessed=now_str)
        _insert_memory(db, "age_30d", storage_strength=5.0,
                       last_accessed="2026-03-15 00:00:00")
        _insert_memory(db, "age_1yr", storage_strength=5.0,
                       last_accessed="2025-04-14 00:00:00")

        decay_memories(db, dry_run=False)

        rows = {
            r["name"]: r["storage_strength"]
            for r in db.execute(
                "SELECT name, storage_strength FROM memories WHERE name IN "
                "('age_1d','age_30d','age_1yr')"
            ).fetchall()
        }

        # Monotonic: fresher = stronger
        assert rows["age_1d"] > rows["age_30d"] > rows["age_1yr"]
        # All values distinct and within valid range
        for name, s in rows.items():
            assert DECAY_FLOOR <= s <= 10.0, f"{name}: {s} out of [0.1, 10.0]"

    def test_dry_run_does_not_modify(self, db):
        """Dry run should count but not modify any memories."""
        _insert_memory(db, "dry_test", storage_strength=5.0,
                       last_accessed="2025-01-01 00:00:00")

        count = decay_memories(db, dry_run=True)
        assert count >= 1

        row = db.execute(
            "SELECT storage_strength FROM memories WHERE name='dry_test'"
        ).fetchone()
        # Dry run must leave value unchanged.
        assert row["storage_strength"] == 5.0

    def test_idempotent_within_noise(self, db):
        """Running decay twice in rapid succession should touch 0 memories the second time."""
        now_str = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        _insert_memory(db, "idem_test", storage_strength=1.0, last_accessed=now_str)

        decay_memories(db, dry_run=False)
        second_run = decay_memories(db, dry_run=False)

        # Second run: new_strength == stored strength → no update
        assert second_run == 0
