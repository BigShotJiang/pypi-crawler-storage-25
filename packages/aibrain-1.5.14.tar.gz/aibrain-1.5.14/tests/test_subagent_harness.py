"""
Tests for subagent harness bookend functions in aibrain/core/harness.py.

Covers:
  - start_subagent_execution: creates an execution_log row
  - complete_subagent_execution: updates the row with output/quality/cost
  - score_subagent_output: returns a float in [0.0, 1.0]
"""

import sqlite3
import sys
import tempfile
import os
from pathlib import Path

import pytest

# Ensure repo root is on path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ---------------------------------------------------------------------------
# Fixture: isolated temp DB so tests don't pollute the real aibrain.db
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def isolated_db(tmp_path, monkeypatch):
    """Redirect AIBRAIN_ROOT to a temp directory for all tests in this file."""
    monkeypatch.setenv("AIBRAIN_ROOT", str(tmp_path))
    yield tmp_path


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _get_row(db_path: Path, execution_id: str) -> dict | None:
    db = sqlite3.connect(str(db_path))
    db.row_factory = sqlite3.Row
    row = db.execute(
        "SELECT * FROM execution_log WHERE id = ?", (execution_id,)
    ).fetchone()
    db.close()
    return dict(row) if row else None


# ---------------------------------------------------------------------------
# Tests: start_subagent_execution
# ---------------------------------------------------------------------------

class TestStartSubagentExecution:
    def test_returns_string_id(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution
        exec_id = start_subagent_execution("Test task", task_type="judgment", actor="neuro")
        assert isinstance(exec_id, str)
        assert len(exec_id) > 0

    def test_creates_row_in_execution_log(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("Audit auth module", task_type="judgment", actor="neuro")
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row is not None, "Row should exist in execution_log after start"

    def test_row_has_correct_actor(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("Do something", task_type="judgment", actor="case")
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row["actor"] == "case"

    def test_row_has_correct_task_type(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("Complex analysis", task_type="complex", actor="neuro")
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row["task_type"] == "complex"

    def test_row_starts_with_null_quality(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("Pending task", actor="neuro")
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row["quality_score"] is None, "Quality should be NULL before completion"

    def test_row_starts_with_success_false(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("In-flight task", actor="neuro")
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row["success"] == 0, "Success should be 0 (in-progress) before completion"

    def test_row_action_prefixed_with_subagent(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("Check vuln scan", actor="neuro")
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row["action"].startswith("subagent."), f"Action should start with 'subagent.', got: {row['action']}"

    def test_links_company_issue_id(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution(
            "Linked task", actor="neuro", company_issue_id="issue-xyz-123"
        )
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row["entity_id"] == "issue-xyz-123"
        assert row["entity_type"] == "company_issue"

    def test_entity_type_subagent_when_no_issue(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("Unlinked task", actor="neuro")
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row["entity_type"] == "subagent"
        assert row["entity_id"] is None


# ---------------------------------------------------------------------------
# Tests: complete_subagent_execution
# ---------------------------------------------------------------------------

class TestCompleteSubagentExecution:
    def test_returns_true_on_success(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution, complete_subagent_execution
        exec_id = start_subagent_execution("Task to complete", actor="neuro")
        result = complete_subagent_execution(exec_id, "Agent output here.", quality_score=0.75)
        assert result is True

    def test_updates_quality_score(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution, complete_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("Quality test", actor="neuro")
        complete_subagent_execution(exec_id, "Good output.", quality_score=0.82)
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert abs(row["quality_score"] - 0.82) < 0.001

    def test_marks_success_for_adequate_quality(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution, complete_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("Pass task", actor="neuro")
        complete_subagent_execution(exec_id, "Great output.", quality_score=0.70)
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row["success"] == 1

    def test_marks_failure_for_low_quality(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution, complete_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("Fail task", actor="neuro")
        complete_subagent_execution(exec_id, "Bad output.", quality_score=0.10)
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row["success"] == 0

    def test_stores_model_used(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution, complete_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("Model test", actor="neuro")
        complete_subagent_execution(exec_id, "Output.", quality_score=0.5, model_used="claude-sonnet-4-5")
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row["model_used"] == "claude-sonnet-4-5"

    def test_stores_cost_cents(self, isolated_db):
        from aibrain.core.harness import start_subagent_execution, complete_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("Cost test", actor="neuro")
        complete_subagent_execution(exec_id, "Output.", quality_score=0.6, cost_cents=42)
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row["cost_cents"] == 42

    def test_accepts_none_cost(self, isolated_db):
        """None cost = subscription-backed / unmeasurable — must not error."""
        from aibrain.core.harness import start_subagent_execution, complete_subagent_execution
        from aibrain_db import AIBRAIN_ROOT
        exec_id = start_subagent_execution("None cost test", actor="neuro")
        ok = complete_subagent_execution(exec_id, "Output.", quality_score=0.6, cost_cents=None)
        assert ok is True
        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row["cost_cents"] is None

    def test_returns_false_for_nonexistent_id(self, isolated_db):
        from aibrain.core.harness import complete_subagent_execution, start_subagent_execution
        # Need to start one first to ensure DB/table exists
        start_subagent_execution("Seed DB", actor="neuro")
        result = complete_subagent_execution("nonexistent-id-xyz", "Output.")
        # Should not raise — just returns True/False based on update success
        # SQLite UPDATE on non-matching WHERE is not an error, so True is acceptable
        # What matters: no exception raised
        assert result in (True, False)


# ---------------------------------------------------------------------------
# Tests: score_subagent_output
# ---------------------------------------------------------------------------

class TestScoreSubagentOutput:
    def test_returns_float(self):
        from aibrain.core.harness import score_subagent_output
        score = score_subagent_output("Some output text here.")
        assert isinstance(score, float)

    def test_score_in_range(self):
        from aibrain.core.harness import score_subagent_output
        for text in [
            "",
            "a",
            "short",
            "Found 3 issues in /api/users. See lines 42, 87.",
            "# Report\n\n- Issue 1: IDOR at `/api/users/<id>`\n- Issue 2: Missing auth\n\n## Recommendation\nAdd auth check.",
            "x " * 1000,
        ]:
            score = score_subagent_output(text, "audit the auth module")
            assert 0.0 <= score <= 1.0, f"Score out of range for text={text[:50]!r}: {score}"

    def test_empty_output_scores_zero(self):
        from aibrain.core.harness import score_subagent_output
        assert score_subagent_output("") == 0.0
        assert score_subagent_output("   ") == 0.0

    def test_nonempty_output_scores_above_floor(self):
        from aibrain.core.harness import score_subagent_output
        score = score_subagent_output("Something happened.")
        assert score >= 0.10, f"Non-empty output should score >= 0.10, got {score}"

    def test_rich_structured_output_scores_higher_than_bare(self):
        from aibrain.core.harness import score_subagent_output
        bare = "done"
        rich = (
            "# Audit Results\n\n"
            "Found **3 IDOR vulnerabilities** in `/api/users/<id>` endpoint.\n\n"
            "## Findings\n\n"
            "1. Line 42: Missing ownership check — `if user.id != request.user.id:`\n"
            "2. Line 87: Admin flag bypassable via `role=admin` query param\n"
            "3. Line 201: `/api/orders/<id>` returns all orders regardless of auth\n\n"
            "## Recommendation\n"
            "Add `require_ownership()` decorator to all user-scoped endpoints.\n"
        )
        score_bare = score_subagent_output(bare, "audit auth module for IDOR")
        score_rich = score_subagent_output(rich, "audit auth module for IDOR")
        assert score_rich > score_bare, (
            f"Rich output ({score_rich:.3f}) should score higher than bare ({score_bare:.3f})"
        )

    def test_task_relevance_boosts_score(self):
        from aibrain.core.harness import score_subagent_output
        on_topic = "Found IDOR vulnerabilities in the auth module endpoint."
        off_topic = "The weather today is sunny and warm in Adelaide."
        score_on = score_subagent_output(on_topic, "audit the auth module for IDOR")
        score_off = score_subagent_output(off_topic, "audit the auth module for IDOR")
        assert score_on >= score_off, (
            f"On-topic ({score_on:.3f}) should score >= off-topic ({score_off:.3f})"
        )

    def test_no_task_description_returns_neutral_relevance(self):
        """With no task_description, function should not raise and should return in range."""
        from aibrain.core.harness import score_subagent_output
        score = score_subagent_output("Some output text.", task_description="")
        assert 0.0 <= score <= 1.0

    def test_file_paths_boost_specificity(self):
        from aibrain.core.harness import score_subagent_output
        with_paths = "See /api/users/route.py line 42 for the issue."
        without_paths = "There is an issue somewhere in the code."
        score_with = score_subagent_output(with_paths)
        score_without = score_subagent_output(without_paths)
        assert score_with >= score_without, (
            f"Output with file paths ({score_with:.3f}) should score >= without ({score_without:.3f})"
        )


# ---------------------------------------------------------------------------
# Integration: full start → complete → verify cycle
# ---------------------------------------------------------------------------

class TestFullCycle:
    def test_start_then_complete_row_persists(self, isolated_db):
        from aibrain.core.harness import (
            start_subagent_execution,
            complete_subagent_execution,
            score_subagent_output,
        )
        from aibrain_db import AIBRAIN_ROOT

        task_desc = "Scan the auth module for SQL injection vulnerabilities"
        agent_output = (
            "# SQL Injection Scan\n\n"
            "Scanned `/api/auth/login` endpoint. Found 1 parameterised query "
            "and 2 raw f-string queries in `auth/views.py` lines 88, 102.\n\n"
            "- Line 88: `f\"SELECT * FROM users WHERE name='{name}'\"` — VULNERABLE\n"
            "- Line 102: `f\"DELETE FROM sessions WHERE id={sid}\"` — VULNERABLE\n\n"
            "**Recommendation:** Replace with parameterised queries using `cursor.execute(sql, params)`."
        )

        exec_id = start_subagent_execution(task_desc, task_type="judgment", actor="neuro")
        quality = score_subagent_output(agent_output, task_desc)
        ok = complete_subagent_execution(
            exec_id, agent_output, quality_score=quality, cost_cents=None, model_used=None
        )

        assert ok is True
        assert 0.0 < quality <= 1.0

        db_path = AIBRAIN_ROOT / "aibrain.db"
        row = _get_row(db_path, exec_id)
        assert row is not None
        assert abs(row["quality_score"] - quality) < 0.001
        assert row["success"] == (1 if quality >= 0.3 else 0)
