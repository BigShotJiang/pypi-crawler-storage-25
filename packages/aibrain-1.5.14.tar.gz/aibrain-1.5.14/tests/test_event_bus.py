"""
Tests for aibrain/core/event_bus.py — AIBrainBus reactive event wiring + audit log.

6 tests covering:
  1. emit+subscribe works (in-process handler fires)
  2. Persistence to DB (row written with event_type + actor)
  3. CLI returns events (cli_events output contains emitted event)
  4. Filter by type (recent() respects event_type filter)
  5. Filter by actor (recent() respects actor filter)
  6. Harness emits task.start and task.complete events
"""

from __future__ import annotations

import json
import os
import sqlite3
import sys
import tempfile
from io import StringIO
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ---------------------------------------------------------------------------
# Helpers: redirect event_bus DB writes to a temp file during tests
# ---------------------------------------------------------------------------

def _temp_db_context():
    """Context manager that redirects event_bus to a fresh temp DB."""
    import importlib
    fd, db_path = tempfile.mkstemp(suffix=".db", prefix="aibrain_test_event_bus_")
    os.close(fd)
    return db_path


def _cleanup(db_path: str):
    for suffix in ("", "-wal", "-shm"):
        try:
            os.unlink(db_path + suffix)
        except OSError:
            pass


# ---------------------------------------------------------------------------
# Test 1: emit + subscribe (in-process handler fires)
# ---------------------------------------------------------------------------

class TestEmitSubscribe:
    def test_emit_fires_registered_handler(self, tmp_path):
        """Registered handler must be called synchronously on emit()."""
        db_path = str(tmp_path / "test.db")
        received = []

        with patch("aibrain.core.event_bus._get_db_path", return_value=Path(db_path)):
            import aibrain.core.event_bus as bus
            bus.clear_handlers()
            bus.on("test.ping", lambda p: received.append(p))
            bus.emit("test.ping", {"msg": "hello"})
            bus.clear_handlers()

        assert len(received) == 1
        assert received[0]["msg"] == "hello"

    def test_emit_fires_multiple_handlers(self, tmp_path):
        """All registered handlers for a type must fire."""
        db_path = str(tmp_path / "test.db")
        calls = []

        with patch("aibrain.core.event_bus._get_db_path", return_value=Path(db_path)):
            import aibrain.core.event_bus as bus
            bus.clear_handlers()
            bus.on("test.multi", lambda p: calls.append("h1"))
            bus.on("test.multi", lambda p: calls.append("h2"))
            bus.emit("test.multi", {})
            bus.clear_handlers()

        assert sorted(calls) == ["h1", "h2"]


# ---------------------------------------------------------------------------
# Test 2: Persistence to DB
# ---------------------------------------------------------------------------

class TestPersistence:
    def test_emit_writes_row_to_db(self, tmp_path):
        """emit() must write a row to event_bus_log with correct event_type + actor."""
        db_path = str(tmp_path / "test.db")

        with patch("aibrain.core.event_bus._get_db_path", return_value=Path(db_path)):
            import aibrain.core.event_bus as bus
            bus.clear_handlers()
            bus.emit("test.persist", {"x": 1}, actor="test_runner")

        # Verify directly via sqlite — substance check, not path check
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            "SELECT * FROM event_bus_log WHERE event_type='test.persist'"
        ).fetchall()
        conn.close()

        assert len(rows) == 1
        assert rows[0]["event_type"] == "test.persist"
        assert rows[0]["actor"] == "test_runner"
        payload = json.loads(rows[0]["payload"])
        assert payload["x"] == 1

    def test_emit_returns_row_id(self, tmp_path):
        """emit() must return the integer row ID of the persisted event."""
        db_path = str(tmp_path / "test.db")

        with patch("aibrain.core.event_bus._get_db_path", return_value=Path(db_path)):
            import aibrain.core.event_bus as bus
            bus.clear_handlers()
            row_id = bus.emit("test.rowid", {"y": 2})

        assert isinstance(row_id, int)
        assert row_id >= 1


# ---------------------------------------------------------------------------
# Test 3: CLI returns events
# ---------------------------------------------------------------------------

class TestCliEvents:
    def test_cli_events_shows_emitted_event(self, tmp_path, capsys):
        """cli_events() must print the emitted event to stdout."""
        db_path = str(tmp_path / "test.db")

        with patch("aibrain.core.event_bus._get_db_path", return_value=Path(db_path)):
            import aibrain.core.event_bus as bus
            bus.clear_handlers()
            bus.emit("test.cli_check", {"label": "cli_test"}, actor="neuro")

            ret = bus.cli_events(["--last", "10"])

        assert ret == 0
        captured = capsys.readouterr()
        assert "test.cli_check" in captured.out
        assert "neuro" in captured.out


# ---------------------------------------------------------------------------
# Test 4: Filter by type
# ---------------------------------------------------------------------------

class TestFilterByType:
    def test_recent_filters_by_event_type(self, tmp_path):
        """recent(event_type=...) must return only events of that type."""
        db_path = str(tmp_path / "test.db")

        with patch("aibrain.core.event_bus._get_db_path", return_value=Path(db_path)):
            import aibrain.core.event_bus as bus
            bus.clear_handlers()
            bus.emit("test.type_a", {"n": 1})
            bus.emit("test.type_b", {"n": 2})
            bus.emit("test.type_a", {"n": 3})

            results = bus.recent(last=10, event_type="test.type_a")

        assert all(r["event_type"] == "test.type_a" for r in results)
        assert len(results) == 2


# ---------------------------------------------------------------------------
# Test 5: Filter by actor
# ---------------------------------------------------------------------------

class TestFilterByActor:
    def test_recent_filters_by_actor(self, tmp_path):
        """recent(actor=...) must return only events from that actor."""
        db_path = str(tmp_path / "test.db")

        with patch("aibrain.core.event_bus._get_db_path", return_value=Path(db_path)):
            import aibrain.core.event_bus as bus
            bus.clear_handlers()
            bus.emit("test.actor_filter", {"n": 1}, actor="neuro")
            bus.emit("test.actor_filter", {"n": 2}, actor="case")
            bus.emit("test.actor_filter", {"n": 3}, actor="neuro")

            neuro_results = bus.recent(last=10, actor="neuro")
            case_results = bus.recent(last=10, actor="case")

        assert all(r["actor"] == "neuro" for r in neuro_results)
        assert len(neuro_results) == 2
        assert len(case_results) == 1
        assert case_results[0]["actor"] == "case"


# ---------------------------------------------------------------------------
# Test 6: Harness emits task.start and task.complete/fail events
# ---------------------------------------------------------------------------

class TestHarnessEvents:
    def test_harness_emits_task_start_and_complete(self, tmp_path):
        """harness.execute() must emit harness.task.start + harness.task.complete."""
        db_path = str(tmp_path / "test.db")

        with patch("aibrain.core.event_bus._get_db_path", return_value=Path(db_path)):
            import aibrain.core.event_bus as bus
            bus.clear_handlers()

            emitted = []
            bus.on("harness.task.start", lambda p: emitted.append(("start", p)))
            bus.on("harness.task.complete", lambda p: emitted.append(("complete", p)))
            bus.on("harness.task.fail", lambda p: emitted.append(("fail", p)))

            from aibrain.core.harness import execute, HarnessConfig
            execute(
                task="test_event_wiring",
                action=lambda: {"result": "ok", "_self_score": 0.9},
                config=HarnessConfig(
                    task_type="deterministic",
                    actor="test_runner",
                    audit=False,
                ),
            )
            bus.clear_handlers()

        event_types = [e[0] for e in emitted]
        assert "start" in event_types, "harness.task.start not emitted"
        # Either complete or fail must fire (deterministic always succeeds)
        assert "complete" in event_types or "fail" in event_types, \
            "Neither harness.task.complete nor harness.task.fail emitted"

        # The start payload must include the task name
        start_payloads = [e[1] for e in emitted if e[0] == "start"]
        assert any(p.get("task") == "test_event_wiring" for p in start_payloads)
