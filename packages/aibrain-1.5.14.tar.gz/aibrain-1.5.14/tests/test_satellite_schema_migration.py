"""
Tests for satellite_dbs schema migration — category/size_bytes/last_validate/registered_by columns.

Three tests:
1. Columns exist after migration (even on a pre-migration DB)
2. satellite_register stores category correctly
3. validate_satellite_dbs marks a missing file as 'missing'
"""

import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

# aibrain_licensing raises ValueError at import time without this key.
os.environ.setdefault("AIBRAIN_SIGNING_KEY", "test-signing-key-sat-schema-migration")


@pytest.fixture()
def isolated_db():
    """Create a fresh isolated AIBrain DB, yield it, then restore global state."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_satmig_")
    os.close(fd)

    import aibrain_db

    original_path = aibrain_db.DB_PATH
    original_conn = aibrain_db._conn
    original_sat_conns = dict(aibrain_db._satellite_conns)

    aibrain_db.DB_PATH = Path(path)
    aibrain_db._conn = None
    aibrain_db._satellite_conns.clear()

    conn = aibrain_db.get_db()
    yield conn

    try:
        conn.close()
    except Exception:
        pass
    aibrain_db._conn = original_conn
    aibrain_db.DB_PATH = original_path
    aibrain_db._satellite_conns.clear()
    aibrain_db._satellite_conns.update(original_sat_conns)

    for suffix in ("", "-wal", "-shm"):
        try:
            os.unlink(path + suffix)
        except OSError:
            pass


class TestColumnsExistAfterMigration:
    """The four new columns must be present after _migrate_schema runs."""

    def test_new_columns_present(self, isolated_db):
        import aibrain_db

        # Run migration explicitly (get_db already ran it, but re-run to be explicit)
        aibrain_db._migrate_schema(isolated_db)

        # Query PRAGMA to confirm all four columns exist
        cols = {
            row[1]
            for row in isolated_db.execute("PRAGMA table_info(satellite_dbs)").fetchall()
        }
        assert "category" in cols, "category column missing from satellite_dbs"
        assert "size_bytes" in cols, "size_bytes column missing from satellite_dbs"
        assert "last_validate" in cols, "last_validate column missing from satellite_dbs"
        assert "registered_by" in cols, "registered_by column missing from satellite_dbs"


class TestRegisterStoresCategory:
    """satellite_register must persist the category field."""

    def test_category_stored_correctly(self, isolated_db):
        import aibrain_db

        # Create a temporary DB file so _get_satellite_db doesn't error
        sat_dir = aibrain_db.AIBRAIN_ROOT / "test_sat_cat"
        sat_dir.mkdir(exist_ok=True)
        sat_path = sat_dir / "cat_test.db"
        sat_path.touch()

        try:
            # Patch check_limit to bypass tier enforcement — this test is about
            # schema correctness, not licensing limits.
            with patch("aibrain_licensing.check_limit", return_value=None):
                aibrain_db.satellite_register(
                    "cat_test_sat",
                    str(sat_path),
                    description="Test category satellite",
                    memory_types=["finding"],
                    search_keywords="test",
                    category="product",
                    registered_by="test_agent",
                )

            row = isolated_db.execute(
                "SELECT category, registered_by FROM satellite_dbs WHERE name='cat_test_sat'"
            ).fetchone()
            assert row is not None, "Row not found after register"
            assert row["category"] == "product", (
                f"Expected category='product', got {row['category']!r}"
            )
            assert row["registered_by"] == "test_agent", (
                f"Expected registered_by='test_agent', got {row['registered_by']!r}"
            )
        finally:
            try:
                sat_path.unlink()
                sat_dir.rmdir()
            except Exception:
                pass


class TestValidateSatelliteDbsMissingFile:
    """validate_satellite_dbs must report status='missing' when the file doesn't exist."""

    def test_missing_file_marked_missing(self, isolated_db):
        import aibrain_db

        # Insert a satellite row pointing at a path that does NOT exist
        nonexistent = str(aibrain_db.AIBRAIN_ROOT / "does_not_exist_12345.db")
        isolated_db.execute("""
            INSERT INTO satellite_dbs
                (name, db_path, description, memory_types, search_keywords, active)
            VALUES ('ghost_sat', ?, 'Ghost satellite', '["finding"]', '', 1)
        """, (nonexistent,))
        isolated_db.commit()

        results = aibrain_db.validate_satellite_dbs()

        ghost = next((r for r in results if r["name"] == "ghost_sat"), None)
        assert ghost is not None, "ghost_sat not found in validate_satellite_dbs() output"
        assert ghost["status"] == "missing", (
            f"Expected status='missing', got {ghost['status']!r}"
        )
