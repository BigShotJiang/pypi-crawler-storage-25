"""
Tests for aibrain/core/companies.py — Companies feature.

Covers: create_company, list_companies, get_company,
        hire_agent, list_agents,
        create_task, list_tasks, checkout_task, complete_task,
        request_approval, approve, reject, pending_approvals.

Uses a temporary SQLite DB for full isolation.
"""

import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))


# ---------------------------------------------------------------------------
# Schema — mirrors docs/COMPANIES_ARCHITECTURE.md
# ---------------------------------------------------------------------------

COMPANIES_SCHEMA = """
CREATE TABLE IF NOT EXISTS companies (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    mission TEXT,
    status TEXT DEFAULT 'active' CHECK(status IN ('active','paused','archived')),
    budget_monthly_cents INTEGER DEFAULT 0,
    spent_monthly_cents INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS company_agents (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL REFERENCES companies(id),
    name TEXT NOT NULL,
    role TEXT DEFAULT 'general' CHECK(role IN ('ceo','manager','general')),
    title TEXT,
    status TEXT DEFAULT 'idle' CHECK(status IN ('idle','active','running','paused','error','terminated')),
    reports_to TEXT REFERENCES company_agents(id),
    model TEXT DEFAULT 'auto',
    task_type TEXT DEFAULT 'judgment',
    authority TEXT DEFAULT 'standard',
    budget_monthly_cents INTEGER DEFAULT 0,
    spent_monthly_cents INTEGER DEFAULT 0,
    heartbeat_interval_seconds INTEGER DEFAULT 14400,
    last_heartbeat_at TIMESTAMP,
    instructions TEXT,
    capabilities TEXT,
    permissions TEXT,
    metadata TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS company_issues (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL REFERENCES companies(id),
    parent_id TEXT REFERENCES company_issues(id),
    title TEXT NOT NULL,
    description TEXT,
    status TEXT DEFAULT 'backlog' CHECK(status IN ('backlog','todo','in_progress','in_review','done','blocked','cancelled')),
    priority TEXT DEFAULT 'medium' CHECK(priority IN ('critical','high','medium','low')),
    assignee_agent_id TEXT REFERENCES company_agents(id),
    project TEXT,
    issue_number INTEGER,
    origin TEXT DEFAULT 'manual',
    request_depth INTEGER DEFAULT 0,
    quality_score REAL,
    cost_cents INTEGER DEFAULT 0,
    started_at TIMESTAMP,
    completed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS company_approvals (
    id TEXT PRIMARY KEY,
    company_id TEXT NOT NULL REFERENCES companies(id),
    type TEXT NOT NULL,
    requested_by_agent_id TEXT REFERENCES company_agents(id),
    status TEXT DEFAULT 'pending' CHECK(status IN ('pending','approved','rejected','revision_requested')),
    payload TEXT,
    decision_note TEXT,
    decided_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS config (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""


@pytest.fixture()
def companies_db(tmp_path):
    """Create a temp DB with the companies schema and patch _get_db."""
    db_path = tmp_path / "test_companies.db"
    conn = sqlite3.connect(str(db_path))
    conn.row_factory = sqlite3.Row
    conn.executescript(COMPANIES_SCHEMA)
    conn.close()

    def _patched_get_db():
        db = sqlite3.connect(str(db_path))
        db.row_factory = sqlite3.Row
        db.execute("PRAGMA journal_mode=WAL")
        return db

    with patch("aibrain.core.companies._get_db", _patched_get_db):
        yield db_path


# ===========================================================================
# Companies
# ===========================================================================


class TestCreateCompany:

    def test_basic_create(self, companies_db):
        from aibrain.core.companies import create_company
        result = create_company("Acme Corp", mission="Sell everything")
        assert "error" not in result
        assert result["name"] == "Acme Corp"
        assert result["mission"] == "Sell everything"
        assert result["status"] == "active"
        assert "id" in result

    def test_create_without_mission(self, companies_db):
        from aibrain.core.companies import create_company
        result = create_company("Bare Inc")
        assert "error" not in result
        assert result["name"] == "Bare Inc"
        assert result["mission"] == ""

    def test_create_generates_unique_ids(self, companies_db):
        from aibrain.core.companies import create_company
        c1 = create_company("First")
        c2 = create_company("Second")
        assert c1["id"] != c2["id"]


class TestListCompanies:

    def test_empty_list(self, companies_db):
        from aibrain.core.companies import list_companies
        result = list_companies()
        assert result == []

    def test_list_returns_all(self, companies_db):
        from aibrain.core.companies import create_company, list_companies
        create_company("A")
        create_company("B")
        result = list_companies()
        assert len(result) == 2

    def test_filter_by_status(self, companies_db):
        from aibrain.core.companies import create_company, list_companies
        create_company("Active Co")

        # Manually archive one
        db = sqlite3.connect(str(companies_db))
        db.execute("INSERT INTO companies (id, name, status) VALUES ('arc1', 'Archived Co', 'archived')")
        db.commit()
        db.close()

        active = list_companies(status="active")
        assert all(c["status"] == "active" for c in active)
        assert len(active) >= 1


class TestGetCompany:

    def test_get_existing(self, companies_db):
        from aibrain.core.companies import create_company, get_company
        c = create_company("TestCo", mission="Testing")
        result = get_company(c["id"])
        assert result is not None
        assert result["name"] == "TestCo"
        assert result["agent_count"] == 0
        assert result["active_tasks"] == 0
        assert result["completed_tasks"] == 0

    def test_get_nonexistent(self, companies_db):
        from aibrain.core.companies import get_company
        result = get_company("nonexistent_id")
        assert result is None

    def test_get_with_agents_and_tasks(self, companies_db):
        from aibrain.core.companies import (
            create_company, hire_agent, create_task, complete_task, get_company
        )
        c = create_company("Full Co")
        hire_agent(c["id"], "Agent A")
        hire_agent(c["id"], "Agent B")
        t = create_task(c["id"], "Task 1")
        complete_task(t["id"], quality_score=0.9)
        create_task(c["id"], "Task 2")  # still in backlog

        info = get_company(c["id"])
        assert info["agent_count"] == 2
        assert info["completed_tasks"] == 1


# ===========================================================================
# Agents
# ===========================================================================


class TestHireAgent:

    def test_hire_basic(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent
        c = create_company("AgentCo")
        agent = hire_agent(c["id"], "Alice", role="general")
        assert "error" not in agent
        assert agent["name"] == "Alice"
        assert agent["role"] == "general"
        assert agent["company_id"] == c["id"]
        assert agent["task_type"] == "simple"
        assert agent["authority"] == "standard"

    def test_hire_ceo_has_admin_authority(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent
        c = create_company("HQ")
        ceo = hire_agent(c["id"], "Boss", role="ceo")
        assert ceo["task_type"] == "complex"
        assert ceo["authority"] == "admin"

    def test_hire_manager_has_elevated_authority(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent
        c = create_company("MiddleMgmt")
        mgr = hire_agent(c["id"], "Manager", role="manager")
        assert mgr["task_type"] == "judgment"
        assert mgr["authority"] == "elevated"

    def test_hire_with_reports_to(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent
        c = create_company("Hierarchy")
        ceo = hire_agent(c["id"], "CEO", role="ceo")
        worker = hire_agent(c["id"], "Worker", role="general", reports_to=ceo["id"])
        assert worker["reports_to"] == ceo["id"]


class TestListAgents:

    def test_list_excludes_terminated(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent, list_agents
        c = create_company("FilterCo")
        hire_agent(c["id"], "Active")
        a2 = hire_agent(c["id"], "Fired")

        # Manually terminate one
        db = sqlite3.connect(str(companies_db))
        db.execute("UPDATE company_agents SET status='terminated' WHERE id=?", (a2["id"],))
        db.commit()
        db.close()

        agents = list_agents(c["id"])
        assert len(agents) == 1
        assert agents[0]["name"] == "Active"

    def test_list_with_status_filter(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent, list_agents
        c = create_company("StatusCo")
        hire_agent(c["id"], "Idle")

        # Default status is 'idle'
        agents = list_agents(c["id"], status="idle")
        assert len(agents) == 1

        agents = list_agents(c["id"], status="running")
        assert len(agents) == 0


# ===========================================================================
# Tasks
# ===========================================================================


class TestCreateTask:

    def test_basic_task(self, companies_db):
        from aibrain.core.companies import create_company, create_task
        c = create_company("TaskCo")
        t = create_task(c["id"], "Do the thing", description="Details here", priority="high")
        assert t["title"] == "Do the thing"
        assert t["description"] == "Details here"
        assert t["priority"] == "high"
        assert t["status"] == "backlog"
        assert t["issue_number"] == 1

    def test_auto_incrementing_issue_numbers(self, companies_db):
        from aibrain.core.companies import create_company, create_task
        c = create_company("NumberCo")
        t1 = create_task(c["id"], "First")
        t2 = create_task(c["id"], "Second")
        t3 = create_task(c["id"], "Third")
        assert t1["issue_number"] == 1
        assert t2["issue_number"] == 2
        assert t3["issue_number"] == 3

    def test_task_with_assignee(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent, create_task
        c = create_company("AssignCo")
        agent = hire_agent(c["id"], "Worker")
        t = create_task(c["id"], "Assigned task", assignee_agent_id=agent["id"])
        assert t["assignee_agent_id"] == agent["id"]


class TestListTasks:

    def test_list_all(self, companies_db):
        from aibrain.core.companies import create_company, create_task, list_tasks
        c = create_company("ListCo")
        create_task(c["id"], "A")
        create_task(c["id"], "B")
        tasks = list_tasks(c["id"])
        assert len(tasks) == 2

    def test_filter_by_status(self, companies_db):
        from aibrain.core.companies import create_company, create_task, complete_task, list_tasks
        c = create_company("FilterTaskCo")
        t = create_task(c["id"], "Done task")
        complete_task(t["id"])
        create_task(c["id"], "Backlog task")

        done = list_tasks(c["id"], status="done")
        assert len(done) == 1
        assert done[0]["title"] == "Done task"

    def test_filter_by_assignee(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent, create_task, list_tasks
        c = create_company("AssignFilterCo")
        a1 = hire_agent(c["id"], "Alice")
        a2 = hire_agent(c["id"], "Bob")
        create_task(c["id"], "Alice task", assignee_agent_id=a1["id"])
        create_task(c["id"], "Bob task", assignee_agent_id=a2["id"])

        alice_tasks = list_tasks(c["id"], assignee=a1["id"])
        assert len(alice_tasks) == 1
        assert alice_tasks[0]["title"] == "Alice task"


class TestCheckoutTask:

    def test_checkout_sets_in_progress(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent, create_task, checkout_task
        c = create_company("CheckoutCo")
        agent = hire_agent(c["id"], "Worker")
        t = create_task(c["id"], "Claimable")
        result = checkout_task(t["id"], agent["id"])
        assert result["status"] == "in_progress"
        assert result["assignee_agent_id"] == agent["id"]

    def test_checkout_nonexistent_task(self, companies_db):
        from aibrain.core.companies import checkout_task
        result = checkout_task("fake_id", "fake_agent")
        assert "error" in result

    def test_checkout_already_claimed_by_other(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent, create_task, checkout_task
        c = create_company("ConflictCo")
        a1 = hire_agent(c["id"], "Alice")
        a2 = hire_agent(c["id"], "Bob")
        t = create_task(c["id"], "Contested")
        checkout_task(t["id"], a1["id"])
        result = checkout_task(t["id"], a2["id"])
        assert "error" in result
        assert result["claimed_by"] == a1["id"]

    def test_checkout_same_agent_is_ok(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent, create_task, checkout_task
        c = create_company("SameAgentCo")
        agent = hire_agent(c["id"], "Solo")
        t = create_task(c["id"], "My task")
        checkout_task(t["id"], agent["id"])
        result = checkout_task(t["id"], agent["id"])
        # Should not error when same agent re-checks-out
        assert "error" not in result or result.get("assignee_agent_id") == agent["id"]


class TestCompleteTask:

    def test_complete_sets_done(self, companies_db):
        from aibrain.core.companies import create_company, create_task, complete_task
        c = create_company("DoneCo")
        t = create_task(c["id"], "Finish me")
        # Pass work_output so quality_score is not capped
        result = complete_task(t["id"], quality_score=0.85, cost_cents=50,
                               work_output="Task completed: output verified, tests pass.")
        assert result["status"] == "done"
        assert result["quality_score"] == 0.85
        assert result["cost_cents"] == 50

    def test_complete_without_quality(self, companies_db):
        from aibrain.core.companies import create_company, create_task, complete_task
        c = create_company("NoQualCo")
        t = create_task(c["id"], "Quick task")
        result = complete_task(t["id"])
        assert result["status"] == "done"
        assert result["quality_score"] is None

    def test_complete_task_with_notes(self, companies_db):
        """Notes kwarg is stored in the notes column on the task record."""
        import sqlite3
        from aibrain.core.companies import create_company, create_task, complete_task
        c = create_company("NotesCo")
        t = create_task(c["id"], "Old task — being superseded")
        supersession_note = "superseded by task abc123 (renamed to 'New Architecture')"
        result = complete_task(t["id"], notes=supersession_note)
        assert result["status"] == "done"

        # Verify the note was persisted to the DB directly
        db = sqlite3.connect(str(companies_db))
        db.row_factory = sqlite3.Row
        row = db.execute("SELECT notes FROM company_issues WHERE id=?", (t["id"],)).fetchone()
        db.close()
        assert row is not None
        assert row["notes"] == supersession_note

    def test_complete_task_without_notes(self, companies_db):
        """Omitting notes kwarg (backward compat) — notes column is NULL, nothing breaks."""
        import sqlite3
        from aibrain.core.companies import create_company, create_task, complete_task
        c = create_company("NoNotesCo")
        t = create_task(c["id"], "Normal task")
        # Pass work_output so quality_score is not capped
        result = complete_task(t["id"], quality_score=0.8,
                               work_output="Normal task done, verified output.")
        assert result["status"] == "done"
        assert result["quality_score"] == 0.8

        # notes column should be NULL when not supplied
        db = sqlite3.connect(str(companies_db))
        db.row_factory = sqlite3.Row
        row = db.execute("SELECT notes FROM company_issues WHERE id=?", (t["id"],)).fetchone()
        db.close()
        assert row is not None
        assert row["notes"] is None

    # ── New tests: work_output enforcement ──────────────────────────────────

    def test_complete_high_priority_without_work_output_raises(self, companies_db):
        """High-priority tasks must provide work_output — ValueError if missing."""
        from aibrain.core.companies import create_company, create_task, complete_task
        c = create_company("HighPriCo")
        t = create_task(c["id"], "Critical feature", priority="high")
        with pytest.raises(ValueError, match="work_output is required for high tasks"):
            complete_task(t["id"], quality_score=0.9)

    def test_complete_critical_priority_without_work_output_raises(self, companies_db):
        """Critical-priority tasks must provide work_output — ValueError if missing."""
        from aibrain.core.companies import create_company, create_task, complete_task
        c = create_company("CritCo")
        t = create_task(c["id"], "P0 fix", priority="critical")
        with pytest.raises(ValueError, match="work_output is required for critical tasks"):
            complete_task(t["id"], quality_score=0.9)

    def test_complete_medium_without_work_output_caps_quality(self, companies_db):
        """Medium tasks without work_output succeed but quality_score is capped at 0.5."""
        from aibrain.core.companies import create_company, create_task, complete_task
        c = create_company("MedCapCo")
        t = create_task(c["id"], "Medium task", priority="medium")
        result = complete_task(t["id"], quality_score=0.9)
        assert result["status"] == "done"
        assert result["quality_score"] == 0.5, (
            "quality_score should be capped at 0.5 when no work_output provided"
        )

    def test_complete_medium_without_work_output_low_score_unchanged(self, companies_db):
        """Quality scores at or below 0.5 are NOT modified — cap only affects inflated scores."""
        from aibrain.core.companies import create_company, create_task, complete_task
        c = create_company("MedLowCo")
        t = create_task(c["id"], "Medium task low", priority="medium")
        result = complete_task(t["id"], quality_score=0.4)
        assert result["status"] == "done"
        assert result["quality_score"] == 0.4

    def test_complete_medium_with_work_output_full_score_preserved(self, companies_db):
        """When work_output IS provided, quality_score above 0.5 is preserved as-is."""
        from aibrain.core.companies import create_company, create_task, complete_task
        c = create_company("MedFullCo")
        t = create_task(c["id"], "Medium task with output", priority="medium")
        result = complete_task(t["id"], quality_score=0.9,
                               work_output="Output: all checks passed, 12/12 tests green.")
        assert result["status"] == "done"
        assert result["quality_score"] == 0.9


# ===========================================================================
# Approvals
# ===========================================================================


class TestApprovals:

    def test_request_approval(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent, request_approval
        c = create_company("ApprovalCo")
        agent = hire_agent(c["id"], "Requester")
        result = request_approval(c["id"], "hire_agent", agent["id"], {"name": "New Hire"})
        assert result["status"] == "pending"
        assert result["type"] == "hire_agent"
        assert json.loads(result["payload"]) == {"name": "New Hire"}

    def test_approve(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent, request_approval, approve
        c = create_company("ApproveCo")
        agent = hire_agent(c["id"], "Requester")
        req = request_approval(c["id"], "budget_override", agent["id"], {"amount": 1000})
        result = approve(req["id"], note="Looks good")
        assert result["status"] == "approved"
        assert result["decision_note"] == "Looks good"
        assert result["decided_at"] is not None

    def test_reject(self, companies_db):
        from aibrain.core.companies import create_company, hire_agent, request_approval, reject
        c = create_company("RejectCo")
        agent = hire_agent(c["id"], "Requester")
        req = request_approval(c["id"], "execute_plan", agent["id"], {"plan": "bad idea"})
        result = reject(req["id"], note="Denied")
        assert result["status"] == "rejected"
        assert result["decision_note"] == "Denied"

    def test_pending_approvals(self, companies_db):
        from aibrain.core.companies import (
            create_company, hire_agent, request_approval, approve, pending_approvals
        )
        c = create_company("PendingCo")
        agent = hire_agent(c["id"], "Requester")
        r1 = request_approval(c["id"], "type_a", agent["id"], {})
        r2 = request_approval(c["id"], "type_b", agent["id"], {})
        approve(r1["id"])

        pending = pending_approvals(c["id"])
        assert len(pending) == 1
        assert pending[0]["id"] == r2["id"]

    def test_pending_empty(self, companies_db):
        from aibrain.core.companies import create_company, pending_approvals
        c = create_company("EmptyPendingCo")
        result = pending_approvals(c["id"])
        assert result == []
