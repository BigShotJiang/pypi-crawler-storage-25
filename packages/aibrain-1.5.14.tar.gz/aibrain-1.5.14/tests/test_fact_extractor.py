"""
Tests for aibrain.core.fact_extractor — pattern-based fact extraction.
"""

import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.fact_extractor import extract_facts, extract_facts_from_messages


class TestExtractFacts:
    """Test extract_facts() classification."""

    def test_update_detection(self):
        """UPDATE facts are detected from change/correction language."""
        facts = extract_facts("The server IP changed to 10.0.0.5 yesterday.")
        assert len(facts) >= 1
        actions = [f["action"] for f in facts]
        assert "UPDATE" in actions

    def test_delete_detection(self):
        """DELETE facts are detected from removal/deprecation language."""
        facts = extract_facts("We no longer use Redis for caching.")
        assert len(facts) >= 1
        actions = [f["action"] for f in facts]
        assert "DELETE" in actions

    def test_add_detection(self):
        """ADD facts are detected from definitional statements."""
        facts = extract_facts("The database is hosted on port 5432 in production.")
        assert len(facts) >= 1
        actions = [f["action"] for f in facts]
        assert "ADD" in actions

    def test_noop_filtered_out(self):
        """Questions, opinions, and filler are excluded from output."""
        facts = extract_facts("Can you help me with this?")
        assert len(facts) == 0

        facts2 = extract_facts("Thanks, that looks good.")
        assert len(facts2) == 0

    def test_empty_input(self):
        """Empty or whitespace-only input returns empty list."""
        assert extract_facts("") == []
        assert extract_facts("   ") == []
        assert extract_facts(None) == []

    def test_multi_sentence_extraction(self):
        """Multiple facts are extracted from multi-sentence text."""
        text = (
            "The API endpoint moved to /v2/data. "
            "We removed the old /v1/data route. "
            "The service uses port 8080."
        )
        facts = extract_facts(text)
        # Should find at least 2 facts
        assert len(facts) >= 2
        actions = set(f["action"] for f in facts)
        # Should have at least UPDATE and DELETE
        assert len(actions) >= 2

    def test_fact_dict_structure(self):
        """Each fact dict has the required keys."""
        facts = extract_facts("The config file was updated to use YAML format instead of JSON.")
        assert len(facts) >= 1
        fact = facts[0]
        assert "action" in fact
        assert "content" in fact
        assert "confidence" in fact
        assert "category" in fact
        assert fact["action"] in ("ADD", "UPDATE", "DELETE")
        assert 0.0 <= fact["confidence"] <= 1.0


class TestExtractFactsFromMessages:
    """Test extract_facts_from_messages() integration with transcript format."""

    def test_processes_transcript_messages(self):
        """Extracts facts from a list of transcript-format messages."""
        messages = [
            {"role": "assistant", "content": "The database was migrated to PostgreSQL 15 on the new server."},
            {"role": "user", "content": "We no longer need the MySQL backup scripts."},
        ]
        facts = extract_facts_from_messages(messages)
        assert len(facts) >= 1
        # All facts should have the required keys for memory storage
        for f in facts:
            assert "name" in f
            assert "type" in f
            assert "content" in f
            assert "importance" in f
            assert "tags" in f
            # UPDATE/DELETE facts map to "correction" type; ADD facts stay "fact"
            assert f["type"] in ("fact", "correction")

    def test_skips_tool_messages(self):
        """Non-human/assistant messages are skipped."""
        messages = [
            {"role": "tool", "content": "The server IP changed to 10.0.0.5."},
        ]
        facts = extract_facts_from_messages(messages)
        assert len(facts) == 0

    def test_dedup_identical_content(self):
        """Duplicate sentences across messages are deduplicated."""
        messages = [
            {"role": "user", "content": "The deployment server changed to production-2."},
            {"role": "assistant", "content": "The deployment server changed to production-2."},
        ]
        facts = extract_facts_from_messages(messages)
        # Should not have duplicates
        contents = [f["content"] for f in facts]
        assert len(contents) == len(set(contents))

    def test_tool_use_blocks_excluded(self):
        """tool_use content blocks must NOT be extracted as facts.

        tool_use blocks contain JSON-encoded function arguments. JSON keys like
        "port", "path", "url" match ADD patterns and generate false-positive
        facts (e.g. {"command": "git status", "path": "/repo"} would previously
        fire an ADD fact for "port/path/url is:"). They are not conversation
        prose and must be filtered before signal detection.
        """
        messages = [
            {
                "role": "assistant",
                "content": [
                    {
                        "type": "tool_use",
                        "name": "Bash",
                        "input": {"command": "git status", "path": "/c/Users/sinde/projects/aibrain"},
                    }
                ],
            }
        ]
        facts = extract_facts_from_messages(messages)
        assert facts == [], (
            f"tool_use block generated {len(facts)} facts — it should produce 0: {facts}"
        )

    def test_tool_result_blocks_excluded(self):
        """tool_result content blocks must NOT be extracted as facts.

        Tool outputs contain raw bash/file content that can trigger false-positive
        completion or ADD signals (e.g. "working now", "done", or a path string).
        These are structured data, not conversation prose.
        """
        messages = [
            {
                "role": "user",
                "content": [
                    {
                        "type": "tool_result",
                        "content": "On branch main\nnothing to commit, working tree clean",
                    }
                ],
            }
        ]
        facts = extract_facts_from_messages(messages)
        assert facts == [], (
            f"tool_result block generated {len(facts)} facts — it should produce 0: {facts}"
        )

    def test_low_confidence_add_filtered(self):
        """ADD facts with confidence < 0.6 should not be stored.

        extract_facts() assigns confidence=0.5 to ADD matches (broad pattern).
        These are too noisy to store as memories — only UPDATE (0.7) and
        DELETE (0.8) have enough signal specificity to be stored unconditionally.
        """
        # This sentence matches a broad ADD pattern but is generic enough that
        # storing it would be noise. The confidence gate should block it.
        messages = [
            {"role": "assistant", "content": "The task requires admin access and sudo privileges."},
        ]
        facts = extract_facts_from_messages(messages)
        # All returned facts must be UPDATE or DELETE (confidence >= 0.6)
        add_facts = [f for f in facts if f.get("action") == "ADD"]
        assert add_facts == [], (
            f"Low-confidence ADD fact was not filtered: {add_facts}"
        )

    def test_update_delete_map_to_correction_type(self):
        """UPDATE and DELETE facts should use type='correction', not 'fact'.

        The memory store routes 'correction' types with higher importance and
        correct attribution. Generic 'fact' type loses the semantic of the
        action (something changed or was removed).
        """
        messages = [
            {"role": "user", "content": "We no longer use Redis for session storage."},
            {"role": "assistant", "content": "The server IP changed to 10.0.0.5."},
        ]
        facts = extract_facts_from_messages(messages)
        # All DELETE and UPDATE facts should have type='correction'
        for f in facts:
            if f.get("action") in ("DELETE", "UPDATE"):
                assert f["type"] == "correction", (
                    f"action={f['action']} fact has type={f['type']!r}, expected 'correction'"
                )
