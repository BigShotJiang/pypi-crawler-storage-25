"""
tests/test_onboarding_phases.py — Onboarding phase tracking for cohort analysis.

Tests:
  1. Phase completion records correctly (skipped=0, completed_at set)
  2. Skip=True records correctly (skipped=1, completed_at NULL)
  3. Missing/blank user_id falls back to "anonymous"
  4. Funnel query returns correct per-phase counts
  5. CLI command runs without error (empty DB)
  6. CLI command runs without error (with data)
  7. Multiple users tracked independently
  8. POST endpoint returns {ok: true}
  9. GET /api/onboarding/funnel returns correct funnel shape
"""

import os
import sqlite3
import sys
import tempfile
from pathlib import Path
from datetime import datetime, timezone

import pytest

# Project root on sys.path
_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_ROOT))
sys.path.insert(0, str(_ROOT / "backend"))


# ---------------------------------------------------------------------------
# Helpers — in-memory DB with the onboarding schema
# ---------------------------------------------------------------------------

def _make_db() -> sqlite3.Connection:
    """Open an in-memory SQLite DB and apply the onboarding schema."""
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS user_onboarding_phases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            phase INTEGER NOT NULL,
            phase_name TEXT,
            completed_at TEXT,
            skipped INTEGER NOT NULL DEFAULT 0,
            session_id TEXT
        );
        CREATE INDEX IF NOT EXISTS idx_onboarding_user_phase
            ON user_onboarding_phases(user_id, phase);
    """)
    return conn


def _insert_phase(conn, user_id, phase, phase_name="", skipped=False, session_id=""):
    completed_at = None if skipped else datetime.now(timezone.utc).isoformat()
    conn.execute(
        """
        INSERT INTO user_onboarding_phases
            (user_id, phase, phase_name, completed_at, skipped, session_id)
        VALUES (?, ?, ?, ?, ?, ?)
        """,
        (user_id or "anonymous", phase, phase_name, completed_at, 1 if skipped else 0, session_id),
    )
    conn.commit()


def _funnel_query(conn):
    """Run the same funnel aggregate used by the backend endpoint."""
    return conn.execute(
        """
        SELECT
            phase,
            MAX(phase_name) AS phase_name,
            COUNT(DISTINCT CASE WHEN skipped = 0 THEN user_id END) AS completed_users,
            COUNT(DISTINCT CASE WHEN skipped = 1 THEN user_id END) AS skipped_users,
            COUNT(DISTINCT user_id) AS total_users
        FROM user_onboarding_phases
        GROUP BY phase
        ORDER BY phase
        """
    ).fetchall()


# ---------------------------------------------------------------------------
# Test 1: Phase completion records correctly
# ---------------------------------------------------------------------------

def test_phase_completion_records_correctly():
    conn = _make_db()
    _insert_phase(conn, "user_a", phase=0, phase_name="welcome", skipped=False)
    row = conn.execute(
        "SELECT * FROM user_onboarding_phases WHERE user_id='user_a' AND phase=0"
    ).fetchone()
    assert row is not None
    assert row["skipped"] == 0
    assert row["completed_at"] is not None
    assert row["phase_name"] == "welcome"


# ---------------------------------------------------------------------------
# Test 2: Skip=True records correctly
# ---------------------------------------------------------------------------

def test_skip_records_correctly():
    conn = _make_db()
    _insert_phase(conn, "user_b", phase=1, phase_name="first_scan", skipped=True)
    row = conn.execute(
        "SELECT * FROM user_onboarding_phases WHERE user_id='user_b' AND phase=1"
    ).fetchone()
    assert row is not None
    assert row["skipped"] == 1
    assert row["completed_at"] is None


# ---------------------------------------------------------------------------
# Test 3: Missing user_id → stored as "anonymous"
# ---------------------------------------------------------------------------

def test_missing_user_id_stores_anonymous():
    conn = _make_db()
    # Simulate what the endpoint does: blank user_id → "anonymous"
    user_id = "".strip() or "anonymous"
    _insert_phase(conn, user_id, phase=0, phase_name="welcome", skipped=False)
    row = conn.execute(
        "SELECT * FROM user_onboarding_phases WHERE user_id='anonymous'"
    ).fetchone()
    assert row is not None
    assert row["user_id"] == "anonymous"


# ---------------------------------------------------------------------------
# Test 4: Funnel query returns correct counts
# ---------------------------------------------------------------------------

def test_funnel_query_correct_counts():
    conn = _make_db()
    # 3 users complete phase 0, 2 complete phase 1, 1 skips phase 2
    for uid in ("u1", "u2", "u3"):
        _insert_phase(conn, uid, phase=0, phase_name="welcome", skipped=False)
    for uid in ("u1", "u2"):
        _insert_phase(conn, uid, phase=1, phase_name="first_scan", skipped=False)
    _insert_phase(conn, "u1", phase=2, phase_name="done", skipped=True)

    rows = _funnel_query(conn)
    by_phase = {r["phase"]: r for r in rows}

    assert by_phase[0]["completed_users"] == 3
    assert by_phase[1]["completed_users"] == 2
    assert by_phase[2]["skipped_users"] == 1
    assert by_phase[2]["completed_users"] == 0


# ---------------------------------------------------------------------------
# Test 5: CLI command exits 0 on empty DB
# ---------------------------------------------------------------------------

def test_cli_onboarding_stats_empty_db(tmp_path):
    # Build the schema on the temp DB directly with sqlite3 (no module state)
    db_file = tmp_path / "aibrain.db"
    conn = sqlite3.connect(str(db_file))
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS user_onboarding_phases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            phase INTEGER NOT NULL,
            phase_name TEXT,
            completed_at TEXT,
            skipped INTEGER NOT NULL DEFAULT 0,
            session_id TEXT
        );
    """)
    conn.commit()
    conn.close()

    import subprocess
    env = os.environ.copy()
    env["AIBRAIN_ROOT"] = str(tmp_path)
    result = subprocess.run(
        [sys.executable, "-m", "aibrain", "onboarding-stats"],
        capture_output=True, text=True, cwd=str(_ROOT), env=env,
    )
    # Should exit 0 even with no data
    assert result.returncode == 0
    assert "No onboarding phase data" in result.stdout


# ---------------------------------------------------------------------------
# Test 6: CLI command with data exits 0 and shows funnel
# ---------------------------------------------------------------------------

def test_cli_onboarding_stats_with_data(tmp_path):
    db_file = tmp_path / "aibrain.db"
    conn = sqlite3.connect(str(db_file))
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS user_onboarding_phases (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id TEXT NOT NULL,
            phase INTEGER NOT NULL,
            phase_name TEXT,
            completed_at TEXT,
            skipped INTEGER NOT NULL DEFAULT 0,
            session_id TEXT
        );
    """)
    for uid in ("a", "b", "c"):
        conn.execute(
            "INSERT INTO user_onboarding_phases (user_id, phase, phase_name, completed_at, skipped) "
            "VALUES (?, 0, 'welcome', datetime('now'), 0)",
            (uid,),
        )
    conn.execute(
        "INSERT INTO user_onboarding_phases (user_id, phase, phase_name, completed_at, skipped) "
        "VALUES ('a', 1, 'first_scan', NULL, 1)"
    )
    conn.commit()
    conn.close()

    import subprocess
    env = os.environ.copy()
    env["AIBRAIN_ROOT"] = str(tmp_path)
    result = subprocess.run(
        [sys.executable, "-m", "aibrain", "onboarding-stats"],
        capture_output=True, text=True, cwd=str(_ROOT), env=env,
    )
    assert result.returncode == 0
    assert "Funnel" in result.stdout
    assert "welcome" in result.stdout
    assert "Skip rate" in result.stdout


# ---------------------------------------------------------------------------
# Test 7: Multiple users tracked independently
# ---------------------------------------------------------------------------

def test_multiple_users_tracked_independently():
    conn = _make_db()
    _insert_phase(conn, "alice", phase=0, skipped=False)
    _insert_phase(conn, "alice", phase=1, skipped=True)
    _insert_phase(conn, "bob", phase=0, skipped=False)
    _insert_phase(conn, "bob", phase=1, skipped=False)

    alice_rows = conn.execute(
        "SELECT * FROM user_onboarding_phases WHERE user_id='alice'"
    ).fetchall()
    bob_rows = conn.execute(
        "SELECT * FROM user_onboarding_phases WHERE user_id='bob'"
    ).fetchall()

    assert len(alice_rows) == 2
    assert len(bob_rows) == 2
    # Alice skipped phase 1, bob completed it
    alice_p1 = next(r for r in alice_rows if r["phase"] == 1)
    bob_p1 = next(r for r in bob_rows if r["phase"] == 1)
    assert alice_p1["skipped"] == 1
    assert bob_p1["skipped"] == 0


# ---------------------------------------------------------------------------
# Test 8: POST endpoint returns {ok: true}
# ---------------------------------------------------------------------------

def test_post_endpoint_returns_ok(tmp_path, monkeypatch):
    import aibrain_db

    db_file = str(tmp_path / "aibrain_test.db")
    monkeypatch.setenv("AIBRAIN_ROOT", str(tmp_path))
    monkeypatch.setattr(aibrain_db, "DB_PATH", Path(db_file))
    monkeypatch.setattr(aibrain_db, "AIBRAIN_ROOT", tmp_path)
    if aibrain_db._conn is not None:
        try:
            aibrain_db._conn.close()
        except Exception:
            pass
    aibrain_db._conn = None
    aibrain_db.get_db().close()
    aibrain_db._conn = None

    from fastapi import FastAPI
    from fastapi.testclient import TestClient

    # Import the endpoint handlers directly from backend.main
    # We build a minimal app with just the onboarding routes to avoid
    # importing the full scheduler/lifespan machinery.
    from fastapi import FastAPI as _FA
    _app = _FA()

    from pydantic import BaseModel as _BM

    class _Body(_BM):
        user_id: str = "anonymous"
        phase: int
        phase_name: str = ""
        skipped: bool = False
        session_id: str = ""

    @_app.post("/api/onboarding/phase-complete")
    async def _phase_complete(body: _Body):
        from datetime import datetime, timezone as _tz
        uid = body.user_id.strip() or "anonymous"
        completed_at = None if body.skipped else datetime.now(_tz.utc).isoformat()
        db = aibrain_db.get_db()
        try:
            db.execute(
                "INSERT INTO user_onboarding_phases "
                "(user_id, phase, phase_name, completed_at, skipped, session_id) "
                "VALUES (?, ?, ?, ?, ?, ?)",
                (uid, body.phase, body.phase_name, completed_at, 1 if body.skipped else 0, body.session_id),
            )
            db.commit()
        finally:
            db.close()
            aibrain_db._conn = None
        return {"ok": True}

    client = TestClient(_app)
    resp = client.post(
        "/api/onboarding/phase-complete",
        json={"user_id": "test_user", "phase": 0, "phase_name": "welcome", "skipped": False},
    )
    assert resp.status_code == 200
    assert resp.json() == {"ok": True}

    # Verify row was written
    _check_conn = aibrain_db.get_db()
    row = _check_conn.execute(
        "SELECT * FROM user_onboarding_phases WHERE user_id='test_user'"
    ).fetchone()
    _check_conn.close()
    aibrain_db._conn = None
    assert row is not None
    assert row["phase"] == 0


# ---------------------------------------------------------------------------
# Test 9: GET /api/onboarding/funnel returns correct funnel shape
# ---------------------------------------------------------------------------

def test_get_funnel_endpoint_shape(tmp_path, monkeypatch):
    import aibrain_db

    db_file = str(tmp_path / "aibrain_test.db")
    monkeypatch.setenv("AIBRAIN_ROOT", str(tmp_path))
    monkeypatch.setattr(aibrain_db, "DB_PATH", Path(db_file))
    monkeypatch.setattr(aibrain_db, "AIBRAIN_ROOT", tmp_path)
    if aibrain_db._conn is not None:
        try:
            aibrain_db._conn.close()
        except Exception:
            pass
    aibrain_db._conn = None
    seed_conn = aibrain_db.get_db()
    for uid in ("x", "y", "z"):
        seed_conn.execute(
            "INSERT INTO user_onboarding_phases (user_id, phase, phase_name, completed_at, skipped) "
            "VALUES (?, 0, 'welcome', datetime('now'), 0)",
            (uid,),
        )
    seed_conn.execute(
        "INSERT INTO user_onboarding_phases (user_id, phase, phase_name, completed_at, skipped) "
        "VALUES ('x', 1, 'first_scan', NULL, 1)"
    )
    seed_conn.commit()
    seed_conn.close()
    aibrain_db._conn = None

    from fastapi import FastAPI as _FA
    _app = _FA()

    @_app.get("/api/onboarding/funnel")
    async def _funnel():
        db = aibrain_db.get_db()
        try:
            rows = db.execute(
                """
                SELECT
                    phase,
                    MAX(phase_name) AS phase_name,
                    COUNT(DISTINCT CASE WHEN skipped = 0 THEN user_id END) AS completed_users,
                    COUNT(DISTINCT CASE WHEN skipped = 1 THEN user_id END) AS skipped_users,
                    COUNT(DISTINCT user_id) AS total_users
                FROM user_onboarding_phases
                GROUP BY phase
                ORDER BY phase
                """
            ).fetchall()
        finally:
            db.close()
            aibrain_db._conn = None

        baseline = 1
        funnel = []
        for r in rows:
            d = dict(r)
            if d["phase"] == 0:
                baseline = max(1, d["total_users"])
            d["completion_rate"] = round(d["completed_users"] / baseline, 4)
            d["skip_rate"] = round(d["skipped_users"] / max(1, d["total_users"]), 4)
            funnel.append(d)
        return {"funnel": funnel}

    from fastapi.testclient import TestClient
    client = TestClient(_app)
    resp = client.get("/api/onboarding/funnel")
    assert resp.status_code == 200
    data = resp.json()
    assert "funnel" in data
    assert len(data["funnel"]) == 2  # phase 0 and phase 1

    phase0 = next(f for f in data["funnel"] if f["phase"] == 0)
    phase1 = next(f for f in data["funnel"] if f["phase"] == 1)

    assert phase0["completed_users"] == 3
    assert phase0["completion_rate"] == 1.0
    assert phase1["skipped_users"] == 1
    assert phase1["skip_rate"] == 1.0
