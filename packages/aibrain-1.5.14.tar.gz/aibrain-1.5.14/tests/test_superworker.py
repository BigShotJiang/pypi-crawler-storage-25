"""test_superworker.py — unit tests for aibrain/core/superworker.py.

These tests MOCK the Anthropic client — no real API calls are made. They
exercise: dataclass shape, JSON sidecar + markdown fallback parsers, honest-None
propagation, cost computation, lens_router integration, persona path, and the
to_harness_dict() adapter the harness reads at harness.py:318.
"""
from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock, patch

import pytest

from aibrain.core import lens_router, superworker
from aibrain.core.superworker import (
    SUPERWORKER_PERSONA_PATH,
    SuperWorkerResult,
    _coerce_float,
    _compute_cost,
    _parse_output,
    _validate,
    invoke,
)


# --- dataclass shape -------------------------------------------------------

def test_result_dataclass_has_all_spec_fields():
    r = SuperWorkerResult(
        task="t", task_type="tt", lenses_consulted=["L1"], routing_reason="r",
        per_lens=[{"name": "L1"}], synthesis="s",
        compatible_views=["v"], conflicts=["c"], overrode=["o"],
        synthesis_confidence=0.8, eval_score=0.7, raw_markdown="md",
        parse_status="ok", warnings=[], cost_cents=5, model_used="m",
        duration_ms=100, success=True, run_id="rid",
    )
    # Spec says raw_markdown is preserved alongside parsed fields
    assert r.raw_markdown == "md"
    assert r.per_lens == [{"name": "L1"}]
    assert r.eval_score == 0.7
    assert r.cost_cents == 5


def test_to_harness_dict_shape():
    """Harness reads _cost_cents + _model_used + _self_score from action dict
    (harness.py:318). The _self_score path is the divergence-reporting wire
    that lets the harness compare the LLM's self-assessment against its own
    independent eval. Honest-None: when eval_score is None on the result,
    _self_score is also None in the dict (never a fake default)."""
    r = SuperWorkerResult(
        task="t", task_type="tt", lenses_consulted=[], routing_reason="",
        per_lens=[], synthesis="", compatible_views=[], conflicts=[], overrode=[],
        synthesis_confidence=None, eval_score=0.7, raw_markdown="",
        parse_status="ok", warnings=[], cost_cents=42, model_used="claude-sonnet-4",
        duration_ms=0, success=True, run_id="x",
    )
    d = r.to_harness_dict()
    assert d["_cost_cents"] == 42
    assert d["_model_used"] == "claude-sonnet-4"
    assert d["_self_score"] == 0.7
    assert d["result"] is r


def test_to_harness_dict_propagates_none_self_score():
    """Honest-rubric: when eval_score is None AND synthesis_confidence is
    None on the SuperWorker result (parser failed, LLM output had no real
    signal), the harness dict must carry None — NEVER a fake 0.5 default."""
    r = SuperWorkerResult(
        task="t", task_type="tt", lenses_consulted=[], routing_reason="",
        per_lens=[], synthesis="", compatible_views=[], conflicts=[], overrode=[],
        synthesis_confidence=None, eval_score=None, raw_markdown="",
        parse_status="failed", warnings=[], cost_cents=None, model_used="m",
        duration_ms=0, success=False, run_id="x",
    )
    d = r.to_harness_dict()
    assert d["_self_score"] is None
    assert d["_cost_cents"] is None


def test_to_harness_dict_falls_back_to_synthesis_confidence():
    """Bidirectional null rule (Apr 11): when eval_score=None but
    synthesis_confidence is a real number, _self_score falls back to
    synthesis_confidence. The persona drift this protects against:
    legitimate measurement of synthesis_confidence but null eval_score —
    that's an asymmetry the divergence loop can't handle.

    Caught by the first SuperWorker dogfood — the persona returned
    synthesis_confidence=0.78 and eval_score=null, leaving _self_score=None
    and breaking divergence reporting on the very first scored test."""
    r = SuperWorkerResult(
        task="t", task_type="tt", lenses_consulted=[], routing_reason="",
        per_lens=[], synthesis="real synthesis", compatible_views=[],
        conflicts=[], overrode=[],
        synthesis_confidence=0.78, eval_score=None, raw_markdown="",
        parse_status="ok", warnings=[], cost_cents=0, model_used="m",
        duration_ms=0, success=True, run_id="x",
    )
    d = r.to_harness_dict()
    # eval_score on the result stays None (we don't mutate the result),
    # but the dict's _self_score falls back to synthesis_confidence
    assert d["_self_score"] == 0.78
    assert r.eval_score is None  # result object itself is unmodified


def test_to_harness_dict_eval_score_wins_when_both_present():
    """When both eval_score and synthesis_confidence are set, eval_score
    is the primary signal — it's the agent's explicit overall rating."""
    r = SuperWorkerResult(
        task="t", task_type="tt", lenses_consulted=[], routing_reason="",
        per_lens=[], synthesis="", compatible_views=[], conflicts=[], overrode=[],
        synthesis_confidence=0.78, eval_score=0.65, raw_markdown="",
        parse_status="ok", warnings=[], cost_cents=0, model_used="m",
        duration_ms=0, success=True, run_id="x",
    )
    d = r.to_harness_dict()
    # eval_score 0.65 takes priority over synthesis_confidence 0.78
    assert d["_self_score"] == 0.65


# --- JSON sidecar parser ---------------------------------------------------

def test_parse_json_sidecar_happy_path():
    text = (
        "# SuperWorker Output: foo\n\n## Per-lens findings\n\n### Linus\n...\n"
        "## Synthesis\n\n**Final recommendation:** ship it\n\n"
        '<!-- superworker_json: {"synthesis": "ship it", '
        '"compatible_views": ["a", "b"], "conflicts": [], "overrode": [], '
        '"synthesis_confidence": 0.85, "eval_score": 0.7, '
        '"per_lens": [{"name": "Linus", "finding": "ok", "confidence": 0.9}]} -->'
    )
    parsed, warnings = _parse_output(text)
    assert parsed["parse_status"] == "ok"
    assert parsed["synthesis"] == "ship it"
    assert parsed["compatible_views"] == ["a", "b"]
    assert parsed["synthesis_confidence"] == 0.85
    assert parsed["eval_score"] == 0.7
    assert len(parsed["per_lens"]) == 1
    assert warnings == []


def test_parse_json_sidecar_malformed_falls_back_to_markdown():
    text = (
        "## Synthesis\n\n**Final recommendation:** go for it\n"
        "**Synthesis confidence:** 0.6\n"
        "**Honest-rubric eval_score (self-assessed):** 0.5\n\n"
        "<!-- superworker_json: {this is not json} -->"
    )
    parsed, warnings = _parse_output(text)
    assert parsed["parse_status"] == "ok"
    assert parsed["synthesis"] == "go for it"
    assert parsed["synthesis_confidence"] == 0.6
    assert parsed["eval_score"] == 0.5
    assert any("JSON sidecar malformed" in w for w in warnings)


def test_parse_json_sidecar_null_eval_score_preserved_as_none():
    """Honest-rubric: null must become None, NOT a fake 0.5."""
    text = (
        '<!-- superworker_json: {"synthesis": "s", "compatible_views": [], '
        '"conflicts": [], "overrode": [], "synthesis_confidence": null, '
        '"eval_score": null, "per_lens": []} -->'
    )
    parsed, _ = _parse_output(text)
    assert parsed["eval_score"] is None
    assert parsed["synthesis_confidence"] is None


# --- markdown regex fallback -----------------------------------------------

def test_parse_markdown_fallback_no_sidecar():
    text = (
        "# SuperWorker Output\n\n## Per-lens findings\n\n### Linus\n...\n"
        "## Synthesis\n\n**Final recommendation:** merge\n"
        "**Synthesis confidence:** 0.9\n"
        "**Honest-rubric eval_score (self-assessed):** 0.8\n"
    )
    parsed, warnings = _parse_output(text)
    assert parsed["parse_status"] == "ok"
    assert parsed["synthesis"] == "merge"
    assert parsed["synthesis_confidence"] == 0.9
    assert parsed["eval_score"] == 0.8


def test_parse_markdown_null_eval_score_honest_none():
    text = (
        "## Synthesis\n\n**Final recommendation:** ok\n"
        "**Honest-rubric eval_score (self-assessed):** null\n"
    )
    parsed, _ = _parse_output(text)
    assert parsed["eval_score"] is None


def test_parse_missing_synthesis_section_fails_honestly():
    text = "# heading\n\nsome text but no synthesis header"
    parsed, warnings = _parse_output(text)
    assert parsed["parse_status"] == "failed"
    assert any("Synthesis" in w for w in warnings)


def test_parse_empty_output_fails_honestly():
    parsed, warnings = _parse_output("")
    assert parsed["parse_status"] == "failed"
    assert "empty LLM output" in warnings


def test_parse_partial_when_synthesis_header_but_no_final_rec():
    text = "## Synthesis\n\nsome prose but no **Final recommendation:** line"
    parsed, warnings = _parse_output(text)
    assert parsed["parse_status"] == "partial"
    assert parsed["synthesis"] == ""


# --- honest-None coercion --------------------------------------------------

def test_coerce_float_null_variants():
    assert _coerce_float(None) is None
    assert _coerce_float("null") is None
    assert _coerce_float("None") is None
    assert _coerce_float("") is None
    assert _coerce_float("not a number") is None
    assert _coerce_float(True) is None  # bool rejected (not a real measurement)


def test_coerce_float_real_values():
    assert _coerce_float(0.5) == 0.5
    assert _coerce_float("0.85") == 0.85
    assert _coerce_float(1) == 1.0


# --- cost computation ------------------------------------------------------

def test_compute_cost_from_valid_usage():
    usage = MagicMock(input_tokens=1000, output_tokens=2000)
    cost = _compute_cost(usage, "claude")
    # claude rates: 0.003/1k input, 0.015/1k output → 0.003 + 0.030 = 0.033 USD = 3.3 cents → 3
    assert cost == 3


def test_compute_cost_missing_usage_returns_none():
    assert _compute_cost(None, "claude") is None


def test_compute_cost_missing_attrs_returns_none():
    """resp.usage exists but no input_tokens attr (hypothetical SDK change) → None, not 0."""
    usage = types.SimpleNamespace()  # no attrs at all
    assert _compute_cost(usage, "claude") is None


def test_compute_cost_unknown_adapter_returns_none():
    usage = MagicMock(input_tokens=100, output_tokens=100)
    assert _compute_cost(usage, "nonexistent_provider_xyz") is None


# --- validation / invariants -----------------------------------------------

def _mk_result(**overrides) -> SuperWorkerResult:
    base = dict(
        task="t", task_type="tt", lenses_consulted=[], routing_reason="",
        per_lens=[], synthesis="", compatible_views=[], conflicts=[], overrode=[],
        synthesis_confidence=None, eval_score=None, raw_markdown="",
        parse_status="ok", warnings=[], cost_cents=None, model_used="m",
        duration_ms=0, success=True, run_id="x",
    )
    base.update(overrides)
    return SuperWorkerResult(**base)


def test_validate_clamps_out_of_range_eval_to_none():
    r = _mk_result(eval_score=1.5)
    _validate(r)
    assert r.eval_score is None
    assert any("out of [0,1]" in w for w in r.warnings)


def test_validate_clamps_negative_cost_to_none():
    r = _mk_result(cost_cents=-10)
    _validate(r)
    assert r.cost_cents is None


def test_validate_in_range_values_unchanged():
    r = _mk_result(eval_score=0.5, synthesis_confidence=0.8, cost_cents=42)
    _validate(r)
    assert r.eval_score == 0.5
    assert r.synthesis_confidence == 0.8
    assert r.cost_cents == 42


# --- persona file path -----------------------------------------------------

def test_persona_path_resolves_to_real_file():
    """The R1B design hardcodes this path as a load-bearing decision."""
    assert SUPERWORKER_PERSONA_PATH.exists(), f"persona missing: {SUPERWORKER_PERSONA_PATH}"
    content = SUPERWORKER_PERSONA_PATH.read_text(encoding="utf-8")
    assert "SuperWorker" in content


# --- invoke() integration with mocked Anthropic ----------------------------

def _fake_anthropic_module(text: str, in_tok: int = 100, out_tok: int = 200):
    """Build a stand-in anthropic module where Anthropic() returns a client
    whose messages.create() returns a response with the given text + usage."""
    mod = types.ModuleType("anthropic")
    resp = MagicMock()
    resp.content = [MagicMock(text=text)]
    resp.usage = MagicMock(input_tokens=in_tok, output_tokens=out_tok)
    client = MagicMock()
    client.messages.create.return_value = resp
    mod.Anthropic = MagicMock(return_value=client)
    return mod, client


def test_invoke_calls_lens_router_with_correct_args(monkeypatch):
    """lens_router.route() must be called with the task description + count."""
    fake_mod, fake_client = _fake_anthropic_module(
        '<!-- superworker_json: {"synthesis": "ok", "compatible_views": [], '
        '"conflicts": [], "overrode": [], "synthesis_confidence": 0.5, '
        '"eval_score": 0.5, "per_lens": []} -->'
    )
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)
    # Disable DB record so tests don't touch the real brain
    monkeypatch.setattr(superworker, "_record_run", lambda r: None)
    # Force SDK path — this test targets the Anthropic SDK branch specifically
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    route_spy = MagicMock(wraps=lens_router.route)
    monkeypatch.setattr(lens_router, "route", route_spy)

    result = invoke("Review the arch for drift", task_type="architecture_review", lens_count=6)

    route_spy.assert_called_once()
    _, kwargs = route_spy.call_args
    assert kwargs["task_type"] == "architecture_review"
    assert kwargs["task_description"] == "Review the arch for drift"
    assert kwargs["lens_count"] == 6
    assert result.success is True
    assert result.lenses_consulted  # non-empty after routing
    # Architecture_review routes through public-floor lenses (always_on +
    # task_type list). At least one of the expected public-floor picks
    # for architecture_review must appear. Names here live in
    # aibrain/core/lenses_public.py so the test stays public-mode safe.
    expected_public_lenses = {
        "Systems Architect", "Data-First Thinking", "Algorithmic Rigor",
        "Architecture & Performance Analyst", "CTO", "Long-Term Vision",
        "Desktop App Engineer", "Operator Lens", "Adversarial Security Lens",
    }
    assert expected_public_lenses.intersection(result.lenses_consulted), (
        f"None of the expected architecture_review lenses found in "
        f"{result.lenses_consulted}"
    )


def test_invoke_propagates_honest_none_on_parse_failure(monkeypatch):
    """Parser failure → success=False, eval_score=None (NEVER a fake 0.5)."""
    # LLM returns junk with no synthesis section and no sidecar
    fake_mod, _ = _fake_anthropic_module("just some text with no structure")
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)
    monkeypatch.setattr(superworker, "_record_run", lambda r: None)
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    result = invoke("trivial task", task_type="architecture_review", lens_count=5)

    assert result.success is False
    assert result.parse_status == "failed"
    assert result.eval_score is None
    assert result.synthesis_confidence is None
    assert result.raw_markdown == "just some text with no structure"  # preserved


def test_invoke_computes_cost_from_usage(monkeypatch):
    """cost_cents must come from resp.usage × adapter rates, not from the LLM body."""
    fake_mod, _ = _fake_anthropic_module(
        '<!-- superworker_json: {"synthesis": "s", "compatible_views": [], '
        '"conflicts": [], "overrode": [], "synthesis_confidence": 0.5, '
        '"eval_score": 0.5, "per_lens": []} -->',
        in_tok=1000, out_tok=2000,
    )
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)
    monkeypatch.setattr(superworker, "_record_run", lambda r: None)
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    result = invoke("t", task_type="architecture_review", lens_count=5)
    # 1000/1000 * 0.003 + 2000/1000 * 0.015 = 0.033 USD → 3 cents
    assert result.cost_cents == 3
    assert result.model_used == "claude-sonnet-4-20250514"


def test_invoke_llm_exception_becomes_failed_result(monkeypatch):
    """API exceptions must not propagate — they become success=False with a warning."""
    fake_mod = types.ModuleType("anthropic")
    client = MagicMock()
    client.messages.create.side_effect = RuntimeError("rate limit")
    fake_mod.Anthropic = MagicMock(return_value=client)
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)
    monkeypatch.setattr(superworker, "_record_run", lambda r: None)
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    result = invoke("t", task_type="architecture_review", lens_count=5)
    assert result.success is False
    assert result.cost_cents is None  # honest None, NOT 0
    assert any("rate limit" in w for w in result.warnings)
    assert result.raw_markdown == ""


# ---------------------------------------------------------------------------
# Tier gating + quota enforcement (Apr 13 2026, task ryN1wU9FIRY)
# ---------------------------------------------------------------------------

import json
import sqlite3
import tempfile
import time
from pathlib import Path

from aibrain.core.superworker import (
    SuperWorkerQuotaError,
    _FREE_TIER_MONTHLY_LIMIT,
    _get_monthly_usage,
    _increment_monthly_usage,
)


def _make_temp_usage_db(tmp_path) -> Path:
    """Create a temp SQLite DB with the superworker_usage table."""
    db_path = tmp_path / "aibrain_test.db"
    with sqlite3.connect(str(db_path)) as db:
        db.execute(
            "CREATE TABLE superworker_usage ("
            "user_id TEXT NOT NULL, month TEXT NOT NULL, "
            "count INTEGER NOT NULL DEFAULT 0, "
            "PRIMARY KEY (user_id, month))"
        )
        db.commit()
    return db_path


# --- voices field -----------------------------------------------------------

def test_voices_default_is_list():
    """voices field is always a list even when not supplied to the dataclass."""
    r = SuperWorkerResult(
        task="t", task_type="tt", lenses_consulted=[], routing_reason="",
        per_lens=[], synthesis="", compatible_views=[], conflicts=[], overrode=[],
        synthesis_confidence=None, eval_score=None, raw_markdown="",
        parse_status="ok", warnings=[], cost_cents=None, model_used="m",
        duration_ms=0, success=True, run_id="x",
    )
    assert isinstance(r.voices, list)


def test_voices_extracted_from_sidecar():
    """voices field is parsed from sidecar JSON with correct structure."""
    raw_voices = [
        {"lens": "Clausewitz", "argument": "Strategic clarity is decisive.", "weight": 0.9},
        {"lens": "Shannon", "argument": "Minimize entropy.", "weight": 0.7},
    ]
    sidecar_data = {
        "synthesis": "The answer is X.",
        "compatible_views": [],
        "conflicts": [],
        "overrode": [],
        "synthesis_confidence": 0.75,
        "eval_score": 0.8,
        "per_lens": [],
        "voices": raw_voices,
    }
    text = f"<!-- superworker_json: {json.dumps(sidecar_data)} -->"
    parsed, warnings = _parse_output(text)
    assert parsed["parse_status"] == "ok"
    voices = parsed.get("voices", [])
    assert isinstance(voices, list)
    assert len(voices) == 2
    assert voices[0]["lens"] == "Clausewitz"
    assert abs(voices[0]["weight"] - 0.9) < 1e-6
    assert "argument" in voices[0]


def test_voices_capped_at_five():
    """Sidecar with 8 voices is truncated to max 5."""
    raw_voices = [
        {"lens": f"Lens{i}", "argument": f"arg{i}", "weight": round(i * 0.1, 1)}
        for i in range(8)
    ]
    sidecar_data = {
        "synthesis": "x", "compatible_views": [], "conflicts": [], "overrode": [],
        "synthesis_confidence": None, "eval_score": None, "per_lens": [],
        "voices": raw_voices,
    }
    text = f"<!-- superworker_json: {json.dumps(sidecar_data)} -->"
    parsed, _ = _parse_output(text)
    assert len(parsed.get("voices", [])) <= 5


def test_voices_missing_lens_key_skipped():
    """Malformed voice entry (missing 'lens') is silently skipped."""
    raw_voices = [
        {"argument": "no lens key", "weight": 0.9},   # missing 'lens' — skip
        {"lens": "Clausewitz", "argument": "Valid.", "weight": 0.8},
    ]
    sidecar_data = {
        "synthesis": "x", "compatible_views": [], "conflicts": [], "overrode": [],
        "synthesis_confidence": None, "eval_score": None, "per_lens": [],
        "voices": raw_voices,
    }
    text = f"<!-- superworker_json: {json.dumps(sidecar_data)} -->"
    parsed, _ = _parse_output(text)
    voices = parsed.get("voices", [])
    assert len(voices) == 1
    assert voices[0]["lens"] == "Clausewitz"


def test_voices_empty_when_sidecar_absent():
    """When no sidecar present, voices key absent from parsed dict (falls back to [])."""
    text = "## Synthesis\n**Final recommendation:** Use X."
    parsed, _ = _parse_output(text)
    assert isinstance(parsed.get("voices", []), list)


# --- quota enforcement -------------------------------------------------------

def test_quota_enforced_on_sixth_call(tmp_path):
    """Free tier: 5 runs allowed; 6th call raises SuperWorkerQuotaError."""
    db_path = _make_temp_usage_db(tmp_path)
    month = time.strftime("%Y-%m")
    with sqlite3.connect(str(db_path)) as db:
        db.execute(
            "INSERT INTO superworker_usage VALUES (?, ?, ?)",
            ("free_user", month, _FREE_TIER_MONTHLY_LIMIT),
        )
        db.commit()

    # _get_or_create_db is imported inside _get_monthly_usage from aibrain.core.harness
    with patch("aibrain.core.harness._get_or_create_db", return_value=db_path):
        with pytest.raises(SuperWorkerQuotaError) as exc_info:
            invoke("sixth call", user_id="free_user", tier="free")

    assert "Free tier" in str(exc_info.value)
    assert "Upgrade" in str(exc_info.value)


def test_quota_allows_fifth_call(monkeypatch, tmp_path):
    """Free tier: 4 existing runs → 5th call succeeds (at the limit, not over)."""
    db_path = _make_temp_usage_db(tmp_path)
    month = time.strftime("%Y-%m")
    with sqlite3.connect(str(db_path)) as db:
        db.execute(
            "INSERT INTO superworker_usage VALUES (?, ?, ?)",
            ("free_user2", month, _FREE_TIER_MONTHLY_LIMIT - 1),
        )
        db.commit()

    monkeypatch.setattr(superworker, "_record_run", lambda r: None)
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    fake_mod = types.ModuleType("anthropic")
    resp = MagicMock()
    resp.content = [MagicMock(text='<!-- superworker_json: {"synthesis": "ok", "compatible_views": [], "conflicts": [], "overrode": [], "synthesis_confidence": null, "eval_score": null, "per_lens": [], "voices": []} -->')]
    resp.usage = MagicMock(input_tokens=10, output_tokens=20)
    client = MagicMock()
    client.messages.create.return_value = resp
    fake_mod.Anthropic = MagicMock(return_value=client)
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)

    with patch("aibrain.core.harness._get_or_create_db", return_value=db_path):
        result = invoke("5th call", user_id="free_user2", tier="free")
    assert result is not None  # did not raise


def test_pro_tier_no_quota(monkeypatch, tmp_path):
    """Pro tier: no quota enforced even with 100 existing runs."""
    db_path = _make_temp_usage_db(tmp_path)
    month = time.strftime("%Y-%m")
    with sqlite3.connect(str(db_path)) as db:
        db.execute(
            "INSERT INTO superworker_usage VALUES (?, ?, ?)",
            ("pro_user", month, 100),
        )
        db.commit()

    monkeypatch.setattr(superworker, "_record_run", lambda r: None)
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    fake_mod = types.ModuleType("anthropic")
    resp = MagicMock()
    resp.content = [MagicMock(text='<!-- superworker_json: {"synthesis": "ok", "compatible_views": [], "conflicts": [], "overrode": [], "synthesis_confidence": null, "eval_score": null, "per_lens": [], "voices": []} -->')]
    resp.usage = MagicMock(input_tokens=10, output_tokens=20)
    client = MagicMock()
    client.messages.create.return_value = resp
    fake_mod.Anthropic = MagicMock(return_value=client)
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)

    # Pro tier: no quota check runs at all — no need to patch DB
    result = invoke("pro task", user_id="pro_user", tier="pro")
    assert result is not None  # did not raise


def test_quota_not_enforced_when_tier_is_none(monkeypatch, tmp_path):
    """tier=None bypasses all quota logic (backwards compat)."""
    monkeypatch.setattr(superworker, "_record_run", lambda r: None)
    monkeypatch.setattr(superworker, "_claude_cli_available", lambda: False)

    fake_mod = types.ModuleType("anthropic")
    resp = MagicMock()
    resp.content = [MagicMock(text='<!-- superworker_json: {"synthesis": "ok", "compatible_views": [], "conflicts": [], "overrode": [], "synthesis_confidence": null, "eval_score": null, "per_lens": [], "voices": []} -->')]
    resp.usage = MagicMock(input_tokens=10, output_tokens=20)
    client = MagicMock()
    client.messages.create.return_value = resp
    fake_mod.Anthropic = MagicMock(return_value=client)
    monkeypatch.setitem(sys.modules, "anthropic", fake_mod)

    # tier=None — must not raise even if DB had 99 runs (quota code path never reached)
    result = invoke("no tier check", user_id="any_user", tier=None)
    assert result is not None


# --- usage helper unit tests ------------------------------------------------

def test_get_monthly_usage_returns_zero_on_no_row(tmp_path):
    db_path = _make_temp_usage_db(tmp_path)
    # _get_or_create_db is imported inside the helper from aibrain.core.harness
    with patch("aibrain.core.harness._get_or_create_db", return_value=db_path):
        count = _get_monthly_usage("nobody")
    assert count == 0


def test_increment_monthly_usage_creates_and_accumulates(tmp_path):
    db_path = _make_temp_usage_db(tmp_path)
    with patch("aibrain.core.harness._get_or_create_db", return_value=db_path):
        _increment_monthly_usage("newuser")
        _increment_monthly_usage("newuser")
        _increment_monthly_usage("newuser")
        count = _get_monthly_usage("newuser")
    assert count == 3
