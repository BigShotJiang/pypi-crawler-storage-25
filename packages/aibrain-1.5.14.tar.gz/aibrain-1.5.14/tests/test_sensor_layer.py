"""
Tests for the sensor-layer + soft quality-weighting anti-hallucination split.

The sensor layer (_sensor_classify) and the quality weighting gate
(apply_quality_weighting) sit in front of LLM reasoning and reduce LLM calls
for unambiguous cases.

Test coverage:
    1. test_sensor_blocks_obvious_api_key
       — high-specificity credential (sk- token) → BLOCK, no LLM needed
    2. test_sensor_allows_normal_memory
       — benign prose memory → ALLOW, no LLM needed
    3. test_sensor_uncertain_passes_to_llm
       — ambiguous text (no strong signal) → UNCERTAIN, LLM must decide
    4. test_quality_weighting_ranks_and_filters
       — soft weighting re-ranks by quality; only genuine noise (quality < 0.02)
         is excluded; low-but-above-noise memories are kept and ranked lower
"""

import sys
from pathlib import Path

import pytest

# Ensure project root is importable
sys.path.insert(0, str(Path(__file__).parent.parent))

from aibrain.core.enforcement import _sensor_classify, check_no_credentials
from aibrain_db import apply_quality_weighting, RETRIEVAL_QUALITY_FLOOR, QUALITY_MIDPOINT


# ---------------------------------------------------------------------------
# 1. Sensor blocks obvious API key
# ---------------------------------------------------------------------------

def test_sensor_blocks_obvious_api_key():
    """sk-XXXXX style token → BLOCK at high confidence, no LLM required."""
    text = "sk-12345abcdef67890abcdef12345abcdef"
    label, conf, desc = _sensor_classify(text)
    assert label == "BLOCK", f"Expected BLOCK, got {label}"
    assert conf >= 0.85, f"Expected confidence >= 0.85, got {conf}"

    # Verify check_no_credentials also short-circuits (no full scan needed):
    # It should return a violation and the violation should note sensor=True.
    violations = check_no_credentials({"content": text})
    assert violations, "Expected at least one violation for obvious API key"
    # The sensor-layer violation context carries sensor=True
    sensor_violations = [v for v in violations if v.context.get("sensor")]
    assert sensor_violations, (
        "Expected a sensor-layer violation (context.sensor=True), "
        f"got violations: {violations}"
    )


# ---------------------------------------------------------------------------
# 2. Sensor allows normal (benign) memory with placeholder markers
# ---------------------------------------------------------------------------

def test_sensor_allows_normal_memory():
    """Text with explicit placeholder markers → ALLOW at high confidence.

    The sensor fires ALLOW when it detects placeholder phrases like
    'your_', 'example', 'placeholder', etc. These are definitive signals
    that no real credential is present — the sensor short-circuits and
    the full regex scan (and any LLM review) is skipped entirely.
    """
    # Placeholder keyword "example" triggers ALLOW path
    text = (
        "To authenticate, set api_key=your_api_key_here. "
        "For example: api_key=example_token_replace_this. "
        "Never commit real credentials."
    )
    label, conf, desc = _sensor_classify(text)
    assert label == "ALLOW", (
        f"Expected ALLOW for placeholder-marked text, got {label} (conf={conf}). "
        "Placeholder phrases should trigger the fast-allow path."
    )
    assert conf >= 0.85, f"Expected confidence >= 0.85, got {conf}"

    # check_no_credentials must return zero violations (sensor short-circuits)
    violations = check_no_credentials({"content": text})
    assert not violations, (
        f"Expected no violations for placeholder text, got {violations}"
    )


# ---------------------------------------------------------------------------
# 3. Sensor passes ambiguous text to LLM (UNCERTAIN)
# ---------------------------------------------------------------------------

def test_sensor_uncertain_passes_to_llm():
    """Ambiguous text without a strong signal → UNCERTAIN so LLM can decide."""
    # This text mentions "token" and "key" in context that sounds like
    # documentation but has no high-specificity pattern and no placeholder.
    text = (
        "Authentication requires a bearer token. "
        "The token must be stored securely and rotated every 90 days. "
        "Never log the raw token value."
    )
    label, conf, desc = _sensor_classify(text)
    # We don't require UNCERTAIN specifically — the test verifies that the
    # sensor does NOT issue a high-confidence BLOCK or ALLOW, leaving the
    # decision to the LLM.
    # If it says ALLOW with high confidence that's fine (it IS benign).
    # But it must NOT say BLOCK with high confidence (no real credential here).
    if label == "BLOCK":
        assert conf < 0.85, (
            f"Sensor incorrectly blocked ambiguous text with conf={conf}. "
            "This would be a false positive."
        )
    # Either UNCERTAIN or a low-confidence result is acceptable.
    # ALLOW at high confidence is also acceptable for this benign text.
    # The key invariant: no high-confidence BLOCK on credential-adjacent prose.


# ---------------------------------------------------------------------------
# 4. Soft quality weighting re-ranks and only excludes genuine noise
# ---------------------------------------------------------------------------

def test_quality_weighting_ranks_and_filters():
    """Soft weighting: quality affects rank not existence.

    Only genuine noise (quality < 0.02) is excluded.
    Memories formerly below 0.09 that are above 0.02 must survive and be
    re-ranked lower than high-quality memories at the same base score.
    """
    # All memories given a uniform relevance score=0.5 so ranking is driven
    # purely by the quality_weight blend.
    memories = [
        # Genuine noise: importance=0.1, confidence=0.1 → quality=0.01 < 0.02 → EXCLUDED
        {"id": 4, "name": "genuine noise",    "importance": 0.1, "confidence": 0.1, "score": 0.5},
        # Low but above noise floor: importance=0.3, confidence=0.2 → quality=0.06 → KEPT, ranked low
        {"id": 5, "name": "low quality",      "importance": 0.3, "confidence": 0.2, "score": 0.5},
        # Old boundary (0.09): importance=0.3, confidence=0.3 → quality=0.09 → KEPT, midpoint weight
        {"id": 6, "name": "boundary quality", "importance": 0.3, "confidence": 0.3, "score": 0.5},
        # Average: importance=0.5, confidence=0.5 → quality=0.25 → KEPT, higher weight
        {"id": 2, "name": "average quality",  "importance": 0.5, "confidence": 0.5, "score": 0.5},
        # Unknown quality: missing fields default to 0.5*0.5=0.25 → KEPT
        {"id": 3, "name": "unknown quality",  "score": 0.5},
        # High quality: importance=0.8, confidence=0.9 → quality=0.72 → KEPT, ranked highest
        {"id": 1, "name": "high quality",     "importance": 0.8, "confidence": 0.9, "score": 0.5},
    ]

    result = apply_quality_weighting(memories)

    ids = [m["id"] for m in result]

    # Genuine noise must be excluded
    assert 4 not in ids, "Genuine noise (quality=0.01 < 0.02) must be excluded"

    # All above-noise memories must be present
    assert 5 in ids, "Low-but-above-noise (quality=0.06) must be kept (soft weighting, not binary cut)"
    assert 6 in ids, "Old boundary (quality=0.09) must be kept"
    assert 1 in ids, "High quality memory must be kept"
    assert 2 in ids, "Average quality memory must be kept"
    assert 3 in ids, "Unknown quality (default 0.25) must be kept"

    # High quality must rank above low quality (same base score, quality drives rank)
    assert ids.index(1) < ids.index(5), "High quality must outrank low quality"
    assert ids.index(2) < ids.index(5), "Average quality must outrank low quality"

    # quality_weight field injected for explainability
    high_q = next(m for m in result if m["id"] == 1)
    low_q  = next(m for m in result if m["id"] == 5)
    assert "quality_weight" in high_q, "quality_weight must be present on result dicts"
    assert high_q["quality_weight"] > low_q["quality_weight"], \
        "Higher quality memory must have higher quality_weight"

    # Noise floor constant must remain at 0.02 (hard floor), not 0.09
    assert RETRIEVAL_QUALITY_FLOOR == 0.02, \
        "RETRIEVAL_QUALITY_FLOOR must be the hard noise floor (0.02), not the old binary cliff (0.09)"
    assert QUALITY_MIDPOINT == 0.09, \
        "QUALITY_MIDPOINT must remain 0.09 (sigmoid midpoint, not a binary cut)"
