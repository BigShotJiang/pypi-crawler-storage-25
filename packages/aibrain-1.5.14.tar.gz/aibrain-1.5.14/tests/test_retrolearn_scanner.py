"""
Tests for aibrain/core/retrolearn_scanner.py

Covers:
- find_session_files: discovery under ~/.claude*/projects/ layout
- scan_file dry_run: extracts memories without writing DB
- dedup: second run on same file is skipped via is_already_scanned
- secrets_filter: injected credential is redacted, not stored raw
"""

from __future__ import annotations

import json
import sqlite3
import tempfile
from pathlib import Path

import pytest

# ---------------------------------------------------------------------------
# Ensure project root is importable in CI / bare pytest runs
# ---------------------------------------------------------------------------
import sys

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))


from aibrain.core.retrolearn_scanner import (
    find_session_files,
    scan_file,
    count_turns,
    is_already_scanned,
    retrolearn_all,
    _ensure_retrolearn_table,
    _mark_scanned,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------


def _write_session(path: Path, turns: list[dict]) -> Path:
    """Write a minimal JSONL session file."""
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        for turn in turns:
            f.write(json.dumps(turn) + "\n")
    return path


def _make_temp_db(tmp_path: Path) -> Path:
    """Create a minimal brain DB with the memories table so create_memory can be called."""
    db_path = tmp_path / "aibrain.db"
    conn = sqlite3.connect(str(db_path))
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT,
            type TEXT,
            memory_class TEXT DEFAULT 'semantic',
            tags TEXT DEFAULT '',
            content TEXT,
            importance REAL DEFAULT 0.5,
            storage_strength REAL DEFAULT 1.0,
            consolidated_from TEXT,
            created TEXT,
            updated TEXT,
            active INTEGER DEFAULT 1,
            status TEXT DEFAULT 'active',
            valid_from TEXT,
            source_agent TEXT DEFAULT 'unknown'
        );
    """)
    conn.commit()
    conn.close()
    return db_path


# ---------------------------------------------------------------------------
# test_find_session_files
# ---------------------------------------------------------------------------


def test_find_session_files_discovers_jsonl(tmp_path):
    """find_session_files should return .jsonl files under base_dir/projects/"""
    # Simulate ~/.claude/projects/<proj>/<session>.jsonl
    base = tmp_path / ".claude"
    proj = base / "projects" / "myproject"
    proj.mkdir(parents=True)
    f1 = proj / "session_abc.jsonl"
    f2 = proj / "session_def.jsonl"
    f1.write_text("{}\n", encoding="utf-8")
    f2.write_text("{}\n", encoding="utf-8")

    # Also create a non-jsonl file that should NOT appear
    (proj / "notes.txt").write_text("ignore me", encoding="utf-8")

    found = find_session_files(base_dirs=[base])
    found_names = {f.name for f in found}

    assert "session_abc.jsonl" in found_names
    assert "session_def.jsonl" in found_names
    assert "notes.txt" not in found_names
    assert len(found) == 2


def test_find_session_files_multiple_claude_dirs(tmp_path):
    """find_session_files should search all provided base dirs."""
    base1 = tmp_path / ".claude"
    base2 = tmp_path / ".claude-sindecker"
    for base in [base1, base2]:
        proj = base / "projects" / "proj"
        proj.mkdir(parents=True)
        (proj / "s.jsonl").write_text("{}\n", encoding="utf-8")

    found = find_session_files(base_dirs=[base1, base2])
    assert len(found) == 2


def test_find_session_files_empty_projects(tmp_path):
    """find_session_files returns [] when projects/ dir exists but has no .jsonl."""
    base = tmp_path / ".claude"
    (base / "projects" / "empty").mkdir(parents=True)
    found = find_session_files(base_dirs=[base])
    assert found == []


# ---------------------------------------------------------------------------
# test_count_turns
# ---------------------------------------------------------------------------


def test_count_turns_basic(tmp_path):
    """count_turns returns accurate (total_lines, user_turn_count)."""
    session = tmp_path / "s.jsonl"
    turns = [
        {"role": "user", "content": "Hello there, how are you doing today?"},
        {"role": "assistant", "content": "I am doing well, thank you for asking!"},
        {"role": "human", "content": "Great to hear. Can you help me fix this bug?"},
        {"role": "assistant", "content": "Of course! Let me take a look at the code."},
        {"invalid": "line"},  # no role
    ]
    _write_session(session, turns)

    total, user = count_turns(session)
    assert total == 5
    assert user == 2  # "user" + "human" roles


def test_count_turns_malformed_jsonl(tmp_path):
    """count_turns handles truncated/malformed lines without raising."""
    session = tmp_path / "s.jsonl"
    session.write_text(
        '{"role": "user", "content": "good line"}\n'
        '{"role": "assistant", "content": "response"}\n'
        'NOT VALID JSON {{{\n'
        '{"role": "user", "content": "another good one"}\n',
        encoding="utf-8",
    )
    total, user = count_turns(session)
    assert total == 4  # 4 lines total (incl malformed)
    assert user == 2   # 2 valid user turns


# ---------------------------------------------------------------------------
# test_scan_file_dry_run
# ---------------------------------------------------------------------------


def _praise_session(tmp_path: Path) -> Path:
    """Create a synthetic session with a praise signal."""
    session = tmp_path / "praise_session.jsonl"
    turns = [
        {
            "role": "user",
            "content": "Good job! That fix was exactly right and I really appreciate the clean solution you provided.",
        },
        {
            "role": "assistant",
            "content": "Thank you! I tried to keep it minimal.",
        },
        {
            "role": "user",
            "content": "This is a filler message without any signals in it at all.",
        },
    ]
    return _write_session(session, turns)


def test_scan_file_dry_run_extracts_praise(tmp_path):
    """scan_file in dry_run mode extracts praise signals but returns memories (no write)."""
    session = _praise_session(tmp_path)
    result = scan_file(session, signals=["praise"], dry_run=True)

    assert result["extracted"] >= 1, f"Expected at least 1 praise signal, got {result}"
    assert result["by_signal"]["praise"] >= 1
    # Verify memory shape
    for mem in result["memories"]:
        assert mem["type"] == "praise"
        assert mem["source_agent"] == "retrolearn_user_install"
        assert "retrolearn" in mem["tags"]
        assert "content" in mem
        assert len(mem["content"]) >= 10


def _correction_session(tmp_path: Path) -> Path:
    """Create a session with a correction signal."""
    session = tmp_path / "correction_session.jsonl"
    turns = [
        {
            "role": "user",
            "content": "Actually, I was wrong about the port number. Turns out it uses 8080, not 80.",
        },
    ]
    return _write_session(session, turns)


def test_scan_file_extracts_correction(tmp_path):
    """scan_file extracts correction signals correctly."""
    session = _correction_session(tmp_path)
    result = scan_file(session, signals=["correction"], dry_run=True)
    assert result["extracted"] >= 1
    assert result["by_signal"]["correction"] >= 1


def _self_reflection_session(tmp_path: Path) -> Path:
    """Create a session with a self-reflection signal from assistant."""
    session = tmp_path / "reflect_session.jsonl"
    turns = [
        {
            "role": "assistant",
            "content": "On second thought, I should have checked the type annotation first before suggesting the refactor.",
        },
    ]
    return _write_session(session, turns)


def test_scan_file_extracts_self_reflection(tmp_path):
    """scan_file extracts self_reflection from assistant turns only."""
    session = _self_reflection_session(tmp_path)
    result = scan_file(session, signals=["self_reflection"], dry_run=True)
    assert result["extracted"] >= 1
    assert result["by_signal"]["self_reflection"] >= 1


def test_scan_file_role_restriction(tmp_path):
    """self_reflection is NOT extracted from user turns."""
    session = tmp_path / "wrong_role.jsonl"
    # Same text as self_reflection but from user role — should NOT match
    turns = [
        {
            "role": "user",
            "content": "On second thought, I should have checked the type annotation first before suggesting the refactor.",
        },
    ]
    _write_session(session, turns)
    result = scan_file(session, signals=["self_reflection"], dry_run=True)
    # User turns are not in allowed roles for self_reflection
    assert result["by_signal"]["self_reflection"] == 0


def test_scan_file_malformed_jsonl_is_graceful(tmp_path):
    """scan_file does not raise on malformed JSONL lines."""
    session = tmp_path / "broken.jsonl"
    session.write_text(
        '{"role": "user", "content": "Good job! Well done, really excellent work on this."}\n'
        'NOTJSON {{{\n'
        '{"truncated": true\n',  # malformed
        encoding="utf-8",
    )
    # Should not raise; should still extract the valid first line
    result = scan_file(session, signals=["praise"], dry_run=True)
    assert isinstance(result, dict)
    assert result["extracted"] >= 0  # may or may not match depending on pattern


# ---------------------------------------------------------------------------
# test_dedup
# ---------------------------------------------------------------------------


def test_dedup_second_run_skips(tmp_path, monkeypatch):
    """retrolearn_all marks files as scanned; second call skips them."""
    db_path = _make_temp_db(tmp_path)

    session_dir = tmp_path / ".claude" / "projects" / "proj"
    session_dir.mkdir(parents=True)
    session = session_dir / "s.jsonl"
    turns = [
        {
            "role": "user",
            "content": "Good job! That was exactly right, well done.",
        },
    ]
    _write_session(session, turns)

    files = [session]

    # Monkeypatch _write_memories to avoid real aibrain_db dependency
    import aibrain.core.retrolearn_scanner as rs

    def _mock_write(memories, db_path_arg):
        pass  # no-op

    monkeypatch.setattr(rs, "_write_memories", _mock_write)

    # First run
    r1 = retrolearn_all(files, dry_run=False, db_path=db_path)
    assert r1["files_scanned"] == 1
    assert r1["files_skipped_dedup"] == 0

    # Second run — should be deduped
    r2 = retrolearn_all(files, dry_run=False, db_path=db_path)
    assert r2["files_scanned"] == 0
    assert r2["files_skipped_dedup"] == 1


def test_is_already_scanned_false_for_new_file(tmp_path):
    """is_already_scanned returns False for a file not yet recorded."""
    db_path = _make_temp_db(tmp_path)
    _ensure_retrolearn_table(db_path)

    fake_path = tmp_path / "never_scanned.jsonl"
    fake_path.write_text("{}\n", encoding="utf-8")

    assert is_already_scanned(fake_path, db_path) is False


def test_is_already_scanned_true_after_mark(tmp_path):
    """is_already_scanned returns True after _mark_scanned is called."""
    db_path = _make_temp_db(tmp_path)

    fake_path = tmp_path / "will_be_scanned.jsonl"
    fake_path.write_text("{}\n", encoding="utf-8")

    _mark_scanned(fake_path, db_path, memories_extracted=3, secrets_skipped=0)
    assert is_already_scanned(fake_path, db_path) is True


# ---------------------------------------------------------------------------
# test_secrets_filter_applied
# ---------------------------------------------------------------------------


def test_secrets_filter_applied_to_extracted_memory(tmp_path):
    """Secrets in session content are redacted before appearing in extracted memories."""
    from aibrain.core.secrets_filter import redact_secrets

    session = tmp_path / "with_secret.jsonl"
    # Inject a fake GitHub PAT in a praise context
    fake_pat = "ghp_" + "A" * 36  # matches the classic PAT pattern
    turns = [
        {
            "role": "user",
            "content": (
                f"Great work! The token you used was {fake_pat} and it worked perfectly. "
                f"Exactly what I needed."
            ),
        },
    ]
    _write_session(session, turns)

    result = scan_file(session, signals=["praise"], dry_run=True, secrets_filter=redact_secrets)

    # Any extracted snippet must NOT contain the raw PAT
    for mem in result["memories"]:
        assert fake_pat not in mem["content"], (
            f"Raw secret found in extracted memory: {mem['content']!r}"
        )
        # It should be replaced with the redaction label
        if "[REDACTED" not in mem["content"]:
            # The snippet might not include the secret at all if the window
            # was centered far from the secret — that's also acceptable
            pass


def test_secrets_filter_high_density_turn_skipped(tmp_path):
    """A turn with >2 secrets is skipped entirely (not partially extracted)."""
    from aibrain.core.secrets_filter import redact_secrets

    session = tmp_path / "dense_secrets.jsonl"
    # Pack in 3 secrets to trigger the skip-whole-turn path
    pat1 = "ghp_" + "B" * 36
    pat2 = "ghp_" + "C" * 36
    pat3 = "ghp_" + "D" * 36
    turns = [
        {
            "role": "user",
            "content": (
                f"Good job. We have three tokens here: {pat1}, {pat2}, {pat3}. "
                f"They all worked perfectly for the auth system."
            ),
        },
    ]
    _write_session(session, turns)

    result = scan_file(session, signals=["praise"], dry_run=True, secrets_filter=redact_secrets)

    # Turn should be skipped entirely due to high secret density
    assert result["skipped_secrets"] >= 1
    # No memory should contain any of the raw PATs
    for mem in result["memories"]:
        assert pat1 not in mem["content"]
        assert pat2 not in mem["content"]
        assert pat3 not in mem["content"]
