"""
tests/test_routing_config.py — Tests for aibrain.core.routing_config.

Five required tests:
  1. test_set_and_get_routing_mode    — set all 4 modes, verify stored
  2. test_budget_enforcement_downgrade — over-budget state, SuperWorker downgraded
  3. test_fast_flag_overrides_mode     — mode=always_superworker, --fast → single-worker
  4. test_deep_flag_overrides_budget   — over budget + --deep → SuperWorker fires (warning logged)
  5. test_midnight_budget_reset        — old reset_date → token_spent_today resets to 0
"""
from __future__ import annotations

import logging
import sqlite3
from datetime import datetime, timezone
from pathlib import Path

import pytest

from aibrain.core.routing_config import (
    VALID_MODES,
    RoutingConfig,
    cli_config_set_routing,
    cli_config_get_routing,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_test_db(tmp_path: Path) -> Path:
    """Create a minimal aibrain.db with config table."""
    db_path = tmp_path / "aibrain.db"
    db = sqlite3.connect(str(db_path))
    db.execute(
        """
        CREATE TABLE config (
            key     TEXT PRIMARY KEY,
            value   TEXT,
            updated TEXT
        )
        """
    )
    db.commit()
    db.close()
    return db_path


def _set_config(db_path: Path, key: str, value: str) -> None:
    """Directly write a config row (for test setup without going through RoutingConfig)."""
    db = sqlite3.connect(str(db_path))
    db.execute(
        "INSERT OR REPLACE INTO config (key, value) VALUES (?, ?)",
        (key, value),
    )
    db.commit()
    db.close()


def _get_config(db_path: Path, key: str) -> str | None:
    db = sqlite3.connect(str(db_path))
    row = db.execute("SELECT value FROM config WHERE key=?", (key,)).fetchone()
    db.close()
    return row[0] if row else None


# ---------------------------------------------------------------------------
# Test 1: Set and get routing mode for all 4 valid modes
# ---------------------------------------------------------------------------

class TestSetAndGetRoutingMode:
    def test_set_and_get_routing_mode(self, tmp_path):
        """Set all 4 modes via RoutingConfig, verify each is stored and retrieved."""
        db_path = _make_test_db(tmp_path)
        rc = RoutingConfig(db_path=db_path)

        for mode in VALID_MODES:
            rc.set_mode(mode)
            stored = _get_config(db_path, "routing.mode")
            assert stored == mode, f"Expected config table to store {mode!r}, got {stored!r}"
            retrieved = rc.get_mode()
            assert retrieved == mode, f"get_mode() returned {retrieved!r}, expected {mode!r}"

    def test_invalid_mode_raises(self, tmp_path):
        """Setting an invalid mode raises ValueError."""
        db_path = _make_test_db(tmp_path)
        rc = RoutingConfig(db_path=db_path)
        with pytest.raises(ValueError, match="Invalid routing mode"):
            rc.set_mode("turbo_mode")

    def test_cli_set_routing_mode(self, tmp_path):
        """cli_config_set_routing validates and stores routing.mode."""
        db_path = _make_test_db(tmp_path)
        result = cli_config_set_routing("routing.mode", "never_superworker", db_path=db_path)
        assert "never_superworker" in result
        assert _get_config(db_path, "routing.mode") == "never_superworker"

    def test_cli_set_invalid_mode_raises(self, tmp_path):
        """cli_config_set_routing raises ValueError for invalid mode."""
        db_path = _make_test_db(tmp_path)
        with pytest.raises(ValueError):
            cli_config_set_routing("routing.mode", "bogus_mode", db_path=db_path)

    def test_cli_get_routing_returns_table(self, tmp_path):
        """cli_config_get_routing returns a formatted string with routing keys."""
        db_path = _make_test_db(tmp_path)
        rc = RoutingConfig(db_path=db_path)
        rc.set_mode("always_superworker")
        rc.set_budget(500)

        output = cli_config_get_routing(db_path=db_path)
        assert "Routing Settings" in output
        assert "always_superworker" in output
        assert "500" in output


# ---------------------------------------------------------------------------
# Test 2: Budget enforcement — over-budget state downgrades SuperWorker
# ---------------------------------------------------------------------------

class TestBudgetEnforcementDowngrade:
    def test_budget_enforcement_downgrade(self, tmp_path):
        """
        When token_spent_today >= token_budget_per_day and no --deep flag,
        should_use_superworker() returns False regardless of mode.
        """
        db_path = _make_test_db(tmp_path)
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        # Set budget cap and simulate already-exceeded spend
        _set_config(db_path, "routing.token_budget_per_day", "200")
        _set_config(db_path, "routing.token_spent_today", "250")   # over cap
        _set_config(db_path, "routing.budget_reset_date", today)   # today so no reset
        _set_config(db_path, "routing.mode", "always_superworker")

        rc = RoutingConfig(db_path=db_path)

        # Budget check should report exceeded
        assert rc.is_budget_exceeded() is True

        # SuperWorker should be downgraded even in always_superworker mode
        result = rc.should_use_superworker("judgment", fast_mode=False, deep_mode=False)
        assert result is False, (
            "Expected SuperWorker to be downgraded when budget exceeded, "
            f"but should_use_superworker returned {result}"
        )

    def test_budget_not_exceeded_allows_superworker(self, tmp_path):
        """Spend below budget cap → SuperWorker allowed per mode setting."""
        db_path = _make_test_db(tmp_path)
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        _set_config(db_path, "routing.token_budget_per_day", "200")
        _set_config(db_path, "routing.token_spent_today", "100")  # under cap
        _set_config(db_path, "routing.budget_reset_date", today)
        _set_config(db_path, "routing.mode", "auto")

        rc = RoutingConfig(db_path=db_path)
        assert rc.is_budget_exceeded() is False
        assert rc.should_use_superworker("judgment") is True

    def test_no_budget_cap_never_blocks(self, tmp_path):
        """budget=null → SuperWorker never blocked by budget."""
        db_path = _make_test_db(tmp_path)
        _set_config(db_path, "routing.token_budget_per_day", "null")
        _set_config(db_path, "routing.token_spent_today", "999999")
        _set_config(db_path, "routing.mode", "always_superworker")

        rc = RoutingConfig(db_path=db_path)
        assert rc.is_budget_exceeded() is False
        assert rc.should_use_superworker("judgment") is True


# ---------------------------------------------------------------------------
# Test 3: --fast flag overrides mode=always_superworker
# ---------------------------------------------------------------------------

class TestFastFlagOverridesMode:
    def test_fast_flag_overrides_mode(self, tmp_path):
        """
        With mode=always_superworker, passing fast_mode=True to
        should_use_superworker() → False (single-worker).
        """
        db_path = _make_test_db(tmp_path)
        _set_config(db_path, "routing.mode", "always_superworker")
        _set_config(db_path, "routing.token_budget_per_day", "null")

        rc = RoutingConfig(db_path=db_path)

        # Without fast_mode: SuperWorker should fire
        assert rc.should_use_superworker("simple", fast_mode=False, deep_mode=False) is True

        # With fast_mode=True: should be blocked
        result = rc.should_use_superworker("judgment", fast_mode=True, deep_mode=False)
        assert result is False, (
            "Expected fast_mode=True to override always_superworker mode, "
            f"but should_use_superworker returned {result}"
        )

    def test_fast_flag_overrides_all_modes(self, tmp_path):
        """fast_mode=True forces single-worker for every mode and task type."""
        db_path = _make_test_db(tmp_path)
        _set_config(db_path, "routing.token_budget_per_day", "null")

        rc = RoutingConfig(db_path=db_path)

        for mode in VALID_MODES:
            rc.set_mode(mode)
            for task_type in ("deterministic", "simple", "judgment", "complex"):
                result = rc.should_use_superworker(
                    task_type, fast_mode=True, deep_mode=False
                )
                assert result is False, (
                    f"fast_mode=True should always yield False, "
                    f"got {result} for mode={mode!r} task_type={task_type!r}"
                )


# ---------------------------------------------------------------------------
# Test 4: --deep flag overrides budget (SuperWorker fires with warning)
# ---------------------------------------------------------------------------

class TestDeepFlagOverridesBudget:
    def test_deep_flag_overrides_budget(self, tmp_path, caplog):
        """
        Over budget + deep_mode=True → SuperWorker fires.
        A warning must be logged about the budget being exceeded.
        """
        db_path = _make_test_db(tmp_path)
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        # Simulate exceeded budget
        _set_config(db_path, "routing.token_budget_per_day", "200")
        _set_config(db_path, "routing.token_spent_today", "300")  # over cap
        _set_config(db_path, "routing.budget_reset_date", today)
        _set_config(db_path, "routing.mode", "auto")

        rc = RoutingConfig(db_path=db_path)
        assert rc.is_budget_exceeded() is True

        with caplog.at_level(logging.WARNING, logger="aibrain.routing_config"):
            result = rc.should_use_superworker(
                "judgment", fast_mode=False, deep_mode=True
            )

        assert result is True, (
            "Expected deep_mode=True to force SuperWorker even when budget exceeded, "
            f"but should_use_superworker returned {result}"
        )
        # A warning about the budget must have been logged
        warning_messages = [r.message for r in caplog.records if r.levelno >= logging.WARNING]
        assert any("budget" in msg.lower() for msg in warning_messages), (
            f"Expected a budget-related warning to be logged, got: {warning_messages}"
        )

    def test_deep_flag_beats_fast_flag(self, tmp_path):
        """deep_mode=True has higher priority than fast_mode=True → SuperWorker."""
        db_path = _make_test_db(tmp_path)
        _set_config(db_path, "routing.token_budget_per_day", "null")
        _set_config(db_path, "routing.mode", "auto")

        rc = RoutingConfig(db_path=db_path)
        result = rc.should_use_superworker(
            "judgment", fast_mode=True, deep_mode=True
        )
        assert result is True, (
            "deep_mode=True should beat fast_mode=True, "
            f"but should_use_superworker returned {result}"
        )


# ---------------------------------------------------------------------------
# Test 5: Midnight budget reset
# ---------------------------------------------------------------------------

class TestMidnightBudgetReset:
    def test_midnight_budget_reset(self, tmp_path):
        """
        When routing.budget_reset_date != today (UTC), reading token_spent_today
        resets the counter to 0 and updates budget_reset_date to today.
        """
        db_path = _make_test_db(tmp_path)
        yesterday = "2020-01-01"  # definitely not today
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        # Pre-populate with a stale reset date and non-zero spend
        _set_config(db_path, "routing.token_spent_today", "999")
        _set_config(db_path, "routing.budget_reset_date", yesterday)

        rc = RoutingConfig(db_path=db_path)

        # Reading spent_today should trigger the reset
        spent = rc.get_spent_today()

        assert spent == 0, (
            f"Expected token_spent_today to reset to 0 after stale reset_date, got {spent}"
        )
        new_reset_date = _get_config(db_path, "routing.budget_reset_date")
        assert new_reset_date == today, (
            f"Expected budget_reset_date to be updated to today ({today}), "
            f"got {new_reset_date!r}"
        )
        new_spent_raw = _get_config(db_path, "routing.token_spent_today")
        assert new_spent_raw == "0", (
            f"Expected config table token_spent_today to be '0', got {new_spent_raw!r}"
        )

    def test_same_day_no_reset(self, tmp_path):
        """When budget_reset_date == today, spend is NOT reset."""
        db_path = _make_test_db(tmp_path)
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        _set_config(db_path, "routing.token_spent_today", "150")
        _set_config(db_path, "routing.budget_reset_date", today)

        rc = RoutingConfig(db_path=db_path)
        spent = rc.get_spent_today()
        assert spent == 150, (
            f"Expected spend to remain 150 (same day), got {spent}"
        )

    def test_increment_spend_accumulates(self, tmp_path):
        """increment_spend adds to the running daily total."""
        db_path = _make_test_db(tmp_path)
        today = datetime.now(timezone.utc).strftime("%Y-%m-%d")

        _set_config(db_path, "routing.token_spent_today", "50")
        _set_config(db_path, "routing.budget_reset_date", today)

        rc = RoutingConfig(db_path=db_path)
        rc.increment_spend(42)
        spent = rc.get_spent_today()
        assert spent == 92, f"Expected 50+42=92, got {spent}"
