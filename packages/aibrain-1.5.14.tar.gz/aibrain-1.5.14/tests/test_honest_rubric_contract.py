"""test_honest_rubric_contract.py — regression tests for the honest-rubric None contract.

All 6 rubric fields must accept None without raising ValidationError:
  - quality / quality_score  (float | None)
  - cost_cents               (int | None)
  - self_score               (float | None)
  - eval_score               (float | None)
  - divergence               (float | None)
  - model_used               (str | None)

See decker_system/03_architecture/honest_rubric_contract.md for the full
specification. None means "could not measure" — callers must handle None,
not assume float/int.

Fix history:
  - agents.py TaskOutput.quality: float → float | None  (commit a2e013d)
  - superworker.py SuperWorkerResult.model_used: str → Optional[str]
  - companies.py complete_task cost_cents: int = 0 → Optional[int] = None
  - backend/companies_api.py CompleteTaskRequest.cost_cents: int = 0 → Optional[int] = None
"""
from __future__ import annotations

import dataclasses

import pytest

# ---------------------------------------------------------------------------
# HarnessResult — all 6 rubric fields
# ---------------------------------------------------------------------------

def test_harness_result_accepts_none_on_all_rubric_fields():
    """HarnessResult must accept None on all 6 honest-rubric fields without error."""
    from aibrain.core.harness import HarnessResult

    r = HarnessResult(
        success=True,
        quality=None,
        cost_cents=None,
        self_score=None,
        divergence=None,
        model_used=None,
    )
    assert r.quality is None
    assert r.cost_cents is None
    assert r.self_score is None
    assert r.divergence is None
    assert r.model_used is None


def test_harness_result_accepts_real_values():
    """HarnessResult still works when all rubric fields carry real measurements."""
    from aibrain.core.harness import HarnessResult

    r = HarnessResult(
        success=True,
        quality=0.85,
        cost_cents=12,
        self_score=0.9,
        divergence=0.05,
        model_used="claude-sonnet-4-5",
    )
    assert r.quality == pytest.approx(0.85)
    assert r.cost_cents == 12
    assert r.self_score == pytest.approx(0.9)
    assert r.divergence == pytest.approx(0.05)
    assert r.model_used == "claude-sonnet-4-5"


# ---------------------------------------------------------------------------
# TaskOutput (agents.py) — quality field
# ---------------------------------------------------------------------------

def test_task_output_quality_accepts_none():
    """TaskOutput.quality must be Optional[float] — None = unknown, not zero."""
    from aibrain.core.agents import TaskOutput

    t = TaskOutput(task_id="t1", raw="some output", quality=None)
    assert t.quality is None


def test_task_output_quality_accepts_float():
    """TaskOutput.quality still works with a real float."""
    from aibrain.core.agents import TaskOutput

    t = TaskOutput(task_id="t2", raw="output", quality=0.75)
    assert t.quality == pytest.approx(0.75)


# ---------------------------------------------------------------------------
# SuperWorkerResult (superworker.py) — model_used field
# ---------------------------------------------------------------------------

def test_superworker_result_model_used_accepts_none():
    """SuperWorkerResult.model_used must be Optional[str]."""
    from aibrain.core.superworker import SuperWorkerResult

    r = SuperWorkerResult(
        task="test task",
        task_type="judgment",
        lenses_consulted=["lens_a"],
        routing_reason="test",
        per_lens=[],
        synthesis="done",
        compatible_views=[],
        conflicts=[],
        overrode=[],
        synthesis_confidence=None,
        eval_score=None,
        raw_markdown="# test",
        parse_status="ok",
        warnings=[],
        cost_cents=None,
        model_used=None,  # the violation that was fixed
        duration_ms=100,
        success=True,
        run_id="run-1",
    )
    assert r.model_used is None


def test_superworker_result_model_used_accepts_str():
    """SuperWorkerResult.model_used still works with a real model string."""
    from aibrain.core.superworker import SuperWorkerResult

    r = SuperWorkerResult(
        task="test task",
        task_type="judgment",
        lenses_consulted=["lens_a"],
        routing_reason="test",
        per_lens=[],
        synthesis="done",
        compatible_views=[],
        conflicts=[],
        overrode=[],
        synthesis_confidence=0.8,
        eval_score=0.82,
        raw_markdown="# test",
        parse_status="ok",
        warnings=[],
        cost_cents=5,
        model_used="claude-sonnet-4-5",
        duration_ms=500,
        success=True,
        run_id="run-2",
    )
    assert r.model_used == "claude-sonnet-4-5"


# ---------------------------------------------------------------------------
# CompleteTaskRequest (backend/companies_api.py) — cost_cents field
# ---------------------------------------------------------------------------

def test_complete_task_request_cost_cents_accepts_none():
    """CompleteTaskRequest.cost_cents must be Optional[int] — None = unmeasured."""
    try:
        from backend.companies_api import CompleteTaskRequest
    except ImportError:
        pytest.skip("backend not importable in this environment")

    req = CompleteTaskRequest(cost_cents=None)
    assert req.cost_cents is None


def test_complete_task_request_cost_cents_accepts_int():
    """CompleteTaskRequest.cost_cents still works with a real int."""
    try:
        from backend.companies_api import CompleteTaskRequest
    except ImportError:
        pytest.skip("backend not importable in this environment")

    req = CompleteTaskRequest(cost_cents=25)
    assert req.cost_cents == 25


def test_complete_task_request_cost_cents_default_is_none():
    """Default for cost_cents must be None (not 0) per the contract."""
    try:
        from backend.companies_api import CompleteTaskRequest
    except ImportError:
        pytest.skip("backend not importable in this environment")

    req = CompleteTaskRequest()
    assert req.cost_cents is None, (
        "cost_cents default must be None — 0 is a real measurement ('explicitly free'), "
        "not 'could not measure'"
    )


# ---------------------------------------------------------------------------
# Type annotation smoke test — fields must carry Optional annotation
# ---------------------------------------------------------------------------

def test_superworker_result_model_used_is_annotated_optional():
    """SuperWorkerResult.model_used annotation must include None (Optional or X | None)."""
    import inspect
    from aibrain.core.superworker import SuperWorkerResult

    hints = {}
    for cls in SuperWorkerResult.__mro__:
        if hasattr(cls, "__annotations__"):
            hints.update(cls.__annotations__)

    ann = hints.get("model_used", None)
    assert ann is not None, "model_used has no annotation"
    ann_str = str(ann)
    # Optional[str] resolves to typing.Optional[str]; str | None to str | None
    assert "None" in ann_str or "Optional" in ann_str, (
        f"model_used annotation {ann_str!r} does not include None — "
        "violates honest-rubric contract"
    )


def test_harness_result_all_rubric_fields_annotated_optional():
    """All 6 rubric fields on HarnessResult must be Optional-annotated."""
    import typing
    from aibrain.core.harness import HarnessResult

    # Get annotations from dataclass fields
    fields = {f.name: f for f in dataclasses.fields(HarnessResult)}

    rubric_fields = ["quality", "cost_cents", "self_score", "divergence", "model_used"]
    for name in rubric_fields:
        assert name in fields, f"HarnessResult missing field {name!r}"
        field = fields[name]
        # The default must be None (not a sentinel like 0 or "")
        default = field.default
        assert default is None, (
            f"HarnessResult.{name} default is {default!r} — must be None "
            "per honest-rubric contract"
        )
