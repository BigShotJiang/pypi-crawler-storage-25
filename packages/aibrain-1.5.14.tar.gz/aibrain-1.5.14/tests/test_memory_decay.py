"""Tests for aibrain.core.memory_decay.

Covers:
  * Ebbinghaus curve shape (monotonic decay, R(0)=1, asymptote→0)
  * Four-factor strength math (each factor strengthens retention)
  * Honest-None semantics (missing factors are skipped, not faked)
  * DB loader against a synthetic memories schema
  * Re-ranker blends scores correctly and preserves passthrough on failure
"""

from __future__ import annotations

import math
import os
import sqlite3
import sys
import tempfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.memory_decay import (  # noqa: E402
    BASE_STRENGTH_DAYS,
    DECAY_FLOOR,
    STRENGTH_FLOOR_DAYS,
    DecayFactors,
    compute_decay_score,
    decay_strength,
    load_factors,
    rerank_by_decay,
    retention,
    strength,
    update_access_time,
)


# ---------------------------------------------------------------------------
# Pure-math tests — no DB
# ---------------------------------------------------------------------------


def test_retention_at_zero_elapsed_is_one():
    r = retention(0.0, DecayFactors())
    assert r == pytest.approx(1.0)


def test_retention_is_monotonically_decreasing():
    f = DecayFactors(access_frequency=2, importance=0.5, confirmation_count=1)
    prev = 1.0 + 1e-9
    for t in (0.0, 0.5, 1.0, 2.0, 5.0, 10.0, 30.0, 100.0):
        r = retention(t, f)
        assert 0.0 <= r <= 1.0
        assert r <= prev, f"not monotonic at t={t}: {r} > {prev}"
        prev = r


def test_retention_asymptotes_toward_zero():
    f = DecayFactors()  # all None → base strength
    assert retention(10_000.0, f) < 1e-6


def test_empty_factors_give_base_strength():
    # S(m) with no known factors == BASE_STRENGTH_DAYS
    assert strength(DecayFactors()) == pytest.approx(BASE_STRENGTH_DAYS)


def test_strength_floor():
    # Even if weights produced something tiny (they can't with current
    # tunables, but the floor guards against future regressions), strength
    # must never drop below STRENGTH_FLOOR_DAYS.
    assert strength(DecayFactors()) >= STRENGTH_FLOOR_DAYS


def test_each_known_factor_increases_strength():
    base = strength(DecayFactors())

    with_access = strength(DecayFactors(access_frequency=10))
    with_imp = strength(DecayFactors(importance=0.9))
    with_conf = strength(DecayFactors(confirmation_count=5))
    with_emo = strength(DecayFactors(emotional_salience=0.8))

    assert with_access > base
    assert with_imp > base
    assert with_conf > base
    assert with_emo > base


def test_factors_are_multiplicative_not_additive():
    # All four known should beat any single factor.
    s_all = strength(DecayFactors(
        access_frequency=10, importance=0.9,
        confirmation_count=5, emotional_salience=0.8,
    ))
    s_imp_only = strength(DecayFactors(importance=0.9))
    assert s_all > s_imp_only


def test_honest_none_unknown_factor_is_skipped_not_zeroed():
    # A None factor must NOT collapse strength — it should equal the
    # strength you would get with that factor simply absent.
    a = strength(DecayFactors(importance=0.5, access_frequency=None))
    b = strength(DecayFactors(importance=0.5))
    assert a == pytest.approx(b)


def test_importance_clamped_to_unit_interval():
    # Out-of-range importance is clamped, not rejected.
    s_hi = strength(DecayFactors(importance=5.0))
    s_one = strength(DecayFactors(importance=1.0))
    s_lo = strength(DecayFactors(importance=-3.0))
    s_zero = strength(DecayFactors(importance=0.0))
    assert s_hi == pytest.approx(s_one)
    assert s_lo == pytest.approx(s_zero)


def test_negative_elapsed_treated_as_zero():
    assert retention(-5.0, DecayFactors()) == pytest.approx(1.0)


def test_curve_matches_closed_form_ebbinghaus():
    # Verify the exact R(t) = exp(-t/S) formula on a known point.
    f = DecayFactors(importance=0.5)  # S = BASE * (1 + 2.0 * 0.5) = 2*BASE
    s = strength(f)
    assert s == pytest.approx(2.0 * BASE_STRENGTH_DAYS)
    assert retention(BASE_STRENGTH_DAYS, f) == pytest.approx(math.exp(-0.5))


# ---------------------------------------------------------------------------
# DB-backed tests
# ---------------------------------------------------------------------------


@pytest.fixture()
def db():
    """Synthetic memories DB with the fields memory_decay needs."""
    fd, path = tempfile.mkstemp(suffix=".db", prefix="aibrain_decay_")
    os.close(fd)

    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.executescript("""
        CREATE TABLE memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TEXT,
            created TEXT NOT NULL,
            active INTEGER DEFAULT 1
        );
        CREATE TABLE memory_history (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            memory_id INTEGER NOT NULL,
            action TEXT NOT NULL,
            created_at TEXT NOT NULL
        );
    """)
    conn.commit()
    yield conn
    conn.close()
    try:
        os.unlink(path)
    except OSError:
        pass


def _insert_memory(db, *, name, importance, access_count, last_accessed, created):
    cur = db.execute(
        "INSERT INTO memories(name, importance, access_count, last_accessed, created) "
        "VALUES (?,?,?,?,?)",
        (name, importance, access_count, last_accessed, created),
    )
    db.commit()
    return cur.lastrowid


def _add_history(db, memory_id, action, when):
    db.execute(
        "INSERT INTO memory_history(memory_id, action, created_at) VALUES (?,?,?)",
        (memory_id, action, when),
    )
    db.commit()


def _ts(dt: datetime) -> str:
    return dt.strftime("%Y-%m-%d %H:%M:%S")


def test_load_factors_happy_path(db):
    now = datetime(2026, 4, 11, 12, 0, 0, tzinfo=timezone.utc)
    mid = _insert_memory(
        db,
        name="hot memory",
        importance=0.8,
        access_count=17,
        last_accessed=_ts(now - timedelta(hours=2)),
        created=_ts(now - timedelta(days=30)),
    )
    _add_history(db, mid, "correction", _ts(now - timedelta(days=1)))
    _add_history(db, mid, "praise", _ts(now - timedelta(days=1)))
    _add_history(db, mid, "self_reflection", _ts(now))

    factors = load_factors(db, mid)
    assert factors is not None
    assert factors.access_frequency == 17
    assert factors.importance == pytest.approx(0.8)
    assert factors.confirmation_count == 3
    assert factors.emotional_salience is None  # honest-None
    assert any("emotional_salience" in n for n in factors.notes)


def test_load_factors_missing_memory(db):
    assert load_factors(db, 999_999) is None


def test_compute_decay_score_fresh_memory_is_high(db):
    now = datetime(2026, 4, 11, 12, 0, 0, tzinfo=timezone.utc)
    mid = _insert_memory(
        db,
        name="fresh",
        importance=0.5,
        access_count=0,
        last_accessed=_ts(now - timedelta(minutes=5)),
        created=_ts(now - timedelta(minutes=5)),
    )
    score = compute_decay_score(mid, now_ts=now, db=db)
    assert score is not None
    assert score > 0.99


def test_compute_decay_score_stale_memory_is_low(db):
    now = datetime(2026, 4, 11, 12, 0, 0, tzinfo=timezone.utc)
    mid = _insert_memory(
        db,
        name="stale",
        importance=0.1,
        access_count=0,
        last_accessed=_ts(now - timedelta(days=120)),
        created=_ts(now - timedelta(days=200)),
    )
    score = compute_decay_score(mid, now_ts=now, db=db)
    assert score is not None
    assert score < 0.05


def test_compute_decay_score_strong_memory_decays_slower_than_weak(db):
    now = datetime(2026, 4, 11, 12, 0, 0, tzinfo=timezone.utc)
    age = _ts(now - timedelta(days=14))

    weak = _insert_memory(
        db, name="weak",
        importance=0.1, access_count=0,
        last_accessed=age, created=age,
    )
    strong = _insert_memory(
        db, name="strong",
        importance=0.95, access_count=50,
        last_accessed=age, created=age,
    )
    for action in ("correction", "praise", "self_reflection", "praise", "correction"):
        _add_history(db, strong, action, age)

    s_weak = compute_decay_score(weak, now_ts=now, db=db)
    s_strong = compute_decay_score(strong, now_ts=now, db=db)
    assert s_weak is not None and s_strong is not None
    assert s_strong > s_weak
    # Strong memory at two weeks should still be recognizable.
    assert s_strong > 0.3
    # Weak memory at two weeks with base strength should be mostly gone.
    assert s_weak < 0.2


def test_compute_decay_score_missing_memory_returns_none(db):
    now = datetime(2026, 4, 11, 12, 0, 0, tzinfo=timezone.utc)
    assert compute_decay_score(123_456_789, now_ts=now, db=db) is None


def test_compute_decay_score_uses_created_when_last_accessed_null(db):
    now = datetime(2026, 4, 11, 12, 0, 0, tzinfo=timezone.utc)
    mid = _insert_memory(
        db, name="no-access",
        importance=0.5, access_count=0,
        last_accessed=None,
        created=_ts(now - timedelta(days=30)),
    )
    score = compute_decay_score(mid, now_ts=now, db=db)
    assert score is not None
    # 30 days with importance=0.5 → S = BASE * 2 = 14, R = exp(-30/14) ≈ 0.117
    assert 0.05 < score < 0.25


# ---------------------------------------------------------------------------
# Re-ranker tests
# ---------------------------------------------------------------------------


def test_rerank_by_decay_blends_and_sorts(db):
    now = datetime(2026, 4, 11, 12, 0, 0, tzinfo=timezone.utc)

    fresh = _insert_memory(
        db, name="fresh", importance=0.5, access_count=0,
        last_accessed=_ts(now - timedelta(hours=1)),
        created=_ts(now - timedelta(hours=1)),
    )
    stale = _insert_memory(
        db, name="stale", importance=0.5, access_count=0,
        last_accessed=_ts(now - timedelta(days=90)),
        created=_ts(now - timedelta(days=90)),
    )

    # Stale starts with a SLIGHTLY higher raw relevance score.
    results = [
        {"id": fresh, "score": 0.70},
        {"id": stale, "score": 0.72},
    ]
    reranked = rerank_by_decay(results, now_ts=now, db=db, blend=0.5)

    # Fresh should win after blending with decay.
    assert reranked[0]["id"] == fresh
    # Decay scores attached.
    assert reranked[0]["decay_score"] is not None
    assert reranked[1]["decay_score"] is not None
    assert reranked[0]["decay_score"] > reranked[1]["decay_score"]


def test_rerank_by_decay_missing_id_passes_through(db):
    now = datetime(2026, 4, 11, 12, 0, 0, tzinfo=timezone.utc)
    results = [{"score": 0.9}, {"id": None, "score": 0.8}]
    reranked = rerank_by_decay(results, now_ts=now, db=db)
    assert all(r["decay_score"] is None for r in reranked)
    # Original ordering by score preserved (0.9 then 0.8).
    assert [r["score"] for r in reranked] == [0.9, 0.8]


def test_rerank_by_decay_rejects_bad_blend(db):
    with pytest.raises(ValueError):
        rerank_by_decay([], blend=1.5, db=db)


# ---------------------------------------------------------------------------
# decay_strength() four-factor API tests (required by Ebbinghaus task spec)
# ---------------------------------------------------------------------------


def test_decay_strength_high_importance_slow():
    """High importance + confidence + frequent access = minimal decay after 7 days."""
    score_high = decay_strength(
        importance=0.95, confidence=0.95, age_days=7.0, access_count=20
    )
    score_low = decay_strength(
        importance=0.1, confidence=0.1, age_days=7.0, access_count=0
    )
    # High-importance memory must decay significantly slower.
    assert score_high > score_low, (
        f"Expected high-importance score {score_high:.4f} > low-importance score {score_low:.4f}"
    )
    # High-importance memory at 7 days should retain noticeable strength above the floor.
    # With the correct R=exp(-t/S) formula, exp(-7/S) at S≈2.75 ≈ 0.08, above DECAY_FLOOR=0.05.
    assert score_high > DECAY_FLOOR, f"High-importance memory decayed too fast: {score_high:.4f}"


def test_decay_strength_low_importance_fast():
    """Low importance + confidence + no access = rapid decay even at short age."""
    score = decay_strength(
        importance=0.05, confidence=0.05, age_days=3.0, access_count=0
    )
    # Very weak memory should decay close to floor within a few days.
    assert score <= 0.2, (
        f"Low-importance memory should decay quickly; got {score:.4f}"
    )


def test_decay_floor_never_zero():
    """decay_strength never returns below DECAY_FLOOR (0.05) regardless of inputs."""
    extreme_cases = [
        (0.0, 0.0, 10_000.0, 0),
        (0.0, 0.0, 0.0, 0),
        (0.001, 0.001, 365.0, 0),
    ]
    for imp, conf, age, acc in extreme_cases:
        score = decay_strength(importance=imp, confidence=conf, age_days=age, access_count=acc)
        assert score >= DECAY_FLOOR, (
            f"decay_strength({imp}, {conf}, {age}, {acc}) = {score:.6f} is below floor {DECAY_FLOOR}"
        )


def test_access_count_slows_decay():
    """Memory accessed 10x decays slower than memory accessed 1x, all else equal.

    Uses a short age (1 day) so both memories are above the floor and the
    difference from access_count is visible in the retention score.
    """
    score_10x = decay_strength(
        importance=0.5, confidence=0.5, age_days=1.0, access_count=10
    )
    score_1x = decay_strength(
        importance=0.5, confidence=0.5, age_days=1.0, access_count=1
    )
    assert score_10x > score_1x, (
        f"10x access score {score_10x:.4f} should exceed 1x access score {score_1x:.4f}"
    )


# ---------------------------------------------------------------------------
# update_access_time() tests
# ---------------------------------------------------------------------------


def test_update_access_time_increments_access_count(db):
    """update_access_time increments access_count and updates last_accessed."""
    now = datetime(2026, 4, 11, 12, 0, 0, tzinfo=timezone.utc)
    mid = _insert_memory(
        db, name="update-test",
        importance=0.5, access_count=5,
        last_accessed=None,
        created=_ts(now - timedelta(days=10)),
    )
    result = update_access_time(mid, db=db)
    assert result is True
    row = db.execute(
        "SELECT access_count, last_accessed FROM memories WHERE id=?", (mid,)
    ).fetchone()
    assert row["access_count"] == 6
    assert row["last_accessed"] is not None


def test_update_access_time_missing_id_returns_false(db):
    """update_access_time returns False when memory_id does not exist."""
    result = update_access_time(999_999_999, db=db)
    assert result is False


# ---------------------------------------------------------------------------
# decay_strength() canonical formula regression tests
# ---------------------------------------------------------------------------


def test_decay_strength_formula_correctness():
    """Verify R = exp(-t/S), NOT R = S * exp(-t/S).

    At age_days=0, R must be exactly 1.0 regardless of stability (exp(-0/S)=1).
    At age_days=S, R must equal exp(-1) to machine precision.

    Uses importance=1.0, confidence=1.0, access_count=0 so that:
        S = 1.0 * 1.0 * log1p(0+1) = log1p(1) = ln(2) ≈ 0.6931

    Then at age_days=ln(2): R = exp(-ln(2)/ln(2)) = exp(-1).
    """
    # t=0: exp(-0/S) = 1.0 regardless of S → clamped result must be 1.0
    assert decay_strength(importance=1.0, confidence=1.0, age_days=0, access_count=1) == 1.0

    # Compute the stability for importance=1, confidence=1, access_count=0
    # stability = 1.0 * 1.0 * log1p(0+1) = ln(2)
    S = math.log1p(0 + 1)  # = ln(2) ≈ 0.6931
    result = decay_strength(importance=1.0, confidence=1.0, age_days=S, access_count=0)
    assert abs(result - math.exp(-1)) < 1e-9, (
        f"decay_strength at age_days=S = {result!r}, expected exp(-1) = {math.exp(-1)!r}"
    )
