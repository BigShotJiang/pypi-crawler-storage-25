"""Tests for adaptive output-token escalation logic in the harness.

Ported from qwencode's pattern:
  - Default output token budget: 8192
  - If response length >= 95% of cap chars (cap * 4) AND quality < 0.7
    → retry with 65536 output tokens (escalation fires exactly once)
  - execution_log row must have output_token_escalated = 1
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from aibrain.core.harness import (
    HarnessConfig,
    HarnessResult,
    execute,
    get_current_output_tokens,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_capped_response(token_budget: int = 8192, pct: float = 0.97) -> str:
    """Return a string that is `pct` × (token_budget × 4) chars long.

    At pct=0.97 with the default 8192-token budget this exceeds the 95%
    threshold and should trigger escalation.
    """
    target = int(token_budget * 4 * pct)
    return "x" * target


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def isolated_db(tmp_path: Path):
    """Temporary aibrain.db with full schema so _log_audit can write."""
    import sys
    import os
    db_path = tmp_path / "aibrain.db"

    # Patch the harness DB-finder functions so they use our temp DB.
    with patch("aibrain.core.harness._find_db", return_value=db_path), \
         patch("aibrain.core.harness._get_or_create_db", return_value=db_path):
        # Bootstrap the schema so the INSERT succeeds.
        conn = sqlite3.connect(str(db_path))
        conn.execute("""
            CREATE TABLE IF NOT EXISTS execution_log (
                id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                actor TEXT NOT NULL,
                action TEXT NOT NULL,
                entity_type TEXT,
                entity_id TEXT,
                detail TEXT,
                quality_score REAL,
                self_score REAL,
                divergence REAL,
                flagged INTEGER DEFAULT 0,
                model_used TEXT,
                cost_cents INTEGER,
                cost_cents_actual INTEGER,
                cost_cents_equivalent INTEGER,
                duration_ms INTEGER DEFAULT 0,
                before_state TEXT,
                after_state TEXT,
                success INTEGER DEFAULT 0,
                error TEXT,
                task_type TEXT,
                authority TEXT,
                retries INTEGER DEFAULT 0,
                output_token_escalated INTEGER DEFAULT 0,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS evolution_outcomes (
                id TEXT PRIMARY KEY,
                skill TEXT NOT NULL,
                result TEXT NOT NULL,
                quality_score REAL,
                failure_reason TEXT,
                source TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        conn.close()
        yield db_path


# ---------------------------------------------------------------------------
# Core escalation test
# ---------------------------------------------------------------------------

class TestTokenEscalation:
    """Adaptive output-token escalation fires when response hits cap + low quality."""

    def test_escalation_fires_on_cap_hit_and_low_quality(self, isolated_db: Path):
        """
        Scenario:
          - First call: action returns a response that is 97% of the 8K cap
            in chars (clearly hit the limit), and quality_score evaluates < 0.7.
          - Escalation should fire: harness retries with 65536 tokens.
          - Second call: action returns a shorter, higher-quality response.
          - result.output_token_escalated must be True.
          - execution_log row must have output_token_escalated = 1.
        """
        # Track how many times the action was called and what token budget was set.
        call_log: list[int] = []

        def _action():
            token_budget = get_current_output_tokens()
            call_log.append(token_budget)
            if len(call_log) == 1:
                # First call: saturate the 8K budget.
                return _make_capped_response(token_budget=8192, pct=0.97)
            # Second call (escalated): return a short, complete answer.
            return "Short complete answer."

        # Patch quality evaluation so:
        #   - attempt 1 (capped response): quality = 0.4  (below 0.7 → triggers escalation)
        #   - attempt 2 (escalated, short): quality = 0.9 (above threshold → accept)
        _eval_call_count = [0]

        def _fake_eval(output, task_name, config, self_score, before_state):
            _eval_call_count[0] += 1
            if _eval_call_count[0] == 1:
                return {
                    "eval_score": 0.4,
                    "verified": True,
                    "checks": {},
                    "detail": "first attempt — capped",
                    "divergence": None,
                    "flagged": False,
                }
            return {
                "eval_score": 0.9,
                "verified": True,
                "checks": {},
                "detail": "second attempt — escalated",
                "divergence": None,
                "flagged": False,
            }

        config = HarnessConfig(
            task_type="deterministic",  # skips budget/authority/approval gates
            audit=True,
            actor="test",
            max_retries=0,  # no budget-based retries; escalation adds its own slot
            quality_threshold=0.5,
        )

        with patch("aibrain.core.harness._find_db", return_value=isolated_db), \
             patch("aibrain.core.harness._get_or_create_db", return_value=isolated_db), \
             patch("aibrain.core.harness.evaluate_task_quality", side_effect=_fake_eval):
            result = execute(task="test_escalation", action=_action, config=config)

        # Action must have been called exactly twice.
        assert len(call_log) == 2, (
            f"Expected action called 2 times (initial + escalated), got {len(call_log)}"
        )

        # First call used default 8192 tokens; second used 65536.
        assert call_log[0] == 8192, f"First call should use 8192 tokens, got {call_log[0]}"
        assert call_log[1] == 65536, f"Escalated call should use 65536 tokens, got {call_log[1]}"

        # Result must flag escalation.
        assert result.output_token_escalated is True, "output_token_escalated must be True"

        # Execution was successful (best attempt wins).
        assert result.success is True

        # execution_log row must have output_token_escalated = 1.
        conn = sqlite3.connect(str(isolated_db))
        rows = conn.execute(
            "SELECT output_token_escalated FROM execution_log WHERE action='test_escalation'"
        ).fetchall()
        conn.close()

        assert rows, "No execution_log row found for test_escalation"
        escalated_values = [r[0] for r in rows]
        assert any(v == 1 for v in escalated_values), (
            f"Expected output_token_escalated=1 in execution_log, got {escalated_values}"
        )

    def test_no_escalation_when_quality_good(self, isolated_db: Path):
        """When quality is >= 0.7, escalation must NOT fire even if response is long."""
        call_log: list[int] = []

        def _action():
            call_log.append(get_current_output_tokens())
            return _make_capped_response(token_budget=8192, pct=0.97)

        def _fake_eval(**kwargs):
            return {
                "eval_score": 0.8,
                "verified": True,
                "checks": {},
                "detail": "good quality — no escalation",
                "divergence": None,
                "flagged": False,
            }

        config = HarnessConfig(
            task_type="deterministic",
            audit=False,
            actor="test",
            max_retries=0,
            quality_threshold=0.5,
        )

        with patch("aibrain.core.harness._find_db", return_value=isolated_db), \
             patch("aibrain.core.harness._get_or_create_db", return_value=isolated_db), \
             patch("aibrain.core.harness.evaluate_task_quality", side_effect=_fake_eval):
            result = execute(task="test_no_escalation", action=_action, config=config)

        assert len(call_log) == 1, "No escalation expected — action should be called once"
        assert result.output_token_escalated is False

    def test_no_escalation_when_response_short(self, isolated_db: Path):
        """When response is well below the cap, escalation must NOT fire."""
        call_log: list[int] = []

        def _action():
            call_log.append(get_current_output_tokens())
            return "Short answer."  # << far below cap

        def _fake_eval(**kwargs):
            return {
                "eval_score": 0.4,  # low quality but response is short
                "verified": True,
                "checks": {},
                "detail": "short response — no escalation",
                "divergence": None,
                "flagged": False,
            }

        config = HarnessConfig(
            task_type="deterministic",
            audit=False,
            actor="test",
            max_retries=0,
        )

        with patch("aibrain.core.harness._find_db", return_value=isolated_db), \
             patch("aibrain.core.harness._get_or_create_db", return_value=isolated_db), \
             patch("aibrain.core.harness.evaluate_task_quality", side_effect=_fake_eval):
            result = execute(task="test_short_no_escalation", action=_action, config=config)

        assert len(call_log) == 1, "No escalation expected for short responses"
        assert result.output_token_escalated is False
