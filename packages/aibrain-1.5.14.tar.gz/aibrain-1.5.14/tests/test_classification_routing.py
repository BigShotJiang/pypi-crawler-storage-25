"""
Tests for data classification routing in AIBrain.

Covers:
  - route_by_classification() in aibrain/core/harness.py
  - classification field storage in mcp_server._store()
  - default classification value (PUBLIC)
"""
from __future__ import annotations

import sqlite3
from unittest.mock import MagicMock, patch

import pytest

from aibrain.core.harness import DataClassification, route_by_classification


# ---------------------------------------------------------------------------
# route_by_classification tests
# ---------------------------------------------------------------------------

class TestRouteByClassificationSecret:
    """SECRET classification must route to local model (Ollama)."""

    def test_secret_with_ollama_available_returns_local_model(self):
        """SECRET + Ollama running → local model in result dict."""
        mock_client = MagicMock()
        mock_client.is_available.return_value = True
        mock_client.model_name.return_value = "gemma3:4b"

        # LocalLLMClient is imported lazily inside route_by_classification —
        # patch at the source module so the lazy import picks up the mock.
        with patch(
            "aibrain.core.local_llm.LocalLLMClient", return_value=mock_client
        ):
            result = route_by_classification(
                DataClassification.SECRET, available_models=["haiku"]
            )

        assert result["model"] == "ollama/gemma3:4b"
        assert result["no_training"] is False

    def test_secret_with_ollama_unavailable_raises_value_error(self):
        """SECRET + Ollama not running → ValueError, never falls back to cloud."""
        mock_client = MagicMock()
        mock_client.is_available.return_value = False

        with patch(
            "aibrain.core.local_llm.LocalLLMClient", return_value=mock_client
        ):
            with pytest.raises(ValueError, match="local model"):
                route_by_classification(
                    DataClassification.SECRET, available_models=["haiku"]
                )

    def test_sensitive_with_ollama_available_returns_local_model(self):
        """SENSITIVE + Ollama running → local model (same code path as SECRET)."""
        mock_client = MagicMock()
        mock_client.is_available.return_value = True
        mock_client.model_name.return_value = "qwen2.5:7b-instruct"

        with patch(
            "aibrain.core.local_llm.LocalLLMClient", return_value=mock_client
        ):
            result = route_by_classification(
                DataClassification.SENSITIVE, available_models=["sonnet"]
            )

        assert result["model"] == "ollama/qwen2.5:7b-instruct"
        assert result["no_training"] is False

    def test_secret_with_ollama_in_available_models_returns_it_directly(self):
        """If an 'ollama/...' model is already in available_models, use it — no HTTP probe."""
        result = route_by_classification(
            DataClassification.SECRET,
            available_models=["ollama/gemma3:4b", "haiku"],
        )
        assert result["model"] == "ollama/gemma3:4b"
        assert result["no_training"] is False


class TestRouteByClassificationInternal:
    """INTERNAL classification → cloud model OK but no_training=True."""

    def test_internal_returns_cloud_model_with_no_training_flag(self):
        """INTERNAL → first available model, no_training=True."""
        result = route_by_classification(
            DataClassification.INTERNAL,
            available_models=["sonnet", "haiku"],
        )
        assert result["model"] == "sonnet"
        assert result["no_training"] is True


class TestRouteByClassificationPublic:
    """PUBLIC classification → any model, no restrictions."""

    def test_public_returns_first_model_no_training_false(self):
        """PUBLIC → first available model, no_training=False."""
        result = route_by_classification(
            DataClassification.PUBLIC,
            available_models=["haiku", "sonnet"],
        )
        assert result["model"] == "haiku"
        assert result["no_training"] is False

    def test_public_empty_models_returns_code_only(self):
        """Empty available_models → code_only fallback."""
        result = route_by_classification(DataClassification.PUBLIC, available_models=[])
        assert result["model"] == "code_only"
        assert result["no_training"] is False


# ---------------------------------------------------------------------------
# classification field storage tests — use the conftest mcp_db fixture
# ---------------------------------------------------------------------------

class TestClassificationStorage:
    """Verify classification is persisted to the memories table."""

    def test_classification_stored_on_new_memory(self, mcp_db):
        """Classification value is written to the DB column on INSERT."""
        import mcp_server

        mcp_server._store(
            name="test_secret_mem",
            content="This is a secret value.",
            classification="SECRET",
        )

        db = mcp_server._get_db()
        row = db.execute(
            "SELECT classification FROM memories WHERE name=?",
            ("test_secret_mem",),
        ).fetchone()
        assert row is not None
        assert row["classification"] == "SECRET"

    def test_default_classification_is_public(self, mcp_db):
        """When classification is not supplied, it defaults to PUBLIC."""
        import mcp_server

        mcp_server._store(
            name="test_default_class",
            content="Ordinary memory with no classification arg.",
        )

        db = mcp_server._get_db()
        row = db.execute(
            "SELECT classification FROM memories WHERE name=?",
            ("test_default_class",),
        ).fetchone()
        assert row is not None
        assert row["classification"] == "PUBLIC"

    def test_invalid_classification_coerces_to_public(self, mcp_db):
        """An unrecognised classification value is silently coerced to PUBLIC."""
        import mcp_server

        mcp_server._store(
            name="test_bad_class",
            content="Memory with garbage classification.",
            classification="TOPSECRET",  # not a valid tier
        )

        db = mcp_server._get_db()
        row = db.execute(
            "SELECT classification FROM memories WHERE name=?",
            ("test_bad_class",),
        ).fetchone()
        assert row is not None
        assert row["classification"] == "PUBLIC"
