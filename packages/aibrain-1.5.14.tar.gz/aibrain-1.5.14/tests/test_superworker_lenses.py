"""test_superworker_lenses.py — tests for SuperWorker lens selection routing.

Covers:
  * Always-on lenses (Decker + Bruce Schneier on overlay; Operator Lens +
    Adversarial Security Lens on public floor) are present in every selection.
  * Engineering/code tasks route to the correct lens set.
  * Strategy/product tasks route to the correct lens set.
  * select_lenses() and describe_lenses() public API shape.

Overlay note: these tests run against the real lens_router (overlay loaded
when present, public floor otherwise). The always-on assertions use
``lens_router.ALWAYS_ON_LENSES`` as the source of truth so the test is
correct on both Decker's machine (overlay="Decker"+"Bruce Schneier") and
a public CI install (public floor="Operator Lens"+"Adversarial Security Lens").
"""
from __future__ import annotations

import pytest

from aibrain.core import lens_router
from aibrain.core.lens_router import (
    ALWAYS_ON_LENSES,
    select_lenses,
    describe_lenses,
)


# ---------------------------------------------------------------------------
# Always-on invariant tests
# ---------------------------------------------------------------------------

def test_decker_lens_always_present():
    """The first always-on lens must appear in every selection regardless of task type.

    On Decker's machine (overlay loaded): first always-on lens is "Decker".
    On a public install (no overlay): first always-on lens is "Operator Lens".
    Both satisfy the 'operator always-on' semantic contract.
    """
    first_always_on = ALWAYS_ON_LENSES[0]
    task_types_to_check = [
        ("code task: fix a bug in the auth module", "engineering"),
        ("strategy: should we open-source Wintermute?", "strategy"),
        ("ML training loop design review", "ml"),
        ("security audit of the broker endpoint", "security"),
        ("write a blog post about aibrain", ""),
    ]
    for description, ttype in task_types_to_check:
        lenses = select_lenses(description, task_type=ttype)
        assert first_always_on in lenses, (
            f"Always-on lens '{first_always_on}' missing from selection for "
            f"task_type={ttype!r}, description={description!r}. "
            f"Got: {lenses}"
        )


def test_schneier_lens_always_present():
    """The second always-on lens must appear in every selection regardless of task type.

    On Decker's machine (overlay loaded): second always-on lens is "Bruce Schneier".
    On a public install (no overlay): second always-on lens is "Adversarial Security Lens".
    Both satisfy the 'security/adversarial always-on' semantic contract.
    """
    second_always_on = ALWAYS_ON_LENSES[1]
    task_types_to_check = [
        ("refactor the memory consolidation pipeline", "engineering"),
        ("product roadmap: should we build the marketplace?", "product"),
        ("benchmark the routing model", "research"),
        ("blue team review of the API surface", "security"),
    ]
    for description, ttype in task_types_to_check:
        lenses = select_lenses(description, task_type=ttype)
        assert second_always_on in lenses, (
            f"Always-on lens '{second_always_on}' missing from selection for "
            f"task_type={ttype!r}, description={description!r}. "
            f"Got: {lenses}"
        )


# ---------------------------------------------------------------------------
# Task-type routing tests
# ---------------------------------------------------------------------------

def test_engineering_task_selects_correct_lenses():
    """Engineering/code tasks must select lenses from the code_review task type.

    The routing contract for engineering tasks:
      - Always-on lenses are present.
      - At least one engineering-domain lens from the known code_review roster
        is present (Lead Engineer, Linus Torvalds, or a QA/security reviewer).
    """
    task = "review this Python module for correctness and performance"
    lenses = select_lenses(task, task_type="engineering")

    # Always-on present
    for ao in ALWAYS_ON_LENSES:
        assert ao in lenses, f"Always-on '{ao}' missing from engineering selection: {lenses}"

    # At least one expected engineering lens present. On overlay: named personas.
    # On public floor: generic role workers.
    expected_engineering_candidates = {
        # overlay persona names
        "Linus Torvalds", "Lead Engineer", "Donald Knuth", "Joel Spolsky",
        "DHH", "QA Lead", "Guido van Rossum", "Rich Hickey",
        # public-floor generic workers
        "Lead Engineer", "QA Lead", "Systems Architect", "Algorithmic Rigor",
        # security/review workers that are core to code_review routing
        "Code Security Auditor", "QA & Test Coverage Analyst",
        "Integration & Regression Risk Analyst", "Chain Logic Reviewer",
    }
    found = [l for l in lenses if l in expected_engineering_candidates]
    assert found, (
        f"No engineering-domain lens found in selection. "
        f"Expected one of {expected_engineering_candidates}. Got: {lenses}"
    )


def test_strategy_task_selects_correct_lenses():
    """Strategy/product tasks must select lenses from the strategy_decision task type.

    The routing contract for strategy tasks:
      - Always-on lenses are present.
      - At least one strategy-domain lens from the known strategy_decision roster
        is present (Thiel, Andreessen, Munger, etc. on overlay; generic equivalents
        on public floor).
    """
    task = "should we price the Pro tier at $9.95 or $19.95 and why"
    lenses = select_lenses(task, task_type="strategy")

    # Always-on present
    for ao in ALWAYS_ON_LENSES:
        assert ao in lenses, f"Always-on '{ao}' missing from strategy selection: {lenses}"

    # At least one expected strategy lens present.
    expected_strategy_candidates = {
        # overlay persona names
        "Peter Thiel", "Marc Andreessen", "Charlie Munger", "Naval Ravikant",
        "Stewart Brand", "Alan Kay", "Neuro (CEO)", "Jeff Bezos",
        # public-floor generic workers / archetypes
        "CEO", "Competitive Intelligence Analyst", "Product Philosopher",
        "Long-Term Vision", "First Principles", "Product Manager",
        # common fallback archetypes that may appear for strategy
        "Cognitive Bias Audit", "Systems Theorist",
    }
    found = [l for l in lenses if l in expected_strategy_candidates]
    assert found, (
        f"No strategy-domain lens found in selection. "
        f"Expected one of {expected_strategy_candidates}. Got: {lenses}"
    )


# ---------------------------------------------------------------------------
# describe_lenses API shape
# ---------------------------------------------------------------------------

def test_describe_lenses_returns_expected_shape():
    """describe_lenses() returns a list of dicts with name + specialty + categories."""
    names = ALWAYS_ON_LENSES[:2]
    described = describe_lenses(names)
    assert len(described) == len(names)
    for entry in described:
        assert "name" in entry
        assert "specialty" in entry
        assert "categories" in entry
        assert isinstance(entry["categories"], list)


def test_describe_lenses_unknown_name_not_dropped():
    """Unknown lens names are included with specialty='unknown', not silently dropped."""
    names = ["__nonexistent_lens__"]
    described = describe_lenses(names)
    assert len(described) == 1
    assert described[0]["name"] == "__nonexistent_lens__"
    assert described[0]["specialty"] == "unknown"
