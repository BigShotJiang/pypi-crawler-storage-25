"""
Tests for confidence + evidence fields and contradiction-decay mechanism.

Covers:
  * Schema has confidence + evidence columns after _migrate_schema()
  * Storing a memory with confidence=0.8 persists and is returned
  * honest-None: confidence=None stores without error, returns None
  * evidence list is stored as JSON and survives round-trip
  * decay_contradicted_memories() reduces confidence on overlapping memories
  * decay respects confidence floor (never < 0.1)
  * non-correction memory types do NOT trigger decay
"""

from __future__ import annotations

import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path

import pytest

# Ensure repo root is importable
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import aibrain_db as adb


# ---------------------------------------------------------------------------
# Fixture: isolated temporary DB with migrated schema
# ---------------------------------------------------------------------------

def _make_tmp_db(path: str) -> None:
    """Create an aibrain DB at path with full schema + migrations applied."""
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    adb._init_schema(conn)
    conn.commit()
    conn.close()


@pytest.fixture()
def tmp_db(tmp_path):
    """Temporary aibrain DB with full schema applied. Returns path string."""
    db_file = tmp_path / "test_confidence.db"
    _make_tmp_db(str(db_file))
    return str(db_file)


@pytest.fixture()
def conn(tmp_db):
    """Open connection to the migrated temp DB."""
    c = sqlite3.connect(tmp_db)
    c.row_factory = sqlite3.Row
    yield c
    c.close()


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _insert(conn, name, content="test content", mem_type="reference",
            confidence=None, evidence=None):
    """Insert a memory directly and return its id."""
    evidence_str = json.dumps(evidence) if evidence is not None else None
    conn.execute(
        """
        INSERT INTO memories
            (name, type, memory_class, tags, content, importance,
             confidence, evidence, created, updated, active, status)
        VALUES
            (?, ?, 'semantic', '', ?, 0.5, ?, ?, datetime('now'), datetime('now'), 1, 'active')
        """,
        (name, mem_type, content, confidence, evidence_str),
    )
    conn.commit()
    return conn.execute(
        "SELECT id FROM memories WHERE name=?", (name,)
    ).fetchone()["id"]


# ---------------------------------------------------------------------------
# 1. Schema column existence
# ---------------------------------------------------------------------------

class TestSchemaHasConfidenceColumn:
    def test_confidence_column_exists(self, conn):
        cols = {r[1] for r in conn.execute("PRAGMA table_info(memories)").fetchall()}
        assert "confidence" in cols, "confidence column missing after migration"

    def test_evidence_column_exists(self, conn):
        cols = {r[1] for r in conn.execute("PRAGMA table_info(memories)").fetchall()}
        assert "evidence" in cols, "evidence column missing after migration"

    def test_confidence_index_exists(self, conn):
        indexes = [
            r[1] for r in conn.execute(
                "SELECT * FROM sqlite_master WHERE type='index' AND name='idx_memories_confidence'"
            ).fetchall()
        ]
        assert "idx_memories_confidence" in indexes, "idx_memories_confidence index missing"


# ---------------------------------------------------------------------------
# 2. Store with confidence
# ---------------------------------------------------------------------------

class TestStoreWithConfidence:
    def test_store_with_confidence_persists(self, conn):
        _insert(conn, "conf_test", confidence=0.8)
        row = conn.execute(
            "SELECT confidence FROM memories WHERE name='conf_test'"
        ).fetchone()
        assert row is not None
        assert abs(row["confidence"] - 0.8) < 1e-6

    def test_store_with_confidence_round_trip(self, conn):
        _insert(conn, "conf_09", confidence=0.9)
        row = conn.execute(
            "SELECT confidence FROM memories WHERE name='conf_09'"
        ).fetchone()
        assert row["confidence"] == pytest.approx(0.9)


# ---------------------------------------------------------------------------
# 3. Honest-None: confidence=None is valid
# ---------------------------------------------------------------------------

class TestHonestNoneConfidence:
    def test_none_confidence_stores_without_error(self, conn):
        mem_id = _insert(conn, "no_confidence", confidence=None)
        assert mem_id > 0

    def test_none_confidence_returns_null(self, conn):
        _insert(conn, "null_conf", confidence=None)
        row = conn.execute(
            "SELECT confidence FROM memories WHERE name='null_conf'"
        ).fetchone()
        assert row["confidence"] is None


# ---------------------------------------------------------------------------
# 4. Evidence round-trip
# ---------------------------------------------------------------------------

class TestEvidenceRoundTrip:
    def test_evidence_list_persists(self, conn):
        evidence = ["memory_id:42", "url:https://example.com", "session:2026-04-13"]
        _insert(conn, "ev_test", evidence=evidence)
        row = conn.execute(
            "SELECT evidence FROM memories WHERE name='ev_test'"
        ).fetchone()
        assert row["evidence"] is not None
        loaded = json.loads(row["evidence"])
        assert loaded == evidence

    def test_none_evidence_stores_null(self, conn):
        _insert(conn, "ev_none", evidence=None)
        row = conn.execute(
            "SELECT evidence FROM memories WHERE name='ev_none'"
        ).fetchone()
        assert row["evidence"] is None


# ---------------------------------------------------------------------------
# 5. decay_contradicted_memories
# ---------------------------------------------------------------------------

class TestDecayOnCorrection:
    def test_decay_reduces_confidence_on_overlap(self, tmp_db, conn):
        # Store a memory about a specific topic with confidence=0.9
        _insert(conn, "old_belief",
                content="Python version is 3.9 installed on this machine",
                confidence=0.9)
        conn.close()  # decay_contradicted_memories opens its own connection

        new_correction = "Python version installed on this machine is actually 3.11"
        decayed = adb.decay_contradicted_memories(new_correction, db_path=tmp_db)
        assert decayed >= 1

        # Re-open to verify
        c2 = sqlite3.connect(tmp_db)
        c2.row_factory = sqlite3.Row
        row = c2.execute(
            "SELECT confidence FROM memories WHERE name='old_belief'"
        ).fetchone()
        c2.close()
        assert row["confidence"] < 0.9

    def test_decay_respects_floor(self, tmp_db, conn):
        # Memory already near floor
        _insert(conn, "near_floor",
                content="Python version is 3.9 installed on this machine",
                confidence=0.15)
        conn.close()

        new_correction = "Python version installed on this machine is actually 3.11"
        adb.decay_contradicted_memories(new_correction, db_path=tmp_db)

        c2 = sqlite3.connect(tmp_db)
        c2.row_factory = sqlite3.Row
        row = c2.execute(
            "SELECT confidence FROM memories WHERE name='near_floor'"
        ).fetchone()
        c2.close()
        assert row["confidence"] >= 0.1

    def test_decay_floor_multiple_passes(self, tmp_db, conn):
        """Multiple corrections cannot push confidence below floor."""
        _insert(conn, "multi_decay",
                content="Python version is 3.9 installed on this machine",
                confidence=0.9)
        conn.close()

        correction = "Python version installed on this machine is actually 3.11"
        for _ in range(20):
            adb.decay_contradicted_memories(correction, db_path=tmp_db)

        c2 = sqlite3.connect(tmp_db)
        c2.row_factory = sqlite3.Row
        row = c2.execute(
            "SELECT confidence FROM memories WHERE name='multi_decay'"
        ).fetchone()
        c2.close()
        assert row["confidence"] >= 0.1

    def test_correction_type_not_decayed(self, tmp_db, conn):
        """Correction memories themselves should not be decayed by subsequent corrections."""
        _insert(conn, "a_correction",
                content="Python version installed on this machine is 3.11",
                mem_type="correction",
                confidence=0.95)
        conn.close()

        new_correction = "Python version installed on this machine is actually 3.12"
        adb.decay_contradicted_memories(new_correction, db_path=tmp_db)

        c2 = sqlite3.connect(tmp_db)
        c2.row_factory = sqlite3.Row
        row = c2.execute(
            "SELECT confidence FROM memories WHERE name='a_correction'"
        ).fetchone()
        c2.close()
        # correction-type memories are excluded from decay
        assert row["confidence"] == pytest.approx(0.95)

    def test_no_overlap_no_decay(self, tmp_db, conn):
        """Unrelated memories are not decayed."""
        _insert(conn, "unrelated",
                content="The stock market closed up 2% today",
                confidence=0.9)
        conn.close()

        new_correction = "Python version installed on this machine is actually 3.11"
        decayed = adb.decay_contradicted_memories(new_correction, db_path=tmp_db)

        c2 = sqlite3.connect(tmp_db)
        c2.row_factory = sqlite3.Row
        row = c2.execute(
            "SELECT confidence FROM memories WHERE name='unrelated'"
        ).fetchone()
        c2.close()
        assert row["confidence"] == pytest.approx(0.9)
        assert decayed == 0

    def test_null_confidence_treated_as_one_for_decay(self, tmp_db, conn):
        """Memories with NULL confidence should be treated as 1.0 for decay calculation."""
        _insert(conn, "null_conf_mem",
                content="Python version is 3.9 installed on this machine",
                confidence=None)
        conn.close()

        new_correction = "Python version installed on this machine is actually 3.11"
        decayed = adb.decay_contradicted_memories(new_correction, db_path=tmp_db)
        assert decayed >= 1

        c2 = sqlite3.connect(tmp_db)
        c2.row_factory = sqlite3.Row
        row = c2.execute(
            "SELECT confidence FROM memories WHERE name='null_conf_mem'"
        ).fetchone()
        c2.close()
        # Should now have an explicit confidence value < 1.0
        assert row["confidence"] is not None
        assert row["confidence"] < 1.0


# ---------------------------------------------------------------------------
# 6. _fmt_memory surfaces confidence (unit test of format function)
# ---------------------------------------------------------------------------

class TestFmtMemoryConfidence:
    def test_fmt_shows_confidence_when_present(self):
        sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
        from mcp_server import _fmt_memory
        m = {
            "id": 1, "name": "test_mem", "type": "reference",
            "tags": "", "content": "hello world",
            "importance": 0.5, "confidence": 0.85,
            "updated": "2026-04-13",
        }
        out = _fmt_memory(m)
        assert "confidence: 0.85" in out

    def test_fmt_omits_confidence_when_none(self):
        from mcp_server import _fmt_memory
        m = {
            "id": 2, "name": "no_conf", "type": "reference",
            "tags": "", "content": "hello world",
            "importance": 0.5, "confidence": None,
            "updated": "2026-04-13",
        }
        out = _fmt_memory(m)
        assert "confidence" not in out
