"""
test_vault_grounded.py — Vault-grounded response protocol for AIBrain MCP.

Bennett's rule: "Search the vault before answering. Reference specific files
when making claims. Never fabricate information about your organisation."
Falsifiability check: "When the AI gives you an answer about your work, ask it
which file it found that in. If it can't cite one, treat it with scepticism."

Covers:
  - memory_search returns memory_id citations in each result
  - memory_search returns confidence in each result
  - memory_recall includes memory_id and confidence in each result
  - memory_cite returns the full record for a given memory_id
  - memory_cite returns an error for a nonexistent memory_id
  - grounding_warning fires when all results have confidence <= 0.3
  - grounding_warning is absent when at least one result has confidence > 0.3
  - memory_search with no results includes grounding_warning
  - memory_recall with no results includes grounding_warning
"""

from __future__ import annotations

import json
from pathlib import Path

import pytest


# ---------------------------------------------------------------------------
# Helpers — call MCP tools directly via mcp_server module functions,
# bypassing the async MCP transport. This mirrors the pattern in
# test_memory_api.py (REST layer) but tests the MCP handler logic directly.
# ---------------------------------------------------------------------------

def _store_memory(name: str, content: str, mem_type: str = "reference",
                  importance: float = 0.8, confidence: float | None = None) -> dict:
    """Store via mcp_server._store so it goes through the same path as the MCP tool."""
    import mcp_server
    return mcp_server._store(
        name=name,
        content=content,
        mem_type=mem_type,
        importance=importance,
        confidence=confidence,
    )


def _call_search(query: str, limit: int = 10, search_type: str | None = None) -> dict:
    """Call the memory_search logic and return the parsed JSON payload."""
    import mcp_server
    # _search returns a list of raw memory dicts
    results = mcp_server._search(query=query, limit=limit, search_type=search_type)
    cited = mcp_server._build_cited_results(results)
    warning = mcp_server._grounding_warning(cited)
    payload = {"count": len(cited), "results": cited}
    if warning:
        payload["grounding_warning"] = warning
    return payload


def _call_recall(mem_type: str | None = None, limit: int = 10) -> dict:
    """Call the memory_recall logic and return the parsed JSON payload."""
    import mcp_server
    results = mcp_server._recall(mem_type=mem_type, limit=limit)
    cited = mcp_server._build_cited_results(results)
    warning = mcp_server._grounding_warning(cited)
    payload = {"count": len(cited), "results": cited}
    if warning:
        payload["grounding_warning"] = warning
    return payload


def _call_cite(memory_id: int) -> dict:
    """Call _cite and return the record dict or an error dict."""
    import mcp_server
    record = mcp_server._cite(memory_id)
    if record is None:
        return {"error": f"No memory found with id={memory_id}"}
    return {
        "memory_id": record["id"],
        "name": record.get("name", ""),
        "content": record.get("content", ""),
        "type": record.get("type", "reference"),
        "confidence": record.get("confidence"),
        "importance": record.get("importance"),
        "tags": record.get("tags", ""),
        "created": record.get("created"),
        "updated": record.get("updated"),
        "evidence": record.get("evidence"),
    }


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestMemorySearchCitations:
    """memory_search must include memory_id and confidence in each result."""

    def test_search_result_has_memory_id(self, mcp_db):
        """Each result from memory_search includes a memory_id field."""
        _store_memory("vault_test_1", "The vault-grounded protocol requires citations")
        payload = _call_search("vault grounded citations")
        assert payload["count"] >= 1, "Expected at least 1 result"
        for r in payload["results"]:
            assert "memory_id" in r, f"Result missing memory_id: {r}"
            assert isinstance(r["memory_id"], int), "memory_id must be an int"
            assert r["memory_id"] > 0, "memory_id must be positive"

    def test_search_result_has_confidence(self, mcp_db):
        """Each result from memory_search includes a confidence field."""
        _store_memory("vault_test_conf", "Confidence citation test memory",
                      confidence=0.85)
        payload = _call_search("confidence citation test")
        assert payload["count"] >= 1
        for r in payload["results"]:
            assert "confidence" in r, f"Result missing confidence: {r}"
            assert isinstance(r["confidence"], float), "confidence must be a float"
            assert 0.0 <= r["confidence"] <= 1.0, "confidence must be in [0, 1]"

    def test_search_result_has_content_and_type(self, mcp_db):
        """Results include content and type fields alongside citations."""
        _store_memory("vault_type_test", "Content for citation type check", mem_type="project")
        payload = _call_search("citation type check")
        assert payload["count"] >= 1
        first = payload["results"][0]
        assert "content" in first
        assert "type" in first
        assert len(first["content"]) > 0

    def test_search_memory_id_matches_stored_id(self, mcp_db):
        """The memory_id in results matches the ID returned by _store."""
        result = _store_memory("vault_id_match", "Specific content for ID match test")
        stored_id = result["id"]
        payload = _call_search("Specific content for ID match test")
        assert payload["count"] >= 1
        returned_ids = [r["memory_id"] for r in payload["results"]]
        assert stored_id in returned_ids, (
            f"Stored id={stored_id} not found in returned_ids={returned_ids}"
        )

    def test_explicit_confidence_surfaced_in_search(self, mcp_db):
        """When a memory was stored with explicit confidence, that value appears in results."""
        _store_memory("vault_explicit_conf", "Explicit confidence memory content",
                      confidence=0.92)
        payload = _call_search("Explicit confidence memory content")
        assert payload["count"] >= 1
        # Find the specific result
        target = next(
            (r for r in payload["results"] if "explicit confidence" in r["content"].lower()),
            None,
        )
        assert target is not None, "Expected to find the explicit confidence memory"
        assert target["confidence"] == pytest.approx(0.92, abs=0.01), (
            f"Expected confidence ~0.92, got {target['confidence']}"
        )


class TestMemoryRecallCitations:
    """memory_recall must include memory_id and confidence in each result."""

    def test_recall_result_has_memory_id(self, mcp_db):
        """Each result from memory_recall includes a memory_id field."""
        _store_memory("recall_cite_1", "High importance recall memory", importance=0.9)
        payload = _call_recall()
        assert payload["count"] >= 1
        for r in payload["results"]:
            assert "memory_id" in r, f"Recall result missing memory_id: {r}"
            assert isinstance(r["memory_id"], int)
            assert r["memory_id"] > 0

    def test_recall_result_has_confidence(self, mcp_db):
        """Each result from memory_recall includes a confidence field."""
        _store_memory("recall_conf_1", "Recall confidence test", confidence=0.75)
        payload = _call_recall()
        assert payload["count"] >= 1
        for r in payload["results"]:
            assert "confidence" in r, f"Recall result missing confidence: {r}"
            assert isinstance(r["confidence"], float)
            assert 0.0 <= r["confidence"] <= 1.0


class TestMemoryCite:
    """memory_cite returns the full record for verification."""

    def test_cite_returns_full_record(self, mcp_db):
        """memory_cite returns full memory record for a valid memory_id."""
        stored = _store_memory("cite_target", "This is the content to cite",
                               mem_type="project", confidence=0.88)
        mem_id = stored["id"]
        record = _call_cite(mem_id)
        assert "error" not in record, f"Expected no error, got: {record}"
        assert record["memory_id"] == mem_id
        assert "cite_target" in record["name"]
        assert "content to cite" in record["content"]
        assert record["type"] == "project"

    def test_cite_returns_error_for_nonexistent_id(self, mcp_db):
        """memory_cite returns an error dict for a nonexistent memory_id."""
        record = _call_cite(999999)
        assert "error" in record, "Expected error for nonexistent memory_id"
        assert "999999" in record["error"]

    def test_cite_includes_confidence_field(self, mcp_db):
        """memory_cite includes the confidence field in the returned record."""
        stored = _store_memory("cite_conf", "Cited confidence content", confidence=0.77)
        mem_id = stored["id"]
        record = _call_cite(mem_id)
        assert "error" not in record
        assert "confidence" in record
        # The raw value may be stored; presence is the check — type depends on DB
        # (stored as REAL, may come back as float or None if not set)


class TestGroundingWarning:
    """grounding_warning enforces Bennett's falsifiability check."""

    def test_grounding_warning_absent_when_high_confidence_result_exists(self, mcp_db):
        """No grounding_warning when at least one result has confidence > 0.3."""
        # Store with explicit high confidence so the result is reliable
        _store_memory("high_conf_mem", "High confidence grounding test content",
                      confidence=0.9)
        payload = _call_search("high confidence grounding test content")
        # Should find the memory and NOT add a warning
        assert payload["count"] >= 1
        high_conf_results = [r for r in payload["results"] if r["confidence"] > 0.3]
        if high_conf_results:
            assert "grounding_warning" not in payload, (
                "grounding_warning should be absent when high-confidence results exist"
            )

    def test_grounding_warning_fires_when_all_low_confidence(self, mcp_db):
        """grounding_warning appears when all results have confidence <= 0.3."""
        import mcp_server
        # Synthesize a list of low-confidence results directly
        fake_results = [
            {"id": 1, "content": "low conf 1", "type": "reference",
             "name": "lc1", "confidence": 0.1, "importance": 0.2},
            {"id": 2, "content": "low conf 2", "type": "reference",
             "name": "lc2", "confidence": 0.2, "importance": 0.3},
        ]
        cited = mcp_server._build_cited_results(fake_results)
        warning = mcp_server._grounding_warning(cited)
        assert warning is not None, "Expected a grounding_warning for all low-confidence results"
        assert "scepticism" in warning.lower() or "skepticism" in warning.lower(), (
            f"Warning should mention scepticism: {warning}"
        )

    def test_grounding_warning_fires_on_empty_search(self, mcp_db):
        """grounding_warning appears when memory_search returns no results."""
        import mcp_server
        # Empty results → warning
        cited = mcp_server._build_cited_results([])
        warning = mcp_server._grounding_warning(cited)
        assert warning is not None
        assert len(warning) > 0

    def test_grounding_warning_absent_when_confidence_just_above_threshold(self, mcp_db):
        """grounding_warning absent when at least one result has confidence = 0.31."""
        import mcp_server
        results = [
            {"id": 10, "content": "borderline", "type": "reference",
             "name": "border", "confidence": 0.31, "importance": 0.5},
        ]
        cited = mcp_server._build_cited_results(results)
        warning = mcp_server._grounding_warning(cited)
        assert warning is None, (
            f"Expected no warning when confidence=0.31 > 0.3, got: {warning}"
        )
