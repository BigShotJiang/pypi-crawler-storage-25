"""
tests/test_checkout.py — Tests for gumroad_checkout_api endpoints.

Covers:
  1.  Key format is AIBRAIN-PRO-{16 hex chars uppercase}
  2.  Key format is AIBRAIN-TEAM-{16 hex chars uppercase} for team tier
  3.  POST /api/gumroad-checkout creates a record and returns the key
  4.  POST /api/gumroad-checkout rejects an unknown/invalid tier
  5.  POST /api/activate binds machine on first call → 200
  6.  POST /api/activate same machine again → idempotent 200
  7.  POST /api/activate different machine → 409
  8.  POST /api/activate with an unknown key → 404
  9.  POST /api/activate on an expired key (past grace_until) → 403
  10. GET  /api/license-status returns correct tier + masked machine_id
  11. GET  /api/license-status for unknown key → 404
  12. GET  /api/license-status for expired key → is_valid=False
  13. GET  /api/license-status within grace window → is_valid=True, is_grace_period=True
"""

from __future__ import annotations

import hashlib
import os
import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

# Ensure project root + backend on sys.path
AIBRAIN_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(AIBRAIN_ROOT))
sys.path.insert(0, str(AIBRAIN_ROOT / "backend"))

from fastapi import FastAPI
from fastapi.testclient import TestClient

from gumroad_checkout_api import router, _sha256, _generate_key, _ensure_schema


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def db_path(tmp_path, monkeypatch):
    """Isolated SQLite DB for each test; AIBRAIN_DB env var pointed at it."""
    path = str(tmp_path / "test_checkout.db")
    monkeypatch.setenv("AIBRAIN_DB", path)
    # Apply schema so the table exists
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    _ensure_schema(conn)
    conn.close()
    return path


@pytest.fixture()
def client(db_path):
    """FastAPI TestClient with gumroad_checkout_api router mounted."""
    app = FastAPI()
    app.include_router(router)
    return TestClient(app, raise_server_exceptions=True)


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------

def _iso_offset(days: int) -> str:
    """Return an ISO UTC string shifted by `days` relative to now."""
    dt = datetime.now(timezone.utc) + timedelta(days=days)
    return dt.strftime("%Y-%m-%dT%H:%M:%SZ")


def _insert_license(db_path: str, *, key_hash: str, email: str = "test@example.com",
                    tier: str = "pro", payment_reference: str = "GR-TEST",
                    valid_until_offset: int = 31, grace_until_offset: int = 34,
                    machine_id: str | None = None, activated_at: str | None = None):
    """Directly insert a gumroad_licenses row for test setup."""
    conn = sqlite3.connect(db_path)
    now_str = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    conn.execute(
        """INSERT INTO gumroad_licenses
           (key_hash, email, tier, payment_reference,
            valid_until, grace_until, machine_id, activated_at, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            key_hash, email, tier, payment_reference,
            _iso_offset(valid_until_offset),
            _iso_offset(grace_until_offset),
            machine_id, activated_at, now_str, now_str,
        ),
    )
    conn.commit()
    conn.close()


# ---------------------------------------------------------------------------
# 1. Key format — PRO
# ---------------------------------------------------------------------------

def test_generate_key_pro_format():
    key = _generate_key("pro")
    assert key.startswith("AIBRAIN-PRO-")
    suffix = key[len("AIBRAIN-PRO-"):]
    assert len(suffix) == 16
    assert suffix == suffix.upper()
    assert all(c in "0123456789ABCDEF" for c in suffix)


# ---------------------------------------------------------------------------
# 2. Key format — TEAM
# ---------------------------------------------------------------------------

def test_generate_key_team_format():
    key = _generate_key("team")
    assert key.startswith("AIBRAIN-TEAM-")
    suffix = key[len("AIBRAIN-TEAM-"):]
    assert len(suffix) == 16
    assert suffix == suffix.upper()
    assert all(c in "0123456789ABCDEF" for c in suffix)


# ---------------------------------------------------------------------------
# 3. Checkout creates record and returns key
# ---------------------------------------------------------------------------

def test_checkout_creates_record(client, db_path):
    resp = client.post("/api/gumroad-checkout", json={
        "email": "buyer@example.com",
        "tier": "pro",
        "payment_reference": "GR-ORDER-12345",
    })
    assert resp.status_code == 200, resp.text
    data = resp.json()

    assert data["tier"] == "pro"
    assert data["email"] == "buyer@example.com"
    assert data["license_key"].startswith("AIBRAIN-PRO-")
    assert "valid_until" in data

    # Verify the DB record exists
    key_hash = _sha256(data["license_key"])
    conn = sqlite3.connect(db_path)
    row = conn.execute(
        "SELECT * FROM gumroad_licenses WHERE key_hash = ?", (key_hash,)
    ).fetchone()
    conn.close()
    assert row is not None, "Record should be in gumroad_licenses"


# ---------------------------------------------------------------------------
# 4. Checkout rejects invalid tier
# ---------------------------------------------------------------------------

def test_checkout_rejects_invalid_tier(client):
    resp = client.post("/api/gumroad-checkout", json={
        "email": "buyer@example.com",
        "tier": "enterprise",  # not allowed by this endpoint
        "payment_reference": "GR-ORDER-99",
    })
    assert resp.status_code == 422  # Pydantic validation error


# ---------------------------------------------------------------------------
# 5. Activate binds machine on first call
# ---------------------------------------------------------------------------

def test_activate_binds_machine(client, db_path):
    raw_key = "AIBRAIN-PRO-ABCD1234EFGH5678"
    key_hash = _sha256(raw_key)
    _insert_license(db_path, key_hash=key_hash)

    resp = client.post("/api/activate", json={
        "license_key": raw_key,
        "machine_fingerprint": "machine-aaa",
    })
    assert resp.status_code == 200, resp.text
    data = resp.json()
    assert data["status"] == "activated"
    assert data["tier"] == "pro"
    assert "expires_at" in data

    # Verify machine_id is persisted
    conn = sqlite3.connect(db_path)
    row = conn.execute(
        "SELECT machine_id, activated_at FROM gumroad_licenses WHERE key_hash = ?",
        (key_hash,),
    ).fetchone()
    conn.close()
    assert row[0] == "machine-aaa"
    assert row[1] is not None


# ---------------------------------------------------------------------------
# 6. Activate same machine is idempotent
# ---------------------------------------------------------------------------

def test_activate_same_machine_idempotent(client, db_path):
    raw_key = "AIBRAIN-PRO-1111222233334444"
    key_hash = _sha256(raw_key)
    _insert_license(db_path, key_hash=key_hash,
                    machine_id="machine-bbb",
                    activated_at=_iso_offset(0))

    resp = client.post("/api/activate", json={
        "license_key": raw_key,
        "machine_fingerprint": "machine-bbb",  # same machine
    })
    assert resp.status_code == 200, resp.text
    assert resp.json()["status"] == "activated"


# ---------------------------------------------------------------------------
# 7. Activate different machine → 409
# ---------------------------------------------------------------------------

def test_activate_different_machine_returns_409(client, db_path):
    raw_key = "AIBRAIN-TEAM-AAAABBBBCCCCDDDD"
    key_hash = _sha256(raw_key)
    _insert_license(db_path, key_hash=key_hash, tier="team",
                    machine_id="machine-ccc",
                    activated_at=_iso_offset(0))

    resp = client.post("/api/activate", json={
        "license_key": raw_key,
        "machine_fingerprint": "machine-ddd",  # different machine
    })
    assert resp.status_code == 409
    assert "different machine" in resp.json()["detail"]


# ---------------------------------------------------------------------------
# 8. Activate unknown key → 404
# ---------------------------------------------------------------------------

def test_activate_unknown_key_returns_404(client, db_path):
    resp = client.post("/api/activate", json={
        "license_key": "AIBRAIN-PRO-DEADBEEFCAFEBABE",
        "machine_fingerprint": "machine-zzz",
    })
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# 9. Activate expired key (past grace_until) → 403
# ---------------------------------------------------------------------------

def test_activate_expired_key_returns_403(client, db_path):
    raw_key = "AIBRAIN-PRO-EXPIREDKEY123456"
    key_hash = _sha256(raw_key)
    _insert_license(
        db_path, key_hash=key_hash,
        valid_until_offset=-34,   # expired 34 days ago
        grace_until_offset=-31,   # grace also expired 31 days ago
    )

    resp = client.post("/api/activate", json={
        "license_key": raw_key,
        "machine_fingerprint": "machine-exp",
    })
    assert resp.status_code == 403
    assert "expired" in resp.json()["detail"]


# ---------------------------------------------------------------------------
# 10. GET /api/license-status returns correct fields with masked machine_id
# ---------------------------------------------------------------------------

def test_license_status_returns_correct_fields(client, db_path):
    raw_key = "AIBRAIN-PRO-STATUS0000000000"
    key_hash = _sha256(raw_key)
    _insert_license(
        db_path, key_hash=key_hash,
        tier="pro",
        machine_id="machine-fingerprint-full-string",
        activated_at=_iso_offset(0),
    )

    resp = client.get("/api/license-status", params={"key": raw_key})
    assert resp.status_code == 200, resp.text
    data = resp.json()

    assert data["tier"] == "pro"
    assert data["is_valid"] is True
    assert data["is_grace_period"] is False
    # machine_id should be masked
    masked = data["machine_id_masked"]
    assert masked is not None
    assert masked.startswith("machine-")   # first 8 chars of "machine-fingerprint-full-string" = "machine-"
    assert "***" in masked
    # raw fingerprint must NOT appear
    assert "machine-fingerprint-full-string" not in masked


# ---------------------------------------------------------------------------
# 11. GET /api/license-status for unknown key → 404
# ---------------------------------------------------------------------------

def test_license_status_unknown_key_returns_404(client, db_path):
    resp = client.get("/api/license-status", params={"key": "AIBRAIN-PRO-DOESNOTEXIST00"})
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# 12. GET /api/license-status for expired key → is_valid=False
# ---------------------------------------------------------------------------

def test_license_status_expired_key_is_invalid(client, db_path):
    raw_key = "AIBRAIN-TEAM-EXPIRED00000000"
    key_hash = _sha256(raw_key)
    _insert_license(
        db_path, key_hash=key_hash, tier="team",
        valid_until_offset=-34,
        grace_until_offset=-31,
    )

    resp = client.get("/api/license-status", params={"key": raw_key})
    assert resp.status_code == 200
    data = resp.json()
    assert data["is_valid"] is False
    assert data["is_grace_period"] is False


# ---------------------------------------------------------------------------
# 13. GET /api/license-status within grace window
# ---------------------------------------------------------------------------

def test_license_status_grace_period(client, db_path):
    raw_key = "AIBRAIN-PRO-GRACE0000000000"
    key_hash = _sha256(raw_key)
    _insert_license(
        db_path, key_hash=key_hash, tier="pro",
        valid_until_offset=-2,   # expired 2 days ago
        grace_until_offset=1,    # grace still open for 1 day
    )

    resp = client.get("/api/license-status", params={"key": raw_key})
    assert resp.status_code == 200
    data = resp.json()
    assert data["is_valid"] is True
    assert data["is_grace_period"] is True
