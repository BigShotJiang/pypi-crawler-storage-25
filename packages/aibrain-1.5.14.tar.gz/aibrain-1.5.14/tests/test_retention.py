"""
Tests for aibrain/core/retention.py — Continuous survival probability retention.

Covers:
  - memory_survival_probability(): type prior, importance signal, time signal
  - KEY: high-importance 'completion' survives where low-importance one is archived
  - apply_retention_policy(): dry_run, real archival, idempotent, empty DB
  - Legacy shim constants (RETENTION_POLICY, DEFAULT_RETENTION_DAYS) still importable

Uses a temporary SQLite DB seeded with memories of various ages, types, and
importance values.
"""

import sqlite3
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from aibrain.core.retention import (
    TYPE_PRIOR_WEIGHTS,
    SURVIVAL_ARCHIVE_THRESHOLD,
    DEFAULT_TYPE_PRIOR,
    DEFAULT_RETENTION_DAYS,
    RETENTION_POLICY,
    memory_survival_probability,
    apply_retention_policy,
)


# ---------------------------------------------------------------------------
# Schema helpers
# ---------------------------------------------------------------------------

MEMORIES_SCHEMA = """
CREATE TABLE IF NOT EXISTS memories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    type TEXT DEFAULT 'reference',
    content TEXT,
    tags TEXT,
    importance REAL DEFAULT 0.5,
    access_count INTEGER DEFAULT 0,
    last_accessed TIMESTAMP,
    source TEXT DEFAULT 'test',
    active INTEGER DEFAULT 1,
    embedding BLOB,
    created TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

_NOW = datetime(2024, 6, 1, 12, 0, 0, tzinfo=timezone.utc)


def _mem(
    *,
    mem_type: str = "reference",
    importance: float = 0.5,
    days_old: float = 30,
    access_count: int = 0,
    last_accessed_days_ago: float | None = None,
) -> dict:
    """Build a minimal memory dict for memory_survival_probability()."""
    created_ts = (_NOW - timedelta(days=days_old)).strftime("%Y-%m-%d %H:%M:%S")
    if last_accessed_days_ago is not None:
        last_accessed_ts = (_NOW - timedelta(days=last_accessed_days_ago)).strftime(
            "%Y-%m-%d %H:%M:%S"
        )
    else:
        last_accessed_ts = None
    return {
        "type": mem_type,
        "importance": importance,
        "access_count": access_count,
        "created": created_ts,
        "last_accessed": last_accessed_ts,
    }


@pytest.fixture()
def retention_db(tmp_path):
    """Create a temp DB seeded with memories of various ages, types, and importance."""
    db_path = tmp_path / "test_retention.db"
    db = sqlite3.connect(str(db_path))
    db.executescript(MEMORIES_SCHEMA)

    now = datetime.utcnow()

    # (name, type, days_old, importance, access_count)
    test_data = [
        # High-prior types — long-lived even with low importance
        ("user_pref",       "user",       365, 0.5, 0),
        ("feedback_1",      "feedback",   200, 0.5, 0),
        ("pattern_1",       "pattern",    300, 0.5, 0),
        ("skill_1",         "skill",      400, 0.5, 0),

        # Neutral-prior types — moderate age, moderate importance
        ("project_old",     "project",    180, 0.3, 0),   # should be archived
        ("project_fresh",   "project",      5, 0.5, 2),   # should survive
        ("ref_old",         "reference",  200, 0.2, 0),   # should be archived
        ("ref_fresh",       "reference",    3, 0.7, 5),   # should survive
        ("decision_old",    "decision",   180, 0.2, 0),   # should be archived

        # Completion — KEY TEST PAIR
        # high-importance completion should survive; low-importance should be archived
        ("completion_hi",   "completion",  45, 0.95,  8), # HIGH importance — survives
        ("completion_lo",   "completion", 200, 0.1,   0), # LOW  importance — archived

        # Other negative-prior types
        ("correction_old",  "correction", 200, 0.1,   0), # should be archived
        ("fix_fresh",       "fix",          2, 0.8,   1), # should survive (fresh)

        # Agent — strong negative prior, ephemeral
        ("agent_old",       "agent",       30, 0.5,   0), # should be archived
        ("agent_fresh",     "agent",        1, 0.5,   1), # should survive

        # Unknown type — neutral prior
        ("weird_old",       "custom_weird", 200, 0.1, 0), # should be archived
        ("weird_fresh",     "custom_weird",   2, 0.5, 2), # should survive
    ]

    for name, mem_type, days_old, importance, access_count in test_data:
        created = (now - timedelta(days=days_old)).strftime("%Y-%m-%d %H:%M:%S")
        db.execute(
            "INSERT INTO memories "
            "(name, type, content, importance, access_count, active, created) "
            "VALUES (?, ?, ?, ?, ?, 1, ?)",
            (name, mem_type, f"Content for {name}", importance, access_count, created),
        )

    db.commit()
    db.close()
    return str(db_path)


# ---------------------------------------------------------------------------
# TYPE_PRIOR_WEIGHTS constants
# ---------------------------------------------------------------------------


class TestTypePriorWeights:

    def test_high_prior_types(self):
        for t in ("user", "feedback", "pattern", "skill"):
            assert TYPE_PRIOR_WEIGHTS[t] == 1.2, f"{t} should have prior 1.2"

    def test_neutral_prior_types(self):
        for t in ("project", "reference", "decision", "discovery"):
            assert TYPE_PRIOR_WEIGHTS[t] == 1.0, f"{t} should have prior 1.0"

    def test_negative_prior_types(self):
        for t in ("completion", "correction", "fix"):
            assert TYPE_PRIOR_WEIGHTS[t] == 0.8, f"{t} should have prior 0.8"

    def test_ephemeral_prior(self):
        assert TYPE_PRIOR_WEIGHTS["agent"] == 0.5

    def test_threshold_value(self):
        assert SURVIVAL_ARCHIVE_THRESHOLD == 0.10

    def test_default_prior(self):
        assert DEFAULT_TYPE_PRIOR == 1.0

    def test_legacy_shim_importable(self):
        """RETENTION_POLICY and DEFAULT_RETENTION_DAYS still importable for old callers."""
        assert isinstance(RETENTION_POLICY, dict)
        assert DEFAULT_RETENTION_DAYS == 60


# ---------------------------------------------------------------------------
# memory_survival_probability() unit tests
# ---------------------------------------------------------------------------


class TestMemorySurvivalProbability:

    def test_returns_float_in_0_1(self):
        mem = _mem(mem_type="reference", importance=0.5, days_old=30)
        p = memory_survival_probability(mem, now=_NOW)
        assert 0.0 <= p <= 1.0

    def test_fresh_memory_high_survival(self):
        mem = _mem(mem_type="reference", importance=0.5, days_old=0)
        p = memory_survival_probability(mem, now=_NOW)
        assert p > 0.5, "A brand-new memory should have survival well above threshold"

    def test_very_old_low_importance_archived(self):
        mem = _mem(mem_type="reference", importance=0.1, days_old=500, access_count=0)
        p = memory_survival_probability(mem, now=_NOW)
        assert p < SURVIVAL_ARCHIVE_THRESHOLD, (
            f"Old low-importance reference should be below threshold, got {p:.4f}"
        )

    def test_high_importance_slows_decay(self):
        """High importance → higher survival than low importance at same age."""
        mem_hi = _mem(mem_type="reference", importance=0.95, days_old=60)
        mem_lo = _mem(mem_type="reference", importance=0.1,  days_old=60)
        p_hi = memory_survival_probability(mem_hi, now=_NOW)
        p_lo = memory_survival_probability(mem_lo, now=_NOW)
        assert p_hi > p_lo, (
            f"High-importance memory should outlast low-importance one: "
            f"{p_hi:.4f} vs {p_lo:.4f}"
        )

    def test_type_prior_shifts_curve(self):
        """user memory should outlast agent memory at same age/importance."""
        mem_user  = _mem(mem_type="user",  importance=0.5, days_old=90)
        mem_agent = _mem(mem_type="agent", importance=0.5, days_old=90)
        p_user  = memory_survival_probability(mem_user,  now=_NOW)
        p_agent = memory_survival_probability(mem_agent, now=_NOW)
        assert p_user > p_agent, (
            f"user prior (1.2) should survive longer than agent prior (0.5): "
            f"{p_user:.4f} vs {p_agent:.4f}"
        )

    def test_access_count_boosts_survival(self):
        """Frequently accessed memory survives longer than unaccessed at same age."""
        mem_hot  = _mem(mem_type="completion", importance=0.5, days_old=60, access_count=20)
        mem_cold = _mem(mem_type="completion", importance=0.5, days_old=60, access_count=0)
        p_hot  = memory_survival_probability(mem_hot,  now=_NOW)
        p_cold = memory_survival_probability(mem_cold, now=_NOW)
        assert p_hot > p_cold, (
            f"Frequently accessed memory should have higher survival: "
            f"{p_hot:.4f} vs {p_cold:.4f}"
        )

    def test_last_accessed_preferred_over_created(self):
        """If last_accessed is recent, elapsed time is short regardless of created."""
        # Very old creation, but accessed yesterday
        mem_recent = _mem(
            mem_type="reference",
            importance=0.5,
            days_old=500,
            last_accessed_days_ago=1,
        )
        mem_stale = _mem(
            mem_type="reference",
            importance=0.5,
            days_old=500,
            last_accessed_days_ago=None,
        )
        p_recent = memory_survival_probability(mem_recent, now=_NOW)
        p_stale  = memory_survival_probability(mem_stale,  now=_NOW)
        assert p_recent > p_stale, (
            "Memory accessed yesterday should have much higher survival than "
            "one last touched 500 days ago"
        )

    def test_unknown_type_gets_default_prior(self):
        """Unknown type uses DEFAULT_TYPE_PRIOR (1.0) — same as neutral types."""
        mem_unknown = _mem(mem_type="totally_custom", importance=0.5, days_old=30)
        mem_project = _mem(mem_type="project",        importance=0.5, days_old=30)
        p_unknown = memory_survival_probability(mem_unknown, now=_NOW)
        p_project = memory_survival_probability(mem_project, now=_NOW)
        assert abs(p_unknown - p_project) < 1e-9, (
            f"Unknown type and neutral-prior 'project' should score identically: "
            f"{p_unknown:.6f} vs {p_project:.6f}"
        )

    # -----------------------------------------------------------------------
    # THE KEY TEST: importance beats type for completion memories
    # -----------------------------------------------------------------------

    def test_high_importance_completion_survives_low_importance_archived(self):
        """Breslow Rec 3 core invariant.

        A high-importance 'completion' memory must survive where a low-importance
        one is archived. Type alone (negative prior 0.8) must NOT override the
        actual importance signal.
        """
        # High-importance completion: recently confirmed, well-accessed
        mem_hi = _mem(
            mem_type="completion",
            importance=0.95,
            days_old=45,
            access_count=8,
        )
        # Low-importance completion: old, never accessed
        mem_lo = _mem(
            mem_type="completion",
            importance=0.05,
            days_old=200,
            access_count=0,
        )
        p_hi = memory_survival_probability(mem_hi, now=_NOW)
        p_lo = memory_survival_probability(mem_lo, now=_NOW)

        assert p_hi >= SURVIVAL_ARCHIVE_THRESHOLD, (
            f"High-importance completion should survive (p={p_hi:.4f} >= {SURVIVAL_ARCHIVE_THRESHOLD})"
        )
        assert p_lo < SURVIVAL_ARCHIVE_THRESHOLD, (
            f"Low-importance completion should be archived (p={p_lo:.4f} < {SURVIVAL_ARCHIVE_THRESHOLD})"
        )

    def test_high_importance_correction_survives(self):
        """Same invariant for 'correction' type."""
        mem_hi = _mem(mem_type="correction", importance=0.9, days_old=30, access_count=5)
        mem_lo = _mem(mem_type="correction", importance=0.05, days_old=200, access_count=0)
        p_hi = memory_survival_probability(mem_hi, now=_NOW)
        p_lo = memory_survival_probability(mem_lo, now=_NOW)
        assert p_hi > p_lo
        assert p_lo < SURVIVAL_ARCHIVE_THRESHOLD


# ---------------------------------------------------------------------------
# apply_retention_policy() integration tests
# ---------------------------------------------------------------------------


class TestDryRun:

    def test_dry_run_does_not_modify_db(self, retention_db):
        db = sqlite3.connect(retention_db)
        before = db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
        db.close()

        result = apply_retention_policy(db_path=retention_db, dry_run=True)

        db = sqlite3.connect(retention_db)
        after = db.execute("SELECT COUNT(*) FROM memories WHERE active=1").fetchone()[0]
        db.close()

        assert before == after
        assert result["dry_run"] is True

    def test_dry_run_reports_counts(self, retention_db):
        result = apply_retention_policy(db_path=retention_db, dry_run=True)
        assert result["total_archived"] > 0
        assert len(result["archived"]) > 0

    def test_dry_run_identifies_expected_types(self, retention_db):
        result = apply_retention_policy(db_path=retention_db, dry_run=True)
        archived = result["archived"]
        # Old low-importance project memory should be flagged
        assert "project" in archived or result["total_archived"] > 0

    def test_dry_run_reports_threshold_and_policy(self, retention_db):
        result = apply_retention_policy(db_path=retention_db, dry_run=True)
        assert "threshold" in result
        assert result["threshold"] == SURVIVAL_ARCHIVE_THRESHOLD
        assert "policy" in result
        assert "user" in result["policy"]


class TestApplyRetention:

    def test_archives_old_low_importance_memories(self, retention_db):
        result = apply_retention_policy(db_path=retention_db, dry_run=False)
        assert result["dry_run"] is False
        assert result["total_archived"] > 0

    def test_high_importance_completion_survives(self, retention_db):
        """THE CORE INVARIANT: high-importance completion is NOT archived."""
        apply_retention_policy(db_path=retention_db, dry_run=False)

        db = sqlite3.connect(retention_db)
        db.row_factory = sqlite3.Row

        hi = db.execute(
            "SELECT active FROM memories WHERE name='completion_hi'"
        ).fetchone()
        lo = db.execute(
            "SELECT active FROM memories WHERE name='completion_lo'"
        ).fetchone()
        db.close()

        assert hi["active"] == 1, (
            "High-importance completion (importance=0.95) should remain active"
        )
        assert lo["active"] == 0, (
            "Low-importance completion (importance=0.1, 200 days old) should be archived"
        )

    def test_fresh_memories_survive_regardless_of_type(self, retention_db):
        """Very fresh memories should survive even with a negative-prior type."""
        apply_retention_policy(db_path=retention_db, dry_run=False)

        db = sqlite3.connect(retention_db)
        db.row_factory = sqlite3.Row

        for name in ("project_fresh", "ref_fresh", "fix_fresh", "agent_fresh", "weird_fresh"):
            row = db.execute(
                "SELECT active FROM memories WHERE name=?", (name,)
            ).fetchone()
            assert row is not None, f"Memory '{name}' not found"
            assert row["active"] == 1, f"Fresh memory '{name}' should survive"

        db.close()

    def test_old_low_importance_memories_archived(self, retention_db):
        """Old + low importance memories should be archived regardless of type."""
        apply_retention_policy(db_path=retention_db, dry_run=False)

        db = sqlite3.connect(retention_db)
        db.row_factory = sqlite3.Row

        for name in ("ref_old", "correction_old", "completion_lo", "weird_old"):
            row = db.execute(
                "SELECT active FROM memories WHERE name=?", (name,)
            ).fetchone()
            assert row is not None, f"Memory '{name}' not found"
            assert row["active"] == 0, (
                f"Old low-importance memory '{name}' should be archived"
            )

        db.close()

    def test_agent_type_decays_fast(self, retention_db):
        """Agent memories have a strong negative prior — 30 days should be enough to archive."""
        apply_retention_policy(db_path=retention_db, dry_run=False)

        db = sqlite3.connect(retention_db)
        db.row_factory = sqlite3.Row

        old_agent = db.execute(
            "SELECT active FROM memories WHERE name='agent_old'"
        ).fetchone()
        fresh_agent = db.execute(
            "SELECT active FROM memories WHERE name='agent_fresh'"
        ).fetchone()
        db.close()

        assert old_agent["active"] == 0, "30-day-old agent memory should be archived"
        assert fresh_agent["active"] == 1, "1-day-old agent memory should survive"

    def test_idempotent(self, retention_db):
        """Running retention twice should not archive anything new on the second run."""
        r1 = apply_retention_policy(db_path=retention_db, dry_run=False)
        r2 = apply_retention_policy(db_path=retention_db, dry_run=False)
        assert r2["total_archived"] == 0, "Second run should find nothing new to archive"

    def test_empty_database(self, tmp_path):
        db_path = tmp_path / "empty.db"
        db = sqlite3.connect(str(db_path))
        db.executescript(MEMORIES_SCHEMA)
        db.close()

        result = apply_retention_policy(db_path=str(db_path), dry_run=False)
        assert result["total_archived"] == 0
        assert result["archived"] == {}

    def test_all_already_inactive(self, tmp_path):
        db_path = tmp_path / "inactive.db"
        db = sqlite3.connect(str(db_path))
        db.executescript(MEMORIES_SCHEMA)
        db.execute(
            "INSERT INTO memories (name, type, content, importance, active, created) "
            "VALUES (?, ?, ?, ?, 0, ?)",
            ("old_inactive", "agent", "content", 0.1, "2020-01-01 00:00:00"),
        )
        db.commit()
        db.close()

        result = apply_retention_policy(db_path=str(db_path), dry_run=False)
        assert result["total_archived"] == 0

    def test_custom_threshold(self, retention_db):
        """A very high threshold archives everything; a zero threshold archives nothing."""
        r_all = apply_retention_policy(
            db_path=retention_db, dry_run=True, threshold=0.9999
        )
        # Re-open a fresh DB for the zero-threshold test
        db = sqlite3.connect(retention_db)
        total_active = db.execute(
            "SELECT COUNT(*) FROM memories WHERE active=1"
        ).fetchone()[0]
        db.close()

        # With threshold=0.9999, almost everything should be a candidate
        assert r_all["total_archived"] > 0

        r_none = apply_retention_policy(
            db_path=retention_db, dry_run=True, threshold=0.0
        )
        assert r_none["total_archived"] == 0, (
            "Threshold=0.0 should archive nothing (all survival probs are >=0)"
        )
