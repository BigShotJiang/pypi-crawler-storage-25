"""
Tests for `aibrain import-mem0` CLI command.

Covers:
  1. Valid JSON import → correct count stored
  2. --dry-run → nothing stored, count printed
  3. Malformed JSON → clear error, no crash
"""

import json
import os
import sys
import tempfile
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest

# Ensure project root is importable
AIBRAIN_ROOT = Path(__file__).resolve().parent.parent
if str(AIBRAIN_ROOT) not in sys.path:
    sys.path.insert(0, str(AIBRAIN_ROOT))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _run_import_mem0(args: list, monkeypatch=None) -> tuple[int, str]:
    """Run _cmd_import_mem0 and return (exit_code, stdout_output)."""
    from aibrain.__main__ import _cmd_import_mem0
    import io

    captured = io.StringIO()
    with patch("sys.stdout", captured):
        code = _cmd_import_mem0(args)
    return code, captured.getvalue()


def _make_export(entries: list, tmp_path: Path) -> Path:
    """Write a Mem0-style JSON export to a temp file and return its path."""
    p = tmp_path / "mem0_export.json"
    p.write_text(json.dumps(entries), encoding="utf-8")
    return p


# ---------------------------------------------------------------------------
# Test 1: Valid JSON → correct count stored
# ---------------------------------------------------------------------------

class TestImportMem0Valid:
    """Happy-path: import from a valid Mem0 JSON file."""

    def test_imports_all_non_empty_entries(self, tmp_path):
        """All entries with non-empty 'memory' fields are stored."""
        entries = [
            {"memory": "User prefers dark mode", "metadata": {"source": "app"}, "created_at": "2024-01-01"},
            {"memory": "User speaks French", "metadata": {}, "created_at": "2024-01-02"},
            {"memory": "   ", "metadata": {}},  # whitespace-only — should be skipped
            {"memory": "", "metadata": {}},      # empty — should be skipped
        ]
        export_file = _make_export(entries, tmp_path)

        stored = []

        def fake_create_memory(**kwargs):
            stored.append(kwargs)
            return len(stored)

        with patch("aibrain_db.create_memory", side_effect=fake_create_memory):
            from aibrain.__main__ import _cmd_import_mem0
            code = _cmd_import_mem0([str(export_file), "--type", "user"])

        assert code == 0
        assert len(stored) == 2, f"Expected 2 stored, got {len(stored)}: {stored}"
        contents = [m["content"] for m in stored]
        assert "User prefers dark mode" in contents
        assert "User speaks French" in contents

    def test_correct_memory_type_passed(self, tmp_path):
        """The --type argument is forwarded to create_memory."""
        entries = [{"memory": "Test memory", "metadata": {}}]
        export_file = _make_export(entries, tmp_path)

        stored = []

        def fake_create_memory(**kwargs):
            stored.append(kwargs)
            return 1

        with patch("aibrain_db.create_memory", side_effect=fake_create_memory):
            from aibrain.__main__ import _cmd_import_mem0
            code = _cmd_import_mem0([str(export_file), "--type", "reference"])

        assert code == 0
        assert stored[0]["mem_type"] == "reference"

    def test_source_agent_set_to_import_mem0(self, tmp_path):
        """source_agent is always 'import-mem0' so attribution is clear."""
        entries = [{"memory": "Test attribution", "metadata": {}}]
        export_file = _make_export(entries, tmp_path)

        stored = []

        def fake_create_memory(**kwargs):
            stored.append(kwargs)
            return 1

        with patch("aibrain_db.create_memory", side_effect=fake_create_memory):
            from aibrain.__main__ import _cmd_import_mem0
            _cmd_import_mem0([str(export_file)])

        assert stored[0]["source_agent"] == "import-mem0"


# ---------------------------------------------------------------------------
# Test 2: --dry-run → nothing stored, count printed
# ---------------------------------------------------------------------------

class TestImportMem0DryRun:
    """--dry-run mode must not write anything and must print the preview count."""

    def test_dry_run_stores_nothing(self, tmp_path):
        """No create_memory calls in dry-run mode."""
        entries = [
            {"memory": "Memory A", "metadata": {}},
            {"memory": "Memory B", "metadata": {}},
        ]
        export_file = _make_export(entries, tmp_path)

        with patch("aibrain_db.create_memory") as mock_create:
            from aibrain.__main__ import _cmd_import_mem0
            import io
            with patch("sys.stdout", io.StringIO()):
                code = _cmd_import_mem0([str(export_file), "--dry-run"])

        assert code == 0
        mock_create.assert_not_called()

    def test_dry_run_prints_count(self, tmp_path):
        """Dry-run output mentions both total and would-import count."""
        entries = [
            {"memory": "Alpha", "metadata": {}},
            {"memory": "Beta", "metadata": {}},
            {"memory": "", "metadata": {}},  # skipped
        ]
        export_file = _make_export(entries, tmp_path)

        import io
        captured = io.StringIO()
        with patch("aibrain_db.create_memory"):
            from aibrain.__main__ import _cmd_import_mem0
            with patch("sys.stdout", captured):
                code = _cmd_import_mem0([str(export_file), "--dry-run"])

        output = captured.getvalue()
        assert code == 0
        # Should mention "DRY RUN" somewhere
        assert "DRY RUN" in output or "dry run" in output.lower()
        # Should mention the 2 valid entries that would be imported
        assert "2" in output


# ---------------------------------------------------------------------------
# Test 3: Malformed JSON → clear error, no crash
# ---------------------------------------------------------------------------

class TestImportMem0Errors:
    """Error handling: bad JSON, missing file, wrong format."""

    def test_malformed_json_exits_with_error(self, tmp_path):
        """Malformed JSON should print a clear error and return non-zero exit."""
        bad_file = tmp_path / "bad.json"
        bad_file.write_text("{ this is not valid json !!!", encoding="utf-8")

        import io
        err_buf = io.StringIO()
        with patch("sys.stderr", err_buf):
            from aibrain.__main__ import _cmd_import_mem0
            with patch("sys.stdout", io.StringIO()):
                code = _cmd_import_mem0([str(bad_file)])

        assert code != 0, "Expected non-zero exit for malformed JSON"
        err = err_buf.getvalue()
        assert "malformed" in err.lower() or "json" in err.lower() or "error" in err.lower()

    def test_missing_file_exits_with_error(self, tmp_path):
        """Missing file should give a clear error without crashing."""
        missing = str(tmp_path / "nonexistent_export.json")

        import io
        err_buf = io.StringIO()
        with patch("sys.stderr", err_buf):
            from aibrain.__main__ import _cmd_import_mem0
            with patch("sys.stdout", io.StringIO()):
                code = _cmd_import_mem0([missing])

        assert code != 0
        err = err_buf.getvalue()
        assert "not found" in err.lower() or "error" in err.lower()

    def test_non_array_json_exits_with_error(self, tmp_path):
        """JSON that is an object (not an array) should give a clear error."""
        bad_format = tmp_path / "object.json"
        bad_format.write_text(json.dumps({"memory": "single item"}), encoding="utf-8")

        import io
        err_buf = io.StringIO()
        with patch("sys.stderr", err_buf):
            from aibrain.__main__ import _cmd_import_mem0
            with patch("sys.stdout", io.StringIO()):
                code = _cmd_import_mem0([str(bad_format)])

        assert code != 0
        err = err_buf.getvalue()
        assert "array" in err.lower() or "error" in err.lower()

    def test_no_args_exits_cleanly(self):
        """No args (or --help) should print usage and return 0 without crashing."""
        import io
        with patch("sys.stdout", io.StringIO()):
            from aibrain.__main__ import _cmd_import_mem0
            code = _cmd_import_mem0([])
        assert code == 0

    def test_help_flag_exits_cleanly(self):
        """--help prints usage and returns 0."""
        import io
        captured = io.StringIO()
        with patch("sys.stdout", captured):
            from aibrain.__main__ import _cmd_import_mem0
            code = _cmd_import_mem0(["--help"])
        assert code == 0
        assert "import-mem0" in captured.getvalue() or "Usage" in captured.getvalue()
