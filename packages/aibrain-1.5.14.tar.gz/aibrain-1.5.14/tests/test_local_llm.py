"""
Tests for aibrain.core.local_llm and aibrain.core.local_rag.

Covers:
- LocalLLMClient.is_available() when Ollama is down (mocked urllib)
- build_rag_context() with in-memory SQLite test fixtures
- complete_with_rag() with mocked LocalLLMClient.complete()
"""

import json
import sqlite3
import sys
import tempfile
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

# Ensure project root is importable
_root = Path(__file__).resolve().parent.parent
if str(_root) not in sys.path:
    sys.path.insert(0, str(_root))

from aibrain.core.local_llm import LocalLLMClient, _pick_model, _should_skip
from aibrain.core.local_rag import (
    _tokenize,
    _query_memories,
    _score_and_rank,
    _deduplicate,
    _format_context,
    build_rag_context,
    complete_with_rag,
)


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture()
def temp_brain_db(tmp_path):
    """Create a minimal aibrain.db with 3 test memories."""
    db_path = tmp_path / "aibrain.db"
    conn = sqlite3.connect(str(db_path))
    conn.execute("""
        CREATE TABLE memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            content TEXT,
            importance REAL DEFAULT 0.5,
            active INTEGER DEFAULT 1,
            status TEXT DEFAULT 'active'
        )
    """)
    conn.executemany(
        "INSERT INTO memories (content, importance, active, status) VALUES (?, ?, 1, 'active')",
        [
            ("Buffer overflow vulnerability in CVE-2024-9999 allows RCE on Linux kernels.", 0.9),
            ("Lateral movement via pass-the-hash attack using Mimikatz credential dumping.", 0.8),
            ("Unrelated memory about shopping list and groceries to buy on weekend.", 0.3),
        ],
    )
    conn.commit()
    conn.close()
    return str(db_path)


# ---------------------------------------------------------------------------
# test_is_available_when_ollama_down
# ---------------------------------------------------------------------------

class TestIsAvailableWhenOllamaDown:
    """LocalLLMClient.is_available() must return False without crashing when Ollama is unreachable."""

    def test_connection_refused(self):
        """Simulate ConnectionRefusedError from urllib — must return False."""
        import urllib.error

        with patch("urllib.request.urlopen", side_effect=urllib.error.URLError("Connection refused")):
            client = LocalLLMClient(base_url="http://localhost:11434")
            assert client.is_available() is False

    def test_os_error(self):
        """Simulate generic OSError (no Ollama process) — must return False."""
        with patch("urllib.request.urlopen", side_effect=OSError("No route to host")):
            client = LocalLLMClient(base_url="http://localhost:11434")
            assert client.is_available() is False

    def test_timeout(self):
        """Simulate timeout — must return False."""
        import socket

        with patch("urllib.request.urlopen", side_effect=socket.timeout("timed out")):
            client = LocalLLMClient(base_url="http://localhost:11434")
            assert client.is_available() is False

    def test_model_name_returns_none_when_down(self):
        """model_name() must return None when Ollama is unavailable."""
        with patch("urllib.request.urlopen", side_effect=OSError("refused")):
            client = LocalLLMClient()
            assert client.model_name() is None

    def test_complete_raises_runtime_error_when_down(self):
        """complete() must raise RuntimeError (not crash silently) when Ollama is unavailable."""
        with patch("urllib.request.urlopen", side_effect=OSError("refused")):
            client = LocalLLMClient()
            with pytest.raises(RuntimeError, match="Ollama is not available"):
                client.complete([{"role": "user", "content": "hello"}])

    def test_skip_keywords_filter_embedding_models(self):
        """Embedding and vision models must be filtered by _should_skip."""
        assert _should_skip("nomic-embed-text:latest") is True
        assert _should_skip("all-minilm:latest") is True
        assert _should_skip("bge-large-en") is True
        assert _should_skip("gemma3:4b") is False
        assert _should_skip("qwen3:8b") is False

    def test_pick_model_prefers_smallest(self):
        """_pick_model should return smallest preferred model available."""
        available = ["gemma3:27b", "qwen2.5:7b-instruct", "gemma3:4b"]
        assert _pick_model(available) == "gemma3:4b"

    def test_pick_model_falls_back_to_first_non_embed(self):
        """When no preferred model found, pick first non-embedding model."""
        available = ["nomic-embed:latest", "deepseek-r1:1.5b"]
        result = _pick_model(available)
        assert result == "deepseek-r1:1.5b"

    def test_is_available_true_when_models_present(self):
        """is_available() returns True when Ollama responds with models."""
        fake_response_body = json.dumps({
            "models": [{"name": "gemma3:4b"}, {"name": "qwen3:8b"}]
        }).encode("utf-8")

        mock_resp = MagicMock()
        mock_resp.read.return_value = fake_response_body
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("urllib.request.urlopen", return_value=mock_resp):
            client = LocalLLMClient()
            assert client.is_available() is True


# ---------------------------------------------------------------------------
# test_build_rag_context
# ---------------------------------------------------------------------------

class TestBuildRagContext:
    """build_rag_context() must query DB, score by keyword match, return formatted block."""

    def test_returns_matching_memories(self, temp_brain_db):
        """Query for 'CVE buffer overflow' should match the security memory."""
        ctx = build_rag_context("CVE buffer overflow", top_n=5, db_path=temp_brain_db)
        assert ctx != ""
        assert "MEMORY 1" in ctx
        assert "CVE-2024-9999" in ctx or "buffer overflow" in ctx.lower()

    def test_returns_at_least_two_matches(self, temp_brain_db):
        """Query for 'vulnerability attack' should match both security memories."""
        ctx = build_rag_context("vulnerability attack", top_n=5, db_path=temp_brain_db)
        assert "MEMORY 1" in ctx
        assert "MEMORY 2" in ctx

    def test_respects_top_n(self, temp_brain_db):
        """top_n=1 should return exactly one memory block."""
        ctx = build_rag_context("vulnerability attack", top_n=1, db_path=temp_brain_db)
        assert "MEMORY 1" in ctx
        assert "MEMORY 2" not in ctx

    def test_returns_empty_for_no_match(self, temp_brain_db):
        """Query with no token matches should return empty string."""
        ctx = build_rag_context("zzzzunlikelytokenxxx", top_n=5, db_path=temp_brain_db)
        assert ctx == ""

    def test_returns_empty_for_missing_db(self, tmp_path):
        """Missing DB path should return empty string gracefully."""
        ctx = build_rag_context("test query", top_n=5, db_path=str(tmp_path / "nonexistent.db"))
        assert ctx == ""

    def test_empty_query_returns_empty(self, temp_brain_db):
        """Empty/whitespace query should return empty string."""
        assert build_rag_context("", db_path=temp_brain_db) == ""
        assert build_rag_context("   ", db_path=temp_brain_db) == ""

    def test_importance_in_output(self, temp_brain_db):
        """Output format should include importance score."""
        ctx = build_rag_context("vulnerability", top_n=1, db_path=temp_brain_db)
        assert "importance:" in ctx

    def test_higher_importance_ranked_first(self, temp_brain_db):
        """The memory with higher importance should appear as MEMORY 1 when match count ties."""
        # Both security memories will match "vulnerability attack" — higher importance (0.9) first
        ctx = build_rag_context("vulnerability attack", top_n=5, db_path=temp_brain_db)
        lines = ctx.split("\n")
        first_line = lines[0] if lines else ""
        # CVE-2024-9999 has importance 0.9 — should be first
        assert "0.9" in first_line or "CVE" in first_line or "buffer" in first_line.lower()

    def test_tokenize_strips_stopwords(self):
        """_tokenize should strip common stopwords."""
        tokens = _tokenize("what is the best way to find vulnerabilities")
        assert "the" not in tokens
        assert "what" not in tokens
        assert "is" not in tokens
        assert "vulnerabilities" in tokens

    def test_tokenize_deduplicates(self):
        """_tokenize should not return duplicate tokens."""
        tokens = _tokenize("overflow overflow overflow")
        assert tokens.count("overflow") == 1

    def test_format_context_structure(self):
        """_format_context must produce [MEMORY N] (importance: X.X): content lines."""
        scored = [
            (3, 0.9, 1, "First memory content"),
            (2, 0.7, 2, "Second memory content"),
        ]
        result = _format_context(scored)
        assert "[MEMORY 1] (importance: 0.9):" in result
        assert "[MEMORY 2] (importance: 0.7):" in result
        assert "First memory content" in result

    def test_deduplicate_removes_near_dupes(self):
        """_deduplicate should remove memories with the same content prefix."""
        scored = [
            (3, 0.9, 1, "Same content repeated here for testing purposes"),
            (2, 0.8, 2, "Same content repeated here for testing purposes"),
            (1, 0.7, 3, "Different content here"),
        ]
        result = _deduplicate(scored)
        assert len(result) == 2  # first duplicate dropped


# ---------------------------------------------------------------------------
# test_complete_with_rag
# ---------------------------------------------------------------------------

class TestCompleteWithRag:
    """complete_with_rag() must prepend RAG context to system prompt before LLM call."""

    def test_rag_context_prepended_to_system(self, temp_brain_db):
        """When RAG matches exist, system passed to LLM must contain memory context."""
        captured_calls = {}

        def fake_complete(messages, system="", stream=False):
            captured_calls["system"] = system
            captured_calls["messages"] = messages
            return "mocked response"

        with patch.object(LocalLLMClient, "complete", side_effect=fake_complete):
            with patch.object(LocalLLMClient, "is_available", return_value=True):
                with patch.object(LocalLLMClient, "_resolve_model", return_value="gemma3:4b"):
                    result = complete_with_rag(
                        query="buffer overflow vulnerability",
                        system="You are a security expert.",
                        db_path=temp_brain_db,
                    )

        assert result == "mocked response"
        assert "system" in captured_calls
        # RAG context should be in the system prompt
        system_used = captured_calls["system"]
        assert "MEMORY" in system_used or "CVE" in system_used or "buffer" in system_used.lower()
        # Original system prompt should be included
        assert "You are a security expert." in system_used

    def test_no_rag_match_passes_original_system(self, temp_brain_db):
        """When no RAG matches, original system prompt is passed unchanged."""
        captured_calls = {}

        def fake_complete(messages, system="", stream=False):
            captured_calls["system"] = system
            return "mocked response"

        with patch.object(LocalLLMClient, "complete", side_effect=fake_complete):
            with patch.object(LocalLLMClient, "is_available", return_value=True):
                with patch.object(LocalLLMClient, "_resolve_model", return_value="gemma3:4b"):
                    complete_with_rag(
                        query="zzzzunlikelytokenxxx",
                        system="Base system prompt only.",
                        db_path=temp_brain_db,
                    )

        system_used = captured_calls.get("system", "")
        assert system_used == "Base system prompt only."

    def test_user_message_passed_as_query(self, temp_brain_db):
        """Query string must be passed as the user message content."""
        captured_calls = {}

        def fake_complete(messages, system="", stream=False):
            captured_calls["messages"] = messages
            return "mocked"

        with patch.object(LocalLLMClient, "complete", side_effect=fake_complete):
            with patch.object(LocalLLMClient, "is_available", return_value=True):
                with patch.object(LocalLLMClient, "_resolve_model", return_value="gemma3:4b"):
                    complete_with_rag(
                        query="explain lateral movement",
                        system="",
                        db_path=temp_brain_db,
                    )

        messages = captured_calls.get("messages", [])
        assert len(messages) == 1
        assert messages[0]["role"] == "user"
        assert messages[0]["content"] == "explain lateral movement"
