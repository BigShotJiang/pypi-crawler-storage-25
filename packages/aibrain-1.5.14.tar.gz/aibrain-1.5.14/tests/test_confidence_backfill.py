"""
Tests for backfill_confidence_from_importance().

Covers:
  1. Backfill sets confidence from importance (importance=0.8 → confidence=0.64)
  2. Backfill sets 0.5 for memories with no importance (NULL importance)
  3. Idempotent: running twice leaves values unchanged
  4. Function returns correct counts
"""

from __future__ import annotations

import sqlite3
import sys
from pathlib import Path

import pytest

# Ensure repo root is importable
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import aibrain_db as adb


# ---------------------------------------------------------------------------
# Fixture: isolated temporary DB with full migrated schema
# ---------------------------------------------------------------------------

def _make_tmp_db(path: str) -> None:
    """Create an aibrain DB at path with full schema + migrations applied."""
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    adb._init_schema(conn)
    conn.commit()
    conn.close()


@pytest.fixture()
def tmp_db(tmp_path):
    """Temporary aibrain DB with full schema. Returns path string."""
    db_file = tmp_path / "test_backfill.db"
    _make_tmp_db(str(db_file))
    return str(db_file)


def _insert_memory(db_path: str, name: str, importance=None, confidence=None) -> int:
    """Insert a memory with given importance and confidence. Returns id."""
    conn = sqlite3.connect(db_path)
    conn.execute(
        """
        INSERT INTO memories
            (name, type, memory_class, tags, content, importance, confidence,
             created, updated, active, status)
        VALUES
            (?, 'reference', 'semantic', '', 'test content', ?, ?,
             datetime('now'), datetime('now'), 1, 'active')
        """,
        (name, importance, confidence),
    )
    conn.commit()
    row_id = conn.execute("SELECT id FROM memories WHERE name=?", (name,)).fetchone()[0]
    conn.close()
    return row_id


def _get_confidence(db_path: str, name: str):
    """Return the confidence value for a named memory."""
    conn = sqlite3.connect(db_path)
    row = conn.execute(
        "SELECT confidence FROM memories WHERE name=?", (name,)
    ).fetchone()
    conn.close()
    return row[0] if row else None


# ---------------------------------------------------------------------------
# Test 1: confidence derived from importance
# ---------------------------------------------------------------------------

class TestBackfillFromImportance:
    def test_importance_0_8_gives_confidence_0_64(self, tmp_db):
        """importance=0.8 → confidence = MIN(1.0, 0.8 * 0.8) = 0.64"""
        _insert_memory(tmp_db, "mem_imp_08", importance=0.8, confidence=None)

        result = adb.backfill_confidence_from_importance(db_path=tmp_db)

        conf = _get_confidence(tmp_db, "mem_imp_08")
        assert conf is not None
        assert abs(conf - 0.64) < 1e-6, f"Expected 0.64, got {conf}"
        assert result["updated_from_importance"] >= 1

    def test_importance_gt_1_25_capped_at_1(self, tmp_db):
        """importance=1.5 → confidence = MIN(1.0, 1.5 * 0.8) = MIN(1.0, 1.2) = 1.0"""
        _insert_memory(tmp_db, "mem_imp_high", importance=1.5, confidence=None)

        adb.backfill_confidence_from_importance(db_path=tmp_db)

        conf = _get_confidence(tmp_db, "mem_imp_high")
        assert conf is not None
        assert conf <= 1.0
        assert abs(conf - 1.0) < 1e-6


# ---------------------------------------------------------------------------
# Test 2: no importance → default 0.5
# ---------------------------------------------------------------------------

class TestBackfillDefaultForNoImportance:
    def test_null_importance_gets_default_0_5(self, tmp_db):
        """Memory with NULL importance and NULL confidence gets confidence=0.5"""
        _insert_memory(tmp_db, "mem_no_imp", importance=None, confidence=None)

        result = adb.backfill_confidence_from_importance(db_path=tmp_db)

        conf = _get_confidence(tmp_db, "mem_no_imp")
        assert conf is not None
        assert abs(conf - 0.5) < 1e-6, f"Expected 0.5, got {conf}"
        assert result["updated_default"] >= 1


# ---------------------------------------------------------------------------
# Test 3: idempotent — running twice leaves values unchanged
# ---------------------------------------------------------------------------

class TestBackfillIdempotent:
    def test_second_run_does_not_change_values(self, tmp_db):
        """Running backfill twice must leave confidence values identical."""
        _insert_memory(tmp_db, "mem_idem_imp", importance=0.6, confidence=None)
        _insert_memory(tmp_db, "mem_idem_noimport", importance=None, confidence=None)

        # First run
        adb.backfill_confidence_from_importance(db_path=tmp_db)
        conf_after_first_imp = _get_confidence(tmp_db, "mem_idem_imp")
        conf_after_first_noi = _get_confidence(tmp_db, "mem_idem_noimport")

        # Second run
        result2 = adb.backfill_confidence_from_importance(db_path=tmp_db)

        conf_after_second_imp = _get_confidence(tmp_db, "mem_idem_imp")
        conf_after_second_noi = _get_confidence(tmp_db, "mem_idem_noimport")

        # Values must be unchanged
        assert abs(conf_after_first_imp - conf_after_second_imp) < 1e-9
        assert abs(conf_after_first_noi - conf_after_second_noi) < 1e-9

        # Second run should have updated 0 rows (all already filled)
        assert result2["updated_from_importance"] == 0
        assert result2["updated_default"] == 0

    def test_existing_confidence_not_overwritten(self, tmp_db):
        """Memories that already have confidence set must not be touched."""
        _insert_memory(tmp_db, "mem_already_set", importance=0.9, confidence=0.42)

        adb.backfill_confidence_from_importance(db_path=tmp_db)

        conf = _get_confidence(tmp_db, "mem_already_set")
        assert abs(conf - 0.42) < 1e-6, (
            f"Expected pre-existing 0.42 to be unchanged, got {conf}"
        )


# ---------------------------------------------------------------------------
# Test 4: function returns correct counts
# ---------------------------------------------------------------------------

class TestBackfillReturnCounts:
    def test_counts_match_actual_updates(self, tmp_db):
        """Return dict counts must match the actual rows updated."""
        # 3 memories with importance, 2 without
        _insert_memory(tmp_db, "cnt_imp_1", importance=0.5, confidence=None)
        _insert_memory(tmp_db, "cnt_imp_2", importance=0.7, confidence=None)
        _insert_memory(tmp_db, "cnt_imp_3", importance=0.3, confidence=None)
        _insert_memory(tmp_db, "cnt_noi_1", importance=None, confidence=None)
        _insert_memory(tmp_db, "cnt_noi_2", importance=None, confidence=None)

        result = adb.backfill_confidence_from_importance(db_path=tmp_db)

        assert result["updated_from_importance"] == 3
        assert result["updated_default"] == 2

    def test_counts_zero_when_all_already_filled(self, tmp_db):
        """If all confidences are already set, both counts should be 0."""
        _insert_memory(tmp_db, "filled_1", importance=0.5, confidence=0.4)
        _insert_memory(tmp_db, "filled_2", importance=0.7, confidence=0.56)

        result = adb.backfill_confidence_from_importance(db_path=tmp_db)

        assert result["updated_from_importance"] == 0
        assert result["updated_default"] == 0
