#!/usr/bin/env python3
"""
AIBrain MCP Server — Persistent agent memory over MCP protocol.

Zero config: backs to ~/aibrain.db by default.
3 core tools: memory_store, memory_search, memory_recall

Usage:
    python mcp_server.py                    # stdio mode (for Claude Code, Cursor, etc.)
    python mcp_server.py --db /path/to.db   # custom DB path

MCP config (.claude.json or .mcp.json):
    {
        "mcpServers": {
            "aibrain-memory": {
                "command": "python",
                "args": ["C:/Users/.../aibrain/mcp_server.py"]
            }
        }
    }
"""

import argparse
import json
import os
import sqlite3
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path

try:
    from mcp.server import Server
    from mcp.server.stdio import stdio_server
    from mcp.types import Tool, TextContent
except ImportError:
    # Graceful degradation — module can be imported for helper functions
    # (like _vec_enabled, _embed) without the MCP server running.
    # Only sys.exit if actually trying to run as MCP server (checked in __main__).
    Server = None
    stdio_server = None
    Tool = None
    TextContent = None
    _MCP_AVAILABLE = False
else:
    _MCP_AVAILABLE = True

# ---------------------------------------------------------------------------
# Optional: Embeddings (graceful degradation — works without them)
# ---------------------------------------------------------------------------

_embedder = None
_vec_enabled = False

try:
    import sqlite_vec
    _SQLITE_VEC_AVAILABLE = True
except ImportError:
    _SQLITE_VEC_AVAILABLE = False

_ST_AVAILABLE = None  # lazy-checked on first use


_EMBEDDING_MODEL = os.environ.get("AIBRAIN_EMBEDDING_MODEL", "all-MiniLM-L6-v2")


def _init_embedder():
    """Load embedding model. Called once at startup if available.

    Model selection (in order of precedence):
      1. AIBRAIN_EMBEDDING_MODEL env var (any sentence-transformer model)
      2. "none" / "off" to disable embeddings entirely
      3. Default: all-MiniLM-L6-v2 (22MB, 384-dim) — beat bge-small on
         LongMemEval hard50: hybrid 0.8634 vs 0.8549, 3x faster
    """
    global _embedder, _vec_enabled, _ST_AVAILABLE
    if _EMBEDDING_MODEL.lower() in ("none", "off", "disabled"):
        return False
    if _ST_AVAILABLE is None:
        try:
            from sentence_transformers import SentenceTransformer  # noqa: F811
            _ST_AVAILABLE = True
        except ImportError:
            _ST_AVAILABLE = False
    if _ST_AVAILABLE and _SQLITE_VEC_AVAILABLE:
        import logging
        logging.getLogger("sentence_transformers").setLevel(logging.WARNING)
        from sentence_transformers import SentenceTransformer
        _embedder = SentenceTransformer(_EMBEDDING_MODEL)
        _vec_enabled = True
    return _vec_enabled


def _get_embedding_dim() -> int:
    """Get dimension of loaded embedding model."""
    if _embedder is not None:
        return _embedder.get_sentence_embedding_dimension()
    return 384  # MiniLM default


def _embed(text: str) -> bytes:
    """Generate embedding and return as bytes for sqlite-vec."""
    import struct
    vec = _embedder.encode(text, normalize_embeddings=True)
    return struct.pack(f"{len(vec)}f", *vec)


def _embed_batch(texts: list[str]) -> list[bytes]:
    """Batch embed for efficiency."""
    import struct
    vecs = _embedder.encode(texts, normalize_embeddings=True, batch_size=64)
    return [struct.pack(f"{len(v)}f", *v) for v in vecs]


# ---------------------------------------------------------------------------
# Optional: Storage-time enrichment (V2 vocabulary expansion for FTS5)
# ---------------------------------------------------------------------------

_enricher = None

try:
    from storage_enricher import StorageEnricher
    _ENRICHER_AVAILABLE = True
except ImportError:
    _ENRICHER_AVAILABLE = False


def _init_enricher():
    """Load storage enricher. Called once at startup if available."""
    global _enricher
    if _ENRICHER_AVAILABLE:
        _enricher = StorageEnricher()
    return _enricher is not None


def _enrich_for_fts(content: str, name: str = "") -> str:
    """Enrich content for FTS5 indexing. Returns enriched string or original if enricher unavailable."""
    if _enricher is None:
        return content
    try:
        result = _enricher.enrich(content, session_id=name)
        return result.get_fts_content()
    except Exception:
        return content  # Graceful degradation — never block storage


# ---------------------------------------------------------------------------
# Database — self-contained, no imports from aibrain_db.py
# ---------------------------------------------------------------------------

_lock = threading.Lock()
_conn = None
_db_path = None


def _get_db() -> sqlite3.Connection:
    global _conn
    if _conn is not None:
        return _conn
    with _lock:
        if _conn is not None:
            return _conn
        _conn = sqlite3.connect(str(_db_path), check_same_thread=False, timeout=10)
        _conn.execute("PRAGMA journal_mode=WAL")
        _conn.execute("PRAGMA busy_timeout=5000")
        _conn.execute("PRAGMA foreign_keys=ON")
        _conn.row_factory = sqlite3.Row
        # Load sqlite-vec extension if available
        if _SQLITE_VEC_AVAILABLE:
            _conn.enable_load_extension(True)
            sqlite_vec.load(_conn)
            _conn.enable_load_extension(False)
        _ensure_schema(_conn)
        return _conn


def _ensure_schema(db: sqlite3.Connection):
    """Create tables if they don't exist. Idempotent."""
    db.executescript("""
        CREATE TABLE IF NOT EXISTS memories (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            type TEXT DEFAULT 'reference',
            memory_class TEXT DEFAULT 'semantic',
            tags TEXT DEFAULT '',
            content TEXT NOT NULL,
            importance REAL DEFAULT 0.5,
            access_count INTEGER DEFAULT 0,
            last_accessed TIMESTAMP,
            created TIMESTAMP DEFAULT (datetime('now')),
            updated TIMESTAMP DEFAULT (datetime('now')),
            active INTEGER DEFAULT 1
        );
    """)
    # Idempotent migration: add classification column if missing (old DBs won't have it)
    try:
        db.execute("ALTER TABLE memories ADD COLUMN classification TEXT DEFAULT 'PUBLIC'")
        db.commit()
    except Exception:
        pass  # Column already exists — sqlite3 raises OperationalError, not a problem
    db.executescript("""

        CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
            name, tags, content, content=memories, content_rowid=id
        );

        -- Triggers to keep FTS in sync
        CREATE TRIGGER IF NOT EXISTS memories_ai AFTER INSERT ON memories BEGIN
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END;

        CREATE TRIGGER IF NOT EXISTS memories_au AFTER UPDATE ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, name, tags, content)
            VALUES ('delete', old.id, old.name, old.tags, old.content);
            INSERT INTO memories_fts(rowid, name, tags, content)
            VALUES (new.id, new.name, new.tags, new.content);
        END;

        CREATE TRIGGER IF NOT EXISTS memories_ad AFTER DELETE ON memories BEGIN
            INSERT INTO memories_fts(memories_fts, rowid, name, tags, content)
            VALUES ('delete', old.id, old.name, old.tags, old.content);
        END;
    """)
    # Passage-level indexing — chunk long memories for better recall
    db.executescript("""
        CREATE TABLE IF NOT EXISTS memory_passages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            memory_id INTEGER NOT NULL,
            passage_index INTEGER NOT NULL,
            content TEXT NOT NULL,
            role_weight REAL DEFAULT 1.0,
            FOREIGN KEY (memory_id) REFERENCES memories(id) ON DELETE CASCADE
        );

        CREATE INDEX IF NOT EXISTS idx_passages_memory ON memory_passages(memory_id);

        CREATE VIRTUAL TABLE IF NOT EXISTS passages_fts USING fts5(
            content, content=memory_passages, content_rowid=id
        );

        CREATE TRIGGER IF NOT EXISTS passages_ai AFTER INSERT ON memory_passages BEGIN
            INSERT INTO passages_fts(rowid, content)
            VALUES (new.id, new.content);
        END;

        CREATE TRIGGER IF NOT EXISTS passages_au AFTER UPDATE ON memory_passages BEGIN
            INSERT INTO passages_fts(passages_fts, rowid, content)
            VALUES ('delete', old.id, old.content);
            INSERT INTO passages_fts(rowid, content)
            VALUES (new.id, new.content);
        END;

        CREATE TRIGGER IF NOT EXISTS passages_ad AFTER DELETE ON memory_passages BEGIN
            INSERT INTO passages_fts(passages_fts, rowid, content)
            VALUES ('delete', old.id, old.content);
        END;
    """)

    # Semantic fact store — Tulving's dual-store: episodic (memories) + semantic (facts)
    # Facts are extracted from episodes at ingest, queryable by SPO triples.
    db.executescript("""
        CREATE TABLE IF NOT EXISTS semantic_facts (
            fact_id INTEGER PRIMARY KEY AUTOINCREMENT,
            subject TEXT NOT NULL,
            predicate TEXT NOT NULL,
            object TEXT NOT NULL,
            fact_type TEXT NOT NULL DEFAULT 'attribute',
            sentiment TEXT DEFAULT 'NEUTRAL',
            confidence REAL DEFAULT 0.5,
            status TEXT DEFAULT 'ACTIVE',
            created_at TEXT DEFAULT (datetime('now')),
            updated_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS fact_evidence (
            evidence_id INTEGER PRIMARY KEY AUTOINCREMENT,
            fact_id INTEGER NOT NULL REFERENCES semantic_facts(fact_id),
            source_memory_id INTEGER NOT NULL,
            extraction_method TEXT NOT NULL DEFAULT 'pattern',
            verbatim_snippet TEXT,
            observed_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS fact_transitions (
            transition_id INTEGER PRIMARY KEY AUTOINCREMENT,
            old_fact_id INTEGER NOT NULL REFERENCES semantic_facts(fact_id),
            new_fact_id INTEGER NOT NULL REFERENCES semantic_facts(fact_id),
            transition_type TEXT NOT NULL DEFAULT 'update',
            evidence_id INTEGER REFERENCES fact_evidence(evidence_id)
        );

        CREATE INDEX IF NOT EXISTS idx_facts_lookup
            ON semantic_facts(subject, predicate, status);
        CREATE INDEX IF NOT EXISTS idx_facts_type
            ON semantic_facts(fact_type, status);
        CREATE INDEX IF NOT EXISTS idx_facts_subject
            ON semantic_facts(subject, status);
        CREATE INDEX IF NOT EXISTS idx_evidence_fact
            ON fact_evidence(fact_id);
        CREATE INDEX IF NOT EXISTS idx_evidence_memory
            ON fact_evidence(source_memory_id);

        -- FTS on semantic facts for keyword matching
        CREATE VIRTUAL TABLE IF NOT EXISTS facts_fts USING fts5(
            subject, predicate, object,
            content=semantic_facts, content_rowid=fact_id
        );

        CREATE TRIGGER IF NOT EXISTS facts_ai AFTER INSERT ON semantic_facts BEGIN
            INSERT INTO facts_fts(rowid, subject, predicate, object)
            VALUES (new.fact_id, new.subject, new.predicate, new.object);
        END;

        CREATE TRIGGER IF NOT EXISTS facts_au AFTER UPDATE ON semantic_facts BEGIN
            INSERT INTO facts_fts(facts_fts, rowid, subject, predicate, object)
            VALUES ('delete', old.fact_id, old.subject, old.predicate, old.object);
            INSERT INTO facts_fts(rowid, subject, predicate, object)
            VALUES (new.fact_id, new.subject, new.predicate, new.object);
        END;

        CREATE TRIGGER IF NOT EXISTS facts_ad AFTER DELETE ON semantic_facts BEGIN
            INSERT INTO facts_fts(facts_fts, rowid, subject, predicate, object)
            VALUES ('delete', old.fact_id, old.subject, old.predicate, old.object);
        END;
    """)

    # Vector table — only if sqlite-vec is loaded
    # Dimension adapts to loaded model (384 for MiniLM, 768 for bge-base, etc.)
    if _SQLITE_VEC_AVAILABLE:
        dim = _get_embedding_dim()
        try:
            # Check if vec table exists with a different dimension
            existing = db.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='memories_vec'"
            ).fetchone()
            if existing:
                # Verify dimension matches — if not, drop and recreate (embeddings
                # will be re-backfilled on startup). This handles model migration.
                try:
                    import struct
                    test_row = db.execute("SELECT embedding FROM memories_vec LIMIT 1").fetchone()
                    if test_row and test_row[0]:
                        existing_dim = len(test_row[0]) // 4  # 4 bytes per float32
                        if existing_dim != dim:
                            db.execute("DROP TABLE memories_vec")
                            db.execute(f"""
                                CREATE VIRTUAL TABLE memories_vec USING vec0(
                                    memory_id INTEGER PRIMARY KEY,
                                    embedding float[{dim}]
                                )
                            """)
                except Exception:
                    pass  # Table exists but empty or unreadable — leave it
            else:
                db.execute(f"""
                    CREATE VIRTUAL TABLE IF NOT EXISTS memories_vec USING vec0(
                        memory_id INTEGER PRIMARY KEY,
                        embedding float[{dim}]
                    )
                """)
        except Exception:
            pass  # vec0 might already exist or extension not loaded


# ---------------------------------------------------------------------------
# Memory operations
# ---------------------------------------------------------------------------

_STOP_WORDS = {
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "have", "has", "had", "do", "does", "did", "will", "would", "could",
    "should", "may", "might", "can", "shall", "to", "of", "in", "for",
    "on", "with", "at", "by", "from", "as", "into", "through", "during",
    "before", "after", "above", "below", "between", "out", "off", "over",
    "under", "again", "further", "then", "once", "here", "there", "when",
    "where", "why", "how", "all", "both", "each", "few", "more", "most",
    "other", "some", "such", "no", "nor", "not", "only", "own", "same",
    "so", "than", "too", "very", "just", "about", "up", "down", "and",
    "but", "or", "if", "what", "which", "who", "whom", "this", "that",
    "these", "those", "am", "it", "its", "i", "me", "my", "we", "our",
    "you", "your", "he", "him", "his", "she", "her", "they", "them",
    "their", "tell", "give", "get", "got", "let", "make", "made",
}


def _normalize_query(query: str) -> str:
    """Normalize format variations so searches match regardless of notation style.

    Handles: path separators, abbreviation synonyms, phone number formats.
    """
    import re
    q = query

    # Path normalization — convert Windows paths to include both forms
    # C:\Users\foo → also search C:/Users/foo and /c/Users/foo
    if "\\" in q:
        q = q + " " + q.replace("\\", "/")
    if re.search(r"[A-Z]:/", q):
        # C:/Users/foo → also /c/Users/foo
        q = re.sub(r"([A-Z]):/", lambda m: f"{m.group(0)} /{m.group(1).lower()}/", q)

    # Phone normalization — strip spaces/dashes so +61455363858 matches +61 455 363 858
    phone_match = re.search(r"\+?\d[\d\s\-]{7,}", q)
    if phone_match:
        digits_only = re.sub(r"[\s\-]", "", phone_match.group())
        q = q + " " + digits_only

    # Session continuity phrases → inject session handoff keywords
    continuity_phrases = [
        "where did we leave off", "where were we", "what were we doing",
        "what was i working on", "last session", "pick up where",
        "continue from", "what happened last time", "resume",
    ]
    q_lower = q.lower()
    if any(phrase in q_lower for phrase in continuity_phrases):
        q = q + " session handoff latest"

    # Constraint/rule recall phrases → inject feedback keywords
    constraint_phrases = [
        "should you never", "should i never", "must not", "must never",
        "not allowed to", "forbidden", "what are the rules",
    ]
    if any(phrase in q_lower for phrase in constraint_phrases):
        q = q + " feedback pattern never"

    # Mistake/error handling phrases → inject feedback keywords
    mistake_phrases = [
        "handle mistakes", "handle errors", "when things go wrong",
        "about mistakes", "about errors",
    ]
    if any(phrase in q_lower for phrase in mistake_phrases):
        q = q + " feedback minor issue dismiss"

    return q


# ---------------------------------------------------------------------------
# Query type classification → conditional weight profiles
# ---------------------------------------------------------------------------

def _classify_query(query: str) -> str:
    """Classify query type for selective routing. Returns one of:
    'temporal', 'preference', 'multi_session', 'ss_user', 'ss_assistant',
    'knowledge_update', 'factual' (default).
    No ML — pure keyword pattern matching.

    CONSERVATIVE: only classify as non-factual when strong signal exists.
    False positive hurts more than false negative because 'factual' (full
    pipeline) works reasonably well for all types.

    Routing is derived from LongMemEval Experiment 19 results — each type
    maps to its optimal retrieval pipeline via _get_routing_table().
    """
    q = query.lower()

    # Knowledge update — asking about changes, corrections, updates to facts
    knowledge_update_kw = [
        "changed to", "updated to", "corrected to", "used to be",
        "no longer", "not anymore", "switched from",
        "what changed", "what's different", "what is different",
        "did i change", "did i update", "latest version",
        "most recent", "current value", "new address", "new number",
        "moved to", "changed my",
    ]
    if any(kw in q for kw in knowledge_update_kw):
        return "knowledge_update"

    # Temporal — only strong multi-word signals or explicit date references
    temporal_kw = [
        "last time", "recently", "last week", "last month",
        "yesterday", "today", "first time", "how long ago",
        "timeline", "chronolog", "when did", "what date",
        "how many times", "how often",
    ]
    if any(kw in q for kw in temporal_kw):
        return "temporal"

    # Single-session user recall — asking about what THEY said/did
    ss_user_kw = [
        "did i say", "did i tell", "did i mention", "i told you",
        "i said", "i asked you", "what did i say", "what did i tell",
        "what did i ask", "remember when i said",
    ]
    if any(kw in q for kw in ss_user_kw):
        return "ss_user"

    # Preference — multi-word phrases only
    preference_kw = [
        "do you prefer", "do i prefer", "does he prefer", "does she prefer",
        "my favorite", "your favorite", "their favorite",
        "my favourite", "your favourite",
        "do you like", "do i like", "what do you think of",
        "fan of", "not a fan",
        "always use", "never use",
        "stopped using", "started using",
        "moved away from",
        "opinion on", "opinion about",
    ]
    if any(kw in q for kw in preference_kw):
        return "preference"

    # Single-session assistant recall — asking about what assistant said/recommended
    ss_assistant_kw = [
        "what did you say", "what did you tell", "what did you recommend",
        "you told me", "you said", "you suggested", "you mentioned",
        "your recommendation", "your suggestion", "your advice",
        "what was your", "did you suggest",
    ]
    if any(kw in q for kw in ss_assistant_kw):
        return "ss_assistant"

    # Multi-session — only clear cross-session signals
    multi_kw = [
        "every time", "across all", "across sessions",
        "connection between", "in common", "overlap between",
        "everything about", "all conversations about",
        "summary of all", "how many", "in total",
    ]
    if any(kw in q for kw in multi_kw):
        return "multi_session"

    return "factual"


# Selective routing tables — derived from LongMemEval experiments.
# Each route specifies a fusion method over {FTS, EMB, HYB} result lists.
#   "rrf"            — reciprocal rank fusion with per-type weights
#   "rrf_all"        — RRF with equal weights [1.0, 1.0, 1.0]
#   "hybrid"         — single hybrid (FTS+EMB via RRF)
#   "fts_only"       — FTS5 only (no embeddings)
#   "emb_only"       — embedding search only
#   "consensus"      — multi-method consensus re-ranking
#   "interleave"     — round-robin interleave from FTS, EMB, HYB lists

# MiniLM routing — Experiments 28-37. Ra@5=0.7894 (371/470).
_ROUTING_TABLE_MINILM = {
    "knowledge_update": "rrf",             # RRF with FTS-heavy weights [2.0, 0.5, 1.0]
    "multi_session":    "rrf_all",         # RRF equal weights (n_gold<=2)
    "multi_session_3":  "emb_only",        # embedding-only for n_gold>=3
    "ss_assistant":     "hybrid",          # single hybrid search
    "preference":       "rrf",             # RRF with FTS-heavy weights [2.0, 0.5, 1.0]
    "ss_user":          "rrf",             # RRF with FTS-heavy weights [2.0, 0.5, 1.0]
    "temporal_1":       "fts_only",        # FTS for n_gold=1 temporal
    "temporal":         "consensus",       # consensus re-ranking for n_gold=2 temporal
    "temporal_3":       "rrf_emb_heavy",   # RRF EMB-heavy for n_gold>=3 temporal
    "factual":          "fts_only",        # FTS5 fallback (default)
}

# bge-base routing — Experiment 41. Ra@5=0.8000 (376/470), bucketed n_gold.
_ROUTING_TABLE_BGE_BASE = {
    "knowledge_update": "interleave",      # round-robin interleave (68/72)
    "multi_session":    "hybrid",          # single hybrid (60/75)
    "multi_session_3":  "rrf_emb_heavy",   # EMB-heavy RRF for n_gold>=3 (14/24)
    "ss_assistant":     "emb_only",        # embedding-only (56/56)
    "preference":       "interleave",      # round-robin interleave (21/30)
    "ss_user":          "interleave",      # round-robin interleave (62/64)
    "temporal_1":       "fts_only",        # FTS for n_gold=1 (18/20)
    "temporal":         "hybrid",          # single hybrid for n_gold=2 (67/82)
    "temporal_3":       "rrf_emb_heavy",   # EMB-heavy RRF for n_gold>=3
    "factual":          "fts_only",        # FTS5 fallback (default)
}

# Select routing table based on loaded model
def _get_routing_table():
    if "bge-base" in _EMBEDDING_MODEL:
        return _ROUTING_TABLE_BGE_BASE
    return _ROUTING_TABLE_MINILM

# RRF weight profiles per route
_RRF_WEIGHTS = {
    "rrf":            {"fts": 2.0, "emb": 0.5, "hyb": 1.0},
    "rrf_all":        {"fts": 1.0, "emb": 1.0, "hyb": 1.0},
    "rrf_emb_heavy":  {"fts": 0.5, "emb": 2.0, "hyb": 1.0},
}


# ---------------------------------------------------------------------------
# Passage chunking — split long content into overlapping passages
# ---------------------------------------------------------------------------

def _chunk_content(content: str, chunk_size: int = 5, overlap: int = 2) -> list[tuple[str, float]]:
    """Split content into overlapping passage chunks.

    Returns list of (passage_text, role_weight) tuples.
    User turns get 2x weight, assistant turns get 1x.
    chunk_size = number of lines per chunk, overlap = lines shared between chunks.
    """
    lines = content.strip().split("\n")
    if len(lines) <= chunk_size:
        # Short content — single passage
        weight = 1.5 if any(l.lower().startswith(("user:", "human:")) for l in lines) else 1.0
        return [(content, weight)]

    passages = []
    step = max(1, chunk_size - overlap)
    for i in range(0, len(lines), step):
        chunk_lines = lines[i:i + chunk_size]
        if not chunk_lines:
            break
        text = "\n".join(chunk_lines)
        # Weight based on role — user statements matter more
        user_lines = sum(1 for l in chunk_lines if l.lower().startswith(("user:", "human:")))
        total = len(chunk_lines)
        weight = 1.0 + (user_lines / total) if total > 0 else 1.0
        passages.append((text, weight))

    return passages


def _index_passages(db, memory_id: int, content: str):
    """Create passage-level index entries for a memory."""
    # Clear old passages for this memory
    db.execute("DELETE FROM memory_passages WHERE memory_id=?", (memory_id,))

    passages = _chunk_content(content)
    for idx, (text, weight) in enumerate(passages):
        db.execute(
            "INSERT INTO memory_passages (memory_id, passage_index, content, role_weight) VALUES (?, ?, ?, ?)",
            (memory_id, idx, text, weight)
        )


# ---------------------------------------------------------------------------
# Preference extraction at ingest — sentiment-adjacent keyword detection
# ---------------------------------------------------------------------------

_PREFERENCE_PATTERNS = {
    "POSITIVE": [
        "love", "loved", "loves", "loving",
        "prefer", "preferred", "prefers",
        "favorite", "favourite", "best",
        "enjoy", "enjoyed", "enjoys",
        "always use", "always uses",
        "fan of", "big fan", "huge fan",
        "great", "amazing", "excellent", "perfect",
        "switched to", "moved to", "upgraded to",
        "recommend", "recommends",
    ],
    "NEGATIVE": [
        "hate", "hated", "hates", "hating",
        "dislike", "disliked", "dislikes",
        "worst", "terrible", "awful", "horrible",
        "never use", "never uses", "stopped using",
        "not a fan", "don't like", "doesn't like",
        "avoid", "avoids", "avoided",
        "switched from", "moved away from",
        "dropped", "ditched", "dumped",
    ],
}


def _extract_preferences(content: str) -> list[tuple[str, str, float]]:
    """Extract preference signals from content.

    Returns list of (text_fragment, sentiment, confidence) tuples.
    Pure heuristic — no ML. Scans for sentiment keywords near entity-like words.
    """
    import re
    preferences = []
    sentences = re.split(r'[.!?\n]', content)

    for sentence in sentences:
        s_lower = sentence.lower().strip()
        if len(s_lower) < 5:
            continue

        for sentiment, patterns in _PREFERENCE_PATTERNS.items():
            for pattern in patterns:
                if pattern in s_lower:
                    # Found a preference signal
                    confidence = 0.8 if len(pattern.split()) > 1 else 0.6
                    preferences.append((sentence.strip(), sentiment, confidence))
                    break  # One match per sentence per sentiment

    return preferences


def _store_preference_edges(db, memory_id: int, content: str):
    """Extract preferences from content and store as typed edges in entity_links."""
    prefs = _extract_preferences(content)
    for text_fragment, sentiment, confidence in prefs:
        try:
            db.execute("""
                INSERT INTO entity_links (source_type, source_id, target_type, target_id,
                    relationship, metadata, link_type, created_at)
                VALUES ('memory', ?, 'preference', 0, ?, ?, 'preference', datetime('now'))
            """, (
                memory_id,
                sentiment,
                json.dumps({"text": text_fragment[:200], "confidence": confidence})
            ))
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Semantic Fact Store — Tulving's dual-store (episodic + semantic)
# ---------------------------------------------------------------------------

# Controlled predicate vocabulary — facts must use these
_PREDICATES = {
    "prefers", "dislikes", "works_at", "lives_in", "owns", "uses",
    "knows", "studies", "wants", "has", "likes", "loves", "hates",
    "switched_to", "switched_from", "started", "stopped", "visits",
    "speaks", "plays", "watches", "reads", "eats", "drives",
    "member_of", "born_in", "moved_to", "graduated_from",
}

# SPO extraction patterns: (regex, predicate, fact_type, sentiment)
# Object capture stops at conjunctions/prepositions to avoid greedy trailing noise
_OBJ = r"([\w](?:[\w\s\-']*[\w])?)(?:\s+(?:and|but|or|because|since|so|then|when|while)\s|[.,!?\n]|$)"

_SPO_PATTERNS = [
    # Preferences — positive
    (r"(?:i|user)\s+(?:really\s+)?(?:like|love|enjoy|prefer)\s+" + _OBJ,
     "prefers", "preference", "POSITIVE"),
    (r"(?:my|the user'?s?)\s+(?:favorite|preferred|fav)\s+\w+\s+(?:is|are)\s+" + _OBJ,
     "prefers", "preference", "POSITIVE"),
    (r"(?:i'm|i am)\s+(?:a\s+)?(?:big\s+)?fan\s+of\s+" + _OBJ,
     "likes", "preference", "POSITIVE"),
    # Preferences — negative
    (r"(?:i|user)\s+(?:really\s+)?(?:hate|dislike|can't stand|detest)\s+" + _OBJ,
     "dislikes", "preference", "NEGATIVE"),
    (r"(?:i|user)\s+(?:never|don't|doesn't)\s+(?:use|like|eat|watch|read)\s+" + _OBJ,
     "dislikes", "preference", "NEGATIVE"),
    # State/attributes
    (r"(?:i|user)\s+(?:work|works)\s+(?:at|for)\s+" + _OBJ,
     "works_at", "attribute", "NEUTRAL"),
    (r"(?:i|user)\s+(?:live|lives)\s+(?:in|at)\s+" + _OBJ,
     "lives_in", "attribute", "NEUTRAL"),
    (r"(?:i|user)\s+(?:study|studies|studied)\s+(?:at|in)?\s*" + _OBJ,
     "studies", "attribute", "NEUTRAL"),
    (r"(?:i|user)\s+(?:graduated|grad)\s+(?:from)\s+" + _OBJ,
     "graduated_from", "attribute", "NEUTRAL"),
    (r"(?:i|user)\s+(?:moved|relocated)\s+(?:to)\s+" + _OBJ,
     "moved_to", "attribute", "NEUTRAL"),
    (r"(?:i|user)\s+(?:speak|speaks)\s+" + _OBJ,
     "speaks", "attribute", "NEUTRAL"),
    (r"(?:i|user)\s+(?:drive|drives)\s+(?:a\s+)?" + _OBJ,
     "drives", "attribute", "NEUTRAL"),
    # State changes
    (r"(?:i|user)\s+(?:switched|moved|migrated|changed)\s+(?:to)\s+" + _OBJ,
     "switched_to", "state_change", "NEUTRAL"),
    (r"(?:i|user)\s+(?:switched|moved|migrated|changed)\s+(?:from)\s+" + _OBJ,
     "switched_from", "state_change", "NEUTRAL"),
    (r"(?:i|user)\s+(?:started|began)\s+(?:using|learning|playing|watching|reading)\s+" + _OBJ,
     "started", "state_change", "NEUTRAL"),
    (r"(?:i|user)\s+(?:stopped|quit|gave up)\s+(?:using|playing|watching|reading)?\s*" + _OBJ,
     "stopped", "state_change", "NEUTRAL"),
    # Possessions/relationships
    (r"(?:i|user)\s+(?:have|has|own|owns)\s+(?:a\s+)?" + _OBJ,
     "owns", "attribute", "NEUTRAL"),
    (r"(?:i|user)\s+(?:use|uses|using)\s+" + _OBJ,
     "uses", "attribute", "NEUTRAL"),
]

import re as _re


def _extract_semantic_facts(content: str, memory_id: int = None) -> list[dict]:
    """Extract SPO facts from content using pattern matching.

    Returns list of fact dicts: {subject, predicate, object, fact_type, sentiment, snippet}
    """
    facts = []
    # Split on sentence boundaries AND conjunctions to isolate clauses
    raw_sentences = _re.split(r'[.!?\n]', content)
    sentences = []
    for s in raw_sentences:
        # Further split on " and I " / " but I " to isolate independent clauses
        clauses = _re.split(r'\s+(?:and|but)\s+(?=(?:i|I|user)\s)', s)
        sentences.extend(clauses)
    seen = set()  # Deduplicate within same content

    for sentence in sentences:
        s = sentence.strip()
        if len(s) < 8:
            continue

        for pattern, predicate, fact_type, sentiment in _SPO_PATTERNS:
            match = _re.search(pattern, s, _re.IGNORECASE)
            if match:
                obj = match.group(1).strip()
                # Clean up the object — cap length, strip trailing noise
                obj = _re.sub(r'\s+', ' ', obj)[:100].strip()
                if len(obj) < 2:
                    continue

                # Determine subject (usually "user" for first-person statements)
                subject = "user"

                # Deduplicate
                fact_key = (subject, predicate, obj.lower())
                if fact_key in seen:
                    continue
                seen.add(fact_key)

                facts.append({
                    "subject": subject,
                    "predicate": predicate,
                    "object": obj,
                    "fact_type": fact_type,
                    "sentiment": sentiment,
                    "snippet": s[:200],
                })

    return facts


def _store_semantic_facts(db, memory_id: int, content: str):
    """Extract and store semantic facts from a memory's content.

    Handles deduplication: if a fact with same (subject, predicate, object) already exists,
    adds new evidence instead of creating a duplicate. Updates confidence based on evidence count.
    """
    facts = _extract_semantic_facts(content, memory_id)

    for fact in facts:
        try:
            # Check for existing fact with same SPO
            existing = db.execute("""
                SELECT fact_id, confidence FROM semantic_facts
                WHERE subject=? AND predicate=? AND LOWER(object)=LOWER(?)
                  AND status='ACTIVE'
            """, (fact["subject"], fact["predicate"], fact["object"])).fetchone()

            if existing:
                # Add evidence to existing fact, update confidence
                db.execute("""
                    INSERT INTO fact_evidence (fact_id, source_memory_id, extraction_method,
                        verbatim_snippet, observed_at)
                    VALUES (?, ?, 'pattern', ?, datetime('now'))
                """, (existing[0], memory_id, fact["snippet"]))

                # Recompute confidence based on evidence count
                ev_count = db.execute(
                    "SELECT COUNT(*) FROM fact_evidence WHERE fact_id=?",
                    (existing[0],)
                ).fetchone()[0]
                new_conf = min(0.3 + (ev_count * 0.15), 0.95)

                db.execute("""
                    UPDATE semantic_facts SET confidence=?, updated_at=datetime('now')
                    WHERE fact_id=?
                """, (new_conf, existing[0]))
            else:
                # Check for contradictions (same subject+predicate, different object)
                contradicting = db.execute("""
                    SELECT fact_id, object, confidence FROM semantic_facts
                    WHERE subject=? AND predicate=? AND LOWER(object)!=LOWER(?)
                      AND status='ACTIVE' AND fact_type=?
                """, (fact["subject"], fact["predicate"], fact["object"],
                      fact["fact_type"])).fetchall()

                # Insert new fact
                cursor = db.execute("""
                    INSERT INTO semantic_facts (subject, predicate, object, fact_type,
                        sentiment, confidence, status, created_at, updated_at)
                    VALUES (?, ?, ?, ?, ?, 0.45, 'ACTIVE', datetime('now'), datetime('now'))
                """, (fact["subject"], fact["predicate"], fact["object"],
                      fact["fact_type"], fact["sentiment"]))
                new_fact_id = cursor.lastrowid

                # Add first evidence
                db.execute("""
                    INSERT INTO fact_evidence (fact_id, source_memory_id, extraction_method,
                        verbatim_snippet, observed_at)
                    VALUES (?, ?, 'pattern', ?, datetime('now'))
                """, (new_fact_id, memory_id, fact["snippet"]))

                # Handle contradictions — supersede old if new is more recent
                for old_id, old_obj, old_conf in contradicting:
                    # Only auto-supersede if old confidence isn't very high
                    if old_conf <= 0.9:
                        db.execute("""
                            UPDATE semantic_facts SET status='SUPERSEDED', updated_at=datetime('now')
                            WHERE fact_id=?
                        """, (old_id,))
                        db.execute("""
                            INSERT INTO fact_transitions (old_fact_id, new_fact_id, transition_type)
                            VALUES (?, ?, 'update')
                        """, (old_id, new_fact_id))

        except Exception:
            pass  # Non-critical — episodic store is the primary


# Common abbreviation synonyms — when user searches one form, also match the other
_SYNONYMS = {
    "rrf": "reciprocal rank fusion",
    "fts": "full-text search",
    "mcp": "model context protocol",
    "vps": "virtual private server",
    "pwa": "progressive web app",
    "rn": "react native",
    "ci": "continuous integration",
    "cd": "continuous deployment",
    "db": "database",
    "api": "application programming interface",
    "ui": "user interface",
    "ux": "user experience",
    "llm": "large language model",
    "cve": "common vulnerabilities exposures",
    "grc": "governance risk compliance",
    "cfp": "call for papers",
}


def _sanitize_fts5(query: str) -> str:
    """Sanitize user input for FTS5 MATCH — strip operators, escape quotes."""
    import re
    q = re.sub(r'\b(AND|OR|NOT|NEAR)\b', '', query, flags=re.IGNORECASE)
    q = q.replace('"', '""')
    q = re.sub(r'[{}()*^]', '', q)
    q = q.strip()
    if not q:
        return '""'
    return f'"{q}"'


def _prepare_fts_query(query: str) -> str:
    """Convert natural language query to FTS5 OR query with keywords."""
    import re

    # Normalize format variations first
    query = _normalize_query(query)

    # Sanitize FTS5 operators first to prevent injection
    query = re.sub(r'\b(AND|OR|NOT|NEAR)\b', '', query, flags=re.IGNORECASE)
    query = query.replace('"', '').replace("'", "")
    query = re.sub(r'[{}()*^]', '', query)

    # Strip punctuation except hyphens and underscores
    cleaned = re.sub(r"[^\w\s\-_]", " ", query)
    words = cleaned.lower().split()
    # Remove stop words, keep meaningful terms
    keywords = [w for w in words if w not in _STOP_WORDS and len(w) > 1]
    if not keywords:
        keywords = [w for w in words if len(w) > 1]
    if not keywords:
        return '""'

    # Expand abbreviation synonyms — add synonym words as extra keywords
    expanded = list(keywords)
    for kw in keywords:
        if kw in _SYNONYMS:
            expanded.extend(_SYNONYMS[kw].split())

    # Deduplicate while preserving order
    seen = set()
    unique = []
    for w in expanded:
        if w not in seen:
            seen.add(w)
            unique.append(w)

    # FTS5 OR query — matches any keyword
    return " OR ".join(unique)


def _semantic_search(query: str, limit: int = 50) -> list[dict]:
    """Vector similarity search using sqlite-vec."""
    if not _vec_enabled:
        return []
    db = _get_db()
    query_embedding = _embed(query)
    try:
        rows = db.execute("""
            SELECT v.memory_id, v.distance
            FROM memories_vec v
            WHERE v.embedding MATCH ?
            AND k = ?
        """, (query_embedding, limit)).fetchall()
        # Fetch full memory data for matched IDs
        results = []
        for row in rows:
            mem = db.execute(
                "SELECT * FROM memories WHERE id=? AND active=1 AND status = 'active'", (row[0],)
            ).fetchone()
            if mem:
                d = dict(mem)
                d["vec_distance"] = row[1]
                results.append(d)
        return results
    except Exception:
        return []


def _rrf_fuse(result_lists: list[list[dict]], k: int = 60,
              weights: list[float] = None) -> list[dict]:
    """Reciprocal Rank Fusion — merge multiple ranked lists."""
    if weights is None:
        weights = [1.0] * len(result_lists)

    scores = {}  # memory_id -> (score, memory_dict)
    for weight, results in zip(weights, result_lists):
        for rank, mem in enumerate(results):
            mid = mem["id"]
            rrf_score = weight / (k + rank + 1)
            if mid in scores:
                scores[mid] = (scores[mid][0] + rrf_score, scores[mid][1])
            else:
                scores[mid] = (rrf_score, mem)

    # Sort by fused score descending
    fused = sorted(scores.values(), key=lambda x: x[0], reverse=True)
    return [mem for _, mem in fused]


def _interleave_fuse(result_lists: list[list[dict]]) -> list[dict]:
    """Round-robin interleave from each list, skip duplicates.

    Takes one result from list 0, then list 1, then list 2, etc.
    Repeats until all lists are exhausted. Already-seen IDs are skipped.
    """
    merged = []
    seen_ids = set()
    max_len = max((len(rl) for rl in result_lists), default=0)

    for i in range(max_len):
        for rl in result_lists:
            if i < len(rl):
                mem = rl[i]
                if mem["id"] not in seen_ids:
                    seen_ids.add(mem["id"])
                    merged.append(mem)
    return merged


def _diversity_merge_fuse(result_lists: list[list[dict]]) -> list[dict]:
    """Sequential dedup — take all from first list, then new from second, etc.

    Preserves the full ranking of the first (primary) list, then appends
    only previously unseen results from each subsequent list in order.
    """
    merged = []
    seen_ids = set()

    for rl in result_lists:
        for mem in rl:
            if mem["id"] not in seen_ids:
                seen_ids.add(mem["id"])
                merged.append(mem)
    return merged


def _rrf_merge_fuse(result_lists: list[list[dict]], k: int = 60,
                    weights: list[float] = None) -> list[dict]:
    """Reciprocal Rank Fusion with explicit weights — wrapper matching fusion API.

    Same algorithm as _rrf_fuse but with a distinct name for the exp29 routing
    to make the call sites clear.
    """
    return _rrf_fuse(result_lists, k=k, weights=weights)


def _consensus_rerank(result_lists: list[list[dict]], top_k: int = 15) -> list[dict]:
    """Multi-method consensus re-ranking.

    Scores each memory by: (number of methods that found it) * 2.0 + sum(1/rank).
    Items found by more methods and at higher ranks score higher.
    """
    # Collect all unique memories from top_k of each list
    all_mems = {}  # id -> memory dict
    for rl in result_lists:
        for mem in rl[:top_k]:
            all_mems[mem["id"]] = mem

    # Score each memory
    scores = {}
    for mid in all_mems:
        methods = 0
        rank_score = 0.0
        for rl in result_lists:
            ids_in_list = [m["id"] for m in rl[:top_k]]
            if mid in ids_in_list:
                methods += 1
                rank_score += 1.0 / (ids_in_list.index(mid) + 1)
        scores[mid] = methods * 2.0 + rank_score

    # Sort by consensus score
    ranked = sorted(all_mems.keys(), key=lambda x: scores[x], reverse=True)
    return [all_mems[mid] for mid in ranked]


def _graph_expand(db, seed_memory_ids: list[int], max_expanded: int = 20) -> list[dict]:
    """Path 3: Graph expansion — follow entity_links and co-mention links from seed memories.

    This is the FlyBrain/connectome piece: seed memories discovered via FTS5/semantic
    are expanded by traversing the entity graph to find related memories that wouldn't
    match the query directly but are connected to memories that did.
    """
    if not seed_memory_ids:
        return []

    expanded_ids = set()
    placeholders = ",".join("?" * len(seed_memory_ids))

    # 1) entity_links: memory→memory links (direct graph edges)
    try:
        rows = db.execute(f"""
            SELECT DISTINCT target_id FROM entity_links
            WHERE source_type='memory' AND source_id IN ({placeholders})
              AND target_type='memory'
            UNION
            SELECT DISTINCT source_id FROM entity_links
            WHERE target_type='memory' AND target_id IN ({placeholders})
              AND source_type='memory'
        """, seed_memory_ids + seed_memory_ids).fetchall()
        for r in rows:
            if r[0] not in seed_memory_ids:
                expanded_ids.add(r[0])
    except Exception:
        pass

    # 2) Co-mention expansion: memories sharing entities with seed memories
    try:
        rows = db.execute(f"""
            SELECT DISTINCT me2.memory_id
            FROM memory_entities me1
            JOIN memory_entities me2 ON me1.entity_id = me2.entity_id
            WHERE me1.memory_id IN ({placeholders})
              AND me2.memory_id NOT IN ({placeholders})
            GROUP BY me2.memory_id
            HAVING COUNT(DISTINCT me1.entity_id) >= 2
            ORDER BY COUNT(DISTINCT me1.entity_id) DESC
            LIMIT ?
        """, seed_memory_ids + seed_memory_ids + [max_expanded]).fetchall()
        for r in rows:
            expanded_ids.add(r[0])
    except Exception:
        pass

    if not expanded_ids:
        return []

    # Fetch the expanded memories
    exp_placeholders = ",".join("?" * len(expanded_ids))
    exp_ids = list(expanded_ids)[:max_expanded]
    exp_ph = ",".join("?" * len(exp_ids))
    try:
        results = [dict(r) for r in db.execute(f"""
            SELECT * FROM memories WHERE id IN ({exp_ph}) AND active=1 AND status = 'active'
        """, exp_ids).fetchall()]
        return results
    except Exception:
        return []


def _extract_date_filter(query: str) -> tuple[str, str | None, str | None]:
    """Extract date references from query and return (cleaned_query, date_from, date_to).

    Handles patterns like:
    - "on March 20th" / "on 2026-03-20"
    - "last week" / "yesterday" / "today"
    - "in March" / "in March 2026"
    - "before March 15" / "after March 10"
    """
    import re
    from datetime import datetime, timedelta

    now = datetime.now()
    date_from = None
    date_to = None
    cleaned = query

    # ISO date: "2026-03-20" or "on 2026-03-20"
    iso_match = re.search(r'(?:on\s+)?(\d{4}-\d{2}-\d{2})', query)
    if iso_match:
        d = iso_match.group(1)
        date_from = d + " 00:00:00"
        date_to = d + " 23:59:59"
        cleaned = query.replace(iso_match.group(0), "").strip()
        return cleaned or query, date_from, date_to

    # DD/MM/YYYY (AU/UK) or MM/DD/YYYY (US) — disambiguate by checking if day > 12
    slash_match = re.search(r'(?:on\s+)?(\d{1,2})[/\-.](\d{1,2})[/\-.](\d{4})', query)
    if slash_match:
        a, b, year = int(slash_match.group(1)), int(slash_match.group(2)), int(slash_match.group(3))
        # If first number > 12, it must be DD/MM (AU/UK)
        # If second number > 12, it must be MM/DD (US)
        # If both <= 12, default to DD/MM (AU/UK format)
        if a > 12:
            day, month = a, b  # DD/MM
        elif b > 12:
            month, day = a, b  # MM/DD
        else:
            day, month = a, b  # Default DD/MM (Australian)
        d = f"{year}-{month:02d}-{day:02d}"
        date_from = d + " 00:00:00"
        date_to = d + " 23:59:59"
        cleaned = query.replace(slash_match.group(0), "").strip()
        return cleaned or query, date_from, date_to

    month_names = {
        "january": 1, "february": 2, "march": 3, "april": 4, "may": 5, "june": 6,
        "july": 7, "august": 8, "september": 9, "october": 10, "november": 11, "december": 12
    }
    month_pattern = '|'.join(month_names.keys())

    # "in March" / "in March 2026" — check BEFORE month+day to avoid false match
    in_month = re.search(
        r'in\s+(' + month_pattern + r')(?:\s+(\d{4}))?(?!\s+\d)',
        query.lower()
    )
    if in_month:
        month = month_names[in_month.group(1)]
        year = int(in_month.group(2)) if in_month.group(2) else now.year
        date_from = f"{year}-{month:02d}-01 00:00:00"
        if month == 12:
            date_to = f"{year + 1}-01-01 00:00:00"
        else:
            date_to = f"{year}-{month + 1:02d}-01 00:00:00"
        cleaned = re.sub(re.escape(in_month.group(0)), "", query, flags=re.IGNORECASE).strip()
        return cleaned or query, date_from, date_to

    # Month + day: "March 20" / "March 20th" / "on March 20"
    md_match = re.search(
        r'(?:on\s+)?(' + month_pattern + r')\s+(\d{1,2})(?:st|nd|rd|th)?(?:\s+(\d{4}))?',
        query.lower()
    )
    if md_match:
        month = month_names[md_match.group(1)]
        day = int(md_match.group(2))
        year = int(md_match.group(3)) if md_match.group(3) else now.year
        d = f"{year}-{month:02d}-{day:02d}"
        date_from = d + " 00:00:00"
        date_to = d + " 23:59:59"
        cleaned = re.sub(re.escape(md_match.group(0)), "", query, flags=re.IGNORECASE).strip()
        return cleaned or query, date_from, date_to

    # Relative: "yesterday", "today", "last week"
    q_lower = query.lower()
    if "yesterday" in q_lower:
        d = (now - timedelta(days=1)).strftime("%Y-%m-%d")
        date_from = d + " 00:00:00"
        date_to = d + " 23:59:59"
        cleaned = q_lower.replace("yesterday", "").strip()
    elif "today" in q_lower:
        d = now.strftime("%Y-%m-%d")
        date_from = d + " 00:00:00"
        date_to = d + " 23:59:59"
        cleaned = q_lower.replace("today", "").strip()
    elif "last week" in q_lower:
        date_from = (now - timedelta(days=7)).strftime("%Y-%m-%d") + " 00:00:00"
        date_to = now.strftime("%Y-%m-%d") + " 23:59:59"
        cleaned = q_lower.replace("last week", "").strip()
    elif "this week" in q_lower:
        start = now - timedelta(days=now.weekday())
        date_from = start.strftime("%Y-%m-%d") + " 00:00:00"
        date_to = now.strftime("%Y-%m-%d") + " 23:59:59"
        cleaned = q_lower.replace("this week", "").strip()

    return cleaned or query, date_from, date_to


def _passage_search(db, fts_query: str, pool: int) -> list[dict]:
    """Search passage-level FTS index and map results back to parent memories.

    Passage-level search catches content that would be diluted in full-memory FTS.
    Returns deduplicated list of memory dicts, ordered by best passage match.
    """
    try:
        rows = db.execute("""
            SELECT p.memory_id, p.role_weight, rank AS passage_score
            FROM memory_passages p
            JOIN passages_fts pf ON p.id=pf.rowid
            WHERE passages_fts MATCH ?
            ORDER BY (rank * -1) * p.role_weight DESC
            LIMIT ?
        """, (fts_query, pool * 2)).fetchall()
    except (sqlite3.OperationalError, Exception):
        return []

    if not rows:
        return []

    # Deduplicate — keep best score per memory_id
    seen = {}
    for r in rows:
        mid = r[0]
        if mid not in seen:
            seen[mid] = r

    # Fetch full memory data
    mem_ids = list(seen.keys())[:pool]
    ph = ",".join("?" * len(mem_ids))
    try:
        results = [dict(r) for r in db.execute(
            f"SELECT * FROM memories WHERE id IN ({ph}) AND active=1 AND status = 'active'", mem_ids  # noqa:SQL F-STRING
        ).fetchall()]
        # Preserve passage-ranking order
        id_order = {mid: i for i, mid in enumerate(mem_ids)}
        results.sort(key=lambda r: id_order.get(r["id"], 999))
        return results
    except Exception:
        return []


def _semantic_fact_search(db, query: str, fts_query: str, query_type: str) -> list[dict]:
    """Search semantic fact store and return scored memory IDs.

    The semantic store returns source_memory_ids from fact_evidence, scored by
    fact confidence. Output is the same type as episodic search — scored memory dicts.
    """
    # Soft routing ratios — how much weight to give semantic vs episodic
    semantic_ratios = {
        "preference": 0.75,
        "factual": 0.60,
        "temporal": 0.15,
        "multi_session": 0.30,
    }
    ratio = semantic_ratios.get(query_type, 0.40)

    if ratio < 0.2:
        return []  # Not worth querying semantic store for temporal queries

    try:
        # Search facts FTS
        fact_rows = db.execute("""
            SELECT sf.fact_id, sf.subject, sf.predicate, sf.object,
                   sf.confidence, sf.fact_type, sf.sentiment
            FROM semantic_facts sf
            JOIN facts_fts ff ON sf.fact_id=ff.rowid
            WHERE facts_fts MATCH ? AND sf.status='ACTIVE'
            ORDER BY sf.confidence DESC
            LIMIT 20
        """, (fts_query,)).fetchall()
    except (sqlite3.OperationalError, Exception):
        fact_rows = []

    if not fact_rows:
        return []

    # Get source memory IDs from evidence table, scored by fact confidence
    memory_scores = {}  # memory_id -> best confidence
    for row in fact_rows:
        fact_id = row[0]
        confidence = row[4]
        try:
            evidence = db.execute("""
                SELECT source_memory_id FROM fact_evidence
                WHERE fact_id=?
            """, (fact_id,)).fetchall()
            for ev in evidence:
                mid = ev[0]
                if mid not in memory_scores or confidence > memory_scores[mid]:
                    memory_scores[mid] = confidence
        except Exception:
            pass

    if not memory_scores:
        return []

    # Fetch full memory data for matched IDs
    mem_ids = list(memory_scores.keys())[:20]
    ph = ",".join("?" * len(mem_ids))
    try:
        results = [dict(r) for r in db.execute(
            f"SELECT * FROM memories WHERE id IN ({ph}) AND active=1 AND status = 'active'", mem_ids  # noqa:SQL F-STRING
        ).fetchall()]
        # Sort by fact confidence
        results.sort(key=lambda r: memory_scores.get(r["id"], 0), reverse=True)
        return results
    except Exception:
        return []


def _passage_rerank(db, fts_query: str, results: list[dict], top_n: int = 20) -> list[dict]:
    """Two-stage passage re-ranking: search passages ONLY within candidate sessions.

    Instead of running passage search globally (which causes RRF vote splitting on
    large haystacks), we search passages only within the top-N session-level results.
    Sessions with strong passage matches get boosted; others keep their original rank.
    This bounds passage candidates regardless of haystack size.
    """
    if not results or not fts_query:
        return results

    # Only re-rank within top candidates
    candidates = results[:top_n]
    remainder = results[top_n:]
    candidate_ids = [r["id"] for r in candidates]

    if not candidate_ids:
        return results

    # Search passages only within candidate memories
    ph = ",".join("?" * len(candidate_ids))
    try:
        rows = db.execute(f"""
            SELECT p.memory_id, MAX((rank * -1) * p.role_weight) AS best_score
            FROM memory_passages p
            JOIN passages_fts pf ON p.id=pf.rowid
            WHERE passages_fts MATCH ? AND p.memory_id IN ({ph})
            GROUP BY p.memory_id
            ORDER BY best_score DESC
        """, [fts_query] + candidate_ids).fetchall()
    except (sqlite3.OperationalError, Exception):
        return results

    if not rows:
        return results

    # Build passage boost scores (normalized 0-1)
    passage_scores = {}
    max_score = max(r[1] for r in rows) if rows else 1.0
    for r in rows:
        passage_scores[r[0]] = r[1] / max_score if max_score > 0 else 0.0

    # Re-rank candidates: blend original position with passage score
    # Original rank contributes 70%, passage score 30%
    reranked = []
    for i, r in enumerate(candidates):
        orig_score = 1.0 - (i / len(candidates))  # 1.0 for first, 0.0 for last
        psg_score = passage_scores.get(r["id"], 0.0)
        combined = orig_score * 0.7 + psg_score * 0.3
        reranked.append((combined, r))

    reranked.sort(key=lambda x: x[0], reverse=True)
    return [r for _, r in reranked] + remainder


def _preference_boost(db, query: str, results: list[dict]) -> list[dict]:
    """Boost results that have preference edges when query is preference-shaped."""
    if not results:
        return results

    # Get memory IDs that have preference edges
    mem_ids = [r["id"] for r in results]
    ph = ",".join("?" * len(mem_ids))
    try:
        pref_rows = db.execute(f"""
            SELECT source_id, relationship, metadata FROM entity_links
            WHERE source_type='memory' AND source_id IN ({ph})
              AND link_type='preference'
        """, mem_ids).fetchall()
    except Exception:
        return results

    if not pref_rows:
        return results

    # Build preference score map
    pref_scores = {}
    for row in pref_rows:
        mid = row[0]
        try:
            meta = json.loads(row[2]) if row[2] else {}
            conf = meta.get("confidence", 0.5)
        except Exception:
            conf = 0.5
        pref_scores[mid] = pref_scores.get(mid, 0) + conf

    # Inject preference boost into results ordering
    boosted = []
    for r in results:
        boost = pref_scores.get(r["id"], 0)
        boosted.append((boost, r))
    # Stable sort — preference-rich memories float up within existing ranking
    boosted.sort(key=lambda x: x[0], reverse=True)
    return [r for _, r in boosted]


def _search(query: str, limit: int = 20, search_type: str | None = None) -> list[dict]:
    """Delegates to aibrain_db.search_memories() — the canonical search implementation.

    All fusion strategies, passage reranking, temporal filtering, preference boost,
    salience scoring, and explainable recall are handled by the canonical function.
    """
    import aibrain_db as _adb

    # Ensure aibrain_db uses the same DB connection as mcp_server
    # (important for tests and when DB path is configured externally)
    _sync_db_to_aibrain_db()

    return _adb.search_memories(query, limit=limit, search_type=search_type)


def _sync_db_to_aibrain_db():
    """Ensure aibrain_db module points to the same DB as mcp_server."""
    import aibrain_db as _adb
    if _db_path and str(_adb.DB_PATH) != str(_db_path):
        _adb.DB_PATH = _db_path
        if _adb._conn is not None:
            try:
                _adb._conn.close()
            except Exception:
                pass
            _adb._conn = None
    # Always sync vec-enabled state and embedder so aibrain_db can use vec search
    _adb._db_vec_enabled = _vec_enabled
    if _embedder is not None and _adb._db_embedder is None:
        _adb._db_embedder = _embedder


def _store(name: str, content: str, mem_type: str = "reference",
           tags: str = "", importance: float = 0.5,
           confidence: float | None = None,
           evidence: list[str] | None = None,
           classification: str = "PUBLIC") -> dict:
    """Store a memory. Uses canonical_dedup for embedding-based dedup, then name match.

    Args:
        classification: Data sensitivity tier — PUBLIC | INTERNAL | SENSITIVE | SECRET.
                        Stored on the memory record. Defaults to PUBLIC.
                        Does not affect retrieval; use route_by_classification() for
                        model routing decisions.
    """
    _VALID_CLASSIFICATIONS = {"PUBLIC", "INTERNAL", "SENSITIVE", "SECRET"}
    classification = (classification or "PUBLIC").upper()
    if classification not in _VALID_CLASSIFICATIONS:
        classification = "PUBLIC"
    import aibrain_db as _adb
    db = _get_db()

    # Ensure aibrain_db uses same DB
    _sync_db_to_aibrain_db()

    # Embedding-based dedup via canonical function (fast vec-table lookup)
    dedup_result = _adb.canonical_dedup(content, name=name, threshold=0.92)
    if dedup_result and dedup_result["action"] in ("dedup", "reinforce"):
        return {"action": "none", "id": dedup_result["id"],
                "message": dedup_result["message"]}

    # Check if a memory with this exact name exists (ADD/UPDATE/NONE logic)
    existing = db.execute(
        "SELECT id, content FROM memories WHERE name=? AND active=1", (name,)
    ).fetchone()

    if existing:
        # Decrypt existing content for comparison (plaintext vs plaintext)
        existing_content = existing["content"]
        try:
            from aibrain_encryption import decrypt_on_read
            existing_content, _ = decrypt_on_read(existing_content, "")
        except ImportError:
            pass
        if existing_content.strip() == content.strip():
            # NONE — already known
            return {"action": "none", "id": existing["id"],
                    "message": f"Memory '{name}' already exists with identical content."}
        else:
            # UPDATE — same name, different content
            # Encrypt before writing if enabled
            enc_content, enc_tags = content, tags
            try:
                from aibrain_encryption import encrypt_on_write
                enc_content, enc_tags = encrypt_on_write(content, tags)
            except ImportError:
                pass
            db.execute("""
                UPDATE memories SET content=?, tags=?, importance=?, updated=datetime('now')
                WHERE id=?
            """, (enc_content, enc_tags, importance, existing["id"]))
            db.commit()
            # Re-embed on update
            if _vec_enabled:
                try:
                    embedding = _embed(f"{name} {content}")
                    db.execute(
                        "INSERT OR REPLACE INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
                        (existing["id"], embedding)
                    )
                    db.commit()
                except Exception:
                    pass
            # Re-index passages, preferences, and semantic facts on update
            try:
                _index_passages(db, existing["id"], content)
                _store_preference_edges(db, existing["id"], content)
                _store_semantic_facts(db, existing["id"], content)
                db.commit()
            except Exception:
                pass
            # Fix FTS: if encrypted, trigger indexed ciphertext — replace with plaintext
            if enc_content != content:
                try:
                    db.execute(
                        "INSERT INTO memories_fts(memories_fts, rowid, name, tags, content) "
                        "VALUES ('delete', ?, ?, ?, ?)",
                        (existing["id"], name, enc_tags, enc_content)
                    )
                    db.execute(
                        "INSERT INTO memories_fts(rowid, name, tags, content) VALUES (?, ?, ?, ?)",
                        (existing["id"], name, tags, content)
                    )
                    db.commit()
                except Exception:
                    pass
            # Re-enrich FTS on update
            if _enricher is not None:
                try:
                    enriched = _enrich_for_fts(content, name=name)
                    if enriched != content:
                        db.execute(
                            "INSERT INTO memories_fts(memories_fts, rowid, name, tags, content) "
                            "VALUES ('delete', ?, ?, ?, ?)",
                            (existing["id"], name, tags, content)
                        )
                        db.execute(
                            "INSERT INTO memories_fts(rowid, name, tags, content) VALUES (?, ?, ?, ?)",
                            (existing["id"], name, tags, enriched)
                        )
                        db.commit()
                except Exception:
                    pass
            return {"action": "updated", "id": existing["id"],
                    "message": f"Memory '{name}' updated with new content."}

    # Enrich correction/feedback memories with structured schema
    if mem_type in ("correction", "feedback"):
        try:
            from aibrain.core.correction_schema import enrich_correction
            content = enrich_correction(name, content)
        except Exception:
            pass  # Schema enrichment is best-effort

    # Memory Lifecycle v1.6: classify claim type at write time
    _lifecycle_claim_type = "assertion"
    _lifecycle_plan_deadline = None
    _lifecycle_confidence = confidence
    try:
        from aibrain.core.claim_classifier import classify_claim_type as _classify_ct, extract_plan_deadline as _extract_dl, CLAIM_CONFIDENCE as _CC
        _lifecycle_claim_type = _classify_ct(content)
        _lifecycle_plan_deadline = _extract_dl(content) if _lifecycle_claim_type == "plan" else None
        if _lifecycle_confidence is None:
            _lifecycle_confidence = _CC.get(_lifecycle_claim_type, 0.5)
    except Exception:
        pass  # Classification failure never blocks storage

    # ADD — new memory (encrypt if enabled)
    enc_content, enc_tags = content, tags
    try:
        from aibrain_encryption import encrypt_on_write
        enc_content, enc_tags = encrypt_on_write(content, tags)
    except ImportError:
        pass
    import json as _json
    _evidence_str = _json.dumps(evidence) if evidence is not None else None
    db.execute("""
        INSERT INTO memories (name, type, memory_class, tags, content, importance,
                              confidence, evidence, classification,
                              claim_type, plan_deadline,
                              created, updated, active)
        VALUES (?, ?, 'semantic', ?, ?, ?, ?, ?, ?,
                ?, ?,
                datetime('now'), datetime('now'), 1)
    """, (name, mem_type, enc_tags, enc_content, importance,
          _lifecycle_confidence, _evidence_str, classification,
          _lifecycle_claim_type, _lifecycle_plan_deadline))
    db.commit()
    new_id = db.execute("SELECT last_insert_rowid()").fetchone()[0]

    # Memory Lifecycle v1.6: extract claims + file references
    try:
        from aibrain.core.claim_extractor import extract_claims as _extract_cl, store_claims as _store_cl
        _claims = _extract_cl(new_id, content, _lifecycle_claim_type)
        _store_cl(db, _claims)
    except Exception:
        pass  # Claim extraction failure never blocks storage
    try:
        from aibrain.core.file_reference_extractor import extract_file_references as _extract_fr, store_file_references as _store_fr
        _refs = _extract_fr(content, new_id)
        _store_fr(db, _refs)
    except Exception:
        pass  # File ref extraction failure never blocks storage

    # Trigger confidence decay on correction memories
    if mem_type in ("correction", "feedback"):
        try:
            import aibrain_db as _adb
            _adb.decay_contradicted_memories(content)
        except Exception:
            pass  # Decay is best-effort, never block storage

    # Fix FTS: if encrypted, the trigger indexed ciphertext — replace with plaintext
    if enc_content != content:
        try:
            db.execute(
                "INSERT INTO memories_fts(memories_fts, rowid, name, tags, content) "
                "VALUES ('delete', ?, ?, ?, ?)",
                (new_id, name, enc_tags, enc_content)
            )
            db.execute(
                "INSERT INTO memories_fts(rowid, name, tags, content) VALUES (?, ?, ?, ?)",
                (new_id, name, tags, content)
            )
            db.commit()
        except Exception:
            pass  # FTS fix failure doesn't block storage

    # Generate embedding if available
    if _vec_enabled:
        try:
            embedding = _embed(f"{name} {content}")
            db.execute(
                "INSERT OR REPLACE INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
                (new_id, embedding)
            )
            db.commit()
        except Exception:
            pass  # Embedding failure doesn't block storage

    # Index passages, preferences, and semantic facts
    try:
        _index_passages(db, new_id, content)
        _store_preference_edges(db, new_id, content)
        _store_semantic_facts(db, new_id, content)
        db.commit()
    except Exception:
        pass  # Indexing failure doesn't block storage

    # Auto-build graph edges — related_to links by keyword overlap
    # Disable with env var AIBRAIN_GRAPH_DISABLE=1
    if not os.environ.get("AIBRAIN_GRAPH_DISABLE"):
        try:
            from aibrain.core.graph_memory import auto_link as _auto_link
            _auto_link(new_id, content, top_n=3, db=db)
        except Exception:
            pass  # Graph linking failure never blocks storage

    # Enrich FTS index — overwrite trigger's raw content with enriched version.
    # The trigger already inserted raw content; we delete and re-insert with enrichment.
    # Only enriches FTS — raw content in memories table stays untouched.
    if _enricher is not None:
        try:
            enriched = _enrich_for_fts(content, name=name)
            if enriched != content:
                db.execute(
                    "INSERT INTO memories_fts(memories_fts, rowid, name, tags, content) "
                    "VALUES ('delete', ?, ?, ?, ?)",
                    (new_id, name, tags, content)
                )
                db.execute(
                    "INSERT INTO memories_fts(rowid, name, tags, content) VALUES (?, ?, ?, ?)",
                    (new_id, name, tags, enriched)
                )
                db.commit()
        except Exception:
            pass  # Enrichment failure doesn't block storage

    # Memory Lifecycle v1.6: supersede plan-state memories when a verified_fact is stored
    if _lifecycle_claim_type == "verified_fact":
        try:
            from aibrain.core.memory_lifecycle_hooks import supersede_plans_on_completion
            supersede_plans_on_completion(new_id, content, db)
        except Exception:
            pass  # Supersession failure never blocks storage

    return {"action": "added", "id": new_id,
            "message": f"Memory '{name}' stored (id={new_id})."}


def _recall(mem_type: str | None = None, limit: int = 20) -> list[dict]:
    """Recall memories — core memories (high importance) or filtered by type.

    Results are fetched by importance/access_count/recency, then re-ranked by
    Ebbinghaus decay strength so recent/reinforced memories float above stale
    ones. v1.6 adds lifecycle-aware ranking: staleness scoring, contradiction
    detection, and presentation annotations.
    """
    db = _get_db()
    # Fetch a larger pool so re-ranking + lifecycle filtering has candidates.
    pool_size = max(limit * 3, 50)
    # v1.6: Exclude deprecated memories, rank verified_fact higher
    sql = """SELECT * FROM memories WHERE active=1 AND status = 'active'
             AND COALESCE(claim_type, 'assertion') NOT IN ('deprecated')"""
    params = []
    if mem_type:
        sql += " AND type=?"
        params.append(mem_type)
    sql += """
        ORDER BY
            CASE
                WHEN claim_type = 'verified_fact' THEN 3
                WHEN claim_type = 'observation' THEN 2
                WHEN claim_type = 'assertion' THEN 1
                WHEN claim_type = 'plan' AND (
                    plan_deadline IS NULL
                    OR plan_deadline >= date('now')
                ) THEN 1
                WHEN claim_type = 'plan' AND plan_deadline < date('now') THEN 0
                ELSE 1
            END DESC,
            importance DESC,
            access_count DESC,
            updated DESC
        LIMIT ?
    """
    params.append(pool_size)
    results = [dict(r) for r in db.execute(sql, params).fetchall()]

    # Re-rank by Ebbinghaus decay — blends importance-based score with retention.
    try:
        from aibrain.core.memory_decay import rerank_by_decay
        from datetime import datetime, timezone
        # Assign a synthetic importance score for re-ranking blend.
        for r in results:
            r.setdefault("score", float(r.get("importance") or 0.5))
        results = rerank_by_decay(results, now_ts=datetime.now(timezone.utc), db=db,
                                  blend=0.3, score_key="score")
    except Exception:
        pass  # Decay re-ranking is optional

    # v1.6: Staleness annotation
    try:
        from aibrain.core.memory_lifecycle import annotate_staleness
        from datetime import datetime, timezone
        results = annotate_staleness(results, datetime.now(timezone.utc))
    except Exception:
        pass  # Staleness annotation is optional

    # v1.6: Contradiction detection
    try:
        from aibrain.core.contradiction_detector import detect_contradictions_in_results
        results = detect_contradictions_in_results(results, db)
    except Exception:
        pass  # Contradiction detection is optional

    # v1.6: Blend effective_confidence into score
    for r in results:
        ec = r.get("effective_confidence", 0.5)
        old_score = r.get("score", 0.5)
        r["score"] = old_score * 0.7 + ec * 0.3

    # Sort and trim
    results.sort(key=lambda x: x.get("score", 0), reverse=True)
    results = results[:limit]

    # v1.6: Presentation annotations
    for r in results:
        if r.get("contradiction_flag"):
            r["_display_prefix"] = "[CONTRADICTED] "
        elif r.get("freshness_label") == "expired":
            r["_display_prefix"] = "[STALE] "
        elif r.get("freshness_label") == "stale":
            r["_display_prefix"] = "[AGING] "
        elif r.get("claim_type") == "plan":
            r["_display_prefix"] = "[PLAN] "
        elif r.get("claim_type") == "verified_fact":
            r["_display_prefix"] = "[VERIFIED] "
        else:
            r["_display_prefix"] = ""

    # Track access via update_access_time (non-blocking — don't fail if DB write is locked)
    try:
        from aibrain.core.memory_decay import update_access_time
        for r in results:
            update_access_time(r["id"], db=db)
    except Exception:
        # Fallback to inline SQL update if import fails
        try:
            for r in results:
                db.execute(
                    "UPDATE memories SET access_count=COALESCE(access_count,0)+1, last_accessed=datetime('now') WHERE id=?",
                    (r["id"],)
                )
            if results:
                db.commit()
        except sqlite3.OperationalError:
            pass  # Access tracking is nice-to-have, not critical
    return results


def _cite(memory_id: int) -> dict | None:
    """Fetch the full record for a memory by ID. Returns None if not found."""
    db = _get_db()
    row = db.execute(
        "SELECT * FROM memories WHERE id=? AND active=1", (memory_id,)
    ).fetchone()
    if not row:
        return None
    m = dict(row)
    # Decrypt content/tags for display
    try:
        from aibrain_encryption import decrypt_on_read
        m["content"], m["tags"] = decrypt_on_read(m.get("content", ""), m.get("tags", ""))
    except ImportError:
        pass
    return m


def _build_cited_results(results: list[dict]) -> list[dict]:
    """Convert raw memory dicts into vault-grounded citation objects.

    Each result becomes:
        {"content": str, "memory_id": int, "confidence": float, "type": str}

    Confidence sources (in priority order):
      1. memories.confidence column (explicit epistemic confidence set at store time)
      2. memories.importance × 0.8 (proxy: high-importance memories are likely reliable)
      3. 0.5 (neutral default when neither is set)
    """
    cited = []
    for m in results:
        raw_conf = m.get("confidence")
        if raw_conf is not None:
            try:
                confidence = float(raw_conf)
            except (TypeError, ValueError):
                confidence = None
        else:
            confidence = None

        if confidence is None:
            imp = m.get("importance")
            if imp is not None:
                try:
                    confidence = float(imp) * 0.8
                except (TypeError, ValueError):
                    confidence = 0.5
            else:
                confidence = 0.5

        content = m.get("content", "")
        try:
            from aibrain_encryption import decrypt_on_read
            content, _ = decrypt_on_read(content, m.get("tags", ""))
        except ImportError:
            pass

        cited.append({
            "content": content,
            "memory_id": m["id"],
            "confidence": round(confidence, 4),
            "type": m.get("type", "reference"),
            "name": m.get("name", ""),
        })
    return cited


def _grounding_warning(cited_results: list[dict]) -> str | None:
    """Return a warning string if no cited result has confidence > 0.3, else None."""
    if not cited_results:
        return "No memories found — treat this answer with scepticism"
    if not any(r["confidence"] > 0.3 for r in cited_results):
        return (
            "No high-confidence memories found — treat this answer with scepticism"
        )
    return None


def _stats() -> dict:
    """Memory system stats."""
    db = _get_db()
    total = db.execute("SELECT COUNT(*) FROM memories WHERE active=1 AND status = 'active'").fetchone()[0]
    by_type = {}
    for row in db.execute("SELECT type, COUNT(*) as c FROM memories WHERE active=1 AND status = 'active' GROUP BY type"):
        by_type[row["type"]] = row["c"]
    newest = db.execute("SELECT updated FROM memories WHERE active=1 AND status = 'active' ORDER BY updated DESC LIMIT 1").fetchone()
    oldest = db.execute("SELECT created FROM memories WHERE active=1 AND status = 'active' ORDER BY created ASC LIMIT 1").fetchone()
    # Embedding stats
    embedded = 0
    if _vec_enabled:
        try:
            embedded = db.execute("SELECT COUNT(*) FROM memories_vec").fetchone()[0]
        except Exception:
            pass

    return {
        "total_memories": total,
        "by_type": by_type,
        "newest": newest["updated"] if newest else None,
        "oldest": oldest["created"] if oldest else None,
        "db_path": str(_db_path),
        "embeddings_enabled": _vec_enabled,
        "embedded_memories": embedded,
    }


# ---------------------------------------------------------------------------
# MCP Server
# ---------------------------------------------------------------------------

def _fmt_memory(m: dict) -> str:
    """Format a memory dict for display. Decrypts if encryption is enabled."""
    # Decrypt content and tags for display
    content = m.get("content", "")
    tags = m.get("tags", "")
    try:
        from aibrain_encryption import decrypt_on_read
        content, tags = decrypt_on_read(content, tags)
    except ImportError:
        pass

    lines = [f"[{m['id']}] {m['name']}"]
    if m.get("type"):
        lines[0] += f"  ({m['type']})"
    if tags:
        lines.append(f"  tags: {tags}")
    if m.get("importance"):
        lines.append(f"  importance: {m['importance']}")
    if m.get("confidence") is not None:
        lines.append(f"  confidence: {m['confidence']:.2f}")
    lines.append(f"  updated: {m.get('updated', '?')}")
    lines.append(f"  {content[:500]}")
    return "\n".join(lines)


def create_server() -> "Server":
    if Server is None:
        print("Error: MCP package not installed. Run: pip install aibrain[mcp]", file=__import__('sys').stderr)
        raise SystemExit(1)
    server = Server("aibrain-memory")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        return [
            Tool(
                name="memory_store",
                description=(
                    "Store a new memory or update an existing one. "
                    "Automatically detects duplicates by name: identical content → no-op, "
                    "different content → update, new name → add. "
                    "Use for facts, decisions, preferences, project context, or anything worth remembering."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "name": {
                            "type": "string",
                            "description": "Short identifier for this memory (e.g., 'user_timezone', 'project_goal')"
                        },
                        "content": {
                            "type": "string",
                            "description": "The memory content — what to remember"
                        },
                        "type": {
                            "type": "string",
                            "enum": ["user", "feedback", "project", "reference", "pattern", "decision"],
                            "description": "Memory category. user=about the human, feedback=how to work, project=ongoing work, reference=external pointers, pattern=recurring behavior, decision=choices made",
                            "default": "reference"
                        },
                        "tags": {
                            "type": "string",
                            "description": "Comma-separated tags for filtering (e.g., 'security,important')",
                            "default": ""
                        },
                        "importance": {
                            "type": "number",
                            "description": "0.0 to 1.0 — higher means recalled more often",
                            "default": 0.5,
                            "minimum": 0.0,
                            "maximum": 1.0
                        },
                        "confidence": {
                            "type": "number",
                            "description": "Epistemic confidence in this memory (0.0–1.0). Omit or null = unknown. Stored as-is; reduced by contradiction decay when a correction overwrites related content.",
                            "minimum": 0.0,
                            "maximum": 1.0
                        },
                        "evidence": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Source references supporting this memory. Format: ['memory_id:42', 'url:https://...', 'session:2026-04-13']. Stored as JSON."
                        },
                        "classification": {
                            "type": "string",
                            "enum": ["PUBLIC", "INTERNAL", "SENSITIVE", "SECRET"],
                            "description": (
                                "Data sensitivity classification for this memory. "
                                "PUBLIC — no restrictions (default). "
                                "INTERNAL — cloud routing OK but no-training tier preferred. "
                                "SENSITIVE — local model required; do not send to cloud APIs. "
                                "SECRET — local model only; also masked in logs. "
                                "Used by route_by_classification() when processing this memory."
                            ),
                            "default": "PUBLIC"
                        }
                    },
                    "required": ["name", "content"]
                }
            ),
            Tool(
                name="memory_search",
                description=(
                    "Search memories with selective routing. "
                    "Automatically detects query type and routes to the optimal retrieval pipeline. "
                    "Supports temporal queries: 'on March 20', 'yesterday', 'last week'. "
                    "Use for finding specific facts, context, preferences, or past decisions."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query — keywords, phrases, or questions"
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Max results to return",
                            "default": 10,
                            "minimum": 1,
                            "maximum": 50
                        },
                        "search_type": {
                            "type": "string",
                            "description": "Optional routing hint. Auto-detected if omitted. Values: temporal, preference, multi_session, ss_user, ss_assistant, knowledge_update, factual",
                            "enum": ["temporal", "preference", "multi_session", "ss_user", "ss_assistant", "knowledge_update", "factual"]
                        },
                        "tiered": {
                            "type": "boolean",
                            "description": "Use tiered retrieval (summaries first, then memories, then satellites). Saves tokens for simple/factual queries. Default: false.",
                            "default": False
                        }
                    },
                    "required": ["query"]
                }
            ),
            Tool(
                name="memory_recall",
                description=(
                    "Recall top memories by importance and usage. "
                    "Without a type filter, returns the most important memories across all types. "
                    "Use at conversation start to load context, or to check what's known about a topic."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "type": {
                            "type": "string",
                            "enum": ["user", "feedback", "project", "reference", "pattern", "decision"],
                            "description": "Filter by memory type (optional)"
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Max memories to return",
                            "default": 10,
                            "minimum": 1,
                            "maximum": 50
                        }
                    }
                }
            ),
            Tool(
                name="memory_stats",
                description="Get memory system statistics — total count, breakdown by type, database path.",
                inputSchema={
                    "type": "object",
                    "properties": {}
                }
            ),
            Tool(
                name="task_route",
                description=(
                    "Route any task to its optimal execution strategy. "
                    "Classifies the task by domain (security, jobs, content, email, trading, memory, automation) "
                    "and action (search, scan, publish, trade, report, respond), then dispatches "
                    "to the best backend (CLI, reactive engine, MCP tool, etc.). "
                    "Returns classification, strategy, and execution result."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "task": {
                            "type": "string",
                            "description": "Natural language task description or JSON task object"
                        },
                        "execute": {
                            "type": "boolean",
                            "description": "If true, execute the task. If false, only classify and route (dry run).",
                            "default": False
                        }
                    },
                    "required": ["task"]
                }
            ),
            Tool(
                name="memory_prepare",
                description=(
                    "Prepare a skill briefing before starting a task. "
                    "Returns learned principles, effective approaches, past mistakes, "
                    "and relevant context from prior experience with this task type. "
                    "Call this at the START of any task for best results."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "task_type": {
                            "type": "string",
                            "description": "Type of task (e.g., 'code_review', 'email_draft', 'data_analysis')"
                        },
                        "context": {
                            "type": "string",
                            "description": "Current task context for relevance filtering",
                            "default": ""
                        }
                    },
                    "required": ["task_type"]
                }
            ),
            Tool(
                name="memory_ingest",
                description=(
                    "Ingest a conversation transcript for automatic memory extraction. "
                    "Extracts decisions, preferences, context, and completed tasks. "
                    "Call at the END of a session with the conversation text."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "transcript": {
                            "type": "string",
                            "description": "Full conversation transcript"
                        },
                        "session_id": {
                            "type": "string",
                            "description": "Session identifier",
                            "default": ""
                        }
                    },
                    "required": ["transcript"]
                }
            ),
            Tool(
                name="memory_forget",
                description=(
                    "Permanently forget everything about a topic. Cascading delete "
                    "across all tables: memories, FTS, embeddings, passages, facts, "
                    "entity links. Cannot be undone. Use for privacy compliance."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Topic to forget — all matching memories will be permanently deleted"
                        },
                        "dry_run": {
                            "type": "boolean",
                            "description": "If true, preview what would be deleted without deleting",
                            "default": True
                        }
                    },
                    "required": ["query"]
                }
            ),
            Tool(
                name="memory_cite",
                description=(
                    "Fetch the full record for a specific memory by its ID. "
                    "Use to verify a citation returned by memory_search or memory_recall. "
                    "Bennett's vault-grounded protocol: 'If the AI gives you an answer about "
                    "your work, ask it which file it found that in. If it can\\'t cite one, "
                    "treat it with scepticism.' — this tool is the verification step."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "memory_id": {
                            "type": "integer",
                            "description": "The memory_id returned by memory_search or memory_recall"
                        }
                    },
                    "required": ["memory_id"]
                }
            ),
            Tool(
                name="file_reference_search",
                description=(
                    "Semantic file search — find files relevant to a natural language query. "
                    "Returns file paths from the file_references index, linked to memories. "
                    "Much faster than blind grep/glob across the filesystem."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Natural language query (e.g. 'wintermute architecture', 'selroute paper')"
                        }
                    },
                    "required": ["query"]
                }
            ),
            Tool(
                name="file_reference_topic",
                description=(
                    "Get all files for a specific topic. Returns file paths indexed under "
                    "the given topic name (e.g. 'wintermute', 'aibrain', 'selroute')."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "topic": {
                            "type": "string",
                            "description": "Topic name (e.g. 'wintermute', 'aibrain', 'permeate', 'selroute')"
                        },
                        "include_stale": {
                            "type": "boolean",
                            "description": "Include files that were missing at last verification check",
                            "default": False
                        }
                    },
                    "required": ["topic"]
                }
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        try:
            if name == "memory_store":
                result = _store(
                    name=arguments["name"],
                    content=arguments["content"],
                    mem_type=arguments.get("type", "reference"),
                    tags=arguments.get("tags", ""),
                    importance=arguments.get("importance", 0.5),
                    confidence=arguments.get("confidence"),
                    evidence=arguments.get("evidence"),
                    classification=arguments.get("classification", "PUBLIC"),
                )
                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            elif name == "memory_search":
                _query = arguments["query"]
                _limit = arguments.get("limit", 10)
                _stype = arguments.get("search_type")
                _tiered = arguments.get("tiered", False)
                # Input validation
                if not _query or len(_query) > 2000:
                    return [TextContent(type="text", text="Error: query must be 1-2000 characters.")]
                if not isinstance(_limit, int) or not 1 <= _limit <= 50:
                    _limit = min(max(int(_limit), 1), 50) if _limit else 10
                _VALID_SEARCH_TYPES = {None, "temporal", "preference", "multi_session",
                                        "ss_user", "ss_assistant", "knowledge_update", "factual"}
                if _stype not in _VALID_SEARCH_TYPES:
                    _stype = None

                # Auto-enable tiered search for simple factual/preference queries
                if not _tiered and _stype in (None, "factual", "preference"):
                    from aibrain_db import classify_query as _cq
                    auto_type = _cq(_query)
                    if auto_type in ("factual", "preference"):
                        _tiered = True

                if _tiered:
                    import aibrain_db as _adb
                    tiered_result = _adb.tiered_search(
                        query=_query,
                        limit=_limit,
                    )
                    results = tiered_result.get("results", [])
                    tier = tiered_result.get("tier_used", 0)
                    reason = tiered_result.get("reason", "")
                    tokens_saved = tiered_result.get("tokens_saved", 0)
                    if not results:
                        return [TextContent(type="text", text="No memories found matching that query.")]
                    # Format based on tier
                    if tier == 1:
                        # Category summaries
                        parts = []
                        for r in results:
                            parts.append(
                                f"**{r.get('category', '?')}** ({r.get('memory_count', 0)} memories, "
                                f"score={r.get('score', 0):.2f})\n{r.get('summary', '')[:500]}"
                            )
                        formatted = "\n\n---\n\n".join(parts)
                    else:
                        formatted = "\n\n---\n\n".join(_fmt_memory(m) for m in results)
                    header = f"Tiered search: {reason}"
                    if tokens_saved > 0:
                        header += f" (~{tokens_saved} tokens saved)"
                    return [TextContent(type="text", text=f"{header}\n\n{formatted}")]

                results = _search(
                    query=_query,
                    limit=_limit,
                    search_type=_stype,
                )
                if not results:
                    no_result_payload = {
                        "count": 0,
                        "results": [],
                        "grounding_warning": "No memories found — treat this answer with scepticism",
                    }
                    return [TextContent(type="text", text=json.dumps(no_result_payload, indent=2))]
                cited = _build_cited_results(results)
                warning = _grounding_warning(cited)
                payload = {
                    "count": len(cited),
                    "results": cited,
                }
                if warning:
                    payload["grounding_warning"] = warning
                return [TextContent(type="text", text=json.dumps(payload, indent=2))]

            elif name == "memory_recall":
                results = _recall(
                    mem_type=arguments.get("type"),
                    limit=arguments.get("limit", 10),
                )
                if not results:
                    return [TextContent(type="text", text=json.dumps({
                        "count": 0,
                        "results": [],
                        "grounding_warning": "No memories stored yet — treat this answer with scepticism",
                    }, indent=2))]
                cited = _build_cited_results(results)
                warning = _grounding_warning(cited)
                payload = {
                    "count": len(cited),
                    "results": cited,
                }
                if warning:
                    payload["grounding_warning"] = warning
                return [TextContent(type="text", text=json.dumps(payload, indent=2))]

            elif name == "memory_stats":
                stats = _stats()
                return [TextContent(type="text", text=json.dumps(stats, indent=2))]

            elif name == "task_route":
                from task_router import classify, route, create_router
                task_text = arguments["task"]
                should_execute = arguments.get("execute", False)

                task_type = classify(task_text)
                strategy = route(task_type)

                result_info = {
                    "classification": {
                        "domain": task_type.domain,
                        "action": task_type.action,
                        "complexity": task_type.complexity,
                        "confidence": task_type.confidence,
                        "key": task_type.key,
                    },
                    "strategy": {
                        "name": strategy.name,
                        "backend": strategy.backend,
                        "graph": strategy.graph_name,
                        "tools": strategy.tool_chain,
                        "key": strategy.key,
                    },
                }

                if should_execute:
                    import asyncio
                    router = create_router(db_path=str(_DB_PATH))
                    exec_result = await router.execute(task_text)
                    result_info["execution"] = {
                        "success": exec_result.success,
                        "backend_used": exec_result.backend_used,
                        "duration_s": round(exec_result.duration_s, 2),
                        "error": exec_result.error or None,
                        "output_preview": str(exec_result.output)[:2000] if exec_result.output else None,
                    }

                return [TextContent(type="text", text=json.dumps(result_info, indent=2))]

            elif name == "memory_prepare":
                from skill_memory import SkillMemory
                sm = SkillMemory(str(_DB_PATH))
                briefing = sm.prepare(
                    task_type=arguments["task_type"],
                    context=arguments.get("context", ""),
                )
                return [TextContent(type="text", text=briefing["briefing"])]

            elif name == "memory_ingest":
                from conversation_observer import ConversationObserver
                observer = ConversationObserver(str(_DB_PATH))
                result = observer.ingest_transcript(
                    transcript=arguments["transcript"],
                    session_id=arguments.get("session_id", ""),
                )
                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            elif name == "memory_forget":
                from memory_lifecycle import MemoryLifecycle
                ml = MemoryLifecycle(str(_DB_PATH))
                result = ml.forget(
                    query=arguments["query"],
                    dry_run=arguments.get("dry_run", True),
                )
                return [TextContent(type="text", text=json.dumps(result, indent=2))]

            elif name == "memory_cite":
                _mid = arguments.get("memory_id")
                if not isinstance(_mid, int) or _mid < 1:
                    return [TextContent(type="text", text=json.dumps(
                        {"error": "memory_id must be a positive integer"}, indent=2
                    ))]
                record = _cite(_mid)
                if record is None:
                    return [TextContent(type="text", text=json.dumps(
                        {"error": f"No memory found with id={_mid}"}, indent=2
                    ))]
                # Return full record with key citation fields prominently listed
                cited_record = {
                    "memory_id": record["id"],
                    "name": record.get("name", ""),
                    "content": record.get("content", ""),
                    "type": record.get("type", "reference"),
                    "confidence": record.get("confidence"),
                    "importance": record.get("importance"),
                    "tags": record.get("tags", ""),
                    "created": record.get("created"),
                    "updated": record.get("updated"),
                    "evidence": record.get("evidence"),
                }
                return [TextContent(type="text", text=json.dumps(cited_record, indent=2))]

            elif name == "file_reference_search":
                from aibrain.core.file_reference_extractor import search_files_by_query
                _fdb = _get_db()
                _fq = arguments.get("query", "")
                _fresults = search_files_by_query(_fq, _fdb)
                return [TextContent(type="text", text=json.dumps(_fresults, indent=2, default=str))]

            elif name == "file_reference_topic":
                from aibrain.core.file_reference_extractor import get_files_for_topic
                _fdb = _get_db()
                _ft = arguments.get("topic", "")
                _fstale = arguments.get("include_stale", False)
                _fresults = get_files_for_topic(_ft, _fdb, include_stale=_fstale)
                return [TextContent(type="text", text=json.dumps(_fresults, indent=2, default=str))]

            else:
                return [TextContent(type="text", text=f"Unknown tool: {name}")]

        except Exception as e:
            return [TextContent(type="text", text=f"Error: {type(e).__name__}: {e}")]

    return server


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def _backfill_embeddings(batch_size: int = 64):
    """Embed all memories that don't yet have embeddings."""
    if not _vec_enabled:
        return 0
    db = _get_db()
    rows = db.execute("""
        SELECT m.id, m.name, m.content FROM memories m
        WHERE m.active=1 AND m.id NOT IN (SELECT memory_id FROM memories_vec)
    """).fetchall()
    if not rows:
        return 0
    count = 0
    for i in range(0, len(rows), batch_size):
        batch = rows[i:i + batch_size]
        texts = [f"{r['name']} {r['content']}" for r in batch]
        embeddings = _embed_batch(texts)
        for r, emb in zip(batch, embeddings):
            try:
                db.execute(
                    "INSERT OR REPLACE INTO memories_vec (memory_id, embedding) VALUES (?, ?)",
                    (r["id"], emb)
                )
                count += 1
            except Exception:
                pass
        db.commit()
    return count


def _get_current_profile_name() -> "str | None":
    """Return the current Claude Code profile name, or None for the primary profile.

    Claude Code sets CLAUDE_CONFIG_DIR to the active profile directory
    (e.g. ~/.claude-work, ~/.claude-security). The profile name is the
    directory name without the ~/.claude- prefix.

    Returns None when running in the primary profile (CLAUDE_CONFIG_DIR not set).
    """
    config_dir = os.environ.get("CLAUDE_CONFIG_DIR", "")
    if not config_dir:
        return None
    return Path(config_dir).name


def _apply_profile_mode_override(resolved_db: Path) -> Path:
    """Return the DB path for the current profile, applying isolated-mode override if needed.

    Profile-level separation via DB path override — not OS-level process isolation.
    For isolated profiles: returns the profile-specific DB path from profiles.json.
    For hive profiles or unregistered profiles: returns resolved_db unchanged.

    Fail-safe: any exception returns resolved_db unchanged.
    """
    try:
        profile_name = _get_current_profile_name()
        if not profile_name:
            return resolved_db  # Primary profile — no override

        # Import here to avoid circular import issues at module load time
        from aibrain.core import profile_registry
        entry = profile_registry.get_profile_entry(profile_name)
        if entry is None:
            return resolved_db  # Unregistered profile — hive behavior by default

        if entry.get("mode") != "isolated":
            return resolved_db  # Hive profile — shared brain

        db_path_str = entry.get("db_path")
        if not db_path_str:
            print(
                f"[aibrain-mcp] WARNING: isolated profile '{profile_name}' has no db_path in registry"
                " — falling back to default DB",
                file=sys.stderr,
            )
            return resolved_db

        override = Path(db_path_str)
        print(
            f"[aibrain-mcp] Isolated profile '{profile_name}' — using dedicated DB: {override}",
            file=sys.stderr,
        )
        return override
    except Exception as exc:
        print(
            f"[aibrain-mcp] WARNING: profile mode override failed ({exc}) — using default DB",
            file=sys.stderr,
        )
        return resolved_db


def _is_isolated_profile() -> bool:
    """Return True if the current profile is registered as isolated.

    Profile-level separation via DB path override — not OS-level process isolation.
    Returns False on any exception so startup is never blocked.
    """
    try:
        profile_name = _get_current_profile_name()
        if not profile_name:
            return False
        from aibrain.core import profile_registry
        return profile_registry.is_isolated(profile_name)
    except Exception:
        return False


def _auto_link_projects_dir() -> None:
    """Silently ensure this profile's projects/ dir points to the primary ~/.claude/projects/.

    When a user creates a second Claude Code profile (CLAUDE_CONFIG_DIR=~/.claude-work etc.)
    Claude Code writes MEMORY.md and other auto-memory files into that profile's own projects/
    subdirectory — completely isolated from the primary profile.  This causes silent data loss
    because memories written in one profile are invisible in the other.

    Fix: detect when we're running inside a non-primary config dir and symlink (or junction on
    Windows) its projects/ folder to ~/.claude/projects/ so all profiles share one memory store.
    Runs every startup — idempotent and silent unless something needs fixing.
    Isolated profiles are skipped — they intentionally maintain their own projects/ dir.
    """
    try:
        if _is_isolated_profile():
            print("[aibrain-mcp] Isolated profile — skipping projects/ link", file=sys.stderr)
            return

        home = Path.home()
        primary_projects = home / ".claude" / "projects"
        if not primary_projects.exists():
            return  # Primary not set up yet — nothing to link to

        # Detect current config dir from env (Claude Code sets CLAUDE_CONFIG_DIR)
        config_dir_env = os.environ.get("CLAUDE_CONFIG_DIR", "")
        if config_dir_env:
            current_config = Path(config_dir_env)
        else:
            current_config = home / ".claude"

        # Nothing to do if we're already in the primary config dir
        if current_config.resolve() == (home / ".claude").resolve():
            return

        current_projects = current_config / "projects"

        # Already correctly linked — nothing to do
        if current_projects.is_symlink():
            if current_projects.resolve() == primary_projects.resolve():
                return
            # Symlink points elsewhere — leave it alone (user may have intentional setup)
            print(f"[aibrain-mcp] NOTE: {current_projects} is a symlink to a non-primary location — leaving as-is", file=sys.stderr)
            return

        if current_projects.exists():
            # Real directory — only replace if it's empty (no MEMORY.md files)
            memory_files = list(current_projects.rglob("MEMORY.md"))
            if memory_files:
                print(f"[aibrain-mcp] WARNING: {current_projects} has diverged MEMORY.md files — run 'aibrain_db.py doctor' to merge", file=sys.stderr)
                return
            try:
                current_projects.rmdir()  # only works if truly empty
            except OSError:
                return  # non-empty, leave it

        # Create the link
        try:
            current_projects.symlink_to(primary_projects)
            print(f"[aibrain-mcp] Auto-linked {current_projects} → {primary_projects} (shared memory)", file=sys.stderr)
        except (OSError, NotImplementedError):
            # Windows may need a directory junction (no admin required)
            try:
                import subprocess as _sp
                _sp.run(
                    ["cmd", "/c", "mklink", "/J",
                     str(current_projects), str(primary_projects)],
                    check=True, capture_output=True
                )
                print(f"[aibrain-mcp] Auto-linked {current_projects} → {primary_projects} (junction, shared memory)", file=sys.stderr)
            except Exception:
                pass  # Silent — doctor can fix manually
    except Exception:
        pass  # Never crash startup due to link logic


def _auto_sync_mcp_servers() -> None:
    """Silently sync mcpServers from the primary ~/.claude.json into the current profile's .claude.json.

    When switching profiles (CLAUDE_CONFIG_DIR=~/.claude-work etc.) Claude Code reads MCP server
    config from that profile's own .claude.json — not the primary one.  This means a fresh profile
    has no MCPs loaded, silently breaking the entire stack.

    Fix: on every MCP server startup, copy mcpServers from ~/.claude.json into the current profile's
    .claude.json so all profiles always have the same servers.  Idempotent — no-ops if already in sync.
    Silent on success; logs only if something changes or goes wrong.
    Isolated profiles are skipped — they carry their own .claude.json with explicit --db.
    """
    try:
        if _is_isolated_profile():
            print("[aibrain-mcp] Isolated profile — skipping MCP sync", file=sys.stderr)
            return

        home = Path.home()
        main_state = home / ".claude.json"
        if not main_state.exists():
            return  # Nothing to sync from

        config_dir_env = os.environ.get("CLAUDE_CONFIG_DIR", "")
        if config_dir_env:
            current_config = Path(config_dir_env)
        else:
            current_config = home / ".claude"

        # Nothing to do for the primary profile — it IS the source of truth
        if current_config.resolve() == (home / ".claude").resolve():
            return

        profile_state = current_config / ".claude.json"
        if not current_config.exists():
            return  # Profile dir doesn't exist yet — nothing to do

        # Read main state
        try:
            with open(main_state, encoding="utf-8") as f:
                main_data = json.load(f)
        except Exception:
            return

        mcp_servers = main_data.get("mcpServers", {})
        if not mcp_servers:
            return  # No MCPs in main profile — nothing to push

        # Read or init profile state
        if profile_state.exists():
            try:
                with open(profile_state, encoding="utf-8") as f:
                    profile_data = json.load(f)
            except Exception:
                profile_data = {}
        else:
            profile_data = {}

        # Already in sync — no-op
        if profile_data.get("mcpServers") == mcp_servers:
            return

        profile_data["mcpServers"] = mcp_servers
        try:
            with open(profile_state, "w", encoding="utf-8") as f:
                json.dump(profile_data, f, indent=2, ensure_ascii=False)
            profile_name = current_config.name
            print(f"[aibrain-mcp] Auto-synced {len(mcp_servers)} MCP servers → {profile_name}/.claude.json", file=sys.stderr)
        except Exception as e:
            print(f"[aibrain-mcp] WARNING: Could not sync mcpServers to {profile_state}: {e}", file=sys.stderr)
    except Exception:
        pass  # Never crash startup due to sync logic


async def main():
    global _db_path

    parser = argparse.ArgumentParser(description="AIBrain Memory MCP Server")
    parser.add_argument("--db", type=str, default=None,
                        help="Path to SQLite database (default: ~/aibrain.db)")
    parser.add_argument("--backfill", action="store_true",
                        help="Backfill embeddings for existing memories and exit")
    parser.add_argument("--backfill-enrichment", action="store_true",
                        help="Re-enrich FTS index for all existing memories and exit")
    args = parser.parse_args()

    if args.db:
        _db_path = Path(args.db)
    elif "AIBRAIN_DB" in os.environ:
        _db_path = Path(os.environ["AIBRAIN_DB"])
    else:
        # Use location-priority order — NOT file size — to select the real brain.
        # "Largest wins" is wrong: a shadow stub that grows (e.g. benchmark writes)
        # would silently beat the real DB.  Priority: AIBRAIN_ROOT > ~/projects/aibrain > ~/aibrain.
        # We only skip symlinks (security) and non-existent paths.
        priority_candidates = []
        if "AIBRAIN_ROOT" in os.environ:
            priority_candidates.append(Path(os.environ["AIBRAIN_ROOT"]) / "aibrain.db")
        priority_candidates += [
            Path.home() / "projects" / "aibrain" / "aibrain.db",
            Path.home() / "aibrain" / "aibrain.db",
        ]
        # Fix #6: treat zero-byte DB files as non-existent (ghost DBs from failed inits
        # would otherwise trigger a spurious multi-DB warning and wrong DB selection).
        found = [p for p in priority_candidates if p.exists() and not p.is_symlink() and p.stat().st_size > 0]
        if found:
            _db_path = found[0]  # first existing in priority order wins
            if len(found) > 1:
                others = ", ".join(str(p) for p in found[1:])
                print(f"[aibrain-mcp] Multiple DBs found — using priority: {_db_path} (others: {others})", file=sys.stderr)
                print(f"[aibrain-mcp] Run 'python aibrain_db.py doctor' to consolidate.", file=sys.stderr)
        else:
            _db_path = Path.home() / "aibrain" / "aibrain.db"  # fresh install default
        if not args.db and "AIBRAIN_DB" not in os.environ:
            print(f"[aibrain-mcp] WARNING: No explicit --db passed. Using fallback: {_db_path}", file=sys.stderr)

    # Apply isolated profile DB override (profile-level separation via DB path override —
    # not OS-level process isolation). For hive/unregistered profiles this is a no-op.
    _db_path = _apply_profile_mode_override(_db_path)

    print(f"[aibrain-mcp] DB: {_db_path.name} ({_db_path.stat().st_size//1024}KB)" if _db_path.exists() else f"[aibrain-mcp] DB: {_db_path} (new)", file=sys.stderr)

    # Auto-repair: ensure this profile's projects/ dir is shared with the primary
    # Claude config dir so MEMORY.md and all auto-memory files stay in one place.
    # This runs silently on every startup — no user action required.
    _auto_link_projects_dir()

    # Auto-sync: copy mcpServers from primary ~/.claude.json into current profile's
    # .claude.json so switching profiles never breaks the MCP stack.
    _auto_sync_mcp_servers()

    # Initialize embedder FIRST — schema needs embedding dimension for vec table
    _init_embedder()

    # Initialize storage enricher (V2 vocabulary expansion for FTS5)
    _init_enricher()

    # Ensure DB exists and schema is ready (uses embedding dim from loaded model)
    _get_db()

    if args.backfill:
        if not _vec_enabled:
            print("Embeddings not available (install sqlite-vec + sentence-transformers)")
            sys.exit(1)
        count = _backfill_embeddings()
        stats = _stats()
        print(f"Backfilled {count} embeddings. Total embedded: {stats['embedded_memories']}/{stats['total_memories']}")
        sys.exit(0)

    if getattr(args, 'backfill_enrichment', False):
        if _enricher is None:
            print("Enricher not available (storage_enricher.py not found)")
            sys.exit(1)
        db = _get_db()
        rows = db.execute("SELECT id, name, content, tags FROM memories WHERE active=1").fetchall()
        enriched_count = 0
        for row in rows:
            try:
                enriched = _enrich_for_fts(row["content"], name=row["name"])
                if enriched != row["content"]:
                    db.execute(
                        "INSERT INTO memories_fts(memories_fts, rowid, name, tags, content) "
                        "VALUES ('delete', ?, ?, ?, ?)",
                        (row["id"], row["name"], row["tags"] or "", row["content"])
                    )
                    db.execute(
                        "INSERT INTO memories_fts(rowid, name, tags, content) VALUES (?, ?, ?, ?)",
                        (row["id"], row["name"], row["tags"] or "", enriched)
                    )
                    enriched_count += 1
            except Exception:
                pass
        db.commit()
        print(f"Enriched {enriched_count}/{len(rows)} memories in FTS index")
        sys.exit(0)

    # Backfill any missing embeddings on startup
    if _vec_enabled:
        backfilled = _backfill_embeddings()
        if backfilled > 0:
            import sys as _sys
            print(f"Backfilled {backfilled} embeddings on startup", file=_sys.stderr)

    server = create_server()
    async with stdio_server() as (read_stream, write_stream):
        await server.run(read_stream, write_stream, server.create_initialization_options())


def _mcp_entry():
    """Sync entry point for the aibrain-mcp console_scripts entry point.

    pyproject.toml points to this function so pip-installed callers get a
    proper sync wrapper around the async main().  Calling async main()
    directly as an entry point returns a coroutine and emits
    'RuntimeWarning: coroutine was never awaited'.
    """
    if not _MCP_AVAILABLE:
        print("Error: MCP package not installed. Run: pip install aibrain[mcp]", file=sys.stderr)
        sys.exit(1)
    import asyncio
    asyncio.run(main())


if __name__ == "__main__":
    _mcp_entry()
