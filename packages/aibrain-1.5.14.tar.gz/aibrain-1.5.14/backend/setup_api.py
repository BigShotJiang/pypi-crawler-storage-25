"""
AIBrain Setup Wizard API — FastAPI router for guided first-run configuration.

Steps:
  1. system_check   — Python version, packages, disk space, DB access
  2. email_config   — IMAP/SMTP credential validation
  3. location       — lat/lon for weather (auto-detect or manual)
  4. llm_provider   — Claude/OpenAI/local API key (optional)
  5. workflows      — pick which workflows to enable
  6. first_run      — execute morning briefing as smoke test

All step state persists in aibrain.db (setup_steps table).
Config values read/write to config.json at AIBRAIN_ROOT.
"""

import asyncio
import base64
import hashlib
import imaplib
import json
import logging
import os
import platform
import secrets
import shutil
import smtplib
import sqlite3
import subprocess
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from fastapi import APIRouter, Body, Query, Request
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse

# ---------------------------------------------------------------------------
# URL validation — reuse from security module
# ---------------------------------------------------------------------------
try:
    from security import validate_url as _validate_url
except ImportError:
    def _validate_url(url: str) -> tuple[bool, str]:
        """Fallback SSRF check when security module unavailable."""
        from urllib.parse import urlparse as _up
        try:
            p = _up(url.strip())
            if p.scheme not in ("http", "https"):
                return False, f"Blocked scheme: {p.scheme}"
            if not p.hostname:
                return False, "No hostname"
            return True, "ok"
        except Exception:
            return False, "Malformed URL"

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------
AIBRAIN_ROOT = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent))
sys.path.insert(0, str(AIBRAIN_ROOT))
sys.path.insert(0, str(Path(__file__).parent))

import aibrain_db

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/setup", tags=["setup"])

# ---------------------------------------------------------------------------
# Setup token — one-time secret printed to console on first startup.
# Required for all setup POST endpoints to prevent unauthorised config writes.
# ---------------------------------------------------------------------------
_setup_token: str | None = None


def get_or_create_setup_token() -> str:
    """Return the current setup token, generating one if needed.

    The token is ephemeral (lives in memory only) — it's printed to the
    console when the API starts.  Anyone who can't see the console can't
    use setup endpoints.
    """
    global _setup_token
    if _setup_token is None:
        import secrets as _sec
        _setup_token = _sec.token_urlsafe(24)
        logger.info("Setup token generated — required for POST /api/setup/* endpoints")
    return _setup_token


def _require_setup_auth(request: Request) -> bool:
    """Check X-Setup-Token header matches the ephemeral setup token.

    Returns True if valid, False otherwise.
    """
    token = request.headers.get("X-Setup-Token", "")
    import hmac as _hmac
    return _hmac.compare_digest(token, get_or_create_setup_token())

CONFIG_PATH = AIBRAIN_ROOT / "config.json"


def _require_localhost(request: Request) -> bool:
    """Setup endpoints: localhost-only access."""
    client_host = request.client.host if request.client else ""
    return client_host in ("127.0.0.1", "::1", "localhost")
DB_PATH = AIBRAIN_ROOT / "aibrain.db"

# Step definitions — order matters for the wizard UI
STEPS = [
    {"key": "system_check", "label": "System Check", "order": 1},
    {"key": "email_config", "label": "Email Configuration", "order": 2},
    {"key": "location", "label": "Location Setup", "order": 3},
    {"key": "llm_provider", "label": "LLM Provider", "order": 4},
    {"key": "workflows", "label": "Initial Workflows", "order": 5},
    {"key": "first_run", "label": "First Run", "order": 6},
]

SENSITIVE_KEYS = {
    "email_app_password", "agent_email_password", "api_key",
    "anthropic_api_key", "openai_api_key", "password",
    "smtp_password", "imap_password",
}

# ---------------------------------------------------------------------------
# DB helpers — setup_steps table
# ---------------------------------------------------------------------------

def _ensure_setup_table():
    """Create setup_steps table if it doesn't exist."""
    db = aibrain_db.get_db()
    db.execute("""
        CREATE TABLE IF NOT EXISTS setup_steps (
            step_key TEXT PRIMARY KEY,
            status TEXT DEFAULT 'pending',
            label TEXT DEFAULT '',
            step_order INTEGER DEFAULT 0,
            result TEXT DEFAULT '{}',
            updated TEXT DEFAULT (datetime('now'))
        )
    """)
    db.commit()
    # Seed rows for any missing steps
    for s in STEPS:
        db.execute("""
            INSERT OR IGNORE INTO setup_steps (step_key, status, label, step_order)
            VALUES (?, 'pending', ?, ?)
        """, (s["key"], s["label"], s["order"]))
    db.commit()


def _get_step_status(step_key: str) -> Optional[str]:
    """Return status string for a step, or None if not found."""
    _ensure_setup_table()
    db = aibrain_db.get_db()
    row = db.execute(
        "SELECT status FROM setup_steps WHERE step_key = ?", (step_key,)
    ).fetchone()
    return row["status"] if row else None


def _set_step_status(step_key: str, status: str, result: dict = None):
    """Update a step's status and optional result JSON."""
    _ensure_setup_table()
    db = aibrain_db.get_db()
    db.execute("""
        UPDATE setup_steps
        SET status = ?, result = ?, updated = datetime('now')
        WHERE step_key = ?
    """, (status, json.dumps(result or {}), step_key))
    db.commit()


def _get_all_steps() -> dict[str, str]:
    """Return {step_key: status} for all steps."""
    _ensure_setup_table()
    db = aibrain_db.get_db()
    rows = db.execute(
        "SELECT step_key, status FROM setup_steps ORDER BY step_order"
    ).fetchall()
    return {r["step_key"]: r["status"] for r in rows}


# ---------------------------------------------------------------------------
# Config helpers
# ---------------------------------------------------------------------------

def _load_config() -> dict:
    """Load config.json, return empty dict if missing/corrupt."""
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            pass
    return {}


def _save_config(cfg: dict):
    """Write config.json atomically."""
    tmp = CONFIG_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
    tmp.replace(CONFIG_PATH)


def _merge_config(updates: dict):
    """Merge updates into existing config.json."""
    cfg = _load_config()
    cfg.update(updates)
    _save_config(cfg)
    return cfg


def _redact(cfg: dict) -> dict:
    """Return a copy of config with sensitive values masked."""
    out = {}
    for k, v in cfg.items():
        if any(sk in k.lower() for sk in ("password", "secret", "api_key", "token")):
            if isinstance(v, str) and len(v) > 4:
                out[k] = v[:2] + "****" + v[-2:]
            elif isinstance(v, str):
                out[k] = "****"
            else:
                out[k] = "****"
        else:
            out[k] = v
    return out


# ---------------------------------------------------------------------------
# HTTP helper (stdlib only — no httpx dependency needed)
# ---------------------------------------------------------------------------

def _http_get_json(url: str, timeout: int = 10) -> tuple[bool, Any]:
    """GET url, parse JSON. Returns (success, data_or_error_string)."""
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "AIBrain-Setup/1.0"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            return True, json.loads(resp.read().decode())
    except Exception as e:
        return False, str(e)


# ---------------------------------------------------------------------------
# Step runners
# ---------------------------------------------------------------------------

def _run_system_check() -> dict:
    """Check Python version, required packages, disk space, DB access."""
    checks = []

    # Python version >= 3.10
    py_ver = f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
    py_ok = sys.version_info >= (3, 10)
    checks.append({
        "name": "python_version",
        "status": "pass" if py_ok else "fail",
        "detail": f"Python {py_ver}" + ("" if py_ok else " (need 3.10+)"),
    })

    # Required packages
    required = ["fastapi", "uvicorn", "apscheduler"]
    for pkg in required:
        try:
            __import__(pkg)
            checks.append({"name": f"package_{pkg}", "status": "pass", "detail": f"{pkg} installed"})
        except ImportError:
            checks.append({"name": f"package_{pkg}", "status": "fail", "detail": f"{pkg} not installed"})

    # Disk space > 100MB on the AIBRAIN_ROOT drive
    try:
        usage = shutil.disk_usage(str(AIBRAIN_ROOT))
        free_mb = usage.free / (1024 * 1024)
        checks.append({
            "name": "disk_space",
            "status": "pass" if free_mb > 100 else "fail",
            "detail": f"{free_mb:.0f} MB free",
        })
    except Exception as e:
        checks.append({"name": "disk_space", "status": "fail", "detail": str(e)[:200]})

    # aibrain.db exists and readable
    try:
        db = aibrain_db.get_db()
        db.execute("SELECT 1")
        checks.append({"name": "database", "status": "pass", "detail": f"aibrain.db accessible at {DB_PATH}"})
    except Exception as e:
        checks.append({"name": "database", "status": "fail", "detail": str(e)[:200]})

    # Node.js (optional but useful)
    try:
        result = subprocess.run(
            ["node", "--version"], capture_output=True, text=True, timeout=10
        )
        if result.returncode == 0:
            checks.append({"name": "node_js", "status": "pass", "detail": f"Node.js {result.stdout.strip()}"})
        else:
            checks.append({"name": "node_js", "status": "warn", "detail": "Node.js not found (optional)"})
    except Exception as e:
        logger.warning("Node.js check failed: %s", e)
        checks.append({"name": "node_js", "status": "warn", "detail": "Node.js not found (optional)"})

    overall = "pass" if all(c["status"] != "fail" for c in checks) else "fail"
    return {"status": overall, "checks": checks}


def _run_email_config(body: dict) -> dict:
    """Validate IMAP and SMTP credentials, save to config on success."""
    email = body.get("email", "").strip()
    password = body.get("password", "").strip()
    imap_host = body.get("imap_host", "imap.gmail.com").strip()
    smtp_host = body.get("smtp_host", "smtp.gmail.com").strip()
    imap_port = int(body.get("imap_port", 993))
    smtp_port = int(body.get("smtp_port", 587))

    if not email or not password:
        return {"status": "fail", "imap": "skipped", "smtp": "skipped", "error": "email and password required"}

    # Test IMAP
    imap_status = "ok"
    imap_error = ""
    try:
        conn = imaplib.IMAP4_SSL(imap_host, imap_port)
        conn.login(email, password)
        conn.select("INBOX", readonly=True)
        conn.close()
        conn.logout()
    except Exception as e:
        imap_status = "error"
        imap_error = str(e)[:200]

    # Test SMTP
    smtp_status = "ok"
    smtp_error = ""
    try:
        server = smtplib.SMTP(smtp_host, smtp_port, timeout=15)
        server.ehlo()
        server.starttls()
        server.ehlo()
        server.login(email, password)
        server.quit()
    except Exception as e:
        smtp_status = "error"
        smtp_error = str(e)[:200]

    overall = "pass" if imap_status == "ok" and smtp_status == "ok" else "fail"

    # Save to config on success
    if overall == "pass":
        _merge_config({
            "user_email": email,
            "email_to": email,
            "email_app_password": password,
            "email_imap_host": imap_host,
            "email_smtp_host": smtp_host,
        })

    result = {"status": overall, "imap": imap_status, "smtp": smtp_status}
    if imap_error:
        result["imap_error"] = imap_error
    if smtp_error:
        result["smtp_error"] = smtp_error
    return result


def _run_location(body: dict) -> dict:
    """Set location for weather. Auto-detect via IP or accept manual coords."""
    auto = body.get("auto", False)
    lat = body.get("lat")
    lon = body.get("lon")
    name = body.get("name", "")

    if auto:
        ok, data = _http_get_json("https://ipapi.co/json/")
        if ok and isinstance(data, dict):
            lat = data.get("latitude")
            lon = data.get("longitude")
            name = data.get("city", "") or data.get("region", "")
        else:
            return {"status": "fail", "error": f"Auto-detect failed: {data}"}

    if lat is None or lon is None:
        return {"status": "fail", "error": "lat and lon required (or set auto: true)"}

    try:
        lat = float(lat)
        lon = float(lon)
    except (ValueError, TypeError):
        return {"status": "fail", "error": "lat and lon must be numeric"}

    # Verify location by fetching weather
    weather_test = ""
    try:
        weather_url = (
            f"https://api.open-meteo.com/v1/forecast"
            f"?latitude={lat}&longitude={lon}&current_weather=true"
        )
        ok, data = _http_get_json(weather_url)
        if ok and "current_weather" in data:
            cw = data["current_weather"]
            temp = cw.get("temperature", "?")
            # WMO weather codes -> simple descriptions
            wmo = {
                0: "Clear sky", 1: "Mainly clear", 2: "Partly cloudy", 3: "Overcast",
                45: "Fog", 48: "Rime fog", 51: "Light drizzle", 53: "Drizzle",
                55: "Dense drizzle", 61: "Light rain", 63: "Rain", 65: "Heavy rain",
                71: "Light snow", 73: "Snow", 75: "Heavy snow", 80: "Rain showers",
                81: "Moderate rain showers", 82: "Heavy rain showers",
                85: "Snow showers", 86: "Heavy snow showers",
                95: "Thunderstorm", 96: "Thunderstorm with hail",
            }
            code = cw.get("weathercode", -1)
            desc = wmo.get(code, f"Code {code}")
            weather_test = f"{temp}\u00b0C, {desc}"
        else:
            weather_test = "Weather API returned unexpected format"
    except Exception as e:
        weather_test = f"Weather check failed: {str(e)[:100]}"

    # Save to config
    _merge_config({
        "location_lat": lat,
        "location_lon": lon,
        "location_name": name or f"{lat},{lon}",
    })

    return {
        "status": "pass",
        "location": name or f"{lat},{lon}",
        "lat": lat,
        "lon": lon,
        "weather_test": weather_test,
    }


def _run_llm_provider(body: dict) -> dict:
    """Configure LLM provider (anthropic, openai, local, claude_cli) or skip."""
    if body.get("skip"):
        _merge_config({"llm_provider": "claude_cli"})
        return {"status": "skipped", "provider": "claude_cli"}

    provider = body.get("provider", "").strip().lower()
    api_key = body.get("api_key", "").strip()

    valid_providers = {"anthropic", "openai", "local", "claude_cli", "ollama"}
    if provider not in valid_providers:
        return {
            "status": "fail",
            "error": f"Unknown provider '{provider}'. Valid: {', '.join(sorted(valid_providers))}",
        }

    # Providers that need an API key
    if provider in ("anthropic", "openai") and not api_key:
        return {"status": "fail", "error": f"api_key required for {provider}"}

    # Optionally validate key with a tiny test call
    validation = "saved"
    if provider == "anthropic" and api_key:
        try:
            import urllib.request
            req = urllib.request.Request(
                "https://api.anthropic.com/v1/messages",
                data=json.dumps({
                    "model": "claude-sonnet-4-20250514",
                    "max_tokens": 5,
                    "messages": [{"role": "user", "content": "hi"}],
                }).encode(),
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                if resp.status == 200:
                    validation = "validated"
        except urllib.error.HTTPError as e:
            if e.code == 401:
                return {"status": "fail", "error": "Invalid API key (401 Unauthorized)"}
            # Other errors (rate limit, etc.) — key format is probably fine
            validation = "saved (could not validate — non-auth error)"
        except Exception as e:
            logger.warning("Anthropic API key validation request failed: %s", e)
            validation = "saved (validation request failed — key saved anyway)"

    elif provider == "openai" and api_key:
        try:
            req = urllib.request.Request(
                "https://api.openai.com/v1/models",
                headers={"Authorization": f"Bearer {api_key}"},
            )
            with urllib.request.urlopen(req, timeout=15) as resp:
                if resp.status == 200:
                    validation = "validated"
        except urllib.error.HTTPError as e:
            if e.code == 401:
                return {"status": "fail", "error": "Invalid API key (401 Unauthorized)"}
            validation = "saved (could not validate — non-auth error)"
        except Exception as e:
            logger.warning("OpenAI API key validation request failed: %s", e)
            validation = "saved (validation request failed — key saved anyway)"

    # Save to config
    config_updates = {"llm_provider": provider}
    if api_key:
        key_name = f"{provider}_api_key"
        config_updates[key_name] = api_key
    _merge_config(config_updates)

    return {"status": "pass", "provider": provider, "validation": validation}


def _run_workflows(body: dict) -> dict:
    """Enable selected workflows, disable the rest."""
    enable_list = body.get("enable", [])
    if not isinstance(enable_list, list):
        return {"status": "fail", "error": "enable must be a list of workflow names"}

    db = aibrain_db.get_db()

    # Get all workflows
    all_wf = db.execute("SELECT id, name, enabled FROM workflows").fetchall()
    if not all_wf:
        return {"status": "fail", "error": "No workflows found in database. Run 'python aibrain_db.py init' first."}

    enabled_count = 0
    disabled_count = 0

    for wf in all_wf:
        should_enable = wf["name"] in enable_list
        new_val = 1 if should_enable else 0
        if new_val != wf["enabled"]:
            db.execute(
                "UPDATE workflows SET enabled = ?, updated = datetime('now') WHERE id = ?",
                (new_val, wf["id"]),
            )
        if should_enable:
            enabled_count += 1
        else:
            disabled_count += 1

    db.commit()

    # Report any names from enable_list that didn't match
    known = {wf["name"] for wf in all_wf}
    unknown = [n for n in enable_list if n not in known]

    result = {"status": "pass", "enabled": enabled_count, "disabled": disabled_count}
    if unknown:
        result["unknown_workflows"] = unknown
        result["note"] = f"{len(unknown)} workflow name(s) not found in database"
    return result


def _run_first_run(body: dict) -> dict:
    """Execute morning briefing script as a smoke test."""
    # Look for the morning briefing script
    candidates = [
        AIBRAIN_ROOT / "workflows" / "morning_check_email_summarize.py",
        AIBRAIN_ROOT / "workflows" / "morning_briefing.py",
        AIBRAIN_ROOT / "workflows" / "email_triage.py",
    ]

    script = None
    for c in candidates:
        if c.exists():
            script = c
            break

    if script is None:
        # No workflow script found — do a lightweight system test instead
        try:
            db = aibrain_db.get_db()
            mem_count = db.execute("SELECT COUNT(*) FROM memories WHERE active = 1").fetchone()[0]
            wf_count = db.execute("SELECT COUNT(*) FROM workflows WHERE enabled = 1").fetchone()[0]
            cfg = _load_config()

            output_lines = [
                "AIBrain First Run — System Verification",
                f"  Database: OK ({mem_count} memories, {wf_count} enabled workflows)",
                f"  Config: {len(cfg)} keys loaded",
                f"  Platform: {platform.system()} {platform.release()}",
                f"  Python: {sys.version.split()[0]}",
            ]

            # Test weather if location configured
            if cfg.get("location_lat") and cfg.get("location_lon"):
                lat, lon = cfg["location_lat"], cfg["location_lon"]
                ok, data = _http_get_json(
                    f"https://api.open-meteo.com/v1/forecast?latitude={lat}&longitude={lon}&current_weather=true"
                )
                if ok and "current_weather" in data:
                    temp = data["current_weather"].get("temperature", "?")
                    output_lines.append(f"  Weather: {temp}\u00b0C at {cfg.get('location_name', 'configured location')}")
                else:
                    output_lines.append("  Weather: API check failed")

            # Test email connectivity if configured
            if cfg.get("user_email") and cfg.get("email_app_password"):
                try:
                    conn = imaplib.IMAP4_SSL(cfg.get("email_imap_host", "imap.gmail.com"))
                    conn.login(cfg["user_email"], cfg["email_app_password"])
                    status, messages = conn.select("INBOX", readonly=True)
                    msg_count = int(messages[0]) if messages else 0
                    conn.close()
                    conn.logout()
                    output_lines.append(f"  Email: Connected ({msg_count} messages in INBOX)")
                except Exception as e:
                    output_lines.append(f"  Email: Connection failed ({str(e)[:80]})")

            output_lines.append("  Status: All systems operational")
            output = "\n".join(output_lines)
            return {"status": "pass", "output": output[:500]}

        except Exception as e:
            return {"status": "fail", "output": f"System verification failed: {str(e)[:400]}"}

    # Execute the workflow script with --dry-run
    try:
        python = sys.executable
        result = subprocess.run(
            [python, str(script), "--dry-run"],
            capture_output=True,
            text=True,
            timeout=60,
            cwd=str(AIBRAIN_ROOT),
            env={**os.environ, "AIBRAIN_ROOT": str(AIBRAIN_ROOT)},
        )
        output = (result.stdout + "\n" + result.stderr).strip()
        status = "pass" if result.returncode == 0 else "fail"
        return {"status": status, "output": output[:500]}
    except subprocess.TimeoutExpired:
        return {"status": "fail", "output": "Workflow script timed out after 60 seconds"}
    except Exception as e:
        return {"status": "fail", "output": f"Error running workflow: {str(e)[:400]}"}


# Map step keys to runner functions
_STEP_RUNNERS = {
    "system_check": _run_system_check,
    "email_config": _run_email_config,
    "location": _run_location,
    "llm_provider": _run_llm_provider,
    "workflows": _run_workflows,
    "first_run": _run_first_run,
}


# ---------------------------------------------------------------------------
# CLI install — find system Python and pip install aibrain
# ---------------------------------------------------------------------------

def _find_system_python() -> Optional[str]:
    """Find a usable system Python installation (not PyInstaller's embedded Python).

    PyInstaller sets sys.executable to its own binary. We need a real Python
    on the host so we can run pip install.  Tries the Windows Python Launcher
    first (py.exe), then common PATH entries and known install directories.
    """
    current_exe = sys.executable.lower()

    candidates = ["py", "python", "python3"]

    # Common Windows installation directories
    localappdata = os.environ.get("LOCALAPPDATA", "")
    for ver_digits in ["313", "312", "311", "310", "39"]:
        candidates.append(
            os.path.join(localappdata, f"Programs\\Python\\Python{ver_digits}\\python.exe")
        )
        candidates.append(f"C:\\Python{ver_digits}\\python.exe")
        candidates.append(f"C:\\Program Files\\Python{ver_digits}\\python.exe")

    for cmd in candidates:
        found = shutil.which(cmd) or (cmd if os.path.isfile(cmd) else None)
        if not found:
            continue
        found_lower = found.lower()
        # Skip our own PyInstaller binary or any temp extraction dir
        if found_lower == current_exe:
            continue
        if "_mei" in found_lower or "pyinstaller" in found_lower:
            continue
        # Confirm it's a real Python
        try:
            r = subprocess.run(
                [found, "--version"],
                capture_output=True, text=True, timeout=10,
            )
            out = (r.stdout + r.stderr).lower()
            if r.returncode == 0 and "python" in out:
                logger.info("System Python found at: %s", found)
                return found
        except Exception:
            continue

    return None


def _run_cli_install_impl() -> dict:
    """Find system Python and install the aibrain PyPI package via pip."""
    python = _find_system_python()

    if not python:
        return {
            "status": "skip",
            "reason": "python_not_found",
            "message": "Python not found on this machine. Install Python then run: pip install aibrain",
            "manual_command": "pip install aibrain",
        }

    try:
        result = subprocess.run(
            [python, "-m", "pip", "install", "--user", "-q", "aibrain"],
            capture_output=True, text=True, timeout=180,
            env={**os.environ},
        )
        if result.returncode == 0:
            cli_path = shutil.which("aibrain")
            return {
                "status": "pass",
                "python": python,
                "cli_path": cli_path,
                "message": "aibrain CLI installed — run `aibrain` in any terminal",
            }
        else:
            err = (result.stderr or result.stdout)[:500]
            return {
                "status": "fail",
                "python": python,
                "error": err,
                "message": "pip install failed — try manually: pip install aibrain",
                "manual_command": "pip install aibrain",
            }
    except subprocess.TimeoutExpired:
        return {
            "status": "fail",
            "error": "pip install timed out (180s)",
            "message": "Installation timed out — try manually: pip install aibrain",
            "manual_command": "pip install aibrain",
        }
    except Exception as e:
        return {
            "status": "fail",
            "error": str(e)[:300],
            "message": "Error running pip — try manually: pip install aibrain",
            "manual_command": "pip install aibrain",
        }


# ---------------------------------------------------------------------------
# API Endpoints
# ---------------------------------------------------------------------------

@router.get("/token")
async def get_setup_token(request: Request):
    """Return the ephemeral setup token. Localhost-only — the frontend fetches this
    once on load and includes it in all subsequent setup POST requests."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Setup token only available from localhost."}, status_code=403)
    return {"token": get_or_create_setup_token()}


@router.get("/status")
async def setup_status(request: Request):
    """Overall setup progress — which steps are done/pending."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Setup endpoints are restricted to localhost."}, status_code=403)
    steps = _get_all_steps()
    steps_done = sum(1 for s in steps.values() if s in ("completed", "skipped"))
    cfg = _load_config()
    return {
        "completed": cfg.get("setup_complete", False),
        "steps_done": steps_done,
        "steps_total": len(STEPS),
        "steps": steps,
    }


@router.get("/steps")
async def list_steps(request: Request):
    """List all setup steps with their current status and metadata."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Setup endpoints are restricted to localhost."}, status_code=403)
    _ensure_setup_table()
    db = aibrain_db.get_db()
    rows = db.execute(
        "SELECT step_key, status, label, step_order, result, updated FROM setup_steps ORDER BY step_order"
    ).fetchall()

    steps = []
    for r in rows:
        step = {
            "key": r["step_key"],
            "label": r["label"],
            "order": r["step_order"],
            "status": r["status"],
            "updated": r["updated"],
        }
        # Parse stored result JSON
        try:
            step["result"] = json.loads(r["result"]) if r["result"] else {}
        except (json.JSONDecodeError, TypeError):
            step["result"] = {}
        steps.append(step)

    return {"steps": steps}


@router.post("/steps/{step_key}/run")
async def run_step(step_key: str, request: Request, body: dict = Body(default={})):
    """Execute a specific setup step."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Setup endpoints are restricted to localhost."}, status_code=403)
    if not _require_setup_auth(request):
        return JSONResponse({"error": "Missing or invalid X-Setup-Token header."}, status_code=401)
    # Block re-execution after setup is complete — prevents credential overwrite
    if _load_config().get("setup_complete"):
        return JSONResponse({"error": "Setup already complete. Re-running steps is not allowed."}, status_code=403)
    runner = _STEP_RUNNERS.get(step_key)
    if not runner:
        return JSONResponse(
            {"error": f"Unknown step '{step_key}'", "valid_steps": list(_STEP_RUNNERS.keys())},
            status_code=404,
        )

    try:
        # Steps that don't need a body (system_check) get called without args;
        # steps that do (email_config, location, etc.) get the body dict.
        import inspect
        sig = inspect.signature(runner)
        if sig.parameters:
            result = await asyncio.to_thread(runner, body)
        else:
            result = await asyncio.to_thread(runner)
    except Exception as e:
        logger.error("Setup step %s failed: %s", step_key, e, exc_info=True)
        result = {"status": "fail", "error": str(e)[:500]}

    # Determine step status from result
    status = result.get("status", "fail")
    if status == "pass":
        step_status = "completed"
    elif status == "skipped":
        step_status = "skipped"
    else:
        step_status = "failed"

    _set_step_status(step_key, step_status, result)

    return result


_SETUP_ALLOWED_KEYS = {
    "llm_provider", "anthropic_api_key", "openai_api_key",
    "anthropic_model", "openai_model", "ollama_model", "ollama_url",
    "theme", "user_name", "user_email", "timezone",
    "smtp_user", "smtp_pass", "smtp_host", "smtp_port",
    "github_token", "telegram_bot_token", "weather_api_key",
    "location_lat", "location_lon", "location_name",
    "email_to", "email_app_password", "email_imap_host", "email_smtp_host",
    "notify_approvals", "notify_chat", "budget_daily", "budget_monthly",
}


@router.post("/config")
async def save_config(request: Request, body: dict = Body(...)):
    """Save configuration values to config.json. Only usable before setup is complete."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Setup endpoints are restricted to localhost."}, status_code=403)
    if not _require_setup_auth(request):
        return JSONResponse({"error": "Missing or invalid X-Setup-Token header."}, status_code=401)
    if not body:
        return JSONResponse({"error": "No config values provided"}, status_code=400)

    # Lock this endpoint once setup is complete — use /api/agent/config instead
    cfg = _load_config()
    if cfg.get("setup_complete"):
        return JSONResponse(
            {"error": "Setup already complete. Use /api/agent/config to update settings."},
            status_code=403,
        )

    filtered = {k: v for k, v in body.items() if k in _SETUP_ALLOWED_KEYS}
    if not filtered:
        return JSONResponse({"error": "No allowed config keys in request"}, status_code=400)

    # Validate ollama_url if provided — block SSRF
    if "ollama_url" in filtered:
        is_safe, reason = _validate_url(filtered["ollama_url"])
        if not is_safe:
            return JSONResponse(
                {"error": f"Invalid ollama_url: {reason}"},
                status_code=400,
            )

    cfg = _merge_config(filtered)
    return {"saved": True, "config": _redact(cfg)}


@router.get("/config")
async def get_config(request: Request):
    """Get current configuration (passwords/keys redacted). Requires setup to be incomplete."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Setup endpoints are restricted to localhost."}, status_code=403)
    cfg = _load_config()
    if cfg.get("setup_complete"):
        return JSONResponse({"error": "Setup complete. Config accessible via authenticated API only."}, status_code=403)
    return {"config": _redact(cfg)}


@router.post("/complete")
async def complete_setup(request: Request):
    """Mark setup as complete. Writes setup_complete: true to config.json."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Setup endpoints are restricted to localhost."}, status_code=403)
    if not _require_setup_auth(request):
        return JSONResponse({"error": "Missing or invalid X-Setup-Token header."}, status_code=401)
    steps = _get_all_steps()

    # Check that at least system_check is done
    if steps.get("system_check") not in ("completed", "skipped"):
        return JSONResponse(
            {"error": "system_check must be completed before marking setup complete"},
            status_code=400,
        )

    now = datetime.now(timezone.utc).isoformat()
    _merge_config({"setup_complete": True, "setup_completed_at": now})

    return {
        "completed": True,
        "timestamp": now,
        "steps": steps,
    }


@router.get("/workflows/available")
async def available_workflows(request: Request):
    """List all workflows available for selection during setup."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Setup endpoints are restricted to localhost."}, status_code=403)
    db = aibrain_db.get_db()
    rows = db.execute(
        "SELECT id, name, display_name, category, description, enabled FROM workflows ORDER BY category, name"
    ).fetchall()

    workflows = []
    for r in rows:
        workflows.append({
            "name": r["name"],
            "display_name": r["display_name"] or r["name"],
            "category": r["category"],
            "description": r["description"],
            "enabled": bool(r["enabled"]),
        })

    # Default top-5 recommendations
    defaults = [
        "morning_briefing", "email_triage", "weather_briefing",
        "weekly_report", "smart_file_organizer",
    ]
    known_names = {w["name"] for w in workflows}
    recommended = [d for d in defaults if d in known_names]

    return {
        "workflows": workflows,
        "total": len(workflows),
        "recommended": recommended,
    }


@router.post("/cli-install")
async def install_cli_package(request: Request):
    """Install the aibrain PyPI package on the host system Python.

    Searches for a real Python installation (skips PyInstaller's embedded
    binary), then runs ``pip install --user aibrain``.  Returns immediately
    with status=skip if Python cannot be located.

    Localhost-only.  No setup token or auth required — this should be callable
    after setup_complete as part of the desktop app first-run wizard.
    """
    if not _require_localhost(request):
        return JSONResponse(
            {"error": "CLI install endpoint is restricted to localhost."},
            status_code=403,
        )
    try:
        result = await asyncio.to_thread(_run_cli_install_impl)
    except Exception as e:
        logger.error("CLI install failed unexpectedly: %s", e, exc_info=True)
        result = {
            "status": "fail",
            "error": str(e)[:300],
            "message": "Unexpected error — try manually: pip install aibrain",
            "manual_command": "pip install aibrain",
        }
    return result


# ---------------------------------------------------------------------------
# Provider dependency detection + install helpers
# ---------------------------------------------------------------------------

def _find_claude_bin() -> Optional[str]:
    """Find claude CLI binary — checks PATH then common Windows/Unix locations."""
    found = shutil.which("claude")
    if found:
        return found
    home = Path.home()
    candidates = [
        home / "AppData" / "Roaming" / "npm" / "claude.cmd",
        home / "AppData" / "Roaming" / "npm" / "claude",
        home / ".npm-global" / "bin" / "claude",
        Path("/usr/local/bin/claude"),
        Path("/usr/bin/claude"),
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    return None


def _check_claude_auth() -> bool:
    """Return True if Claude Code credentials exist on this machine."""
    home = Path.home()
    appdata = os.environ.get("APPDATA", "")
    cred_candidates = [
        home / ".claude" / ".credentials.json",
        home / ".claude" / "credentials.json",
        Path(appdata) / "Claude" / "credentials.json" if appdata else None,
        home / ".config" / "claude" / "credentials.json",
    ]
    for cred in cred_candidates:
        if cred and cred.exists() and cred.stat().st_size > 10:
            return True
    return False


@router.get("/claude-cli-status")
async def get_claude_cli_status(request: Request):
    """Check if Claude Code CLI is installed and authenticated. Localhost-only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Localhost only."}, status_code=403)
    claude_bin = _find_claude_bin()
    installed = claude_bin is not None
    authenticated = _check_claude_auth() if installed else False
    npm_bin = shutil.which("npm") or shutil.which("npm.cmd")
    return {
        "installed": installed,
        "authenticated": authenticated,
        "path": claude_bin,
        "npm_available": npm_bin is not None,
    }


def _run_claude_cli_install() -> dict:
    """Install Claude Code CLI via npm. Returns status dict."""
    npm = shutil.which("npm") or shutil.which("npm.cmd")
    if not npm:
        return {
            "status": "no_npm",
            "message": "npm not found — install Node.js (nodejs.org) first, then retry.",
            "install_url": "https://nodejs.org/en/download/",
        }
    try:
        result = subprocess.run(
            [npm, "install", "-g", "@anthropic-ai/claude-code"],
            capture_output=True, text=True, timeout=180,
            env={**os.environ},
        )
        if result.returncode == 0:
            claude_bin = _find_claude_bin()
            return {
                "status": "pass",
                "path": claude_bin,
                "message": "Claude Code installed. Sign in to complete setup.",
            }
        else:
            err = (result.stderr or result.stdout)[:500]
            return {
                "status": "fail",
                "error": err,
                "message": "npm install failed — try: npm install -g @anthropic-ai/claude-code",
            }
    except subprocess.TimeoutExpired:
        return {"status": "fail", "error": "install timed out (180s)"}
    except Exception as e:
        return {"status": "fail", "error": str(e)[:300]}


@router.post("/claude-cli-install")
async def install_claude_cli(request: Request):
    """Install Claude Code CLI via npm. Localhost-only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Localhost only."}, status_code=403)
    result = await asyncio.to_thread(_run_claude_cli_install)
    return result


@router.post("/claude-cli-login")
async def start_claude_login(request: Request):
    """Launch `claude login` in the background — opens browser OAuth flow. Localhost-only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Localhost only."}, status_code=403)
    claude_bin = _find_claude_bin()
    if not claude_bin:
        return {"status": "not_installed", "message": "Claude Code CLI not found."}
    try:
        # Detach — the OAuth flow opens the default browser; we poll auth status separately
        subprocess.Popen(
            [claude_bin, "login"],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            start_new_session=True,
        )
        return {"status": "launched", "message": "Browser opened for Claude sign-in."}
    except Exception as e:
        return {"status": "fail", "error": str(e)[:300]}


def _find_ollama_bin() -> Optional[str]:
    """Find ollama binary."""
    found = shutil.which("ollama")
    if found:
        return found
    home = Path.home()
    candidates = [
        Path("C:/Users") / home.name / "AppData" / "Local" / "Programs" / "Ollama" / "ollama.exe",
        Path("/usr/local/bin/ollama"),
        Path("/usr/bin/ollama"),
    ]
    for c in candidates:
        if c.exists():
            return str(c)
    return None


def _run_ollama_install() -> dict:
    """Install Ollama via winget (Windows) or return manual URL."""
    system = platform.system()
    if system == "Windows":
        winget = shutil.which("winget")
        if winget:
            try:
                result = subprocess.run(
                    [winget, "install", "--id", "Ollama.Ollama", "-e", "--accept-source-agreements", "--accept-package-agreements"],
                    capture_output=True, text=True, timeout=300,
                    env={**os.environ},
                )
                if result.returncode == 0:
                    ollama_bin = _find_ollama_bin()
                    return {"status": "pass", "path": ollama_bin, "message": "Ollama installed."}
                else:
                    err = (result.stderr or result.stdout)[:300]
                    return {
                        "status": "fail", "error": err,
                        "message": "winget install failed.",
                        "install_url": "https://ollama.com/download",
                    }
            except subprocess.TimeoutExpired:
                return {"status": "fail", "error": "timed out", "install_url": "https://ollama.com/download"}
            except Exception as e:
                return {"status": "fail", "error": str(e)[:200], "install_url": "https://ollama.com/download"}
        else:
            return {
                "status": "no_winget",
                "message": "Open the installer to get Ollama.",
                "install_url": "https://ollama.com/download/OllamaSetup.exe",
            }
    else:
        # macOS / Linux: curl install script
        try:
            result = subprocess.run(
                ["sh", "-c", "curl -fsSL https://ollama.com/install.sh | sh"],
                capture_output=True, text=True, timeout=300,
            )
            if result.returncode == 0:
                return {"status": "pass", "message": "Ollama installed."}
            return {"status": "fail", "error": result.stderr[:300], "install_url": "https://ollama.com/download"}
        except Exception as e:
            return {"status": "fail", "error": str(e)[:200], "install_url": "https://ollama.com/download"}


@router.get("/ollama-status")
async def get_ollama_status(request: Request):
    """Check if Ollama is installed and running. Localhost-only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Localhost only."}, status_code=403)
    ollama_bin = _find_ollama_bin()
    installed = ollama_bin is not None
    running = False
    models: list = []
    if installed:
        try:
            import urllib.request as _ur
            with _ur.urlopen("http://localhost:11434/api/tags", timeout=2) as resp:
                data = json.loads(resp.read())
                models = [m["name"] for m in data.get("models", [])]
                running = True
        except Exception:
            pass
    return {"installed": installed, "running": running, "models": models, "path": ollama_bin}


@router.post("/ollama-install")
async def install_ollama(request: Request):
    """Install Ollama via winget (Windows) or curl script (Unix). Localhost-only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Localhost only."}, status_code=403)
    result = await asyncio.to_thread(_run_ollama_install)
    return result


# ---------------------------------------------------------------------------
# OAuth callback handler for LLM provider setup (Anthropic, OpenAI, Google)
#
# The setup wizard can initiate an OAuth flow to obtain an API token from the
# provider directly, rather than asking the user to copy-paste a key.
#
# Flow:
#   1. Frontend calls GET /api/setup/oauth/{provider}/start
#   2. Backend generates PKCE challenge + state, redirects to provider
#   3. Provider redirects back to GET /api/setup/oauth/{provider}/callback
#   4. Backend exchanges auth code for access token, writes to config.json
#   5. Returns an HTML page that auto-closes the browser tab
#
# Client ID and secret are read from env vars:
#   ANTHROPIC_OAUTH_CLIENT_ID / ANTHROPIC_OAUTH_CLIENT_SECRET
#   OPENAI_OAUTH_CLIENT_ID / OPENAI_OAUTH_CLIENT_SECRET
#   GOOGLE_OAUTH_CLIENT_ID / GOOGLE_OAUTH_CLIENT_SECRET
# ---------------------------------------------------------------------------

# Provider OAuth configuration for LLM API access
_LLM_OAUTH_PROVIDERS = {
    "anthropic": {
        "authorize_url": "https://console.anthropic.com/oauth/authorize",
        "token_url": "https://console.anthropic.com/oauth/token",
        "scope": "api",
        "config_key": "anthropic_api_key",
        "label": "Anthropic",
    },
    "openai": {
        "authorize_url": "https://auth.openai.com/authorize",
        "token_url": "https://auth.openai.com/oauth/token",
        "scope": "openai.public",
        "config_key": "openai_api_key",
        "label": "OpenAI",
    },
    "google": {
        "authorize_url": "https://accounts.google.com/o/oauth2/v2/auth",
        "token_url": "https://oauth2.googleapis.com/token",
        "scope": "https://www.googleapis.com/auth/generative-language",
        "config_key": "google_api_key",
        "label": "Google",
    },
}

# In-memory state store for OAuth PKCE flows (ephemeral — cleared on restart)
_oauth_states: dict[str, dict] = {}


def _llm_oauth_configured(provider: str) -> bool:
    """Check that OAuth client credentials are set for a given LLM provider."""
    if provider not in _LLM_OAUTH_PROVIDERS:
        return False
    key = provider.upper()
    return bool(
        os.environ.get(f"{key}_OAUTH_CLIENT_ID")
        and os.environ.get(f"{key}_OAUTH_CLIENT_SECRET")
    )


def _llm_oauth_credentials(provider: str) -> tuple[str, str]:
    """Return (client_id, client_secret) from env vars."""
    key = provider.upper()
    return (
        os.environ.get(f"{key}_OAUTH_CLIENT_ID", ""),
        os.environ.get(f"{key}_OAUTH_CLIENT_SECRET", ""),
    )


def _setup_pkce_verifier() -> str:
    """Generate a PKCE code verifier (43-128 chars per RFC 7636)."""
    return secrets.token_urlsafe(64)[:96]


def _setup_pkce_challenge(verifier: str) -> str:
    """Generate a PKCE S256 challenge from a verifier."""
    h = hashlib.sha256(verifier.encode("ascii")).digest()
    return base64.urlsafe_b64encode(h).rstrip(b"=").decode("ascii")


def _oauth_redirect_uri(provider: str) -> str:
    """Build the OAuth redirect URI for the callback endpoint."""
    base = os.environ.get("AIBRAIN_BASE_URL", "http://localhost:8001")
    return f"{base.rstrip('/')}/api/setup/oauth/{provider}/callback"


_OAUTH_SUCCESS_HTML = """\
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>AIBrain - Connected</title>
  <style>
    body {{
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      display: flex; align-items: center; justify-content: center;
      min-height: 100vh; margin: 0;
      background: #0a0a0a; color: #e4e4e7;
    }}
    .card {{
      text-align: center; padding: 3rem 2rem;
      border: 1px solid #27272a; border-radius: 1rem;
      background: #18181b; max-width: 400px;
    }}
    .check {{ font-size: 3rem; margin-bottom: 1rem; }}
    h2 {{ margin: 0 0 0.5rem; font-size: 1.25rem; }}
    p {{ color: #a1a1aa; font-size: 0.875rem; margin: 0; }}
  </style>
</head>
<body>
  <div class="card">
    <div class="check">&#10003;</div>
    <h2>{provider} connected</h2>
    <p>API key saved to AIBrain. You can close this tab.</p>
    <p style="margin-top:1rem;font-size:0.75rem;color:#71717a;">This tab will close automatically.</p>
  </div>
  <script>setTimeout(function(){{ window.close(); }}, 2000);</script>
</body>
</html>
"""

_OAUTH_ERROR_HTML = """\
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>AIBrain - OAuth Error</title>
  <style>
    body {{
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      display: flex; align-items: center; justify-content: center;
      min-height: 100vh; margin: 0;
      background: #0a0a0a; color: #e4e4e7;
    }}
    .card {{
      text-align: center; padding: 3rem 2rem;
      border: 1px solid #7f1d1d; border-radius: 1rem;
      background: #18181b; max-width: 400px;
    }}
    .icon {{ font-size: 3rem; margin-bottom: 1rem; }}
    h2 {{ margin: 0 0 0.5rem; font-size: 1.25rem; color: #fca5a5; }}
    p {{ color: #a1a1aa; font-size: 0.875rem; margin: 0; }}
    .detail {{ margin-top: 1rem; font-size: 0.75rem; color: #71717a;
               word-break: break-all; }}
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">&#9888;</div>
    <h2>Connection failed</h2>
    <p>{message}</p>
    <p class="detail">{detail}</p>
  </div>
</body>
</html>
"""


def _expire_oauth_states():
    """Remove OAuth states older than 10 minutes to prevent memory leaks."""
    now = datetime.now(timezone.utc)
    expired = []
    for s, data in _oauth_states.items():
        try:
            created = datetime.fromisoformat(data["created_at"])
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            if (now - created).total_seconds() > 600:
                expired.append(s)
        except (ValueError, KeyError):
            expired.append(s)
    for s in expired:
        _oauth_states.pop(s, None)


@router.get("/oauth/providers")
async def setup_oauth_providers():
    """Return which LLM providers have OAuth configured."""
    configured = [p for p in _LLM_OAUTH_PROVIDERS if _llm_oauth_configured(p)]
    supported = list(_LLM_OAUTH_PROVIDERS.keys())
    return {"configured": configured, "supported": supported}


@router.get("/oauth/{provider}/start")
async def setup_oauth_start(provider: str, request: Request):
    """Initiate an OAuth flow for an LLM provider. Redirects the browser to
    the provider's authorize endpoint."""
    if not _require_localhost(request):
        return JSONResponse(
            {"error": "OAuth start is restricted to localhost."},
            status_code=403,
        )
    if provider not in _LLM_OAUTH_PROVIDERS:
        return JSONResponse(
            {"error": f"Unknown provider: {provider}",
             "supported": list(_LLM_OAUTH_PROVIDERS.keys())},
            status_code=404,
        )
    if not _llm_oauth_configured(provider):
        return JSONResponse(
            {"error": f"OAuth not configured for {provider}. "
                      f"Set {provider.upper()}_OAUTH_CLIENT_ID and "
                      f"{provider.upper()}_OAUTH_CLIENT_SECRET env vars."},
            status_code=503,
        )

    cfg = _LLM_OAUTH_PROVIDERS[provider]
    client_id, _ = _llm_oauth_credentials(provider)

    verifier = _setup_pkce_verifier()
    challenge = _setup_pkce_challenge(verifier)
    state = secrets.token_urlsafe(32)

    # Store state for callback verification (10 min TTL)
    _oauth_states[state] = {
        "provider": provider,
        "code_verifier": verifier,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }

    # Expire old states (housekeeping)
    _expire_oauth_states()

    params = {
        "response_type": "code",
        "client_id": client_id,
        "redirect_uri": _oauth_redirect_uri(provider),
        "scope": cfg["scope"],
        "state": state,
        "code_challenge": challenge,
        "code_challenge_method": "S256",
    }
    # Google requires access_type=offline for refresh token
    if provider == "google":
        params["access_type"] = "offline"
        params["prompt"] = "consent"

    url = f"{cfg['authorize_url']}?{urllib.parse.urlencode(params)}"
    return RedirectResponse(url, status_code=302)


@router.get("/oauth/{provider}/callback")
async def setup_oauth_callback(
    provider: str,
    request: Request,
    code: Optional[str] = Query(default=None),
    state: Optional[str] = Query(default=None),
    error: Optional[str] = Query(default=None),
    error_description: Optional[str] = Query(default=None),
):
    """Receive the OAuth redirect from the LLM provider. Exchanges the
    authorization code for an access token and writes it to config.json."""
    if provider not in _LLM_OAUTH_PROVIDERS:
        return HTMLResponse(
            _OAUTH_ERROR_HTML.format(
                message="Unknown provider.",
                detail=f"Provider '{provider}' is not supported.",
            ),
            status_code=404,
        )

    if error:
        return HTMLResponse(
            _OAUTH_ERROR_HTML.format(
                message=f"The provider returned an error: {error}",
                detail=error_description or "",
            ),
            status_code=400,
        )

    if not code or not state:
        return HTMLResponse(
            _OAUTH_ERROR_HTML.format(
                message="Missing authorization code or state parameter.",
                detail="The OAuth redirect was incomplete. Try again.",
            ),
            status_code=400,
        )

    # Validate state
    state_data = _oauth_states.pop(state, None)
    if not state_data or state_data["provider"] != provider:
        return HTMLResponse(
            _OAUTH_ERROR_HTML.format(
                message="Invalid or expired OAuth state.",
                detail="The session may have timed out. Please try connecting again.",
            ),
            status_code=400,
        )

    cfg = _LLM_OAUTH_PROVIDERS[provider]
    client_id, client_secret = _llm_oauth_credentials(provider)

    # Exchange authorization code for access token
    try:
        token_data = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": _oauth_redirect_uri(provider),
            "client_id": client_id,
            "client_secret": client_secret,
            "code_verifier": state_data["code_verifier"],
        }
        body_bytes = urllib.parse.urlencode(token_data).encode("utf-8")
        token_req = urllib.request.Request(
            cfg["token_url"],
            data=body_bytes,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Accept": "application/json",
            },
            method="POST",
        )
        with urllib.request.urlopen(token_req, timeout=15) as resp:
            token_resp = json.loads(resp.read().decode("utf-8"))

        access_token = token_resp.get("access_token")
        if not access_token:
            err_msg = token_resp.get("error", "unknown")
            err_desc = token_resp.get("error_description", "")
            logger.warning(
                "OAuth token exchange failed for %s: %s - %s", provider, err_msg, err_desc,
            )
            return HTMLResponse(
                _OAUTH_ERROR_HTML.format(
                    message=f"Token exchange failed: {err_msg}",
                    detail=err_desc,
                ),
                status_code=400,
            )

    except urllib.error.HTTPError as e:
        err_body = ""
        try:
            err_body = e.read().decode("utf-8")[:500]
        except Exception:
            pass
        logger.warning("OAuth token exchange HTTP error for %s: %s %s", provider, e.code, err_body)
        return HTMLResponse(
            _OAUTH_ERROR_HTML.format(
                message=f"Token exchange failed (HTTP {e.code}).",
                detail=err_body[:200] if err_body else "No details from provider.",
            ),
            status_code=502,
        )
    except Exception as e:
        logger.error("OAuth token exchange exception for %s: %s", provider, e, exc_info=True)
        return HTMLResponse(
            _OAUTH_ERROR_HTML.format(
                message="Token exchange failed due to a network error.",
                detail=str(e)[:200],
            ),
            status_code=502,
        )

    # Write the access token to config.json
    config_key = cfg["config_key"]
    provider_map = {"anthropic": "claude", "openai": "openai", "google": "google"}
    config_updates = {
        config_key: access_token,
        "llm_provider": provider_map.get(provider, provider),
    }
    # Store refresh token if provided (Google sends one with access_type=offline)
    refresh_token = token_resp.get("refresh_token")
    if refresh_token:
        config_updates[f"{provider}_refresh_token"] = refresh_token

    _merge_config(config_updates)
    logger.info("OAuth token for %s written to config.json (key: %s)", provider, config_key)

    return HTMLResponse(
        _OAUTH_SUCCESS_HTML.format(provider=cfg["label"]),
        status_code=200,
    )
