"""
AIBrain Backend — FastAPI server for the portable AI brain.
Serves memory DB, cron registry, skills, agent status, workflow groups,
built-in scheduler, approval queue, and chat WebSocket.
"""

import asyncio
import json
import logging
import os
import sys
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import Optional

import time as _time

from fastapi import Depends, FastAPI, Query, Request, UploadFile, WebSocket, WebSocketDisconnect
from pydantic import BaseModel

logger = logging.getLogger(__name__)

# Track server start time for uptime calculation
_server_start_time = _time.monotonic()

# Structured logging — JSON for production, readable for dev
_log_format = os.environ.get("LOG_FORMAT", "text")
if _log_format == "json":
    import json as _json_mod
    class _JsonFormatter(logging.Formatter):
        def format(self, record):
            return _json_mod.dumps({
                "ts": self.formatTime(record), "level": record.levelname,
                "logger": record.name, "msg": record.getMessage(),
            }, default=str)
    _handler = logging.StreamHandler()
    _handler.setFormatter(_JsonFormatter())
    logging.root.handlers = [_handler]
    logging.root.setLevel(logging.INFO)
else:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
        datefmt="%H:%M:%S",
    )

from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse, RedirectResponse

# ---------------------------------------------------------------------------
# Consolidated DB + Scheduler imports
# ---------------------------------------------------------------------------
# Resolve AIBRAIN_ROOT: explicit env var wins; otherwise detect dev vs pip-install layout.
# On a clean pip install __file__ lives in site-packages/backend/ — data must go to ~/aibrain.
# In the dev clone __file__ is inside the project dir — use parent.parent (project root).
def _resolve_aibrain_root() -> Path:
    if "AIBRAIN_ROOT" in os.environ:
        return Path(os.environ["AIBRAIN_ROOT"])
    # Check ~/.aibrainrc sentinel (set by `aibrain init`)
    sentinel = Path.home() / ".aibrainrc"
    if sentinel.exists():
        try:
            configured = Path(sentinel.read_text(encoding="utf-8").strip())
            if (configured / "aibrain.db").exists():
                return configured
        except Exception:
            pass
    pkg_parent = Path(__file__).parent.parent
    if "site-packages" in str(pkg_parent):
        # pip install — use user data dir; set env var so aibrain_db picks it up
        user_root = Path.home() / "aibrain"
        user_root.mkdir(parents=True, exist_ok=True)
        os.environ["AIBRAIN_ROOT"] = str(user_root)
        return user_root
    return pkg_parent

AIBRAIN_ROOT = _resolve_aibrain_root()
sys.path.insert(0, str(AIBRAIN_ROOT))
sys.path.insert(0, str(Path(__file__).parent))
import aibrain_db
from aibrain import __version__ as _AIBRAIN_VERSION

from scheduler import init_scheduler, reload_jobs, get_scheduler_status, shutdown_scheduler
from action_executor import execute_approved_action

# Legacy — kept for backward compat with approval_queue module
from approval_queue import (
    add_item as aq_add, list_items as aq_list, get_item as aq_get,
    decide as aq_decide, pending_count as aq_pending, summary as aq_summary,
    feedback as aq_feedback,
)
APPROVAL_DB = AIBRAIN_ROOT / "approval.db"
CRON_JOBS_PATH = AIBRAIN_ROOT / "scheduled_jobs.json"


# ---------------------------------------------------------------------------
# Lifespan — start/stop scheduler with the server
# ---------------------------------------------------------------------------
_broker_poll_task = None

async def _poll_broker_for_chat():
    """Background task: poll broker for messages and push to chat."""
    if not _BROKER_URL:
        return
    while True:
        try:
            await asyncio.sleep(3)
            replies = await asyncio.to_thread(_check_broker_replies, _CHAT_AGENT_ID)
            for r in replies:
                from_agent = r.get("from_agent", "unknown")
                content = r.get("content", "")
                if content and from_agent != _CHAT_AGENT_ID:
                    agent_msg = {
                        "type": "message",
                        "role": "agent",
                        "from": from_agent,
                        "content": content,
                        "timestamp": datetime.now().isoformat(),
                    }
                    _chat_history.append(agent_msg)
                    if len(_chat_history) > _MAX_HISTORY:
                        _chat_history[:] = _chat_history[-_MAX_HISTORY:]
                    await _broadcast_chat(agent_msg)
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.warning("Broker poll error: %s", e)
            await asyncio.sleep(10)


_BUILDIT_INTERVAL_SECONDS = {"1h": 3600, "1d": 86400, "1w": 604800}


async def _run_buildit_auto_improve():
    """Background task: fire improve on any buildit build whose interval has elapsed."""
    while True:
        try:
            await asyncio.sleep(600)  # check every 10 minutes
            db = aibrain_db.get_db()
            rows = db.execute(
                "SELECT id, auto_improve_interval, last_improved_at FROM buildit_builds"
                " WHERE auto_improve_interval IS NOT NULL"
            ).fetchall()
            now = datetime.utcnow()
            for row in rows:
                interval_str = row["auto_improve_interval"]
                interval_secs = _BUILDIT_INTERVAL_SECONDS.get(interval_str)
                if interval_secs is None:
                    continue
                last_str = row["last_improved_at"]
                if last_str:
                    try:
                        last_dt = datetime.fromisoformat(last_str.replace("Z", "+00:00")).replace(tzinfo=None)
                    except ValueError:
                        last_dt = None
                else:
                    last_dt = None
                due = last_dt is None or (now - last_dt).total_seconds() >= interval_secs
                if due:
                    build_id = row["id"]
                    logger.info("buildit auto-improve: firing for build %s (interval=%s)", build_id, interval_str)
                    try:
                        import httpx as _httpx
                        async with _httpx.AsyncClient(timeout=120) as client:
                            resp = await client.post(f"http://localhost:8001/api/buildit/improve/{build_id}")
                            if resp.status_code == 200:
                                logger.info("buildit auto-improve: build %s improved ok", build_id)
                            else:
                                logger.warning("buildit auto-improve: build %s returned %s", build_id, resp.status_code)
                    except Exception as _ie:
                        logger.warning("buildit auto-improve: improve call failed for %s: %s", build_id, _ie)
        except asyncio.CancelledError:
            break
        except Exception as e:
            logger.warning("buildit auto-improve scheduler error: %s", e)


_buildit_improve_task = None


@asynccontextmanager
async def lifespan(app):
    global _broker_poll_task, _buildit_improve_task
    # Startup: launch the built-in scheduler
    if CRON_JOBS_PATH.exists():
        init_scheduler(AIBRAIN_ROOT, CRON_JOBS_PATH)
        logger.info("Scheduler started — reading %s", CRON_JOBS_PATH)
    # Start broker poll for chat messages
    _broker_poll_task = asyncio.create_task(_poll_broker_for_chat())
    logger.info("Broker chat poll started — checking every 3s for messages")
    # Start buildit auto-improve background scheduler (checks every 10 minutes)
    _buildit_improve_task = asyncio.create_task(_run_buildit_auto_improve())
    logger.info("Buildit auto-improve scheduler started — checking every 10 minutes")
    yield
    # Shutdown
    if _broker_poll_task:
        _broker_poll_task.cancel()
    if _buildit_improve_task:
        _buildit_improve_task.cancel()
    shutdown_scheduler()
    logger.info("Scheduler stopped")


app = FastAPI(title="AIBrain API", version=_AIBRAIN_VERSION, lifespan=lifespan)

_cors_origins = os.environ.get("AIBRAIN_CORS_ORIGINS", "").strip()
if _cors_origins == "*":
    # Wildcard CORS with credentials is insecure — fall back to localhost
    import logging as _log
    _log.getLogger(__name__).warning("AIBRAIN_CORS_ORIGINS=* is insecure with credentials. Using localhost only.")
    _allowed = ["http://localhost:5173", "http://localhost:8001"]
elif _cors_origins:
    _allowed = [o.strip() for o in _cors_origins.split(",")]
else:
    # Dashboard (3000/5173), API (8001), Electron (file:// sends null origin),
    # and myaibrain.org for the public /public/stats metrics page.
    _allowed = ["http://localhost:3000", "http://localhost:5173", "http://localhost:8001",
                "http://localhost:1420",      # Tauri / Vite dev server
                "http://127.0.0.1:8001",
                "https://myaibrain.org", "https://www.myaibrain.org",
                "tauri://localhost",          # Tauri v1
                "https://tauri.localhost",    # Tauri v2 (macOS/Linux)
                "http://tauri.localhost"]     # Tauri v2 (Windows)

app.add_middleware(
    CORSMiddleware,
    allow_origins=_allowed,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "X-API-Key", "X-Request-ID"],
)

# CSRF protection — state-changing methods must use application/json Content-Type
# This prevents form-based CSRF since browsers can't send application/json cross-origin
# without a CORS preflight, which we already restrict.
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import Response as StarletteResponse


class CSRFContentTypeMiddleware(BaseHTTPMiddleware):
    """Reject state-changing requests without application/json Content-Type."""

    _STATE_CHANGING = {"POST", "PUT", "DELETE", "PATCH"}

    async def dispatch(self, request: Request, call_next):
        if request.method in self._STATE_CHANGING:
            # Skip check for WebSocket upgrades, file uploads, and health endpoints
            path = request.url.path
            ct = (request.headers.get("content-type") or "").lower()
            is_upload = "multipart/form-data" in ct
            is_health = path in ("/health", "/api/health", "/api/ready")
            is_webhook = (
                path.startswith("/api/agent/webhook")  # noqa:PATH STARTSWITH BYPASS
                or path == "/webhooks/stripe"  # Stripe sends raw bytes, not JSON
            )
            if not is_upload and not is_health and not is_webhook:
                if "application/json" not in ct and request.method != "DELETE":
                    return StarletteResponse(
                        content='{"error":"Content-Type must be application/json"}',
                        status_code=415,
                        media_type="application/json",
                    )
        return await call_next(request)


app.add_middleware(CSRFContentTypeMiddleware)

# Request ID for tracing, then auth, then rate limiting (outermost → innermost)
from security import RateLimitMiddleware, AuthMiddleware, RequestIdMiddleware
app.add_middleware(RequestIdMiddleware)
app.add_middleware(AuthMiddleware)

# Rate limiting — 60 req/min general, 10 req/min for auth/approval endpoints
app.add_middleware(RateLimitMiddleware, general_rpm=60, auth_rpm=10)

from aibrain_api import router as aibrain_router, set_notify_callback
app.include_router(aibrain_router)

# Auth router — myaibrain.org user accounts. Mounted at /auth/* (not /api/*)
# so it doesn't inherit the AuthMiddleware API-key requirement. Handles its
# own session cookies.
try:
    from auth_routes import router as auth_router
    app.include_router(auth_router)
    logger.info("Auth router loaded (/auth/*)")
except Exception as _are:
    logger.error("Auth router FAILED: %s", _are)

from reactive_workflows import router as reactive_router, set_notify_callback as set_reactive_notify
app.include_router(reactive_router)

from pattern_bus_api import router as pattern_bus_router
app.include_router(pattern_bus_router)

from setup_api import router as setup_router
app.include_router(setup_router)

try:
    from companies_api import router as companies_router
    app.include_router(companies_router)
    logger.info("Companies API loaded (/api/companies/*)")
except Exception as _cae:
    logger.error("Companies API FAILED: %s", _cae)

try:
    from license_activations_api import router as license_activations_router
    app.include_router(license_activations_router)
    logger.info("License activations API loaded (/api/license/*)")
except Exception as _lae:
    logger.error("License activations API FAILED: %s", _lae)

try:
    from gumroad_checkout_api import router as gumroad_checkout_router
    app.include_router(gumroad_checkout_router)
    logger.info("Gumroad checkout API loaded (/api/gumroad-checkout, /api/activate, /api/license-status)")
except Exception as _gce:
    logger.error("Gumroad checkout API FAILED: %s", _gce)

# Archive/update company endpoint (inline — router import caching blocks additions to companies_api.py)
@app.patch("/api/companies/{company_id}")
def _inline_patch_company(company_id: str, request: Request):
    if not _require_localhost(request):
        from fastapi.responses import JSONResponse as _JSONResponse
        return _JSONResponse({"error": "Company updates are restricted to localhost."}, status_code=403)
    import asyncio
    body = asyncio.get_event_loop().run_until_complete(request.json())
    from aibrain.core.heartbeat import _get_db
    db = _get_db()
    existing = db.execute("SELECT * FROM companies WHERE id=?", (company_id,)).fetchone()
    if not existing:
        db.close()
        raise HTTPException(404, "Company not found")
    allowed = {"name", "mission", "status"}
    updates = {k: v for k, v in body.items() if k in allowed}
    if updates:
        set_clause = ", ".join(f"{k}=?" for k in updates)
        db.execute(f"UPDATE companies SET {set_clause} WHERE id=?", [*updates.values(), company_id])  # noqa:sql-injection
        db.commit()
    row = db.execute("SELECT * FROM companies WHERE id=?", (company_id,)).fetchone()
    db.close()
    return dict(row)

# Memory REST API — no-MCP mode (mirrors MCP memory tools as plain REST endpoints)
try:
    from memory_api import router as memory_api_router
    app.include_router(memory_api_router)
    logger.info("Memory REST API loaded (no-MCP mode: /api/memory/*)")
except Exception as _mae:
    logger.error("Memory REST API FAILED: %s", _mae)

# Cross-domain question generator (Pixel Moment substrate)
import sys as _sys
_wf_path = str(Path(__file__).resolve().parent.parent / "workflows")
if _wf_path not in _sys.path:
    _sys.path.insert(0, _wf_path)
try:
    from cross_domain_questions import create_router as create_questions_router
    _qr = create_questions_router()
    app.include_router(_qr)
    logger.info("Cross-domain questions router loaded (%d routes)", len(_qr.routes))
except Exception as _qe:
    logger.error("Cross-domain questions router FAILED: %s", _qe)

from chat_responder import get_response as llm_respond
from webhooks import router as webhooks_router
from security import jwt_auth as _jwt_auth_dep
app.include_router(webhooks_router, prefix="/api/agent", dependencies=[Depends(_jwt_auth_dep)])

try:
    from critic_generator import create_router as create_critic_router
    app.include_router(create_critic_router())
    logger.info("Critic-generator router loaded")
except Exception as _cge:
    logger.error("Critic-generator router FAILED: %s", _cge)

# ---------------------------------------------------------------------------
# User Feedback endpoint — no auth, localhost + external OK
# ---------------------------------------------------------------------------

from fastapi import Body as _Body
from datetime import datetime as _dt
import json as _json

@app.post("/api/feedback", tags=["feedback"])
async def submit_feedback(payload: dict = _Body(...)):
    """Accept user feedback, save to DB, and notify operator via Telegram."""
    category = str(payload.get("category", "general"))[:64]
    message  = str(payload.get("message", ""))[:2000]
    email    = str(payload.get("email", ""))[:256]
    version  = str(payload.get("version", "unknown"))[:32]
    tier     = str(payload.get("tier", "free"))[:32]

    if not message.strip():
        return {"status": "error", "detail": "Message is required"}

    # Persist to SQLite
    db_path = Path(os.environ.get("AIBRAIN_DB", Path(__file__).parent.parent / "aibrain.db"))
    try:
        import sqlite3 as _sq
        conn = _sq.connect(str(db_path))
        conn.execute("PRAGMA journal_mode=wal")
        conn.execute("""
            CREATE TABLE IF NOT EXISTS user_feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created TEXT NOT NULL,
                category TEXT DEFAULT 'general',
                message TEXT NOT NULL,
                email TEXT DEFAULT '',
                version TEXT DEFAULT '',
                tier TEXT DEFAULT 'free'
            )
        """)
        conn.execute(
            "INSERT INTO user_feedback (created, category, message, email, version, tier) VALUES (?,?,?,?,?,?)",
            (_dt.utcnow().isoformat(), category, message, email, version, tier),
        )
        conn.commit()
        conn.close()
    except Exception as _e:
        logger.error("Feedback DB save failed: %s", _e)

    # Load config once for both notification channels
    _cfg_path = Path(os.environ.get("AIBRAIN_ROOT", Path(__file__).parent.parent)) / "config.json"
    _cfg: dict = {}
    try:
        if _cfg_path.exists():
            _cfg = _json.loads(_cfg_path.read_text(encoding="utf-8"))
    except Exception:
        pass

    _cat_emoji = {"bug": "🐛", "feature": "✨", "praise": "🙏", "general": "💬"}.get(category, "💬")

    # Telegram notification (best-effort)
    try:
        import httpx as _httpx
        _token  = _cfg.get("telegram_token", os.environ.get("TELEGRAM_TOKEN", ""))
        _dm_id  = _cfg.get("telegram_dm_id", os.environ.get("TELEGRAM_DM_ID", ""))
        if _token and _dm_id:
            _text = (
                f"{_cat_emoji} <b>User Feedback</b>\n"
                f"<b>Category:</b> {category}\n"
                f"<b>Version:</b> {version} ({tier})\n"
                f"<b>Email:</b> {email or '—'}\n\n"
                f"{message}"
            )
            _httpx.post(
                f"https://api.telegram.org/bot{_token}/sendMessage",
                json={"chat_id": int(_dm_id), "text": _text, "parse_mode": "HTML"},
                timeout=10,
            )
    except Exception as _e:
        logger.warning("Feedback Telegram notify failed: %s", _e)

    # Email notification to operator (best-effort)
    try:
        import smtplib as _smtp
        from email.message import EmailMessage as _EM
        _gmail_addr = _cfg.get("gmail_address", os.environ.get("GMAIL_ADDRESS", ""))
        _gmail_pass = _cfg.get("gmail_app_password", os.environ.get("GMAIL_APP_PASSWORD", ""))
        _notify_to  = _cfg.get("feedback_notify_email", "decker.ops@gmail.com")
        if _gmail_addr and _gmail_pass:
            _subject = f"[AIBrain Feedback] {_cat_emoji} {category.capitalize()} — v{version} ({tier})"
            _body = (
                f"Category: {category}\n"
                f"Version: {version} ({tier})\n"
                f"User email: {email or '—'}\n"
                f"{'─' * 40}\n\n"
                f"{message}"
            )
            _msg = _EM()
            _msg["From"] = _gmail_addr
            _msg["To"] = _notify_to
            _msg["Subject"] = _subject
            _msg.set_content(_body)
            with _smtp.SMTP_SSL("smtp.gmail.com", 465, timeout=10) as _s:
                _s.login(_gmail_addr, _gmail_pass)
                _s.send_message(_msg)
    except Exception as _e:
        logger.warning("Feedback email notify failed: %s", _e)

    return {"status": "ok", "message": "Feedback received — thank you!"}


# ---------------------------------------------------------------------------
# Root — browser landing for API-only mode
# ---------------------------------------------------------------------------
@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def root():
    """Redirect to /chat so the browser lands on the chat interface."""
    return RedirectResponse(url="/chat", status_code=302)


@app.get("/chat", response_class=HTMLResponse, include_in_schema=False)
async def chat_ui():
    """Serve the embedded chat UI — no React, no build step, pure HTML."""
    ver = _AIBRAIN_VERSION
    return HTMLResponse(f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AIBrain Chat</title>
<style>
  *{{box-sizing:border-box;margin:0;padding:0}}
  body{{font-family:system-ui,sans-serif;background:#0a0a0f;color:#e2e8f0;height:100vh;display:flex;flex-direction:column}}
  header{{padding:.75rem 1.25rem;background:#0d1117;border-bottom:1px solid #1e2a3a;display:flex;align-items:center;gap:.75rem;flex-shrink:0}}
  header h1{{font-size:1.1rem;color:#7c3aed;font-weight:700}}
  .badge{{background:#1e1b4b;color:#a5b4fc;padding:.2rem .6rem;border-radius:999px;font-size:.75rem}}
  #log{{flex:1;overflow-y:auto;padding:1rem;display:flex;flex-direction:column;gap:.6rem}}
  .msg{{max-width:78%;padding:.65rem 1rem;border-radius:.75rem;font-size:.92rem;line-height:1.5;word-break:break-word}}
  .msg.user{{align-self:flex-end;background:#7c3aed;color:#fff;border-bottom-right-radius:.25rem}}
  .msg.agent{{align-self:flex-start;background:#1a1f2e;color:#e2e8f0;border:1px solid #1e2a3a;border-bottom-left-radius:.25rem}}
  .msg.system{{align-self:center;background:transparent;color:#64748b;font-size:.8rem;border:none;padding:.25rem .5rem}}
  .msg.error{{align-self:flex-start;background:#2d1515;color:#f87171;border:1px solid #7f1d1d;border-bottom-left-radius:.25rem}}
  #input-row{{padding:.75rem 1rem;background:#0d1117;border-top:1px solid #1e2a3a;display:flex;gap:.6rem;flex-shrink:0}}
  #msg-input{{flex:1;background:#161b27;color:#e2e8f0;border:1px solid #1e2a3a;border-radius:.5rem;padding:.6rem .9rem;font-size:.95rem;outline:none;resize:none;max-height:120px;line-height:1.45}}
  #msg-input:focus{{border-color:#7c3aed}}
  #send-btn{{background:#7c3aed;color:#fff;border:none;border-radius:.5rem;padding:.6rem 1.2rem;font-size:.95rem;font-weight:600;cursor:pointer;flex-shrink:0;align-self:flex-end}}
  #send-btn:hover{{background:#6d28d9}}
  #send-btn:disabled{{background:#4c3080;cursor:not-allowed}}
  .typing{{color:#64748b;font-style:italic;font-size:.85rem}}
</style>
</head>
<body>
<header>
  <h1>AIBrain</h1>
  <span class="badge">v{ver}</span>
  <span style="margin-left:auto;color:#64748b;font-size:.8rem">Your brain, running locally</span>
</header>
<div id="log">
  <div class="msg system">Brain is online. Ask it anything — it remembers across sessions.</div>
</div>
<div id="input-row">
  <textarea id="msg-input" rows="1" placeholder="Type a message..." autofocus></textarea>
  <button id="send-btn">Send</button>
</div>
<script>
const log = document.getElementById('log');
const input = document.getElementById('msg-input');
const btn = document.getElementById('send-btn');

function addMsg(role, text) {{
  const div = document.createElement('div');
  div.className = 'msg ' + role;
  div.textContent = text;
  log.appendChild(div);
  log.scrollTop = log.scrollHeight;
  return div;
}}

function setLoading(on) {{
  btn.disabled = on;
  btn.textContent = on ? '...' : 'Send';
}}

async function send() {{
  const text = input.value.trim();
  if (!text) return;
  input.value = '';
  input.style.height = '';
  addMsg('user', text);
  setLoading(true);
  const typing = addMsg('agent typing', 'Thinking...');
  try {{
    const res = await fetch('/api/agent/chat/send', {{
      method: 'POST',
      headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{content: text}})
    }});
    typing.remove();
    if (!res.ok) {{
      const err = await res.text();
      addMsg('error', 'Error ' + res.status + ': ' + err);
    }} else {{
      const data = await res.json();
      const reply = data.response;
      if (reply && reply.content) {{
        // Strip the "[auto] " prefix that the LLM fallback adds
        const content = reply.content.replace(/^\[auto\] /, '');
        addMsg('agent', content);
      }} else {{
        addMsg('system', '(no response — is an LLM configured? Run: aibrain config set llm_provider openai)');
      }}
    }}
  }} catch(e) {{
    typing.remove();
    addMsg('error', 'Network error: ' + e.message);
  }}
  setLoading(false);
  input.focus();
}}

btn.addEventListener('click', send);
input.addEventListener('keydown', e => {{
  if (e.key === 'Enter' && !e.shiftKey) {{
    e.preventDefault();
    send();
  }}
}});

// Auto-resize textarea
input.addEventListener('input', () => {{
  input.style.height = '';
  input.style.height = Math.min(input.scrollHeight, 120) + 'px';
}});
</script>
</body>
</html>""")


# ---------------------------------------------------------------------------
# Health
# ---------------------------------------------------------------------------
@app.get("/health")
async def health():
    pending = aq_pending(APPROVAL_DB)
    sched = get_scheduler_status()

    # Check memory DB accessibility
    db_path = AIBRAIN_ROOT / "aibrain.db"
    memory_db_ok = False
    try:
        if db_path.exists():
            import sqlite3 as _sqlite3
            conn = _sqlite3.connect(str(db_path), timeout=2)
            conn.execute("SELECT 1")
            conn.close()
            memory_db_ok = True
    except Exception:
        pass

    return {
        "status": "ok",
        "service": "aibrain-backend",
        "version": _AIBRAIN_VERSION,
        "timestamp": datetime.now().isoformat(),
        "uptime_seconds": round(_time.monotonic() - _server_start_time, 1),
        "memory_db": {"accessible": memory_db_ok},
        "scheduler": {"running": sched["running"], "jobs": sched["job_count"]},
        "pending_approvals": pending,
    }


@app.get("/api/health")
async def api_health():
    """Lightweight health probe — always returns 200 if the process is alive."""
    return {"status": "healthy", "timestamp": datetime.now().isoformat()}


@app.get("/api/ready")
async def api_ready():
    """Readiness probe — checks SQLite connectivity and scheduler status."""
    checks = {}

    # Check 1: SQLite connection
    try:
        import sqlite3 as _sqlite3
        db_path = str(AIBRAIN_ROOT / "aibrain.db")
        conn = _sqlite3.connect(db_path, timeout=2)
        conn.execute("SELECT 1")
        conn.close()
        checks["sqlite"] = True
    except Exception as e:
        checks["sqlite"] = False

    # Check 2: Scheduler running
    try:
        sched = get_scheduler_status()
        checks["scheduler"] = sched.get("running", False)
    except Exception as e:
        logger.warning("Scheduler health check failed: %s", e)
        checks["scheduler"] = False

    ready = all(checks.values())
    return {"ready": ready, "checks": checks}


@app.get("/api/health/deep")
async def deep_health():
    """Comprehensive health check — tests all subsystems."""
    checks = {}

    # Memory DB
    try:
        from aibrain_api import get_db
        db = get_db()
        count = db.execute("SELECT COUNT(*) FROM memories WHERE active = 1").fetchone()[0]
        db.close()
        checks["memory_db"] = {"ok": True, "memories": count}
    except Exception as e:
        checks["memory_db"] = {"ok": False, "error": str(e)[:100]}

    # Scheduler
    try:
        sched = get_scheduler_status()
        checks["scheduler"] = {"ok": sched["running"], "jobs": sched["job_count"]}
    except Exception as e:
        checks["scheduler"] = {"ok": False, "error": str(e)[:100]}

    # Approval queue
    try:
        pending = aq_pending(APPROVAL_DB)
        checks["approvals"] = {"ok": True, "pending": pending}
    except Exception as e:
        checks["approvals"] = {"ok": False, "error": str(e)[:100]}

    # LLM provider
    try:
        from chat_responder import get_provider_status
        checks["llm"] = get_provider_status()
    except Exception as e:
        logger.warning("LLM provider health check failed: %s", e)
        checks["llm"] = {"ok": False, "error": "Chat responder not available"}

    # Entity extraction
    try:
        from entity_extractor import extract_entities
        test = extract_entities("test python docker")
        checks["entity_extractor"] = {"ok": True, "test_entities": len(test)}
    except Exception as e:
        checks["entity_extractor"] = {"ok": False, "error": str(e)[:100]}

    # Trace DB
    try:
        from trace_logger import get_cost_summary
        s = get_cost_summary(1)
        checks["trace_db"] = {"ok": True, "total_cost": s.get("total_cost_usd", 0)}
    except Exception as e:
        logger.warning("Trace DB health check failed: %s", e)
        checks["trace_db"] = {"ok": False, "error": "Not initialized"}

    # WebSocket connections
    checks["websocket"] = {
        "ok": True,
        "chat_connections": len(_chat_connections),
        "notify_connections": len(_notify_connections),
    }

    all_ok = all(c.get("ok", False) for c in checks.values())
    return {
        "status": "healthy" if all_ok else "degraded",
        "checks": checks,
    }


# ---------------------------------------------------------------------------
# Auth API — /api/auth/* (bypasses AuthMiddleware)
# ---------------------------------------------------------------------------
from security import (
    register_api_key, revoke_api_key, issue_jwt,
    create_api_key, _hash_key, ws_authenticate, jwt_auth,
)
from models import AuthModeRequest, TokenRequest, TokenVerifyRequest, KeyRevokeRequest

def _require_localhost(request: Request) -> bool:
    """Check if request comes from localhost. Auth mgmt is localhost-only."""
    client_ip = request.client.host if request.client else "unknown"
    return client_ip in ("127.0.0.1", "::1")


# ---------------------------------------------------------------------------
# Public stats — no auth required, 5-minute in-memory cache
# Used by myaibrain.org/metrics page
# ---------------------------------------------------------------------------
import urllib.request as _urllib_req

_stats_cache: dict = {"data": None, "expires_at": 0.0}
_STATS_TTL = 300  # 5 minutes


def _fetch_pypi_downloads() -> int:
    """Fetch recent downloads from pypistats.org — returns last-month total."""
    try:
        url = "https://pypistats.org/api/packages/aibrain/recent"
        req = _urllib_req.Request(url, headers={"User-Agent": "aibrain-backend/1.0"})
        with _urllib_req.urlopen(req, timeout=5) as resp:
            import json as _json
            data = _json.loads(resp.read())
            # data.data has: last_day, last_month, last_week
            for row in data.get("data", []):
                if row.get("category") == "without_mirrors":
                    return row.get("downloads", 0)
            # Fallback: sum all without_mirrors across categories
            return data.get("data", [{}])[0].get("downloads", 0)
    except Exception:
        return -1  # Signal unavailable


def _fetch_db_stats() -> dict:
    """Count signups, memories, and pro users from aibrain.db."""
    result = {"total_signups": 0, "pro_users": 0, "memories_stored": 0}
    try:
        import sqlite3 as _sqlite3
        db_path = str(AIBRAIN_ROOT / "aibrain.db")
        conn = _sqlite3.connect(db_path, timeout=3)
        conn.row_factory = _sqlite3.Row

        # Total registered users
        row = conn.execute("SELECT COUNT(*) as n FROM users").fetchone()
        if row:
            result["total_signups"] = row["n"]

        # Pro/Team users (tier != 'free' and not null)
        row = conn.execute(
            "SELECT COUNT(*) as n FROM users WHERE tier IS NOT NULL AND tier != 'free'"
        ).fetchone()
        if row:
            result["pro_users"] = row["n"]

        # Active memories
        row = conn.execute(
            "SELECT COUNT(*) as n FROM memories WHERE active = 1"
        ).fetchone()
        if row:
            result["memories_stored"] = row["n"]

        conn.close()
    except Exception:
        pass
    return result


@app.get("/public/stats")
async def public_stats():
    """
    Public install/signup funnel stats — no auth required.
    Cached for 5 minutes. Safe to call from myaibrain.org metrics page.
    """
    now = _time.monotonic()
    if _stats_cache["data"] is not None and now < _stats_cache["expires_at"]:
        return _stats_cache["data"]

    # Gather fresh data
    db = _fetch_db_stats()
    pypi_downloads = await asyncio.to_thread(_fetch_pypi_downloads)
    total_installs = pypi_downloads if pypi_downloads >= 0 else db.get("total_signups", 0)

    payload = {
        "total_installs": total_installs,
        "total_signups": db["total_signups"],
        "pro_users": db["pro_users"],
        "memories_stored": db["memories_stored"],
        "cached": False,
        "as_of": datetime.now().isoformat(),
    }
    _stats_cache["data"] = {**payload, "cached": False}
    _stats_cache["expires_at"] = now + _STATS_TTL

    return payload


@app.get("/api/auth/mode")
async def get_auth_mode():
    """Get current auth mode."""
    mode = aibrain_db.config_get("auth_mode", "api_key")
    key_count = len(aibrain_db.config_get("api_keys", []))
    return {"auth_mode": mode, "api_key_count": key_count}


@app.post("/api/auth/mode")
async def set_auth_mode(body: AuthModeRequest, request: Request):
    """Set auth mode: none, api_key, or jwt. Localhost only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Auth mode changes are restricted to localhost."}, status_code=403)
    aibrain_db.config_set("auth_mode", body.mode)
    return {"auth_mode": body.mode, "message": f"Auth mode set to {body.mode}"}


@app.post("/api/auth/keys")
async def create_key(request: Request):
    """Generate a new API key. Localhost only. Returns the plaintext key ONCE."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Key management is restricted to localhost."}, status_code=403)
    key = register_api_key(aibrain_db)
    return {
        "api_key": key,
        "message": "Store this key — it cannot be retrieved later.",
    }


@app.delete("/api/auth/keys")
async def delete_key(body: KeyRevokeRequest, request: Request):
    """Revoke an API key by hash prefix. Localhost only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Key management is restricted to localhost."}, status_code=403)
    ok = revoke_api_key(aibrain_db, body.hash_prefix)
    if not ok:
        return JSONResponse({"error": "No key matched that prefix"}, status_code=404)
    return {"revoked": True}


@app.get("/api/auth/keys")
async def list_keys(request: Request):
    """List API key hash prefixes (for identification). Localhost only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Key management is restricted to localhost."}, status_code=403)
    keys = aibrain_db.config_get("api_keys", [])
    return {"keys": [{"hash_prefix": k[:12]} for k in keys]}


@app.post("/api/auth/token")
async def create_token(body: TokenRequest, request: Request):
    """Issue a JWT token. Localhost only."""
    if not _require_localhost(request):
        return JSONResponse({"error": "Token issuance is restricted to localhost."}, status_code=403)
    token = issue_jwt(aibrain_db, body.subject, body.ttl)
    return {"token": token, "subject": body.subject, "ttl": body.ttl}


@app.post("/api/auth/verify")
async def verify_token(body: TokenVerifyRequest):
    """Verify a JWT token. Body: {token: str}."""
    from security import jwt_decode
    secret = aibrain_db.config_get("jwt_secret")
    if not secret:
        return JSONResponse({"error": "No JWT secret configured"}, status_code=400)
    payload = jwt_decode(body.token, secret)
    if payload is None:
        return JSONResponse({"error": "Invalid or expired token"}, status_code=403)
    return {"valid": True, "payload": payload}


# ---------------------------------------------------------------------------
# User account auth — JWT-based (Option B): register, login, me
#
# Distinct from the cookie-session /auth/* router (auth_routes.py) which
# serves the myaibrain.org web frontend. These endpoints return JWT tokens
# for programmatic API clients and are under /api/auth/* (not bypassed by
# AuthMiddleware because register/login/me are added to _AUTH_BYPASS_PREFIXES).
#
# Password hashing: delegates to auth.password (bcrypt cost 12) — same
# function the cookie-session system uses. No new deps.
#
# DB: reads/writes users and license_state in aibrain.db via auth.db.get_conn().
# The users table and license_state table already exist (created by aibrain_db
# migration). If a user was created via the web signup they already have a row
# here; register returns 409 in that case.
# ---------------------------------------------------------------------------

class RegisterBody(BaseModel):
    email: str
    password: str


class LoginJWTBody(BaseModel):
    email: str
    password: str


def _api_auth_get_jwt_secret() -> str:
    """Return (or lazily create) the JWT secret stored in aibrain_db config."""
    import secrets as _secrets
    secret = aibrain_db.config_get("jwt_secret")
    if not secret:
        secret = _secrets.token_hex(32)
        aibrain_db.config_set("jwt_secret", secret)
    return secret


@app.post("/api/auth/register")
async def api_register(body: RegisterBody):
    """Register a new user account.

    Body: {email, password}
    Returns: {user_id, email}
    409 if email already registered.
    """
    from auth.db import get_conn as _get_conn
    from auth.password import hash_password, validate_password_strength
    import re as _re
    import secrets as _secrets
    from datetime import datetime as _dt, timezone as _tz

    _EMAIL_RE = _re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")
    email = (body.email or "").strip().lower()
    if not _EMAIL_RE.match(email):
        return JSONResponse({"error": "Invalid email address"}, status_code=400)

    ok, reason = validate_password_strength(body.password)
    if not ok:
        return JSONResponse({"error": reason}, status_code=400)

    conn = _get_conn()
    try:
        existing = conn.execute(
            "SELECT id FROM users WHERE email = ? COLLATE NOCASE", (email,)
        ).fetchone()
        if existing:
            return JSONResponse({"error": "Email already registered"}, status_code=409)

        user_id = _secrets.token_urlsafe(8)[:11]
        now_str = _dt.now(_tz.utc).strftime("%Y-%m-%d %H:%M:%S")
        ph = hash_password(body.password)

        # Build insert dynamically — handles both minimal and extended (RBAC) schemas
        cols = {r[1] for r in conn.execute("PRAGMA table_info(users)").fetchall()}
        fields = ["id", "email", "password_hash", "created_at", "email_verified", "totp_enabled"]
        values: list = [user_id, email, ph, now_str, 0, 0]
        if "role" in cols:
            fields.append("role"); values.append("member")
        if "status" in cols:
            fields.append("status"); values.append("active")
        placeholders = ", ".join(["?"] * len(fields))
        conn.execute(
            f"INSERT INTO users ({', '.join(fields)}) VALUES ({placeholders})",  # noqa: sql-injection
            values,
        )
    finally:
        conn.close()

    logger.info("api_register: new user %s id=%s", email, user_id)
    return {"user_id": user_id, "email": email}


@app.post("/api/auth/login")
async def api_login(body: LoginJWTBody):
    """Authenticate with email + password and return a JWT.

    Body: {email, password}
    Returns: {token, user_id, email, license_state}
    401 on bad credentials.
    """
    from auth.db import get_conn as _get_conn
    from auth.password import verify_password
    from security import jwt_encode

    email = (body.email or "").strip().lower()
    conn = _get_conn()
    try:
        row = conn.execute(
            "SELECT * FROM users WHERE email = ? COLLATE NOCASE", (email,)
        ).fetchone()
        if not row or not row["password_hash"]:
            return JSONResponse({"error": "Invalid email or password"}, status_code=401)

        if not verify_password(body.password, row["password_hash"]):
            return JSONResponse({"error": "Invalid email or password"}, status_code=401)

        user_id = row["id"]

        # Fetch license_state — defaults to "free" if no row yet
        lic_row = conn.execute(
            "SELECT tier FROM license_state WHERE user_id = ?", (user_id,)
        ).fetchone()
        license_state = (lic_row["tier"] if lic_row else None) or "free"
    finally:
        conn.close()

    secret = _api_auth_get_jwt_secret()
    token = jwt_encode(
        {"sub": user_id, "email": email, "license_state": license_state, "role": "user"},
        secret,
        ttl=86400,
    )

    logger.info("api_login: user %s id=%s license=%s", email, user_id, license_state)
    return {"token": token, "user_id": user_id, "email": email, "license_state": license_state}


@app.get("/api/auth/me")
async def api_me(request: Request):
    """Return current user info. Requires a valid JWT Bearer token.

    Returns: {user_id, email, license_state}
    401 if no/invalid token.
    """
    from auth.db import get_conn as _get_conn
    from security import jwt_decode

    auth_header = request.headers.get("authorization", "")
    if not auth_header.lower().startswith("bearer "):
        return JSONResponse(
            {"error": "Missing or malformed Authorization header. Use: Bearer <token>"},
            status_code=401,
        )
    token = auth_header[7:].strip()
    secret = aibrain_db.config_get("jwt_secret", "")
    if not secret:
        return JSONResponse({"error": "Auth not configured"}, status_code=500)

    payload = jwt_decode(token, secret)
    if payload is None:
        return JSONResponse({"error": "Invalid or expired token"}, status_code=401)

    user_id = payload.get("sub", "")
    email = payload.get("email", "")

    # Always re-fetch license_state from DB — token may be stale after Stripe upgrade
    conn = _get_conn()
    try:
        lic_row = conn.execute(
            "SELECT tier FROM license_state WHERE user_id = ?", (user_id,)
        ).fetchone()
        license_state = (lic_row["tier"] if lic_row else None) or "free"
    finally:
        conn.close()

    return {"user_id": user_id, "email": email, "license_state": license_state}


# ---------------------------------------------------------------------------
# Doctor — brain DB health check
# ---------------------------------------------------------------------------
@app.get("/api/agent/doctor")
async def doctor_report():
    """Brain DB health check — canonical DB, ghost DBs, schema, vectors."""
    import sqlite3
    from datetime import datetime, timezone

    try:
        from aibrain_db import AIBRAIN_ROOT, find_all_aibrain_dbs
    except Exception as e:
        return {"error": str(e)}

    canonical_db = AIBRAIN_ROOT / "aibrain.db"
    all_dbs = find_all_aibrain_dbs()

    ghost_dbs = []
    for p in all_dbs:
        if p != canonical_db.resolve():
            try:
                sz = p.stat().st_size // 1024
            except Exception:
                sz = 0
            ghost_dbs.append({"path": str(p), "size_kb": sz})

    canonical_size_kb = 0
    if canonical_db.exists():
        try:
            canonical_size_kb = canonical_db.stat().st_size // 1024
        except Exception:
            pass

    # Pre-commit linter: check if .git/hooks/pre-commit exists and references aibrain
    pre_commit_ok = False
    try:
        hook = AIBRAIN_ROOT / ".git" / "hooks" / "pre-commit"
        if hook.exists():
            pre_commit_ok = "aibrain" in hook.read_text(errors="ignore")
    except Exception:
        pass

    return {
        "canonical_db_path": str(canonical_db),
        "canonical_db_size_kb": canonical_size_kb,
        "ghost_dbs": ghost_dbs,
        "invariant_ok": len(ghost_dbs) == 0,
        "pre_commit_linter_ok": pre_commit_ok,
        "checked_at": datetime.now(timezone.utc).isoformat(),
    }


# ---------------------------------------------------------------------------
# Scheduler API
# ---------------------------------------------------------------------------
@app.get("/api/agent/scheduler/status")
async def scheduler_status():
    return get_scheduler_status()


@app.post("/api/agent/scheduler/reload")
async def scheduler_reload():
    """Reload all jobs from scheduled_jobs.json."""
    reload_jobs(AIBRAIN_ROOT, CRON_JOBS_PATH)
    status = get_scheduler_status()
    return {"status": "reloaded", "jobs": status["job_count"]}


# ---------------------------------------------------------------------------
# Approval Queue API
# ---------------------------------------------------------------------------
@app.get("/api/agent/approvals")
async def list_approvals(
    status: Optional[str] = Query(None),
    category: Optional[str] = Query(None),
    limit: int = Query(50),
):
    from security import safe_limit
    limit = safe_limit(limit, 200)
    items = aq_list(APPROVAL_DB, status=status, category=category, limit=limit)
    pending = aq_pending(APPROVAL_DB)
    return {"items": items, "pending": pending, "total": len(items)}


@app.get("/api/agent/approvals/summary")
async def approval_summary():
    return aq_summary(APPROVAL_DB)


@app.get("/api/agent/approvals/{item_id}")
async def get_approval(item_id: int):
    item = aq_get(APPROVAL_DB, item_id)
    if not item:
        return JSONResponse({"error": "Not found"}, status_code=404)
    return item


@app.post("/api/agent/approvals")
async def create_approval(body: dict):
    """Create a new approval request. Body: {category, title, detail?, payload?}"""
    title = body.get("title")
    if not title:
        return JSONResponse({"error": "title required"}, status_code=400)
    payload = body.get("payload")
    # Normalize: if payload arrives as a JSON string, parse it to dict
    if isinstance(payload, str):
        try:
            payload = json.loads(payload)
        except (json.JSONDecodeError, TypeError):
            payload = {"raw": payload}
    category = body.get("category", "general")
    item_id = aq_add(
        APPROVAL_DB,
        category=category,
        title=title,
        detail=body.get("detail", ""),
        payload=payload,
    )
    # Push real-time notification
    asyncio.ensure_future(broadcast_notification({
        "type": "approval",
        "action": "new",
        "id": item_id,
        "title": title,
        "category": category,
        "pending_count": aq_pending(APPROVAL_DB),
    }))
    return {"id": item_id, "status": "pending"}


@app.post("/api/agent/approvals/{item_id}/approve")
async def approve_item(item_id: int, body: dict = None):
    body = body or {}
    result = aq_decide(APPROVAL_DB, item_id, approved=True, note=body.get("note", ""))

    # Execute the action behind the approval
    item = aq_get(APPROVAL_DB, item_id)
    exec_result = None
    if item:
        try:
            exec_result = execute_approved_action(item)
        except Exception as e:
            exec_result = f"Execution error: {e}"
    result["execution"] = exec_result

    # Notify connected chat clients
    await _broadcast_chat({
        "type": "approval_decided",
        "item_id": item_id,
        "decision": "approved",
        "execution": exec_result,
        "timestamp": result["decided_at"],
    })
    return result


@app.post("/api/agent/approvals/{item_id}/reject")
async def reject_item(item_id: int, body: dict = None):
    body = body or {}
    result = aq_decide(APPROVAL_DB, item_id, approved=False, note=body.get("note", ""))
    await _broadcast_chat({
        "type": "approval_decided",
        "item_id": item_id,
        "decision": "rejected",
        "timestamp": result["decided_at"],
    })
    return result


@app.post("/api/agent/approvals/{item_id}/feedback")
async def feedback_item(item_id: int, body: dict = None):
    """Return an item with feedback instead of just approve/reject.
    Operator can provide instructions like 'follow up on the jobs in this email'
    or 'this is not a job offer, it's a notification'."""
    body = body or {}
    note = body.get("note", "")
    if not note:
        return {"error": "Feedback requires a note"}, 400
    result = aq_feedback(APPROVAL_DB, item_id, note=note)
    await _broadcast_chat({
        "type": "approval_decided",
        "item_id": item_id,
        "decision": "feedback",
        "note": note,
        "timestamp": result["updated_at"],
    })
    return result


# ---------------------------------------------------------------------------
# Chat WebSocket — real-time agent communication
# Messages route through the peer discovery broker so active agents
# can pick them up and respond. Falls back to Claude CLI if no agent responds.
# ---------------------------------------------------------------------------
_chat_connections: list[WebSocket] = []
_chat_lock = asyncio.Lock()
_chat_history: list[dict] = []
_MAX_HISTORY = 200
_MAX_WS_CONNECTIONS = 50  # Per-type WebSocket connection limit


_MAX_MSG_SIZE = 10_000  # Max characters per chat message
_WS_RATE_LIMIT = 30  # Max messages per minute per connection
_WS_RATE_WINDOW = 60  # Rate limit window in seconds

# Broker integration for chat
_BROKER_URL = os.environ.get("PEER_BROKER_URL", "")
_CHAT_AGENT_ID = os.environ.get("CHAT_AGENT_ID", "user")
_CHAT_TARGET = os.environ.get("CHAT_TARGET", "agent")
_KNOWN_PEERS = set(filter(None, os.environ.get("KNOWN_PEERS", "").split(",")))


def _send_to_broker(from_agent: str, to_agent: str, content: str) -> bool:
    """Send a message via the peer discovery broker. Returns True on success."""
    if not _BROKER_URL:
        return False
    import urllib.request
    try:
        data = json.dumps({
            "from_agent": from_agent,
            "to_agent": to_agent,
            "content": content,
        }).encode()
        req = urllib.request.Request(
            f"{_BROKER_URL}/messages/send",
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        resp = urllib.request.urlopen(req, timeout=5)
        return resp.status == 200
    except Exception as e:
        logger.warning("Broker send failed: %s", e)
        return False


def _check_broker_replies(agent_id: str = "agent") -> list:
    """Check broker for new messages addressed to this agent. Marks them read."""
    if not _BROKER_URL:
        return []
    import urllib.request
    try:
        url = f"{_BROKER_URL}/messages?agent_id={agent_id}&mark_read=true"
        req = urllib.request.Request(url, method="GET")
        resp = urllib.request.urlopen(req, timeout=5)
        data = json.loads(resp.read())
        return data.get("messages", [])
    except Exception:
        return []


async def _broadcast_chat(message: dict):
    """Send a message to all connected chat clients."""
    async with _chat_lock:
        stale = []
        for ws in list(_chat_connections):
            try:
                await ws.send_json(message)
            except Exception:
                stale.append(ws)
        for ws in stale:
            try:
                _chat_connections.remove(ws)
            except ValueError:
                pass


class _WsRateLimiter:
    """Per-connection sliding window rate limiter for WebSocket messages."""

    def __init__(self, max_msgs: int = _WS_RATE_LIMIT, window_s: float = _WS_RATE_WINDOW):
        self._max_msgs = max_msgs
        self._window_s = window_s
        self._timestamps: list[float] = []

    def check(self) -> bool:
        """Return True if message is allowed, False if rate exceeded."""
        import time as _t
        now = _t.monotonic()
        cutoff = now - self._window_s
        self._timestamps = [ts for ts in self._timestamps if ts > cutoff]
        if len(self._timestamps) >= self._max_msgs:
            return False
        self._timestamps.append(now)
        return True


async def _add_chat_connection(ws: WebSocket) -> bool:
    """Add a WebSocket to chat connections. Returns False if limit reached."""
    async with _chat_lock:
        if len(_chat_connections) >= _MAX_WS_CONNECTIONS:
            return False
        _chat_connections.append(ws)
        return True


async def _remove_chat_connection(ws: WebSocket):
    """Safely remove a WebSocket from the connections list."""
    async with _chat_lock:
        try:
            _chat_connections.remove(ws)
        except ValueError:
            pass


def _validate_ws_origin(websocket: WebSocket) -> bool:
    """Reject WebSocket connections from untrusted origins."""
    import ipaddress as _ipaddress
    origin = (websocket.headers.get("origin") or "").lower()
    if not origin:
        return True  # No origin = non-browser client (CLI, etc.)
    from urllib.parse import urlparse
    parsed = urlparse(origin)
    host = parsed.hostname or ""
    if host in ("localhost", "127.0.0.1", "::1"):
        return True
    # Allow Tailscale IPs (100.64.0.0/10 CGNAT range — RFC 6598)
    # Only reachable from authenticated Tailscale peers, so this is safe
    try:
        addr = _ipaddress.ip_address(host)
        if addr in _ipaddress.ip_network("100.64.0.0/10"):
            return True
    except ValueError:
        pass  # Not an IP address — fall through to CORS check
    # Check configured CORS origins
    allowed = os.environ.get("AIBRAIN_CORS_ORIGINS", "").lower()
    if allowed and origin in [o.strip() for o in allowed.split(",")]:
        return True
    return False


@app.websocket("/ws/chat")
async def chat_websocket(websocket: WebSocket):
    if not _validate_ws_origin(websocket):
        await websocket.close(code=4004, reason="Origin not allowed")
        return
    await websocket.accept()

    # Require auth before any data exchange
    if not await ws_authenticate(websocket):
        return

    if not await _add_chat_connection(websocket):
        await websocket.close(code=1013, reason="Too many connections")
        return

    rate_limiter = _WsRateLimiter()

    try:
        # Send chat history on connect
        await websocket.send_json({
            "type": "history",
            "messages": _chat_history[-50:],
            "pending_approvals": aq_pending(APPROVAL_DB),
        })

        while True:
            try:
                data = await websocket.receive_json()
            except (json.JSONDecodeError, ValueError):
                await websocket.send_json({
                    "type": "error",
                    "content": "Invalid message format — expected JSON.",
                })
                continue

            msg_type = data.get("type", "message")

            if msg_type == "message":
                # Rate limit: max 30 messages per minute per connection
                if not rate_limiter.check():
                    await websocket.close(code=4008, reason="Rate limit exceeded — max 30 messages per minute")
                    return
                content = (data.get("content") or "").strip()
                if not content:
                    await websocket.send_json({
                        "type": "error",
                        "content": "Empty message.",
                    })
                    continue
                if len(content) > _MAX_MSG_SIZE:
                    await websocket.send_json({
                        "type": "error",
                        "content": f"Message too long ({len(content)} chars, max {_MAX_MSG_SIZE}).",
                    })
                    continue

                target = data.get("to", _CHAT_TARGET)

                chat_msg = {
                    "type": "message",
                    "role": "user",
                    "content": content,
                    "target": target,
                    "timestamp": datetime.now().isoformat(),
                }
                _chat_history.append(chat_msg)
                if len(_chat_history) > _MAX_HISTORY:
                    _chat_history[:] = _chat_history[-_MAX_HISTORY:]

                await _broadcast_chat(chat_msg)

                # Send to broker for active agents
                broker_sent = await asyncio.to_thread(
                    _send_to_broker, _CHAT_AGENT_ID, target, content
                )

                # Wait for agent reply via broker
                agent_reply = None
                if broker_sent:
                    for _ in range(6):
                        await asyncio.sleep(1)
                        replies = await asyncio.to_thread(
                            _check_broker_replies, _CHAT_AGENT_ID
                        )
                        for r in replies:
                            peer = r.get("from_agent", "")
                            if not _KNOWN_PEERS or peer in _KNOWN_PEERS:
                                agent_reply = r.get("content", "")
                                break
                        if agent_reply:
                            break

                if agent_reply:
                    agent_msg = {
                        "type": "message",
                        "role": "agent",
                        "from": target,
                        "content": agent_reply,
                        "timestamp": datetime.now().isoformat(),
                    }
                    _chat_history.append(agent_msg)
                    await _broadcast_chat(agent_msg)
                else:
                    # No agent responded — fall back to commands then CLI
                    response = _handle_chat_command(content)
                    if not response:
                        try:
                            response = await asyncio.to_thread(
                                llm_respond, content, _chat_history[-20:]
                            )
                        except Exception as e:
                            logger.error("LLM respond failed: %s", e, exc_info=True)
                            response = f"Agent error: {str(e)[:200]}"

                    if response:
                        agent_msg = {
                            "type": "message",
                            "role": "agent",
                            "content": f"[auto] {response}",
                            "timestamp": datetime.now().isoformat(),
                        }
                        _chat_history.append(agent_msg)
                        await _broadcast_chat(agent_msg)

            elif msg_type == "ping":
                await websocket.send_json({"type": "pong"})

    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.warning("Chat WebSocket error: %s", e)
    finally:
        await _remove_chat_connection(websocket)


# ---------------------------------------------------------------------------
# Notification WebSocket — real-time events for Activity, Approvals, etc.
# ---------------------------------------------------------------------------
_notify_connections: list[WebSocket] = []
_notify_lock = asyncio.Lock()


async def broadcast_notification(event: dict):
    """Send a real-time notification to all connected notification clients.
    Call this from anywhere to push events to the frontend.
    event should have at minimum: {"type": "activity|approval|system", ...}
    """
    event.setdefault("timestamp", datetime.now().isoformat())
    async with _notify_lock:
        stale = []
        for ws in list(_notify_connections):
            try:
                await ws.send_json(event)
            except Exception:
                stale.append(ws)
        for ws in stale:
            try:
                _notify_connections.remove(ws)
            except ValueError:
                pass

# Wire up notification callback so aibrain_api can broadcast events
set_notify_callback(broadcast_notification)
set_reactive_notify(broadcast_notification)


@app.websocket("/ws/notifications")
async def notification_websocket(websocket: WebSocket):
    if not _validate_ws_origin(websocket):
        await websocket.close(code=4004, reason="Origin not allowed")
        return
    await websocket.accept()

    # Require auth before any data exchange
    if not await ws_authenticate(websocket):
        return

    async with _notify_lock:
        if len(_notify_connections) >= _MAX_WS_CONNECTIONS:
            await websocket.close(code=1013, reason="Too many connections")
            return
        _notify_connections.append(websocket)
    try:
        # Send initial state
        await websocket.send_json({
            "type": "connected",
            "pending_approvals": aq_pending(APPROVAL_DB),
            "timestamp": datetime.now().isoformat(),
        })
        while True:
            try:
                data = await websocket.receive_json()
            except (json.JSONDecodeError, ValueError):
                continue
            if data.get("type") == "ping":
                await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        pass
    except Exception as e:
        logger.warning("Notification WebSocket error: %s", e)
    finally:
        async with _notify_lock:
            try:
                _notify_connections.remove(websocket)
            except ValueError:
                pass


@app.get("/api/agent/chat/history")
async def chat_history(limit: int = Query(50)):
    """Get recent chat history via REST (for non-WebSocket clients)."""
    from security import safe_limit
    limit = safe_limit(limit, 200)
    return {"messages": _chat_history[-limit:], "total": len(_chat_history)}


def _strip_markdown_fences(text: str) -> str:
    """Strip markdown code fences from LLM response, returning just the inner content."""
    import re
    # Match ```lang\n...\n``` or ```\n...\n```
    pattern = r'```(?:html|javascript|js|css|python|bash|sh)?\n([\s\S]*?)\n```'
    match = re.search(pattern, text)
    if match:
        return match.group(1).strip()
    return text


@app.post("/api/agent/chat/send")
async def chat_send(body: dict):
    """Send a chat message — routes through peer broker so active agents can respond."""
    content = (body.get("content") or "").strip()
    if not content:
        return JSONResponse({"error": "content required"}, status_code=400)
    if len(content) > _MAX_MSG_SIZE:
        return JSONResponse({"error": f"message too long ({len(content)} chars, max {_MAX_MSG_SIZE})"}, status_code=400)

    target = body.get("to", _CHAT_TARGET)  # Allow targeting specific peer agents

    chat_msg = {
        "type": "message",
        "role": "user",
        "content": content,
        "target": target,
        "timestamp": datetime.now().isoformat(),
    }
    _chat_history.append(chat_msg)
    if len(_chat_history) > _MAX_HISTORY:
        _chat_history[:] = _chat_history[-_MAX_HISTORY:]

    await _broadcast_chat(chat_msg)

    # Send to broker so the actual agent can pick it up
    broker_sent = await asyncio.to_thread(_send_to_broker, _CHAT_AGENT_ID, target, content)

    if broker_sent:
        # Wait a few seconds for an agent reply via broker
        agent_reply = None
        for _ in range(6):  # Poll for up to 6 seconds
            await asyncio.sleep(1)
            replies = await asyncio.to_thread(_check_broker_replies, _CHAT_AGENT_ID)
            for r in replies:
                peer = r.get("from_agent", "")
                if not _KNOWN_PEERS or peer in _KNOWN_PEERS:
                    agent_reply = r.get("content", "")
                    break
            if agent_reply:
                break

        if agent_reply:
            agent_msg = {
                "type": "message",
                "role": "agent",
                "from": target,
                "content": agent_reply,
                "timestamp": datetime.now().isoformat(),
            }
            _chat_history.append(agent_msg)
            await _broadcast_chat(agent_msg)
            return {"sent": chat_msg, "response": agent_msg}

    # No agent responded — fall back to commands then CLI
    response = _handle_chat_command(content)
    if not response:
        try:
            source = body.get("source", "")
            system_prompt = None
            if source == "buildit":
                system_prompt = (
                    "You are Buildit — an AI builder that creates real, working software. "
                    "When asked for a web app, game, or browser tool: create a single self-contained HTML file "
                    "with all CSS and JS inline. The file must run immediately in a browser. "
                    "When asked for a Python script, native app, or other non-browser output: "
                    "create the appropriate files (main.py, requirements.txt, etc.). "
                    "Always build something complete and functional — no stubs, no placeholders. "
                    "Do not add explanatory text around the code, just build it."
                )
            response = await asyncio.to_thread(llm_respond, content, _chat_history[-20:], system_prompt=system_prompt)
            if source == "buildit" and response:
                response = _strip_markdown_fences(response)
        except Exception as e:
            logger.error("REST chat LLM error: %s", e, exc_info=True)
            response = f"Agent error: {str(e)[:200]}"

    if response:
        content_prefix = "" if source == "buildit" else "[auto] "
        agent_msg = {
            "type": "message",
            "role": "agent",
            "content": f"{content_prefix}{response}",
            "timestamp": datetime.now().isoformat(),
        }
        _chat_history.append(agent_msg)
        await _broadcast_chat(agent_msg)
        return {"sent": chat_msg, "response": agent_msg}

    return {"sent": chat_msg, "response": None}


@app.post("/api/agent/chat/upload")
async def chat_upload(file: UploadFile):
    """Upload a file and return its content for chat context."""
    UPLOAD_DIR = AIBRAIN_ROOT / "uploads"
    UPLOAD_DIR.mkdir(exist_ok=True)

    ALLOWED_EXTENSIONS = {
        ".txt", ".md", ".py", ".js", ".ts", ".jsx", ".tsx", ".json",
        ".yaml", ".yml", ".toml", ".csv", ".log", ".sh", ".bash",
        ".html", ".css", ".xml", ".rst", ".ini", ".cfg", ".conf",
        ".sql", ".r", ".go", ".rs", ".java", ".c", ".cpp", ".h",
    }
    import os as _os
    _, ext = _os.path.splitext((file.filename or "").lower())
    if ext not in ALLOWED_EXTENSIONS:
        return JSONResponse(
            {"error": f"File type '{ext or 'unknown'}' not allowed. Upload text-based files only."},
            status_code=415,
        )

    max_size = 5 * 1024 * 1024  # 5MB
    chunks = []
    total = 0
    while True:
        chunk = await file.read(65536)
        if not chunk:
            break
        total += len(chunk)
        if total > max_size:
            return JSONResponse({"error": f"File too large. Maximum size: {max_size // 1024 // 1024}MB"}, status_code=413)
        chunks.append(chunk)
    content = b"".join(chunks)

    # Save file
    import re as _re
    safe_name = _re.sub(r'[^a-zA-Z0-9._-]', '_', file.filename)[:100]
    save_path = (UPLOAD_DIR / safe_name).resolve()
    if not str(save_path).startswith(str(UPLOAD_DIR.resolve())):  # noqa:PATH STARTSWITH BYPASS
        return JSONResponse({"error": "Invalid filename"}, status_code=400)
    save_path.write_bytes(content)

    # Try to extract text content
    text_content = None
    try:
        text_content = content.decode("utf-8")
    except (UnicodeDecodeError, ValueError):
        text_content = f"[Binary file: {safe_name}, {len(content)} bytes]"

    # Truncate very large text
    if text_content and len(text_content) > 50000:
        text_content = text_content[:50000] + f"\n... [truncated, {len(content)} bytes total]"

    return {
        "filename": safe_name,
        "size": len(content),
        "path": safe_name,
        "text_preview": text_content[:2000] if text_content else None,
        "text_content": text_content,
    }


def _handle_chat_command(content: str) -> str | None:
    """Handle built-in chat commands. Returns response or None."""
    cmd = content.strip().lower()

    if cmd in ("status", "/status"):
        sched = get_scheduler_status()
        pending = aq_pending(APPROVAL_DB)
        return (
            f"Scheduler: {'running' if sched['running'] else 'stopped'} ({sched['job_count']} jobs)\n"
            f"Pending approvals: {pending}\n"
            f"Recent runs: {len(sched['run_log'])}"
        )

    if cmd in ("approvals", "/approvals", "pending"):
        items = aq_list(APPROVAL_DB, status="pending", limit=10)
        if not items:
            return "No pending approvals."
        lines = [f"Pending approvals ({len(items)}):"]
        for item in items:
            lines.append(f"  [{item['id']}] [{item['category']}] {item['title']}")
        return "\n".join(lines)

    if cmd in ("schedule", "/schedule", "jobs"):
        sched = get_scheduler_status()
        if not sched["jobs"]:
            return "No scheduled jobs."
        lines = [f"Scheduled jobs ({sched['job_count']}):"]
        for job in sched["jobs"][:15]:
            lines.append(f"  {job['name']:25s} next: {job['next_run'] or 'paused'}")
        return "\n".join(lines)

    if cmd in ("help", "/help"):
        return (
            "Available commands:\n"
            "  /status     — scheduler + approval summary\n"
            "  /approvals  — list pending approval items\n"
            "  /schedule   — list scheduled jobs\n"
            "  /costs      — LLM cost summary\n"
            "  /content    — generate content posts\n"
            "  /create     — create a workflow from description\n"
            "  /help       — show this help\n"
            "\nOr type anything — your message goes to the AI agent."
        )

    # /costs — show LLM cost summary
    if cmd in ("costs", "/costs", "spending"):
        try:
            from trace_logger import get_cost_summary
            summary = get_cost_summary(30)
            lines = [f"LLM Costs (last 30 days): ${summary['total_cost_usd']:.4f}"]
            for m in summary.get("by_model", [])[:5]:
                lines.append(f"  {m['model']}: ${m['cost']:.4f} ({m['calls']} calls)")
            if not summary.get("by_model"):
                lines.append("  No LLM calls tracked yet.")
            return "\n".join(lines)
        except Exception as e:
            logger.warning("Cost tracking query failed: %s", e)
            return "Cost tracking not initialized yet. Make an LLM call first."

    # /content — generate content posts
    if cmd in ("content", "/content", "generate content"):
        try:
            import sys
            sys.path.insert(0, str(AIBRAIN_ROOT / "workflows"))
            from content_calendar import generate_posts, save_state
            from approval_queue import add_item as _aq_add

            state, posts = generate_posts(count=5)
            save_state(state)
            for post in posts:
                _aq_add(
                    APPROVAL_DB,
                    category="social",
                    title=f"Post to {post['platform']}: {post['text'][:60]}...",
                    detail=post["text"],
                    payload={"action": "publish", "platform": post["platform"], "content": post["text"]},
                )
            return f"Generated {len(posts)} content posts. Check the Approval Queue to review and publish."
        except Exception as e:
            return f"Content generation error: {str(e)[:200]}"

    # /create <description> — create workflow from natural language
    if cmd.startswith("/create ") or cmd.startswith("create workflow "):
        description = content.strip()
        if cmd.startswith("/create"):
            description = content.strip()[8:].strip()
        elif cmd.startswith("create workflow"):
            description = content.strip()[16:].strip()
        if not description:
            return "Usage: /create <description>\nExample: /create Every morning check my email and summarize it"
        try:
            from workflow_generator import generate_workflow
            result = generate_workflow(description)
            return f"Workflow created: {result['name']}\nSchedule: {result['cron']}\nCategory: {result['category']}\nEdit: workflows/{result['name']}.py"
        except Exception as e:
            return f"Workflow creation error: {str(e)[:200]}"

    # Not a command — just a message. Agent will pick it up.
    return None


# ---------------------------------------------------------------------------
# Stripe Checkout + Webhook Endpoints
# ---------------------------------------------------------------------------

def _license_valid_until_and_grace() -> tuple:
    """Compute valid_until (now+31d) and grace_until (now+34d) as ISO strings."""
    from datetime import timedelta
    now = datetime.utcnow()
    valid_until = (now + timedelta(days=31)).strftime("%Y-%m-%dT%H:%M:%SZ")
    grace_until = (now + timedelta(days=34)).strftime("%Y-%m-%dT%H:%M:%SZ")
    return valid_until, grace_until


def _write_license_state_per_user(
    *,
    tier: str,
    email: str,
    customer_id: str,
    subscription_id: str,
    license_key: str,
    client_reference_id: str,
    raw_event_type: str,
    raw_data: dict,
    machine_fingerprint: str = "",
) -> None:
    """Resolve a Stripe event to a local user and upsert license_state.

    Resolution order:
      1. client_reference_id → users.id
      2. email → users.email (case-insensitive via COLLATE NOCASE on the column)
      3. Neither → unattributed_license_events, no license_state touch.

    Honest-null: never fabricate a user_id. Unresolved events go to the
    audit table for manual reconciliation.
    """
    import json as _json
    conn = aibrain_db.get_db()
    user_id = ""
    # 1. client_reference_id lookup
    if client_reference_id:
        row = conn.execute(
            "SELECT id FROM users WHERE id = ?", (client_reference_id,)
        ).fetchone()
        if row:
            user_id = row["id"]
    # 2. email lookup (only if crid didn't resolve)
    if not user_id and email:
        row = conn.execute(
            "SELECT id FROM users WHERE email = ?", (email,)
        ).fetchone()
        if row:
            user_id = row["id"]

    if not user_id:
        # Honest-null — log to unattributed table, do NOT write license_state
        conn.execute(
            """INSERT INTO unattributed_license_events
               (event_type, tier, email, stripe_customer_id, stripe_subscription_id,
                license_key, raw_data)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (
                raw_event_type,
                tier,
                email,
                customer_id,
                subscription_id,
                license_key,
                _json.dumps(raw_data),
            ),
        )
        conn.commit()
        logger.warning(
            "Stripe event unattributed (no user match): type=%s email=%s customer=%s",
            raw_event_type, email, customer_id,
        )
        return

    valid_until, grace_until = _license_valid_until_and_grace()

    # Compute key_hash for indexed lookup — SHA-256 of the raw license key.
    # Stored alongside license_key so the status endpoint can use WHERE key_hash=?
    # (O(1) index seek) instead of a full-table LIKE scan.
    import hashlib as _hashlib
    _key_hash = _hashlib.sha256(license_key.encode()).hexdigest() if license_key else ""

    # Upsert license_state for the resolved user — sets state=VALID, valid_until, grace_until.
    # On first activation also records machine_fingerprint and activation_count.
    conn.execute(
        """INSERT INTO license_state
           (user_id, tier, license_key, stripe_customer_id, stripe_subscription_id,
            state, valid_until, grace_until, machine_fingerprint, activation_count,
            key_hash, updated_at)
           VALUES (?, ?, ?, ?, ?, 'VALID', ?, ?, ?, 1, ?, datetime('now'))
           ON CONFLICT(user_id) DO UPDATE SET
               tier = excluded.tier,
               license_key = excluded.license_key,
               stripe_customer_id = excluded.stripe_customer_id,
               stripe_subscription_id = excluded.stripe_subscription_id,
               state = 'VALID',
               valid_until = excluded.valid_until,
               grace_until = excluded.grace_until,
               machine_fingerprint = CASE
                   WHEN license_state.machine_fingerprint IS NULL OR license_state.machine_fingerprint = ''
                   THEN excluded.machine_fingerprint
                   ELSE license_state.machine_fingerprint
               END,
               activation_count = license_state.activation_count + 1,
               key_hash = excluded.key_hash,
               updated_at = datetime('now')""",
        (user_id, tier, license_key, customer_id, subscription_id,
         valid_until, grace_until, machine_fingerprint or "", _key_hash),
    )
    conn.commit()
    logger.info(
        "license_state upserted: user_id=%s tier=%s customer=%s valid_until=%s",
        user_id, tier, customer_id, valid_until,
    )


def _extend_license_state_by_subscription_id(subscription_id: str) -> bool:
    """Extend valid_until for a known subscription after successful payment.

    Returns True if a row was found and updated, False otherwise.
    """
    if not subscription_id:
        return False
    conn = aibrain_db.get_db()
    valid_until, grace_until = _license_valid_until_and_grace()
    cursor = conn.execute(
        """UPDATE license_state
           SET state = 'VALID',
               valid_until = ?,
               grace_until = ?,
               updated_at = datetime('now')
           WHERE stripe_subscription_id = ?""",
        (valid_until, grace_until, subscription_id),
    )
    conn.commit()
    if cursor.rowcount > 0:
        logger.info(
            "license_state extended: subscription=%s valid_until=%s",
            subscription_id, valid_until,
        )
        return True
    return False


def _set_grace_period_by_subscription_id(subscription_id: str) -> bool:
    """On subscription deletion, set grace_until = valid_until + 3 days.

    We do NOT immediately invalidate — we keep state=VALID and set grace_until
    so the status endpoint returns valid during the 3-day grace window.
    The expiry check at query time (status endpoint and validate_key) enforces
    INVALID after grace_until elapses.
    """
    if not subscription_id:
        return False
    from datetime import timedelta
    conn = aibrain_db.get_db()
    row = conn.execute(
        "SELECT valid_until FROM license_state WHERE stripe_subscription_id = ?",
        (subscription_id,),
    ).fetchone()
    if not row:
        return False
    valid_until_str = (row["valid_until"] if isinstance(row, dict) else row[0]) or ""
    if valid_until_str:
        try:
            vu_dt = datetime.fromisoformat(valid_until_str.replace("Z", ""))
            grace_dt = vu_dt + timedelta(days=3)
            grace_until = grace_dt.strftime("%Y-%m-%dT%H:%M:%SZ")
        except (ValueError, TypeError):
            _, grace_until = _license_valid_until_and_grace()
    else:
        # valid_until not set — use now + 3 days as fallback
        grace_until = (datetime.utcnow() + timedelta(days=3)).strftime("%Y-%m-%dT%H:%M:%SZ")

    cursor = conn.execute(
        """UPDATE license_state
           SET grace_until = ?,
               updated_at = datetime('now')
           WHERE stripe_subscription_id = ?""",
        (grace_until, subscription_id),
    )
    conn.commit()
    return cursor.rowcount > 0


@app.post("/api/checkout")
async def create_checkout_session(request: Request):
    """Create a Stripe Checkout session for a subscription tier.

    Body: {"tier": "pro" | "team" | "enterprise", "interval": "monthly" | "yearly" (optional), "email": str (optional)}
    Returns: {"checkout_url": "https://checkout.stripe.com/..."}
    """
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "Request body must be valid JSON"}, status_code=400)

    tier = body.get("tier", "").lower()
    interval = body.get("interval", "monthly").lower()
    email = body.get("email", "")

    if not tier:
        return JSONResponse({"error": "tier is required (pro, team, enterprise)"}, status_code=400)

    if tier not in ("pro", "team", "enterprise"):
        return JSONResponse(
            {"error": f"Invalid tier '{tier}'. Must be one of: pro, team, enterprise"},
            status_code=400,
        )

    if interval not in ("monthly", "yearly"):
        return JSONResponse(
            {"error": f"Invalid interval '{interval}'. Must be monthly or yearly"},
            status_code=400,
        )

    try:
        from aibrain_payments import PaymentManager
    except ImportError:
        return JSONResponse({"error": "Payments module not available"}, status_code=503)

    pm = PaymentManager()
    if not pm.available:
        return JSONResponse(
            {"error": "Stripe not configured — set STRIPE_SECRET_KEY in environment"},
            status_code=503,
        )

    # Resolve the logged-in user ID (for client_reference_id → Stripe webhook → license_state)
    # Try session cookie first (normal browser auth), then JWT state (API auth)
    client_reference_id: str = ""
    try:
        from auth import sessions as _sessions
        _session_token = request.cookies.get(_sessions.COOKIE_NAME)
        _user_row = _sessions.load_session(_session_token) if _session_token else None
        if _user_row:
            client_reference_id = str(_user_row["id"])
    except Exception:
        pass
    if not client_reference_id:
        # Fallback: JWT middleware attaches the sub claim to request.state.user
        _state_user = getattr(request.state, "user", None)
        if _state_user and _state_user != "anonymous":
            client_reference_id = str(_state_user)

    try:
        result = pm.create_subscription_checkout(
            tier=tier,
            email=email or None,
            interval=interval,
            client_reference_id=client_reference_id or None,
        )
    except ValueError as e:
        # Price ID not configured for this tier/interval
        return JSONResponse({"error": str(e)}, status_code=422)
    except Exception as e:
        logger.error("Stripe checkout error for tier=%s: %s", tier, e)
        return JSONResponse({"error": "Failed to create checkout session"}, status_code=500)

    logger.info("Checkout session created: tier=%s interval=%s session=%s",
                tier, interval, result.get("session_id", ""))

    return {"checkout_url": result["url"], "session_id": result["session_id"]}


@app.post("/api/checkout/portal")
async def create_portal_session(request: Request):
    """Create a Stripe Customer Portal session for billing self-service.

    Resolves customer_id from the authenticated user's own license_state row —
    never accepts customer_id from the request body (IDOR prevention).
    Returns: {"portal_url": "https://billing.stripe.com/..."}
    """
    # Resolve customer_id from the authenticated user — never trust the request body
    user_id = getattr(request.state, "user", None)
    if not user_id:
        return JSONResponse({"error": "Authentication required"}, status_code=401)

    from auth.db import get_conn as _get_auth_conn
    try:
        _conn = _get_auth_conn()
        row = _conn.execute(
            "SELECT stripe_customer_id FROM license_state WHERE user_id = ?", (user_id,)
        ).fetchone()
        _conn.close()
    except Exception:
        row = None

    customer_id = (row["stripe_customer_id"] if row else None) or ""
    if not customer_id:
        return JSONResponse({"error": "No Stripe subscription found for this account"}, status_code=404)

    try:
        from aibrain_payments import PaymentManager
    except ImportError:
        return JSONResponse({"error": "Payments module not available"}, status_code=503)

    pm = PaymentManager()
    if not pm.available:
        return JSONResponse(
            {"error": "Stripe not configured — set STRIPE_SECRET_KEY in environment"},
            status_code=503,
        )

    try:
        result = pm.create_portal_session(customer_id=customer_id)
    except Exception as e:
        logger.error("Stripe portal error for customer=%s: %s", customer_id, e)
        return JSONResponse({"error": "Failed to create portal session"}, status_code=500)

    return {"portal_url": result["url"]}


@app.post("/webhooks/stripe")
async def stripe_webhook(request: Request):
    """Process Stripe webhook events for subscriptions and marketplace."""
    try:
        from aibrain_payments import PaymentManager
    except ImportError:
        return {"error": "Payments not configured"}

    pm = PaymentManager()
    if not pm.available:
        return {"error": "Stripe not configured"}

    payload = await request.body()
    sig = request.headers.get("stripe-signature", "")

    result = pm.handle_webhook(payload, sig)

    if result.get("action") == "subscription_activated":
        data = result["data"]
        tier = data.get("tier", "pro")
        email = data.get("email", "")
        customer_id = data.get("customer_id", "")
        subscription_id = data.get("subscription_id", "")
        license_key = data.get("license_key", "")
        client_reference_id = data.get("client_reference_id", "")
        logger.info("New subscription: %s for %s (customer=%s)", tier, email, customer_id)

        # --- Per-user license_state write (item 3 of stripe split-brain fix) ---
        # Resolution order:
        #   1. Stripe session.client_reference_id → users.id lookup
        #   2. Stripe customer_email → users.email lookup (case-insensitive)
        #   3. Unattributed → unattributed_license_events table (no license_state write)
        try:
            _write_license_state_per_user(
                tier=tier,
                email=email,
                customer_id=customer_id,
                subscription_id=subscription_id,
                license_key=license_key,
                client_reference_id=client_reference_id,
                raw_event_type="checkout.session.completed",
                raw_data=data,
            )
        except Exception as e:
            logger.error("Failed to write per-user license_state: %s", e)

        # --- Legacy compat: also write the global config.tier so existing
        # single-tenant installs keep working until they migrate to per-user
        # auth. Remove this block once all deployments have user accounts. ---
        try:
            aibrain_db.config_set(
                "tier", tier,
                changed_by="stripe_webhook",
                reason=f"Subscription activated for {email} (customer={customer_id})",
            )
            # Bust the tier cache so next request sees the upgrade immediately
            from tiers import invalidate_cache
            invalidate_cache()
            logger.info("Tier saved to DB: %s (triggered by Stripe webhook for %s)", tier, email)
        except Exception as e:
            logger.error("Failed to save tier to DB after Stripe webhook: %s", e)

    elif result.get("action") == "subscription_changed":
        data = result["data"]
        tier = data.get("tier", "")
        status = data.get("status", "")
        customer_id = data.get("customer_id", "")
        logger.info("Subscription changed: tier=%s status=%s customer=%s", tier, status, customer_id)

        # Sync tier if status is active; downgrade to free if cancelled/unpaid
        if status in ("active", "trialing") and tier in ("pro", "team", "enterprise"):
            try:
                aibrain_db.config_set(
                    "tier", tier,
                    changed_by="stripe_webhook",
                    reason=f"Subscription updated: status={status}, customer={customer_id}",
                )
                from tiers import invalidate_cache
                invalidate_cache()
                logger.info("Tier updated in DB: %s (status=%s)", tier, status)
            except Exception as e:
                logger.error("Failed to update tier in DB: %s", e)
        elif status in ("canceled", "unpaid", "past_due"):
            try:
                aibrain_db.config_set(
                    "tier", "free",
                    changed_by="stripe_webhook",
                    reason=f"Subscription {status} for customer={customer_id}",
                )
                from tiers import invalidate_cache
                invalidate_cache()
                logger.info("Tier downgraded to free (subscription %s)", status)
            except Exception as e:
                logger.error("Failed to downgrade tier in DB: %s", e)

    elif result.get("action") == "brain_purchased":
        logger.info("Brain purchased: %s by %s",
                     result["data"].get("brain_id"), result["data"].get("buyer_email"))

    elif result.get("action") == "subscription_cancelled":
        data = result["data"]
        sub_id = data.get("subscription_id", "")
        logger.info("Subscription cancelled: %s", sub_id)
        # Set grace period on license_state — state stays VALID until grace_until elapses.
        # The status endpoint and validate_key enforce INVALID after that window.
        try:
            _set_grace_period_by_subscription_id(sub_id)
        except Exception as e:
            logger.error("Failed to set grace period for sub %s: %s", sub_id, e)
        # Also keep the legacy global config in sync for existing single-tenant installs
        try:
            aibrain_db.config_set(
                "tier", "free",
                changed_by="stripe_webhook",
                reason=f"Subscription cancelled: {sub_id}",
            )
            from tiers import invalidate_cache
            invalidate_cache()
            logger.info("Tier downgraded to free after cancellation (grace period set for per-user row)")
        except Exception as e:
            logger.error("Failed to downgrade tier after cancellation: %s", e)

    elif result.get("action") == "payment_succeeded":
        data = result["data"]
        sub_id = data.get("subscription_id", "")
        customer_id = data.get("customer_id", "")
        logger.info("Payment succeeded: customer=%s sub=%s", customer_id, sub_id)
        # Extend valid_until by 31 days from now (renewal or late payment)
        try:
            updated = _extend_license_state_by_subscription_id(sub_id)
            if not updated:
                logger.warning("payment_succeeded: no license_state row for sub=%s", sub_id)
        except Exception as e:
            logger.error("Failed to extend license_state for sub %s: %s", sub_id, e)

    return {"status": "ok", "action": result.get("action", "ignored")}


# ---------------------------------------------------------------------------
# License status endpoint — server is source of truth for subscription state
# ---------------------------------------------------------------------------

@app.get("/api/license/status/{key_hash}")
async def license_status(key_hash: str, request: Request):
    """Get the server-side license state for a key_hash.

    Returns VALID/INVALID state, valid_until, days_remaining, and grace_period flag.
    Admin callers (X-Admin-Token header) get the full license_state row.

    Fails open by design: callers that receive a non-200 response must not
    block the user (validate_key in aibrain_licensing.py handles that).
    """
    if not key_hash or len(key_hash) < 16:
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail="Invalid key_hash")

    conn = aibrain_db.get_db()
    # O(1) indexed lookup via key_hash column (idx_license_state_key_hash).
    # Replaces the former full-table LIKE scan on license_key.
    row = conn.execute(
        """SELECT user_id, tier, state, valid_until, grace_until,
                  machine_fingerprint, activation_count, updated_at
           FROM license_state
           WHERE key_hash = ?
           LIMIT 1""",
        (key_hash,),
    ).fetchone()

    if not row:
        # Try the license_activations table which stores key_hash directly
        act_row = conn.execute(
            "SELECT key_hash FROM license_activations WHERE key_hash = ?",
            (key_hash,),
        ).fetchone()
        if not act_row:
            return JSONResponse(
                {"state": "INVALID", "valid_until": None, "days_remaining": 0,
                 "grace_period": False, "reason": "Unknown key"},
                status_code=404,
            )
        # We know the key exists but have no per-user row → treat as VALID (free tier)
        return {"state": "VALID", "valid_until": None, "days_remaining": None,
                "grace_period": False}

    row = dict(row)
    state = row.get("state") or "VALID"
    valid_until_str = row.get("valid_until") or ""
    grace_until_str = row.get("grace_until") or ""

    # Compute days remaining
    days_remaining = None
    grace_period = False
    now = datetime.utcnow()

    if valid_until_str:
        try:
            vu_dt = datetime.fromisoformat(valid_until_str.replace("Z", ""))
            delta = (vu_dt - now).total_seconds()
            days_remaining = max(0, int(delta / 86400))
            # Has valid_until passed? If so check grace window
            if delta < 0 and grace_until_str:
                try:
                    gu_dt = datetime.fromisoformat(grace_until_str.replace("Z", ""))
                    if now <= gu_dt:
                        grace_period = True
                        state = "VALID"  # still within grace window — treat as VALID
                    else:
                        state = "INVALID"
                except (ValueError, TypeError):
                    state = "INVALID"
            elif delta < 0:
                state = "INVALID"
        except (ValueError, TypeError):
            pass

    _admin_token = os.environ.get("AIBRAIN_ADMIN_TOKEN", "").strip()
    # Explicit length check: empty/unset token must NEVER grant admin access
    _provided_token = (request.headers.get("X-Admin-Token") or "").strip()
    is_admin = bool(_admin_token) and bool(_provided_token) and _provided_token == _admin_token
    if is_admin:
        return {
            "state": state,
            "valid_until": valid_until_str or None,
            "days_remaining": days_remaining,
            "grace_period": grace_period,
            "machine_fingerprint": row.get("machine_fingerprint") or None,
            "activation_count": row.get("activation_count"),
            "tier": row.get("tier"),
            "user_id": row.get("user_id"),
            "updated_at": row.get("updated_at"),
        }

    return {
        "state": state,
        "valid_until": valid_until_str or None,
        "days_remaining": days_remaining,
        "grace_period": grace_period,
        "machine_fingerprint": row.get("machine_fingerprint") or None,
    }


# ---------------------------------------------------------------------------
# Onboarding phase tracking — cohort analysis
# ---------------------------------------------------------------------------

from pydantic import BaseModel as _BaseModel


class _OnboardingPhaseBody(_BaseModel):
    user_id: str = "anonymous"
    phase: int
    phase_name: str = ""
    skipped: bool = False
    session_id: str = ""


@app.post("/api/onboarding/phase-complete")
async def onboarding_phase_complete(body: _OnboardingPhaseBody):
    """Record completion or skip of an onboarding wizard phase."""
    from datetime import datetime, timezone as _tz
    user_id = body.user_id.strip() or "anonymous"
    completed_at = None if body.skipped else datetime.now(_tz.utc).isoformat()
    db = aibrain_db.get_db()
    try:
        db.execute(
            """
            INSERT INTO user_onboarding_phases
                (user_id, phase, phase_name, completed_at, skipped, session_id)
            VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                user_id,
                body.phase,
                body.phase_name or "",
                completed_at,
                1 if body.skipped else 0,
                body.session_id or "",
            ),
        )
        db.commit()
    finally:
        db.close()
    return {"ok": True}


@app.get("/api/onboarding/funnel")
async def onboarding_funnel():
    """Aggregate funnel: completion + skip counts per phase."""
    db = aibrain_db.get_db()
    try:
        rows = db.execute(
            """
            SELECT
                phase,
                MAX(phase_name) AS phase_name,
                COUNT(DISTINCT CASE WHEN skipped = 0 THEN user_id END) AS completed_users,
                COUNT(DISTINCT CASE WHEN skipped = 1 THEN user_id END) AS skipped_users,
                COUNT(DISTINCT user_id) AS total_users
            FROM user_onboarding_phases
            GROUP BY phase
            ORDER BY phase
            """
        ).fetchall()
    finally:
        db.close()

    # Find total users who reached phase 0 (the baseline denominator)
    baseline = 1
    funnel = []
    for r in rows:
        row_dict = dict(r) if hasattr(r, "keys") else {
            "phase": r[0], "phase_name": r[1],
            "completed_users": r[2], "skipped_users": r[3], "total_users": r[4],
        }
        if row_dict["phase"] == 0:
            baseline = max(1, row_dict["total_users"])
        row_dict["completion_rate"] = round(
            row_dict["completed_users"] / baseline, 4
        )
        row_dict["skip_rate"] = round(
            row_dict["skipped_users"] / max(1, row_dict["total_users"]), 4
        )
        funnel.append(row_dict)

    return {"funnel": funnel}


# ---------------------------------------------------------------------------
# Dashboard live data endpoints
# ---------------------------------------------------------------------------

@app.get("/api/dashboard/memory-stats")
async def dashboard_memory_stats():
    """Live memory statistics for the dashboard MemoryStatsPanel."""
    import json as _json
    db = aibrain_db.get_db()
    try:
        total = db.execute(
            "SELECT COUNT(*) FROM memories WHERE active = 1"
        ).fetchone()[0]

        # Type breakdown
        type_rows = db.execute(
            "SELECT type, COUNT(*) as cnt FROM memories WHERE active = 1 GROUP BY type ORDER BY cnt DESC"
        ).fetchall()
        by_type = {r[0]: r[1] for r in type_rows}

        # Average confidence — many rows have NULL; default 0.0 if none set
        avg_conf_row = db.execute(
            "SELECT AVG(confidence) FROM memories WHERE active = 1 AND confidence IS NOT NULL"
        ).fetchone()
        avg_confidence = round(float(avg_conf_row[0]), 3) if avg_conf_row[0] is not None else 0.0

        # Top tags — tags field is a comma-separated string; split and count
        tag_rows = db.execute(
            "SELECT tags FROM memories WHERE active = 1 AND tags IS NOT NULL AND tags != ''"
        ).fetchall()
        tag_counts: dict[str, int] = {}
        for (raw_tags,) in tag_rows:
            for tag in raw_tags.split(","):
                tag = tag.strip()
                if tag:
                    tag_counts[tag] = tag_counts.get(tag, 0) + 1
        top_tags = sorted(tag_counts.items(), key=lambda x: x[1], reverse=True)[:10]

        # Graph relations count
        try:
            rel_row = db.execute("SELECT COUNT(*) FROM memory_relations").fetchone()
            graph_relations = rel_row[0]
        except Exception:
            graph_relations = 0

        return {
            "total_memories": total,
            "by_type": by_type,
            "avg_confidence": avg_confidence,
            "top_tags": top_tags,
            "graph_relations": graph_relations,
        }
    finally:
        db.close()


@app.get("/api/dashboard/workflow-stats")
async def dashboard_workflow_stats():
    """Live workflow execution statistics for the dashboard WorkflowPanel."""
    db = aibrain_db.get_db()
    try:
        total = db.execute("SELECT COUNT(*) FROM execution_log").fetchone()[0]

        # Last 10 executions — use action as workflow_name (no workflow_name column)
        recent_rows = db.execute(
            """SELECT action, quality_score, cost_cents, model_used, created_at, success
               FROM execution_log
               ORDER BY created_at DESC
               LIMIT 10"""
        ).fetchall()
        recent_executions = [
            {
                "workflow_name": r[0],
                "quality_score": round(r[1], 3) if r[1] is not None else None,
                "cost_cents": r[2] if r[2] is not None else 0,
                "model_used": r[3] or "unknown",
                "created_at": r[4],
                "success": bool(r[5]),
            }
            for r in recent_rows
        ]

        # Average quality across rows that have a score
        avg_row = db.execute(
            "SELECT AVG(quality_score) FROM execution_log WHERE quality_score IS NOT NULL"
        ).fetchone()
        avg_quality = round(float(avg_row[0]), 3) if avg_row[0] is not None else 0.0

        # Success rate
        success_row = db.execute(
            "SELECT COUNT(*) FROM execution_log WHERE success = 1"
        ).fetchone()
        success_count = success_row[0]
        success_rate = round(success_count / total, 3) if total > 0 else 0.0

        return {
            "recent_executions": recent_executions,
            "total_executions": total,
            "avg_quality": avg_quality,
            "success_rate": success_rate,
        }
    finally:
        db.close()


@app.get("/api/dashboard/learning-stats")
async def dashboard_learning_stats():
    """Live 7-day learning statistics for the dashboard LearningPanel.

    evolution_outcomes stores quality/cost/model inside a JSON 'details' field,
    not as dedicated columns. We parse them out here; rows with unparseable
    details are counted but excluded from numeric averages.
    """
    import json as _json
    db = aibrain_db.get_db()
    try:
        # 7-day window
        rows_7d = db.execute(
            """SELECT details, result FROM evolution_outcomes
               WHERE created_at >= datetime('now', '-7 days')"""
        ).fetchall()

        total_7d = len(rows_7d)
        rewards: list[float] = []
        cost_sum = 0
        model_counts: dict[str, int] = {}
        consolidated = 0

        for (details_raw, result) in rows_7d:
            # Count consolidation events
            if result and "consolidat" in (result or "").lower():
                consolidated += 1

            if not details_raw:
                continue
            try:
                d = _json.loads(details_raw)
            except Exception:
                continue

            # quality / eval_score
            q = d.get("eval_score") or d.get("quality")
            if q is not None:
                try:
                    rewards.append(float(q))
                except (TypeError, ValueError):
                    pass

            # cost_cents
            c = d.get("cost_cents")
            if c is not None:
                try:
                    cost_sum += int(c)
                except (TypeError, ValueError):
                    pass

            # model_used
            m = d.get("model_used") or d.get("model_routed")
            if m:
                model_counts[m] = model_counts.get(m, 0) + 1

        avg_reward = round(sum(rewards) / len(rewards), 3) if rewards else 0.0
        consolidation_rate = round(consolidated / total_7d, 3) if total_7d > 0 else 0.0

        return {
            "evolution_outcomes_7d": total_7d,
            "consolidation_rate_7d": consolidation_rate,
            "avg_reward_7d": avg_reward,
            "cost_last_7d_cents": cost_sum,
            "model_usage": model_counts,
        }
    finally:
        db.close()


# ---------------------------------------------------------------------------
# Buildit — build persistence endpoints
# ---------------------------------------------------------------------------

@app.post("/api/buildit/save")
async def buildit_save(body: dict):
    """Persist a completed build (prompt + output) to the DB."""
    import uuid
    prompt = (body.get("prompt") or "").strip()
    output = (body.get("output") or "").strip()
    if not prompt or not output:
        return JSONResponse({"error": "prompt and output required"}, status_code=400)
    build_id = str(uuid.uuid4())
    title = prompt[:60] + ("..." if len(prompt) > 60 else "")
    now_iso = datetime.now().isoformat()
    db = aibrain_db.get_db()
    db.execute(
        "INSERT INTO buildit_builds (id, prompt, output, title, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
        (build_id, prompt, output, title, "done", now_iso, now_iso),
    )
    db.commit()
    return {"id": build_id, "prompt": prompt, "output": output, "title": title, "status": "done", "created_at": now_iso, "updated_at": now_iso}


@app.get("/api/buildit/builds")
async def buildit_list(offset: int = Query(0), limit: int = Query(20)):
    """List saved builds — id, prompt, title, status, created_at only (no output)."""
    from security import safe_limit
    limit = safe_limit(limit, 100)
    offset = max(0, offset)
    db = aibrain_db.get_db()
    rows = db.execute(
        "SELECT id, prompt, title, status, created_at, updated_at, improve_count, last_improved_at, auto_improve_interval FROM buildit_builds ORDER BY created_at DESC LIMIT ? OFFSET ?",
        (limit, offset),
    ).fetchall()
    return [dict(r) for r in rows]


@app.get("/api/buildit/builds/{build_id}")
async def buildit_get(build_id: str):
    """Fetch a single build including its full output."""
    db = aibrain_db.get_db()
    row = db.execute(
        "SELECT id, prompt, output, title, status, created_at, updated_at FROM buildit_builds WHERE id = ?",
        (build_id,),
    ).fetchone()
    if row is None:
        return JSONResponse({"error": "not found"}, status_code=404)
    return dict(row)


@app.delete("/api/buildit/builds/{build_id}")
async def buildit_delete(build_id: str):
    """Delete a saved build."""
    db = aibrain_db.get_db()
    row = db.execute("SELECT id FROM buildit_builds WHERE id = ?", (build_id,)).fetchone()
    if row is None:
        return JSONResponse({"error": "not found"}, status_code=404)
    db.execute("DELETE FROM buildit_builds WHERE id = ?", (build_id,))
    db.commit()
    return {"deleted": build_id}


@app.post("/api/buildit/schedule")
async def buildit_schedule(body: dict):
    """Set or clear the auto-improvement interval for a build.

    Body: {build_id: str, interval: '1h'|'1d'|'1w'|null}
    Passing null or empty string clears the schedule (turns off auto-improve).
    """
    build_id = body.get("build_id")
    interval = body.get("interval") or None  # coerce empty string → None

    if not build_id:
        return JSONResponse({"error": "build_id required"}, status_code=400)

    valid_intervals = {"1h", "1d", "1w", None}
    if interval not in valid_intervals:
        return JSONResponse(
            {"error": f"interval must be one of: 1h, 1d, 1w (or null to disable)"},
            status_code=400,
        )

    db = aibrain_db.get_db()
    result = db.execute(
        "UPDATE buildit_builds SET auto_improve_interval = ? WHERE id = ?",
        (interval, build_id),
    )
    if result.rowcount == 0:
        return JSONResponse({"error": "build not found"}, status_code=404)
    db.commit()
    return {"ok": True}


@app.post("/api/buildit/improve/{build_id}")
async def buildit_improve(build_id: str):
    """Run one improvement iteration on a saved build.

    Loads the current build, searches brain for prior improvement history,
    calls the LLM for one improvement pass, saves the result as a new revision,
    stores a memory entry, and updates the parent row's metadata.

    Returns: {new_build_id, improve_count, summary}
    """
    import uuid

    db = aibrain_db.get_db()

    # 1. Load the build
    row = db.execute(
        "SELECT id, prompt, output, improve_count FROM buildit_builds WHERE id = ?",
        (build_id,),
    ).fetchone()
    if row is None:
        return JSONResponse({"error": "build not found"}, status_code=404)

    prompt = row["prompt"]
    current_output = row["output"]
    prior_count = row["improve_count"] or 0

    # 2. Search brain for prior improvement history
    try:
        prior_memories = aibrain_db.search_memories(
            f"buildit improvement build {build_id}", limit=5
        )
        brain_context = "\n".join(
            m.get("content", "") for m in prior_memories if m.get("content")
        ) or "No prior improvements recorded."
    except Exception as _mem_err:
        logger.warning("buildit_improve: memory search failed: %s", _mem_err)
        brain_context = "No prior improvements recorded."

    # 3. Build prompts
    system_prompt = (
        "You are improving an existing app. Return ONLY the complete improved code "
        "with no explanation. Make ONE meaningful improvement."
    )
    user_message = (
        f"Current app (built from: {prompt}):\n\n{current_output}\n\n"
        f"Prior improvements made:\n{brain_context}\n\n"
        f"Implement one clear improvement."
    )

    # 4. Call the LLM
    try:
        improved_output = await asyncio.to_thread(
            llm_respond, user_message, [], system_prompt=system_prompt
        )
    except Exception as e:
        logger.error("buildit_improve LLM error: %s", e, exc_info=True)
        return JSONResponse({"error": f"LLM error: {str(e)[:200]}"}, status_code=500)

    # 5. Save result as a new row (child build)
    new_build_id = str(uuid.uuid4())
    new_count = prior_count + 1
    now_iso = datetime.now().isoformat()
    title = prompt[:60] + ("..." if len(prompt) > 60 else "")

    db.execute(
        """INSERT INTO buildit_builds
           (id, prompt, output, title, created_at, parent_build_id, improve_count, last_improved_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
        (new_build_id, prompt, improved_output, title, now_iso, build_id, new_count, now_iso),
    )

    # 6. Update parent row's last_improved_at and improve_count
    db.execute(
        "UPDATE buildit_builds SET last_improved_at = ?, improve_count = ? WHERE id = ?",
        (now_iso, new_count, build_id),
    )
    db.commit()

    # 7. Store memory of this improvement
    try:
        memory_content = (
            f"buildit improvement build {build_id}: "
            f"iteration {new_count} — improved from parent {build_id}, "
            f"new build id {new_build_id}"
        )
        aibrain_db.create_memory(
            name=f"buildit_improve_{build_id}_iter{new_count}",
            mem_type="completion",
            content=memory_content,
            tags="buildit,auto-improve",
            importance=0.4,
            source_agent="buildit_improve",
        )
    except Exception as _store_err:
        logger.warning("buildit_improve: memory store failed (non-fatal): %s", _store_err)

    # 8. Return result
    return {
        "new_build_id": new_build_id,
        "improve_count": new_count,
        "summary": f"Improved {prompt[:50]}{'...' if len(prompt) > 50 else ''}",
    }
