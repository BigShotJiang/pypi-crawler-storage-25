"""sec_report_kit package."""

__all__ = ["__version__"]
__version__ = "0.2.2"
