"""parser.py"""

import ast
from collections import defaultdict
from concurrent.futures import Future, as_completed
from dataclasses import dataclass

from .discovery import Module, Package, node_name_gen
from .pool import MIN_FILES_FOR_POOL, executor


@dataclass(slots=True)
class DpdmanImport:
    module: str | None
    names: list[str]
    level: int


@dataclass(slots=True)
class CallerCollection:
    module: Module
    imports: set[str]
    call_edges: dict[str, set[str]]


def node_generator(
    module: Module,
    dpdman_import: DpdmanImport,
) -> set[str]:
    """With the DpdmanImport corresponding to a module, we can create the
    import string nodes corresponding to it.
    """
    import_strings: set[str] = set()
    parents = []
    if dpdman_import.level != 0:
        module_path = list(module.path.parts)
        module_path.pop(-1)
        n = len(module_path)
        parents = module_path[: (n - (dpdman_import.level - 1))]
    if dpdman_import.module:
        parents.append(dpdman_import.module)
    import_str = ".".join(parents)

    import_strings.add(import_str)

    for name in dpdman_import.names:
        import_strings.add(f"{import_str}::{name}")
    return import_strings


def _resolve_base_module(module: Module, node: ast.ImportFrom) -> str:
    """Absolute module path for a `from ... import` statement, resolving
    relative `level`. Mirrors the parent-walking logic in `node_generator`.
    """
    parents: list[str] = []
    if node.level != 0:
        module_path = list(module.path.parts)
        module_path.pop(-1)
        n = len(module_path)
        parents = module_path[: (n - (node.level - 1))]
    if node.module:
        parents.append(node.module)
    return ".".join(parents)


def _walk_attribute_chain(
    node: ast.Attribute,
) -> tuple[str, list[str]] | None:
    """Walk an attribute chain (`np.linalg.norm`) into (root, attrs)
    ordered root-to-leaf. Returns None if the chain doesn't bottom out in
    an `ast.Name` (e.g. subscripts or calls in the middle).
    """
    parts: list[str] = []
    current: ast.expr = node
    while isinstance(current, ast.Attribute):
        parts.append(current.attr)
        current = current.value
    if not isinstance(current, ast.Name):
        return None
    parts.reverse()
    return current.id, parts


def _try_attribute_match(
    canonical_root: str,
    parts: list[str],
    project_definitions: set[str],
    project_nodes: set[str],
) -> str | None:
    """Reconstruct a canonical from a resolved root + chain parts. Tries
    every split point (which part is the callable name) and returns the
    first hit in `project_definitions`. Falls back to a pure-module match.
    """
    if "::" in canonical_root:
        # Root is a callable (class). Append trail with dots.
        candidate = ".".join([canonical_root, *parts])
        return candidate if candidate in project_definitions else None

    for i in range(len(parts)):
        prefix = [canonical_root, *parts[:i]]
        callable_name = parts[i]
        trail = parts[i + 1 :]
        base = ".".join(prefix)
        candidate = f"{base}::{callable_name}"
        if trail:
            candidate += "." + ".".join(trail)
        if candidate in project_definitions:
            return candidate

    module_candidate = ".".join([canonical_root, *parts])
    if module_candidate in project_nodes:
        return module_candidate

    return None


def _resolve(
    expr: ast.expr,
    alias_mapper: dict[str, str],
    project_definitions: set[str],
    project_nodes: set[str],
    in_scope_for_naive: set[str],
) -> set[str]:
    """Single entry point for resolving any reference expression (call
    targets, inheritance bases, decorators) into a set of project-internal
    canonicals.
    """
    # Decorator factory: `@foo(arg)` is a Call. Unwrap to its `.func`.
    if isinstance(expr, ast.Call):
        return _resolve(
            expr.func,
            alias_mapper,
            project_definitions,
            project_nodes,
            in_scope_for_naive,
        )

    if isinstance(expr, ast.Name):
        canonical = alias_mapper.get(expr.id)
        if canonical and (
            canonical in project_definitions or canonical in project_nodes
        ):
            return {canonical}
        return set()

    if isinstance(expr, ast.Attribute):
        chain = _walk_attribute_chain(expr)
        if chain is None:
            return set()
        root, parts = chain

        if root in alias_mapper:
            # Root is a known name (import or local def). The lookup is
            # authoritative: if it matches a project canonical we use it;
            # if not (e.g. `requests.Session()` — root resolves but to an
            # external canonical) we bail. Falling through to naive here
            # would over-match against any project class with a same-named
            # method.
            canonical_root = alias_mapper[root]
            resolved = _try_attribute_match(
                canonical_root, parts, project_definitions, project_nodes
            )
            return {resolved} if resolved else set()

        # Root is unknown — local variable, parameter, or comprehension
        # binding — so we genuinely can't resolve it without type info.
        # Scoped naive fallback: match the trailing attribute against
        # methods of in-scope classes.
        method_name = parts[-1]
        return {
            f"{c}.{method_name}"
            for c in in_scope_for_naive
            if f"{c}.{method_name}" in project_definitions
        }

    return set()


def _emit_resolved_refs(
    exprs: list[ast.expr],
    source: str,
    edges: dict[str, set[str]],
    alias_mapper: dict[str, str],
    project_definitions: set[str],
    project_nodes: set[str],
    in_scope_for_naive: set[str],
) -> None:
    """Resolve each expression in `exprs` and merge the results into
    `edges[source]`. Used for decorators (FunctionDef/ClassDef/method) and
    inheritance bases — three contexts that share the same shape: "a list
    of expressions that reference callables/classes."
    """
    for expr in exprs:
        edges[source].update(
            _resolve(
                expr,
                alias_mapper,
                project_definitions,
                project_nodes,
                in_scope_for_naive,
            )
        )


_PROPERTY_ROLE_SUFFIX = {
    "property": "@get",
    "setter": "@set",
    "deleter": "@del",
}


def _property_role(decorator_list: list[ast.expr]) -> str | None:
    """Detect whether a FunctionDef belongs to the property protocol and
    return its role suffix. Without this, `@property def bar`,
    `@bar.setter def bar` and `@bar.deleter def bar` collapse to a single
    `Class.bar` canonical because they share a name — set dedup throws away
    two of them and `parse_calls` then merges all three bodies' edges into
    one node.

    Only the property family is differentiated. `@typing.overload` and
    similar same-name multiplicity patterns intentionally keep collapsing,
    since they are semantically one function.
    """
    for dec in decorator_list:
        if isinstance(dec, ast.Name) and dec.id == "property":
            return _PROPERTY_ROLE_SUFFIX["property"]
        if isinstance(dec, ast.Attribute) and dec.attr in (
            "setter",
            "deleter",
        ):
            return _PROPERTY_ROLE_SUFFIX[dec.attr]
    return None


def _emit_calls_in_subtree(
    scope: ast.AST,
    source: str,
    edges: dict[str, set[str]],
    alias_mapper: dict[str, str],
    project_definitions: set[str],
    project_nodes: set[str],
    in_scope_for_naive: set[str],
) -> None:
    """Walk an AST subtree and attribute every `ast.Call` to `source`.
    Pragmatic rule: nested function/class defs aren't new sources — calls
    inside them flow up to the outermost enclosing callable.

    For each Call we also resolve any Name/Attribute argument that points
    at a project canonical — this catches the `pool.submit(handler, ...)`
    pattern where the callable is passed *as data* instead of being called
    directly. The downstream project filter inside `_resolve` keeps
    external references (`print(x)`) from polluting the edge set.
    """
    resolve_kwargs = dict(
        alias_mapper=alias_mapper,
        project_definitions=project_definitions,
        project_nodes=project_nodes,
        in_scope_for_naive=in_scope_for_naive,
    )
    for node in ast.walk(scope):
        if not isinstance(node, ast.Call):
            continue
        edges[source].update(_resolve(node.func, **resolve_kwargs))
        for arg in node.args:
            if isinstance(arg, (ast.Name, ast.Attribute)):
                edges[source].update(_resolve(arg, **resolve_kwargs))
        for kw in node.keywords:
            if isinstance(kw.value, (ast.Name, ast.Attribute)):
                edges[source].update(_resolve(kw.value, **resolve_kwargs))


def parse_calls(
    module: Module,
    project_nodes: set[str],
    project_definitions: set[str],
) -> CallerCollection:
    """Per-module caller-scoped edge collection for the callable graph.

    Two passes:
      1. Imports → build alias_mapper (local name → canonical) and the
         module's import set. Handles lazy/in-function imports because we
         visit every Import/ImportFrom in the tree first.
      2. Top-level callables → emit source → target edges for body calls,
         decorators, and (for classes) inheritance bases. Module-scope
         statements attribute to a synthetic `mod::<module>` source so
         entry-point invocations like `cli()` in `__main__.py` aren't lost.
    """
    text_source = module.full_path.read_text(encoding="utf-8")
    tree = ast.parse(text_source)
    module_name = node_name_gen(module)

    caller_collection = CallerCollection(
        module=module,
        imports=set(),
        call_edges=defaultdict(set),
    )

    # ---- Pass 1: alias_mapper + imports ----
    alias_mapper: dict[str, str] = {}
    import_strings: set[str] = set()

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for imported in node.names:
                # `import a`         → local "a",  canonical "a"
                # `import a.b`       → local "a",  canonical "a"   (only `a` is bound)
                # `import a as b`    → local "b",  canonical "a"
                # `import a.b as ab` → local "ab", canonical "a.b"
                local = imported.asname or imported.name.split(".")[0]
                canonical = imported.name if imported.asname else local
                alias_mapper[local] = canonical

                dpdman_import = DpdmanImport(
                    module=imported.name,
                    names=[],
                    level=0,
                )
                import_strings.update(node_generator(module, dpdman_import))
        elif isinstance(node, ast.ImportFrom):
            base = _resolve_base_module(module, node)
            for imported in node.names:
                local = imported.asname or imported.name
                callable_candidate = f"{base}::{imported.name}"
                module_candidate = f"{base}.{imported.name}"

                # Callable wins over module (matches Python's
                # __init__-name-over-submodule rule). Externals get the
                # callable form as a placeholder; the downstream project
                # filter drops them.
                if callable_candidate in project_definitions:
                    alias_mapper[local] = callable_candidate
                elif module_candidate in project_nodes:
                    alias_mapper[local] = module_candidate
                else:
                    alias_mapper[local] = callable_candidate

                dpdman_import = DpdmanImport(
                    module=node.module,
                    names=[imported.name],
                    level=node.level,
                )
                import_strings.update(node_generator(module, dpdman_import))

    caller_collection.imports.update(import_strings)

    # Local definitions are in this module's namespace too — a call to
    # `helper()` where `helper` is defined in the same file is `ast.Name`
    # resolution, just like an import. Add them to alias_mapper; they
    # shadow any matching import (Python's normal binding order).
    own_top_level_canonicals = {
        d
        for d in project_definitions
        if d.startswith(f"{module_name}::") and "." not in d.split("::", 1)[1]
    }
    for canonical in own_top_level_canonicals:
        local_name = canonical.split("::", 1)[1]
        alias_mapper[local_name] = canonical

    # In-scope set for the naive fallback: everything this module imported,
    # plus its own top-level class-like canonicals. A local `obj = MyClass()`
    # can be an instance of any class reachable from here.
    in_scope_for_naive: set[str] = set(alias_mapper.values())
    in_scope_for_naive.update(own_top_level_canonicals)

    # ---- Pass 2: per-callable walk ----
    module_source = f"{module_name}::<module>"
    edges = caller_collection.call_edges

    resolver_args = (
        alias_mapper,
        project_definitions,
        project_nodes,
        in_scope_for_naive,
    )

    for top in ast.iter_child_nodes(tree):
        if isinstance(top, (ast.FunctionDef, ast.AsyncFunctionDef)):
            source = f"{module_name}::{top.name}"
            _emit_resolved_refs(top.decorator_list, source, edges, *resolver_args)
            _emit_calls_in_subtree(top, source, edges, *resolver_args)
        elif isinstance(top, ast.ClassDef):
            class_canonical = f"{module_name}::{top.name}"
            _emit_resolved_refs(top.bases, class_canonical, edges, *resolver_args)
            _emit_resolved_refs(
                top.decorator_list, class_canonical, edges, *resolver_args
            )
            for child in ast.iter_child_nodes(top):
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    role = _property_role(child.decorator_list)
                    method_source = f"{class_canonical}.{child.name}"
                    if role:
                        method_source += role
                    _emit_resolved_refs(
                        child.decorator_list,
                        method_source,
                        edges,
                        *resolver_args,
                    )
                    _emit_calls_in_subtree(child, method_source, edges, *resolver_args)
                else:
                    # Class-level statement (e.g. `CONST = compute()`) —
                    # attribute to the class itself.
                    _emit_calls_in_subtree(
                        child, class_canonical, edges, *resolver_args
                    )
        else:
            # Module-scope statement (top-level call, decorator-application,
            # constant init, `if __name__ == "__main__": cli()`).
            _emit_calls_in_subtree(top, module_source, edges, *resolver_args)

    caller_collection.call_edges = dict(edges)
    return caller_collection


def definition_collector(module: Module) -> set[str]:
    """Getting all the functions and class definitions that are in each of the
    modules.
    """
    text_source = module.full_path.read_text(encoding="utf-8")
    tree = ast.parse(text_source)

    # Creating the functions and classes definitions
    definitions: set[str] = set()

    # creating the node string
    module_name = node_name_gen(module)
    # we will only walk the top level nodes, not all the code.
    for node in ast.iter_child_nodes(tree):
        if isinstance(node, (ast.AsyncFunctionDef, ast.FunctionDef)):
            definition = f"{module_name}::{node.name}"
            definitions.add(definition)
        elif isinstance(node, ast.ClassDef):
            definition = f"{module_name}::{node.name}"
            definitions.add(definition)
            for child_node in ast.iter_child_nodes(node):
                if isinstance(child_node, (ast.AsyncFunctionDef, ast.FunctionDef)):
                    role = _property_role(child_node.decorator_list)
                    method_canonical = f"{definition}.{child_node.name}"
                    if role:
                        method_canonical += role
                    definitions.add(method_canonical)
    return definitions


def callable_level_node_generator(file_source: list[Package]) -> set[str]:
    """All functions, classes and methods defined across the project."""
    project_definitions: set[str] = set()

    modules: list[Module] = [
        module for package in file_source for module in package.modules
    ]

    if len(modules) < MIN_FILES_FOR_POOL:
        for module in modules:
            project_definitions.update(definition_collector(module))
        return project_definitions

    # Parallelism hell
    with executor() as pool:
        futures: list[Future[set[str]]] = [
            pool.submit(definition_collector, module) for module in modules
        ]

        for future in as_completed(futures):
            project_definitions.update(future.result())
    return project_definitions
