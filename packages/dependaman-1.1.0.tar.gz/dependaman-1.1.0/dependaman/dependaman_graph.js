const canvas = document.getElementById('graph');
const ctx = canvas.getContext('2d');
const tooltip = document.getElementById('tooltip');
const modal = document.getElementById('modal');
const overlay = document.getElementById('overlay');
const modalTitle = document.getElementById('modal-title');
const modalBody = document.getElementById('modal-body');

let W, H;

function resize() {
  W = canvas.width = window.innerWidth;
  H = canvas.height = window.innerHeight;
}
resize();
window.addEventListener('resize', () => { resize(); draw(); });

// Build node map and edge list from DATA
const nodeMap = {};
const allNodes = [];
const allEdges = [];

for (const pkg of DATA.packages) {
  for (const mod of pkg.modules) {
    const node = { ...mod, package: pkg.id, x: 0, y: 0, r: 18 };
    nodeMap[mod.id] = node;
    allNodes.push(node);
  }
}

for (const node of allNodes) {
  for (const edgeId of node.edges) {
    if (nodeMap[edgeId]) allEdges.push({ source: node, target: nodeMap[edgeId] });
  }
}

// Mark cycle edges for red highlighting
const cycleEdgeSet = new Set();
for (const cycle of DATA.cycles) {
  for (let i = 0; i < cycle.length - 1; i++) {
    cycleEdgeSet.add(cycle[i] + '->' + cycle[i + 1]);
  }
}


// Reverse edge map for highlight
const inEdges = {};
for (const node of allNodes) inEdges[node.id] = [];
for (const edge of allEdges) {
  if (inEdges[edge.target.id]) inEdges[edge.target.id].push(edge.source.id);
}

// Callable layer — flat map + reverse map for "called by" lookups.
// Every callable canonical (mod::func / mod::Class.method / mod::<module>)
// gets an entry with its module reference and edge data.
const callableMap = {};
const callableInverse = {};
for (const pkg of DATA.packages) {
  for (const mod of pkg.modules) {
    for (const c of (mod.callables || [])) {
      callableMap[c.id] = { ...c, module: mod.id };
    }
  }
}
for (const c of Object.values(callableMap)) {
  for (const target of c.edges) {
    if (!callableInverse[target]) callableInverse[target] = [];
    callableInverse[target].push(c.id);
  }
}

// Short label for a callable id: "mod.a::ClassName.method" -> "ClassName.method"
function callableLabel(id) {
  const parts = id.split('::');
  return parts.length > 1 ? parts[1] : id;
}

// Escape `<>"&'` so the synthetic `<module>` source (and any other content
// holding angle brackets) renders as text instead of being parsed as HTML.
function escapeHtml(s) {
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

// Resolve a click on a callable id back to its containing module node.
function moduleFor(callableId) {
  const c = callableMap[callableId];
  if (!c) return null;
  return nodeMap[c.module] || null;
}


// Hierarchical layout — bottom-up circle packing
const NODE_R = 18;

// Build package hierarchy tree
const pkgTree = {};
DATA.packages.forEach(p => {
  pkgTree[p.id] = {
    id: p.id, modules: p.modules, children: [],
    parent: p.id.includes('.') ? p.id.split('.').slice(0, -1).join('.') : null
  };
});
Object.values(pkgTree).forEach(p => {
  if (p.parent && pkgTree[p.parent]) pkgTree[p.parent].children.push(p.id);
});

// Minimum ring radius to fit N nodes without overlap
function minRingR(n) {
  if (n <= 1) return NODE_R + 10;
  return (NODE_R + 20) / Math.sin(Math.PI / n);
}

// Greedily pack child circles, biggest first
// er() returns the actual drawn radius (pkgR stores pack radius; draw adds NODE_R+10)
function packChildren(childIds) {
  const er = id => pkgR[id] + NODE_R + 10;
  const sorted = [...childIds].sort((a, b) => pkgR[b] - pkgR[a]);
  const pos = {};
  if (sorted.length === 1) { pos[sorted[0]] = { x: 0, y: 0 }; return pos; }
  pos[sorted[0]] = { x: -(er(sorted[0]) + 10), y: 0 };
  pos[sorted[1]] = { x: pos[sorted[0]].x + er(sorted[0]) + er(sorted[1]) + 10, y: 0 };
  for (let i = 2; i < sorted.length; i++) {
    const r = er(sorted[i]);
    let bx = 0, by = -(er(sorted[0]) + r + 20), bd = Infinity;
    for (let a = 0; a < Math.PI * 2; a += 0.1) {
      for (const [id, p] of Object.entries(pos)) {
        const x = p.x + Math.cos(a) * (er(id) + r + 10);
        const y = p.y + Math.sin(a) * (er(id) + r + 10);
        let overlap = false;
        for (const [id2, p2] of Object.entries(pos)) {
          const dx = x - p2.x, dy = y - p2.y;
          if (Math.sqrt(dx*dx + dy*dy) < er(id2) + r + 5) { overlap = true; break; }
        }
        if (!overlap) {
          const d = Math.sqrt(x*x + y*y);
          if (d < bd) { bd = d; bx = x; by = y; }
        }
      }
    }
    pos[sorted[i]] = { x: bx, y: by };
  }
  return pos;
}

// Bottom-up: compute radius for each package
const pkgR = {};
const childOffsets = {};
const sortedByDepth = Object.values(pkgTree).sort((a, b) =>
  b.id.split('.').length - a.id.split('.').length
);
sortedByDepth.forEach(p => {
  if (p.children.length === 0) {
    pkgR[p.id] = minRingR(p.modules.length);
    return;
  }
  const positions = packChildren(p.children);
  childOffsets[p.id] = positions;
  const maxExtent = Math.max(...p.children.map(c => {
    const cp = positions[c];
    return Math.sqrt(cp.x*cp.x + cp.y*cp.y) + pkgR[c];
  }));
  pkgR[p.id] = maxExtent + NODE_R + 30;
});

// Position top-level packages using packChildren — keeps them adjacent regardless of size differences
// zoomToFit() (package-extent-based) handles bringing everything into view
const pkgCenters = {};
const topLevel = DATA.packages.filter(p => !pkgTree[p.id].parent);
if (topLevel.length === 1) {
  pkgCenters[topLevel[0].id] = { x: W / 2, y: H / 2 };
} else {
  const topOffsets = packChildren(topLevel.map(p => p.id));
  // Center the packed layout on the canvas (bounding box of drawn extents)
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const pkg of topLevel) {
    const o = topOffsets[pkg.id];
    const r = pkgR[pkg.id] + NODE_R + 10;
    minX = Math.min(minX, o.x - r); maxX = Math.max(maxX, o.x + r);
    minY = Math.min(minY, o.y - r); maxY = Math.max(maxY, o.y + r);
  }
  const cx = (minX + maxX) / 2, cy = (minY + maxY) / 2;
  topLevel.forEach(pkg => {
    const o = topOffsets[pkg.id];
    pkgCenters[pkg.id] = { x: W / 2 + o.x - cx, y: H / 2 + o.y - cy };
  });
}

// Top-down: position children from packed offsets
const sortedTopDown = Object.values(pkgTree).sort((a, b) =>
  a.id.split('.').length - b.id.split('.').length
);
sortedTopDown.forEach(pkg => {
  if (!pkgTree[pkg.id].parent) return;
  const parent = pkgTree[pkg.id].parent;
  if (!pkgCenters[parent] || !childOffsets[parent]) return;
  const offset = childOffsets[parent][pkg.id];
  if (!offset) return;
  pkgCenters[pkg.id] = {
    x: pkgCenters[parent].x + offset.x,
    y: pkgCenters[parent].y + offset.y,
  };
});

// Place nodes on ring inside their package
// Packages with children: own modules go on the outer ring to avoid overlapping children
// Leaf packages: own modules go on their calculated ring
DATA.packages.forEach(pkg => {
  const center = pkgCenters[pkg.id];
  const hasChildren = pkgTree[pkg.id].children.length > 0;
  const r = hasChildren
    ? pkgR[pkg.id] + 6
    : minRingR(pkg.modules.length);
  pkg.modules.forEach((mod, mi) => {
    const node = nodeMap[mod.id];
    if (!node || !center) return;
    const a = (2 * Math.PI * mi) / Math.max(pkg.modules.length, 1);
    node.x = center.x + Math.cos(a) * r;
    node.y = center.y + Math.sin(a) * r;
  });
});

// Force simulation — only within packages, anchored to fixed package centers


const pkgDrawOrder = [...DATA.packages].sort((a, b) => pkgR[b.id] - pkgR[a.id]);

function zoomToFit() {
  const padding = 60;
  let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
  for (const pkg of DATA.packages) {
    const c = pkgCenters[pkg.id];
    if (!c) continue;
    const r = pkgR[pkg.id] + NODE_R + 10;
    minX = Math.min(minX, c.x - r); maxX = Math.max(maxX, c.x + r);
    minY = Math.min(minY, c.y - r); maxY = Math.max(maxY, c.y + r);
  }
  const bw = maxX - minX, bh = maxY - minY;
  scale = Math.min((W - padding * 2) / bw, (H - padding * 2) / bh);
  minScale = scale;
  panX = (W - bw * scale) / 2 - minX * scale;
  panY = (H - bh * scale) / 2 - minY * scale;
  draw();
}

function zoomToPackage(pkg) {
  const c = pkgCenters[pkg.id];
  if (!c) return;
  const r = pkgR[pkg.id] + NODE_R + 10;
  const padding = 60;
  scale = Math.min((W - padding * 2) / (r * 2), (H - padding * 2) / (r * 2));
  panX = W / 2 - c.x * scale;
  panY = H / 2 - c.y * scale;
  draw();
}

// Node fill: blue (0 commits) → red (max commits), fixed lightness for text readability
const _commitMax = Math.max(...allNodes.map(n => n.n_commits), 1);
function nodeColor(node) {
  const t = node.n_commits / _commitMax;   // 0 = untouched, 1 = hottest file
  const hue = Math.round(220 - t * 220);   // 220 (blue) → 0 (red)
  return `hsl(${hue}, 60%, 72%)`;           // pastel: high lightness, softer saturation
}

// Package border brightness: bright at top level, dark at deepest nesting
const _maxPkgDepth = Math.max(...DATA.packages.map(p => p.id.split('.').filter(Boolean).length), 1);
function pkgBorderColor(depth) {
  const ratio = depth / _maxPkgDepth;
  const l = Math.round(65 - ratio * 42);   // 65% (bright) → 23% (dim)
  return `hsl(210, 18%, ${l}%)`;
}

// Compute the smallest enclosing circle for a set of nodes
function enclosingCircle(nodes) {
  if (!nodes.length) return { x: 0, y: 0, r: 0 };
  const cx = nodes.reduce((s, n) => s + n.x, 0) / nodes.length;
  const cy = nodes.reduce((s, n) => s + n.y, 0) / nodes.length;
  let r = 0;
  for (const n of nodes) {
    const d = Math.sqrt((n.x - cx) ** 2 + (n.y - cy) ** 2) + n.r + 24;
    if (d > r) r = d;
  }
  return { x: cx, y: cy, r: Math.max(r, 50) };
}

// Draw a directed arrow between two points
const MIN_ARROW_LEN = 20;

function drawArrow(x1, y1, x2, y2, color) {
  const headLen = 10;
  const dx = x2 - x1, dy = y2 - y1;
  const dist = Math.sqrt(dx * dx + dy * dy);
  if (dist < 2 * 22 + MIN_ARROW_LEN) return;
  const ux = dx / dist, uy = dy / dist;
  const sx = x1 + ux * 22, sy = y1 + uy * 22;
  const ex = x2 - ux * 22, ey = y2 - uy * 22;

  ctx.beginPath();
  ctx.setLineDash([]);
  ctx.moveTo(sx, sy);
  ctx.lineTo(ex, ey);
  ctx.strokeStyle = color;
  ctx.lineWidth = 1.5;
  ctx.stroke();

  const angle = Math.atan2(dy, dx);
  ctx.beginPath();
  ctx.moveTo(ex, ey);
  ctx.lineTo(ex - headLen * Math.cos(angle - 0.4), ey - headLen * Math.sin(angle - 0.4));
  ctx.lineTo(ex - headLen * Math.cos(angle + 0.4), ey - headLen * Math.sin(angle + 0.4));
  ctx.closePath();
  ctx.fillStyle = color;
  ctx.fill();
}

// Test filter
let showTests = false;
function isTest(id) { return id.toLowerCase().includes('test'); }

// Pan, zoom, and selection state
let panX = 0, panY = 0, scale = 1, minScale = 0.05;
let isPanning = false, panStartX = 0, panStartY = 0;
let selectedNode = null;

function toWorldX(screenX) { return (screenX - panX) / scale; }
function toWorldY(screenY) { return (screenY - panY) / scale; }

canvas.addEventListener('mousedown', (e) => {
  if (e.button === 1) { e.preventDefault(); isPanning = true; panStartX = e.clientX - panX; panStartY = e.clientY - panY; }
});
canvas.addEventListener('mouseup', () => { isPanning = false; });
canvas.addEventListener('mouseleave', () => { isPanning = false; });

let rafPending = false;
function scheduleDraw() {
  if (rafPending) return;
  rafPending = true;
  requestAnimationFrame(() => { rafPending = false; draw(); });
}

canvas.addEventListener('wheel', (e) => {
  e.preventDefault();
  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left, my = e.clientY - rect.top;
  const delta = e.deltaY > 0 ? 0.9 : 1.1;
  const newScale = Math.max(minScale, Math.min(5, scale * delta));
  const applied = newScale / scale;   // actual ratio after clamping
  panX = mx - (mx - panX) * applied;
  panY = my - (my - panY) * applied;
  scale = newScale;
  scheduleDraw();
}, { passive: false });

function draw() {
  ctx.clearRect(0, 0, W, H);
  ctx.save();
  ctx.translate(panX, panY);
  ctx.scale(scale, scale);

  // Package circles — largest first so parents render behind children
  for (const pkg of pkgDrawOrder) {
    if (!showTests && isTest(pkg.id)) continue;
    const center = pkgCenters[pkg.id];
    if (!center) continue;
    const r = pkgR[pkg.id] + NODE_R + 10;
    const depth = pkg.id.split('.').filter(Boolean).length;
    const fills = ['rgba(22,27,34,0.7)', 'rgba(33,38,45,0.7)', 'rgba(44,51,58,0.7)', 'rgba(55,62,70,0.7)'];
    const fill = fills[Math.min(depth, fills.length - 1)];

    ctx.beginPath();
    ctx.arc(center.x, center.y, r, 0, 2 * Math.PI);
    ctx.fillStyle = fill;
    ctx.fill();
    ctx.strokeStyle = pkgBorderColor(depth);
    ctx.lineWidth = Math.max(0.8, 2 - depth * 0.3);
    ctx.setLineDash([6, 3]);
    ctx.stroke();
    ctx.setLineDash([]);

    ctx.font = `${depth === 0 ? 13 : 11}px Fira Code, monospace`;
    ctx.textAlign = 'center';
    ctx.shadowColor = 'rgba(0,0,0,0.9)';
    ctx.shadowBlur = 4;
    ctx.fillStyle = '#e6edf3';
    ctx.fillText(pkg.id, center.x, center.y - r + 16);
    ctx.shadowBlur = 0;
  }

  // Edges
  for (const edge of allEdges) {
    if (!showTests && (isTest(edge.source.id) || isTest(edge.target.id))) continue;
    const key = edge.source.id + '->' + edge.target.id;
    const color = cycleEdgeSet.has(key) ? 'rgba(218,54,51,0.9)' : 'rgba(139,148,158,0.6)';
    drawArrow(edge.source.x, edge.source.y, edge.target.x, edge.target.y, color);
  }

  // Module nodes
  for (const node of allNodes) {
    if (!showTests && isTest(node.id)) continue;

    ctx.beginPath();
    ctx.arc(node.x, node.y, node.r, 0, 2 * Math.PI);
    ctx.fillStyle = nodeColor(node);
    ctx.fill();
    ctx.strokeStyle = '#0d1117';
    ctx.lineWidth = 2;
    ctx.stroke();

    // Dead-callable ring — same red as cycle arrows, dashed to distinguish
    // from the solid blue selection ring. Modules containing one or more
    // callables flagged as dead by `dead_callables_detector` get this halo.
    if (node.with_symbols_to_review) {
      ctx.beginPath();
      ctx.arc(node.x, node.y, node.r + 3, 0, 2 * Math.PI);
      ctx.strokeStyle = 'rgba(218,54,51,0.9)';
      ctx.lineWidth = 1.8;
      ctx.setLineDash([4, 3]);
      ctx.stroke();
      ctx.setLineDash([]);
    }

    // Selection ring
    if (node === selectedNode) {
      ctx.beginPath();
      ctx.arc(node.x, node.y, node.r + 7, 0, 2 * Math.PI);
      ctx.strokeStyle = '#58a6ff';
      ctx.lineWidth = 2.5;
      ctx.stroke();
    }

    const label = node.id.split('.').pop();
    ctx.font = '10px Fira Code, monospace';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor = 'rgba(0,0,0,0.8)';
    ctx.shadowBlur = 3;
    ctx.fillStyle = '#e6edf3';
    ctx.fillText(label, node.x, node.y);
    ctx.shadowBlur = 0;
    ctx.textBaseline = 'alphabetic';
  }
  ctx.restore();
}

draw();
zoomToFit();

// Interaction
let hoveredNode = null;

canvas.addEventListener('mousemove', (e) => {
  const rect = canvas.getBoundingClientRect();
  if (isPanning) {
    panX = e.clientX - panStartX;
    panY = e.clientY - panStartY;
    scheduleDraw();
  }
  const mx = toWorldX(e.clientX - rect.left), my = toWorldY(e.clientY - rect.top);
  hoveredNode = null;
  for (const node of allNodes) {
    if (Math.sqrt((mx - node.x) ** 2 + (my - node.y) ** 2) < node.r) {
      hoveredNode = node;
      break;
    }
  }
  if (hoveredNode) {
    canvas.style.cursor = 'pointer';
    tooltip.style.display = 'block';
    tooltip.style.left = (e.clientX + 14) + 'px';
    tooltip.style.top = (e.clientY - 10) + 'px';
    tooltip.innerHTML =
      '<strong>' + hoveredNode.id + '</strong><br>' +
      'Commits: ' + hoveredNode.n_commits + '<br>' +
      'Churn: +' + hoveredNode.added_lines + '/-' + hoveredNode.removed_lines;
  } else {
    canvas.style.cursor = 'default';
    tooltip.style.display = 'none';
  }
});

canvas.addEventListener('click', (e) => {
  const target = hoveredNode;
  if (!target) {
    const rect = canvas.getBoundingClientRect();
    const wx = toWorldX(e.clientX - rect.left);
    const wy = toWorldY(e.clientY - rect.top);
    // Find smallest package containing the click (most nested wins)
    const hit = DATA.packages
      .filter(pkg => {
        if (!showTests && isTest(pkg.id)) return false;
        const c = pkgCenters[pkg.id];
        if (!c) return false;
        const r = pkgR[pkg.id] + NODE_R + 10;
        const dx = wx - c.x, dy = wy - c.y;
        return Math.sqrt(dx*dx + dy*dy) < r;
      })
      .sort((a, b) => pkgR[a.id] - pkgR[b.id])[0];
    if (hit) { zoomToPackage(hit); return; }
    selectedNode = null;
    draw();
    return;
  }
  selectedNode = target;
  draw();
  openModal(target);
});

function openModal(n) {
  modalTitle.textContent = n.id;
  modalBody.innerHTML =
    '<div id="modal-stats">' +
    '<div class="row"><span class="label">Commits</span><span class="value">' + n.n_commits + '</span></div>' +
    '<div class="row"><span class="label">Fan-in</span><span class="value">' + n.fan_in + '</span></div>' +
    '<div class="row"><span class="label">Fan-out</span><span class="value">' + n.fan_out + '</span></div>' +
    '<div class="row"><span class="label">Lines added</span><span class="value">+' + n.added_lines + '</span></div>' +
    '<div class="row"><span class="label">Lines removed</span><span class="value">-' + n.removed_lines + '</span></div>' +
    '<div class="row full"><span class="label">Last author</span><span class="value">' + (n.last_author || '&mdash;') + '</span></div>' +
    '</div>' +
    '<div class="edges"><h3>Imports (' + n.edges.length + ')</h3>' +
    (n.edges.filter(e => nodeMap[e]).map(e => '<div class="edge-item edge-nav" data-node-id="' + e + '">&rarr; ' + e + '</div>').join('') ||
      '<div style="color:#8b949e;font-size:12px">None</div>') +
    '</div>' +
    (function() {
      const incoming = (inEdges[n.id] || []).filter(id => nodeMap[id] && !(!showTests && isTest(id)));
      return '<div class="edges"><h3>Imported by (' + incoming.length + ')</h3>' +
        (incoming.map(e => '<div class="edge-item edge-nav" data-node-id="' + e + '">&larr; ' + e + '</div>').join('') ||
          '<div style="color:#8b949e;font-size:12px">None</div>') +
        '</div>';
    })() +
    (function() {
      const callables = n.callables || [];
      if (!callables.length) return '';
      // Dead first, then by fan-in desc so hot/dead jump out at the top.
      const sorted = [...callables].sort((a, b) => {
        if (a.is_dead !== b.is_dead) return a.is_dead ? -1 : 1;
        return b.fan_in - a.fan_in;
      });
      const deadCount = callables.filter(c => c.is_dead).length;
      const heading = '<h3>Callables (' + callables.length + ')' +
        (deadCount ? ' <span style="color:#da3633">— ' + deadCount + ' dead</span>' : '') +
        '</h3>';
      // Helper: link renders amber when the target sits in the same module —
      // signals to the user that clicking won't navigate, just scrolls.
      const linkFor = (id) => {
        const inSameModule = callableMap[id] && callableMap[id].module === n.id;
        const cls = 'callable-link' + (inSameModule ? ' callable-link-same' : '');
        return '<span class="' + cls + '" data-callable-id="' + escapeHtml(id) + '">' + escapeHtml(callableLabel(id)) + '</span>';
      };
      return '<div class="edges">' + heading +
        sorted.map(c => {
          const label = callableLabel(c.id);
          const deadCls = c.is_dead ? ' callable-dead' : '';
          const callers = callableInverse[c.id] || [];
          const targets = c.edges || [];
          const callsHTML = targets.length
            ? targets.map(linkFor).join(', ')
            : '<em style="color:#6e7681">none</em>';
          const callersHTML = callers.length
            ? callers.map(linkFor).join(', ')
            : '<em style="color:#6e7681">none</em>';
          return '<div class="callable-item' + deadCls + '" data-callable-id="' + escapeHtml(c.id) + '">' +
            '<div class="callable-header">' +
              '<span class="callable-name">' + escapeHtml(label) + '</span>' +
              '<span class="callable-stats">&darr;' + c.fan_in + ' &uarr;' + c.fan_out + '</span>' +
              (c.is_dead ? '<span class="callable-dead-tag">dead</span>' : '') +
            '</div>' +
            '<div class="callable-meta"><span class="callable-meta-label">calls</span> ' + callsHTML + '</div>' +
            '<div class="callable-meta"><span class="callable-meta-label">called by</span> ' + callersHTML + '</div>' +
          '</div>';
        }).join('') +
        '</div>';
    })();
  modal.style.display = 'block';
  overlay.style.display = 'block';
}

modalBody.addEventListener('click', (e) => {
  const id = e.target.dataset.nodeId;
  if (id && nodeMap[id]) {
    selectedNode = nodeMap[id];
    draw();
    openModal(nodeMap[id]);
    return;
  }
  const callableId = e.target.dataset.callableId;
  if (!callableId) return;
  const targetCallable = callableMap[callableId];
  if (!targetCallable) return;

  // Same-module: target sits in the modal we're already looking at. Scroll
  // it into view and flash a glow so the user can find it.
  if (selectedNode && targetCallable.module === selectedNode.id) {
    const target = modalBody.querySelector(
      '.callable-item[data-callable-id="' + (window.CSS && CSS.escape ? CSS.escape(callableId) : callableId) + '"]'
    );
    if (target) {
      target.scrollIntoView({ behavior: 'smooth', block: 'center' });
      target.classList.remove('callable-flash');
      // Force reflow so the animation restarts on repeated clicks.
      void target.offsetWidth;
      target.classList.add('callable-flash');
    }
    return;
  }

  // Different module: jump to the module that hosts the target callable and
  // reopen its modal.
  const targetMod = moduleFor(callableId);
  if (targetMod) {
    selectedNode = targetMod;
    draw();
    openModal(targetMod);
  }
});

document.getElementById('btn-fit').addEventListener('click', zoomToFit);
document.getElementById('modal-close').addEventListener('click', closeModal);
overlay.addEventListener('click', closeModal);
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    closeModal();
    selectedNode = null;
    draw();
    searchInput.value = '';
    searchResults.style.display = 'none';
  }
  if (e.key === 'f' || e.key === 'F') zoomToFit();
});
document.getElementById('toggle-tests').addEventListener('change', (e) => {
  showTests = e.target.checked;
  draw();
});

// Search
const searchInput = document.getElementById('search-input');
const searchResults = document.getElementById('search-results');
let activeIdx = -1;

function fuzzyScore(query, str) {
  let qi = 0, score = 0, lastMatch = -1;
  for (let i = 0; i < str.length && qi < query.length; i++) {
    if (str[i].toLowerCase() === query[qi].toLowerCase()) {
      score += (lastMatch === i - 1) ? 2 : 1;
      lastMatch = i;
      qi++;
    }
  }
  return qi === query.length ? score : -1;
}

function fuzzyHighlight(query, str) {
  let qi = 0, out = '';
  for (let i = 0; i < str.length; i++) {
    if (qi < query.length && str[i].toLowerCase() === query[qi].toLowerCase()) {
      out += '<span class="search-match">' + str[i] + '</span>';
      qi++;
    } else {
      out += str[i];
    }
  }
  return out;
}

function zoomToNode(node) {
  const padding = 120;
  scale = Math.min((W - padding * 2) / (NODE_R * 6), (H - padding * 2) / (NODE_R * 6), 4);
  panX = W / 2 - node.x * scale;
  panY = H / 2 - node.y * scale;
  selectedNode = node;
  draw();
  openModal(node);
}

function runSearch() {
  const q = searchInput.value.trim();
  searchResults.innerHTML = '';
  activeIdx = -1;
  if (!q) { searchResults.style.display = 'none'; return; }
  const results = allNodes
    .filter(n => !(!showTests && isTest(n.id)))
    .map(n => ({ node: n, score: fuzzyScore(q, n.id) }))
    .filter(r => r.score >= 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, 10);
  if (!results.length) { searchResults.style.display = 'none'; return; }
  results.forEach(r => {
    const el = document.createElement('div');
    el.className = 'search-item';
    el.innerHTML = fuzzyHighlight(q, r.node.id);
    el.addEventListener('mousedown', e => {
      e.preventDefault();
      searchInput.value = '';
      searchResults.style.display = 'none';
      zoomToNode(r.node);
    });
    searchResults.appendChild(el);
  });
  searchResults.style.display = 'block';
}

searchInput.addEventListener('input', runSearch);

searchInput.addEventListener('keydown', e => {
  const items = searchResults.querySelectorAll('.search-item');
  if (e.key === 'ArrowDown') {
    e.preventDefault();
    activeIdx = Math.min(activeIdx + 1, items.length - 1);
    items.forEach((el, i) => el.classList.toggle('active', i === activeIdx));
  } else if (e.key === 'ArrowUp') {
    e.preventDefault();
    activeIdx = Math.max(activeIdx - 1, 0);
    items.forEach((el, i) => el.classList.toggle('active', i === activeIdx));
  } else if (e.key === 'Enter') {
    const target = activeIdx >= 0 ? items[activeIdx] : items[0];
    if (target) target.dispatchEvent(new MouseEvent('mousedown'));
  } else if (e.key === 'Escape') {
    searchInput.value = '';
    searchResults.style.display = 'none';
    searchInput.blur();
  }
});

searchInput.addEventListener('blur', () => {
  setTimeout(() => { searchResults.style.display = 'none'; }, 150);
});

document.addEventListener('keydown', e => {
  if (e.key === '/' && document.activeElement !== searchInput) {
    e.preventDefault();
    searchInput.focus();
    searchInput.select();
  }
});

function closeModal() {
  modal.style.display = 'none';
  overlay.style.display = 'none';
}
