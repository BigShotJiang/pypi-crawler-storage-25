"""graph.py"""

from concurrent.futures import Future, as_completed

from .discovery import Module, Package, node_name_gen
from .parser import CallerCollection, parse_calls
from .pool import MIN_FILES_FOR_POOL, executor


# NOTE: The initial design made speed_grapher responsabilities lower than
# before as we didn't had the correct data structures or final flow of the
# project to allow this to be the central part of the code.
# Now that this is done, is possible for us to collapse logic in here.
# I love swimming, thats why I put pools everywhere.
def speed_grapher(
    file_source: list[Package],
    project_nodes: set[str],
    project_definitions: set[str],
) -> tuple[set[str], dict[str, set[str]], dict[str, set[str]]]:
    """Single-pass over all modules: returns (project_imports, module_graph,
    callable_graph). One file read and one AST parse per module total.
    """
    project_imports: set[str] = set()
    module_graph: dict[str, set[str]] = {}
    callable_graph: dict[str, set[str]] = {c: set() for c in project_definitions}

    def _merge(caller: CallerCollection) -> None:
        node = node_name_gen(caller.module)
        project_imports.update(caller.imports)
        module_graph[node] = {e for e in caller.imports if e in project_nodes}
        for source, targets in caller.call_edges.items():
            callable_graph.setdefault(source, set()).update(targets)

    modules: list[Module] = [
        module for package in file_source for module in package.modules
    ]

    if len(modules) < MIN_FILES_FOR_POOL:
        for module in modules:
            _merge(parse_calls(module, project_nodes, project_definitions))
        return project_imports, module_graph, callable_graph

    with executor() as pool:
        futures: list[Future[CallerCollection]] = [
            pool.submit(parse_calls, module, project_nodes, project_definitions)
            for module in modules
        ]
        for future in as_completed(futures):
            _merge(future.result())

    return project_imports, module_graph, callable_graph
