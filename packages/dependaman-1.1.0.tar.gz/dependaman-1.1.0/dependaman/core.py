"""core.py

Orchestator. Here is where everything takes shape. In dependaman we build all
tools that are needed to make the code analysis, here we put them together so
with a simple command/function call we can execute the project analysis.
"""

import webbrowser
from pathlib import Path

from .analysis import (
    circular_imports,
    dead_callables_detector,
    fanin_analyzer,
    fanout_analyzer,
)
from .discovery import discover, module_level_node_generator
from .git import git_commit_freq
from .graph import speed_grapher
from .parser import callable_level_node_generator
from .renderer import data_constructor, render


def dependaman(path: Path | str = ".", in_memory: bool = False) -> str | None:
    """Given the path of the project found, the folder structure and nodes of
    the project are generated. Then the different files are being parsed and
    from them we get the import nodes of each one of them. After both nodes are
    created, we match an see for each module, which other modules are imported
    to them.

    With that information we can analyze which modules are the ones that import
    the most, which are the ones that are imported the most and if there are
    circular imports detect them.
    """

    file_source = discover(path)
    project_nodes: set[str] = module_level_node_generator(file_source)
    project_definitions: set[str] = callable_level_node_generator(file_source)

    project_imports, directed_graph, callable_graph = speed_grapher(
        file_source, project_nodes, project_definitions
    )

    # ---- Module graph layer ----
    fanin_analysis = fanin_analyzer(project_nodes, directed_graph)
    fanout_analysis = fanout_analyzer(directed_graph)
    circular_imports_analysis = circular_imports(directed_graph)

    # ---- Callable graph layer ----
    callable_fanin = fanin_analyzer(project_definitions, callable_graph)
    callable_fanout = fanout_analyzer(callable_graph)
    callable_cycles = circular_imports(callable_graph)
    dead_callables = dead_callables_detector(
        project_definitions, callable_fanin, project_imports
    )

    git_freq = git_commit_freq(file_source, project_nodes, path)

    data = data_constructor(
        file_source,
        project_nodes,
        project_definitions,
        directed_graph,
        circular_imports_analysis,
        fanin_analysis,
        fanout_analysis,
        callable_graph,
        callable_fanin,
        callable_fanout,
        callable_cycles,
        dead_callables,
        git_freq,
    )

    rendered_data: str = render(data)

    if in_memory:
        return rendered_data

    with open("output.html", "w") as f:
        f.write(rendered_data)
    webbrowser.open(f"file://{Path('output.html').resolve()}")
