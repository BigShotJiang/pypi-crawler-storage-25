"""analysis.py"""


def fanin_analyzer(
    project_nodes: set[str],
    graph: dict[str, set[str]],
) -> dict[str, int]:
    """Counts how many times each node is referenced as an edge target.

    Generic over both the module graph (universe = project_nodes /
    modules) and the callable graph (universe = project_definitions /
    callables). The `edge in fanin` guard tolerates edges whose targets
    aren't in the supplied universe — e.g. callable-graph edges that
    point at a module canonical rather than a callable.
    """
    fanin = dict.fromkeys(project_nodes, 0)
    for _, value in graph.items():
        for edge in value:
            if edge in fanin:
                fanin[edge] += 1
    return fanin


def fanout_analyzer(graph: dict[str, set[str]]) -> dict[str, int]:
    """Checks how many imports each module has."""
    fanout = dict.fromkeys(graph.keys(), 0)
    for key, value in graph.items():
        fanout[key] += len(value)
    return fanout


def _dfs(
    key: str,
    graph: dict[str, set[str]],
    current_path: list[str],
    visited_nodes: set[str],
) -> list[str] | None:
    """Walking the directed graph of dependencies."""
    dfs = []
    current_path.append(key)

    for neighbor in graph[key]:
        if neighbor in current_path:
            dfs = current_path[current_path.index(neighbor) :].copy()
            dfs.append(neighbor)
            break
        if neighbor not in visited_nodes and neighbor in graph:
            dfs = _dfs(neighbor, graph, current_path, visited_nodes)
            if dfs:
                break
    current_path.pop(current_path.index(key))
    visited_nodes.add(key)
    return dfs


def circular_imports(graph: dict[str, set[str]]) -> list[list[str]]:
    """Checks if there are any circular imports that we should worry about."""
    visited_nodes: set[str] = set()
    cycles: list[list[str]] = []
    for key in graph.keys():
        current_path: list[str] = []
        if key in visited_nodes:
            continue
        cycle = _dfs(key, graph, current_path, visited_nodes)
        if cycle:
            cycles.append(cycle)
    return cycles


def dead_callables_detector(
    project_definitions: set[str],
    callable_fanin: dict[str, int],
    project_imports: set[str],
) -> set[str]:
    """Project-wide set of canonical callables that are likely dead.

    A callable is dead when nothing references it — zero call-graph fan-in
    AND its canonical does not appear in the project import set. The
    import check protects names exported as public API even when no
    in-project call site is visible (e.g. consumed by external code).
    """
    return {
        c
        for c in project_definitions
        if callable_fanin.get(c, 0) == 0 and c not in project_imports
    }
