"""renderer.py"""

import json
from pathlib import Path

from .discovery import Package, node_name_gen

CURRENT_FOLDER_LOCATION: Path = Path(__file__).parent


def data_constructor(
    file_source: list[Package],
    project_nodes: set[str],
    project_definitions: set[str],
    directed_graph: dict[str, set[str]],
    cycles: list[list[str]],
    fanin: dict[str, int],
    fanout: dict[str, int],
    callable_graph: dict[str, set[str]],
    callable_fanin: dict[str, int],
    callable_fanout: dict[str, int],
    callable_cycles: list[list[str]],
    dead_callables: set[str],
    git_frequency: dict[str, dict[str, int | str]],
) -> dict:
    """Build the JSON-serializable payload for the renderer.

    Two graph layers are exposed per module: the existing module-level
    metrics, plus a `callables` array containing every function / class /
    method defined in that module with its own edges, fan-in/out, and
    dead flag. The synthetic `mod::<module>` source is included too so
    entry-point invocations show up.
    """
    data: dict = {}
    data["packages"] = []
    data["cycles"] = cycles
    data["callable_cycles"] = callable_cycles

    for package in file_source:
        package_info = {"id": package.name, "modules": []}
        for module in package.modules:
            node: str = node_name_gen(module)

            if node not in project_nodes:
                continue

            module_prefix = f"{node}::"
            module_callables = [
                c for c in project_definitions if c.startswith(module_prefix)
            ]
            module_module_source = f"{node}::<module>"

            callables_payload = [
                {
                    "id": c,
                    "edges": list(callable_graph.get(c, set())),
                    "fan_in": callable_fanin.get(c, 0),
                    "fan_out": callable_fanout.get(c, 0),
                    "is_dead": c in dead_callables,
                }
                for c in module_callables
            ]
            if module_module_source in callable_graph:
                callables_payload.append(
                    {
                        "id": module_module_source,
                        "edges": list(callable_graph.get(module_module_source, set())),
                        "fan_in": 0,
                        "fan_out": callable_fanout.get(module_module_source, 0),
                        "is_dead": False,
                    }
                )

            git_info = git_frequency.get(node, {})
            package_info["modules"].append(
                {
                    "id": node,
                    "edges": list(directed_graph.get(node, set())),
                    "fan_in": fanin.get(node, 0),
                    "fan_out": fanout.get(node, 0),
                    "n_commits": git_info.get("n_commits", 0),
                    "added_lines": git_info.get("added_lines", 0),
                    "removed_lines": git_info.get("removed_lines", 0),
                    "last_author": git_info.get("last_author", ""),
                    "with_symbols_to_review": any(
                        c.startswith(module_prefix) for c in dead_callables
                    ),
                    "callables": callables_payload,
                }
            )
        data["packages"].append(package_info)

    return data


def render(data: dict) -> str:
    """Creates a HTML string"""
    json_data: str = json.dumps(data)
    html_path = f"{CURRENT_FOLDER_LOCATION}/dependaman_template.html"
    js_path = f"{CURRENT_FOLDER_LOCATION}/dependaman_graph.js"
    with open(html_path) as html:
        with open(js_path) as js:
            js_data = js.read()
            html_data = html.read()
            html_data = html_data.replace("__GRAPH_DATA__", json_data)
            html_data = html_data.replace("__GRAPH_JS__", f"<script>{js_data}</script>")
            return html_data
