"""pool.py

Drown me baby!!
"""

import sys
from concurrent.futures import ProcessPoolExecutor, ThreadPoolExecutor

try:
    gil_enabled: bool = sys._is_gil_enabled()
except AttributeError:
    gil_enabled = True


MIN_FILES_FOR_POOL: int = 100


executor: type[ProcessPoolExecutor | ThreadPoolExecutor] = (
    ProcessPoolExecutor if gil_enabled else ThreadPoolExecutor
)
