"""异步队列封装"""

import asyncio
from typing import Any, Optional, List, Tuple


class BackpressureStrategy:
    """背压策略"""
    BLOCK = "block"  # 阻塞等待
    TIMEOUT_DROP = "timeout_drop"  # 超时丢弃
    IMMEDIATE_DROP = "immediate_drop"  # 立即丢弃
    THROW = "throw"  # 抛异常


class AsyncQueue:
    """异步队列"""
    
    def __init__(self, maxsize: int = 0, backpressure_strategy: str = BackpressureStrategy.BLOCK, timeout: float = 1.0):
        self.queue = asyncio.Queue(maxsize=maxsize)
        self.backpressure_strategy = backpressure_strategy
        self.timeout = timeout
    
    async def put(self, item: Any) -> bool:
        """放入数据
        
        Returns:
            bool: 是否成功放入
        """
        if self.backpressure_strategy == BackpressureStrategy.IMMEDIATE_DROP:
            if self.queue.full():
                return False
            await self.queue.put(item)
            return True
        elif self.backpressure_strategy == BackpressureStrategy.TIMEOUT_DROP:
            try:
                await asyncio.wait_for(self.queue.put(item), timeout=self.timeout)
                return True
            except asyncio.TimeoutError:
                return False
        elif self.backpressure_strategy == BackpressureStrategy.THROW:
            if self.queue.full():
                raise asyncio.QueueFull()
            await self.queue.put(item)
            return True
        else:  # BLOCK
            await self.queue.put(item)
            return True
    
    async def get(self) -> Any:
        """获取数据"""
        return await self.queue.get()
    
    async def put_batch(self, items: List[Any]) -> Tuple[int, List[Any]]:
        """批量放入数据
        
        Returns:
            Tuple[int, List[Any]]: (成功放入数量, 失败的项目列表)
        """
        success_count = 0
        failed_items = []
        for item in items:
            if await self.put(item):
                success_count += 1
            else:
                failed_items.append(item)
        return success_count, failed_items
    
    async def get_batch(self, max_items: int) -> List[Any]:
        """批量获取数据
        
        Args:
            max_items: 最大获取数量
        
        Returns:
            List[Any]: 获取的数据列表
        """
        items = []
        while len(items) < max_items and not self.queue.empty():
            items.append(await self.queue.get())
        return items
    
    def qsize(self) -> int:
        """获取队列大小"""
        return self.queue.qsize()
    
    def empty(self) -> bool:
        """检查队列是否为空"""
        return self.queue.empty()
    
    def full(self) -> bool:
        """检查队列是否已满"""
        return self.queue.full()
