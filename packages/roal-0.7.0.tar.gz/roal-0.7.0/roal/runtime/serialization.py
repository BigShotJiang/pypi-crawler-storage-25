"""跨进程序列化模块 - 支持多种序列化策略"""

import pickle
import json
import msgpack
from typing import Any, Optional, Callable


class SerializationError(Exception):
    """序列化错误"""
    pass


class DeserializationError(Exception):
    """反序列化错误"""
    pass


class Serializer:
    """序列化器抽象"""

    def serialize(self, data: Any) -> bytes:
        raise NotImplementedError

    def deserialize(self, data: bytes) -> Any:
        raise NotImplementedError


class PickleSerializer(Serializer):
    """Pickle 序列化器 - 支持任意 Python 对象"""

    def serialize(self, data: Any) -> bytes:
        try:
            return pickle.dumps(data, protocol=pickle.HIGHEST_PROTOCOL)
        except Exception as e:
            raise SerializationError(f"Pickle serialization failed: {e}")

    def deserialize(self, data: bytes) -> Any:
        try:
            return pickle.loads(data)
        except Exception as e:
            raise DeserializationError(f"Pickle deserialization failed: {e}")


class JSONSerializer(Serializer):
    """JSON 序列化器 - 适用于基本数据类型"""

    def serialize(self, data: Any) -> bytes:
        try:
            return json.dumps(data, default=str).encode('utf-8')
        except Exception as e:
            raise SerializationError(f"JSON serialization failed: {e}")

    def deserialize(self, data: bytes) -> Any:
        try:
            return json.loads(data.decode('utf-8'))
        except Exception as e:
            raise DeserializationError(f"JSON deserialization failed: {e}")


class MsgpackSerializer(Serializer):
    """MessagePack 序列化器 - 高效二进制格式"""

    def serialize(self, data: Any) -> bytes:
        try:
            return msgpack.packb(data, use_bin_type=True, default=str)
        except Exception as e:
            raise SerializationError(f"Msgpack serialization failed: {e}")

    def deserialize(self, data: bytes) -> Any:
        try:
            return msgpack.unpackb(data, raw=False)
        except Exception as e:
            raise DeserializationError(f"Msgpack deserialization failed: {e}")


class WrappedMessage:
    """包装的消息 - 用于跨进程传递"""

    def __init__(self, payload: Any, metadata: Optional[dict] = None, is_error: bool = False):
        self.payload = payload
        self.metadata = metadata or {}
        self.is_error = is_error

    def to_dict(self) -> dict:
        return {
            'payload': self.payload,
            'metadata': self.metadata,
            'is_error': self.is_error,
        }

    @classmethod
    def from_dict(cls, data: dict) -> 'WrappedMessage':
        return cls(
            payload=data.get('payload'),
            metadata=data.get('metadata', {}),
            is_error=data.get('is_error', False),
        )


class IPCSerializer:
    """IPC 消息序列化器 - 处理完整的 IPC 消息包装"""

    def __init__(self, serializer: Optional[Serializer] = None):
        self._serializer = serializer or PickleSerializer()

    def wrap_and_serialize(self, payload: Any, metadata: Optional[dict] = None, is_error: bool = False) -> bytes:
        """包装并序列化消息"""
        msg = WrappedMessage(payload=payload, metadata=metadata, is_error=is_error)
        msg_dict = msg.to_dict()
        return self._serializer.serialize(msg_dict)

    def deserialize_and_unwrap(self, data: bytes) -> tuple:
        """反序列化并解包消息"""
        msg_dict = self._serializer.deserialize(data)
        msg = WrappedMessage.from_dict(msg_dict)
        return msg.payload, msg.metadata, msg.is_error
