"""多进程 Worker 池 - 用于 CPU 密集型任务隔离"""

import asyncio
import multiprocessing
import time
import traceback
from typing import Any, Optional, Dict, List, Callable
from multiprocessing import Queue, Process
from threading import Thread
import logging

from roal.runtime.serialization import IPCSerializer, WrappedMessage, SerializationError, DeserializationError
from roal.monitoring.logger import get_task_logger


logger = logging.getLogger(__name__)


def _process_worker_loop(
    worker_id: int,
    func_name: str,  # 接收任务名称而不是task对象
    input_queue: Queue,
    output_queue: Queue,
    pipeline_id: str,
    task_name: str,
    config: Optional[dict] = None,
    stop_event=None,
):
    """子进程中的 Worker 循环"""
    serializer = IPCSerializer()
    logger = get_task_logger(pipeline_id, task_name)
    logger.info(f"Process worker {worker_id} started in PID {multiprocessing.current_process().pid}")

    try:
        # 从__main__模块中获取函数
        import __main__
        task_func = None
        if hasattr(__main__, func_name):
            task_func = getattr(__main__, func_name)
            logger.info(f"从__main__模块加载了函数: {func_name}")
        else:
            logger.error(f"无法从__main__模块加载函数: {func_name}")
            return

        # 检查函数是否有on_start方法
        if hasattr(task_func, 'on_start'):
            from roal.api.context import TaskContext
            ctx = TaskContext(
                pipeline_id=pipeline_id,
                task_name=task_name,
                config=config or {},
            )
            task_func.on_start(ctx)

        while True:
            if stop_event and stop_event.is_set():
                break

            try:
                raw_data = input_queue.get(timeout=0.1)
            except Exception:
                continue

            if raw_data is None:
                break

            try:
                data, metadata, is_error = serializer.deserialize_and_unwrap(raw_data)
            except (SerializationError, DeserializationError) as e:
                logger.error(f"Deserialization failed: {e}")
                continue

            try:
                from roal.api.context import TaskContext
                ctx = TaskContext(
                    pipeline_id=pipeline_id,
                    task_name=task_name,
                    record_id=metadata.get('record_id', ''),
                    config=config or {},
                )
                
                import asyncio as aio
                # 直接调用task_func
                if aio.iscoroutinefunction(task_func):
                    loop = asyncio.new_event_loop()
                    asyncio.set_event_loop(loop)
                    result = loop.run_until_complete(task_func(data, ctx))
                    loop.close()
                else:
                    result = task_func(data, ctx)
                    if aio.iscoroutine(result):
                        loop = asyncio.new_event_loop()
                        asyncio.set_event_loop(loop)
                        result = loop.run_until_complete(result)
                        loop.close()

                if result is not None:
                    out_data = serializer.wrap_and_serialize(result, metadata)
                    output_queue.put(out_data)

            except Exception as e:
                error_data = serializer.wrap_and_serialize(
                    None,
                    {**metadata, 'error': str(e), 'traceback': traceback.format_exc()},
                    is_error=True,
                )
                output_queue.put(error_data)
                logger.error(f"Process worker {worker_id} error: {e}")

        if hasattr(task_func, 'on_stop'):
            from roal.api.context import TaskContext
            ctx = TaskContext(pipeline_id, task_name, "", config=config or {})
            task_func.on_stop(ctx)

    except Exception as e:
        logger.error(f"Process worker {worker_id} fatal error: {e}")
    finally:
        logger.info(f"Process worker {worker_id} stopped")


class ProcessWorker:
    """单个进程 Worker"""

    def __init__(
        self,
        worker_id: int,
        task: Any,
        pipeline_id: str,
        task_name: str,
        config: Optional[dict] = None,
    ):
        self.worker_id = worker_id
        self.task = task
        self.pipeline_id = pipeline_id
        self.task_name = task_name
        self.config = config or {}
        self.input_queue: Queue = Queue(maxsize=1000)
        self.output_queue: Queue = Queue(maxsize=1000)
        self.process: Optional[Process] = None
        self._running = False
        self._stop_event = multiprocessing.Event()
        self._serializer = IPCSerializer()

    def start(self) -> None:
        """启动进程 Worker"""
        self._running = True
        self._stop_event.clear()

        # 不传递task对象，而是传递task的名称
        # 在子进程中根据名称重新获取函数，避免pickle错误
        self.process = Process(
            target=_process_worker_loop,
            args=(
                self.worker_id,
                self.task_name,  # 传递任务名称而不是task对象
                self.input_queue,
                self.output_queue,
                self.pipeline_id,
                self.task_name,
                self.config,
            ),
            kwargs={'stop_event': self._stop_event},
            daemon=True,
        )
        self.process.start()

    def put(self, data: Any, metadata: Optional[dict] = None) -> None:
        """发送数据到进程 Worker"""
        serialized = self._serializer.wrap_and_serialize(data, metadata)
        self.input_queue.put(serialized)

    def get(self, timeout: float = 0.1) -> Optional[tuple]:
        """从进程 Worker 获取结果"""
        try:
            raw_data = self.output_queue.get(timeout=timeout)
            return self._serializer.deserialize_and_unwrap(raw_data)
        except Exception:
            return None

    def stop(self) -> None:
        """停止进程 Worker"""
        self._running = False
        self._stop_event.set()
        try:
            # 发送终止信号
            self.input_queue.put(None, timeout=1)
        except Exception as e:
            logger.warning(f"发送终止信号失败: {e}")

        # 强制终止进程
        if self.process and self.process.is_alive():
            logger.info(f"等待进程 {self.process.pid} 终止...")
            self.process.join(timeout=3)
            if self.process.is_alive():
                logger.warning(f"进程 {self.process.pid} 未响应，强制终止...")
                self.process.terminate()
                self.process.join(timeout=2)
                if self.process.is_alive():
                    logger.error(f"进程 {self.process.pid} 无法终止")

    @property
    def is_alive(self) -> bool:
        return self.process is not None and self.process.is_alive()

    @property
    def qsize(self) -> int:
        return self.output_queue.qsize() if self.process else 0


class ProcessWorkerPool:
    """多进程 Worker 池 - 用于 CPU 密集型任务"""

    def __init__(
        self,
        task: Any,
        pipeline_id: str,
        task_name: str,
        worker_count: int = 1,
        config: Optional[dict] = None,
    ):
        self.task = task
        self.pipeline_id = pipeline_id
        self.task_name = task_name
        self.worker_count = worker_count
        self.config = config or {}
        self.workers: List[ProcessWorker] = []
        self._running = False
        self._serializer = IPCSerializer()
        self._output_queues: List[Queue] = []
        self._merged_output_queue: Queue = Queue(maxsize=10000)
        self._output_thread: Optional[Thread] = None
        self._output_thread_stop = False
        self._logger = get_task_logger(pipeline_id, task_name)

    def start(self) -> None:
        """启动所有进程 Worker"""
        self._running = True
        self._output_thread_stop = False

        for i in range(self.worker_count):
            worker = ProcessWorker(
                worker_id=i,
                task=self.task,
                pipeline_id=self.pipeline_id,
                task_name=self.task_name,
                config=self.config,
            )
            worker.start()
            self.workers.append(worker)
            self._output_queues.append(worker.output_queue)

        self._output_thread = Thread(target=self._merge_outputs, daemon=True)
        self._output_thread.start()

        self._logger.info(f"Started {self.worker_count} process workers")

    def _merge_outputs(self) -> None:
        """合并所有 Worker 的输出到一个队列"""
        while not self._output_thread_stop:
            for queue in self._output_queues:
                try:
                    item = queue.get(timeout=0.05)
                    self._merged_output_queue.put(item, timeout=0.1)
                except Exception:
                    continue

    def put(self, data: Any, metadata: Optional[dict] = None) -> None:
        """发送数据到 Worker 池（轮询分发）"""
        if not self.workers:
            return

        worker = self.workers[0]
        worker.put(data, metadata)

    def get(self, timeout: float = 0.1) -> Optional[tuple]:
        """从 Worker 池获取结果"""
        try:
            raw_data = self._merged_output_queue.get(timeout=timeout)
            return self._serializer.deserialize_and_unwrap(raw_data)
        except Exception:
            return None

    async def stop(self) -> None:
        """停止所有进程 Worker"""
        self._running = False
        self._output_thread_stop = True

        for worker in self.workers:
            worker.stop()

        if self._output_thread and self._output_thread.is_alive():
            self._output_thread.join(timeout=5)

        self._logger.info("All process workers stopped")

    async def scale(self, worker_count: int) -> None:
        """动态调整进程 Worker 数量"""
        if worker_count == self.worker_count:
            return

        if worker_count < self.worker_count:
            for i in range(worker_count, self.worker_count):
                if i < len(self.workers):
                    self.workers[i].stop()
            self.workers = self.workers[:worker_count]
            self._output_queues = self._output_queues[:worker_count]
        else:
            for i in range(self.worker_count, worker_count):
                worker = ProcessWorker(
                    worker_id=i,
                    task=self.task,
                    pipeline_id=self.pipeline_id,
                    task_name=self.task_name,
                    config=self.config,
                )
                worker.start()
                self.workers.append(worker)
                self._output_queues.append(worker.output_queue)

        self.worker_count = worker_count
        self._logger.info(f"Scaled to {worker_count} process workers")

    @property
    def merged_queue(self) -> Queue:
        return self._merged_output_queue
