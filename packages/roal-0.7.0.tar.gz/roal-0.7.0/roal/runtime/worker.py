"""Worker 协程管理 - 0.6.0 动态能力增强"""

import asyncio
import time
from typing import Optional, List, Dict, Any
from roal.api.context import TaskContext, DataLineage
from roal.runtime.queue import AsyncQueue
from roal.monitoring.metrics import MetricsCollector, default_collector, Timer
from roal.monitoring.pipeline_metrics import PipelineMetrics
from roal.monitoring.logger import get_task_logger
from roal.core.retry import RetryStrategy, NoRetry, execute_with_retry
from roal.core.dead_letter import DeadLetterQueue, DeadLetterRecord


class Worker:
    """Worker 协程"""

    def __init__(
        self,
        worker_id: int,
        task: Any,
        queue: AsyncQueue,
        pipeline_id: str,
        task_name: str,
        executor: Any,
        state_store=None,
        metrics_collector: Optional[MetricsCollector] = None,
        pipeline_metrics: Optional[PipelineMetrics] = None,
        retry_strategy: Optional[RetryStrategy] = None,
        dead_letter_queue: Optional[DeadLetterQueue] = None,
        checkpoint_manager=None,
        config_registry=None,
        pause_event=None,
    ):
        self.worker_id = worker_id
        self.task = task
        self.queue = queue
        self.pipeline_id = pipeline_id
        self.task_name = task_name
        self.executor = executor
        self.state_store = state_store
        self.metrics_collector = metrics_collector or default_collector
        self.pipeline_metrics = pipeline_metrics
        self.retry_strategy = retry_strategy or NoRetry()
        self.dead_letter_queue = dead_letter_queue
        self.checkpoint_manager = checkpoint_manager
        self.config_registry = config_registry
        self.pause_event = pause_event
        self.running = False
        self.task_coro = None
        self._processed_count = 0
        self._logger = get_task_logger(pipeline_id, task_name)

    def _make_context(self, record_id: str = "", lineage=None) -> TaskContext:
        return TaskContext(
            self.pipeline_id, self.task_name, record_id,
            state_store=self.state_store,
            metrics_collector=self.metrics_collector,
            lineage=lineage,
            config_registry=self.config_registry,
        )

    async def start(self) -> None:
        """启动 Worker"""
        self.running = True
        try:
            if hasattr(self.task, 'on_start'):
                ctx = self._make_context()
                self.task.on_start(ctx)

            self._logger.info(f"Worker {self.worker_id} started")

            while self.running:
                try:
                    if self.pause_event and not self.pause_event.is_set():
                        try:
                            await asyncio.wait_for(self.pause_event.wait(), timeout=0.1)
                        except asyncio.TimeoutError:
                            continue

                    try:
                        data = await asyncio.wait_for(self.queue.get(), timeout=0.1)
                    except asyncio.TimeoutError:
                        continue

                    record_id = getattr(data, 'record_id', f"{self.pipeline_id}-{self.task_name}-{self.worker_id}-{time.time()}")
                    lineage = getattr(data, 'lineage', None)
                    payload = getattr(data, 'payload', data)

                    ctx = self._make_context(record_id, lineage)

                    start_time = time.perf_counter()
                    retries = 0

                    try:
                        async def _execute():
                            return await self.task(payload, ctx)

                        if hasattr(self.task, '__call__') and asyncio.iscoroutinefunction(self.task.__call__):
                            result = await execute_with_retry(_execute, strategy=self.retry_strategy)
                        elif asyncio.iscoroutinefunction(self.task):
                            result = await execute_with_retry(_execute, strategy=self.retry_strategy)
                        else:
                            result = self.task(payload, ctx)
                            if asyncio.iscoroutine(result):
                                result = await result
                            elif hasattr(result, '__await__'):
                                result = await result

                        elapsed = time.perf_counter() - start_time

                        if self.pipeline_metrics:
                            self.pipeline_metrics.record_processed(self.task_name, elapsed)

                        ctx.logger.debug(f"Task processed successfully in {elapsed:.3f}s")

                        self._processed_count += 1

                        if self.checkpoint_manager:
                            await self.checkpoint_manager.save_checkpoint(
                                self.pipeline_id, self.task_name, self._processed_count, record_id
                            )

                        if result is not None:
                            if hasattr(result, '__aiter__'):
                                async for item in result:
                                    if item is not None:
                                        await self.executor.route_data(
                                            self.task, item, self.pipeline_id, lineage
                                        )
                            elif hasattr(result, '__iter__') and not isinstance(result, (str, bytes)):
                                for item in result:
                                    if item is not None:
                                        await self.executor.route_data(
                                            self.task, item, self.pipeline_id, lineage
                                        )
                            else:
                                await self.executor.route_data(
                                    self.task, result, self.pipeline_id, lineage
                                )
                    except Exception as e:
                        if self.pipeline_metrics:
                            self.pipeline_metrics.record_error(self.task_name)

                        if self.dead_letter_queue:
                            dl_record = DeadLetterRecord(
                                payload=payload,
                                task_name=self.task_name,
                                pipeline_id=self.pipeline_id,
                                error=e,
                                retries=retries,
                                original_record_id=record_id,
                            )
                            await self.dead_letter_queue.put(dl_record)
                            ctx.logger.warning(f"Data sent to dead letter queue: {e}")

                        raise

                except asyncio.CancelledError:
                    break
                except Exception as e:
                    self._logger.error(f"Worker {self.worker_id} error: {e}")
        finally:
            if hasattr(self.task, 'on_stop'):
                ctx = self._make_context()
                self.task.on_stop(ctx)
            self._logger.info(f"Worker {self.worker_id} stopped")

    def stop(self) -> None:
        """停止 Worker"""
        self.running = False


class WorkerPool:
    """Worker 池"""

    def __init__(
        self,
        task: Any,
        queue: AsyncQueue,
        pipeline_id: str,
        task_name: str,
        worker_count: int = 1,
        executor: Any = None,
        state_store=None,
        metrics_collector: Optional[MetricsCollector] = None,
        pipeline_metrics: Optional[PipelineMetrics] = None,
        retry_strategy: Optional[RetryStrategy] = None,
        dead_letter_queue: Optional[DeadLetterQueue] = None,
        checkpoint_manager=None,
        config_registry=None,
        pause_event=None,
    ):
        self.task = task
        self.queue = queue
        self.pipeline_id = pipeline_id
        self.task_name = task_name
        self.worker_count = worker_count
        self.executor = executor
        self.state_store = state_store
        self.metrics_collector = metrics_collector or default_collector
        self.pipeline_metrics = pipeline_metrics
        self.retry_strategy = retry_strategy or NoRetry()
        self.dead_letter_queue = dead_letter_queue
        self.checkpoint_manager = checkpoint_manager
        self.config_registry = config_registry
        self.pause_event = pause_event
        self.workers: List[Worker] = []
        self.tasks: List[asyncio.Task] = []
        self._paused = False
        self._local_pause_event = asyncio.Event()
        self._local_pause_event.set()
        self._logger = get_task_logger(pipeline_id, task_name)

    async def start(self) -> None:
        """启动所有 Worker"""
        if hasattr(self.task, 'on_init'):
            ctx = TaskContext(
                self.pipeline_id, self.task_name, "",
                state_store=self.state_store,
                metrics_collector=self.metrics_collector,
                config_registry=self.config_registry,
            )
            self.task.on_init(ctx)

        self._logger.info(f"Starting {self.worker_count} workers")

        effective_pause = self.pause_event if self.pause_event else self._local_pause_event

        for i in range(self.worker_count):
            worker = Worker(
                i, self.task, self.queue, self.pipeline_id, self.task_name,
                self.executor, self.state_store,
                self.metrics_collector, self.pipeline_metrics,
                self.retry_strategy, self.dead_letter_queue, self.checkpoint_manager,
                self.config_registry,
                effective_pause,
            )
            self.workers.append(worker)
            task = asyncio.create_task(worker.start())
            self.tasks.append(task)

    async def stop(self) -> None:
        """停止所有 Worker"""
        for worker in self.workers:
            worker.stop()

        if self.tasks:
            await asyncio.gather(*self.tasks, return_exceptions=True)

        if hasattr(self.task, 'on_destroy'):
            ctx = TaskContext(
                self.pipeline_id, self.task_name, "",
                state_store=self.state_store,
                metrics_collector=self.metrics_collector,
                config_registry=self.config_registry,
            )
            self.task.on_destroy(ctx)

        self._logger.info("All workers stopped")

    async def scale(self, worker_count: int) -> None:
        """动态调整 Worker 数量"""
        if worker_count == self.worker_count:
            return

        effective_pause = self.pause_event if self.pause_event else self._local_pause_event

        if worker_count < self.worker_count:
            for i in range(worker_count, self.worker_count):
                if i < len(self.workers):
                    worker = self.workers[i]
                    worker.stop()
                    if i < len(self.tasks):
                        await self.tasks[i]

            self.workers = self.workers[:worker_count]
            self.tasks = self.tasks[:worker_count]
        else:
            for i in range(self.worker_count, worker_count):
                worker = Worker(
                    i, self.task, self.queue, self.pipeline_id, self.task_name,
                    self.executor, self.state_store,
                    self.metrics_collector, self.pipeline_metrics,
                    self.retry_strategy, self.dead_letter_queue, self.checkpoint_manager,
                    self.config_registry,
                    effective_pause,
                )
                self.workers.append(worker)
                task = asyncio.create_task(worker.start())
                self.tasks.append(task)

        self.worker_count = worker_count

        if self.pipeline_metrics:
            self.pipeline_metrics.update_active_workers(self.task_name, worker_count)

        self._logger.info(f"Scaled to {worker_count} workers")

    def pause(self) -> None:
        """暂停Task池"""
        self._paused = True
        if self.pause_event:
            self.pause_event.clear()
        else:
            self._local_pause_event.clear()

    def resume(self) -> None:
        """恢复Task池"""
        self._paused = False
        if self.pause_event:
            self.pause_event.set()
        else:
            self._local_pause_event.set()

    async def pause_async(self) -> None:
        """异步暂停"""
        self.pause()

    async def resume_async(self) -> None:
        """异步恢复"""
        self.resume()
