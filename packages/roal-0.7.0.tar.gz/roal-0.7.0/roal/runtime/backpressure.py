"""背压控制"""

from typing import Optional


class BackpressureStrategy:
    """背压策略"""
    
    def apply(self, queue_size: int, max_size: int) -> bool:
        """应用背压策略"""
        pass


class BlockingStrategy(BackpressureStrategy):
    """阻塞等待策略"""
    
    def apply(self, queue_size: int, max_size: int) -> bool:
        return queue_size >= max_size


class DropStrategy(BackpressureStrategy):
    """丢弃策略"""
    
    def apply(self, queue_size: int, max_size: int) -> bool:
        return queue_size >= max_size


class ErrorStrategy(BackpressureStrategy):
    """抛异常策略"""
    
    def apply(self, queue_size: int, max_size: int) -> bool:
        if queue_size >= max_size:
            raise Exception("Queue is full")
        return False
