"""文件存储"""

import json
from typing import Any, Optional
import os
import time
from .base import StateStore


class FileStateStore(StateStore):
    """文件状态存储"""
    
    def __init__(self, file_path: str):
        super().__init__()
        self.file_path = file_path
        self.store: dict = {}
        self.ttl_map: dict = {}
        self._load()
    
    def _load(self) -> None:
        """加载存储"""
        if os.path.exists(self.file_path) and os.path.getsize(self.file_path) > 0:
            with open(self.file_path, 'r') as f:
                data = json.load(f)
                self.store = data.get('store', {})
                self.ttl_map = data.get('ttl_map', {})
        else:
            dir_path = os.path.dirname(os.path.abspath(self.file_path))
            if dir_path:
                os.makedirs(dir_path, exist_ok=True)
            self.store = {}
            self.ttl_map = {}
    
    def _save(self) -> None:
        """保存存储"""
        data = {
            'store': self.store,
            'ttl_map': self.ttl_map
        }
        with open(self.file_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    async def get(self, key: str) -> Optional[Any]:
        if key in self.store:
            if key in self.ttl_map and time.time() > self.ttl_map[key]:
                await self.delete(key)
                return None
            return self.store.get(key)
        return None
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        old_value = self.store.get(key)
        self.store[key] = value
        if ttl is not None:
            self.ttl_map[key] = time.time() + ttl
        elif key in self.ttl_map:
            del self.ttl_map[key]
        self._save()
        await self._notify_subscribers(key, value, old_value)
    
    async def delete(self, key: str) -> None:
        if key in self.store:
            old_value = self.store.pop(key)
            if key in self.ttl_map:
                del self.ttl_map[key]
            self._save()
            await self._notify_subscribers(key, None, old_value)
    
    async def increment(self, key: str, value: int = 1) -> int:
        old_value = self.store.get(key, 0)
        new_value = old_value + value
        self.store[key] = new_value
        self._save()
        await self._notify_subscribers(key, new_value, old_value)
        return new_value
    
    async def compare_and_set(self, key: str, old_value: Any, new_value: Any) -> bool:
        current = self.store.get(key)
        if current == old_value:
            self.store[key] = new_value
            self._save()
            await self._notify_subscribers(key, new_value, old_value)
            return True
        return False
