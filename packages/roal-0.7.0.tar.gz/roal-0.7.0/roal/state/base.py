"""StateStore 抽象"""

from abc import ABC, abstractmethod
from typing import Any, Optional, Callable, Dict, List
import asyncio
import time


class StateStore(ABC):
    """状态存储抽象"""
    
    def __init__(self):
        self._subscribers: Dict[str, List[Callable]] = {}
    
    @abstractmethod
    async def get(self, key: str) -> Optional[Any]:
        """获取状态"""
        pass
    
    @abstractmethod
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        """设置状态"""
        pass
    
    @abstractmethod
    async def delete(self, key: str) -> None:
        """删除状态"""
        pass
    
    @abstractmethod
    async def increment(self, key: str, value: int = 1) -> int:
        """原子递增"""
        pass
    
    @abstractmethod
    async def compare_and_set(self, key: str, old_value: Any, new_value: Any) -> bool:
        """比较并设置"""
        pass
    
    def subscribe(self, key: str, callback: Callable) -> None:
        """订阅状态变更"""
        if key not in self._subscribers:
            self._subscribers[key] = []
        self._subscribers[key].append(callback)
    
    def unsubscribe(self, key: str, callback: Callable) -> None:
        """取消订阅"""
        if key in self._subscribers:
            self._subscribers[key].remove(callback)
            if not self._subscribers[key]:
                del self._subscribers[key]
    
    async def _notify_subscribers(self, key: str, new_value: Any, old_value: Any) -> None:
        """通知订阅者"""
        if key in self._subscribers:
            for callback in self._subscribers[key]:
                if asyncio.iscoroutinefunction(callback):
                    await callback(key, new_value, old_value)
                else:
                    callback(key, new_value, old_value)
