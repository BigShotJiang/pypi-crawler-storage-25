"""内存存储"""

from typing import Any, Optional, Dict
import time
import asyncio
from .base import StateStore


class MemoryStateStore(StateStore):
    """内存状态存储"""
    
    def __init__(self):
        super().__init__()
        self.store: Dict[str, Any] = {}
        self.ttl_map: Dict[str, float] = {}
    
    async def get(self, key: str) -> Optional[Any]:
        if key in self.store:
            if key in self.ttl_map and time.time() > self.ttl_map[key]:
                await self.delete(key)
                return None
            return self.store.get(key)
        return None
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        old_value = self.store.get(key)
        self.store[key] = value
        if ttl is not None:
            self.ttl_map[key] = time.time() + ttl
        elif key in self.ttl_map:
            del self.ttl_map[key]
        await self._notify_subscribers(key, value, old_value)
    
    async def delete(self, key: str) -> None:
        if key in self.store:
            old_value = self.store.pop(key)
            if key in self.ttl_map:
                del self.ttl_map[key]
            await self._notify_subscribers(key, None, old_value)
    
    async def increment(self, key: str, value: int = 1) -> int:
        old_value = self.store.get(key, 0)
        new_value = old_value + value
        self.store[key] = new_value
        await self._notify_subscribers(key, new_value, old_value)
        return new_value
    
    async def compare_and_set(self, key: str, old_value: Any, new_value: Any) -> bool:
        current = self.store.get(key)
        if current == old_value:
            self.store[key] = new_value
            await self._notify_subscribers(key, new_value, old_value)
            return True
        return False
    
    def clear(self) -> None:
        """清空存储"""
        self.store.clear()
        self.ttl_map.clear()
