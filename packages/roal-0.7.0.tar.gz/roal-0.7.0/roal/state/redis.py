"""Redis 存储"""

from typing import Any, Optional
import json
import asyncio
from .base import StateStore


class RedisStateStore(StateStore):
    """Redis 状态存储"""
    
    def __init__(self, redis_url: str = "redis://localhost:6379"):
        super().__init__()
        self.redis_url = redis_url
        self._redis = None
    
    def _get_redis(self):
        """懒加载 Redis 连接"""
        if self._redis is None:
            import redis.asyncio as redis
            self._redis = redis.from_url(self.redis_url, decode_responses=True)
        return self._redis
    
    async def get(self, key: str) -> Optional[Any]:
        redis_client = self._get_redis()
        value = await redis_client.get(key)
        if value is not None:
            try:
                return json.loads(value)
            except (json.JSONDecodeError, TypeError):
                return value
        return None
    
    async def set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        redis_client = self._get_redis()
        old_value = await self.get(key)
        serialized = json.dumps(value)
        if ttl:
            await redis_client.setex(key, ttl, serialized)
        else:
            await redis_client.set(key, serialized)
        await self._notify_subscribers(key, value, old_value)
    
    async def delete(self, key: str) -> None:
        redis_client = self._get_redis()
        old_value = await self.get(key)
        await redis_client.delete(key)
        await self._notify_subscribers(key, None, old_value)
    
    async def increment(self, key: str, value: int = 1) -> int:
        redis_client = self._get_redis()
        new_value = await redis_client.incrby(key, value)
        old_value = new_value - value
        await self._notify_subscribers(key, new_value, old_value)
        return new_value
    
    async def compare_and_set(self, key: str, old_value: Any, new_value: Any) -> bool:
        redis_client = self._get_redis()
        async with redis_client.pipeline() as pipe:
            try:
                await pipe.watch(key)
                current = await pipe.get(key)
                if current is not None:
                    try:
                        current = json.loads(current)
                    except (json.JSONDecodeError, TypeError):
                        pass
                
                if current == old_value:
                    await pipe.multi()
                    serialized = json.dumps(new_value)
                    await pipe.set(key, serialized)
                    await pipe.execute()
                    await self._notify_subscribers(key, new_value, old_value)
                    return True
                return False
            except Exception:
                return False
    
    async def close(self) -> None:
        """关闭 Redis 连接"""
        if self._redis:
            await self._redis.close()
