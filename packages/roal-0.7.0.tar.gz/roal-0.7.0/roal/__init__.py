"""Roal 框架 - 纯数据流转与任务编排框架"""

__version__ = "0.7.0"

from .api.task import task, Task
from .api.pipeline import Pipeline, PipelineStatus
from .api.context import TaskContext
from .api.boundary import DataBoundary
from .state.base import StateStore
from .state.memory import MemoryStateStore
from .state.file import FileStateStore
from .state.redis import RedisStateStore
from .monitoring.metrics import MetricsCollector, Counter, Histogram, Gauge, Timer
from .monitoring.logger import setup_logging, get_logger
from .core.retry import RetryStrategy, NoRetry, FixedRetry, ExponentialBackoffRetry, ConditionalRetry
from .core.dead_letter import DeadLetterQueue, DeadLetterRecord
from .core.config import ConfigRegistry
from .checkpoint.stores import CheckpointStore, MemoryCheckpointStore, FileCheckpointStore, RedisCheckpointStore
from .checkpoint.manager import CheckpointManager, CheckpointInfo

__all__ = [
    "task",
    "Task",
    "Pipeline",
    "PipelineStatus",
    "TaskContext",
    "DataBoundary",
    "StateStore",
    "MemoryStateStore",
    "FileStateStore",
    "RedisStateStore",
    "MetricsCollector",
    "Counter",
    "Histogram",
    "Gauge",
    "Timer",
    "setup_logging",
    "get_logger",
    "RetryStrategy",
    "NoRetry",
    "FixedRetry",
    "ExponentialBackoffRetry",
    "ConditionalRetry",
    "DeadLetterQueue",
    "DeadLetterRecord",
    "ConfigRegistry",
    "CheckpointStore",
    "MemoryCheckpointStore",
    "FileCheckpointStore",
    "RedisCheckpointStore",
    "CheckpointManager",
    "CheckpointInfo",
]
