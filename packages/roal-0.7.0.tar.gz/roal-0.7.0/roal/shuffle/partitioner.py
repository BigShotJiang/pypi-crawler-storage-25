"""Shuffle 分区器"""

import hashlib


class Partitioner:
    """分区器基类"""
    
    def __init__(self, num_partitions: int):
        self.num_partitions = num_partitions
    
    def partition(self, key: str) -> int:
        """根据 key 计算分区 ID"""
        raise NotImplementedError


class HashPartitioner(Partitioner):
    """哈希分区器"""
    
    def partition(self, key: str) -> int:
        hash_value = int(hashlib.md5(key.encode()).hexdigest(), 16)
        return hash_value % self.num_partitions


class RangePartitioner(Partitioner):
    """范围分区器"""
    
    def __init__(self, num_partitions: int, key_ranges=None):
        super().__init__(num_partitions)
        self.key_ranges = key_ranges or self._default_ranges()
    
    def _default_ranges(self):
        """默认范围划分"""
        ranges = []
        step = 1.0 / self.num_partitions
        for i in range(self.num_partitions):
            ranges.append((i * step, (i + 1) * step))
        return ranges
    
    def partition(self, key: str) -> int:
        hash_value = int(hashlib.md5(key.encode()).hexdigest(), 16) / (2**128)
        for i, (start, end) in enumerate(self.key_ranges):
            if start <= hash_value < end:
                return i
        return 0