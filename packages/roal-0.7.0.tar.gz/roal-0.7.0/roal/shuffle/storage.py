"""Shuffle 存储实现"""

import asyncio
import tempfile
import os
import struct
import zlib
import pickle
import sys
from abc import ABC, abstractmethod
from collections import defaultdict
from typing import AsyncIterator, Tuple, Any


class ShuffleStorage(ABC):
    """Shuffle 存储抽象基类"""
    
    @abstractmethod
    async def write(self, partition: int, key: str, value: Any) -> None:
        pass
    
    @abstractmethod
    async def read_grouped(self, partition: int) -> AsyncIterator[Tuple[str, AsyncIterator]]:
        pass
    
    @abstractmethod
    def seal(self) -> None:
        """封存存储，表示不再写入"""
        pass
    
    @abstractmethod
    async def cleanup(self) -> None:
        """清理存储资源"""
        pass


class MemoryShuffleStorage(ShuffleStorage):
    """内存存储"""
    
    def __init__(self, config):
        self._data = defaultdict(lambda: defaultdict(list))
        self._sealed = False
        self._lock = asyncio.Lock()
    
    async def write(self, partition: int, key: str, value: Any) -> None:
        async with self._lock:
            if self._sealed:
                raise RuntimeError("Storage is sealed")
            self._data[partition][key].append(value)
    
    async def read_grouped(self, partition: int) -> AsyncIterator[Tuple[str, AsyncIterator]]:
        if not self._sealed:
            raise RuntimeError("Storage not sealed yet")
        
        partition_data = self._data.get(partition, {})
        for key, values in partition_data.items():
            async def value_iterator(vals=values):
                for v in vals:
                    yield v
            yield key, value_iterator()
    
    def seal(self) -> None:
        self._sealed = True
    
    async def cleanup(self) -> None:
        self._data.clear()


class DiskShuffleStorage(ShuffleStorage):
    """磁盘存储"""
    
    def __init__(self, config):
        self._user_spill_dir = config.spill_dir is not None
        self.spill_dir = config.spill_dir or tempfile.mkdtemp()
        self.compress = config.compress
        os.makedirs(self.spill_dir, exist_ok=True)
        self._files = defaultdict(dict)
        self._sealed = False
        self._lock = asyncio.Lock()
    
    def _get_or_create_file(self, partition: int, key: str):
        if key not in self._files[partition]:
            self._files[partition][key] = tempfile.NamedTemporaryFile(
                dir=self.spill_dir, delete=False, suffix=".shuffle"
            )
        return self._files[partition][key]
    
    async def write(self, partition: int, key: str, value: Any) -> None:
        async with self._lock:
            if self._sealed:
                raise RuntimeError("Storage is sealed")
            f = self._get_or_create_file(partition, key)
            data = pickle.dumps(value)
            if self.compress:
                data = zlib.compress(data)
            f.write(struct.pack(">I", len(data)))
            f.write(data)
            f.flush()
    
    async def read_grouped(self, partition: int) -> AsyncIterator[Tuple[str, AsyncIterator]]:
        if not self._sealed:
            raise RuntimeError("Storage not sealed yet")
        
        partition_files = self._files.get(partition, {})
        for key, f in list(partition_files.items()):
            if not os.path.exists(f.name):
                continue
            async def value_iterator(file_path=f.name):
                with open(file_path, 'rb') as fh:
                    while True:
                        len_bytes = fh.read(4)
                        if not len_bytes:
                            break
                        length = struct.unpack(">I", len_bytes)[0]
                        data = fh.read(length)
                        if self.compress:
                            data = zlib.decompress(data)
                        yield pickle.loads(data)
            yield key, value_iterator()
    
    def seal(self) -> None:
        self._sealed = True
        for partition_files in self._files.values():
            for f in partition_files.values():
                try:
                    f.close()
                except:
                    pass
    
    async def cleanup(self) -> None:
        for partition_files in self._files.values():
            for f in partition_files.values():
                try:
                    if os.path.exists(f.name):
                        os.unlink(f.name)
                except:
                    pass
        self._files.clear()
        if not self._user_spill_dir and self.spill_dir and os.path.exists(self.spill_dir):
            try:
                import shutil
                shutil.rmtree(self.spill_dir, ignore_errors=True)
            except:
                pass


class HybridShuffleStorage(ShuffleStorage):
    """混合存储：内存 + 磁盘溢写
    
    磁盘存储采用 per-partition 单文件设计（而非 per-key 多文件）：
    - 每个分区只有一个 .shuffle 文件
    - 文件格式：[key_len:4][key_bytes][val_len:4][val_bytes]... 重复追加
    - 读取时按 key 分组，流式 yield 给 Reducer
    
    这样无论数据量多大、key 多少，磁盘文件数 = num_partitions（如 20 个）
    """

    def __init__(self, config):
        self.memory_limit = config.memory_limit_mb * 1024 * 1024
        self.spill_dir = config.spill_dir or tempfile.mkdtemp()
        self.compress = config.compress
        self._cleanup_on_complete = config.cleanup_on_complete
        self._user_spill_dir = config.spill_dir is not None
        os.makedirs(self.spill_dir, exist_ok=True)
        
        self._memory_buffers: defaultdict[int, defaultdict[str, list]] = defaultdict(lambda: defaultdict(list))
        self._partition_files: dict[int, str] = {}   # partition_id → 文件路径
        self._current_memory = 0
        self._sealed = False
        self._lock = asyncio.Lock()
        
    def _estimate_value_size(self, value: Any) -> int:
        """估算单个值的内存占用"""
        return len(pickle.dumps(value))
    
    def _get_partition_file(self, partition_id: int) -> str:
        """获取或创建分区的溢写文件路径"""
        if partition_id not in self._partition_files:
            path = os.path.join(self.spill_dir, f"partition_{partition_id}.shuffle")
            self._partition_files[partition_id] = path
        return self._partition_files[partition_id]
        
    async def write(self, partition: int, key: str, value: Any) -> None:
        async with self._lock:
            if self._sealed:
                raise RuntimeError("Storage is sealed")
                
            self._memory_buffers[partition][key].append(value)
            
            self._current_memory += self._estimate_value_size(value)
            
            if self._current_memory > self.memory_limit:
                await self._spill_largest_partition()
                
    async def _spill_largest_partition(self):
        """将最大分区溢写到对应的单文件中"""
        if not self._memory_buffers:
            return
            
        largest_partition = max(
            self._memory_buffers.keys(),
            key=lambda p: sum(len(v) for v in self._memory_buffers[p].values())
        )
        
        file_path = self._get_partition_file(largest_partition)
        
        key_bytes_cache = {}
        
        with open(file_path, 'ab') as fh:
            partition_data = self._memory_buffers[largest_partition]
            for key, values in partition_data.items():
                if key not in key_bytes_cache:
                    kb = key.encode('utf-8')
                    key_bytes_cache[key] = kb
                else:
                    kb = key_bytes_cache[key]
                    
                for value in values:
                    data = pickle.dumps(value)
                    if self.compress:
                        data = zlib.compress(data)
                    fh.write(struct.pack(">I", len(kb)))
                    fh.write(kb)
                    fh.write(struct.pack(">I", len(data)))
                    fh.write(data)
            
        del self._memory_buffers[largest_partition]
        self._current_memory = self._estimate_memory()
        
    def _estimate_memory(self):
        total = 0
        for partition in self._memory_buffers.values():
            for values in partition.values():
                for value in values:
                    total += self._estimate_value_size(value)
        return total
    
    async def read_grouped(self, partition: int) -> AsyncIterator[Tuple[str, AsyncIterator]]:
        if not self._sealed:
            raise RuntimeError("Storage not sealed yet")
            
        disk_values_by_key = {}
        
        if partition in self._partition_files:
            file_path = self._partition_files[partition]
            if os.path.exists(file_path):
                with open(file_path, 'rb') as fh:
                    while True:
                        kl_bytes = fh.read(4)
                        if not kl_bytes or len(kl_bytes) < 4:
                            break
                        key_len = struct.unpack(">I", kl_bytes)[0]
                        key = fh.read(key_len).decode('utf-8')
                        
                        vl_bytes = fh.read(4)
                        if not vl_bytes or len(vl_bytes) < 4:
                            break
                        val_len = struct.unpack(">I", vl_bytes)[0]
                        data = fh.read(val_len)
                        
                        if self.compress:
                            data = zlib.decompress(data)
                        value = pickle.loads(data)
                        
                        if key not in disk_values_by_key:
                            disk_values_by_key[key] = []
                        disk_values_by_key[key].append(value)
        
        all_keys = set()
        
        if partition in self._memory_buffers:
            all_keys.update(self._memory_buffers[partition].keys())
        all_keys.update(disk_values_by_key.keys())
        
        for key in all_keys:
            yield key, self._read_key_values(partition, key, disk_values_by_key)
            
    async def _read_key_values(self, partition: int, key: str, disk_values: dict) -> AsyncIterator:
        """读取指定 key 的所有值（混合内存和磁盘）"""
        if partition in self._memory_buffers and key in self._memory_buffers[partition]:
            for value in self._memory_buffers[partition][key]:
                yield value
                
        if key in disk_values:
            for value in disk_values[key]:
                yield value
                
    def seal(self) -> None:
        """封存存储"""
        self._sealed = True
        
    async def cleanup(self) -> None:
        """清理临时文件"""
        for file_path in self._partition_files.values():
            try:
                if os.path.exists(file_path):
                    os.unlink(file_path)
            except:
                pass
        self._partition_files.clear()
        self._memory_buffers.clear()
        if not self._user_spill_dir and self.spill_dir and os.path.exists(self.spill_dir):
            try:
                import shutil
                shutil.rmtree(self.spill_dir, ignore_errors=True)
            except:
                pass
