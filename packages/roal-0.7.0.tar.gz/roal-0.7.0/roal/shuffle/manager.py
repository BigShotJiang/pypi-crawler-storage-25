"""Shuffle 管理器"""

import asyncio
from typing import AsyncIterator, Tuple, Any
from .storage import ShuffleStorage, HybridShuffleStorage, MemoryShuffleStorage, DiskShuffleStorage
from .partitioner import HashPartitioner, RangePartitioner
from .config import ShuffleStorageConfig


class ShuffleManager:
    """Shuffle 管理器"""
    
    def __init__(self, config: ShuffleStorageConfig, num_partitions: int):
        self.config = config
        self.num_partitions = num_partitions
        self.partitioner = self._create_partitioner()
        self.storage = self._create_storage()
        self._map_complete = asyncio.Event()
        
    def _create_partitioner(self):
        """创建分区器"""
        if self.config.backend == "range":
            return RangePartitioner(self.num_partitions)
        return HashPartitioner(self.num_partitions)
    
    def _create_storage(self):
        """创建存储后端"""
        if self.config.backend == "memory":
            return MemoryShuffleStorage(self.config)
        elif self.config.backend == "disk":
            return DiskShuffleStorage(self.config)
        else:
            return HybridShuffleStorage(self.config)
    
    async def write(self, key: str, value: Any) -> None:
        """Map 端：写入数据到对应分区"""
        partition_id = self.partitioner.partition(key)
        await self.storage.write(partition_id, key, value)
        
    async def read(self, partition_id: int) -> AsyncIterator[Tuple[str, AsyncIterator]]:
        """Reduce 端：读取指定分区的数据，返回按 key 分组的迭代器"""
        await self._map_complete.wait()  # 等待 Map 完成
        async for item in self.storage.read_grouped(partition_id):
            yield item
        
    def mark_map_complete(self) -> None:
        """标记 Map 阶段完成"""
        self._map_complete.set()
        self.storage.seal()  # 封存存储，禁止再写入
    
    async def cleanup(self) -> None:
        """清理存储资源"""
        await self.storage.cleanup()