"""Shuffle 存储配置"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class ShuffleStorageConfig:
    """Shuffle 存储配置"""
    backend: str = "hybrid"           # "memory", "disk", "hybrid", "sqlite"
    memory_limit_mb: int = 512        # 内存阈值，超过后溢写磁盘
    spill_dir: Optional[str] = None   # 溢写目录，默认为系统临时目录
    compress: bool = True             # 是否压缩溢写数据
    cleanup_on_complete: bool = True  # 完成后是否清理临时文件