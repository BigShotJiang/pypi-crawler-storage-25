"""Pipeline 类 - 0.6.0 动态能力增强"""

import asyncio
import time
from typing import Any, List, Optional, Dict, Callable, Union
from roal.state.base import StateStore
from roal.state.memory import MemoryStateStore
from roal.monitoring.metrics import MetricsCollector, default_collector
from roal.core.retry import RetryStrategy, NoRetry, FixedRetry, ExponentialBackoffRetry
from roal.core.dead_letter import DeadLetterQueue
from roal.core.config import ConfigRegistry
from roal.checkpoint.stores import CheckpointStore, MemoryCheckpointStore
from roal.checkpoint.manager import CheckpointManager


class Pipeline:
    """流水线"""

    def __init__(
        self,
        name: str,
        state_store: Optional[StateStore] = None,
        metrics_collector: Optional[MetricsCollector] = None,
        retry_strategy: Optional[RetryStrategy] = None,
        dead_letter_queue: Optional[DeadLetterQueue] = None,
        boundary: Optional['DataBoundary'] = None,
        boundary_config: Optional[Dict] = None,
    ):
        self.name = name
        self.tasks = []
        self.edges = []
        self._default_configs: Dict[str, Dict[str, Any]] = {}
        self._task_name_map: Dict[str, Any] = {}
        self.state_store = state_store or MemoryStateStore()
        self.metrics_collector = metrics_collector or default_collector
        self._executor = None
        self._running = False
        self._stop_event = None
        self._pause_events: Dict[str, asyncio.Event] = {}
        self._paused_tasks: set = set()
        self.config_registry = ConfigRegistry()
        self._config_subscriptions: Dict[str, List[Callable]] = {}
        self.retry_strategy = retry_strategy or NoRetry()
        self.dead_letter_queue = dead_letter_queue
        self.checkpoint_manager: Optional[CheckpointManager] = None
        self.boundary = boundary
        self.boundary_config = boundary_config or {}
        self.shuffle_config = None
        self.reduce_task = None
        self.reduce_workers = 1
        self.on_complete_callback = None

    def source(self, task: 'Task') -> 'Pipeline':
        """添加数据源 Task"""
        self._register_task(task)
        self.tasks.append(task)
        return self

    def then(self, task: 'Task', route_config: Dict = None) -> 'Pipeline':
        """添加下一个 Task"""
        if self.tasks:
            self.edges.append((self.tasks[-1], task))
            if route_config:
                self.tasks[-1].route_config = route_config
        self._register_task(task)
        self.tasks.append(task)
        return self

    def fork(self) -> 'ForkBuilder':
        """开始分流"""
        return ForkBuilder(self, self.tasks[-1])

    def merge(self) -> 'Pipeline':
        """合并分支"""
        return self

    def sink(self, task: 'Task') -> 'Pipeline':
        """添加数据汇 Task"""
        if self.tasks:
            self.edges.append((self.tasks[-1], task))
        self._register_task(task)
        self.tasks.append(task)
        return self
    
    def shuffle(
        self, 
        key_extractor: Union[str, Callable[[Any], str]],
        partitioner: str = "hash",
        num_partitions: int = 10,
        storage_config: Optional[Union[Dict, 'ShuffleStorageConfig']] = None
    ) -> "Pipeline":
        """
        定义 Shuffle 规则
        
        Args:
            key_extractor: Shuffle Key 提取器，可以是字段名或可调用对象
            partitioner: 分区策略，支持 "hash" 或 "range"
            num_partitions: 分区数量（即 Reduce Task 并发数）
            storage_config: Shuffle 存储配置
            
        Returns:
            self，支持链式调用
        """
        from roal.shuffle.config import ShuffleStorageConfig
        if isinstance(storage_config, ShuffleStorageConfig):
            # 如果已经是 ShuffleStorageConfig 对象，直接使用
            storage_config_obj = storage_config
        else:
            # 否则创建新的 ShuffleStorageConfig 对象
            storage_config_obj = ShuffleStorageConfig(**(storage_config or {}))
        self.shuffle_config = {
            "key_extractor": key_extractor,
            "partitioner": partitioner,
            "num_partitions": num_partitions,
            "storage_config": storage_config_obj
        }
        return self
    
    def reduce(
        self,
        reducer_task: Union['Task', Callable],
        workers: int = 1
    ) -> "Pipeline":
        """
        定义 Reduce 阶段
        
        Args:
            reducer_task: Reduce Task，其函数签名应为 (key: str, values: Iterator) -> Any
            workers: Reduce Task 的并发数
            
        Returns:
            self，支持链式调用
        """
        from roal.api.task import TaskWrapper
        if not isinstance(reducer_task, TaskWrapper):
            # 如果是普通函数，包装为 TaskWrapper
            reducer_task = TaskWrapper(reducer_task, task_type="reduce")
        self.reduce_task = reducer_task
        self.reduce_workers = workers
        self._register_task(reducer_task)
        if self.tasks:
            self.edges.append((self.tasks[-1], reducer_task))
        self.tasks.append(reducer_task)
        return self
    
    def on_complete(self, callback: Callable[['PipelineStatus'], None]) -> "Pipeline":
        """
        注册 Pipeline 完成时的回调
        
        Args:
            callback: 回调函数，签名为 (status: PipelineStatus) -> None
            
        Returns:
            self
        """
        self.on_complete_callback = callback
        return self

    def _register_task(self, task: 'Task') -> None:
        """注册Task到名称映射和配置注册表"""
        task_name = getattr(task, 'name', str(id(task)))
        self._task_name_map[task_name] = task
        if task_name not in self._default_configs:
            self._default_configs[task_name] = {}

        if hasattr(task, 'config'):
            for key, value in task.config.items():
                self._default_configs[task_name][key] = value

        self.config_registry.register(task_name, self._default_configs[task_name])

    def run(self) -> None:
        """阻塞运行"""
        import asyncio
        asyncio.run(self.run_async())

    async def run_async(self) -> None:
        """异步运行"""
        from roal.core.executor import Executor
        from roal.core.stage_scheduler import StageScheduler
        from roal.api.boundary import DataBoundary
        
        self._stop_event = asyncio.Event()
        self._running = True
        
        # 检查是否需要使用批流一体执行模型
        if self.boundary and self.boundary != DataBoundary.UNBOUNDED and self.shuffle_config:
            # 使用 StageScheduler 执行批流一体
            scheduler = StageScheduler(self)
            try:
                status = await scheduler.execute()
                if self.on_complete_callback:
                    self.on_complete_callback(status)
            finally:
                self._running = False
        else:
            # 使用传统执行器
            self._executor = Executor(
                state_store=self.state_store,
                metrics_collector=self.metrics_collector,
                retry_strategy=self.retry_strategy,
                dead_letter_queue=self.dead_letter_queue,
                checkpoint_manager=self.checkpoint_manager,
                config_registry=self.config_registry,
                stop_event=self._stop_event,
                pause_events=self._pause_events,
            )
            if self.checkpoint_manager:
                await self.checkpoint_manager.start()
            try:
                await self._executor.run_pipeline(self)
                if self.on_complete_callback:
                    status = self.status()
                    self.on_complete_callback(status)
            finally:
                if self.checkpoint_manager:
                    await self.checkpoint_manager.stop()
                self._running = False

    def start(self) -> None:
        """后台运行"""
        import asyncio
        self._task = asyncio.create_task(self.run_async())

    def stop(self) -> None:
        """停止运行"""
        if self._stop_event:
            self._stop_event.set()
        if hasattr(self, '_task') and self._task:
            self._task.cancel()
            self._running = False

    def status(self) -> 'PipelineStatus':
        """获取运行状态"""
        if self._executor:
            metrics = self._executor.get_metrics()
            return PipelineStatus(metrics=metrics)
        return PipelineStatus()

    def get_metrics(self) -> Dict[str, Any]:
        """获取指标详情"""
        if self._executor:
            return self._executor.get_metrics() or {}
        return self.metrics_collector.get_all_metrics()

    async def scale(self, task_name: str, workers: int) -> None:
        """动态调整 Worker 数量"""
        if self._executor and task_name in self._executor.worker_pools:
            await self._executor.worker_pools[task_name].scale(workers)

    def scale_sync(self, task_name: str, workers: int) -> None:
        """同步触发动态扩缩容（在Pipeline运行时使用）"""
        import asyncio
        if self._executor and task_name in self._executor.worker_pools:
            asyncio.create_task(self._executor.worker_pools[task_name].scale(workers))

    def pause(self, task_name: str) -> None:
        """暂停特定 Task"""
        self._paused_tasks.add(task_name)
        if task_name not in self._pause_events:
            self._pause_events[task_name] = asyncio.Event()
        self._pause_events[task_name].clear()
        if self._executor and task_name in self._executor.worker_pools:
            self._executor.worker_pools[task_name].pause()

    def resume(self, task_name: str) -> None:
        """恢复特定 Task"""
        self._paused_tasks.discard(task_name)
        if task_name in self._pause_events:
            self._pause_events[task_name].set()
        if self._executor and task_name in self._executor.worker_pools:
            self._executor.worker_pools[task_name].resume()

    def is_paused(self, task_name: str) -> bool:
        """检查Task是否暂停"""
        return task_name in self._paused_tasks

    async def pause_async(self, task_name: str) -> None:
        """异步暂停特定 Task"""
        import asyncio
        self._paused_tasks.add(task_name)
        if task_name not in self._pause_events:
            self._pause_events[task_name] = asyncio.Event()
        self._pause_events[task_name].clear()
        if self._executor and task_name in self._executor.worker_pools:
            await self._executor.worker_pools[task_name].pause_async()

    async def resume_async(self, task_name: str) -> None:
        """异步恢复特定 Task"""
        self._paused_tasks.discard(task_name)
        if task_name in self._pause_events:
            self._pause_events[task_name].set()
        if self._executor and task_name in self._executor.worker_pools:
            await self._executor.worker_pools[task_name].resume_async()

    def update_config(self, task_name: str, config: Dict[str, Any]) -> 'Pipeline':
        """更新 Task 配置（运行时生效）"""
        self.config_registry.update(task_name, config)
        if hasattr(self, '_task_name_map') and task_name in self._task_name_map:
            task = self._task_name_map[task_name]
            if hasattr(task, 'config'):
                task.config.update(config)

        self._notify_config_change(task_name, config)
        return self

    def set_config(self, task_name: str, config: Dict[str, Any]) -> 'Pipeline':
        """全量替换 Task 配置"""
        self.config_registry.set(task_name, config)
        if hasattr(self, '_task_name_map') and task_name in self._task_name_map:
            task = self._task_name_map[task_name]
            if hasattr(task, 'config'):
                task.config = dict(config)

        return self

    def get_config(self, task_name: str) -> Dict[str, Any]:
        """获取 Task 当前配置"""
        return self.config_registry.get_all(task_name)

    def subscribe_config_change(self, task_name: str, callback: Callable) -> None:
        """订阅配置变更"""
        if task_name not in self._config_subscriptions:
            self._config_subscriptions[task_name] = []
        self._config_subscriptions[task_name].append(callback)
        self.config_registry.subscribe(task_name, callback)

    def unsubscribe_config_change(self, task_name: str, callback: Callable) -> None:
        """取消订阅配置变更"""
        self.config_registry.unsubscribe(task_name, callback)

    def _notify_config_change(self, task_name: str, config: Dict[str, Any]) -> None:
        """内部通知机制 - 可被框架内部模块监听"""
        if task_name in self._config_subscriptions:
            for callback in self._config_subscriptions[task_name]:
                try:
                    callback(task_name, config)
                except Exception:
                    pass

    def enable_checkpoint(self, store: Optional['CheckpointStore'] = None, interval: int = 10) -> 'Pipeline':
        """启用断点续传

        Args:
            store: Checkpoint 存储后端（默认使用 MemoryCheckpointStore）
            interval: 检查点保存间隔（秒）
        """
        if store is None:
            store = MemoryCheckpointStore()
        self.checkpoint_manager = CheckpointManager(store=store, interval=interval)
        return self

    def enable_prometheus(self, port: int = 8000, addr: str = "0.0.0.0") -> 'Pipeline':
        """启用 Prometheus 指标暴露"""
        from roal.monitoring.prometheus import default_exporter
        default_exporter.start_http_server(port, addr)
        return self

    @property
    def is_running(self) -> bool:
        """检查Pipeline是否正在运行"""
        return self._running


class ForkBuilder:
    """分流构建器"""

    def __init__(self, pipeline: Pipeline, source_task: 'Task'):
        self.pipeline = pipeline
        self.source_task = source_task

    def to(self, *tasks: 'Task', route_config: Dict = None) -> 'ForkBuilder':
        """添加分支 Task"""
        for task in tasks:
            self.pipeline.edges.append((self.source_task, task))
            self.pipeline._register_task(task)
            self.pipeline.tasks.append(task)
        if route_config:
            self.source_task.route_config = route_config
        return self


class PipelineStatus:
    """流水线状态"""

    def __init__(self, metrics: Optional[Dict[str, Any]] = None):
        self._metrics = metrics or {}

    @property
    def total_records(self) -> int:
        """总处理记录数"""
        tasks = self._metrics.get('tasks', {})
        return sum(t.get('processed', 0) for t in tasks.values())

    @property
    def records_per_second(self) -> float:
        """每秒处理记录数"""
        return self._metrics.get('throughput', 0.0)

    @property
    def queue_sizes(self) -> Dict[str, int]:
        """队列大小"""
        return self._metrics.get('queue_sizes', {})

    @property
    def uptime_seconds(self) -> float:
        """运行时间（秒）"""
        return self._metrics.get('uptime_seconds', 0.0)

    @property
    def task_metrics(self) -> Dict[str, Any]:
        """各 Task 的指标详情"""
        return self._metrics.get('tasks', {})

    def to_dict(self) -> Dict[str, Any]:
        """转换为字典"""
        return {
            'pipeline_name': self._metrics.get('pipeline_name', ''),
            'total_records': self.total_records,
            'records_per_second': self.records_per_second,
            'uptime_seconds': self.uptime_seconds,
            'tasks': self.task_metrics,
        }
