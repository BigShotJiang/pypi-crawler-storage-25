"""数据边界定义"""

from enum import Enum
from typing import Optional, Dict


class DataBoundary(Enum):
    """数据边界类型"""
    UNBOUNDED = "unbounded"
    FILE_SET = "file_set"
    BATCH_COUNT = "batch_count"
    TIME_WINDOW = "time_window"
    EXPLICIT_MARKER = "explicit"


class BoundaryEvent(Enum):
    """边界事件"""
    END_OF_SET = "end_of_set"
    END_OF_BATCH = "end_of_batch"
    END_OF_WINDOW = "end_of_window"
    EXPLICIT_EOS = "explicit_eos"


class BoundaryDetector:
    """边界检测器基类"""
    
    async def monitor(self, source):
        """监控数据源，返回边界事件"""
        raise NotImplementedError


class FileSetBoundaryDetector(BoundaryDetector):
    """文件集边界检测器：检测所有文件是否处理完毕
    
    当 total_files 已知时，在处理完指定数量的数据后触发边界；
    当 total_files 未指定时，在数据源耗尽（生成器结束）时自动触发边界。
    """
    
    def __init__(self, total_files: Optional[int] = None):
        self.total_files = total_files
        self.processed_files = 0
        
    async def monitor(self, source):
        async for item in source:
            self.processed_files += 1
            yield item
            
            if self.total_files is not None and self.processed_files >= self.total_files:
                yield BoundaryEvent.END_OF_SET
                return
        
        yield BoundaryEvent.END_OF_SET


class BatchCountBoundaryDetector(BoundaryDetector):
    """数量边界检测器：计数达到阈值时触发"""
    
    def __init__(self, threshold: int):
        self.threshold = threshold
        self.counter = 0
        
    async def monitor(self, source):
        async for item in source:
            yield item
            self.counter += 1
            
            if self.counter >= self.threshold:
                yield BoundaryEvent.END_OF_BATCH
                self.counter = 0


class TimeWindowBoundaryDetector(BoundaryDetector):
    """时间窗口边界检测器：窗口结束时触发"""
    
    def __init__(self, window_seconds: int):
        self.window_seconds = window_seconds
        self.window_start = None
        
    async def monitor(self, source):
        import time
        self.window_start = time.time()
        
        async for item in source:
            yield item
            current_time = time.time()
            
            if current_time - self.window_start >= self.window_seconds:
                yield BoundaryEvent.END_OF_WINDOW
                self.window_start = current_time


class ExplicitMarkerBoundaryDetector(BoundaryDetector):
    """显式标记边界检测器：检测显式 EOS 信号"""
    
    async def monitor(self, source):
        async for item in source:
            if item is BoundaryEvent.EXPLICIT_EOS:
                yield BoundaryEvent.EXPLICIT_EOS
            else:
                yield item
