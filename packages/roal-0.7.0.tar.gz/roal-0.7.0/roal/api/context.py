"""TaskContext 类"""

import time
from typing import Any, Dict, Optional, Callable, List
from roal.monitoring.metrics import MetricsCollector, Counter, Histogram, Gauge, Timer, default_collector
from roal.monitoring.logger import RoalLogger, get_task_logger
from roal.state.memory import MemoryStateStore


class DataLineage:
    """数据血缘追踪"""

    def __init__(
        self,
        record_id: str = "",
        pipeline_id: str = "",
        source_task: str = "",
        path: Optional[List[str]] = None,
        start_time: float = 0.0
    ):
        self.record_id = record_id
        self.pipeline_id = pipeline_id
        self._source_task = source_task
        self._path = path or []
        self._start_time = start_time or time.time()

    @property
    def source_task(self) -> str:
        return self._source_task

    @property
    def path(self) -> List[str]:
        return list(self._path)

    @property
    def duration_ms(self) -> float:
        return (time.time() - self._start_time) * 1000

    def add_task(self, task_name: str) -> None:
        self._path.append(task_name)

    def to_dict(self) -> Dict[str, Any]:
        return {
            'record_id': self.record_id,
            'pipeline_id': self.pipeline_id,
            'source_task': self._source_task,
            'path': self._path,
            'duration_ms': self.duration_ms,
        }


class TaskContext:
    """Task 上下文"""

    def __init__(
        self,
        pipeline_id: str,
        task_name: str,
        record_id: str = "",
        config: Optional[Dict[str, Any]] = None,
        config_registry=None,
        state_store=None,
        metrics_collector: Optional[MetricsCollector] = None,
        lineage: Optional[DataLineage] = None
    ):
        self.pipeline_id = pipeline_id
        self.task_name = task_name
        self.record_id = record_id
        self._config = config or {}
        self._config_registry = config_registry
        self._state_store = state_store
        self._metrics_collector = metrics_collector or default_collector
        self._lineage = lineage or DataLineage(
            record_id=record_id,
            pipeline_id=pipeline_id,
            source_task=task_name
        )
        self._logger = get_task_logger(pipeline_id, task_name, record_id)
        self._shuffle_key = None

    @property
    def metrics(self) -> 'MetricsAccessor':
        return MetricsAccessor(self.task_name, self._metrics_collector)

    @property
    def config(self) -> 'ConfigAccessor':
        """返回配置访问器 - 支持动态配置时从 ConfigRegistry 读取"""
        return ConfigAccessor(self.task_name, self._config, self._config_registry)

    def config_get(self, key: str, default: Any = None) -> Any:
        accessor = self.config
        return accessor.get(key, default)

    async def state_get(self, key: str, default: Any = None) -> Any:
        if self._state_store:
            value = await self._state_store.get(key)
            return value if value is not None else default
        return default

    async def state_set(self, key: str, value: Any, ttl: Optional[int] = None) -> None:
        if self._state_store:
            await self._state_store.set(key, value, ttl)

    async def state_delete(self, key: str) -> None:
        if self._state_store:
            await self._state_store.delete(key)

    async def state_increment(self, key: str, value: int = 1) -> int:
        if self._state_store:
            return await self._state_store.increment(key, value)
        return 0

    async def state_compare_and_set(self, key: str, old_value: Any, new_value: Any) -> bool:
        if self._state_store:
            return await self._state_store.compare_and_set(key, old_value, new_value)
        return False

    def state_subscribe(self, key: str, callback: Callable) -> None:
        if self._state_store:
            self._state_store.subscribe(key, callback)

    def state_unsubscribe(self, key: str, callback: Callable) -> None:
        if self._state_store:
            self._state_store.unsubscribe(key, callback)

    def lineage(self) -> DataLineage:
        return self._lineage

    @property
    def logger(self) -> RoalLogger:
        return self._logger
    
    def set_shuffle_key(self, key: str) -> None:
        """设置当前数据的 Shuffle Key"""
        self._shuffle_key = key
    
    def get_shuffle_key(self) -> Optional[str]:
        """获取当前数据的 Shuffle Key"""
        return self._shuffle_key
    
    def mark_eos(self) -> None:
        """显式标记数据流结束（用于 EXPLICIT_MARKER 边界）"""
        from .boundary import BoundaryEvent
        # 这里实际上是在当前数据处理中标记EOS，具体的处理逻辑由框架实现
        pass


class MetricsAccessor:
    """指标访问器 - 提供简洁的 API 供 Task 上报指标"""

    def __init__(self, task_name: str, collector: MetricsCollector):
        self._task_name = task_name
        self._collector = collector

    def counter(self, name: str, help_text: str = "") -> Counter:
        full_name = f"roal_task_{self._task_name}_{name}"
        return self._collector.counter(full_name, help_text)

    def histogram(self, name: str, help_text: str = "") -> Histogram:
        full_name = f"roal_task_{self._task_name}_{name}"
        return self._collector.histogram(full_name, help_text)

    def gauge(self, name: str, help_text: str = "") -> Gauge:
        full_name = f"roal_task_{self._task_name}_{name}"
        return self._collector.gauge(full_name, help_text)

    def timer(self, name: str, help_text: str = "") -> Timer:
        hist = self.histogram(name, help_text)
        return Timer(hist)


class ConfigAccessor:
    """配置访问器 - 支持静态配置 + 动态配置合并读取"""

    def __init__(self, task_name: str, static_config: Dict[str, Any], config_registry=None):
        self._task_name = task_name
        self._static_config = static_config
        self._config_registry = config_registry

    def get(self, key: str, default: Any = None) -> Any:
        """获取配置值 - 优先从动态配置读取"""
        if self._config_registry is not None:
            return self._config_registry.get(self._task_name, key, self._static_config.get(key, default))
        return self._static_config.get(key, default)

    def __getitem__(self, key: str) -> Any:
        value = self.get(key)
        if value is None and key not in self._static_config:
            raise KeyError(key)
        return value

    def __contains__(self, key: str) -> bool:
        if self._config_registry is not None:
            return key in self._config_registry.get_all(self._task_name) or key in self._static_config
        return key in self._static_config

    def keys(self):
        """返回所有配置键"""
        if self._config_registry is not None:
            dynamic = set(self._config_registry.get_all(self._task_name).keys())
            static = set(self._static_config.keys())
            return dynamic | static
        return self._static_config.keys()

    def items(self):
        """返回所有配置项"""
        result = {}
        for key in self.keys():
            result[key] = self.get(key)
        return result.items()

    def to_dict(self) -> Dict[str, Any]:
        """合并为完整字典"""
        return dict(self.items())
