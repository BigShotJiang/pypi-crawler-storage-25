"""Task 协议和装饰器"""

import asyncio
from typing import Any, Callable, Optional, Dict, TypeVar, Protocol, Literal
from functools import wraps

T = TypeVar('T')


class Task(Protocol):

    async def __call__(self, data: Any, ctx: 'TaskContext') -> Any:
        ...

    def on_init(self, ctx: 'TaskContext') -> None:
        ...

    def on_start(self, ctx: 'TaskContext') -> None:
        ...

    def on_stop(self, ctx: 'TaskContext') -> None:
        ...

    def on_destroy(self, ctx: 'TaskContext') -> None:
        ...


class TaskWrapper:
    """Task 包装器"""

    def __init__(
        self,
        func: Callable,
        name: Optional[str] = None,
        workers: int = 1,
        process_mode: Literal["thread", "process"] = "thread",
        task_type: Literal["map", "reduce"] = "map",
    ):
        self.func = func
        self.name = name or func.__name__
        self.workers = workers
        self.process_mode = process_mode
        self.task_type = task_type

    async def __call__(self, data: Any, ctx: 'TaskContext') -> Any:
        result = self.func(data, ctx)
        # 处理异步生成器
        if hasattr(result, '__aiter__'):
            return result
        # 处理普通生成器
        elif hasattr(result, '__iter__') and not isinstance(result, (str, bytes)):
            return result
        # 处理协程
        elif asyncio.iscoroutine(result):
            return await result
        # 处理可等待对象
        elif hasattr(result, '__await__'):
            return await result
        # 处理普通返回值
        else:
            return result

    def on_init(self, ctx: 'TaskContext') -> None:
        if hasattr(self.func, 'on_init'):
            self.func.on_init(ctx)

    def on_start(self, ctx: 'TaskContext') -> None:
        if hasattr(self.func, 'on_start'):
            self.func.on_start(ctx)

    def on_stop(self, ctx: 'TaskContext') -> None:
        if hasattr(self.func, 'on_stop'):
            self.func.on_stop(ctx)

    def on_destroy(self, ctx: 'TaskContext') -> None:
        if hasattr(self.func, 'on_destroy'):
            self.func.on_destroy(ctx)

    def __getstate__(self):
        """序列化时调用"""
        state = self.__dict__.copy()
        # 移除不可序列化的func属性
        if 'func' in state:
            del state['func']
        return state

    def __setstate__(self, state):
        """反序列化时调用"""
        self.__dict__.update(state)
        # 注意：这里需要在子进程中重新获取func，但由于我们在_process_worker_loop中直接调用task对象，
        # 而不是使用func属性，所以暂时不需要重新设置func


def task(
    name: Optional[str] = None,
    workers: int = 1,
    process_mode: Literal["thread", "process"] = "thread",
    task_type: Literal["map", "reduce"] = "map",
) -> Callable:
    """Task 装饰器

    Args:
        name: Task 名称
        workers: Worker 并发数量
        process_mode: 执行模式
            - "thread": 在协程线程中运行（默认，适合 I/O 密集型）
            - "process": 在独立进程中运行（适合 CPU 密集型，避免 GIL 限制）
        task_type: Task 类型
            - "map": Map 阶段 Task（默认）
            - "reduce": Reduce 阶段 Task
    """
    def decorator(func: Callable) -> TaskWrapper:
        return TaskWrapper(func, name, workers, process_mode, task_type)
    return decorator
