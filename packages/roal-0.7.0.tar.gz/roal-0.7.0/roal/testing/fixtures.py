"""测试 fixtures"""

from typing import Dict, Any
from ..api.context import TaskContext


def mock_context(config: Dict[str, Any] = None) -> TaskContext:
    """创建模拟上下文"""
    return TaskContext(
        pipeline_id="test_pipeline",
        task_name="test_task",
        record_id="test_record",
        config=config or {}
    )
