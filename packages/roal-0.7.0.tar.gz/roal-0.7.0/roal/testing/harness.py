"""测试工具 - 0.6.0 增强"""

from typing import List, Any, Optional


class MemorySource:
    """内存数据源 - 产生数据然后发出终止信号"""

    def __init__(self, data: List[Any], stop_on_complete: bool = True):
        self.data = data
        self.stop_on_complete = stop_on_complete

    async def __call__(self, ctx: 'TaskContext') -> Any:
        """产生数据"""
        for item in self.data:
            yield item

    async def on_start(self, ctx: 'TaskContext') -> None:
        """启动后停止Pipeline（如果是单次运行模式）"""
        pass


class MemorySink:
    """内存数据汇"""

    def __init__(self):
        self.received = []

    async def __call__(self, data: Any, ctx: 'TaskContext') -> None:
        """接收数据"""
        self.received.append(data)


class MockSource:
    """可控制的数据源 - 适合测试"""

    def __init__(self):
        self._queue: List[Any] = []
        self._completed = False

    def put(self, data: Any) -> None:
        self._queue.append(data)

    def complete(self) -> None:
        self._completed = True

    async def __call__(self, ctx: 'TaskContext'):
        while True:
            if self._queue:
                yield self._queue.pop(0)
            elif self._completed:
                break
            else:
                import asyncio
                await asyncio.sleep(0.01)


class RecordingSink:
    """可记录的数据汇 - 支持断言和过滤"""

    def __init__(self):
        self.received = []
        self.call_count = 0

    async def __call__(self, data: Any, ctx: 'TaskContext') -> None:
        self.received.append(data)
        self.call_count += 1

    def get(self, index: int) -> Any:
        return self.received[index]

    def filter(self, predicate) -> List[Any]:
        return [d for d in self.received if predicate(d)]

    def contains(self, expected) -> bool:
        return expected in self.received
