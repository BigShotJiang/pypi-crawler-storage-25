"""Prometheus 集成"""

import asyncio
from typing import Dict, Optional, Any
from prometheus_client import Counter as PCounter, Histogram as PHistogram, Gauge as PGauge, CollectorRegistry, generate_latest, CONTENT_TYPE_LATEST, start_http_server
from roal.monitoring.metrics import MetricsCollector


class PrometheusExporter:
    """Prometheus 导出器 - 将内部指标同步到 Prometheus"""

    def __init__(self, registry: Optional[CollectorRegistry] = None):
        self._registry = registry or CollectorRegistry()
        self._counters: Dict[str, PCounter] = {}
        self._histograms: Dict[str, PHistogram] = {}
        self._gauges: Dict[str, PGauge] = {}
        self._started = False
        self._port = 0

    def counter(self, name: str, help_text: str = "") -> PCounter:
        """创建或获取 Prometheus 计数器"""
        if name not in self._counters:
            safe_name = name.replace(".", "_").replace("-", "_")
            self._counters[name] = PCounter(safe_name, documentation=help_text, registry=self._registry)
        return self._counters[name]

    def histogram(self, name: str, help_text: str = "", buckets=None) -> PHistogram:
        """创建或获取 Prometheus 直方图"""
        if name not in self._histograms:
            safe_name = name.replace(".", "_").replace("-", "_")
            kwargs = {"name": safe_name, "documentation": help_text, "registry": self._registry}
            if buckets:
                kwargs["buckets"] = buckets
            self._histograms[name] = PHistogram(**kwargs)
        return self._histograms[name]

    def gauge(self, name: str, help_text: str = "") -> PGauge:
        """创建或获取 Prometheus 仪表"""
        if name not in self._gauges:
            safe_name = name.replace(".", "_").replace("-", "_")
            self._gauges[name] = PGauge(safe_name, documentation=help_text, registry=self._registry)
        return self._gauges[name]

    def sync_metrics(self, collector: MetricsCollector) -> None:
        """将内部指标同步到 Prometheus"""
        for name, counter in collector._counters.items():
            p_counter = self.counter(name, counter.help_text)
            p_counter.inc(counter.value - p_counter._value.get())

        for name, histogram in collector._histograms.items():
            p_histogram = self.histogram(name, histogram.help_text)
            for value in histogram.values:
                p_histogram.observe(value)

        for name, gauge in collector._gauges.items():
            p_gauge = self.gauge(name, gauge.help_text)
            p_gauge.set(gauge.value)

    def start_http_server(self, port: int = 8000, addr: str = "0.0.0.0") -> None:
        """启动 HTTP 服务暴露 /metrics 端点"""
        start_http_server(port, addr=addr, registry=self._registry)
        self._started = True
        self._port = port

    def get_metrics_text(self) -> bytes:
        """获取 Prometheus 格式的指标文本"""
        return generate_latest(self._registry)

    @property
    def metrics_url(self) -> Optional[str]:
        """获取 metrics 端点 URL"""
        if self._started:
            return f"http://localhost:{self._port}/metrics"
        return None


default_exporter = PrometheusExporter()
