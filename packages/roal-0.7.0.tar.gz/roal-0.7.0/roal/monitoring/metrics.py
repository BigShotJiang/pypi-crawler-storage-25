"""指标收集模块"""

import time
from typing import Dict, Any, Optional, List
from threading import Lock


class MetricsCollector:
    """指标收集器 - 管理所有指标实例"""

    def __init__(self):
        self._counters: Dict[str, 'Counter'] = {}
        self._histograms: Dict[str, 'Histogram'] = {}
        self._gauges: Dict[str, 'Gauge'] = {}
        self._lock = Lock()

    def counter(self, name: str, help_text: str = "") -> 'Counter':
        """获取或创建计数器"""
        if name not in self._counters:
            with self._lock:
                if name not in self._counters:
                    self._counters[name] = Counter(name, help_text)
        return self._counters[name]

    def histogram(self, name: str, help_text: str = "") -> 'Histogram':
        """获取或创建直方图"""
        if name not in self._histograms:
            with self._lock:
                if name not in self._histograms:
                    self._histograms[name] = Histogram(name, help_text)
        return self._histograms[name]

    def gauge(self, name: str, help_text: str = "") -> 'Gauge':
        """获取或创建仪表"""
        if name not in self._gauges:
            with self._lock:
                if name not in self._gauges:
                    self._gauges[name] = Gauge(name, help_text)
        return self._gauges[name]

    def get_all_metrics(self) -> Dict[str, Any]:
        """获取所有指标快照"""
        return {
            'counters': {name: metric.value for name, metric in self._counters.items()},
            'histograms': {name: metric.get_summary() for name, metric in self._histograms.items()},
            'gauges': {name: metric.value for name, metric in self._gauges.items()}
        }

    def clear(self) -> None:
        """清空所有指标（用于测试）"""
        self._counters.clear()
        self._histograms.clear()
        self._gauges.clear()


class Counter:
    """计数器 - 单调递增指标"""

    def __init__(self, name: str, help_text: str = ""):
        self.name = name
        self.help_text = help_text
        self._value = 0
        self._lock = Lock()

    @property
    def value(self) -> float:
        return self._value

    def inc(self, amount: float = 1.0) -> None:
        """增加计数"""
        if amount < 0:
            raise ValueError("Counter increment must be non-negative")
        with self._lock:
            self._value += amount

    def reset(self) -> None:
        """重置计数器"""
        with self._lock:
            self._value = 0


class Histogram:
    """直方图 - 分布统计指标"""

    DEFAULT_BUCKETS = (0.005, 0.01, 0.025, 0.05, 0.075, 0.1, 0.25, 0.5, 0.75, 1.0, 2.5, 5.0, 7.5, 10.0, float('inf'))

    def __init__(self, name: str, help_text: str = "", buckets: Optional[List[float]] = None):
        self.name = name
        self.help_text = help_text
        self.buckets = sorted(buckets or list(self.DEFAULT_BUCKETS))
        self._values: List[float] = []
        self._bucket_counts: Dict[float, int] = {b: 0 for b in self.buckets}
        self._lock = Lock()

    def observe(self, value: float) -> None:
        """观察值"""
        with self._lock:
            self._values.append(value)
            for bucket in self.buckets:
                if value <= bucket:
                    self._bucket_counts[bucket] += 1

    @property
    def values(self) -> List[float]:
        return list(self._values)

    def get_summary(self) -> Dict[str, Any]:
        """获取统计摘要"""
        if not self._values:
            return {
                'count': 0,
                'sum': 0.0,
                'min': 0.0,
                'max': 0.0,
                'avg': 0.0,
                'p50': 0.0,
                'p90': 0.0,
                'p95': 0.0,
                'p99': 0.0,
            }

        sorted_values = sorted(self._values)
        count = len(sorted_values)

        return {
            'count': count,
            'sum': sum(sorted_values),
            'min': sorted_values[0],
            'max': sorted_values[-1],
            'avg': sum(sorted_values) / count,
            'p50': self._percentile(sorted_values, 50),
            'p90': self._percentile(sorted_values, 90),
            'p95': self._percentile(sorted_values, 95),
            'p99': self._percentile(sorted_values, 99),
            'buckets': dict(self._bucket_counts)
        }

    def _percentile(self, sorted_data: List[float], percentile: float) -> float:
        """计算百分位数"""
        if not sorted_data:
            return 0.0
        index = (percentile / 100.0) * (len(sorted_data) - 1)
        lower = int(index)
        upper = lower + 1
        if upper >= len(sorted_data):
            return sorted_data[-1]
        weight = index - lower
        return sorted_data[lower] * (1 - weight) + sorted_data[upper] * weight

    def reset(self) -> None:
        """重置直方图"""
        with self._lock:
            self._values.clear()
            for bucket in self._bucket_counts:
                self._bucket_counts[bucket] = 0


class Gauge:
    """仪表 - 可增减指标"""

    def __init__(self, name: str, help_text: str = ""):
        self.name = name
        self.help_text = help_text
        self._value = 0.0
        self._lock = Lock()

    @property
    def value(self) -> float:
        return self._value

    def set(self, value: float) -> None:
        """设置值"""
        with self._lock:
            self._value = value

    def inc(self, amount: float = 1.0) -> None:
        """增加"""
        with self._lock:
            self._value += amount

    def dec(self, amount: float = 1.0) -> None:
        """减少"""
        with self._lock:
            self._value -= amount

    def set_to_current_time(self) -> None:
        """设置为当前时间戳"""
        self.set(time.time())


class Timer:
    """计时器 - 用于测量代码块执行时间"""

    def __init__(self, histogram: Histogram):
        self._histogram = histogram
        self._start_time = 0.0

    def __enter__(self):
        self._start_time = time.perf_counter()
        return self

    def __exit__(self, *args):
        elapsed = time.perf_counter() - self._start_time
        self._histogram.observe(elapsed)

    async def __aenter__(self):
        self._start_time = time.perf_counter()
        return self

    async def __aexit__(self, *args):
        elapsed = time.perf_counter() - self._start_time
        self._histogram.observe(elapsed)


default_collector = MetricsCollector()
