"""结构化日志模块"""

import logging
import structlog
from typing import Optional, Dict, Any


def setup_logging(
    log_level: str = "INFO",
    json_format: bool = False,
    output_file: Optional[str] = None
) -> None:
    """配置结构化日志

    Args:
        log_level: 日志级别 (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        json_format: 是否使用 JSON 格式输出
        output_file: 输出到文件（可选）
    """
    level = getattr(logging, log_level.upper(), logging.INFO)

    processors = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.StackInfoRenderer(),
        structlog.dev.set_exc_info,
        structlog.processors.TimeStamper(fmt="iso"),
    ]

    if json_format:
        processors.append(structlog.processors.JSONRenderer())
    else:
        processors.append(structlog.dev.ConsoleRenderer())

    structlog.configure(
        processors=processors,
        wrapper_class=structlog.make_filtering_bound_logger(level),
        context_class=dict,
        logger_factory=structlog.PrintLoggerFactory(),
        cache_logger_on_first_use=False,
    )

    logging.basicConfig(
        format="%(message)s",
        stream=open(output_file, "a") if output_file else None,
        level=level,
    )


def get_logger(**kwargs: Any) -> structlog.BoundLogger:
    """获取绑定上下文的 logger

    Args:
        **kwargs: 要绑定的上下文键值对
    """
    return structlog.get_logger(**kwargs)


class RoalLogger:
    """Roal 框架专用 Logger - 自动注入 Pipeline 和 Task 上下文"""

    def __init__(
        self,
        pipeline_id: Optional[str] = None,
        task_name: Optional[str] = None,
        record_id: Optional[str] = None,
        is_roal_logger: bool = False
    ):
        self._pipeline_id = pipeline_id
        self._task_name = task_name
        self._record_id = record_id
        self._is_roal_logger = is_roal_logger
        self._logger = self._build_logger()

    def _build_logger(self) -> structlog.BoundLogger:
        kwargs = {}
        if self._pipeline_id:
            kwargs['pipeline_id'] = self._pipeline_id
        if self._task_name:
            kwargs['task_name'] = self._task_name
        if self._record_id:
            kwargs['record_id'] = self._record_id
        kwargs['logger_level'] = 'global' if self._is_roal_logger else 'local'
        return structlog.get_logger(**kwargs)

    def bind(self, **kwargs: Any) -> 'RoalLogger':
        """绑定额外的上下文"""
        new_logger = RoalLogger(
            pipeline_id=self._pipeline_id,
            task_name=self._task_name,
            record_id=self._record_id
        )
        for key, value in kwargs.items():
            setattr(new_logger, f'_{key}', value)
        new_logger._logger = new_logger._build_logger()
        return new_logger

    def debug(self, message: str, **kwargs: Any) -> None:
        self._logger.debug(message, **kwargs)

    def info(self, message: str, **kwargs: Any) -> None:
        self._logger.info(message, **kwargs)

    def warning(self, message: str, **kwargs: Any) -> None:
        self._logger.warning(message, **kwargs)

    def error(self, message: str, **kwargs: Any) -> None:
        self._logger.error(message, **kwargs)

    def exception(self, message: str, **kwargs: Any) -> None:
        self._logger.error(message, **kwargs)


def get_task_logger(
    pipeline_id: str,
    task_name: str,
    record_id: Optional[str] = None
) -> RoalLogger:
    """获取 Task 专用的 Logger

    Args:
        pipeline_id: Pipeline ID
        task_name: Task 名称
        record_id: 记录 ID（可选）
    """
    return RoalLogger(
        pipeline_id=pipeline_id,
        task_name=task_name,
        record_id=record_id
    )


def get_roal_logger() -> RoalLogger:
    """
    获取 Roal 全局专用的 Logger
    """
    return RoalLogger(is_roal_logger=True)


ROAL_LOGGER = get_roal_logger()
