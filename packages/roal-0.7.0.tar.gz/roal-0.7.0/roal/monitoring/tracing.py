"""追踪"""

from typing import Dict, Any, Optional


class Tracer:
    """追踪器"""
    
    def start_span(self, name: str) -> 'Span':
        """开始一个 span"""
        return Span(name)


class Span:
    """Span"""
    
    def __init__(self, name: str):
        self.name = name
        self.start_time = 0
        self.end_time = 0
    
    def finish(self) -> None:
        """结束 span"""
        pass
    
    def set_tag(self, key: str, value: Any) -> None:
        """设置标签"""
        pass
