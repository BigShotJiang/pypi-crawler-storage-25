"""框架级指标收集"""

import time
import asyncio
from typing import Dict, Any, Optional
from roal.monitoring.metrics import MetricsCollector, Counter, Histogram, Gauge, Timer


class PipelineMetrics:
    """Pipeline 级别指标收集器"""

    def __init__(self, pipeline_name: str, collector: Optional[MetricsCollector] = None):
        self.pipeline_name = pipeline_name
        self._collector = collector or MetricsCollector()
        self._start_time = time.time()
        self._task_metrics: Dict[str, Dict[str, Any]] = {}

    def _get_task_metrics(self, task_name: str) -> Dict[str, Any]:
        """获取或创建 Task 指标"""
        if task_name not in self._task_metrics:
            prefix = f"roal_{self.pipeline_name}_{task_name}"
            self._task_metrics[task_name] = {
                'processed': self._collector.counter(
                    f"{prefix}_processed_total",
                    f"Total records processed by {task_name}"
                ),
                'errors': self._collector.counter(
                    f"{prefix}_errors_total",
                    f"Total errors in {task_name}"
                ),
                'duration': self._collector.histogram(
                    f"{prefix}_duration_seconds",
                    f"Processing duration for {task_name}"
                ),
                'active_workers': self._collector.gauge(
                    f"{prefix}_active_workers",
                    f"Active workers for {task_name}"
                ),
            }
        return self._task_metrics[task_name]

    def record_processed(self, task_name: str, duration: float) -> None:
        """记录成功处理"""
        metrics = self._get_task_metrics(task_name)
        metrics['processed'].inc()
        metrics['duration'].observe(duration)

    def record_error(self, task_name: str) -> None:
        """记录错误"""
        metrics = self._get_task_metrics(task_name)
        metrics['errors'].inc()

    def update_active_workers(self, task_name: str, count: int) -> None:
        """更新活跃 Worker 数量"""
        metrics = self._get_task_metrics(task_name)
        metrics['active_workers'].set(count)

    def update_queue_depth(self, task_name: str, depth: int) -> None:
        """更新队列深度"""
        gauge = self._collector.gauge(
            f"roal_{self.pipeline_name}_{task_name}_queue_depth",
            f"Queue depth for {task_name}"
        )
        gauge.set(depth)

    def get_throughput(self) -> float:
        """获取整体吞吐量（记录/秒）"""
        elapsed = time.time() - self._start_time
        if elapsed <= 0:
            return 0.0
        total_processed = sum(
            m['processed'].value for m in self._task_metrics.values()
        )
        return total_processed / elapsed

    def get_summary(self) -> Dict[str, Any]:
        """获取指标摘要"""
        return {
            'pipeline_name': self.pipeline_name,
            'uptime_seconds': time.time() - self._start_time,
            'throughput': self.get_throughput(),
            'tasks': {
                name: {
                    'processed': m['processed'].value,
                    'errors': m['errors'].value,
                    'active_workers': m['active_workers'].value,
                    'duration_summary': m['duration'].get_summary(),
                }
                for name, m in self._task_metrics.items()
            }
        }
