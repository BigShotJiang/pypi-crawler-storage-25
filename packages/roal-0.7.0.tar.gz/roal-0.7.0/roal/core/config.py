"""配置管理 - 支持运行时动态更新"""

import asyncio
import time
from typing import Any, Dict, Optional, Callable, List


class ConfigRegistry:
    """集中式配置注册表，支持运行时动态更新"""

    def __init__(self):
        self._configs: Dict[str, Dict[str, Any]] = {}
        self._listeners: Dict[str, List[Callable]] = {}
        self._last_updated: Dict[str, float] = {}

    def register(self, task_name: str, config: Dict[str, Any]) -> None:
        """注册Task配置"""
        self._configs[task_name] = dict(config)
        self._last_updated[task_name] = time.time()

    def get(self, task_name: str, key: str, default: Any = None) -> Any:
        """获取配置值"""
        if task_name not in self._configs:
            return default
        return self._configs[task_name].get(key, default)

    def get_all(self, task_name: str) -> Dict[str, Any]:
        """获取Task所有配置"""
        if task_name not in self._configs:
            return {}
        return dict(self._configs[task_name])

    def update(self, task_name: str, config: Dict[str, Any]) -> bool:
        """更新Task配置（合并模式）"""
        if task_name not in self._configs:
            self._configs[task_name] = {}

        old_config = dict(self._configs[task_name])
        self._configs[task_name].update(config)
        self._last_updated[task_name] = time.time()

        new_config = dict(self._configs[task_name])

        self._notify(task_name, old_config, new_config)
        return True

    def set(self, task_name: str, config: Dict[str, Any]) -> None:
        """全量设置Task配置（替换模式）"""
        old_config = self.get_all(task_name)
        self._configs[task_name] = dict(config)
        self._last_updated[task_name] = time.time()
        self._notify(task_name, old_config, dict(config))

    def subscribe(self, task_name: str, callback: Callable) -> None:
        """订阅配置变更事件

        回调签名: callback(old_config: dict, new_config: dict, changed_keys: list)
        """
        if task_name not in self._listeners:
            self._listeners[task_name] = []
        self._listeners[task_name].append(callback)

    def unsubscribe(self, task_name: str, callback: Callable) -> None:
        """取消订阅"""
        if task_name in self._listeners:
            self._listeners[task_name].remove(callback)

    def _notify(self, task_name: str, old_config: Dict[str, Any], new_config: Dict[str, Any]) -> None:
        """通知订阅者配置变更"""
        if task_name not in self._listeners:
            return

        changed_keys = set()
        all_keys = set(old_config.keys()) | set(new_config.keys())
        for key in all_keys:
            if old_config.get(key) != new_config.get(key):
                changed_keys.add(key)

        changed_keys = list(changed_keys)

        for callback in self._listeners[task_name]:
            try:
                if asyncio.iscoroutinefunction(callback):
                    asyncio.create_task(callback(old_config, new_config, changed_keys))
                else:
                    callback(old_config, new_config, changed_keys)
            except Exception:
                pass

    def get_last_updated(self, task_name: str) -> Optional[float]:
        """获取最后一次配置更新时间"""
        return self._last_updated.get(task_name)
