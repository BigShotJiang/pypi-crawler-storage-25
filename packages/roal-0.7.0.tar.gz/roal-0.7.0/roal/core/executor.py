"""执行引擎 - 0.7.0 多进程支持"""

import asyncio
import time
from typing import List, Dict, Optional, Any
from roal.core.dag import DAG
from roal.core.router import DirectRouter, BroadcastRouter, RoundRobinRouter, HashRouter, ConditionalRouter
from roal.core.retry import RetryStrategy, NoRetry, FixedRetry, ExponentialBackoffRetry
from roal.core.dead_letter import DeadLetterQueue
from roal.core.config import ConfigRegistry
from roal.runtime.queue import AsyncQueue
from roal.runtime.worker import WorkerPool
from roal.runtime.process_worker import ProcessWorkerPool
from roal.api.context import TaskContext, DataLineage
from roal.state.base import StateStore
from roal.state.memory import MemoryStateStore
from roal.monitoring.metrics import MetricsCollector, default_collector
from roal.monitoring.pipeline_metrics import PipelineMetrics
from roal.monitoring.logger import get_task_logger


class DataRecord:
    """数据记录"""

    def __init__(
        self,
        payload: Any,
        record_id: str,
        pipeline_id: str,
        source_task: str,
        lineage: Optional[DataLineage] = None
    ):
        self.payload = payload
        self.record_id = record_id
        self.pipeline_id = pipeline_id
        self.source_task = source_task
        self.timestamp = time.time()
        self.sequence = 0
        self.headers = {}
        self._lineage = lineage or DataLineage(
            record_id=record_id,
            pipeline_id=pipeline_id,
            source_task=source_task
        )

    @property
    def lineage(self) -> DataLineage:
        return self._lineage


class Executor:
    """执行器"""

    def __init__(
        self,
        state_store: Optional[StateStore] = None,
        metrics_collector: Optional[MetricsCollector] = None,
        retry_strategy: Optional[RetryStrategy] = None,
        dead_letter_queue: Optional[DeadLetterQueue] = None,
        checkpoint_manager=None,
        config_registry: Optional[ConfigRegistry] = None,
        stop_event: Optional[asyncio.Event] = None,
        pause_events: Optional[Dict[str, asyncio.Event]] = None,
    ):
        self.loop = asyncio.get_event_loop()
        self.queues: Dict[Any, AsyncQueue] = {}
        self.worker_pools: Dict[Any, WorkerPool] = {}
        self.process_pools: Dict[Any, ProcessWorkerPool] = {}
        self.task_routes: Dict[Any, List[Any]] = {}
        self.route_configs: Dict[Any, Dict] = {}
        self.state_store = state_store or MemoryStateStore()
        self.metrics_collector = metrics_collector or default_collector
        self._pipeline_metrics: Optional[PipelineMetrics] = None
        self.retry_strategy = retry_strategy or NoRetry()
        self.dead_letter_queue = dead_letter_queue
        self.checkpoint_manager = checkpoint_manager
        self.config_registry = config_registry or ConfigRegistry()
        self.stop_event = stop_event or asyncio.Event()
        self.pause_events = pause_events or {}
        self._bridge_tasks: Dict[Any, asyncio.Task] = {}

    async def execute(self, task: Any, data: Any, ctx: TaskContext) -> Any:
        """执行任务"""
        return await task(data, ctx)

    async def _process_bridge(self, task: Any, process_pool: ProcessWorkerPool, pipeline: Any) -> None:
        """桥接进程池输出到下游队列"""
        while not self.stop_event.is_set():
            result = await asyncio.get_event_loop().run_in_executor(None, process_pool.get, 0.1)
            if result is None:
                continue

            payload, metadata, is_error = result
            if is_error:
                if self.dead_letter_queue:
                    from roal.core.dead_letter import DeadLetterRecord
                    dl_record = DeadLetterRecord(
                        payload=payload,
                        task_name=getattr(task, 'name', str(id(task))),
                        pipeline_id=pipeline.name,
                        error=metadata.get('error', 'Unknown'),
                        retries=0,
                        original_record_id=metadata.get('record_id', ''),
                    )
                    await self.dead_letter_queue.put(dl_record)
                continue

            lineage = metadata.get('lineage')
            await self.route_data(task, payload, pipeline.name, lineage)

    async def run_pipeline(self, pipeline: Any) -> None:
        """运行流水线 - 事件驱动终止，支持多进程"""
        self._pipeline_metrics = PipelineMetrics(pipeline.name, self.metrics_collector)
        logger = get_task_logger(pipeline.name, "executor")
        logger.info("Pipeline execution starting")

        try:
            dag = DAG()
            for task in pipeline.tasks:
                dag.add_node(task)
            for from_task, to_task in pipeline.edges:
                dag.add_edge(from_task, to_task)

            sorted_tasks = dag.topological_sort()

            for task in sorted_tasks:
                self.queues[task] = AsyncQueue(maxsize=1000)

            for from_task, to_task in pipeline.edges:
                if from_task not in self.task_routes:
                    self.task_routes[from_task] = []
                self.task_routes[from_task].append(to_task)

                if from_task not in self.route_configs:
                    route_config = getattr(from_task, 'route_config', {})
                    self.route_configs[from_task] = route_config

            start_coroutines = []
            for task in sorted_tasks:
                worker_count = getattr(task, 'workers', 1)
                task_name = getattr(task, 'name', str(id(task)))
                process_mode = getattr(task, 'process_mode', 'thread')

                config = self.config_registry.get_all(task_name)

                if process_mode == 'process':
                    pool = ProcessWorkerPool(
                        task=task,
                        pipeline_id=pipeline.name,
                        task_name=task_name,
                        worker_count=worker_count,
                        config=config,
                    )
                    self.process_pools[task] = pool
                    start_coroutines.append(asyncio.get_event_loop().run_in_executor(None, pool.start))

                    bridge = asyncio.create_task(self._process_bridge(task, pool, pipeline))
                    self._bridge_tasks[task] = bridge
                else:
                    worker_pool = WorkerPool(
                        task=task,
                        queue=self.queues[task],
                        pipeline_id=pipeline.name,
                        task_name=task_name,
                        worker_count=worker_count,
                        executor=self,
                        state_store=self.state_store,
                        metrics_collector=self.metrics_collector,
                        pipeline_metrics=self._pipeline_metrics,
                        retry_strategy=self.retry_strategy,
                        dead_letter_queue=self.dead_letter_queue,
                        checkpoint_manager=self.checkpoint_manager,
                        config_registry=self.config_registry,
                        pause_event=self.pause_events.get(task_name),
                    )
                    self.worker_pools[task] = worker_pool
                    start_coroutines.append(worker_pool.start())

                self._pipeline_metrics.update_active_workers(task_name, worker_count)

            for coro in start_coroutines:
                await coro

            logger.info("All workers started")

            await self._feed_data_to_pools(pipeline, sorted_tasks)

            await self.stop_event.wait()
        finally:
            stop_tasks = []
            for pool in self.worker_pools.values():
                stop_tasks.append(pool.stop())
            for pool in self.process_pools.values():
                stop_tasks.append(pool.stop())

            for bridge in self._bridge_tasks.values():
                bridge.cancel()

            await asyncio.gather(*stop_tasks, return_exceptions=True)
            logger.info("Pipeline execution completed")

    async def _feed_data_to_pools(self, pipeline: Any, sorted_tasks: list) -> None:
        """将数据从上游路由到进程池"""
        source_tasks = []
        for task in sorted_tasks:
            if not any(to == task for _, to in pipeline.edges):
                source_tasks.append(task)

        for source_task in source_tasks:
            asyncio.create_task(self._run_source(source_task, pipeline))

    async def _run_source(self, source_task: Any, pipeline: Any) -> None:
        """运行源Task并将其输出路由到下游"""
        task_name = getattr(source_task, 'name', str(id(source_task)))
        ctx = TaskContext(
            pipeline.name,
            task_name,
            state_store=self.state_store,
            config_registry=self.config_registry,
        )

        try:
            if hasattr(source_task, 'func'):
                func = source_task.func
                import inspect
                sig = inspect.signature(func)
                params = list(sig.parameters.keys())
                
                if len(params) == 1:
                    result = func(ctx)
                else:
                    result = func(None, ctx)
            else:
                result = source_task(ctx)
            
            if hasattr(result, '__aiter__'):
                async for item in result:
                    if item is not None:
                        await self.route_data(source_task, item, pipeline.name)
            elif hasattr(result, '__iter__') and not isinstance(result, (str, bytes)):
                for item in result:
                    if item is not None:
                        await self.route_data(source_task, item, pipeline.name)
        except Exception as e:
            get_task_logger(pipeline.name, task_name).error(f"Source task error: {e}")

    async def route_data(self, from_task: Any, data: Any, pipeline_id: str, lineage: Optional[DataLineage] = None) -> None:
        """路由数据到下游任务"""
        if from_task not in self.task_routes:
            return

        downstream_tasks = self.task_routes[from_task]
        if not downstream_tasks:
            return

        task_name = getattr(from_task, 'name', str(id(from_task)))
        record_id = f"{task_name}-{time.time()}-{id(data)}"

        record = DataRecord(
            payload=data,
            record_id=record_id,
            pipeline_id=pipeline_id,
            source_task=task_name,
            lineage=lineage
        )

        if lineage:
            lineage.add_task(task_name)

        route_config = self.route_configs.get(from_task, {})
        route_type = route_config.get('type', 'broadcast')

        if route_type == 'direct':
            router = DirectRouter()
        elif route_type == 'round_robin':
            router = RoundRobinRouter()
        elif route_type == 'hash':
            key_fn = route_config.get('key_fn', lambda x: id(x))
            router = HashRouter(key_fn)
        elif route_type == 'conditional':
            conditions = route_config.get('conditions', [])
            router = ConditionalRouter(conditions)
        else:
            router = BroadcastRouter()

        target_tasks = router.route(record, downstream_tasks)

        for target_task in target_tasks:
            if target_task in self.process_pools:
                process_pool = self.process_pools[target_task]
                metadata = {'record_id': record_id, 'lineage': lineage}
                process_pool.put(data, metadata)
            elif target_task in self.queues:
                await self.queues[target_task].put(record)
                if self._pipeline_metrics:
                    target_name = getattr(target_task, 'name', str(id(target_task)))
                    self._pipeline_metrics.update_queue_depth(target_name, self.queues[target_task].qsize())

    def get_metrics(self) -> Optional[Dict[str, Any]]:
        """获取指标摘要"""
        if self._pipeline_metrics:
            return self._pipeline_metrics.get_summary()
        return None
