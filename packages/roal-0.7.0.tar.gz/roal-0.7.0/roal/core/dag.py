"""DAG 构建和拓扑排序"""

from typing import List, Dict, Set, Optional, Any


class DAG:
    """有向无环图"""
    
    def __init__(self):
        self.nodes = []
        self.edges = []
    
    def add_node(self, node: Any) -> None:
        """添加节点"""
        if node not in self.nodes:
            self.nodes.append(node)
    
    def add_edge(self, from_node: Any, to_node: Any) -> None:
        """添加边"""
        self.add_node(from_node)
        self.add_node(to_node)
        if (from_node, to_node) not in self.edges:
            self.edges.append((from_node, to_node))
    
    def topological_sort(self) -> List[Any]:
        """拓扑排序"""
        # 构建入度表
        in_degree = {node: 0 for node in self.nodes}
        for _, to_node in self.edges:
            in_degree[to_node] += 1
        
        # 初始化队列
        queue = [node for node, degree in in_degree.items() if degree == 0]
        result = []
        
        # 拓扑排序
        while queue:
            node = queue.pop(0)
            result.append(node)
            
            for from_node, to_node in self.edges:
                if from_node == node:
                    in_degree[to_node] -= 1
                    if in_degree[to_node] == 0:
                        queue.append(to_node)
        
        # 检查是否有环
        if len(result) != len(self.nodes):
            raise ValueError("DAG contains cycles")
        
        return result
    
    def get_predecessors(self, node: Any) -> List[Any]:
        """获取节点的前驱节点"""
        return [from_node for from_node, to_node in self.edges if to_node == node]
    
    def get_successors(self, node: Any) -> List[Any]:
        """获取节点的后继节点"""
        return [to_node for from_node, to_node in self.edges if from_node == node]
    
    def has_cycle(self) -> bool:
        """检查是否有环"""
        try:
            self.topological_sort()
            return False
        except ValueError:
            return True
