"""重试策略模块"""

import asyncio
import time
from typing import Optional, Callable, Any
from abc import ABC, abstractmethod


class RetryStrategy(ABC):
    """重试策略抽象基类"""

    @abstractmethod
    async def should_retry(self, attempt: int, error: Exception) -> bool:
        """判断是否应该重试"""
        pass

    @abstractmethod
    async def get_delay(self, attempt: int) -> float:
        """获取重试延迟时间（秒）"""
        pass


class NoRetry(RetryStrategy):
    """不重试策略"""

    async def should_retry(self, attempt: int, error: Exception) -> bool:
        return False

    async def get_delay(self, attempt: int) -> float:
        return 0.0


class FixedRetry(RetryStrategy):
    """固定次数重试策略"""

    def __init__(self, max_retries: int = 3, delay: float = 1.0):
        self.max_retries = max_retries
        self.delay = delay

    async def should_retry(self, attempt: int, error: Exception) -> bool:
        return attempt < self.max_retries

    async def get_delay(self, attempt: int) -> float:
        return self.delay


class ExponentialBackoffRetry(RetryStrategy):
    """指数退避重试策略"""

    def __init__(
        self,
        max_retries: int = 3,
        base_delay: float = 1.0,
        max_delay: float = 60.0,
        multiplier: float = 2.0
    ):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.multiplier = multiplier

    async def should_retry(self, attempt: int, error: Exception) -> bool:
        return attempt < self.max_retries

    async def get_delay(self, attempt: int) -> float:
        delay = self.base_delay * (self.multiplier ** attempt)
        return min(delay, self.max_delay)


class ConditionalRetry(RetryStrategy):
    """条件重试策略：根据异常类型决定是否重试"""

    def __init__(
        self,
        max_retries: int = 3,
        retryable_exceptions: Optional[tuple] = None,
        strategy: Optional[RetryStrategy] = None
    ):
        self.max_retries = max_retries
        self.retryable_exceptions = retryable_exceptions or (Exception,)
        self.strategy = strategy or FixedRetry(max_retries=max_retries)
        self._attempt = 0

    async def should_retry(self, attempt: int, error: Exception) -> bool:
        if not isinstance(error, self.retryable_exceptions):
            return False
        self._attempt = attempt
        return await self.strategy.should_retry(attempt, error)

    async def get_delay(self, attempt: int) -> float:
        return await self.strategy.get_delay(attempt)


async def execute_with_retry(
    func: Callable,
    *args: Any,
    strategy: RetryStrategy,
    **kwargs: Any
) -> Any:
    """使用重试策略执行函数"""
    attempt = 0
    last_error = None

    while True:
        try:
            return await func(*args, **kwargs)
        except Exception as e:
            last_error = e
            if not await strategy.should_retry(attempt, e):
                raise
            delay = await strategy.get_delay(attempt)
            if delay > 0:
                await asyncio.sleep(delay)
            attempt += 1
