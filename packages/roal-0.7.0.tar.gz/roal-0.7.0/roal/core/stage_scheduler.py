"""阶段调度器"""

import asyncio
from typing import Dict, Optional
from roal.api.boundary import BoundaryDetector, FileSetBoundaryDetector, BatchCountBoundaryDetector, TimeWindowBoundaryDetector, ExplicitMarkerBoundaryDetector, DataBoundary
from roal.monitoring.logger import ROAL_LOGGER
from roal.shuffle.manager import ShuffleManager
from roal.api.pipeline import Pipeline, PipelineStatus


class StageStatus:
    """阶段状态"""
    COMPLETED = "completed"
    FAILED = "failed"
    SKIPPED = "skipped"


class StageScheduler:
    """阶段调度器"""
    
    def __init__(self, pipeline: Pipeline):
        self.pipeline = pipeline
        self.shuffle_manager: Optional[ShuffleManager] = None
        self.boundary_detector: Optional[BoundaryDetector] = None
        self._stage_status = {}
        
    async def execute(self) -> PipelineStatus:
        """执行 Pipeline"""
        try:
            await self._setup_boundary_detector()
            await self._setup_shuffle_manager()
            
            map_status = await self._run_map_phase()
            self._stage_status["map"] = map_status
            
            if map_status == StageStatus.COMPLETED:
                if self.shuffle_manager:
                    self.shuffle_manager.mark_map_complete()
                    
                reduce_status = await self._run_reduce_phase()
                self._stage_status["reduce"] = reduce_status
                
            return self._build_pipeline_status()
            
        except Exception as e:
            ROAL_LOGGER.error(f"Pipeline execution failed: {e}", exc_info=True)
            self._stage_status.setdefault("map", StageStatus.FAILED)
            return self._build_pipeline_status()
        finally:
            if self.shuffle_manager:
                await self.shuffle_manager.cleanup()
                
    async def _setup_boundary_detector(self):
        """设置边界检测器"""
        boundary = self.pipeline.boundary
        config = self.pipeline.boundary_config
        
        if boundary == DataBoundary.FILE_SET:
            total_files = config.get("total_files")
            self.boundary_detector = FileSetBoundaryDetector(total_files)
        elif boundary == DataBoundary.BATCH_COUNT:
            threshold = config.get("threshold", 1000)
            self.boundary_detector = BatchCountBoundaryDetector(threshold)
        elif boundary == DataBoundary.TIME_WINDOW:
            window_seconds = config.get("window_seconds", 3600)
            self.boundary_detector = TimeWindowBoundaryDetector(window_seconds)
        elif boundary == DataBoundary.EXPLICIT_MARKER:
            self.boundary_detector = ExplicitMarkerBoundaryDetector()
        else:
            # 默认使用无边界检测器
            pass
    
    async def _setup_shuffle_manager(self):
        """设置 Shuffle 管理器"""
        if not self.pipeline.shuffle_config:
            return
        
        shuffle_config = self.pipeline.shuffle_config
        self.shuffle_manager = ShuffleManager(
            shuffle_config["storage_config"],
            shuffle_config["num_partitions"]
        )
    
    async def _run_map_phase(self) -> StageStatus:
        """运行 Map 阶段"""
        try:
            # 构建 Map 阶段的任务链
            map_tasks = self._get_map_tasks()
            task_names = [getattr(task, 'name', str(id(task))) for task in map_tasks]
            ROAL_LOGGER.info(f"Map tasks: {task_names}")
            if not map_tasks:
                return StageStatus.SKIPPED
            
            # 获取源任务
            source_task = map_tasks[0]
            
            # 获取任务名称
            task_name = getattr(source_task, 'name', str(id(source_task)))
            
            # 执行源任务，产生数据流
            source_data = await source_task(None, self._create_task_context(task_name))
            
            # 包装数据源，添加边界检测
            if self.boundary_detector:
                monitored_source = self.boundary_detector.monitor(source_data)
            else:
                monitored_source = source_data
            
            # 处理数据流
            async for item in monitored_source:
                # 检查是否是边界事件
                from roal.api.boundary import BoundaryEvent
                if isinstance(item, BoundaryEvent):
                    # 边界事件到达，结束 Map 阶段
                    break
                
                # 处理数据通过 Map 任务链
                if len(map_tasks) > 1:
                    # 对于第一个任务的输出，传递给后续所有任务
                    # 注意：map_tasks[0] 是源任务，已经执行过了
                    # 所以我们从 map_tasks[1] 开始处理
                    current_task = map_tasks[1]
                    remaining_tasks = map_tasks[2:]
                    await self._process_data_through_tasks(item, [current_task] + remaining_tasks)
            
            return StageStatus.COMPLETED
        except Exception as e:
            ROAL_LOGGER.error(f"Map phase failed: {e}", exc_info=True)
            return StageStatus.FAILED
    
    async def _process_data_through_tasks(self, data, tasks):
        """将数据通过任务链处理"""
        if not tasks:
            return
            
        current_task = tasks[0]
        remaining_tasks = tasks[1:]
        
        # 获取任务名称
        task_name = getattr(current_task, 'name', str(id(current_task)))
        ctx = self._create_task_context(task_name)
        
        # 执行当前任务
        result = await current_task(data, ctx)
        
        # 处理任务结果
        if result is None:
            return
        elif hasattr(result, '__aiter__'):
            # 处理异步生成器
            async for item in result:
                if item is not None:
                    await self._process_data_through_tasks(item, remaining_tasks)
        elif hasattr(result, '__iter__') and not isinstance(result, (str, bytes)):
            # 处理普通生成器
            for item in result:
                if item is not None:
                    await self._process_data_through_tasks(item, remaining_tasks)
        else:
            # 处理单个结果
            await self._handle_task_result(result, ctx, current_task)
            if remaining_tasks:
                await self._process_data_through_tasks(result, remaining_tasks)
    
    async def _process_map_data(self, data, map_tasks):
        """处理 Map 阶段的数据"""
        # 处理初始数据
        if hasattr(data, '__aiter__'):
            async for item in data:
                await self._process_single_item(item, map_tasks)
        elif hasattr(data, '__iter__') and not isinstance(data, (str, bytes)):
            for item in data:
                await self._process_single_item(item, map_tasks)
        else:
            await self._process_single_item(data, map_tasks)
    
    async def _process_single_item(self, item, map_tasks):
        """处理单个数据项"""
        if item is None:
            return
            
        current_data = item
        
        for task in map_tasks:
            # 获取任务名称
            task_name = getattr(task, 'name', str(id(task)))
            ctx = self._create_task_context(task_name)
            result = await task(current_data, ctx)
            
            # 处理生成器结果
            if hasattr(result, '__aiter__'):
                async for sub_item in result:
                    if sub_item is not None:
                        # 递归处理生成的子项
                        await self._process_single_item(sub_item, map_tasks[map_tasks.index(task) + 1:])
            elif hasattr(result, '__iter__') and not isinstance(result, (str, bytes)):
                for sub_item in result:
                    if sub_item is not None:
                        # 递归处理生成的子项
                        await self._process_single_item(sub_item, map_tasks[map_tasks.index(task) + 1:])
            else:
                if result is not None:
                    # 对于单个结果，处理它并更新 current_data
                    await self._handle_task_result(result, ctx, task)
                    # 更新 current_data 并继续处理下一个任务
                    current_data = result
                else:
                    # 如果结果为 None，跳过后续任务
                    return
    
    async def _handle_task_result(self, result, ctx, task):
        """处理单个任务结果"""
        if result is None:
            return
        
        # 获取 Shuffle Key
        shuffle_key = ctx.get_shuffle_key()
        if not shuffle_key and hasattr(result, 'shuffle_key'):
            shuffle_key = result.shuffle_key
        
        # 如果有 Shuffle Key 且设置了 Shuffle 配置，写入 Shuffle 存储
        if shuffle_key and self.shuffle_manager:
            await self.shuffle_manager.write(shuffle_key, result)
    
    async def _run_reduce_phase(self) -> StageStatus:
        """运行 Reduce 阶段"""
        try:
            if not self.pipeline.reduce_task:
                return StageStatus.SKIPPED
            
            if not self.shuffle_manager:
                return StageStatus.FAILED
            
            num_partitions = self.pipeline.shuffle_config["num_partitions"]
            _ = min(self.pipeline.reduce_workers, num_partitions)
            
            tasks = []
            for partition_id in range(num_partitions):
                task = self._run_reduce_partition(partition_id)
                tasks.append(task)
            
            results = await asyncio.gather(*tasks, return_exceptions=True)
            
            for result in results:
                if isinstance(result, Exception):
                    ROAL_LOGGER.error(f"Reduce partition failed: {result}", exc_info=result)
                    
            return StageStatus.COMPLETED
        except Exception as e:
            ROAL_LOGGER.error(f"Reduce phase failed: {e}", exc_info=True)
            return StageStatus.FAILED
    
    async def _run_reduce_partition(self, partition_id):
        """运行单个 Reduce 分区"""
        if not self.shuffle_manager or not self.pipeline.reduce_task:
            return
        
        # 获取任务名称
        task_name = getattr(self.pipeline.reduce_task, 'name', str(id(self.pipeline.reduce_task)))
        
        # 读取分区数据
        async for key, values in self.shuffle_manager.read(partition_id):
            ctx = self._create_task_context(task_name)
            result = await self.pipeline.reduce_task((key, values), ctx)
            
            # 处理 Reduce 结果
            if result is not None:
                # 将结果传递给 sink 任务
                await self._process_reduce_result(result)
    
    def _get_map_tasks(self):
        """获取 Map 阶段的任务"""
        map_tasks = []
        for task in self.pipeline.tasks:
            if getattr(task, 'task_type', 'map') == 'map':
                map_tasks.append(task)
            else:
                # 遇到 Reduce 任务就停止
                break
        return map_tasks
    
    def _get_sink_tasks(self):
        """获取 Sink 阶段的任务"""
        sink_tasks = []
        found_reduce = False
        for task in self.pipeline.tasks:
            if getattr(task, 'task_type', 'map') == 'reduce':
                found_reduce = True
            elif found_reduce:
                #  Reduce 任务之后的任务都是 sink 任务
                sink_tasks.append(task)
        return sink_tasks
    
    async def _process_reduce_result(self, result):
        """处理 Reduce 结果"""
        sink_tasks = self._get_sink_tasks()
        if not sink_tasks:
            return
        
        # 将结果传递给 sink 任务链
        await self._process_data_through_tasks(result, sink_tasks)
    
    def _create_task_context(self, task_name):
        """创建任务上下文"""
        from roal.api.context import TaskContext
        return TaskContext(
            pipeline_id=self.pipeline.name,
            task_name=task_name,
            config_registry=self.pipeline.config_registry,
            state_store=self.pipeline.state_store,
            metrics_collector=self.pipeline.metrics_collector
        )
    
    def _build_pipeline_status(self):
        """构建 Pipeline 状态"""
        metrics = {
            "pipeline_name": self.pipeline.name,
            "stage_status": self._stage_status,
            "uptime_seconds": 0
        }
        return PipelineStatus(metrics=metrics)