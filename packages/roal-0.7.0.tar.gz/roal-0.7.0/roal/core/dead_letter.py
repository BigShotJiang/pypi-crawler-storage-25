"""死信队列模块"""

import asyncio
import time
from typing import Any, Optional, List, Dict


class DeadLetterRecord:
    """死信记录"""

    def __init__(
        self,
        payload: Any,
        task_name: str,
        pipeline_id: str,
        error: Exception,
        retries: int = 0,
        original_record_id: str = "",
        metadata: Optional[Dict[str, Any]] = None
    ):
        self.payload = payload
        self.task_name = task_name
        self.pipeline_id = pipeline_id
        self.error = error
        self.error_message = str(error)
        self.retries = retries
        self.original_record_id = original_record_id
        self.timestamp = time.time()
        self.metadata = metadata or {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            'payload': self.payload,
            'task_name': self.task_name,
            'pipeline_id': self.pipeline_id,
            'error_message': self.error_message,
            'retries': self.retries,
            'original_record_id': self.original_record_id,
            'timestamp': self.timestamp,
            'metadata': self.metadata,
        }


class DeadLetterQueue:
    """死信队列"""

    def __init__(self, maxsize: int = 0):
        self._queue: asyncio.Queue = asyncio.Queue(maxsize=maxsize)
        self._records: List[DeadLetterRecord] = []
        self._maxsize = maxsize

    async def put(self, record: DeadLetterRecord) -> bool:
        """添加死信记录"""
        try:
            await asyncio.wait_for(self._queue.put(record), timeout=1.0)
            self._records.append(record)
            return True
        except (asyncio.TimeoutError, asyncio.QueueFull):
            return False

    async def get(self) -> Optional[DeadLetterRecord]:
        """获取死信记录"""
        try:
            return await asyncio.wait_for(self._queue.get(), timeout=0.1)
        except (asyncio.TimeoutError, asyncio.QueueEmpty):
            return None

    async def get_all(self) -> List[DeadLetterRecord]:
        """获取所有死信记录"""
        records = []
        while not self._queue.empty():
            try:
                record = await asyncio.wait_for(self._queue.get(), timeout=0.1)
                records.append(record)
            except (asyncio.TimeoutError, asyncio.QueueEmpty):
                break
        return records

    def peek(self) -> List[DeadLetterRecord]:
        """查看所有死信记录（不移除）"""
        return list(self._records)

    def size(self) -> int:
        """获取队列大小"""
        return self._queue.qsize()

    def total_count(self) -> int:
        """获取总记录数"""
        return len(self._records)

    def filter_by_task(self, task_name: str) -> List[DeadLetterRecord]:
        """按 Task 名称过滤"""
        return [r for r in self._records if r.task_name == task_name]

    def filter_by_pipeline(self, pipeline_id: str) -> List[DeadLetterRecord]:
        """按 Pipeline ID 过滤"""
        return [r for r in self._records if r.pipeline_id == pipeline_id]

    def clear(self) -> None:
        """清空死信队列"""
        self._records.clear()
        while not self._queue.empty():
            try:
                self._queue.get_nowait()
            except asyncio.QueueEmpty:
                break
