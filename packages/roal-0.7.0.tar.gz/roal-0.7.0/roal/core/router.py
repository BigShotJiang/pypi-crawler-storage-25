"""路由策略实现"""

from typing import List, Any, Callable, Dict


class Router:
    """路由器基类"""
    
    def route(self, data: Any, targets: List[Any]) -> List[Any]:
        """路由数据到目标"""
        pass


class DirectRouter(Router):
    """直通路由"""
    
    def route(self, data: Any, targets: List[Any]) -> List[Any]:
        return targets[:1] if targets else []


class BroadcastRouter(Router):
    """广播路由"""
    
    def route(self, data: Any, targets: List[Any]) -> List[Any]:
        return targets


class RoundRobinRouter(Router):
    """轮询路由"""
    
    def __init__(self):
        self.index = 0
    
    def route(self, data: Any, targets: List[Any]) -> List[Any]:
        if not targets:
            return []
        target = targets[self.index % len(targets)]
        self.index += 1
        return [target]


class HashRouter(Router):
    """哈希路由"""
    
    def __init__(self, key_fn: Callable[[Any], Any]):
        self.key_fn = key_fn
    
    def route(self, data: Any, targets: List[Any]) -> List[Any]:
        if not targets:
            return []
        key = self.key_fn(data)
        index = hash(key) % len(targets)
        return [targets[index]]


class ConditionalRouter(Router):
    """条件路由"""
    
    def __init__(self, conditions: List[Callable[[Any], bool]]):
        self.conditions = conditions
    
    def route(self, data: Any, targets: List[Any]) -> List[Any]:
        result = []
        for i, condition in enumerate(self.conditions):
            if i < len(targets) and condition(data):
                result.append(targets[i])
        return result
