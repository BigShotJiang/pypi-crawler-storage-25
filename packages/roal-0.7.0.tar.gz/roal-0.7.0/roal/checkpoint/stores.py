"""Checkpoint 存储"""

import asyncio
from typing import Any, Optional, List


class CheckpointStore:
    """Checkpoint 存储抽象"""

    async def get(self, key: str) -> Optional[Any]:
        """获取检查点"""
        pass

    async def set(self, key: str, value: Any) -> None:
        """设置检查点"""
        pass

    async def delete(self, key: str) -> None:
        """删除检查点"""
        pass

    async def list_keys(self, prefix: str = "") -> List[str]:
        """列出所有键（带前缀过滤）"""
        return []


class MemoryCheckpointStore(CheckpointStore):
    """内存 Checkpoint 存储"""

    def __init__(self):
        self.store = {}

    async def get(self, key: str) -> Optional[Any]:
        return self.store.get(key)

    async def set(self, key: str, value: Any) -> None:
        self.store[key] = value

    async def delete(self, key: str) -> None:
        self.store.pop(key, None)

    async def list_keys(self, prefix: str = "") -> List[str]:
        if prefix:
            return [k for k in self.store if k.startswith(prefix)]
        return list(self.store.keys())


class RedisCheckpointStore(CheckpointStore):
    """Redis Checkpoint 存储"""

    def __init__(self, redis_url: str):
        import redis.asyncio as redis
        self.redis = redis.from_url(redis_url)

    async def get(self, key: str) -> Optional[Any]:
        import json
        value = await self.redis.get(key)
        return json.loads(value) if value else None

    async def set(self, key: str, value: Any) -> None:
        import json
        await self.redis.set(key, json.dumps(value))

    async def delete(self, key: str) -> None:
        await self.redis.delete(key)

    async def list_keys(self, prefix: str = "") -> List[str]:
        pattern = f"{prefix}*" if prefix else "*"
        keys = await self.redis.keys(pattern)
        return [k.decode() if isinstance(k, bytes) else k for k in keys]

    async def close(self) -> None:
        await self.redis.close()


class FileCheckpointStore(CheckpointStore):
    """文件 Checkpoint 存储"""

    def __init__(self, file_path: str):
        self.file_path = file_path
        self._load()

    def _load(self) -> None:
        """加载存储"""
        import json
        import os
        if os.path.exists(self.file_path) and os.path.getsize(self.file_path) > 0:
            with open(self.file_path, 'r') as f:
                content = f.read().strip()
                if content:
                    self.store = json.loads(content)
                else:
                    self.store = {}
        else:
            self.store = {}

    def _save(self) -> None:
        """保存存储"""
        import json
        with open(self.file_path, 'w') as f:
            json.dump(self.store, f)

    async def get(self, key: str) -> Optional[Any]:
        return self.store.get(key)

    async def set(self, key: str, value: Any) -> None:
        self.store[key] = value
        self._save()

    async def delete(self, key: str) -> None:
        self.store.pop(key, None)
        self._save()

    async def list_keys(self, prefix: str = "") -> List[str]:
        if prefix:
            return [k for k in self.store if k.startswith(prefix)]
        return list(self.store.keys())
