"""Checkpoint 管理器"""

import asyncio
import time
from typing import Optional, Dict, Any, Callable


class CheckpointInfo:
    """检查点信息"""

    def __init__(
        self,
        pipeline_id: str,
        task_name: str,
        offset: int = 0,
        timestamp: float = 0.0,
        record_id: str = "",
        metadata: Optional[Dict[str, Any]] = None
    ):
        self.pipeline_id = pipeline_id
        self.task_name = task_name
        self.offset = offset
        self.timestamp = timestamp or time.time()
        self.record_id = record_id
        self.metadata = metadata or {}

    def to_dict(self) -> Dict[str, Any]:
        return {
            "pipeline_id": self.pipeline_id,
            "task_name": self.task_name,
            "offset": self.offset,
            "timestamp": self.timestamp,
            "record_id": self.record_id,
            "metadata": self.metadata,
        }

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'CheckpointInfo':
        return cls(
            pipeline_id=data.get("pipeline_id", ""),
            task_name=data.get("task_name", ""),
            offset=data.get("offset", 0),
            timestamp=data.get("timestamp", 0.0),
            record_id=data.get("record_id", ""),
            metadata=data.get("metadata", {}),
        )


class CheckpointManager:
    """Checkpoint 管理器"""

    def __init__(self, store: 'CheckpointStore', interval: int = 10):
        self.store = store
        self.interval = interval
        self._pending_checkpoints: Dict[str, CheckpointInfo] = {}
        self._running = False
        self._save_task: Optional[asyncio.Task] = None
        self._on_checkpoint_saved: Optional[Callable] = None

    def set_save_callback(self, callback: Callable) -> None:
        """设置检查点保存回调"""
        self._on_checkpoint_saved = callback

    async def start(self) -> None:
        """启动周期性保存任务"""
        self._running = True
        self._save_task = asyncio.create_task(self._periodic_save())

    async def stop(self) -> None:
        """停止周期性保存并刷新待保存的检查点"""
        self._running = False
        if self._save_task:
            self._save_task.cancel()
            try:
                await self._save_task
            except asyncio.CancelledError:
                pass
        await self.flush()

    async def save_checkpoint(
        self,
        pipeline_id: str,
        task_name: str,
        offset: int,
        record_id: str = "",
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """保存检查点（缓存到内存）"""
        key = f"{pipeline_id}:{task_name}"
        info = CheckpointInfo(
            pipeline_id=pipeline_id,
            task_name=task_name,
            offset=offset,
            record_id=record_id,
            metadata=metadata,
        )
        self._pending_checkpoints[key] = info

    async def save_checkpoint_now(
        self,
        pipeline_id: str,
        task_name: str,
        offset: int,
        record_id: str = "",
        metadata: Optional[Dict[str, Any]] = None
    ) -> None:
        """立即保存检查点（不缓存）"""
        key = f"{pipeline_id}:{task_name}"
        info = CheckpointInfo(
            pipeline_id=pipeline_id,
            task_name=task_name,
            offset=offset,
            record_id=record_id,
            metadata=metadata,
        )
        store_key = f"checkpoint:{pipeline_id}:{task_name}"
        await self.store.set(store_key, info.to_dict())
        if self._on_checkpoint_saved:
            self._on_checkpoint_saved(info)

    async def get_checkpoint(self, pipeline_id: str, task_name: str) -> Optional[CheckpointInfo]:
        """获取检查点"""
        store_key = f"checkpoint:{pipeline_id}:{task_name}"
        data = await self.store.get(store_key)
        if data:
            return CheckpointInfo.from_dict(data)
        return None

    async def delete_checkpoint(self, pipeline_id: str, task_name: str) -> None:
        """删除检查点"""
        store_key = f"checkpoint:{pipeline_id}:{task_name}"
        await self.store.delete(store_key)
        key = f"{pipeline_id}:{task_name}"
        self._pending_checkpoints.pop(key, None)

    async def flush(self) -> None:
        """刷新所有待保存的检查点"""
        for key, info in list(self._pending_checkpoints.items()):
            store_key = f"checkpoint:{info.pipeline_id}:{info.task_name}"
            await self.store.set(store_key, info.to_dict())
            if self._on_checkpoint_saved:
                self._on_checkpoint_saved(info)
        self._pending_checkpoints.clear()

    async def _periodic_save(self) -> None:
        """周期性保存检查点"""
        while self._running:
            await asyncio.sleep(self.interval)
            if self._pending_checkpoints:
                await self.flush()

    async def restore_checkpoints(self, pipeline_id: str) -> Dict[str, CheckpointInfo]:
        """恢复指定 Pipeline 的所有检查点"""
        checkpoints = {}
        if hasattr(self.store, 'list_keys'):
            keys = await self.store.list_keys(f"checkpoint:{pipeline_id}:")
            for key in keys:
                data = await self.store.get(key)
                if data:
                    info = CheckpointInfo.from_dict(data)
                    checkpoints[info.task_name] = info
        return checkpoints
