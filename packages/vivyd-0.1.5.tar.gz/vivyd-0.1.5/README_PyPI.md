# VIVyD: Vortex-Induced Vibration Dynamics

## Description
VIVyD is a Python package for simulating vortex-induced vibrations (VIV). It implements several models for the fluid-structure interaction.

## Installation
You can install it using the `pip` command:
```
pip install vivyd
```

## Development setup

To work on the source code of this project, **clone** [this repository](https://gitlab.uliege.be/structural-and-stochastic-dynamics/vivyd) to your local machine.
```
git clone https://gitlab.uliege.be/structural-and-stochastic-dynamics/vivyd.git
```
Or, if you prefer using SSH:
```
git clone git@gitlab.uliege.be:structural-and-stochastic-dynamics/vivyd.git
```
Then, navigate into the project directory:
```
cd vivyd
```
Next, it is recommended to create a **virtual environment** to manage dependencies. In particular, this project uses [`uv`](https://docs.astral.sh/uv/) as recommended environment management. To install the environment in editable mode with the specified dependencies, simply run:
```
uv sync
```

Equivalently, using [`pip`](https://pip.pypa.io/en/stable/):
```
pip install -e .
```

## Usage

Once installed, the package can be imported in your own Python scripts or Jupyter notebooks with
```python
import vivyd
```

Under the development setup, examples of how to use the package can be found in the `examples/` directory. You can run scripts using
```
cd src/examples
uv run example_name.py
```
or, interactively for the Jupyter notebooks.

## Support
The best way to get help is to open an issue in the issue tracker of this repository.

## Contributing
This project is open to contributions. If you would like to contribute, please fork [the repository](https://gitlab.uliege.be/structural-and-stochastic-dynamics/vivyd) and create a pull request with your changes. Make sure to follow the coding style and include tests for any new features or bug fixes.

## License
This project is licensed under the MIT License. See the [LICENSE.md](https://gitlab.uliege.be/structural-and-stochastic-dynamics/vivyd/-/blob/main/LICENSE.md) file for more details.