from ..models import TaichiCompatible, TaichiConvertible
from ..excitation import Noise
from ..typing import arrf64, float64
from ..core import is_taichi_used

import taichi as ti
from numpy import zeros
from typing import Callable


@ti.data_oriented
class EulerExplicit:
    def __init__(self, verbose: bool=False):
        
        self.verbose = verbose
        
        if is_taichi_used():
            self._run = self._integrate_taichi
        else:
            self._run = self._integrate_python
            
    def run(
        self,
        model:  Callable,
        t_tab:  arrf64,
        state0: arrf64,
        noise:  Noise | None = None
    ) -> arrf64:
        
        if noise is None:
            noise_tab = zeros((*t_tab.shape, *state0.shape), dtype=float64)
        else:
            noise_tab = noise(t_tab)
            
        if noise_tab.shape != (*t_tab.shape, *state0.shape):
            raise ValueError(f"Noise shape {noise_tab.shape} does not match expected shape {(len(t_tab), len(state0))}")
            
        return self._run(model, t_tab, state0, noise_tab)
    
    
    @ti.func
    def _integrate_taichi_func(
        self,
        model:     ti.template(),
        t_tab:     ti.types.ndarray(dtype=ti.f64, ndim=1),
        state0:    ti.types.ndarray(dtype=ti.f64, ndim=1),
        state_cur: ti.types.ndarray(dtype=ti.f64, ndim=1),
        noise_tab: ti.types.ndarray(dtype=ti.f64, ndim=2),
        noise_cur: ti.types.ndarray(dtype=ti.f64, ndim=1),
        out:       ti.types.ndarray(dtype=ti.f64, ndim=2),
    ):
        n_state = state0.shape[0]
        n_time  = t_tab.shape[0]
        
        progress = 0.0
        
        for j in range(n_state):
            out[0, j] = state0[j]
        
        ti.loop_config(serialize=True)  
        for i in range(1, n_time):
            
            if ti.static(self.verbose):
                p = (i+1) / n_time
                if p >= progress + 0.01:
                    progress = p
                    print(f"\rProgress: {int(progress*100)} %", end="")
            
            dt = t_tab[i] - t_tab[i - 1]
            
            for j in range(n_state):
                state_cur[j] = out[i - 1, j]
                noise_cur[j] = noise_tab[i - 1, j]
            
            rhs = model._rhs_taichi_func(t_tab[i - 1], state_cur)
            
            for j in range(n_state):
                out[i, j] = out[i - 1, j] + (rhs[j] + noise_cur[j]) * dt
                
        if ti.static(self.verbose):
            print("\rProgress: 100 %")

    @ti.kernel
    def _integrate_taichi_kernel(
        self,
        model:     ti.template(),
        t_tab:     ti.types.ndarray(dtype=ti.f64, ndim=1),
        state0:    ti.types.ndarray(dtype=ti.f64, ndim=1),
        state_cur: ti.types.ndarray(dtype=ti.f64, ndim=1),
        noise_tab: ti.types.ndarray(dtype=ti.f64, ndim=2),
        noise_cur: ti.types.ndarray(dtype=ti.f64, ndim=1),
        out:       ti.types.ndarray(dtype=ti.f64, ndim=2),
    ):
        self._integrate_taichi_func(model, t_tab, state0, state_cur, noise_tab, noise_cur, out)

    def _integrate_taichi(
        self,
        model:     Callable,
        t_tab:     arrf64,
        state0:    arrf64,
        noise_tab: arrf64
    ) -> arrf64:
        
        if not isinstance(model, TaichiCompatible):
            if not isinstance(model, TaichiConvertible):
                raise TypeError("Model does not support Taichi solvers")            
            else:
                return self._integrate_taichi(model.to_taichi(), t_tab, state0, noise_tab)
        
        out = zeros((len(t_tab), len(state0)), dtype=float64)
        state_cur = zeros(state0.shape[0], dtype=float64)
        noise_cur = zeros(state0.shape[0], dtype=float64)
        self._integrate_taichi_kernel(model, t_tab, state0, state_cur, noise_tab, noise_cur, out)
        return out
    
    def _integrate_python(
        self,
        model:     Callable,
        t_tab:     arrf64,
        state0:    arrf64,
        noise_tab: arrf64
    ) -> arrf64:

        out = zeros((*t_tab.shape, *state0.shape), dtype=float64)

        out[0] = state0
        
        progress = 0.0
        
        for i in range(1, len(t_tab)):
            
            if self.verbose:
                p = (i+1) / len(t_tab)
                if p >= progress + 0.01:
                    progress = p
                    print(f"\rProgress: {int(progress*100)} %", end="")
            
            s = out[i-1]
            
            t  = t_tab[i-1]
            dt = t_tab[i] - t_tab[i-1]
            ds = model(t, s) + noise_tab[i-1]
            
            out[i] = s + ds * dt
            
        if self.verbose:
            print("\rProgress: 100 %")
            
        return out