from ..typing import arrf64
from . import VIVModel, GeneralizedModel

from dataclasses import dataclass
from numpy import array, pi
from typing import ClassVar


@dataclass(kw_only=True, slots=True)
class TamuraModel(VIVModel):
    
    state_size: ClassVar[int] = 4
    
    xi:     float = 4e-3
    rho:    float = 1.25
    diam:   float = 0.18
    m_lin:  float = 6.5
    fm:     float = 1.16
    Cd:     float = 1.2
    St:     float = 0.18
    v:      float = 1.0
    f0:     float = 1.0
    Cl0:    float = 0.4
    l_star: float = 1.1
    
    @property
    def n(self) -> float:
        return self.rho * self.diam**2 / (2 * self.m_lin)
    
    @property
    def omega(self):
        fs = self.St * self.v / self.diam
        return fs/self.f0
    
    @property
    def zeta(self) -> float:
        factor = 1.0 / (2.0**1.5 * pi**2)
        return factor * self.fm / self.l_star
    
    @property
    def m_star(self) -> float:
        return 1.0 / (0.5 + self.l_star)
        
    @property
    def St_star(self) -> float:
        return 2*pi*self.St
        
    def __call__(self, t: float, state: arrf64) -> arrf64:
        
        self.validate_state(state)
        
        y_dot, y, q_dot, q = state
        
        lhs = (2*self.xi + self.n*(self.fm+self.Cd)*self.omega/self.St_star) * y_dot + y
        rhs = - self.fm * self.n * self.omega**2 / self.St_star**2 * q
        
        dy_dot = rhs - lhs
        
        dy = y_dot
        
        lhs = - 2 * self.zeta * self.omega * (1.0 - 4*self.fm**2/self.Cl0**2 * q**2) * q_dot + self.omega**2 * q
        rhs = - self.m_star * dy_dot - self.St_star * self.omega * y_dot
        
        dq_dot = rhs - lhs
        
        dq = q_dot
        
        return array([dy_dot, dy, dq_dot, dq])
    
    def to_taichi(self) -> GeneralizedModel:
        
        return GeneralizedModel(
            xi = self.xi + self.n * (self.fm + self.Cd) * self.omega / (2.0 * self.St_star),
            M0 = - self.fm * self.n * self.omega**2 / self.St_star**2,
            omega = self.omega,
            a = 8.0 * self.zeta * self.fm**2 / self.Cl0**2,
            eps = 2.0 * self.zeta,
            A1 = - self.omega * self.St_star,
            A2 = - self.m_star
        )
        
    def get_lift(self, state: arrf64) -> float:
        y_dot, _, _, q = state
        return - self.fm * (q + self.St_star/self.omega * y_dot)