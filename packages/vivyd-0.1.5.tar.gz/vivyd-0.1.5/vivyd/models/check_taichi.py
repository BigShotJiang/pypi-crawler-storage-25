from __future__ import annotations

from typing import Callable, Protocol, runtime_checkable


@runtime_checkable
class TaichiCompatible(Protocol):

    def _rhs_taichi_func(self, *args, **kwargs): ...
    
    def _rhs_taichi_kernel(self, *args, **kwargs): ...
    
    def _rhs_taichi(self, *args, **kwargs): ...
    
    
@runtime_checkable
class TaichiConvertible(Protocol):

    def to_taichi(self, *args, **kwargs) -> Callable: ...