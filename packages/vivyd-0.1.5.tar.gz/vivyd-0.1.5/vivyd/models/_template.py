#TODO: import mother class (most general being VIVModel)

class TemplateModel(...): #TODO
    
    def __init__(
        self, *,
        ... #TODO
    ):
        super().__init__(
            ... #TODO
        )
        
        self._locked = [
            ... #TODO
        ]
        
    def set_original_params(
        self, *,
        ... #TODO
    ):
        ... #TODO
        
    @classmethod
    def from_original_params(
        cls, *,
        ... #TODO
    ) -> TemplateModel:
        
        new = cls()
        new.set_original_params(
            ... #TODO
        )
        return new