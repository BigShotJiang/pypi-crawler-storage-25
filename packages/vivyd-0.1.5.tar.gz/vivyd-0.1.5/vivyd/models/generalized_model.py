from ..core import is_taichi_used
from ..typing import arrf64, float64
from . import VIVModel

from typing import ClassVar
from numpy import array, zeros_like
import taichi as ti


@ti.data_oriented
class GeneralizedModel(VIVModel):
    
    state_size: ClassVar[int] = 4
    
    def __init__(
        self,
        xi:    float = 0.0,
        M0:    float = 0.0,
        omega: float = 0.0,
        a:     float = 0.0,
        b:     float = 0.0,
        eps:   float = 0.0,
        A0:    float = 0.0,
        A1:    float = 0.0,
        A2:    float = 0.0
    ) -> None:
        
        self.xi = xi
        self.M0 = M0
        self.omega = omega
        self.a = a
        self.b = b
        self.eps = eps
        self.A0 = A0
        self.A1 = A1
        self.A2 = A2
        
        if is_taichi_used():
            self._rhs = self._rhs_taichi
        else:
            self._rhs = self._rhs_python
    
    def __call__(self, t: float, state: arrf64) -> arrf64:
        self.validate_state(state)
        return self._rhs(t, state)
    
    @ti.func
    def _rhs_taichi_func(self, t: ti.f64, state: ti.types.ndarray(dtype=ti.f64, ndim=1)) -> ti.types.ndarray(dtype=ti.f64, ndim=1):
        
        y_dot = state[0]
        y = state[1]
        q_dot = state[2]
        q = state[3]
        
        lhs = 2 * self.xi * y_dot + y
        rhs = self.M0 * q
        dy_dot = rhs - lhs
        
        dy = y_dot
        
        lhs = self.omega * (self.a * q**2 + self.b * q_dot**2 - self.eps) * q_dot + self.omega**2 * q
        rhs = self.A0 * y + self.A1 * y_dot + self.A2 * dy_dot
        dq_dot = rhs - lhs
        
        dq  = q_dot
        
        return ti.Vector([dy_dot, dy, dq_dot, dq], dt=ti.f64)

    @ti.kernel
    def _rhs_taichi_kernel(
        self,
        t: ti.f64,
        state: ti.types.ndarray(dtype=ti.f64, ndim=1),
        out: ti.types.ndarray(dtype=ti.f64, ndim=1),
    ):
        rhs = self._rhs_taichi_func(t, state)
        for i in range(4):
            out[i] = rhs[i]
            
    def _rhs_taichi(self, t: float, state: arrf64) -> arrf64:
        
        out = zeros_like(state, dtype=float64)
        self._rhs_taichi_kernel(t, state, out)
        return out

    def _rhs_python(self, t: float, state: arrf64) -> arrf64:
        
        y_dot, y, q_dot, q = state
        
        lhs = 2 * self.xi * y_dot + y
        rhs = self.M0 * q
        dy_dot = rhs - lhs
        
        dy = y_dot
        
        lhs = self.omega * (self.a * q**2 + self.b * q_dot**2 - self.eps) * q_dot + self.omega**2 * q
        rhs = self.A0 * y + self.A1 * y_dot + self.A2 * dy_dot
        dq_dot = rhs - lhs
        
        dq  = q_dot
        
        return array([dy_dot, dy, dq_dot, dq])