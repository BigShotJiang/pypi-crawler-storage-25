from ..typing import arrf64
from . import VIVModel, GeneralizedModel

from typing import ClassVar
from dataclasses import dataclass
from numpy import pi, array


@dataclass(kw_only=True, slots=True)
class HartlenCurrieModel(VIVModel):
    
    state_size: ClassVar[int] = 4
    
    xi:    float = 4e-3
    rho:   float = 1.25
    diam:  float = 0.18
    St:    float = 0.18
    m_lin: float = 6.5
    v:     float = 1.0
    f0:    float = 1.0
    alpha: float = 0.02
    gamma: float = 0.667
    b:     float = 0.4
    
    @property
    def a(self) -> float:
        num = self.rho * self.diam**2
        den = 8 * pi**2 * self.St**2 * self.m_lin
        return num / den
    
    @property
    def omega(self):
        fs = self.St * self.v / self.diam
        return fs/self.f0
    
    def __call__(self, t: float, state: arrf64) -> arrf64:
        
        self.validate_state(state)
        
        y_dot, y, q_dot, q = state
        
        lhs = 2 * self.xi * y_dot + y
        rhs = self.a * self.omega**2 * q
        dy_dot = rhs - lhs
        
        dy = y_dot
        
        lhs = (self.gamma/self.omega * q_dot**2 - self.alpha * self.omega) * q_dot + self.omega**2 * q
        rhs = self.b * y_dot
        
        dq_dot = rhs - lhs
        
        dq = q_dot
        
        return array([dy_dot, dy, dq_dot, dq])
    
    def to_taichi(self) -> GeneralizedModel:
        
        return GeneralizedModel(
            xi    = self.xi,
            M0    = self.a * self.omega**2,
            omega = self.omega,
            b     = self.gamma / self.omega**2,
            eps   = self.alpha,
            A1    = self.b
        )
