from ..typing import arrf64, float64

from abc import ABC, abstractmethod
import taichi as ti
from typing import ClassVar
from numpy import asarray


class VIVModel(ABC):
    
    state_size: ClassVar[int]
    
    def validate_state(self, state: arrf64) -> arrf64:
        array = asarray(state, dtype=float64)
        if array.ndim != 1:
            raise ValueError("state must be a one-dimensional array")
        if array.shape[0] != self.state_size:
            raise ValueError(f"expected state size {self.state_size}, got {array.shape[0]}")
        return array
    
    @abstractmethod
    def __call__(self, t: float, state: arrf64) -> arrf64:
        raise NotImplementedError
    
    def _rhs_taichi_func(self, t: ti.f64, state: ti.template()) -> ti.template():
        raise NotImplementedError(f"Taichi acceleration is not implemented for model {self.__class__.__name__}.")
    
    def _rhs_taichi_kernel(
        self,
        t: ti.f64,
        state: ti.types.ndarray(dtype=ti.f64, ndim=1),
        out: ti.types.ndarray(dtype=ti.f64, ndim=1),
    ):
        raise NotImplementedError(f"Taichi acceleration is not implemented for model {self.__class__.__name__}.")