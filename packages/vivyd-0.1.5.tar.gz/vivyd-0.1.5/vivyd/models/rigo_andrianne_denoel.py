from ..typing import arrf64
from . import VIVModel, GeneralizedModel

from typing import ClassVar
from dataclasses import dataclass
from numpy import array


@dataclass(kw_only=True, slots=True)
class RigoAndrianneDenoelModel(VIVModel):
    
    state_size: ClassVar[int] = 2
    
    alpha: float = - 0.085
    gamma: float =   0.009
    delta: float =   0.057
    
    def __call__(self, t: float, state: arrf64) -> arrf64:
        
        q_dot, q = state
        
        dq_dot = (self.alpha * q**2 + self.gamma * q_dot**2 + self.delta) * q_dot - q
        
        dq = q_dot
        
        return array([dq_dot, dq])
        
    def to_taichi(self) -> GeneralizedModel:
        
        return GeneralizedModel(
            omega = 1.0,
            a     = - self.alpha,
            b     = - self.gamma,
            eps   = self.delta
        )
        
    def get_lift(self, state: arrf64, Cl0: float) -> float:
        
        q = state[1]
        
        return q * Cl0 / 2.0