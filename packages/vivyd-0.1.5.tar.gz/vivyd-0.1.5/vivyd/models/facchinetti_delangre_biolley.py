from ..typing import arrf64
from . import VIVModel, GeneralizedModel

from typing import ClassVar
from dataclasses import dataclass
from numpy import array, pi


@dataclass(kw_only=True, slots=True)
class FacchinettiDelangreBiolleyModel(VIVModel):
    
    state_size: ClassVar[int] = 4
    
    xi:     float = 4e-3
    f0:     float = 1.0
    v:      float = 1.0
    St:     float = 0.18
    diam:   float = 0.18
    Cd:     float = 1.2
    Cl0:    float = 0.4
    m:      float = 6.5
    Cm:     float = 1.0
    rho:    float = 1.25
    eps:    float = 0.3
    A:      float = 6.0
    
    @property
    def fs(self) -> float:
        return self.St * self.v / self.diam
    
    @property
    def delta(self) -> float:
        return self.f0 / self.fs
    
    @property
    def gamma(self) -> float:
        return self.Cd / (4.0 * pi * self.St)

    @property
    def m_fluid(self) -> float:
        return self.Cm * self.rho * pi * self.diam**2 / 4.0

    @property
    def mu(self) -> float:
        return (self.m + self.m_fluid) / (self.rho * self.diam**2)

    def __call__(self, t: float, state: arrf64) -> arrf64:
        
        self.validate_state(state)
        
        y_dot, y, q_dot, q = state
        
        lhs = (2.0 * self.xi * self.delta + self.gamma / self.mu) * y_dot + self.delta**2 * y
        rhs = self.Cl0 / (16.0 * pi**2 * self.St**2 * self.mu) * q
        
        dy_dot = rhs - lhs
        
        dy = y_dot
        
        lhs = self.eps * (q**2 - 1.0) * q_dot + q
        rhs = self.A * y_dot
        
        dq_dot = rhs - lhs
        
        dq = q_dot
        
        return array([dy_dot, dy, dq_dot, dq])
    
    def to_taichi(self) -> GeneralizedModel:
        return GeneralizedModel(
            xi    = self.xi + 0.5*self.gamma/self.mu/self.delta,
            M0    = self.Cl0 / (16.0 * pi**2 * self.St**2 * self.mu) / self.delta**2,
            omega = 1.0 / self.delta,
            a     = self.eps,
            eps   = self.eps,
            A1    = self.A
        )