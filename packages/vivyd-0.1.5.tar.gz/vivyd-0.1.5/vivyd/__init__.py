from importlib.metadata import version
from .core import use_taichi, is_taichi_used
from . import typing
from . import models
from . import solvers
from . import data
from . import excitation

__version__ = version("vivyd")

__all__ = [
	"__version__",
	"use_taichi",
	"is_taichi_used",
	"models",
	"solvers",
	"data",
	"excitation"
]
