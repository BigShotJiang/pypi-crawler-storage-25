from ..typing import arrf64
from . import Noise

from typing import Callable, Sequence
from numpy import array, zeros, ones_like, sqrt, pi, exp, conj, zeros_like
from numpy.fft import fftfreq, ifft
from numpy.random import uniform


type psd_func = Callable[[arrf64], arrf64]


class NoiseGenerator:
    
    def __init__(self, n: int, dt: float, psd_tab: Sequence[Callable[[arrf64], arrf64]]):
        
        if dt <= 0.0:
            raise ValueError("dt must be positive")
        if n <= 0:
            raise ValueError("n must be positive")
        
        self.n       = n
        self.dt      = dt
        self.psd_tab = psd_tab
        
        self.f_tab   = fftfreq(self.n, self.dt).astype(float)
        
        self.R_tab   = [
            sqrt(psd(self.f_tab) * self.n / self.dt)
            for psd in self.psd_tab
        ]
            

    def __call__(self) -> Noise:
        
        x_all = []
                
        for amplitudes in self.R_tab:
            
            phases_pos = uniform(0, 2 * pi, (self.n - 1) // 2)
            
            X = zeros(self.n, dtype=complex)
        
            # DC should be real
            X[0] = amplitudes[0]
            
            # random phase on positive frequencies
            X[1:(self.n+1)//2] = amplitudes[1:(self.n+1)//2] * exp(1j * phases_pos)
            
            # if n is even, the Nyquist frequency is in the array and it should be real
            if self.n % 2 == 0:
                X[-self.n // 2] = amplitudes[-self.n // 2]
                    
            # the phase must be an odd function for the signal to be real
            X[-1:-self.n//2:-1] = conj(X[1:(self.n+1)//2])

            x_all.append(ifft(X).real)
        
        return Noise(array(x_all).T, self.dt)
    
    @staticmethod
    def deterministic() -> psd_func:
        def func(f: arrf64) -> arrf64:
            return zeros_like(f)
        return func
    
    @staticmethod
    def none() -> psd_func:
        def func(f: arrf64) -> arrf64:
            return zeros_like(f)
        return func

    @staticmethod
    def white(s: float = 1.0) -> psd_func:
        def func(f: arrf64) -> arrf64:
            return s * ones_like(f)
        return func
    
    @staticmethod
    def generalized(sigma2: float, U: float, Lu: float, A: float, B: float, mu: float) -> psd_func:
        def func(f: arrf64) -> arrf64:
            return sigma2 * A * (Lu/U) / (1 + B * (abs(f) * Lu/U)**mu)**(5/(3*mu))
        return func
    
    @staticmethod
    def von_karman(sigma2: float, U: float, Lu: float) -> psd_func:
        return NoiseGenerator.generalized(sigma2, U, Lu, A=2.0, B=70.8, mu=2.0) 