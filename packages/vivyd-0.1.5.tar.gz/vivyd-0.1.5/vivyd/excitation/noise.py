from ..typing import arrf64
from ..core import is_taichi_used

from numpy import zeros
import taichi as ti


@ti.data_oriented
class Noise:
    def __init__(self, x: arrf64, dt: float):
        if x.ndim == 1:
            x = x[:, None]
        self.x  = x
        self.dt = dt
        
        if is_taichi_used():
            self._interpolate = self._interpolate_taichi
        else:
            self._interpolate = self._interpolate_python
        
    def __call__(self, t: arrf64) -> arrf64:
        return self._interpolate(t)
    
    def _interpolate_python(self, t: arrf64) -> arrf64:
        
        x = zeros((t.shape[0], self.x.shape[1]), dtype=self.x.dtype)
        
        i = t / self.dt
        
        where_int = (i == i.astype(int))
        
        x[where_int] = self.x[i[where_int].astype(int)]
        
        x_inf = self.x[i[~where_int].astype(int)]
        x_sup = self.x[i[~where_int].astype(int) + 1]
        
        t_mid = t[~where_int] - i[~where_int] * self.dt
        t_mid = t_mid[:, None]                          # None is like newaxis
        
        x[~where_int] = x_inf + (x_sup - x_inf) * t_mid / self.dt
        
        return x
    
    @ti.func
    def _interpolate_taichi_func(
        self,
        x:   ti.types.ndarray(dtype=ti.f64, ndim=2),
        t:   ti.types.ndarray(dtype=ti.f64, ndim=1),
        out: ti.types.ndarray(dtype=ti.f64, ndim=2)
    ):
        
        for i in range(t.shape[0]):
            t_i = t[i]
            
            i_true = t_i / self.dt
            i_inf  = int(i_true)
            i_sup  = i_inf + 1
            
            if ti.abs(i_true - ti.cast(i_inf, ti.f64)) < 1e-12:
                for j in range(out.shape[1]):
                    out[i, j] = x[i_inf, j]
            else:
                t_mid = t_i - i_inf * self.dt
                for j in range(out.shape[1]):
                    x_inf = x[i_inf, j]
                    x_sup = x[i_sup, j]
                    out[i, j] = x_inf + (x_sup - x_inf) * t_mid / self.dt
                    
    @ti.kernel
    def _interpolate_taichi_kernel(
        self,
        x:   ti.types.ndarray(dtype=ti.f64, ndim=2),
        t:   ti.types.ndarray(dtype=ti.f64, ndim=1),
        out: ti.types.ndarray(dtype=ti.f64, ndim=2)
    ):
        self._interpolate_taichi_func(x, t, out)
        
    def _interpolate_taichi(self, t: arrf64) -> arrf64:
        
        out = zeros((t.shape[0], self.x.shape[1]), dtype=self.x.dtype)
        self._interpolate_taichi_kernel(self.x, t, out)
        return out