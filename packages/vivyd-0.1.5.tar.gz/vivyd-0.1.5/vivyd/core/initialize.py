
_USE_TAICHI = False

def use_taichi(use_taichi: bool=True, **ti_params):
    global _USE_TAICHI

    if use_taichi:

        try:
            import taichi as ti

        except ImportError:
            _USE_TAICHI = False
            print ("Taichi is not available. Falling back to classic Python implementation.")

        else:
            _USE_TAICHI = True
            
            if "arch" not in ti_params:
                ti_params["arch"] = ti.cpu
            if "cpu_max_num_threads" not in ti_params:
                ti_params["cpu_max_num_threads"] = 1
            
            print("Taichi is available. Initializing Taichi with parameters:", ti_params)

            ti.init(**ti_params)
            
    else:
        _USE_TAICHI = False
        
def is_taichi_used() -> bool:
    return _USE_TAICHI