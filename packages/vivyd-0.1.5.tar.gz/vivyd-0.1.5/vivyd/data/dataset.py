from __future__ import annotations

from .container import Container
from .study import Study
from .signal import Signal

import json
import zarr
import warnings
from zarr.storage import ZipStore
from dataclasses import dataclass, field
from typing import Any
from pathlib import Path
from zenodo_get import download

    
@dataclass(kw_only=True)
class DataSet(Container):
    site:    Site
    authors: list[Author]   = field(default_factory=list)
        
    def add(self, *study: Study) -> DataSet:
        for s in study:
            self._add_entry(s.name, s)
        return self
    
    def save(self, path: Path | str, create_dirs: bool = False):
        if isinstance(path, str):
            path = Path(path)
        if path.suffix != ".vxp":
            raise ValueError("Use .vxp for chunked storage")

        if create_dirs:
            path.parent.mkdir(parents=True, exist_ok=True)

        # Suppress zarr/zipfile duplicate name warning (harmless internal behavior)
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", category=UserWarning, message=".*Duplicate name.*")
            
            store = ZipStore(str(path), mode="w")           # Zarr store backed by a zip file
            root = zarr.open_group(store=store, mode="w")   # Root of the Zarr store

            # Walk the tree and save arrays, collecting refs
            def inject_refs(obj):
                
                # Recursively store contents of containers
                if isinstance(obj, Container):
                    return {
                        **obj.__dict__,
                        "contents": [inject_refs(c) for c in obj.contents.values()]
                    }
                    
                # For signals, compress arrays (heavy data) to seperate zarr files
                # Only references to arrays are stored in the metadata
                elif isinstance(obj, Signal):
                    data_ref, time_ref = obj._save_arrays(root)   # Heavy signal data is saved in a compressed, chunked format
                    return {
                        **obj.__dict__,
                        "data_ref": data_ref,
                        "time_ref": time_ref
                    }

                else:
                    return obj.__dict__

            meta = inject_refs(self)    # Apply to the entire dataset

            # Store metadata as JSON string in the store's root attributes
            root.attrs["_metadata"] = json.dumps(meta)
            
            store.close()
        
    @staticmethod
    def load(path: Path | str) -> DataSet:
        if isinstance(path, str):
            path = Path(path)
        if path.suffix != ".vxp":
            raise ValueError("Use .vxp for chunked storage")

        store = ZipStore(str(path), mode="r")
        root = zarr.open_group(store=store, mode="r")
        
        # Read metadata from zarr group attributes (stored as JSON string)
        meta_str = str(root.attrs["_metadata"])
        meta = json.loads(meta_str)

        return DataSet._from_dict(meta, store)
    
    @staticmethod
    def download_from_zenodo(
        record_id: str,
        output_dir: Path | str,
        token: str | None = None,
        create_dirs: bool = False
    ):
        if isinstance(output_dir, str):
            output_dir = Path(output_dir)
        if create_dirs:
            output_dir.mkdir(parents=True, exist_ok=True)

        download(
            record=record_id,
            access_token=token,
            output_dir=output_dir
        )
    
    @property
    def __dict__(self) -> dict[str, Any]:
        return {
            **super().__dict__,
            "site":    self.site.__dict__,
            "authors": [author.__dict__ for author in self.authors],
        }
        
    @staticmethod    
    def _from_dict(data: dict[str, Any], store: ZipStore) -> DataSet:
        
        new = DataSet(
            name = data["name"],
            info = data["info"],
            site = Site(**data["site"]),
            authors = [Author(**a) for a in data["authors"]]
        )
        
        for study in data["contents"]:
            new.add(Study._from_dict(study, store))
        
        return new
        
        
@dataclass(kw_only=True)
class Author:
    firstname:   str
    lastname:    str
    email:       str
    institution: str
    info:        dict[str, Any] = field(default_factory=dict)


@dataclass(kw_only=True)
class Site:
    name:        str
    location:    str
    institution: str
