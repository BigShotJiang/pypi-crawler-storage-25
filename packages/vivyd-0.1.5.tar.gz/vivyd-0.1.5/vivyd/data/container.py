from __future__ import annotations

from .signal import Signal
from .value import Value

from dataclasses import dataclass, field
from typing import Any
from textwrap import dedent
from json import dumps


@dataclass(kw_only=True)
class Container:
    name:     str
    info:     dict[str, Any]
    contents: dict[str, Any] = field(default_factory=dict, init=False)
    
    
    def _clean_info(self, info: dict[str, Any]) -> dict[str, Any]:
        """Recursively clean string fields in the info dictionary."""
        cleaned = {}
        for key, value in info.items():
            if isinstance(value, str):
                cleaned[key] = dedent(value).strip()
            elif isinstance(value, dict):
                cleaned[key] = self._clean_info(value)
            else:
                cleaned[key] = value
        return cleaned
    
    def __post_init__(self):
        object.__setattr__(self, "name", dedent(self.name).strip())
        object.__setattr__(self, "info", self._clean_info(self.info))
    
    def _add_entry(self, key: str, value: Any):
        if key in self.contents:
            raise ValueError(f"Entry with key '{key}' already exists in this container.")
        self.contents[key] = value
        
    def keys(self) -> list[str]:
        return list(self.contents.keys())
    
    def tree(self, indent: int = 0) -> str:
        """Return a hierarchical tree representation of container and its contents."""
        lines: list[str] = []
        prefix = "  " * indent
        lines.append(f"{prefix}<{self.__class__.__name__}> {self.name}")
        
        for item in self.contents.values():
            if hasattr(item, "tree"):
                # Recursively print containers
                lines.append(item.tree(indent + 1))
        
        return "\n".join(lines)
    
    def print_tree(self) -> None:
        """Print the hierarchical tree of container entries."""
        print(self.tree())
    
    def to_json(self, *, indent: int = 2, ensure_ascii: bool = False) -> str:
        """Return the container and its contents as a formatted JSON string."""
        return dumps(self, indent=indent, ensure_ascii=ensure_ascii, default=lambda o: o.__dict__)
    
    def print_json(self) -> None:
        """Print the container and its contents as formatted JSON."""
        print(self.to_json())
    
    def __getitem__(self, key: str) -> Any:
        if not key in self.contents:
            raise KeyError(f"No entry with key '{key}' found in this container.")
        return self.contents[key]
    
    def __str__(self) -> str:
        text = dumps(self, indent=2, ensure_ascii=False, default=lambda o: o.__dict__)
        return text.replace("\\n", "\n").replace("\\t", "\t")
    
    @property
    def __dict__(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "info": self.info,
            "type": self.__class__.__name__,
            "contents": [c.__dict__ for c in self.contents.values()],
            "keys": self.keys(),
        }
        
    def __iter__(self):
        for key, value in self.contents.items():
            yield key, value