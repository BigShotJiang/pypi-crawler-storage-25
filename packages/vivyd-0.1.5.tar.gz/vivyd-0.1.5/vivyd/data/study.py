from __future__ import annotations

from .container import Container
from .experiment import Experiment

from dataclasses import dataclass
from typing import Any
from zarr.storage import ZipStore


@dataclass(kw_only=True)
class Study(Container):
    
    def add(self, *obj: Study | Experiment) -> Study:
        for o in obj:
            self._add_entry(o.name, o)
        return self

    @staticmethod
    def _from_dict(data: dict[str, Any], store: ZipStore) -> Study:
        new = Study(
            name=data["name"],
            info=data["info"]
        )
        for obj in data["contents"]:
            match obj["type"]:
                case "Study":
                    new.add(Study._from_dict(obj, store))
                case "Experiment":
                    new.add(Experiment._from_dict(obj, store))
                case _:
                    raise ValueError(f"Unsupported type '{obj['type']}' found in study '{new.name}'. Supported types are 'Study' and 'Experiment'.")
        return new