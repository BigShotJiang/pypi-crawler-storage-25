from __future__ import annotations

from .container import Container
from .signal import Signal
from .value import Value

from dataclasses import dataclass
from typing import Any
from zarr.storage import ZipStore


@dataclass(kw_only=True)
class Source(Container):
    
    def add(self, *obj: Signal | Value) -> Source:
        for o in obj:
            self._add_entry(o.name, o)
        return self
        
    @staticmethod
    def _from_dict(data: dict[str, Any], store: ZipStore) -> Source:
        new = Source(
            name=data["name"],
            info=data["info"]
        )
        for obj in data["contents"]:
            match obj["type"]:
                case "Signal":
                    new.add(Signal._from_dict(obj, store))
                case "Value":
                    new.add(Value._from_dict(obj))
                case _:
                    raise ValueError(f"Unsupported type '{obj['type']}' found in source '{new.name}'. Supported types are 'Signal' and 'Value'.")
        return new