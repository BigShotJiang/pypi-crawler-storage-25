from __future__ import annotations

from dataclasses import dataclass
from typing import Any
from quantities import UnitQuantity, Quantity


@dataclass(kw_only=True)
class Value:
    name:  str
    data:  float | str | bool
    units: UnitQuantity | Quantity
    
    @property
    def __dict__(self) -> dict[str, Any]:
        return {
            "name":  self.name,
            "data":  self.data,
            "units": self.units.dimensionality.string,
            "type":  self.__class__.__name__
        }
        
    @staticmethod
    def _from_dict(data: dict[str, Any]) -> Value:
        return Value(
            name=data["name"],
            data=data["data"],
            units=Quantity(1.0, data["units"]).units
        )
        
    def tree(self, indent: int = 0) -> str:
        
        type_ = self.__class__.__name__
        units_ = self.units.dimensionality.string
        return f"{'  ' * indent}<{type_}> {self.name} [{units_}] {self.data}"
    