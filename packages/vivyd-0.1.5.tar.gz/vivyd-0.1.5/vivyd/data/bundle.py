from __future__ import annotations

from .container import Container
from .source import Source

from dataclasses import dataclass
from typing import Any
from zarr.storage import ZipStore


@dataclass(kw_only=True)
class Bundle(Container):
    
    def add(self, *obj: Bundle | Source) -> Bundle:
        for o in obj:
            self._add_entry(o.name, o)
        return self

    @staticmethod
    def _from_dict(data: dict[str, Any], store: ZipStore) -> Bundle:
        new = Bundle(
            name=data["name"],
            info=data["info"]
        )
        for obj in data["contents"]:
            match obj["type"]:
                case "Bundle":
                    new.add(Bundle._from_dict(obj, store))
                case "Source":
                    new.add(Source._from_dict(obj, store))
                case _:
                    raise ValueError(f"Unsupported type '{obj['type']}' found in bundle '{new.name}'. Supported types are 'Bundle' and 'Source'.")        
        return new