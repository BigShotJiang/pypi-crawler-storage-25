from __future__ import annotations

from .container import Container
from .bundle import Bundle

from dataclasses import dataclass
from datetime import datetime
from typing import Any
from zarr.storage import ZipStore


@dataclass(kw_only=True)
class Experiment(Container):
    date: datetime
    
    def add(self, *bundle: Bundle) -> Experiment:
        for b in bundle:
            self._add_entry(b.name, b)
        return self

    @property
    def __dict__(self) -> dict[str, Any]:
        return {
            **super().__dict__,
            "date": self.date.isoformat()
        }
        
    @staticmethod
    def _from_dict(data: dict[str, Any], store: ZipStore) -> Experiment:
        new = Experiment(
            name=data["name"],
            info=data["info"],
            date=datetime.fromisoformat(data["date"]),
        )
        for bdl in data["contents"]:
            new.add(Bundle._from_dict(bdl, store))
        return new