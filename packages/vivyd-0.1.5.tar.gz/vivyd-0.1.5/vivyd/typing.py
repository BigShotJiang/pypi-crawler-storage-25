from numpy import float64
from numpy.typing import NDArray

type arrf64 = NDArray[float64]