#import "@preview/hydra:0.5.1": *
#import "@preview/abbr:0.2.3"
#import "@preview/colorful-boxes:1.3.1": *
#import "@preview/equate:0.2.0": *
#import "@preview/suboutline:0.2.0": *
#import "@preview/lovelace:0.3.0": *
#import "@preview/equate:0.3.0": *
#import "@preview/slydst:0.1.4": *

#let acr   = abbr.a
#let acrpl = abbr.pla
#let reset-acronym = abbr.l

/* SHORT FORMATS */

//#let FIG_PATH = "../../figures/"
//#let fig(source, width: auto, height: auto, caption: none) = figure(image(FIG_PATH+source, width: width, height: height), caption: caption)

//#show figure.caption: it => [
//   *#it.supplement*
//   *#{context it.counter.display(it.numbering)}*:
//   #it.body
// ]

//#show : project.with(figures: (cover,), title: "Title", subtitle: "Inspired by the lectures given by Prof. ...", authors: ("Tom BERTRAND",), date: "... 20..", endnote:"Achieved with the help of Github Copilot.")

// #show: thmbox-init(counter-level: 1)
// #let rem(..args) = remark(..args, numbering:"A")


#let appendix(body) = {
  set heading(numbering: "A.1", supplement: [Appendix])
  counter(heading).update(0)
  show heading.where(level:1): it => {
    let num = counter(heading).display()
    [Appendix #num: #it.body]
  }
  body
}

#let algo(body, caption) = {
  figure(
  kind: "algorithm",
  supplement: [Algorithm],
  pseudocode-list(hooks: .5em, booktabs: true, body),
  caption: caption
  )
}

#let cmt-title(..body) = [
  #text(underline(body.pos().join()), luma(50%))
]

#let cmt(..body) = [
  #text( luma(50%))[\# #body.pos().join()]
]

// #let cover_png = image("FSA-uni.png", width: 100%)
// #let cover = image("../figures/FSA-uni.svg", width: 100%)

#let myblock(body) = block(fill: luma(240), width: 100%, inset: 8pt, radius: 4pt, body)

#let py(body)  = [#raw(body, lang: "py")]
#let pr(body) = [#raw(">>> " + body)]
#let match = text(py("match"), rgb(215, 59, 74))
#let case = text(py("case"), rgb(215, 59, 74))

#let eq           = equate
#let vector(body) = $underline(#body)$
#let vec          = vector
#let matrix(body) = $underline(underline(#body))$
#let tensor(body) = $underline(underline(#body))$
#let obar(body)   = $overline(#body)$
#let sgn          = $op("sgn")$
#let inf          = $oo$
#let otimes       = $times.circle$
#let ddag         = $dagger.double$
#let ddot(body)   = $dot.double(#body)$
#let Var          = $op("Var")$
#let hbar         = $planck.reduce$
#let infty        = $infinity$
#let int          = $integral$
#let ij           = $i j$
#let ji           = $j i$
#let ii           = $i i$
#let jj           = $j j$
#let ik           = $i k$
#let kj           = $k j$
#let ki           = $k i$
#let kk           = $k k$
#let jk           = $j k$
#let ijk          = $i j k$
#let ijkl         = $i j k l$
#let kl           = $k l$
#let lj           = $l j$
#let il           = $i l$
#let li           = $l i$
#let lk           = $l k$
#let jl           = $j l$
#let lm           = $l m$
#let mn           = $m n$
#let pq           = $p q$
#let rs           = $r s$
#let pqrs         = $p q r s$
#let AB           = $A B$
#let BA           = $B A$
#let CD           = $C D$
#let DC           = $D C$
#let AA           = $A A$
#let BC           = $B C$
#let AC           = $A C$
#let CA           = $C A$
#let CB           = $C B$
#let CE           = $C E$
#let EC           = $E C$
#let EB           = $E B$
#let AD           = $A D$
#let DA           = $D A$
#let ABCD         = $A B C D$
#let iA           = $i A$
#let Ai           = $A i$
#let Aj           = $A j$
#let Ak           = $A k$
#let jA           = $j A$
#let iB           = $i B$
#let Bi           = $B i$
#let iC           = $i C$
#let Ci           = $C i$
#let jB           = $j B$
#let Bj           = $B j$
#let ABC          = $A B C$
#let hand         = $#h(0.5cm) "and" #h(0.5cm)$
#let hand2        = $#h(1cm) "and" #h(1cm)$
#let hspace       = $#h(0.5cm)$
#let hspace2      = $#h(1cm)$
#let iprod(f, g)  = $lr(angle.l #f,#g angle.r)$
#let braket(body) = $lr(angle.l #body angle.r)$
#let atanh        = math.op("atanh")
#let dev          = math.op("dev")
#let erf          = math.op("erf")
#let ind          = $𝟙$
#let diag         = $op("diag")$
#let dom          = $op("dom")$
#let eth          = $ð$
#let iid          = $tilde^"iid"$
#let Unif         = $op("Unif")$

#let TODO(..body) = {
  if(body.pos().join() != none){
    rect(text("TODO : "+(body.pos().join()), fill: red, weight: "extrabold"), stroke: red)
  }
  else{
    rect(text("TODO", fill: red, weight: "extrabold"), stroke: red)
  }
}

#let TODO-final(..body) = rect(
  text("TODO (final): "+(body.pos().join()), fill: orange, weight: "extrabold"), stroke: orange
)

#let encircle_letter(body) = {
  h(1pt)
  box(circle(align(body, center + horizon), radius:5pt))
  h(1pt)
}

#let bblock(body) = block(fill: rgb(210, 230, 250), width: 100%, inset: 8pt, radius: 4pt, body)

#let gblock(body) = block(fill: rgb(210, 255, 180), width: 100%, inset: 8pt, radius: 4pt, body)

#let rblock(body) = block(fill: rgb(249, 210, 216), width: 100%, inset: 8pt, radius: 4pt, body)

#let kblock(body) = block(fill: rgb(230, 230, 230), width: 100%, inset: 8pt, radius: 4pt, body)

#let defblock(body) = colorbox(
  title: [Definition],
  color: "blue",
  radius: 5pt,
  width: auto
)[
  #v(-5pt)
  #body
]

#let minipage(body, width:80%) = align(center)[#block(width:width, align(left, body))]

/* TEMPLATES */

#let condensed(equation_numbering: "(1)", body) = {
  set page(margin: (x: 3em, y: 4em), numbering: "1")
  set par(justify: true, linebreaks: "optimized", leading: 1.3em)
  set text(hyphenate: false, size: 10pt, spacing: 2pt, lang: "fr", font: "New Computer Modern")
  set math.equation(numbering: equation_numbering, supplement: "Eq.")
  set figure(supplement: "Fig.")

  show figure: it => align(center)[
    #v(1%)
    #box[
    #it.body
    #it.supplement
    #it.counter.display(it.numbering)]
  ]

  show math.equation: it => text(" "+it+" ", size: 11pt)
  
  body
}


#let project(figures, title: "Title", subtitle: "Subtitle", authors: ("Author 1", "Author 2", "..."), date: "Date", language: "en", numbered: "1.1", outlined: true, endnote: none, alt_numbering:"I", n_col:1, fontsize: 11pt, acknowledgements: none, extra:[], enable-hydra: false, body) = {

  set document(author: authors, title: title)
  set page(numbering: alt_numbering, number-align: center, header: context {
      if calc.odd(here().page()) and enable-hydra {
        align(right, emph(hydra(1, skip-starting: true, book:true)))
      } else if calc.even(here().page()) and enable-hydra {
        align(left, emph(hydra(2, skip-starting: true, book:true)))
      }
    })

  set par(justify: true, linebreaks: "optimized")
  set text(size: fontsize, font: "New Computer Modern", lang:language, hyphenate: false)
  set footnote(numbering: "(1)")
  show: equate.with(breakable: true, sub-numbering: true)
  show math.equation: set text(weight: 400)
  set math.equation(numbering: "(1)")
  if language == "fr" {
    set math.equation(supplement: "Équation")
  }
  else if language == "en" {
    set math.equation(supplement: "Equation")
  }
  set heading(numbering: numbered)
  show bibliography: set heading(numbering: "1")

  if figures != none {
    if figures.len() == 2 {
      place(left+top, figures.at(0))
      place(right+top, figures.at(1))
      v(10%)
    }
    else {
      grid(
        columns: (1fr,) * calc.min(2, figures.len()),
        gutter: 1em,
        ..figures.map(figures => align(center, figure(figures))))
      v(3%)
    }
  }

  // Title row.
  align(center)[
    #v(10%)
    #line(length: 100%)
    #v(5%)
    #block(text(weight: 700, 18pt, smallcaps(title)))
    #if subtitle != none {
      v(2%)
      block(text(weight: 100, 15pt, subtitle))
    }
    #v(5%)
    #line(length: 100%)
    #grid(columns: (1fr, 1fr),
      align(left)[#text(size: 15pt)[Université de Liège]],
      align(right)[#text(size: 15pt)[Faculté des Sciences Appliquées]]
    )
  ]

  // Author information.
  pad(
    top: 4em,
    bottom: 0em,
    x: 2em,
    grid(
      columns: (1fr,) * calc.min(3, authors.len()),
      gutter: 1em,
      ..authors.map(author => align(center, block(text(author, 18pt)))),
    ),
  )

  v(4em)

  if acknowledgements != none {
    align(center, text(acknowledgements, 15pt))
    v(5em)
  }

  
  if date != none {
    align(center, text("---  " + date + "  ---", 15pt))
  }

  if endnote != none {
    place(bottom, dy:-3%, text(endnote, 15pt, luma(100)))
  }

  pagebreak()

  extra
  
  pagebreak()

  if outlined {
    outline(depth: 3)
  }
  
  counter(figure.where(kind: image)).update(0)

  // set page(numbering: "1")

  body
}


#let booklet(figures, title: "Title", subtitle: "Subtitle", authors: ("Author 1", "Author 2", "..."), date: "Date", language: "en", numbered: "1.1", outlined: true, endnote: none, alt_numbering:"I", n_col:1, fontsize: 11pt, body) = {
  
  set document(author: authors, title: title)
  set page(numbering: alt_numbering, number-align: center)
  set par(justify: true, linebreaks: "optimized")
  set text(size: fontsize, font: "New Computer Modern", lang:language, hyphenate: false)
  set footnote(numbering: "(1)")
  show math.equation: set text(weight: 400)
  set math.equation(numbering: "(1)")
  if language == "fr" {
    set math.equation(supplement: "Équation")
  }
  else if language == "en" {
    set math.equation(supplement: "Equation")
  }
  set heading(numbering: numbered)
  show bibliography: set heading(numbering: "1")
  show link: it => underline(text(blue)[#it])
  show heading: it => {
    
  }

  v(3%)

  if figures != none {
    grid(
      columns: (1fr,) * calc.min(2, figures.len()),
      gutter: 1em,
      ..figures.map(figures => align(center, figure(figures))))
  }

  // Title row.
  align(center)[
    #v(10%)
    #line(length: 100%)
    #v(5%)
    #block(text(weight: 700, 16pt, smallcaps(title)))
    #if subtitle != none {
      v(2%)
      block(text(weight: 100, 15pt, subtitle))
    }
    #v(5%)
    #line(length: 100%)
  ]

  // Author information.
  pad(
    top: 6em,
    bottom: 0em,
    x: 2em,
    grid(
      columns: (1fr,) * calc.min(3, authors.len()),
      gutter: 1em,
      ..authors.map(author => align(center, block(text(author, 15pt)))),
    ),
  )

  v(6em)
  
  if date != none {
    align(center, text("---  " + date + "  ---", 15pt))
  }

  if endnote != none {
    place(bottom, dy:-3%, text(endnote, 15pt, luma(100)))
  }

  pagebreak()

  text(" ")
  
  pagebreak()

  if outlined {
    outline(depth: 3, indent: true)
    pagebreak(to: "odd")
  }
  
  set page(numbering: "1")

  counter(figure.where(kind: image)).update(0)
  
  columns(n_col, body)
}