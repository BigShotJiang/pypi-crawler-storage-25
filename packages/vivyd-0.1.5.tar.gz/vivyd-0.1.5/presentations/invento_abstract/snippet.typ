#import "template.typ": *

#set par(spacing: -1em, leading: 0.4em)

#myblock(py(
"from vivyd import modeling, integration, stochastic, postprocessing, database

model   = modeling.Tamura(...)
noise   = stochastic.NoiseGenerator(psd=stochastic.WhiteNoise())

result  = integration.euler_explicit(t_tab=..., model, noise)

dataset = database.load(query='ULiege_expELIArmus')

fig = postprocessing.plot_compare(result, dataset)
"))