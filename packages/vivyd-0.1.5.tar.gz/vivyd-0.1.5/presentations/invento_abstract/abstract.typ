#import "../template.typ": *


#show: body => {
    set document(author: ("Tom BERTRAND",), title: [VIVyD: Open Python code for simulating vortex induced vibrations])
    set page(numbering: "1", number-align: center)
    set par(justify: true, linebreaks: "optimized", spacing: 2em)
    set text(size: 10pt, font: "New Computer Modern", lang:"en", hyphenate: false)
    set footnote(numbering: "(1)")
    show: equate.with(breakable: true, sub-numbering: true)
    show math.equation: set text(weight: 400)
    set math.equation(numbering: "(1.1)", supplement: "Equation")
    set cite(style: "alphanumeric")
    set list(marker: [---])
    show heading: set block(below: 1em)
    body
}

#abbr.make(
  ("SLIP", "Spring-Loaded Inverted Pendulum"),
  ("ACoM", "Anatomical Center of Mass"),
  ("ICoM", "Instantaneous Center of Mass"),
  ("GRF", "Ground Reaction Force"),
  ("HSI", "Human-Structure Interaction"),
  ("PCA", "Principal Component Analysis"),
  ("DoF", "Degree of Freedom", "Degrees of Freedom"),
  ("PSD", "Power Spectral Density")
)

#let FIG_PATH = "../../figures/"

#let fig(source, width: auto, height: auto, caption: none) = figure(image(FIG_PATH+source, width: width, height: height), caption: caption)

#show figure.caption: it => [
  *#it.supplement*
  *#{context it.counter.display(it.numbering)}*:
  #it.body
]

#place(top + center, scope: "parent", float: true,)[
  #text(size: 15pt, weight: "bold")[VIVyD: Open source Python code for simulating vortex induced vibrations]
  #v(0.5em)
  #text(size:12pt)[Tom Bertrand]#super[_a,b_],
  #text(size:12pt)[Vincent Denoël]#super[_a_]
  #v(1.0em)
  #text(size:8pt)[#super[_a_] Structural & Stochastic Dynamics, University of Liège]\
  #text(size:8pt)[#super[_b_] F.R.S.-FNRS, National Fund for Scientific Research, Belgium]
  #v(1.5em)
]

