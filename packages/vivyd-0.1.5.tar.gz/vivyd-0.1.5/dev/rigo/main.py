from datetime import datetime

from vivyd.data import *
from scipy.io import loadmat
import numpy as np
from pathlib import Path
import matplotlib.pyplot as plt
from instrumentation import StudyBuilder
import quantities as units


import taichi as ti

ti.init(arch=ti.gpu)



DATA_PATH = Path(__file__).parents[2] / "data"
DATA_FILE = lambda i: DATA_PATH / f"rigo/datagrid{i}_el1.mat"


def make_study_sequence(filename: Path | str) -> list[Study]:
    
    ping = (
        StudyBuilder(
            Study(
                name = "ping",
                info = {
                    "description": "A ping test is performed, in which the cylinder is manually displaced in the y-direction and released in order to identify the modal properties of the structure.",
                }
            ),
            filename
        ).add_experiment(
            name = "ping",
            info = {
                "description": "A ping test is performed, in which the cylinder is manually displaced in the y-direction and released in order to identify the modal properties of the structure.",
            },
            idx = 0
        ).build()
    )
    
    sweep_builder = StudyBuilder(
        Study(
            name = "sweep",
            info = {
                "description": "A sweep test is performed, in which the cylinder is subjected to a range of wind speeds to identify the dynamic response of the structure. The data structure respects the chronological order in which the wind speeds are applied, which is not necessarily in uniformly ascending or descending order.",
            }
        ),
        filename
    )
    
    for idx in range(1, sweep_builder.len):
        sweep_builder.add_experiment(
            name = f"{idx - 1}",
            info = {
                "description": f"Response of the system at wind speed {sweep_builder.get_mean_speed(idx):.2f} m/s.",
            },
            idx = idx
        )
    
    sweep = sweep_builder.build()
    
    return [ping, sweep]
    

def make_dataset() -> DataSet:

    d = DataSet(
        
        name = """
            VIV on a spring-mounted cylinder in cross-flow @ Wind Tunnel of ULiège 2020
        """,

        info = {
            "setup": """
                The wind tunnel set-up developed in the present study consists in a smooth circular cylinder suspended vertically and free to oscillate horizontally. This PVC cylinder has an external diameter of D = 10 cm, a thickness e = 3 mm and a length L = 1440 mm. It is supported by extension springs connected to a rigid frame attached to the ceiling and the ground of the test section of the Wind Tunnel Laboratory of University of Liège. The bending stiffness in the horizontal direction is equal to 6155 N/m, elastomers are added and a wind-off analysis showed a natural frequency of f0 = 7.8 Hz and a damping ratio of ξ = 0.1%. An illustration of the set-up comes along with this file, under the name "setup.jpg".
            """,
            "data": """
                The velocity is measured with a Pitot tube, while the cylinder's trransverse horizontal displacement is measured with a laser. The 3D flow velocity in the wake of the model is measured with a cobra probe synchronously with the cylinder displacement measured with the laser. At mid-span, 36 pressure taps are distributed evenly around the circumference of the cylinder. The dataset contains four studies, each of them corresponding to different turbulence conditions in the incoming flow: no turbulence grid, and then 3 different turbulence grids with varying meshes.
            """,
            "publication": """
                This dataset was used in the following publication: F. Rigo, T. Andrianne, and V. Denoël, “Parameter identification of wake-oscillator from wind tunnel data,” Journal of Fluids and Structures, vol. 109, p. 103474, Feb. 2022, doi: 10.1016/j.jfluidstructs.2021.103474.
            """
        },

        authors = [
            Author(
                firstname   = "François",
                lastname    = "RIGO",
                email       = "",
                institution = "Strutural & Stochastic Dynamics, University of Liège",
            ),
            Author(
                firstname   = "Vincent",
                lastname    = "DENOËL",
                email       = "v.denoel@uliege.be",
                institution = "Structural & Stochastic Dynamics, University of Liège"
            ),
            Author(
                firstname   = "Thomas",
                lastname    = "ANDRIANNE",
                email       = "t.andrianne@uliege.be",
                institution = "Wind Tunnel Lab, University of Liège"
            )
        ],

        site = Site(
            name        = "Wind Tunnel of ULiège",
            location    = "Liège, Belgium",
            institution = "University of Liège"
        )
    ).add(
        Study(
            name = "grid_off",
            info = {
                "description": "No turbulence grid is used, such that the oncoming flow is uniform",
            }
        ).add(
            *make_study_sequence(DATA_FILE(0))
        )
    ).add(
        Study(
            name = "grid_1",
            info = {
                "description": "...",   #TODO
            }
        ).add(
            *make_study_sequence(DATA_FILE(1))
        )
    ).add(
        Study(
            name = "grid_2",
            info = {
                "description": "...",   #TODO
            }
        ).add(
            *make_study_sequence(DATA_FILE(2))
        )
    ).add(
        Study(
            name = "grid_3",
            info = {
                "description": "...",   #TODO
            }
        ).add(
            *make_study_sequence(DATA_FILE(3))
        )
    )
    
    
    return d

if __name__ == "__main__":
    
    dataset = make_dataset()
    dataset.save(DATA_PATH / "rigo/dataset.vxp")
    
    with open(DATA_PATH / "rigo/dataset.json", "w") as f:
        f.write(dataset.to_json(indent=4))