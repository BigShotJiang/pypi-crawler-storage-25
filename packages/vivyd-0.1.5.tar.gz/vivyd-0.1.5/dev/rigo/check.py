from utils import *
import vivyd as vd

from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt


DATA_PATH = Path(__file__).parents[2] / "data"

d = vd.data.DataSet.load(DATA_PATH / "rigo/dataset.vxp")

# d.print_json()

v_tab = []
s_tab = []
fy_tab = []
fp_tab_tab = []

fig, ax = plt.subplots(2, 2)
ax = ax.flatten()

for grid_idx, (grid_name, grid) in enumerate(d):
    print(f"Grid {grid_name}")
    color = f"C{grid_idx}"
    for study_idx, (study_name, study) in enumerate(grid):
        print(f"  Study {study_name}")
        for exp_idx, (exp_name, exp) in enumerate(study):
            if exp_idx == 0:
                continue
            ax[grid_idx].plot(exp_idx, exp["wind"]["pitot"]["u"].data.mean(), "o", color=color)  # Example plot, replace with actual data visualization

plt.show()

# study = d["sweep"]

# for exp_idx, exp in study:
#     v = exp["wind_speed"]["pitot"]["u"].data
#     v_tab.append(v.mean())
    
#     y = exp["displacement"]["..."]["y"].data
#     s_tab.append(y.std())
    
#     t = exp["displacement"]["..."]["y"].time
#     f  = np.fft.rfftfreq(len(y), d=t[1] - t[0])
    
#     ry = np.fft.rfft(y)
#     fy_tab.append(f[np.argmax(np.abs(ry[1:])) + 1])  # Skip the zero-frequency component, which is usually dominant but not informative about the dynamics of the system.
    
#     get_cp = lambda i: exp["pressure"]["..."][f"cp_{i}"].data
#     fp_tab_tab.append([])
#     for i in range(36):
#         rp = np.fft.rfft(get_cp(i))
#         fp_tab_tab[-1].append(f[np.argmax(np.abs(rp[1:])) + 1])  # Skip the zero-frequency component, which is usually dominant but not informative about the dynamics of the system.
        
#     # plt.plot(f, np.abs(ry))
#     # plt.show()

# fig, ax = plt.subplots(ncols=3)
# ax[0].plot(v_tab, s_tab, "o-")
# ax[0].set_xlabel("Wind Speed [m/s]")
# ax[0].set_ylabel("Displacement Std Dev [m]")
# ax[1].plot(v_tab, fy_tab, "o-")
# ax[1].set_xlabel("Wind Speed [m/s]")
# ax[1].set_ylabel("Dominant Frequency [Hz]")
# for i in range(36):
#     ax[2].plot(v_tab, np.array(fp_tab_tab)[:, i], "o-")
#     ax[2].set_xlabel("Wind Speed [m/s]")
#     ax[2].set_ylabel("Pressure Frequency [Hz]")
# plt.show()