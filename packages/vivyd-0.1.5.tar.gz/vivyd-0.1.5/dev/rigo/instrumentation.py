from __future__ import annotations

from datetime import datetime

from vivyd.data import *
import quantities as units
from pathlib import Path
from scipy.io import loadmat


class StudyBuilder:
    
    def __init__(self, study: Study, file_path: Path | str):
        
        self._study     = study
        
        if isinstance(file_path, str):
            file_path = Path(file_path)
        self.file_path  = file_path
        
        self._data      = loadmat(str(self.file_path), squeeze_me=True)
        self.t          = self._data["data"]["t"]
        self.cp         = self._data["data"]["cp"]
        self.U          = self._data["data"]["U"]
        self.y          = self._data["data"]["y"]
        self.u          = self._data["data"]["u"]
        self.v          = self._data["data"]["v"]
        self.w          = self._data["data"]["w"]
        
        self.len = 0
        for key in ["t", "cp", "U", "y", "u", "v", "w"]:
            if self.len == 0:
                self.len = len(self._data["data"][key])
            else:
                assert self.len == len(self._data["data"][key]), f"All data arrays should have the same length, but {key} has length {len(self._data['data'][key])} instead of {self.len}."

    def add_experiment(self, name: str, info: dict[str, str], idx: int) -> StudyBuilder:
        self._study.add(
            exp := Experiment(
                name = name,
                info = info,
                date = datetime(2020, 4, 10)
            )
        )
            
        exp.add(
            Bundle(
                name = "displacement",
                info = {
                    "description": "The signals related to the transverse cross-axis horizontal displacement of the cylinder in the y-direction."
                }
            ).add(
                Source(
                    name = "laser",
                    info = {
                        "description": "A laser is used to measure the transverse cross-axis horizontal displacement of the cylinder in the y-direction.",
                        "manufacturer": "SICK",
                        "model": "OD2-P300W200I0",
                        "url": "https://www.sick.com/media/pdf/5/15/915/dataSheet_OD2-P300W200I0_6048912_en.pdf"
                    }
                ).add(
                    Signal(
                        name="y",
                        data=self.y[idx],
                        time=self.t[idx],
                        units=units.m
                    )
                )
            )
        )
        
        if idx != 0:  # No wind for the ping experiment, so no wind speed or pressure measurements
            exp.add(
                Bundle(
                    name = "wind",
                    info = {
                        "description": "The wind speeds measured by the Pitot tube and Cobra probe."
                    }
                ).add(
                    Source(
                        name = "pitot",
                        info = {
                            "description": """
                                The constant wind speed measured by a Pitot tube in the test section of the wind tunnel. For wind speeds lower than 3 m/s, the Pitot tube is not able to measure the wind speed.
                            """,
                            "manufacturer": "KIMO Instruments",
                            "model": "Pitot tube NPL type L",
                            "url": "https://kimo-instruments.com/en-INT/measuring-instruments/transmitters/probes/pitot-tubes-type-l"
                        }
                    ).add(
                        Signal(
                            name="u",
                            data=self.U[idx],
                            time=self.t[idx],
                            units=units.m / units.s
                        )
                    )
                ).add(
                    Source(
                        name = "cobra",
                        info = {
                            "description": """
                                This probe is used to measure the 3D flow velocity in the wake of the cylinder. It is located at one diameter downstream of the cylinder.
                            """,
                            "manufacturer": "Turbulent Flow Instrumentation",
                            "model": "Series 100 Cobra Probe",
                            "url": "https://manualzz.com/doc/30332101/getting-started---cobra-probe---turbulent-flow-instrument"
                        }
                    ).add(
                        Signal(
                            name="u",
                            data=self.u[idx],
                            time=self.t[idx],
                            units=units.m / units.s
                        )
                    ).add(
                        Signal(
                            name="v",
                            data=self.v[idx],
                            time=self.t[idx],
                            units=units.m / units.s
                        )
                    ).add(
                        Signal(
                            name="w",
                            data=self.w[idx],
                            time=self.t[idx],
                            units=units.m / units.s
                        )
                    )
                )
            ).add(
                Bundle(
                    name = "pressure",
                    info = {
                        "description": "The signals related to the pressure measurements around the cylinder at mid-span."
                    }
                ).add(
                    Source(
                        name = "pressure_taps",
                        info = {
                            "description": "36 pressure taps are distributed evenly around the circumference of the cylinder at mid-span.",
                            "manufacturer": "Turbulent Flow Instrumentation",
                            "model": "Dynamic Pressure Measurement System, 128 channels",
                            "url": "https://www.turbulentflow.com.au/Products/DPMS/DPMS.php"
                        }
                    ).add(
                        *(
                            Signal(
                                name=f"{sensor_idx}",
                                data=self.cp[idx][sensor_idx],
                                time=self.t[idx],
                                units=units.Pa
                            )
                            for sensor_idx in range(len(self.cp[idx]))
                        )
                    )
                )
            )
            
        return self
    
    def build(self) -> Study:
        return self._study
    
    def get_mean_speed(self, idx: int) -> float:
        return self.U[idx].mean()