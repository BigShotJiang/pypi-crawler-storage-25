from utils import *
import vivyd as vd

from pathlib import Path
import matplotlib.pyplot as plt
import numpy as np
from scipy.optimize import curve_fit
from scipy.signal import butter, filtfilt
from tqdm import tqdm

vd.use_taichi()


DATA_PATH = Path(__file__).parents[1] / "data"


elia = vd.data.DataSet.load(DATA_PATH / "elia/cylinder/dataset.vxp")
print(elia.info)


#%% PING TEST

# t_ping = elia["ping_start"]["y"]["force"]["6DOF sensor"]["Fy"].time
# y_ping = elia["ping_start"]["y"]["force"]["6DOF sensor"]["Fy"].data

# crop = (t_ping > 0.0) & (t_ping < 15.0)
# t_ping = t_ping[crop] - t_ping[crop][0]
# y_ping = y_ping[crop] - y_ping[crop].mean()

# def model(t, A, f, xi, phi):
#     return A * np.exp(-xi * 2 * np.pi * f * t) * np.cos(2 * np.pi * f * t + phi)
# p_opt, _ = curve_fit(model, t_ping, y_ping, p0=[0.5, 1.0, 0.01, 0.0])

# print(p_opt)

# plt.plot(t_ping, y_ping)
# plt.plot(t_ping, model(t_ping, *p_opt))
# plt.xlabel("Time [s]")
# plt.ylabel("Force [N]")
# plt.show()

# filter_butter = butter(4, (120.0, 130.0), fs=1/(t_ping[1] - t_ping[0]), btype="bandpass")
# y_ping_filtered = filtfilt(*filter_butter, y_ping)
# fft_y = np.fft.rfft(y_ping_filtered)
# fft_freq = np.fft.rfftfreq(len(y_ping_filtered), d=(t_ping[1] - t_ping[0]))
# plt.plot(fft_freq, np.abs(fft_y))
# plt.xlabel("Frequency [Hz]")
# plt.ylabel("Amplitude")
# plt.show()

# plt.plot(t_ping, y_ping_filtered)
# plt.xlabel("Time [s]")
# plt.ylabel("Force [N]")
# plt.show()


#%% AMPLITUDE RESPONSE CURVE

# v_tab = []
# s_tab = []
# for exp_idx, exp in elia["sweep_up"]:
#     t = exp["force"]["6DOF sensor"]["Fy"].time
#     y = exp["force"]["6DOF sensor"]["Fy"].data
#     y = y - y.mean()
    
#     v = exp["wind_speed"]["prompted"]["u"].data
#     v_tab.append(v)
    
#     s = y.std()
#     s_tab.append(s)
    
# plt.plot(v_tab, s_tab, "o-")
# plt.xlabel("Wind Speed [m/s]")
# plt.ylabel("Force Std Dev [N]")
# plt.title("Amplitude Response Curve")
# plt.show()



# tam = vd.models.TamuraModel(
#     # xi    = p_opt[2],
#     # diam  = 0.024,
#     # f0    = p_opt[1],
#     # m_lin = 0.14,
#     # v     = 1.0
# )

# solver = vd.solvers.EulerExplicit(verbose=False)
# dt = 0.0001
# nt = 10_000_000
# n_keep = 4_000_000
# t_tab = np.arange(0.0, nt) * dt
# state0 = np.array([0.0, 0.05, 0.0, 0.0])

# # psd_tab = [
# #     vd.excitation.NoiseGenerator.none(),
# #     vd.excitation.NoiseGenerator.none(),
# #     vd.excitation.NoiseGenerator.white(s=0.001),
# #     vd.excitation.NoiseGenerator.none()
# # ]

# # noise_gen = vd.excitation.NoiseGenerator(n=nt, dt=dt, psd_tab=psd_tab)

# v_plot = np.arange(0.8, 1.4+0.005, 0.005)
# st_tab = []
# f_max = 500.0
# fft_max_freq = []
# for v in tqdm(v_plot):
#     tam.v = v
#     result = solver.run(tam, t_tab, state0)
#     y_tab = result[:, 1] * tam.diam
#     t_tab = t_tab / (2 * np.pi * tam.f0)

#     crop  = slice(-n_keep, None)
#     t_tab = t_tab[crop] - t_tab[crop][0]
#     y_tab = y_tab[crop]
    
#     st_tab.append(y_tab.std())
    
#     freqs = np.fft.rfftfreq(len(y_tab), d=(t_tab[1] - t_tab[0]))
#     fft_tab = np.log(np.abs(np.fft.rfft(y_tab))**2)
#     fft_max_idx = np.argmax(fft_tab[1:]) + 1
#     fft_max_freq.append(freqs[fft_max_idx])
    
# # plt.plot(v_plot, fft_max_freq, "o-", label="Tamura Model")
    
# plt.plot(v_plot, st_tab, "o-", label="Tamura Model")
# plt.show()

# # plt.imshow(fft_tab, aspect="auto", origin="lower")
# # plt.show()

# # plt.plot(t_tab, y_tab)
# # plt.xlabel("Time [s]")
# # plt.ylabel("Position [m]")
# # plt.title("Tamura Model Simulation")
# # plt.show()



from utils import *

from numpy import arange
from numpy.fft import rfft, rfftfreq
import matplotlib.pyplot as plt
import numpy as np

import vivyd as vd


vd.use_taichi()

    
omega_tab = arange(14.0, 20.0+0.005, 0.05)

tam = vd.models.TamuraModel(
    xi    = 0.015,
    diam  = 0.024,
    f0    = 124.5,
    m_lin = 0.14,
    v     = 1.0
)
fdb = vd.models.FacchinettiDelangreBiolleyModel()
hc  = vd.models.HartlenCurrieModel(
    xi    = 0.015,
    diam  = 0.024,
    f0    = 124.5,
    m_lin = 0.14,
    v     = 1.0
)

dt = 0.005
n = 8_000_000
n_transient = 4_000_000

t_tab  = np.arange(0.0, n) * dt
state0 = np.array([0.0, 0.2, 0.0, 0.0])

solver = vd.solvers.EulerExplicit(verbose=False)

freq_tab_all = []
for model in [tam, hc]:
    print(f"Computing amplitude response curve for {model.__class__.__name__}...")
    freq_tab = []
    for omega in omega_tab:
        model.v = omega
        result  = solver.run(model, t_tab, state0)
        y_tab   = result[:, 1]
        y = y_tab[n_transient:]
        yf = rfft(y)
        xf = rfftfreq(y.shape[0], dt) * 2 * np.pi
        idx_peak = np.abs(yf).argmax()
        freq_tab.append(xf[idx_peak])
        print(f"Omega: {omega:.3f}, Frequency: {xf[idx_peak]:.4f}")
    freq_tab_all.append(freq_tab)
    
freq_tab_all = np.array(freq_tab_all)

for freq_tab, label in zip(freq_tab_all, ['Tamura', 'Facchinetti-Delangre-Biolley', 'Hartlen-Currie']):
    plt.plot(omega_tab, freq_tab, label=label)
    
plt.xlabel('Dimensionless wind speed: $\\Omega$ [-]')
plt.ylabel('Shedding frequency: $f_s$ [-]')
plt.title('Lock-in Curve')
plt.legend()
plt.savefig(FIG_PATH / 'lock_in_curve.pdf')
plt.close()