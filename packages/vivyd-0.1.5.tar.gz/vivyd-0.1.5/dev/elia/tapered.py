from __future__ import annotations

from vivyd.data.dataset import *

from pathlib import Path
from instrumentation import StudyBuilder


def make_dataset() -> DataSet:

    d = DataSet(
        
        name = """
            VIV on a slender truncated cone (or tapered cylinder) in cross-flow @ Wind Tunnel of ULiège 2026
        """,

        info = {
            "setup": """
                The setup consists of a slightly tapered hollow cylinder made of PLA, with height 84 cm, base diameter 2.02 cm, tip diameter 0.5 cm, and variable shell thickness,
                so as to reproduce a 1:26 downscaled version of an existing lightning mast. The plans of the structure come along with this file, under the name "blueprint.pdf".
                The tapered cylinder is mounted vertically in the middle of the test section of the wind tunnel at the University of Liège, Belgium.
                The top of the tapered cylinder is free (with closed tip, to avoid flow inside the tapered cylinder), and the bottom is clamped (glued) to a rigid support.
                The rigid support contains a 6-DOF load cell, which measures the forces and moments at the base of the tapered cylinder.
                The inflow wind conditions are assumed uniform and the air speed is monitored with a Pitot tube.
                We assume that the flow direction is the x-axis, the z-axis is the upward vertical axis and the y-axis such that the system is right-handed.
            """,
            "data": """
                The dataset contains the measurements of the forces and moments at the base of the tapered cylinder under different flow conditions.
                Chronologically, the dataset contains the following experiments:
                [1] a ping test (start), [2] a sweep-up test, [3] a sweep-down test, and [4] a second ping test (end).
            """,
            "presentation": "The dataset was used as a basis for a presentation by J. Zeoli at the 2026 In-Vento conference"
        },

        authors = [
            Author(
                firstname   = "Juliette",
                lastname    = "ZEOLI",
                email       = "j.zeoli@uliege.be",
                institution = "Structural & Stochastic Dynamics, University of Liège"
            ),
            Author(
                firstname   = "Tom",
                lastname    = "BERTRAND",
                email       = "tom.bertrand@uliege.be",
                institution = "Structural & Stochastic Dynamics, University of Liège",
                info        = {
                    "funding": "F.R.S.-FNRS, National Fund for Scientific Research, Belgium"
                }
            ),
            Author(
                firstname   = "Édouard",
                lastname    = "VERSTRAELEN",
                email       = "everstraelen@uliege.be",
                institution = "Wind Tunnel Lab, University of Liège"
            ),
            Author(
                firstname   = "Vincent",
                lastname    = "DENOËL",
                email       = "v.denoel@uliege.be",
                institution = "Structural & Stochastic Dynamics, University of Liège"
            )
        ],

        site = Site(
            name        = "Wind Tunnel of ULiège",
            location    = "Liège, Belgium",
            institution = "University of Liège"
        )
    )

    ping_start = (
        StudyBuilder(
            study=Study(
                name = "ping_start",
                info = {
                    "description": "The tip of the tapered cylinder is manually displaced and released, to identify the natural frequencies of the system.",
                }
            ),
            path_base=Path.cwd() / "data/WT_test/Day3/Ping/StartPing"
        ).add_experiment(
            name = "x",
            info = {
                "description": "The tip of the tapered cylinder is displaced in the x-direction before release.",
            },
            ref = "data_0"
        ).add_experiment(
            name = "y",
            info = {
                "description": "The tip of the tapered cylinder is displaced in the y-direction before release.",
            },
            ref = "data_1"
        ).build()
    )
    d.add(ping_start)

    ping_end = (
        StudyBuilder(
            study=Study(
                name = "ping_end",
                info = {
                    "description": """
                        The tip of the tapered cylinder is manually displaced and released, to identify the natural frequencies of the system.
                        This experiment is performed at the end of the test campaign, to check for any changes in the system's natural frequencies caused by the tests.
                        No such changes were observed, confirming the constance of the system's properties throughout the test campaign.
                    """,
                }
            ),
            path_base=Path.cwd() / "data/WT_test/Day3/Ping/EndPing"
        ).add_experiment(
            name = "x",
            info = {
                "description": "The tip of the tapered cylinder is displaced in the x-direction.",
            },
            ref = "data_0"
        ).add_experiment(
            name = "y",
            info = {
                "description": "The tip of the tapered cylinder is displaced in the y-direction.",
            },
            ref = "data_1"
        ).build()
    )
    d.add(ping_end)

    sweep_up_builder = (
        StudyBuilder(
            study=Study(
                name = "sweep_up",
                info = {
                    "description": "The flow velocity is gradually increased from 1 m/s (index i = 0) to 20 m/s (index i = 95) with steps of 0.2 m/s.",
                    "keys": "Each experiment is referenced with the index i defined in the 'description' field."
                }
            ),
            path_base=Path.cwd() / "data/WT_test/Day3/SweepUp"
        )
    )
    for i in range(96):
        sweep_up_builder.add_experiment(
            name = f"{i}",
            info = {},
            ref = f"data_{i}"
        )
    sweep_up = sweep_up_builder.build()
    d.add(sweep_up)

    sweep_down_builder = (
        StudyBuilder(
            study=Study(
                name = "sweep_down",
                info = {
                    "description": "The flow velocity is gradually decreased from 20 m/s (index i = 0) to 1 m/s (index i = 95) with steps of 0.2 m/s.",
                    "keys": "Each experiment is referenced with the index i defined in the 'description' field."
                }
            ),
            path_base=Path.cwd() / "data/WT_test/Day3/SweepDown"
        )
    )
    for i in range(96):
        sweep_down_builder.add_experiment(
            name = f"{i}",
            info = {
                "description": f"The flow velocity is set to {20.0 - i * 0.2:.1f} m/s."
            },
            ref = f"data_{i}"
        )
    sweep_down = sweep_down_builder.build()
    d.add(sweep_down)
    
    return d


if __name__ == "__main__":

    from time import perf_counter
    
    start = perf_counter()
    d = make_dataset()
    end = perf_counter()
    print(f"Creating dataset took {end - start:.2f} seconds.")
    
    start = perf_counter()
    d.save(Path.cwd() / "data/elia/tapered/dataset.vxp", create_dirs=True)
    end = perf_counter()
    print(f"Saving dataset took {end - start:.2f} seconds.")