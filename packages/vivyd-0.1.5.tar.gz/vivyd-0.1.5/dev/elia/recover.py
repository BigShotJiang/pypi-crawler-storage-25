# from vivyd.data import Author, DataSet

# DataSet.download_from_zenodo(
#     record_id = "19693260",
#     output_dir = "./data/elia/cylinder",
#     token      = "2kz6oflL8DoU7jAB8KAhISCqKeIcnjWYNj1xsajlaqwbp3ZlEMasH6ubbZ11",
#     create_dirs = True
# )

# d = DataSet.load("./data/elia/cylinder/dataset.vxp")

# with open("./data/elia/cylinder/old.json", "w") as f:
#     f.write(d.to_json(indent=4))

# for study_name, study in d:
#     if "sweep" in study_name:
#         study.info["description"] += " Each time, enough time (30 s) is given for the flow to stabilize before starting the measurement, which lasts for 45 s."

# d.save("./data/elia/cylinder/dataset_new.vxp")

# with open("./data/elia/cylinder/new.json", "w") as f:
#     f.write(d.to_json(indent=4))