from utils import *
import vivyd as vd

from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt



DATA_PATH = Path(__file__).parents[2] / "data/elia"


def spectrogram(d: vd.data.DataSet, ax):
    
    sweep_up : vd.data.Study = d["sweep_up"]
    
    t, v, fy, sy, f_max = [], [], [], [], []
    for _, exp in sweep_up:
        
        wind_speed = exp["wind_speed"]["prompted"]["u"]
        v.append(wind_speed.data)
        
        force_y = exp["force"]["6DOF sensor"]["Fy"]
        fy.append(force_y.data)
        t.append(force_y.time)
        
        sy.append(np.fft.rfft(force_y.data))
        
        s_max_idx = np.argmax(np.abs(sy[-1])[1:]) + 1
        f_max.append(np.fft.rfftfreq(len(force_y.data), d=(force_y.time[1] - force_y.time[0]))[s_max_idx])
        
    w = np.fft.rfftfreq(len(t[0]), d=(t[0][1] - t[0][0]))
    ax.imshow(np.log(np.abs(sy)), origin="lower", aspect="auto", extent=(w[0], w[-1], v[0], v[-1]), cmap="Blues")
    ax.scatter(f_max, v, color="red", label="Max Frequency")
    ax.set_xlabel("Frequency [Hz]")
    ax.set_ylabel("Wind Speed [m/s]")
    

if __name__ == "__main__":
    
    fig, ax = plt.subplots(ncols=2)
    
    cylinder = vd.data.DataSet.load(DATA_PATH / "cylinder/dataset.vxp")   
    print(cylinder.info)
    spectrogram(cylinder, ax[0])
    
    
    # tapered  = vd.data.DataSet.load(DATA_PATH / "tapered/dataset.vxp")    
    # spectrogram(tapered, ax[1])
    
    plt.show()