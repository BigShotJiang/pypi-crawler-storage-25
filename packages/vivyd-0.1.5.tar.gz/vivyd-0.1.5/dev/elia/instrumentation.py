from __future__ import annotations

from datetime import datetime

from vivyd.data import *
import quantities as units
import numpy as np
from pathlib import Path
from json import loads
from pandas import read_csv
from numpy.typing import NDArray
from functools import cache


class StudyBuilder:
    
    def __init__(self, study: Study, path_base: Path):
        self._study     = study
        self._path_base = path_base
        
    @cache
    def read_datetime(self, ref: str) -> datetime:
        
        file = self._path_base / f"{ref}.Untitled_Fx.json"
        with file.open("r") as f:
            json = loads(f.read())
        return datetime.fromisoformat(json["channel_properties"]["wf_start_time"])
        
    @cache
    def read_prompted_wind_speed(self, ref: str) -> float:
        
        file = self._path_base / f"{ref}.json"
        with file.open("r") as f:
            json = loads(f.read())
            
        return json["airspeed console [m/s]"]
    
    
    @cache
    def read_pitot_wind_speed(self, ref: str) -> float:
        
        file = self._path_base / f"{ref}.json"
        with file.open("r") as f:
            json = loads(f.read())
            
        return json["airspeed pitot2 [m/s]"]
    
    @cache
    def read_signal(self, ref: str, name: str) -> tuple[NDArray[np.float64], NDArray[np.float64]]:
        
        file = self._path_base / f"{ref}.Untitled_{name}.csv"
        df = read_csv(file)
        dt = np.asarray(df["prop_wf_increment"].values)
        time = dt.cumsum() - dt[0]  # Subtract the first value to start at 0
        data = np.asarray(df.iloc[:, 0].values)
        return time, data

    def add_experiment(self, name: str, info: dict[str, str], ref: str) -> StudyBuilder:
        self._study.add(
            Experiment(
                name = name,
                info = info,
                date = self.read_datetime(ref)
            ).add(
                Bundle(
                    name = "wind_speed",
                    info = {
                        "description": "The prompted and measured wind speeds."
                    }
                ).add(
                    Source(
                        name = "prompted",
                        info = {
                            "description": "The prompted wind speed, i.e., the wind speed that the experimenter set on the wind tunnel"
                        }
                    ).add(
                        Value(
                            name = "u",
                            data = self.read_prompted_wind_speed(ref),
                            units = units.m / units.s
                        )
                    )
                ).add(
                    Source(
                        name = "pitot",
                        info = {
                            "description": """
                                The constant wind speed measured by a Pitot tube in the test section of the wind tunnel.
                                For wind speeds lower than 3 m/s, the Pitot tube is not able to measure the wind speed.
                            """,
                            "manufacturer": "KIMO Instruments",
                            "model": "Pitot tube NPL type L",
                            "url": "https://kimo-instruments.com/en-INT/measuring-instruments/transmitters/probes/pitot-tubes-type-l"
                        }
                    ).add(
                        Value(
                            name = "u",
                            data = self.read_pitot_wind_speed(ref),
                            units = units.m / units.s
                        )
                    )
                )
            ).add(
                Bundle(
                    name = "force",
                    info = {
                        "description": "The force measurements at the base of the cylinder."
                    }
                ).add(
                    Source(
                        name = "6DOF sensor",
                        info = {
                            "description": "The 6-DOF load cell that measures the forces and moments",
                            "manufacturer": "ATI Industrial Automation",
                            "model": "F/T Sensor: Gamma",
                            "url": "https://www.ati-ia.com/products/ft/ft_models.aspx?id=Gamma"
                        }
                    ).add(
                        *[
                            Signal(
                                name = name_,
                                time = self.read_signal(ref, name_)[0],
                                data = self.read_signal(ref, name_)[1],
                                units = units.N
                            ) for name_ in ["Fx", "Fy", "Fz"]
                        ],
                        *[
                            Signal(
                                name = name_,
                                time = self.read_signal(ref, name_)[0],
                                data = self.read_signal(ref, name_)[1],
                                units = units.N * units.m
                            ) for name_ in ["Mx", "My", "Mz"]
                        ]
                    )
                )
            )
        )
        return self
    
    def build(self) -> Study:
        return self._study