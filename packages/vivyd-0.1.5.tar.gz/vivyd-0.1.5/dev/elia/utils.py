from matplotlib.pyplot import rcParams
from cycler import cycler
from pathlib import Path

rcParams.update({
    "axes.grid": True,
    "grid.color" : (0.5, 0.5, 0.5, 0.4),
    "figure.figsize": (10, 5),
    "figure.constrained_layout.use": True,
    "font.size": 14,    # for 9pt report
    "axes.labelsize": 14,
    "axes.formatter.use_mathtext" : True,
    "font.family": "serif",
    "font.serif": ["cmr10"],
    "mathtext.fontset": "cm",
    "axes.autolimit_mode": "round_numbers",
    "axes.xmargin": 0,
    "axes.ymargin": 0,   
    "axes.prop_cycle": cycler('color', ['#1f77b4', '#ff7f0e', '#2ca02c',
                                        '#d62728', '#9467bd', '#8c564b',
                                        '#bcbd22', '#17becf', '#7f7f7f',
                                        'darkblue', 'gold', 'salmon',
                                        'teal', '#e377c2', 'tan',
                                        'darkred'])
})

CWD_PATH  = Path(__file__).parents[1]
FIG_PATH  = CWD_PATH / 'figures'
DATA_PATH = CWD_PATH / 'data'