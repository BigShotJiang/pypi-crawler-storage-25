from vivyd.models.tamura import TamuraModel

pass