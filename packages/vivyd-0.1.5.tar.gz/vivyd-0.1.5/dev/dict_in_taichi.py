import taichi as ti
from typing import Sequence, Callable
import numpy as np

from vivyd.typing import arrf64

ti.init(arch=ti.cpu, cpu_max_num_threads=1)

# @ti.data_oriented
# class Excitation:
    
#     def __init__(self, n_states: int):
#         self.n: int = n_states
#         self.x: dict[int, list[tuple[arrf64, arrf64]]] = dict()
        
#     def add(self, idx: int, t: arrf64, x: arrf64):
#         if idx not in self.x:
#             self.x[idx] = []
#         self.x[idx].append((t, x))
        
#     def __add__(self, other: "Excitation") -> "Excitation":
        
#         if not other.n == self.n:
#             raise ValueError("Cannot add excitations with different number of states")
        
#         result = Excitation(self.n)
#         for idx, data in self.x.items():
#             for t, x in data:
#                 result.add(idx, t, x)
#         for idx, data in other.x.items():
#             for t, x in data:
#                 result.add(idx, t, x)
#         return result
    
#     def __call__(self, t: arrf64) -> arrf64:
        
#         x = np.zeros((t.shape[0], self.n), dtype=np.float64)
        
#         for idx, data in self.x.items():
#             for t_i, x_i in data:
#                 x[:, idx] += np.interp(t, t_i, x_i)
        
#         return x

@ti.data_oriented
class Excitation:
    
    def __init__(self, n_states: int):
        self.n: int = n_states
        self.x: dict[int, list[tuple[list[float], list[float]]]] = dict()
        
    def add(self, idx: int, t: list[float], x: list[float]):
        if idx not in self.x:
            self.x[idx] = []
        self.x[idx].append((t, x))
        
    def __add__(self, other: "Excitation") -> "Excitation":
        
        if not other.n == self.n:
            raise ValueError("Cannot add excitations with different number of states")
        
        result = Excitation(self.n)
        for idx, data in self.x.items():
            for t, x in data:
                result.add(idx, t, x)
        for idx, data in other.x.items():
            for t, x in data:
                result.add(idx, t, x)
        return result
        
    def __call__(self, t: arrf64) -> dict[int, arrf64]:
        
        out = {}
        
        for idx, data in self.x.items():
            for t_i, x_i in data:
                if idx not in out:
                    out[idx] = np.zeros_like(t)
                out[idx] += np.interp(t, t_i, x_i)

        return out
    
    @ti.kernel
    def interp_taichi(self, t: arrf64, out: ti.template()):
        for idx, data in self.x.items():
            for t_i, x_i in data:
                for i in range(t.shape[0]):
                    t_i = t[i]

@ti.kernel
def test(n: ti.template()):
    func(n.x)
    
@ti.func
def func(x: ti.template()):
    print(x[0])
            
if __name__ == "__main__":
    excitation = Excitation(3)
    excitation.add(0, [0.0, 1.0, 2.0], [0.0, 1.0, 0.0])
    excitation.add(0, [0.0, 0.5, 2.0], [0.0, 0.0, 1.0])
    excitation.add(2, [0.0, 1.6, 2.0], [1.0, 0.0, 0.0])
    # test(excitation)
    
    print(excitation(np.array([0.0, 0.5, 1.0, 1.5, 2.0])))