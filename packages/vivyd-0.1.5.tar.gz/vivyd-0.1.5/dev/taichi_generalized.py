import numpy as np
from time import perf_counter
import taichi as ti
from typing import Callable
from time import perf_counter


import vivyd as vd

vd.use_taichi(arch=ti.cpu, cpu_max_num_threads=1)


class MyModel:
    def __init__(self, a: float, b: float):
        self.a = a
        self.b = b
        
    def to_taichi(self) -> "MyModelTaichi":
        return MyModelTaichi(a=self.a, b=self.b)


@ti.dataclass
class MyModelTaichi:
    a: ti.f64
    b: ti.f64
    
    @ti.func
    def rhs_func(self, state: ti.types.ndarray(dtype=ti.f64, ndim=1)):
        y_dot = state[0]
        y = state[1]
        q_dot = state[2]
        q = state[3]
                
        return ti.Vector([
            self.a * q,
            y_dot * self.a * self.b,
            self.b * y,
            q_dot,
        ], dt=ti.f64)
        


def get_rhs_collection(models_taichi: ti.StructField, state: np.ndarray) -> np.ndarray:
    
    out = np.zeros((n_models, 4), dtype=np.float64)
    start = perf_counter()
    get_rhs_collection_kernel(models_taichi, state, out)
    end = perf_counter()
    print(f"Time taken: {end - start:.4f} seconds")
    return out

@ti.kernel
def get_rhs_collection_kernel(models: ti.template(), state: ti.types.ndarray(dtype=ti.f64, ndim=1), out: ti.types.ndarray(dtype=ti.f64, ndim=2)):
    for i in range(models.shape[0]):
        print(f"Processing model {i}")
        rhs = models[i].rhs_func(state)
        for j in ti.static(range(4)):
            out[i, j] = rhs[j]
            
@ti.kernel
def get_rhs(model: MyModelTaichi, state: ti.types.ndarray(dtype=ti.f64, ndim=1), out: ti.types.ndarray(dtype=ti.f64, ndim=1)):
    rhs = model.rhs_func(state)
    for j in ti.static(range(4)):
        out[j] = rhs[j] 
        

models = [
    MyModel(a=_a, b=_b) for _a, _b in zip(range(100_000), range(100_000))
]

n_models = len(models)
models_taichi = MyModelTaichi.field(shape=n_models)
for i in range(n_models):
    models_taichi[i] = models[i].to_taichi()

state = np.array([1.0, 0.0, 0.0, 0.0])

out = np.zeros((2, 4), dtype=np.float64)

out = get_rhs_collection(models_taichi, state)

models_taichi = np.zeros(n_models, dtype=object)
for i in range(n_models):
    print(f"Processing model {i}")
    models_taichi[i] = models[i].to_taichi()

start = perf_counter()
for i in range(n_models):
    print(f"Processing model {i}")
    get_rhs(models_taichi[i], state, out[0])
end = perf_counter()
print(f"Time taken for individual calls: {end - start:.4f} seconds")

# print(out)













# model1 = vd.models.TamuraModel().to_taichi().to_dataclass()
# model2 = vd.models.HartlenCurrieModel().to_taichi().to_dataclass()
# omega = 1.0
# model1.v = omega
# model2.v = omega
# # model = model.to_taichi()

# dt    = 0.005
# n     = 20_000_000
# t_tab = np.arange(0.0, n) * dt
# state0 = np.array([0.0, 0.2, 0.0, 0.0])

# solver  = vd.solvers.EulerExplicit(verbose=True)







# start = perf_counter()
# sol   = solver.run(model1, t_tab, state0)
# end   = perf_counter()
# print(f"Time taken: {end - start:.4f} seconds")