import vivyd as vd

import matplotlib.pyplot as plt
import numpy as np


davenport_psd  = vd.excitation.NoiseGenerator.davenport(U0=1, Cd=1, Lu=1)
von_karman_psd = vd.excitation.NoiseGenerator.von_karman(s=1, Lu=1, V=1)

f_tab = np.linspace(-100, 100, 10_000)

plt.plot(f_tab, davenport_psd(f_tab), label="Davenport")
plt.plot(f_tab, von_karman_psd(f_tab), label="von Karman")
plt.xlabel("Frequency (Hz)")
plt.ylabel("PSD")
plt.legend()
plt.show()