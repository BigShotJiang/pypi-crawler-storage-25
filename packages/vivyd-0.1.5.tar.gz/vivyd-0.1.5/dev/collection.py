import numpy as np
import vivyd as vd
from vivyd.models import VIVModel

import matplotlib.pyplot as plt


def mode_shape_matrix(n: int) -> np.ndarray:
    """
    Create an (n x n) mode shape matrix for a 1D fixed–fixed system.

    M[i, k] = sin( (k+1) * (i+1) * pi / (n+1) )

    Columns = modes
    Rows    = spatial points
    """
    i = np.arange(0, n)[:, None]      # spatial index
    k = np.arange(0, n)[None, :]      # mode index

    M = np.sin(np.pi * (k + 1) * i / (n - 1))

    # optional normalization (orthonormal modes)
    M *= np.sqrt(2 / (n + 1))

    return M


class Chain:
    
    def __init__(self, *models: VIVModel):
        
        self.models = models
        self.n      = len(models)
        
        self.state_size = 0
        for m in models:
            if self.state_size == 0:
                self.state_size = m.state_size
            elif self.state_size != m.state_size:
                raise ValueError("Models of chain must have same state size")
            
    def __iter__(self):
        for m in self.models:
            yield m
            

class System:
    def __init__(
        self,
        chain: Chain,
        modal_mass: np.ndarray,
        modal_damping: np.ndarray,
        modal_stiffness: np.ndarray,
        mode_shapes: np.ndarray
    ):
        self.chain = chain
        
        self.state = np.zeros((self.chain.n, self.chain.state_size))
        self.state_flat = self.state.flatten()

        self.m = modal_mass
        self.check_dims_1D(self.m)

        self.c = modal_damping
        self.check_dims_1D(self.c)

        self.k = modal_stiffness
        self.check_dims_1D(self.k)

        self.phi = mode_shapes
        self.check_dims_2D(self.phi)
        self.normalize_mode_shapes()
        
        self.diff = np.zeros_like(self.state)
        
        
    def check_dims_1D(self, mat: np.ndarray):
        if mat.shape != (self.chain.n,):
            raise ValueError(f"Vector must be of shape ({self.chain.n},), got {mat.shape}")

    def check_dims_2D(self, mat: np.ndarray):
        if mat.shape != (self.chain.n, self.chain.n):
            raise ValueError(f"Matrix must be of shape ({self.chain.n}, {self.chain.n}), got {mat.shape}")
        
    def normalize_mode_shapes(self):
        for i in range(self.chain.n):
            norm = np.linalg.norm(self.phi[:, i])
            if norm == 0:
                raise ValueError(f"Mode shape {i} has zero norm, cannot normalize")
            self.phi[:, i] /= norm
    
    def struct_to_struct(self, t: float, state: np.ndarray) -> np.ndarray:
        y_bar_dot  =   self.phi.T @ state[:, 0]
        y_bar      =   self.phi.T @ state[:, 1]
        dy_bar_dot = - self.c / self.m * y_bar_dot - self.k / self.m * y_bar
        dy_dot     =   self.phi @ dy_bar_dot
        return dy_dot
    
    def __call__(self, t: float, state: np.ndarray):        
        
        self.diff[:, :]    = np.array([model(t, state[model_idx]) for model_idx, model in enumerate(self.chain)])
        self.diff[:, 0]   += self.struct_to_struct(t, state)
        
        return self.diff



if __name__ == "__main__":
    
    n = 21
    
    alone = vd.models.TamuraModel(no_dim=True)
    
    chain = Chain(
        *(
            vd.models.TamuraModel(no_dim=True)
            for _ in range(n)
        )
    )
    
    mode_shapes = mode_shape_matrix(n)
    
    for mode_shape in mode_shapes.T:
        plt.plot(mode_shape)
    plt.show()
    
    system = System(chain, np.ones(n), np.ones(n)*1e-4, np.ones(n)*1e-4, mode_shape_matrix(n))
    
    solver = vd.solvers.EulerExplicit(verbose=True)
    
    t_tab = np.linspace(0.0, 1000.0, 150_000)
    state0 = np.zeros((n, 4))
    state0[:, 1] = 0.15
    
    res = solver.run(system, t_tab, state0)
    
    print(res)
    
    for node_idx in range(res.shape[1]):
        plt.plot(res[:, node_idx, 1])
        
    res_alone = solver.run(alone, t_tab, state0[0])
    
    plt.plot(res_alone[:, 1])
        
    plt.show()