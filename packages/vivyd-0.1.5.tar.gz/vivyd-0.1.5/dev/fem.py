from __future__ import annotations

from dataclasses import dataclass, field
from abc import ABC, abstractmethod
import numpy as np
from scipy.linalg import eigh
from numpy.typing import NDArray


@dataclass(frozen=True)
class Position2D:
    x: float
    y: float
    
@dataclass
class Displacement2D:
    u:     float = field(default=0.0)
    v:     float = field(default=0.0)
    theta: float = field(default=0.0)

@dataclass
class Anchoring2D:
    node:   Node2D
    u_lock:   bool = False
    v_lock:   bool = False
    t_lock:   bool = False

@dataclass
class Node2D:
    pos:  Position2D
    disp: Displacement2D = field(default_factory=Displacement2D, init=False)
    
@dataclass
class Link2D(ABC):
    node_lo: Node2D
    node_hi: Node2D
    
@dataclass
class Element2D(Link2D, ABC):
    
    @property
    def length(self) -> float:
        dx = self.node_hi.pos.x - self.node_lo.pos.x
        dy = self.node_hi.pos.y - self.node_lo.pos.y
        return np.sqrt(dx**2 + dy**2)
    
    @property
    @abstractmethod
    def mass_matrix(self) -> NDArray[np.float64]: ...
    
    @property
    @abstractmethod
    def stiffness_matrix(self) -> NDArray[np.float64]: ...
    
    def as_mesh(self) -> Mesh2D:
        mesh = Mesh2D()
        mesh.append_element(self)
        return mesh
    
@dataclass
class Spring2D(Element2D):
    k_u: float = 0.0
    k_v: float = 0.0
    k_t: float = 0.0

    @property
    def mass_matrix(self) -> NDArray[np.float64]:
        return np.zeros((6, 6))
    
    @property
    def stiffness_matrix(self) -> NDArray[np.float64]:
        k_u = self.k_u
        k_v = self.k_v
        k_t = self.k_t
        return np.array([
            [k_u, 0.0, 0.0, -k_u, 0.0, 0.0],
            [0.0, k_v, 0.0, 0.0, -k_v, 0.0],
            [0.0, 0.0, k_t, 0.0, 0.0, -k_t],
            [-k_u, 0.0, 0.0, k_u, 0.0, 0.0],
            [0.0, -k_v, 0.0, 0.0, k_v, 0.0],
            [0.0, 0.0, -k_t, 0.0, 0.0, k_t]
        ])
        
@dataclass
class TorqueSpring2D(Element2D):
    k_t: float
    
    @property
    def mass_matrix(self) -> NDArray[np.float64]:
        return np.zeros((6, 6))
    
    @property
    def stiffness_matrix(self) -> NDArray[np.float64]:
        k_t = self.k_t
        return np.array([
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, k_t, 0.0, 0.0, -k_t],
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, -k_t, 0.0, 0.0, k_t]
        ])
        
    def as_mesh(self) -> Mesh2D:
        mesh = super().as_mesh()
        mesh.connect(
            node_lo=self.node_lo,
            node_hi=self.node_hi,
            u_same=True,
            v_same=True,
            t_same=False
        )
        return mesh
        
@dataclass
class Beam2D(Element2D):
    young:   float
    area:    float
    inertia: float
    rho:     float
    
    @property
    def mass_matrix(self) -> NDArray[np.float64]:
        L = self.length
        m = self.rho * self.area * L
        return (m / 420) * np.array([
            [140.0,     0.0,       0.0,  70.0,     0.0,       0.0],
            [  0.0,   156.0,    22.0*L,   0.0,    54.0,   -13.0*L],
            [  0.0,  22.0*L,  4.0*L**2,   0.0,  13.0*L, -3.0*L**2],
            [ 70.0,     0.0,       0.0, 140.0,     0.0,       0.0],
            [  0.0,    54.0,    13.0*L,   0.0,   156.0,   -22.0*L],
            [  0.0, -13.0*L, -3.0*L**2,   0.0, -22.0*L,  4.0*L**2]
        ])
        
    @property
    def stiffness_matrix(self) -> NDArray[np.float64]:
        L   = self.length
        E   = self.young
        I   = self.inertia
        A   = self.area
        k_a = (E * A) / L
        k_b = (E * I) / (L**3)
        return np.array([
            [ k_a,       0.0,          0.0, -k_a,        0.0,          0.0],
            [ 0.0,  12.0*k_b,    6.0*L*k_b,  0.0,  -12.0*k_b,    6.0*L*k_b],
            [ 0.0, 6.0*L*k_b, 4.0*L**2*k_b,  0.0, -6.0*L*k_b, 2.0*L**2*k_b],
            [-k_a,       0.0,          0.0,  k_a,        0.0,          0.0],
            [ 0.0, -12.0*k_b,   -6.0*L*k_b,  0.0,   12.0*k_b,   -6.0*L*k_b],
            [ 0.0, 6.0*L*k_b, 2.0*L**2*k_b,  0.0, -6.0*L*k_b, 4.0*L**2*k_b]
        ])

@dataclass    
class Connector2D(Link2D):
    u_same: bool = True
    v_same: bool = True
    t_same: bool = True
        
@dataclass
class Mesh2D:
    elements:   list[Element2D]   = field(default_factory=list, init=False)
    connectors: list[Connector2D] = field(default_factory=list, init=False)
    anchorings: list[Anchoring2D] = field(default_factory=list, init=False)
        
    @property
    def nodes(self) -> list[Node2D]:
        if not self.elements:
            return []
        nodes = [self.elements[0].node_lo]
        for elem in self.elements:
            nodes.append(elem.node_hi)
        return nodes
    
    @property
    def node_lookup_table(self) -> dict[int, int]:
        """
        Used to avoid the overhead caused by using list.index() several times
        and to ensure that node identity is used instead of equality.
        """
        return {id(node): i for i, node in enumerate(self.nodes)}
    
    @property
    def start_node(self) -> Node2D:
        if not self.nodes:
            raise ValueError("Cannot access start_node on an empty mesh.")
        return self.nodes[0]
    
    @property
    def end_node(self) -> Node2D:
        if not self.nodes:
            raise ValueError("Cannot access end_node on an empty mesh.")
        return self.nodes[-1]
        
    @property
    def n_elems(self) -> int:
        return len(self.elements)
    
    @property
    def n_nodes(self) -> int:
        if self.n_elems == 0:
            return 0
        return self.n_elems + 1
    
    @property
    def n_dofs(self) -> int:
        return self.n_nodes * 3
    
    @property
    def mass_matrix(self) -> NDArray[np.float64]:
        n_dofs = self.n_nodes * 3
        M = np.zeros((n_dofs, n_dofs))
        for i, elem in enumerate(self.elements):
            m_elem = elem.mass_matrix
            dof_start = i * 3
            dof_end   = dof_start + 6
            M[dof_start:dof_end, dof_start:dof_end] += m_elem
        return M
    
    @property
    def stiffness_matrix(self) -> NDArray[np.float64]:
        K = np.zeros((self.n_dofs, self.n_dofs))
        for i, elem in enumerate(self.elements):
            k_elem = elem.stiffness_matrix
            dof_start = i * 3
            dof_end   = dof_start + 6
            K[dof_start:dof_end, dof_start:dof_end] += k_elem
        return K
    
    @property
    def connections(self) -> NDArray[np.intp]:
        conn_indices = np.arange(self.n_dofs)
        
        node_to_idx = self.node_lookup_table
        
        for connector in self.connectors:
            idx_lo = node_to_idx[id(connector.node_lo)]
            idx_hi = node_to_idx[id(connector.node_hi)]
            
            if connector.u_same:
                master_idx = conn_indices[idx_hi * 3]
                conn_indices[idx_lo * 3] = master_idx
            if connector.v_same:
                master_idx = conn_indices[idx_hi * 3 + 1]
                conn_indices[idx_lo * 3 + 1] = master_idx
            if connector.t_same:
                master_idx = conn_indices[idx_hi * 3 + 2]
                conn_indices[idx_lo * 3 + 2] = master_idx
        
        return conn_indices
    
    def append_element(self, element: Element2D):
        if self.elements:
            node_mesh_end   = self.end_node
            node_elem_start = element.node_lo
            if node_mesh_end != node_elem_start:
                raise ValueError(f"Incompatibility at mesh appending point: {node_mesh_end} is incompatible with {node_elem_start}")
        self.elements.append(element)
        
    @property
    def locked_indices(self) -> NDArray[np.intp]:
        
        node_to_idx = self.node_lookup_table
        
        locked_idx = []
        for anchoring in self.anchorings:
            node = anchoring.node
            node_idx = node_to_idx[id(node)]
            if anchoring.u_lock:
                locked_idx.append(node_idx*3    )
            if anchoring.v_lock:
                locked_idx.append(node_idx*3 + 1)
            if anchoring.t_lock:
                locked_idx.append(node_idx*3 + 2)
                            
        return np.array(locked_idx, dtype=np.intp)
    
    def solve_dynamics(self) -> tuple[NDArray[np.float64], NDArray[np.float64]]:

        M = self.mass_matrix
        K = self.stiffness_matrix
        n_dofs = self.n_dofs
        
        full_to_master = self.connections
        master_dofs = np.unique(full_to_master)
        
        # Construction of reduced matrices
        M_red = np.zeros((n_dofs, n_dofs))
        K_red = np.zeros((n_dofs, n_dofs))
        
        for full_idx, master_idx in enumerate(full_to_master):
            M_red[master_idx, :] += M[full_idx, :]
            M_red[:, master_idx] += M[:, full_idx]
            K_red[master_idx, :] += K[full_idx, :]
            K_red[:, master_idx] += K[:, full_idx]
        
        M_red = M_red[np.ix_(master_dofs, master_dofs)]
        K_red = K_red[np.ix_(master_dofs, master_dofs)]
        
        # Elimination of locked master DOFs
        locked_dofs = self.locked_indices
        locked_master_dofs = np.unique(full_to_master[locked_dofs])
        free_master_dofs = np.setdiff1d(master_dofs, locked_master_dofs)
        free_master_dofs_red = np.searchsorted(master_dofs, free_master_dofs)
        
        M_free_red = M_red[np.ix_(free_master_dofs_red, free_master_dofs_red)]
        K_free_red = K_red[np.ix_(free_master_dofs_red, free_master_dofs_red)]
        
        # Solve eigenvalue problem
        eigvals, eigvecs_free = eigh(K_free_red, M_free_red)
        frequencies = np.sqrt(np.maximum(eigvals, 0.0)) / (2 * np.pi)
        
        # Sort by ascending frequency
        sort_idx = np.argsort(frequencies)
        frequencies = frequencies[sort_idx]
        eigvecs_free = eigvecs_free[:, sort_idx]
        
        # Map eigenvectors back to full system
        eigvecs_master = np.zeros((n_dofs, eigvecs_free.shape[1]))
        eigvecs_master[free_master_dofs, :] = eigvecs_free
        eigvecs_full = eigvecs_master[full_to_master, :]
        
        return frequencies, eigvecs_full
    
    def compute_forces(self, displacements: NDArray[np.float64]) -> NDArray[np.float64]:
        K = self.stiffness_matrix
        forces = K @ displacements
        return forces
    
    def set_nodes(self, displacements: NDArray[np.float64]):
        assert displacements.shape[0] == self.n_dofs, "Displacement array has incorrect size."
        for node_idx, node in enumerate(self.nodes):
            node.disp.u     = displacements[node_idx * 3    ]
            node.disp.v     = displacements[node_idx * 3 + 1]
            node.disp.theta = displacements[node_idx * 3 + 2]
            
    def get_displacement_at(self, x: float) -> Displacement2D:
        for elem in self.elements:
            x_start = elem.node_lo.pos.x
            x_end   = elem.node_hi.pos.x
            if x_start <= x <= x_end:
                L = elem.length
                if L == 0.0: continue
                xi = (x - x_start) / L  # normalized coordinate
                NU1 = 1 - xi
                NU2 = xi
                NV1 = 1 - 3*xi**2 + 2*xi**3
                NV2 = L * (xi - 2*xi**2 + xi**3)
                NV3 = 3*xi**2 - 2*xi**3
                NV4 = L * (-xi**2 + xi**3)
                NT1 = -6*xi/L + 6*xi**2/L
                NT2 = 1 - 4*xi + 3*xi**2
                NT3 = 6*xi/L - 6*xi**2/L
                NT4 = -2*xi + 3*xi**2
                
                u = (NU1 * elem.node_lo.disp.u +
                     NU2 * elem.node_hi.disp.u)
                
                v = (NV1 * elem.node_lo.disp.v +
                     NV2 * elem.node_lo.disp.theta +
                     NV3 * elem.node_hi.disp.v +
                     NV4 * elem.node_hi.disp.theta)
                
                theta = (NT1 * elem.node_lo.disp.v +
                         NT2 * elem.node_lo.disp.theta +
                         NT3 * elem.node_hi.disp.v +
                         NT4 * elem.node_hi.disp.theta)
                
                return Displacement2D(u, v, theta)
        raise ValueError(f"{x=} is out of the range of the mesh.")
        
    def __add__(self, other: Mesh2D) -> Mesh2D:
        
        if self.n_elems == 0:
            return other
        if other.n_elems == 0:
            return self
        
        if self.end_node != other.start_node:
            raise ValueError(f"Incompatibility at mesh merging point: {self.end_node} is incompatible with {other.start_node}")
        
        to_replace = other.start_node
        replacer   = self.end_node
        
        for element in other.elements:
            if element.node_hi == to_replace:
                element.node_hi = replacer
            if element.node_lo == to_replace:
                element.node_lo = replacer
        for connector in other.connectors:
            if connector.node_hi == to_replace:
                connector.node_hi = replacer
            if connector.node_lo == to_replace:
                connector.node_lo = replacer
        for anchoring in other.anchorings:
            if anchoring.node == to_replace:
                anchoring.node = replacer
        
        new_mesh = Mesh2D()
        new_mesh.elements   = self.elements   + other.elements
        new_mesh.connectors = self.connectors + other.connectors
        new_mesh.anchorings = self.anchorings + other.anchorings
        
        return new_mesh
        
    def add_connector(self, connector: Connector2D) -> None:
        self.connectors.append(connector)
        
    def connect(
        self,
        node_lo: Node2D,
        node_hi: Node2D,
        *,
        u_same: bool = True,
        v_same: bool = True,
        t_same: bool = True
    ) -> None:
        self.add_connector(
            Connector2D(
                node_lo=node_lo,
                node_hi=node_hi,
                u_same=u_same,
                v_same=v_same,
                t_same=t_same
            )
        )
        
    def add_anchoring(self, anchoring: Anchoring2D) -> None:
        self.anchorings.append(anchoring)
        
    def anchor(
        self,
        node: Node2D,
        *,
        u_lock: bool = False,
        v_lock: bool = False,
        t_lock: bool = False
    ) -> None:
        self.add_anchoring(
            Anchoring2D(
                node=node,
                u_lock=u_lock,
                v_lock=v_lock,
                t_lock=t_lock
            )
        )