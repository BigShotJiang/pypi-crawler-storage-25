from nptdms import TdmsFile
import pandas as pd
import json
from pathlib import Path
from utils import DATA_PATH

ROOT_PATH = DATA_PATH / "WT_test/Day3"

print(f"Processing TDMS files in {ROOT_PATH}...")

for file in ROOT_PATH.glob("**/*.tdms"):
    FILE_PATH = file.resolve()
    print(f"Processing {FILE_PATH}...")

    tdms = TdmsFile.read(FILE_PATH)

    # --- Save file-level properties once
    with open(FILE_PATH.with_suffix(".json"), "w") as f:
        json.dump(tdms.properties, f, indent=2, default=str)

    for group in tdms.groups():
        for channel in group.channels():
            data = channel[:]

            # Build DataFrame
            df = pd.DataFrame(data, columns=[channel.name])

            # Add properties as extra columns (constant per channel)
            for key, value in channel.properties.items():
                df[f"prop_{key}"] = value

            # Also include group properties
            for key, value in group.properties.items():
                df[f"group_prop_{key}"] = value

            csv_path = FILE_PATH.with_suffix(f".{group.name}_{channel.name}.csv")
            df.to_csv(csv_path, index=False)

            # Save full metadata separately (cleaner)
            meta = {
                "file_properties": tdms.properties,
                "group_properties": group.properties,
                "channel_properties": channel.properties,
            }

            with open(csv_path.with_suffix(".json"), "w") as f:
                json.dump(meta, f, indent=2, default=str)

print("Export complete.")