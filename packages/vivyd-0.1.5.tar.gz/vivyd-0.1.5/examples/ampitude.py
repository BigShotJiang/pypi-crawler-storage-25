from utils import *

from numpy import arange
import matplotlib.pyplot as plt
import numpy as np

import vivyd as vd


vd.use_taichi()


omega_tab = arange(0.8, 1.4+0.005, 0.005)

tam = vd.models.TamuraModel()
fdb = vd.models.FacchinettiDelangreBiolleyModel()
hc  = vd.models.HartlenCurrieModel()

dt = 0.005
n = 8_000_000
n_transient = 4_000_000

t_tab  = np.arange(0.0, n) * dt
state0 = np.array([0.0, 0.2, 0.0, 0.0])

solver = vd.solvers.EulerExplicit(verbose=False)

std_tab_all = []
for model in [tam, fdb, hc]:
    print(f"Computing amplitude response curve for {model.__class__.__name__}...")
    std_tab = []
    for omega in omega_tab:
        model.v = omega
        result  = solver.run(model, t_tab, state0)
        y_tab   = result[:, 1]
        std     = y_tab[n_transient:].std()
        print(f"Omega: {omega:.3f}, Amplitude: {std:.4f}")
        std_tab.append(std)
    std_tab_all.append(std_tab)
    
std_tab_all = np.array(std_tab_all)

for std_tab, label in zip(std_tab_all, ['Tamura', 'Facchinetti-Delangre-Biolley', 'Hartlen-Currie']):
    plt.plot(omega_tab, std_tab, label=label)
    
plt.xlabel('Dimensionless wind speed: $\\Omega$ [-]')
plt.ylabel('Amplitude: $\\sigma_y$ [-]')
plt.title('Amplitude Response Curve')
plt.legend()
plt.savefig(FIG_PATH / 'amplitude_response_curve.pdf')
plt.close()