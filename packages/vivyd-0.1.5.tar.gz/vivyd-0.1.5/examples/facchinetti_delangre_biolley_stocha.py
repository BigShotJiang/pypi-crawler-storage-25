from vivyd.models import FacchinettiDelangreBiolleyModel
from vivyd.excitation import NoiseGenerator
from vivyd.solvers import EulerExplicit

from numpy import array, arange
import matplotlib.pyplot as plt

model = FacchinettiDelangreBiolleyModel()

n  = 200000
dt = 0.001

noise_gen = NoiseGenerator(n=n, dt=dt, psd_tab = (NoiseGenerator.white(s=0.01),))
noise_sample = noise_gen()

t_tab = (arange(n) * dt).astype(float)

state0 = array([0.0, 0.0, 0.0, 0.0])

solution = EulerExplicit(verbose=False).run(model, t_tab, state0, noise_sample)

fig, ax = plt.subplots(nrows=2, sharex=True)
ax[0].plot(t_tab, solution[:, 1])
ax[1].plot(t_tab, solution[:, 3])
ax[0].set_title("Time histories for the Facchinetti-De Langre-Biolley model with white noise")
ax[0].set_ylabel("Structure: $y$ [-]")
ax[1].set_ylabel("Wake: $q$ [-]")
ax[1].set_xlabel("Time: $t$ [s]")
plt.show()