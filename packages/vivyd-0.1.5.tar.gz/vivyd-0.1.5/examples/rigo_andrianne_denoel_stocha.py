from vivyd.models import RigoAndrianneDenoelModel
from vivyd.excitation import NoiseGenerator
from vivyd.solvers import EulerExplicit

from numpy import array, arange
import matplotlib.pyplot as plt

model = RigoAndrianneDenoelModel()

n  = 500000
dt = 0.001

noise_gen = NoiseGenerator(n=n, dt=dt, psd_tab = (NoiseGenerator.white(s=0.01),))
noise_sample = noise_gen()

t_tab = (arange(n) * dt).astype(float)

state0 = array([0.0, 0.0])

solution = EulerExplicit(verbose=False).run(model, t_tab, state0, noise_sample)

fig, ax = plt.subplots()
ax.plot(t_tab, solution[:, 1])
ax.set_title("Time histories for the Rigo-Andrianne-Denoel model with white noise")
ax.set_ylabel("Wake: $q$ [-]")
ax.set_xlabel("Time: $t$ [s]")
plt.show()