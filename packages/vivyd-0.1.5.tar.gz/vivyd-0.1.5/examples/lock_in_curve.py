from utils import *

from numpy import arange
from numpy.fft import rfft, rfftfreq
import matplotlib.pyplot as plt
import numpy as np

import vivyd as vd


vd.use_taichi()

    
omega_tab = arange(0.8, 1.4+0.005, 0.005)

tam = vd.models.TamuraModel()
fdb = vd.models.FacchinettiDelangreBiolleyModel()
hc  = vd.models.HartlenCurrieModel()

dt = 0.005
n = 8_000_000
n_transient = 4_000_000

t_tab  = np.arange(0.0, n) * dt
state0 = np.array([0.0, 0.2, 0.0, 0.0])

solver = vd.solvers.EulerExplicit(verbose=False)

freq_tab_all = []
for model in [tam, fdb, hc]:
    print(f"Computing amplitude response curve for {model.__class__.__name__}...")
    freq_tab = []
    for omega in omega_tab:
        model.v = omega
        result  = solver.run(model, t_tab, state0)
        y_tab   = result[:, 1]
        y = y_tab[n_transient:]
        yf = rfft(y)
        xf = rfftfreq(y.shape[0], dt) * 2 * np.pi
        idx_peak = np.abs(yf).argmax()
        freq_tab.append(xf[idx_peak])
        print(f"Omega: {omega:.3f}, Frequency: {xf[idx_peak]:.4f}")
    freq_tab_all.append(freq_tab)
    
freq_tab_all = np.array(freq_tab_all)

for freq_tab, label in zip(freq_tab_all, ['Tamura', 'Facchinetti-Delangre-Biolley', 'Hartlen-Currie']):
    plt.plot(omega_tab, freq_tab, label=label)
    
plt.xlabel('Dimensionless wind speed: $\\Omega$ [-]')
plt.ylabel('Shedding frequency: $f_s$ [-]')
plt.title('Lock-in Curve')
plt.legend()
plt.savefig(FIG_PATH / 'lock_in_curve.pdf')
plt.close()