import vivyd

def test_package_import():
    """Test that the package imports successfully."""
    assert vivyd.__version__
    # Verify version is a string with format like "0.1.0"
    assert isinstance(vivyd.__version__, str)
    assert len(vivyd.__version__.split('.')) >= 2