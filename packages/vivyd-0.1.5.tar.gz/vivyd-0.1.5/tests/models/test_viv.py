from vivyd.models import VIVModel

from pytest import raises


def test_instance():
    with raises(TypeError):
        VIVModel()         #type:ignore