from vivyd.models import TamuraModel, GeneralizedModel

from numpy import array, ndarray
from pytest import approx


def test_instance():
    model = TamuraModel()
    assert model is not None

def test_to_taichi():
    
    model = TamuraModel()
    model_gen = model.to_taichi()
    
    assert isinstance(model_gen, GeneralizedModel), "to_taichi did not return the correct type"
    
    t     = 13.0
    state = array([2.0, 3.0, 5.0, 7.0])
    
    diff     = model(    t, state)
    diff_gen = model_gen(t, state)
    
    assert diff_gen == approx(diff)
            
def test_call():
    
    t = 0.0
    state = array([1.0, 2.0, 3.0, 4.0])
    
    out = TamuraModel()(t, state)
    
    assert isinstance(out, ndarray), "Output of __call__ is not the correct type"
    assert out.shape == (4,), "Output of __call__ does not have the correct shape"