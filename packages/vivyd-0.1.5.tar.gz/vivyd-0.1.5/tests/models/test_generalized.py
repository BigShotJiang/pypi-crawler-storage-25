from vivyd.models import GeneralizedModel

from numpy import array, ndarray


REF_MODEL = GeneralizedModel(
    xi = 2.0,
    M0 = 3.0,
    omega = 5.0,
    a = 7.0,
    b = 9.0,
    eps = 11.0,
    A0 = 13.0,
    A1 = 15.0,
    A2 = 17.0
)


def test_instance():
    model = GeneralizedModel()
    assert model is not None, "GeneralizedModel instance should not be None"
    
def test_call():
    
    t = 0.0
    state = array([1.0, 2.0, 3.0, 4.0])
    
    out = REF_MODEL(t, state)
    
    assert isinstance(out, ndarray), "Output of __call__ is not the correct type"
    assert out.shape == (4,), "Output of __call__ does not have the correct shape"