from vivyd.excitation import NoiseGenerator

def test_variance():
    generator = NoiseGenerator(n=1000000, dt=1.0, psd_tab=(NoiseGenerator.white(1.0),))
    sample    = generator()
    variance  = sample.x.var()
    assert abs(variance - 1.0) < 1e-3
    
def test_variance_with_s():
    generator = NoiseGenerator(n=1000000, dt=1.0, psd_tab=(NoiseGenerator.white(2.0),))
    sample    = generator()
    variance  = sample.x.var()
    print(variance)
    assert abs(variance - 2.0)/2.0 < 1e-3
    
def test_variance_with_dt():
    generator = NoiseGenerator(n=1000000, dt=0.01, psd_tab=(NoiseGenerator.white(1.0),))
    sample    = generator()
    variance  = sample.x.var()
    print(variance)
    assert abs(variance - 100.0)/100.0 < 1e-3