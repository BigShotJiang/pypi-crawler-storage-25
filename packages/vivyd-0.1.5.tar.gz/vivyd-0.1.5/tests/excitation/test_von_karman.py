from vivyd.excitation import NoiseGenerator


# Here, the psd is very peaky but keeps a lot of weight in the tails, so we need
# a lot of samples (n, giving df) and a large cutoff frequency (low dt, giving large fN)

def test_variance():
    generator = NoiseGenerator(n=20000000, dt=0.0005, psd_tab=(NoiseGenerator.von_karman(1.0, 1.0, 1.0),))
    sample    = generator()
    variance  = sample.x.var()
    print(variance)
    assert abs(variance - 1.0) < 1e-2
    
def test_variance_with_sigma2():
    generator = NoiseGenerator(n=20000000, dt=0.0005, psd_tab=(NoiseGenerator.von_karman(2.0, 1.0, 1.0),))
    sample    = generator()
    variance  = sample.x.var()
    print(variance)
    assert abs(variance - 2.0)/2.0 < 1e-2
    
def test_variance_with_U():
    generator = NoiseGenerator(n=20000000, dt=0.0005, psd_tab=(NoiseGenerator.von_karman(1.0, 10.0, 1.0),))
    sample    = generator()
    variance  = sample.x.var()
    print(variance)
    assert abs(variance - 1.0)/1.0 < 1e-2
    
def test_variance_with_Lu():    
    generator = NoiseGenerator(n=20000000, dt=0.0005, psd_tab=(NoiseGenerator.von_karman(1.0, 1.0, 10.0),))
    sample    = generator()
    variance  = sample.x.var()
    print(variance)
    assert abs(variance - 1.0)/1.0 < 1e-2