from vivyd.data import *

from datetime import datetime
from numpy import array
import quantities as pq
from pathlib import Path
from pytest import fixture


OUT_DIR = Path(__file__).parents[2] / "data/tests"


@fixture
def dataset()-> DataSet:
    d = DataSet(
        name="",
        info={},
        site=Site(name="", location="", institution=""),
        authors=[],
    )

    s = Study(name="", info={})
    d.add(s)

    ss = Study(name="", info={})
    s.add(ss)

    e = Experiment(name="", info={}, date=datetime.now())
    ss.add(e)

    b = Bundle(name="", info={})
    e.add(b)

    bb = Bundle(name="", info={})
    b.add(bb)

    so = Source(name="", info={})
    bb.add(so)

    so.add(
        Signal(
            name="s",
            time=array([0]),
            data=array([0]),
            units=pq.dimensionless,
        )
    )
    so.add(
        Value(
            name="v",
            data=0,
            units=pq.dimensionless,
        )
    )

    return d


def test_empty_dataset_builds(dataset):
    pass


def test_empty_dataset_print_tree(dataset):
    dataset.print_tree()


def test_empty_dataset_print_json(dataset):
    dataset.print_json()


def test_empty_dataset_save_and_load(dataset):
    path = OUT_DIR / "saved/dataset.vxp"
    dataset.save(path, create_dirs=True)

    d_load = DataSet.load(path)
    assert dataset == d_load


def test_download_dataset():


    DataSet.download_from_zenodo(
        record_id="19498280",
        output_dir=OUT_DIR / "downloaded",
        create_dirs=True
    )

    d_downloaded = DataSet.load(OUT_DIR / "downloaded/dataset.vxp")