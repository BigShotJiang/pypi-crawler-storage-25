vivyd package
=============

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   vivyd.core
   vivyd.data
   vivyd.excitation
   vivyd.models
   vivyd.solvers

Submodules
----------

vivyd.typing module
-------------------

.. automodule:: vivyd.typing
   :members:
   :show-inheritance:
   :undoc-members:

Module contents
---------------

.. automodule:: vivyd
   :members:
   :show-inheritance:
   :undoc-members:
