.. VIVyD documentation master file, created by
   sphinx-quickstart on Fri Apr 24 12:09:14 2026.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

VIVyD documentation
===================

Add your content using ``reStructuredText`` syntax. See the
`reStructuredText <https://www.sphinx-doc.org/en/master/usage/restructuredtext/index.html>`_
documentation for details.

.. toctree::
   modules

.. toctree::
   :maxdepth: 2
   :caption: Contents:

