"""
This script provides functionality for posting sensor data to FlexDB. It merely serves as a proof-of-concept and for
testing purposes. The functionality has to be implemented in the final code for the Road-Side-Inspections (RSI).
"""

import json
import requests

from typing import List


url = "https://api.livingcarlab.nl/json"

def post_to_flexdb(headers: dict, payload: List[dict]) -> requests.Response:

    response = requests.post(url, headers=headers, json=payload, timeout=(10, 120))  # postin the data to FlexDB

    return response



