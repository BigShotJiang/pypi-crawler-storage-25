"""
TODO
Thanks to M. Elstgeest for sharing the code.
"""

import json
import sys
from pathlib import Path
from urllib.parse import urlencode

import requests
from dateutil import parser as dtparser


AUTH_URL = "https://livingcarlab.nl/auth"
EXPORT_URL = "https://livingcarlab.nl/export.csv"


def read_credentials(path: Path) -> tuple[str, str]:
    if not path.exists():
        raise FileNotFoundError(f"Credentials file not found: {path}")
    with path.open("r", encoding="utf-8") as f:
        data = json.load(f)
    try:
        return data["email"], data["password"]
    except KeyError as e:
        raise KeyError(
            f"Missing key in credentials JSON ({e}). "
            "Expected: {'email': '...', 'password': '...'}"
        )


def parse_iso_like(s: str) -> str:
    """
    Neemt veelvoorkomende tijdformaten aan (bv. '2026-03-13 06:00', '2026-03-13T06:00').
    Geeft terug als 'YYYY-MM-DD HH:MM' (zonder timezone-offset), zodat het overeenkomt
    met je voorbeeld-URL waar spatie wordt ge-encode naar '+'.
    """
    dt = dtparser.parse(s)
    # Strip timezone info voor consistente representatie tenzij je API UTC verwacht.
    # Als de API UTC verwacht, vervang dit door .astimezone(timezone.utc)
    # en format met 'Z' of offset.
    if dt.tzinfo is not None:
        dt = dt.astimezone().replace(tzinfo=None)
    return dt.strftime("%Y-%m-%d %H:%M")


def try_session_login_old(session: requests.Session, username: str, password: str) -> bool:
    """
    Probeert te 'loggen' op AUTH_URL. Afhankelijk van de server kan dit een GET met Basic Auth,
    of een POST met Basic Auth/JSON body zijn. We proberen eerst GET met Basic Auth.
    Retourneert True als er indicaties zijn dat login/cookie is gezet.
    """
    # 1) Probeer GET met Basic Auth (veel frameworks accepteren dit en geven cookie/succes terug)
    r = session.get(AUTH_URL, auth=(username, password), timeout=30)
    if r.status_code in (200, 204):
        # Als er cookies zijn toegevoegd door de server, is dat vaak voldoende.
        # We kunnen geen harde garantie geven, maar dit is een redelijke heuristiek.
        if session.cookies:
            return True
        # Als 200 terugkomt zonder cookies, kan het nog steeds zijn dat vervolgrequests met Basic Auth nodig zijn.
        # We returnen False zodat fallback pad ook gebruikt kan worden.
        return False

    # 2) (optioneel) Probeer POST met Basic Auth - sommige servers vereisen expliciete login POST
    #    We sturen geen body mee, maar je kunt dit aanpassen als de server JSON verwacht.
    if r.status_code in (401, 405, 404):
        try:
            r2 = session.post(AUTH_URL, auth=(username, password), timeout=30)
            if r2.status_code in (200, 204) and session.cookies:
                return True
        except requests.RequestException:
            pass

    return False

def try_session_login(session: requests.Session, username: str, password: str) -> bool:
    payload = {
        "email": username,
        "password": password,
        # add any other fields from the browser form here
    }
    r = session.post(AUTH_URL, data=payload, timeout=30, allow_redirects=True)

    print("login status:", r.status_code)
    print("set-cookie:", r.headers.get("set-cookie"))
    print("cookies:", session.cookies.get_dict())

    return "tno_auth" in session.cookies.get_dict()


def build_export_url(device_id: str, start_time: str, end_time: str, relation: str) -> str:
    params = {
        "device_id": device_id,
        "start_time": start_time,  # bijv. '2026-03-13 06:00' -> wordt ge-encode naar '+'
        "end_time": end_time,
        "relation": relation,
    }
    qs = urlencode(params)
    return f"{EXPORT_URL}?{qs}"


def download_csv(
    session: requests.Session,
    url: str,
    out_path: Path,
    auth: tuple[str, str] | None = None,
) -> None:
    # stream=True om grote downloads te ondersteunen
    with session.get(url, stream=True, timeout=120, auth=auth) as r:
        # Verwacht 200 en Content-Type 'text/csv' (niet verplicht, maar handig ter controle)
        if r.status_code != 200:
            text_preview = ""
            try:
                text_preview = r.text[:500]
            except Exception:
                pass
            raise RuntimeError(
                f"Export request failed: HTTP {r.status_code}\n"
                f"URL: {url}\n"
                f"Response (first 500 chars): {text_preview}"
            )

        # Schrijf naar bestand
        out_path.parent.mkdir(parents=True, exist_ok=True)
        with out_path.open("wb") as f:
            for chunk in r.iter_content(chunk_size=64 * 1024):
                if chunk:
                    f.write(chunk)


def get_from_flexdb(args):

    try:
        username, password = read_credentials(args.creds)
    except Exception as e:
        print(f"[FOUT] Kon credentials niet lezen: {e}", file=sys.stderr)
        sys.exit(1)

    # Normaliseer tijden naar 'YYYY-MM-DD HH:MM'
    try:
        start_str = parse_iso_like(args.start)
        end_str = parse_iso_like(args.end)
    except Exception as e:
        print(f"[FOUT] Ongeldige datum/tijd: {e}", file=sys.stderr)
        sys.exit(1)

    out_path = args.output_path

    sess = requests.Session()
    # Zet verify=False alleen als --insecure is opgegeven (bijv. self-signed certs)
    sess.verify = not args.insecure

    # 1) Probeer eerst sessie-login op /auth (zet evt. cookies)
    logged_in = False
    try:
        logged_in = try_session_login(sess, username, password)
    except requests.SSLError as e:
        print(
            "[FOUT] SSL fout tijdens login. "
            "Probeer --insecure of configureer de juiste CA-certificaten.\n"
            f"Details: {e}",
            file=sys.stderr,
        )
        sys.exit(1)
    except requests.RequestException as e:
        # Niet fataal; we kunnen fallback nog proberen
        print(f"[WAARSCHUWING] Login via /auth mislukte of gaf geen cookies: {e}", file=sys.stderr)

    # 2) Bouw export-URL
    export_url = build_export_url(args.device_id, start_str, end_str, args.relation)

    # 3) Download: eerst met sessie (zonder auth) als we denken dat cookie gezet is; anders fallback met Basic Auth
    try:
        if logged_in:
            # Probeer met sessie-cookies
            download_csv(sess, export_url, out_path, auth=None)
        else:
            # Fallback: directe Basic Auth op export endpoint
            download_csv(sess, export_url, out_path, auth=(username, password))
    except RuntimeError as e:
        # Nog een fallback: als cookie-pad faalde, probeer Basic Auth alsnog
        if logged_in:
            print(
                "[INFO] Export met sessie-cookies faalde, probeer directe Basic Auth als fallback...",
                file=sys.stderr,
            )
            download_csv(sess, export_url, out_path, auth=(username, password))
        else:
            raise

    print(f"[OK] CSV gedownload: {out_path.resolve()}")

    login = sess.get(AUTH_URL, auth=(username, password), timeout=30)
    print("login_status", login.status_code)
    print("login_url", login.url)
    print("login_content_type", login.headers.get("Content-Type"))
    print("cookies_after_login", bool(sess.cookies))

    resp = sess.get(export_url, auth=(username, password), timeout=30)
    print("export_status", resp.status_code)
    print("export_url", resp.url)
    print("export_content_type", resp.headers.get("Content-Type"))
    print("history", [(r.status_code, r.headers.get("Location")) for r in resp.history])
    print("starts_with", resp.text[:80].replace("\n", " "))
