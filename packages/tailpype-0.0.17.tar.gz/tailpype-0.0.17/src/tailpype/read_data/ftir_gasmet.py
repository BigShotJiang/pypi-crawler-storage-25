"""
This module provides functionality to read data from the Testo 350 emission measurement tool.
"""

import glob
import numpy as np
import pandas as pd


def read_ftir_data(path_to_data: str, ftir_time_zone: str) -> pd.DataFrame:
    """
    Reads and combines FTIR data from a given input path.
    :param path_to_data: pathname
    :param ftir_time_zone: time zone
    :return: DataFrame containing the combined data
    """

    ftir_files = glob.iglob(path_to_data, recursive=True)

    df_ftir = pd.DataFrame()
    for file_ in ftir_files:

        new_table = []
        with open(file_, 'r') as f:
            for h, line in enumerate(f):
                if 'Line' in line:
                    new_table.append(h)

        n_rows =  [t - s - 1 for s, t in zip(new_table, new_table[1:])]
        # noinspection PyTypeChecker
        n_rows.append(None)

        for h, table_loc in enumerate(new_table):

            df_iter = pd.read_csv(filepath_or_buffer=file_, sep='\t', encoding='ansi',
                                  skiprows=table_loc, nrows=n_rows[h])

            df_iter_columns = []
            for clmn_ in df_iter.columns:
                clmn_ = clmn_.strip()  # remove leading and trailing spaces
                if 'Unit' in clmn_:
                    clmn_ = subst_ + ' - ' + 'Unit'
                elif 'Compensation' in clmn_:
                    clmn_ = subst_ + ' - ' + 'Compensation'
                elif 'Residual' in clmn_:
                    clmn_ = subst_ + ' - ' + 'Residual'
                else:
                    subst_ = clmn_
                df_iter_columns.append(clmn_)
            df_iter.columns = df_iter_columns

            df_iter['datetime (UTC) [-]'] = df_iter['Date'] + ' ' + df_iter['Time']
            df_iter['datetime (UTC) [-]'] = pd.to_datetime(df_iter['datetime (UTC) [-]'], format='%Y-%m-%d %H:%M:%S')
            df_iter['datetime (UTC) [-]'] =\
                df_iter['datetime (UTC) [-]'].dt.tz_localize(ftir_time_zone).dt.tz_convert('UTC').dt.round(freq='s')
            df_iter = df_iter.resample('1s', on='datetime (UTC) [-]').last()
            df_iter = df_iter.reset_index()
            df_iter = df_iter.ffill(axis=0, limit=None)
            # It is assumed that one file contains one time interval w/o gaps other than caused by resampling.
            # Therefore, no limit is needed.

            df_ftir = pd.concat([df_ftir, df_iter], axis=0)

    if len(df_ftir) == 0:
        return df_ftir

    df_ftir = df_ftir.replace(np.inf, np.nan).dropna(how='all', axis=1)
    df_ftir = df_ftir.sort_values(by='datetime (UTC) [-]').reset_index(drop=True)

    return df_ftir