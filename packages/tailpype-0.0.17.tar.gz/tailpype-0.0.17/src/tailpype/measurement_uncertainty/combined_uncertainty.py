"""
TODO: Refer to GUM1995!
"""

import sympy

from typing import Any, Callable, List


# ----------------------------------------------------------------------------------------------------------------------
# classes

class Function:

    def __init__(self, name: str, function: Callable, x_0: dict[str, float], u_2: dict[str, float] = None):
        """

        :param name:
        :param function:
        :param x_0: Dictionary of evaluation points (values of the variables of the function). For the keys use the
        variable names as strings. Make sure that for every variable a value is given.
        :param u_2: Dictionary of uncertainties (variances of the variables of the function. For the keys use the
        variable names as strings. Make sure that for every variable an uncertainty is given. Use 0.0 if there is no
        (relevant) uncertainty related to this variable.
        """

        # Input check
        self.variables = function.__code__.co_varnames
        if any([u_ < 0.0 for u_ in u_2.values()]):
            raise 'Uncertainties must not be negative !'
        if len(u_2) != len(self.variables):
            raise 'For every variable an uncertainty has to be given. Use 0.0 if the value is known exactly.'

        print('Creating new Function object.', flush=True)

        self.name = name
        self.function = function
        self.x_0 = x_0
        self.u_2 = u_2
        self.variables_symb = sympy.symbols(self.variables)
        self.function_diff_1 = {}
        self.function_diff_2 = {}
        self.function_diff_1_lambda = {}
        self.function_diff_2_lambda = {}
        self.rel_cond = {}
        self.rel_cond_lambda = {}
        self.combined_uncertainty = 0.0

        for var_1 in self.variables_symb:

            print('Calculating 1st derivative with respect to {}.'.format(var_1), flush=True)
            self.function_diff_1[str(var_1)] = sympy.simplify(sympy.diff(self.function(*self.variables_symb), var_1))
            self.function_diff_1_lambda[str(var_1)] =\
                sympy.lambdify([*self.variables_symb], self.function_diff_1[str(var_1)], 'numpy')

            self.function_diff_2[str(var_1)] = {}
            self.function_diff_2_lambda[str(var_1)] = {}
            for var_2 in self.variables_symb:

                print('Calculating 2nd derivative with respect to {} and {}.'.format(var_1, var_2), flush=True)
                self.function_diff_2[str(var_1)][str(var_2)] =\
                    sympy.simplify(sympy.diff(self.function_diff_1[str(var_1)], var_2))
                self.function_diff_2_lambda[str(var_1)][str(var_2)] = \
                    sympy.lambdify([*self.variables_symb], self.function_diff_2[str(var_1)][str(var_2)], 'numpy')

            print('Calculating relative condition number with respect to {}.'.format(var_1), flush=True)
            self.rel_cond[str(var_1)] =\
                abs(self.function_diff_1[str(var_1)]) * abs(var_1) / abs(self.function(*self.variables_symb))
            self.rel_cond_lambda[str(var_1)] =\
                sympy.lambdify([*self.variables_symb], self.rel_cond[str(var_1)], 'numpy')

            # This part relies on that the 2nd derivative with respect to var_1 is already known. So be careful when
            # making changes.
            # This part relies on that the 2nd derivative with respect to var_1 is already known.
            self.combined_uncertainty +=\
                abs(self.function_diff_1_lambda[str(var_1)](**self.x_0)) ** 2 * u_2[str(var_1)]








    def get_first_derivatives(self) -> tuple[dict[str, str], dict[str, Any], dict[str, float]]:

        return self.function_diff_1_lambda,\
            self.function_diff_1_lambda,\
            {str(var_): self.function_diff_1_lambda[str(var_)](**self.x_0) for var_ in self.variables_symb}

    def get_second_derivatives(self) -> tuple[dict[str, float], dict[str, Any], dict[str, float]]:

        return self.function_diff_2,\
            self.function_diff_2_lambda,\
            {str(var_): self.function_diff_2_lambda[str(var_)](**self.x_0) for var_ in self.variables_symb}

    def get_relative_condition_number(self) -> tuple[dict[str, float], dict[str, Any], dict[str, float]]:

        return self.rel_cond,\
            self.rel_cond_lambda,\
            {str(var_): self.rel_cond_lambda[str(var_)](**self.x_0) for var_ in self.variables_symb}

    def get_combined_uncertainty(self) -> float:

        return self.combined_uncertainty
