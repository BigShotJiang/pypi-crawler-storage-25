"""
This module provides functionality for the calculation of emissions from seafaring vessels. Much of it is based on
the NOx Technical Code (NTC) of the IMO, which provides a standardized method for calculating NOx emissions from
marine engines.
"""

def humidity_correction(intermediate_air_cooler: bool, h_a: float, t_a: float, t_sc: float=None,
                        t_scref: float=None) -> \
        float:

    if intermediate_air_cooler:
        if any([x_ is None for x_ in [t_sc, t_scref]]):
            raise ValueError('Charge air temperature T_SC and charge air temperature at each mode point corresponding'
                             'to a seawater temperature of 25°C T_SCRef is required for compression ignition engines '
                             'with intermediate air cooler !')
        k_hd = 1 / (1.0 - 0.012 * (h_a - 10.71) + 0.00275 * (t_a - 298.0) + 0.00285 * (t_sc - t_scref))
    else:
        k_hd = 1 / (1.0 - 0.0182 * (h_a - 10.71) + 0.0045 * (t_a - 298.0))

    return k_hd
