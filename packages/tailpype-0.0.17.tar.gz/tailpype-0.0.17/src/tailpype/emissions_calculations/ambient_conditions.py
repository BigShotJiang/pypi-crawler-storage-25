"""
TODO
"""

import numpy as np
import scipy.interpolate as sp_interpolate


def abs_humidity_from_rel_humidity(rh, t_amb, p_amb):
    """
    This function calculates the absolute humidity in grams of water per kg of dry air from the relative humidity and
    ambient pressure and temperature. For reference see https://en.wikipedia.org/wiki/Humidity and
    https://de.wikipedia.org/wiki/Luft.
    :param rh: relative humidity [%]
    :param t_amb: ambient temperature [°C]
    :param p_amb: ambient pressure [kPa]
    :return: absolute humidity in g H2O per kg dry air
    """

    if np.isnan(rh) | np.isnan(t_amb):
        return np.nan

    rho_air = 1.293  # kg/m3 @273.15K & 101.325kPa (normal conditions); https://de.wikipedia.org/wiki/Luft
    t_0 = 273.15  # K
    p_0 = 101.325  # kPa
    rho_air_amb = rho_air * (t_0 / (t_amb + 273.15)) * (p_amb / p_0)

    rel_hum = np.linspace(0, 100, 11)
    t_degc = np.linspace(-25, 50, 16)
    abs_hum_tbl = np.array([[0.0, 0.1, 0.1, 0.2, 0.2, 0.3, 0.3, 0.4, 0.4, 0.5, 0.6],
                           [0.0, 0.1, 0.2, 0.3, 0.4, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9],
                           [0.0, 0.2, 0.3, 0.5, 0.6, 0.8, 1.0, 1.1, 1.3, 1.5, 1.6],
                           [0.0, 0.2, 0.5, 0.7, 0.9, 1.2, 1.4, 1.6, 1.9, 2.1, 2.3],
                           [0.0, 0.3, 0.7, 1.0, 1.4, 1.7, 2.1, 2.4, 2.7, 3.1, 3.4],
                           [0.0, 0.5, 1.0, 1.5, 1.9, 2.4, 2.9, 3.4, 3.9, 4.4, 4.8],
                           [0.0, 0.7, 1.4, 2.0, 2.7, 3.4, 4.1, 4.8, 5.4, 6.1, 6.8],
                           [0.0, 0.9, 1.9, 2.8, 3.8, 4.7, 5.6, 6.6, 7.5, 8.5, 9.4],
                           [0.0, 1.3, 2.6, 3.9, 5.1, 6.4, 7.7, 9.0, 10.3, 11.5, 12.8],
                           [0.0, 1.7, 3.5, 5.2, 6.9, 8.7, 10.4, 12.1, 13.8, 15.6, 17.3],
                           [0.0, 2.3, 4.6, 6.9, 9.2, 11.5, 13.8, 16.1, 18.4, 20.7, 23.0],
                           [0.0, 3.0, 6.1, 9.1, 12.1, 15.2, 18.2, 21.3, 24.3, 27.3, 30.4],
                           [0.0, 4.0, 7.9, 11.9, 15.8, 19.8, 23.8, 27.7, 31.7, 35.6, 39.6],
                           [0.0, 5.1, 10.2, 15.3, 20.5, 25.6, 30.7, 35.8, 40.9, 46.0, 51.1],
                           [0.0, 6.5, 13.1, 19.6, 26.2, 32.7, 39.3, 45.8, 52.4, 58.9, 65.4],
                           [0.0, 8.3, 16.6, 24.9, 33.2, 41.5, 49.8, 58.1, 66.4, 74.7, 83.0]])

    # noinspection PyTypeChecker
    return sp_interpolate.interpn((t_degc, rel_hum), abs_hum_tbl, np.array([t_amb, rh]))[0] / rho_air_amb
