"""
A really cool package that does a lot of stuff !
"""


from . import emissions_calculations, ftir, read_data

__all__ = ['emissions_calculations', 'ftir', 'read_data']
