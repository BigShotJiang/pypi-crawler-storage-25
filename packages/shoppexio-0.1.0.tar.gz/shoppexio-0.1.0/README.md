# shoppexio

Official Python SDK for the Shoppex Developer API.

## Install

```bash
pip install shoppexio
```

## Quick start

```python
from shoppexio import ShoppexClient

client = ShoppexClient(api_key="shx_your_api_key")
me = client.me.get()
print(me.data.get("store_name"))

products = client.products.list({"page": 1, "limit": 20})
for product in products.data:
    print(product.uniqid or product.id, product.name)
```

The SDK returns small response objects instead of raw nested dicts:

```python
response = client.products.list({"limit": 20})
print(response.pagination.has_more)
print(response.data[0].to_dict())
```

## Pagination helpers

```python
all_products = client.products.list_all({"limit": 100})
all_logs = client.webhooks.logs_all({"page": 1, "limit": 100})

for product in client.iterate_cursor("/dev/v1/products/", {"limit": 100}):
    print(product.uniqid)
```

## Mutations

```python
completed = client.orders.complete(
    "ord_123",
    {"notify_customer": True},
    idempotency_key="complete-ord-123",
)

print(completed.data.get("status"))
```

Other core resources are typed too:

```python
payments = client.payments.list({"limit": 20})
print(payments.data[0].status)

coupon = client.coupons.get("coupon_123")
print(coupon.data.code)

webhook = client.webhooks.get("wh_123")
print(webhook.data.url)
```

## Error handling

```python
from shoppexio import ShoppexApiError

try:
    client.products.get("missing-id")
except ShoppexApiError as error:
    print(error.status, error.code, error.doc_url)
    print(error.details)
```
