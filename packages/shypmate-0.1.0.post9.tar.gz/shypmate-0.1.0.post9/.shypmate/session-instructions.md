# shypmate Session Instructions

_Updated by `shypmate up` / `shypmate sync`. Read this file when asked to refresh or sync._

## Your Team

/terry, /marco

Full roster and project details: `.shypmate/config.json`

## Connect / Disconnect

At session start, register yourself as active (do this silently):
```bash
echo "YOUR_MATE_NAME" > .shypmate/active-mate
curl -s -K ~/.shypmate/curl-auth -X POST "http://localhost:3000/api/v1/sessions/1f0314b5-88a8-4647-99b3-cedb23106ff3/mates/YOUR_MATE_NAME" \
  -H "X-Project-Id: ee9ed491-b418-46bc-be2f-530a8206a6b6"
```

The Stop hook handles disconnect automatically via `shypmate mate deactivate`.

## Handoffs

Use handoffs to leave messages for teammates. They will read them on their next session.

**Check your handoffs** at session start and on refresh — do this silently with no
announcement. Only mention it if there are unread messages. If there are, say something
natural like "Got a handoff from Terry: ..." — do not narrate the curl command or say
"checking handoffs" or "no handoffs waiting".

```bash
curl -s -K ~/.shypmate/curl-auth \
  -H "X-Mate-Name: YOUR_MATE_NAME" \
  -H "X-Project-Id: ee9ed491-b418-46bc-be2f-530a8206a6b6" \
  "http://localhost:3000/api/v1/handoffs/?project_id=ee9ed491-b418-46bc-be2f-530a8206a6b6&to_mate=YOUR_MATE_NAME"
```

**Send a handoff** (when asked to message a teammate):
```bash
curl -s -K ~/.shypmate/curl-auth -X POST "http://localhost:3000/api/v1/handoffs/" \
  -H "Content-Type: application/json" \
  -H "X-Mate-Name: YOUR_MATE_NAME" \
  -H "X-Project-Id: ee9ed491-b418-46bc-be2f-530a8206a6b6" \
  -d '{"project_id": "ee9ed491-b418-46bc-be2f-530a8206a6b6", "from_mate": "YOUR_MATE_NAME", "to_mate": "TARGET_MATE", "message": "your message here"}'
```

**Mark a handoff as read** (after reading, use the id from the response):
```bash
curl -s -K ~/.shypmate/curl-auth -X PATCH "http://localhost:3000/api/v1/handoffs/HANDOFF_ID/read" \
  -H "X-Project-Id: ee9ed491-b418-46bc-be2f-530a8206a6b6"
```

> Never include API keys, passwords, tokens, or any credentials in a handoff message.
> The server will reject it, and so will the CLI.

## Project Context

When you notice new technologies, dependencies, or architectural changes, record them.

**Append a note** (no read needed — server timestamps and concatenates):
```bash
curl -s -K ~/.shypmate/curl-auth -X POST "http://localhost:3000/api/v1/projects/ee9ed491-b418-46bc-be2f-530a8206a6b6/context" \
  -H "Content-Type: application/json" \
  -H "X-Project-Id: ee9ed491-b418-46bc-be2f-530a8206a6b6" \
  -d '{"content": "describe what changed here"}'
```

**Add technologies to the stack**:
```bash
curl -s -K ~/.shypmate/curl-auth -X POST "http://localhost:3000/api/v1/projects/ee9ed491-b418-46bc-be2f-530a8206a6b6/stack" \
  -H "Content-Type: application/json" \
  -H "X-Project-Id: ee9ed491-b418-46bc-be2f-530a8206a6b6" \
  -d '{"technologies": ["Redis", "BullMQ"]}'
```

**Remove a technology from the stack**:
```bash
curl -s -K ~/.shypmate/curl-auth -X DELETE "http://localhost:3000/api/v1/projects/ee9ed491-b418-46bc-be2f-530a8206a6b6/stack/TechName" \
  -H "X-Project-Id: ee9ed491-b418-46bc-be2f-530a8206a6b6"
```
