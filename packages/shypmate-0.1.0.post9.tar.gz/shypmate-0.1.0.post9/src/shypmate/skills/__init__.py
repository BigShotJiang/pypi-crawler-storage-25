"""Claude Code skill installation and management.

Handles syncing mate personas from shypmate.dev to:
- ~/.claude/skills/<name>/SKILL.md  — global, enables Claude Code slash commands
- .shypmate/mates/<name>/SKILL.md   — project record, safe to commit
"""

import shutil
from pathlib import Path
from typing import Optional

from shypmate.api import ShypmateClient
from shypmate.config import get_api_url


CLAUDE_SKILLS_DIR = Path.home() / ".claude" / "skills"
PROJECT_MATES_DIR = Path(".shypmate") / "mates"
SESSION_INSTRUCTIONS_FILE = Path(".shypmate") / "session-instructions.md"


# Minimal footer — all live instructions are in session-instructions.md
_REFRESH_FOOTER = """
## Refresh / Sync

When the user says anything like "refresh", "reload", "sync up", "synchronize",
"who's on the team", or "update your context" — read `.shypmate/session-instructions.md`
and confirm the current state to the user.
"""


def write_session_instructions(project_id: str, api_url: str, mates: list[str], machine_id: str = "") -> Path:
    """Write .shypmate/session-instructions.md with live values filled in.

    Called on `shypmate up` and `shypmate sync`. Mates read this file at runtime
    so instructions stay current without needing to regenerate skill files.
    """
    if not Path(".shypmate").exists():
        return SESSION_INSTRUCTIONS_FILE

    team = ", ".join(f"/{m}" for m in mates) if mates else "none yet"
    machine_id_section = f"""
## Connect / Disconnect

At session start, register yourself as active (do this silently):
```bash
echo "YOUR_MATE_NAME" > .shypmate/active-mate
curl -s -K ~/.shypmate/curl-auth -X POST "{api_url}/sessions/{machine_id}/mates/YOUR_MATE_NAME" \\
  -H "X-Project-Id: {project_id}"
```

The Stop hook handles disconnect automatically via `shypmate mate deactivate`.
""" if machine_id else ""

    content = f"""# shypmate Session Instructions

_Updated by `shypmate up` / `shypmate sync`. Read this file when asked to refresh or sync._

## Your Team

{team}

Full roster and project details: `.shypmate/config.json`
{machine_id_section}
## Handoffs

Use handoffs to leave messages for teammates. They will read them on their next session.

**Check your handoffs** at session start and on refresh — do this silently with no
announcement. Only mention it if there are unread messages. If there are, say something
natural like "Got a handoff from Terry: ..." — do not narrate the curl command or say
"checking handoffs" or "no handoffs waiting".

```bash
curl -s -K ~/.shypmate/curl-auth \\
  -H "X-Mate-Name: YOUR_MATE_NAME" \\
  -H "X-Project-Id: {project_id}" \\
  "{api_url}/handoffs/?project_id={project_id}&to_mate=YOUR_MATE_NAME"
```

**Send a handoff** (when asked to message a teammate):
```bash
curl -s -K ~/.shypmate/curl-auth -X POST "{api_url}/handoffs/" \\
  -H "Content-Type: application/json" \\
  -H "X-Mate-Name: YOUR_MATE_NAME" \\
  -H "X-Project-Id: {project_id}" \\
  -d '{{"project_id": "{project_id}", "from_mate": "YOUR_MATE_NAME", "to_mate": "TARGET_MATE", "message": "your message here"}}'
```

**Mark a handoff as read** (after reading, use the id from the response):
```bash
curl -s -K ~/.shypmate/curl-auth -X PATCH "{api_url}/handoffs/HANDOFF_ID/read" \\
  -H "X-Project-Id: {project_id}"
```

> Never include API keys, passwords, tokens, or any credentials in a handoff message.
> The server will reject it, and so will the CLI.

## Project Context

When you notice new technologies, dependencies, or architectural changes, record them.

**Append a note** (no read needed — server timestamps and concatenates):
```bash
curl -s -K ~/.shypmate/curl-auth -X POST "{api_url}/projects/{project_id}/context" \\
  -H "Content-Type: application/json" \\
  -H "X-Project-Id: {project_id}" \\
  -d '{{"content": "describe what changed here"}}'
```

**Add technologies to the stack**:
```bash
curl -s -K ~/.shypmate/curl-auth -X POST "{api_url}/projects/{project_id}/stack" \\
  -H "Content-Type: application/json" \\
  -H "X-Project-Id: {project_id}" \\
  -d '{{"technologies": ["Redis", "BullMQ"]}}'
```

**Remove a technology from the stack**:
```bash
curl -s -K ~/.shypmate/curl-auth -X DELETE "{api_url}/projects/{project_id}/stack/TechName" \\
  -H "X-Project-Id: {project_id}"
```
"""

    SESSION_INSTRUCTIONS_FILE.write_text(content)
    return SESSION_INSTRUCTIONS_FILE


def install_mate_skill(mate_name: str, skill_content: str) -> Path:
    """Install a SKILL.md for a mate — globally and project-locally if initialized."""
    content = skill_content.rstrip() + "\n" + _REFRESH_FOOTER

    # Global: enables /name slash commands in Claude Code
    global_dir = CLAUDE_SKILLS_DIR / mate_name
    global_dir.mkdir(parents=True, exist_ok=True)
    global_file = global_dir / "SKILL.md"
    global_file.write_text(content)

    # Project-local: project record, written only if .shypmate/ exists
    if Path(".shypmate").exists():
        local_dir = PROJECT_MATES_DIR / mate_name
        local_dir.mkdir(parents=True, exist_ok=True)
        (local_dir / "SKILL.md").write_text(content)

    return global_file


def install_base_skill(api_url: Optional[str] = None) -> Path:
    """Install the _base skill that loads the shared playbook."""
    base_dir = CLAUDE_SKILLS_DIR / "_base"
    base_dir.mkdir(parents=True, exist_ok=True)

    url = api_url or get_api_url()

    content = f"""---
name: _base
description: >
  Shared team playbook loader for shypmate. Automatically loaded by all mate
  personas. Fetches the team playbook from shypmate.dev on session start.
  Do not invoke directly.
autoApply: false
---

# Shared Team Playbook

You are a shypmate mate. Before starting any work:

1. Fetch and follow the shared playbook:
```bash
curl -s -K ~/.shypmate/curl-auth {url}/playbook
```

2. The playbook defines how ALL mates work: communication standards,
   code quality rules, memory protocol, handoff format, and error handling.

3. Your persona SKILL.md defines WHO you are. The playbook defines HOW you work.

## Session Instructions

Read `.shypmate/session-instructions.md` for your current team roster, handoff
commands, and any other live context. Re-read it whenever asked to refresh or sync.

## Memory Protocol

To save a learning at session end:

**Global** (applies everywhere):
```bash
curl -s -K ~/.shypmate/curl-auth -X POST {url}/mates/YOURMATENAME/memory \\
  -H "Content-Type: application/json" \\
  -H "X-Mate-Name: YOURMATENAME" \\
  -d '{{"content": "your learning here", "scope": "global"}}'
```

**Project-specific**:
```bash
curl -s -K ~/.shypmate/curl-auth -X POST {url}/mates/YOURMATENAME/memory \\
  -H "Content-Type: application/json" \\
  -H "X-Mate-Name: YOURMATENAME" \\
  -d '{{"content": "your learning here", "scope": "project", "project_id": "PROJECT_ID"}}'
```

Replace YOURMATENAME with your mate name and PROJECT_ID with the project ID
from .shypmate/config.json.

## Project Context — Keep It Current

You are responsible for keeping the project's context and stack accurate over time.

**At session start**, glance at `.shypmate/project-context.md` and the project's
manifest files (package.json, pyproject.toml, Dockerfile, etc.). If you notice
anything significant that's missing or has changed — a new library, a new service,
a removed dependency — update the server silently as part of your startup routine.

**During work**, if you add, remove, or discover a technology, update it immediately
— don't wait until session end. Use the commands in `.shypmate/session-instructions.md`.

What counts as worth recording:
- New frameworks, databases, queues, caches, or infrastructure
- Removed or replaced dependencies
- New services (APIs, third-party integrations)
- Significant architectural decisions

What to skip: minor version bumps, dev tooling changes, test libraries.
"""

    skill_file = base_dir / "SKILL.md"
    skill_file.write_text(content)

    return skill_file


def remove_mate_skill(mate_name: str) -> bool:
    """Remove a mate's skill from both global and project-local locations."""
    removed = False
    global_dir = CLAUDE_SKILLS_DIR / mate_name
    if global_dir.exists():
        shutil.rmtree(global_dir)
        removed = True
    local_dir = PROJECT_MATES_DIR / mate_name
    if local_dir.exists():
        shutil.rmtree(local_dir)
        removed = True
    return removed


def list_installed_skills() -> list[str]:
    """List all installed mate skill names."""
    if not CLAUDE_SKILLS_DIR.exists():
        return []
    return [
        d.name
        for d in sorted(CLAUDE_SKILLS_DIR.iterdir())
        if d.is_dir()
        and d.name not in ("_base", "_archived", "team-generator")
        and (d / "SKILL.md").exists()
    ]


def sync_all_mates(client: ShypmateClient) -> list[str]:
    """Sync all mates from shypmate.dev to local skills."""
    mates = client.list_mates()
    installed = []

    for mate in mates:
        name = mate["name"]
        skill_content = mate.get("skill_md") or client.get_mate_skill(name)
        if skill_content:
            install_mate_skill(name, skill_content)
            installed.append(name)

    install_base_skill(client.base_url)

    return installed
