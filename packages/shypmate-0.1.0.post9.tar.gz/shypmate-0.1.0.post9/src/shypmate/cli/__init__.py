"""shypmate CLI — main entry point.

All commands registered here via Click groups.
"""

import click

from shypmate.cli.auth import auth
from shypmate.cli.team import team, hire, fire, rehire, roster, mate
from shypmate.cli.project import init, sync, push_context, stack_add, stack_remove
from shypmate.cli.memory import memory
from shypmate.cli.session import up, down, status
from shypmate.cli.watch import watch


@click.group()
@click.version_option(package_name="shypmate")
def cli():
    """shypmate — Build, manage, and deploy AI mates."""
    pass


# Session commands
cli.add_command(up)
cli.add_command(down)
cli.add_command(status)

# Auth commands
cli.add_command(auth)

# Team commands
cli.add_command(mate)
cli.add_command(team)
cli.add_command(hire)
cli.add_command(fire)
cli.add_command(rehire)
cli.add_command(roster)

# Project commands
cli.add_command(init)
cli.add_command(sync)
cli.add_command(push_context)
cli.add_command(stack_add)
cli.add_command(stack_remove)

# Memory commands
cli.add_command(memory)

# Watch command
cli.add_command(watch)


if __name__ == "__main__":
    cli()
