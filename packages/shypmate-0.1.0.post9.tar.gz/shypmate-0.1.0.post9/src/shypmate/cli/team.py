"""Team management commands — hire, fire, roster, etc."""

import click
from rich.console import Console
from rich.table import Table

from pathlib import Path

from shypmate.config import is_authenticated, get_project_id
from shypmate.session import get_machine_id
from shypmate.api import ShypmateClient, ShypmateAPIError
from shypmate.skills import install_mate_skill, remove_mate_skill, list_installed_skills

console = Console()

ROLE_SHORTCUTS = {
    "qa": "Senior QA Engineer — integration testing, E2E testing, code review, edge cases, test strategy",
    "frontend": "Senior Frontend Engineer — UI implementation, component architecture, accessibility, responsive design",
    "backend": "Senior Backend Engineer — API design, database architecture, server-side performance, reliability",
    "devops": "Senior DevOps Engineer — CI/CD, Docker, deployment automation, monitoring, infrastructure as code",
    "security": "Security Engineer — authentication, authorization, input validation, dependency auditing, OWASP",
    "mobile": "Senior Mobile Engineer — native mobile, platform UX, offline-first architecture, app store deployment",
    "data": "Data Engineer — database optimization, migrations, analytics pipelines, data modeling",
    "writer": "Technical Writer — API documentation, user guides, developer onboarding, inline code docs",
    "architect": "Solutions Architect — system design, scalability planning, tech stack decisions",
    "designer": "UI/UX Designer — user flows, wireframes, design system, accessibility, visual consistency",
    "fullstack": "Senior Full-Stack Engineer — end-to-end feature delivery across frontend and backend",
    "lead": "Technical Lead — architecture decisions, code review, mentoring, shipping velocity",
}


def _require_auth():
    if not is_authenticated():
        console.print("[red]Not authenticated.[/red] Run [bold]shypmate auth login[/bold] first.")
        raise click.Abort()


def _mate_error(e: "ShypmateAPIError", name: str = "") -> None:
    """Print a standardized error message based on status code."""
    if e.status_code == 403:
        console.print("[red]Plan limit reached[/red] — upgrade at [bold]shypmate.dev/upgrade[/bold]")
    elif e.status_code == 404:
        label = f"'{name}'" if name else "Mate"
        console.print(f"[red]Mate {label} not found or is archived[/red]")
    elif e.status_code == 409:
        label = f"'{name}'" if name else "that name"
        console.print(f"[red]A mate named {label} already exists[/red]")
    else:
        console.print(f"[red]Error:[/red] {e.message}")


@click.group()
def team():
    """Manage your team of mates."""
    pass


@team.command("list")
def team_list():
    """List all mates."""
    _require_auth()
    client = ShypmateClient()

    try:
        mates = client.list_mates()
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        return

    if not mates:
        console.print("No mates yet. Run [bold]shypmate hire[/bold] to create one.")
        return

    installed = list_installed_skills()

    table = Table(show_header=True, header_style="bold")
    table.add_column("Mate", style="bold")
    table.add_column("Role")
    table.add_column("Projects")
    table.add_column("Memory")
    table.add_column("Local")

    for a in mates:
        name = a["name"]
        local = "[green]✓[/green]" if name in installed else "[yellow]—[/yellow]"
        projects = ", ".join(a.get("projects", [])) or "—"
        mem = str(a.get("memory_count", 0))
        table.add_row(f"/{name}", a.get("role", ""), projects, mem, local)

    console.print(table)


@click.command()
@click.argument("role_description")
@click.option("--project", default=None, help="Assign to a project ID")
def hire(role_description: str, project: str | None):
    """Hire a new mate by role or description.

    Supports shortcuts: qa, frontend, backend, devops, security, mobile,
    data, writer, architect, designer, fullstack, lead.
    """
    _require_auth()
    client = ShypmateClient()

    # Check for shortcuts
    key = role_description.lower().strip()
    if key in ROLE_SHORTCUTS:
        expanded = ROLE_SHORTCUTS[key]
        console.print(f"  Role shortcut: [bold]{key}[/bold] → {expanded}\n")
        role_description = expanded

    project_id = project or get_project_id()

    console.print(f"[bold]Hiring:[/bold] {role_description}")
    if project_id:
        console.print(f"  Project: {project_id}")
    console.print()

    try:
        with console.status("Generating mate persona..."):
            result = client.generate_mate(role_description, project_id=project_id)

        name = result["name"]
        role = result.get("role", "")
        skill_content = result.get("skill_md", "")

        console.print(f"[green]✓[/green] Hired: [bold]/{name}[/bold] — {role}")

        if skill_content:
            path = install_mate_skill(name, skill_content)
            console.print(f"  Installed to {path}")

        console.print(f"\n  Start working: [bold]claude /{name} \"your task here\"[/bold]")

    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")


@click.command()
@click.argument("mate_name")
@click.option("--archive", is_flag=True, help="Archive instead of permanently deleting")
def fire(mate_name: str, archive: bool):
    """Remove a mate from your team."""
    _require_auth()
    client = ShypmateClient()
    name = mate_name.lower().strip()

    try:
        client.delete_mate(name, archive=archive)
        action = "Archived" if archive else "Removed"
        console.print(f"[green]✓[/green] {action} [bold]/{name}[/bold]")

        if remove_mate_skill(name):
            console.print(f"  Removed local skill from ~/.claude/skills/{name}/")

        if archive:
            console.print(f"  To reinstate: [bold]shypmate rehire {name}[/bold]")

    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")


@click.command()
@click.argument("mate_name")
def rehire(mate_name: str):
    """Reinstate a previously archived mate."""
    _require_auth()
    client = ShypmateClient()
    name = mate_name.lower().strip()

    try:
        client.update_mate(name, {"archived": False})
        console.print(f"[green]✓[/green] Reinstated [bold]/{name}[/bold]")

        skill_content = client.get_mate_skill(name)
        if skill_content:
            path = install_mate_skill(name, skill_content)
            console.print(f"  Installed to {path}")

    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")


@click.command()
def roster():
    """Show detailed team roster."""
    _require_auth()
    client = ShypmateClient()

    try:
        mates = client.list_mates()
    except ShypmateAPIError as e:
        console.print(f"[red]Error:[/red] {e.message}")
        return

    if not mates:
        console.print("No mates. Run [bold]shypmate hire[/bold] to create one.")
        return

    console.print("\n[bold]Team roster[/bold]\n")

    for a in mates:
        name = a["name"]
        role = a.get("role", "")
        style = a.get("communication_style", "")
        bias = a.get("decision_bias", "")
        projects = ", ".join(a.get("projects", [])) or "(no project)"
        mem_count = a.get("memory_count", 0)

        console.print(f"  [bold]/{name}[/bold] — {role}")
        if style:
            console.print(f"    Style: {style}")
        if bias:
            console.print(f"    Bias:  {bias}")
        console.print(f"    Projects: {projects}")
        console.print(f"    Memory: {mem_count} entries")
        console.print()

    console.print(f"  Total: {len(mates)} mates")


# ── mate command group ──────────────────────────────────────────

@click.group()
def mate():
    """Add, copy, list, and archive mates."""
    pass


@mate.command("add")
@click.argument("name")
@click.option("--role", default=None, help="Role description for the mate")
def mate_add(name: str, role: str | None):
    """Add a mate by name, optionally with a role description."""
    _require_auth()
    client = ShypmateClient()
    slug = name.lower().strip()

    data = {"name": slug}
    if role:
        data["role"] = role

    try:
        with console.status(f"Adding /{slug}..."):
            result = client.create_mate(data)

        mate_name = result["name"]
        mate_role = result.get("role", "")
        skill_content = result.get("skill_md", "")

        console.print(f"[green]✓[/green] Added: [bold]/{mate_name}[/bold]" + (f" — {mate_role}" if mate_role else ""))

        # If role was provided and no skill yet, generate a persona
        if role and not skill_content:
            try:
                with console.status(f"Generating persona for /{mate_name}..."):
                    gen = client.generate_mate_persona(mate_name, role=role)
                skill_content = gen.get("skill_md", "")
            except ShypmateAPIError:
                pass  # Falls back to template skill_md from create response

        if skill_content:
            path = install_mate_skill(mate_name, skill_content)
            console.print(f"  Installed to {path}")

        console.print(f"\n  Start working: [bold]claude /{mate_name} \"your task here\"[/bold]")

    except ShypmateAPIError as e:
        _mate_error(e, slug)


@mate.command("generate")
@click.argument("name")
@click.option("--role", default=None, help="Update the role before generating")
def mate_generate(name: str, role: str | None):
    """Generate or regenerate a mate's AI persona."""
    _require_auth()
    client = ShypmateClient()
    slug = name.lower().strip()

    try:
        with console.status(f"Generating persona for /{slug}..."):
            result = client.generate_mate_persona(slug, role=role)

        skill_content = result.get("skill_md", "")
        mate_role = result.get("role", "")

        console.print(f"[green]✓[/green] Persona generated for [bold]/{slug}[/bold]" + (f" — {mate_role}" if mate_role else ""))

        if skill_content:
            path = install_mate_skill(slug, skill_content)
            console.print(f"  Installed to {path}")
        else:
            console.print("  [yellow]No skill content returned — try again or check server logs[/yellow]")

        console.print(f"\n  Start working: [bold]claude /{slug} \"your task here\"[/bold]")

    except ShypmateAPIError as e:
        _mate_error(e, slug)


@mate.command("copy")
@click.argument("source")
@click.argument("new_name")
def mate_copy(source: str, new_name: str):
    """Copy a mate's role and skill to a new name."""
    _require_auth()
    client = ShypmateClient()
    src = source.lower().strip()
    dst = new_name.lower().strip()

    try:
        with console.status(f"Copying /{src} → /{dst}..."):
            result = client.copy_mate(src, dst)

        skill_content = result.get("skill_md", "")
        console.print(f"[green]✓[/green] Copied [bold]/{src}[/bold] → [bold]/{dst}[/bold]")

        if skill_content:
            path = install_mate_skill(dst, skill_content)
            console.print(f"  Installed to {path}")

        console.print(f"\n  Start working: [bold]claude /{dst} \"your task here\"[/bold]")

    except ShypmateAPIError as e:
        _mate_error(e, dst if e.status_code == 409 else src)


@mate.command("list")
def mate_list():
    """List all mates."""
    _require_auth()
    client = ShypmateClient()

    try:
        mates = client.list_mates()
    except ShypmateAPIError as e:
        _mate_error(e)
        return

    if not mates:
        console.print("No mates yet. Run [bold]shypmate mate add <name>[/bold] to create one.")
        return

    installed = list_installed_skills()

    table = Table(show_header=True, header_style="bold")
    table.add_column("Mate", style="bold")
    table.add_column("Role")
    table.add_column("Connections")
    table.add_column("Last connected")
    table.add_column("Local")

    for m in mates:
        name = m["name"]
        local = "[green]✓[/green]" if name in installed else "[yellow]—[/yellow]"
        connections = str(m.get("connection_count", 0))
        last = m.get("last_connected") or "—"
        table.add_row(f"/{name}", m.get("role", ""), connections, last, local)

    console.print(table)


@mate.command("deactivate")
@click.option("--quiet", is_flag=True, hidden=True)
def mate_deactivate(quiet: bool):
    """Mark the active mate as disconnected (called by Stop hook)."""
    active_file = Path(".shypmate") / "active-mate"
    compacting_flag = Path(".shypmate") / ".compacting"

    # If a compact/clear is in progress, skip deactivation — mate is resuming
    if compacting_flag.exists():
        compacting_flag.unlink(missing_ok=True)
        return

    if not active_file.exists():
        return

    mate_name = active_file.read_text().strip()
    if not mate_name:
        active_file.unlink(missing_ok=True)
        return

    active_file.unlink(missing_ok=True)

    if not is_authenticated():
        return

    try:
        ShypmateClient().disconnect_mate(get_machine_id(), mate_name)
        if not quiet:
            console.print(f"[dim]/{mate_name} disconnected[/dim]")
    except Exception:
        pass  # Best-effort — don't block session exit


@mate.command("archive")
@click.argument("name")
@click.confirmation_option(prompt="Remove local skill files too?")
def mate_archive(name: str):
    """Archive a mate and remove local skill files."""
    _require_auth()
    client = ShypmateClient()
    slug = name.lower().strip()

    try:
        client.delete_mate(slug, archive=True)
        console.print(f"[green]✓[/green] Archived [bold]/{slug}[/bold]")

        if remove_mate_skill(slug):
            console.print(f"  Removed local skill files for /{slug}")

    except ShypmateAPIError as e:
        _mate_error(e, slug)
