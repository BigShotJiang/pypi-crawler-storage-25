"""Watch command — autonomous handoff processing."""

import shutil
import subprocess
import time
from pathlib import Path

import click
from rich.console import Console

from shypmate.api import ShypmateClient, ShypmateAPIError
from shypmate.config import get_project_config, is_authenticated, is_initialized

console = Console()

CLAUDE_TIMEOUT = 300  # 5 minutes per task


def _find_claude() -> str | None:
    """Find the claude CLI binary for the current platform."""
    return shutil.which("claude")


def _invoke_claude(mate_name: str, message: str) -> str:
    """Run claude non-interactively with the mate's skill loaded as context."""
    claude = _find_claude()
    if not claude:
        return "Error: Claude CLI not found. Install Claude Code to process handoffs."

    skill_file = Path.home() / ".claude" / "skills" / mate_name / "SKILL.md"
    if skill_file.exists():
        skill_content = skill_file.read_text().strip()
        prompt = f"{skill_content}\n\n---\n\n{message}"
    else:
        prompt = message

    try:
        result = subprocess.run(
            [claude, "-p", prompt],
            capture_output=True,
            text=True,
            timeout=CLAUDE_TIMEOUT,
        )
        output = result.stdout.strip() or result.stderr.strip()
        return output or "No response from Claude."
    except subprocess.TimeoutExpired:
        return f"Task timed out after {CLAUDE_TIMEOUT // 60} minutes."
    except Exception as e:
        return f"Error invoking Claude: {e}"


def _process_handoff(
    client: ShypmateClient, handoff: dict, project_id: str, mate_name: str
) -> None:
    """Invoke Claude on a handoff, send result back, mark original as read."""
    handoff_id = handoff["id"]
    from_mate = handoff["from_mate"]
    message = handoff["message"]
    preview = message[:80] + ("..." if len(message) > 80 else "")

    console.print(f"\n  [bold]Handoff from /{from_mate}:[/bold] {preview}")

    with console.status(f"  /{mate_name} working..."):
        result = _invoke_claude(mate_name, message)

    console.print(f"  [dim]Response: {len(result)} chars[/dim]")

    try:
        client.create_handoff(
            project_id=project_id,
            from_mate=mate_name,
            to_mate=from_mate,
            message=result,
        )
        console.print(f"  [green]✓[/green] Result sent to /{from_mate}")
    except ShypmateAPIError as e:
        console.print(f"  [red]Failed to send result:[/red] {e.message}")

    try:
        client.mark_handoff_read(handoff_id)
    except Exception:
        pass


@click.command()
@click.option("--mate", required=True, help="Mate name to watch for incoming handoffs")
@click.option(
    "--interval",
    default=30,
    show_default=True,
    help="Poll interval in seconds",
)
@click.option(
    "--once",
    is_flag=True,
    help="Process the first pending handoff then exit",
)
def watch(mate: str, interval: int, once: bool):
    """Watch for handoffs and process them autonomously with Claude.

    Polls for handoffs addressed to MATE, invokes Claude non-interactively
    to perform the work, then sends the result back to the original sender.

    Example:

        shypmate watch --mate terry
    """
    if not is_authenticated():
        console.print("[red]Not authenticated.[/red] Run [bold]shypmate auth login[/bold] first.")
        raise click.Abort()

    if not is_initialized():
        console.print("[yellow]Not initialized.[/yellow] Run [bold]shypmate init[/bold] first.")
        raise click.Abort()

    claude = _find_claude()
    if not claude:
        console.print("[red]Claude CLI not found.[/red] Install Claude Code to use shypmate watch.")
        raise click.Abort()

    config = get_project_config()
    project_id = config.get("project_id", "")
    mate_name = mate.lower().strip()

    skill_file = Path.home() / ".claude" / "skills" / mate_name / "SKILL.md"
    if not skill_file.exists():
        console.print(
            f"[yellow]Warning:[/yellow] No skill found for /{mate_name} — "
            "run [bold]shypmate sync[/bold] to install skills."
        )

    console.print()
    console.print(f"  [bold]/{mate_name}[/bold] watching for handoffs")
    console.print(f"  Polling every {interval}s  •  {claude}")
    if once:
        console.print("  [dim]--once: will exit after first handoff[/dim]")
    console.print("  Ctrl+C to stop\n")

    client = ShypmateClient()

    try:
        while True:
            try:
                handoffs = client.get_handoffs(project_id=project_id, to_mate=mate_name)
            except ShypmateAPIError as e:
                console.print(f"  [red]Poll error:[/red] {e.message}")
                time.sleep(interval)
                continue

            for handoff in handoffs:
                _process_handoff(client, handoff, project_id, mate_name)
                if once:
                    console.print("\n  [dim]Done.[/dim]")
                    return

            time.sleep(interval)

    except KeyboardInterrupt:
        console.print("\n  [dim]Stopped.[/dim]")
