from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.environment_response import EnvironmentResponse
from ...models.http_validation_error import HTTPValidationError
from ...models.set_variable_request import SetVariableRequest
from ...types import UNSET, Response


def _get_kwargs(
    key: str,
    *,
    body: SetVariableRequest,
    project_id: str,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    params: dict[str, Any] = {}

    params["projectId"] = project_id

    params = {k: v for k, v in params.items() if v is not UNSET and v is not None}

    _kwargs: dict[str, Any] = {
        "method": "put",
        "url": "/v1/environments/{key}".format(
            key=quote(str(key), safe=""),
        ),
        "params": params,
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> EnvironmentResponse | HTTPValidationError | None:
    if response.status_code == 200:
        response_200 = EnvironmentResponse.from_dict(response.json())

        return response_200

    if response.status_code == 422:
        response_422 = HTTPValidationError.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[EnvironmentResponse | HTTPValidationError]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    key: str,
    *,
    client: AuthenticatedClient | Client,
    body: SetVariableRequest,
    project_id: str,
) -> Response[EnvironmentResponse | HTTPValidationError]:
    """Set Variable

     Create or update a single environment variable.

    Args:
        key (str):
        project_id (str):
        body (SetVariableRequest): Create or update a single variable.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EnvironmentResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        key=key,
        body=body,
        project_id=project_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    key: str,
    *,
    client: AuthenticatedClient | Client,
    body: SetVariableRequest,
    project_id: str,
) -> EnvironmentResponse | HTTPValidationError | None:
    """Set Variable

     Create or update a single environment variable.

    Args:
        key (str):
        project_id (str):
        body (SetVariableRequest): Create or update a single variable.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EnvironmentResponse | HTTPValidationError
    """

    return sync_detailed(
        key=key,
        client=client,
        body=body,
        project_id=project_id,
    ).parsed


async def asyncio_detailed(
    key: str,
    *,
    client: AuthenticatedClient | Client,
    body: SetVariableRequest,
    project_id: str,
) -> Response[EnvironmentResponse | HTTPValidationError]:
    """Set Variable

     Create or update a single environment variable.

    Args:
        key (str):
        project_id (str):
        body (SetVariableRequest): Create or update a single variable.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[EnvironmentResponse | HTTPValidationError]
    """

    kwargs = _get_kwargs(
        key=key,
        body=body,
        project_id=project_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    key: str,
    *,
    client: AuthenticatedClient | Client,
    body: SetVariableRequest,
    project_id: str,
) -> EnvironmentResponse | HTTPValidationError | None:
    """Set Variable

     Create or update a single environment variable.

    Args:
        key (str):
        project_id (str):
        body (SetVariableRequest): Create or update a single variable.

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        EnvironmentResponse | HTTPValidationError
    """

    return (
        await asyncio_detailed(
            key=key,
            client=client,
            body=body,
            project_id=project_id,
        )
    ).parsed
