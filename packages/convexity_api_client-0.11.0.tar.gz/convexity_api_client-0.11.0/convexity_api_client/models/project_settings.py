from __future__ import annotations

from collections.abc import Mapping
from typing import TYPE_CHECKING, Any, Literal, TypeVar, cast

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.app_settings import AppSettings
    from ..models.env_settings import EnvSettings


T = TypeVar("T", bound="ProjectSettings")


@_attrs_define
class ProjectSettings:
    """Versioned project settings persisted as JSON.

    The `version` field enables forward-compatible schema migrations:
    deserialise → detect version → upgrade in-place → persist.

        Attributes:
            version (str | Unset): Schema version for forward-compatible migrations Default: '1'.
            type_ (Literal['project_settings'] | Unset): Discriminator for settings type Default: 'project_settings'.
            apps (AppSettings | Unset): App-related project settings.
            env (EnvSettings | Unset): Project-level environment variables (like a .env file).
    """

    version: str | Unset = "1"
    type_: Literal["project_settings"] | Unset = "project_settings"
    apps: AppSettings | Unset = UNSET
    env: EnvSettings | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> dict[str, Any]:
        version = self.version

        type_ = self.type_

        apps: dict[str, Any] | Unset = UNSET
        if not isinstance(self.apps, Unset):
            apps = self.apps.to_dict()

        env: dict[str, Any] | Unset = UNSET
        if not isinstance(self.env, Unset):
            env = self.env.to_dict()

        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({})
        if version is not UNSET:
            field_dict["version"] = version
        if type_ is not UNSET:
            field_dict["type"] = type_
        if apps is not UNSET:
            field_dict["apps"] = apps
        if env is not UNSET:
            field_dict["env"] = env

        return field_dict

    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.app_settings import AppSettings
        from ..models.env_settings import EnvSettings

        d = dict(src_dict)
        version = d.pop("version", UNSET)

        type_ = cast(Literal["project_settings"] | Unset, d.pop("type", UNSET))
        if type_ != "project_settings" and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'project_settings', got '{type_}'")

        _apps = d.pop("apps", UNSET)
        apps: AppSettings | Unset
        if isinstance(_apps, Unset):
            apps = UNSET
        else:
            apps = AppSettings.from_dict(_apps)

        _env = d.pop("env", UNSET)
        env: EnvSettings | Unset
        if isinstance(_env, Unset):
            env = UNSET
        else:
            env = EnvSettings.from_dict(_env)

        project_settings = cls(
            version=version,
            type_=type_,
            apps=apps,
            env=env,
        )

        project_settings.additional_properties = d
        return project_settings

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
