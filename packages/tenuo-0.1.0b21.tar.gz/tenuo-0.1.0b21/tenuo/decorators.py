"""
Decorators for Tenuo authorization.

Supports both explicit warrant passing and ContextVar-based context (for LangChain/FastAPI).

Example with explicit warrant:
    @guard(warrant, tool="manage_infrastructure")
    def scale_cluster(cluster: str, replicas: int):
        # This function can only be called if the warrant authorizes it
        ...

Example with ContextVar (LangChain/FastAPI pattern):
    from tenuo import warrant_scope, key_scope

    # Set warrant and keypair in context (e.g., in FastAPI middleware)
    with warrant_scope(warrant), key_scope(keypair):
        scale_cluster(cluster="staging-web", replicas=5)

    @guard(tool="manage_infrastructure")
    def scale_cluster(cluster: str, replicas: int):
        # Warrant and keypair are automatically retrieved from context
        # PoP signature is created automatically if warrant.requires_pop
        ...

Audit Logging:
    All authorization decisions are logged as structured JSON events.
    Configure via: tenuo.audit.audit_logger.configure(service_name="my-service")

IMPORTANT: Async Context Sharp Edges
====================================
Python contextvars work correctly with:
- `async def` functions and `await`
- `asyncio.gather()` / `asyncio.wait()`

But NOT automatically with:
- `asyncio.create_task()` called BEFORE context is set
- `concurrent.futures.ThreadPoolExecutor` / `ProcessPoolExecutor`
- Callbacks scheduled with `loop.call_soon()` / `loop.call_later()`

For thread pools, use `contextvars.copy_context().run(fn)` or
the helper `tenuo.spawn()` when available.
"""

import logging
import traceback
import warnings
from contextvars import ContextVar
from functools import wraps
from typing import Any, Callable, List, Literal, Optional, Union, get_args, get_origin, get_type_hints, overload

from typing_extensions import Annotated

from .audit import AuditEvent, AuditEventType, audit_logger
from .exceptions import (
    AuthorizationDenied,
    ConfigurationError,
    ConstraintResult,
    ExpiredError,
    MissingSignature,
    MissingSigningKey,
    ScopeViolation,
    ToolNotAuthorized,
)
from ._enforcement import EnforcementResult, enforce_tool_call
from .bound_warrant import BoundWarrant

logger = logging.getLogger("tenuo.decorators")


# =============================================================================
# Error Codes for Structured Logging
# =============================================================================


class AuthErrorCode:
    """Standard error codes for authorization failures."""

    MISSING_CONTEXT = "MISSING_CONTEXT"  # No warrant in context
    INVALID_WARRANT = "INVALID_WARRANT"  # Warrant malformed or wrong type
    EXPIRED = "EXPIRED"  # Warrant has expired
    SCOPE_VIOLATION = "SCOPE_VIOLATION"  # Tool not in warrant.tools
    CONSTRAINT_VIOLATION = "CONSTRAINT_VIOLATION"  # Args don't satisfy constraints
    POP_MISSING = "POP_MISSING"  # SigningKey not available for PoP


# Custom warning category for integration issues
class SecurityWarning(UserWarning):
    """Warning for potential security/integration issues."""

    pass


def _get_callsite() -> str:
    """
    Get the callsite (filename:line) of the tool invocation.

    Walks up the stack to find the first frame outside tenuo internals.
    """
    for frame_info in traceback.extract_stack():
        # Skip tenuo internals
        if "/tenuo/" in frame_info.filename or frame_info.filename.endswith("decorators.py"):
            continue
        return f"{frame_info.filename}:{frame_info.lineno}"
    return "unknown"


def _make_actionable_error(
    error_code: str,
    tool_name: str,
    func_name: str,
    callsite: str,
    details: str,
) -> str:
    """Create an actionable error message that helps developers fix the issue."""
    base = f"[{error_code}] {details}\n"
    base += f"\n  Tool: {tool_name}"
    base += f"\n  Function: {func_name}"
    base += f"\n  Location: {callsite}"

    # Add specific fix suggestions based on error code
    if error_code == AuthErrorCode.MISSING_CONTEXT:
        base += "\n\nTo fix:"
        base += '\n  1. Wrap the call with: async with root_task(Capability("<tool>", ...)):'
        base += "\n  2. Or use: with warrant_scope(warrant), key_scope(keypair):"
        base += f"\n  3. Or pass warrant explicitly: @guard(warrant, tool='{tool_name}')"
    elif error_code == AuthErrorCode.POP_MISSING:
        base += "\n\nTo fix:"
        base += "\n  1. Add keypair to context: with key_scope(keypair):"
        base += "\n  2. Or use root_task() which handles this automatically"
    elif error_code == AuthErrorCode.EXPIRED:
        base += "\n\nTo fix:"
        base += "\n  1. Issue a new warrant with root_task()"
        base += "\n  2. Or check TTL configuration"
    elif error_code == AuthErrorCode.SCOPE_VIOLATION:
        base += "\n\nTo fix:"
        base += f'\n  1. Add a capability for this tool: root_task(Capability("{tool_name}", ...))'
        base += "\n  2. Or use scoped_task to narrow from parent warrant"
    elif error_code == AuthErrorCode.CONSTRAINT_VIOLATION:
        base += "\n\nTo fix:"
        base += "\n  1. Check if the function arguments satisfy the warrant constraints"
        base += "\n  2. Or issue a warrant with appropriate constraints"

    return base


# Runtime imports (after class definitions above)
from tenuo_core import SigningKey, Warrant  # type: ignore[import-untyped]  # noqa: E402

# =============================================================================
# Annotated Type Hint Extraction
# =============================================================================


def _is_tenuo_constraint(obj: Any) -> bool:
    """Check if an object is a Tenuo constraint (Pattern, Exact, Range, etc.)."""
    # Check by class name since we can't import all constraint types here
    constraint_types = {
        "Pattern",
        "Exact",
        "Range",
        "OneOf",
        "NotOneOf",
        "Contains",
        "Subset",
        "Regex",
        "Cidr",
        "UrlPattern",
        "CEL",
        "All",
        "AnyOf",
        "Not",
        "Subpath",
        "UrlSafe",
        "Shlex",
        "Wildcard",
    }
    return type(obj).__name__ in constraint_types


def _check_annotated_constraint(constraint: Any, value: Any) -> bool:
    """
    Check if a value satisfies an annotated constraint using Rust core bindings.

    SECURITY: Type-aware dispatch to ensure correct Rust method is called.
    Fails closed (returns False) for unknown constraint types.

    All constraint runtime checks use Rust core bindings:
      - Subpath.contains()     -> Rust core
      - UrlSafe.is_safe()      -> Rust core
      - Cidr.contains_ip()     -> Rust core
      - Pattern.matches()      -> Rust core
      - Shlex.matches()        -> Python shlex (full POSIX parsing)
      - Range.contains()       -> Rust core
      - Exact.matches()        -> Rust core
      - OneOf.contains()       -> Rust core
      - NotOneOf.allows()      -> Rust core
      - Wildcard.matches()     -> Rust core
    """
    constraint_type = type(constraint).__name__

    try:
        # Subpath - filesystem path containment (Rust core)
        if hasattr(constraint, "contains") and constraint_type == "Subpath":
            return constraint.contains(str(value))

        # UrlSafe - SSRF protection (Rust core)
        if hasattr(constraint, "is_safe"):
            return constraint.is_safe(str(value))

        # Cidr - IP address range (Rust core)
        if hasattr(constraint, "contains_ip"):
            return constraint.contains_ip(str(value))

        # Pattern - glob matching (Rust core)
        if hasattr(constraint, "matches") and constraint_type == "Pattern":
            return constraint.matches(value)

        # Shlex - shell command validation (Python full shlex parsing)
        if hasattr(constraint, "matches") and constraint_type == "Shlex":
            return constraint.matches(str(value))

        # UrlPattern - URL pattern matching (Rust core)
        if hasattr(constraint, "matches_url"):
            return constraint.matches_url(str(value))

        # Range - numeric bounds (Rust core)
        if hasattr(constraint, "contains") and constraint_type == "Range":
            try:
                return constraint.contains(float(value))
            except (ValueError, TypeError):
                return False

        # Exact - exact value match (Rust core)
        if hasattr(constraint, "matches") and constraint_type == "Exact":
            return constraint.matches(str(value))

        # OneOf - set membership (Rust core)
        if hasattr(constraint, "contains") and constraint_type == "OneOf":
            return constraint.contains(str(value))

        # NotOneOf - exclusion list (Rust core)
        if hasattr(constraint, "allows") and constraint_type == "NotOneOf":
            return constraint.allows(str(value))

        # Wildcard - matches anything (Rust core)
        if hasattr(constraint, "matches") and constraint_type == "Wildcard":
            return constraint.matches(str(value))

        # Regex - regex matching (Rust core)
        if hasattr(constraint, "matches") and constraint_type == "Regex":
            return constraint.matches(value)

        # Fallback: generic matches() for other constraints
        if hasattr(constraint, "matches"):
            return constraint.matches(value)

        # Fallback: check() method (some libraries use this)
        if hasattr(constraint, "check"):
            return constraint.check(value)

        # Fallback: equality for Exact values without methods
        if hasattr(constraint, "value"):
            return constraint.value == value

        # Unknown constraint type - FAIL CLOSED
        logger.warning(f"Unknown constraint type '{constraint_type}' in type annotation - failing closed")
        return False

    except Exception as e:
        logger.warning(f"Constraint check failed with exception: {e} - failing closed")
        return False


def _extract_annotated_constraints(func: Callable) -> dict[str, Any]:
    """
    Extract Tenuo constraints from Annotated type hints.

    Example:
        def read_file(path: Annotated[str, Pattern("/data/*")]) -> str: ...

    Returns:
        {"path": Pattern("/data/*")}
    """
    constraints: dict[str, Any] = {}

    try:
        hints = get_type_hints(func, include_extras=True)
    except Exception:
        return constraints

    for param_name, hint in hints.items():
        if param_name == "return":
            continue

        # Check if it's Annotated[T, ...]
        if get_origin(hint) is Annotated:
            args = get_args(hint)
            # args[0] is the base type, args[1:] are the annotations
            for annotation in args[1:]:
                if _is_tenuo_constraint(annotation):
                    constraints[param_name] = annotation
                    break

    return constraints


# Context variable for warrant storage (works with both threads and asyncio)
# This allows warrants to be passed through async call stacks without explicit threading
_warrant_context: ContextVar[Optional[Warrant]] = ContextVar("_warrant_context", default=None)

# Context variable for keypair storage (for PoP signatures)
_keypair_context: ContextVar[Optional[SigningKey]] = ContextVar("_keypair_context", default=None)

# Context variable for parent warrant chain (root-first, excluding the leaf).
# Set alongside warrant_scope when the active warrant is a delegated child.
# SecureMCPClient reads this to encode a WarrantStack on the wire.
_chain_context: ContextVar[Optional[List[Any]]] = ContextVar("_chain_context", default=None)

# Context variable for allowed tools (narrower than warrant.tools)
# Used by scoped_task to restrict tools beyond what the warrant allows
_allowed_tools_context: ContextVar[Optional[List[str]]] = ContextVar("_allowed_tools_context", default=None)

# Context variable for test bypass mode (set by allow_all())
# When True, @guard skips authorization entirely
# SECURITY: Only works when TENUO_ENV=test to prevent accidental production bypass
_bypass_context: ContextVar[bool] = ContextVar("_bypass_context", default=False)

def is_bypass_enabled() -> bool:
    """
    Check if authorization bypass is enabled (for testing).

    SECURITY: Bypass only works when TENUO_ENV environment variable is set to 'test'.
    This prevents accidental enablement in production.

    Returns:
        True if bypass is enabled AND we're in test mode, False otherwise.
    """
    import os

    if not _bypass_context.get():
        return False

    # SECURITY GUARD: Only allow bypass in test environment
    env = os.environ.get("TENUO_ENV", "").lower()
    if env != "test":
        # Log warning but don't bypass - someone tried to enable bypass in non-test env
        import warnings

        warnings.warn(
            "[SECURITY] Bypass mode requested but TENUO_ENV != 'test'. "
            "Bypass is disabled. Set TENUO_ENV=test to enable bypass for testing.",
            SecurityWarning,
            stacklevel=2,
        )
        return False

    return True


def get_warrant_context() -> Optional[Warrant]:
    """
    Get the current warrant from context.

    Returns:
        The warrant in the current context, or None if not set.
    """
    return _warrant_context.get()


def get_signing_key_context() -> Optional[SigningKey]:
    """
    Get the current signing key from context.

    Returns:
        The signing key in the current context, or None if not set.
    """
    return _keypair_context.get()


def get_allowed_tools_context() -> Optional[List[str]]:
    """
    Get the current allowed tools from context.

    This returns the tools restricted by scoped_task, which may be
    narrower than what the warrant.tools field allows.

    Returns:
        List of allowed tool names, or None if not restricted.
    """
    return _allowed_tools_context.get()


@overload
def warrant_scope() -> Optional[Warrant]: ...
@overload
def warrant_scope(warrant: Warrant) -> "WarrantContext": ...


def warrant_scope(warrant: Optional[Warrant] = None) -> Union[Optional[Warrant], "WarrantContext"]:
    """
    Get or set the warrant context.

    Usage as getter (no args):
        warrant = warrant_scope()

    Usage as setter (context manager):
        with warrant_scope(warrant):
            process_request()  # @guard uses this warrant
    """
    if warrant is None:
        return _warrant_context.get()
    return WarrantContext(warrant)


@overload
def key_scope() -> Optional[SigningKey]: ...
@overload
def key_scope(keypair: SigningKey) -> "SigningKeyContext": ...


def key_scope(keypair: Optional[SigningKey] = None) -> Union[Optional[SigningKey], "SigningKeyContext"]:
    """
    Get or set the signing key context.

    Usage as getter (no args):
        key = key_scope()

    Usage as setter (context manager):
        with key_scope(keypair):
            process_request()  # @guard uses this key for PoP
    """
    if keypair is None:
        return _keypair_context.get()
    return SigningKeyContext(keypair)


def chain_scope(parents=None):
    """Get or set the parent warrant chain context.

    The chain is a list of parent warrants in root-first order,
    **excluding** the leaf (which lives in ``warrant_scope``).
    ``SecureMCPClient`` reads this to encode a WarrantStack on the wire
    so the server can verify the full delegation path.

    Usage as getter (no args):
        parents = chain_scope()

    Usage as setter (context manager):
        with chain_scope([root_warrant]):
            with warrant_scope(worker_warrant):
                await client.call_tool(...)
    """
    if parents is None:
        return _chain_context.get()
    return ChainContext(parents)


class ChainContext:
    """Context manager for setting the parent warrant chain."""

    def __init__(self, parents: list):
        self.parents = parents
        self.token = None

    def __enter__(self):
        self.token = _chain_context.set(self.parents)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.token is not None:
            _chain_context.reset(self.token)
        return False


class WarrantContext:
    """Context manager for setting warrant in ContextVar."""

    def __init__(self, warrant: Warrant):
        self.warrant = warrant
        self.token = None

    def __enter__(self):
        self.token = _warrant_context.set(self.warrant)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.token is not None:
            _warrant_context.reset(self.token)
        return False


class SigningKeyContext:
    """Context manager for setting keypair in ContextVar (for PoP)."""

    def __init__(self, keypair: SigningKey):
        self.keypair = keypair
        self.token = None

    def __enter__(self):
        self.token = _keypair_context.set(self.keypair)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self.token is not None:
            _keypair_context.reset(self.token)
        return False


# =============================================================================
# Bridge: EnforcementResult → @guard's exception & audit contract
# =============================================================================


def _reraise_if_crypto(
    result: EnforcementResult,
    warrant: Warrant,
) -> None:
    """Re-raise crypto exceptions that ``enforce_tool_call`` caught internally.

    ``enforce_tool_call`` wraps all failures — including ``SignatureInvalid``,
    ``ExpiredError``, and ``MissingSignature`` — into ``EnforcementResult``.
    ``@guard`` historically propagated these directly, and callers (including
    tests) may be catching them specifically.  Detect them from the result
    metadata and re-raise to preserve backward compatibility.
    """
    from tenuo.exceptions import SignatureInvalid as _SigInvalid

    et = result.error_type or ""

    if et == "expired":
        expires_at = warrant.expires_at() if hasattr(warrant, "expires_at") else "unknown"
        raise ExpiredError(
            warrant_id=warrant.id if hasattr(warrant, "id") else "unknown",
            expired_at=str(expires_at),
        )

    # enforce_tool_call labels crypto failures "tenuo_error" (sign path)
    # or "authorization_failed" (verify path).  Inspect the denial_reason
    # to distinguish signature failures from policy denials.
    dr = (result.denial_reason or "").lower()
    _sig_keywords = ("signature", "pop", "proof-of-possession")
    _sig_indicators = ("invalid", "failed", "verification", "mismatch", "missing")
    if any(kw in dr for kw in _sig_keywords) and any(ind in dr for ind in _sig_indicators):
        raise _SigInvalid(reason=result.denial_reason or "Signature verification failed")


def _map_result_to_guard_error(
    result: EnforcementResult,
    warrant_to_use: Warrant,
    tool_name: str,
    auth_args: dict,
    callsite: str,
    func_name: str,
) -> None:
    """Translate a denied ``EnforcementResult`` into the same exceptions and
    audit events that ``@guard``'s inline enforcement block historically
    produced.

    This preserves:
    - ``ToolNotAuthorized`` with ``authorized_tools`` and a mint hint
    - ``AuthorizationDenied`` with ``ConstraintResult`` list and explorer URL
    - ``why_denied().suggestion`` passthrough
    - Structured ``audit_logger`` events with callsite/function metadata

    Raises ``ToolNotAuthorized`` or ``AuthorizationDenied``; never returns.
    """
    from .warrant_ext import DenyCode as _DenyCode

    why = warrant_to_use.why_denied(tool_name, auth_args)

    _is_tool_not_granted = why.deny_code == _DenyCode.TOOL_NOT_FOUND or (
        why.deny_code == _DenyCode.CONSTRAINT_MISMATCH
        and getattr(why, "field", None) == "tool"
    )

    if _is_tool_not_granted:
        error_code = AuthErrorCode.SCOPE_VIOLATION

        audit_logger.log(
            AuditEvent(
                event_type=AuditEventType.AUTHORIZATION_FAILURE,
                warrant_id=warrant_to_use.id if hasattr(warrant_to_use, "id") else None,
                tool=tool_name,
                action="denied",
                error_code=error_code,
                details=f"Tool '{tool_name}' not in warrant grants",
                metadata={
                    "callsite": callsite,
                    "function": func_name,
                },
            )
        )

        raise ToolNotAuthorized(
            tool=tool_name,
            authorized_tools=getattr(warrant_to_use, "tools", []) or [],
            hint=f"Add Capability('{tool_name}', ...) to your mint() call",
        )

    # Constraint / policy violation
    error_code = AuthErrorCode.CONSTRAINT_VIOLATION

    constraint_results = []
    if getattr(why, "field", None):
        constraint_results.append(
            ConstraintResult(
                name=why.field,
                passed=False,
                constraint_repr="<see warrant>",
                value=auth_args.get(why.field, "<not provided>"),
                explanation=getattr(why, "suggestion", None) or "Constraint not satisfied",
            )
        )
    else:
        for arg_name, arg_value in auth_args.items():
            constraint_results.append(
                ConstraintResult(
                    name=arg_name,
                    passed=False,
                    constraint_repr="<see warrant>",
                    value=arg_value,
                    explanation="Value does not satisfy constraint",
                )
            )

    audit_logger.log(
        AuditEvent(
            event_type=AuditEventType.AUTHORIZATION_FAILURE,
            warrant_id=warrant_to_use.id if hasattr(warrant_to_use, "id") else None,
            tool=tool_name,
            action="denied",
            constraints=auth_args,
            trace_id=warrant_to_use.session_id if hasattr(warrant_to_use, "session_id") else None,
            error_code=error_code,
            details=f"Constraint violation for '{tool_name}'",
            metadata={
                    "callsite": callsite,
                    "function": func_name,
                    "provided_args": {k: str(v)[:100] for k, v in auth_args.items()},
                    "suggestion": why.suggestion if hasattr(why, "suggestion") else None,
                },
        )
    )

    # Build explorer URL for debugging
    warrant_b64 = warrant_to_use.to_base64() if hasattr(warrant_to_use, "to_base64") else ""
    if warrant_b64:
        import base64 as b64_mod
        import json as json_mod
        import urllib.parse

        state = {"warrant": warrant_b64, "tool": tool_name, "args": json_mod.dumps(auth_args)}
        state_b64 = b64_mod.b64encode(json_mod.dumps(state).encode()).decode()
        explorer_url = f"https://tenuo.ai/explorer/?s={urllib.parse.quote(state_b64)}"
    else:
        explorer_url = None

    hint = why.suggestion if hasattr(why, "suggestion") else None
    if explorer_url:
        hint = f"{hint}\n\n🔗 Debug: {explorer_url}" if hint else f"🔗 Debug: {explorer_url}"

    raise AuthorizationDenied(
        tool=tool_name,
        constraint_results=constraint_results,
        reason="Arguments do not satisfy warrant constraints",
        hint=hint,
    )


def guard(
    warrant_or_tool: Optional[Union[Warrant, str]] = None,
    tool: Optional[str] = None,
    keypair: Optional[SigningKey] = None,
    extract_args: Optional[Callable[..., dict]] = None,
    mapping: Optional[dict[str, str]] = None,
    trusted_roots: Optional[list] = None,
    verify_mode: Literal["sign", "verify"] = "sign",
    authorizer: Optional[Any] = None,
    extract_signature: Optional[Callable[..., bytes]] = None,
    extract_chain: Optional[Callable[..., list]] = None,
    approval_handler: Optional[Any] = None,
):
    """
    Decorator that enforces warrant authorization before function execution.

    IMPORTANT: PoP is MANDATORY
    ---------------------------
    Keypair must always be available (either provided or in context) because
    Proof-of-Possession is mandatory. This ensures leaked warrants are useless
    without the corresponding private key.

    Supports multiple usage patterns:

    1. Minimal (tool name inferred from function name):
        @guard
        def search(query: str): ...  # tool="search"

    2. With Annotated constraints (auto-extracted):
        @guard
        def read_file(path: Annotated[str, Pattern("/data/*")]) -> str: ...

    3. Explicit tool name:
        @guard(tool="manage_infrastructure")
        def scale_cluster(cluster: str, replicas: int): ...

    4. Explicit warrant (for non-context usage):
        @guard(warrant, tool="manage_infrastructure", keypair=keypair)
        def scale_cluster(cluster: str, replicas: int): ...

    5. With explicit trust anchor (production recommended):
        @guard(trusted_roots=[control_plane_key.public_key])
        def read_file(path: str): ...

    Args:
        warrant_or_tool: If Warrant instance, use it explicitly. If str, treat as tool name.
                        If None, tool is inferred from function name.
        tool: The tool name to authorize (optional - inferred from function name if not provided)
        keypair: SigningKey for PoP signature (required - or use key_scope)
        extract_args: Optional function to extract args from function arguments.
                     If None, uses the function's kwargs as args.
        mapping: Optional dictionary mapping function argument names to constraint names.
                 e.g., {"target_env": "cluster"} maps arg 'target_env' to constraint 'cluster'.
        trusted_roots: Trusted issuer public keys (tenuo_core.PublicKey).  When supplied
                       the Authorizer verifies the warrant issuer against these roots,
                       closing the self-signed trust gap.  Highly recommended in production.
                       Falls back to warrant.issuer when omitted (accepts self-signed warrants).
        approval_handler: Optional callback invoked when a warrant approval gate fires.
                         Receives an ``ApprovalRequest`` and returns ``SignedApproval``
                         object(s).  See ``enforce_tool_call`` for details.

    Raises:
        AuthorizationError: If no warrant/keypair is available, or authorization fails.
    """
    # Determine warrant and tool
    active_warrant: Optional[Warrant] = None
    active_keypair: Optional[SigningKey] = keypair
    tool_name: Optional[str] = None

    if isinstance(warrant_or_tool, Warrant):
        # Pattern: @guard(warrant, tool="...")
        active_warrant = warrant_or_tool
        tool_name = tool
    elif isinstance(warrant_or_tool, str):
        # Pattern: @guard("tool_name") or @guard(tool="tool_name")
        tool_name = warrant_or_tool
    elif callable(warrant_or_tool):
        # Pattern: @guard (no parentheses) - warrant_or_tool is actually the function
        # Infer tool name from function name
        func = warrant_or_tool
        inferred_tool = func.__name__
        # Apply decorator and return immediately
        inner_decorator = guard(tool=inferred_tool, keypair=keypair, extract_args=extract_args, mapping=mapping, trusted_roots=trusted_roots, verify_mode=verify_mode, authorizer=authorizer, extract_signature=extract_signature, extract_chain=extract_chain, approval_handler=approval_handler)
        return inner_decorator(func)
    else:
        # Pattern: @guard(tool="...") - tool passed as keyword arg
        tool_name = tool

    def decorator(func: Callable) -> Callable:
        # Infer tool name from function name if not provided
        nonlocal tool_name
        if tool_name is None:
            tool_name = func.__name__

        # Extract annotated constraints for defense-in-depth enforcement
        # This allows the code to define strict boundaries that even a broad warrant cannot violate
        annotated_constraints = _extract_annotated_constraints(func)

        @wraps(func)
        def wrapper(*args, **kwargs):
            # Check for test bypass mode (set by allow_all())
            if is_bypass_enabled():
                return func(*args, **kwargs)

            from .config import get_config

            config = get_config()
            callsite = _get_callsite()
            func_name = f"{func.__module__}.{func.__qualname__}"

            warrant_to_use = active_warrant or get_warrant_context()

            if warrant_to_use is None:
                error_code = AuthErrorCode.MISSING_CONTEXT

                audit_logger.log(
                    AuditEvent(
                        event_type=AuditEventType.AUTHORIZATION_FAILURE,
                        tool=tool_name,
                        action="denied",
                        error_code=error_code,
                        details=f"No warrant context for {tool_name}",
                        metadata={
                            "callsite": callsite,
                            "function": func_name,
                        },
                    )
                )

                should_fail = config.strict_mode

                # Tripwire: auto-flip to strict after threshold is reached
                if config.max_missing_warrant_warnings > 0:
                    config._missing_warrant_count += 1
                    if config._missing_warrant_count >= config.max_missing_warrant_warnings:
                        should_fail = True
                        warnings.warn(
                            f"Tripwire triggered: {config._missing_warrant_count} missing warrant warnings "
                            f"reached threshold ({config.max_missing_warrant_warnings}). "
                            "Switching to strict mode (hard fail).",
                            SecurityWarning,
                            stacklevel=2,
                        )

                if should_fail:
                    error_msg = _make_actionable_error(
                        error_code=error_code,
                        tool_name=tool_name,
                        func_name=func_name,
                        callsite=callsite,
                        details=f"No warrant context available for tool '{tool_name}'.",
                    )
                    raise RuntimeError(error_msg)

                elif config.warn_on_missing_warrant:
                    warning_msg = (
                        f"[{error_code}] Tool '{tool_name}' called without warrant context.\n"
                        f"  Function: {func_name}\n"
                        f"  Location: {callsite}\n"
                        "  This would fail in strict_mode. Add root_task() or warrant_scope()."
                    )
                    warnings.warn(warning_msg, SecurityWarning, stacklevel=2)
                    # Passthrough allowed - continue without authorization
                    return func(*args, **kwargs)

                elif config.allow_passthrough:
                    # Dev mode passthrough - just execute
                    return func(*args, **kwargs)

                else:
                    error_msg = _make_actionable_error(
                        error_code=error_code,
                        tool_name=tool_name,
                        func_name=func_name,
                        callsite=callsite,
                        details=f"No warrant context available for tool '{tool_name}'.",
                    )
                    raise ScopeViolation(error_msg)

            # Check warrant expiry BEFORE any further processing
            if warrant_to_use.is_expired():
                expires_at = warrant_to_use.expires_at() if hasattr(warrant_to_use, "expires_at") else "unknown"
                error_code = AuthErrorCode.EXPIRED

                audit_logger.log(
                    AuditEvent(
                        event_type=AuditEventType.WARRANT_EXPIRED,
                        warrant_id=warrant_to_use.id if hasattr(warrant_to_use, "id") else None,
                        tool=tool_name,
                        action="denied",
                        error_code=error_code,
                        details=f"Warrant expired at {expires_at}",
                        metadata={
                            "callsite": callsite,
                            "function": func_name,
                            "expires_at": str(expires_at),
                        },
                    )
                )

                error_msg = _make_actionable_error(
                    error_code=error_code,
                    tool_name=tool_name,
                    func_name=func_name,
                    callsite=callsite,
                    details=f"Warrant expired at {expires_at}.",
                )
                raise ExpiredError(
                    warrant_id=warrant_to_use.id if hasattr(warrant_to_use, "id") else "unknown", expired_at=expires_at
                )

            keypair_to_use = active_keypair or get_signing_key_context()

            # PoP is MANDATORY in sign mode — keypair must always be available.
            # In verify mode the caller provides a pre-computed signature via
            # extract_signature, so no local keypair is needed.
            if keypair_to_use is None and verify_mode != "verify":
                error_code = AuthErrorCode.POP_MISSING

                audit_logger.log(
                    AuditEvent(
                        event_type=AuditEventType.POP_FAILED,
                        warrant_id=warrant_to_use.id if hasattr(warrant_to_use, "id") else None,
                        tool=tool_name,
                        action="denied",
                        error_code=error_code,
                        details=f"Proof-of-Possession is mandatory but no keypair available for {tool_name}",
                        metadata={
                            "callsite": callsite,
                            "function": func_name,
                        },
                    )
                )

                error_msg = _make_actionable_error(
                    error_code=error_code,
                    tool_name=tool_name,
                    func_name=func_name,
                    callsite=callsite,
                    details="Proof-of-Possession is mandatory but no keypair available.",
                )
                raise MissingSigningKey(tool=tool_name)

            if extract_args:
                auth_args = extract_args(*args, **kwargs)
            else:
                import inspect

                sig = inspect.signature(func)

                try:
                    bound = sig.bind(*args, **kwargs)
                    bound.apply_defaults()
                    auth_args = dict(bound.arguments)
                except TypeError as e:
                    # If binding fails (e.g. wrong number of args), we can't authorize
                    # Let the function call proceed to fail naturally, or raise
                    # But for security, if we can't inspect args, we shouldn't authorize.
                    # However, the function call itself would fail right after.
                    # Let's log and re-raise to be safe/clear.
                    audit_logger.log(
                        AuditEvent(
                            event_type=AuditEventType.AUTHORIZATION_FAILURE,
                            tool=tool_name,
                            action="denied",
                            error_code="argument_binding_error",
                            details=f"Failed to bind arguments for {tool_name}: {e}",
                        )
                    )
                    raise

                if mapping:
                    mapped_args = {}
                    for arg_name, value in auth_args.items():
                        constraint_name = mapping.get(arg_name, arg_name)
                        mapped_args[constraint_name] = value
                    auth_args = mapped_args

            # Defense in Depth: Enforce code-level constraints from Annotated hints
            # These are checked BEFORE the warrant, preventing unsafe values even if authorized
            if annotated_constraints:
                for param, constraint in annotated_constraints.items():
                    if param in auth_args:
                        val = auth_args[param]
                        # Check constraint using Rust core bindings (type-aware)
                        is_valid = _check_annotated_constraint(constraint, val)

                        if not is_valid:
                            # Use AuthorizatonDenied for rich error
                            details = f"Value '{val}' violates code-defined constraint for '{param}'"
                            hint = f"Function signature requires: {constraint}"

                            # Log the enforcement block
                            audit_logger.log(
                                AuditEvent(
                                    event_type=AuditEventType.AUTHORIZATION_FAILURE,
                                    tool=tool_name,
                                    action="denied",
                                    error_code="CODE_CONSTRAINT_VIOLATION",
                                    details=details,
                                    metadata={"param": param, "value": str(val), "constraint": str(constraint)},
                                )
                            )

                            raise AuthorizationDenied(
                                tool=tool_name,
                                reason=details,
                                hint=hint,
                                constraint_results=[
                                    ConstraintResult(
                                        name=param,
                                        passed=False,
                                        constraint_repr=str(constraint),
                                        value=val,
                                        explanation="Violated type hint constraint",
                                    )
                                ],
                            )

            # ── Enforcement via enforce_tool_call ──────────────────────────
            # Construct a BoundWarrant and delegate to the shared enforcement
            # path. This gives @guard approval gates, nonce replay protection,
            # chain verification, and chain_result for signed receipts — all
            # for free.
            _bw = BoundWarrant(
                warrant_to_use,
                keypair_to_use,
                trusted_roots=list(trusted_roots) if trusted_roots else None,
            )

            # For verify mode, extract the precomputed signature and chain
            # from the request (e.g. HTTP headers) before calling enforce.
            _precomputed_sig = None
            _warrant_chain = None
            _verify_authorizer = authorizer
            if verify_mode == "verify":
                _precomputed_sig = extract_signature(*args, **kwargs) if callable(extract_signature) else None
                if _precomputed_sig is None:
                    raise MissingSignature("@guard(verify_mode='verify') requires extract_signature to return bytes")
                _precomputed_sig = bytes(_precomputed_sig)
                _raw_chain = extract_chain(*args, **kwargs) if callable(extract_chain) else None
                if _raw_chain:
                    _warrant_chain = list(_raw_chain)
                # Build authorizer from trusted_roots if not explicitly provided
                if _verify_authorizer is None:
                    from .config import resolve_trusted_roots as _rtr
                    from tenuo_core import Authorizer as _Authorizer
                    _vr = _rtr(trusted_roots)
                    if _vr:
                        _verify_authorizer = _Authorizer(trusted_roots=_vr)
                    else:
                        raise ConfigurationError(
                            "@guard(verify_mode='verify') requires either an explicit authorizer= "
                            "or trusted_roots configured via configure() at startup."
                        )

            result = enforce_tool_call(
                tool_name=tool_name,
                tool_args=auth_args,
                bound_warrant=_bw,
                trusted_roots=list(trusted_roots) if trusted_roots else None,
                verify_mode=verify_mode,
                precomputed_signature=_precomputed_sig,
                authorizer=_verify_authorizer,
                warrant_chain=_warrant_chain,
                approval_handler=approval_handler,
            )

            if not result.allowed:
                # Preserve crypto exception propagation for backward
                # compatibility.  enforce_tool_call catches crypto exceptions
                # and returns a denied EnforcementResult, but @guard callers
                # may be catching SignatureInvalid / ExpiredError directly.
                _reraise_if_crypto(result, warrant_to_use)

                _map_result_to_guard_error(
                    result, warrant_to_use, tool_name, auth_args, callsite, func_name,
                )

            audit_logger.log(
                AuditEvent(
                    event_type=AuditEventType.AUTHORIZATION_SUCCESS,
                    warrant_id=warrant_to_use.id if hasattr(warrant_to_use, "id") else None,
                    tool=tool_name,
                    action="authorized",
                    constraints=auth_args,
                    trace_id=warrant_to_use.session_id if hasattr(warrant_to_use, "session_id") else None,
                    details=f"Authorization successful for {tool_name}",
                    metadata={
                        "callsite": callsite,
                        "function": func_name,
                    },
                )
            )

            return func(*args, **kwargs)

        return wrapper

    return decorator
