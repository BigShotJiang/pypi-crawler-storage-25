# Training Guide

How to train a tokenizer from scratch and how to extend it later with new data.

---

## 1. Train from scratch

```python
from bpe_from_scratch import ByteLevelBPE

bpe = ByteLevelBPE()
bpe.train(text, vocab_size=1024)
bpe.save("my_model.json")
```

`vocab_size` is the **total** vocabulary size including the 256 base byte tokens, so `vocab_size=1024` learns 768 merge rules.

### Using multiple files

If your corpus lives in a folder of `.txt` files, use the built-in helper:

```python
from bpe_from_scratch.train import train_from_folder

bpe = train_from_folder(
    folder_path="data/corpus_A/",
    model_path="my_model.json",
    vocab_size=1024,
)
```

---

## 2. Continue training on new data

Later, when you have new text and want to extend the vocabulary **without discarding what was already learned**:

```python
from bpe_from_scratch import ByteLevelBPE

bpe = ByteLevelBPE()
bpe.load("my_model.json")                          # load the existing model
bpe.continue_train(new_text, new_vocab_size=1280)  # extend to 1280 total tokens
bpe.save("my_model.json")                          # overwrite (or save to a new path)
```

`new_vocab_size` must be **greater than the current vocabulary size**. All previously learned token IDs remain stable — documents encoded with the old model are still valid.

### Using multiple files

```python
from bpe_from_scratch.train import continue_train_from_folder

bpe = continue_train_from_folder(
    folder_path="data/corpus_B/",
    model_path="my_model.json",   # loaded and saved back in-place
    new_vocab_size=1280,
)
```

---

## 3. Encode and decode

```python
tokens = bpe.encode("Hello, world!")   # list[int]
text   = bpe.decode(tokens)            # "Hello, world!"
```

---

## 4. What "continue training" actually does

When you call `continue_train`:

1. The new text is pre-tokenized with the same GPT-2 regex used during initial training.
2. **All existing merge rules are replayed** on the new text, bringing it into the current token space.
3. From there, the standard greedy BPE loop runs and appends new merge rules until `new_vocab_size` is reached.

This means existing token IDs are **frozen** — you can safely continue encoding old documents with the updated model.

### Known limitations

| Situation                                              | Works well?                                                  |
| ------------------------------------------------------ | ------------------------------------------------------------ |
| New data is the same domain / language as the original | Yes                                                          |
| New data is a very different language                  | Suboptimal — early slots were spent on the original language |
| You need globally optimal tokenization over all data   | No — only a full retrain gives that                          |

If the new corpus is large and domain-divergent, consider a full retrain with all data combined.
