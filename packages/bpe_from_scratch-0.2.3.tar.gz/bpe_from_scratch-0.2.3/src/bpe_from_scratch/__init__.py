from .bpe import ByteLevelBPE
from importlib.metadata import version, PackageNotFoundError

try:
    __version__ = version("bpe-from-scratch")
except PackageNotFoundError:
    __version__ = "unknown"

__all__ = ["ByteLevelBPE", "__version__"]
