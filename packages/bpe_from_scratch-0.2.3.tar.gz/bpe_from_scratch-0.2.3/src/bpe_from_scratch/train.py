from pathlib import Path
import time
from bpe_from_scratch import ByteLevelBPE


def train_from_folder(
    folder_path: str, model_path: str, vocab_size: int = 512
) -> ByteLevelBPE:
    folder = Path(folder_path)
    texts = []

    for path in sorted(folder.glob("*.txt")):
        if path.is_file():
            texts.append(path.read_text(encoding="utf-8"))
            print(f"Loaded: {path.name}")

    if not texts:
        raise ValueError(f"No .txt files found in {folder_path}")

    text = "\n".join(texts)
    num_bytes = len(text.encode("utf-8"))
    print(
        f"Total corpus: {len(text):,} chars | {num_bytes:,} bytes | {len(texts)} file(s)"
    )

    bpe = ByteLevelBPE()

    start = time.perf_counter()
    tokens = bpe.train(text, vocab_size=vocab_size, verbose=True)
    elapsed = time.perf_counter() - start

    bpe.save(model_path)

    total_tokens = sum(len(chunk) for chunk in tokens)
    compression = num_bytes / total_tokens if total_tokens else 0.0

    print("\n--- Training complete ---")
    print(f"Time:        {elapsed:.2f}s")
    print(f"Merges:      {len(bpe.merges)}")
    print(f"Vocab size:  {len(bpe.vocab)}")
    print(f"Tokens:      {num_bytes:,} bytes -> {total_tokens:,} tokens")
    print(f"Compression: {compression:.2f}x")
    print(f"Saved to:    {model_path}")

    return bpe


if __name__ == "__main__":
    train_from_folder(
        folder_path="/Users/mohanadabunayla/Desktop/tokenizer_text_for_traning",
        model_path="bpe_model.json",
        vocab_size=1024,
    )


def continue_train_from_folder(
    folder_path: str, model_path: str, new_vocab_size: int
) -> ByteLevelBPE:
    folder = Path(folder_path)
    texts = []

    for path in sorted(folder.glob("*.txt")):
        if path.is_file():
            texts.append(path.read_text(encoding="utf-8"))
            print(f"Loaded: {path.name}")

    if not texts:
        raise ValueError(f"No .txt files found in {folder_path}")

    text = "\n".join(texts)
    num_bytes = len(text.encode("utf-8"))
    print(
        f"Total corpus: {len(text):,} chars | {num_bytes:,} bytes | {len(texts)} file(s)"
    )

    bpe = ByteLevelBPE()
    bpe.load(model_path)
    prev_merge_count = len(bpe.merges)

    start = time.perf_counter()
    tokens = bpe.continue_train(text, new_vocab_size=new_vocab_size, verbose=True)
    elapsed = time.perf_counter() - start

    bpe.save(model_path)

    total_tokens = sum(len(chunk) for chunk in tokens)
    compression = num_bytes / total_tokens if total_tokens else 0.0

    print("\n--- Continue training complete ---")
    print(f"Time:        {elapsed:.2f}s")
    print(f"New merges:  {len(bpe.merges) - prev_merge_count}")
    print(f"Vocab size:  {len(bpe.vocab)}")
    print(f"Tokens:      {num_bytes:,} bytes -> {total_tokens:,} tokens")
    print(f"Compression: {compression:.2f}x")
    print(f"Saved to:    {model_path}")

    return bpe
