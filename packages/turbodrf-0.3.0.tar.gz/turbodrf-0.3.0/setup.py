from setuptools import find_packages, setup

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="turbodrf",
    version="0.3.0",
    author="Alexander Collins",
    author_email="",
    description="Dead simple Django REST API generator with role-based permissions",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/alexandercollins/turbodrf",
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Internet :: WWW/HTTP :: Dynamic Content",
        "Topic :: Internet :: WWW/HTTP :: HTTP Servers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: 3.13",
        "Programming Language :: Python :: 3.14",
        "Framework :: Django",
        "Framework :: Django :: 4.2",
        "Framework :: Django :: 5.2",
    ],
    python_requires=">=3.10",
    install_requires=[
        "Django>=4.2",
        "djangorestframework>=3.12.0",
        "drf-yasg>=1.20.0",
        "django-filter>=2.0",
    ],
    extras_require={
        "fast": [
            "msgspec>=0.18.0",
        ],
        "dev": [
            "pytest>=6.0",
            "pytest-django>=4.0",
            "pytest-cov>=2.0",
            "black>=22.0",
            "flake8>=4.0",
            "isort>=5.0",
            "mypy>=0.9",
            "msgspec>=0.18.0",
        ],
    },
    include_package_data=True,
    package_data={
        "turbodrf": ["templates/turbodrf/*.html"],
    },
)
