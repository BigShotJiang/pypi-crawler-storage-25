from __future__ import annotations

from pathlib import Path

from claude_select.paths import (
    get_claude_config_home,
    get_credentials_path,
    get_default_store_root,
    get_global_config_path,
)


def test_paths_respect_env_overrides(tmp_path):
    env = {
        "CLAUDE_CONFIG_DIR": str(tmp_path / "claude-home"),
        "XDG_CONFIG_HOME": str(tmp_path / "xdg"),
    }

    assert get_claude_config_home(env) == tmp_path / "claude-home"
    assert get_credentials_path(env) == tmp_path / "claude-home" / ".credentials.json"
    assert get_global_config_path(env) == tmp_path / "claude-home" / ".claude.json"
    assert get_default_store_root(env) == tmp_path / "xdg" / "claude-select"


def test_global_config_prefers_legacy_file(tmp_path):
    env = {"CLAUDE_CONFIG_DIR": str(tmp_path / "claude-home")}
    legacy = Path(env["CLAUDE_CONFIG_DIR"]) / ".config.json"
    legacy.parent.mkdir(parents=True)
    legacy.write_text("{}", encoding="utf-8")

    assert get_global_config_path(env) == legacy
