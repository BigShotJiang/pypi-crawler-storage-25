"""
System tray icon for Alto service status indication.
"""

import logging
import webbrowser
from io import BytesIO
from pathlib import Path
from threading import Thread
from typing import Callable, Optional

from PIL import Image, ImageDraw
from pystray import Icon as TrayIcon
from pystray import Menu, MenuItem

from alto.state import State
from alto.updater import UpdateInfo

logger = logging.getLogger(__name__)


class AltoTrayIcon:
    """System tray icon for visual feedback of Alto service state.

    Displays a colored icon in the system tray that changes based on the
    current state of the Alto service:
    - Green: READY (waiting for voice input)
    - Red: RECORDING (actively recording audio)
    - Yellow: TRANSCRIBING (processing audio)
    - Blue: TYPING (injecting text)
    - Gray: ERROR (error state)

    Args:
        on_quit: Callback function to call when user selects Quit from menu.
        on_feedback: Callback for Report Issue menu item.
        on_settings: Callback for Settings menu item.
        update_info: Optional update information to display in menu.
        user_info: Optional user info dict (cloud mode).
        usage_info: Optional usage info dict (cloud mode).
    """

    # State colors (RGB)
    _STATE_COLORS = {
        State.READY: (0, 200, 0),  # Green
        State.RECORDING: (255, 0, 0),  # Red
        State.TRANSCRIBING: (255, 200, 0),  # Yellow
        State.TYPING: (0, 100, 255),  # Blue
        State.ERROR: (128, 128, 128),  # Gray
    }

    # State tooltips
    _STATE_TOOLTIPS = {
        State.READY: "Alto - Ready",
        State.RECORDING: "Alto - Recording",
        State.TRANSCRIBING: "Alto - Transcribing",
        State.TYPING: "Alto - Typing",
        State.ERROR: "Alto - Error",
    }

    def __init__(
        self,
        on_quit: Optional[Callable[[], None]] = None,
        on_feedback: Optional[Callable[[], None]] = None,
        on_settings: Optional[Callable[[], None]] = None,
        on_login: Optional[Callable[[], None]] = None,
        on_manage_subscription: Optional[Callable[[], None]] = None,
        on_logout: Optional[Callable[[], None]] = None,
        update_info: Optional[UpdateInfo] = None,
        user_info: Optional[dict] = None,
        usage_info: Optional[dict] = None,
        authenticated: bool = True,
    ):
        self._on_quit = on_quit
        self._on_feedback = on_feedback
        self._on_settings = on_settings
        self._on_login = on_login
        self._on_manage_subscription = on_manage_subscription
        self._on_logout = on_logout
        self._update_info = update_info
        self._user_info = user_info
        self._usage_info = usage_info
        self._icon: Optional[TrayIcon] = None
        self._current_state = State.READY
        self._authenticated = authenticated
        self._thread: Optional[Thread] = None

        logger.info("TrayIcon initialized")

    def start(self) -> None:
        """Start the tray icon."""
        if self._icon is not None:
            logger.warning("Tray icon already started")
            return

        logger.info("Starting tray icon")

        image = self._create_icon_image(self._current_state)

        menu_items = []

        # Not authenticated — show login option
        if not self._authenticated:
            menu_items.append(MenuItem("Not connected", None, enabled=False))
            if self._on_login is not None:
                menu_items.append(MenuItem("Log in...", self._handle_login))
            menu_items.append(Menu.SEPARATOR)

        # Account info (cloud mode)
        elif self._user_info:
            email = self._user_info.get("email", "")
            tier = self._user_info.get("tier", "free").capitalize()
            active = self._user_info.get("subscription_active", False)
            account_label = f"Account: {email} ({tier})"
            menu_items.append(MenuItem(account_label, None, enabled=False))

            # Usage info
            if self._usage_info:
                seconds = self._usage_info.get("audio_seconds", 0)
                minutes = seconds / 60.0
                tier_lower = self._user_info.get("tier", "free")
                if tier_lower == "free":
                    usage_label = f"Usage: {minutes:.0f}/15 min this month"
                elif tier_lower == "pro":
                    usage_label = f"Usage: {minutes:.0f}/180 min this month"
                elif tier_lower == "max":
                    usage_label = f"Usage: {minutes:.0f}/600 min this month"
                else:
                    usage_label = f"Usage: {minutes:.0f} min this month"
                menu_items.append(MenuItem(usage_label, None, enabled=False))

            menu_items.append(Menu.SEPARATOR)

            # Manage subscription
            if active:
                menu_items.append(
                    MenuItem("Manage subscription", self._handle_manage_subscription)
                )

            # Logout
            if self._on_logout is not None:
                menu_items.append(MenuItem("Log out", self._handle_logout))

            menu_items.append(Menu.SEPARATOR)

        # Add update notification if available
        if self._update_info is not None and self._update_info.update_available:
            menu_items.append(
                MenuItem(
                    f"Update: {self._update_info.latest_version}",
                    self._handle_update_info,
                )
            )

        # Add Settings option (only when authenticated)
        if self._on_settings is not None and self._authenticated:
            menu_items.append(MenuItem("Settings", self._handle_settings))

        # Add Report Issue option
        if self._on_feedback is not None:
            menu_items.append(MenuItem("Report an issue", self._handle_feedback))

        menu_items.append(Menu.SEPARATOR)

        # Add Quit option
        menu_items.append(MenuItem("Quit", self._handle_quit))

        menu = Menu(*menu_items)

        title = self._STATE_TOOLTIPS[self._current_state]
        if not self._authenticated and self._current_state == State.READY:
            title = "Alto - Not connected"

        self._icon = TrayIcon(
            name="Alto",
            icon=image,
            title=title,
            menu=menu,
        )

        self._thread = Thread(
            target=self._icon.run,
            daemon=True,
            name="TrayIconThread",
        )
        self._thread.start()

        logger.info("Tray icon started")

    def stop(self) -> None:
        if self._icon is None:
            logger.warning("Tray icon not started")
            return

        logger.info("Stopping tray icon")

        if self._icon is not None:
            self._icon.stop()
            self._icon = None

        if self._thread is not None:
            self._thread.join(timeout=2.0)
            self._thread = None

        logger.info("Tray icon stopped")

    def update_state(self, state: State, error_context: Optional[str] = None) -> None:
        if self._icon is None:
            logger.warning("Cannot update tray icon: not started")
            return

        logger.debug(f"Updating tray icon to {state.name}")

        self._current_state = state

        image = self._create_icon_image(state)
        self._icon.icon = image

        tooltip = self._STATE_TOOLTIPS[state]
        if state == State.ERROR and error_context:
            tooltip = f"Alto - Error: {error_context}"

        self._icon.title = tooltip

    def update_account_info(self, user_info: dict, usage_info: Optional[dict] = None) -> None:
        """Update account info and rebuild the tray menu."""
        old_tier = self._user_info.get("tier") if self._user_info else None
        self._user_info = user_info
        if usage_info is not None:
            self._usage_info = usage_info
        self._authenticated = True

        new_tier = user_info.get("tier")
        if old_tier != new_tier:
            logger.info(f"Account info updated: tier {old_tier} -> {new_tier}")

        # Rebuild tray icon with new menu
        if self._icon is not None:
            Thread(target=self._rebuild, daemon=True, name="TrayRebuild").start()

    def set_authenticated(self, authenticated: bool) -> None:
        """Update authentication status and rebuild tray menu."""
        self._authenticated = authenticated
        if not authenticated:
            self._user_info = None
            self._usage_info = None
        # Rebuild tray icon with updated menu (in a new thread to avoid deadlock)
        if self._icon is not None:
            Thread(target=self._rebuild, daemon=True, name="TrayRebuild").start()

    def _rebuild(self) -> None:
        """Stop and restart tray icon to rebuild the menu."""
        self.stop()
        self.start()

    def _create_icon_image(self, state: State) -> Image.Image:
        size = 64
        image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        draw = ImageDraw.Draw(image)

        # Orange when not authenticated and in READY state
        if not self._authenticated and state == State.READY:
            color = (255, 165, 0)  # Orange
        else:
            color = self._STATE_COLORS.get(state, (128, 128, 128))

        margin = 4
        draw.ellipse(
            [margin, margin, size - margin, size - margin],
            fill=color,
            outline=(255, 255, 255),
            width=2,
        )

        return image

    def _handle_login(self, icon: TrayIcon, item: MenuItem) -> None:
        """Trigger browser login from tray menu."""
        logger.info("Login selected from tray menu")
        if self._on_login is not None:
            try:
                self._on_login()
            except Exception as e:
                logger.error(f"Error in on_login callback: {e}", exc_info=True)

    def _handle_manage_subscription(self, icon: TrayIcon, item: MenuItem) -> None:
        """Open the billing portal in the browser."""
        logger.info("Manage subscription selected from tray menu")
        if self._on_manage_subscription is not None:
            try:
                self._on_manage_subscription()
            except Exception as e:
                logger.error(f"Error opening subscription portal: {e}", exc_info=True)
        else:
            webbrowser.open("https://alto-dictation.com/account")

    def _handle_logout(self, icon: TrayIcon, item: MenuItem) -> None:
        """Trigger logout from tray menu."""
        logger.info("Logout selected from tray menu")
        if self._on_logout is not None:
            try:
                self._on_logout()
            except Exception as e:
                logger.error(f"Error in on_logout callback: {e}", exc_info=True)

    def _handle_update_info(self, icon: TrayIcon, item: MenuItem) -> None:
        logger.info("Update info selected from tray menu")

        if self._update_info is not None:
            logger.info("\n" + "=" * 70)
            logger.info("UPDATE AVAILABLE")
            logger.info("=" * 70)
            logger.info(self._update_info.update_instructions)
            logger.info("=" * 70)

            import sys
            print("\n" + "=" * 70, file=sys.stderr)
            print("UPDATE AVAILABLE", file=sys.stderr)
            print("=" * 70, file=sys.stderr)
            print(self._update_info.update_instructions, file=sys.stderr)
            print("=" * 70, file=sys.stderr)

    def _handle_feedback(self, icon: TrayIcon, item: MenuItem) -> None:
        logger.info("Report Issue selected from tray menu")
        if self._on_feedback is not None:
            try:
                self._on_feedback()
            except Exception as e:
                logger.error(f"Error in on_feedback callback: {e}", exc_info=True)

    def _handle_settings(self, icon: TrayIcon, item: MenuItem) -> None:
        logger.info("Settings selected from tray menu")
        if self._on_settings is not None:
            try:
                self._on_settings()
            except Exception as e:
                logger.error(f"Error in on_settings callback: {e}", exc_info=True)

    def _handle_quit(self, icon: TrayIcon, item: MenuItem) -> None:
        logger.info("Quit selected from tray menu")
        icon.stop()
        if self._on_quit is not None:
            try:
                self._on_quit()
            except Exception as e:
                logger.error(f"Error in on_quit callback: {e}", exc_info=True)
