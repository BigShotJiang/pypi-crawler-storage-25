"""
Main entry point for Alto daemon.
"""

import argparse
import logging
import sys
from pathlib import Path

from alto.config import load_config
from alto.logger import setup_logging


def verify_dependencies() -> list[str]:
    """Verify required dependencies are available.

    Returns:
        List of error messages. Empty list if all dependencies are available.
    """
    errors = []

    # Check for required Python packages
    try:
        import sounddevice
    except ImportError:
        errors.append("sounddevice package not found. Run: pip install alto-dictation")

    try:
        import evdev
    except ImportError:
        errors.append("evdev package not found. Run: pip install alto-dictation")

    return errors


def cmd_login(args) -> int:
    """Handle 'alto login' command."""
    from alto.api_client import AltoAPIClient, APIError

    config = load_config(args.config)
    client = AltoAPIClient(base_url=config.api_base_url)

    if client.is_authenticated():
        try:
            info = client.get_me()
            print(f"Already logged in as {info.get('email')}")
            return 0
        except APIError:
            pass  # Token expired, proceed to login

    print("Opening browser for login...")

    try:
        client.browser_login(timeout=120)

        try:
            info = client.get_me()
            email = info.get("email", "")
            tier = info.get("tier", "free").capitalize()
            active = info.get("subscription_active", False)
            status_str = f"{tier}" + (" (active)" if active else "")
            print(f"Logged in as {email}")
            print(f"Plan: {status_str}")
        except Exception:
            print("Login successful!")

        return 0

    except TimeoutError:
        print("\nLogin timed out (2 minutes). Please try again.", file=sys.stderr)
        return 1
    except APIError as e:
        print(f"\nLogin failed: {e.detail}", file=sys.stderr)
        return 1


def cmd_logout(args) -> int:
    """Handle 'alto logout' command."""
    from alto.api_client import AltoAPIClient

    config = load_config(args.config)
    client = AltoAPIClient(base_url=config.api_base_url)

    if not client.is_authenticated():
        print("Not logged in")
        return 0

    client.logout()
    print("Logged out")
    return 0


def cmd_status(args) -> int:
    """Handle 'alto status' command."""
    from alto.api_client import AltoAPIClient, APIError

    config = load_config(args.config)

    client = AltoAPIClient(base_url=config.api_base_url)

    if not client.is_authenticated():
        print("Account: not logged in")
        print("\nRun 'alto login' to authenticate.")
        return 0

    try:
        info = client.get_me()
        email = info.get("email", "unknown")
        tier = info.get("tier", "free")
        active = info.get("subscription_active", False)

        print(f"Account: {email}")
        print(f"Plan: {tier.capitalize()}" + (" (active)" if active else ""))

        # Get usage
        try:
            usage = client.get_usage()
            seconds = usage.get("audio_seconds", 0)
            requests = usage.get("requests", 0)
            period = usage.get("period", "")
            minutes = seconds / 60.0

            # Show limits based on tier
            if tier == "free":
                limit_str = f"{minutes:.1f} / 15 min"
            elif tier == "pro":
                limit_str = f"{minutes:.1f} / 180 min"
            else:
                limit_str = f"{minutes:.1f} / 600 min"

            print(f"Usage ({period}): {limit_str} ({requests} requests)")
        except Exception:
            pass

        return 0

    except APIError as e:
        print(f"Error fetching account info: {e.detail}", file=sys.stderr)
        return 1


def cmd_subscribe(args) -> int:
    """Handle 'alto subscribe' command."""
    from alto.api_client import AltoAPIClient, APIError

    config = load_config(args.config)
    client = AltoAPIClient(base_url=config.api_base_url)

    if not client.is_authenticated():
        print("Not logged in. Run 'alto login' first.", file=sys.stderr)
        return 1

    print("Alto - Subscribe")
    print("=" * 40)
    print()
    print("Available plans:")
    print("  1. Pro  - 5 EUR/month  (180 min/month)")
    print("  2. Max  - 9 EUR/month  (600 min/month)")
    print()

    choice = input("Choose a plan (1/2): ").strip()
    tier = {"1": "pro", "2": "max"}.get(choice)

    if not tier:
        print("Invalid choice", file=sys.stderr)
        return 1

    try:
        url = client.create_checkout(tier)
        if url:
            print(f"\nOpening checkout page...")
            webbrowser.open(url)
            print("Complete the payment in your browser.")
            return 0
        else:
            print("Failed to create checkout session", file=sys.stderr)
            return 1
    except APIError as e:
        print(f"Error: {e.detail}", file=sys.stderr)
        return 1


def _first_run_setup(config_path: Path) -> "ServiceConfig":
    """Interactive first-run setup for new users."""
    from alto.config import ServiceConfig, save_config

    key = "KEY_GRAVE"

    config = ServiceConfig(evdev_key=key, language="en")
    config_path.parent.mkdir(parents=True, exist_ok=True)
    save_config(config_path, config)

    print()
    print("  Welcome to Alto — voice dictation for Linux.")
    print()
    print(f"  Push-to-talk key: ` (grave/backtick, left of 1)")
    print(f"  Hold it and speak — text will appear at your cursor.")
    print(f"  Change it anytime from Settings (right-click tray icon).")
    print()

    return config


def cmd_daemon(args) -> int:
    """Run the Alto daemon (default command)."""
    from alto.daemon import AltoDaemon
    from alto.platforms import detect_key_interactive

    # Key detection mode
    if args.detect_key:
        print("Alto - Key Detection Utility")
        print("=" * 50)
        print()
        detect_key_interactive()
        return 0

    # First-run setup: if no config file exists, guide the user
    config_path = args.config
    if not config_path.exists():
        config = _first_run_setup(config_path)
    else:
        config = load_config(config_path)

    # Normal daemon mode - verify dependencies first

    dependency_errors = verify_dependencies()
    if dependency_errors:
        print("Error: Missing required dependencies:\n", file=sys.stderr)
        for error in dependency_errors:
            print(f"  - {error}", file=sys.stderr)
        print("\nPlease fix the above issues before starting Alto.", file=sys.stderr)
        return 1

    try:
        # Set up logging
        setup_logging(config.log_level)

        logger = logging.getLogger(__name__)
        logger.info("=" * 60)
        logger.info("Alto - System-wide push-to-talk speech-to-text service")
        logger.info("=" * 60)
        logger.info(f"Configuration loaded from {args.config}")
        logger.info(f"Language: {config.language}")
        logger.info(f"Push-to-talk key: {config.evdev_key}")
        logger.info(f"Typing delay: {config.typing_delay_ms}ms")
        logger.info("=" * 60)

        # Create and run daemon
        daemon = AltoDaemon(config, config_path=args.config)
        daemon.run()

        return 0

    except KeyboardInterrupt:
        print("\nShutdown by user")
        return 0

    except Exception as e:
        print(f"Fatal error: {e}", file=sys.stderr)
        logging.getLogger(__name__).exception("Fatal error")
        return 1


def main() -> int:
    """Main entry point for Alto."""
    parser = argparse.ArgumentParser(
        description="Alto - System-wide push-to-talk speech-to-text service"
    )
    parser.add_argument(
        "--config",
        type=Path,
        default=Path.home() / ".config" / "alto" / "config.json",
        help="Path to config.json file (default: ~/.config/alto/config.json)",
    )

    subparsers = parser.add_subparsers(dest="command")

    # Login command
    subparsers.add_parser("login", help="Log in to your Alto account")

    # Logout command
    subparsers.add_parser("logout", help="Log out of your Alto account")

    # Status command
    subparsers.add_parser("status", help="Show account and usage status")

    # Subscribe command
    subparsers.add_parser("subscribe", help="Subscribe to a paid plan")

    # Default daemon mode (no subcommand)
    parser.add_argument(
        "--detect-key",
        action="store_true",
        help="Run key detection utility to find your PTT key",
    )

    args = parser.parse_args()

    # Route to appropriate command
    if args.command == "login":
        return cmd_login(args)
    elif args.command == "logout":
        return cmd_logout(args)
    elif args.command == "status":
        return cmd_status(args)
    elif args.command == "subscribe":
        return cmd_subscribe(args)
    else:
        return cmd_daemon(args)


if __name__ == "__main__":
    sys.exit(main())
