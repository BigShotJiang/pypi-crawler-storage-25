"""
Hotkey listener module using evdev for global key detection.
"""

import logging
import select
import time
from pathlib import Path
from threading import Event, Lock, Thread
from typing import Callable, Optional

import evdev
from evdev import InputDevice, UInput, categorize, ecodes

from alto.platforms.base import BaseHotkeyListener

logger = logging.getLogger(__name__)


class HotkeyListener(BaseHotkeyListener):
    """Listens for global hotkey presses using evdev.

    Monitors keyboard input devices and triggers callbacks on key press/release
    events. Uses a threaded select() loop for non-blocking input detection.

    Args:
        key_name: Name of the key to monitor (e.g., "KEY_F20").
        on_press: Callback function called when the key is pressed.
        on_release: Callback function called when the key is released.
        devices: List of device paths to monitor, or "auto" for auto-detection.
                 Defaults to "auto".
    """

    def __init__(
        self,
        key_name: str,
        on_press: Optional[Callable[[], None]] = None,
        on_release: Optional[Callable[[], None]] = None,
        devices: str | list[str] = "auto",
    ):
        self.key_name = key_name
        self.on_press = on_press
        self.on_release = on_release

        # Convert key name to evdev keycode
        try:
            self.keycode = ecodes.ecodes[key_name]
        except KeyError:
            raise ValueError(
                f"Invalid key name: {key_name}. "
                f"Use evdev key names like 'KEY_F20', 'KEY_LEFTCTRL', etc."
            )

        # Initialize devices
        if devices == "auto":
            self._devices = self._detect_keyboard_devices()
        else:
            self._devices = [InputDevice(path) for path in devices]

        if not self._devices:
            raise RuntimeError("No keyboard devices found")

        logger.info(
            f"HotkeyListener initialized for {key_name} on {len(self._devices)} device(s)"
        )
        for device in self._devices:
            logger.debug(f"  Monitoring: {device.path} - {device.name}")

        # Threading control
        self._thread: Optional[Thread] = None
        self._stop_event = Event()
        self._suspended = Event()
        self._resume_event = Event()
        self._running = False
        self._lock = Lock()
        self._device_config = devices  # Keep original config for resume

    def _detect_keyboard_devices(self) -> list[InputDevice]:
        """Auto-detect keyboard input devices."""
        devices = []

        for device_path in evdev.list_devices():
            device = None
            try:
                device = InputDevice(device_path)
                capabilities = device.capabilities(verbose=False)

                if ecodes.EV_KEY not in capabilities:
                    device.close()
                    device = None
                    continue

                key_codes = capabilities[ecodes.EV_KEY]
                if self.keycode in key_codes:
                    devices.append(device)
                    device = None  # Don't close, we're keeping it
                    logger.debug(
                        f"Found keyboard device: {devices[-1].path} - {devices[-1].name}"
                    )
                else:
                    device.close()
                    device = None

            except (OSError, PermissionError) as e:
                logger.warning(f"Cannot access device {device_path}: {e}")
                if device is not None:
                    try:
                        device.close()
                    except Exception:
                        pass

        if not devices:
            logger.warning(
                f"No keyboard devices found supporting {self.key_name}. "
                f"You may need to run with sudo or add your user to the 'input' group."
            )

        return devices

    def start(self) -> None:
        with self._lock:
            if self._running:
                raise RuntimeError("Hotkey listener is already running")

            self._running = True
            self._stop_event.clear()

            self._thread = Thread(target=self._listen_loop, daemon=True)
            self._thread.start()

            logger.info(f"Hotkey listener started for {self.key_name}")

    def stop(self) -> None:
        with self._lock:
            if not self._running:
                logger.warning("Hotkey listener is not running")
                return

            logger.info("Stopping hotkey listener")
            self._stop_event.set()

        if self._thread is not None:
            self._thread.join(timeout=2.0)
            if self._thread.is_alive():
                logger.warning("Hotkey listener thread did not terminate cleanly")

        with self._lock:
            self._running = False
            logger.info("Hotkey listener stopped")

    def suspend(self) -> None:
        with self._lock:
            if not self._running:
                return

        logger.info("Suspending hotkey listener for sleep")
        self._suspended.set()

        deadline = time.time() + 2.0
        while self._suspended.is_set() and time.time() < deadline:
            time.sleep(0.05)

        if self._suspended.is_set():
            logger.warning(
                "Hotkey listener did not confirm suspension in time, "
                "force-releasing device grabs"
            )
            with self._lock:
                for dev in self._devices:
                    try:
                        dev.ungrab()
                    except Exception:
                        pass
        else:
            logger.info("Hotkey listener suspended, devices released")

    def resume(self) -> bool:
        with self._lock:
            if not self._running:
                return False

        logger.info("Resuming hotkey listener after wake")

        if self._device_config == "auto":
            new_devices = self._detect_keyboard_devices()
        else:
            new_devices = [InputDevice(path) for path in self._device_config]

        if not new_devices:
            logger.warning("No keyboard devices found after wake (will retry)")
            return False

        with self._lock:
            old_devices = self._devices
            self._devices = new_devices

        for dev in old_devices:
            try:
                dev.close()
            except Exception:
                pass

        self._resume_event.set()

        logger.info(
            f"Hotkey listener resumed with {len(new_devices)} device(s)"
        )
        return True

    def is_running(self) -> bool:
        with self._lock:
            return self._running

    def _grab_devices(self) -> tuple[Optional[UInput], list[InputDevice]]:
        """Grab input devices and create UInput passthrough."""
        uinput = None
        grabbed = []

        try:
            with self._lock:
                devices = list(self._devices)

            uinput = UInput.from_device(*devices, name="alto-passthrough")
            for dev in devices:
                dev.grab()
                grabbed.append(dev)
            logger.info(
                f"Grabbed {len(grabbed)} device(s) for exclusive "
                f"{self.key_name} access"
            )
        except Exception as e:
            logger.warning(
                f"Could not grab input devices: {e}. "
                f"The hotkey character may be typed when pressed."
            )
            for dev in grabbed:
                try:
                    dev.ungrab()
                except Exception:
                    pass
            grabbed = []
            if uinput is not None:
                try:
                    uinput.close()
                except Exception:
                    pass
                uinput = None

        return uinput, grabbed

    def _release_devices(
        self, uinput: Optional[UInput], grabbed: list[InputDevice]
    ) -> None:
        """Release grabbed devices and close UInput."""
        for dev in grabbed:
            try:
                dev.ungrab()
                logger.debug(f"Ungrabbed device: {dev.path}")
            except Exception as e:
                logger.warning(f"Error ungrabbing device {dev.path}: {e}")
        if uinput is not None:
            try:
                uinput.close()
                logger.debug("UInput device closed")
            except Exception as e:
                logger.warning(f"Error closing UInput: {e}")

    def _listen_loop(self) -> None:
        """Main listening loop that runs in a background thread."""
        uinput = None
        grabbed_devices = []

        try:
            logger.debug("Entering hotkey listen loop")

            uinput, grabbed_devices = self._grab_devices()

            with self._lock:
                fd_to_device = {dev.fd: dev for dev in self._devices}
                devices_version = id(self._devices)

            while not self._stop_event.is_set():
                # --- Handle suspend/resume for sleep/wake ---
                if self._suspended.is_set():
                    logger.info("Hotkey listener releasing devices for sleep")
                    self._release_devices(uinput, grabbed_devices)
                    uinput = None
                    grabbed_devices = []

                    self._resume_event.clear()
                    self._suspended.clear()

                    resumed = self._resume_event.wait(timeout=30.0)
                    if self._stop_event.is_set() or not resumed:
                        if not resumed:
                            logger.error(
                                "Timed out waiting for device recovery "
                                "after wake (30s). Hotkey listener stopped."
                            )
                        break

                    logger.info("Hotkey listener re-grabbing devices after wake")
                    uinput, grabbed_devices = self._grab_devices()
                    with self._lock:
                        fd_to_device = {dev.fd: dev for dev in self._devices}
                        devices_version = id(self._devices)

                    for dev in fd_to_device.values():
                        try:
                            while dev.read_one() is not None:
                                pass
                        except (OSError, BlockingIOError):
                            pass
                    logger.debug("Flushed stale events after resume")

                if id(self._devices) != devices_version:
                    with self._lock:
                        fd_to_device = {dev.fd: dev for dev in self._devices}
                        devices_version = id(self._devices)

                # --- Normal event processing ---
                try:
                    r, w, x = select.select(
                        fd_to_device.keys(), [], [], 0.5
                    )
                except (OSError, ValueError) as e:
                    logger.warning(f"select() error (device may have changed): {e}")
                    time.sleep(0.5)
                    continue

                if r:
                    for fd in r:
                        device = fd_to_device.get(fd)
                        if device is None:
                            continue

                        try:
                            for event in device.read():
                                if (
                                    event.type == ecodes.EV_KEY
                                    and event.code == self.keycode
                                ):
                                    self._handle_key_event(event)
                                elif uinput is not None:
                                    if (
                                        event.type == ecodes.EV_SYN
                                        and event.code == ecodes.SYN_DROPPED
                                    ):
                                        continue
                                    uinput.write_event(event)
                        except OSError as e:
                            logger.error(
                                f"Error reading from device {device.path}: {e}"
                            )

        except Exception as e:
            logger.error(f"Error in hotkey listen loop: {e}", exc_info=True)
        finally:
            self._release_devices(uinput, grabbed_devices)
            logger.debug("Exiting hotkey listen loop")

    def _handle_key_event(self, event) -> None:
        """Handle a key event for the monitored key."""
        if event.value == 1:  # Key press
            logger.debug(f"{self.key_name} pressed")
            if self.on_press is not None:
                try:
                    self.on_press()
                except Exception as e:
                    logger.error(f"Error in on_press callback: {e}", exc_info=True)

        elif event.value == 0:  # Key release
            logger.debug(f"{self.key_name} released")
            if self.on_release is not None:
                try:
                    self.on_release()
                except Exception as e:
                    logger.error(f"Error in on_release callback: {e}", exc_info=True)

    def __enter__(self):
        self.start()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.stop()


def _detect_single_key(timeout: float = 30.0) -> str:
    """Wait for a single key press and return its name.

    Returns empty string on timeout or error.
    """
    import time

    devices = []
    for device_path in evdev.list_devices():
        try:
            device = InputDevice(device_path)
            if ecodes.EV_KEY in device.capabilities(verbose=False):
                devices.append(device)
        except (OSError, PermissionError):
            continue

    if not devices:
        return ""

    fd_to_device = {dev.fd: dev for dev in devices}
    deadline = time.time() + timeout
    try:
        while time.time() < deadline:
            r, _, _ = select.select(fd_to_device.keys(), [], [], 0.2)
            for fd in r:
                for event in fd_to_device[fd].read():
                    if event.type == ecodes.EV_KEY and event.value == 1 and event.code < 272:
                        key_event = categorize(event)
                        name = key_event.keycode
                        if isinstance(name, (list, tuple)):
                            name = name[0]
                        return name
    finally:
        for dev in devices:
            try:
                dev.close()
            except Exception:
                pass
    return ""


def detect_key_interactive() -> str:
    """Interactive utility to detect which key the user presses."""
    print("Key detection mode - Press any key to detect its name (Ctrl+C to exit)")
    print()

    devices = []
    for device_path in evdev.list_devices():
        try:
            device = InputDevice(device_path)
            capabilities = device.capabilities(verbose=False)

            if ecodes.EV_KEY in capabilities:
                devices.append(device)
                print(f"Monitoring: {device.path} - {device.name}")

        except (OSError, PermissionError) as e:
            print(f"Warning: Cannot access {device_path}: {e}")

    if not devices:
        print("\nError: No keyboard devices found!")
        print("You may need to run with sudo or add your user to the 'input' group:")
        print("  sudo usermod -a -G input $USER")
        print("  (then log out and back in)")
        return ""

    print("\nWaiting for key press...")
    print()

    try:
        fd_to_device = {dev.fd: dev for dev in devices}

        while True:
            r, w, x = select.select(fd_to_device.keys(), [], [], 0.1)

            for fd in r:
                device = fd_to_device[fd]

                for event in device.read():
                    if event.type == ecodes.EV_KEY:
                        key_event = categorize(event)
                        key_name = key_event.keycode

                        if isinstance(key_name, list):
                            key_name = key_name[0]

                        if event.value == 1:
                            print(f"Detected key: {key_name}")
                            print(f"  Device: {device.name}")
                            print(f"  Code: {event.code}")
                            print()
                            print(f"Use this in your config.json:")
                            print(f'  "evdev_key": "{key_name}"')
                            print()
                            return key_name

    except KeyboardInterrupt:
        print("\n\nKey detection cancelled")
        return ""
    finally:
        for device in devices:
            device.close()
