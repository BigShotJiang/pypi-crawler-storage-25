"""
Daemon orchestrator for Alto service.
"""

import logging
import os
import queue
import shutil
import signal
import subprocess
import tempfile
from pathlib import Path
from queue import Queue
from threading import Event, Thread
from typing import Optional

try:
    from importlib.metadata import version
except ImportError:
    from importlib_metadata import version

from alto.config import ServiceConfig
from alto.feedback import FeedbackManager
from alto.platforms import HotkeyListener, TextInjector, SleepMonitor
from alto.recorder import AudioRecorder
from alto.state import State, StateMachine
from alto.transcriber import Transcriber
from alto.tray import AltoTrayIcon
from alto.updater import UpdateChecker, UpdateInfo

logger = logging.getLogger(__name__)


def preflight_check(config: ServiceConfig) -> list[str]:
    """Perform preflight checks before starting the daemon.

    Verifies that all external dependencies are available and properly configured:
    - ydotoold daemon is running
    - User has read permissions on /dev/input/event* devices
    - Authentication is configured (cloud mode: credentials, local mode: MISTRAL_API_KEY)

    Args:
        config: Service configuration.

    Returns:
        List of error messages. Empty list if all checks pass.
    """
    errors = []

    # Check 1: Verify ydotoold is running
    try:
        result = subprocess.run(
            ["pidof", "ydotoold"],
            capture_output=True,
            text=True,
            timeout=2,
            check=False,
        )

        if result.returncode != 0:
            errors.append(
                "ydotoold daemon is not running. Start it with: "
                "sudo systemctl start ydotool"
            )
        else:
            logger.info("✓ ydotoold daemon is running")

    except subprocess.TimeoutExpired:
        errors.append("pidof command timed out while checking for ydotoold")
    except FileNotFoundError:
        errors.append("pidof command not found (required for preflight check)")

    # Check 2: Verify read permissions on /dev/input/event* devices
    input_devices = list(Path("/dev/input").glob("event*"))

    if not input_devices:
        errors.append("No /dev/input/event* devices found")
    else:
        readable_devices = []
        for device in input_devices:
            if os.access(device, os.R_OK):
                readable_devices.append(device)

        if not readable_devices:
            errors.append(
                "No read permissions on /dev/input/event* devices. "
                "Add your user to the 'input' group: "
                "sudo usermod -a -G input $USER (then log out and back in)"
            )
        else:
            logger.info(
                f"✓ Read permissions OK ({len(readable_devices)}/{len(input_devices)} devices readable)"
            )

    # Check 3: Authentication
    from alto.api_client import AltoAPIClient, APIError
    client = AltoAPIClient(base_url=config.api_base_url)
    if not client.is_authenticated():
        errors.append(
            "Not logged in to Alto. Run 'alto login' to authenticate."
        )
    else:
        try:
            client.get_me()
            logger.info("✓ Alto account authenticated")
        except APIError as e:
            if e.status_code == 401:
                errors.append(
                    "Alto session expired. Run 'alto login' to re-authenticate."
                )
            else:
                logger.warning(f"Could not verify Alto account: {e}")
                logger.info("✓ Alto credentials present (API check skipped)")

    return errors


class AltoDaemon:
    """Main daemon orchestrator for Alto service.

    Coordinates all components (hotkey listener, audio recorder, transcriber,
    text injector) and manages the workflow from key press to text injection.

    Args:
        config: Service configuration.
    """

    def __init__(self, config: ServiceConfig, config_path: Optional[Path] = None):
        self.config = config
        self.config_path = config_path or Path("config.json")
        self.state_machine = StateMachine(initial_state=State.READY)

        # Initialize components
        self.recorder = AudioRecorder(
            sample_rate=config.audio_sample_rate,
            channels=config.audio_channels,
            dtype=config.audio_dtype,
            blocksize=config.audio_blocksize,
            enable_noise_suppression=config.audio_enable_noise_suppression,
            enable_agc=config.audio_enable_agc,
        )

        # Initialize API client and transcriber
        from alto.api_client import AltoAPIClient
        self._api_client = AltoAPIClient(base_url=config.api_base_url)
        self.transcriber = Transcriber(
            api_client=self._api_client,
            language=config.language,
        )

        self.injector = TextInjector(delay_ms=config.typing_delay_ms)
        self.hotkey_listener: Optional[HotkeyListener] = None
        self.tray_icon: Optional[AltoTrayIcon] = None

        # Initialize feedback manager
        self.feedback_manager = FeedbackManager(
            feedback_url=config.feedback_url,
            enable_telemetry=config.enable_telemetry,
        )

        # Initialize update checker
        try:
            pkg_version = version("alto-dictation")
        except Exception:
            pkg_version = "1.0.0"  # Fallback if package not installed

        self.update_checker = UpdateChecker(
            current_version=pkg_version,
            check_enabled=config.check_for_updates,
        )
        self._update_info: Optional[UpdateInfo] = None

        # Sleep/wake monitor
        self.sleep_monitor = SleepMonitor(
            on_sleep=self._on_sleep,
            on_wake=self._on_wake,
        )

        # Worker thread management
        self._transcription_queue: Queue = Queue()
        self._injection_queue: Queue = Queue()
        self._transcription_worker: Optional[Thread] = None
        self._injection_worker: Optional[Thread] = None
        self._account_poll_worker: Optional[Thread] = None
        self._stop_event = Event()

        # Temporary audio file for current recording
        self._current_audio_file: Optional[Path] = None

        # Preflight check results
        self._preflight_errors: list[str] = []

        logger.info("AltoDaemon initialized")

    def _startup_login(self) -> None:
        """Attempt browser login at startup (runs in background thread)."""
        logger.info("Not authenticated — opening browser for login...")
        try:
            self._api_client.browser_login(timeout=120)
            logger.info("Startup login successful")
            if self.tray_icon:
                try:
                    user_info = self._api_client.get_me()
                    usage_info = self._api_client.get_usage()
                    self.tray_icon.update_account_info(user_info, usage_info)
                except Exception:
                    self.tray_icon.set_authenticated(True)
            # Start account polling now that we're authenticated
            if self._account_poll_worker is None:
                self._account_poll_worker = Thread(
                    target=self._account_poll_loop,
                    daemon=True,
                    name="AccountPollWorker",
                )
                self._account_poll_worker.start()
        except Exception as e:
            logger.warning(f"Startup login failed: {e}")

    def _try_browser_login(self) -> bool:
        """Attempt browser-based login. Returns True on success."""
        if not self._api_client:
            return False
        try:
            logger.info("Not authenticated — opening browser for login...")
            self._api_client.browser_login(timeout=120)
            logger.info("Browser login successful")
            return True
        except Exception as e:
            logger.warning(f"Browser login failed: {e}")
            return False

    def start(self) -> None:
        """Start the Alto daemon."""
        logger.info("Starting Alto daemon")

        # Check auth state (without blocking on login yet)
        is_authenticated = True
        needs_login = False
        if self._api_client:
            if not self._api_client.is_authenticated():
                needs_login = True
                is_authenticated = False
            else:
                try:
                    self._api_client.get_me()
                except Exception:
                    needs_login = True
                    is_authenticated = False

        # Perform preflight checks
        self._preflight_errors = preflight_check(self.config)

        if self._preflight_errors:
            # If the only error is auth and we're running unauthenticated, don't block
            auth_errors = [e for e in self._preflight_errors if "logged in" in e or "login" in e.lower() or "authenticate" in e.lower()]
            other_errors = [e for e in self._preflight_errors if e not in auth_errors]

            if other_errors:
                logger.error("Preflight checks failed:")
                for error in other_errors:
                    logger.error(f"  - {error}")
                self.state_machine.transition(State.ERROR)
                return

            # Auth-only errors: continue with degraded mode (orange tray)
            if auth_errors and not is_authenticated:
                logger.warning("Running without authentication — dictation disabled until login")

        logger.info("Preflight checks passed")

        # Check for updates
        try:
            self._update_info = self.update_checker.check_for_updates()
            if self._update_info and self._update_info.update_available:
                logger.info(
                    f"Update available: {self._update_info.latest_version} "
                    f"(current: {self._update_info.current_version})"
                )
            elif self._update_info:
                logger.info("Alto is up to date")
        except Exception as e:
            logger.warning(f"Update check failed: {e}")
            self._update_info = None

        # Log startup event
        self.feedback_manager.log_event("daemon_started", include_system_info=True)

        # Build tray icon kwargs
        tray_kwargs = {
            "on_quit": self._handle_tray_quit,
            "on_feedback": self._handle_tray_feedback,
            "on_settings": self._handle_tray_settings,
            "on_login": lambda: Thread(target=self._handle_tray_login, daemon=True, name="TrayLogin").start(),
            "on_manage_subscription": lambda: self._handle_tray_manage_subscription(),
            "on_logout": lambda: self._handle_tray_logout(),
            "update_info": self._update_info,
            "authenticated": is_authenticated,
        }

        # Add account info
        if self._api_client and is_authenticated:
            try:
                user_info = self._api_client.get_me()
                tray_kwargs["user_info"] = user_info
                usage = self._api_client.get_usage()
                tray_kwargs["usage_info"] = usage

                # Subscription status notifications
                sub_status = user_info.get("subscription_status", "none")
                if sub_status == "scheduled_cancel":
                    ends_at = user_info.get("subscription_ends_at", "")
                    self._send_notification(
                        "Alto — Subscription",
                        f"Your subscription ends on {ends_at}.\n"
                        "You can renew it from the menu.",
                    )
                elif sub_status == "past_due":
                    self._send_notification(
                        "Alto — Payment issue",
                        "A payment has failed. Please update your payment method\n"
                        "to avoid service interruption.",
                        urgency="critical",
                    )
            except Exception as e:
                logger.warning(f"Could not fetch account info for tray: {e}")

        # Start tray icon
        self.tray_icon = AltoTrayIcon(**tray_kwargs)
        self.tray_icon.start()

        # Start worker threads
        self._stop_event.clear()

        # Start account polling (refreshes tray when subscription changes)
        if self._api_client and is_authenticated:
            self._account_poll_worker = Thread(
                target=self._account_poll_loop,
                daemon=True,
                name="AccountPollWorker",
            )
            self._account_poll_worker.start()

        self._transcription_worker = Thread(
            target=self._transcription_worker_loop,
            daemon=True,
            name="TranscriptionWorker",
        )
        self._transcription_worker.start()

        self._injection_worker = Thread(
            target=self._injection_worker_loop,
            daemon=True,
            name="InjectionWorker",
        )
        self._injection_worker.start()

        # Register state transition callback
        self.state_machine.register_callback(self._on_state_change)

        # Start hotkey listener
        self.hotkey_listener = HotkeyListener(
            key_name=self.config.evdev_key,
            on_press=self._on_key_press,
            on_release=self._on_key_release,
            devices=self.config.evdev_devices,
        )
        self.hotkey_listener.start()

        # Start sleep/wake monitor
        self.sleep_monitor.start()

        # If login needed, trigger it now (non-blocking — tray is already visible)
        if needs_login and self._api_client:
            Thread(
                target=self._startup_login,
                daemon=True,
                name="StartupLogin",
            ).start()

        logger.info(f"Alto daemon started (listening for {self.config.evdev_key})")

        # Set up signal handlers for clean shutdown
        signal.signal(signal.SIGTERM, self._signal_handler)
        signal.signal(signal.SIGINT, self._signal_handler)

    def stop(self) -> None:
        """Stop the Alto daemon and clean up resources."""
        logger.info("Stopping Alto daemon")

        # Stop sleep monitor
        self.sleep_monitor.stop()

        # Stop tray icon
        if self.tray_icon is not None:
            self.tray_icon.stop()
            self.tray_icon = None

        # Stop hotkey listener
        if self.hotkey_listener is not None:
            self.hotkey_listener.stop()
            self.hotkey_listener = None

        # Stop worker threads
        self._stop_event.set()

        if self._account_poll_worker is not None:
            self._account_poll_worker.join(timeout=5.0)
            self._account_poll_worker = None

        if self._transcription_worker is not None:
            self._transcription_queue.put(None)
            self._transcription_worker.join(timeout=5.0)
            self._transcription_worker = None

        if self._injection_worker is not None:
            self._injection_queue.put(None)
            self._injection_worker.join(timeout=5.0)
            self._injection_worker = None

        # Clean up any lingering temp files
        if self._current_audio_file and self._current_audio_file.exists():
            try:
                self._current_audio_file.unlink()
                logger.debug(f"Cleaned up temp audio file: {self._current_audio_file}")
            except Exception as e:
                logger.warning(f"Failed to clean up temp audio file: {e}")

        logger.info("Alto daemon stopped")

    def get_preflight_errors(self) -> list[str]:
        return self._preflight_errors.copy()

    def _on_key_press(self) -> None:
        """Handle push-to-talk key press event (non-blocking)."""
        logger.debug("Key press event received")

        try:
            if not self.state_machine.can_transition(State.RECORDING):
                logger.warning(
                    f"Cannot start recording: current state is {self.state_machine.state.name}"
                )
                return

            self.state_machine.transition(State.RECORDING)

            Thread(
                target=self._start_recording_async,
                daemon=True,
                name="RecordingStart",
            ).start()

        except Exception as e:
            logger.error(f"Unexpected error handling key press: {e}", exc_info=True)
            self._handle_error(f"Unexpected error: {type(e).__name__}")

    def _start_recording_async(self) -> None:
        try:
            self.recorder.start()
            logger.info("Recording started")
            self.feedback_manager.log_event("recording_started")
        except RuntimeError as e:
            logger.error(f"Failed to start recording: {e}")
            self._handle_error(f"Recording failed: {e}")
        except Exception as e:
            logger.error(f"Unexpected error starting recording: {e}", exc_info=True)
            self._handle_error(f"Unexpected error: {type(e).__name__}")

    def _on_key_release(self) -> None:
        """Handle push-to-talk key release event (non-blocking)."""
        logger.debug("Key release event received")

        try:
            if self.state_machine.state != State.RECORDING:
                logger.debug(
                    f"Ignoring key release: current state is {self.state_machine.state.name}"
                )
                return

            Thread(
                target=self._stop_recording_async,
                daemon=True,
                name="RecordingStop",
            ).start()

        except Exception as e:
            logger.error(f"Unexpected error handling key release: {e}", exc_info=True)
            self._handle_error(f"Unexpected error: {type(e).__name__}")

    def _stop_recording_async(self) -> None:
        try:
            audio_bytes, duration = self.recorder.stop()
            logger.info(f"Recording stopped: {duration:.2f}s")

            self.feedback_manager.log_event(
                "recording_stopped",
                event_data={"duration_seconds": round(duration, 2)}
            )

            if duration < 0.1:
                logger.warning("Recording too short, ignoring")
                self.state_machine.transition(State.READY)
                return

            temp_file = Path(tempfile.mktemp(suffix=".wav", prefix="alto_"))
            self.recorder.save_to_file(audio_bytes, temp_file)
            self._current_audio_file = temp_file

            self.state_machine.transition(State.TRANSCRIBING)

            self._transcription_queue.put(temp_file)

        except RuntimeError as e:
            logger.error(f"Failed to stop recording: {e}")
            self._handle_error(f"Recording stop failed: {e}")
        except OSError as e:
            logger.error(f"Failed to save audio file: {e}")
            self._handle_error(f"Audio save failed: {e}")
        except Exception as e:
            logger.error(f"Unexpected error stopping recording: {e}", exc_info=True)
            self._handle_error(f"Unexpected error: {type(e).__name__}")

    def _transcription_worker_loop(self) -> None:
        logger.debug("Transcription worker started")

        while not self._stop_event.is_set():
            try:
                audio_file = self._transcription_queue.get(timeout=1.0)
            except queue.Empty:
                continue

            if audio_file is None:
                break

            try:
                text = self.transcriber.transcribe(audio_file)

                if text is None or not text.strip():
                    logger.warning("Transcription returned empty text")
                    self.feedback_manager.log_event("transcription_failed", event_data={"reason": "empty_result"})
                    self._handle_error("Transcription failed: empty result")
                    continue

                self.feedback_manager.log_event(
                    "transcription_completed",
                    event_data={"text_length": len(text)}
                )

                # Check if usage is running low
                self._check_usage_warning()

                self.state_machine.transition(State.TYPING)

                self._injection_queue.put(text, block=False)

            except Exception as e:
                error_name = type(e).__name__
                logger.error(f"Transcription error: {error_name}: {e}")

                # Show user-friendly message for usage limits
                if error_name == "UsageLimitError":
                    tier = "free"
                    try:
                        ui = getattr(self._api_client, '_user_info', None)
                        if ui:
                            tier = ui.get("tier", "free")
                    except Exception:
                        pass

                    if tier == "free":
                        limit_msg = "Upgrade to Pro ($5/mo) for 180 min/month."
                    elif tier == "pro":
                        limit_msg = "Upgrade to Max ($9/mo) for 600 min/month."
                    else:
                        limit_msg = "600 min quota reached. Resets on the 1st of the month."

                    self._send_notification(
                        "Alto — Limit reached",
                        f"Your monthly quota is exhausted.\n{limit_msg}",
                        urgency="critical",
                    )
                    self._handle_error(f"Usage limit reached. {limit_msg}")
                else:
                    self._handle_error(f"Transcription error: {error_name}")

        logger.debug("Transcription worker stopped")

    def _injection_worker_loop(self) -> None:
        logger.debug("Injection worker started")

        while not self._stop_event.is_set():
            try:
                text = self._injection_queue.get(timeout=1.0)
            except queue.Empty:
                continue

            if text is None:
                break

            try:
                self.injector.type_text(text)

                self.feedback_manager.log_event(
                    "text_injection_completed",
                    event_data={"text_length": len(text)}
                )

                self.state_machine.transition(State.READY)

            except RuntimeError as e:
                logger.error(f"Text injection failed: {e}")
                self._handle_error(f"Text injection failed: {e}")
            except Exception as e:
                logger.error(f"Unexpected injection error: {type(e).__name__}: {e}")
                self._handle_error(f"Injection error: {type(e).__name__}")

        logger.debug("Injection worker stopped")

    def _send_notification(self, title: str, body: str, urgency: str = "normal") -> None:
        """Send a desktop notification via notify-send."""
        try:
            cmd = ["notify-send", f"--urgency={urgency}", "--app-name=Alto", title, body]
            subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        except FileNotFoundError:
            logger.debug("notify-send not available, skipping notification")

    def _check_usage_warning(self) -> None:
        """Check remaining usage and warn the user if running low."""
        if not self._api_client:
            return

        remaining = self._api_client.usage_remaining_seconds
        if remaining is None:
            return

        # Determine tier limits to calculate percentage
        try:
            user_info = getattr(self._api_client, '_user_info', None)
            tier = user_info.get("tier", "free") if user_info else "free"
        except Exception:
            tier = "free"

        if tier == "free":
            limit = 900.0  # 15 min
        elif tier == "pro":
            limit = 10800.0  # 180 min
        else:
            limit = 36000.0  # 600 min
        threshold = limit * 0.2  # 20% remaining

        remaining_min = remaining / 60.0
        if remaining <= 0:
            return  # Already handled by UsageLimitError
        if remaining <= threshold and not getattr(self, '_usage_warning_sent', False):
            self._usage_warning_sent = True

            if tier == "free":
                upgrade_hint = "Upgrade to Pro ($5/mo) for 180 min/month."
            elif tier == "pro":
                upgrade_hint = "Upgrade to Max ($9/mo) for 600 min/month."
            else:
                upgrade_hint = "Resets on the 1st of the month."

            self._send_notification(
                "Alto — Quota running low",
                f"You have {remaining_min:.0f} minute(s) left this month.\n{upgrade_hint}",
                urgency="normal",
            )
            logger.info(f"Usage warning: {remaining_min:.0f} min remaining")

    def _handle_error(self, error_context: Optional[str] = None) -> None:
        context_msg = f" ({error_context})" if error_context else ""
        logger.warning(f"Handling error condition{context_msg}")

        try:
            if self.recorder.is_recording():
                self.recorder.stop()
                logger.debug("Stopped ongoing recording due to error")
        except Exception as e:
            logger.error(f"Error stopping recorder: {e}", exc_info=True)

        try:
            self.state_machine.transition(State.ERROR, error_context=error_context)
            self.state_machine.recover_from_error()
        except Exception as e:
            logger.error(f"Error during state transition: {e}", exc_info=True)
            self.state_machine.reset()

    def _on_state_change(self, old_state: State, new_state: State) -> None:
        logger.info(f"State transition: {old_state.name} -> {new_state.name}")

        if self.tray_icon is not None:
            error_context = None
            if new_state == State.ERROR:
                error_context = self.state_machine.get_error_context()

            self.tray_icon.update_state(new_state, error_context=error_context)

    def _handle_tray_login(self) -> None:
        """Handle login request from tray menu (runs in background thread)."""
        if not self._api_client:
            return
        try:
            self._api_client.browser_login(timeout=120)
            logger.info("Tray login successful")
            if self.tray_icon:
                try:
                    user_info = self._api_client.get_me()
                    usage_info = self._api_client.get_usage()
                    self.tray_icon.update_account_info(user_info, usage_info)
                except Exception:
                    self.tray_icon.set_authenticated(True)
            # Start account polling now that we're authenticated
            if self._account_poll_worker is None:
                self._account_poll_worker = Thread(
                    target=self._account_poll_loop,
                    daemon=True,
                    name="AccountPollWorker",
                )
                self._account_poll_worker.start()
        except Exception as e:
            logger.warning(f"Tray login failed: {e}")

    def _account_poll_loop(self) -> None:
        """Poll /me every 30s and update tray when subscription info changes."""
        logger.debug("Account poll worker started")
        last_tier = None
        last_status = None

        while not self._stop_event.is_set():
            # Wait 30 seconds between polls (but check stop every 1s)
            for _ in range(30):
                if self._stop_event.is_set():
                    return
                self._stop_event.wait(timeout=1.0)

            if not self._api_client:
                continue

            try:
                user_info = self._api_client.get_me()
                tier = user_info.get("tier")
                status = user_info.get("subscription_status")

                if tier != last_tier or status != last_status:
                    logger.info(f"Account poll: tier={tier}, status={status}")
                    last_tier = tier
                    last_status = status

                    # Refresh usage too
                    try:
                        usage_info = self._api_client.get_usage()
                    except Exception:
                        usage_info = None

                    if self.tray_icon:
                        self.tray_icon.update_account_info(user_info, usage_info)

            except Exception as e:
                logger.debug(f"Account poll failed: {e}")

        logger.debug("Account poll worker stopped")

    def _handle_tray_logout(self) -> None:
        """Handle logout request from tray menu — switch to unauthenticated mode."""
        if self._api_client:
            self._api_client.logout()
            logger.info("User logged out from tray")
        if self.tray_icon:
            self.tray_icon.set_authenticated(False)

    def _handle_tray_manage_subscription(self) -> None:
        """Handle manage subscription request from tray menu."""
        if not self._api_client:
            return
        try:
            portal_url = self._api_client.get_billing_portal()
            if portal_url:
                import webbrowser
                webbrowser.open(portal_url)
            else:
                self._send_notification(
                    "Alto",
                    "Could not open the billing portal.\nNo active Creem subscription found.",
                )
        except Exception as e:
            logger.error(f"Error opening billing portal: {e}")
            self._send_notification(
                "Alto",
                "Could not open the billing portal.",
            )

    def _handle_tray_quit(self) -> None:
        logger.info("Quit requested from tray icon")
        self.feedback_manager.log_event("daemon_stopped")
        self._stop_event.set()

    def _handle_tray_feedback(self) -> None:
        logger.info("Feedback/Report Issue requested from tray icon")
        self.feedback_manager.log_event("feedback_requested")
        success = self.feedback_manager.open_feedback_url()
        if not success:
            logger.warning("Failed to open feedback URL, please visit manually: %s", self.config.feedback_url)

    def _handle_tray_settings(self) -> None:
        logger.info("Settings requested from tray icon")

        from alto.settings_window import open_settings_window

        open_settings_window(
            config=self.config,
            config_path=self.config_path,
            on_save=self._restart,
            hotkey_listener=None,  # Don't pass — detection runs in subprocess
            api_client=self._api_client,
        )

    def _restart(self) -> None:
        import sys

        logger.info("Restarting Alto daemon after settings change")
        self.stop()
        os.execv(sys.executable, [sys.executable] + sys.argv)

    def _on_sleep(self) -> None:
        logger.info("Preparing for system sleep")

        try:
            if self.recorder.is_recording():
                self.recorder.stop()
                logger.info("Stopped active recording before sleep")
        except Exception as e:
            logger.warning(f"Error stopping recorder before sleep: {e}")

        if self.state_machine.state not in (State.READY, State.ERROR):
            try:
                self.state_machine.reset()
            except Exception:
                pass

        try:
            self.injector._cleanup_clipboard_proc()
        except Exception:
            pass

        if self.hotkey_listener is not None:
            self.hotkey_listener.suspend()

        logger.info("Ready for system sleep")

    def _on_wake(self) -> None:
        import time

        delays = [1, 2, 4, 8]

        for attempt, delay in enumerate(delays, 1):
            logger.info(
                "System wake: attempting device recovery "
                f"(attempt {attempt}/{len(delays)}, waiting {delay}s)"
            )
            time.sleep(delay)

            if self.hotkey_listener is not None:
                if self.hotkey_listener.resume():
                    break
        else:
            logger.error(
                "Failed to recover input devices after all attempts. "
                "Hotkey listener may be non-functional until restart."
            )

        if self.tray_icon is not None:
            self.tray_icon.update_state(State.READY)

        logger.info("System wake recovery complete")

    def _signal_handler(self, signum: int, frame) -> None:
        logger.info(f"Received signal {signum}, shutting down...")
        self.stop()

    def run(self) -> None:
        """Run the daemon (blocking)."""
        self.start()

        # Only bail on non-auth errors — auth errors allow degraded mode
        non_auth_errors = [
            e for e in self._preflight_errors
            if "logged in" not in e and "login" not in e.lower() and "authenticate" not in e.lower()
        ]
        if non_auth_errors:
            logger.error("Daemon not running due to preflight errors")
            return

        try:
            self._stop_event.wait()
        except KeyboardInterrupt:
            logger.info("Keyboard interrupt received")
        finally:
            self.stop()
