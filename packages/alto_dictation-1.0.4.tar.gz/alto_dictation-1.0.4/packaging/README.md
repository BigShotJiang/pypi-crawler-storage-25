# Alto Packaging

This directory contains packaging configurations for distributing Alto across different platforms.

## Supported Package Formats

- **PyPI**: Python package distribution via pip
- **Debian/Ubuntu**: `.deb` packages
- **Fedora/RHEL**: `.rpm` packages
- **Arch Linux**: `PKGBUILD` for AUR

## PyPI Distribution

### Building for PyPI

```bash
# Install build dependencies
pip install build twine

# Build source distribution and wheel
python -m build

# Test the build locally
pip install dist/alto_dictation-0.1.0-py3-none-any.whl

# Upload to PyPI (requires account)
python -m twine upload dist/*
```

### Installing from PyPI

```bash
pip install alto-dictation
```

## Debian/Ubuntu Package

### Building .deb Package

```bash
# Install build dependencies
sudo apt install debhelper dh-python python3-all python3-setuptools

# Build the package
cd packaging/debian
dpkg-buildpackage -us -uc -b

# The .deb file will be in the parent directory
```

### Installing .deb Package

```bash
sudo dpkg -i alto-dictation_0.1.0-1_all.deb
sudo apt-get install -f  # Install dependencies if needed
```

### Building with pbuilder (for clean environment)

```bash
# Create base environment
sudo pbuilder create

# Build package in clean environment
sudo pbuilder build packaging/debian/alto-dictation_0.1.0-1.dsc
```

## Fedora/RHEL Package

### Building .rpm Package

```bash
# Install build dependencies
sudo dnf install rpm-build rpmdevtools python3-devel

# Set up RPM build environment
rpmdev-setuptree

# Copy spec file
cp packaging/rpm/alto-dictation.spec ~/rpmbuild/SPECS/

# Download source tarball
spectool -g -R ~/rpmbuild/SPECS/alto-dictation.spec

# Build the package
rpmbuild -ba ~/rpmbuild/SPECS/alto-dictation.spec

# The .rpm file will be in ~/rpmbuild/RPMS/noarch/
```

### Installing .rpm Package

```bash
sudo dnf install ~/rpmbuild/RPMS/noarch/alto-dictation-0.1.0-1.noarch.rpm
```

### Building with mock (for clean environment)

```bash
# Install mock
sudo dnf install mock

# Add yourself to mock group
sudo usermod -a -G mock $USER

# Build package in clean environment
mock -r fedora-39-x86_64 ~/rpmbuild/SPECS/alto-dictation.spec
```

## Arch Linux Package

### Building with makepkg

```bash
# Navigate to PKGBUILD directory
cd packaging/arch

# Build the package
makepkg -s

# Install the package
sudo pacman -U alto-dictation-0.1.0-1-any.pkg.tar.zst
```

### Installing from AUR

Once published to AUR:

```bash
# Using yay
yay -S alto-dictation

# Using paru
paru -S alto-dictation

# Manual installation
git clone https://aur.archlinux.org/alto-dictation.git
cd alto-dictation
makepkg -si
```

## Post-Installation Steps

All packages include post-installation scripts that guide users through:

1. Adding user to `input` group for keyboard access
2. Enabling and starting `ydotool` service
3. Setting the `MISTRAL_API_KEY` environment variable
4. Configuring the push-to-talk key
5. Starting Alto

## Testing Packages

### Debian/Ubuntu Testing

```bash
# Install in a clean Docker container
docker run -it ubuntu:22.04 bash
apt update
apt install -y ./alto-dictation_0.1.0-1_all.deb
```

### Fedora Testing

```bash
# Install in a clean Docker container
docker run -it fedora:39 bash
dnf install -y ./alto-dictation-0.1.0-1.noarch.rpm
```

### Arch Testing

```bash
# Install in a clean Docker container
docker run -it archlinux:latest bash
pacman -U --noconfirm alto-dictation-0.1.0-1-any.pkg.tar.zst
```

## Version Bumping

When releasing a new version:

1. Update version in `pyproject.toml`
2. Update version in `alto/__init__.py`
3. Update version in `packaging/debian/changelog`
4. Update version in `packaging/rpm/alto-dictation.spec`
5. Update version in `packaging/arch/PKGBUILD`
6. Create git tag: `git tag -a v0.1.0 -m "Release v0.1.0"`
7. Build and publish packages

## Automation Scripts

See `scripts/build_packages.sh` for automated package building across all platforms.

## License

All packaging files are distributed under the same license as Alto (MIT).
