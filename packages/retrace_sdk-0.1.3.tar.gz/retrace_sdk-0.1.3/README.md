# retrace-sdk

The execution replay engine for AI agents. Record every LLM call, tool invocation, and error your AI agent makes. Replay step-by-step. Fork from any point. Share interactive traces via URL.

## Install

```bash
pip install retrace-sdk
```

## Quick Start

```python
from retrace_sdk import configure, record

configure(api_key="rt_live_...")

@record(name="my-agent")
def run_agent(prompt: str):
    response = client.chat.completions.create(
        model="gpt-4o",
        messages=[{"role": "user", "content": prompt}]
    )
    return response.choices[0].message.content

run_agent("What is quantum computing?")
```

## Features

- **Record** — One decorator captures every LLM call, tool call, and error
- **Replay** — Step through executions with play/pause/speed controls
- **Fork** — Branch from any step, modify input, watch a new path diverge
- **Share** — Publish traces as shareable "tapes" with interactive playback

## Links

- [Documentation](https://retrace.yashbogam.me/docs)
- [GitHub](https://github.com/yash1511-bogam/retrace)
