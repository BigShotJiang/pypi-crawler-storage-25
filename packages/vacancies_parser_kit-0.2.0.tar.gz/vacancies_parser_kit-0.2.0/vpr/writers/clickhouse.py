"""ClickHouse writer."""

from __future__ import annotations

import json
from typing import Any

from vpr.core.models import Vacancy
from vpr.writers.base import BaseWriter
from vpr.writers.registry import register_writer

CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS {table} (
    source          String,
    source_id       String,
    title           Nullable(String),
    company         Nullable(String),
    description     Nullable(String),
    url             Nullable(String),
    city            Nullable(String),
    region          Nullable(String),
    country         Nullable(String),
    is_remote       Nullable(UInt8),
    salary_min      Nullable(Float64),
    salary_max      Nullable(Float64),
    salary_currency Nullable(String),
    experience      Nullable(String),
    employment_type Nullable(String),
    schedule        Nullable(String),
    skills          Array(String),
    published_at    Nullable(DateTime64(3)),
    fetched_at      DateTime64(3),
    status          String,
    raw             String
) ENGINE = ReplacingMergeTree()
ORDER BY (source, source_id)
"""


@register_writer
class ClickHouseWriter(BaseWriter):
    writer_type = "clickhouse"

    def __init__(self, target_config):
        super().__init__(target_config)
        self._client = None

    def _get_client(self):
        if self._client is None:
            import clickhouse_connect

            cfg = self.target_config
            self._client = clickhouse_connect.get_client(
                host=getattr(cfg, "host", "localhost"),
                port=int(getattr(cfg, "port", 8123)),
                database=getattr(cfg, "database", "default"),
                username=getattr(cfg, "user", "default"),
                password=getattr(cfg, "password", ""),
            )
            table = cfg.params.get("table", "vacancies")
            self._client.command(CREATE_TABLE.format(table=table))
        return self._client

    async def write(self, vacancies: list[Vacancy]) -> int:
        client = self._get_client()
        table = self.target_config.params.get("table", "vacancies")

        rows = [self._to_row(v) for v in vacancies]
        columns = [
            "source", "source_id", "title", "company", "description", "url",
            "city", "region", "country", "is_remote",
            "salary_min", "salary_max", "salary_currency",
            "experience", "employment_type", "schedule", "skills",
            "published_at", "fetched_at", "status", "raw",
        ]
        client.insert(table, rows, column_names=columns)
        return len(rows)

    async def close(self) -> None:
        if self._client:
            self._client.close()
            self._client = None

    @staticmethod
    def _to_row(v: Vacancy) -> list[Any]:
        return [
            v.source,
            v.source_id,
            v.title,
            v.company,
            v.description,
            v.url,
            v.city,
            v.region,
            v.country,
            int(v.is_remote) if v.is_remote is not None else None,
            v.salary.min if v.salary else None,
            v.salary.max if v.salary else None,
            v.salary.currency if v.salary else None,
            v.experience,
            v.employment_type,
            v.schedule,
            v.skills,
            v.published_at,
            v.fetched_at,
            v.status.value,
            json.dumps(v.raw, ensure_ascii=False, default=str),
        ]
