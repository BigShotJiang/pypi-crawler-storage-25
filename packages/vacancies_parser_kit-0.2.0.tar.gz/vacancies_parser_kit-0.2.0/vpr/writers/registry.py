"""Writer plugin registry."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vpr.writers.base import BaseWriter

_REGISTRY: dict[str, type[BaseWriter]] = {}


def register_writer(cls: type[BaseWriter]) -> type[BaseWriter]:
    """Class decorator: register a writer plugin by its ``writer_type``."""
    _REGISTRY[cls.writer_type] = cls
    return cls


def get_writer_class(writer_type: str) -> type[BaseWriter]:
    if writer_type not in _REGISTRY:
        available = ", ".join(sorted(_REGISTRY)) or "(none)"
        raise KeyError(f"Unknown writer type '{writer_type}'. Available: {available}")
    return _REGISTRY[writer_type]


def available_writer_types() -> list[str]:
    return sorted(_REGISTRY)
