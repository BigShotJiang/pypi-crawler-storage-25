"""Base class for vacancy writers (storage backends)."""

from __future__ import annotations

from abc import ABC, abstractmethod

from vpr.config.profile import TargetConfig
from vpr.core.models import Vacancy


class BaseWriter(ABC):
    """Every writer plugin extends this class."""

    writer_type: str  # must match the ``type`` field in profiles target

    def __init__(self, target_config: TargetConfig) -> None:
        self.target_config = target_config

    @abstractmethod
    async def write(self, vacancies: list[Vacancy]) -> int:
        """Write vacancies to the target. Return number of rows written."""
        ...  # pragma: no cover

    async def close(self) -> None:
        """Release resources (connections, etc.)."""
