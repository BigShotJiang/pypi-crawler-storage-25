"""JSONL file writer — zero-dependency local storage."""

from __future__ import annotations

import json
from pathlib import Path

from vpr.core.models import Vacancy
from vpr.writers.base import BaseWriter
from vpr.writers.registry import register_writer


@register_writer
class JsonlWriter(BaseWriter):
    writer_type = "jsonl"

    async def write(self, vacancies: list[Vacancy]) -> int:
        path = Path(self.target_config.params.get("path", "vacancies.jsonl"))
        path.parent.mkdir(parents=True, exist_ok=True)

        mode = self.target_config.params.get("mode", "append")
        file_mode = "a" if mode == "append" else "w"

        with open(path, file_mode, encoding="utf-8") as f:
            for v in vacancies:
                f.write(v.model_dump_json() + "\n")

        return len(vacancies)
