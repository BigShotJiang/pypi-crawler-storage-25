"""PostgreSQL writer."""

from __future__ import annotations

import json

from vpr.core.models import Vacancy
from vpr.writers.base import BaseWriter
from vpr.writers.registry import register_writer

CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS {table} (
    source          TEXT NOT NULL,
    source_id       TEXT NOT NULL,
    title           TEXT,
    company         TEXT,
    description     TEXT,
    url             TEXT,
    city            TEXT,
    region          TEXT,
    country         TEXT,
    is_remote       BOOLEAN,
    salary_min      DOUBLE PRECISION,
    salary_max      DOUBLE PRECISION,
    salary_currency TEXT,
    experience      TEXT,
    employment_type TEXT,
    schedule        TEXT,
    skills          JSONB DEFAULT '[]',
    published_at    TIMESTAMPTZ,
    fetched_at      TIMESTAMPTZ,
    status          TEXT,
    raw             JSONB DEFAULT '{}',
    PRIMARY KEY (source, source_id)
)
"""

UPSERT = """
INSERT INTO {table} (
    source, source_id, title, company, description, url,
    city, region, country, is_remote,
    salary_min, salary_max, salary_currency,
    experience, employment_type, schedule, skills,
    published_at, fetched_at, status, raw
) VALUES (
    $1, $2, $3, $4, $5, $6,
    $7, $8, $9, $10,
    $11, $12, $13,
    $14, $15, $16, $17,
    $18, $19, $20, $21
)
ON CONFLICT (source, source_id) DO UPDATE SET
    title=EXCLUDED.title, company=EXCLUDED.company,
    description=EXCLUDED.description, url=EXCLUDED.url,
    city=EXCLUDED.city, region=EXCLUDED.region, country=EXCLUDED.country,
    is_remote=EXCLUDED.is_remote,
    salary_min=EXCLUDED.salary_min, salary_max=EXCLUDED.salary_max,
    salary_currency=EXCLUDED.salary_currency,
    experience=EXCLUDED.experience, employment_type=EXCLUDED.employment_type,
    schedule=EXCLUDED.schedule, skills=EXCLUDED.skills,
    published_at=EXCLUDED.published_at, fetched_at=EXCLUDED.fetched_at,
    status=EXCLUDED.status, raw=EXCLUDED.raw
"""


@register_writer
class PostgresWriter(BaseWriter):
    writer_type = "postgres"

    def __init__(self, target_config):
        super().__init__(target_config)
        self._pool = None

    async def _get_pool(self):
        if self._pool is None:
            import asyncpg

            cfg = self.target_config
            self._pool = await asyncpg.create_pool(
                host=getattr(cfg, "host", "localhost"),
                port=int(getattr(cfg, "port", 5432)),
                database=getattr(cfg, "database", "vacancies"),
                user=getattr(cfg, "user", "postgres"),
                password=getattr(cfg, "password", ""),
                min_size=1,
                max_size=5,
            )
            table = cfg.params.get("table", "vacancies")
            async with self._pool.acquire() as conn:
                await conn.execute(CREATE_TABLE.format(table=table))
        return self._pool

    async def write(self, vacancies: list[Vacancy]) -> int:
        pool = await self._get_pool()
        table = self.target_config.params.get("table", "vacancies")
        query = UPSERT.format(table=table)

        async with pool.acquire() as conn:
            for v in vacancies:
                await conn.execute(query, *self._to_args(v))
        return len(vacancies)

    async def close(self) -> None:
        if self._pool:
            await self._pool.close()
            self._pool = None

    @staticmethod
    def _to_args(v: Vacancy) -> tuple:
        return (
            v.source,
            v.source_id,
            v.title,
            v.company,
            v.description,
            v.url,
            v.city,
            v.region,
            v.country,
            v.is_remote,
            v.salary.min if v.salary else None,
            v.salary.max if v.salary else None,
            v.salary.currency if v.salary else None,
            v.experience,
            v.employment_type,
            v.schedule,
            json.dumps(v.skills, ensure_ascii=False),
            v.published_at,
            v.fetched_at,
            v.status.value,
            json.dumps(v.raw, ensure_ascii=False, default=str),
        )
