"""SQLite writer — lightweight local database, zero external deps."""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from vpr.core.models import Vacancy
from vpr.writers.base import BaseWriter
from vpr.writers.registry import register_writer

CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS vacancies (
    source       TEXT NOT NULL,
    source_id    TEXT NOT NULL,
    title        TEXT,
    company      TEXT,
    description  TEXT,
    url          TEXT,
    city         TEXT,
    region       TEXT,
    country      TEXT,
    is_remote    INTEGER,
    salary_min   REAL,
    salary_max   REAL,
    salary_currency TEXT,
    experience   TEXT,
    employment_type TEXT,
    schedule     TEXT,
    skills       TEXT,  -- JSON array
    published_at TEXT,
    fetched_at   TEXT,
    status       TEXT,
    raw          TEXT,  -- full JSON
    PRIMARY KEY (source, source_id)
)
"""

UPSERT = """
INSERT INTO vacancies (
    source, source_id, title, company, description, url,
    city, region, country, is_remote,
    salary_min, salary_max, salary_currency,
    experience, employment_type, schedule, skills,
    published_at, fetched_at, status, raw
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
ON CONFLICT(source, source_id) DO UPDATE SET
    title=excluded.title, company=excluded.company,
    description=excluded.description, url=excluded.url,
    city=excluded.city, region=excluded.region, country=excluded.country,
    is_remote=excluded.is_remote,
    salary_min=excluded.salary_min, salary_max=excluded.salary_max,
    salary_currency=excluded.salary_currency,
    experience=excluded.experience, employment_type=excluded.employment_type,
    schedule=excluded.schedule, skills=excluded.skills,
    published_at=excluded.published_at, fetched_at=excluded.fetched_at,
    status=excluded.status, raw=excluded.raw
"""


@register_writer
class SqliteWriter(BaseWriter):
    writer_type = "sqlite"

    def __init__(self, target_config):
        super().__init__(target_config)
        self._conn: sqlite3.Connection | None = None

    def _get_conn(self) -> sqlite3.Connection:
        if self._conn is None:
            db_path = Path(self.target_config.params.get("path", "vacancies.db"))
            db_path.parent.mkdir(parents=True, exist_ok=True)
            self._conn = sqlite3.connect(str(db_path))
            self._conn.execute(CREATE_TABLE)
        return self._conn

    async def write(self, vacancies: list[Vacancy]) -> int:
        conn = self._get_conn()
        rows = [self._to_row(v) for v in vacancies]
        conn.executemany(UPSERT, rows)
        conn.commit()
        return len(rows)

    async def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    @staticmethod
    def _to_row(v: Vacancy) -> tuple:
        return (
            v.source,
            v.source_id,
            v.title,
            v.company,
            v.description,
            v.url,
            v.city,
            v.region,
            v.country,
            int(v.is_remote) if v.is_remote is not None else None,
            v.salary.min if v.salary else None,
            v.salary.max if v.salary else None,
            v.salary.currency if v.salary else None,
            v.experience,
            v.employment_type,
            v.schedule,
            json.dumps(v.skills, ensure_ascii=False),
            v.published_at.isoformat() if v.published_at else None,
            v.fetched_at.isoformat() if v.fetched_at else None,
            v.status.value,
            json.dumps(v.raw, ensure_ascii=False, default=str),
        )
