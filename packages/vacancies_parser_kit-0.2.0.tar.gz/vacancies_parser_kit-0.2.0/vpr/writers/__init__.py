"""Writer plugins — import here so @register_writer decorators fire."""

import vpr.writers.jsonl  # noqa: F401
import vpr.writers.sqlite  # noqa: F401

# These require extra deps — import guarded so CLI doesn't break without them
try:
    import vpr.writers.clickhouse  # noqa: F401
except ImportError:
    pass

try:
    import vpr.writers.postgres  # noqa: F401
except ImportError:
    pass
