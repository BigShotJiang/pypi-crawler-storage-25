from vpr.templates.scaffold import render_project_scaffold

__all__ = ["render_project_scaffold"]
