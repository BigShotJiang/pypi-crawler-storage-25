"""Project scaffold templates for `vpr init`."""

from __future__ import annotations

from pathlib import Path

# ------------------------------------------------------------------ #
# vpr_project.yml
# ------------------------------------------------------------------ #

VPR_PROJECT_YML = """\
# vpr project configuration
# Docs: https://github.com/alexeiveselov92/vacancies-parser-kit

name: {project_name}
version: "1.0"

# Профиль по умолчанию (из profiles.yml)
default_profile: dev

# Пути к директориям (относительно корня проекта)
paths:
  sources: sources             # YAML-файлы источников вакансий
  dictionaries: dictionaries   # Справочники (регионы, профессии и т.д.)
"""

# ------------------------------------------------------------------ #
# profiles.yml
# ------------------------------------------------------------------ #

PROFILES_YML = """\
# Профили определяют куда сохранять данные (targets).
# Каждый профиль может содержать несколько targets разных типов.
# Используйте {{{{ env_var('NAME') }}}} для подстановки переменных окружения.

default_profile: dev

profiles:
  dev:
    targets:
      # ── SQLite (локальная БД, без внешних зависимостей) ─────────────
      sqlite_local:
        type: sqlite
        params:
          path: output/vacancies.db     # файл будет создан автоматически

      # ── JSONL (один JSON-объект на строку) ──────────────────────────
      jsonl_local:
        type: jsonl
        params:
          path: output/vacancies.jsonl
          mode: append                  # append | overwrite

      # ── ClickHouse ─────────────────────────────────────────────────
      # clickhouse_local:
      #   type: clickhouse
      #   host: localhost
      #   port: 8123
      #   database: vacancies
      #   user: default
      #   password: ""
      #   params:
      #     table: vacancies            # имя таблицы (создаётся автоматически)

      # ── PostgreSQL ─────────────────────────────────────────────────
      # postgres_local:
      #   type: postgres
      #   host: localhost
      #   port: 5432
      #   database: vacancies
      #   user: postgres
      #   password: ""
      #   params:
      #     table: vacancies

  # ── Production профиль (пример с переменными окружения) ──────────
  # prod:
  #   targets:
  #     clickhouse_prod:
  #       type: clickhouse
  #       host: "{{{{ env_var('CH_HOST') }}}}"
  #       port: 8123
  #       database: vacancies
  #       user: "{{{{ env_var('CH_USER') }}}}"
  #       password: "{{{{ env_var('CH_PASSWORD') }}}}"
  #     postgres_prod:
  #       type: postgres
  #       host: "{{{{ env_var('PG_HOST') }}}}"
  #       port: 5432
  #       database: vacancies
  #       user: "{{{{ env_var('PG_USER') }}}}"
  #       password: "{{{{ env_var('PG_PASSWORD') }}}}"
"""

# ------------------------------------------------------------------ #
# Example sources — one per source type
# ------------------------------------------------------------------ #

EXAMPLE_HH = """\
# ┌─────────────────────────────────────────────────────────────────┐
# │  HeadHunter (hh.ru) — источник вакансий через публичное API    │
# │                                                                 │
# │  Как работает:                                                  │
# │  1. Поиск вакансий через GET /vacancies (краткие карточки)      │
# │  2. Обогащение каждой вакансии через GET /vacancies/{{id}}       │
# │     (полное описание, ключевые навыки, языки)                   │
# │                                                                 │
# │  Ограничения API:                                               │
# │  - Макс. 2000 вакансий на один поисковый запрос                 │
# │    (при превышении автоматически разбивается по датам)           │
# │  - Нужен токен приложения с dev.hh.ru для стабильной работы    │
# │                                                                 │
# │  Документация API: https://github.com/hhru/api                 │
# └─────────────────────────────────────────────────────────────────┘

name: hh_example
type: headhunter
tags: [hh, example]

params:
  # ── Авторизация ─────────────────────────────────────────────────
  # Токен приложения (client_credentials) — получить на https://dev.hh.ru
  # Без токена API работает, но может потребовать CAPTCHA.
  # token: "YOUR_APP_TOKEN"

  # ── Параметры поиска (все опциональны) ──────────────────────────
  search_text: "python developer"   # поисковый запрос (поддерживает синтаксис hh.ru)
  area: 1                           # регион: 1=Москва, 2=СПб, 113=Россия (id из /areas)
  experience: noExperience          # noExperience | between1And3 | between3And6 | moreThan6
  # employment: full                # full | part | project | volunteer | probation
  # schedule: remote                # fullDay | shift | flexible | remote | flyInFlyOut
  # professional_role: 96           # id из /professional_roles
  # industry: 7                     # id из /industries
  # salary: 100000                  # показать вакансии с зарплатой от этого значения
  # currency: RUR                   # валюта зарплаты
  # date_from: "2026-04-01T00:00:00+0300"  # нижняя граница даты публикации
  # date_to: "2026-04-05T00:00:00+0300"    # верхняя граница
  # period: 7                       # последние N дней (нельзя с date_from/date_to)
  # order_by: publication_time      # relevance | publication_time | salary_desc | salary_asc
  # search_field: name              # где искать: name | company_name | description

  # ── Обогащение (pass 2) ────────────────────────────────────────
  # Запрашивать полные данные по каждой вакансии отдельным запросом.
  # Добавляет: description (HTML), key_skills, languages.
  # Без этого — только краткая карточка из поисковой выдачи.
  enrich: true

  # ── Скорость ────────────────────────────────────────────────────
  # Задержка между запросами (секунды). Увеличьте, если получаете 429.
  request_delay: 0.25

# ── Куда сохранять ────────────────────────────────────────────────
# Если не указано — используются все targets из текущего профиля.
# targets:
#   - sqlite_local
#   - jsonl_local
"""

EXAMPLE_TELEGRAM = """\
# ┌─────────────────────────────────────────────────────────────────┐
# │  Telegram — парсинг вакансий из Telegram-каналов                │
# │                                                                 │
# │  Как работает:                                                  │
# │  Подключается к Telegram через API (Telethon), читает           │
# │  сообщения из указанного канала и извлекает информацию          │
# │  о вакансиях из текста сообщений.                               │
# │                                                                 │
# │  Требуется:                                                     │
# │  - api_id и api_hash с https://my.telegram.org                  │
# │  - pip install vacancies-parser-kit[telegram]                   │
# │                                                                 │
# │  ⚠ Источник неструктурированный — данные извлекаются из         │
# │    свободного текста, поэтому часть полей может быть пустой.    │
# └─────────────────────────────────────────────────────────────────┘

name: tg_python_jobs
type: telegram
tags: [telegram, python]
enabled: false                       # включите после настройки api_id/api_hash

params:
  # ── Авторизация Telegram API ────────────────────────────────────
  # Получить на https://my.telegram.org → API development tools
  api_id: 12345678
  api_hash: "your_api_hash_here"

  # ── Канал ───────────────────────────────────────────────────────
  channel: "@python_vacancy"         # username канала или числовой id
  # channel: -1001234567890          # или числовой id приватного канала

  # ── Фильтрация ─────────────────────────────────────────────────
  limit: 100                         # макс. кол-во сообщений для обработки
  # days_back: 7                     # сообщения за последние N дней

  # ── Парсинг текста ──────────────────────────────────────────────
  # Ключевые слова для фильтрации релевантных сообщений
  # keywords: ["python", "django", "fastapi", "backend"]

# targets:
#   - sqlite_local
"""

EXAMPLE_LINKEDIN = """\
# ┌─────────────────────────────────────────────────────────────────┐
# │  LinkedIn — парсинг вакансий с LinkedIn Jobs                    │
# │                                                                 │
# │  Как работает:                                                  │
# │  Парсит публичные страницы вакансий LinkedIn через HTTP.        │
# │  Не требует авторизации для публичных вакансий.                 │
# │                                                                 │
# │  Требуется:                                                     │
# │  - pip install vacancies-parser-kit[linkedin]                   │
# │                                                                 │
# │  ⚠ LinkedIn может ограничивать количество запросов.             │
# │    Используйте request_delay для контроля скорости.             │
# └─────────────────────────────────────────────────────────────────┘

name: linkedin_example
type: linkedin
tags: [linkedin, example]
enabled: false                       # включите после настройки

params:
  # ── Параметры поиска ────────────────────────────────────────────
  keywords: "data engineer"          # поисковый запрос
  location: "Russia"                 # локация
  # remote: true                     # только удалённые вакансии

  # ── Пагинация ──────────────────────────────────────────────────
  limit: 50                          # макс. кол-во вакансий

  # ── Скорость ────────────────────────────────────────────────────
  request_delay: 1.0                 # задержка между запросами (секунды)

# targets:
#   - sqlite_local
"""

# ------------------------------------------------------------------ #
# Generated README
# ------------------------------------------------------------------ #

PROJECT_README = """\
# {project_name}

Проект на базе [vacancies-parser-kit](https://pypi.org/project/vacancies-parser-kit/) — \
инструмент для сбора вакансий с разных площадок.

## Быстрый старт

```bash
# 1. Установите vpr
pip install vacancies-parser-kit[hh]

# 2. Настройте profiles.yml — укажите куда сохранять данные

# 3. Настройте источники в sources/*.yml — раскомментируйте и заполните

# 4. Запустите
vpr run --select hh_example          # один источник по имени
vpr run --select tag:hh              # все источники с тегом
vpr run --select "hh_*"              # по паттерну
```

## Структура проекта

```
{project_name}/
├── vpr_project.yml       # настройки проекта
├── profiles.yml          # куда сохранять (targets): SQLite, JSONL, ClickHouse, Postgres
├── sources/              # источники вакансий (по одному .yml на источник)
│   ├── hh_example.yml        # HeadHunter — пример
│   ├── tg_python_jobs.yml    # Telegram — пример
│   └── linkedin_example.yml  # LinkedIn — пример
└── dictionaries/         # справочники (регионы, профессии)
```

## Основные команды

```bash
vpr list                             # показать все источники
vpr list --tags                      # сгруппировать по тегам
vpr run --select <name>              # запустить один источник
vpr run --select tag:<tag>           # все с тегом
vpr run --select "prefix_*"          # по glob-паттерну
vpr run --select tag:hh --exclude hh_test  # с исключением
vpr run --select hh_example --steps fetch  # только шаг fetch (без записи)
```

## Шаги пайплайна

Каждый запуск проходит три шага (можно запускать выборочно через `--steps`):

1. **fetch** — получение данных из источника (API, парсинг)
2. **transform** — нормализация в единый формат `Vacancy`
3. **write** — запись в target(ы) из профиля

## Полезные ссылки

- [Документация](https://github.com/alexeiveselov92/vacancies-parser-kit)
- [HeadHunter API](https://github.com/hhru/api)
- [PyPI](https://pypi.org/project/vacancies-parser-kit/)
"""


def render_project_scaffold(target: Path, project_name: str) -> None:
    """Create a full project skeleton at *target*."""
    target.mkdir(parents=True)
    (target / "sources").mkdir()
    (target / "dictionaries").mkdir()
    (target / "output").mkdir()

    (target / "vpr_project.yml").write_text(
        VPR_PROJECT_YML.format(project_name=project_name)
    )
    (target / "profiles.yml").write_text(PROFILES_YML)
    (target / "README.md").write_text(
        PROJECT_README.format(project_name=project_name)
    )

    # Example source per type
    (target / "sources" / "hh_example.yml").write_text(EXAMPLE_HH)
    (target / "sources" / "tg_python_jobs.yml").write_text(EXAMPLE_TELEGRAM)
    (target / "sources" / "linkedin_example.yml").write_text(EXAMPLE_LINKEDIN)

    (target / "dictionaries" / ".gitkeep").touch()
    (target / "output" / ".gitkeep").touch()
