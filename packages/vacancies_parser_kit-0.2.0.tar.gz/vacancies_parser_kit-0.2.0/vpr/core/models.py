"""Canonical vacancy model — unified schema all sources map into."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field


class VacancyStatus(str, Enum):
    CREATED = "created"
    UPDATED = "updated"
    DELETED = "deleted"


class Salary(BaseModel):
    min: float | None = None
    max: float | None = None
    currency: str | None = None
    gross: bool | None = None


class Vacancy(BaseModel):
    """Canonical vacancy record.

    Composite identity: (source, source_id).
    All fields except source/source_id are nullable — sources may provide
    incomplete data and that's OK.
    """

    # --- identity ---
    source: str
    source_id: str

    # --- core ---
    title: str | None = None
    company: str | None = None
    description: str | None = None
    url: str | None = None

    # --- location ---
    city: str | None = None
    region: str | None = None
    country: str | None = None
    is_remote: bool | None = None

    # --- compensation ---
    salary: Salary | None = None

    # --- classification ---
    experience: str | None = None
    employment_type: str | None = None  # full-time, part-time, contract …
    schedule: str | None = None  # remote, office, hybrid …
    skills: list[str] = Field(default_factory=list)

    # --- timestamps ---
    published_at: datetime | None = None
    fetched_at: datetime = Field(default_factory=lambda: datetime.now(UTC))

    # --- lifecycle ---
    status: VacancyStatus = VacancyStatus.CREATED

    # --- extra ---
    raw: dict[str, Any] = Field(default_factory=dict)
