"""Source selector: resolve --select / --exclude to a list of SourceConfig."""

from __future__ import annotations

from fnmatch import fnmatch

from vpr.config.source_config import SourceConfig

TAG_PREFIX = "tag:"


def select_sources(
    all_sources: list[SourceConfig],
    selector: str,
    *,
    excludes: set[str] | None = None,
) -> list[SourceConfig]:
    """Return sources matching *selector*, minus *excludes*.

    Selector forms:
      - ``tag:<tag>``       — all sources with given tag
      - ``name_with_*``     — glob match on source name
      - ``exact_name``      — exact match on source name
    """
    excludes = excludes or set()

    if selector.startswith(TAG_PREFIX):
        tag = selector[len(TAG_PREFIX) :]
        matched = [s for s in all_sources if tag in s.tags]
    elif any(ch in selector for ch in ("*", "?", "[")):
        matched = [s for s in all_sources if fnmatch(s.name, selector)]
    else:
        matched = [s for s in all_sources if s.name == selector]

    return [s for s in matched if s.name not in excludes]
