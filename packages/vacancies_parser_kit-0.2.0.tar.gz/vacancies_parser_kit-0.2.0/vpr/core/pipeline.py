"""Pipeline: fetch → transform → write."""

from __future__ import annotations

from rich.console import Console

from vpr.config.profile import ProfileConfig
from vpr.config.source_config import SourceConfig
from vpr.core.models import Vacancy
from vpr.sources.registry import get_source_class
from vpr.writers.registry import get_writer_class

console = Console()


async def run_source_pipeline(
    *,
    source_config: SourceConfig,
    profile: ProfileConfig,
    steps: list[str],
    full_refresh: bool = False,
) -> None:
    """Execute fetch → transform → write for a single source."""
    vacancies: list[Vacancy] = []

    # --- FETCH ---
    if "fetch" in steps:
        console.print("  [dim]fetching…[/dim]")
        source_cls = get_source_class(source_config.type)
        source = source_cls(source_config)
        async for vacancy in source.fetch():
            vacancies.append(vacancy)
        console.print(f"  [dim]fetched {len(vacancies)} vacancies[/dim]")

    # --- TRANSFORM ---
    if "transform" in steps and vacancies:
        console.print("  [dim]transforming…[/dim]")
        from vpr.transforms.normalize import normalize

        vacancies = [normalize(v) for v in vacancies]

    # --- WRITE ---
    if "write" in steps and vacancies:
        targets = source_config.targets
        if not targets:
            targets = list(profile.targets.keys())

        for target_name in targets:
            if target_name not in profile.targets:
                console.print(f"  [yellow]target '{target_name}' not found in profile, skipping[/yellow]")
                continue
            target_cfg = profile.targets[target_name]
            writer_cls = get_writer_class(target_cfg.type)
            writer = writer_cls(target_cfg)
            try:
                count = await writer.write(vacancies)
                console.print(f"  [dim]wrote {count} rows → {target_name}[/dim]")
            finally:
                await writer.close()
