"""Normalisation: clean up and enrich canonical vacancy records."""

from __future__ import annotations

from vpr.core.models import Vacancy


def normalize(vacancy: Vacancy) -> Vacancy:
    """Apply basic normalisation to a vacancy.

    This is a placeholder — per-source transforms can be added
    via a registry or by extending this function.
    """
    if vacancy.title:
        vacancy.title = vacancy.title.strip()
    if vacancy.company:
        vacancy.company = vacancy.company.strip()
    return vacancy
