"""vpr run — fetch, transform, and write vacancies."""

from __future__ import annotations

import asyncio
from typing import TYPE_CHECKING

import click
from rich.console import Console

from vpr.config.project import find_project_root, load_project_config
from vpr.config.profile import load_profiles
from vpr.config.source_config import load_source_configs
from vpr.core.selector import select_sources

if TYPE_CHECKING:
    pass

console = Console()

VALID_STEPS = ("fetch", "transform", "write")


@click.command("run")
@click.option("--select", "selector", required=True, help="Source selector: name, glob pattern, or tag:<tag>")
@click.option("--exclude", "excludes", multiple=True, help="Exclude sources by name")
@click.option("--steps", default=None, help=f"Comma-separated pipeline steps: {', '.join(VALID_STEPS)}")
@click.option("--profile", default=None, help="Override default profile from vpr_project.yml")
@click.option("--full-refresh", is_flag=True, help="Drop existing data and re-fetch from scratch")
def run_cmd(
    selector: str,
    excludes: tuple[str, ...],
    steps: str | None,
    profile: str | None,
    full_refresh: bool,
) -> None:
    """Run the vacancy pipeline for selected sources."""
    active_steps = _parse_steps(steps)

    project_root = find_project_root()
    project_cfg = load_project_config(project_root)
    profiles_cfg = load_profiles(project_root)
    all_sources = load_source_configs(project_root / project_cfg.paths.sources)

    if not all_sources:
        raise click.ClickException(f"No source configs found in {project_cfg.paths.sources}/")

    matched = select_sources(all_sources, selector, excludes=set(excludes))
    if not matched:
        raise click.ClickException(f"No sources matched selector '{selector}'")

    profile_name = profile or project_cfg.default_profile
    if profile_name not in profiles_cfg.profiles:
        raise click.ClickException(f"Profile '{profile_name}' not found in profiles.yml")

    console.print(f"[bold]Profile:[/bold] {profile_name}")
    console.print(f"[bold]Steps:[/bold]  {', '.join(active_steps)}")
    console.print(f"[bold]Sources ({len(matched)}):[/bold]")
    for src in matched:
        console.print(f"  - {src.name} [dim]({src.type})[/dim]")
    console.print()

    asyncio.run(_run_pipeline(matched, profiles_cfg, profile_name, active_steps, full_refresh))


async def _run_pipeline(sources, profiles_cfg, profile_name, steps, full_refresh):
    """Execute the pipeline for each matched source."""
    from vpr.core.pipeline import run_source_pipeline

    profile = profiles_cfg.profiles[profile_name]
    for src_cfg in sources:
        console.print(f"[bold cyan]>>> {src_cfg.name}[/bold cyan]")
        try:
            await run_source_pipeline(
                source_config=src_cfg,
                profile=profile,
                steps=steps,
                full_refresh=full_refresh,
            )
            console.print(f"[green]  ✓ {src_cfg.name} done[/green]")
        except Exception as exc:
            console.print(f"[red]  ✗ {src_cfg.name} failed: {exc}[/red]")


def _parse_steps(raw: str | None) -> list[str]:
    if raw is None:
        return list(VALID_STEPS)
    parts = [s.strip() for s in raw.split(",")]
    for s in parts:
        if s not in VALID_STEPS:
            raise click.ClickException(f"Unknown step '{s}'. Valid: {', '.join(VALID_STEPS)}")
    return parts
