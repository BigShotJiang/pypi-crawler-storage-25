"""vpr list — show all configured sources."""

from __future__ import annotations

import click
from rich.console import Console
from rich.table import Table

from vpr.config.project import find_project_root, load_project_config
from vpr.config.source_config import load_source_configs

console = Console()


@click.command("list")
@click.option("--tags", is_flag=True, help="Group sources by tag")
def list_cmd(tags: bool) -> None:
    """List all configured sources."""
    project_root = find_project_root()
    project_cfg = load_project_config(project_root)
    sources = load_source_configs(project_root / project_cfg.paths.sources)

    if not sources:
        console.print("[yellow]No sources found.[/yellow]")
        return

    if tags:
        _print_by_tags(sources)
    else:
        _print_table(sources)


def _print_table(sources) -> None:
    table = Table(title="Sources")
    table.add_column("Name", style="cyan")
    table.add_column("Type", style="green")
    table.add_column("Tags")
    table.add_column("Targets")

    for src in sorted(sources, key=lambda s: s.name):
        table.add_row(
            src.name,
            src.type,
            ", ".join(src.tags),
            ", ".join(src.targets) if src.targets else "—",
        )
    console.print(table)


def _print_by_tags(sources) -> None:
    tag_map: dict[str, list[str]] = {}
    for src in sources:
        for tag in src.tags:
            tag_map.setdefault(tag, []).append(src.name)

    for tag in sorted(tag_map):
        console.print(f"[bold]tag:{tag}[/bold]")
        for name in sorted(tag_map[tag]):
            console.print(f"  - {name}")
