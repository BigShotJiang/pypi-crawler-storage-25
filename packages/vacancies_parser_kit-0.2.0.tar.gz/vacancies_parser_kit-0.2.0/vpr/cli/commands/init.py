"""vpr init — scaffold a new project."""

from __future__ import annotations

from pathlib import Path

import click
from rich.console import Console

from vpr.templates import render_project_scaffold

console = Console()


@click.command("init")
@click.argument("project_name")
def init_cmd(project_name: str) -> None:
    """Create a new vpr project."""
    target = Path.cwd() / project_name
    if target.exists():
        raise click.ClickException(f"Directory '{project_name}' already exists")

    render_project_scaffold(target, project_name)
    console.print(f"[green]Project '{project_name}' created at {target}[/green]")
    console.print("Next steps:")
    console.print(f"  cd {project_name}")
    console.print("  # edit profiles.yml with your database credentials")
    console.print("  # add source definitions to sources/")
    console.print("  vpr run --select <source_name>")
