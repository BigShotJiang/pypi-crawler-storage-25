"""CLI entry point for vpr."""

import click

from vpr import __version__
from vpr.cli.commands.init import init_cmd
from vpr.cli.commands.list import list_cmd
from vpr.cli.commands.run import run_cmd


@click.group()
@click.version_option(version=__version__, prog_name="vpr")
def cli():
    """vpr — multi-source vacancy parser."""


cli.add_command(init_cmd, "init")
cli.add_command(run_cmd, "run")
cli.add_command(list_cmd, "list")
