"""Remotive vacancy source.

Open API, no authentication required. Rate limit: 2 req/min.
Covers global remote positions across tech categories.
Documentation: https://remotive.com/api/remote-jobs
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, AsyncIterator

import httpx

from vpr.config.source_config import SourceConfig
from vpr.core.models import Vacancy, VacancyStatus
from vpr.sources.base import BaseSource
from vpr.sources.registry import register_source

logger = logging.getLogger(__name__)

REMOTIVE_API_BASE = "https://remotive.com"


@register_source
class RemotiveSource(BaseSource):
    source_type = "remotive"

    def __init__(self, config: SourceConfig) -> None:
        super().__init__(config)
        self._category: str | None = self.params.get("category")
        self._search: str | None = self.params.get("search")
        self._limit: int | None = self.params.get("limit")

    # ------------------------------------------------------------------ #
    # public interface
    # ------------------------------------------------------------------ #

    async def fetch(self) -> AsyncIterator[Vacancy]:
        async with self._make_client() as client:
            data = await self._fetch_jobs(client)
            if data is None:
                return

            for item in data.get("jobs") or []:
                yield self._to_vacancy(item)

    # ------------------------------------------------------------------ #
    # http
    # ------------------------------------------------------------------ #

    async def _fetch_jobs(self, client: httpx.AsyncClient) -> dict[str, Any] | None:
        params: dict[str, Any] = {}
        if self._category:
            params["category"] = self._category
        if self._search:
            params["search"] = self._search
        if self._limit:
            params["limit"] = self._limit

        resp = await client.get("/api/remote-jobs", params=params)
        if resp.status_code != 200:
            logger.error("remotive fetch failed: %d %s", resp.status_code, resp.text[:200])
            return None
        return resp.json()

    def _make_client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=REMOTIVE_API_BASE,
            headers={"Accept": "application/json"},
            timeout=30.0,
        )

    # ------------------------------------------------------------------ #
    # mapping
    # ------------------------------------------------------------------ #

    @staticmethod
    def _to_vacancy(raw: dict[str, Any]) -> Vacancy:
        # tags is a comma-separated string
        tags_raw = raw.get("tags") or ""
        skills = [t.strip() for t in tags_raw.split(",") if t.strip()] if isinstance(tags_raw, str) else list(tags_raw)

        published_at = None
        pub_date = raw.get("publication_date")
        if pub_date:
            try:
                published_at = datetime.fromisoformat(pub_date)
            except (ValueError, TypeError):
                pass

        return Vacancy(
            source="remotive",
            source_id=str(raw["id"]),
            title=raw.get("title"),
            company=raw.get("company_name"),
            description=raw.get("description"),
            url=raw.get("url"),
            region=raw.get("candidate_required_location"),
            is_remote=True,
            skills=skills,
            employment_type=raw.get("job_type"),
            published_at=published_at,
            status=VacancyStatus.CREATED,
            raw=raw,
        )
