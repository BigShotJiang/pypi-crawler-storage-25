"""HeadHunter dictionary/reference data loader.

Fetches and caches /areas, /dictionaries, /professional_roles, /industries
so that source configs can use human-readable names or numeric IDs.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

import httpx

logger = logging.getLogger(__name__)

HH_API_BASE = "https://api.hh.ru"

DICT_ENDPOINTS = {
    "areas": "/areas",
    "dictionaries": "/dictionaries",
    "professional_roles": "/professional_roles",
    "industries": "/industries",
}


async def fetch_dictionaries(
    cache_dir: Path,
    *,
    user_agent: str = "vpr-vacancy-parser/0.1",
    token: str | None = None,
    force: bool = False,
) -> dict[str, Any]:
    """Fetch HH dictionaries and cache them as JSON files.

    Returns a dict keyed by dictionary name.
    """
    cache_dir.mkdir(parents=True, exist_ok=True)
    result: dict[str, Any] = {}

    headers: dict[str, str] = {"HH-User-Agent": user_agent}
    if token:
        headers["Authorization"] = f"Bearer {token}"

    async with httpx.AsyncClient(base_url=HH_API_BASE, headers=headers, timeout=30.0) as client:
        for name, endpoint in DICT_ENDPOINTS.items():
            cache_path = cache_dir / f"{name}.json"

            if cache_path.exists() and not force:
                result[name] = json.loads(cache_path.read_text())
                logger.debug("loaded %s from cache", name)
                continue

            resp = await client.get(endpoint)
            if resp.status_code != 200:
                logger.warning("failed to fetch %s: %d", endpoint, resp.status_code)
                continue

            data = resp.json()
            cache_path.write_text(json.dumps(data, ensure_ascii=False, indent=2))
            result[name] = data
            logger.info("fetched and cached %s (%d bytes)", name, len(resp.content))

    return result


def flatten_areas(areas: list[dict[str, Any]]) -> dict[str, str]:
    """Flatten the hierarchical areas tree into {id: full_name} map.

    Example: {"1": "Москва", "2": "Санкт-Петербург", ...}
    """
    flat: dict[str, str] = {}

    def _walk(nodes: list[dict[str, Any]]) -> None:
        for node in nodes:
            flat[str(node["id"])] = node["name"]
            if node.get("areas"):
                _walk(node["areas"])

    _walk(areas)
    return flat
