"""Jobicy vacancy source.

Open API, no authentication required. Rate limit: 1 req/hour.
Covers global remote positions with salary data.
Documentation: https://jobicy.com/api/v2/remote-jobs

Supported params:
  count    — number of listings to return (1–50, default 50)
  geo      — filter by country/region (e.g. "usa", "uk", "worldwide")
  industry — filter by industry slug
  tag      — filter by job tag/skill
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, AsyncIterator

import httpx

from vpr.config.source_config import SourceConfig
from vpr.core.models import Salary, Vacancy, VacancyStatus
from vpr.sources.base import BaseSource
from vpr.sources.registry import register_source

logger = logging.getLogger(__name__)

JOBICY_API_URL = "https://jobicy.com/api/v2/remote-jobs"


@register_source
class JobicySource(BaseSource):
    source_type = "jobicy"

    def __init__(self, config: SourceConfig) -> None:
        super().__init__(config)
        self._count: int = self.params.get("count", 50)
        self._geo: str | None = self.params.get("geo")
        self._industry: str | None = self.params.get("industry")
        self._tag: str | None = self.params.get("tag")

    # ------------------------------------------------------------------ #
    # public interface
    # ------------------------------------------------------------------ #

    async def fetch(self) -> AsyncIterator[Vacancy]:
        async with self._make_client() as client:
            data = await self._fetch_jobs(client)
            if data is None:
                return

            for item in data.get("jobs") or []:
                yield self._to_vacancy(item)

    # ------------------------------------------------------------------ #
    # http
    # ------------------------------------------------------------------ #

    async def _fetch_jobs(self, client: httpx.AsyncClient) -> dict[str, Any] | None:
        params: dict[str, Any] = {"count": self._count}
        if self._geo:
            params["geo"] = self._geo
        if self._industry:
            params["industry"] = self._industry
        if self._tag:
            params["tag"] = self._tag

        resp = await client.get(JOBICY_API_URL, params=params)
        if resp.status_code != 200:
            logger.error("jobicy fetch failed: %d %s", resp.status_code, resp.text[:200])
            return None
        return resp.json()

    def _make_client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            headers={"Accept": "application/json"},
            timeout=30.0,
        )

    # ------------------------------------------------------------------ #
    # mapping
    # ------------------------------------------------------------------ #

    @staticmethod
    def _to_vacancy(raw: dict[str, Any]) -> Vacancy:
        sal_min = raw.get("annualSalaryMin")
        sal_max = raw.get("annualSalaryMax")
        sal_cur = raw.get("salaryCurrency")
        salary = None
        if sal_min or sal_max:
            salary = Salary(
                min=float(sal_min) if sal_min else None,
                max=float(sal_max) if sal_max else None,
                currency=sal_cur or None,
            )

        published_at = None
        pub_date = raw.get("pubDate")
        if pub_date:
            try:
                published_at = datetime.fromisoformat(pub_date)
            except (ValueError, TypeError):
                pass

        job_type = raw.get("jobType")
        if isinstance(job_type, list):
            employment_type = job_type[0] if job_type else None
        else:
            employment_type = job_type or None

        return Vacancy(
            source="jobicy",
            source_id=str(raw["id"]),
            title=raw.get("jobTitle"),
            company=raw.get("companyName"),
            description=raw.get("jobDescription"),
            url=raw.get("url"),
            country=raw.get("jobGeo"),
            is_remote=True,
            salary=salary,
            employment_type=employment_type,
            published_at=published_at,
            status=VacancyStatus.CREATED,
            raw=raw,
        )
