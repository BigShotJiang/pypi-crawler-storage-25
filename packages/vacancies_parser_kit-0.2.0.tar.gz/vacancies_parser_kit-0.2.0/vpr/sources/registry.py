"""Source plugin registry."""

from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from vpr.sources.base import BaseSource

_REGISTRY: dict[str, type[BaseSource]] = {}


def register_source(cls: type[BaseSource]) -> type[BaseSource]:
    """Class decorator: register a source plugin by its ``source_type``."""
    _REGISTRY[cls.source_type] = cls
    return cls


def get_source_class(source_type: str) -> type[BaseSource]:
    if source_type not in _REGISTRY:
        available = ", ".join(sorted(_REGISTRY)) or "(none)"
        raise KeyError(f"Unknown source type '{source_type}'. Available: {available}")
    return _REGISTRY[source_type]


def available_source_types() -> list[str]:
    return sorted(_REGISTRY)
