"""RemoteOK vacancy source.

Open API, no authentication required.
Returns the full dataset in a single request.
Documentation: https://remoteok.com/api

Note: the first element of the response array is a legal notice object
(no "id" field) and must be skipped.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Any, AsyncIterator

import httpx

from vpr.config.source_config import SourceConfig
from vpr.core.models import Salary, Vacancy, VacancyStatus
from vpr.sources.base import BaseSource
from vpr.sources.registry import register_source

logger = logging.getLogger(__name__)

REMOTEOK_API_URL = "https://remoteok.com/api"


@register_source
class RemoteOKSource(BaseSource):
    source_type = "remoteok"

    def __init__(self, config: SourceConfig) -> None:
        super().__init__(config)

    # ------------------------------------------------------------------ #
    # public interface
    # ------------------------------------------------------------------ #

    async def fetch(self) -> AsyncIterator[Vacancy]:
        async with self._make_client() as client:
            items = await self._fetch_all(client)
            for item in items:
                yield self._to_vacancy(item)

    # ------------------------------------------------------------------ #
    # http
    # ------------------------------------------------------------------ #

    async def _fetch_all(self, client: httpx.AsyncClient) -> list[dict[str, Any]]:
        resp = await client.get(REMOTEOK_API_URL)
        if resp.status_code != 200:
            logger.error("remoteok fetch failed: %d %s", resp.status_code, resp.text[:200])
            return []

        raw_list = resp.json()
        # Skip the first element — it's a legal notice without an "id" field
        return [item for item in raw_list if "id" in item]

    def _make_client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            headers={
                "Accept": "application/json",
                # RemoteOK blocks requests without a User-Agent
                "User-Agent": "vpr-vacancy-parser/0.1 (vacancy analytics)",
            },
            timeout=30.0,
        )

    # ------------------------------------------------------------------ #
    # mapping
    # ------------------------------------------------------------------ #

    @staticmethod
    def _to_vacancy(raw: dict[str, Any]) -> Vacancy:
        salary_min = raw.get("salary_min")
        salary_max = raw.get("salary_max")
        salary = None
        if salary_min or salary_max:
            salary = Salary(
                min=float(salary_min) if salary_min else None,
                max=float(salary_max) if salary_max else None,
                currency="USD",
            )

        published_at = None
        date_raw = raw.get("date")
        if date_raw:
            try:
                published_at = datetime.fromisoformat(date_raw)
            except (ValueError, TypeError):
                pass

        return Vacancy(
            source="remoteok",
            source_id=str(raw["id"]),
            title=raw.get("position"),
            company=raw.get("company"),
            description=raw.get("description"),
            url=raw.get("url"),
            city=raw.get("location") or None,
            is_remote=True,
            salary=salary,
            skills=list(raw.get("tags") or []),
            published_at=published_at,
            status=VacancyStatus.CREATED,
            raw=raw,
        )
