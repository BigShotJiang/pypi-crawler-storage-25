"""Base class for vacancy sources."""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import AsyncIterator

from vpr.config.source_config import SourceConfig
from vpr.core.models import Vacancy


class BaseSource(ABC):
    """Every source plugin extends this class.

    A source receives its YAML-defined ``params`` and yields raw Vacancy
    objects (with at least ``source`` and ``source_id`` filled).
    """

    source_type: str  # must match the ``type`` field in source YAML

    def __init__(self, config: SourceConfig) -> None:
        self.config = config
        self.params = config.params

    @abstractmethod
    async def fetch(self) -> AsyncIterator[Vacancy]:
        """Yield vacancies from the external source."""
        ...  # pragma: no cover
