"""Source plugins — import here so @register_source decorators fire."""

import vpr.sources.arbeitnow  # noqa: F401
import vpr.sources.headhunter  # noqa: F401
import vpr.sources.jobicy  # noqa: F401
import vpr.sources.remoteok  # noqa: F401
import vpr.sources.remotive  # noqa: F401
