"""HeadHunter (hh.ru) vacancy source.

Two-pass fetch strategy:
  1. Search via GET /vacancies — returns short records (no description, key_skills, languages).
     Max 2000 results per query; uses date windowing to handle larger volumes.
  2. Enrich via GET /vacancies/{id} — fetches full vacancy with all fields.
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Any, AsyncIterator

import httpx

from vpr.config.source_config import SourceConfig
from vpr.core.models import Salary, Vacancy, VacancyStatus
from vpr.sources.base import BaseSource
from vpr.sources.registry import register_source

logger = logging.getLogger(__name__)

HH_API_BASE = "https://api.hh.ru"
MAX_RESULTS_DEPTH = 2000
MAX_PER_PAGE = 100
DEFAULT_REQUEST_DELAY = 0.25  # seconds between individual vacancy requests


@register_source
class HeadHunterSource(BaseSource):
    source_type = "headhunter"

    def __init__(self, config: SourceConfig) -> None:
        super().__init__(config)
        self._token: str | None = self.params.get("token")
        self._user_agent: str = self.params.get("user_agent", "vpr-vacancy-parser/0.1 (vacancy analytics)")
        self._request_delay: float = self.params.get("request_delay", DEFAULT_REQUEST_DELAY)
        self._enrich: bool = self.params.get("enrich", True)

    # ------------------------------------------------------------------ #
    # public interface
    # ------------------------------------------------------------------ #

    async def fetch(self) -> AsyncIterator[Vacancy]:
        async with self._make_client() as client:
            # Pass 1: search
            short_items = await self._search_all(client)
            logger.info("search returned %d vacancies", len(short_items))

            for item in short_items:
                # Pass 2: enrich each vacancy with full data
                if self._enrich:
                    full = await self._fetch_full(client, item["id"])
                    if full:
                        item = {**item, **full}
                    await asyncio.sleep(self._request_delay)

                yield self._to_vacancy(item)

    # ------------------------------------------------------------------ #
    # search (pass 1)
    # ------------------------------------------------------------------ #

    async def _search_all(self, client: httpx.AsyncClient) -> list[dict[str, Any]]:
        """Fetch all vacancies matching params, using date windowing if >2000."""
        search_params = self._build_search_params()
        items = await self._search_window(client, search_params)
        return items

    async def _search_window(
        self,
        client: httpx.AsyncClient,
        params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Paginate through search results; split time window if hitting 2000 limit."""
        first_page = await self._search_page(client, params, page=0)
        if first_page is None:
            return []

        found = first_page["found"]
        total_pages = first_page["pages"]
        items = list(first_page["items"])

        # Если больше 2000 — разбиваем окно пополам
        if found > MAX_RESULTS_DEPTH:
            return await self._split_and_search(client, params)

        for page in range(1, total_pages):
            data = await self._search_page(client, params, page=page)
            if data:
                items.extend(data["items"])
            await asyncio.sleep(self._request_delay)

        return items

    async def _split_and_search(
        self,
        client: httpx.AsyncClient,
        params: dict[str, Any],
    ) -> list[dict[str, Any]]:
        """Recursively split time window in half to stay within 2000 limit."""
        date_from = params.get("date_from")
        date_to = params.get("date_to")

        if not date_from or not date_to:
            # Если не задано окно — берём последние 30 дней
            now = datetime.now(tz=timezone.utc)
            date_to = date_to or now.isoformat()
            date_from = date_from or (now - timedelta(days=30)).isoformat()

        dt_from = datetime.fromisoformat(date_from)
        dt_to = datetime.fromisoformat(date_to)
        mid = dt_from + (dt_to - dt_from) / 2

        # Минимальное окно — 1 час; если меньше — просто берём что есть (обрезка)
        if (dt_to - dt_from) < timedelta(hours=1):
            logger.warning("time window too narrow, truncating results")
            return await self._search_window(
                client, {**params, "date_from": date_from, "date_to": date_to}
            )

        left_params = {**params, "date_from": dt_from.isoformat(), "date_to": mid.isoformat()}
        right_params = {**params, "date_from": mid.isoformat(), "date_to": dt_to.isoformat()}

        left = await self._search_window(client, left_params)
        right = await self._search_window(client, right_params)

        # Дедупликация по id
        seen: set[str] = set()
        result: list[dict[str, Any]] = []
        for item in left + right:
            vid = str(item["id"])
            if vid not in seen:
                seen.add(vid)
                result.append(item)
        return result

    async def _search_page(
        self,
        client: httpx.AsyncClient,
        params: dict[str, Any],
        page: int,
    ) -> dict[str, Any] | None:
        qp = {**params, "page": page, "per_page": MAX_PER_PAGE}
        resp = await client.get("/vacancies", params=qp)
        if resp.status_code != 200:
            logger.error("search page %d failed: %d %s", page, resp.status_code, resp.text[:200])
            return None
        return resp.json()

    def _build_search_params(self) -> dict[str, Any]:
        """Map source YAML params to HH API query params."""
        mapping = {
            "search_text": "text",
            "area": "area",
            "experience": "experience",
            "employment": "employment",
            "schedule": "schedule",
            "professional_role": "professional_role",
            "industry": "industry",
            "employer_id": "employer_id",
            "salary": "salary",
            "currency": "currency",
            "label": "label",
            "period": "period",
            "date_from": "date_from",
            "date_to": "date_to",
            "order_by": "order_by",
            "search_field": "search_field",
        }
        result: dict[str, Any] = {}
        for yaml_key, api_key in mapping.items():
            val = self.params.get(yaml_key)
            if val is not None:
                result[api_key] = val
        return result

    # ------------------------------------------------------------------ #
    # enrich (pass 2)
    # ------------------------------------------------------------------ #

    async def _fetch_full(self, client: httpx.AsyncClient, vacancy_id: str) -> dict[str, Any] | None:
        resp = await client.get(f"/vacancies/{vacancy_id}")
        if resp.status_code != 200:
            logger.warning("failed to fetch vacancy %s: %d", vacancy_id, resp.status_code)
            return None
        return resp.json()

    # ------------------------------------------------------------------ #
    # mapping to canonical model
    # ------------------------------------------------------------------ #

    @staticmethod
    def _to_vacancy(raw: dict[str, Any]) -> Vacancy:
        salary_data = raw.get("salary")
        salary = None
        if salary_data:
            salary = Salary(
                min=salary_data.get("from"),
                max=salary_data.get("to"),
                currency=salary_data.get("currency"),
                gross=salary_data.get("gross"),
            )

        area = raw.get("area") or {}
        employer = raw.get("employer") or {}
        schedule = raw.get("schedule") or {}
        experience = raw.get("experience") or {}
        employment = raw.get("employment") or {}

        key_skills = raw.get("key_skills") or []
        skills = [ks["name"] for ks in key_skills if "name" in ks]

        published = raw.get("published_at")
        published_dt = None
        if published:
            try:
                published_dt = datetime.fromisoformat(published)
            except (ValueError, TypeError):
                pass

        return Vacancy(
            source="headhunter",
            source_id=str(raw["id"]),
            title=raw.get("name"),
            company=employer.get("name"),
            description=raw.get("description"),
            url=raw.get("alternate_url"),
            city=area.get("name"),
            salary=salary,
            experience=experience.get("name"),
            employment_type=employment.get("name"),
            schedule=schedule.get("name"),
            skills=skills,
            published_at=published_dt,
            status=VacancyStatus.CREATED,
            raw=raw,
        )

    # ------------------------------------------------------------------ #
    # http client
    # ------------------------------------------------------------------ #

    def _make_client(self) -> httpx.AsyncClient:
        headers: dict[str, str] = {"HH-User-Agent": self._user_agent}
        if self._token:
            headers["Authorization"] = f"Bearer {self._token}"
        return httpx.AsyncClient(
            base_url=HH_API_BASE,
            headers=headers,
            timeout=30.0,
        )
