"""Arbeitnow vacancy source.

Open API, no authentication required.
Covers EU tech/IT vacancies and remote positions.
Documentation: https://www.arbeitnow.com/api/job-board-api
"""

from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import Any, AsyncIterator

import httpx

from vpr.config.source_config import SourceConfig
from vpr.core.models import Vacancy, VacancyStatus
from vpr.sources.base import BaseSource
from vpr.sources.registry import register_source

logger = logging.getLogger(__name__)

ARBEITNOW_API_BASE = "https://www.arbeitnow.com"


@register_source
class ArbeitnowSource(BaseSource):
    source_type = "arbeitnow"

    def __init__(self, config: SourceConfig) -> None:
        super().__init__(config)
        self._request_delay: float = self.params.get("request_delay", 0.5)

    # ------------------------------------------------------------------ #
    # public interface
    # ------------------------------------------------------------------ #

    async def fetch(self) -> AsyncIterator[Vacancy]:
        async with self._make_client() as client:
            page = 1
            while True:
                data = await self._fetch_page(client, page)
                if data is None:
                    break

                items = data.get("data", [])
                if not items:
                    break

                for item in items:
                    yield self._to_vacancy(item)

                meta = data.get("meta", {})
                last_page = meta.get("last_page", 1)
                if page >= last_page:
                    break

                page += 1
                await asyncio.sleep(self._request_delay)

    # ------------------------------------------------------------------ #
    # http
    # ------------------------------------------------------------------ #

    async def _fetch_page(self, client: httpx.AsyncClient, page: int) -> dict[str, Any] | None:
        resp = await client.get("/api/job-board-api", params={"page": page})
        if resp.status_code != 200:
            logger.error("arbeitnow page %d failed: %d %s", page, resp.status_code, resp.text[:200])
            return None
        return resp.json()

    def _make_client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=ARBEITNOW_API_BASE,
            headers={"Accept": "application/json"},
            timeout=30.0,
        )

    # ------------------------------------------------------------------ #
    # mapping
    # ------------------------------------------------------------------ #

    @staticmethod
    def _to_vacancy(raw: dict[str, Any]) -> Vacancy:
        job_types: list[str] = raw.get("job_types") or []
        employment_type = job_types[0] if job_types else None

        published_at = None
        created_at = raw.get("created_at")
        if created_at:
            try:
                # created_at is a Unix timestamp (int)
                published_at = datetime.fromtimestamp(int(created_at), tz=timezone.utc)
            except (ValueError, TypeError, OSError):
                pass

        return Vacancy(
            source="arbeitnow",
            source_id=str(raw["slug"]),
            title=raw.get("title"),
            company=raw.get("company_name"),
            description=raw.get("description"),
            url=raw.get("url"),
            city=raw.get("location"),
            is_remote=raw.get("remote"),
            skills=list(raw.get("tags") or []),
            employment_type=employment_type,
            published_at=published_at,
            status=VacancyStatus.CREATED,
            raw=raw,
        )
