"""Source instance configuration (sources/*.yml)."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, Field


class SourceConfig(BaseModel):
    """A single source instance loaded from YAML."""

    name: str
    type: str
    tags: list[str] = Field(default_factory=list)
    profile: str | None = None
    params: dict[str, Any] = Field(default_factory=dict)
    targets: list[str] = Field(default_factory=list)
    enabled: bool = True

    # metadata — filled at load time
    config_path: Path | None = Field(default=None, exclude=True)


def load_source_config(path: Path) -> SourceConfig:
    with open(path) as f:
        data = yaml.safe_load(f)
    if not data:
        raise ValueError(f"Empty source config: {path}")
    cfg = SourceConfig(**data)
    cfg.config_path = path
    return cfg


def load_source_configs(sources_dir: Path) -> list[SourceConfig]:
    """Load all *.yml files from *sources_dir* recursively."""
    if not sources_dir.is_dir():
        return []
    configs: list[SourceConfig] = []
    for yml_path in sorted(sources_dir.rglob("*.yml")):
        cfg = load_source_config(yml_path)
        if cfg.enabled:
            configs.append(cfg)
    return configs
