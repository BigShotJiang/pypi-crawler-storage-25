"""Project-level configuration (vpr_project.yml)."""

from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel, Field

PROJECT_FILE = "vpr_project.yml"


class ProjectPaths(BaseModel):
    sources: str = "sources"
    dictionaries: str = "dictionaries"


class ProjectConfig(BaseModel):
    name: str
    version: str = "1.0"
    default_profile: str = "dev"
    paths: ProjectPaths = Field(default_factory=ProjectPaths)


def find_project_root(start: Path | None = None) -> Path:
    """Walk up from *start* (default cwd) until vpr_project.yml is found."""
    current = (start or Path.cwd()).resolve()
    for directory in (current, *current.parents):
        if (directory / PROJECT_FILE).is_file():
            return directory
    raise FileNotFoundError(
        f"Could not find {PROJECT_FILE}. "
        "Are you inside a vpr project? Run 'vpr init <name>' to create one."
    )


def load_project_config(project_root: Path) -> ProjectConfig:
    path = project_root / PROJECT_FILE
    with open(path) as f:
        data = yaml.safe_load(f)
    return ProjectConfig(**data)
