"""Profiles configuration (profiles.yml)."""

from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel

_ENV_VAR_RE = re.compile(r"\{\{\s*env_var\(['\"](\w+)['\"]\)\s*\}\}")


class TargetConfig(BaseModel):
    type: str
    params: dict[str, Any] = {}

    model_config = {"extra": "allow"}


class ProfileConfig(BaseModel):
    targets: dict[str, TargetConfig]


class ProfilesConfig(BaseModel):
    default_profile: str = "dev"
    profiles: dict[str, ProfileConfig]


def _resolve_env_vars(obj: Any) -> Any:
    """Recursively resolve {{ env_var('NAME') }} placeholders."""
    if isinstance(obj, str):
        return _ENV_VAR_RE.sub(lambda m: os.environ.get(m.group(1), ""), obj)
    if isinstance(obj, dict):
        return {k: _resolve_env_vars(v) for k, v in obj.items()}
    if isinstance(obj, list):
        return [_resolve_env_vars(v) for v in obj]
    return obj


def load_profiles(project_root: Path) -> ProfilesConfig:
    path = project_root / "profiles.yml"
    if not path.is_file():
        raise FileNotFoundError(f"profiles.yml not found in {project_root}")
    with open(path) as f:
        data = yaml.safe_load(f)
    data = _resolve_env_vars(data)
    return ProfilesConfig(**data)
