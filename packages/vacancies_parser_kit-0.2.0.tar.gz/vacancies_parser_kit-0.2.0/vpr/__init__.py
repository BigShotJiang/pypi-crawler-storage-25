"""vpr — multi-source vacancy parser."""

__version__ = "0.1.0"
