# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project Overview

Multi-source vacancy/job-listing parser. Collects vacancies from heterogeneous sources (Telegram channels, HeadHunter API, LinkedIn, and other job platforms), normalises them into a unified schema, and writes them to pluggable storage backends.

CLI tool: **`vpr`** (vacancy parser). Design follows dbt/detectkit patterns — YAML-based source definitions, profiles, tag-based selection.

## Key Design Decisions

- **Source-agnostic ingestion**: each source is a plugin that yields raw vacancy data. Sources may return unstructured or incomplete data — that's expected and must be handled gracefully (missing fields are nullable, never silently dropped).
- **Source instances in YAML**: each source is defined as a `.yml` file in `sources/`. Same source type (e.g. `headhunter`) can have multiple instances with different params.
- **Unified vacancy model**: all sources map to one canonical `Vacancy` record (`vpr/core/models.py`). Composite identity: `(source, source_id)`. Records support CRUD lifecycle states.
- **Per-source dictionaries**: sources may ship lookup/mapping dictionaries (e.g. HeadHunter area codes → city names) used during normalisation.
- **Pluggable storage**: writers are independent of sources. Targets defined in `profiles.yml`. Primary: ClickHouse, PostgreSQL.
- **No built-in scheduler**: execution via bash/cron/Prefect. CLI supports `--select` and tags for orchestration.

## Architecture

```
vpr/
├── cli/              – Click CLI: vpr init / run / list
│   └── commands/     – one module per command
├── config/           – YAML config loaders (project, profile, source)
├── core/
│   ├── models.py     – canonical Vacancy schema
│   ├── selector.py   – --select / --exclude resolution (name, glob, tag:)
│   └── pipeline.py   – fetch → transform → write orchestration
├── sources/
│   ├── base.py       – BaseSource ABC (async fetch → Vacancy iterator)
│   └── registry.py   – @register_source decorator + lookup
├── transforms/
│   └── normalize.py  – raw → canonical normalisation
├── writers/
│   ├── base.py       – BaseWriter ABC (async write)
│   └── registry.py   – @register_writer decorator + lookup
└── templates/        – scaffold for `vpr init`
```

## Development

```bash
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"       # editable install with dev deps
pip install -e ".[all]"       # all source/writer extras
```

```bash
pytest                        # run all tests
pytest tests/test_selector.py # single test file
pytest -k "test_tag"          # by test name pattern
ruff check vpr/               # lint
ruff format vpr/              # format
```

## CLI Usage

```bash
vpr init <project-name>                    # scaffold a new project
vpr run --select <name|glob|tag:X>         # run pipeline
vpr run --select tag:hh --exclude hh_test  # with exclusion
vpr run --select "tg_*" --steps fetch      # only fetch step
vpr list                                   # table of all sources
vpr list --tags                            # grouped by tag
```

## Adding a New Source

1. Create `vpr/sources/<type>.py`, subclass `BaseSource`, set `source_type = "<type>"`
2. Decorate with `@register_source`
3. Implement `async def fetch(self) -> AsyncIterator[Vacancy]`
4. Import the module in `vpr/sources/__init__.py` so the decorator fires

## Adding a New Writer

1. Create `vpr/writers/<type>.py`, subclass `BaseWriter`, set `writer_type = "<type>"`
2. Decorate with `@register_writer`
3. Implement `async def write(self, vacancies: list[Vacancy]) -> int`
4. Import the module in `vpr/writers/__init__.py`

## Conventions

- All user-facing text and code comments in Russian are acceptable; code identifiers in English.
- Configuration via environment variables / `.env` files (never committed). Use `{{ env_var('NAME') }}` in profiles.yml.
- Each source and writer must be independently testable with a fixture/mock for the external service.
- Pipeline steps: `fetch`, `transform`, `write` — each can run independently via `--steps`.
