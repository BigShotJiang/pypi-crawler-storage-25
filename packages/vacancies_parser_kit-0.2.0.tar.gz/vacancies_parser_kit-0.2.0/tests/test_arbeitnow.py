"""Tests for Arbeitnow source (mocked HTTP)."""

import json
from unittest.mock import AsyncMock, patch

import pytest

from vpr.config.source_config import SourceConfig
from vpr.sources.arbeitnow import ArbeitnowSource


def _make_config(**params) -> SourceConfig:
    return SourceConfig(name="test_arbeitnow", type="arbeitnow", params=params)


def _job(slug: str = "python-dev-acme", title: str = "Python Developer") -> dict:
    return {
        "slug": slug,
        "title": title,
        "company_name": "Acme GmbH",
        "description": "<p>Great opportunity</p>",
        "url": f"https://www.arbeitnow.com/jobs/{slug}",
        "location": "Berlin",
        "remote": True,
        "tags": ["python", "django"],
        "job_types": ["full-time"],
        "created_at": 1712300000,
    }


def _page_response(jobs: list[dict], current: int = 1, last: int = 1) -> dict:
    return {
        "data": jobs,
        "meta": {"current_page": current, "last_page": last},
    }


class FakeResponse:
    def __init__(self, data: dict, status_code: int = 200):
        self._data = data
        self.status_code = status_code
        self.text = json.dumps(data)

    def json(self):
        return self._data


@pytest.mark.asyncio
async def test_fetch_returns_vacancies():
    source = ArbeitnowSource(_make_config(request_delay=0))

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=FakeResponse(_page_response([_job("dev-1"), _job("dev-2")])))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert len(vacancies) == 2
    assert vacancies[0].source == "arbeitnow"
    assert vacancies[0].source_id == "dev-1"
    assert vacancies[0].title == "Python Developer"
    assert vacancies[0].company == "Acme GmbH"
    assert vacancies[0].city == "Berlin"
    assert vacancies[0].is_remote is True
    assert vacancies[0].skills == ["python", "django"]
    assert vacancies[0].employment_type == "full-time"
    assert vacancies[0].published_at is not None


@pytest.mark.asyncio
async def test_fetch_paginates():
    source = ArbeitnowSource(_make_config(request_delay=0))

    page1 = FakeResponse(_page_response([_job("dev-1")], current=1, last=2))
    page2 = FakeResponse(_page_response([_job("dev-2")], current=2, last=2))

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(side_effect=[page1, page2])
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert len(vacancies) == 2
    assert mock_client.get.call_count == 2


@pytest.mark.asyncio
async def test_empty_response():
    source = ArbeitnowSource(_make_config())

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=FakeResponse({"data": [], "meta": {"current_page": 1, "last_page": 1}}))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert vacancies == []


def test_vacancy_mapping():
    v = ArbeitnowSource._to_vacancy(_job("slug-42"))
    assert v.source == "arbeitnow"
    assert v.source_id == "slug-42"
    assert v.title == "Python Developer"
    assert v.company == "Acme GmbH"
    assert v.description == "<p>Great opportunity</p>"
    assert v.url == "https://www.arbeitnow.com/jobs/slug-42"
    assert v.is_remote is True
    assert "python" in v.skills
    assert v.employment_type == "full-time"
    assert v.salary is None
    assert v.raw["slug"] == "slug-42"
