"""Tests for HeadHunter source (mocked HTTP)."""

import json
from unittest.mock import AsyncMock, patch

import pytest

from vpr.config.source_config import SourceConfig
from vpr.sources.headhunter import HeadHunterSource


def _make_config(**params) -> SourceConfig:
    return SourceConfig(name="test_hh", type="headhunter", params=params)


def _vacancy_json(vid: str, name: str = "Python Dev") -> dict:
    return {
        "id": vid,
        "name": name,
        "employer": {"name": "TestCorp"},
        "area": {"id": "1", "name": "Москва"},
        "salary": {"from": 100000, "to": 200000, "currency": "RUR", "gross": False},
        "experience": {"id": "between1And3", "name": "1–3 года"},
        "employment": {"id": "full", "name": "Полная занятость"},
        "schedule": {"id": "remote", "name": "Удалённая работа"},
        "published_at": "2026-04-05T10:00:00+0300",
        "alternate_url": "https://hh.ru/vacancy/12345",
    }


def _full_vacancy_json(vid: str) -> dict:
    base = _vacancy_json(vid)
    base["description"] = "<p>We need a Python developer</p>"
    base["key_skills"] = [{"name": "Python"}, {"name": "FastAPI"}]
    return base


def _search_response(items: list[dict], found: int | None = None) -> dict:
    return {
        "found": found or len(items),
        "pages": 1,
        "per_page": 100,
        "page": 0,
        "items": items,
    }


class FakeResponse:
    def __init__(self, data: dict, status_code: int = 200):
        self._data = data
        self.status_code = status_code
        self.text = json.dumps(data)
        self.content = self.text.encode()

    def json(self):
        return self._data


@pytest.mark.asyncio
async def test_fetch_with_enrich():
    """Two-pass: search + enrich each vacancy."""
    config = _make_config(search_text="python", enrich=True, request_delay=0)
    source = HeadHunterSource(config)

    search_resp = FakeResponse(_search_response([_vacancy_json("1"), _vacancy_json("2")]))
    full_1 = FakeResponse(_full_vacancy_json("1"))
    full_2 = FakeResponse(_full_vacancy_json("2"))

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(side_effect=[search_resp, full_1, full_2])
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert len(vacancies) == 2
    assert vacancies[0].source == "headhunter"
    assert vacancies[0].source_id == "1"
    assert vacancies[0].description == "<p>We need a Python developer</p>"
    assert vacancies[0].skills == ["Python", "FastAPI"]
    assert vacancies[0].salary.min == 100000
    assert vacancies[0].salary.currency == "RUR"
    assert vacancies[0].city == "Москва"


@pytest.mark.asyncio
async def test_fetch_without_enrich():
    """Single pass: search only, no description/skills."""
    config = _make_config(search_text="python", enrich=False, request_delay=0)
    source = HeadHunterSource(config)

    search_resp = FakeResponse(_search_response([_vacancy_json("1")]))

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=search_resp)
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert len(vacancies) == 1
    assert vacancies[0].description is None
    assert vacancies[0].skills == []


@pytest.mark.asyncio
async def test_vacancy_mapping():
    """Check all canonical fields are correctly mapped."""
    v = HeadHunterSource._to_vacancy(_full_vacancy_json("42"))
    assert v.source == "headhunter"
    assert v.source_id == "42"
    assert v.title == "Python Dev"
    assert v.company == "TestCorp"
    assert v.experience == "1–3 года"
    assert v.employment_type == "Полная занятость"
    assert v.schedule == "Удалённая работа"
    assert v.url == "https://hh.ru/vacancy/12345"
    assert "Python" in v.skills
    assert v.raw["id"] == "42"
