"""Tests for RemoteOK source (mocked HTTP)."""

import json
from unittest.mock import AsyncMock, patch

import pytest

from vpr.config.source_config import SourceConfig
from vpr.sources.remoteok import RemoteOKSource


def _make_config(**params) -> SourceConfig:
    return SourceConfig(name="test_remoteok", type="remoteok", params=params)


# RemoteOK prepends a legal notice as the first element (no "id")
_LEGAL_NOTICE = {"legal": "This data is for personal use only."}


def _job(job_id: str = "123456", position: str = "Data Engineer") -> dict:
    return {
        "id": job_id,
        "position": position,
        "company": "StreamCorp",
        "description": "<p>Build pipelines</p>",
        "url": f"https://remoteok.com/remote-jobs/{job_id}",
        "location": "Worldwide",
        "tags": ["python", "spark", "kafka"],
        "date": "2026-04-05T08:00:00Z",
        "salary_min": 90000,
        "salary_max": 130000,
    }


class FakeResponse:
    def __init__(self, data: list, status_code: int = 200):
        self._data = data
        self.status_code = status_code
        self.text = json.dumps(data)

    def json(self):
        return self._data


@pytest.mark.asyncio
async def test_fetch_returns_vacancies():
    source = RemoteOKSource(_make_config())

    api_response = [_LEGAL_NOTICE, _job("1"), _job("2")]
    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=FakeResponse(api_response))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert len(vacancies) == 2
    assert vacancies[0].source == "remoteok"
    assert vacancies[0].source_id == "1"
    assert vacancies[0].title == "Data Engineer"
    assert vacancies[0].company == "StreamCorp"
    assert vacancies[0].is_remote is True
    assert vacancies[0].skills == ["python", "spark", "kafka"]
    assert vacancies[0].published_at is not None


@pytest.mark.asyncio
async def test_salary_mapping():
    source = RemoteOKSource(_make_config())

    api_response = [_LEGAL_NOTICE, _job("99")]
    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=FakeResponse(api_response))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert vacancies[0].salary is not None
    assert vacancies[0].salary.min == 90000.0
    assert vacancies[0].salary.max == 130000.0
    assert vacancies[0].salary.currency == "USD"


@pytest.mark.asyncio
async def test_legal_notice_skipped():
    """First element (legal notice without 'id') must be silently skipped."""
    source = RemoteOKSource(_make_config())

    api_response = [_LEGAL_NOTICE]  # only the notice, no actual jobs
    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=FakeResponse(api_response))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert vacancies == []


def test_vacancy_mapping():
    v = RemoteOKSource._to_vacancy(_job("77", "Backend Engineer"))
    assert v.source == "remoteok"
    assert v.source_id == "77"
    assert v.title == "Backend Engineer"
    assert v.company == "StreamCorp"
    assert v.salary.min == 90000.0
    assert v.salary.currency == "USD"
    assert v.raw["id"] == "77"
