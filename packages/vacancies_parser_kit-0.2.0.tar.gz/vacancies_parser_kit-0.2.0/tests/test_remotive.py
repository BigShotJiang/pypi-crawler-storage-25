"""Tests for Remotive source (mocked HTTP)."""

import json
from unittest.mock import AsyncMock, patch

import pytest

from vpr.config.source_config import SourceConfig
from vpr.sources.remotive import RemotiveSource


def _make_config(**params) -> SourceConfig:
    return SourceConfig(name="test_remotive", type="remotive", params=params)


def _job(job_id: int = 1, title: str = "Data Analyst") -> dict:
    return {
        "id": job_id,
        "title": title,
        "company_name": "DataCo",
        "description": "<p>Analyse data</p>",
        "url": f"https://remotive.com/remote-jobs/data/{job_id}",
        "candidate_required_location": "Worldwide",
        "salary": "80k-120k USD",
        "tags": "sql, python, tableau",
        "job_type": "full_time",
        "publication_date": "2026-04-01T12:00:00",
        "category": "Data",
    }


def _jobs_response(jobs: list[dict]) -> dict:
    return {"jobs": jobs, "job-count": len(jobs)}


class FakeResponse:
    def __init__(self, data: dict, status_code: int = 200):
        self._data = data
        self.status_code = status_code
        self.text = json.dumps(data)

    def json(self):
        return self._data


@pytest.mark.asyncio
async def test_fetch_returns_vacancies():
    source = RemotiveSource(_make_config())

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=FakeResponse(_jobs_response([_job(1), _job(2)])))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert len(vacancies) == 2
    assert vacancies[0].source == "remotive"
    assert vacancies[0].source_id == "1"
    assert vacancies[0].title == "Data Analyst"
    assert vacancies[0].company == "DataCo"
    assert vacancies[0].is_remote is True
    assert vacancies[0].region == "Worldwide"
    assert vacancies[0].skills == ["sql", "python", "tableau"]
    assert vacancies[0].employment_type == "full_time"
    assert vacancies[0].published_at is not None
    # salary string goes to raw only, not parsed into Salary model
    assert vacancies[0].salary is None
    assert vacancies[0].raw["salary"] == "80k-120k USD"


@pytest.mark.asyncio
async def test_params_passed_to_api():
    source = RemotiveSource(_make_config(category="data", search="analyst", limit=10))

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=FakeResponse(_jobs_response([])))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        _ = [v async for v in source.fetch()]

    call_kwargs = mock_client.get.call_args
    params = call_kwargs.kwargs.get("params", {})
    assert params.get("category") == "data"
    assert params.get("search") == "analyst"
    assert params.get("limit") == 10


@pytest.mark.asyncio
async def test_empty_response():
    source = RemotiveSource(_make_config())

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=FakeResponse({"jobs": []}))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert vacancies == []


def test_vacancy_mapping():
    v = RemotiveSource._to_vacancy(_job(42, "ML Engineer"))
    assert v.source == "remotive"
    assert v.source_id == "42"
    assert v.title == "ML Engineer"
    assert v.skills == ["sql", "python", "tableau"]
    assert v.salary is None
