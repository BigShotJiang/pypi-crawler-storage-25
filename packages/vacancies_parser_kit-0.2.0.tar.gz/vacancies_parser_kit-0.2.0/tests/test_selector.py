"""Tests for source selector logic."""

from vpr.config.source_config import SourceConfig
from vpr.core.selector import select_sources


def _make(name: str, tags: list[str] | None = None) -> SourceConfig:
    return SourceConfig(name=name, type="test", tags=tags or [])


SOURCES = [
    _make("hh_backend", ["hh", "backend"]),
    _make("hh_frontend", ["hh", "frontend"]),
    _make("tg_python_jobs", ["telegram", "python"]),
    _make("tg_devops_jobs", ["telegram", "devops"]),
    _make("linkedin_eu", ["linkedin"]),
]


def test_select_by_exact_name():
    result = select_sources(SOURCES, "hh_backend")
    assert [s.name for s in result] == ["hh_backend"]


def test_select_by_glob():
    result = select_sources(SOURCES, "hh_*")
    assert sorted(s.name for s in result) == ["hh_backend", "hh_frontend"]


def test_select_by_tag():
    result = select_sources(SOURCES, "tag:telegram")
    assert sorted(s.name for s in result) == ["tg_devops_jobs", "tg_python_jobs"]


def test_select_all_glob():
    result = select_sources(SOURCES, "*")
    assert len(result) == 5


def test_exclude():
    result = select_sources(SOURCES, "tag:hh", excludes={"hh_frontend"})
    assert [s.name for s in result] == ["hh_backend"]


def test_no_match():
    result = select_sources(SOURCES, "nonexistent")
    assert result == []


def test_exclude_all():
    result = select_sources(SOURCES, "tag:hh", excludes={"hh_backend", "hh_frontend"})
    assert result == []
