"""Tests for Jobicy source (mocked HTTP)."""

import json
from unittest.mock import AsyncMock, patch

import pytest

from vpr.config.source_config import SourceConfig
from vpr.sources.jobicy import JobicySource


def _make_config(**params) -> SourceConfig:
    return SourceConfig(name="test_jobicy", type="jobicy", params=params)


def _job(job_id: str = "j1", title: str = "Analytics Engineer") -> dict:
    return {
        "id": job_id,
        "jobTitle": title,
        "companyName": "DataFlow Inc",
        "jobDescription": "<p>Build dbt models</p>",
        "url": f"https://jobicy.com/jobs/{job_id}",
        "jobGeo": "worldwide",
        "jobType": ["full-time"],
        "jobIndustry": "Data & Analytics",
        "annualSalaryMin": 70000,
        "annualSalaryMax": 110000,
        "salaryCurrency": "USD",
        "pubDate": "2026-04-03T10:00:00+00:00",
    }


def _jobs_response(jobs: list[dict]) -> dict:
    return {"jobs": jobs, "apiVersion": "2", "documentationUrl": "https://jobicy.com/api"}


class FakeResponse:
    def __init__(self, data: dict, status_code: int = 200):
        self._data = data
        self.status_code = status_code
        self.text = json.dumps(data)

    def json(self):
        return self._data


@pytest.mark.asyncio
async def test_fetch_returns_vacancies():
    source = JobicySource(_make_config())

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=FakeResponse(_jobs_response([_job("j1"), _job("j2")])))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert len(vacancies) == 2
    assert vacancies[0].source == "jobicy"
    assert vacancies[0].source_id == "j1"
    assert vacancies[0].title == "Analytics Engineer"
    assert vacancies[0].company == "DataFlow Inc"
    assert vacancies[0].country == "worldwide"
    assert vacancies[0].is_remote is True
    assert vacancies[0].employment_type == "full-time"
    assert vacancies[0].published_at is not None


@pytest.mark.asyncio
async def test_salary_mapping():
    source = JobicySource(_make_config())

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=FakeResponse(_jobs_response([_job("j99")])))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert vacancies[0].salary is not None
    assert vacancies[0].salary.min == 70000.0
    assert vacancies[0].salary.max == 110000.0
    assert vacancies[0].salary.currency == "USD"


@pytest.mark.asyncio
async def test_params_passed_to_api():
    source = JobicySource(_make_config(count=10, geo="uk", industry="data", tag="python"))

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=FakeResponse(_jobs_response([])))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        _ = [v async for v in source.fetch()]

    call_kwargs = mock_client.get.call_args
    params = call_kwargs.kwargs.get("params", {})
    assert params.get("count") == 10
    assert params.get("geo") == "uk"
    assert params.get("industry") == "data"
    assert params.get("tag") == "python"


@pytest.mark.asyncio
async def test_empty_response():
    source = JobicySource(_make_config())

    mock_client = AsyncMock()
    mock_client.get = AsyncMock(return_value=FakeResponse({"jobs": []}))
    mock_client.__aenter__ = AsyncMock(return_value=mock_client)
    mock_client.__aexit__ = AsyncMock(return_value=False)

    with patch.object(source, "_make_client", return_value=mock_client):
        vacancies = [v async for v in source.fetch()]

    assert vacancies == []


def test_vacancy_mapping():
    v = JobicySource._to_vacancy(_job("x1", "Data Scientist"))
    assert v.source == "jobicy"
    assert v.source_id == "x1"
    assert v.title == "Data Scientist"
    assert v.salary.min == 70000.0
    assert v.salary.currency == "USD"
    assert v.raw["id"] == "x1"
