# CLI справочник

## vpr init

Создать новый проект.

```bash
vpr init <project-name>
```

Создаёт директорию с готовой структурой: `vpr_project.yml`, `profiles.yml`, примеры источников для каждого типа, `README.md`.

## vpr run

Запустить пайплайн для выбранных источников.

```bash
vpr run --select <selector> [OPTIONS]
```

### Selector

| Формат | Пример | Описание |
|--------|--------|----------|
| Имя | `--select hh_backend` | Точное совпадение по `name` |
| Glob | `--select "hh_*"` | Паттерн с подстановочными символами |
| Тег | `--select tag:telegram` | Все источники с тегом |

### Опции

| Опция | Описание |
|-------|----------|
| `--select` | **(обязательно)** Селектор источников |
| `--exclude NAME` | Исключить источник по имени (можно несколько раз) |
| `--steps fetch,transform,write` | Выполнить только указанные шаги |
| `--profile NAME` | Переопределить профиль |
| `--full-refresh` | Удалить существующие данные и пересобрать |

### Примеры

```bash
# Один источник
vpr run --select hh_backend

# Все источники с тегом
vpr run --select tag:hh

# Паттерн
vpr run --select "tg_*"

# С исключением
vpr run --select tag:hh --exclude hh_test

# Только fetch (без записи)
vpr run --select hh_backend --steps fetch

# Fetch + transform (посмотреть что получится, без записи)
vpr run --select hh_backend --steps fetch,transform

# Другой профиль
vpr run --select tag:daily --profile prod
```

## vpr list

Показать все настроенные источники.

```bash
vpr list [OPTIONS]
```

| Опция | Описание |
|-------|----------|
| `--tags` | Группировать по тегам |

### Примеры

```bash
# Таблица всех источников
vpr list

# Группировка по тегам
vpr list --tags
```

## Общие опции

```bash
vpr --version    # показать версию
vpr --help       # справка
vpr run --help   # справка по команде
```
