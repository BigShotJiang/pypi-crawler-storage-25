# Установка

## Из PyPI

```bash
# Базовая установка (SQLite + JSONL из коробки)
pip install vacancies-parser-kit

# С поддержкой HeadHunter
pip install vacancies-parser-kit[hh]

# С поддержкой Telegram
pip install vacancies-parser-kit[telegram]

# Все источники + все хранилища
pip install vacancies-parser-kit[all]

# Для разработки
pip install vacancies-parser-kit[dev]
```

## Из исходников

```bash
git clone https://github.com/alexeiveselov92/vacancies-parser-kit.git
cd vacancies-parser-kit
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"
```

## Проверка установки

```bash
vpr --version
# vpr, version 0.1.0
```

## Зависимости по extras

| Extra | Пакеты | Для чего |
|-------|--------|----------|
| `hh` | httpx | HeadHunter API |
| `telegram` | telethon | Telegram каналы |
| `linkedin` | httpx | LinkedIn Jobs |
| `clickhouse` | clickhouse-connect | ClickHouse writer |
| `postgres` | asyncpg, psycopg | PostgreSQL writer |
| `all` | все вышеперечисленное | полная установка |
| `dev` | pytest, ruff | разработка и тесты |
