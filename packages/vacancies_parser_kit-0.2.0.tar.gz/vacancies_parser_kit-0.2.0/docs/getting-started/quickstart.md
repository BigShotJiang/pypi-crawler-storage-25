# Быстрый старт

Первый запуск за 5 минут: собираем вакансии с HeadHunter в локальную базу.

## Шаг 1. Установка

```bash
pip install vacancies-parser-kit[hh]
```

## Шаг 2. Создание проекта

```bash
vpr init my_vacancies
cd my_vacancies
```

Будет создана структура:

```
my_vacancies/
├── vpr_project.yml           # настройки проекта
├── profiles.yml              # куда сохранять данные
├── README.md                 # описание проекта
├── sources/
│   ├── hh_example.yml        # пример: HeadHunter
│   ├── tg_python_jobs.yml    # пример: Telegram (отключен)
│   └── linkedin_example.yml  # пример: LinkedIn (отключен)
├── dictionaries/
└── output/
```

## Шаг 3. Настройка источника

Отредактируйте `sources/hh_example.yml` — измените `search_text` и `area` под свои нужды:

```yaml
name: hh_example
type: headhunter
tags: [hh, example]

params:
  search_text: "data analyst"
  area: 113            # 113 = Россия, 1 = Москва, 2 = СПб
  schedule: remote
  period: 3            # последние 3 дня
  enrich: true         # получать полное описание и навыки
  request_delay: 0.25
```

## Шаг 4. Проверка

```bash
vpr list
```

```
┏━━━━━━━━━━━━┳━━━━━━━━━━━━┳━━━━━━━━━━━━━┳━━━━━━━━━┓
┃ Name       ┃ Type       ┃ Tags        ┃ Targets ┃
┡━━━━━━━━━━━━╇━━━━━━━━━━━━╇━━━━━━━━━━━━━╇━━━━━━━━━┩
│ hh_example │ headhunter │ hh, example │ —       │
└────────────┴────────────┴─────────────┴─────────┘
```

## Шаг 5. Запуск

```bash
vpr run --select hh_example
```

```
Profile: dev
Steps:  fetch, transform, write
Sources (1):
  - hh_example (headhunter)

>>> hh_example
  fetching…
  fetched 110 vacancies
  transforming…
  wrote 110 rows → sqlite_local
  wrote 110 rows → jsonl_local
  ✓ hh_example done
```

## Шаг 6. Результат

Данные сохранены в `output/`:

**SQLite** — можно открыть любым SQL-клиентом:

```bash
sqlite3 output/vacancies.db "SELECT title, company, city, salary_min, salary_max FROM vacancies LIMIT 5"
```

**JSONL** — по одному JSON-объекту на строку:

```bash
head -1 output/vacancies.jsonl | python3 -m json.tool
```

## Шаг 7. Добавление источников

Создайте новый YAML в `sources/`:

```yaml
# sources/hh_backend_spb.yml
name: hh_backend_spb
type: headhunter
tags: [hh, backend, daily]

params:
  search_text: "backend developer"
  area: 2               # Санкт-Петербург
  experience: between1And3
  enrich: true
  request_delay: 0.25
```

Запустите все HH-источники разом:

```bash
vpr run --select tag:hh
```

## Что дальше

- [Конфигурация](../guides/configuration.md) — все параметры profiles.yml и source YAML
- [Источники](../guides/sources.md) — HeadHunter, Telegram, LinkedIn
- [Хранилища](../guides/writers.md) — подключение ClickHouse, PostgreSQL
- [CLI](../reference/cli.md) — полный справочник команд
