# Источники вакансий

## HeadHunter (hh.ru)

**Тип:** `headhunter`  
**Extra:** `pip install vacancies-parser-kit[hh]`  
**API:** https://github.com/hhru/api

### Как работает

Двухпроходная стратегия:

1. **Поиск** (`GET /vacancies`) — массовая выгрузка кратких карточек. Макс. 2000 результатов на запрос; при превышении автоматически разбивает временное окно.
2. **Обогащение** (`GET /vacancies/{id}`) — для каждой вакансии запрашивает полные данные: `description` (HTML), `key_skills`, `languages`.

### Параметры

```yaml
params:
  # Авторизация
  token: "..."                  # app-токен с dev.hh.ru (опционально)

  # Поиск
  search_text: "python"         # поисковый запрос
  area: 1                       # регион (1=Москва, 2=СПб, 113=Россия)
  experience: between1And3      # noExperience | between1And3 | between3And6 | moreThan6
  employment: full              # full | part | project | volunteer | probation
  schedule: remote              # fullDay | shift | flexible | remote | flyInFlyOut
  professional_role: 96         # id из /professional_roles
  industry: 7                   # id из /industries
  salary: 100000                # мин. зарплата
  currency: RUR                 # валюта
  date_from: "2026-04-01T00:00:00+0300"
  date_to: "2026-04-05T00:00:00+0300"
  period: 7                     # последние N дней (нельзя с date_from/date_to)
  order_by: publication_time    # relevance | publication_time | salary_desc | salary_asc
  search_field: name            # name | company_name | description

  # Обогащение
  enrich: true                  # true — полные данные, false — только карточки
  request_delay: 0.25           # задержка между запросами (секунды)
```

### Поля без обогащения vs с обогащением

| Поле | Без enrich | С enrich |
|------|-----------|----------|
| title, company, city | ✓ | ✓ |
| salary, experience | ✓ | ✓ |
| description (HTML) | ✗ | ✓ |
| key_skills | ✗ | ✓ |
| languages | ✗ | ✓ |

### Справочники HH

Для маппинга ID → имена используйте модуль `hh_dictionaries`:

- `/areas` — дерево регионов (id → название)
- `/dictionaries` — experience, employment, schedule и др.
- `/professional_roles` — профессиональные роли
- `/industries` — отрасли

### Ограничения

- Макс. 2000 вакансий на один поисковый запрос → используйте `date_from`/`date_to` или `period`
- `per_page` макс. 100 (управляется автоматически)
- Без токена могут появляться CAPTCHA

---

## Arbeitnow

**Тип:** `arbeitnow`  
**Extra:** `pip install vacancies-parser-kit[arbeitnow]`  
**API:** https://www.arbeitnow.com/api/job-board-api  
**Авторизация:** не требуется  
**Покрытие:** Европа (DE-фокус) + remote tech-вакансии

### Как работает

Один запрос возвращает до 100 вакансий, пагинация по `meta.last_page`. Поддерживает теги, тип занятости, remote-флаг. Нет фильтрации через API — все фильтры только на стороне клиента.

### Параметры

```yaml
params:
  request_delay: 0.5  # задержка между страницами (секунды)
```

### Маппинг полей

| Поле Vacancy | Поле API |
|---|---|
| `source_id` | `slug` |
| `title` | `title` |
| `company` | `company_name` |
| `description` | `description` (HTML) |
| `url` | `url` |
| `city` | `location` |
| `is_remote` | `remote` (bool) |
| `skills` | `tags` (list) |
| `employment_type` | `job_types[0]` |
| `published_at` | `created_at` (Unix timestamp) |
| `salary` | — отсутствует в API |

### Ограничения

- API не поддерживает фильтрацию по ключевым словам или региону — возвращает весь каталог
- Данные по зарплате отсутствуют

---

## Remotive

**Тип:** `remotive`  
**Extra:** `pip install vacancies-parser-kit[remotive]`  
**API:** https://remotive.com/api/remote-jobs  
**Авторизация:** не требуется  
**Покрытие:** глобальный remote, все отрасли

### Как работает

Один запрос возвращает все вакансии (или отфильтрованное подмножество). Rate limit: 2 запроса в минуту.

### Параметры

```yaml
params:
  category: "data"        # фильтр по категории (необязательно)
  search: "analyst"       # поиск по тексту вакансии (необязательно)
  limit: 100              # макс. число результатов (необязательно)
```

Доступные категории: `software-dev`, `customer-support`, `design`, `marketing`, `data`, `devops`, `finance`, `product`, `business` и др. Полный список: https://remotive.com/api/remote-jobs/categories

### Маппинг полей

| Поле Vacancy | Поле API |
|---|---|
| `source_id` | `id` |
| `title` | `title` |
| `company` | `company_name` |
| `description` | `description` (HTML) |
| `url` | `url` |
| `region` | `candidate_required_location` (строка, напр. "Worldwide", "LATAM") |
| `is_remote` | всегда `true` |
| `skills` | `tags` (строка через запятую → list) |
| `employment_type` | `job_type` |
| `published_at` | `publication_date` (ISO) |
| `salary` | — строка вида "80k-120k USD", только в `raw` |

### Ограничения

- Зарплата — неструктурированная строка, парсинг не выполняется (хранится в `raw`)
- Нет пагинации: один запрос — весь датасет (обычно 100–300 вакансий)

---

## RemoteOK

**Тип:** `remoteok`  
**Extra:** `pip install vacancies-parser-kit[remoteok]`  
**API:** https://remoteok.com/api  
**Авторизация:** не требуется  
**Покрытие:** глобальный remote, tech-фокус

### Как работает

Один запрос возвращает весь массив активных вакансий (~100–200 позиций). Первый элемент массива — юридический notice без поля `id`, он автоматически пропускается.

### Параметры

```yaml
params:
  # Параметры не поддерживаются — API возвращает полный датасет
```

### Маппинг полей

| Поле Vacancy | Поле API |
|---|---|
| `source_id` | `id` |
| `title` | `position` |
| `company` | `company` |
| `description` | `description` (HTML) |
| `url` | `url` |
| `city` | `location` |
| `is_remote` | всегда `true` |
| `skills` | `tags` (list) |
| `salary.min` | `salary_min` (USD) |
| `salary.max` | `salary_max` (USD) |
| `salary.currency` | всегда `"USD"` |
| `published_at` | `date` (ISO) |

### Ограничения

- Нет фильтрации: только полный датасет одним запросом
- Зарплата указана не у всех вакансий
- Требует `User-Agent` в заголовке (проставляется автоматически)

---

## Jobicy

**Тип:** `jobicy`  
**Extra:** `pip install vacancies-parser-kit[jobicy]`  
**API:** https://jobicy.com/api/v2/remote-jobs  
**Авторизация:** не требуется  
**Покрытие:** глобальный remote, зарплатные данные

### Как работает

Один запрос с параметрами фильтрации. Максимум 50 вакансий. Rate limit: 1 запрос в час — планируйте соответственно.

### Параметры

```yaml
params:
  count: 50               # число вакансий, 1–50 (default: 50)
  geo: "worldwide"        # страна/регион: "usa", "uk", "canada", "worldwide" и др.
  industry: "data"        # отрасль (необязательно)
  tag: "python"           # тег/навык для фильтрации (необязательно)
```

### Маппинг полей

| Поле Vacancy | Поле API |
|---|---|
| `source_id` | `id` |
| `title` | `jobTitle` |
| `company` | `companyName` |
| `description` | `jobDescription` (HTML) |
| `url` | `url` |
| `country` | `jobGeo` |
| `is_remote` | всегда `true` |
| `salary.min` | `annualSalaryMin` |
| `salary.max` | `annualSalaryMax` |
| `salary.currency` | `salaryCurrency` |
| `employment_type` | `jobType[0]` (список → первый элемент) |
| `published_at` | `pubDate` (ISO) |

### Ограничения

- Rate limit: 1 запрос в час — не подходит для частых обновлений
- Максимум 50 вакансий на запрос

---

## Telegram

**Тип:** `telegram`  
**Extra:** `pip install vacancies-parser-kit[telegram]`

### Параметры

```yaml
params:
  api_id: 12345678              # с https://my.telegram.org
  api_hash: "your_api_hash"
  channel: "@python_vacancy"    # username или числовой id
  limit: 100                    # макс. сообщений
  days_back: 7                  # за последние N дней
  keywords: ["python", "django"]  # фильтрация по ключевым словам
```

> **Примечание:** Telegram — неструктурированный источник. Данные извлекаются из свободного текста, часть полей может быть пустой. Это нормальное поведение.

---

## LinkedIn

**Тип:** `linkedin`  
**Extra:** `pip install vacancies-parser-kit[linkedin]`

### Параметры

```yaml
params:
  keywords: "data engineer"     # поисковый запрос
  location: "Russia"
  remote: true                  # только удалённые
  limit: 50
  request_delay: 1.0
```

---

## Создание своего источника

1. Создайте `vpr/sources/<type>.py`
2. Наследуйте `BaseSource`, установите `source_type`
3. Декорируйте `@register_source`
4. Реализуйте `async def fetch(self) -> AsyncIterator[Vacancy]`
5. Импортируйте модуль в `vpr/sources/__init__.py`

```python
from vpr.sources.base import BaseSource
from vpr.sources.registry import register_source
from vpr.core.models import Vacancy

@register_source
class MySource(BaseSource):
    source_type = "my_source"

    async def fetch(self):
        # ваша логика
        yield Vacancy(source="my_source", source_id="1", title="...")
```
