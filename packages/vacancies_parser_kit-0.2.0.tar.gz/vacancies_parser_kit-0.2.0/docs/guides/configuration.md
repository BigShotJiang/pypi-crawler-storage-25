# Конфигурация

vpr использует три типа конфигурационных файлов:

1. **`vpr_project.yml`** — настройки проекта
2. **`profiles.yml`** — хранилища (куда сохранять)
3. **`sources/*.yml`** — источники вакансий (откуда брать)

## vpr_project.yml

Корневой файл проекта. Создаётся автоматически через `vpr init`.

```yaml
name: my_project
version: "1.0"
default_profile: dev          # профиль из profiles.yml по умолчанию

paths:
  sources: sources            # папка с YAML-файлами источников
  dictionaries: dictionaries  # папка со справочниками
```

| Поле | По умолчанию | Описание |
|------|-------------|----------|
| `name` | — | Имя проекта |
| `version` | `"1.0"` | Версия проекта |
| `default_profile` | `dev` | Профиль по умолчанию (можно переопределить через `--profile`) |
| `paths.sources` | `sources` | Путь к директории с источниками |
| `paths.dictionaries` | `dictionaries` | Путь к справочникам |

## profiles.yml

Определяет targets — куда сохранять данные. Каждый профиль содержит набор targets.

```yaml
default_profile: dev

profiles:
  dev:
    targets:
      sqlite_local:
        type: sqlite
        params:
          path: output/vacancies.db

      jsonl_local:
        type: jsonl
        params:
          path: output/vacancies.jsonl
          mode: append                  # append | overwrite

      clickhouse_local:
        type: clickhouse
        host: localhost
        port: 8123
        database: vacancies
        user: default
        password: ""
        params:
          table: vacancies

      postgres_local:
        type: postgres
        host: localhost
        port: 5432
        database: vacancies
        user: postgres
        password: ""
        params:
          table: vacancies

  prod:
    targets:
      clickhouse_prod:
        type: clickhouse
        host: "{{ env_var('CH_HOST') }}"
        port: 8123
        database: vacancies
        user: "{{ env_var('CH_USER') }}"
        password: "{{ env_var('CH_PASSWORD') }}"
```

### Переменные окружения

Используйте `{{ env_var('NAME') }}` для подстановки:

```yaml
host: "{{ env_var('DB_HOST') }}"
password: "{{ env_var('DB_PASSWORD') }}"
```

Переменные загружаются из окружения или `.env` файла.

## Source YAML

Каждый файл в `sources/` — это один экземпляр источника.

```yaml
name: hh_backend_msk          # уникальное имя (используется в --select)
type: headhunter               # тип источника (headhunter | telegram | linkedin)
tags: [hh, backend, daily]     # теги для группового запуска (tag:hh)
enabled: true                  # false — источник игнорируется
profile: prod                  # переопределить профиль (по умолчанию — из проекта)

params:                        # параметры, специфичные для типа источника
  search_text: "backend developer"
  area: 1

targets:                       # куда сохранять (по умолчанию — все targets профиля)
  - clickhouse_prod
  - postgres_prod
```

### Общие поля

| Поле | Обязательное | Описание |
|------|-------------|----------|
| `name` | да | Уникальное имя источника |
| `type` | да | Тип плагина |
| `tags` | нет | Список тегов для `--select tag:X` |
| `enabled` | нет | `true` по умолчанию. `false` — пропускается |
| `profile` | нет | Переопределить профиль для этого источника |
| `params` | нет | Параметры, специфичные для типа |
| `targets` | нет | Список targets. Если пусто — все targets из профиля |

### Один тип — много экземпляров

Один и тот же тип может использоваться многократно с разными параметрами:

```
sources/
├── hh_backend_msk.yml      # HeadHunter, backend, Москва
├── hh_backend_spb.yml      # HeadHunter, backend, СПб
├── hh_data_analyst.yml     # HeadHunter, data analyst, Россия
├── tg_python_jobs.yml      # Telegram, канал @python_vacancy
└── tg_devops_jobs.yml      # Telegram, канал @devops_jobs
```

Запуск всех HH-источников: `vpr run --select tag:hh`
