# Хранилища (Writers)

Writers определяют куда сохранять вакансии. Настраиваются в `profiles.yml` как targets.

## SQLite

**Тип:** `sqlite`  
**Зависимости:** нет (стандартная библиотека Python)

Локальная БД, идеально для разработки и небольших объёмов. Таблица и схема создаются автоматически.

```yaml
targets:
  sqlite_local:
    type: sqlite
    params:
      path: output/vacancies.db   # путь к файлу БД
```

Стратегия записи: **UPSERT** по `(source, source_id)` — повторный запуск обновляет существующие записи.

```bash
# Просмотр данных
sqlite3 output/vacancies.db "SELECT count(*) FROM vacancies"
sqlite3 output/vacancies.db "SELECT title, company, city FROM vacancies LIMIT 10"
```

## JSONL

**Тип:** `jsonl`  
**Зависимости:** нет

Один JSON-объект на строку. Удобно для пайплайнов обработки данных, импорта в другие системы.

```yaml
targets:
  jsonl_local:
    type: jsonl
    params:
      path: output/vacancies.jsonl
      mode: append       # append — дописывать, overwrite — перезаписывать
```

```bash
# Подсчёт записей
wc -l output/vacancies.jsonl

# Просмотр первой записи
head -1 output/vacancies.jsonl | python3 -m json.tool
```

## ClickHouse

**Тип:** `clickhouse`  
**Extra:** `pip install vacancies-parser-kit[clickhouse]`

Таблица создаётся автоматически с движком `ReplacingMergeTree` — дубли по `(source, source_id)` схлопываются при мержах.

```yaml
targets:
  clickhouse_prod:
    type: clickhouse
    host: localhost
    port: 8123
    database: vacancies
    user: default
    password: ""
    params:
      table: vacancies    # имя таблицы
```

## PostgreSQL

**Тип:** `postgres`  
**Extra:** `pip install vacancies-parser-kit[postgres]`

Таблица создаётся автоматически. Поля `skills` и `raw` хранятся как `JSONB`. Стратегия: **UPSERT** по `(source, source_id)`.

```yaml
targets:
  postgres_prod:
    type: postgres
    host: localhost
    port: 5432
    database: vacancies
    user: postgres
    password: ""
    params:
      table: vacancies
```

## Схема данных

Все writers сохраняют одну и ту же каноническую модель `Vacancy`:

| Поле | Тип | Описание |
|------|-----|----------|
| `source` | string | Тип источника (`headhunter`, `telegram`, ...) |
| `source_id` | string | ID вакансии в источнике |
| `title` | string? | Название вакансии |
| `company` | string? | Компания |
| `description` | string? | Полное описание (HTML) |
| `url` | string? | Ссылка на вакансию |
| `city` | string? | Город |
| `region` | string? | Регион |
| `country` | string? | Страна |
| `is_remote` | bool? | Удалённая работа |
| `salary_min` | float? | Зарплата от |
| `salary_max` | float? | Зарплата до |
| `salary_currency` | string? | Валюта |
| `experience` | string? | Требуемый опыт |
| `employment_type` | string? | Тип занятости |
| `schedule` | string? | График |
| `skills` | list[string] | Навыки |
| `published_at` | datetime? | Дата публикации |
| `fetched_at` | datetime | Дата выгрузки |
| `status` | string | created / updated / deleted |
| `raw` | json | Исходные данные от источника |

Все поля кроме `source`, `source_id`, `fetched_at`, `status` — nullable. Источники могут возвращать неполные данные — это нормально.

## Создание своего writer

1. Создайте `vpr/writers/<type>.py`
2. Наследуйте `BaseWriter`, установите `writer_type`
3. Декорируйте `@register_writer`
4. Реализуйте `async def write(self, vacancies: list[Vacancy]) -> int`
5. Импортируйте модуль в `vpr/writers/__init__.py`

```python
from vpr.writers.base import BaseWriter
from vpr.writers.registry import register_writer

@register_writer
class MyWriter(BaseWriter):
    writer_type = "my_storage"

    async def write(self, vacancies):
        # ваша логика записи
        return len(vacancies)
```
