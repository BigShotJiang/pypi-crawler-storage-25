# Документация vpr

## Содержание

### Начало работы
- [Установка](getting-started/installation.md)
- [Быстрый старт](getting-started/quickstart.md) — первый запуск за 5 минут

### Руководства
- [Конфигурация](guides/configuration.md) — vpr_project.yml, profiles.yml, source YAML
- [Источники](guides/sources.md) — HeadHunter, Telegram, LinkedIn
- [Хранилища](guides/writers.md) — SQLite, JSONL, ClickHouse, PostgreSQL

### Справочник
- [CLI команды](reference/cli.md) — init, run, list
