# vacancies-parser-kit (vpr)

[![PyPI](https://img.shields.io/pypi/v/vacancies-parser-kit)](https://pypi.org/project/vacancies-parser-kit/)
[![Python](https://img.shields.io/pypi/pyversions/vacancies-parser-kit)](https://pypi.org/project/vacancies-parser-kit/)

Multi-source vacancy parser — собирает вакансии с разных площадок, приводит к единому формату и сохраняет в любое хранилище.

## Возможности

- **Источники:** HeadHunter API, Arbeitnow, Remotive, RemoteOK, Jobicy, Telegram-каналы, LinkedIn
- **Хранилища:** SQLite, JSONL, ClickHouse, PostgreSQL
- **CLI** в стиле dbt: YAML-конфиги, теги, `--select` / `--exclude`
- **Расширяемость:** добавление новых источников и хранилищ через плагины
- **Один тип → много экземпляров:** один HeadHunter-плагин, разные конфиги для разных запросов

## Быстрый старт

```bash
pip install vacancies-parser-kit[hh]

vpr init my_project
cd my_project

# Отредактируйте sources/hh_example.yml под свои нужды
vpr run --select hh_example
```

## CLI

```bash
vpr init <project-name>                    # создать проект
vpr run --select <name|glob|tag:X>         # запустить пайплайн
vpr run --select tag:hh --exclude hh_test  # с исключением
vpr run --select "tg_*" --steps fetch      # только fetch
vpr list                                   # все источники
vpr list --tags                            # по тегам
```

## Пайплайн

```
fetch → transform → write
```

1. **fetch** — получение данных из источника
2. **transform** — нормализация в единый формат Vacancy
3. **write** — сохранение в target(ы) из profiles.yml

Каждый шаг можно запускать отдельно через `--steps`.

## Структура проекта

```
my_project/
├── vpr_project.yml       # настройки проекта
├── profiles.yml          # куда сохранять (targets)
├── sources/              # YAML-файлы источников
│   ├── hh_backend.yml
│   ├── tg_python.yml
│   └── linkedin_eu.yml
└── dictionaries/         # справочники
```

## Source YAML

Один тип источника может иметь множество экземпляров с разными параметрами — как модели в dbt.

**HeadHunter** (Россия и СНГ):
```yaml
name: hh_backend_msk
type: headhunter
tags: [hh, backend, daily]
params:
  search_text: "backend developer"
  area: 1                # 1=Москва, 113=Россия, 40=Казахстан
  enrich: true           # полное описание + навыки
  request_delay: 0.25
targets:
  - sqlite_local
```

**Arbeitnow** (Европа + remote, без ключей):
```yaml
name: arbeitnow_eu
type: arbeitnow
tags: [eu, remote, daily]
targets:
  - sqlite_local
```

**Remotive** (global remote, без ключей):
```yaml
name: remotive_data
type: remotive
tags: [remote, data, daily]
params:
  category: "data"
  search: "analyst"
targets:
  - sqlite_local
```

**RemoteOK** (global remote, без ключей):
```yaml
name: remoteok_all
type: remoteok
tags: [remote, daily]
targets:
  - sqlite_local
```

**Jobicy** (global remote + зарплаты, без ключей):
```yaml
name: jobicy_data
type: jobicy
tags: [remote, data, hourly]
params:
  tag: "data analyst"
  geo: "worldwide"
  count: 50
targets:
  - sqlite_local
```

## Установка

```bash
pip install vacancies-parser-kit              # базовая (SQLite + JSONL)
pip install vacancies-parser-kit[hh]          # + HeadHunter (Россия, СНГ)
pip install vacancies-parser-kit[arbeitnow]   # + Arbeitnow (Европа, remote)
pip install vacancies-parser-kit[remotive]    # + Remotive (global remote)
pip install vacancies-parser-kit[remoteok]    # + RemoteOK (global remote)
pip install vacancies-parser-kit[jobicy]      # + Jobicy (global remote + зарплаты)
pip install vacancies-parser-kit[telegram]    # + Telegram-каналы
pip install vacancies-parser-kit[all]         # все источники и хранилища
```

## Документация

- [Быстрый старт](docs/getting-started/quickstart.md)
- [Конфигурация](docs/guides/configuration.md)
- [Источники](docs/guides/sources.md) — HeadHunter, Arbeitnow, Remotive, RemoteOK, Jobicy, Telegram, LinkedIn
- [Хранилища](docs/guides/writers.md) — SQLite, JSONL, ClickHouse, PostgreSQL
- [CLI справочник](docs/reference/cli.md)

## Разработка (для контрибьюторов)

Если вы хотите вносить изменения в сам `vpr` — клонируйте репозиторий и установите в editable-режиме:

```bash
git clone https://github.com/alexeiveselov92/vacancies-parser-kit.git
cd vacancies-parser-kit
python3 -m venv .venv && source .venv/bin/activate
pip install -e ".[dev]"

pytest                    # тесты
ruff check vpr/           # линтер
ruff format vpr/          # форматирование
```
