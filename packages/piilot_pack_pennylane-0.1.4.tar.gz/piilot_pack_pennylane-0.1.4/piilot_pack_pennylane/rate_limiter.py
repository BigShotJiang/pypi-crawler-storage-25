"""Async rate limiter with adaptive backoff for external API calls."""

from __future__ import annotations

import asyncio


class RateLimiter:
    """Async rate limiter with adaptive backoff and auto-recovery.

    On 429 → doubles the interval (up to _MAX_INTERVAL).
    After _RECOVER_AFTER consecutive successes → restores base interval.

    Usage::

        limiter = RateLimiter(max_per_second=4)

        await limiter.acquire()
        resp = await do_request()
        if resp.status_code == 429:
            limiter.back_off()
        else:
            limiter.success()
    """

    _MAX_INTERVAL = 5.0
    _RECOVER_AFTER = 10  # consecutive successes before restoring base rate

    def __init__(self, max_per_second: float = 4.0) -> None:
        self._base_interval = 1.0 / max_per_second
        self._min_interval = self._base_interval
        self._lock = asyncio.Lock()
        self._last_call: float = 0.0
        self._ok_streak: int = 0

    def back_off(self) -> None:
        """Double the minimum interval (called after a 429)."""
        self._min_interval = min(self._min_interval * 2, self._MAX_INTERVAL)
        self._ok_streak = 0

    def success(self) -> None:
        """Record a successful request; recover base rate after enough successes."""
        if self._min_interval > self._base_interval:
            self._ok_streak += 1
            if self._ok_streak >= self._RECOVER_AFTER:
                self._min_interval = self._base_interval
                self._ok_streak = 0

    async def acquire(self) -> None:
        """Wait until the next request slot is available."""
        async with self._lock:
            loop = asyncio.get_event_loop()
            now = loop.time()
            elapsed = now - self._last_call
            if elapsed < self._min_interval:
                await asyncio.sleep(self._min_interval - elapsed)
            self._last_call = asyncio.get_event_loop().time()

    async def __aenter__(self) -> RateLimiter:
        await self.acquire()
        return self

    async def __aexit__(self, *exc: object) -> None:
        pass
