"""Plugin HTTP routes.

Mounted under ``/plugins/pennylane/*`` by the loader via
``piilot.sdk.http.register_router``. Exposes:

* Treasury dashboard ``GET /treasury/dashboard``
* CRUD connections (list/connect/connect-firm/disconnect/schedule)
* Firm clients (list/get)
* OAuth2 flow (authorize/callback)
* Status + sync progress
* Read-only data access (invoices/customers/transactions)

Until B.6 of PLT-18 the core still served the equivalent paths under
``/integrations/pennylane/*`` and ``/modules/pennylane-treasury/*``.
The big bang in B.6 removes those from the core; the frontend is
repointed to the ``/plugins/pennylane/*`` paths in the same PR.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
from datetime import UTC, datetime, timedelta
from typing import Any, Literal
from urllib.parse import urlencode

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.encoders import jsonable_encoder
from fastapi.responses import JSONResponse, RedirectResponse
from piilot.sdk.access import check_grant
from piilot.sdk.connectors import (
    delete_connection,
    get_connection,
    list_connections,
    save_connection,
    update_sync_state,
)
from piilot.sdk.crypto import decrypt, encrypt, mask_api_key
from piilot.sdk.db import cursor as _db_cursor
from piilot.sdk.http import get_real_ip, require_admin, require_builder, require_user
from pydantic import BaseModel, Field
from slowapi import Limiter

from . import module_treasury
from .client import PennylaneAPIError, PennylaneClient
from .repositories import (
    pennylane_customers_repo,
    pennylane_firm_clients_repo,
    pennylane_invoices_repo,
    pennylane_suppliers_repo,
    pennylane_transactions_repo,
)
from .repositories._base import run_in_thread
from .sync import _compute_next_sync, get_sync_progress, sync_pennylane, sync_pennylane_firm

logger = logging.getLogger(__name__)

_TREASURY_MODULE_SLUG = "pennylane-treasury"
_SECRET_FIELDS = {"access_token_encrypted", "refresh_token_encrypted"}

# Strong references to background sync tasks (prevents GC; SPEC §v0.17.0).
_bg_sync_tasks: set = set()


# slowapi limiter bound to the SDK's get_real_ip (Cloudflare-aware).
limiter = Limiter(key_func=get_real_ip)


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------


class ConnectPennylaneRequest(BaseModel):
    api_token: str = Field(..., min_length=1, max_length=500)
    label: str = Field(..., min_length=1, max_length=100)


class ConnectPennylaneFirmRequest(BaseModel):
    api_token: str = Field(..., min_length=10, max_length=500)
    label: str = Field(..., min_length=1, max_length=100)


class EntityScopes(BaseModel):
    """Which Pennylane entity kinds the nightly sync should pull.

    Omitted keys default to ``True`` at sync time (``sync.py`` reads the
    stored JSON with ``.get(key, True)``). Writing a ``false`` here
    skips that entity — the existing DB rows are **not** truncated,
    they just stop being refreshed until the flag flips back.
    """

    clients: bool = True
    invoices: bool = True
    suppliers: bool = True
    transactions: bool = True


class UpdateConnectionRequest(BaseModel):
    """Partial-update payload for ``PATCH /connections/{id}``.

    Every field is optional — the server merges what is sent into the
    existing row's ``config`` JSONB. Empty body is a no-op.
    """

    label: str | None = Field(None, min_length=1, max_length=100)
    sync_frequency: int | None = Field(None, ge=1, le=2)
    sync_times: list[str] | None = Field(None, min_length=1, max_length=2)
    sync_timezone: str | None = Field(None, max_length=50)
    entity_scopes: EntityScopes | None = None

    def validate_patch(self) -> str | None:
        """Return an error message if the patch is structurally invalid.

        Called before the SDK write so we surface 422s on nonsense
        payloads (wrong time format, frequency/times mismatch,
        zero scopes active, …) rather than surface a cryptic DB
        error after the fact.
        """
        if self.sync_frequency is not None or self.sync_times is not None:
            # When either is sent both must be; otherwise the row ends
            # up in an inconsistent schedule state.
            if self.sync_frequency is None or self.sync_times is None:
                return "sync_frequency and sync_times must be sent together"
            if len(self.sync_times) != self.sync_frequency:
                return f"sync_times must have exactly {self.sync_frequency} entries"
            last_hour = -1
            for t in self.sync_times:
                if not re.fullmatch(r"[0-2]?\d:[0-5]\d", t):
                    return f"Invalid time format: {t}"
                h = int(t.split(":")[0])
                if h > 23:
                    return f"Hour out of range: {t}"
                if h <= last_hour:
                    return "sync_times must be sorted ascending"
                last_hour = h
        if self.entity_scopes is not None:
            scopes = self.entity_scopes
            if not any(
                (scopes.clients, scopes.invoices, scopes.suppliers, scopes.transactions)
            ):
                return "at least one entity_scope must be enabled"
        return None

    def is_empty(self) -> bool:
        return all(
            v is None
            for v in (
                self.label,
                self.sync_frequency,
                self.sync_times,
                self.sync_timezone,
                self.entity_scopes,
            )
        )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _serialize_firm_client(c: dict) -> dict:
    """Explicit allowlist — never leak raw_data."""
    synced_at = c.get("synced_at")
    return {
        "id": c["id"],
        "connection_id": c.get("connection_id"),
        "external_company_id": c.get("external_company_id"),
        "company_name": c.get("company_name"),
        "siren": c.get("siren"),
        "siret": c.get("siret"),
        "legal_form": c.get("legal_form"),
        "is_active": c.get("is_active", True),
        "synced_at": synced_at.isoformat() if hasattr(synced_at, "isoformat") else synced_at,
    }


def _safe_connection(conn: dict) -> dict:
    """Strip encrypted tokens, add masked key for display."""
    result = {k: v for k, v in conn.items() if k not in _SECRET_FIELDS}
    encrypted = conn.get("access_token_encrypted", "")
    if encrypted:
        try:
            result["api_key_masked"] = mask_api_key(decrypt(encrypted))
        except Exception:
            result["api_key_masked"] = "***"
    return result


def _serialize_connection_summary(c: dict) -> dict:
    """Compact serialization for GET /connections."""
    encrypted = c.get("access_token_encrypted") or ""
    masked = None
    if encrypted:
        try:
            masked = mask_api_key(decrypt(encrypted))
        except Exception:
            masked = "***"
    config = c.get("config") or {}
    return {
        "id": c["id"],
        "label": c.get("label"),
        "mode": config.get("mode", "company"),
        "auth_type": c.get("auth_type"),
        "is_active": c.get("is_active", True),
        "last_sync_at": c.get("last_sync_at"),
        "next_sync_at": c.get("next_sync_at"),
        "created_at": c.get("created_at"),
        "api_key_masked": masked,
    }


async def _load_pennylane_connection_or_404(connection_id: str, company_id: str) -> dict | None:
    """Resolve a connection_id within the caller's tenant.

    Returns the connection dict on success, ``None`` if the id is unknown
    or belongs to another tenant. Also enforces that the connection is
    a Pennylane one — cross-provider access is a 404.
    """
    conn = await run_in_thread(get_connection, connection_id)
    if not conn:
        return None
    if conn.get("provider") != "pennylane" or str(conn.get("company_id")) != str(company_id):
        return None
    return conn


def _get_module_id_by_slug(slug: str) -> str | None:
    """Resolve the ``modules.modules.id`` UUID for a given slug.

    SDK v0.2 exposes ``modules.register_module`` (upsert) but no
    ``modules.get_by_slug`` read helper. We fall back to direct SQL via
    ``piilot.sdk.db.cursor``. Tracked as SDK v0.3 candidate primitive.
    """
    with _db_cursor() as cur:
        cur.execute(
            "SELECT id FROM modules.modules WHERE module_slug = %s",
            (slug,),
        )
        row = cur.fetchone()
    if not row:
        return None
    return str(row["id"])


def _list_sync_logs_by_connection(connection_id: str, limit: int = 5) -> list[dict]:
    """List the N most recent sync_logs for a connection.

    SDK v0.2 has no ``list_sync_logs`` helper (only ``log_sync`` for
    writing). We fall back to SQL on ``integrations_master.sync_logs``.
    Candidate SDK v0.3 primitive.
    """
    with _db_cursor() as cur:
        cur.execute(
            "SELECT id, connection_id, company_id, sync_type, status, "
            "items_synced, items_failed, error_message, s3_path, "
            "started_at, completed_at "
            "FROM integrations_master.sync_logs "
            "WHERE connection_id = %s "
            "ORDER BY started_at DESC LIMIT %s",
            (connection_id, limit),
        )
        return [dict(row) for row in cur.fetchall()]


def _find_connection_by_label(company_id: str, provider: str, label: str) -> dict | None:
    """Look up a connection by (company, provider, label).

    SDK v0.2 ``list_connections(company_id, provider)`` returns all; we
    filter locally. Candidate SDK v0.3: pass ``label=`` to list_connections.
    """
    for c in list_connections(company_id, provider=provider):
        if c.get("label") == label:
            return c
    return None


router = APIRouter()


# ===================================================================
# Treasury dashboard
# ===================================================================


@router.get("/treasury/dashboard")
@limiter.limit("30/minute")
async def get_treasury_dashboard(
    request: Request,
    connection_id: str = Query(..., min_length=1),
    period: Literal["30d", "ytd", "12m", "24m"] = Query("30d"),
    bank_account: str | None = Query(None),
    auth: Any = Depends(require_user),  # noqa: B008
):
    """Treasury dashboard — aggregated from locally-synced data."""
    user_id, _role, company_id = auth
    if not company_id:
        raise HTTPException(status_code=400, detail="Company requise")

    conn = await _load_pennylane_connection_or_404(connection_id, company_id)
    if not conn or not conn.get("is_active"):
        raise HTTPException(status_code=404, detail="Connexion Pennylane introuvable")

    module_id = await run_in_thread(_get_module_id_by_slug, _TREASURY_MODULE_SLUG)
    if not module_id:
        raise HTTPException(status_code=404, detail="Module tresorerie non trouve")

    has_access = await run_in_thread(check_grant, str(company_id), "module", module_id, str(user_id))
    if not has_access:
        raise HTTPException(status_code=403, detail="Acces refuse a ce module")

    data = await run_in_thread(
        module_treasury.get_dashboard,
        connection_id,
        period,
        bank_account,
        conn.get("last_sync_at"),
    )
    data["connected"] = True
    return data


# ===================================================================
# Connections — list / connect / connect-firm / disconnect / schedule
# ===================================================================


@router.get("/connections")
@limiter.limit("30/minute")
async def list_pennylane_connections(request: Request):
    """List every Pennylane connection of the caller's tenant."""
    _user_id, _role, company_id = require_admin(request)
    conns = await run_in_thread(list_connections, company_id, provider="pennylane")
    return JSONResponse(
        {
            "success": True,
            "connections": [_serialize_connection_summary(c) for c in conns],
            "count": len(conns),
        }
    )


@router.post("/connect")
@limiter.limit("5/minute")
async def connect_pennylane(data: ConnectPennylaneRequest, request: Request):
    _user_id, _role, company_id = require_admin(request)

    collision = await run_in_thread(_find_connection_by_label, company_id, "pennylane", data.label)
    if collision:
        return JSONResponse(
            {"success": False, "error": f"An integration named '{data.label}' already exists"},
            status_code=409,
        )

    try:
        client = PennylaneClient(data.api_token)
        me = await client.get_me()
    except PennylaneAPIError as exc:
        return JSONResponse(
            {"success": False, "error": f"Invalid token: {exc}"},
            status_code=401,
        )
    except (httpx.TimeoutException, httpx.ConnectError) as exc:
        return JSONResponse(
            {"success": False, "error": f"Cannot reach Pennylane: {exc}"},
            status_code=502,
        )

    # /me returns {"user": {...}, "company": {"id": int, ...}}
    company_info = me.get("company", {})
    external_id = str(company_info.get("id", me.get("id", "")))

    # SDK save_connection auto-encrypts ``access_token`` via
    # credentials_schema declared in Plugin.register().
    conn = await run_in_thread(
        save_connection,
        company_id=str(company_id),
        provider="pennylane",
        auth_type="api_token",
        label=data.label,
        credentials={
            "access_token": data.api_token,
            "external_account_id": external_id,
        },
        config={
            "sync_frequency": 1,
            "sync_times": ["08:00"],
            "sync_entities": ["invoices", "customers", "transactions", "suppliers"],
        },
    )

    task = asyncio.create_task(sync_pennylane(conn))
    _bg_sync_tasks.add(task)
    task.add_done_callback(_bg_sync_tasks.discard)

    logger.info(
        "Pennylane connected for company %s label=%r (external=%s) — initial sync queued",
        company_id,
        data.label,
        external_id,
    )
    return JSONResponse(
        {"success": True, "connection": _safe_connection(conn)},
        status_code=201,
    )


@router.post("/connect-firm")
@limiter.limit("5/minute")
async def connect_pennylane_firm(data: ConnectPennylaneFirmRequest, request: Request):
    _user_id, _role, company_id = require_admin(request)

    collision = await run_in_thread(_find_connection_by_label, company_id, "pennylane", data.label)
    if collision:
        return JSONResponse(
            {"success": False, "error": f"An integration named '{data.label}' already exists"},
            status_code=409,
        )

    try:
        async with PennylaneClient(data.api_token) as client:
            firm_companies = await client.list_firm_companies()
    except PennylaneAPIError as exc:
        return JSONResponse(
            {"success": False, "error": f"Invalid Firm token (Pennylane returned {exc.status_code})"},
            status_code=401,
        )
    except (httpx.TimeoutException, httpx.ConnectError):
        return JSONResponse(
            {"success": False, "error": "Cannot reach Pennylane"},
            status_code=502,
        )

    if not firm_companies:
        return JSONResponse(
            {"success": False, "error": "Firm token valid but no client companies accessible"},
            status_code=400,
        )

    conn = await run_in_thread(
        save_connection,
        company_id=str(company_id),
        provider="pennylane",
        auth_type="api_token",
        label=data.label,
        credentials={
            "access_token": data.api_token,
            "external_account_id": f"firm-{company_id}",
        },
        config={
            "mode": "firm",
            "sync_frequency": 1,
            "sync_times": ["08:00"],
            "sync_entities": ["invoices", "customers", "transactions", "suppliers"],
        },
    )

    task = asyncio.create_task(sync_pennylane_firm(conn))
    _bg_sync_tasks.add(task)
    task.add_done_callback(_bg_sync_tasks.discard)

    logger.info(
        "Pennylane Firm connected for company %s label=%r (%d client companies)",
        company_id,
        data.label,
        len(firm_companies),
    )
    return JSONResponse(
        {
            "success": True,
            "connection": _safe_connection(conn),
            "firm_clients_count": len(firm_companies),
        },
        status_code=201,
    )


@router.delete("/disconnect")
@limiter.limit("5/minute")
async def disconnect_pennylane(
    request: Request,
    connection_id: str = Query(..., min_length=1),
):
    _user_id, _role, company_id = require_admin(request)

    conn = await _load_pennylane_connection_or_404(connection_id, company_id)
    if not conn:
        return JSONResponse({"success": False, "error": "Connection not found"}, status_code=404)

    await run_in_thread(delete_connection, str(conn["id"]))
    logger.info(
        "Pennylane disconnected for company %s label=%r",
        company_id,
        conn.get("label"),
    )
    return JSONResponse({"success": True, "message": "Pennylane disconnected"})


@router.patch("/connections/{connection_id}")
@limiter.limit("10/minute")
async def update_connection(
    connection_id: str,
    data: UpdateConnectionRequest,
    request: Request,
):
    """Partial update of a Pennylane connection.

    Accepts any combination of ``label``, ``sync_frequency`` +
    ``sync_times``, ``sync_timezone`` and ``entity_scopes``. Only the
    fields present in the body are modified — the rest of the
    connection row is preserved.
    """
    _user_id, _role, company_id = require_admin(request)

    if data.is_empty():
        return JSONResponse(
            {"success": True, "message": "No changes"},
            status_code=200,
        )

    err = data.validate_patch()
    if err:
        return JSONResponse({"success": False, "error": err}, status_code=422)

    conn = await _load_pennylane_connection_or_404(connection_id, company_id)
    if not conn or not conn.get("is_active"):
        return JSONResponse(
            {"success": False, "error": "Connection not found or inactive"},
            status_code=404,
        )

    # Label uniqueness check — ``(company_id, provider, label)`` is a
    # soft invariant enforced at the app layer since the DB has no
    # constraint for it. Same-id rename is allowed (self-match skipped).
    new_label = data.label if data.label is not None else conn.get("label")
    if data.label and data.label != conn.get("label"):
        existing = await run_in_thread(
            _find_connection_by_label,
            str(company_id), "pennylane", data.label,
        )
        if existing and str(existing.get("id")) != str(conn["id"]):
            return JSONResponse(
                {"success": False, "error": "Label already used by another connection"},
                status_code=409,
            )

    current_config = dict(conn.get("config") or {})
    schedule_changed = False
    if data.sync_frequency is not None and data.sync_times is not None:
        current_config["sync_frequency"] = data.sync_frequency
        current_config["sync_times"] = data.sync_times
        schedule_changed = True
    if data.sync_timezone is not None:
        current_config["sync_timezone"] = data.sync_timezone
        schedule_changed = True
    if data.entity_scopes is not None:
        current_config["entity_scopes"] = {
            "clients": data.entity_scopes.clients,
            "invoices": data.entity_scopes.invoices,
            "suppliers": data.entity_scopes.suppliers,
            "transactions": data.entity_scopes.transactions,
        }

    # ``save_connection`` upsert merges — passing empty credentials
    # leaves the encrypted tokens untouched. Label change also goes
    # through here because ``integrations_master.connections.label``
    # is a first-class column the SDK writes.
    await run_in_thread(
        save_connection,
        company_id=str(company_id),
        provider="pennylane",
        auth_type=conn.get("auth_type", "api_token"),
        label=new_label or "Pennylane",
        credentials={},
        config=current_config,
        connection_id=str(conn["id"]),
    )

    # Re-compute ``next_sync_at`` when the schedule moved — otherwise
    # the DB still points at the old slot.
    next_sync = None
    if schedule_changed:
        next_sync = _compute_next_sync(current_config)
        await run_in_thread(update_sync_state, str(conn["id"]), next_sync_at=next_sync)

    logger.info(
        "Connection %s updated: label=%r, schedule_changed=%s, scopes=%s",
        connection_id,
        new_label,
        schedule_changed,
        current_config.get("entity_scopes"),
    )

    response = {
        "success": True,
        "connection_id": str(conn["id"]),
        "label": new_label,
        "entity_scopes": current_config.get("entity_scopes"),
        "sync_schedule": {
            "sync_frequency": current_config.get("sync_frequency"),
            "sync_times": current_config.get("sync_times"),
            "sync_timezone": current_config.get("sync_timezone"),
        },
    }
    if next_sync is not None:
        response["next_sync_at"] = next_sync.isoformat()

    return JSONResponse(response)


# ===================================================================
# Firm clients
# ===================================================================


@router.get("/firm-clients")
@limiter.limit("30/minute")
async def list_pennylane_firm_clients(
    request: Request,
    connection_id: str = Query(..., min_length=1),
):
    _user_id, _role, company_id = require_admin(request)

    conn = await _load_pennylane_connection_or_404(connection_id, company_id)
    if not conn:
        return JSONResponse({"success": False, "error": "Connection not found"}, status_code=404)

    clients = await run_in_thread(pennylane_firm_clients_repo.list_by_connection, connection_id)
    return JSONResponse(
        {
            "success": True,
            "firm_clients": [_serialize_firm_client(c) for c in clients],
            "count": len(clients),
        }
    )


@router.get("/firm-clients/{client_id}")
@limiter.limit("30/minute")
async def get_pennylane_firm_client(
    client_id: str,
    request: Request,
    connection_id: str = Query(..., min_length=1),
):
    _user_id, _role, company_id = require_admin(request)

    conn = await _load_pennylane_connection_or_404(connection_id, company_id)
    if not conn:
        return JSONResponse({"success": False, "error": "Connection not found"}, status_code=404)

    client = await run_in_thread(pennylane_firm_clients_repo.get, client_id)
    if (
        not client
        or str(client.get("connection_id")) != str(connection_id)
        or str(client.get("company_id")) != str(company_id)
    ):
        return JSONResponse({"success": False, "error": "Firm client not found"}, status_code=404)

    counts = {
        "invoices": await run_in_thread(
            pennylane_invoices_repo.count_by_connection,
            connection_id,
            firm_client_id=client_id,
        ),
        "customers": await run_in_thread(
            pennylane_customers_repo.count_by_connection,
            connection_id,
            firm_client_id=client_id,
        ),
        "suppliers": await run_in_thread(
            pennylane_suppliers_repo.count_by_connection,
            connection_id,
            firm_client_id=client_id,
        ),
        "transactions": await run_in_thread(
            pennylane_transactions_repo.count_by_connection,
            connection_id,
            firm_client_id=client_id,
        ),
    }
    return JSONResponse(
        {
            "success": True,
            "firm_client": {**_serialize_firm_client(client), "counts": counts},
        }
    )


# ===================================================================
# OAuth2 flow
# ===================================================================


@router.get("/authorize")
@limiter.limit("5/minute")
async def authorize_pennylane(
    request: Request,
    label: str = Query(..., min_length=1, max_length=100),
):
    _user_id, _role, company_id = require_admin(request)

    client_id = os.getenv("PENNYLANE_CLIENT_ID", "")
    redirect_uri = os.getenv("PENNYLANE_REDIRECT_URI", "")
    if not client_id or not redirect_uri:
        return JSONResponse(
            {"success": False, "error": "OAuth2 not configured (PENNYLANE_CLIENT_ID / PENNYLANE_REDIRECT_URI missing)"},
            status_code=500,
        )

    state_payload = json.dumps(
        {
            "company_id": str(company_id),
            "label": label,
            "ts": datetime.now(UTC).isoformat(),
        }
    )
    state = encrypt(state_payload)

    params = urlencode(
        {
            "client_id": client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "state": state,
        }
    )
    authorize_url = f"https://app.pennylane.com/oauth/authorize?{params}"

    return JSONResponse({"success": True, "authorize_url": authorize_url})


@router.get("/callback")
@limiter.limit("10/minute")
async def callback_pennylane(
    request: Request,
    code: str = Query(...),
    state: str = Query(...),
):
    try:
        state_data = json.loads(decrypt(state))
        company_id = state_data["company_id"]
        label = state_data.get("label") or "Pennylane OAuth"
        ts = datetime.fromisoformat(state_data["ts"])
        if datetime.now(UTC) - ts > timedelta(minutes=10):
            return JSONResponse({"success": False, "error": "State expired"}, status_code=400)
    except Exception:
        return JSONResponse({"success": False, "error": "Invalid state"}, status_code=400)

    client_id = os.getenv("PENNYLANE_CLIENT_ID", "")
    client_secret = os.getenv("PENNYLANE_CLIENT_SECRET", "")
    redirect_uri = os.getenv("PENNYLANE_REDIRECT_URI", "")

    try:
        async with httpx.AsyncClient(timeout=30) as http:
            resp = await http.post(
                "https://app.pennylane.com/oauth/token",
                json={
                    "grant_type": "authorization_code",
                    "code": code,
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "redirect_uri": redirect_uri,
                },
            )
            if resp.status_code >= 400:
                logger.error(
                    "Pennylane OAuth token exchange failed: %d %s",
                    resp.status_code,
                    resp.text,
                )
                return JSONResponse(
                    {"success": False, "error": "Token exchange failed"},
                    status_code=400,
                )
            token_data = resp.json()
    except Exception as exc:
        logger.error("Pennylane OAuth token exchange error: %s", exc)
        return JSONResponse(
            {"success": False, "error": "Token exchange error"},
            status_code=502,
        )

    expires_at = datetime.now(UTC) + timedelta(
        seconds=token_data.get("expires_in", 86400),
    )

    existing = await run_in_thread(_find_connection_by_label, company_id, "pennylane", label)
    if existing:
        # SDK save_connection with connection_id refreshes credentials.
        await run_in_thread(
            save_connection,
            company_id=str(company_id),
            provider="pennylane",
            auth_type="oauth2",
            label=label,
            credentials={
                "access_token": token_data["access_token"],
                "refresh_token": token_data.get("refresh_token", ""),
                "token_expires_at": expires_at,
            },
            connection_id=str(existing["id"]),
        )
    else:
        new_conn = await run_in_thread(
            save_connection,
            company_id=str(company_id),
            provider="pennylane",
            auth_type="oauth2",
            label=label,
            credentials={
                "access_token": token_data["access_token"],
                "refresh_token": token_data.get("refresh_token", ""),
                "token_expires_at": expires_at,
            },
            config={
                "sync_frequency": 1,
                "sync_times": ["08:00"],
                "sync_entities": ["invoices", "customers", "transactions", "suppliers"],
            },
        )
        task = asyncio.create_task(sync_pennylane(new_conn))
        _bg_sync_tasks.add(task)
        task.add_done_callback(_bg_sync_tasks.discard)

    logger.info("Pennylane OAuth connected for company %s label=%r", company_id, label)

    frontend_url = os.getenv("FRONTEND_URL", "")
    if frontend_url:
        return RedirectResponse(f"{frontend_url}/settings/integrations?status=success")
    return JSONResponse({"success": True, "message": "Pennylane connected via OAuth"})


# ===================================================================
# Status + sync progress
# ===================================================================


@router.get("/status")
@limiter.limit("30/minute")
async def pennylane_status(
    request: Request,
    connection_id: str = Query(..., min_length=1),
):
    _user_id, _role, company_id = require_admin(request)

    conn = await _load_pennylane_connection_or_404(connection_id, company_id)
    if not conn:
        return JSONResponse({"success": False, "error": "Connection not found"}, status_code=404)

    config = conn.get("config") or {}
    mode = config.get("mode", "company")

    recent_syncs = await run_in_thread(_list_sync_logs_by_connection, str(conn["id"]), 5)
    sync_schedule = {
        "sync_frequency": config.get("sync_frequency", 1),
        "sync_times": config.get("sync_times", ["08:00"]),
        "sync_timezone": config.get("sync_timezone", "UTC"),
    }

    base = {
        "success": True,
        "connected": True,
        "mode": mode,
        "connection": _safe_connection(conn),
        "last_sync_at": conn.get("last_sync_at"),
        "next_sync_at": conn.get("next_sync_at"),
        "sync_schedule": sync_schedule,
        "recent_syncs": recent_syncs,
    }

    if mode == "firm":
        firm_clients = await run_in_thread(pennylane_firm_clients_repo.list_by_connection, connection_id)
        summaries = []
        for c in firm_clients:
            fc_id = str(c["id"])
            inv = await run_in_thread(
                pennylane_invoices_repo.count_by_connection,
                connection_id,
                firm_client_id=fc_id,
            )
            tx = await run_in_thread(
                pennylane_transactions_repo.count_by_connection,
                connection_id,
                firm_client_id=fc_id,
            )
            summaries.append(
                {
                    "id": fc_id,
                    "name": c.get("company_name"),
                    "invoices": inv,
                    "transactions": tx,
                }
            )
        base["firm_clients_count"] = len(firm_clients)
        base["firm_clients"] = summaries
        return JSONResponse(jsonable_encoder(base))

    invoices_count = await run_in_thread(pennylane_invoices_repo.count_by_connection, connection_id)
    customers_count = await run_in_thread(pennylane_customers_repo.count_by_connection, connection_id)
    transactions_count = await run_in_thread(pennylane_transactions_repo.count_by_connection, connection_id)
    suppliers_count = await run_in_thread(pennylane_suppliers_repo.count_by_connection, connection_id)
    base["counts"] = {
        "invoices": invoices_count,
        "customers": customers_count,
        "suppliers": suppliers_count,
        "transactions": transactions_count,
    }
    return JSONResponse(jsonable_encoder(base))


@router.get("/sync-progress")
@limiter.limit("60/minute")
async def pennylane_sync_progress(
    request: Request,
    connection_id: str = Query(..., min_length=1),
):
    _user_id, _role, company_id = require_admin(request)

    conn = await _load_pennylane_connection_or_404(connection_id, company_id)
    if not conn:
        return JSONResponse({"success": False, "error": "Connection not found"}, status_code=404)

    progress = await get_sync_progress(str(conn["id"]))
    return JSONResponse({"success": True, "progress": progress})


# ===================================================================
# Data read — invoices / customers / transactions
# ===================================================================


@router.get("/invoices")
@limiter.limit("30/minute")
async def list_pennylane_invoices(
    request: Request,
    connection_id: str = Query(..., min_length=1),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    status: str | None = Query(None),
    search: str | None = Query(None),
    firm_client_id: str | None = Query(None),
):
    _user_id, _role, company_id = require_builder(request)

    conn = await _load_pennylane_connection_or_404(connection_id, company_id)
    if not conn:
        return JSONResponse({"success": False, "error": "Connection not found"}, status_code=404)

    if search:
        invoices = await run_in_thread(
            pennylane_invoices_repo.search,
            connection_id,
            search,
            limit,
            firm_client_id=firm_client_id,
        )
    else:
        invoices = await run_in_thread(
            pennylane_invoices_repo.list_by_connection,
            connection_id,
            status,
            limit,
            offset,
            firm_client_id=firm_client_id,
        )

    return JSONResponse({"success": True, "invoices": invoices, "count": len(invoices)})


@router.get("/customers")
@limiter.limit("30/minute")
async def list_pennylane_customers(
    request: Request,
    connection_id: str = Query(..., min_length=1),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    search: str | None = Query(None),
    firm_client_id: str | None = Query(None),
):
    _user_id, _role, company_id = require_builder(request)

    conn = await _load_pennylane_connection_or_404(connection_id, company_id)
    if not conn:
        return JSONResponse({"success": False, "error": "Connection not found"}, status_code=404)

    if search:
        customers = await run_in_thread(
            pennylane_customers_repo.search,
            connection_id,
            search,
            limit,
            firm_client_id=firm_client_id,
        )
    else:
        customers = await run_in_thread(
            pennylane_customers_repo.list_by_connection,
            connection_id,
            limit,
            offset,
            firm_client_id=firm_client_id,
        )

    return JSONResponse({"success": True, "customers": customers, "count": len(customers)})


@router.get("/transactions")
@limiter.limit("30/minute")
async def list_pennylane_transactions(
    request: Request,
    connection_id: str = Query(..., min_length=1),
    limit: int = Query(100, ge=1, le=500),
    offset: int = Query(0, ge=0),
    date_from: str | None = Query(None),
    date_to: str | None = Query(None),
    firm_client_id: str | None = Query(None),
):
    _user_id, _role, company_id = require_builder(request)

    conn = await _load_pennylane_connection_or_404(connection_id, company_id)
    if not conn:
        return JSONResponse({"success": False, "error": "Connection not found"}, status_code=404)

    transactions = await run_in_thread(
        pennylane_transactions_repo.list_by_connection,
        connection_id,
        date_from,
        date_to,
        limit,
        offset,
        firm_client_id=firm_client_id,
    )

    return JSONResponse({"success": True, "transactions": transactions, "count": len(transactions)})
