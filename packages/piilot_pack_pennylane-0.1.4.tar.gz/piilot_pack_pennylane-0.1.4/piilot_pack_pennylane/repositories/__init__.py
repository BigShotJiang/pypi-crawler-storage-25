"""Repositories for the Pennylane plugin.

All tables live in the ``integrations_pennylane`` PG schema, owned by
this plugin. Each repository keeps the column allowlist explicit and
uses the shared helpers from :mod:`._base` (DB pool + RLS context).

Note
----
``_base.py`` currently duplicates the core's pool and RLS helpers
verbatim. This is a deliberate, documented short-term trade-off:
the plugin stays functionally equivalent to the in-tree
implementation while SDK v0.2 is validated on a real integration.
Once ``piilot.sdk.db.cursor()`` is proven in production by this
plugin, ``_base.py`` should collapse into thin wrappers around the
SDK primitives (tracked as SDK v0.3 task).
"""

from __future__ import annotations

from .pennylane_customers import (
    PennylaneCustomersRepository,
    pennylane_customers_repo,
)
from .pennylane_firm_clients import (
    PennylaneFirmClientsRepository,
    pennylane_firm_clients_repo,
)
from .pennylane_invoices import (
    PennylaneInvoicesRepository,
    pennylane_invoices_repo,
)
from .pennylane_supplier_invoices import (
    PennylaneSupplierInvoicesRepository,
    pennylane_supplier_invoices_repo,
)
from .pennylane_suppliers import (
    PennylaneSuppliersRepository,
    pennylane_suppliers_repo,
)
from .pennylane_transactions import (
    PennylaneTransactionsRepository,
    pennylane_transactions_repo,
)

__all__ = [
    # Classes
    "PennylaneCustomersRepository",
    "PennylaneFirmClientsRepository",
    "PennylaneInvoicesRepository",
    "PennylaneSupplierInvoicesRepository",
    "PennylaneSuppliersRepository",
    "PennylaneTransactionsRepository",
    # Singletons (used by sync.py + future service layers)
    "pennylane_customers_repo",
    "pennylane_firm_clients_repo",
    "pennylane_invoices_repo",
    "pennylane_supplier_invoices_repo",
    "pennylane_suppliers_repo",
    "pennylane_transactions_repo",
]
