"""Repository for integrations_pennylane.firm_clients.

Stores the list of client companies reachable through a Pennylane Firm API
connection (accounting-firm mode). Each row represents one client company
of the firm — data belonging to that client (invoices, customers, etc.)
is linked via firm_client_id on the existing Pennylane tables.

Scoped by ``connection_id`` since PLT-8 phase 6 — a tenant may hold
several Firm connections, each listing its own set of client companies.
"""

from __future__ import annotations

import logging
from typing import Any

from ._base import Json, _fetchall, _fetchone, _get_conn, execute_values

logger = logging.getLogger(__name__)


class PennylaneFirmClientsRepository:
    """CRUD + upsert for Pennylane Firm client companies."""

    _TABLE = "integrations_pennylane.firm_clients"

    _COLS = (
        "id, company_id, connection_id, external_company_id, company_name, "
        "siren, siret, legal_form, fiscal_year_start, is_active, raw_data, "
        "synced_at, created_at, updated_at"
    )

    def list_by_connection(
        self,
        connection_id: str,
        active_only: bool = True,
    ) -> list[dict]:
        sql = f"SELECT {self._COLS} FROM {self._TABLE} WHERE connection_id = %s"
        params: list[Any] = [connection_id]
        if active_only:
            sql += " AND is_active = true"
        sql += " ORDER BY company_name ASC"
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return _fetchall(cur)

    def get(self, firm_client_id: str) -> dict | None:
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"SELECT {self._COLS} FROM {self._TABLE} WHERE id = %s",
                    (firm_client_id,),
                )
                return _fetchone(cur)

    def get_by_external_id(
        self,
        connection_id: str,
        external_company_id: str,
    ) -> dict | None:
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"SELECT {self._COLS} FROM {self._TABLE} " "WHERE connection_id = %s AND external_company_id = %s",
                    (connection_id, external_company_id),
                )
                return _fetchone(cur)

    def batch_upsert(
        self,
        company_id: str,
        connection_id: str,
        rows: list[dict],
    ) -> int:
        """Upsert many firm clients in a single INSERT ... ON CONFLICT statement.

        Expected payload per row:
            external_company_id, company_name, siren, siret, legal_form,
            fiscal_year_start, is_active, raw_data, synced_at.
        """
        if not rows:
            return 0
        values = [
            (
                company_id,
                connection_id,
                r["external_company_id"],
                r.get("company_name", ""),
                r.get("siren"),
                r.get("siret"),
                r.get("legal_form"),
                r.get("fiscal_year_start"),
                r.get("is_active", True),
                Json(r.get("raw_data") or {}),
                r.get("synced_at"),
            )
            for r in rows
        ]
        sql = f"""INSERT INTO {self._TABLE}
            (company_id, connection_id, external_company_id, company_name,
             siren, siret, legal_form, fiscal_year_start, is_active,
             raw_data, synced_at)
            VALUES %s
            ON CONFLICT (connection_id, external_company_id) DO UPDATE SET
                company_name = EXCLUDED.company_name,
                siren = EXCLUDED.siren,
                siret = EXCLUDED.siret,
                legal_form = EXCLUDED.legal_form,
                fiscal_year_start = EXCLUDED.fiscal_year_start,
                is_active = EXCLUDED.is_active,
                raw_data = EXCLUDED.raw_data,
                synced_at = EXCLUDED.synced_at"""
        with _get_conn() as conn:
            with conn.cursor() as cur:
                execute_values(cur, sql, values, page_size=200)
                return len(rows)

    def count_by_connection(self, connection_id: str) -> int:
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"SELECT COUNT(*) AS cnt FROM {self._TABLE} " "WHERE connection_id = %s AND is_active = true",
                    (connection_id,),
                )
                row = cur.fetchone()
                return row["cnt"] if row else 0

    def search(
        self,
        connection_id: str,
        query: str,
        limit: int = 20,
    ) -> list[dict]:
        """Fuzzy search by company_name or siren, prefix matches ranked first.

        Used by agent tools (Phase 3) to resolve a user-supplied client name
        like 'DURAND' into a firm_client_id.
        """
        term = query.strip()
        pattern = f"%{term}%"
        prefix = f"{term}%"
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"SELECT {self._COLS} FROM {self._TABLE} "
                    "WHERE connection_id = %s AND is_active = true "
                    "AND (company_name ILIKE %s OR siren ILIKE %s) "
                    "ORDER BY "
                    "  CASE WHEN company_name ILIKE %s THEN 0 ELSE 1 END, "
                    "  company_name ASC "
                    "LIMIT %s",
                    (connection_id, pattern, pattern, prefix, limit),
                )
                return _fetchall(cur)

    def delete_by_connection(self, connection_id: str) -> int:
        """Purge all firm clients attached to a connection.

        Called when the user disconnects a Firm integration. ON DELETE CASCADE
        propagates to linked invoices / customers / suppliers / transactions
        via firm_client_id FK.
        """
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"DELETE FROM {self._TABLE} WHERE connection_id = %s",
                    (connection_id,),
                )
                return cur.rowcount


pennylane_firm_clients_repo = PennylaneFirmClientsRepository()

__all__ = [
    "PennylaneFirmClientsRepository",
    "pennylane_firm_clients_repo",
]
