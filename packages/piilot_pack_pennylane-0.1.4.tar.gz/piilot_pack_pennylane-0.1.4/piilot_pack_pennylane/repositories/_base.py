"""Shared infrastructure for all repositories — pool, helpers, RLS context."""

from __future__ import annotations

import asyncio
import logging
import os
import threading
import uuid as _uuid_mod
from contextlib import contextmanager
from datetime import UTC, datetime
from decimal import Decimal
from typing import Any

import dotenv
import psycopg2
import psycopg2.extras
import psycopg2.pool
from psycopg2.extras import Json, RealDictCursor, execute_values  # noqa: F401

dotenv.load_dotenv()

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# RLS user context (thread-local)
# ---------------------------------------------------------------------------

_rls_local = threading.local()


def set_rls_user(user_id: str | None) -> None:
    """Set the current user ID for RLS policies (thread-local, transaction-scoped).

    Call this immediately after JWT validation in protected routes.
    The value is forwarded as app.current_user_id via SET LOCAL in each transaction,
    enabling RLS policies on piilot_app connections.
    """
    _rls_local.user_id = str(user_id) if user_id else None


def clear_rls_user() -> None:
    """Clear the RLS user context (call at end of request if needed)."""
    _rls_local.user_id = None


async def run_in_thread(func, *args, **kwargs):
    """Run a sync function in a thread pool, propagating RLS user context.

    threading.local() is per-thread, so when asyncio.to_thread() dispatches
    work to a pool thread the RLS user_id set on the event-loop thread is
    invisible.  This helper captures the current user_id, re-sets it inside
    the worker thread, runs *func*, and cleans up afterwards.
    """
    uid = getattr(_rls_local, "user_id", None)

    def _wrapper():
        if uid:
            set_rls_user(uid)
        try:
            return func(*args, **kwargs)
        finally:
            clear_rls_user()

    return await asyncio.to_thread(_wrapper)


# ---------------------------------------------------------------------------
# Connection pool
# ---------------------------------------------------------------------------

_pool: psycopg2.pool.ThreadedConnectionPool | None = None
_pool_lock = threading.Lock()


def _get_pool() -> psycopg2.pool.ThreadedConnectionPool:
    """Lazy pool initialisation — created on first DB call, not at import time."""
    global _pool
    if _pool is None:
        with _pool_lock:
            if _pool is None:
                DATABASE_URL = os.getenv("DATABASE_URL")
                if not DATABASE_URL:
                    raise RuntimeError("DATABASE_URL environment variable is not set")
                _pool = psycopg2.pool.ThreadedConnectionPool(
                    minconn=2,
                    maxconn=10,
                    dsn=DATABASE_URL,
                    cursor_factory=RealDictCursor,
                )
    return _pool


@contextmanager
def _get_conn():
    """Yield a connection from the pool, set RLS context, commit on success."""
    conn = _get_pool().getconn()
    try:
        # Inject current_user_id as a transaction-scoped session variable.
        # SET LOCAL resets automatically on COMMIT/ROLLBACK — safe with pooling.
        uid = getattr(_rls_local, "user_id", None) or ""
        with conn.cursor() as cur:
            cur.execute("SELECT set_config('app.current_user_id', %s, true)", (uid,))
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        _pool.putconn(conn)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _serialize(val: Any) -> Any:
    """Recursively convert psycopg2 types to JSON-serializable Python types."""
    if isinstance(val, datetime):
        return val.isoformat()
    if isinstance(val, _uuid_mod.UUID):
        return str(val)
    if isinstance(val, Decimal):
        return float(val)
    if isinstance(val, dict):
        return {k: _serialize(v) for k, v in val.items()}
    if isinstance(val, list):
        return [_serialize(v) for v in val]
    return val


def _fetchone(cur) -> dict | None:
    row = cur.fetchone()
    if not row:
        return None
    return {k: _serialize(v) for k, v in dict(row).items()}


def _fetchall(cur) -> list[dict]:
    return [{k: _serialize(v) for k, v in dict(row).items()} for row in cur.fetchall()]


def _vec(embedding: list[float]) -> str:
    """Convert a float list to a PostgreSQL vector literal string."""
    return "[" + ",".join(str(x) for x in embedding) + "]"


def _now() -> datetime:
    return datetime.now(UTC)


def _json_val(v: Any) -> Any:
    """Wrap dicts/lists in Json() for JSONB columns; pass other types as-is."""
    if isinstance(v, (dict, list)):
        return Json(v)
    return v


def close_pool() -> None:
    """Close the connection pool gracefully (call on app shutdown)."""
    global _pool
    if _pool is not None:
        try:
            _pool.closeall()
            logger.info("DB connection pool closed")
        except Exception:
            logger.warning("Error closing DB pool", exc_info=True)
        _pool = None
