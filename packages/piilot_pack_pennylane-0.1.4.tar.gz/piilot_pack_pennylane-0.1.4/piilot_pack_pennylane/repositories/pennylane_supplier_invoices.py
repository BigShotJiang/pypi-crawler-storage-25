"""Repository for integrations_pennylane.supplier_invoices.

Supplier invoices (factures d'achat) are distinct from customer
invoices and live in their own table. Shape mirrors
``pennylane_invoices`` with ``supplier_name`` in place of
``customer_name``.
"""

from __future__ import annotations

import logging
from datetime import datetime

from ._base import Json, _fetchall, _fetchone, _get_conn, _json_val, execute_values

logger = logging.getLogger(__name__)


class PennylaneSupplierInvoicesRepository:
    """CRUD + upsert + aggregation for Pennylane supplier invoices."""

    _TABLE = "integrations_pennylane.supplier_invoices"

    _COLS = (
        "id, company_id, connection_id, external_id, invoice_number, invoice_type, "
        "status, supplier_name, supplier_external_id, "
        "issue_date, due_date, paid_date, currency, "
        "amount_excl_tax, tax_amount, amount_incl_tax, amount_remaining, "
        "line_items, raw_data, firm_client_id, synced_at, created_at, updated_at"
    )

    def upsert(
        self,
        company_id: str,
        connection_id: str,
        external_id: str,
        *,
        invoice_number: str | None = None,
        invoice_type: str = "supplier_invoice",
        status: str | None = None,
        supplier_name: str | None = None,
        supplier_external_id: str | None = None,
        issue_date: str | None = None,
        due_date: str | None = None,
        paid_date: str | None = None,
        currency: str = "EUR",
        amount_excl_tax: float | None = None,
        tax_amount: float | None = None,
        amount_incl_tax: float | None = None,
        amount_remaining: float | None = None,
        line_items: list | None = None,
        raw_data: dict | None = None,
        firm_client_id: str | None = None,
        synced_at: datetime | None = None,
    ) -> dict:
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""INSERT INTO {self._TABLE}
                    (company_id, connection_id, external_id, invoice_number, invoice_type,
                     status, supplier_name, supplier_external_id,
                     issue_date, due_date, paid_date, currency,
                     amount_excl_tax, tax_amount, amount_incl_tax, amount_remaining,
                     line_items, raw_data, firm_client_id, synced_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (connection_id, external_id) DO UPDATE SET
                        invoice_number = EXCLUDED.invoice_number,
                        invoice_type = EXCLUDED.invoice_type,
                        status = EXCLUDED.status,
                        supplier_name = EXCLUDED.supplier_name,
                        supplier_external_id = EXCLUDED.supplier_external_id,
                        issue_date = EXCLUDED.issue_date,
                        due_date = EXCLUDED.due_date,
                        paid_date = EXCLUDED.paid_date,
                        currency = EXCLUDED.currency,
                        amount_excl_tax = EXCLUDED.amount_excl_tax,
                        tax_amount = EXCLUDED.tax_amount,
                        amount_incl_tax = EXCLUDED.amount_incl_tax,
                        amount_remaining = EXCLUDED.amount_remaining,
                        line_items = EXCLUDED.line_items,
                        raw_data = EXCLUDED.raw_data,
                        firm_client_id = EXCLUDED.firm_client_id,
                        synced_at = EXCLUDED.synced_at
                    RETURNING {self._COLS}""",
                    (
                        company_id,
                        connection_id,
                        external_id,
                        invoice_number,
                        invoice_type,
                        status,
                        supplier_name,
                        supplier_external_id,
                        issue_date,
                        due_date,
                        paid_date,
                        currency,
                        amount_excl_tax,
                        tax_amount,
                        amount_incl_tax,
                        amount_remaining,
                        _json_val(line_items or []),
                        _json_val(raw_data),
                        firm_client_id,
                        synced_at,
                    ),
                )
                return _fetchone(cur) or {}

    def batch_upsert(
        self,
        company_id: str,
        connection_id: str,
        rows: list[dict],
        firm_client_id: str | None = None,
    ) -> int:
        if not rows:
            return 0
        values = [
            (
                company_id,
                connection_id,
                r["external_id"],
                r.get("invoice_number"),
                r.get("invoice_type", "supplier_invoice"),
                r.get("status"),
                r.get("supplier_name"),
                r.get("supplier_external_id"),
                r.get("issue_date"),
                r.get("due_date"),
                r.get("paid_date"),
                r.get("currency", "EUR"),
                r.get("amount_excl_tax"),
                r.get("tax_amount"),
                r.get("amount_incl_tax"),
                r.get("amount_remaining"),
                Json(r.get("line_items") or []),
                Json(r.get("raw_data") or {}),
                firm_client_id,
                r.get("synced_at"),
            )
            for r in rows
        ]
        sql = f"""INSERT INTO {self._TABLE}
            (company_id, connection_id, external_id, invoice_number, invoice_type,
             status, supplier_name, supplier_external_id,
             issue_date, due_date, paid_date, currency,
             amount_excl_tax, tax_amount, amount_incl_tax, amount_remaining,
             line_items, raw_data, firm_client_id, synced_at)
            VALUES %s
            ON CONFLICT (connection_id, external_id) DO UPDATE SET
                invoice_number = EXCLUDED.invoice_number,
                invoice_type = EXCLUDED.invoice_type,
                status = EXCLUDED.status,
                supplier_name = EXCLUDED.supplier_name,
                supplier_external_id = EXCLUDED.supplier_external_id,
                issue_date = EXCLUDED.issue_date,
                due_date = EXCLUDED.due_date,
                paid_date = EXCLUDED.paid_date,
                currency = EXCLUDED.currency,
                amount_excl_tax = EXCLUDED.amount_excl_tax,
                tax_amount = EXCLUDED.tax_amount,
                amount_incl_tax = EXCLUDED.amount_incl_tax,
                amount_remaining = EXCLUDED.amount_remaining,
                line_items = EXCLUDED.line_items,
                raw_data = EXCLUDED.raw_data,
                firm_client_id = EXCLUDED.firm_client_id,
                synced_at = EXCLUDED.synced_at"""
        with _get_conn() as conn:
            with conn.cursor() as cur:
                execute_values(cur, sql, values, page_size=200)
                return len(rows)

    def list_by_connection(
        self,
        connection_id: str,
        status: str | None = None,
        limit: int = 100,
        offset: int = 0,
        firm_client_id: str | None = None,
    ) -> list[dict]:
        sql = f"SELECT {self._COLS} FROM {self._TABLE} WHERE connection_id = %s"
        params: list = [connection_id]
        if status:
            sql += " AND status = %s"
            params.append(status)
        if firm_client_id is not None:
            sql += " AND firm_client_id = %s"
            params.append(firm_client_id)
        sql += " ORDER BY issue_date DESC LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return _fetchall(cur)

    def aggregate_by_counterparty(
        self,
        connection_id: str,
        *,
        date_from: str | None = None,
        date_to: str | None = None,
        status: str | None = None,
        limit: int = 10,
        firm_client_id: str | None = None,
    ) -> list[dict]:
        """Aggregate supplier invoices: total spend per supplier, sorted desc.

        Returns rows ``{counterparty, total, invoice_count}`` ordered by
        ``total`` descending. ``COALESCE(amount_incl_tax, 0)`` is used so
        rows with a missing total still contribute their count.
        """
        sql = (
            f"SELECT COALESCE(supplier_name, '—') AS counterparty, "
            f"COALESCE(SUM(amount_incl_tax), 0) AS total, "
            f"COUNT(*) AS invoice_count "
            f"FROM {self._TABLE} WHERE connection_id = %s"
        )
        params: list = [connection_id]
        if status:
            sql += " AND status = %s"
            params.append(status)
        if date_from:
            sql += " AND issue_date >= %s"
            params.append(date_from)
        if date_to:
            sql += " AND issue_date <= %s"
            params.append(date_to)
        if firm_client_id is not None:
            sql += " AND firm_client_id = %s"
            params.append(firm_client_id)
        sql += " GROUP BY supplier_name ORDER BY total DESC LIMIT %s"
        params.append(limit)
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return _fetchall(cur)


pennylane_supplier_invoices_repo = PennylaneSupplierInvoicesRepository()
