"""Repository for integrations_pennylane.customers."""

from __future__ import annotations

import logging
from datetime import datetime

from ._base import Json, _fetchall, _fetchone, _get_conn, _json_val, execute_values

logger = logging.getLogger(__name__)


class PennylaneCustomersRepository:
    """CRUD + upsert for Pennylane synced customers.

    Scoped by ``connection_id`` since PLT-8 phase 6.
    """

    _TABLE = "integrations_pennylane.customers"

    _COLS = (
        "id, company_id, connection_id, external_id, name, email, phone, "
        "address, city, zip_code, country, siret, vat_number, "
        "raw_data, firm_client_id, synced_at, created_at, updated_at"
    )

    def upsert(
        self,
        company_id: str,
        connection_id: str,
        external_id: str,
        *,
        name: str = "",
        email: str | None = None,
        phone: str | None = None,
        address: str | None = None,
        city: str | None = None,
        zip_code: str | None = None,
        country: str | None = None,
        siret: str | None = None,
        vat_number: str | None = None,
        raw_data: dict | None = None,
        firm_client_id: str | None = None,
        synced_at: datetime | None = None,
    ) -> dict:
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""INSERT INTO {self._TABLE}
                    (company_id, connection_id, external_id, name, email, phone,
                     address, city, zip_code, country, siret, vat_number,
                     raw_data, firm_client_id, synced_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (connection_id, external_id) DO UPDATE SET
                        name = EXCLUDED.name,
                        email = EXCLUDED.email,
                        phone = EXCLUDED.phone,
                        address = EXCLUDED.address,
                        city = EXCLUDED.city,
                        zip_code = EXCLUDED.zip_code,
                        country = EXCLUDED.country,
                        siret = EXCLUDED.siret,
                        vat_number = EXCLUDED.vat_number,
                        raw_data = EXCLUDED.raw_data,
                        firm_client_id = EXCLUDED.firm_client_id,
                        synced_at = EXCLUDED.synced_at
                    RETURNING {self._COLS}""",
                    (
                        company_id,
                        connection_id,
                        external_id,
                        name,
                        email,
                        phone,
                        address,
                        city,
                        zip_code,
                        country,
                        siret,
                        vat_number,
                        _json_val(raw_data),
                        firm_client_id,
                        synced_at,
                    ),
                )
                return _fetchone(cur) or {}

    def batch_upsert(
        self,
        company_id: str,
        connection_id: str,
        rows: list[dict],
        firm_client_id: str | None = None,
    ) -> int:
        """Upsert many customers in a single INSERT ... ON CONFLICT statement."""
        if not rows:
            return 0
        values = [
            (
                company_id,
                connection_id,
                r["external_id"],
                r.get("name", ""),
                r.get("email"),
                r.get("phone"),
                r.get("address"),
                r.get("city"),
                r.get("zip_code"),
                r.get("country"),
                r.get("siret"),
                r.get("vat_number"),
                Json(r.get("raw_data") or {}),
                firm_client_id,
                r.get("synced_at"),
            )
            for r in rows
        ]
        sql = f"""INSERT INTO {self._TABLE}
            (company_id, connection_id, external_id, name, email, phone,
             address, city, zip_code, country, siret, vat_number,
             raw_data, firm_client_id, synced_at)
            VALUES %s
            ON CONFLICT (connection_id, external_id) DO UPDATE SET
                name = EXCLUDED.name,
                email = EXCLUDED.email,
                phone = EXCLUDED.phone,
                address = EXCLUDED.address,
                city = EXCLUDED.city,
                zip_code = EXCLUDED.zip_code,
                country = EXCLUDED.country,
                siret = EXCLUDED.siret,
                vat_number = EXCLUDED.vat_number,
                raw_data = EXCLUDED.raw_data,
                firm_client_id = EXCLUDED.firm_client_id,
                synced_at = EXCLUDED.synced_at"""
        with _get_conn() as conn:
            with conn.cursor() as cur:
                execute_values(cur, sql, values, page_size=200)
                return len(rows)

    def list_by_connection(
        self,
        connection_id: str,
        limit: int = 100,
        offset: int = 0,
        firm_client_id: str | None = None,
    ) -> list[dict]:
        sql = f"SELECT {self._COLS} FROM {self._TABLE} WHERE connection_id = %s"
        params: list = [connection_id]
        if firm_client_id is not None:
            sql += " AND firm_client_id = %s"
            params.append(firm_client_id)
        sql += " ORDER BY name ASC LIMIT %s OFFSET %s"
        params.extend([limit, offset])
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return _fetchall(cur)

    def get(self, customer_id: str) -> dict | None:
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"SELECT {self._COLS} FROM {self._TABLE} WHERE id = %s",
                    (customer_id,),
                )
                return _fetchone(cur)

    def search(
        self,
        connection_id: str,
        name: str,
        limit: int = 20,
        firm_client_id: str | None = None,
    ) -> list[dict]:
        pattern = f"%{name}%"
        sql = f"SELECT {self._COLS} FROM {self._TABLE} " "WHERE connection_id = %s AND name ILIKE %s"
        params: list = [connection_id, pattern]
        if firm_client_id is not None:
            sql += " AND firm_client_id = %s"
            params.append(firm_client_id)
        sql += " ORDER BY name ASC LIMIT %s"
        params.append(limit)
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return _fetchall(cur)

    def count_by_connection(
        self,
        connection_id: str,
        firm_client_id: str | None = None,
    ) -> int:
        sql = f"SELECT COUNT(*) AS cnt FROM {self._TABLE} WHERE connection_id = %s"
        params: list = [connection_id]
        if firm_client_id is not None:
            sql += " AND firm_client_id = %s"
            params.append(firm_client_id)
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                row = cur.fetchone()
                return row["cnt"] if row else 0


pennylane_customers_repo = PennylaneCustomersRepository()
