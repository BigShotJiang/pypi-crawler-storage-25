"""Repository for integrations_pennylane.transactions."""

from __future__ import annotations

import logging
from datetime import datetime

from ._base import Json, _fetchall, _fetchone, _get_conn, _json_val, execute_values

logger = logging.getLogger(__name__)


class PennylaneTransactionsRepository:
    """CRUD + upsert for Pennylane synced bank transactions.

    Scoped by ``connection_id`` since PLT-8 phase 6.
    """

    _TABLE = "integrations_pennylane.transactions"

    # No updated_at on this table (snapshots)
    _COLS = (
        "id, company_id, connection_id, external_id, bank_account_name, bank_account_id, "
        "date, label, amount, currency, category, is_reconciled, "
        "raw_data, firm_client_id, synced_at, created_at"
    )

    def upsert(
        self,
        company_id: str,
        connection_id: str,
        external_id: str,
        *,
        bank_account_name: str | None = None,
        bank_account_id: str | None = None,
        date: str | None = None,
        label: str | None = None,
        amount: float = 0,
        currency: str = "EUR",
        category: str | None = None,
        is_reconciled: bool = False,
        raw_data: dict | None = None,
        firm_client_id: str | None = None,
        synced_at: datetime | None = None,
    ) -> dict:
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(
                    f"""INSERT INTO {self._TABLE}
                    (company_id, connection_id, external_id, bank_account_name, bank_account_id,
                     date, label, amount, currency, category, is_reconciled,
                     raw_data, firm_client_id, synced_at)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (connection_id, external_id) DO UPDATE SET
                        bank_account_name = EXCLUDED.bank_account_name,
                        bank_account_id = EXCLUDED.bank_account_id,
                        date = EXCLUDED.date,
                        label = EXCLUDED.label,
                        amount = EXCLUDED.amount,
                        currency = EXCLUDED.currency,
                        category = EXCLUDED.category,
                        is_reconciled = EXCLUDED.is_reconciled,
                        raw_data = EXCLUDED.raw_data,
                        firm_client_id = EXCLUDED.firm_client_id,
                        synced_at = EXCLUDED.synced_at
                    RETURNING {self._COLS}""",
                    (
                        company_id,
                        connection_id,
                        external_id,
                        bank_account_name,
                        bank_account_id,
                        date,
                        label,
                        amount,
                        currency,
                        category,
                        is_reconciled,
                        _json_val(raw_data),
                        firm_client_id,
                        synced_at,
                    ),
                )
                return _fetchone(cur) or {}

    def batch_upsert(
        self,
        company_id: str,
        connection_id: str,
        rows: list[dict],
        firm_client_id: str | None = None,
    ) -> int:
        """Upsert many transactions in a single INSERT ... ON CONFLICT statement."""
        if not rows:
            return 0
        values = [
            (
                company_id,
                connection_id,
                r["external_id"],
                r.get("bank_account_name"),
                r.get("bank_account_id"),
                r.get("date"),
                r.get("label"),
                r.get("amount", 0),
                r.get("currency", "EUR"),
                r.get("category"),
                r.get("is_reconciled", False),
                Json(r.get("raw_data") or {}),
                firm_client_id,
                r.get("synced_at"),
            )
            for r in rows
        ]
        sql = f"""INSERT INTO {self._TABLE}
            (company_id, connection_id, external_id, bank_account_name, bank_account_id,
             date, label, amount, currency, category, is_reconciled,
             raw_data, firm_client_id, synced_at)
            VALUES %s
            ON CONFLICT (connection_id, external_id) DO UPDATE SET
                bank_account_name = EXCLUDED.bank_account_name,
                bank_account_id = EXCLUDED.bank_account_id,
                date = EXCLUDED.date,
                label = EXCLUDED.label,
                amount = EXCLUDED.amount,
                currency = EXCLUDED.currency,
                category = EXCLUDED.category,
                is_reconciled = EXCLUDED.is_reconciled,
                raw_data = EXCLUDED.raw_data,
                firm_client_id = EXCLUDED.firm_client_id,
                synced_at = EXCLUDED.synced_at"""
        with _get_conn() as conn:
            with conn.cursor() as cur:
                execute_values(cur, sql, values, page_size=200)
                return len(rows)

    def list_by_connection(
        self,
        connection_id: str,
        date_from: str | None = None,
        date_to: str | None = None,
        limit: int = 100,
        offset: int = 0,
        firm_client_id: str | None = None,
    ) -> list[dict]:
        with _get_conn() as conn:
            with conn.cursor() as cur:
                conditions = ["connection_id = %s"]
                params: list = [connection_id]
                if date_from:
                    conditions.append("date >= %s")
                    params.append(date_from)
                if date_to:
                    conditions.append("date <= %s")
                    params.append(date_to)
                if firm_client_id is not None:
                    conditions.append("firm_client_id = %s")
                    params.append(firm_client_id)
                params.extend([limit, offset])
                cur.execute(
                    f"SELECT {self._COLS} FROM {self._TABLE} "
                    f"WHERE {' AND '.join(conditions)} "
                    "ORDER BY date DESC LIMIT %s OFFSET %s",
                    params,
                )
                return _fetchall(cur)

    def group_by_label(
        self,
        connection_id: str,
        date_from: str | None = None,
        date_to: str | None = None,
        limit: int = 30,
        firm_client_id: str | None = None,
    ) -> list[dict]:
        """Aggregate transactions by label: count, total credit, total debit."""
        with _get_conn() as conn:
            with conn.cursor() as cur:
                conditions = ["connection_id = %s"]
                params: list = [connection_id]
                if date_from:
                    conditions.append("date >= %s")
                    params.append(date_from)
                if date_to:
                    conditions.append("date <= %s")
                    params.append(date_to)
                if firm_client_id is not None:
                    conditions.append("firm_client_id = %s")
                    params.append(firm_client_id)
                params.append(limit)
                cur.execute(
                    f"""SELECT
                        label,
                        COUNT(*) AS tx_count,
                        COALESCE(SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END), 0) AS total_credit,
                        COALESCE(SUM(CASE WHEN amount < 0 THEN amount ELSE 0 END), 0) AS total_debit,
                        COALESCE(SUM(amount), 0) AS net,
                        MIN(date) AS first_date,
                        MAX(date) AS last_date
                    FROM {self._TABLE}
                    WHERE {' AND '.join(conditions)}
                    GROUP BY label
                    ORDER BY tx_count DESC
                    LIMIT %s""",
                    params,
                )
                return _fetchall(cur)

    def get_balance_summary(
        self,
        connection_id: str,
        firm_client_id: str | None = None,
    ) -> dict:
        """Aggregate credit/debit/net balance for a connection (optionally a firm client)."""
        sql = f"""SELECT
                COUNT(*) AS total_transactions,
                COALESCE(SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END), 0) AS total_credit,
                COALESCE(SUM(CASE WHEN amount < 0 THEN amount ELSE 0 END), 0) AS total_debit,
                COALESCE(SUM(amount), 0) AS net_balance,
                MIN(date) AS earliest_date,
                MAX(date) AS latest_date
            FROM {self._TABLE}
            WHERE connection_id = %s"""
        params: list = [connection_id]
        if firm_client_id is not None:
            sql += " AND firm_client_id = %s"
            params.append(firm_client_id)
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                return _fetchone(cur) or {}

    def count_by_connection(
        self,
        connection_id: str,
        firm_client_id: str | None = None,
    ) -> int:
        sql = f"SELECT COUNT(*) AS cnt FROM {self._TABLE} WHERE connection_id = %s"
        params: list = [connection_id]
        if firm_client_id is not None:
            sql += " AND firm_client_id = %s"
            params.append(firm_client_id)
        with _get_conn() as conn:
            with conn.cursor() as cur:
                cur.execute(sql, params)
                row = cur.fetchone()
                return row["cnt"] if row else 0


pennylane_transactions_repo = PennylaneTransactionsRepository()
