"""
Pennylane agent tools — read synced data, create invoices.

Read tools query local PostgreSQL tables (~5ms). The write tool calls the
Pennylane API directly for immediate feedback.

Since PLT-8 phase 7, the tools are **multi-token aware**. A tenant may have
several Pennylane connections (Company + Firm, multi-Firm, etc.) and the
active connection is resolved via ``active_scope.connection_id`` on the
session. When only one connection is active (most common), it is picked
automatically and persisted into the scope for subsequent turns — the
single-token UX is preserved.

The chat-native flow is driven by three selector tools: ``list_connections``,
``select_connection`` and ``select_firm_client``. The LLM is expected to use
them when the user mentions an integration, or to disambiguate when several
connections cohabit.
"""

from __future__ import annotations

import json
import logging
from datetime import UTC, datetime, timedelta

from langchain_core.tools import StructuredTool
from piilot.sdk import session as sdk_session
from piilot.sdk.connectors import get_connection, list_connections
from piilot.sdk.crypto import decrypt
from piilot.sdk.tools import bind_session

from .repositories import (
    pennylane_customers_repo,
    pennylane_firm_clients_repo,
    pennylane_invoices_repo,
    pennylane_supplier_invoices_repo,
    pennylane_suppliers_repo,
    pennylane_transactions_repo,
)
from .utils import _run_async

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# User-facing messages
# ---------------------------------------------------------------------------

_NO_INTEGRATION = "Aucune integration Pennylane active pour cette entreprise."
_NO_SESSION = "Session introuvable."
_FIRM_NO_SCOPE = (
    "Mode cabinet : precisez le dossier client. Exemple : 'factures de "
    "DURAND MACONNERIE' ou utilisez l'outil pennylane_list_firm_clients "
    "pour voir tous les dossiers."
)
_FIRM_ONLY_TOOL = "Cet outil n'est disponible qu'en mode cabinet (Firm)."


# ---------------------------------------------------------------------------
# Connection resolution — multi-token aware (PLT-8 phase 7)
# ---------------------------------------------------------------------------


def _list_active_pennylane_connections(company_id: str) -> list[dict]:
    """List every active Pennylane connection for a tenant, newest first."""
    # SDK ``list_connections`` already filters by ``is_active=true`` at the
    # DB layer (see integrations_master.connections indexes); we keep the
    # defensive filter to stay identical to the in-tree behaviour in case
    # the core's definition of "active" drifts from the SDK's.
    conns = list_connections(company_id, provider="pennylane")
    return [c for c in conns if c.get("is_active")]


def _format_connections_for_prompt(conns: list[dict]) -> str:
    """Render a compact ``"'<label>' (<mode>)"`` list for user-facing messages."""
    parts = []
    for c in conns:
        mode = (c.get("config") or {}).get("mode", "company")
        parts.append(f"'{c.get('label', '?')}' ({mode})")
    return ", ".join(parts)


def _get_pennylane_context(
    session_id: str,
) -> tuple[str, dict | None, str | None]:
    """Resolve the active Pennylane connection for a session.

    Returns ``(company_id, connection, error)``. When ``error`` is not
    None, the caller should return it verbatim to the user — ``connection``
    will be ``None`` in that case.

    Resolution order:
        1. ``active_scope.connection_id`` → direct lookup (honor the pinned choice)
        2. No pin + single active connection → auto-pick & persist via ``set_scope``
        3. No pin + N≥2 active connections → ambiguity message with labels
        4. No active connection → "no integration" message
    """
    state = sdk_session.get(session_id)
    if not state:
        return "", None, _NO_SESSION
    company_id = state.user_infos.get("_organization_id", "")
    if not company_id:
        return "", None, _NO_SESSION

    # 1. Honor pinned connection if present and still valid
    scope = sdk_session.get_scope(session_id)
    if scope and scope.get("plugin") == "pennylane":
        pinned = scope.get("connection_id")
        if pinned:
            # SDK ``get_connection`` looks up by id only — we enforce the
            # tenant boundary explicitly here (the in-tree
            # ``get_by_id_and_company`` filtered at the repo layer).
            conn = get_connection(pinned)
            if (
                conn
                and conn.get("is_active")
                and conn.get("provider") == "pennylane"
                and str(conn.get("company_id")) == str(company_id)
            ):
                return company_id, conn, None
            # Pin stale (deleted/deactivated/cross-tenant) → fall through and clear
            sdk_session.clear_scope(session_id)

    # 2/3/4 — enumerate active connections
    active = _list_active_pennylane_connections(company_id)
    if not active:
        return company_id, None, _NO_INTEGRATION

    if len(active) == 1:
        conn = active[0]
        sdk_session.set_scope(
            session_id,
            "pennylane",
            connection_id=str(conn["id"]),
            connection_label=conn.get("label"),
        )
        return company_id, conn, None

    # N ≥ 2 — ambiguous
    listing = _format_connections_for_prompt(active)
    msg = (
        f"Vous avez {len(active)} integrations Pennylane : {listing}. "
        "Precisez laquelle utiliser ou appelez pennylane_select_connection."
    )
    return company_id, None, msg


def _resolve_firm_scope(
    connection_id: str,
    session_id: str,
    client_company_hint: str,
) -> tuple[str | None, str | None]:
    """Resolve firm_client_id from a hint or from the active session scope.

    Returns ``(firm_client_id, error_message)``. When ``error_message`` is
    not None, the caller should return it as-is to the user. Never reads
    the session scope when a hint is provided — explicit overrides implicit.
    """
    if client_company_hint:
        matches = pennylane_firm_clients_repo.search(
            connection_id,
            client_company_hint,
            limit=3,
        )
        if not matches:
            return None, f"Aucun dossier client trouve pour '{client_company_hint}'."
        if len(matches) > 1:
            names = ", ".join(m["company_name"] for m in matches)
            return None, (f"Plusieurs dossiers matchent '{client_company_hint}' : {names}. " "Soyez plus precis.")
        return str(matches[0]["id"]), None

    scope = sdk_session.get_scope(session_id)
    if scope and scope.get("plugin") == "pennylane":
        scope_id = scope.get("scope_id")
        if scope_id:
            return scope_id, None

    return None, _FIRM_NO_SCOPE


def _maybe_firm_client_id(
    conn: dict,
    session_id: str,
    client_company: str,
) -> tuple[str | None, str | None]:
    """Return ``(firm_client_id_or_None, error_message_or_None)``.

    In Company mode always returns ``(None, None)`` — ``client_company`` is
    silently ignored (retrocompat). In Firm mode, delegates to
    ``_resolve_firm_scope``.
    """
    mode = (conn.get("config") or {}).get("mode", "company")
    if mode != "firm":
        return None, None
    connection_id = str(conn["id"])
    return _resolve_firm_scope(connection_id, session_id, client_company)


# ---------------------------------------------------------------------------
# System prompt helper — advertise available integrations to the LLM
# ---------------------------------------------------------------------------


def build_pennylane_context_block(company_id: str) -> str:
    """Build the ``--- PENNYLANE ---`` block appended to the agent system prompt.

    Returns an empty string when the tenant has no active Pennylane
    connection (no block injected). With N=1, states the current token.
    With N≥2, instructs the LLM to use ``pennylane_select_connection``.
    """
    if not company_id:
        return ""
    conns = _list_active_pennylane_connections(company_id)
    if not conns:
        return ""

    header = "\n\n--- PENNYLANE ---\n"
    if len(conns) == 1:
        c = conns[0]
        mode = (c.get("config") or {}).get("mode", "company")
        return (
            f"{header}"
            f"Integration active : '{c.get('label', '?')}' (mode {mode}). "
            "Les outils pennylane_* utilisent automatiquement cette integration."
        )

    lines = [f"L'utilisateur a {len(conns)} integrations Pennylane :"]
    for c in conns:
        mode = (c.get("config") or {}).get("mode", "company")
        lines.append(f"- '{c.get('label', '?')}' (mode {mode})")
    lines.append(
        "Si l'utilisateur ne precise pas laquelle, demande-lui ou appelle "
        "pennylane_select_connection pour en fixer une pour la conversation. "
        "Le choix reste actif jusqu'a changement explicite."
    )
    return header + "\n".join(lines)


# ---------------------------------------------------------------------------
# Period parsing (for pennylane_compare_clients period filter)
# ---------------------------------------------------------------------------

_MONTHS_FR = {
    "janvier": 1,
    "fevrier": 2,
    "mars": 3,
    "avril": 4,
    "mai": 5,
    "juin": 6,
    "juillet": 7,
    "aout": 8,
    "septembre": 9,
    "octobre": 10,
    "novembre": 11,
    "decembre": 12,
}


def _parse_period(s: str) -> tuple[str | None, str | None]:
    """Parse a French/ISO period string into ``(date_from, date_to)`` bounds.

    Supported formats (case-insensitive, accents stripped):
    - ``""`` → ``(None, None)`` (no filter)
    - ``"2026"`` → ``("2026-01-01", "2026-12-31")``
    - ``"Q1 2026"`` / ``"T1 2026"`` → ``("2026-01-01", "2026-03-31")``
    - ``"mars 2026"`` → ``("2026-03-01", "2026-03-31")``

    Returns ``(None, None)`` on any parse failure.
    """
    import calendar
    import re
    import unicodedata

    if not s or not s.strip():
        return None, None
    norm = unicodedata.normalize("NFKD", s.strip().lower())
    norm = "".join(c for c in norm if not unicodedata.combining(c))
    norm = re.sub(r"\s+", " ", norm)

    m = re.fullmatch(r"(\d{4})", norm)
    if m:
        y = int(m.group(1))
        return f"{y:04d}-01-01", f"{y:04d}-12-31"

    m = re.fullmatch(r"[qt]([1-4])\s+(\d{4})", norm)
    if m:
        q, y = int(m.group(1)), int(m.group(2))
        start_m, end_m = 3 * q - 2, 3 * q
        last_day = {3: 31, 6: 30, 9: 30, 12: 31}[end_m]
        return f"{y:04d}-{start_m:02d}-01", f"{y:04d}-{end_m:02d}-{last_day}"

    m = re.fullmatch(r"([a-z]+)\s+(\d{4})", norm)
    if m and m.group(1) in _MONTHS_FR:
        mo, y = _MONTHS_FR[m.group(1)], int(m.group(2))
        last_day = calendar.monthrange(y, mo)[1]
        return f"{y:04d}-{mo:02d}-01", f"{y:04d}-{mo:02d}-{last_day:02d}"

    return None, None


def _fmt_amount(value: float | None, currency: str = "EUR") -> str:
    if value is None:
        return "—"
    return f"{value:,.2f} {currency}".replace(",", " ")


def _fmt_date(value) -> str:
    if not value:
        return "—"
    from datetime import date, datetime

    if isinstance(value, (date, datetime)):
        return value.strftime("%d/%m/%Y")
    value = str(value)
    if len(value) >= 10:
        parts = value[:10].split("-")
        if len(parts) == 3:
            return f"{parts[2]}/{parts[1]}/{parts[0]}"
    return value


# ---------------------------------------------------------------------------
# Connection selector tools (chat-native multi-token)
# ---------------------------------------------------------------------------


def pennylane_list_connections_fn(session_id: str = "") -> str:
    """Liste les integrations Pennylane actives du tenant courant."""
    state = sdk_session.get(session_id)
    if not state:
        return _NO_SESSION
    company_id = state.user_infos.get("_organization_id", "")
    if not company_id:
        return _NO_SESSION

    conns = _list_active_pennylane_connections(company_id)
    if not conns:
        return "Aucune integration Pennylane configuree pour cette entreprise."

    scope = sdk_session.get_scope(session_id) or {}
    active_id = scope.get("connection_id") if scope.get("plugin") == "pennylane" else None

    lines = [f"{len(conns)} integration(s) Pennylane :"]
    for c in conns:
        mode = (c.get("config") or {}).get("mode", "company")
        marker = " (active)" if str(c["id"]) == str(active_id) else ""
        lines.append(f"- '{c.get('label', '?')}' (mode {mode}){marker}")
    return "\n".join(lines)


def _resolve_connection_ref(
    company_id: str,
    ref: str,
) -> tuple[dict | None, str | None]:
    """Resolve a user-supplied reference (label or UUID) to a connection.

    Returns ``(connection, error)``. Matches are case-insensitive on
    ``label`` and exact on ``id``. Returns a disambiguation message on
    multiple label matches.
    """
    ref = (ref or "").strip()
    if not ref:
        return None, "Precisez un nom ou un identifiant d'integration."

    conns = _list_active_pennylane_connections(company_id)
    if not conns:
        return None, _NO_INTEGRATION

    # Exact UUID match wins
    for c in conns:
        if str(c["id"]) == ref:
            return c, None

    # Label match — case insensitive, first exact then prefix
    lowered = ref.lower()
    exact = [c for c in conns if (c.get("label") or "").lower() == lowered]
    if len(exact) == 1:
        return exact[0], None
    if len(exact) > 1:
        listing = _format_connections_for_prompt(exact)
        return None, (f"Plusieurs integrations s'appellent '{ref}' : {listing}. " "Precisez l'identifiant exact.")

    prefix = [c for c in conns if (c.get("label") or "").lower().startswith(lowered)]
    if len(prefix) == 1:
        return prefix[0], None
    if len(prefix) > 1:
        listing = _format_connections_for_prompt(prefix)
        return None, (f"Plusieurs integrations commencent par '{ref}' : {listing}. " "Soyez plus precis.")

    listing = _format_connections_for_prompt(conns)
    return None, (f"Aucune integration ne correspond a '{ref}'. " f"Integrations disponibles : {listing}.")


def pennylane_select_connection_fn(
    ref: str = "",
    session_id: str = "",
) -> str:
    """Fixe l'integration Pennylane active pour la conversation.

    Accepte un label (ex: 'Cabinet principal') ou un id UUID. Reinitialise
    le dossier firm client actif (un dossier d'un token n'existe pas dans
    un autre).
    """
    state = sdk_session.get(session_id)
    if not state:
        return _NO_SESSION
    company_id = state.user_infos.get("_organization_id", "")
    if not company_id:
        return _NO_SESSION

    conn, err = _resolve_connection_ref(company_id, ref)
    if err:
        return err
    assert conn is not None

    sdk_session.set_scope(
        session_id,
        "pennylane",
        connection_id=str(conn["id"]),
        connection_label=conn.get("label"),
    )
    mode = (conn.get("config") or {}).get("mode", "company")
    return (
        f"Integration active : '{conn.get('label', '?')}' (mode {mode}). "
        "Le choix reste actif jusqu'a changement explicite."
    )


def pennylane_select_firm_client_fn(
    ref: str = "",
    session_id: str = "",
) -> str:
    """Fixe le dossier client actif pour la conversation (mode Firm uniquement).

    Accepte un nom de societe (recherche fuzzy) ou un id UUID.
    """
    company_id, conn, err = _get_pennylane_context(session_id)
    if err:
        return err
    assert conn is not None

    mode = (conn.get("config") or {}).get("mode", "company")
    if mode != "firm":
        return _FIRM_ONLY_TOOL

    connection_id = str(conn["id"])
    ref = (ref or "").strip()
    if not ref:
        return "Precisez un nom de dossier ou un identifiant."

    # UUID lookup first
    direct = pennylane_firm_clients_repo.get(ref)
    if direct and str(direct.get("connection_id")) == connection_id:
        sdk_session.set_scope(
            session_id,
            "pennylane",
            scope_id=str(direct["id"]),
            scope_label=direct.get("company_name"),
        )
        return f"Dossier actif : {direct.get('company_name', '?')}."

    # Fuzzy name search
    matches = pennylane_firm_clients_repo.search(connection_id, ref, limit=3)
    if not matches:
        return f"Aucun dossier client trouve pour '{ref}'."
    if len(matches) > 1:
        names = ", ".join(m["company_name"] for m in matches)
        return f"Plusieurs dossiers matchent '{ref}' : {names}. " "Soyez plus precis."
    fc = matches[0]
    sdk_session.set_scope(
        session_id,
        "pennylane",
        scope_id=str(fc["id"]),
        scope_label=fc.get("company_name"),
    )
    return f"Dossier actif : {fc.get('company_name', '?')}."


# ---------------------------------------------------------------------------
# Tool 1 — pennylane_list_invoices
# ---------------------------------------------------------------------------


def pennylane_list_invoices_fn(
    status: str = "all",
    limit: int = 20,
    client_company: str = "",
    session_id: str = "",
) -> str:
    """Liste les factures clients depuis les donnees Pennylane synchronisees."""
    company_id, conn, err = _get_pennylane_context(session_id)
    if err:
        return err
    assert conn is not None
    connection_id = str(conn["id"])

    firm_client_id, err = _maybe_firm_client_id(conn, session_id, client_company)
    if err:
        return err

    status_filter = status if status != "all" else None
    invoices = pennylane_invoices_repo.list_by_connection(
        connection_id,
        status=status_filter,
        limit=min(limit, 50),
        firm_client_id=firm_client_id,
    )
    if not invoices:
        return "Aucune facture trouvee."

    lines = [f"Factures ({len(invoices)} resultats) :"]
    for inv in invoices:
        num = inv.get("invoice_number") or inv.get("external_id", "?")
        client = inv.get("customer_name") or "—"
        amount = _fmt_amount(inv.get("amount_incl_tax"), inv.get("currency", "EUR"))
        st = inv.get("status") or "—"
        date = _fmt_date(inv.get("issue_date"))
        lines.append(f"  - {num} — {client} — {amount} — {st} — {date}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Tool 2 — pennylane_get_invoice
# ---------------------------------------------------------------------------


def pennylane_get_invoice_fn(
    invoice_number: str = "",
    session_id: str = "",
) -> str:
    """Detail d'une facture par son numero ou identifiant."""
    company_id, conn, err = _get_pennylane_context(session_id)
    if err:
        return err
    assert conn is not None
    connection_id = str(conn["id"])

    results = pennylane_invoices_repo.search(connection_id, invoice_number, limit=5)
    if not results:
        return f"Aucune facture trouvee pour '{invoice_number}'."

    inv = results[0]
    parts = [
        f"Facture {inv.get('invoice_number', '?')}",
        f"  Type : {inv.get('invoice_type', '—')}",
        f"  Statut : {inv.get('status', '—')}",
        f"  Client : {inv.get('customer_name', '—')}",
        f"  Date emission : {_fmt_date(inv.get('issue_date'))}",
        f"  Echeance : {_fmt_date(inv.get('due_date'))}",
        f"  Date paiement : {_fmt_date(inv.get('paid_date'))}",
        f"  Montant HT : {_fmt_amount(inv.get('amount_excl_tax'))}",
        f"  TVA : {_fmt_amount(inv.get('tax_amount'))}",
        f"  Montant TTC : {_fmt_amount(inv.get('amount_incl_tax'))}",
        f"  Reste a payer : {_fmt_amount(inv.get('amount_remaining'))}",
    ]

    line_items = inv.get("line_items") or []
    if line_items:
        parts.append(f"  Lignes ({len(line_items)}) :")
        for li in line_items[:10]:
            label = li.get("label") or li.get("description") or "—"
            qty = li.get("quantity", "")
            unit_price = li.get("unit_price") or li.get("amount") or ""
            parts.append(f"    - {label} (qte: {qty}, PU: {unit_price})")

    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Tool 3 — pennylane_list_customers
# ---------------------------------------------------------------------------


def pennylane_list_customers_fn(
    query: str = "",
    limit: int = 20,
    client_company: str = "",
    session_id: str = "",
) -> str:
    """Liste les clients Pennylane avec recherche optionnelle par nom."""
    company_id, conn, err = _get_pennylane_context(session_id)
    if err:
        return err
    assert conn is not None
    connection_id = str(conn["id"])

    firm_client_id, err = _maybe_firm_client_id(conn, session_id, client_company)
    if err:
        return err

    if query:
        customers = pennylane_customers_repo.search(
            connection_id,
            query,
            limit=min(limit, 50),
            firm_client_id=firm_client_id,
        )
    else:
        customers = pennylane_customers_repo.list_by_connection(
            connection_id,
            limit=min(limit, 50),
            firm_client_id=firm_client_id,
        )

    if not customers:
        return "Aucun client trouve."

    lines = [f"Clients ({len(customers)} resultats) :"]
    for c in customers:
        name = c.get("name", "—")
        email = c.get("email") or ""
        city = c.get("city") or ""
        siret = c.get("siret") or ""
        info_parts = [name]
        if email:
            info_parts.append(email)
        if city:
            info_parts.append(city)
        if siret:
            info_parts.append(f"SIRET {siret}")
        lines.append(f"  - {' — '.join(info_parts)}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Tool 4 — pennylane_get_balance
# ---------------------------------------------------------------------------


def pennylane_get_balance_fn(
    client_company: str = "",
    session_id: str = "",
) -> str:
    """Solde des comptes bancaires depuis les transactions Pennylane synchronisees."""
    company_id, conn, err = _get_pennylane_context(session_id)
    if err:
        return err
    assert conn is not None
    connection_id = str(conn["id"])

    firm_client_id, err = _maybe_firm_client_id(conn, session_id, client_company)
    if err:
        return err

    summary = pennylane_transactions_repo.get_balance_summary(
        connection_id,
        firm_client_id=firm_client_id,
    )
    if not summary or summary.get("total_transactions", 0) == 0:
        return "Aucune transaction bancaire synchronisee."

    return (
        f"Resume tresorerie :\n"
        f"  Transactions : {summary.get('total_transactions', 0)}\n"
        f"  Credits (entrees) : {_fmt_amount(summary.get('total_credit'))}\n"
        f"  Debits (sorties) : {_fmt_amount(summary.get('total_debit'))}\n"
        f"  Solde net : {_fmt_amount(summary.get('net_balance'))}\n"
        f"  Periode : {_fmt_date(summary.get('earliest_date'))} → {_fmt_date(summary.get('latest_date'))}"
    )


# ---------------------------------------------------------------------------
# Tool 5 — pennylane_list_transactions
# ---------------------------------------------------------------------------


def pennylane_list_transactions_fn(
    days: int = 365,
    limit: int = 20,
    client_company: str = "",
    session_id: str = "",
) -> str:
    """Transactions bancaires des N derniers jours depuis Pennylane (defaut 365j)."""
    company_id, conn, err = _get_pennylane_context(session_id)
    if err:
        return err
    assert conn is not None
    connection_id = str(conn["id"])

    firm_client_id, err = _maybe_firm_client_id(conn, session_id, client_company)
    if err:
        return err

    date_from = (datetime.now(UTC) - timedelta(days=days)).strftime("%Y-%m-%d")
    transactions = pennylane_transactions_repo.list_by_connection(
        connection_id,
        date_from=date_from,
        limit=min(limit, 50),
        firm_client_id=firm_client_id,
    )
    if not transactions:
        return f"Aucune transaction sur les {days} derniers jours."

    lines = [f"Transactions ({len(transactions)} resultats, {days} derniers jours) :"]
    for tx in transactions:
        date = _fmt_date(tx.get("date"))
        label = tx.get("label") or "—"
        amount = _fmt_amount(tx.get("amount"), tx.get("currency", "EUR"))
        bank = tx.get("bank_account_name") or ""
        reconciled = "OK" if tx.get("is_reconciled") else ""
        parts = [date, label, amount]
        if bank:
            parts.append(bank)
        if reconciled:
            parts.append(reconciled)
        lines.append(f"  - {' — '.join(parts)}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Tool 6 — pennylane_transactions_summary
# ---------------------------------------------------------------------------


def pennylane_transactions_summary_fn(
    days: int = 365,
    limit: int = 30,
    client_company: str = "",
    session_id: str = "",
) -> str:
    """Agregation des transactions par label/tiers : nombre, credits, debits, solde net."""
    company_id, conn, err = _get_pennylane_context(session_id)
    if err:
        return err
    assert conn is not None
    connection_id = str(conn["id"])

    firm_client_id, err = _maybe_firm_client_id(conn, session_id, client_company)
    if err:
        return err

    date_from = (datetime.now(UTC) - timedelta(days=days)).strftime("%Y-%m-%d")
    groups = pennylane_transactions_repo.group_by_label(
        connection_id,
        date_from=date_from,
        limit=min(limit, 50),
        firm_client_id=firm_client_id,
    )
    if not groups:
        return f"Aucune transaction sur les {days} derniers jours."

    total_tx = sum(g.get("tx_count", 0) for g in groups)
    lines = [
        f"Transactions par libelle bancaire ({len(groups)} libelles, {total_tx} transactions, {days} derniers jours) :"
    ]
    for g in groups:
        label = g.get("label") or "—"
        count = g.get("tx_count", 0)
        credit = _fmt_amount(g.get("total_credit"))
        debit = _fmt_amount(g.get("total_debit"))
        net = _fmt_amount(g.get("net"))
        first = _fmt_date(g.get("first_date"))
        last = _fmt_date(g.get("last_date"))
        lines.append(f"  - {label} : {count} tx, credits {credit}, debits {debit}, " f"net {net} ({first} → {last})")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Tool 7 — pennylane_list_suppliers
# ---------------------------------------------------------------------------


def pennylane_list_suppliers_fn(
    query: str = "",
    limit: int = 20,
    client_company: str = "",
    session_id: str = "",
) -> str:
    """Liste les fournisseurs Pennylane avec recherche optionnelle par nom."""
    company_id, conn, err = _get_pennylane_context(session_id)
    if err:
        return err
    assert conn is not None
    connection_id = str(conn["id"])

    firm_client_id, err = _maybe_firm_client_id(conn, session_id, client_company)
    if err:
        return err

    if query:
        suppliers = pennylane_suppliers_repo.search(
            connection_id,
            query,
            limit=min(limit, 50),
            firm_client_id=firm_client_id,
        )
    else:
        suppliers = pennylane_suppliers_repo.list_by_connection(
            connection_id,
            limit=min(limit, 50),
            firm_client_id=firm_client_id,
        )

    if not suppliers:
        return "Aucun fournisseur trouve."

    lines = [f"Fournisseurs ({len(suppliers)} resultats) :"]
    for s in suppliers:
        name = s.get("name", "—")
        email = s.get("email") or ""
        siret = s.get("siret") or ""
        vat = s.get("vat_number") or ""
        info_parts = [name]
        if email:
            info_parts.append(email)
        if siret:
            info_parts.append(f"SIRET {siret}")
        if vat:
            info_parts.append(f"TVA {vat}")
        lines.append(f"  - {' — '.join(info_parts)}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Tool — pennylane_invoices_summary (aggregate by counterparty, generic)
# ---------------------------------------------------------------------------

_DIRECTION_CHOICES = ("purchase", "sale")


def pennylane_invoices_summary_fn(
    direction: str = "purchase",
    period: str = "",
    status: str = "all",
    limit: int = 10,
    client_company: str = "",
    session_id: str = "",
) -> str:
    """Top fournisseurs/clients par montant facture sur une periode donnee.

    direction='purchase' agrege les factures d'achat (fournisseurs),
    direction='sale' agrege les factures de vente (clients). Idiomatique
    pour 'quel est mon top fournisseur' ou 'top 5 clients Q1 2026'.
    """
    direction = (direction or "purchase").lower().strip()
    if direction not in _DIRECTION_CHOICES:
        return f"Direction inconnue : '{direction}'. " f"Valeurs autorisees : {', '.join(_DIRECTION_CHOICES)}."

    company_id, conn, err = _get_pennylane_context(session_id)
    if err:
        return err
    assert conn is not None
    connection_id = str(conn["id"])

    firm_client_id, err = _maybe_firm_client_id(conn, session_id, client_company)
    if err:
        return err

    date_from, date_to = _parse_period(period)
    status_filter = status if status and status != "all" else None

    repo = pennylane_supplier_invoices_repo if direction == "purchase" else pennylane_invoices_repo
    rows = repo.aggregate_by_counterparty(
        connection_id,
        date_from=date_from,
        date_to=date_to,
        status=status_filter,
        limit=max(min(limit, 50), 1),
        firm_client_id=firm_client_id,
    )

    if not rows:
        scope = "achats" if direction == "purchase" else "ventes"
        return f"Aucune facture {scope} trouvee pour cette periode."

    label = "fournisseurs (factures d'achat)" if direction == "purchase" else "clients (factures de vente)"
    period_label = f" — periode : {period}" if period else ""
    header = f"Top {len(rows)} {label}{period_label} :"
    lines = [header]
    for r in rows:
        counterparty = r.get("counterparty") or "—"
        total = float(r.get("total") or 0)
        count = int(r.get("invoice_count") or 0)
        lines.append(f"- {counterparty} : {_fmt_amount(total)} ({count} facture{'s' if count > 1 else ''})")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Tool 8 — pennylane_create_invoice (API directe)
# ---------------------------------------------------------------------------


def pennylane_create_invoice_fn(
    customer_id: str = "",
    lines_json: str = "[]",
    session_id: str = "",
) -> str:
    """Cree une facture dans Pennylane (appel API direct).

    lines_json: JSON array avec objets {"label": str, "quantity": int, "unit_price": float}.
    """
    company_id, conn, err = _get_pennylane_context(session_id)
    if err:
        return err
    assert conn is not None

    try:
        lines = json.loads(lines_json)
        if not isinstance(lines, list) or not lines:
            return "Erreur : lines_json doit etre un tableau JSON non vide."
    except json.JSONDecodeError:
        return "Erreur : lines_json n'est pas du JSON valide."

    if not customer_id:
        return "Erreur : customer_id est requis."

    # Decrypt token and call Pennylane API
    token_enc = conn.get("access_token_encrypted", "")
    if not token_enc:
        return "Erreur : token Pennylane manquant."

    try:
        token = decrypt(token_enc)
    except Exception:
        return "Erreur : impossible de dechiffrer le token Pennylane."

    from .client import PennylaneClient

    async def _create():
        client = PennylaneClient(token)
        return await client.create_invoice(
            {
                "customer_id": customer_id,
                "line_items": lines,
            }
        )

    try:
        # Routed through the main FastAPI loop — same rationale as the
        # KB-tool embedding calls (see tools_v2._run_async).
        result = _run_async(_create())
    except Exception as exc:
        logger.error("pennylane_create_invoice failed: %s", exc)
        return f"Erreur lors de la creation de la facture : {exc}"

    invoice_number = result.get("invoice_number", result.get("id", "?"))
    return f"Facture {invoice_number} creee avec succes dans Pennylane."


# ---------------------------------------------------------------------------
# Firm-only tools
# ---------------------------------------------------------------------------


def pennylane_list_firm_clients_fn(
    query: str = "",
    limit: int = 50,
    session_id: str = "",
) -> str:
    """Liste les dossiers clients du cabinet comptable (mode Firm)."""
    company_id, conn, err = _get_pennylane_context(session_id)
    if err:
        return err
    assert conn is not None
    connection_id = str(conn["id"])

    mode = (conn.get("config") or {}).get("mode", "company")
    if mode != "firm":
        return _FIRM_ONLY_TOOL

    cap = min(limit, 100)
    if query:
        clients = pennylane_firm_clients_repo.search(connection_id, query, limit=cap)
    else:
        clients = pennylane_firm_clients_repo.list_by_connection(connection_id)[:cap]

    if not clients:
        return "Aucun dossier client trouve."

    lines = [f"{len(clients)} dossier(s) client(s) :"]
    for c in clients:
        siren = f" (SIREN {c['siren']})" if c.get("siren") else ""
        legal = f" [{c['legal_form']}]" if c.get("legal_form") else ""
        lines.append(f"- {c.get('company_name', '?')}{siren}{legal}")
    return "\n".join(lines)


_SUPPORTED_METRICS = ("revenue", "balance", "invoices_count", "overdue")


def _compute_metric_for_client(
    metric: str,
    connection_id: str,
    firm_client_id: str,
    date_from: str | None,
    date_to: str | None,
) -> tuple[float, str]:
    """Return ``(sortable_numeric_value, human_readable_format)`` for a client.

    ``revenue`` and ``overdue`` iterate listed invoices with limit=500; a
    warning is logged if the cap is hit so ops can surface it.
    """
    if metric == "invoices_count":
        n = pennylane_invoices_repo.count_by_connection(
            connection_id,
            firm_client_id=firm_client_id,
        )
        return float(n), f"{n} factures"

    if metric == "balance":
        summary = pennylane_transactions_repo.get_balance_summary(
            connection_id,
            firm_client_id=firm_client_id,
        )
        net = float(summary.get("net_balance") or 0)
        return net, _fmt_amount(net)

    # revenue / overdue — fetch + Python aggregation
    status_filter = "paid" if metric == "revenue" else "overdue"
    rows = pennylane_invoices_repo.list_by_connection(
        connection_id,
        status=status_filter,
        limit=500,
        firm_client_id=firm_client_id,
    )
    if len(rows) == 500:
        logger.warning(
            "compare_clients: 500-row truncation metric=%s firm_client_id=%s",
            metric,
            firm_client_id,
        )

    if date_from or date_to:

        def _in_range(iso: str) -> bool:
            if not iso:
                return False
            if date_from and iso < date_from:
                return False
            if date_to and iso > date_to:
                return False
            return True

        rows = [r for r in rows if _in_range(str(r.get("issue_date") or ""))]

    if metric == "revenue":
        total = sum(float(r.get("amount_incl_tax") or 0) for r in rows)
        return total, _fmt_amount(total)

    # overdue
    count = len(rows)
    total = sum(float(r.get("amount_incl_tax") or 0) for r in rows)
    return total, f"{count} facture(s) — {_fmt_amount(total)}"


def pennylane_compare_clients_fn(
    metric: str = "revenue",
    period: str = "",
    limit: int = 10,
    session_id: str = "",
) -> str:
    """Compare les dossiers clients du cabinet sur une metrique (mode Firm)."""
    company_id, conn, err = _get_pennylane_context(session_id)
    if err:
        return err
    assert conn is not None
    connection_id = str(conn["id"])

    mode = (conn.get("config") or {}).get("mode", "company")
    if mode != "firm":
        return _FIRM_ONLY_TOOL

    if metric not in _SUPPORTED_METRICS:
        return f"Metrique inconnue : '{metric}'. " f"Valeurs autorisees : {', '.join(_SUPPORTED_METRICS)}."

    date_from, date_to = _parse_period(period)
    clients = pennylane_firm_clients_repo.list_by_connection(connection_id)
    if not clients:
        return "Aucun dossier client."

    rows: list[tuple[str, float, str]] = []
    for c in clients:
        value, fmt = _compute_metric_for_client(
            metric,
            connection_id,
            str(c["id"]),
            date_from,
            date_to,
        )
        rows.append((c.get("company_name", "?"), value, fmt))

    rows.sort(key=lambda r: r[1], reverse=True)
    rows = rows[: max(limit, 1)]

    period_label = f" ({period})" if period else ""
    lines = [f"Top {len(rows)} dossiers par {metric}{period_label} :"]
    for name, _value, fmt in rows:
        lines.append(f"- {name} : {fmt}")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# StructuredTool exports
# ---------------------------------------------------------------------------

pennylane_list_connections = StructuredTool.from_function(
    bind_session(pennylane_list_connections_fn),
    name="pennylane_list_connections",
    description=(
        "Liste les integrations Pennylane actives de l'entreprise avec leur "
        "label, mode (company/firm) et indique celle actuellement active "
        "pour la conversation. A utiliser quand l'utilisateur ne precise pas "
        "quelle integration, ou pour lever une ambiguite avant d'appeler "
        "pennylane_select_connection. "
        "Params: session_id."
    ),
)

pennylane_select_connection = StructuredTool.from_function(
    bind_session(pennylane_select_connection_fn),
    name="pennylane_select_connection",
    description=(
        "Fixe l'integration Pennylane active pour la conversation. "
        "Accepte un label (ex: 'Cabinet principal') ou un id UUID. "
        "La selection reste active pour les messages suivants jusqu'a "
        "changement explicite. Reinitialise automatiquement le dossier "
        "client firm actif (un dossier d'un token n'existe pas dans un autre). "
        "Params: ref (str, label ou uuid), session_id."
    ),
)

pennylane_select_firm_client = StructuredTool.from_function(
    bind_session(pennylane_select_firm_client_fn),
    name="pennylane_select_firm_client",
    description=(
        "Mode cabinet (Firm) uniquement. Fixe le dossier client actif pour "
        "la conversation. Accepte un nom de societe (recherche fuzzy) ou "
        "un id UUID. La selection reste active jusqu'a changement explicite. "
        "Params: ref (str, nom ou uuid), session_id."
    ),
)

pennylane_list_invoices = StructuredTool.from_function(
    bind_session(pennylane_list_invoices_fn),
    name="pennylane_list_invoices",
    description=(
        "Liste les factures clients depuis les donnees Pennylane synchronisees. "
        "En mode cabinet (Firm), preciser client_company (nom ou SIREN) pour "
        "cibler un dossier specifique, sinon utilise le dossier actif de la session. "
        "En mode entreprise (Company), client_company est ignore. "
        "Params: status (all|draft|finalized|paid|overdue), limit (int, defaut 20), "
        "client_company (str optionnel mode Firm), session_id."
    ),
)

pennylane_get_invoice = StructuredTool.from_function(
    bind_session(pennylane_get_invoice_fn),
    name="pennylane_get_invoice",
    description=(
        "Detail d'une facture Pennylane par son numero ou identifiant. "
        "Affiche montants, client, dates, lignes de facturation. "
        "Params: invoice_number (str), session_id (str)."
    ),
)

pennylane_list_customers = StructuredTool.from_function(
    bind_session(pennylane_list_customers_fn),
    name="pennylane_list_customers",
    description=(
        "Liste les clients Pennylane avec recherche optionnelle par nom. "
        "En mode cabinet (Firm), preciser client_company pour cibler un dossier "
        "ou laisser vide pour utiliser le dossier actif de la session. "
        "Params: query (str, vide = tous), limit (int, defaut 20), "
        "client_company (str optionnel mode Firm), session_id."
    ),
)

pennylane_get_balance = StructuredTool.from_function(
    bind_session(pennylane_get_balance_fn),
    name="pennylane_get_balance",
    description=(
        "Resume de tresorerie : solde net, credits, debits, nombre de transactions "
        "depuis les donnees bancaires Pennylane synchronisees. "
        "En mode cabinet (Firm), preciser client_company pour cibler un dossier. "
        "Params: client_company (str optionnel mode Firm), session_id."
    ),
)

pennylane_list_transactions = StructuredTool.from_function(
    bind_session(pennylane_list_transactions_fn),
    name="pennylane_list_transactions",
    description=(
        "Transactions bancaires depuis Pennylane, triees par date decroissante. "
        "En mode cabinet (Firm), preciser client_company pour cibler un dossier. "
        "Params: days (int, defaut 365), limit (int, defaut 20), "
        "client_company (str optionnel mode Firm), session_id."
    ),
)

pennylane_transactions_summary = StructuredTool.from_function(
    bind_session(pennylane_transactions_summary_fn),
    name="pennylane_transactions_summary",
    description=(
        "Agregation des transactions bancaires par libelle de releve : nombre de tx, "
        "total credits, total debits, solde net par libelle. "
        "ATTENTION: les libelles bancaires (ex: 'VIR SALAIRES PERSONNEL') sont differents "
        "des fournisseurs Pennylane. Utilise ce tool pour analyser les mouvements bancaires, "
        "pas pour lister les fournisseurs. "
        "En mode cabinet (Firm), preciser client_company pour cibler un dossier. "
        "Params: days (int, defaut 365), limit (int, defaut 30), "
        "client_company (str optionnel mode Firm), session_id. "
        "Ne pas reduire le limit sauf si demande explicitement."
    ),
)

pennylane_list_suppliers = StructuredTool.from_function(
    bind_session(pennylane_list_suppliers_fn),
    name="pennylane_list_suppliers",
    description=(
        "Liste les fournisseurs Pennylane avec recherche optionnelle par nom. "
        "En mode cabinet (Firm), preciser client_company pour cibler un dossier. "
        "Params: query (str, vide = tous), limit (int, defaut 20), "
        "client_company (str optionnel mode Firm), session_id."
    ),
)

pennylane_create_invoice = StructuredTool.from_function(
    bind_session(pennylane_create_invoice_fn),
    name="pennylane_create_invoice",
    description=(
        "Cree une facture dans Pennylane (appel API direct, pas synchronisation). "
        "Params: customer_id (str, ID Pennylane du client), "
        'lines_json (str, JSON array [{"label": str, "quantity": int, "unit_price": float}]), '
        "session_id (str)."
    ),
)

pennylane_invoices_summary = StructuredTool.from_function(
    bind_session(pennylane_invoices_summary_fn),
    name="pennylane_invoices_summary",
    description=(
        "Agrege les factures synchronisees par contrepartie (fournisseur ou "
        "client) et renvoie le top N trie par montant facture decroissant. "
        "A utiliser pour repondre a 'top fournisseur', 'top 5 clients Q1 2026', "
        "'qui me coute le plus', 'a qui je facture le plus'. "
        "Params: direction (str, 'purchase' = factures d'achat/fournisseurs ou "
        "'sale' = factures de vente/clients ; defaut 'purchase'), "
        "period (str optionnel, ex '2026', 'Q1 2026', 'mars 2026'), "
        "status (str optionnel, 'all'|'paid'|'overdue'|'finalized' ; defaut 'all'), "
        "limit (int, defaut 10, max 50), "
        "client_company (str optionnel mode Firm), session_id. "
        "Renvoie une ligne par contrepartie avec montant total TTC et nombre "
        "de factures. Les libelles bancaires (voir pennylane_transactions_summary) "
        "sont differents des noms de contreparties."
    ),
)

pennylane_list_firm_clients = StructuredTool.from_function(
    bind_session(pennylane_list_firm_clients_fn),
    name="pennylane_list_firm_clients",
    description=(
        "Liste les dossiers clients du cabinet comptable (mode Firm uniquement). "
        "En mode entreprise (Company), l'outil renvoie une erreur. "
        "Utiliser pour repondre a 'liste des dossiers', 'quels clients du cabinet', "
        "ou pour trouver le nom/SIREN d'un dossier avant d'utiliser client_company. "
        "Params: query (str optionnel, recherche par nom ou SIREN), "
        "limit (int, defaut 50), session_id."
    ),
)

pennylane_compare_clients = StructuredTool.from_function(
    bind_session(pennylane_compare_clients_fn),
    name="pennylane_compare_clients",
    description=(
        "Compare les dossiers clients du cabinet sur une metrique (mode Firm). "
        "Utile pour questions transversales : 'top CA Q1 2026', "
        "'quels clients en retard', 'solde tresorerie par dossier'. "
        "Metriques disponibles : revenue (CA facture paye), balance (solde tresorerie), "
        "invoices_count (nombre de factures), overdue (factures en retard). "
        "Period optionnelle : '2026', 'Q1 2026', 'T1 2026', 'mars 2026'. "
        "Params: metric (str), period (str optionnel), limit (int, defaut 10), session_id."
    ),
)
