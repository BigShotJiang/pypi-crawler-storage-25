"""Plugin-local utilities.

Isolated helpers that don't fit elsewhere. Kept intentionally small —
most reusable bits belong upstream in ``piilot.sdk``. If this file
grows past a few functions, promote each one to a dedicated module
(and consider whether it should become an SDK primitive).
"""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Coroutine
from typing import Any

logger = logging.getLogger(__name__)


def _run_async(coro: Coroutine[Any, Any, Any]) -> Any:
    """Run an async coroutine from a synchronous LangChain tool context.

    Resolution order:

    1. Current thread already has a running loop (rare — tool called on
       the event-loop thread) → schedule on it.
    2. Nothing registered → ``asyncio.run`` fallback.

    Notes vs the core's in-tree helper
    ----------------------------------

    The core's ``tools_v2._run_async`` has an extra step that picks up
    the long-lived FastAPI main loop via
    ``backend.services.event_loop.get_main_loop`` — that path binds
    httpx.AsyncClient instances to a stable loop so their finalizers
    don't log ``RuntimeError: Event loop is closed`` on shutdown.

    Plugins are not allowed to import ``backend.*`` so we drop that
    optimization. Impact is limited in practice: only
    ``pennylane_create_invoice_fn`` calls ``_run_async`` — short, single
    HTTP call, no long-lived client leak issue. Candidate SDK v0.3
    primitive (``piilot.sdk.utils.run_async`` or
    ``piilot.sdk.tools.run_async_from_sync_tool``) to recover the main
    loop optimization via a SDK-provided ``get_main_loop`` equivalent.
    """
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop is not None:
        future = asyncio.run_coroutine_threadsafe(coro, loop)
        return future.result(timeout=120)

    # Fallback — short-lived loop via asyncio.run. Acceptable for the
    # current in-tree usage (single HTTP call). May log spurious
    # "Event loop is closed" warnings from async HTTP finalizers outside
    # the FastAPI app context.
    return asyncio.run(coro)
