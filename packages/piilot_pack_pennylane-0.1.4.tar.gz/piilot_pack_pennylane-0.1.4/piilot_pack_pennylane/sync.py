"""Pennylane data synchronization service.

Orchestrates: fetch API → store raw JSON in S3 → upsert into local tables.
Writes progress to Redis for real-time frontend tracking.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import time
from datetime import UTC, datetime, timedelta
from zoneinfo import ZoneInfo

from piilot.sdk import cache as sdk_cache
from piilot.sdk import storage as sdk_storage
from piilot.sdk.connectors import (
    log_sync,
    save_connection,
    update_sync_state,
)
from piilot.sdk.crypto import decrypt

from .client import PennylaneClient
from .repositories import (
    pennylane_customers_repo,
    pennylane_firm_clients_repo,
    pennylane_invoices_repo,
    pennylane_supplier_invoices_repo,
    pennylane_suppliers_repo,
    pennylane_transactions_repo,
)
from .repositories._base import run_in_thread

logger = logging.getLogger(__name__)

_DEFAULT_SYNC_INTERVAL_HOURS = 6
_S3_PREFIX = "integrations"
_DEFAULT_SYNC_TIMES = ["08:00"]
_TOKEN_REFRESH_MARGIN = timedelta(minutes=30)
_PROGRESS_TTL = 300  # 5 minutes


# ---------------------------------------------------------------------------
# Progress helpers
# ---------------------------------------------------------------------------


def _progress_key(connection_id: str) -> str:
    return f"sync:pennylane:{connection_id}"


async def _update_progress(connection_id: str, progress: dict) -> None:
    try:
        await sdk_cache.set(_progress_key(connection_id), progress, ttl=_PROGRESS_TTL)
    except Exception as exc:
        # best-effort: Redis outage must not block the sync
        logger.debug("pennylane sync: progress cache set failed for %s: %s", connection_id, exc)


def _compute_next_sync(config: dict) -> datetime:
    """Compute next sync time from schedule config.

    Times in ``sync_times`` are expressed in the user's local timezone
    (``sync_timezone``, e.g. ``"Europe/Paris"``).  The returned datetime
    is always UTC so it can be compared with ``now()`` in SQL.

    Falls back to the legacy ``sync_interval_hours`` for connections
    created before the schedule feature.
    """
    now_utc = datetime.now(UTC)
    times = config.get("sync_times")

    if not times:
        hours = config.get("sync_interval_hours", _DEFAULT_SYNC_INTERVAL_HOURS)
        return now_utc + timedelta(hours=hours)

    tz_name = config.get("sync_timezone", "UTC")
    try:
        tz = ZoneInfo(tz_name)
    except (KeyError, Exception):
        tz = UTC

    now_local = now_utc.astimezone(tz)

    today_slots: list[datetime] = []
    for t in sorted(times):
        parts = t.split(":")
        h, m = int(parts[0]), int(parts[1]) if len(parts) > 1 else 0
        slot = now_local.replace(hour=h, minute=m, second=0, microsecond=0)
        today_slots.append(slot)

    for slot in today_slots:
        if slot > now_local:
            return slot.astimezone(UTC)
    # All today's slots have passed — first slot tomorrow
    return (today_slots[0] + timedelta(days=1)).astimezone(UTC)


async def get_sync_progress(connection_id: str) -> dict | None:
    """Read current sync progress from cache (called by the route layer)."""
    try:
        return await sdk_cache.get(_progress_key(connection_id))
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


async def sync_pennylane(connection: dict) -> dict:
    """Run a full Pennylane sync for one connection.

    Steps:
        1. Ensure the access token is fresh (refresh if OAuth2)
        2. Fetch all entities in parallel via PennylaneClient
        3. Upload raw JSON to S3 (audit trail)
        4. Batch upsert into integrations_pennylane.* tables
        5. Update connection timestamps
        6. Create a sync_log entry

    Progress is written to Redis at each step for frontend tracking.

    Returns:
        The created sync_log dict.
    """
    company_id = str(connection["company_id"])
    connection_id = str(connection["id"])
    started_at = datetime.now(UTC)
    t_start = time.monotonic()

    # Step 1 — token
    access_token = await _ensure_fresh_token(connection)
    if access_token is None:
        logger.error("sync_pennylane: token unavailable for connection %s — deactivating", connection_id)
        await _update_progress(
            connection_id,
            {
                "status": "error",
                "error": "Token unavailable",
                "started_at": started_at.isoformat(),
            },
        )
        # NOTE(B.3): SDK v0.2 ne fournit pas de primitive pour marquer
        # is_active=False. Le core handler fait encore la désactivation.
        # Trou SDK à combler en v0.3 (ex: connectors.set_active(cid, False)).
        logger.warning(
            "Token unavailable for connection %s — skipping deactivation (SDK v0.2 trou)",
            connection_id,
        )
        return await run_in_thread(
            log_sync,
            connection_id=connection_id,
            company_id=company_id,
            sync_type="full",
            status="error",
            error_message="Token unavailable or refresh failed",
            started_at=started_at,
            completed_at=datetime.now(UTC),
        )

    timestamp = started_at.strftime("%Y-%m-%d_%H")
    results: dict[str, int] = {}
    errors: dict[str, str] = {}

    # --- entity_scopes gating (Lot D) ---
    # Map the UI's 4 toggles (clients / invoices / suppliers /
    # transactions) onto the 5 fetch streams the plugin actually pulls.
    # Missing keys default to True so pre-Lot D connections keep
    # syncing everything (retrocompat).
    raw_scopes = (connection.get("config") or {}).get("entity_scopes") or {}
    scope_enabled = {
        "invoices": bool(raw_scopes.get("invoices", True)),
        "customers": bool(raw_scopes.get("clients", True)),
        "suppliers": bool(raw_scopes.get("suppliers", True)),
        # ``supplier_invoices`` (factures fournisseurs) ride the same UI
        # toggle as customer invoices — "Factures" covers both.
        "supplier_invoices": bool(raw_scopes.get("invoices", True)),
        "transactions": bool(raw_scopes.get("transactions", True)),
    }

    # --- Progress state (shared across concurrent fetchers) ---
    entity_names = ["invoices", "customers", "suppliers", "supplier_invoices", "transactions"]
    progress: dict = {
        "status": "fetching",
        "entities": {
            name: {
                "status": "skipped" if not scope_enabled[name] else "pending",
                "items": 0,
            }
            for name in entity_names
        },
        "started_at": started_at.isoformat(),
    }
    await _update_progress(connection_id, progress)

    # Step 2 — fetch all entities in parallel (shared rate limiter)
    async def _fetch_entity(
        name: str,
        fetch_coro,
    ) -> list[dict]:
        """Wrapper that updates progress around each entity fetch."""
        progress["entities"][name]["status"] = "fetching"
        await _update_progress(connection_id, progress)
        result = await fetch_coro
        count = len(result) if isinstance(result, list) else 0
        progress["entities"][name]["status"] = "done"
        progress["entities"][name]["items"] = count
        await _update_progress(connection_id, progress)
        return result

    async def _tx_on_page(page_num: int, items_so_far: int) -> None:
        """Callback for transactions pagination — fine-grained progress."""
        progress["entities"]["transactions"]["pages_done"] = page_num
        progress["entities"]["transactions"]["items_so_far"] = items_so_far
        await _update_progress(connection_id, progress)

    async with PennylaneClient(access_token) as client:
        t_fetch = time.monotonic()

        # Build one coroutine per enabled entity. Skipped entities are
        # neither fetched (save API quota) nor upserted (keep existing
        # DB rows as-is — a user can re-enable later without data
        # loss).
        enabled = [n for n in entity_names if scope_enabled[n]]
        skipped = [n for n in entity_names if not scope_enabled[n]]
        for name in skipped:
            logger.info(
                "sync_pennylane %s/%s: skipped (entity_scopes disabled)",
                company_id, name,
            )

        fetcher_by_name = {
            "invoices": client.list_all_invoices(),
            "customers": client.list_all_customers(),
            "suppliers": client.list_all_suppliers(),
            "supplier_invoices": client.list_all_supplier_invoices(),
            "transactions": client.list_all_transactions(on_page=_tx_on_page),
        }

        fetch_results: dict[str, list[dict] | Exception] = {}
        if enabled:
            gathered = await asyncio.gather(
                *(_fetch_entity(name, fetcher_by_name[name]) for name in enabled),
                return_exceptions=True,
            )
            for name, result in zip(enabled, gathered, strict=True):
                fetch_results[name] = result

        # Close unused coroutines so asyncio doesn't warn about them.
        for name in skipped:
            coro = fetcher_by_name[name]
            try:
                coro.close()
            except Exception:
                pass

        t_fetch_done = time.monotonic()
        logger.info(
            "sync_pennylane %s: API fetch done in %.1fs",
            company_id,
            t_fetch_done - t_fetch,
        )

    # Step 3-4 — S3 upload + batch upsert per entity
    progress["status"] = "storing"
    await _update_progress(connection_id, progress)

    upsert_map = {
        "invoices": (_parse_invoices_batch, pennylane_invoices_repo),
        "customers": (_parse_customers_batch, pennylane_customers_repo),
        "suppliers": (_parse_suppliers_batch, pennylane_suppliers_repo),
        "supplier_invoices": (_parse_supplier_invoices_batch, pennylane_supplier_invoices_repo),
        "transactions": (_parse_transactions_batch, pennylane_transactions_repo),
    }

    for entity_name, raw_or_exc in fetch_results.items():
        if isinstance(raw_or_exc, Exception):
            logger.error("sync_pennylane %s/%s fetch failed: %s", company_id, entity_name, raw_or_exc)
            errors[entity_name] = str(raw_or_exc)
            continue

        raw_items: list[dict] = raw_or_exc
        try:
            # S3 raw upload (audit trail).
            # SDK storage auto-prefixes keys with ``plugins/pennylane/`` so the
            # effective path becomes ``plugins/pennylane/integrations/{company_id}/pennylane/{timestamp}/...``.
            # The redundant ``pennylane`` segment is harmless and we keep the
            # same intra-key shape as the in-tree version for audit consistency.
            s3_key = f"{_S3_PREFIX}/{company_id}/pennylane/{timestamp}/{entity_name}.json"
            raw_bytes = json.dumps(raw_items, default=str).encode()
            await sdk_storage.put_object(s3_key, raw_bytes, content_type="application/json")

            # Parse + batch upsert
            parse_fn, repo = upsert_map[entity_name]
            parsed_rows = parse_fn(raw_items)
            count = await run_in_thread(
                repo.batch_upsert,
                company_id,
                connection_id,
                parsed_rows,
            )
            results[entity_name] = count
            logger.info("sync_pennylane %s/%s: %d items", company_id, entity_name, count)

        except Exception as exc:
            logger.error("sync_pennylane %s/%s upsert failed: %s", company_id, entity_name, exc)
            errors[entity_name] = str(exc)

    # Step 5 — determine status. Skipped entities count as neither
    # success nor failure — the denominator is the number of
    # *enabled* entities (entity_scopes opt-in).
    enabled_count = sum(1 for v in scope_enabled.values() if v)
    if not errors:
        status = "success"
    elif enabled_count > 0 and len(errors) < enabled_count:
        status = "partial"
    else:
        status = "error"

    total_synced = sum(results.values())
    s3_base = f"{_S3_PREFIX}/{company_id}/pennylane/{timestamp}/"

    # Step 6 — update connection timestamps
    next_sync = _compute_next_sync(connection.get("config", {}))
    await run_in_thread(
        update_sync_state,
        connection_id,
        last_sync_at=started_at,
        next_sync_at=next_sync,
    )

    # Step 7 — sync log
    sync_log = await run_in_thread(
        log_sync,
        connection_id=connection_id,
        company_id=company_id,
        sync_type="full",
        status=status,
        items_synced=total_synced,
        items_failed=len(errors),
        error_message=json.dumps(errors) if errors else None,
        s3_path=s3_base,
        started_at=started_at,
        completed_at=datetime.now(UTC),
    )

    # Final progress update
    progress["status"] = "done" if not errors else "error"
    await _update_progress(connection_id, progress)

    elapsed = time.monotonic() - t_start
    logger.info(
        "sync_pennylane %s: status=%s synced=%d failed=%d elapsed=%.1fs",
        company_id,
        status,
        total_synced,
        len(errors),
        elapsed,
    )
    return sync_log


# ---------------------------------------------------------------------------
# Firm mode — helpers
# ---------------------------------------------------------------------------

_FIRM_ENTITY_NAMES = (
    "invoices",
    "customers",
    "suppliers",
    "supplier_invoices",
    "transactions",
)


def _map_firm_company_to_row(fc: dict, synced_at: datetime) -> dict:
    """Map a Pennylane Firm /companies entry to a firm_clients repo row."""
    siren = fc.get("siren")
    if siren and not str(siren).isdigit():
        siren = None
    siret = fc.get("siret")
    if siret and not str(siret).isdigit():
        siret = None
    return {
        "external_company_id": str(fc["id"]),
        "company_name": fc.get("name") or fc.get("company_name") or "",
        "siren": str(siren) if siren else None,
        "siret": str(siret) if siret else None,
        "legal_form": fc.get("legal_form"),
        "fiscal_year_start": fc.get("fiscal_year_start"),
        "is_active": fc.get("is_active", True),
        "raw_data": fc,
        "synced_at": synced_at,
    }


async def _upload_raw_firm(
    company_id: str,
    firm_client_id: str,
    timestamp: str,
    data: dict[str, list[dict]],
) -> str:
    """Upload per-client raw JSON payloads to S3 for audit trail.

    Writes one file per entity under
    ``integrations/{company_id}/pennylane/firm/{firm_client_id}/{timestamp}/{entity}.json``
    and returns the base prefix (for inclusion in sync_logs.s3_path).
    """
    base = f"{_S3_PREFIX}/{company_id}/pennylane/firm/{firm_client_id}/{timestamp}"
    for entity, items in data.items():
        if not isinstance(items, list):
            continue
        key = f"{base}/{entity}.json"
        payload = json.dumps(items, default=str).encode()
        await sdk_storage.put_object(key, payload, content_type="application/json")
    return f"{base}/"


# ---------------------------------------------------------------------------
# Firm mode — orchestrator
# ---------------------------------------------------------------------------


async def sync_pennylane_firm(connection: dict) -> dict:
    """Run a full Pennylane sync for a Firm-mode connection.

    Iterates over all client companies reachable via the Firm API token and
    upserts per-client data (invoices, customers, suppliers, transactions)
    into integrations_pennylane.* tables tagged with the corresponding
    firm_client_id. Company-mode sync is unaffected.

    Steps:
        1. Ensure the access token is fresh
        2. Fetch list of firm companies → upsert firm_clients
        3. Per client (sequential — rate limit is shared):
           a. Fetch 4 entities in parallel within the client
           b. Upload raw JSON to S3
           c. Batch upsert with firm_client_id
        4. Update connection timestamps
        5. Create a sync_log entry (sync_type="firm_full")

    Returns the created sync_log dict.
    """
    company_id = str(connection["company_id"])
    connection_id = str(connection["id"])
    started_at = datetime.now(UTC)
    t_start = time.monotonic()

    # Step 1 — token
    access_token = await _ensure_fresh_token(connection)
    if access_token is None:
        logger.error(
            "sync_pennylane_firm: token unavailable for connection %s — deactivating",
            connection_id,
        )
        await _update_progress(
            connection_id,
            {
                "status": "error",
                "mode": "firm",
                "error": "Token unavailable",
                "started_at": started_at.isoformat(),
            },
        )
        # NOTE(B.3): SDK v0.2 ne fournit pas de primitive pour marquer
        # is_active=False. Le core handler fait encore la désactivation.
        # Trou SDK à combler en v0.3 (ex: connectors.set_active(cid, False)).
        logger.warning(
            "Token unavailable for connection %s — skipping deactivation (SDK v0.2 trou)",
            connection_id,
        )
        return await run_in_thread(
            log_sync,
            connection_id=connection_id,
            company_id=company_id,
            sync_type="firm_full",
            status="error",
            error_message="Token unavailable or refresh failed",
            started_at=started_at,
            completed_at=datetime.now(UTC),
        )

    timestamp = started_at.strftime("%Y-%m-%d_%H")
    total_synced = 0
    per_client_errors: dict[str, str] = {}

    # Initial progress — fetching the list of clients
    progress: dict = {
        "status": "fetching_clients",
        "mode": "firm",
        "clients_total": 0,
        "clients_done": 0,
        "started_at": started_at.isoformat(),
    }
    await _update_progress(connection_id, progress)

    async with PennylaneClient(access_token) as client:
        # Step 2 — list firm companies and upsert locally
        try:
            firm_companies = await client.list_firm_companies()
        except Exception as exc:
            logger.exception(
                "sync_pennylane_firm %s: list_firm_companies failed",
                company_id,
            )
            await _update_progress(
                connection_id,
                {
                    "status": "error",
                    "mode": "firm",
                    "error": type(exc).__name__,
                    "started_at": started_at.isoformat(),
                },
            )
            return await run_in_thread(
                log_sync,
                connection_id=connection_id,
                company_id=company_id,
                sync_type="firm_full",
                status="error",
                error_message=f"list_firm_companies failed: {type(exc).__name__}",
                started_at=started_at,
                completed_at=datetime.now(UTC),
            )

        firm_rows = [_map_firm_company_to_row(fc, started_at) for fc in firm_companies]
        await run_in_thread(
            pennylane_firm_clients_repo.batch_upsert,
            company_id,
            connection_id,
            firm_rows,
        )

        # Refresh from DB to get the local UUIDs (scoped to this connection)
        db_firm_clients = await run_in_thread(
            pennylane_firm_clients_repo.list_by_connection,
            connection_id,
        )
        clients_total = len(db_firm_clients)
        clients_done = 0

        progress = {
            "status": "syncing",
            "mode": "firm",
            "clients_total": clients_total,
            "clients_done": 0,
            "started_at": started_at.isoformat(),
        }
        await _update_progress(connection_id, progress)

        # Step 3 — per-client sync (sequential; rate limit is shared)
        for firm_client in db_firm_clients:
            external_id = str(firm_client["external_company_id"])
            firm_client_id = str(firm_client["id"])
            client_name = firm_client.get("company_name") or external_id

            progress = {
                **progress,
                "current_client": client_name,
                "current_client_id": firm_client_id,
                "current_entities": {name: {"status": "pending", "items": 0} for name in _FIRM_ENTITY_NAMES},
            }
            await _update_progress(connection_id, progress)

            try:
                # 3a — fetch 5 entities in parallel for this client
                gathered = await asyncio.gather(
                    client.list_company_invoices(external_id),
                    client.list_company_customers(external_id),
                    client.list_company_suppliers(external_id),
                    client.list_company_supplier_invoices(external_id),
                    client.list_company_transactions(external_id),
                    return_exceptions=True,
                )
                raw_by_entity = {
                    name: (res if isinstance(res, list) else [])
                    for name, res in zip(_FIRM_ENTITY_NAMES, gathered, strict=True)
                }

                # 3b — S3 raw upload
                await _upload_raw_firm(
                    company_id,
                    firm_client_id,
                    timestamp,
                    raw_by_entity,
                )

                # 3c — batch upsert with firm_client_id
                for entity_name, parse_fn_and_repo in (
                    ("invoices", (_parse_invoices_batch, pennylane_invoices_repo)),
                    ("customers", (_parse_customers_batch, pennylane_customers_repo)),
                    ("suppliers", (_parse_suppliers_batch, pennylane_suppliers_repo)),
                    ("supplier_invoices", (_parse_supplier_invoices_batch, pennylane_supplier_invoices_repo)),
                    ("transactions", (_parse_transactions_batch, pennylane_transactions_repo)),
                ):
                    parse_fn, repo = parse_fn_and_repo
                    raw_items = raw_by_entity[entity_name]
                    parse_res = gathered[_FIRM_ENTITY_NAMES.index(entity_name)]
                    if isinstance(parse_res, Exception):
                        progress["current_entities"][entity_name] = {
                            "status": "error",
                            "items": 0,
                        }
                        logger.warning(
                            "sync_pennylane_firm %s/%s/%s fetch failed: %s",
                            company_id,
                            external_id,
                            entity_name,
                            type(parse_res).__name__,
                        )
                        continue
                    parsed = parse_fn(raw_items)
                    count = await run_in_thread(
                        repo.batch_upsert,
                        company_id,
                        connection_id,
                        parsed,
                        firm_client_id=firm_client_id,
                    )
                    total_synced += count
                    progress["current_entities"][entity_name] = {
                        "status": "done",
                        "items": count,
                    }
                    await _update_progress(connection_id, progress)

            except Exception as exc:
                logger.exception(
                    "sync_pennylane_firm %s: client %s (%s) failed",
                    company_id,
                    client_name,
                    external_id,
                )
                per_client_errors[external_id] = type(exc).__name__

            clients_done += 1
            progress["clients_done"] = clients_done
            await _update_progress(connection_id, progress)

    # Step 4 — determine final status
    if not per_client_errors:
        status = "success"
    elif len(per_client_errors) < max(clients_total, 1):
        status = "partial"
    else:
        status = "error"

    s3_base = f"{_S3_PREFIX}/{company_id}/pennylane/firm/{timestamp}/"

    # Step 5 — update connection timestamps
    next_sync = _compute_next_sync(connection.get("config", {}))
    await run_in_thread(
        update_sync_state,
        connection_id,
        last_sync_at=started_at,
        next_sync_at=next_sync,
    )

    # Step 6 — sync log
    sync_log = await run_in_thread(
        log_sync,
        connection_id=connection_id,
        company_id=company_id,
        sync_type="firm_full",
        status=status,
        items_synced=total_synced,
        items_failed=len(per_client_errors),
        error_message=json.dumps(per_client_errors) if per_client_errors else None,
        s3_path=s3_base,
        started_at=started_at,
        completed_at=datetime.now(UTC),
    )

    progress = {
        "status": "done" if not per_client_errors else "error",
        "mode": "firm",
        "clients_total": clients_total,
        "clients_done": clients_done,
        "started_at": started_at.isoformat(),
    }
    await _update_progress(connection_id, progress)

    elapsed = time.monotonic() - t_start
    logger.info(
        "sync_pennylane_firm %s: status=%s clients=%d/%d synced=%d elapsed=%.1fs",
        company_id,
        status,
        clients_done - len(per_client_errors),
        clients_total,
        total_synced,
        elapsed,
    )
    return sync_log


# ---------------------------------------------------------------------------
# Token management
# ---------------------------------------------------------------------------


async def _ensure_fresh_token(connection: dict) -> str | None:
    """Decrypt the access token; refresh via OAuth2 if expiring soon."""
    access_enc = connection.get("access_token_encrypted")
    if not access_enc:
        return None

    access_token = decrypt(access_enc)

    if connection["auth_type"] != "oauth2":
        return access_token

    expires_at = connection.get("token_expires_at")
    if not expires_at:
        return access_token

    if isinstance(expires_at, str):
        expires_at = datetime.fromisoformat(expires_at)

    remaining = expires_at - datetime.now(UTC)
    if remaining > _TOKEN_REFRESH_MARGIN:
        return access_token

    refresh_enc = connection.get("refresh_token_encrypted")
    if not refresh_enc:
        logger.error("No refresh token for connection %s", connection["id"])
        return None

    client_id = os.getenv("PENNYLANE_CLIENT_ID", "")
    client_secret = os.getenv("PENNYLANE_CLIENT_SECRET", "")
    if not client_id or not client_secret:
        logger.error("PENNYLANE_CLIENT_ID / PENNYLANE_CLIENT_SECRET not set")
        return None

    old_refresh = decrypt(refresh_enc)

    try:
        token_data = await PennylaneClient.refresh_token(client_id, client_secret, old_refresh)
    except Exception:
        logger.exception("Token refresh failed for connection %s", connection["id"])
        return None

    new_expires = datetime.now(UTC) + timedelta(
        seconds=token_data.get("expires_in", 86400),
    )

    # SDK save_connection auto-encrypts fields declared ``type: secret`` in
    # the connector's credentials_schema. The canonical names
    # ``access_token`` / ``refresh_token`` route to the dedicated
    # ``access_token_encrypted`` / ``refresh_token_encrypted`` columns;
    # ``token_expires_at`` goes to its own column (not encrypted).
    await run_in_thread(
        save_connection,
        company_id=str(connection["company_id"]),
        provider="pennylane",
        auth_type=connection["auth_type"],
        label=connection.get("label") or "Pennylane",
        credentials={
            "access_token": token_data["access_token"],
            "refresh_token": token_data.get("refresh_token", old_refresh),
            "token_expires_at": new_expires,
        },
        connection_id=str(connection["id"]),
    )

    logger.info("Refreshed OAuth token for connection %s", connection["id"])
    return token_data["access_token"]


# ---------------------------------------------------------------------------
# Batch parsers — return list[dict] ready for batch_upsert
# ---------------------------------------------------------------------------


def _parse_invoices_batch(raw_items: list[dict]) -> list[dict]:
    return [_parse_invoice(item) for item in raw_items]


def _parse_customers_batch(raw_items: list[dict]) -> list[dict]:
    return [_parse_customer(item) for item in raw_items]


def _parse_suppliers_batch(raw_items: list[dict]) -> list[dict]:
    return [_parse_supplier(item) for item in raw_items]


def _parse_supplier_invoices_batch(raw_items: list[dict]) -> list[dict]:
    return [_parse_supplier_invoice(item) for item in raw_items]


def _parse_transactions_batch(raw_items: list[dict]) -> list[dict]:
    return [_parse_transaction(item) for item in raw_items]


# ---------------------------------------------------------------------------
# Parsers — map Pennylane API fields to our schema columns
# ---------------------------------------------------------------------------


def _parse_invoice(raw: dict) -> dict:
    customer = raw.get("customer") or {}
    if isinstance(customer, str):
        customer = {}
    now = datetime.now(UTC)
    return {
        "external_id": str(raw["id"]),
        "invoice_number": raw.get("invoice_number"),
        "invoice_type": raw.get("type", "invoice"),
        "status": raw.get("status"),
        "customer_name": customer.get("name") or raw.get("customer_name"),
        "customer_external_id": str(customer.get("id", "")) if customer.get("id") else None,
        "issue_date": raw.get("date") or raw.get("issue_date"),
        "due_date": raw.get("deadline") or raw.get("due_date"),
        "paid_date": raw.get("paid_date"),
        "currency": raw.get("currency", "EUR"),
        "amount_excl_tax": raw.get("amount"),
        "tax_amount": raw.get("tax"),
        "amount_incl_tax": raw.get("total"),
        "amount_remaining": raw.get("remaining_amount"),
        "line_items": raw.get("line_items", []),
        "raw_data": raw,
        "synced_at": now,
    }


def _parse_supplier_invoice(raw: dict) -> dict:
    """Map a Pennylane supplier_invoice payload to the repo row shape.

    Field names on the Pennylane supplier_invoice API differ slightly from
    customer_invoices. Best effort with fallbacks so we don't silently drop
    rows when the upstream schema shifts.
    """
    supplier = raw.get("supplier") or {}
    if isinstance(supplier, str):
        supplier = {}
    now = datetime.now(UTC)
    return {
        "external_id": str(raw["id"]),
        "invoice_number": raw.get("invoice_number") or raw.get("number"),
        "invoice_type": raw.get("type", "supplier_invoice"),
        "status": raw.get("status"),
        "supplier_name": (supplier.get("name") or raw.get("supplier_name") or raw.get("label")),
        "supplier_external_id": (str(supplier.get("id", "")) if supplier.get("id") else None),
        "issue_date": raw.get("date") or raw.get("issue_date"),
        "due_date": raw.get("deadline") or raw.get("due_date"),
        "paid_date": raw.get("paid_date"),
        "currency": raw.get("currency", "EUR"),
        "amount_excl_tax": raw.get("amount"),
        "tax_amount": raw.get("tax"),
        "amount_incl_tax": raw.get("total") or raw.get("amount_incl_tax"),
        "amount_remaining": raw.get("remaining_amount"),
        "line_items": raw.get("line_items", []),
        "raw_data": raw,
        "synced_at": now,
    }


def _extract_siret(raw: dict) -> str | None:
    """Extract SIRET (14 digits) from reg_no or siret field. Ignore non-SIRET codes."""
    for field in ("siret", "reg_no"):
        val = raw.get(field)
        if val and isinstance(val, str) and val.isdigit() and len(val) <= 14:
            return val
    return None


def _parse_customer(raw: dict) -> dict:
    now = datetime.now(UTC)
    addr = raw.get("postal_address") or {}
    if isinstance(addr, str):
        addr = {}
    emails = raw.get("emails", [])
    first_email = emails[0] if isinstance(emails, list) and emails else raw.get("email")
    return {
        "external_id": str(raw["id"]),
        "name": raw.get("name", ""),
        "email": first_email,
        "phone": raw.get("phone"),
        "address": addr.get("address") or None,
        "city": addr.get("city") or None,
        "zip_code": addr.get("postal_code") or addr.get("zipcode") or None,
        "country": addr.get("country_alpha2") or addr.get("country") or None,
        "siret": _extract_siret(raw),
        "vat_number": raw.get("vat_number") or None,
        "raw_data": raw,
        "synced_at": now,
    }


def _parse_supplier(raw: dict) -> dict:
    now = datetime.now(UTC)
    emails = raw.get("emails", [])
    first_email = emails[0] if isinstance(emails, list) and emails else raw.get("email")
    return {
        "external_id": str(raw["id"]),
        "name": raw.get("name", ""),
        "email": first_email,
        "phone": raw.get("phone"),
        "siret": _extract_siret(raw),
        "vat_number": raw.get("vat_number") or None,
        "raw_data": raw,
        "synced_at": now,
    }


def _parse_transaction(raw: dict) -> dict:
    now = datetime.now(UTC)
    bank_account = raw.get("bank_account") or {}
    if isinstance(bank_account, str):
        bank_account = {}
    raw_amount = raw.get("amount", 0)
    try:
        amount = float(raw_amount)
    except (TypeError, ValueError):
        amount = 0.0
    categories = raw.get("categories") or []
    category = categories[0].get("label") if categories and isinstance(categories[0], dict) else None
    return {
        "external_id": str(raw["id"]),
        "bank_account_name": bank_account.get("name") or None,
        "bank_account_id": str(bank_account.get("id", "")) if bank_account.get("id") else None,
        "date": raw.get("date"),
        "label": raw.get("label") or raw.get("name"),
        "amount": amount,
        "currency": raw.get("currency", "EUR"),
        "category": category,
        "is_reconciled": raw.get("archived_at") is not None,
        "raw_data": raw,
        "synced_at": now,
    }
