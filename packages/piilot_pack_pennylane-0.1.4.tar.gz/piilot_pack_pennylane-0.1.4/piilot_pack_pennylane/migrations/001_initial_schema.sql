-- ============================================================
-- 001_initial_schema.sql
-- Condensed, idempotent recreation of the integrations_pennylane schema.
--
-- Reproduces the end-state of the core migrations 056, 077, 078, 081:
--   * 056 — initial schema (invoices, customers, suppliers, transactions) + RLS
--   * 077 — Firm mode: firm_clients table + firm_client_id FK on the 4 above
--   * 078 — PLT-8 multi-token: connection_id FK (NOT NULL) on all tables,
--           UNIQUE (connection_id, external_id)
--   * 081 — supplier_invoices table
--
-- Reproduction strategy: final state, NOT a replay of the sequence.
-- Everything uses IF NOT EXISTS / DROP ... IF EXISTS; zero TRUNCATE,
-- zero destructive ALTER. Safe to run on a fresh dev DB AND on a
-- production DB where the core migrations already ran.
--
-- Out of scope (handled elsewhere):
--   * integrations_master.* tables — owned by the Piilot core
--   * agents.* seeds / templates — handled by plugin sub-lot B.4
--   * connectors_registry seed for 'pennylane' — handled by B.3 via
--     piilot.sdk.connectors.register_connector
--
-- Depends on (core, must pre-exist):
--   * schema public, tables public.companies
--   * functions public.is_company_member, public.is_company_admin,
--     public.update_updated_at_column
--   * schema integrations_master, table integrations_master.connections
--   * role piilot, role piilot_app
-- ============================================================

-- ============================================================
-- 1. Schema
-- ============================================================

CREATE SCHEMA IF NOT EXISTS integrations_pennylane;
GRANT USAGE ON SCHEMA integrations_pennylane TO piilot_app;


-- ============================================================
-- 2. Tables
--    firm_clients first — invoices/customers/suppliers/transactions
--    reference it via firm_client_id.
-- ============================================================

CREATE TABLE IF NOT EXISTS integrations_pennylane.firm_clients (
    id                    UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    company_id            UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
    connection_id         UUID NOT NULL REFERENCES integrations_master.connections(id) ON DELETE CASCADE,
    external_company_id   VARCHAR(100) NOT NULL,
    company_name          VARCHAR(255) NOT NULL,
    siren                 VARCHAR(9),
    siret                 VARCHAR(14),
    legal_form            VARCHAR(100),
    fiscal_year_start     DATE,
    is_active             BOOLEAN NOT NULL DEFAULT true,
    raw_data              JSONB,
    synced_at             TIMESTAMPTZ NOT NULL,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT firm_clients_connection_id_external_company_id_key
        UNIQUE (connection_id, external_company_id)
);

CREATE TABLE IF NOT EXISTS integrations_pennylane.invoices (
    id                    UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    company_id            UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
    connection_id         UUID NOT NULL REFERENCES integrations_master.connections(id) ON DELETE CASCADE,
    external_id           VARCHAR(100) NOT NULL,
    invoice_number        VARCHAR(50),
    invoice_type          VARCHAR(20) DEFAULT 'invoice',
    status                VARCHAR(30),
    customer_name         VARCHAR(255),
    customer_external_id  VARCHAR(100),
    issue_date            DATE,
    due_date              DATE,
    paid_date             DATE,
    currency              VARCHAR(3) DEFAULT 'EUR',
    amount_excl_tax       NUMERIC(12,2),
    tax_amount            NUMERIC(12,2),
    amount_incl_tax       NUMERIC(12,2),
    amount_remaining      NUMERIC(12,2),
    line_items            JSONB DEFAULT '[]',
    raw_data              JSONB,
    firm_client_id        UUID REFERENCES integrations_pennylane.firm_clients(id) ON DELETE CASCADE,
    synced_at             TIMESTAMPTZ NOT NULL,
    created_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at            TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT invoices_connection_id_external_id_key
        UNIQUE (connection_id, external_id)
);

CREATE TABLE IF NOT EXISTS integrations_pennylane.customers (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    company_id      UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
    connection_id   UUID NOT NULL REFERENCES integrations_master.connections(id) ON DELETE CASCADE,
    external_id     VARCHAR(100) NOT NULL,
    name            VARCHAR(255) NOT NULL,
    email           VARCHAR(255),
    phone           VARCHAR(50),
    address         TEXT,
    city            VARCHAR(100),
    zip_code        VARCHAR(10),
    country         VARCHAR(50),
    siret           VARCHAR(14),
    vat_number      VARCHAR(20),
    raw_data        JSONB,
    firm_client_id  UUID REFERENCES integrations_pennylane.firm_clients(id) ON DELETE CASCADE,
    synced_at       TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT customers_connection_id_external_id_key
        UNIQUE (connection_id, external_id)
);

CREATE TABLE IF NOT EXISTS integrations_pennylane.suppliers (
    id              UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    company_id      UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
    connection_id   UUID NOT NULL REFERENCES integrations_master.connections(id) ON DELETE CASCADE,
    external_id     VARCHAR(100) NOT NULL,
    name            VARCHAR(255) NOT NULL,
    email           VARCHAR(255),
    phone           VARCHAR(50),
    siret           VARCHAR(14),
    vat_number      VARCHAR(20),
    raw_data        JSONB,
    firm_client_id  UUID REFERENCES integrations_pennylane.firm_clients(id) ON DELETE CASCADE,
    synced_at       TIMESTAMPTZ NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT suppliers_connection_id_external_id_key
        UNIQUE (connection_id, external_id)
);

CREATE TABLE IF NOT EXISTS integrations_pennylane.transactions (
    id                  UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    company_id          UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
    connection_id       UUID NOT NULL REFERENCES integrations_master.connections(id) ON DELETE CASCADE,
    external_id         VARCHAR(100) NOT NULL,
    bank_account_name   VARCHAR(255),
    bank_account_id     VARCHAR(100),
    date                DATE NOT NULL,
    label               VARCHAR(500),
    amount              NUMERIC(12,2) NOT NULL,
    currency            VARCHAR(3) DEFAULT 'EUR',
    category            VARCHAR(100),
    is_reconciled       BOOLEAN DEFAULT false,
    raw_data            JSONB,
    firm_client_id      UUID REFERENCES integrations_pennylane.firm_clients(id) ON DELETE CASCADE,
    synced_at           TIMESTAMPTZ NOT NULL,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT transactions_connection_id_external_id_key
        UNIQUE (connection_id, external_id)
);

CREATE TABLE IF NOT EXISTS integrations_pennylane.supplier_invoices (
    id                      UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    company_id              UUID NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
    connection_id           UUID NOT NULL REFERENCES integrations_master.connections(id) ON DELETE CASCADE,
    external_id             TEXT NOT NULL,
    invoice_number          TEXT,
    invoice_type            TEXT DEFAULT 'supplier_invoice',
    status                  TEXT,
    supplier_name           TEXT,
    supplier_external_id    TEXT,
    issue_date              DATE,
    due_date                DATE,
    paid_date               DATE,
    currency                TEXT DEFAULT 'EUR',
    amount_excl_tax         NUMERIC(18, 2),
    tax_amount              NUMERIC(18, 2),
    amount_incl_tax         NUMERIC(18, 2),
    amount_remaining        NUMERIC(18, 2),
    line_items              JSONB DEFAULT '[]',
    raw_data                JSONB DEFAULT '{}',
    firm_client_id          UUID REFERENCES integrations_pennylane.firm_clients(id) ON DELETE CASCADE,
    synced_at               TIMESTAMPTZ,
    created_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ NOT NULL DEFAULT now(),
    CONSTRAINT supplier_invoices_connection_id_external_id_key
        UNIQUE (connection_id, external_id)
);


-- ============================================================
-- 3. Indexes
-- ============================================================

-- firm_clients
CREATE INDEX IF NOT EXISTS idx_pl_firm_clients_company
    ON integrations_pennylane.firm_clients(company_id);
CREATE INDEX IF NOT EXISTS idx_pl_firm_clients_connection
    ON integrations_pennylane.firm_clients(connection_id);
CREATE INDEX IF NOT EXISTS idx_pl_firm_clients_siren
    ON integrations_pennylane.firm_clients(siren) WHERE siren IS NOT NULL;

-- invoices
CREATE INDEX IF NOT EXISTS idx_pl_invoices_company
    ON integrations_pennylane.invoices(company_id);
CREATE INDEX IF NOT EXISTS idx_pl_invoices_status
    ON integrations_pennylane.invoices(company_id, status);
CREATE INDEX IF NOT EXISTS idx_pl_invoices_issue_date
    ON integrations_pennylane.invoices(company_id, issue_date);
CREATE INDEX IF NOT EXISTS idx_pl_invoices_customer
    ON integrations_pennylane.invoices(company_id, customer_external_id);
CREATE INDEX IF NOT EXISTS idx_pl_invoices_firm_client
    ON integrations_pennylane.invoices(firm_client_id) WHERE firm_client_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_pl_invoices_connection
    ON integrations_pennylane.invoices(connection_id);
CREATE INDEX IF NOT EXISTS idx_pl_invoices_connection_status
    ON integrations_pennylane.invoices(connection_id, status);
CREATE INDEX IF NOT EXISTS idx_pl_invoices_connection_issue_date
    ON integrations_pennylane.invoices(connection_id, issue_date);

-- customers
CREATE INDEX IF NOT EXISTS idx_pl_customers_company
    ON integrations_pennylane.customers(company_id);
CREATE INDEX IF NOT EXISTS idx_pl_customers_name
    ON integrations_pennylane.customers(company_id, name);
CREATE INDEX IF NOT EXISTS idx_pl_customers_firm_client
    ON integrations_pennylane.customers(firm_client_id) WHERE firm_client_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_pl_customers_connection
    ON integrations_pennylane.customers(connection_id);
CREATE INDEX IF NOT EXISTS idx_pl_customers_connection_name
    ON integrations_pennylane.customers(connection_id, name);

-- suppliers
CREATE INDEX IF NOT EXISTS idx_pl_suppliers_company
    ON integrations_pennylane.suppliers(company_id);
CREATE INDEX IF NOT EXISTS idx_pl_suppliers_firm_client
    ON integrations_pennylane.suppliers(firm_client_id) WHERE firm_client_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_pl_suppliers_connection
    ON integrations_pennylane.suppliers(connection_id);
CREATE INDEX IF NOT EXISTS idx_pl_suppliers_connection_name
    ON integrations_pennylane.suppliers(connection_id, name);

-- transactions
CREATE INDEX IF NOT EXISTS idx_pl_transactions_company
    ON integrations_pennylane.transactions(company_id);
CREATE INDEX IF NOT EXISTS idx_pl_transactions_date
    ON integrations_pennylane.transactions(company_id, date);
CREATE INDEX IF NOT EXISTS idx_pl_transactions_firm_client
    ON integrations_pennylane.transactions(firm_client_id) WHERE firm_client_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_pl_transactions_connection
    ON integrations_pennylane.transactions(connection_id);
CREATE INDEX IF NOT EXISTS idx_pl_transactions_connection_date
    ON integrations_pennylane.transactions(connection_id, date);

-- supplier_invoices
CREATE INDEX IF NOT EXISTS idx_pl_supplier_invoices_connection
    ON integrations_pennylane.supplier_invoices(connection_id);
CREATE INDEX IF NOT EXISTS idx_pl_supplier_invoices_connection_status
    ON integrations_pennylane.supplier_invoices(connection_id, status);
CREATE INDEX IF NOT EXISTS idx_pl_supplier_invoices_connection_issue_date
    ON integrations_pennylane.supplier_invoices(connection_id, issue_date);
CREATE INDEX IF NOT EXISTS idx_pl_supplier_invoices_firm_client
    ON integrations_pennylane.supplier_invoices(firm_client_id) WHERE firm_client_id IS NOT NULL;
CREATE INDEX IF NOT EXISTS idx_pl_supplier_invoices_supplier_name
    ON integrations_pennylane.supplier_invoices(connection_id, supplier_name);


-- ============================================================
-- 4. Triggers (updated_at)
--    DROP + CREATE since CREATE TRIGGER IF NOT EXISTS only lands in PG 17+
-- ============================================================

DROP TRIGGER IF EXISTS trg_pl_firm_clients_updated_at
    ON integrations_pennylane.firm_clients;
CREATE TRIGGER trg_pl_firm_clients_updated_at
    BEFORE UPDATE ON integrations_pennylane.firm_clients
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS trg_pl_invoices_updated_at
    ON integrations_pennylane.invoices;
CREATE TRIGGER trg_pl_invoices_updated_at
    BEFORE UPDATE ON integrations_pennylane.invoices
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS trg_pl_customers_updated_at
    ON integrations_pennylane.customers;
CREATE TRIGGER trg_pl_customers_updated_at
    BEFORE UPDATE ON integrations_pennylane.customers
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS trg_pl_suppliers_updated_at
    ON integrations_pennylane.suppliers;
CREATE TRIGGER trg_pl_suppliers_updated_at
    BEFORE UPDATE ON integrations_pennylane.suppliers
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

DROP TRIGGER IF EXISTS trg_pl_supplier_invoices_updated_at
    ON integrations_pennylane.supplier_invoices;
CREATE TRIGGER trg_pl_supplier_invoices_updated_at
    BEFORE UPDATE ON integrations_pennylane.supplier_invoices
    FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- transactions has no updated_at column by design (append-only with synced_at).


-- ============================================================
-- 5. RLS — ENABLE + FORCE + policies
--    Tenant-level policies keyed on company_id. bypass policy for the
--    owner role (piilot) so server-side operations and migrations pass
--    through unrestricted.
-- ============================================================

-- firm_clients
ALTER TABLE integrations_pennylane.firm_clients ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations_pennylane.firm_clients FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS pl_firm_clients_bypass ON integrations_pennylane.firm_clients;
CREATE POLICY pl_firm_clients_bypass ON integrations_pennylane.firm_clients
    TO piilot USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS pl_firm_clients_select ON integrations_pennylane.firm_clients;
CREATE POLICY pl_firm_clients_select ON integrations_pennylane.firm_clients
    FOR SELECT TO piilot_app USING (public.is_company_member(company_id));

DROP POLICY IF EXISTS pl_firm_clients_admin ON integrations_pennylane.firm_clients;
CREATE POLICY pl_firm_clients_admin ON integrations_pennylane.firm_clients
    FOR ALL TO piilot_app
    USING (public.is_company_admin(company_id))
    WITH CHECK (public.is_company_admin(company_id));

-- invoices
ALTER TABLE integrations_pennylane.invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations_pennylane.invoices FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS pl_invoices_bypass ON integrations_pennylane.invoices;
CREATE POLICY pl_invoices_bypass ON integrations_pennylane.invoices
    TO piilot USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS pl_invoices_select ON integrations_pennylane.invoices;
CREATE POLICY pl_invoices_select ON integrations_pennylane.invoices
    FOR SELECT TO piilot_app USING (public.is_company_member(company_id));

DROP POLICY IF EXISTS pl_invoices_admin ON integrations_pennylane.invoices;
CREATE POLICY pl_invoices_admin ON integrations_pennylane.invoices
    FOR ALL TO piilot_app
    USING (public.is_company_admin(company_id))
    WITH CHECK (public.is_company_admin(company_id));

-- customers
ALTER TABLE integrations_pennylane.customers ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations_pennylane.customers FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS pl_customers_bypass ON integrations_pennylane.customers;
CREATE POLICY pl_customers_bypass ON integrations_pennylane.customers
    TO piilot USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS pl_customers_select ON integrations_pennylane.customers;
CREATE POLICY pl_customers_select ON integrations_pennylane.customers
    FOR SELECT TO piilot_app USING (public.is_company_member(company_id));

DROP POLICY IF EXISTS pl_customers_admin ON integrations_pennylane.customers;
CREATE POLICY pl_customers_admin ON integrations_pennylane.customers
    FOR ALL TO piilot_app
    USING (public.is_company_admin(company_id))
    WITH CHECK (public.is_company_admin(company_id));

-- suppliers
ALTER TABLE integrations_pennylane.suppliers ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations_pennylane.suppliers FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS pl_suppliers_bypass ON integrations_pennylane.suppliers;
CREATE POLICY pl_suppliers_bypass ON integrations_pennylane.suppliers
    TO piilot USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS pl_suppliers_select ON integrations_pennylane.suppliers;
CREATE POLICY pl_suppliers_select ON integrations_pennylane.suppliers
    FOR SELECT TO piilot_app USING (public.is_company_member(company_id));

DROP POLICY IF EXISTS pl_suppliers_admin ON integrations_pennylane.suppliers;
CREATE POLICY pl_suppliers_admin ON integrations_pennylane.suppliers
    FOR ALL TO piilot_app
    USING (public.is_company_admin(company_id))
    WITH CHECK (public.is_company_admin(company_id));

-- transactions
ALTER TABLE integrations_pennylane.transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations_pennylane.transactions FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS pl_transactions_bypass ON integrations_pennylane.transactions;
CREATE POLICY pl_transactions_bypass ON integrations_pennylane.transactions
    TO piilot USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS pl_transactions_select ON integrations_pennylane.transactions;
CREATE POLICY pl_transactions_select ON integrations_pennylane.transactions
    FOR SELECT TO piilot_app USING (public.is_company_member(company_id));

DROP POLICY IF EXISTS pl_transactions_admin ON integrations_pennylane.transactions;
CREATE POLICY pl_transactions_admin ON integrations_pennylane.transactions
    FOR ALL TO piilot_app
    USING (public.is_company_admin(company_id))
    WITH CHECK (public.is_company_admin(company_id));

-- supplier_invoices
-- Note: the in-tree migration 081 only ships a bypass policy on this
-- table (no select_member / admin counterparts). We reproduce the
-- same state for parity — tightening is a follow-up, not a B.2 task.
ALTER TABLE integrations_pennylane.supplier_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE integrations_pennylane.supplier_invoices FORCE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS pl_supplier_invoices_bypass ON integrations_pennylane.supplier_invoices;
CREATE POLICY pl_supplier_invoices_bypass
    ON integrations_pennylane.supplier_invoices
    TO piilot USING (true) WITH CHECK (true);


-- ============================================================
-- 6. Grants
-- ============================================================

GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA integrations_pennylane TO piilot_app;
GRANT USAGE ON ALL SEQUENCES IN SCHEMA integrations_pennylane TO piilot_app;

ALTER DEFAULT PRIVILEGES FOR ROLE piilot IN SCHEMA integrations_pennylane
    GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO piilot_app;
