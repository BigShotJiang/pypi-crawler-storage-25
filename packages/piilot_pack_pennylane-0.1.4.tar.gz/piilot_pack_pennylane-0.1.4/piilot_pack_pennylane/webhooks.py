"""Pennylane webhook receiver — mounted under ``/plugins/pennylane/webhooks/*``.

Receives Pennylane webhook events for near-real-time sync. Validates
the HMAC signature (env var ``PENNYLANE_WEBHOOK_SECRET``) and dispatches
the event to the right upsert based on its type. Routes under this
module are bypassed by the ``plugin_gate`` middleware — Pennylane SaaS
posts without any ``X-Company-Id`` header, the payload itself carries
the ``account_id`` which we use to resolve ``(company_id, connection_id)``.

The matching in-tree route lived at ``POST /webhooks/pennylane``; the
plugin exposes it at ``POST /plugins/pennylane/webhooks/events`` (the
``/events`` suffix makes the path unambiguous when the plugin adds more
webhook endpoints in the future).
"""

from __future__ import annotations

import hashlib
import hmac
import json
import logging
import os

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse
from piilot.sdk.db import cursor as _db_cursor
from piilot.sdk.http import get_real_ip
from slowapi import Limiter

from .repositories import (
    pennylane_customers_repo,
    pennylane_invoices_repo,
)
from .repositories._base import run_in_thread
from .sync import _parse_customer, _parse_invoice

logger = logging.getLogger(__name__)

limiter = Limiter(key_func=get_real_ip)


def _resolve_connection_from_webhook_sync(
    external_account_id: str,
) -> tuple[str, str] | None:
    """Find ``(company_id, connection_id)`` for a Pennylane webhook event.

    Returns ``None`` when the event cannot be unambiguously routed — for
    example when multiple active Pennylane connections share the same
    external_account_id (Firm mode rare edge).
    """
    if external_account_id:
        with _db_cursor() as cur:
            cur.execute(
                "SELECT id, company_id FROM integrations_master.connections "
                "WHERE provider = 'pennylane' AND is_active = true "
                "AND external_account_id = %s",
                (external_account_id,),
            )
            rows = cur.fetchall()
        if len(rows) == 1:
            return str(rows[0]["company_id"]), str(rows[0]["id"])
        if len(rows) > 1:
            return None  # ambiguous — skip rather than guess

    with _db_cursor() as cur:
        cur.execute(
            "SELECT id, company_id FROM integrations_master.connections "
            "WHERE provider = 'pennylane' AND is_active = true"
        )
        rows = cur.fetchall()
    if len(rows) == 1:
        return str(rows[0]["company_id"]), str(rows[0]["id"])
    return None


router = APIRouter()


@router.post("/events")
@limiter.limit("60/minute")
async def pennylane_webhook(request: Request):
    """Receive Pennylane webhook events for near-real-time sync."""
    payload = await request.body()

    webhook_secret = os.getenv("PENNYLANE_WEBHOOK_SECRET", "")
    if webhook_secret:
        signature = request.headers.get("X-Pennylane-Signature", "")
        expected = hmac.new(webhook_secret.encode(), payload, hashlib.sha256).hexdigest()
        if not hmac.compare_digest(expected, signature):
            logger.warning("Pennylane webhook: invalid signature")
            return JSONResponse({"received": False, "error": "Invalid signature"}, status_code=400)

    try:
        event = json.loads(payload)
    except json.JSONDecodeError:
        return JSONResponse({"received": False, "error": "Invalid JSON"}, status_code=400)

    event_type = event.get("type", "")
    event_data = event.get("data", {})

    account_id = event.get("account_id") or event.get("company_id") or ""
    resolved = await run_in_thread(_resolve_connection_from_webhook_sync, str(account_id))
    if not resolved:
        logger.warning(
            "Pennylane webhook: cannot resolve connection for account %s",
            account_id,
        )
        return JSONResponse({"received": True, "processed": False})
    company_id, connection_id = resolved

    try:
        if "invoice" in event_type:
            parsed = _parse_invoice(event_data)
            await run_in_thread(
                pennylane_invoices_repo.upsert,
                company_id,
                connection_id,
                parsed.pop("external_id"),
                **parsed,
            )
        elif "customer" in event_type:
            parsed = _parse_customer(event_data)
            await run_in_thread(
                pennylane_customers_repo.upsert,
                company_id,
                connection_id,
                parsed.pop("external_id"),
                **parsed,
            )
        else:
            logger.info("Pennylane webhook: unhandled event type '%s'", event_type)
    except Exception:
        logger.exception("Pennylane webhook processing error for event '%s'", event_type)

    # Always return 200 to avoid Pennylane retries
    return JSONResponse({"received": True})
