"""Pennylane Treasury dashboard service.

Aggregates data from integrations_pennylane.transactions and
integrations_pennylane.invoices to produce a treasury dashboard payload.
Zero Pennylane API calls — everything is local SQL on synced data.

Scoped by ``connection_id`` since PLT-8 phase 6/7. Each Pennylane token
produces its own dashboard — a cabinet with a Company + a Firm token
sees two separate trésoreries, one per navigation URL.
"""

from __future__ import annotations

import logging
from datetime import date, timedelta

from .repositories._base import _fetchall, _fetchone, _get_conn

logger = logging.getLogger(__name__)

_TX_TABLE = "integrations_pennylane.transactions"
_INV_TABLE = "integrations_pennylane.invoices"

# Period → (date_trunc granularity, SQL interval for date >= filter)
_PERIOD_CONFIG = {
    "30d": ("day", "now() - interval '30 days'"),
    "ytd": ("day", "date_trunc('year', now())"),
    "12m": ("month", "now() - interval '12 months'"),
    "24m": ("month", "now() - interval '24 months'"),
}


def _get_bank_accounts(cur, connection_id: str) -> list[str]:
    cur.execute(
        f"SELECT DISTINCT bank_account_name FROM {_TX_TABLE} "
        "WHERE connection_id = %s AND bank_account_name IS NOT NULL "
        "ORDER BY bank_account_name",
        (connection_id,),
    )
    return [r["bank_account_name"] for r in _fetchall(cur)]


def _get_balance(cur, connection_id: str, bank_account: str | None) -> float:
    cur.execute(
        f"SELECT COALESCE(SUM(amount), 0) AS balance FROM {_TX_TABLE} "
        f"WHERE connection_id = %s AND (%s::text IS NULL OR bank_account_name = %s)",
        (connection_id, bank_account, bank_account),
    )
    row = _fetchone(cur)
    return float(row["balance"]) if row else 0.0


def _get_chart(
    cur,
    connection_id: str,
    period: str,
    bank_account: str | None,
) -> list[dict]:
    granularity, date_filter = _PERIOD_CONFIG[period]
    cur.execute(
        f"""SELECT
            date_trunc(%s, date)::date AS period_date,
            COALESCE(SUM(CASE WHEN amount > 0 THEN amount ELSE 0 END), 0) AS inflows,
            COALESCE(SUM(CASE WHEN amount < 0 THEN ABS(amount) ELSE 0 END), 0) AS outflows
        FROM {_TX_TABLE}
        WHERE connection_id = %s
          AND date >= {date_filter}
          AND (%s::text IS NULL OR bank_account_name = %s)
        GROUP BY period_date
        ORDER BY period_date""",
        (granularity, connection_id, bank_account, bank_account),
    )
    rows = _fetchall(cur)
    return [
        {
            "date": str(r["period_date"]),
            "inflows": float(r["inflows"]),
            "outflows": float(r["outflows"]),
        }
        for r in rows
    ]


def _get_pending_invoices(cur, connection_id: str) -> dict:
    cur.execute(
        f"SELECT COUNT(*) AS count, COALESCE(SUM(amount_remaining), 0) AS amount "
        f"FROM {_INV_TABLE} "
        f"WHERE connection_id = %s AND status NOT IN ('paid', 'cancelled')",
        (connection_id,),
    )
    row = _fetchone(cur)
    return {
        "count": int(row["count"]) if row else 0,
        "amount": float(row["amount"]) if row else 0.0,
    }


def _get_overdue_invoices(cur, connection_id: str) -> dict:
    cur.execute(
        f"SELECT COUNT(*) AS count, COALESCE(SUM(amount_remaining), 0) AS amount "
        f"FROM {_INV_TABLE} "
        f"WHERE connection_id = %s AND status NOT IN ('paid', 'cancelled') "
        f"AND due_date < CURRENT_DATE",
        (connection_id,),
    )
    row = _fetchone(cur)
    return {
        "count": int(row["count"]) if row else 0,
        "amount": float(row["amount"]) if row else 0.0,
    }


def _get_monthly_flows(
    cur,
    connection_id: str,
    bank_account: str | None,
) -> dict:
    cur.execute(
        f"""SELECT
            COALESCE(SUM(CASE WHEN amount > 0 AND date >= date_trunc('month', now())
                THEN amount END), 0) AS current_inflows,
            COALESCE(SUM(CASE WHEN amount < 0 AND date >= date_trunc('month', now())
                THEN ABS(amount) END), 0) AS current_outflows,
            COALESCE(SUM(CASE WHEN amount > 0
                AND date >= date_trunc('month', now() - interval '1 month')
                AND date < date_trunc('month', now())
                THEN amount END), 0) AS previous_inflows,
            COALESCE(SUM(CASE WHEN amount < 0
                AND date >= date_trunc('month', now() - interval '1 month')
                AND date < date_trunc('month', now())
                THEN ABS(amount) END), 0) AS previous_outflows
        FROM {_TX_TABLE}
        WHERE connection_id = %s
          AND (%s::text IS NULL OR bank_account_name = %s)
          AND date >= date_trunc('month', now() - interval '1 month')""",
        (connection_id, bank_account, bank_account),
    )
    row = _fetchone(cur)
    if not row:
        return {
            "monthly_inflows": {"current": 0, "previous": 0, "delta_pct": 0},
            "monthly_outflows": {"current": 0, "previous": 0, "delta_pct": 0},
        }

    ci = float(row["current_inflows"])
    pi = float(row["previous_inflows"])
    co = float(row["current_outflows"])
    po = float(row["previous_outflows"])

    def delta(current: float, previous: float) -> float:
        if previous == 0:
            return 0.0
        return round((current - previous) / previous * 100, 1)

    return {
        "monthly_inflows": {"current": ci, "previous": pi, "delta_pct": delta(ci, pi)},
        "monthly_outflows": {"current": co, "previous": po, "delta_pct": delta(co, po)},
    }


def _get_dso(cur, connection_id: str) -> int:
    """DSO = average days between issue_date and paid_date on paid invoices (last 90 days)."""
    cur.execute(
        f"""SELECT COALESCE(
            AVG(paid_date - issue_date),
            0
        )::int AS dso_days
        FROM {_INV_TABLE}
        WHERE connection_id = %s
          AND status = 'paid'
          AND paid_date IS NOT NULL
          AND paid_date >= now() - interval '90 days'""",
        (connection_id,),
    )
    row = _fetchone(cur)
    return int(row["dso_days"]) if row else 0


def _get_top_customers(
    cur,
    connection_id: str,
    date_from: str,
) -> list[dict]:
    """Top 5 clients by invoiced amount (from invoices table)."""
    cur.execute(
        f"""SELECT customer_name AS name,
               COALESCE(SUM(amount_incl_tax), 0) AS total,
               COUNT(*) AS invoice_count
        FROM {_INV_TABLE}
        WHERE connection_id = %s
          AND customer_name IS NOT NULL
          AND issue_date >= %s
        GROUP BY customer_name
        ORDER BY total DESC
        LIMIT 5""",
        (connection_id, date_from),
    )
    return [
        {"name": r["name"], "total": float(r["total"]), "invoice_count": int(r["invoice_count"])}
        for r in _fetchall(cur)
    ]


def _get_top_suppliers(
    cur,
    connection_id: str,
    date_from: str,
) -> list[dict]:
    """Top 5 suppliers by outflow volume (negative transactions grouped by label)."""
    cur.execute(
        f"""SELECT label AS name,
               COALESCE(SUM(ABS(amount)), 0) AS total,
               COUNT(*) AS invoice_count
        FROM {_TX_TABLE}
        WHERE connection_id = %s
          AND amount < 0
          AND label IS NOT NULL
          AND label != ''
          AND date >= %s
        GROUP BY label
        ORDER BY total DESC
        LIMIT 5""",
        (connection_id, date_from),
    )
    return [
        {"name": r["name"], "total": float(r["total"]), "invoice_count": int(r["invoice_count"])}
        for r in _fetchall(cur)
    ]


def _get_forecast(
    cur,
    connection_id: str,
    current_balance: float,
) -> dict:
    # Expected inflows = all unpaid invoices (only customer invoices are synced)
    cur.execute(
        f"SELECT COALESCE(SUM(amount_remaining), 0) AS expected "
        f"FROM {_INV_TABLE} "
        f"WHERE connection_id = %s "
        f"AND status NOT IN ('paid', 'cancelled')",
        (connection_id,),
    )
    row_in = _fetchone(cur)
    expected_inflows = float(row_in["expected"]) if row_in else 0.0

    # Expected outflows: no supplier invoices synced — estimate from avg monthly outflows
    cur.execute(
        f"""SELECT COALESCE(
            ABS(SUM(CASE WHEN amount < 0 AND date >= date_trunc('month', now())
                THEN amount ELSE 0 END)),
            0
        ) AS current_month_outflows
        FROM {_TX_TABLE}
        WHERE connection_id = %s
          AND date >= date_trunc('month', now())""",
        (connection_id,),
    )
    row_out = _fetchone(cur)
    expected_outflows = float(row_out["current_month_outflows"]) if row_out else 0.0

    return {
        "current_balance": current_balance,
        "expected_inflows": expected_inflows,
        "expected_outflows": expected_outflows,
        "estimated_balance": round(current_balance + expected_inflows - expected_outflows, 2),
    }


def get_dashboard(
    connection_id: str,
    period: str = "30d",
    bank_account: str | None = None,
    last_sync_at: str | None = None,
) -> dict:
    """Build the full treasury dashboard payload for a single connection.

    Runs synchronously (called via ``run_in_thread`` by the route).
    """
    if period not in _PERIOD_CONFIG:
        period = "30d"

    with _get_conn() as conn:
        with conn.cursor() as cur:
            bank_accounts = _get_bank_accounts(cur, connection_id)
            balance = _get_balance(cur, connection_id, bank_account)
            chart = _get_chart(cur, connection_id, period, bank_account)
            pending = _get_pending_invoices(cur, connection_id)
            overdue = _get_overdue_invoices(cur, connection_id)
            flows = _get_monthly_flows(cur, connection_id, bank_account)
            dso = _get_dso(cur, connection_id)

            # date_from for tops: same as period filter
            if period == "ytd":
                date_from = str(date(date.today().year, 1, 1))
            elif period == "12m":
                date_from = str(date.today() - timedelta(days=365))
            elif period == "24m":
                date_from = str(date.today() - timedelta(days=730))
            else:
                date_from = str(date.today() - timedelta(days=30))

            top_customers = _get_top_customers(cur, connection_id, date_from)
            top_suppliers = _get_top_suppliers(cur, connection_id, date_from)
            forecast = _get_forecast(cur, connection_id, balance)

    return {
        "bank_accounts": bank_accounts,
        "selected_account": bank_account,
        "last_sync_at": last_sync_at,
        "period": period,
        "balance": {"amount": balance, "currency": "EUR"},
        "chart": chart,
        "pending_invoices": pending,
        "overdue_invoices": overdue,
        "monthly_inflows": flows["monthly_inflows"],
        "monthly_outflows": flows["monthly_outflows"],
        "dso_days": dso,
        "top_customers": top_customers,
        "top_suppliers": top_suppliers,
        "forecast_30d": forecast,
    }
