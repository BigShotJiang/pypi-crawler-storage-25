"""REST client for the Pennylane API v2."""

from __future__ import annotations

import asyncio
import logging
from collections.abc import Awaitable, Callable
from typing import Any

import httpx

from .rate_limiter import RateLimiter

logger = logging.getLogger(__name__)

_TIMEOUT = 30.0
_MAX_RETRIES = 3
_RETRY_STATUSES = {429, 503}


class PennylaneAPIError(Exception):
    """Raised when the Pennylane API returns a non-retryable error."""

    def __init__(
        self,
        status_code: int,
        message: str,
        response_body: dict | None = None,
    ) -> None:
        self.status_code = status_code
        self.response_body = response_body
        super().__init__(f"Pennylane API {status_code}: {message}")


class PennylaneClient:
    """Client REST for Pennylane API v2 with rate limiting and auto-pagination.

    Uses a shared httpx.AsyncClient for TCP/TLS connection reuse.
    Must be used as an async context manager::

        async with PennylaneClient(token) as client:
            invoices = await client.list_all_invoices()
    """

    BASE_URL = "https://app.pennylane.com/api/external/v2"

    def __init__(self, access_token: str) -> None:
        self._token = access_token
        self._limiter = RateLimiter(max_per_second=3.0)
        self._http: httpx.AsyncClient | None = None

    # ------------------------------------------------------------------
    # Context manager — reuse a single TCP connection
    # ------------------------------------------------------------------

    async def __aenter__(self) -> PennylaneClient:
        self._http = httpx.AsyncClient(
            timeout=_TIMEOUT,
            headers={
                "Authorization": f"Bearer {self._token}",
                "Accept": "application/json",
            },
            http2=False,
        )
        return self

    async def __aexit__(self, *exc: object) -> None:
        if self._http:
            await self._http.aclose()
            self._http = None

    def _get_http(self) -> httpx.AsyncClient:
        """Return the shared HTTP client, creating one if not in context manager."""
        if self._http is None:
            self._http = httpx.AsyncClient(
                timeout=_TIMEOUT,
                headers={
                    "Authorization": f"Bearer {self._token}",
                    "Accept": "application/json",
                },
            )
        return self._http

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    async def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        json_data: dict[str, Any] | None = None,
        max_retries: int = _MAX_RETRIES,
    ) -> dict:
        """Execute an HTTP request with rate limiting and retry on 429/503."""
        url = f"{self.BASE_URL}/{path.lstrip('/')}"
        http = self._get_http()

        last_exc: Exception | None = None
        for attempt in range(max_retries + 1):
            await self._limiter.acquire()
            try:
                resp = await http.request(
                    method,
                    url,
                    params=params,
                    json=json_data,
                )

                if resp.status_code in _RETRY_STATUSES and attempt < max_retries:
                    self._limiter.back_off()
                    retry_after = max(
                        float(resp.headers.get("Retry-After", 2)),
                        2 ** (attempt + 1),
                    )
                    logger.warning(
                        "Pennylane %s %s → %d, retrying in %.1fs (attempt %d/%d)",
                        method,
                        path,
                        resp.status_code,
                        retry_after,
                        attempt + 1,
                        max_retries,
                    )
                    await asyncio.sleep(retry_after)
                    continue

                if resp.status_code >= 400:
                    body = None
                    try:
                        body = resp.json()
                    except Exception:
                        pass
                    raise PennylaneAPIError(resp.status_code, resp.reason_phrase or "Error", body)

                self._limiter.success()
                return resp.json()

            except httpx.TimeoutException as exc:
                last_exc = exc
                if attempt < max_retries:
                    wait = 2**attempt
                    logger.warning(
                        "Pennylane %s %s timeout, retrying in %ds (attempt %d/%d)",
                        method,
                        path,
                        wait,
                        attempt + 1,
                        max_retries,
                    )
                    await asyncio.sleep(wait)
                    continue
                raise

            except httpx.ConnectError:
                raise

        raise last_exc or RuntimeError("Unexpected retry exhaustion")

    async def _paginate(
        self,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        max_pages: int = 200,
        on_page: Callable[[int, int], Awaitable[None]] | None = None,
    ) -> list[dict]:
        """Auto-paginate a GET endpoint collecting all items.

        Args:
            on_page: optional async callback ``(page_num, total_items_so_far)``
                     called after each page is fetched.

        Stops after *max_pages* to avoid runaway loops.
        """
        all_items: list[dict] = []
        page_params = dict(params or {})

        for page_num in range(1, max_pages + 1):
            data = await self._request("GET", path, params=page_params)

            items = []
            if "items" in data and isinstance(data["items"], list):
                items = data["items"]
            else:
                for key in (
                    "invoices",
                    "customers",
                    "suppliers",
                    "supplier_invoices",
                    "customer_invoices",
                    "transactions",
                    "products",
                    "categories",
                    "data",
                ):
                    if key in data and isinstance(data[key], list):
                        items = data[key]
                        break
            if not items and isinstance(data, list):
                items = data

            all_items.extend(items)

            if on_page is not None:
                await on_page(page_num, len(all_items))

            has_more = data.get("has_more", False)
            next_cursor = data.get("next_cursor")
            if not next_cursor:
                pagination = data.get("pagination", {})
                next_cursor = pagination.get("cursor") or pagination.get("next_cursor")
            if not has_more or not next_cursor or not items:
                break
            page_params["cursor"] = next_cursor

        if page_num >= max_pages:
            logger.warning("Pennylane %s: stopped at %d pages (%d items)", path, max_pages, len(all_items))

        return all_items

    # ------------------------------------------------------------------
    # Read methods
    # ------------------------------------------------------------------

    async def get_me(self) -> dict:
        """Verify token and get current account info."""
        return await self._request("GET", "me")

    async def list_all_invoices(
        self,
        on_page: Callable[[int, int], Awaitable[None]] | None = None,
        **filters: Any,
    ) -> list[dict]:
        """List all customer invoices (auto-paginated)."""
        return await self._paginate("customer_invoices", params=filters or None, on_page=on_page)

    async def get_invoice(self, invoice_id: str) -> dict:
        """Get a single customer invoice by ID."""
        return await self._request("GET", f"customer_invoices/{invoice_id}")

    async def list_all_customers(
        self,
        on_page: Callable[[int, int], Awaitable[None]] | None = None,
    ) -> list[dict]:
        """List all customers (auto-paginated)."""
        return await self._paginate("customers", on_page=on_page)

    async def list_all_suppliers(
        self,
        on_page: Callable[[int, int], Awaitable[None]] | None = None,
    ) -> list[dict]:
        """List all suppliers (auto-paginated)."""
        return await self._paginate("suppliers", on_page=on_page)

    async def list_all_supplier_invoices(
        self,
        on_page: Callable[[int, int], Awaitable[None]] | None = None,
        **filters: Any,
    ) -> list[dict]:
        """List all supplier invoices / purchase invoices (auto-paginated)."""
        return await self._paginate(
            "supplier_invoices",
            params=filters or None,
            on_page=on_page,
        )

    async def list_all_transactions(
        self,
        date_from: str | None = None,
        date_to: str | None = None,
        on_page: Callable[[int, int], Awaitable[None]] | None = None,
    ) -> list[dict]:
        """List all bank transactions (auto-paginated)."""
        params: dict[str, str] = {}
        if date_from:
            params["filter[date_from]"] = date_from
        if date_to:
            params["filter[date_to]"] = date_to
        return await self._paginate("transactions", params=params or None, on_page=on_page)

    # ------------------------------------------------------------------
    # Firm API methods (accounting-firm mode — scoped per client company)
    # ------------------------------------------------------------------

    async def list_firm_companies(
        self,
        on_page: Callable[[int, int], Awaitable[None]] | None = None,
    ) -> list[dict]:
        """List all client companies accessible via a Firm API token."""
        return await self._paginate("companies", on_page=on_page)

    async def get_firm_company(self, company_id: str) -> dict:
        """Get details of a specific client company (Firm mode)."""
        return await self._request("GET", f"companies/{company_id}")

    async def list_company_invoices(
        self,
        company_id: str,
        on_page: Callable[[int, int], Awaitable[None]] | None = None,
        **filters: Any,
    ) -> list[dict]:
        """List customer invoices for a specific client company (Firm mode)."""
        return await self._paginate(
            f"companies/{company_id}/customer_invoices",
            params=filters or None,
            on_page=on_page,
        )

    async def list_company_customers(
        self,
        company_id: str,
        on_page: Callable[[int, int], Awaitable[None]] | None = None,
    ) -> list[dict]:
        """List customers for a specific client company (Firm mode)."""
        return await self._paginate(
            f"companies/{company_id}/customers",
            on_page=on_page,
        )

    async def list_company_suppliers(
        self,
        company_id: str,
        on_page: Callable[[int, int], Awaitable[None]] | None = None,
    ) -> list[dict]:
        """List suppliers for a specific client company (Firm mode)."""
        return await self._paginate(
            f"companies/{company_id}/suppliers",
            on_page=on_page,
        )

    async def list_company_supplier_invoices(
        self,
        company_id: str,
        on_page: Callable[[int, int], Awaitable[None]] | None = None,
        **filters: Any,
    ) -> list[dict]:
        """List supplier invoices for a specific client company (Firm mode)."""
        return await self._paginate(
            f"companies/{company_id}/supplier_invoices",
            params=filters or None,
            on_page=on_page,
        )

    async def list_company_transactions(
        self,
        company_id: str,
        date_from: str | None = None,
        date_to: str | None = None,
        on_page: Callable[[int, int], Awaitable[None]] | None = None,
    ) -> list[dict]:
        """List bank transactions for a specific client company (Firm mode)."""
        params: dict[str, str] = {}
        if date_from:
            params["filter[date_from]"] = date_from
        if date_to:
            params["filter[date_to]"] = date_to
        return await self._paginate(
            f"companies/{company_id}/transactions",
            params=params or None,
            on_page=on_page,
        )

    async def get_company_trial_balance(
        self,
        company_id: str,
        fiscal_year: str | None = None,
    ) -> dict:
        """Trial balance for a client company (Firm-only endpoint)."""
        params = {"fiscal_year": fiscal_year} if fiscal_year else None
        return await self._request(
            "GET",
            f"companies/{company_id}/trial_balance",
            params=params,
        )

    async def get_company_fec(
        self,
        company_id: str,
        fiscal_year: str | None = None,
    ) -> dict:
        """FEC (Fichier des Ecritures Comptables) export for a client company."""
        params = {"fiscal_year": fiscal_year} if fiscal_year else None
        return await self._request(
            "GET",
            f"companies/{company_id}/fec",
            params=params,
        )

    # ------------------------------------------------------------------
    # Write methods
    # ------------------------------------------------------------------

    async def create_invoice(self, data: dict) -> dict:
        """Create a customer invoice in Pennylane."""
        return await self._request("POST", "customer_invoices", json_data=data)

    async def create_customer(self, data: dict) -> dict:
        """Create a customer in Pennylane."""
        return await self._request("POST", "customers", json_data=data)

    async def import_supplier_invoice(self, data: dict) -> dict:
        """Import a supplier invoice in Pennylane."""
        return await self._request("POST", "supplier_invoices/import", json_data=data)

    # ------------------------------------------------------------------
    # OAuth2
    # ------------------------------------------------------------------

    @staticmethod
    async def refresh_token(
        client_id: str,
        client_secret: str,
        refresh_token: str,
    ) -> dict:
        """Exchange a refresh token for new access + refresh tokens."""
        async with httpx.AsyncClient(timeout=_TIMEOUT) as client:
            resp = await client.post(
                "https://app.pennylane.com/oauth/token",
                json={
                    "grant_type": "refresh_token",
                    "client_id": client_id,
                    "client_secret": client_secret,
                    "refresh_token": refresh_token,
                },
            )
            if resp.status_code >= 400:
                raise PennylaneAPIError(
                    resp.status_code,
                    "Token refresh failed",
                    resp.json() if resp.content else None,
                )
            return resp.json()
