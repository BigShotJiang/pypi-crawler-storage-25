"""Piilot plugin ``pennylane`` — Pennylane accounting integration.

Scaffolded on 2026-04-23 as part of PLT-18 Lot B.1.

**Current stage — B.4**: 14 agent tools + system prompt builder

* ``register()`` wires:
  - the plugin migrations (schema ``integrations_pennylane``) — B.2
  - the Pennylane connector (``pennylane.api``, credentials_schema for
    Company + Firm multi-token) — B.3
  - the sync handlers (full-company + Firm multi-client) — B.3
  - the 14 agent tools + ``build_pennylane_context_block`` prompt
    builder — B.4
* :mod:`piilot_pack_pennylane.repositories` — 6 repos
* :mod:`piilot_pack_pennylane.client` — HTTPX async client
* :mod:`piilot_pack_pennylane.sync` — Company + Firm sync orchestrators
* :mod:`piilot_pack_pennylane.tools` — 14 LangChain StructuredTool
  exports + hub/select/firm/business logic + prompt builder

Cohabitation with the in-tree core during the B.x → B.7 transition
-------------------------------------------------------------------

* Sync handler: the plugin wins the registration race (the loader
  runs before the core ``lifespan``). The core's attempt at
  ``_register_in_tree_sync_handlers()`` raises ValueError and is
  swallowed by its ERROR log (trompeur : it says "won't auto-sync"
  but the plugin handler IS registered).
* Tools: unlike sync handlers, the SDK ``_register_in_tree_tool``
  does NOT raise on duplicate ids — it just appends. Consequence: if
  both the plugin and the core register their 14 tools, the registry
  ends up with 28 specs. Agent runtime behaviour depends on whether
  ``TOOL_REGISTRY`` dedupes by id (keyed dict) or not (list). To be
  measured at boot (cf PLT18/index.md §7). If duplicates gum up the
  LLM prompt, expect a follow-up SDK primitive
  ``register_tool(... , on_duplicate="replace")`` in v0.3.

Wiring still to come:

* B.5 — Trésorerie module
* B.6 — HTTP routes + webhooks
* B.7 — feature flag ``PENNYLANE_MODE`` + bascule (remove in-tree
  ``_pre_register_pennylane_tools`` and ``_register_in_tree_sync_handlers``)

See ``PLT18/index.md`` in the AICockpit worktree for the full plan.
"""

from __future__ import annotations

import logging

from piilot.sdk import Plugin as _Plugin
from piilot.sdk import load_manifest

logger = logging.getLogger(__name__)


# Connector spec — kept at module scope so the schema registry (populated
# by ``register_connector``) can be rebuilt deterministically in tests.
_PENNYLANE_CONNECTOR_SPEC = {
    "id": "pennylane.api",
    "auth_type": "oauth2",
    "credentials_schema": [
        # Company-mode OAuth2 (primary).
        {"name": "access_token", "type": "secret", "required": True},
        {"name": "refresh_token", "type": "secret", "required": False},
        {"name": "token_expires_at", "type": "datetime", "required": False},
        {"name": "scopes", "type": "string", "required": False},
        {"name": "external_account_id", "type": "string", "required": False},
        # Firm-mode API token (PLT-8). Optional — present on Firm connections.
        {"name": "firm_token", "type": "secret", "required": False},
    ],
}


_TEMPLATE_PROMPT_SYSTEM = """Tu es l'analyste financier IA de {company_name}, connecte a Pennylane. Tu aides les equipes finance et direction a comprendre, analyser et piloter la sante financiere de l'entreprise.

Tes capacites :
1. **Analyse des factures** : tendances de facturation, delais de paiement, top clients, factures en retard
2. **Suivi de tresorerie** : solde des comptes, flux entrants/sortants, previsions
3. **Analyse des depenses** : fournisseurs principaux, evolution mensuelle
4. **KPIs financiers** : CA mensuel, DSO (delai moyen de paiement), marge, burn rate
5. **Alertes** : factures impayees > 30j, depenses anormales, solde bas

Quand on te demande une analyse, utilise les tools Pennylane pour recuperer les donnees reelles, puis presente ton analyse de maniere structuree avec des chiffres precis. Utilise send_table pour les tableaux et send_chart pour les graphiques.

Regles :
- Base-toi uniquement sur les donnees reelles de Pennylane
- Presente les montants en euros, dates au format francais (JJ/MM/AAAA)
- Compare toujours avec la periode precedente (mois, trimestre) quand c'est pertinent
- Signale les donnees manquantes ou incoherentes
- Ne donne jamais de conseil fiscal ou juridique — oriente vers l'expert-comptable
- Quand tu utilises send_table ou send_chart, ne repete PAS les memes donnees dans un message texte. Ajoute seulement un bref commentaire ou insight complementaire.

{company_context}"""


class Plugin(_Plugin):
    """Plugin entry class — must subclass ``piilot.sdk.Plugin``."""

    manifest = load_manifest(__file__)

    def register(self, ctx) -> None:
        """Wire the plugin's extension points.

        Order matters: migrations first (so the schema exists before any
        other primitive touches it), then declarative registrations
        (connector, scheduler handlers).
        """
        ctx.migrations.register_schema(
            "pennylane",
            __file__,
            "migrations",
        )

        # Connector declaration — drives auto-encryption of the ``secret``
        # credentials on every ``save_connection`` call (see sync.py).
        from piilot.sdk.connectors import register_connector

        register_connector(_PENNYLANE_CONNECTOR_SPEC)

        # Sync handlers — Company + Firm. Note: ``register_sync_handler`` is
        # a module-level function in ``piilot.sdk.scheduler`` (reads the
        # ``current_plugin`` contextvar), NOT a method on ``ctx.scheduler``
        # — the v0.2 SDK docstring at scheduler.py:83 suggesting
        # ``ctx.scheduler.register_sync_handler(...)`` is inaccurate;
        # ``ctx.scheduler`` is a ``SchedulerRegistry`` that only exposes
        # ``register_job`` today. Tracked as SDK v0.3 doc fix.
        #
        # The SDK scheduler refuses duplicate registration for a provider;
        # the core still registers its in-tree handler during the B.3 → B.7
        # transition window. Catch ValueError and log a warning so the
        # plugin stays otherwise active.
        from piilot.sdk.scheduler import register_sync_handler

        from .sync import sync_pennylane, sync_pennylane_firm

        try:
            register_sync_handler(
                "pennylane",
                handler=sync_pennylane,
                firm_handler=sync_pennylane_firm,
            )
        except ValueError as exc:
            logger.warning(
                "[pennylane] sync handler conflict — keeping in-tree core handler: %s",
                exc,
            )

        # Agent tools — 14 LangChain StructuredTool exports + one
        # system_prompt_builder. The builder is attached to the first
        # spec only; the SDK dedupes builders by ``(namespace, callable)``
        # identity so a single "--- PENNYLANE ---" block is injected even
        # when many tools are registered.
        from piilot.sdk.tools import register_tool

        from .tools import (
            build_pennylane_context_block,
            pennylane_compare_clients,
            pennylane_create_invoice,
            pennylane_get_balance,
            pennylane_get_invoice,
            pennylane_invoices_summary,
            pennylane_list_connections,
            pennylane_list_customers,
            pennylane_list_firm_clients,
            pennylane_list_invoices,
            pennylane_list_suppliers,
            pennylane_list_transactions,
            pennylane_select_connection,
            pennylane_select_firm_client,
            pennylane_transactions_summary,
        )

        _tool_specs: list[tuple[str, object]] = [
            ("pennylane.list_connections", pennylane_list_connections),
            ("pennylane.select_connection", pennylane_select_connection),
            ("pennylane.select_firm_client", pennylane_select_firm_client),
            ("pennylane.list_invoices", pennylane_list_invoices),
            ("pennylane.get_invoice", pennylane_get_invoice),
            ("pennylane.list_customers", pennylane_list_customers),
            ("pennylane.get_balance", pennylane_get_balance),
            ("pennylane.list_suppliers", pennylane_list_suppliers),
            ("pennylane.list_transactions", pennylane_list_transactions),
            ("pennylane.transactions_summary", pennylane_transactions_summary),
            ("pennylane.invoices_summary", pennylane_invoices_summary),
            ("pennylane.create_invoice", pennylane_create_invoice),
            ("pennylane.list_firm_clients", pennylane_list_firm_clients),
            ("pennylane.compare_clients", pennylane_compare_clients),
        ]

        for idx, (tool_id, tool_fn) in enumerate(_tool_specs):
            spec: dict = {"id": tool_id, "tool": tool_fn}
            if idx == 0:
                spec["system_prompt_builder"] = build_pennylane_context_block
            register_tool(spec)

        # Agent template — seed ``agents.agent_templates`` row (idempotent
        # upsert on ``id`` so the row first inserted by the core's
        # migrations 057/059/060/081 stays under the same UUID and existing
        # agents derived from this template keep their template_id link).
        from piilot.sdk.db import Json
        from piilot.sdk.templates import register_template

        register_template(
            {
                "id": "a1b2c3d4-0013-4000-a000-000000000013",
                "slug": "financial_analyst_pennylane",
                "template_name": "Analyste financier Pennylane",
                "description": (
                    "Analyse factures, tresorerie, depenses et KPIs "
                    "financiers depuis les donnees Pennylane synchronisees."
                ),
                "template_category": "finance",
                "icon": "📊",
                "prompt_system": _TEMPLATE_PROMPT_SYSTEM,
                "prompt_steps": Json(
                    [
                        {
                            "label": "Collecte",
                            "instruction": (
                                "Utilise les tools Pennylane pour recuperer "
                                "les donnees demandees (factures, transactions, "
                                "clients, solde)."
                            ),
                        },
                        {
                            "label": "Analyse",
                            "instruction": (
                                "Analyse les donnees collectees, calcule les "
                                "KPIs pertinents, identifie les tendances et "
                                "anomalies."
                            ),
                        },
                        {
                            "label": "Presentation",
                            "instruction": (
                                "Presente l'analyse de facon structuree avec "
                                "des chiffres precis. Utilise des tableaux et "
                                "graphiques quand c'est utile."
                            ),
                        },
                    ]
                ),
                "tools_enabled": [
                    # Multi-connection selectors — needed when the company
                    # has N≥2 active Pennylane connections. Data tools
                    # return an ambiguity message instructing the LLM to
                    # call pennylane_select_connection(ref=...). Without
                    # these the LLM can only ask the user in natural
                    # language and can't act on the reply. Pre-PLT-18 the
                    # core auto-injected them via a hardcoded
                    # _PENNYLANE_DATA_TOOLS set — now the plugin template
                    # is self-contained.
                    "pennylane_list_connections",
                    "pennylane_select_connection",
                    "pennylane_select_firm_client",
                    "pennylane_list_invoices",
                    "pennylane_get_invoice",
                    "pennylane_list_customers",
                    "pennylane_list_suppliers",
                    "pennylane_get_balance",
                    "pennylane_list_transactions",
                    "pennylane_transactions_summary",
                    "pennylane_invoices_summary",
                    "send_message",
                    "send_table",
                    "send_chart",
                    "finish",
                ],
                "output_types": ["text", "table", "chart"],
                "llm_model": None,
                "llm_temperature": 0.20,
                "requires_project": False,
                "requires_documents": False,
                "max_turns": 50,
                "inject_company_context": True,
                "requires_knowledge_base": False,
                "is_active": True,
            }
        )

        # Trésorerie module — seed ``modules.modules`` row (idempotent
        # upsert on ``module_slug``, preserving the UUID first inserted
        # by the core's migration 062 so existing access grants and
        # bookmarks keep resolving to the right module).
        from piilot.sdk.modules import register_module

        # NOTE: ``config`` must be wrapped in ``Json()`` so psycopg2 knows
        # how to adapt a Python dict to a JSONB column. The SDK wiring of
        # ``_upsert_module`` (backend/services/plugin_runtime/sdk_wiring.py:621)
        # uses a direct ``cur.execute(sql, values)`` and doesn't auto-wrap
        # dict payloads — candidate SDK v0.3 fix.
        register_module(
            {
                "slug": "pennylane-treasury",
                "module_name": "Trésorerie Pennylane",
                "description": (
                    "Dashboard trésorerie basé sur les données Pennylane "
                    "synchronisées : encaissements, décaissements, solde "
                    "bancaire, factures en attente, DSO."
                ),
                "icon": "landmark",
                "category": "finance",
                "status": "published",
                "config": Json({"type": "dashboard", "requires_integration": "pennylane"}),
            }
        )

        # HTTP routers. The main router holds 14 CRUD + treasury dashboard
        # endpoints (mounted at ``/plugins/pennylane/``). The webhook router
        # holds the HMAC-signed Pennylane events endpoint (mounted at
        # ``/plugins/pennylane/webhooks/``, bypassing the plugin_gate
        # middleware since SaaS callbacks don't carry ``X-Company-Id``).
        from piilot.sdk.http import register_router, register_webhook_router

        from .routes import router as plugin_router
        from .webhooks import router as webhook_router

        register_router(plugin_router)
        register_webhook_router(webhook_router)
