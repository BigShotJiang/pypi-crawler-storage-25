"""Tests for build_pennylane_context_block — system prompt injection (PLT-8 P7).

The helper advertises the tenant's Pennylane integrations to the LLM:
empty string when there's no connection, single-token note when N=1,
explicit list + usage instructions when N≥2.

Ported from the in-tree ``test_system_prompt_pennylane.py``. Patches
rewired from the core's ``connections_repo.list_by_company_provider`` to
the SDK's ``list_connections`` as imported by ``plugin.tools``.
"""

from __future__ import annotations

from unittest.mock import patch

from piilot_pack_pennylane.tools import build_pennylane_context_block

# The plugin tools module binds ``list_connections`` locally via
# ``from piilot.sdk.connectors import list_connections``. Patching here
# replaces the local rebinding, which is what the code actually calls.
_PATCH_LIST_CONNS = "piilot_pack_pennylane.tools.list_connections"


def _conn(conn_id: str, label: str, mode: str = "company", active: bool = True):
    return {
        "id": conn_id,
        "provider": "pennylane",
        "label": label,
        "is_active": active,
        "config": {"mode": mode},
    }


class TestBuildPennylaneContextBlock:
    def test_empty_company_id_returns_empty(self):
        assert build_pennylane_context_block("") == ""

    @patch(_PATCH_LIST_CONNS)
    def test_no_connections_returns_empty(self, mock_list):
        mock_list.return_value = []
        assert build_pennylane_context_block("c-1") == ""

    @patch(_PATCH_LIST_CONNS)
    def test_single_connection_states_active(self, mock_list):
        mock_list.return_value = [
            _conn("a", "Cabinet principal", "firm"),
        ]
        block = build_pennylane_context_block("c-1")
        assert "--- PENNYLANE ---" in block
        assert "Cabinet principal" in block
        assert "firm" in block
        # No ambiguity prompt in single-token case
        assert "pennylane_select_connection" not in block

    @patch(_PATCH_LIST_CONNS)
    def test_multiple_connections_instruct_llm_to_choose(self, mock_list):
        mock_list.return_value = [
            _conn("a", "Cabinet", "firm"),
            _conn("b", "Compta perso", "company"),
        ]
        block = build_pennylane_context_block("c-1")
        assert "--- PENNYLANE ---" in block
        assert "2 integrations" in block
        assert "Cabinet" in block
        assert "Compta perso" in block
        assert "pennylane_select_connection" in block

    @patch(_PATCH_LIST_CONNS)
    def test_inactive_connections_ignored(self, mock_list):
        mock_list.return_value = [
            _conn("a", "Cabinet", "firm"),
            _conn("b", "Deactivated", "company", active=False),
        ]
        block = build_pennylane_context_block("c-1")
        # Only one active → single-token formulation
        assert "2 integrations" not in block
        assert "Deactivated" not in block
