"""Smoke tests for the treasury module — B.5.

The in-tree ``test_modules_pennylane_treasury.py`` (~385 lines) is
entirely route-level and patches heavily core-specific symbols
(``connections_repo``, ``access_grants_repo``, ``modules_repo``,
``members_repo``, ``pennylane_treasury_service``). Rewiring the
patches to the SDK names we now use here would be churn without
signal until B.7 switches the frontend over to the plugin route.

This file keeps two lightweight checks: the plugin modules import
cleanly (catching most refactor accidents) and the router mounts at
the expected SDK-scoped prefix. Deeper integration tests are
deferred to post-B.7, same policy as ``test_sync_firm`` (B.3) and
``test_tools_pennylane_{select,firm,invoices_summary}`` (B.4).
"""

from __future__ import annotations

import importlib


def test_module_treasury_imports():
    """``module_treasury`` imports and exposes ``get_dashboard``."""
    mod = importlib.import_module("piilot_pack_pennylane.module_treasury")
    assert callable(getattr(mod, "get_dashboard", None))


def test_routes_module_imports():
    """``routes`` imports and exposes a FastAPI ``router``."""
    mod = importlib.import_module("piilot_pack_pennylane.routes")
    router = getattr(mod, "router", None)
    assert router is not None
    # The plugin router wires its own paths (``/treasury/dashboard``);
    # the SDK prefixes it with ``/plugins/{namespace}`` at mount time.
    paths = {route.path for route in router.routes}
    assert "/treasury/dashboard" in paths


def test_module_treasury_slug_constant():
    """The slug used in register_module and in the route must match."""
    from piilot_pack_pennylane import routes

    assert routes._TREASURY_MODULE_SLUG == "pennylane-treasury"
