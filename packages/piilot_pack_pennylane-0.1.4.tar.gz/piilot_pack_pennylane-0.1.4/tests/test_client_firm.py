"""Unit tests for PennylaneClient Firm API methods (PLT-8).

Patches ``_request`` / ``_paginate`` at the instance level with AsyncMock so
no real HTTP call is made. We verify the exact endpoint path and params
each Firm method uses — that's the contract we need to guarantee, the
lower layers (rate limit, retry, pagination) are already tested indirectly
through the Company-mode code path.
"""

from __future__ import annotations

from unittest.mock import AsyncMock

import pytest

from piilot_pack_pennylane.client import PennylaneClient


@pytest.fixture
def client() -> PennylaneClient:
    return PennylaneClient(access_token="fake-firm-token")


class TestListFirmCompanies:
    @pytest.mark.asyncio
    async def test_hits_companies_endpoint(self, client: PennylaneClient):
        client._paginate = AsyncMock(return_value=[{"id": "ext-1", "name": "ACME"}])
        result = await client.list_firm_companies()
        assert result == [{"id": "ext-1", "name": "ACME"}]
        client._paginate.assert_awaited_once()
        args, kwargs = client._paginate.call_args
        assert args[0] == "companies"
        assert kwargs.get("on_page") is None


class TestGetFirmCompany:
    @pytest.mark.asyncio
    async def test_hits_company_detail_endpoint(self, client: PennylaneClient):
        client._request = AsyncMock(return_value={"id": "ext-1", "name": "ACME"})
        result = await client.get_firm_company("ext-1")
        assert result["id"] == "ext-1"
        client._request.assert_awaited_once_with("GET", "companies/ext-1")


class TestListCompanyInvoices:
    @pytest.mark.asyncio
    async def test_hits_scoped_invoice_endpoint(self, client: PennylaneClient):
        client._paginate = AsyncMock(return_value=[{"id": "inv-1"}])
        result = await client.list_company_invoices("ext-1")
        assert result == [{"id": "inv-1"}]
        args, kwargs = client._paginate.call_args
        assert args[0] == "companies/ext-1/customer_invoices"
        assert kwargs.get("params") is None

    @pytest.mark.asyncio
    async def test_forwards_filters_as_query_params(self, client: PennylaneClient):
        client._paginate = AsyncMock(return_value=[])
        await client.list_company_invoices("ext-1", status="paid", limit=10)
        _, kwargs = client._paginate.call_args
        assert kwargs["params"] == {"status": "paid", "limit": 10}


class TestListCompanyCustomers:
    @pytest.mark.asyncio
    async def test_hits_scoped_customers_endpoint(self, client: PennylaneClient):
        client._paginate = AsyncMock(return_value=[])
        await client.list_company_customers("ext-42")
        args, _ = client._paginate.call_args
        assert args[0] == "companies/ext-42/customers"


class TestListCompanySuppliers:
    @pytest.mark.asyncio
    async def test_hits_scoped_suppliers_endpoint(self, client: PennylaneClient):
        client._paginate = AsyncMock(return_value=[])
        await client.list_company_suppliers("ext-42")
        args, _ = client._paginate.call_args
        assert args[0] == "companies/ext-42/suppliers"


class TestListCompanyTransactions:
    @pytest.mark.asyncio
    async def test_hits_scoped_transactions_endpoint_no_dates(self, client: PennylaneClient):
        client._paginate = AsyncMock(return_value=[])
        await client.list_company_transactions("ext-42")
        args, kwargs = client._paginate.call_args
        assert args[0] == "companies/ext-42/transactions"
        assert kwargs.get("params") is None

    @pytest.mark.asyncio
    async def test_forwards_date_range_as_filters(self, client: PennylaneClient):
        client._paginate = AsyncMock(return_value=[])
        await client.list_company_transactions(
            "ext-42",
            date_from="2026-01-01",
            date_to="2026-03-31",
        )
        _, kwargs = client._paginate.call_args
        assert kwargs["params"] == {
            "filter[date_from]": "2026-01-01",
            "filter[date_to]": "2026-03-31",
        }


class TestGetCompanyTrialBalance:
    @pytest.mark.asyncio
    async def test_hits_trial_balance_endpoint_no_year(self, client: PennylaneClient):
        client._request = AsyncMock(return_value={"entries": []})
        await client.get_company_trial_balance("ext-1")
        client._request.assert_awaited_once_with(
            "GET",
            "companies/ext-1/trial_balance",
            params=None,
        )

    @pytest.mark.asyncio
    async def test_forwards_fiscal_year(self, client: PennylaneClient):
        client._request = AsyncMock(return_value={})
        await client.get_company_trial_balance("ext-1", fiscal_year="2025")
        client._request.assert_awaited_once_with(
            "GET",
            "companies/ext-1/trial_balance",
            params={"fiscal_year": "2025"},
        )


class TestGetCompanyFec:
    @pytest.mark.asyncio
    async def test_hits_fec_endpoint(self, client: PennylaneClient):
        client._request = AsyncMock(return_value={"url": "https://..."})
        await client.get_company_fec("ext-1", fiscal_year="2025")
        client._request.assert_awaited_once_with(
            "GET",
            "companies/ext-1/fec",
            params={"fiscal_year": "2025"},
        )

    @pytest.mark.asyncio
    async def test_fec_no_year(self, client: PennylaneClient):
        client._request = AsyncMock(return_value={})
        await client.get_company_fec("ext-1")
        _, kwargs = client._request.call_args
        assert kwargs["params"] is None
