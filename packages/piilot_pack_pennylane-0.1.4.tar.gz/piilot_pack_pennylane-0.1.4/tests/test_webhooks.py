"""Smoke tests for the Pennylane webhook receiver — B.6.

The in-tree ``test_webhooks_pennylane.py`` (~200 lines) was deleted
with the rest of the in-tree Pennylane suite (commit ``8f56dbf``). It
patched ``connections_repo``, ``pennylane_invoices_repo``,
``pennylane_customers_repo`` and the parse helpers — rewiring those
patches to the plugin's own modules would be churn without signal now
that the plugin owns the path. Same deferral policy as
``test_routes.py``.

This file keeps three lightweight checks: the webhooks module imports
cleanly, the FastAPI router exposes ``POST /events``, and the HMAC
signature verification inside the handler works end-to-end against a
known secret + payload.
"""

from __future__ import annotations

import hashlib
import hmac
import importlib
import json

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient


def test_webhooks_module_imports():
    """``webhooks`` imports and exposes a FastAPI ``router``."""
    mod = importlib.import_module("piilot_pack_pennylane.webhooks")
    router = getattr(mod, "router", None)
    assert router is not None


def test_router_exposes_events_endpoint():
    """The single events endpoint must be ``POST /events``."""
    from piilot_pack_pennylane.webhooks import router

    matches = [
        r for r in router.routes
        if r.path == "/events" and "POST" in (r.methods or set())
    ]
    assert len(matches) == 1


def _post(client: TestClient, body: bytes, signature: str | None) -> "TestClient":
    headers = {"Content-Type": "application/json"}
    if signature is not None:
        headers["X-Pennylane-Signature"] = signature
    return client.post("/events", content=body, headers=headers)


@pytest.fixture()
def app(monkeypatch):
    """FastAPI app mounting only the webhook router for isolated tests."""
    from piilot_pack_pennylane.webhooks import router

    # Force a known secret so we can compute the expected signature.
    monkeypatch.setenv("PENNYLANE_WEBHOOK_SECRET", "test-secret")

    app = FastAPI()
    app.include_router(router)
    # Plug a no-op limiter state so slowapi doesn't blow up without
    # the SlowAPIMiddleware that the real plugin mount adds.
    from slowapi.errors import RateLimitExceeded

    @app.exception_handler(RateLimitExceeded)
    def _ignore(*args, **kwargs):  # pragma: no cover — never triggers in tests
        return None

    return app


def test_webhook_rejects_invalid_signature(app, monkeypatch):
    """An obviously wrong signature → 400."""
    # Patch the resolver to a no-op so we never hit the DB even if the
    # signature check were skipped.
    import piilot_pack_pennylane.webhooks as wh

    monkeypatch.setattr(
        wh, "_resolve_connection_from_webhook_sync", lambda *a, **kw: None,
    )

    client = TestClient(app)
    payload = json.dumps({"type": "invoice.updated", "data": {}}).encode()
    response = _post(client, payload, signature="deadbeef")
    assert response.status_code == 400
    assert response.json()["received"] is False


def test_webhook_accepts_valid_signature_unresolved_account(app, monkeypatch):
    """Valid HMAC + unresolved account_id → 200 with processed=False."""
    import piilot_pack_pennylane.webhooks as wh

    monkeypatch.setattr(
        wh, "_resolve_connection_from_webhook_sync", lambda *a, **kw: None,
    )

    client = TestClient(app)
    payload = json.dumps(
        {"type": "invoice.updated", "data": {}, "account_id": "unknown"}
    ).encode()
    sig = hmac.new(b"test-secret", payload, hashlib.sha256).hexdigest()

    response = _post(client, payload, signature=sig)
    assert response.status_code == 200
    body = response.json()
    assert body["received"] is True
    assert body["processed"] is False


def test_webhook_rejects_invalid_json(app, monkeypatch):
    """Valid HMAC + non-JSON body → 400."""
    payload = b"not json"
    sig = hmac.new(b"test-secret", payload, hashlib.sha256).hexdigest()

    client = TestClient(app)
    response = _post(client, payload, signature=sig)
    assert response.status_code == 400
    assert "Invalid JSON" in response.json()["error"]
