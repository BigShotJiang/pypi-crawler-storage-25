"""Lot D — validation of ``PATCH /plugins/pennylane/connections/{id}`` payload
shape and the ``entity_scopes`` gating logic in ``sync.py``.

Pure-function tests — no live backend, no FastAPI client. We exercise
the Pydantic request model's ``validate_patch`` method directly and
the ``scope_enabled`` derivation by constructing a fake connection
dict. Heavier integration tests (with the SDK + DB wired) stay out of
this file to keep the plugin suite fast and isolated (same policy as
B.3 / B.4 / B.5 deferrals).
"""

from __future__ import annotations

import pytest

from piilot_pack_pennylane.routes import EntityScopes, UpdateConnectionRequest


# ---------------------------------------------------------------------------
# UpdateConnectionRequest.validate_patch
# ---------------------------------------------------------------------------


def test_empty_patch_is_detected():
    req = UpdateConnectionRequest()
    assert req.is_empty() is True
    assert req.validate_patch() is None  # empty is valid (no-op)


def test_label_only_patch_is_valid():
    req = UpdateConnectionRequest(label="Sandbox1")
    assert req.is_empty() is False
    assert req.validate_patch() is None


def test_label_length_bounds_enforced_by_pydantic():
    # Pydantic trims at the Field(min_length / max_length) — we don't
    # have to re-check those here, but asserting the model raises
    # surfaces breakage if someone removes the Field constraint.
    with pytest.raises(Exception):
        UpdateConnectionRequest(label="")  # min_length=1
    with pytest.raises(Exception):
        UpdateConnectionRequest(label="x" * 101)  # max_length=100


def test_schedule_requires_both_frequency_and_times():
    req = UpdateConnectionRequest(sync_frequency=1)
    assert req.validate_patch() == (
        "sync_frequency and sync_times must be sent together"
    )

    req = UpdateConnectionRequest(sync_times=["06:00"])
    assert req.validate_patch() == (
        "sync_frequency and sync_times must be sent together"
    )


def test_schedule_length_must_match_frequency():
    req = UpdateConnectionRequest(sync_frequency=2, sync_times=["06:00"])
    assert req.validate_patch() == "sync_times must have exactly 2 entries"


def test_schedule_time_format_validated():
    req = UpdateConnectionRequest(sync_frequency=1, sync_times=["25:00"])
    assert req.validate_patch() is not None
    assert "Hour out of range" in req.validate_patch()

    req = UpdateConnectionRequest(sync_frequency=1, sync_times=["abc"])
    assert "Invalid time format" in (req.validate_patch() or "")


def test_schedule_times_must_be_sorted():
    req = UpdateConnectionRequest(sync_frequency=2, sync_times=["18:00", "06:00"])
    assert req.validate_patch() == "sync_times must be sorted ascending"


def test_schedule_valid_2x_accepted():
    req = UpdateConnectionRequest(sync_frequency=2, sync_times=["06:00", "18:00"])
    assert req.validate_patch() is None


def test_entity_scopes_all_false_rejected():
    scopes = EntityScopes(
        clients=False, invoices=False, suppliers=False, transactions=False,
    )
    req = UpdateConnectionRequest(entity_scopes=scopes)
    assert req.validate_patch() == "at least one entity_scope must be enabled"


def test_entity_scopes_at_least_one_true_accepted():
    req = UpdateConnectionRequest(
        entity_scopes=EntityScopes(
            clients=False, invoices=True, suppliers=False, transactions=False,
        ),
    )
    assert req.validate_patch() is None


def test_entity_scopes_defaults_true():
    # Omitted keys default to True at the Pydantic level.
    scopes = EntityScopes()
    assert scopes.clients and scopes.invoices and scopes.suppliers and scopes.transactions


def test_compound_patch_valid():
    req = UpdateConnectionRequest(
        label="Nouveau nom",
        sync_frequency=2,
        sync_times=["06:00", "18:00"],
        entity_scopes=EntityScopes(clients=True, invoices=False, suppliers=True, transactions=True),
    )
    assert req.is_empty() is False
    assert req.validate_patch() is None


# ---------------------------------------------------------------------------
# sync.py — scope_enabled derivation
# ---------------------------------------------------------------------------


def _scope_enabled(raw_scopes: dict) -> dict:
    """Mirror the derivation used inside ``sync_pennylane``.

    Duplicated here (not imported) to keep the test independent of
    implementation details — we only assert on the contract.
    """
    return {
        "invoices": bool(raw_scopes.get("invoices", True)),
        "customers": bool(raw_scopes.get("clients", True)),
        "suppliers": bool(raw_scopes.get("suppliers", True)),
        "supplier_invoices": bool(raw_scopes.get("invoices", True)),
        "transactions": bool(raw_scopes.get("transactions", True)),
    }


def test_scope_mapping_defaults_enable_all_entities_pre_lot_d():
    """Pre-Lot D connections have no entity_scopes in their config —
    every stream must stay enabled for backward compatibility."""
    result = _scope_enabled({})
    assert result == {
        "invoices": True, "customers": True, "suppliers": True,
        "supplier_invoices": True, "transactions": True,
    }


def test_scope_mapping_invoices_toggle_covers_customer_and_supplier_invoices():
    result = _scope_enabled({
        "clients": True, "invoices": False,
        "suppliers": True, "transactions": True,
    })
    assert result["invoices"] is False
    assert result["supplier_invoices"] is False
    assert result["customers"] is True
    assert result["suppliers"] is True


def test_scope_mapping_clients_toggle_only_disables_customers():
    result = _scope_enabled({
        "clients": False, "invoices": True,
        "suppliers": True, "transactions": True,
    })
    assert result["customers"] is False
    assert result["invoices"] is True  # Factures stay synced


def test_scope_mapping_suppliers_toggle_isolated_from_supplier_invoices():
    """Turning off the "Fournisseurs" toggle disables the suppliers
    entity but leaves supplier_invoices alone — those ride the
    "Factures" toggle (see UI mapping)."""
    result = _scope_enabled({
        "clients": True, "invoices": True,
        "suppliers": False, "transactions": True,
    })
    assert result["suppliers"] is False
    assert result["supplier_invoices"] is True
