"""Unit tests for sync_pennylane_firm orchestrator (PLT-8 Phase 2).

Only the pure-function tests are ported to B.3. The integration-style
tests that patched core names (``connections_repo``, ``sync_logs_repo``,
``storage_service``, ``cache``) need their patches rewired to the SDK
symbols now used by the plugin (``save_connection``, ``update_sync_state``,
``log_sync``, ``sdk_storage``, ``sdk_cache``). That rewrite is deferred
to a follow-up after B.7 (when the PENNYLANE_MODE flag lets the plugin
actually own the sync path — running these tests against the in-tree
copy in the meantime would add no signal).
"""

from __future__ import annotations

from datetime import UTC, datetime

# Import target module at file level so if a future fixture ever needs
# sync in sys.modules, it's here. (noqa: F401 to keep the import even
# when the rest of the file is dormant.)
from piilot_pack_pennylane import sync as _sync_mod  # noqa: F401
from piilot_pack_pennylane.sync import _map_firm_company_to_row

# ---------------------------------------------------------------------------
# Unit tests — _map_firm_company_to_row (pure function, no I/O)
# ---------------------------------------------------------------------------


class TestMapFirmCompanyToRow:
    def test_maps_minimal_payload(self):
        now = datetime.now(UTC)
        fc = {"id": 1234, "name": "ACME"}
        row = _map_firm_company_to_row(fc, now)
        assert row["external_company_id"] == "1234"
        assert row["company_name"] == "ACME"
        assert row["siren"] is None
        assert row["siret"] is None
        assert row["is_active"] is True
        assert row["synced_at"] == now

    def test_ignores_non_digit_siren(self):
        row = _map_firm_company_to_row(
            {"id": 1, "name": "X", "siren": "NOT-DIGITS"},
            datetime.now(UTC),
        )
        assert row["siren"] is None

    def test_preserves_valid_siren_and_siret(self):
        row = _map_firm_company_to_row(
            {
                "id": 42,
                "name": "Valid Co",
                "siren": "123456789",
                "siret": "12345678900015",
                "legal_form": "SAS",
            },
            datetime.now(UTC),
        )
        assert row["siren"] == "123456789"
        assert row["siret"] == "12345678900015"
        assert row["legal_form"] == "SAS"

    def test_falls_back_to_company_name_key(self):
        row = _map_firm_company_to_row(
            {"id": 7, "company_name": "Legacy Name"},
            datetime.now(UTC),
        )
        assert row["company_name"] == "Legacy Name"

    def test_preserves_raw_data(self):
        fc = {"id": 1, "name": "X", "unknown_field": "keep me"}
        row = _map_firm_company_to_row(fc, datetime.now(UTC))
        assert row["raw_data"] == fc
