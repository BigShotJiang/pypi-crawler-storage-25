"""Smoke tests for the plugin HTTP routes — B.6.

The in-tree ``test_integrations_pennylane_routes.py`` (~400 lines) was
deleted with the rest of the in-tree Pennylane suite (commit
``8f56dbf``). It patched dozens of core symbols
(``connections_repo``, ``connectors_registry_repo``, OAuth helpers,
encrypt/decrypt, sync orchestrators) — rewiring those patches to the
SDK + plugin equivalents would be churn without signal now that the
plugin owns the path. Same policy as the B.3 / B.4 / B.5 deferrals.

This file keeps three lightweight checks: the routes module imports
cleanly, the FastAPI router exposes every endpoint the in-tree core
served, and the SDK mounts it at the expected ``/plugins/pennylane``
prefix.
"""

from __future__ import annotations

import importlib


# Paths declared by the plugin router (without the SDK ``/plugins/pennylane``
# prefix that ``register_router`` adds at mount time). One entry per
# in-tree route the plugin replaces.
EXPECTED_PATHS: set[str] = {
    "/treasury/dashboard",
    "/connections",
    "/connections/{connection_id}",  # PATCH — Lot D (replaces /schedule)
    "/connect",
    "/connect-firm",
    "/disconnect",
    "/firm-clients",
    "/firm-clients/{client_id}",
    "/authorize",
    "/callback",
    "/status",
    "/sync-progress",
    "/invoices",
    "/customers",
    "/transactions",
}


def test_routes_module_imports():
    """``routes`` imports and exposes a FastAPI ``router``."""
    mod = importlib.import_module("piilot_pack_pennylane.routes")
    router = getattr(mod, "router", None)
    assert router is not None


def test_router_exposes_all_expected_paths():
    """Every endpoint the in-tree core served is reachable on the plugin."""
    from piilot_pack_pennylane.routes import router

    paths = {route.path for route in router.routes}
    missing = EXPECTED_PATHS - paths
    assert not missing, f"missing routes: {sorted(missing)}"


def test_router_methods_match_expectations():
    """Sanity check on the verb of a few critical endpoints."""
    from piilot_pack_pennylane.routes import router

    by_path: dict[str, set[str]] = {}
    for route in router.routes:
        by_path.setdefault(route.path, set()).update(route.methods or set())

    assert "POST" in by_path["/connect"]
    assert "POST" in by_path["/connect-firm"]
    assert "DELETE" in by_path["/disconnect"]
    assert "PATCH" in by_path["/connections/{connection_id}"]
    assert "GET" in by_path["/treasury/dashboard"]
    assert "GET" in by_path["/authorize"]
    assert "GET" in by_path["/callback"]
