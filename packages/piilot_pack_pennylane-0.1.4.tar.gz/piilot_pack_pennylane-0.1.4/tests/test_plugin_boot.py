"""Smoke tests that prove the plugin boots correctly.

At B.3 the plugin's ``register()`` wires:
- the migrations directory (schema ``integrations_pennylane``)
- the ``pennylane.api`` connector spec
- the sync handler (with ``firm_handler``) — may raise ValueError if the
  in-tree core handler is already registered, in which case the plugin
  catches and logs a warning.

We verify:
1. The plugin package imports without error.
2. The manifest loaded from ``pyproject.toml`` is valid.
3. ``Plugin.register(ctx)`` runs to completion against a fake Context
   — without raising, even when the sync handler is a duplicate.
"""

from __future__ import annotations

import importlib


def test_plugin_package_imports():
    """The plugin package is importable — basic syntactic smoke."""
    pkg = importlib.import_module("piilot_pack_pennylane")
    assert hasattr(pkg, "Plugin"), "The plugin package must expose a 'Plugin' class"


def test_manifest_valid():
    """The pyproject.toml manifest passes the SDK schema."""
    pkg = importlib.import_module("piilot_pack_pennylane")
    m = pkg.Plugin.manifest
    assert m["manifest_version"] == 1
    assert m["namespace"] == "pennylane"
    assert "supported_modes" in m and m["supported_modes"]
    assert "sdk_compat" in m


def test_plugin_register_wires_primitives(fake_ctx, plugin_context):
    """``Plugin.register()`` wires migrations + connector + sync handler.

    Under a fresh plugin contextvar the scheduler registry is empty, so
    ``register_sync_handler`` should succeed without the ValueError
    fallback path.
    """
    # Reset scheduler registry before the test so duplicate detection
    # doesn't bleed from other tests in the session.
    from piilot.sdk import scheduler as sdk_scheduler

    sdk_scheduler._reset_sync_handlers_for_tests()

    pkg = importlib.import_module("piilot_pack_pennylane")
    plugin = pkg.Plugin()
    with plugin_context("pennylane"):
        result = plugin.register(fake_ctx)
    assert result is None

    # The sync handler is registered for the "pennylane" provider.
    handlers = sdk_scheduler._drain_sync_handlers()
    assert "pennylane" in handlers
    ns, _handler, firm_handler = handlers["pennylane"]
    assert ns == "pennylane"
    assert firm_handler is not None, "firm_handler must be wired for PLT-8 multi-token"


def test_plugin_register_handles_duplicate_sync_handler(fake_ctx, plugin_context):
    """If the provider already has a registered handler (simulating the
    core's in-tree registration), the plugin catches ValueError and
    continues — register() still returns None (non-fatal)."""
    from piilot.sdk import scheduler as sdk_scheduler

    sdk_scheduler._reset_sync_handlers_for_tests()

    async def _fake_existing_handler(_conn):  # pragma: no cover
        return {}

    sdk_scheduler._register_in_tree_handler("pennylane", "core-in-tree", _fake_existing_handler, None)

    pkg = importlib.import_module("piilot_pack_pennylane")
    plugin = pkg.Plugin()
    with plugin_context("pennylane"):
        # Must NOT raise despite the duplicate
        result = plugin.register(fake_ctx)
    assert result is None
