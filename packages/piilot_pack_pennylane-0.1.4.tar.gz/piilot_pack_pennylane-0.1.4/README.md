# piilot-pack-pennylane

> Pennylane integration — invoices & treasury

Piilot plugin that wraps the [Pennylane](https://pennylane.com)
accounting API (invoices, suppliers, treasury) and exposes it to
Piilot agents and modules.

## Status

**v0.0.1 — scaffold only.** The plugin is intentionally inert at this
stage: `Plugin.register()` is a no-op. Real wiring is added
incrementally by PLT-18 Lot B (sub-lots B.2 → B.6):

| Sub-lot | Brings |
|---|---|
| B.2 | Migrations + repositories (schema `integrations_pennylane`) |
| B.3 | HTTP connector + scheduler sync |
| B.4 | 14 agent tools + system-prompt builder |
| B.5 | Trésorerie module |
| B.6 | REST routes + webhooks |

Track the plan in the AICockpit worktree at `PLT18/index.md`.

## Install (dev)

The core Piilot dev stack picks this plugin up via a bind mount. Clone
it next to (or inside) the core's `plugins-dev/` and restart the
backend container:

```bash
# From AICockpit/workspaces/<worktree>/plugins-dev/
gh repo clone Kinetics-Consulting-V2/piilot-pack-pennylane

# Then, from the worktree root:
docker compose -f compose.dev.yml restart backend
```

Watch the logs for:

```
[plugins] Loaded: pennylane v0.0.1
```

## Run the tests

```bash
pip install -e .[dev]
pytest
```

## Conventions

- **SDK contract** — the plugin imports only from `piilot.sdk.*`. The
  core loader's AST check refuses any `from backend.*` or `import
  backend`.
- **Namespace** — every identifier the plugin exposes (handler ids,
  tool ids, i18n keys, env vars, HTTP routes) is prefixed by
  `pennylane`.
- **DB schema** — all plugin-owned tables live under
  `integrations_pennylane.*`. Migrations are idempotent (`IF NOT
  EXISTS` everywhere).

## Versioning

Semantic Versioning. `sdk_compat` in `pyproject.toml` pins the Piilot
SDK range this plugin builds against. Watch the core's
[`docs/SDK_CHANGELOG.md`][changelog] for breaking changes.

[changelog]: https://github.com/Kinetics-Consulting-V2/AICockpit/blob/main/docs/SDK_CHANGELOG.md

## License

Apache-2.0. See [`LICENSE`](LICENSE).
