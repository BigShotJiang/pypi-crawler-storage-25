"""
V7 Capital CLI — Interactive terminal authentication

Commands:
  v7-cli login   — Login with email/password via /api/auth/login
  v7-cli logout  — Delete stored credentials
  v7-cli status  — Show current auth status

No Supabase credentials needed — auth goes through the V7 Capital API.
"""

import getpass

import click
import httpx

from .config import API_BASE_URL, REQUEST_TIMEOUT
from .credentials import load_credentials, save_credentials, delete_credentials


@click.group()
def main():
    """V7 Capital CLI — Authenticate and manage your MCP connection."""
    pass


@main.command()
def login():
    """Login to V7 Capital with email and password."""
    email = click.prompt("Email")
    password = getpass.getpass("Password: ")

    click.echo("Logging in...")

    try:
        with httpx.Client(timeout=REQUEST_TIMEOUT) as client:
            # Authenticate via V7 Capital API (Supabase handled server-side)
            r = client.post(
                f"{API_BASE_URL}/api/auth/login",
                json={"email": email, "password": password},
            )

            if r.status_code == 401:
                click.echo("Error: Invalid email or password.", err=True)
                raise SystemExit(1)

            r.raise_for_status()
            data = r.json()

            if not data.get("success"):
                click.echo(f"Error: {data.get('error', 'Login failed')}", err=True)
                raise SystemExit(1)

            save_credentials({
                "access_token": data["access_token"],
                "refresh_token": data["refresh_token"],
                "user_email": data.get("user_email", email),
            })

            click.echo(f"\n✓ Logged in as {data.get('user_email', email)}")
            click.echo("✓ Credentials saved to ~/.v7capital/credentials.json")
            click.echo(f"\nAPI: {API_BASE_URL}")

    except httpx.HTTPStatusError as e:
        click.echo(f"Error: API returned {e.response.status_code}", err=True)
        raise SystemExit(1)
    except httpx.ConnectError:
        click.echo(f"Error: Cannot connect to {API_BASE_URL}. Is the server running?", err=True)
        raise SystemExit(1)


@main.command()
def logout():
    """Delete stored credentials."""
    delete_credentials()
    click.echo("✓ Logged out. Credentials deleted.")


@main.command()
def status():
    """Show current authentication status."""
    creds = load_credentials()
    if not creds:
        click.echo("Not authenticated. Run 'v7-cli login' first.")
        return

    click.echo(f"Email: {creds.get('user_email', 'unknown')}")
    click.echo(f"API: {API_BASE_URL}")
    click.echo(f"Token: {'present' if creds.get('access_token') else 'missing'}")
    click.echo(f"Refresh token: {'present' if creds.get('refresh_token') else 'missing'}")
