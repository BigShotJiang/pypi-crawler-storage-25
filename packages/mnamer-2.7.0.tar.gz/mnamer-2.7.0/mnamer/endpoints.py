"""Provides a low-level interface for metadata media APIs.

Endpoint functions raise exceptions on API errors, so the response TypedDicts in this module
describe the success-case shape only. Keys are snake_case. Responses are routed through
`normalize_keys` to translate API camelCase/PascalCase before cast. Fields documented as
always-present per the API contract are required; partial/optional fields use `NotRequired`.
"""

import datetime
from re import match
from time import sleep
from typing import Any, NotRequired, TypedDict, cast

from mnamer.exceptions import (
    MnamerException,
    MnamerNetworkException,
    MnamerNotFoundException,
)
from mnamer.language import Language
from mnamer.utils import clean_dict, normalize_keys, parse_date, request_json

OMDB_PLOT_TYPES = {"short", "long"}
MAX_RETRIES = 5


class OmdbSearchEntry(TypedDict):
    imdb_id: str
    year: str
    title: NotRequired[str]


class OmdbTitleResponse(TypedDict):
    title: str
    year: str
    released: NotRequired[str]
    plot: NotRequired[str]
    imdb_id: str
    error: NotRequired[str]


class OmdbSearchResponse(TypedDict):
    search: list[OmdbSearchEntry]
    total_results: NotRequired[str]
    error: NotRequired[str]


class TmdbSearchEntry(TypedDict):
    id: int
    title: str
    release_date: NotRequired[str]
    overview: NotRequired[str]


class TmdbMovieResponse(TypedDict):
    id: int
    title: str
    release_date: NotRequired[str]
    overview: NotRequired[str]
    imdb_id: NotRequired[str]


class TmdbSearchResponse(TypedDict):
    results: list[TmdbSearchEntry]
    total_pages: int
    total_results: int


class TvdbLinks(TypedDict):
    last: int


class TvdbSeriesData(TypedDict):
    id: int
    series_name: str


class TvdbSeriesResponse(TypedDict):
    data: TvdbSeriesData


class TvdbEpisodeEntry(TypedDict):
    first_aired: str
    aired_episode_number: int
    aired_season: int
    overview: str | None
    episode_name: str


class TvdbEpisodesResponse(TypedDict):
    data: list[TvdbEpisodeEntry]
    links: TvdbLinks


class TvdbSearchEntry(TypedDict):
    id: int


class TvdbSearchResponse(TypedDict):
    data: list[TvdbSearchEntry]


class TvMazeExternals(TypedDict):
    thetvdb: int | str | None
    imdb: NotRequired[str | None]


class TvMazeShow(TypedDict):
    id: int
    name: str
    externals: TvMazeExternals


class TvMazeSearchEntry(TypedDict):
    show: TvMazeShow


class TvMazeEpisode(TypedDict):
    airdate: str | None
    number: int | None
    season: int
    name: str | None
    summary: str | None


def omdb_title(
    api_key: str,
    id_imdb: str | None = None,
    media: str | None = None,
    title: str | None = None,
    season: int | None = None,
    episode: int | None = None,
    year: int | None = None,
    plot: str | None = None,
    cache: bool = True,
) -> OmdbTitleResponse:
    """
    Looks up media by id using the Open Movie Database.

    Online docs: http://www.omdbapi.com/#parameters
    """
    if (not title and not id_imdb) or (title and id_imdb):
        raise MnamerException("either id_imdb or title must be specified")
    elif plot and plot not in OMDB_PLOT_TYPES:
        raise MnamerException(f"plot must be one of {','.join(OMDB_PLOT_TYPES)}")
    url = "http://www.omdbapi.com"
    parameters: dict[str, Any] = {
        "apikey": api_key,
        "i": id_imdb,
        "t": title,
        "y": year,
        "season": season,
        "episode": episode,
        "type": media,
        "plot": plot,
    }
    status, content = request_json(url, clean_dict(parameters), cache=cache)
    content = normalize_keys(content)
    error = content.get("error")
    if status == 401:
        if error == "Request limit reached!":
            raise MnamerException("API request limit reached")
        raise MnamerException("invalid API key")
    elif status != 200 or not content:  # pragma: no cover
        raise MnamerNetworkException("OMDb down or unavailable?")
    elif error:
        raise MnamerNotFoundException(error)
    return cast(OmdbTitleResponse, content)


def omdb_search(
    api_key: str,
    query: str,
    year: int | None = None,
    media: str | None = None,
    page: int = 1,
    cache: bool = True,
) -> OmdbSearchResponse:
    """
    Search for media using the Open Movie Database.

    Online docs: http://www.omdbapi.com/#parameters.
    """
    if page < 1 or page > 100:
        raise MnamerException("page must be between 1 and 100")
    url = "http://www.omdbapi.com"
    parameters: dict[str, Any] = {
        "apikey": api_key,
        "s": query,
        "y": year,
        "type": media,
        "page": page,
    }
    status, content = request_json(url, clean_dict(parameters), cache=cache)
    content = normalize_keys(content)
    if status == 401:
        raise MnamerException("invalid API key")
    elif content and not content.get("total_results"):
        raise MnamerNotFoundException()
    elif not content or status != 200:  # pragma: no cover
        raise MnamerNetworkException("OMDb down or unavailable?")
    return cast(OmdbSearchResponse, content)


def tmdb_find(
    api_key: str,
    external_source: str,
    external_id: str,
    language: Language | None = None,
    cache: bool = True,
) -> dict[str, Any]:
    """
    Search for The Movie Database objects using another DB's foreign key.

    Note: language codes aren't checked on this end or by TMDb, so if you
        enter an invalid language code your search itself will succeed, but
        certain fields like synopsis will just be empty.

    Online docs: developers.themoviedb.org/3/find.
    """
    sources = ["imdb_id", "freebase_mid", "freebase_id", "tvdb_id", "tvrage_id"]
    if external_source not in sources:
        raise MnamerException(f"external_source must be in {sources}")
    if external_source == "imdb_id" and not match(r"tt\d+", external_id):
        raise MnamerException("invalid imdb tt-const value")
    url = "https://api.themoviedb.org/3/find/" + external_id or ""
    parameters: dict[str, Any] = {
        "api_key": api_key,
        "external_source": external_source,
        "language": language,
    }
    keys = [
        "movie_results",
        "person_results",
        "tv_episode_results",
        "tv_results",
        "tv_season_results",
    ]
    status, content = request_json(url, parameters, cache=cache)
    content = normalize_keys(content)
    if status == 401:
        raise MnamerException("invalid API key")
    elif status != 200 or not any(content.keys()):  # pragma: no cover
        raise MnamerNetworkException("TMDb down or unavailable?")
    elif not any(content.get(k, {}) for k in keys):
        raise MnamerNotFoundException
    return content


def tmdb_movies(
    api_key: str,
    id_tmdb: str,
    language: Language | None = None,
    cache: bool = True,
) -> TmdbMovieResponse:
    """
    Lookup a movie item using The Movie Database.

    Online docs: developers.themoviedb.org/3/movies.
    """
    url = f"https://api.themoviedb.org/3/movie/{id_tmdb}"
    parameters: dict[str, Any] = {"api_key": api_key, "language": language}
    status, content = request_json(url, parameters, cache=cache)
    content = normalize_keys(content)
    if status == 401:
        raise MnamerException("invalid API key")
    elif status == 404:
        raise MnamerNotFoundException
    elif status != 200 or not any(content.keys()):  # pragma: no cover
        raise MnamerNetworkException("TMDb down or unavailable?")
    return cast(TmdbMovieResponse, content)


def tmdb_search_movies(
    api_key: str,
    title: str,
    year: int | str | None = None,
    language: Language | None = None,
    region: str | None = None,
    adult: bool = False,
    page: int = 1,
    cache: bool = True,
) -> TmdbSearchResponse:
    """
    Search for movies using The Movie Database.

    Online docs: developers.themoviedb.org/3/search/search-movies.
    """
    url = "https://api.themoviedb.org/3/search/movie"
    parameters: dict[str, Any] = {
        "api_key": api_key,
        "query": title,
        "page": page,
        "include_adult": adult,
        "language": language,
        "region": region,
        "year": year,
    }
    status, content = request_json(url, parameters, cache=cache)
    content = normalize_keys(content)
    if status == 401:
        raise MnamerException("invalid API key")
    elif status != 200 or not any(content.keys()):  # pragma: no cover
        raise MnamerNetworkException("TMDb down or unavailable?")
    elif not content.get("total_results"):
        raise MnamerNotFoundException
    return cast(TmdbSearchResponse, content)


def tvdb_login(api_key: str) -> str:
    """
    Logs into TVDb using the provided api key.

    Note: You can register for a free TVDb key at thetvdb.com/?tab=apiregister
    Online docs: api.thetvdb.com/swagger#!/Authentication/post_login.
    """
    url = "https://api.thetvdb.com/login"
    body = {"apikey": api_key}
    status, content = request_json(url, body=body, cache=False)
    if status == 401:
        raise MnamerException("invalid api key")
    elif status != 200 or not content.get("token"):  # pragma: no cover
        raise MnamerNetworkException("TVDb down or unavailable?")
    return content["token"]


def tvdb_refresh_token(token: str) -> str:
    """
    Refreshes JWT token.

    Online docs: api.thetvdb.com/swagger#!/Authentication/get_refresh_token.
    """
    url = "https://api.thetvdb.com/refresh_token"
    headers = {"Authorization": f"Bearer {token}"}
    status, content = request_json(url, headers=headers, cache=False)
    if status == 401:
        raise MnamerException("invalid token")
    elif status != 200 or not content.get("token"):  # pragma: no cover
        raise MnamerNetworkException("TVDb down or unavailable?")
    return content["token"]


def tvdb_episodes_id(
    token: str,
    id_tvdb: str,
    language: Language | None = None,
    cache: bool = True,
) -> dict[str, Any]:
    """
    Returns the full information for a given episode id.

    Online docs: https://api.thetvdb.com/swagger#!/Episodes.
    """
    Language.ensure_valid_for_tvdb(language)
    url = f"https://api.thetvdb.com/episodes/{id_tvdb}"
    headers = {"Authorization": f"Bearer {token}"}
    if language:
        headers["Accept-Language"] = language.a2
    status, content = request_json(
        url, headers=headers, cache=cache is True and language is None
    )
    content = normalize_keys(content)
    if status == 401:
        raise MnamerException("invalid token")
    elif status == 404 or not content.get("data"):
        raise MnamerNotFoundException
    elif status != 200:  # pragma: no cover
        raise MnamerNetworkException("TVDb down or unavailable?")
    elif content["data"]["id"] == 0:
        raise MnamerNotFoundException
    return content


def tvdb_series_id(
    token: str,
    id_tvdb: str,
    language: Language | None = None,
    cache: bool = True,
) -> TvdbSeriesResponse:
    """
    Returns a series records that contains all information known about a
    particular series id.

    Online docs: api.thetvdb.com/swagger#!/Series/get_series_id.
    """
    Language.ensure_valid_for_tvdb(language)
    url = f"https://api.thetvdb.com/series/{id_tvdb}"
    headers = {"Authorization": f"Bearer {token}"}
    if language:
        headers["Accept-Language"] = language.a2
    status, content = request_json(
        url, headers=headers, cache=cache is True and language is None
    )
    content = normalize_keys(content)
    if status == 401:
        raise MnamerException("invalid token")
    elif status == 404 or not content.get("data"):
        raise MnamerNotFoundException
    elif status != 200:  # pragma: no cover
        raise MnamerNetworkException("TVDb down or unavailable?")
    elif content["data"]["id"] == 0:
        raise MnamerNotFoundException
    return cast(TvdbSeriesResponse, content)


def tvdb_series_id_episodes(
    token: str,
    id_tvdb: str,
    page: int = 1,
    language: Language | None = None,
    cache: bool = True,
) -> TvdbEpisodesResponse:
    """
    All episodes for a given series.

    Note: Paginated with 100 results per page.
    Online docs: api.thetvdb.com/swagger#!/Series/get_series_id_episodes.
    """
    Language.ensure_valid_for_tvdb(language)
    url = f"https://api.thetvdb.com/series/{id_tvdb}/episodes"
    headers = {"Authorization": f"Bearer {token}"}
    if language:
        headers["Accept-Language"] = language.a2
    parameters: dict[str, Any] = {"page": page}
    status, content = request_json(
        url, parameters, headers=headers, cache=cache is True and language is None
    )
    content = normalize_keys(content)
    if status == 401:
        raise MnamerException("invalid token")
    elif status == 404 or not content.get("data"):
        raise MnamerNotFoundException
    elif status != 200:  # pragma: no cover
        raise MnamerNetworkException("TVDb down or unavailable?")
    return cast(TvdbEpisodesResponse, content)


def tvdb_series_id_episodes_query(
    token: str,
    id_tvdb: str,
    episode: int | None = None,
    season: int | None = None,
    page: int = 1,
    language: Language | None = None,
    cache: bool = True,
) -> TvdbEpisodesResponse:
    """
    Allows the user to query against episodes for the given series.

    Note: Paginated with 100 results per page; omitted imdbId-- when would you
    ever need to query against both tvdb and imdb series ids?
    Online docs: api.thetvdb.com/swagger#!/Series/get_series_id_episodes_query.
    """
    Language.ensure_valid_for_tvdb(language)
    url = f"https://api.thetvdb.com/series/{id_tvdb}/episodes/query"
    headers = {"Authorization": f"Bearer {token}"}
    if language:
        headers["Accept-Language"] = language.a2
    parameters: dict[str, Any] = {
        "airedSeason": season,
        "airedEpisode": episode,
        "page": page,
    }
    status, content = request_json(
        url,
        parameters,
        headers=headers,
        cache=cache is True and language is None,
    )
    content = normalize_keys(content)
    if status == 401:
        raise MnamerException("invalid token")
    elif status == 404 or not content.get("data"):
        raise MnamerNotFoundException
    elif status != 200:  # pragma: no cover
        raise MnamerNetworkException("TVDb down or unavailable?")
    return cast(TvdbEpisodesResponse, content)


def tvdb_search_series(
    token: str,
    series: str | None = None,
    id_imdb: str | None = None,
    id_zap2it: str | None = None,
    language: Language | None = None,
    cache: bool = True,
) -> TvdbSearchResponse:
    """
    Allows the user to search for a series based on the following parameters.

    Online docs: https://api.thetvdb.com/swagger#!/Search/get_search_series
    Note: results a maximum of 100 entries per page, no option for pagination.
    """
    Language.ensure_valid_for_tvdb(language)
    url = "https://api.thetvdb.com/search/series"
    parameters: dict[str, Any] = {
        "name": series,
        "imdbId": id_imdb,
        "zap2itId": id_zap2it,
    }
    headers = {"Authorization": f"Bearer {token}"}
    if language:
        headers["Accept-Language"] = language.a2
    status, content = request_json(
        url, parameters, headers=headers, cache=cache is True and language is None
    )
    content = normalize_keys(content)
    if status == 401:
        raise MnamerException("invalid token")
    elif status == 405:
        raise MnamerException(
            "series, id_imdb, id_zap2it parameters are mutually exclusive"
        )
    elif status == 404 or not content.get("data"):
        raise MnamerNotFoundException
    elif status != 200:  # pragma: no cover
        raise MnamerNetworkException("TVDb down or unavailable?")
    return cast(TvdbSearchResponse, content)


def tvmaze_show(
    id_tvmaze: str,
    embed_episodes: bool = False,
    cache: bool = False,
    attempt: int = 1,
) -> TvMazeShow:
    """
    Retrieve all primary information for a given show.

    Online docs: https://www.tvmaze.com/api#show-main-information
    """
    url = f"http://api.tvmaze.com/shows/{id_tvmaze}"
    parameters: dict[str, Any] = {}
    if embed_episodes:
        parameters["embed"] = "episodes"
    status, content = request_json(url, parameters, cache=cache)
    if status == 443 and attempt <= MAX_RETRIES:  # pragma: no cover
        sleep(attempt * 2)
        return tvmaze_show(id_tvmaze, embed_episodes, cache, attempt + 1)
    elif status == 404 or not content:
        raise MnamerNotFoundException
    elif status != 200:  # pragma: no cover
        raise MnamerNetworkException
    return cast(TvMazeShow, normalize_keys(content))


def tvmaze_show_search(
    query: str, cache: bool = True, attempt: int = 1
) -> list[TvMazeSearchEntry]:
    """
    Search through all the shows in the database by the show's name. A fuzzy
    algorithm is used (with a fuzziness value of 2), meaning that shows will be
    found even if your query contains small typos. Results are returned in order
    of relevancy (best matches on top) and contain each show's full information.

    Online docs: https://www.tvmaze.com/api#show-search
    """
    url = "http://api.tvmaze.com/search/shows"
    parameters: dict[str, Any] = {"q": query}
    status, content = request_json(url, parameters, cache=cache)
    if status == 443 and attempt <= MAX_RETRIES:  # pragma: no cover
        sleep(attempt * 2)
        return tvmaze_show_search(query, cache, attempt + 1)
    elif status == 404 or not content:
        raise MnamerNotFoundException
    elif status != 200:  # pragma: no cover
        raise MnamerNetworkException
    return cast(list[TvMazeSearchEntry], normalize_keys(content))


def tvmaze_show_single_search(
    query: str, cache: bool = True, attempt: int = 1
) -> TvMazeShow:
    """
    Singlesearch endpoint either returns exactly one result, or no result at
    all. This endpoint is also forgiving of typos, but less so than the regular
    search (with a fuzziness of 1 instead of 2), to reduce the chance of a false
    positive.

    Online docs: https://www.tvmaze.com/api#show-single-search
    """
    url = "http://api.tvmaze.com/singlesearch/shows"
    parameters: dict[str, Any] = {"q": query}
    status, content = request_json(url, parameters, cache=cache)
    if status == 443 and attempt <= MAX_RETRIES:  # pragma: no cover
        sleep(attempt * 2)
        return tvmaze_show_single_search(query, cache, attempt + 1)
    elif status == 404 or not content:
        raise MnamerNotFoundException
    elif status != 200:  # pragma: no cover
        raise MnamerNetworkException
    return cast(TvMazeShow, normalize_keys(content))


def tvmaze_show_lookup(
    id_imdb: str | None = None,
    id_tvdb: str | None = None,
    cache: bool = True,
    attempt: int = 1,
) -> TvMazeShow:
    """
    If you already know a show's tvrage, thetvdb or IMDB ID, you can use this
    endpoint to find this exact show on TVmaze.

    Online docs: https://www.tvmaze.com/api#show-lookup
    """
    if not [id_imdb, id_tvdb].count(None) == 1:
        raise MnamerException("id_imdb and id_tvdb are mutually exclusive")
    url = "http://api.tvmaze.com/lookup/shows"
    parameters: dict[str, Any] = {"imdb": id_imdb, "thetvdb": id_tvdb}
    status, content = request_json(url, parameters, cache=cache)
    if status == 443 and attempt <= MAX_RETRIES:  # pragma: no cover
        sleep(attempt * 2)
        return tvmaze_show_lookup(id_imdb, id_tvdb, cache, attempt + 1)
    elif status == 404:
        raise MnamerNotFoundException
    elif status != 200 or not content:  # pragma: no cover
        raise MnamerNetworkException
    return cast(TvMazeShow, normalize_keys(content))


def tvmaze_show_episodes_list(
    id_tvmaze: str,
    include_specials: bool = False,
    cache: bool = True,
    attempt: int = 1,
) -> list[TvMazeEpisode]:
    """
    A complete list of episodes for the given show. Episodes are returned in
    their airing order, and include full episode information. By default,
    specials are not included in the list.

    Online docs: https://www.tvmaze.com/api#show-episode-list
    """
    url = f"http://api.tvmaze.com/shows/{id_tvmaze}/episodes"
    parameters: dict[str, Any] = {"specials": int(include_specials)}
    status, content = request_json(url, parameters, cache=cache)
    if status == 443 and attempt <= MAX_RETRIES:  # pragma: no cover
        sleep(attempt * 2)
        return tvmaze_show_episodes_list(
            id_tvmaze, include_specials, cache, attempt + 1
        )
    elif status == 404:
        raise MnamerNotFoundException
    elif status != 200 or not content:  # pragma: no cover
        raise MnamerNetworkException
    return cast(list[TvMazeEpisode], normalize_keys(content))


def tvmaze_episodes_by_date(
    id_tvmaze: str,
    air_date: datetime.date | str,
    cache: bool = True,
    attempt: int = 1,
) -> list[TvMazeEpisode]:
    """
    Retrieves all episodes from this show that have aired on a specific date.
    Useful for daily shows that don't adhere to a common season numbering.

    Online docs: https://www.tvmaze.com/api#episodes-by-date
    """
    url = f"http://api.tvmaze.com/shows/{id_tvmaze}/episodesbydate"
    parameters: dict[str, Any] = {"date": parse_date(air_date)}
    status, content = request_json(url, parameters, cache=cache)
    if status == 443 and attempt <= MAX_RETRIES:  # pragma: no cover
        sleep(attempt * 2)
        return tvmaze_episodes_by_date(id_tvmaze, air_date, cache, attempt + 1)
    elif status == 404:
        raise MnamerNotFoundException
    elif status != 200 or not content:  # pragma: no cover
        raise MnamerNetworkException
    return cast(list[TvMazeEpisode], normalize_keys(content))


def tvmaze_episode_by_number(
    id_tvmaze: str,
    season: int | None,
    episode: int | None,
    cache: bool = True,
    attempt: int = 1,
) -> TvMazeEpisode:
    """
    Retrieve one specific episode from this show given its season number and
    episode number.

    Online docs: https://www.tvmaze.com/api#episode-by-number
    """
    url = f"http://api.tvmaze.com/shows/{id_tvmaze}/episodebynumber"
    parameters: dict[str, Any] = {"season": season, "number": episode}
    status, content = request_json(url, parameters, cache=cache)
    if status == 443 and attempt <= MAX_RETRIES:  # pragma: no cover
        sleep(attempt * 2)
        return tvmaze_episode_by_number(id_tvmaze, season, episode, cache, attempt + 1)
    elif status == 404:
        raise MnamerNotFoundException
    elif status != 200 or not content:  # pragma: no cover
        raise MnamerNetworkException
    return cast(TvMazeEpisode, normalize_keys(content))
