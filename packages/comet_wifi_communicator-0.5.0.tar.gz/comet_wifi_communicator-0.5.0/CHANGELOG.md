# CHANGELOG

<!-- version list -->

## v0.5.0 (2026-04-22)

### Features

- Add sleep before checking published package
  ([`d6d9225`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/d6d9225428ec76b5c47721ba2c4aadc01091b7ab))


## v0.4.8 (2026-04-22)

### Bug Fixes

- Variable usage
  ([`8af698d`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/8af698d9a00e24ef1a3d0152a5eb767303af216b))


## v0.4.7 (2026-04-22)

### Bug Fixes

- Publishing condition
  ([`683b4d5`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/683b4d592a836919d2e89fba4833b8b60381639f))


## v0.4.6 (2026-04-22)

### Bug Fixes

- PIP not using latest index
  ([`030ba81`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/030ba81846a56a1c4830f2c509fdaf9f2e3be2ff))


## v0.4.5 (2026-04-22)

### Bug Fixes

- Version variable
  ([`b2fc685`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/b2fc685dce5fd696ce59e9364f9af5d968da7193))


## v0.4.4 (2026-04-22)

### Bug Fixes

- Permissions
  ([`723198e`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/723198e2065251e32cacfcb6dd6fe99b66674393))


## v0.4.3 (2026-04-22)

### Bug Fixes

- Dependencies
  ([`4edddd4`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/4edddd4a19c594427e70fb71a2bcce3dc671e01e))

- Missing checking-out of repository
  ([`5fa474e`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/5fa474e20a4ff9438561f340a59a4fa08dd58b82))


## v0.4.2 (2026-04-22)

### Bug Fixes

- Missing python installation in publishing jobs
  ([`6829915`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/6829915dd521bb9bc4bac559836ae8eda4fc08de))


## v0.4.1 (2026-04-22)

### Bug Fixes

- Condition in publishing steps
  ([`7610604`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/7610604fa72e79fdd3a60345ff870a957083dcc8))


## v0.4.0 (2026-04-22)

### Bug Fixes

- Job condition
  ([`b40f424`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/b40f424d6acdba5d08358ad2b0682ce721f00685))

### Features

- Separate jobs
  ([`2c5f16a`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/2c5f16ae0a85d341137e6ee32bee70fd13058fc1))


## v0.3.0 (2026-04-22)

### Features

- Use trusted publisher instead of token
  ([`17ca6a6`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/17ca6a634cc54f1090e73bbcbeb35fccaf58e3b0))


## v0.2.4 (2026-04-22)


## v0.2.3 (2026-04-22)

### Bug Fixes

- Wrong package
  ([`c9a6007`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/c9a6007c9116f7708a368fcc928c6d7ee224fab2))


## v0.2.2 (2026-04-22)

### Bug Fixes

- Typo
  ([`e020fd6`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/e020fd6bc2f9f063a956acb59757263c652475ce))


## v0.2.1 (2026-04-22)

### Bug Fixes

- Variable in project description
  ([`f221bb8`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/f221bb8002a1a8569971dc76d8eea7531d2fe482))


## v0.2.0 (2026-04-22)

### Features

- Check installed version is most recent
  ([`e492f52`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/e492f525ecf6567994db13d8c3b8d881732e5f7e))


## v0.1.0 (2026-04-22)

### Bug Fixes

- Missing version in cd
  ([`123386b`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/123386bbc9f24ac67d9a04696ce65a04d9461bdd))

- Typo
  ([`590772a`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/590772accd11b27c18eee6f0cbaeeb90f6b93371))

- Typo in cd condition
  ([`98da947`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/98da94708465f9d74ed42edccb799d283dc164e6))

- Typo in cd condition
  ([`d5909e4`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/d5909e428e18c11cf6f5cd346171b53138422804))

### Features

- Add release to PyPI
  ([`9cf1c24`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/9cf1c24763a1dc41dda583e4a6058e20f7108647))

- Automatically release to TestPyPI
  ([`38cc78a`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/38cc78ac3593e9f279ca18f2b8aefabcc11e3f32))


## v0.0.9 (2026-04-20)

### Bug Fixes

- Allow zero versions for semantic_release
  ([`443ea8f`](https://github.com/zerog981/Comet-WiFi-Communicator/commit/443ea8f63cb5f23eaf279762d64283a6535b7389))


## v0.0.8 (2026-04-20)


## v0.0.7 (2026-04-13)


## v0.0.6 (2026-04-11)


## v0.0.5 (2026-04-11)


## v0.0.4 (2026-04-07)


## v0.0.3 (2026-03-27)


## v0.0.2 (2026-03-27)


## v0.0.1 (2026-02-04)

- Initial Release
