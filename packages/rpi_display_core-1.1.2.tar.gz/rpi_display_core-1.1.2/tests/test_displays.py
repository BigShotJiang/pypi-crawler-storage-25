import sys
import types

from PIL import Image


def test_ssd1306_display_initializes_and_forwards_calls(monkeypatch):
    recorded = {}

    class FakeI2C:
        def __init__(self, scl, sda):
            recorded["i2c_args"] = (scl, sda)

    class FakeSSD1306:
        def __init__(self, width, height, i2c, addr):
            recorded["ssd1306_init"] = {
                "width": width,
                "height": height,
                "i2c": i2c,
                "addr": addr,
            }
            self.image_calls = []
            self.show_calls = 0
            self.fill_calls = []

        def image(self, image):
            self.image_calls.append(image)

        def show(self):
            self.show_calls += 1

        def fill(self, value):
            self.fill_calls.append(value)

    monkeypatch.setitem(
        sys.modules, "board", types.SimpleNamespace(SCL="SCL", SDA="SDA")
    )
    monkeypatch.setitem(sys.modules, "busio", types.SimpleNamespace(I2C=FakeI2C))
    monkeypatch.setitem(
        sys.modules,
        "adafruit_ssd1306",
        types.SimpleNamespace(SSD1306_I2C=FakeSSD1306),
    )

    from rpi_display.displays.ssd1306 import SSD1306Display

    display = SSD1306Display(address=0x3D, width=96, height=16)
    assert display.width == 96
    assert display.height == 16
    assert recorded["i2c_args"] == ("SCL", "SDA")
    assert recorded["ssd1306_init"]["addr"] == 0x3D

    image = Image.new("1", (96, 16))
    display.show(image)
    assert display._oled.image_calls == [image]
    assert display._oled.show_calls == 1

    display.clear()
    assert display._oled.fill_calls == [0]
    assert display._oled.show_calls == 2


def test_sh1106_display_initializes_and_forwards_calls(monkeypatch):
    recorded = {}

    def fake_i2c(*, port, address):
        recorded["serial_init"] = {"port": port, "address": address}
        return "serial-object"

    class FakeSH1106:
        def __init__(self, serial, width, height):
            recorded["sh1106_init"] = {
                "serial": serial,
                "width": width,
                "height": height,
            }
            self.display_calls = []
            self.clear_calls = 0

        def display(self, image):
            self.display_calls.append(image)

        def clear(self):
            self.clear_calls += 1

    monkeypatch.setitem(
        sys.modules,
        "luma.core.interface.serial",
        types.SimpleNamespace(i2c=fake_i2c),
    )
    monkeypatch.setitem(
        sys.modules,
        "luma.oled.device",
        types.SimpleNamespace(sh1106=FakeSH1106),
    )

    from rpi_display.displays.sh1106 import SH1106Display

    display = SH1106Display(address=0x3C, port=1, width=128, height=64)
    assert display.width == 128
    assert display.height == 64
    assert recorded["serial_init"] == {"port": 1, "address": 0x3C}
    assert recorded["sh1106_init"] == {
        "serial": "serial-object",
        "width": 128,
        "height": 64,
    }

    image = Image.new("1", (128, 64))
    display.show(image)
    assert display._device.display_calls == [image]

    display.clear()
    assert display._device.clear_calls == 1
