"""Tests for all built-in widgets using MockDisplay (no hardware required)."""

from PIL import Image, ImageDraw

from rpi_display.widgets.clock import ClockWidget
from rpi_display.widgets.network import NetworkWidget
from rpi_display.widgets.shapes import ProgressBar
from rpi_display.widgets.spinner import Spinner
from rpi_display.widgets.system import SystemStatsWidget
from rpi_display.widgets.text import MultiLineText, ScrollingText, Text


def _draw():
    img = Image.new("1", (128, 64))
    return img, ImageDraw.Draw(img)


def _has_pixels(img):
    return any(b != 0 for b in img.tobytes())


# ---------------------------------------------------------------------------
# Text
# ---------------------------------------------------------------------------


def test_text_renders():
    img, draw = _draw()
    Text("hi").render(draw, 0, 0)
    assert _has_pixels(img)


def test_multiline_renders():
    img, draw = _draw()
    MultiLineText(["line a", "line b"]).render(draw, 0, 0)
    assert _has_pixels(img)


def test_scrolling_advances():
    _, draw = _draw()
    s = ScrollingText("hello world")
    s.render(draw, 0, 0)
    off1 = s._offset
    s.render(draw, 0, 0)
    off2 = s._offset
    assert off2 != off1 or off2 == 0, "offset must advance or wrap"


def test_scrolling_advances_by_speed():
    _, draw = _draw()
    s = ScrollingText("hello world", speed=5)
    initial = s._offset
    s.render(draw, 0, 0)
    assert s._offset == initial + 5 or s._offset == 0


# ---------------------------------------------------------------------------
# ProgressBar
# ---------------------------------------------------------------------------


def test_progressbar_renders():
    img, draw = _draw()
    ProgressBar(0.5).render(draw, 0, 10)
    assert _has_pixels(img)


def test_progressbar_clamps_high():
    assert ProgressBar(1.5).value == 1.0


def test_progressbar_clamps_low():
    assert ProgressBar(-0.1).value == 0.0


def test_progressbar_with_label_renders():
    img, draw = _draw()
    ProgressBar(0.65, label="CPU").render(draw, 4, 26)
    assert _has_pixels(img)


# ---------------------------------------------------------------------------
# ClockWidget
# ---------------------------------------------------------------------------


def test_clock_renders_pixels():
    img, draw = _draw()
    ClockWidget().render(draw, 0, 0)
    assert _has_pixels(img)


def test_clock_without_seconds_bar():
    img, draw = _draw()
    ClockWidget(show_seconds_bar=False).render(draw, 0, 0)
    assert _has_pixels(img)


# ---------------------------------------------------------------------------
# Spinner
# ---------------------------------------------------------------------------


def test_spinner_renders():
    img, draw = _draw()
    Spinner().render(draw, 0, 0)
    assert _has_pixels(img)


def test_spinner_advances_frame():
    _, draw = _draw()
    s = Spinner()
    s.render(draw, 0, 0)
    assert s._frame == 1
    s.render(draw, 0, 0)
    assert s._frame == 2


def test_spinner_wraps_frames():
    _, draw = _draw()
    s = Spinner()
    total = len(s.FRAMES)
    for _ in range(total):
        s.render(draw, 0, 0)
    assert s._frame == total


# ---------------------------------------------------------------------------
# SystemStatsWidget
# ---------------------------------------------------------------------------


def test_system_stats_renders():
    img, draw = _draw()
    SystemStatsWidget().render(draw, 0, 0)
    assert _has_pixels(img)


# ---------------------------------------------------------------------------
# NetworkWidget
# ---------------------------------------------------------------------------


def test_network_renders():
    img, draw = _draw()
    NetworkWidget().render(draw, 0, 0)
    assert _has_pixels(img)
