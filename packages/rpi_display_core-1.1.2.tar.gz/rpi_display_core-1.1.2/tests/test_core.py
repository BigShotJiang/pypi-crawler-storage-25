"""Tests for core framework: MockDisplay, canvas, Runner, load_font."""

import contextlib
import threading
import time

from PIL import Image

from rpi_display.canvas import canvas
from rpi_display.mock import MockDisplay
from rpi_display.runner import Runner
from rpi_display.widget import Widget, load_font

# ---------------------------------------------------------------------------
# MockDisplay
# ---------------------------------------------------------------------------


def test_mock_display_defaults():
    d = MockDisplay()
    assert d.width == 128
    assert d.height == 64
    assert d.last_image is None
    assert d.show_count == 0
    assert d.clear_count == 0


def test_mock_display_stores_image():
    d = MockDisplay()
    img = Image.new("1", (128, 64))
    d.show(img)
    assert d.last_image is img
    assert d.show_count == 1


def test_mock_display_clear():
    d = MockDisplay()
    img = Image.new("1", (128, 64))
    d.show(img)
    d.clear()
    assert d.last_image is None
    assert d.clear_count == 1


# ---------------------------------------------------------------------------
# canvas
# ---------------------------------------------------------------------------


def test_canvas_flushes_on_exit():
    d = MockDisplay()
    with canvas(d) as draw:
        draw.text((0, 0), "test", fill=255)
    assert d.show_count == 1
    assert d.last_image is not None


def test_canvas_flushes_even_on_exception():
    d = MockDisplay()
    try:
        with canvas(d) as draw:
            draw.text((0, 0), "test", fill=255)
            raise RuntimeError("intentional")
    except RuntimeError:
        pass
    # show() must still have been called
    assert d.show_count == 1


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------


class _Noop(Widget):
    def render(self, draw, x=0, y=0):
        pass


def test_runner_calls_show():
    d = MockDisplay()
    r = Runner(d, _Noop(), fps=20)
    t = threading.Thread(target=r.run, daemon=True)
    t.start()
    time.sleep(0.15)
    # daemon thread will be killed at test end; just assert show was called
    assert d.show_count >= 1


def test_runner_clears_on_exit():
    d = MockDisplay()

    def _raise(draw, x=0, y=0):
        raise StopIteration

    r = Runner(d, _raise, fps=20)
    with contextlib.suppress(StopIteration):
        r.run()
    assert d.clear_count >= 1


def test_runner_accepts_callable():
    """Runner should accept a plain callable, not only Widget instances."""
    d = MockDisplay()
    called = []

    def fn(draw, x=0, y=0):
        called.append(True)
        raise StopIteration

    r = Runner(d, fn, fps=20)
    with contextlib.suppress(StopIteration):
        r.run()
    assert called


# ---------------------------------------------------------------------------
# load_font
# ---------------------------------------------------------------------------


def test_load_font_returns_font():
    font = load_font(10)
    assert font is not None


def test_load_font_fallback():
    """Fallback must work even when the TTF file path is bad."""
    import rpi_display.widget as widget_module

    original = widget_module.DEFAULT_FONT_PATH
    try:
        widget_module.DEFAULT_FONT_PATH = "/nonexistent/path/font.ttf"
        font = load_font(10)
        assert font is not None
    finally:
        widget_module.DEFAULT_FONT_PATH = original
