from rpi_display.widget import Widget, load_font


class Spinner(Widget):
    FRAMES = ["|", "/", "-", "\\"]

    def __init__(self, label: str = "Loading...", font_size: int = 10):
        self.label = label
        self.font = load_font(font_size)
        self._frame = 0

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        char = self.FRAMES[self._frame % len(self.FRAMES)]
        draw.text((x, y), char, font=self.font, fill=255)
        if self.label:
            draw.text((x + 14, y), self.label, font=self.font, fill=255)
        self._frame += 1
