import socket
import subprocess

from rpi_display.widget import Widget, load_font


class NetworkWidget(Widget):
    def __init__(self, line_height: int = 13, font_size: int = 10):
        self.font = load_font(font_size)
        self.line_height = line_height

    def _hostname(self) -> str:
        try:
            return socket.gethostname()
        except OSError:
            return "N/A"

    def _ip(self) -> str:
        try:
            result = subprocess.run(
                ["hostname", "-I"], capture_output=True, text=True, timeout=2
            )
            parts = result.stdout.strip().split()
            return parts[0] if parts else "No IP"
        except Exception:
            return "N/A"

    def _ping(self, host: str = "8.8.8.8", timeout: int = 1) -> str:
        try:
            r = subprocess.run(
                ["ping", "-c1", f"-W{timeout}", host],
                capture_output=True,
                timeout=timeout + 1,
            )
            return "OK" if r.returncode == 0 else "FAIL"
        except Exception:
            return "FAIL"

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        lines = [
            f"Host: {self._hostname()}",
            f"IP:   {self._ip()}",
            f"Net:  {self._ping()}",
        ]
        for i, line in enumerate(lines):
            draw.text((x, y + i * self.line_height), line, font=self.font, fill=255)
