from rpi_display.widget import Widget, load_font


class Text(Widget):
    def __init__(self, text: str, font_size: int = 10, fill: int = 255):
        self.text = text
        self.font = load_font(font_size)
        self.fill = fill

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        draw.text((x, y), self.text, font=self.font, fill=self.fill)


class MultiLineText(Widget):
    def __init__(
        self, lines: list, font_size: int = 10, line_spacing: int = 4, fill: int = 255
    ):
        self.lines = lines
        self.font = load_font(font_size)
        self.line_spacing = line_spacing
        self.fill = fill

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        bbox = self.font.getbbox("A")
        line_height = (bbox[3] - bbox[1]) + self.line_spacing
        for i, line in enumerate(self.lines):
            draw.text((x, y + i * line_height), line, font=self.font, fill=self.fill)


class ScrollingText(Widget):
    def __init__(self, text: str, font_size: int = 10, speed: int = 3, fill: int = 255):
        self.text = text
        self.font = load_font(font_size)
        self.speed = speed
        self.fill = fill
        self._offset = 0

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        bbox = self.font.getbbox(self.text + "  ")
        text_width = bbox[2] - bbox[0]
        draw.text(
            (x - self._offset, y), self.text + "  ", font=self.font, fill=self.fill
        )
        self._offset += self.speed
        if self._offset >= text_width:
            self._offset = 0
