from datetime import datetime

from rpi_display.widget import Widget, load_font
from rpi_display.widgets.shapes import ProgressBar


class ClockWidget(Widget):
    def __init__(self, show_seconds_bar: bool = True):
        self.font_large = load_font(24)
        self.font_small = load_font(10)
        self.show_seconds_bar = show_seconds_bar

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        display_width = draw._image.size[0]
        now = datetime.now()
        time_str = now.strftime("%H:%M:%S")
        date_str = now.strftime("%a %d %b %Y")

        bbox = self.font_large.getbbox(time_str)
        tw = bbox[2] - bbox[0]
        draw.text(
            (x + (display_width - tw) // 2, y + 4),
            time_str,
            font=self.font_large,
            fill=255,
        )

        draw.line((x, y + 32, x + display_width - 1, y + 32), fill=255)

        bbox = self.font_small.getbbox(date_str)
        dw = bbox[2] - bbox[0]
        draw.text(
            (x + (display_width - dw) // 2, y + 34),
            date_str,
            font=self.font_small,
            fill=255,
        )

        if self.show_seconds_bar:
            pct = now.second / 59
            ProgressBar(pct, width=display_width, height=7).render(draw, x, y + 57)
