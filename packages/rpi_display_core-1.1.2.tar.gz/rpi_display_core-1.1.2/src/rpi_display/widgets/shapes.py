from typing import Optional

from rpi_display.widget import Widget, load_font


class ProgressBar(Widget):
    def __init__(
        self,
        value: float,
        width: int = 120,
        height: int = 10,
        label: Optional[str] = None,
        font_size: int = 8,
    ):
        self.value = max(0.0, min(1.0, value))
        self.bar_width = width
        self.bar_height = height
        self.label = label
        self.font = load_font(font_size) if label else None

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        draw.rectangle(
            (x, y, x + self.bar_width, y + self.bar_height), outline=255, fill=0
        )
        fill_w = int(self.bar_width * self.value)
        if fill_w > 0:
            draw.rectangle(
                (x, y, x + fill_w, y + self.bar_height), outline=255, fill=255
            )
        if self.label and self.font:
            draw.text(
                (x, y - self.bar_height - 2), self.label, font=self.font, fill=255
            )
