import subprocess
import time

from rpi_display.widget import Widget, load_font


class IpWidget(Widget):
    def __init__(self, label: str = "IP"):
        self.label = label
        self.font = load_font(10)

    def _get_value(self) -> str:
        try:
            result = subprocess.run(
                ["hostname", "-I"], capture_output=True, text=True, timeout=2
            )
            parts = result.stdout.strip().split()
            return parts[0] if parts else "No IP"
        except Exception:
            return "N/A"

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        draw.text(
            (x, y), f"{self.label}: {self._get_value()}", font=self.font, fill=255
        )


class CpuWidget(Widget):
    def __init__(self, label: str = "CPU"):
        self.label = label
        self.font = load_font(10)

    def _get_value(self) -> str:
        try:

            def read_stat():
                with open("/proc/stat") as f:
                    line = f.readline()
                fields = list(map(int, line.split()[1:]))
                idle = fields[3]
                total = sum(fields)
                return idle, total

            idle1, total1 = read_stat()
            time.sleep(0.1)
            idle2, total2 = read_stat()
            diff_total = total2 - total1
            diff_idle = idle2 - idle1
            if diff_total == 0:
                return "N/A"
            pct = 100.0 * (1 - diff_idle / diff_total)
            return f"{pct:.1f}%"
        except Exception:
            return "N/A"

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        draw.text(
            (x, y), f"{self.label}: {self._get_value()}", font=self.font, fill=255
        )


class RamWidget(Widget):
    def __init__(self, label: str = "RAM"):
        self.label = label
        self.font = load_font(10)

    def _get_value(self) -> str:
        try:
            result = subprocess.run(
                ["free", "-m"], capture_output=True, text=True, timeout=2
            )
            lines = result.stdout.strip().splitlines()
            parts = lines[1].split()
            total = int(parts[1])
            used = int(parts[2])
            pct = 100.0 * used / total if total else 0
            return f"{used}/{total}MB {pct:.0f}%"
        except Exception:
            return "N/A"

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        draw.text(
            (x, y), f"{self.label}: {self._get_value()}", font=self.font, fill=255
        )


class DiskWidget(Widget):
    def __init__(self, label: str = "Disk", path: str = "/"):
        self.label = label
        self.path = path
        self.font = load_font(10)

    def _get_value(self) -> str:
        try:
            result = subprocess.run(
                ["df", "-h", self.path], capture_output=True, text=True, timeout=2
            )
            lines = result.stdout.strip().splitlines()
            parts = lines[1].split()
            used = parts[2]
            total = parts[1]
            pct = parts[4]
            return f"{used}/{total} {pct}"
        except Exception:
            return "N/A"

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        draw.text(
            (x, y), f"{self.label}: {self._get_value()}", font=self.font, fill=255
        )


class TempWidget(Widget):
    def __init__(self, label: str = "Temp"):
        self.label = label
        self.font = load_font(10)

    def _get_value(self) -> str:
        try:
            with open("/sys/class/thermal/thermal_zone0/temp") as f:
                raw = int(f.read().strip())
            return f"{raw / 1000:.1f}C"
        except Exception:
            return "N/A"

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        draw.text(
            (x, y), f"{self.label}: {self._get_value()}", font=self.font, fill=255
        )


class SystemStatsWidget(Widget):
    def __init__(self, line_height: int = 13):
        self.widgets: list[Widget] = [
            IpWidget(),
            CpuWidget(),
            RamWidget(),
            DiskWidget(),
            TempWidget(),
        ]
        self.line_height = line_height

    def render(self, draw, x: int = 0, y: int = 0) -> None:
        for i, w in enumerate(self.widgets):
            w.render(draw, x, y + i * self.line_height)
