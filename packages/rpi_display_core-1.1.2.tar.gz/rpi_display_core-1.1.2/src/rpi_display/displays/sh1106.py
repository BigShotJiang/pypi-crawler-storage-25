class SH1106Display:
    def __init__(self, address=0x3C, port=1, width=128, height=64):
        from luma.core.interface.serial import i2c
        from luma.oled.device import sh1106

        self._serial = i2c(port=port, address=address)
        self._device = sh1106(self._serial, width=width, height=height)
        self.width = width
        self.height = height

    def show(self, image):
        self._device.display(image)

    def clear(self):
        self._device.clear()


Display = SH1106Display


__all__ = ["SH1106Display", "Display"]
