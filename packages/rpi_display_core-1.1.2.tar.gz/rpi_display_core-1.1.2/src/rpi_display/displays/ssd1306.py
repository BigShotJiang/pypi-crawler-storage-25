class SSD1306Display:
    def __init__(self, address=0x3C, width=128, height=64):
        import adafruit_ssd1306
        import board
        import busio

        i2c = busio.I2C(board.SCL, board.SDA)
        self._oled = adafruit_ssd1306.SSD1306_I2C(width, height, i2c, addr=address)
        self.width = width
        self.height = height

    def show(self, image):
        self._oled.image(image)
        self._oled.show()

    def clear(self):
        self._oled.fill(0)
        self._oled.show()


Display = SSD1306Display


__all__ = ["SSD1306Display", "Display"]
