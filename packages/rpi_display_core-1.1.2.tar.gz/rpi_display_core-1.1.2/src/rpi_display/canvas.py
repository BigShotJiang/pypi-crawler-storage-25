from contextlib import contextmanager

from PIL import Image, ImageDraw


@contextmanager
def canvas(display):
    image = Image.new("1", (display.width, display.height))
    draw = ImageDraw.Draw(image)
    try:
        yield draw
    finally:
        display.show(image)
