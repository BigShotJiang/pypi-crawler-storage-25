from PIL import Image


class MockDisplay:
    def __init__(self, width: int = 128, height: int = 64):
        self.width = width
        self.height = height
        self.last_image: Image.Image | None = None
        self.show_count: int = 0
        self.clear_count: int = 0

    def show(self, image: Image.Image) -> None:
        self.last_image = image
        self.show_count += 1

    def clear(self) -> None:
        self.last_image = None
        self.clear_count += 1
