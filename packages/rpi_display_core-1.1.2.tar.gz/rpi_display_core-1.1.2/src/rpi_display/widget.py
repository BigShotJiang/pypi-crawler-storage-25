from typing import Any

from PIL import ImageFont

DEFAULT_FONT_PATH = "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf"


def load_font(size: int = 10) -> Any:
    try:
        return ImageFont.truetype(DEFAULT_FONT_PATH, size)
    except OSError:
        return ImageFont.load_default()


class Widget:
    def render(self, draw, x: int = 0, y: int = 0) -> None:
        raise NotImplementedError
