import time

from rpi_display.canvas import canvas


class Runner:
    def __init__(self, display, widget_or_fn, fps: float = 1):
        self.display = display
        self._render = (
            widget_or_fn.render if hasattr(widget_or_fn, "render") else widget_or_fn
        )
        self.fps = fps

    def run(self):
        interval = 1.0 / self.fps
        try:
            while True:
                start = time.monotonic()
                with canvas(self.display) as draw:
                    self._render(draw, 0, 0)
                elapsed = time.monotonic() - start
                sleep = interval - elapsed
                if sleep > 0:
                    time.sleep(sleep)
        finally:
            self.display.clear()
