"""
Alter Vault Python SDK

OAuth token management with policy enforcement and automatic token injection.

Zero Token Exposure Architecture:
- Tokens are NEVER exposed to developers
- SDK handles all token operations internally
- Developers only see API results, never credentials
"""

from alter_sdk.client import AlterVault
from alter_sdk.exceptions import (
    AlterSDKError,
    AlterValueError,
    BackendError,
    ConnectConfigError,
    ConnectDeniedError,
    ConnectFlowError,
    ConnectTimeoutError,
    CredentialRevokedError,
    GrantDeletedError,
    GrantExpiredError,
    GrantNotFoundError,
    GrantRevokedError,
    NetworkError,
    PolicyViolationError,
    ProviderAPIError,
    ReAuthRequiredError,
    ScopeReauthRequiredError,
    TimeoutError,
)
from alter_sdk.models import (
    APICallAuditLog,
    AuthResult,
    ConnectResult,
    ConnectSession,
    GrantInfo,
    GrantListResult,
    GrantPolicy,
    TokenResponse,
)
from alter_sdk.providers.enums import CallerType, HttpMethod, Provider

__version__ = "0.8.0"

__all__ = [
    "AlterVault",
    "AuthResult",
    "CallerType",
    "HttpMethod",
    "Provider",
    "TokenResponse",
    "APICallAuditLog",
    "GrantInfo",
    "ConnectResult",
    "ConnectSession",
    "GrantListResult",
    "GrantPolicy",
    "AlterSDKError",
    "AlterValueError",
    "BackendError",
    "ReAuthRequiredError",
    "ConnectFlowError",
    "ConnectDeniedError",
    "ConnectConfigError",
    "ConnectTimeoutError",
    "PolicyViolationError",
    "GrantDeletedError",
    "GrantExpiredError",
    "GrantNotFoundError",
    "GrantRevokedError",
    "CredentialRevokedError",
    "ProviderAPIError",
    "ScopeReauthRequiredError",
    "NetworkError",
    "TimeoutError",
]
