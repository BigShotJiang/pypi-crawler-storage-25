"""
AlterAuthProvider — FastMCP-compatible auth provider using Alter Connect.

Implements FastMCP's auth provider protocol to handle OAuth authorization
via Alter Connect. When MCP OAuth is initiated, this provider triggers
an Alter Connect flow with all declared providers/scopes.
"""

from __future__ import annotations

import logging
from typing import TYPE_CHECKING, Any

from alter_sdk.exceptions import AlterValueError

if TYPE_CHECKING:
    from alter_sdk.client import AlterVault

logger = logging.getLogger(__name__)


class AlterAuthProvider:
    """FastMCP auth provider that uses Alter Connect for OAuth.

    Usage with FastMCP:
        from fastmcp import FastMCP
        from alter_sdk.mcp import AlterMCP

        vault = AlterVault(api_key="alter_key_...")
        alter = AlterMCP(vault)
        mcp = FastMCP("my-server")

        # The auth provider handles OAuth initiation via Alter Connect
        auth = AlterAuthProvider(vault, providers={"google": ["gmail.readonly"]})
    """

    def __init__(
        self,
        vault: AlterVault,
        *,
        providers: dict[str, list[str]] | None = None,
    ) -> None:
        """Initialize the auth provider.

        Args:
            vault: AlterVault client instance
            providers: Map of provider_id → required scopes
                       e.g., {"google": ["gmail.readonly"], "github": ["repo"]}
        """
        self._vault = vault
        self._providers = providers or {}

    async def create_auth_url(self, **kwargs: Any) -> str:  # noqa: ARG002 - FastMCP protocol signature
        """Create an Alter Connect URL for OAuth authorization.

        Called by FastMCP when a user needs to authenticate. The Connect
        session is built with **all** providers declared in
        ``self._providers`` and forwards every provider's scope list to
        ``vault.create_connect_session(required_scopes=...)``. This
        preserves the SDK's scope-attenuation invariant: a non-primary
        provider's scopes can never be silently dropped.

        Scope ceiling: each provider's scopes are forwarded to the
        backend as a per-provider ceiling. The backend validates that
        every requested scope is already in the Dev Portal's configured
        allowlist for that provider — requesting a scope outside the
        allowlist raises ``BackendError`` with ``scope_not_allowed``.
        The Dev Portal remains the authoritative ceiling: this hook can
        only NARROW what the Dev Portal allows, never widen it.

        Returns:
            Connect URL for user to complete OAuth authorization.
        """
        if not self._providers:
            # Raise AlterValueError (not bare ValueError) so callers
            # catching the SDK's base exception hierarchy
            # (AlterSDKError / AlterValueError) don't miss this.
            raise AlterValueError("No providers configured for AlterAuthProvider")

        allowed_providers = list(self._providers.keys())

        # Forward EVERY provider's scope ceiling. Dropping non-primary
        # entries (a previous bug) silently widened those providers'
        # scopes back to the Dev Portal default, breaking the
        # attenuation invariant. Empty/None scope lists are skipped so
        # we don't pin a provider to "no scopes."
        required_scopes: dict[str, list[str]] = {}
        for provider_id, scopes in self._providers.items():
            if scopes:
                required_scopes[provider_id] = list(scopes)

        session = await self._vault.create_connect_session(
            allowed_providers=allowed_providers,
            required_scopes=required_scopes if required_scopes else None,
        )
        return session.connect_url

    async def verify_token(self, token: str) -> dict[str, Any] | None:
        """Verify an incoming bearer token against the app's configured IDP.

        Delegates to ``AlterVault.verify_user_token``, which makes an
        HMAC-signed request to the backend's ``POST /sdk/auth/verify-token``
        endpoint. The backend runs the token through the production
        ``JWTValidationService``:

        - Signature verification against the app's IDP JWKS (RS256/ES256/PS256)
        - ``iss`` must match the configured issuer URL
        - ``aud`` must match the configured audience (if set)
        - ``exp`` must be in the future (with 30s clock skew tolerance)
        - Key rotation is handled by the backend's JWKS cache with
          kid-miss refetch
        - SSRF protection on JWKS and discovery fetches

        This is **not** a stub — it is a real auth boundary backed by the
        same verification service the backend uses for identity resolution
        on every SDK token request. Fail-closed: any verification failure
        (expired, bad signature, wrong issuer, wrong audience, network
        error, backend unavailable) returns ``None``, which FastMCP treats
        as "reject the request."

        Args:
            token: Bearer token from the incoming MCP request.

        Returns:
            ``{"sub": <verified subject>}`` on success, or ``None`` if
            the token cannot be trusted for any reason. Returning
            ``None`` MUST cause the caller to reject the request.

        SECURITY: The returned dict deliberately contains ONLY ``sub``.
        The backend ``verify-token`` endpoint never returns the full JWT
        payload, so PII or scope-bearing claims (email, groups, org
        metadata) cannot leak through this provider into MCP middleware
        downstream of FastMCP.
        """
        if not token:
            return None
        sub = await self._vault.verify_user_token(token)
        if sub is None:
            # Do not log the token or its prefix — nothing about the token
            # is trustworthy at this point and surfacing any part of it in
            # logs would turn this verifier into a free oracle for an
            # attacker with log access.
            logger.info("AlterAuthProvider.verify_token rejected a token")
            return None
        logger.debug(
            "AlterAuthProvider.verify_token accepted token for sub=%s",
            sub,
        )
        return {"sub": sub}
