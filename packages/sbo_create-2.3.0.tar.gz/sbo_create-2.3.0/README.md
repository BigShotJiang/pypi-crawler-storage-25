[![pipeline](https://gitlab.com/dslackw/sbo-create/badges/main/pipeline.svg)](https://gitlab.com/dslackw/sbo-create/-/pipelines)
[![coverage](https://gitlab.com/dslackw/sbo-create/badges/main/coverage.svg)](https://gitlab.com/dslackw/sbo-create/-/commits/main)
[![PyPI](https://img.shields.io/pypi/v/sbo-create.svg)](https://pypi.org/project/sbo-create/)
[![Python](https://img.shields.io/pypi/pyversions/sbo-create.svg)](https://pypi.org/project/sbo-create/)
[![License](https://img.shields.io/badge/license-GPLv3-blue.svg)](https://www.gnu.org/licenses/gpl-3.0.html)

## About

sbo-create is a command-line tool for creating and maintaining
[SlackBuilds.org](https://www.slackbuilds.org) packages.

It covers the entire package lifecycle: generating files from official SBo templates,
downloading and verifying sources, validating against SBo submission guidelines,
bumping versions, and packaging for submission — all from a single tool.

## Source

* [GitLab](https://gitlab.com/dslackw/sbo-create) repository.
* [SlackBuilds.org](https://slackbuilds.org/repository/15.0/system/sbo-create/) repository.
* [PyPI](https://pypi.org/project/sbo-create/) repository.

## Commands

| Command       | Description                                              |
|---------------|----------------------------------------------------------|
| `create`      | Create SlackBuild files (interactive or non-interactive) |
| `download`    | Download source files listed in the `.info` file         |
| `check`       | Check if package(s) exist in the SBo repository         |
| `search`      | Search for packages by partial name                      |
| `scan`        | Scan a source tarball for potential dependencies         |
| `validate`    | Validate package files against SBo submission guidelines |
| `bump`        | Bump version in `.info` and `.SlackBuild`                |
| `package`     | Create the submission tarball                            |
| `edit`        | Open package files in the configured editor              |
| `rename`      | Rename package files and update all PRGNAM references    |
| `fetch`       | Fetch a SlackBuild package from SBo or local clone       |
| `deps`        | Show dependency tree for a package                       |
| `rdeps`       | Show reverse dependencies for a package                  |
| `repo diff`   | Show diff between local files and the SBo repository     |
| `repo sync`   | Sync the local SBo git repository                        |
| `repo submit` | Commit and push a package update via git                 |
| `repo copy`   | Copy local package files to the SBo repository          |
| `repo log`    | Show packages committed on current branch                |
| `repology`    | Check package versions via repology.org                  |
| `clean`       | Remove downloaded source tarballs                        |
| `maintainer`  | Create or update maintainer configuration                |
| `update`      | Update templates from slackbuilds.org                    |

## Quick Start

```bash
# First run: download templates and package index
sbo-create update

# Create a new package interactively
sbo-create create

# Validate and auto-fix before submission
sbo-create validate --fix

# Bump version and recompute checksums
sbo-create bump 2.0.0 --with-sources
```

## Documentation

Full documentation: `man sbo-create` or [dslackw.gitlab.io/sbo-create](https://dslackw.gitlab.io/sbo-create/).

## License

[GNU General Public License v3 (GPLv3)](https://www.gnu.org/licenses/gpl-3.0.html)

## Donate

Did you know that developers love coffee?

[<img src="https://gitlab.com/dslackw/slpkg/-/raw/site/docs/images/paypaldonate.png" alt="paypal" title="donate">](https://www.paypal.me/dslackw)

## Contributing

Contributions are welcome! Please open an issue or merge request on GitLab.

## Copyrights

Slackware® is a Registered Trademark of Patrick Volkerding.  
Linux is a Registered Trademark of Linus Torvalds.
