#!/usr/bin/python3
# -*- coding: utf-8 -*-

__prog__: str = 'sbo-create'
__author__: str = 'dslackw'
__copyright__: str = '2015-2026'
__version_info__: tuple[int, int, int] = (2, 3, 0)
__version__: str = f'{__version_info__[0]}.{__version_info__[1]}.{__version_info__[2]}'
__license__: str = 'GNU General Public License v3 (GPLv3)'
__email__: str = 'dslackw@gmail.com'
__website__: str = 'https://gitlab.com/dslackw/sbo-create'
