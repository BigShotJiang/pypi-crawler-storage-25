import asyncio
import httpx
class Ornymo:
    def __init__(self,*, key, ban_num_of_attempts,identifier, max_attempts=50, cooldown=3):
        self.key = key
        self.identifier = identifier
        self.max_attempts = max_attempts

        self.cooldown = cooldown


    async def rate_limiter(self):
        async with httpx.AsyncClient(timeout=3.9) as client:
            try:
                res = await client.post(
                    f"https://api.ornymo.com/config/rate/limit/details",
                    json={"key": self.key,
                          "ban_num_of_attempts": self.ban_num_of_attempts,
                          "max_attempts":
                              self.max_attempts,"cooldown":
                              self.cooldown,"identifier":self.identifier},

                )
            except httpx.HTTPStatusError as e:
                pass
            except redis.exceptions.ConnectionError:
                pass
            except Exception as e:
                raise e



    async def per_endpoint_limiter(self,counter_addition):
        async with httpx.AsyncClient(timeout=5) as client:
            try:
                res = await client.post(
                url=f"https://api.ornymo.com/per/endpoint",
                json={"key":self.key,"counter_addition":counter_addition,"identifier":self.identifier},
                )
            except httpx.HTTPStatusError as e:
                pass
            except Exception as e:
                raise e
            except ConnectionError:
                pass


            

