import logging
import os
import re
from collections.abc import Mapping
from pathlib import Path
from typing import TypeVar, cast

import yaml
from pydantic import BaseModel
from pydantic import ValidationInfo as _PydanticValidationInfo

LoaderValidationInfo = _PydanticValidationInfo[dict[str, bool] | None]

T = TypeVar("T", bound=BaseModel)

LOGGER = logging.getLogger(__name__)

_ENV_PLACEHOLDER = re.compile(r"\$\{([A-Z_][A-Z0-9_]*)\}")


def resolve_env_var(v: object, info: LoaderValidationInfo) -> object:
    if not isinstance(v, str) or not (info.context or {}).get("resolve_env"):
        return v
    matches = list(_ENV_PLACEHOLDER.finditer(v))
    if not matches:
        return v
    if len(matches) == 1 and matches[0].span() == (0, len(v)):
        return os.environ.get(matches[0].group(1))
    return _ENV_PLACEHOLDER.sub(lambda m: os.environ.get(m.group(1), ""), v)


def load_yaml_mapping(path: str) -> Mapping[str, object]:
    file_path = Path(path)
    with file_path.open(encoding="utf-8") as file:
        data = cast("object", yaml.safe_load(file))

    if data is None:
        return {}

    if not isinstance(data, Mapping):
        msg = "YAML root must be a mapping"
        raise TypeError(msg)

    return data


def build_config(path: str, model_class: type[T]) -> T:
    raw_data = load_yaml_mapping(path)
    config = model_class.model_validate(raw_data, context={"resolve_env": True})
    extras = cast("Mapping[str, object] | None", config.model_extra)
    if extras:
        LOGGER.warning(
            "Some keys were not recognized: %s. "
            "The analysis will be performed only using the supported keys",
            ", ".join(sorted(extras)),
        )
    return config
