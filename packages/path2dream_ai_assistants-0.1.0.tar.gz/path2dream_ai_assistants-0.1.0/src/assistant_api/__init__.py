"""Notes assistant API package."""
