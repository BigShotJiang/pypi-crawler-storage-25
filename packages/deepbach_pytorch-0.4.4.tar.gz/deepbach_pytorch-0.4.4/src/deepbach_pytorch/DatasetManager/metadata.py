"""
Metadata classes
"""
import numpy as np
from music21 import analysis, stream, meter
from DatasetManager.helpers import SLUR_SYMBOL, \
    PAD_SYMBOL


class Metadata:
    def __init__(self):
        self.num_values = None
        self.is_global = None
        self.name = None

    def get_index(self, value):
        # trick with the 0 value
        raise NotImplementedError

    def get_value(self, index):
        raise NotImplementedError

    def evaluate(self, chorale, subdivision):
        """
        takes a music21 chorale as input and the number of subdivisions per beat
        """
        raise NotImplementedError

    def generate(self, length):
        raise NotImplementedError


class IsPlayingMetadata(Metadata):
    def __init__(self, voice_index, min_num_ticks):
        """
        Metadata that indicates if a voice is playing
        Voice i is considered to be muted if more than 'min_num_ticks' contiguous
        ticks contain a rest.


        :param voice_index: index of the voice to take into account
        :param min_num_ticks: minimum length in ticks for a rest to be taken
        into account in the metadata
        """
        super(IsPlayingMetadata, self).__init__()
        self.min_num_ticks = min_num_ticks
        self.voice_index = voice_index
        self.is_global = False
        self.num_values = 2
        self.name = 'isplaying'

    def get_index(self, value):
        return int(value)

    def get_value(self, index):
        return bool(index)

    def evaluate(self, chorale, subdivision):
        """
        takes a music21 chorale as input
        """
        length = int(chorale.duration.quarterLength * subdivision)
        metadatas = np.ones(shape=(length,))
        part = chorale.parts[self.voice_index]

        for note_or_rest in part.notesAndRests:
            is_playing = True
            if note_or_rest.isRest:
                if note_or_rest.quarterLength * subdivision >= self.min_num_ticks:
                    is_playing = False
            # these should be integer values
            start_tick = note_or_rest.offset * subdivision
            end_tick = start_tick + note_or_rest.quarterLength * subdivision
            metadatas[start_tick:end_tick] = self.get_index(is_playing)
        return metadatas

    def generate(self, length):
        return np.ones(shape=(length,))


class TickMetadata(Metadata):
    """
    Metadata class that tracks on which subdivision of the beat we are on
    """

    def __init__(self, subdivision):
        super(TickMetadata, self).__init__()
        self.is_global = False
        self.num_values = subdivision
        self.name = 'tick'

    def get_index(self, value):
        return value

    def get_value(self, index):
        return index

    def evaluate(self, chorale, subdivision):
        assert subdivision == self.num_values
        # suppose all pieces start on a beat
        length = int(chorale.duration.quarterLength * subdivision)
        return np.array(list(map(
            lambda x: x % self.num_values,
            range(length)
        )))

    def generate(self, length):
        return np.array(list(map(
            lambda x: x % self.num_values,
            range(length)
        )))


class ModeMetadata(Metadata):
    """
    Metadata class that indicates the current mode of the melody
    can be major, minor or other
    """

    def __init__(self):
        super(ModeMetadata, self).__init__()
        self.is_global = False
        self.num_values = 3  # major, minor or other
        self.name = 'mode'

    def get_index(self, value):
        if value == 'major':
            return 1
        if value == 'minor':
            return 2
        return 0

    def get_value(self, index):
        if index == 1:
            return 'major'
        if index == 2:
            return 'minor'
        return 'other'

    def evaluate(self, chorale, subdivision):
        # todo add measures when in midi
        # init key analyzer
        ka = analysis.floatingKey.KeyAnalyzer(chorale)
        res = ka.run()

        measure_offset_map = chorale.parts[0].measureOffsetMap()
        length = int(chorale.duration.quarterLength * subdivision)  # in 16th notes

        modes = np.zeros((length,))

        measure_index = -1
        for time_index in range(length):
            beat_index = time_index / subdivision
            if beat_index in measure_offset_map:
                measure_index += 1
                modes[time_index] = self.get_index(res[measure_index].mode)

        return np.array(modes, dtype=np.int32)

    def generate(self, length):
        return np.full((length,), self.get_index('major'))


class KeyMetadata(Metadata):
    """
    Metadata class that indicates in which key we are
    Only returns the number of sharps or flats
    Does not distinguish a key from its relative key
    """

    def __init__(self, window_size=4):
        super(KeyMetadata, self).__init__()
        self.window_size = window_size
        self.is_global = False
        self.num_max_sharps = 7
        self.num_values = 16
        self.name = 'key'

    def get_index(self, value):
        """

        :param value: number of sharps (between -7 and +7)
        :return: index in the representation
        """
        return value + self.num_max_sharps + 1

    def get_value(self, index):
        """

        :param index:  index (between 0 and self.num_values); 0 is unused (no constraint)
        :return: true number of sharps (between -7 and 7)
        """
        return index - 1 - self.num_max_sharps

    def evaluate(self, chorale, subdivision):
        # init key analyzer
        # we must add measures by hand for the case when we are parsing midi files
        chorale_with_measures = stream.Score()
        for part in chorale.parts:
            chorale_with_measures.append(part.makeMeasures())

        ka = analysis.floatingKey.KeyAnalyzer(chorale_with_measures)
        ka.windowSize = self.window_size
        res = ka.run()

        measure_offset_map = chorale_with_measures.parts.measureOffsetMap()
        length = int(chorale.duration.quarterLength * subdivision)  # in 16th notes

        key_signatures = np.zeros((length,))

        measure_index = -1
        for time_index in range(length):
            beat_index = time_index / subdivision
            if beat_index in measure_offset_map:
                measure_index += 1
                if measure_index == len(res):
                    measure_index -= 1

            key_signatures[time_index] = self.get_index(res[measure_index].sharps)
        return np.array(key_signatures, dtype=np.int32)

    def generate(self, length):
        return np.full((length,), self.get_index(0))


class FermataMetadata(Metadata):
    """
    Metadata class which indicates if a fermata is on the current note
    """

    def __init__(self):
        super(FermataMetadata, self).__init__()
        self.is_global = False
        self.num_values = 2
        self.name = 'fermata'

    def get_index(self, value):
        # possible values are 1 and 0, thus value = index
        return value

    def get_value(self, index):
        # possible values are 1 and 0, thus value = index
        return index

    def evaluate(self, chorale, subdivision):
        part = chorale.parts[0]
        length = int(part.duration.quarterLength * subdivision)  # in 16th notes
        list_notes = part.flat.notes
        num_notes = len(list_notes)
        j = 0
        i = 0
        fermatas = np.zeros((length,))
        while i < length:
            if j < num_notes - 1:
                if list_notes[j + 1].offset > i / subdivision:

                    if len(list_notes[j].expressions) == 1:
                        fermata = True
                    else:
                        fermata = False
                    fermatas[i] = fermata
                    i += 1
                else:
                    j += 1
            else:
                if len(list_notes[j].expressions) == 1:
                    fermata = True
                else:
                    fermata = False

                fermatas[i] = fermata
                i += 1
        return np.array(fermatas, dtype=np.int32)

    def generate(self, length):
        # fermata every 2 bars
        return np.array([1 if i % 32 >= 28 else 0
                         for i in range(length)])


class HarmonyMetadata(Metadata):
    """
    Metadata indicating the Roman-numeral scale degree at each tick.

    Uses music21's chordify() to collapse all voices into simultaneous chords,
    then assigns each chord a scale degree (1–7) via romanNumeralFromChord().
    Index 0 is reserved for unknown / analysis failure.

    num_values = 8   (0 = unknown, 1–7 = scale degrees I–VII)

    Learned generation via a first-order Markov chain
    --------------------------------------------------
    Every time evaluate() is called during dataset construction, the resulting
    sequence of scale degrees is used to update a (8 x 8) bigram count matrix
    (_transition_counts) and a length-8 initial-state count vector
    (_initial_counts).  generate() samples from the normalised versions of
    these counts, so the harmonic patterns it produces reflect what the model
    actually learned from the corpus rather than a hand-written cadence.

    Because the dataset object (including this metadata instance) is persisted
    to disk by DatasetManager, the accumulated counts survive across runs.
    evaluate() is called for every transposition of every chorale, so by the
    time generate() is ever needed, the counts will have been built from the
    full augmented corpus.

    Fallback
    --------
    If generate() is called before any evaluate() call has populated the
    counts (e.g., in a unit test with an empty dataset), it falls back to a
    uniform distribution over degrees 1–7.
    """

    def __init__(self):
        super(HarmonyMetadata, self).__init__()
        self.is_global = False
        self.num_values = 8   # indices 0–7
        self.name = 'harmony'

        # Bigram transition counts: _transition_counts[i, j] is the number of
        # times degree j followed degree i in any evaluated chorale.
        # Shape (8, 8) — row = current state, column = next state.
        self._transition_counts = np.zeros((8, 8), dtype=np.float64)

        # Count of how often each degree appears as the first non-zero tick
        # in a chorale, used to sample the starting degree in generate().
        self._initial_counts = np.zeros(8, dtype=np.float64)

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _update_markov(self, sequence: np.ndarray) -> None:
        """
        Accumulate bigram counts from one harmony sequence.

        Only non-zero (known) degrees are used so that padding zeros produced
        by failed chord analyses do not pollute the transition statistics.
        Consecutive identical degrees are counted normally — held harmonies
        are part of the real distribution and should be reproduced in
        generation.
        """
        # Find the first non-zero entry for the initial-state count.
        non_zero = sequence[sequence > 0]
        if len(non_zero) == 0:
            return
        self._initial_counts[non_zero[0]] += 1.0

        # Bigram counts over the full sequence, skipping transitions that
        # involve a zero on either side.
        for i in range(len(sequence) - 1):
            a, b = int(sequence[i]), int(sequence[i + 1])
            if a > 0 and b > 0:
                self._transition_counts[a, b] += 1.0

    def _sample_next(self, current: int, rng: np.random.Generator) -> int:
        """
        Sample the next degree from the learned conditional distribution
        p(next | current).  If the current row is all zeros (unseen context),
        fall back to the marginal distribution over initial counts.
        """
        row = self._transition_counts[current]
        total = row.sum()
        if total > 0.0:
            probs = row / total
        else:
            # Unseen context: fall back to marginal over degrees 1–7.
            fallback = self._initial_counts.copy()
            fallback[0] = 0.0
            s = fallback.sum()
            probs = fallback / s if s > 0.0 else np.array(
                [0.0, 1/7, 1/7, 1/7, 1/7, 1/7, 1/7, 1/7]
            )
        return int(rng.choice(8, p=probs))

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def get_index(self, value):
        """
        :param value: scale degree as int (1–7); anything else maps to 0
        :return: index in [0, 7]
        """
        try:
            v = int(value)
        except (TypeError, ValueError):
            return 0
        return v if 1 <= v <= 7 else 0

    def get_value(self, index):
        """
        :param index: integer in [0, 7]
        :return: scale degree (same integer; 0 means unknown)
        """
        return index

    def evaluate(self, chorale, subdivision):
        """
        Assign a scale-degree index to every tick in the chorale and
        accumulate Markov statistics for later use in generate().

        After the chord loop, any ticks still at 0 (analysis failure, passing
        tones, ornaments that music21 cannot assign to a chord) are filled
        forward from the most recent known degree.  This prevents the model
        from seeing degree 0 at positions that are harmonically defined but
        analytically opaque, which would otherwise teach it that any note is
        acceptable after an unknown harmony.  Ticks at the very start of the
        sequence that precede the first successful analysis are back-filled
        from the first known degree.
        """
        from music21 import roman

        length = int(chorale.duration.quarterLength * subdivision)
        result = np.zeros(length, dtype=np.int32)

        try:
            key = chorale.analyze('key')
            chordified = chorale.chordify()

            for chord in chordified.flatten().getElementsByClass('Chord'):
                try:
                    rn = roman.romanNumeralFromChord(chord, key)
                    degree = rn.scaleDegree          # int 1–7
                    start_tick = int(chord.offset * subdivision)
                    end_tick = int((chord.offset + chord.quarterLength) * subdivision)
                    start_tick = max(0, start_tick)
                    end_tick = min(length, end_tick)
                    if start_tick < end_tick:
                        result[start_tick:end_tick] = self.get_index(degree)
                except Exception:
                    pass  # leave those ticks as 0 for now; filled below

        except Exception:
            pass  # entire chorale failed analysis; result stays all-zeros

        # Forward-fill: propagate the last known degree into every 0-valued
        # tick that follows it.  This eliminates gaps caused by passing tones,
        # grace notes, and any chord that romanNumeralFromChord cannot parse.
        last_known = 0
        for t in range(length):
            if result[t] > 0:
                last_known = result[t]
            elif last_known > 0:
                result[t] = last_known
            # If last_known is still 0, the sequence hasn't had a single
            # successful analysis yet; leave as 0 and continue.

        # Back-fill the leading zeros (ticks before the first successful
        # analysis) using the first known degree found anywhere in the sequence.
        first_known = result[result > 0]
        if len(first_known) > 0:
            first_degree = int(first_known[0])
            for t in range(length):
                if result[t] == 0:
                    result[t] = first_degree
                else:
                    break

        # Update Markov counts from this chorale's (now gap-free) sequence.
        self._update_markov(result)

        return result

    def generate(self, length: int) -> np.ndarray:
        """
        Sample a harmony sequence of the requested length from the learned
        first-order Markov chain.

        If no data has been accumulated yet (empty corpus, unit test), fall
        back to a uniform distribution over degrees 1–7 so the method always
        returns a valid array.
        """
        rng = np.random.default_rng()
        result = np.zeros(length, dtype=np.int32)

        # Choose a starting degree.
        total_initial = self._initial_counts.sum()
        if total_initial > 0.0:
            init_probs = self._initial_counts / total_initial
            current = int(rng.choice(8, p=init_probs))
            if current == 0:
                # Zero is the unknown/padding index; resample from 1–7.
                current = int(rng.integers(1, 8))
        else:
            # Fallback: no data yet.
            current = int(rng.integers(1, 8))

        for t in range(length):
            result[t] = current
            current = self._sample_next(current, rng)

        return result