"""
@author: Gaetan Hadjeres
Modified:
  - train_model() accepts lr_patience / lr_factor for ReduceLROnPlateau
  - best-val-loss checkpointing (only saves when val loss improves)
  - MODERNIZE: ReduceLROnPlateau verbose=True removed (deprecated in PyTorch 2.x);
    LR changes are printed manually instead
  - UPGRADE: cross-voice attention added to forward()
    A MultiheadAttention layer attends over individual per-voice note embeddings
    at the center tick, using the bidirectional LSTM context as the query.
    The result is blended with the original mlp_center output through a learned
    sigmoid gate.  embed() is unchanged; the new path uses note_embeddings
    directly on the raw center-tick indices (cn) which are available in forward()
    before they are concatenated by embed().
"""

import os
import random

import torch
from torch import nn

try:
    from torch.amp import GradScaler, autocast
    _AMP_DEVICE = 'cuda'
except ImportError:
    from torch.cuda.amp import GradScaler, autocast  # type: ignore
    _AMP_DEVICE = None

from DatasetManager.chorale_dataset import ChoraleDataset
from DeepBach.helpers import cuda_variable, init_hidden
from DeepBach.data_utils import reverse_tensor, mask_entry

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_PACKAGE_ROOT = os.path.dirname(_THIS_DIR)
_DEFAULT_MODELS_DIR = os.path.join(_PACKAGE_ROOT, 'models')


class VoiceModel(nn.Module):
    def __init__(self,
                 dataset: ChoraleDataset,
                 main_voice_index: int,
                 note_embedding_dim: int,
                 meta_embedding_dim: int,
                 num_layers: int,
                 lstm_hidden_size: int,
                 dropout_lstm: float,
                 hidden_size_linear=200,
                 models_dir: str = None,
                 num_attn_heads: int = 4,
                 ):
        """
        num_attn_heads controls the cross-voice MultiheadAttention.
        lstm_hidden_size must be divisible by num_attn_heads.
        The default of 4 works for the standard lstm_hidden_size=256.
        """
        super(VoiceModel, self).__init__()

        if lstm_hidden_size % num_attn_heads != 0:
            raise ValueError(
                f'lstm_hidden_size ({lstm_hidden_size}) must be divisible by '
                f'num_attn_heads ({num_attn_heads}).'
            )

        self.dataset = dataset
        self.main_voice_index = main_voice_index
        self.note_embedding_dim = note_embedding_dim
        self.meta_embedding_dim = meta_embedding_dim
        self.num_notes_per_voice = [len(d) for d in dataset.note2index_dicts]
        self.num_voices = self.dataset.num_voices
        self.num_metas_per_voice = [
            metadata.num_values for metadata in dataset.metadatas
        ] + [self.num_voices]
        self.num_metas = len(self.dataset.metadatas) + 1
        self.num_layers = num_layers
        self.lstm_hidden_size = lstm_hidden_size
        self.dropout_lstm = dropout_lstm
        self.hidden_size_linear = hidden_size_linear
        self.num_attn_heads = num_attn_heads

        self.models_dir = models_dir or _DEFAULT_MODELS_DIR

        self.other_voices_indexes = [i for i in range(self.num_voices)
                                     if i != main_voice_index]

        self.note_embeddings = nn.ModuleList(
            [nn.Embedding(num_notes, note_embedding_dim)
             for num_notes in self.num_notes_per_voice]
        )
        self.meta_embeddings = nn.ModuleList(
            [nn.Embedding(num_metas, meta_embedding_dim)
             for num_metas in self.num_metas_per_voice]
        )
        self.lstm_left = nn.LSTM(
            input_size=note_embedding_dim * self.num_voices + meta_embedding_dim * self.num_metas,
            hidden_size=lstm_hidden_size,
            num_layers=num_layers,
            dropout=dropout_lstm,
            batch_first=True)
        self.lstm_right = nn.LSTM(
            input_size=note_embedding_dim * self.num_voices + meta_embedding_dim * self.num_metas,
            hidden_size=lstm_hidden_size,
            num_layers=num_layers,
            dropout=dropout_lstm,
            batch_first=True)
        self.mlp_center = nn.Sequential(
            nn.Linear(note_embedding_dim * (self.num_voices - 1)
                      + meta_embedding_dim * self.num_metas,
                      hidden_size_linear),
            nn.ReLU(),
            nn.Linear(hidden_size_linear, lstm_hidden_size))
        self.mlp_predictions = nn.Sequential(
            nn.Linear(self.lstm_hidden_size * 3, hidden_size_linear),
            nn.ReLU(),
            nn.Linear(hidden_size_linear, self.num_notes_per_voice[main_voice_index]))

        # -----------------------------------------------------------------------
        # Cross-voice attention modules
        #
        # voice_key_proj:    projects each other-voice note embedding
        #                    (note_embedding_dim) up to lstm_hidden_size so it
        #                    can serve as key/value in the attention layer.
        #
        # cross_voice_attn:  MultiheadAttention where the query is the
        #                    bidirectional LSTM context (mean of left and right
        #                    final states) and the key/value set is the projected
        #                    per-voice embeddings at the center tick.
        #                    This lets the model selectively attend to whichever
        #                    other voice is most constraining at the prediction
        #                    point, rather than treating all voices equally via
        #                    concatenation.
        #
        # attn_gate:         A sigmoid gate that blends the original mlp_center
        #                    output with the attention output.  Initialising with
        #                    near-zero weights means the gate starts near 0.5,
        #                    so both paths contribute from the start of training.
        # -----------------------------------------------------------------------
        self.voice_key_proj = nn.Linear(note_embedding_dim, lstm_hidden_size)

        self.cross_voice_attn = nn.MultiheadAttention(
            embed_dim=lstm_hidden_size,
            num_heads=num_attn_heads,
            dropout=dropout_lstm,
            batch_first=True,
        )

        # Gate input: [center_mlp | attn_out] → scalar gate per hidden unit.
        #
        # FIX: bias initialised to +3.0 so sigmoid(3) ≈ 0.95 at the start of
        # training.  This means the gate strongly favours the proven MLP path
        # in early epochs, when the attention path has not yet learned anything
        # useful.  The attention contribution grows gradually as the weights
        # converge, rather than injecting noise from the first step.
        # Without this fix, Kaiming init produces gate ≈ 0.5 from epoch 0,
        # which effectively halves the contribution of the pre-trained MLP
        # features and slows convergence, producing dissonant output.
        self.attn_gate = nn.Sequential(
            nn.Linear(lstm_hidden_size * 2, lstm_hidden_size),
            nn.Sigmoid(),
        )
        nn.init.zeros_(self.attn_gate[0].weight)
        nn.init.constant_(self.attn_gate[0].bias, 3.0)

        if torch.cuda.is_available():
            self._scaler = (GradScaler(_AMP_DEVICE) if _AMP_DEVICE
                            else GradScaler())
        else:
            self._scaler = None

    # ---------------------------------------------------------------------------
    # Dynamic embedding resize
    # ---------------------------------------------------------------------------

    def resize_embeddings_to_dataset(self):
        changed = False

        for voice_idx in range(self.num_voices):
            actual = len(self.dataset.note2index_dicts[voice_idx])
            emb = self.note_embeddings[voice_idx]
            current = emb.num_embeddings
            dim = emb.embedding_dim

            if actual == current:
                continue
            if actual < current:
                print(f'  [resize_embeddings] WARNING: voice {voice_idx} vocab '
                      f'shrank {current} -> {actual}; skipping.')
                continue

            print(f'  [resize_embeddings] Voice {voice_idx}: expanding embedding '
                  f'{current} -> {actual} (+{actual - current} new tokens)')
            new_emb = nn.Embedding(actual, dim)
            with torch.no_grad():
                new_emb.weight[:current] = emb.weight
            new_emb = new_emb.to(emb.weight.device)
            self.note_embeddings[voice_idx] = new_emb
            self.num_notes_per_voice[voice_idx] = actual
            changed = True

        main_vocab = len(self.dataset.note2index_dicts[self.main_voice_index])
        out_layer = self.mlp_predictions[-1]
        if out_layer.out_features != main_vocab:
            print(f'  [resize_embeddings] Resizing output projection: '
                  f'{out_layer.out_features} -> {main_vocab}')
            new_linear = nn.Linear(out_layer.in_features, main_vocab)
            new_linear = new_linear.to(out_layer.weight.device)
            with torch.no_grad():
                keep = min(out_layer.out_features, main_vocab)
                new_linear.weight[:keep] = out_layer.weight[:keep]
                new_linear.bias[:keep] = out_layer.bias[:keep]
            layers = list(self.mlp_predictions.children())
            layers[-1] = new_linear
            self.mlp_predictions = nn.Sequential(*layers)
            changed = True

        if changed:
            print(f'  [resize_embeddings] Voice {self.main_voice_index}: '
                  f'embeddings updated and ready for training.')
        return changed

    # ---------------------------------------------------------------------------
    # Forward pass
    # ---------------------------------------------------------------------------

    def forward(self, *input):
        notes, metas = input
        batch_size, num_voices, timesteps_ticks = notes[0].size()

        # cn holds raw note indices for other voices at the center tick:
        # shape [B, num_voices-1].  It is not transposed and is kept here
        # so the cross-voice attention can look up individual embeddings below.
        ln, cn, rn = notes
        ln, rn = ln.transpose(1, 2), rn.transpose(1, 2)
        notes = ln, cn, rn

        notes_embedded = self.embed(notes, type='note')
        metas_embedded = self.embed(metas, type='meta')

        input_embedded = [
            torch.cat([n, m], 2) if n is not None else None
            for n, m in zip(notes_embedded, metas_embedded)
        ]
        left_emb, center_emb, right_emb = input_embedded

        hidden = init_hidden(self.num_layers, batch_size, self.lstm_hidden_size)
        left_out, _ = self.lstm_left(left_emb, hidden)
        left_out = left_out[:, -1, :]    # [B, lstm_hidden]

        hidden = init_hidden(self.num_layers, batch_size, self.lstm_hidden_size)
        right_out, _ = self.lstm_right(right_emb, hidden)
        right_out = right_out[:, -1, :]  # [B, lstm_hidden]

        if self.num_voices == 1:
            center_out = cuda_variable(torch.zeros(batch_size, self.lstm_hidden_size))
        else:
            # ---------------------------------------------------------------
            # Original MLP path: concatenated other-voice embeddings
            # center_emb: [B, 1, (num_voices-1)*note_emb + num_metas*meta_emb]
            # ---------------------------------------------------------------
            center_mlp = self.mlp_center(center_emb[:, 0, :])  # [B, lstm_hidden]

            # ---------------------------------------------------------------
            # Cross-voice attention path
            #
            # Build per-voice embeddings directly from cn (raw indices) rather
            # than from the already-concatenated center_emb.  This gives the
            # attention layer a separate key/value vector per voice rather than
            # a single flattened representation.
            #
            # per_voice_emb: [B, num_voices-1, note_emb_dim]
            # kv:            [B, num_voices-1, lstm_hidden]  (after projection)
            # query:         [B, 1, lstm_hidden]  (mean of left/right context)
            # attn_out:      [B, lstm_hidden]
            # ---------------------------------------------------------------
            per_voice_emb = torch.stack(
                [self.note_embeddings[vid](cn[:, k])
                 for k, vid in enumerate(self.other_voices_indexes)],
                dim=1,
            )                                                   # [B, num_voices-1, note_emb_dim]
            kv = self.voice_key_proj(per_voice_emb)            # [B, num_voices-1, lstm_hidden]

            query = ((left_out + right_out) * 0.5).unsqueeze(1)  # [B, 1, lstm_hidden]
            attn_out, _ = self.cross_voice_attn(query, kv, kv)
            attn_out = attn_out.squeeze(1)                     # [B, lstm_hidden]

            # Learned gate blends the two center representations.
            # gate ∈ (0,1)^lstm_hidden: values near 1 favour the MLP path,
            # values near 0 favour the attention path.  The model learns the
            # balance per-dimension during training.
            gate = self.attn_gate(
                torch.cat([center_mlp, attn_out], dim=1)
            )                                                   # [B, lstm_hidden]
            center_out = gate * center_mlp + (1.0 - gate) * attn_out

        predictions = self.mlp_predictions(
            torch.cat([left_out, center_out, right_out], dim=1)
        )
        return predictions

    def embed(self, notes_or_metas, type):
        if type == 'note':
            embeddings = self.note_embeddings
            embedding_dim = self.note_embedding_dim
            other_voices_indexes = self.other_voices_indexes
        else:
            embeddings = self.meta_embeddings
            embedding_dim = self.meta_embedding_dim
            other_voices_indexes = range(self.num_metas)

        batch_size, timesteps_left_ticks, num_voices = notes_or_metas[0].size()
        batch_size, timesteps_right_ticks, _ = notes_or_metas[2].size()
        left, center, right = notes_or_metas

        left_embedded = torch.cat([
            embeddings[vid](left[:, :, vid])[:, :, None, :]
            for vid in range(num_voices)
        ], 2).view(batch_size, timesteps_left_ticks, num_voices * embedding_dim)

        right_embedded = torch.cat([
            embeddings[vid](right[:, :, vid])[:, :, None, :]
            for vid in range(num_voices)
        ], 2).view(batch_size, timesteps_right_ticks, num_voices * embedding_dim)

        if self.num_voices == 1 and type == 'note':
            center_embedded = None
        else:
            center_embedded = torch.cat([
                embeddings[vid](center[:, k].unsqueeze(1))
                for k, vid in enumerate(other_voices_indexes)
            ], 1).view(batch_size, 1, len(list(other_voices_indexes)) * embedding_dim)

        return left_embedded, center_embedded, right_embedded

    # ---------------------------------------------------------------------------
    # Save / load
    # ---------------------------------------------------------------------------

    def save(self, models_dir=None):
        target_dir = models_dir or self.models_dir
        os.makedirs(target_dir, exist_ok=True)
        save_path = os.path.join(target_dir, self.__repr__())
        torch.save(self.state_dict(), save_path)
        print(f'Model {self.__repr__()} saved to {target_dir}')

    def load(self, models_dir=None):
        target_dir = models_dir or self.models_dir
        load_path = os.path.join(target_dir, self.__repr__())
        state_dict = torch.load(load_path,
                                map_location=lambda storage, loc: storage,
                                weights_only=True)
        print(f'Loading {self.__repr__()} from {target_dir}')
        self.load_state_dict(state_dict)

    def __repr__(self):
        # num_attn_heads is included so that models trained with different
        # attention configurations do not silently share the same filename.
        return (f'VoiceModel('
                f'{self.dataset.__repr__()},'
                f'{self.main_voice_index},'
                f'{self.note_embedding_dim},'
                f'{self.meta_embedding_dim},'
                f'{self.num_layers},'
                f'{self.lstm_hidden_size},'
                f'{self.dropout_lstm},'
                f'{self.hidden_size_linear},'
                f'{self.num_attn_heads})')

    # ---------------------------------------------------------------------------
    # Training
    # ---------------------------------------------------------------------------

    def train_model(self,
                    batch_size=16,
                    num_epochs=10,
                    optimizer=None,
                    lr_patience: int = 3,
                    lr_factor: float = 0.5,
                    ):
        # MODERNIZE: verbose=True is deprecated in PyTorch 2.x; print LR changes manually
        scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
            optimizer,
            mode='min',
            patience=lr_patience,
            factor=lr_factor,
        )

        best_val_loss = float('inf')

        for epoch in range(num_epochs):
            print(f'=== Voice {self.main_voice_index} — Epoch {epoch} ===')
            (dataloader_train,
             dataloader_val,
             _) = self.dataset.data_loaders(batch_size=batch_size)

            print('  Checking embedding sizes after dataset build...')
            resized = self.resize_embeddings_to_dataset()
            if resized:
                print('  Embeddings resized — rebuilding optimizer & scheduler.')
                optimizer = torch.optim.Adam(self.parameters(),
                                             lr=optimizer.param_groups[0]['lr'])
                scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
                    optimizer, mode='min', patience=lr_patience, factor=lr_factor)
            else:
                print('  Embedding sizes OK.')

            loss, acc = self.loss_and_acc(dataloader_train,
                                          optimizer=optimizer,
                                          phase='train')
            print(f'  Train  loss: {loss:.4f}  acc: {acc:.2f}%')

            val_loss, val_acc = self.loss_and_acc(dataloader_val,
                                                  optimizer=None,
                                                  phase='test')
            print(f'  Val    loss: {val_loss:.4f}  acc: {val_acc:.2f}%')

            # Step scheduler and print if LR changed
            old_lr = optimizer.param_groups[0]['lr']
            scheduler.step(val_loss)
            new_lr = optimizer.param_groups[0]['lr']
            if new_lr != old_lr:
                print(f'  LR reduced: {old_lr:.2e} → {new_lr:.2e}')

            if val_loss < best_val_loss:
                best_val_loss = val_loss
                self.save()
                print(f'  ✓ Best model saved (val_loss={val_loss:.4f})')

        print(f'Voice {self.main_voice_index} done. Best val loss: {best_val_loss:.4f}')

    def loss_and_acc(self, dataloader, optimizer=None, phase='train'):
        average_loss = 0
        average_acc = 0

        if phase == 'train':
            self.train()
        elif phase in ('eval', 'test'):
            self.eval()
        else:
            raise NotImplementedError(f'Unknown phase: {phase}')

        loss_fn = nn.CrossEntropyLoss()

        for tensor_chorale, tensor_metadata in dataloader:
            tensor_chorale = cuda_variable(tensor_chorale).long()
            tensor_metadata = cuda_variable(tensor_metadata).long()

            for v in range(self.num_voices):
                max_idx = self.note_embeddings[v].num_embeddings - 1
                tensor_chorale[:, v, :] = tensor_chorale[:, v, :].clamp(0, max_idx)

            notes, metas, label = self.preprocess_input(tensor_chorale, tensor_metadata)

            if self._scaler is not None and phase == 'train':
                with autocast(_AMP_DEVICE or 'cuda'):
                    weights = self.forward(notes, metas)
                    loss = loss_fn(weights, label)
                optimizer.zero_grad()
                self._scaler.scale(loss).backward()
                self._scaler.step(optimizer)
                self._scaler.update()
            else:
                weights = self.forward(notes, metas)
                loss = loss_fn(weights, label)
                if phase == 'train':
                    optimizer.zero_grad()
                    loss.backward()
                    optimizer.step()

            average_loss += loss.item()
            average_acc += self.accuracy(weights, label).item()

        n = len(dataloader)
        return average_loss / n, average_acc / n

    def accuracy(self, weights, target):
        batch_size, = target.size()
        pred = nn.Softmax(dim=1)(weights).max(1)[1].type_as(target)
        return (pred == target).float().sum() / batch_size * 100

    def preprocess_input(self, tensor_chorale, tensor_metadata):
        batch_size, num_voices, chorale_length_ticks = tensor_chorale.size()
        offset = random.randint(0, self.dataset.subdivision)
        time_index_ticks = chorale_length_ticks // 2 + offset
        notes, label = self.preprocess_notes(tensor_chorale, time_index_ticks)
        metas = self.preprocess_metas(tensor_metadata, time_index_ticks)
        return notes, metas, label

    def preprocess_notes(self, tensor_chorale, time_index_ticks):
        left_notes = tensor_chorale[:, :, :time_index_ticks]
        right_notes = reverse_tensor(tensor_chorale[:, :, time_index_ticks + 1:], dim=2)
        if self.num_voices == 1:
            central_notes = None
        else:
            central_notes = mask_entry(tensor_chorale[:, :, time_index_ticks],
                                       entry_index=self.main_voice_index,
                                       dim=1)
        label = tensor_chorale[:, self.main_voice_index, time_index_ticks]
        return (left_notes, central_notes, right_notes), label

    def preprocess_metas(self, tensor_metadata, time_index_ticks):
        left_metas = tensor_metadata[:, self.main_voice_index, :time_index_ticks, :]
        right_metas = reverse_tensor(
            tensor_metadata[:, self.main_voice_index, time_index_ticks + 1:, :], dim=1)
        central_metas = tensor_metadata[:, self.main_voice_index, time_index_ticks, :]
        return left_metas, central_metas, right_metas