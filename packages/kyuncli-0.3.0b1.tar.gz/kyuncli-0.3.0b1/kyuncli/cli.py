import click
from .accounts import account
from .bricks import brick
from .chat import chat
from .danbos import danbo
from .deposits import deposit
from .notify import notify
from .stripe import stripe
from .version import get_version


@click.group(invoke_without_command=True)
@click.version_option(version=get_version(), prog_name="kyuncli")
@click.pass_context
def cli(ctx):
    """KyunCLI.

    Run without arguments to see available command groups and options.
    """
    if ctx.invoked_subcommand is None:
        click.echo(ctx.get_help())

cli.add_command(account)
cli.add_command(brick)
cli.add_command(chat)
cli.add_command(danbo)
cli.add_command(deposit)
cli.add_command(notify)
cli.add_command(stripe)

if __name__ == "__main__":
    cli()
