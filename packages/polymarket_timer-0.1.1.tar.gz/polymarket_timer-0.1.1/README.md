# polymarket-timer

Contract expiry timer for Polymarket markets. BTC 5-min/15-min slug parsing.

Standalone re-export from [polymarket-trading-mcp](https://github.com/whitmorelabs/polymarket-mcp).

## Install

```bash
pip install polymarket-timer
```

## Usage

```python
from polymarket_timer import get_contract_status
```

## Source

Part of [Whitmore Labs polymarket-mcp](https://github.com/whitmorelabs/polymarket-mcp).
