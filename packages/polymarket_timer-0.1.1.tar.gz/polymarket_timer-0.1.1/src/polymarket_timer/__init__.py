"""
polymarket-timer — Contract expiry timer for Polymarket markets.

Standalone re-export from polymarket-trading-mcp.
"""
from polymarket_mcp.tools.timer import get_contract_status

__all__ = ["get_contract_status"]
__version__ = "0.1.0"
