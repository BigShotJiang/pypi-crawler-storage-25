import json
import os
import stat
import tempfile
from unittest.mock import patch

from dbt.adapters.setu.session_manager import (
    SetuSessionManager,
    SETU_SESSION_INFO_PATH_ENV,
)


class TestWriteSessionInfoForCancel:
    def setup_method(self):
        self._original_session_id = SetuSessionManager.session_id

    def teardown_method(self):
        SetuSessionManager.session_id = self._original_session_id

    def test_write_session_info_writes_file(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = os.path.join(tmpdir, "setu_session_info.json")
            SetuSessionManager.session_id = "batch-42"
            with patch.dict(os.environ, {SETU_SESSION_INFO_PATH_ENV: file_path}):
                SetuSessionManager._write_session_info_for_cancel("https://setu.example.com/v1/batches/")

            with open(file_path) as f:
                data = json.load(f)
            assert data["setu_batch_id"] == "batch-42"
            assert data["setu_host_url"] == "https://setu.example.com/v1/batches/"

    def test_write_session_info_noop_without_env(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = os.path.join(tmpdir, "setu_session_info.json")
            SetuSessionManager.session_id = "batch-42"
            with patch.dict(os.environ, {}, clear=True):
                os.environ.pop(SETU_SESSION_INFO_PATH_ENV, None)
                SetuSessionManager._write_session_info_for_cancel("https://host/v1/")
            assert not os.path.exists(file_path)

    def test_write_session_info_noop_without_session_id(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = os.path.join(tmpdir, "setu_session_info.json")
            SetuSessionManager.session_id = None
            with patch.dict(os.environ, {SETU_SESSION_INFO_PATH_ENV: file_path}):
                SetuSessionManager._write_session_info_for_cancel("https://host/v1/")
            assert not os.path.exists(file_path)

    def test_write_session_info_creates_parent_dirs(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            file_path = os.path.join(tmpdir, "nested", "dir", "setu.json")
            SetuSessionManager.session_id = "batch-99"
            with patch.dict(os.environ, {SETU_SESSION_INFO_PATH_ENV: file_path}):
                SetuSessionManager._write_session_info_for_cancel("https://host/v1/")
            assert os.path.exists(file_path)
            with open(file_path) as f:
                data = json.load(f)
            assert data["setu_batch_id"] == "batch-99"

    def test_write_session_info_handles_write_error(self):
        with tempfile.TemporaryDirectory() as tmpdir:
            # Create a read-only directory to cause a write error
            readonly_dir = os.path.join(tmpdir, "readonly")
            os.makedirs(readonly_dir)
            file_path = os.path.join(readonly_dir, "setu.json")
            os.chmod(readonly_dir, stat.S_IRUSR | stat.S_IXUSR)
            try:
                SetuSessionManager.session_id = "batch-fail"
                with patch.dict(os.environ, {SETU_SESSION_INFO_PATH_ENV: file_path}):
                    # Should not raise
                    SetuSessionManager._write_session_info_for_cancel("https://host/v1/")
                assert not os.path.exists(file_path)
            finally:
                os.chmod(readonly_dir, stat.S_IRWXU)
