import ctypes
import os
import json

_lib = ctypes.CDLL(os.path.join(os.path.dirname(__file__), "vspider-api.so"))
_lib.check.argtypes = [ctypes.c_char_p]
_lib.check.restype = ctypes.c_char_p

def check(url):
    result = _lib.check(url.encode())
    if result:
        decoded = result.decode()
        try:
            return json.loads(decoded)
        except:
            return decoded
    return None

__all__ = ['check']
