from setuptools import setup, find_packages

setup(
    name='vspider-check',
    version='1.0.6',
    description='DDoS bypass library - bypass DDoS-Guard protection',
    long_description='# vspider-check\n\nBypass DDoS-Guard protection and get JSON response\n\n## Usage\n```python\nimport vspider_api as vsapi\nresult = vsapi.check("https://example.com")\nprint(result)\n```',
    long_description_content_type='text/markdown',
    author='VSpider',
    packages=find_packages(),
    package_data={'vspider_api': ['*.so']},
    include_package_data=True,
    python_requires='>=3.6',
)
