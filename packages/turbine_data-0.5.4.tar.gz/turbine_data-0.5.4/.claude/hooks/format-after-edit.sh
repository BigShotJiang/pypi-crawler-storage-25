#!/bin/bash
# Runs ruff format on .py files after Edit/Write tool calls

INPUT=$(cat)
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path')

if [[ -n "$FILE_PATH" && "$FILE_PATH" == *.py ]]; then
  uv run ruff format "$FILE_PATH" 2>/dev/null
fi

exit 0
