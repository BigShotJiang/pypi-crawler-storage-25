#!/bin/bash
# Full quality gate before git commit:
# ruff check --fix, ruff format, ty check, complexipy, tach check

INPUT=$(cat)
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command')

if echo "$COMMAND" | grep -q "git commit"; then
  CWD=$(echo "$INPUT" | jq -r '.cwd')
  cd "$CWD"

  # Lint + format
  uv run ruff check --fix . 2>&1
  RUFF_EXIT=$?
  uv run ruff format . 2>/dev/null

  if [ $RUFF_EXIT -ne 0 ]; then
    echo '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"ruff check --fix found unfixable lint errors. Fix them before committing."}}'
    exit 0
  fi

  # Type check
  uv run ty check 2>&1
  TY_EXIT=$?
  if [ $TY_EXIT -ne 0 ]; then
    echo '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"ty check found type errors. Fix them before committing."}}'
    exit 0
  fi

  # Complexity check
  uv run complexipy src/ -mx 10 2>&1
  COMPLEX_EXIT=$?
  if [ $COMPLEX_EXIT -ne 0 ]; then
    echo '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"complexipy found functions exceeding complexity threshold. Simplify before committing."}}'
    exit 0
  fi

  # Boundary check
  uv run tach check 2>&1
  TACH_EXIT=$?
  if [ $TACH_EXIT -ne 0 ]; then
    echo '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"tach check found module boundary violations. Fix imports before committing."}}'
    exit 0
  fi
fi

exit 0
