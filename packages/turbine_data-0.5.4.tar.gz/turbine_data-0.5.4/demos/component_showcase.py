"""Turbine Dashboard -- Component Showcase.

Demos every DSL component using the same production wiring as app.py,
with a MockDispatcher instead of the real API.

Run with: uv run streamlit run demos/component_showcase.py
"""
# ruff: noqa: INP001, S311 — standalone demo script, fake-data randomness is non-cryptographic

from __future__ import annotations

import datetime as dt
import random
from collections.abc import Mapping
from typing import Any

import streamlit as st

from turbine.core.common.quality_dimension import QualityDimension
from turbine.core.dashboard.components.charts import BarChart, Gauge, Heatmap, TrendChart
from turbine.core.dashboard.components.data import (
    CellValue,
    ColumnConfig,
    ColumnType,
    ColumnWidth,
    RowViewer,
    Table,
)
from turbine.core.dashboard.components.display import Alert, SeverityLevel
from turbine.core.dashboard.components.layout import (
    KPI,
    Divider,
    GaugeStrip,
    Header,
    KpiStrip,
    Page,
    Tabs,
)
from turbine.core.dashboard.injection import DependencyRegistry, Depends
from turbine.core.dashboard.models import TimeRange, get_page_meta, page
from turbine.core.dashboard.query import ChainSpec, DimensionScores, Query, Resource
from turbine.core.quality.check_results import DimensionScore
from turbine.presentation.dashboard.app import wrap_page
from turbine.presentation.dashboard.renderer import (
    BUILTIN_RENDERERS,
    CompositeRenderer,
    render_dashboard_css,
)
from turbine.presentation.dashboard.sidebar import render_sidebar

# -- Deterministic fake data --------------------------------------------------

random.seed(42)
TABLES = ("orders", "customers", "products", "inventory", "readings", "sensors")
CHECKS = ("null_check", "range_check", "format_check", "referential_check", "freshness_check")
DIMENSIONS = (
    QualityDimension.ACCURACY,
    QualityDimension.COMPLETENESS,
    QualityDimension.CONSISTENCY,
    QualityDimension.TIMELINESS,
)

DATES = tuple(str(dt.date(2026, 3, 15) + dt.timedelta(days=day)) for day in range(21))
PASS_RATES = tuple(round(88 + random.uniform(-3, 5), 1) for _ in DATES)
CHECK_COUNTS = tuple(float(random.randint(40, 65)) for _ in DATES)

SCORES = [
    DimensionScore(QualityDimension.ACCURACY, score=94.2, checks_passed=47, checks_total=50),
    DimensionScore(QualityDimension.COMPLETENESS, score=88.5, checks_passed=42, checks_total=48),
    DimensionScore(QualityDimension.CONSISTENCY, score=91.0, checks_passed=30, checks_total=33),
    DimensionScore(QualityDimension.TIMELINESS, score=97.8, checks_passed=44, checks_total=45),
]

HEATMAP_Z = tuple(tuple(round(random.uniform(75, 100), 1) for _ in DIMENSIONS) for _ in TABLES)

FAILURE_ROWS: tuple[Mapping[str, CellValue], ...] = tuple(
    {
        "Table": random.choice(TABLES),
        "Check": random.choice(CHECKS),
        "Dimension": random.choice([dim.value for dim in DIMENSIONS]),
        "Rows": random.randint(10, 500),
        "Severity": random.choice(["critical", "warning", "info"]),
        "Time": f"{random.randint(1, 23)}h ago",
    }
    for _ in range(12)
)


class MockDispatcher:
    """Return deterministic fake data for all resource types."""

    def execute(self, resource: Resource[Any], spec: ChainSpec) -> Any:  # noqa: ARG002 — Protocol impl
        """Return SCORES for DimensionScores resources; empty list otherwise."""
        if isinstance(resource, DimensionScores):
            return SCORES
        return []


# -- Pages using the full DSL ------------------------------------------------


@page("Overview", icon=":material/dashboard:", order=1)
def overview_page(scores: list[DimensionScore] = Depends(DimensionScores())) -> Page:
    """KPIs, gauges, trends, and quality heatmap."""
    overall = sum(score.score for score in scores) / len(scores) if scores else None
    total_checks = sum(score.checks_total for score in scores)
    total_passed = sum(score.checks_passed for score in scores)
    total_failed = total_checks - total_passed

    return Page(
        KpiStrip(
            KPI(label="Pass Rate", value=overall, fmt=".1f%", delta=1.3, delta_fmt="+.1f%"),
            KPI(label="Checks Run", value=total_checks, fmt=".0f"),
            KPI(label="Passed", value=total_passed, fmt=".0f"),
            KPI(label="Failed", value=total_failed, fmt=".0f"),
        ),
        Divider(),
        Header(text="Quality Dimensions"),
        GaugeStrip(*(Gauge(label=score.label().title(), value=score.score) for score in scores)),
        Divider(),
        Tabs(
            **{
                "Pass Rate": TrendChart(x=DATES, y=PASS_RATES, sla_line=90.0, y_label="Pass Rate %"),
                "Check Volume": BarChart(x=DATES, y=CHECK_COUNTS, y_label="Checks"),
                "Quality Matrix": Heatmap(
                    z=HEATMAP_Z, x_labels=tuple(dim.value.title() for dim in DIMENSIONS), y_labels=TABLES
                ),
            }
        ),
        title="Overview",
    )


@page("Data Explorer", icon=":material/table_chart:", order=2)
def data_explorer_page() -> Page:
    """Table and RowViewer with download buttons."""
    return Page(
        Alert(message="Showing mock data for demonstration purposes.", severity=SeverityLevel.INFO),
        Divider(),
        Header(text="Recent Failures"),
        Table(
            data=FAILURE_ROWS,
            columns=(
                ColumnConfig(name="Rows", column_type=ColumnType.NUMBER, fmt="%d"),
                ColumnConfig(name="Severity", width=ColumnWidth.SMALL),
                ColumnConfig(name="Time", width=ColumnWidth.SMALL),
            ),
            title="Failure Log",
            downloadable=True,
        ),
        Divider(),
        Header(text="Flagged Row Browser"),
        Alert(
            message="2 tables have critical failures requiring attention.",
            severity=SeverityLevel.WARNING,
        ),
        RowViewer(
            data=FAILURE_ROWS,
            columns=(
                ColumnConfig(name="Rows", column_type=ColumnType.NUMBER, fmt="%d"),
                ColumnConfig(name="Severity", width=ColumnWidth.SMALL),
            ),
            title="Click a row to inspect details",
            expandable=True,
        ),
        title="Data Explorer",
    )


@page("Alerts Demo", icon=":material/warning:", order=3)
def alerts_page() -> Page:
    """All three alert severity levels."""
    return Page(
        Alert(message="All checks passed in the last 24 hours.", severity=SeverityLevel.INFO),
        Alert(message="3 tables have freshness scores below 90%.", severity=SeverityLevel.WARNING),
        Alert(
            message="Critical: orders table null_check failed with 247 flagged rows.",
            severity=SeverityLevel.ERROR,
        ),
        Divider(),
        Header(text="Tabs with Mixed Content"),
        Tabs(
            Summary=(
                KpiStrip(
                    KPI(label="Healthy Tables", value=4, fmt=".0f"),
                    KPI(label="Warning Tables", value=1, fmt=".0f"),
                    KPI(label="Critical Tables", value=1, fmt=".0f"),
                ),
            ),
            Details=Table(
                data=FAILURE_ROWS[:5],
                columns=(ColumnConfig(name="Rows", column_type=ColumnType.NUMBER, fmt="%d"),),
                title="Top 5 Failures",
            ),
        ),
        title="Alert Levels",
    )


# -- Streamlit wiring (uses production app.py patterns) ----------------------


def main() -> None:
    """Configure Streamlit and render the component showcase page."""
    st.set_page_config(
        page_title="Turbine Component Showcase", page_icon=":material/speed:", layout="wide"
    )

    render_dashboard_css()
    dispatcher = MockDispatcher()

    with st.sidebar:
        st.title("Turbine")
        st.caption("Component Showcase")
        st.divider()
        time_range, refresh_interval = render_sidebar()
        st.divider()
        st.caption("v2.0.0-dev -- Wave 2 demo")

    run_every = refresh_interval.to_timedelta()

    registry = DependencyRegistry()
    registry.register(Query, lambda: Query(dispatcher))
    registry.register_value(TimeRange, time_range)

    all_pages = [overview_page, data_explorer_page, alerts_page]
    renderer = CompositeRenderer(BUILTIN_RENDERERS)

    st_pages = [
        st.Page(
            wrap_page(page_fn, registry, renderer, run_every=run_every),
            title=get_page_meta(page_fn).title,
            icon=get_page_meta(page_fn).icon or None,
            url_path=page_fn.__name__,
        )
        for page_fn in all_pages
    ]
    nav = st.navigation(st_pages)
    nav.run()


main()
