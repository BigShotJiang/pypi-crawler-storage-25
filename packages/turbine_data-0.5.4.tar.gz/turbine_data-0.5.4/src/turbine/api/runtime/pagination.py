"""Offset/limit pagination envelope, headers, and list-response builder.

``Page`` is the typed body wrapping every list response, the ``X-*`` /
``Link`` header helpers stamp the wire-side counters per the Enexis
pagination rules, and ``build_list_response`` branches on ``_fields`` so
sparse projections fall back to a raw ``JSONResponse`` instead of the
``response_model`` validation pipeline.
"""

from __future__ import annotations

from http import HTTPStatus
from typing import Any

from fastapi import Request, Response
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from turbine.api.runtime.query import parse_fields_directive


class Page[Item: BaseModel](BaseModel):
    """Offset/limit page envelope per the Enexis API spec.

    Mirrors the body fields callers see on every list response — the
    page itself plus the three counters needed to compute progress
    without re-reading headers.
    """

    items: list[Item]
    total: int
    offset: int
    limit: int


def build_link_header(path: str, *, offset: int, limit: int, total: int) -> str:
    """Build an RFC 8288 ``Link`` header for offset/limit pagination.

    Always emits ``rel="first"`` and ``rel="last"``. ``rel="prev"`` is
    only present when the caller has advanced past the first page;
    ``rel="next"`` only when more rows exist beyond the current page.
    """

    def link(target_offset: int, rel: str) -> str:
        return f'<{path}?_offset={target_offset}&_limit={limit}>; rel="{rel}"'

    parts: list[str] = [link(0, "first")]
    if offset > 0:
        parts.append(link(max(0, offset - limit), "prev"))
    if offset + limit < total:
        parts.append(link(offset + limit, "next"))
    last_offset = max(0, ((total - 1) // limit) * limit) if total > 0 else 0
    parts.append(link(last_offset, "last"))
    return ", ".join(parts)


def apply_pagination_headers(
    response: Response, *, request: Request, items_count: int, total: int, offset: int, limit: int
) -> None:
    """Stamp pagination headers and status code on *response*.

    Sets ``X-Total-Count``, ``X-Result-Count``, and ``Link`` per the
    Enexis pagination rules. Status flips to 206 when the response
    represents a real partial slice and stays 200 when the caller
    received everything available — including the degenerate
    out-of-range-offset case where no rows match at the requested
    window.
    """
    response.headers["X-Total-Count"] = str(total)
    response.headers["X-Result-Count"] = str(items_count)
    response.headers["Link"] = build_link_header(
        request.url.path, offset=offset, limit=limit, total=total
    )
    is_partial = (offset > 0 or limit < total) and offset < total
    response.status_code = HTTPStatus.PARTIAL_CONTENT if is_partial else HTTPStatus.OK


def build_list_response(
    rows: list[Any],
    *,
    request: Request,
    response: Response,
    fields_raw: str | None,
    total: int,
    offset: int,
    limit: int,
) -> Any:
    """Branch on ``_fields``: full ``Page`` or sparse ``JSONResponse``.

    The default path returns a parameterised ``Page`` so FastAPI's
    ``response_model`` validates the items end-to-end.  The sparse path
    bypasses ``response_model`` because the partial dicts can be missing
    fields the schema declares as required; we copy the pagination
    headers and status code over manually so the caller still sees the
    206/X-Total-Count behaviour.
    """
    selected = parse_fields_directive(fields_raw)
    if selected is None:
        items = [row.to_schema(request) for row in rows]
        return Page(items=items, total=total, offset=offset, limit=limit)
    sparse = [row.project_row(request, selected) for row in rows]
    payload = {"items": sparse, "total": total, "offset": offset, "limit": limit}
    return JSONResponse(
        content=payload, status_code=response.status_code, headers=dict(response.headers)
    )
