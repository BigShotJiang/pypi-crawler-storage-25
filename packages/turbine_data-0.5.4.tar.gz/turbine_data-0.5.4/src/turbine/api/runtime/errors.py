"""RFC 9457 ``application/problem+json`` exception handlers.

Four handlers (``HTTPException``, ``RequestValidationError``,
SQLAlchemy ``DBAPIError``, fallback ``Exception``) plus
:func:`register_exception_handlers` that wires them all on a FastAPI
app. Every error response goes out as a problem document with
``type``, ``title``, ``status``, ``detail``, ``instance``.

Database and unhandled errors NEVER echo ``str(exc)`` into the
response body — those messages typically embed the offending SQL
statement and bind parameters. They are logged in full and replaced
with a generic message in the wire payload.
"""

from __future__ import annotations

from http import HTTPStatus

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from loguru import logger
from sqlalchemy.exc import DBAPIError

PROBLEM_JSON_MEDIA_TYPE = "application/problem+json"
DB_ERROR_PROBLEM_TYPE = "/problems/query-error"
INTERNAL_ERROR_PROBLEM_TYPE = "/problems/internal-error"


def problem_response(
    request: Request, *, status: int, title: str, detail: str, problem_type: str = "about:blank"
) -> JSONResponse:
    """Build an RFC 9457 ``application/problem+json`` response."""
    body = {
        "type": problem_type,
        "title": title,
        "status": status,
        "detail": detail,
        "instance": str(request.url),
    }
    return JSONResponse(content=body, status_code=status, media_type=PROBLEM_JSON_MEDIA_TYPE)


async def http_exception_handler(request: Request, exc: HTTPException) -> JSONResponse:
    """Render any ``HTTPException`` as RFC 9457 problem details."""
    title = HTTPStatus(exc.status_code).phrase
    detail = str(exc.detail) if exc.detail else title
    return problem_response(request, status=exc.status_code, title=title, detail=detail)


def format_validation_errors(exc: RequestValidationError) -> str:
    """Render Pydantic errors as ``field: message; field: message``.

    ``loc`` is ``(source, field, ...)`` where *source* is ``query`` /
    ``body`` / ``path``; the field path is everything after it. A
    location with no field (a whole-body error) falls back to the
    source name so the message is never empty.
    """
    parts: list[str] = []
    for error in exc.errors():
        location = error.get("loc", ())
        field = ".".join(str(segment) for segment in location[1:]) or (
            str(location[0]) if location else "request"
        )
        parts.append(f"{field}: {error.get('msg', 'invalid value')}")
    return "; ".join(parts) or "request validation failed"


async def validation_exception_handler(request: Request, exc: RequestValidationError) -> JSONResponse:
    """Render Pydantic validation errors as RFC 9457 problem details."""
    return problem_response(
        request,
        status=HTTPStatus.UNPROCESSABLE_ENTITY,
        title="Unprocessable Entity",
        detail=format_validation_errors(exc),
    )


async def database_exception_handler(request: Request, exc: DBAPIError) -> JSONResponse:
    """Render SQLAlchemy ``DBAPIError`` as a sanitised 500 problem.

    The full exception (including SQL and bind parameters) is logged;
    the body carries a generic message so server internals don't leak.
    """
    logger.opt(exception=exc).error("database query error in {} {}", request.method, request.url)
    return problem_response(
        request,
        status=HTTPStatus.INTERNAL_SERVER_ERROR,
        title="Internal Server Error",
        detail=(
            "The database query failed. Check that the table and columns exist, "
            "your datasource has permission to read them, and the contract matches the database."
        ),
        problem_type=DB_ERROR_PROBLEM_TYPE,
    )


async def fallback_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """Last-resort handler turning any unhandled error into a 500 problem.

    Logs the full exception; returns a generic body so internal state
    (stack traces, secrets, cursor descriptions) never reaches clients.
    """
    logger.opt(exception=exc).error("unhandled error in {} {}", request.method, request.url)
    return problem_response(
        request,
        status=HTTPStatus.INTERNAL_SERVER_ERROR,
        title="Internal Server Error",
        detail="The server hit an unexpected error. Retry the request, then check the server logs.",
        problem_type=INTERNAL_ERROR_PROBLEM_TYPE,
    )


def register_exception_handlers(app: FastAPI) -> None:
    """Wire RFC 9457 problem-details handlers onto *app*."""
    app.add_exception_handler(HTTPException, http_exception_handler)  # ty: ignore[invalid-argument-type]
    app.add_exception_handler(RequestValidationError, validation_exception_handler)  # ty: ignore[invalid-argument-type]
    app.add_exception_handler(DBAPIError, database_exception_handler)  # ty: ignore[invalid-argument-type]
    app.add_exception_handler(Exception, fallback_exception_handler)
