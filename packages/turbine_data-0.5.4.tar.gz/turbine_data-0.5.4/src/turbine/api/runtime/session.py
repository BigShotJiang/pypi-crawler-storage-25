"""SQLAlchemy session wiring for the generated FastAPI ``mount(app)`` flow.

The generated ``mount(app, ...)`` calls :func:`bind_datasource` to attach a
SQLAlchemy engine and ``sessionmaker`` to ``app.state``.  Generated routers
depend on :func:`get_session`, which yields a Session pulled from that
state — so the routers stay free of any engine, URL, or driver knowledge.

Two ways to bind:

* ``datasource=`` — pass a Turbine :class:`DatasourceConfig`; the helper
  builds the engine via :func:`create_engine_from_config`.
* ``engine=`` — pass an already-built SQLAlchemy ``Engine`` (test
  fixtures, custom auth, in-memory SQLite).
"""

from __future__ import annotations

import re
from collections.abc import Iterator
from typing import Any

from fastapi import FastAPI, Request
from sqlalchemy import Engine, event
from sqlalchemy.orm import Session, sessionmaker

from turbine.core.common import DatasourceConfig
from turbine.infra.database.engine import create_engine_from_config

SESSION_LOCAL_STATE_KEY = "turbine_session_local"
SQLITE_DIALECT_NAME = "sqlite"


def bind_datasource(
    app: FastAPI, *, engine: Engine | None = None, datasource: DatasourceConfig | None = None
) -> Engine:
    """Attach a SQLAlchemy engine + sessionmaker to *app*'s state.

    Pass exactly one of ``engine`` or ``datasource``.  When
    ``datasource`` is given, the engine is built via
    :func:`create_engine_from_config`; when ``engine`` is given, it is
    used directly.

    Returns the bound :class:`Engine` so callers can hold a reference for
    teardown (``engine.dispose()``).
    """
    bound_engine = resolve_engine(engine=engine, datasource=datasource)
    install_sqlite_regexp_if_needed(bound_engine)
    session_local = sessionmaker(bind=bound_engine, expire_on_commit=False)
    setattr(app.state, SESSION_LOCAL_STATE_KEY, session_local)
    return bound_engine


def resolve_engine(*, engine: Engine | None, datasource: DatasourceConfig | None) -> Engine:
    """Coerce the (engine, datasource) pair into exactly one engine.

    Raises ``ValueError`` when neither is given or both are given so
    callers fail loudly at boot rather than dispatching against a dead
    handler later.
    """
    if engine is not None and datasource is not None:
        raise ValueError("pass either engine= or datasource=, not both")
    if engine is not None:
        return engine
    if datasource is not None:
        return create_engine_from_config(datasource)
    raise ValueError("bind_datasource requires engine= or datasource=")


def install_sqlite_regexp_if_needed(engine: Engine) -> None:
    """Wire a Python ``re.search`` into SQLite so ``column.regexp_match`` works.

    SQLite ships without a REGEXP function, so the ``*=`` filter operator
    (which compiles to ``column REGEXP pattern``) returns no rows
    otherwise.  Postgres / Snowflake / DuckDB have native operators and
    short-circuit.
    """
    if engine.dialect.name != SQLITE_DIALECT_NAME:
        return

    @event.listens_for(engine, "connect")
    def register(dbapi_connection: Any, connection_record: Any) -> None:
        del connection_record

        def regexp(pattern: str | None, value: str | None) -> bool:
            if pattern is None or value is None:
                return False
            return re.search(pattern, value) is not None

        dbapi_connection.create_function("REGEXP", 2, regexp)


def get_session(request: Request) -> Iterator[Session]:
    """FastAPI dependency yielding a Session from ``app.state``.

    Raises ``RuntimeError`` if :func:`bind_datasource` has not run on
    the app yet, so misconfigured deployments fail at first request
    rather than producing silent empty results.
    """
    session_local = getattr(request.app.state, SESSION_LOCAL_STATE_KEY, None)
    if session_local is None:
        raise RuntimeError(
            "No SQLAlchemy session is bound to this app. "
            "Call mount(app, datasource=...) or mount(app, engine=...) "
            "before serving requests."
        )
    session = session_local()
    try:
        yield session
    finally:
        session.close()
