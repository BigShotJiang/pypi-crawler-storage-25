"""Per-major OpenAPI views, docs, and contract introspection routes.

``register_versioned_openapi`` adds ``/v{major}/openapi.json``,
``/v{major}/docs``, ``/v{major}/redoc``, ``/v{major}/__contracts__``,
and ``/v{major}/__schema__`` routes filtered to one major version each.
The filter trims paths, prunes orphan component schemas, and rewrites
``info`` / ``tags`` / ``x-tagGroups`` so each spec stands alone.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from fastapi import FastAPI, Response
from fastapi.openapi.docs import get_redoc_html, get_swagger_ui_html
from fastapi.responses import JSONResponse
from pydantic import BaseModel

REF_PREFIX = "#/components/schemas/"
JSON_SCHEMA_DRAFT = "https://json-schema.org/draft/2020-12/schema"


@dataclass(frozen=True, slots=True)
class ResourceInfo:
    """One sibling resource under a contract.

    A multi-dataset contract carries N entries (one per Dataset) on its
    :class:`ContractInfo`; a single-dataset contract carries one. The
    operationIds let the introspection endpoints rebuild URLs without
    importing the per-resource router code.
    """

    resource_name: str
    schema_cls: type[BaseModel]
    list_operation_id: str
    detail_operation_id: str


@dataclass(frozen=True, slots=True)
class ContractInfo:
    """Per-contract metadata exposed via ``/__contracts__`` and ``/__schema__``.

    Lifecycle (status, sunset, successor) is one per contract regardless
    of how many datasets it carries; *resources* lists each Dataset's
    URL slug and Pydantic schema. *sunset_date* is the contract
    author's raw ``YYYY-MM-DD`` string (already ISO-8601), and
    *successor_href* is a pre-resolved relative URL — both are ``None``
    when absent so the introspection JSON shows ``null`` rather than
    missing keys.
    """

    contract_id: str
    domain: str
    version: str
    status: str
    docs_url: str
    resources: tuple[ResourceInfo, ...]
    sunset_date: str | None = None
    successor_href: str | None = None


@dataclass(frozen=True, slots=True)
class MajorVersionInfo:
    """Per-major metadata used to render filtered OpenAPI views.

    *domain_descriptions* is a sorted ``(name, description)`` pair list
    so the renderer keeps tag ordering stable across reruns and so the
    rendered code stays diff-friendly.  *contracts* drives the
    ``__contracts__`` and ``__schema__`` introspection endpoints.
    """

    major: int
    version: str
    description: str
    domain_descriptions: tuple[tuple[str, str], ...] = ()
    contracts: tuple[ContractInfo, ...] = ()


def collect_refs(node: Any) -> set[str]:
    """Recursively collect every ``#/components/schemas/...`` ref name."""
    found: set[str] = set()
    if isinstance(node, dict):
        ref = node.get("$ref")
        if isinstance(ref, str) and ref.startswith(REF_PREFIX):
            found.add(ref[len(REF_PREFIX) :])
        for value in node.values():
            found.update(collect_refs(value))
    elif isinstance(node, list):
        for item in node:
            found.update(collect_refs(item))
    return found


def transitive_schema_closure(schemas: dict[str, Any], roots: set[str]) -> set[str]:
    """Expand *roots* with every schema reachable through nested $refs."""
    reachable = set(roots)
    pending = list(roots)
    while pending:
        name = pending.pop()
        schema = schemas.get(name)
        if schema is None:
            continue
        for ref in collect_refs(schema):
            if ref not in reachable:
                reachable.add(ref)
                pending.append(ref)
    return reachable


TAG_SEPARATOR = " · "


def tag_for_resource(contract: ContractInfo, resource: ResourceInfo) -> str:
    """Mirror the codegen ``tag_for`` rule at runtime.

    Multi-dataset contracts get ``{contract_id} · {resource_name}`` so
    the Swagger nav distinguishes siblings; single-dataset contracts
    get just ``{contract_id}``.
    """
    if len(contract.resources) > 1:
        return f"{contract.contract_id}{TAG_SEPARATOR}{resource.resource_name}"
    return contract.contract_id


def per_domain_tag_groups(info: MajorVersionInfo) -> list[dict[str, Any]]:
    """Build the ``x-tagGroups`` list grouping contract+resource tags under their domain."""
    grouped: dict[str, list[str]] = {}
    for contract in info.contracts:
        for resource in contract.resources:
            grouped.setdefault(contract.domain, []).append(tag_for_resource(contract, resource))
    return [{"name": domain, "tags": grouped[domain]} for domain in sorted(grouped)]


def major_path_prefixes(info: MajorVersionInfo) -> tuple[str, ...]:
    """Return the URL prefixes owned by *info* (one per resource).

    The set is built from ``info.contracts`` rather than a regex match
    so unrelated routes that happen to look like ``/<seg>/v{major}/...``
    (e.g. management endpoints under ``/api/v{major}/...``) cannot leak
    into the per-major spec.
    """
    return tuple(
        f"/{contract.domain}/v{info.major}/{contract.contract_id}/{resource.resource_name}"
        for contract in info.contracts
        for resource in contract.resources
    )


def filter_openapi_for_major(spec: dict[str, Any], info: MajorVersionInfo) -> dict[str, Any]:
    """Return *spec* trimmed to a single major version.

    Keeps paths that fall under one of the contract resource prefixes
    declared on *info* (``/{domain}/v{major}/{contract_id}/{resource_name}/...``),
    prunes orphan component schemas, and rewrites ``info``, ``tags``,
    and ``x-tagGroups``. Tags now mirror the URL hierarchy: each
    contract contributes one tag per resource (``{contract_id} · {resource_name}``
    for multi-dataset, ``{contract_id}`` for single-dataset);
    ``x-tagGroups`` groups those tags under their domain so the Redoc
    nav reads ``domain → contract · resource``.
    """
    prefixes = major_path_prefixes(info)
    paths = {
        path: ops
        for path, ops in spec.get("paths", {}).items()
        if any(path == prefix or path.startswith(f"{prefix}/") for prefix in prefixes)
    }
    components = dict(spec.get("components", {}))
    schemas = dict(components.get("schemas", {}))
    if schemas:
        kept = transitive_schema_closure(schemas, collect_refs(paths))
        trimmed = {name: schemas[name] for name in kept if name in schemas}
        if trimmed:
            components["schemas"] = trimmed
        else:
            components.pop("schemas", None)
    filtered: dict[str, Any] = {**spec, "paths": paths}
    if components:
        filtered["components"] = components
    elif "components" in filtered:
        del filtered["components"]
    filtered["info"] = {
        "title": f"v{info.major}",
        "version": info.version,
        "description": info.description,
    }
    filtered["tags"] = [
        {"name": tag_for_resource(contract, resource), "description": contract.docs_url}
        for contract in info.contracts
        for resource in contract.resources
    ]
    filtered["x-tagGroups"] = per_domain_tag_groups(info)
    return filtered


def resource_url(info: MajorVersionInfo, contract: ContractInfo, resource: ResourceInfo) -> str:
    """Return the canonical URL for one resource."""
    return f"/{contract.domain}/v{info.major}/{contract.contract_id}/{resource.resource_name}"


def build_contracts_payload(info: MajorVersionInfo) -> list[dict[str, Any]]:
    """Render the ``__contracts__`` JSON list for *info*.

    Each contract entry carries a ``resources`` list so consumers can
    discover sibling endpoints without scraping the OpenAPI spec.
    """
    return [
        {
            "id": contract.contract_id,
            "domain": contract.domain,
            "version": contract.version,
            "status": contract.status,
            "docs": contract.docs_url,
            "openapi": f"/v{info.major}/openapi.json",
            "sunset": contract.sunset_date,
            "supersededBy": contract.successor_href,
            "resources": [
                {
                    "name": resource.resource_name,
                    "url": resource_url(info, contract, resource),
                    "listOperationId": resource.list_operation_id,
                    "detailOperationId": resource.detail_operation_id,
                }
                for resource in contract.resources
            ],
        }
        for contract in info.contracts
    ]


def build_schema_payload(info: MajorVersionInfo) -> dict[str, Any]:
    """Render the consolidated ``__schema__`` JSON Schema for *info*.

    Definitions are keyed by ``{contract_id}/{resource_name}`` so a
    multi-dataset contract surfaces every dataset's schema without
    collisions.
    """
    definitions = {
        f"{contract.contract_id}/{resource.resource_name}": resource.schema_cls.model_json_schema()
        for contract in info.contracts
        for resource in contract.resources
    }
    return {"$schema": JSON_SCHEMA_DRAFT, "definitions": definitions}


def register_versioned_openapi(app: FastAPI, infos: list[MajorVersionInfo]) -> None:
    """Wire ``/v{major}/openapi.json``, ``/v{major}/docs``, ``/v{major}/redoc``."""
    for info in infos:
        register_one_major(app, info)


def register_one_major(app: FastAPI, info: MajorVersionInfo) -> None:
    """Register the per-major openapi, docs, redoc, and introspection routes."""
    spec_path = f"/v{info.major}/openapi.json"
    docs_path = f"/v{info.major}/docs"
    redoc_path = f"/v{info.major}/redoc"
    contracts_path = f"/v{info.major}/__contracts__"
    schema_path = f"/v{info.major}/__schema__"

    async def openapi_view() -> JSONResponse:
        return JSONResponse(filter_openapi_for_major(app.openapi(), info))

    async def swagger_view() -> Response:
        return get_swagger_ui_html(openapi_url=spec_path, title=f"v{info.major} - Swagger UI")

    async def redoc_view() -> Response:
        return get_redoc_html(openapi_url=spec_path, title=f"v{info.major} - ReDoc")

    async def contracts_view() -> JSONResponse:
        return JSONResponse(build_contracts_payload(info))

    async def schema_view() -> JSONResponse:
        return JSONResponse(build_schema_payload(info))

    app.add_api_route(spec_path, openapi_view, include_in_schema=False, methods=["GET"])
    app.add_api_route(docs_path, swagger_view, include_in_schema=False, methods=["GET"])
    app.add_api_route(redoc_path, redoc_view, include_in_schema=False, methods=["GET"])
    app.add_api_route(contracts_path, contracts_view, include_in_schema=False, methods=["GET"])
    app.add_api_route(schema_path, schema_view, include_in_schema=False, methods=["GET"])
