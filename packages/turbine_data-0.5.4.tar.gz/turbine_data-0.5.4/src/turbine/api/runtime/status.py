"""Contract-status middleware: Deprecation, Sunset, X-Contract-Status, successor Link.

Reads the active route's ``openapi_extra`` payload (stamped by codegen
into every ``router.get(... openapi_extra=...)`` decorator) and layers
the corresponding lifecycle headers onto every response.

Implemented as a pure-ASGI middleware so it never crosses async-task
boundaries — same rationale as :mod:`turbine.api.runtime.observability`.
"""

from __future__ import annotations

from typing import Any, cast

from fastapi import FastAPI, Request, Response
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from turbine.api.runtime.caching import format_imf_fixdate

CONTRACT_STATUS_DRAFT = "draft"
CONTRACT_STATUS_DEPRECATED = "deprecated"
SUCCESSOR_LINK_REL = "successor-version"


def route_openapi_extras(request: Request) -> dict[str, Any] | None:
    """Return the matched route's ``openapi_extra`` dict, or ``None``."""
    return route_openapi_extras_from_scope(request.scope)


def route_openapi_extras_from_scope(scope: Scope) -> dict[str, Any] | None:
    """Return the matched route's ``openapi_extra`` dict, reading from *scope*."""
    route = scope.get("route")
    if route is None:
        return None
    return getattr(route, "openapi_extra", None)


def apply_status_headers(response: Response, extras: dict[str, Any]) -> None:
    """Stamp lifecycle headers (X-Contract-Status, Deprecation, Sunset, Link).

    DRAFT contracts emit ``X-Contract-Status``; DEPRECATED ones emit
    ``Deprecation: true`` plus optional ``Sunset`` and successor
    ``Link`` headers when the contract author declared
    ``customProperties.sunsetDate`` / ``supersededBy``.
    """
    status = extras.get("x-contract-status")
    if status == CONTRACT_STATUS_DRAFT:
        response.headers["X-Contract-Status"] = CONTRACT_STATUS_DRAFT
        return
    if status != CONTRACT_STATUS_DEPRECATED:
        return
    response.headers["Deprecation"] = "true"
    sunset = extras.get("x-sunset-date")
    if isinstance(sunset, str) and sunset:
        response.headers["Sunset"] = format_imf_fixdate(sunset)
    href = extras.get("x-successor-href")
    if isinstance(href, str) and href:
        response.headers.append("Link", f'<{href}>; rel="{SUCCESSOR_LINK_REL}"')


def apply_status_headers_to_raw(headers: list[tuple[bytes, bytes]], extras: dict[str, Any]) -> None:
    """Stamp lifecycle headers on a raw ASGI header list."""
    status = extras.get("x-contract-status")
    if status == CONTRACT_STATUS_DRAFT:
        replace_header(headers, "X-Contract-Status", CONTRACT_STATUS_DRAFT)
        return
    if status != CONTRACT_STATUS_DEPRECATED:
        return
    replace_header(headers, "Deprecation", "true")
    sunset = extras.get("x-sunset-date")
    if isinstance(sunset, str) and sunset:
        replace_header(headers, "Sunset", format_imf_fixdate(sunset))
    href = extras.get("x-successor-href")
    if isinstance(href, str) and href:
        headers.append((b"link", f'<{href}>; rel="{SUCCESSOR_LINK_REL}"'.encode("latin-1")))


def replace_header(headers: list[tuple[bytes, bytes]], name: str, value: str) -> None:
    """Drop any existing entry for *name* (case-insensitive) and append the new value."""
    name_bytes = name.lower().encode("latin-1")
    headers[:] = [
        (existing, existing_value)
        for existing, existing_value in headers
        if existing.lower() != name_bytes
    ]
    headers.append((name_bytes, value.encode("latin-1")))


class contract_status_middleware:  # noqa: N801 — class is the public middleware symbol
    """Pure-ASGI middleware: layers lifecycle headers onto every response.

    Wraps the downstream ``send`` to mutate the outbound
    ``http.response.start`` headers in place; the matched route is on
    ``scope["route"]`` by the time the start message is emitted.
    """

    __slots__ = ("app",)

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        async def stamp_send(message: Message) -> None:
            if message["type"] == "http.response.start":
                extras = route_openapi_extras_from_scope(scope)
                if extras:
                    headers: list[tuple[bytes, bytes]] = list(message.get("headers", ()))
                    apply_status_headers_to_raw(headers, extras)
                    message["headers"] = headers
            await send(message)

        await self.app(scope, receive, stamp_send)


def register_contract_status_middleware(app: FastAPI) -> None:
    """Wire :class:`contract_status_middleware` onto *app*."""
    app.add_middleware(cast(Any, contract_status_middleware))
