"""Wire-format helpers for filter / sort / sparse-fields query directives.

Inline operator decoding (``>=10``, ``*=.*foo.*``, etc.) and ``_sort`` /
``_fields`` / camelCase translation live here so route handlers stay
declarative — they just collect raw query strings, the runtime parses
them.
"""

from __future__ import annotations

from enum import StrEnum

FIELDS_NONE_KEYWORD = "none"
META_QUERY_PARAMS: frozenset[str] = frozenset({"_offset", "_limit", "_sort", "_fields"})


class FilterOperator(StrEnum):
    """Inline operator parsed off the value side of a filter query param."""

    EQ = "eq"
    IN = "in"
    GT = "gt"
    GTE = "gte"
    LT = "lt"
    LTE = "lte"
    REGEX = "regex"


def to_camel(snake: str) -> str:
    """Convert ``snake_case`` to ``lowerCamelCase``.

    Empty input returns empty.  A single segment is returned unchanged.
    """
    if not snake:
        return snake
    head, *tail = snake.split("_")
    return head + "".join(part[:1].upper() + part[1:] for part in tail)


FILTER_PREFIX_OPERATORS: tuple[tuple[str, FilterOperator], ...] = (
    (">=", FilterOperator.GTE),
    ("<=", FilterOperator.LTE),
    (">", FilterOperator.GT),
    ("<", FilterOperator.LT),
    ("*=", FilterOperator.REGEX),
)


def parse_filter_value(raw: str) -> tuple[FilterOperator, str | list[str]]:
    """Decode an inline-encoded filter value into ``(operator, value)``.

    Per the Enexis spec, operators ride in the value with URL-encoded
    prefixes (``%3E`` -> ``>``, ``%2A%3D`` -> ``*=``, etc.).  By the time
    the request reaches Python the framework has already decoded them,
    so we match raw ASCII prefixes here.
    """
    for prefix, operator in FILTER_PREFIX_OPERATORS:
        if raw.startswith(prefix):
            return operator, raw[len(prefix) :]
    if "," in raw:
        return FilterOperator.IN, raw.split(",")
    return FilterOperator.EQ, raw


def parse_sort_directive(raw: str) -> list[tuple[str, bool]]:
    """Split ``_sort`` into ``[(field, ascending)]`` pairs.

    ``+field`` and bare ``field`` are ascending; ``-field`` is
    descending.  Field names come back unchanged (camelCase from the
    wire) for the caller to translate into snake_case columns.
    """
    out: list[tuple[str, bool]] = []
    for token in raw.split(","):
        stripped = token.strip()
        if not stripped:
            continue
        if stripped.startswith("-"):
            out.append((stripped[1:], False))
        elif stripped.startswith("+"):
            out.append((stripped[1:], True))
        else:
            out.append((stripped, True))
    return out


def parse_fields_directive(raw: str | None) -> frozenset[str] | None:
    """Decode ``_fields``: ``None`` -> all, ``frozenset()`` -> id+href only.

    The literal ``_fields=none`` collapses to an empty frozenset, which
    callers treat as the "id and href only" special case from the spec.
    """
    if raw is None:
        return None
    if raw == FIELDS_NONE_KEYWORD:
        return frozenset()
    return frozenset(token.strip() for token in raw.split(",") if token.strip())
