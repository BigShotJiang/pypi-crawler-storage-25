"""Token-bucket rate limiting middleware with env-driven config.

Off by default: ``register_rate_limit_middleware`` short-circuits when
the resolved :class:`RateLimitConfig` has ``enabled=False`` so a fresh
mount has zero per-request cost.  Set ``TURBINE_RATE_LIMIT_ENABLED=1`` (and
optionally ``TURBINE_RATE_LIMIT_RATE`` / ``_PERIOD_SECONDS`` / ``_BURST``
/ ``_CLIENT_HEADER``) to opt in.

Implemented as a pure-ASGI middleware so it never crosses async-task
boundaries — same rationale as :mod:`turbine.api.runtime.observability`.
"""

from __future__ import annotations

import math
import os
from dataclasses import dataclass
from http import HTTPStatus
from time import monotonic
from typing import Any, Protocol, cast

from fastapi import FastAPI, Request, Response
from fastapi.responses import JSONResponse
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from turbine.api.runtime.errors import problem_response
from turbine.api.runtime.observability import REQUEST_ID_HEADER, set_raw_header

RATE_LIMIT_LIMIT_HEADER = "X-Rate-Limit-Limit"
RATE_LIMIT_REMAINING_HEADER = "X-Rate-Limit-Remaining"
RATE_LIMIT_RESET_HEADER = "X-Rate-Limit-Reset"
RETRY_AFTER_HEADER = "Retry-After"
DEFAULT_CLIENT_HEADER = "X-Client-Id"
ANONYMOUS_CLIENT_ID = "anonymous"
TURBINE_RATE_LIMIT_ENABLED = "TURBINE_RATE_LIMIT_ENABLED"
TURBINE_RATE_LIMIT_RATE = "TURBINE_RATE_LIMIT_RATE"
TURBINE_RATE_LIMIT_PERIOD_SECONDS = "TURBINE_RATE_LIMIT_PERIOD_SECONDS"
TURBINE_RATE_LIMIT_BURST = "TURBINE_RATE_LIMIT_BURST"
TURBINE_RATE_LIMIT_CLIENT_HEADER = "TURBINE_RATE_LIMIT_CLIENT_HEADER"
TRUTHY_ENV_VALUES: frozenset[str] = frozenset({"1", "true", "yes", "on"})


@dataclass(frozen=True, slots=True)
class RateLimitConfig:
    """Token-bucket policy applied uniformly across every route.

    *enabled* gates the whole feature so the default is a true no-op:
    when it stays ``False`` the middleware never inspects the request,
    never stamps headers, and never short-circuits with 429.  *rate*
    and *period_seconds* describe the steady-state refill (60 tokens
    per 60s by default); *burst* sets the bucket capacity, which also
    seeds the initial token count so a fresh client gets a small
    spike before settling into the rate.
    """

    enabled: bool = False
    rate: int = 60
    period_seconds: float = 60.0
    burst: int = 30
    client_header: str = DEFAULT_CLIENT_HEADER

    @property
    def refill_rate(self) -> float:
        """Tokens added per second."""
        return self.rate / self.period_seconds


@dataclass(frozen=True, slots=True)
class RateLimitDecision:
    """Outcome of one bucket consumption: allowed-or-not plus header values."""

    allowed: bool
    limit: int
    remaining: int
    reset_seconds: float


@dataclass(slots=True)
class TokenBucket:
    """Single-client token bucket: drains on take, refills with elapsed time."""

    capacity: int
    refill_rate: float
    tokens: float
    last_refill: float

    def refill(self, now: float) -> None:
        """Advance the bucket clock to *now*, capping tokens at *capacity*."""
        elapsed = max(0.0, now - self.last_refill)
        self.tokens = min(float(self.capacity), self.tokens + elapsed * self.refill_rate)
        self.last_refill = now

    def take(self, now: float) -> bool:
        """Refill, then consume one token if any are available."""
        self.refill(now)
        if self.tokens >= 1.0:
            self.tokens -= 1.0
            return True
        return False

    def reset_seconds(self) -> float:
        """Seconds until the bucket holds at least one whole token again."""
        if self.tokens >= 1.0 or self.refill_rate <= 0.0:
            return 0.0
        return (1.0 - self.tokens) / self.refill_rate


class RateLimitBackend(Protocol):
    """Pluggable storage for token buckets keyed by client id."""

    def consume(self, client_id: str, config: RateLimitConfig, now: float) -> RateLimitDecision:
        """Take a token for *client_id* and return the resulting decision."""
        ...


class InMemoryRateLimitBackend(RateLimitBackend):
    """Single-process in-memory backend; OK for one worker, not for fleets.

    Multi-worker deployments need an external store (Redis) to share
    bucket state across processes; that's a follow-up.  Buckets are
    created lazily on first sight of a client so memory grows with the
    active client set rather than the configured-but-unseen population.
    """

    buckets: dict[str, TokenBucket]

    def __init__(self) -> None:
        self.buckets = {}

    def bucket_for(self, client_id: str, config: RateLimitConfig, now: float) -> TokenBucket:
        """Return the existing bucket or seed a fresh one at full capacity."""
        bucket = self.buckets.get(client_id)
        if bucket is None:
            bucket = TokenBucket(
                capacity=config.burst,
                refill_rate=config.refill_rate,
                tokens=float(config.burst),
                last_refill=now,
            )
            self.buckets[client_id] = bucket
        return bucket

    def consume(self, client_id: str, config: RateLimitConfig, now: float) -> RateLimitDecision:
        bucket = self.bucket_for(client_id, config, now)
        allowed = bucket.take(now)
        return RateLimitDecision(
            allowed=allowed,
            limit=config.burst,
            remaining=int(bucket.tokens),
            reset_seconds=bucket.reset_seconds(),
        )


def env_truthy(value: str | None) -> bool:
    """Return ``True`` when *value* matches the canonical truthy strings."""
    return value is not None and value.strip().lower() in TRUTHY_ENV_VALUES


def rate_limit_config_from_env() -> RateLimitConfig:
    """Build a :class:`RateLimitConfig` from ``TURBINE_RATE_LIMIT_*`` env vars."""
    defaults = RateLimitConfig()
    enabled = env_truthy(os.environ.get(TURBINE_RATE_LIMIT_ENABLED))
    rate_raw = os.environ.get(TURBINE_RATE_LIMIT_RATE)
    period_raw = os.environ.get(TURBINE_RATE_LIMIT_PERIOD_SECONDS)
    burst_raw = os.environ.get(TURBINE_RATE_LIMIT_BURST)
    header = os.environ.get(TURBINE_RATE_LIMIT_CLIENT_HEADER, defaults.client_header)
    return RateLimitConfig(
        enabled=enabled,
        rate=int(rate_raw) if rate_raw else defaults.rate,
        period_seconds=float(period_raw) if period_raw else defaults.period_seconds,
        burst=int(burst_raw) if burst_raw else defaults.burst,
        client_header=header,
    )


def extract_client_id(request: Request, config: RateLimitConfig) -> str:
    """Pick the bucket key off *request*: configured header, then request id."""
    candidate = request.headers.get(config.client_header)
    if candidate:
        return candidate
    upstream = request.headers.get(REQUEST_ID_HEADER)
    if upstream:
        return upstream
    return ANONYMOUS_CLIENT_ID


def extract_client_id_from_scope(scope: Scope, config: RateLimitConfig) -> str:
    """Pick the bucket key off *scope*: configured header, then upstream request id."""
    target = config.client_header.lower().encode("latin-1")
    request_id_target = REQUEST_ID_HEADER.lower().encode("latin-1")
    upstream_request_id: str | None = None
    for name, value in scope.get("headers", ()):
        lower = name.lower()
        if lower == target:
            return value.decode("latin-1")
        if lower == request_id_target:
            upstream_request_id = value.decode("latin-1")
    return upstream_request_id or ANONYMOUS_CLIENT_ID


def apply_rate_limit_headers(response: Response, decision: RateLimitDecision) -> None:
    """Stamp the three ``X-Rate-Limit-*`` headers on *response*."""
    response.headers[RATE_LIMIT_LIMIT_HEADER] = str(decision.limit)
    response.headers[RATE_LIMIT_REMAINING_HEADER] = str(decision.remaining)
    response.headers[RATE_LIMIT_RESET_HEADER] = str(math.ceil(decision.reset_seconds))


def stamp_rate_limit_headers(headers: list[tuple[bytes, bytes]], decision: RateLimitDecision) -> None:
    """Stamp the three ``X-Rate-Limit-*`` headers on a raw ASGI header list."""
    set_raw_header(headers, RATE_LIMIT_LIMIT_HEADER, str(decision.limit))
    set_raw_header(headers, RATE_LIMIT_REMAINING_HEADER, str(decision.remaining))
    set_raw_header(headers, RATE_LIMIT_RESET_HEADER, str(math.ceil(decision.reset_seconds)))


def rate_limited_response(request: Request, decision: RateLimitDecision) -> JSONResponse:
    """Build the 429 problem-details response for an exhausted bucket."""
    retry_after = max(1, math.ceil(decision.reset_seconds))
    response = problem_response(
        request,
        status=HTTPStatus.TOO_MANY_REQUESTS,
        title="Too Many Requests",
        detail=f"Rate limit exceeded. Retry after {retry_after} seconds.",
    )
    apply_rate_limit_headers(response, decision)
    response.headers[RETRY_AFTER_HEADER] = str(retry_after)
    return response


class rate_limit_middleware:  # noqa: N801 — class is the public middleware symbol
    """Pure-ASGI middleware: drains the per-client bucket on every request.

    Returning the 429 response from ASGI directly (instead of through a
    Starlette ``Response``) keeps the whole exchange on a single asyncio
    task, matching the OTEL-safe pattern used by the other middlewares.
    """

    __slots__ = ("app", "backend", "config")

    def __init__(self, app: ASGIApp, *, config: RateLimitConfig, backend: RateLimitBackend) -> None:
        self.app = app
        self.config = config
        self.backend = backend

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        client_id = extract_client_id_from_scope(scope, self.config)
        decision = self.backend.consume(client_id, self.config, monotonic())
        if not decision.allowed:
            request = Request(scope, receive)
            response = rate_limited_response(request, decision)
            await response(scope, receive, send)
            return

        async def stamp_send(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers: list[tuple[bytes, bytes]] = list(message.get("headers", ()))
                stamp_rate_limit_headers(headers, decision)
                message["headers"] = headers
            await send(message)

        await self.app(scope, receive, stamp_send)


def register_rate_limit_middleware(
    app: FastAPI, *, config: RateLimitConfig | None = None, backend: RateLimitBackend | None = None
) -> None:
    """Wire :class:`rate_limit_middleware` onto *app* when *config* is enabled.

    A ``None`` config falls back to :func:`rate_limit_config_from_env`,
    so calling this from ``mount(app)`` with no arguments is the
    canonical "off by default, opt-in via env vars" wiring.  When the
    resolved config is disabled the function returns immediately and
    the middleware is never added — there is zero per-request cost in
    the default configuration.
    """
    resolved = config if config is not None else rate_limit_config_from_env()
    if not resolved.enabled:
        return
    chosen_backend = backend if backend is not None else InMemoryRateLimitBackend()
    app.add_middleware(cast(Any, rate_limit_middleware), config=resolved, backend=chosen_backend)
