"""Per-request X-Request-Id, X-Trace-Id, X-Contract-* and Server-Timing.

``PhaseTimer`` accumulates per-phase durations a handler stamps via the
:func:`phase` context manager; the middleware layers the resulting
``Server-Timing`` value plus the request id (echoed if upstream sent
one), the OTEL trace id (when available), and the matched route's
``x-contract-id`` / ``x-contract-version`` extras.

The middleware is implemented as a pure-ASGI class so it never crosses
async-task boundaries.  Starlette's ``BaseHTTPMiddleware`` (the engine
behind ``app.middleware("http")``) spawns a separate anyio task for the
downstream call, which breaks OpenTelemetry context tokens — they get
attached in one task and detached in another, raising ``Token was
created in a different Context``.  Wrapping the work in a pure-ASGI
class keeps the whole request/response on a single asyncio task.
"""

from __future__ import annotations

import uuid
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass, field
from time import perf_counter
from typing import Any, cast

from fastapi import FastAPI, Request, Response
from starlette.types import ASGIApp, Message, Receive, Scope, Send

from turbine.api.runtime.status import route_openapi_extras_from_scope

try:
    import opentelemetry.trace as _opentelemetry_trace

    otel_trace: Any = _opentelemetry_trace
except ImportError:
    otel_trace = None

REQUEST_ID_HEADER = "X-Request-Id"
TRACE_ID_HEADER = "X-Trace-Id"
CONTRACT_ID_HEADER = "X-Contract-Id"
CONTRACT_VERSION_HEADER = "X-Contract-Version"
SERVER_TIMING_HEADER = "Server-Timing"
PHASE_TIMER_STATE_KEY = "phase_timer"
PHASE_TOTAL = "total"
PHASE_DB = "db"
PHASE_VALIDATION = "validation"


def format_duration(dur_ms: float) -> str:
    """Render *dur_ms* trimmed of trailing zeros so 12.250 renders as 12.25."""
    formatted = f"{dur_ms:.3f}".rstrip("0").rstrip(".")
    return formatted or "0"


@dataclass(slots=True)
class PhaseTimer:
    """Accumulator for named phase durations on a single request.

    Each ``record`` call layers milliseconds onto the named phase so a
    handler can sum nested DB calls without losing per-phase totals.
    ``server_timing_value`` renders the accumulator as the body of a
    ``Server-Timing`` header, sorted alphabetically so reruns produce a
    stable ordering.
    """

    durations_ms: dict[str, float] = field(default_factory=dict)

    def record(self, name: str, dur_ms: float) -> None:
        """Add *dur_ms* milliseconds to the running total for *name*."""
        self.durations_ms[name] = self.durations_ms.get(name, 0.0) + dur_ms

    def server_timing_value(self) -> str:
        """Render the accumulator as a ``Server-Timing`` header value."""
        if not self.durations_ms:
            return ""
        parts = [f"{name};dur={format_duration(dur)}" for name, dur in sorted(self.durations_ms.items())]
        return ", ".join(parts)


@contextmanager
def phase(request: Request, name: str) -> Iterator[None]:
    """Time the wrapped block and add it to the request's :class:`PhaseTimer`.

    A no-op when the observability middleware has not registered a
    timer on ``request.state`` so handler code stays valid even when
    callers mount the routers without :class:`observability_middleware`.
    """
    timer = getattr(request.state, PHASE_TIMER_STATE_KEY, None)
    if timer is None:
        yield
        return
    start = perf_counter()
    try:
        yield
    finally:
        timer.record(name, (perf_counter() - start) * 1000.0)


def current_otel_trace_id() -> str | None:
    """Return the active OTEL span id as a 16-char hex string, or ``None``.

    Returns ``None`` when OpenTelemetry is not installed or when no
    recording span is on the stack — span_id ``0`` is OTEL's sentinel
    for "no context", and we never want to emit a header full of zeros.
    """
    if otel_trace is None:
        return None
    span = otel_trace.get_current_span()
    span_context = span.get_span_context()
    if span_context.span_id == 0:
        return None
    return f"{span_context.span_id:016x}"


def set_raw_header(headers: list[tuple[bytes, bytes]], name: str, value: str) -> None:
    """Replace any existing entry for *name* and append the new value.

    ASGI headers are a list of ``(name, value)`` byte tuples; mutating
    the list in place is the canonical way to stamp a response header
    from inside an ASGI middleware.
    """
    name_bytes = name.lower().encode("latin-1")
    headers[:] = [
        (existing, existing_value)
        for existing, existing_value in headers
        if existing.lower() != name_bytes
    ]
    headers.append((name_bytes, value.encode("latin-1")))


def apply_observability_headers(
    response: Response, *, request_id: str, extras: dict[str, Any] | None, timer: PhaseTimer
) -> None:
    """Stamp request-id, trace-id, contract metadata, and Server-Timing.

    Used by tests and by callers building a ``Response`` outside the
    ASGI flow.  The middleware itself stamps the same headers directly
    on the outbound ``http.response.start`` message.
    """
    response.headers[REQUEST_ID_HEADER] = request_id
    trace_id = current_otel_trace_id()
    if trace_id is not None:
        response.headers[TRACE_ID_HEADER] = trace_id
    if extras:
        contract_id = extras.get("x-contract-id")
        if isinstance(contract_id, str) and contract_id:
            response.headers[CONTRACT_ID_HEADER] = contract_id
        contract_version = extras.get("x-contract-version")
        if isinstance(contract_version, str) and contract_version:
            response.headers[CONTRACT_VERSION_HEADER] = contract_version
    timing = timer.server_timing_value()
    if timing:
        response.headers[SERVER_TIMING_HEADER] = timing


def upstream_request_id(scope: Scope) -> str | None:
    """Return the inbound ``X-Request-Id`` value from *scope*, or ``None``."""
    target = REQUEST_ID_HEADER.lower().encode("latin-1")
    for name, value in scope.get("headers", ()):
        if name.lower() == target:
            return value.decode("latin-1")
    return None


def stamp_response_start_headers(
    message: Message, scope: Scope, request_id: str, timer: PhaseTimer
) -> None:
    """Apply observability headers to an ``http.response.start`` message."""
    headers: list[tuple[bytes, bytes]] = list(message.get("headers", ()))
    set_raw_header(headers, REQUEST_ID_HEADER, request_id)
    trace_id = current_otel_trace_id()
    if trace_id is not None:
        set_raw_header(headers, TRACE_ID_HEADER, trace_id)
    extras = route_openapi_extras_from_scope(scope)
    stamp_contract_headers(headers, extras)
    timing = timer.server_timing_value()
    if timing:
        set_raw_header(headers, SERVER_TIMING_HEADER, timing)
    message["headers"] = headers


def stamp_contract_headers(headers: list[tuple[bytes, bytes]], extras: dict[str, Any] | None) -> None:
    """Apply contract metadata headers when route OpenAPI extras provide them."""
    if not extras:
        return
    contract_id = extras.get("x-contract-id")
    if isinstance(contract_id, str) and contract_id:
        set_raw_header(headers, CONTRACT_ID_HEADER, contract_id)
    contract_version = extras.get("x-contract-version")
    if isinstance(contract_version, str) and contract_version:
        set_raw_header(headers, CONTRACT_VERSION_HEADER, contract_version)


class observability_middleware:  # noqa: N801 — class is the public middleware symbol
    """Pure-ASGI middleware: stamps the observability headers on every response.

    Lives on a single asyncio task for the whole request/response so
    OpenTelemetry context tokens attached during the handler are still
    detachable when the response unwinds.  Wraps the downstream ``send``
    to mutate the outbound ``http.response.start`` headers in place,
    then forwards every message untouched.
    """

    __slots__ = ("app",)

    def __init__(self, app: ASGIApp) -> None:
        self.app = app

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        request_id = upstream_request_id(scope) or str(uuid.uuid4())
        timer = PhaseTimer()
        scope.setdefault("state", {})
        scope["state"][PHASE_TIMER_STATE_KEY] = timer

        start = perf_counter()

        async def stamp_send(message: Message) -> None:
            if message["type"] == "http.response.start":
                timer.record(PHASE_TOTAL, (perf_counter() - start) * 1000.0)
                stamp_response_start_headers(message, scope, request_id, timer)
            await send(message)

        await self.app(scope, receive, stamp_send)


def build_observability_middleware(app: ASGIApp) -> ASGIApp:
    """Return an observability middleware instance for Starlette registration."""
    return observability_middleware(app)


def register_observability_middleware(app: FastAPI) -> None:
    """Wire :class:`observability_middleware` onto *app*."""
    app.add_middleware(cast(Any, build_observability_middleware))


# Re-export for callers that constructed Request manually before this rewrite.
__all__ = [
    "CONTRACT_ID_HEADER",
    "CONTRACT_VERSION_HEADER",
    "PHASE_DB",
    "PHASE_TIMER_STATE_KEY",
    "PHASE_TOTAL",
    "PHASE_VALIDATION",
    "REQUEST_ID_HEADER",
    "SERVER_TIMING_HEADER",
    "TRACE_ID_HEADER",
    "PhaseTimer",
    "apply_observability_headers",
    "current_otel_trace_id",
    "format_duration",
    "observability_middleware",
    "phase",
    "register_observability_middleware",
    "route_openapi_extras_from_scope",
    "set_raw_header",
    "upstream_request_id",
]
