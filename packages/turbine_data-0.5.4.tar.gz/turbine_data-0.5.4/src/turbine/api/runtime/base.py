"""SQLAlchemy declarative base + generic helpers used by every generated model.

``Base`` is the single ``DeclarativeBase`` every generated table class
inherits.  ``AbstractModel`` layers query helpers (filter, sort, page,
sparse projection) on top so individual contract models stay free of
infrastructure code.
"""

from __future__ import annotations

from collections.abc import Callable
from datetime import date, datetime, time
from decimal import Decimal, InvalidOperation
from http import HTTPStatus
from typing import Any, ClassVar, Self

from fastapi import HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import Select, func, select
from sqlalchemy.orm import DeclarativeBase, Session

from turbine.api.runtime.query import (
    META_QUERY_PARAMS,
    FilterOperator,
    parse_filter_value,
    parse_sort_directive,
)

FILTER_CLAUSE_BUILDERS: dict[FilterOperator, Callable[[Any, Any], Any]] = {
    FilterOperator.EQ: lambda column, value: column == value,
    FilterOperator.IN: lambda column, value: column.in_(value),
    FilterOperator.GT: lambda column, value: column > value,
    FilterOperator.GTE: lambda column, value: column >= value,
    FilterOperator.LT: lambda column, value: column < value,
    FilterOperator.LTE: lambda column, value: column <= value,
    FilterOperator.REGEX: lambda column, value: column.regexp_match(value),
}

NON_COERCED_OPERATORS: frozenset[FilterOperator] = frozenset({FilterOperator.REGEX})

TRUTHY_LITERALS: frozenset[str] = frozenset({"true", "1", "yes", "y", "t"})
FALSY_LITERALS: frozenset[str] = frozenset({"false", "0", "no", "n", "f"})


def coerce_bool(raw: str) -> bool:
    """Decode common boolean literals; raise 400 on anything else."""
    lowered = raw.lower()
    if lowered in TRUTHY_LITERALS:
        return True
    if lowered in FALSY_LITERALS:
        return False
    raise HTTPException(
        HTTPStatus.BAD_REQUEST,
        f"'{raw}' is not a valid true/false value. Use true, false, yes, no, 1, or 0.",
    )


SCALAR_COERCERS: dict[type, Callable[[str], Any]] = {
    str: lambda raw: raw,
    bool: coerce_bool,
    int: int,
    float: float,
    Decimal: Decimal,
    datetime: datetime.fromisoformat,
    date: date.fromisoformat,
    time: time.fromisoformat,
}

COERCION_LABELS: dict[type, str] = {
    bool: "boolean",
    int: "integer",
    float: "number",
    Decimal: "decimal",
    datetime: "timestamp",
    date: "date",
    time: "time",
}


def coerce_scalar(raw: str, python_type: type) -> Any:
    """Coerce one query string to the column's Python type, or raise 400.

    Supports the scalar types SQLAlchemy maps onto: int, float,
    Decimal, bool, str, datetime, date, time. Unknown types fall
    through unchanged so callers don't lose data.
    """
    coercer = SCALAR_COERCERS.get(python_type)
    if coercer is None:
        return raw
    try:
        return coercer(raw)
    except (ValueError, InvalidOperation) as exc:
        label = COERCION_LABELS.get(python_type, python_type.__name__)
        raise HTTPException(
            HTTPStatus.BAD_REQUEST,
            f"'{raw}' is not a valid {label} value. Use the same format as the column data.",
        ) from exc


def column_python_type(column: Any) -> type:
    """Resolve the Python type for a SQLAlchemy column, falling back to str."""
    column_type = getattr(column, "type", None)
    if column_type is None:
        return str
    try:
        resolved = column_type.python_type
    except (NotImplementedError, AttributeError):
        return str
    return resolved


def coerce_filter_value(column: Any, op: FilterOperator, value: str | list[str]) -> Any:
    """Coerce one parsed filter value to the column's native type.

    REGEX is left as a string because the SQL operator works on text.
    All other operators get the column's Python type so the bind param
    matches the column type and the database doesn't refuse the
    comparison.
    """
    if op in NON_COERCED_OPERATORS:
        return value
    python_type = column_python_type(column)
    if isinstance(value, list):
        return [coerce_scalar(item, python_type) for item in value]
    return coerce_scalar(value, python_type)


def filter_clause(column: Any, op: FilterOperator, value: str | list[str]) -> Any:
    """Dispatch on *op* to build the SQLAlchemy clause for a single filter."""
    coerced = coerce_filter_value(column, op, value)
    return FILTER_CLAUSE_BUILDERS[op](column, coerced)


class Base(DeclarativeBase):
    """Shared declarative base for every codegen'd model."""


class AbstractModel[FilterSchema: BaseModel, IdType](Base):
    """Generic SQLAlchemy base providing query helpers and schema projection.

    Type parameters:
        FilterSchema: Pydantic filter class for list queries (unused in this slice).
        IdType: Primary-key Python type — ``int``, ``str``, or a tuple
            for composite keys.

    Subclasses set ``__id_field__``, ``__schema_cls__`` and
    ``__detail_operation_id__``.  ``to_schema`` then builds a Pydantic
    payload populated from instance attributes plus an ``href`` field
    resolved against the active request's URL space.
    """

    __abstract__ = True
    __id_field__: ClassVar[str | tuple[str, ...]] = "id"
    __schema_cls__: ClassVar[type[BaseModel]]
    __detail_operation_id__: ClassVar[str]
    __list_operation_id__: ClassVar[str]

    @classmethod
    def id_fields(cls) -> tuple[str, ...]:
        """Normalize ``__id_field__`` to a tuple of column names."""
        if isinstance(cls.__id_field__, tuple):
            return cls.__id_field__
        return (cls.__id_field__,)

    @classmethod
    def get_or_404(cls, session: Session, entity_id: IdType) -> Self:
        """Return one row by primary key or raise an HTTP 404."""
        entity = session.get(cls, entity_id)
        if entity is None:
            raise HTTPException(HTTPStatus.NOT_FOUND, f"{cls.__name__} not found")
        return entity

    @classmethod
    def validate_query_params(cls, request: Request) -> None:
        """Reject any query param that isn't a meta key or a known field alias."""
        allowed = META_QUERY_PARAMS | cls.field_alias_map().keys()
        for key in request.query_params:
            if key not in allowed:
                allowed_text = ", ".join(sorted(allowed))
                raise HTTPException(
                    HTTPStatus.BAD_REQUEST,
                    f"'{key}' is not a valid query parameter. Allowed parameters: {allowed_text}.",
                )

    @classmethod
    def field_alias_map(cls) -> dict[str, str]:
        """Map both camelCase aliases and snake names back to snake fields.

        Filter columns share aliases with the response schema, so the
        Pydantic schema's ``model_fields`` is the single source of truth
        for what's projectable, sortable, and filterable.  ``href`` is
        a synthetic field and is not exposed for filtering or sorting.
        """
        schema_cls = cls.__schema_cls__
        out: dict[str, str] = {}
        for field_name, field_info in schema_cls.model_fields.items():
            if field_name == "href":
                continue
            out[field_name] = field_name
            if field_info.alias:
                out[field_info.alias] = field_name
        return out

    @classmethod
    def resolve_field(cls, raw_field: str, kind: str) -> str:
        """Translate a wire-side field name to a snake-case attribute.

        Raises a 400 problem-details ``HTTPException`` if the field is
        unknown.  *kind* is one of ``"filter"``, ``"sort"``, or
        ``"fields"`` and is used in the error message so callers see
        which directive failed.
        """
        snake = cls.field_alias_map().get(raw_field)
        if snake is None:
            allowed_text = ", ".join(sorted(cls.field_alias_map()))
            raise HTTPException(
                HTTPStatus.BAD_REQUEST,
                f"Cannot use '{raw_field}' for {kind}. Available fields: {allowed_text}.",
            )
        return snake

    @classmethod
    def apply_filter_op(
        cls, stmt: Select, column: Any, op: FilterOperator, value: str | list[str]
    ) -> Select:
        """Translate one parsed filter into a SQLAlchemy ``WHERE`` clause."""
        clause = filter_clause(column, op, value)
        return stmt.where(clause)

    @classmethod
    def apply_filters(cls, stmt: Select, filters: dict[str, str | None]) -> Select:
        """Layer ``WHERE`` clauses for every non-``None`` raw filter value."""
        for snake_field, raw_value in filters.items():
            if raw_value is None:
                continue
            column = getattr(cls, snake_field, None)
            if column is None:
                allowed_text = ", ".join(sorted(cls.field_alias_map()))
                raise HTTPException(
                    HTTPStatus.BAD_REQUEST,
                    f"Cannot filter by '{snake_field}'. Available fields: {allowed_text}.",
                )
            op, value = parse_filter_value(raw_value)
            stmt = cls.apply_filter_op(stmt, column, op, value)
        return stmt

    @classmethod
    def apply_sort(cls, stmt: Select, sort_raw: str | None) -> Select:
        """Apply ``_sort`` directives, validating fields against the schema.

        Always appends a stable tiebreaker on ``__id_field__`` so OFFSET
        pagination returns deterministic windows even when the explicit
        sort key has duplicates.
        """
        if sort_raw:
            for raw_field, ascending in parse_sort_directive(sort_raw):
                snake = cls.resolve_field(raw_field, "sort")
                column = getattr(cls, snake)
                stmt = stmt.order_by(column.asc() if ascending else column.desc())
        for id_field in cls.id_fields():
            stmt = stmt.order_by(getattr(cls, id_field).asc())
        return stmt

    @classmethod
    def list_query(
        cls,
        session: Session,
        *,
        offset: int = 0,
        limit: int = 50,
        filters: dict[str, str | None] | None = None,
        sort: str | None = None,
    ) -> tuple[list[Self], int]:
        """Return ``(rows, total)`` in one round-trip via ``COUNT(*) OVER ()``."""
        total_col = func.count().over().label("total_count")
        stmt: Select = select(cls, total_col)
        if filters:
            stmt = cls.apply_filters(stmt, filters)
        stmt = cls.apply_sort(stmt, sort).offset(offset).limit(limit)
        rows = session.execute(stmt).all()
        if rows:
            entities = [row[0] for row in rows]
            return entities, int(rows[0][1])
        count_stmt: Select = select(func.count()).select_from(cls)
        if filters:
            count_stmt = cls.apply_filters(count_stmt, filters)
        total = int(session.execute(count_stmt).scalar_one())
        return [], total

    def to_schema(self, request: Request) -> BaseModel:
        """Project this row into its Pydantic schema, resolving ``href``."""
        schema_cls = type(self).__schema_cls__
        id_fields = type(self).id_fields()
        if id_fields:
            operation_id = type(self).__detail_operation_id__
            id_kwargs: dict[str, Any] = {field: getattr(self, field) for field in id_fields}
            href = str(request.url_for(operation_id, **id_kwargs))
        else:
            href = str(request.url_for(type(self).__list_operation_id__))
        payload: dict[str, Any] = {
            field: getattr(self, field) for field in schema_cls.model_fields if field != "href"
        }
        payload["href"] = href
        return schema_cls.model_validate(payload)

    def project_row(self, request: Request, fields: frozenset[str]) -> dict[str, Any]:
        """Return the row as a sparse dict scoped to *fields* + ``href``."""
        cls = type(self)
        full = self.to_schema(request)
        if not fields:
            keep = set(cls.id_fields())
        else:
            keep = {cls.resolve_field(token, "fields") for token in fields}
        keep.add("href")
        return full.model_dump(mode="json", by_alias=True, include=keep)
