"""ETag / Cache-Control / Last-Modified handling for detail endpoints.

The detail handler computes a weak ETag from the contract version + a
stable hash of the rendered payload, optionally pairs it with an
RFC 8594 IMF-fixdate ``Last-Modified``, and short-circuits to 304 when
the request's ``If-None-Match`` or ``If-Modified-Since`` validators
match.
"""

from __future__ import annotations

import hashlib
import json
from datetime import UTC, date, datetime, time
from email.utils import format_datetime, parsedate_to_datetime
from http import HTTPStatus
from typing import Any

from fastapi import Request, Response
from pydantic import BaseModel

ETAG_HEADER = "ETag"
CACHE_CONTROL_HEADER = "Cache-Control"
LAST_MODIFIED_HEADER = "Last-Modified"
IF_NONE_MATCH_HEADER = "If-None-Match"
IF_MODIFIED_SINCE_HEADER = "If-Modified-Since"
LIST_CACHE_CONTROL = "no-store"


def format_imf_fixdate(date_str: str) -> str:
    """Render ``YYYY-MM-DD`` as an RFC 8594 / 7231 IMF-fixdate.

    The ``Sunset`` header pins to end-of-day UTC (23:59:59) so a
    consumer treating it as a hard cutoff has the full final day.
    """
    parsed = datetime.strptime(date_str, "%Y-%m-%d").replace(tzinfo=UTC).date()
    end_of_day = datetime.combine(parsed, time(23, 59, 59), tzinfo=UTC)
    return format_datetime(end_of_day, usegmt=True)


def compute_etag(contract_version: str, payload: dict[str, Any]) -> str:
    """Build a weak ETag from the contract version + a stable payload hash.

    Pydantic JSON serialisation order is not bytewise stable across Python
    versions, so we render with ``sort_keys=True`` and stamp the result as a
    weak validator (``W/"..."``).  ``default=str`` covers ``datetime`` /
    ``UUID`` / ``Decimal`` payload values that ``json.dumps`` would otherwise
    refuse.
    """
    canonical = json.dumps(payload, sort_keys=True, default=str).encode("utf-8")
    digest = hashlib.sha256(canonical).hexdigest()[:16]
    return f'W/"{contract_version}-{digest}"'


def latency_imf_fixdate(value: Any) -> str | None:
    """Render a row's latency column value as an IMF-fixdate, or ``None``.

    Naive datetimes are assumed to be UTC since SLA timestamps are stored
    in a single timezone per the contract design. Aware datetimes in any
    other zone (e.g. Postgres ``timestamptz`` returned in the session's
    local zone) are converted to UTC. ``date`` values pin to midnight UTC.
    Anything else (string columns, ``None``) returns ``None`` so the
    handler omits the ``Last-Modified`` header.
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        timestamp = value.replace(tzinfo=UTC) if value.tzinfo is None else value.astimezone(UTC)
    elif isinstance(value, date):
        timestamp = datetime.combine(value, time(0, 0, 0), tzinfo=UTC)
    else:
        return None
    return format_datetime(timestamp, usegmt=True)


def parse_http_date(raw: str) -> datetime | None:
    """Parse an HTTP-date header into a UTC datetime, or ``None`` on error."""
    try:
        parsed = parsedate_to_datetime(raw)
    except (TypeError, ValueError):
        return None
    return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=UTC)


def not_modified_response(etag: str, cache_control: str, last_modified: str | None) -> Response:
    """Build the empty-body 304 echoing the validators we already computed."""
    headers = {ETAG_HEADER: etag, CACHE_CONTROL_HEADER: cache_control}
    if last_modified is not None:
        headers[LAST_MODIFIED_HEADER] = last_modified
    return Response(status_code=HTTPStatus.NOT_MODIFIED, headers=headers)


def apply_detail_caching(
    response: Response,
    *,
    request: Request,
    payload: BaseModel,
    contract_version: str,
    cache_control: str,
    last_modified: str | None = None,
) -> Response | None:
    """Stamp ETag/Cache-Control/Last-Modified, return 304 on validator match.

    Returns the 304 ``Response`` when ``If-None-Match`` matches the freshly
    computed ETag or ``If-Modified-Since`` is at-or-after the row's
    ``Last-Modified``; the caller hands that response back to FastAPI
    verbatim.  Returns ``None`` to mean "keep the body you were going to
    return" — the headers we set on *response* still propagate because
    FastAPI merges the dependency-injected response with the handler's
    payload.
    """
    payload_dict = payload.model_dump(mode="json", by_alias=True)
    etag = compute_etag(contract_version, payload_dict)
    response.headers[ETAG_HEADER] = etag
    response.headers[CACHE_CONTROL_HEADER] = cache_control
    if last_modified is not None:
        response.headers[LAST_MODIFIED_HEADER] = last_modified

    if request.headers.get(IF_NONE_MATCH_HEADER) == etag:
        return not_modified_response(etag, cache_control, last_modified)

    if last_modified is not None:
        ims_raw = request.headers.get(IF_MODIFIED_SINCE_HEADER)
        if ims_raw is not None:
            ims = parse_http_date(ims_raw)
            origin = parse_http_date(last_modified)
            if ims is not None and origin is not None and ims >= origin:
                return not_modified_response(etag, cache_control, last_modified)
    return None
