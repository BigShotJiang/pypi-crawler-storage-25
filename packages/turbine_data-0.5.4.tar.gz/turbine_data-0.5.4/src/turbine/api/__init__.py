"""Public runtime helpers consumed by Turbine-generated FastAPI packages.

Generated routers, models, and the mount module import from
``turbine.api.runtime`` directly; the user's project carries no copy of
this code. Splitting by concern (errors, pagination, caching, status,
observability, rate limiting, openapi filtering) lets users opt out of
features by simply not wiring the corresponding ``register_*`` helper.
"""
