"""Git adapter — load contract files from git refs."""

from .loader import SubprocessGitLoader
from .previous_version import GitPreviousVersionReader

__all__ = ["GitPreviousVersionReader", "SubprocessGitLoader"]
