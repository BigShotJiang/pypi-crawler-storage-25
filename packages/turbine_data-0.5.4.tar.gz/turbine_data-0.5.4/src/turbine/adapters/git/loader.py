"""SubprocessGitLoader — load contract files from a git ref via subprocess."""

import subprocess
from pathlib import Path

YAML_SUFFIXES = {".yml", ".yaml"}


class SubprocessGitLoader:
    """Loads contract files from a git ref using git ls-tree and git show."""

    def __init__(self, repo_root: Path) -> None:
        """Store the repository root for subprocess cwd."""
        self.repo_root = repo_root

    def discover(
        self, ref: str, contracts_dir: Path, extra_dirs: tuple[Path, ...] = ()
    ) -> tuple[Path, ...]:
        """List YAML contract files at a git ref across one or more directories."""
        all_dirs = (contracts_dir, *extra_dirs)
        paths: list[Path] = []
        for search_dir in all_dirs:
            paths.extend(self._ls_tree(ref, search_dir))
        return tuple(paths)

    def read(self, ref: str, path: Path) -> str:
        """Read file content at a git ref. Raises FileNotFoundError if not found."""
        result = subprocess.run(
            ["git", "show", f"{ref}:{path}"],  # noqa: S607
            cwd=self.repo_root,
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            msg = f"file not found at {ref}:{path}"
            raise FileNotFoundError(msg)
        return result.stdout

    def _ls_tree(self, ref: str, directory: Path) -> list[Path]:
        """List files under a directory at a git ref, filtering for YAML."""
        result = subprocess.run(
            ["git", "ls-tree", "-r", "--name-only", ref, str(directory)],  # noqa: S607
            cwd=self.repo_root,
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            return []
        return [
            Path(line)
            for line in result.stdout.strip().splitlines()
            if Path(line).suffix in YAML_SUFFIXES
        ]
