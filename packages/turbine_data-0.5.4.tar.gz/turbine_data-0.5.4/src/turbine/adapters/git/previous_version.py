"""GitPreviousVersionReader — read a contract's committed text via ``git show``."""

import subprocess
from pathlib import Path

from turbine.core.contract.ports import PreviousVersionReader


class GitPreviousVersionReader(PreviousVersionReader):
    """Read the committed contents of a file at a git ref, or None if unavailable.

    Probes the workspace once at construction with ``git rev-parse
    --is-inside-work-tree``. A non-git workspace short-circuits every
    ``read()`` to None. ``git show <ref>:<path>`` runs with ``check=False`` so
    a missing path or unknown ref yields None rather than an exception.
    """

    def __init__(self, repo_root: Path) -> None:
        """Probe whether *repo_root* is inside a git work tree and cache the answer."""
        self.repo_root = repo_root
        self.is_git_workspace = probe_git_workspace(repo_root)

    def read(self, path: Path, ref: str = "HEAD") -> str | None:
        """Return *path*'s text at *ref*, or None when not in git, missing, or outside repo."""
        if not self.is_git_workspace:
            return None
        relative = relative_to_repo(path, self.repo_root)
        if relative is None:
            return None
        result = subprocess.run(
            ["git", "show", f"{ref}:{relative}"],  # noqa: S607
            cwd=self.repo_root,
            capture_output=True,
            text=True,
            check=False,
        )
        if result.returncode != 0:
            return None
        return result.stdout

    def ref_exists(self, ref: str) -> bool:
        """Return True when git can find *ref* in this workspace."""
        if not self.is_git_workspace:
            return False
        result = subprocess.run(
            ["git", "rev-parse", "--verify", f"{ref}^{{tree}}"],  # noqa: S607
            cwd=self.repo_root,
            capture_output=True,
            text=True,
            check=False,
        )
        return result.returncode == 0


def probe_git_workspace(repo_root: Path) -> bool:
    """Return True when *repo_root* lies inside a git work tree."""
    if not repo_root.exists():
        return False
    result = subprocess.run(
        ["git", "rev-parse", "--is-inside-work-tree"],  # noqa: S607
        cwd=repo_root,
        capture_output=True,
        text=True,
        check=False,
    )
    return result.returncode == 0 and result.stdout.strip() == "true"


def relative_to_repo(path: Path, repo_root: Path) -> Path | None:
    """Return *path* expressed as a repo-relative path, or None when outside the repo."""
    resolved_path = path.resolve()
    resolved_root = repo_root.resolve()
    try:
        return resolved_path.relative_to(resolved_root)
    except ValueError:
        return None
