"""Indexing adapter — in-memory project index for contract lookup."""

from .project_index import InMemoryProjectIndex

__all__ = ["InMemoryProjectIndex"]
