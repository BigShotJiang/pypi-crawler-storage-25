"""In-memory project index — stores contracts for fast lookup by ID or table."""

import itertools
from collections import defaultdict
from collections.abc import Iterable
from dataclasses import dataclass, field
from typing import Self

from turbine.core.common import DatasetSpec, LocationInfo, SymbolKind, WorkspaceSymbolInfo

index_generation = itertools.count()
"""Process-wide monotonic source for :attr:`InMemoryProjectIndex.revision`.

Every constructed index draws the next value, so two indexes are never
confused even when the old one is garbage-collected and the allocator reuses
its address. ``itertools.count().__next__`` is atomic under the GIL, so the
worker thread (live rebuilds) and the main loop (cold-start rebuild, ``empty``)
can both draw from it without a lock.
"""


@dataclass(frozen=True, slots=True)
class InMemoryProjectIndex:
    """Immutable, pre-computed lookup structure over all contracts in a project.

    Built once from a flat iterable of ``DatasetSpec`` objects, then queried
    repeatedly by the analysis layer for hover info, go-to-definition,
    completions, and cross-contract references.

    All internal dictionaries are built eagerly at construction time so every
    lookup is O(1).

    Attributes:
        stored_contracts: All contracts in insertion order.
        by_id: Contract lookup by ``contract_id`` preserving duplicate ids.
        by_target_contract: Quality specs grouped by the ``target_contract``
            they reference.
        stored_quality_specs: Subset of contracts that have a ``target_contract``
            set (i.e. quality specs).
        revision: Unique, monotonically increasing identity stamped at
            construction. The diagnostic lint cache keys on this so a rebuilt
            index reliably invalidates cached entries, even when the old index
            object's address is recycled. Excluded from equality and hashing —
            two indexes with identical contents stay equal.

    Example::

        index = InMemoryProjectIndex.from_contracts(parsed_specs)
        spec = index.find_contract("orders")
    """

    stored_contracts: tuple[DatasetSpec, ...]
    by_id: dict[str, tuple[DatasetSpec, ...]]
    by_target_contract: dict[str, tuple[DatasetSpec, ...]]
    stored_quality_specs: tuple[DatasetSpec, ...]
    revision: int = field(default_factory=lambda: next(index_generation), compare=False)

    @classmethod
    def from_contracts(cls, contracts: Iterable[DatasetSpec]) -> Self:
        """Build an index from an iterable of contracts.

        Iterates *contracts* exactly once, grouping them by table and by
        ``target_contract`` for O(1) lookups later.

        Args:
            contracts: Parsed contract specs (will be fully materialized into
                a tuple).

        Returns:
            A fully populated ``InMemoryProjectIndex``.

        Example::

            index = InMemoryProjectIndex.from_contracts(load_all_specs(root))
        """
        materialized = tuple(contracts)
        id_groups: dict[str, list[DatasetSpec]] = defaultdict(list)
        target_groups: dict[str, list[DatasetSpec]] = defaultdict(list)
        quality: list[DatasetSpec] = []
        for spec in materialized:
            id_groups[spec.metadata.contract_id].append(spec)
            if spec.target_contract is not None:
                target_groups[spec.target_contract].append(spec)
                quality.append(spec)
        return cls(
            stored_contracts=materialized,
            by_id={key: tuple(value) for key, value in id_groups.items()},
            by_target_contract={key: tuple(value) for key, value in target_groups.items()},
            stored_quality_specs=tuple(quality),
        )

    @classmethod
    def empty(cls) -> Self:
        """Create an index with no contracts, useful as a default or in tests.

        Returns:
            An ``InMemoryProjectIndex`` where every collection is empty.
        """
        return cls(stored_contracts=(), by_id={}, by_target_contract={}, stored_quality_specs=())

    def contracts(self) -> tuple[DatasetSpec, ...]:
        """Return all indexed contracts in their original insertion order.

        Returns:
            Tuple of every ``DatasetSpec`` that was passed to ``from_contracts``.
        """
        return self.stored_contracts

    def find_contract(self, contract_id: str) -> DatasetSpec | None:
        """Look up a representative contract by ID.

        Multi-schema DataContracts share one contract id, so callers that need a
        specific schema should scan ``contracts()`` and select by table instead.

        Args:
            contract_id: The ``contract_id`` value to search for.

        Returns:
            The first matching ``DatasetSpec``, or ``None`` if no contract has that ID.
        """
        matches = self.by_id.get(contract_id, ())
        return matches[0] if matches else None

    def find_specs_for_contract(self, contract_id: str) -> tuple[DatasetSpec, ...]:
        """Find quality specs that reference a contract via ``target_contract``.

        Args:
            contract_id: The ``contract_id`` of the base contract.

        Returns:
            Tuple of quality specs pointing at *contract_id*; empty tuple if
            none exist.
        """
        return self.by_target_contract.get(contract_id, ())

    def quality_specs(self) -> tuple[DatasetSpec, ...]:
        """Return all specs that have a ``target_contract`` set.

        Returns:
            Tuple of quality-type specs across the entire project.
        """
        return self.stored_quality_specs

    def search_symbols(self, query: str) -> tuple[WorkspaceSymbolInfo, ...]:
        """Search contracts, schemas, and quality specs by case-insensitive substring match."""
        symbols: list[WorkspaceSymbolInfo] = []
        for spec in self.stored_contracts:
            if spec.target_contract is not None:
                continue  # quality specs handled below
            contract_id = spec.metadata.contract_id
            uri = spec.metadata.source_path.as_uri()
            symbols.append(WorkspaceSymbolInfo(name=contract_id, kind=SymbolKind.CONTRACT, uri=uri))
            symbols.append(
                WorkspaceSymbolInfo(
                    name=str(spec.table), kind=SymbolKind.SCHEMA, uri=uri, container_name=contract_id
                )
            )
        symbols.extend(
            WorkspaceSymbolInfo(
                name=spec.metadata.contract_id,
                kind=SymbolKind.CONTRACT,
                uri=spec.metadata.source_path.as_uri(),
            )
            for spec in self.stored_quality_specs
        )
        if not query:
            return tuple(symbols)
        needle = query.lower()
        return tuple(sym for sym in symbols if needle in sym.name.lower())

    def find_contract_id_locations(self, word: str) -> tuple[LocationInfo, ...]:
        """Find quality specs whose target_contract matches *word*."""
        return tuple(
            LocationInfo(uri=spec.metadata.source_path.as_uri())
            for spec in self.find_specs_for_contract(word)
        )

    def find_table_locations(self, word: str) -> tuple[LocationInfo, ...]:
        """Find contracts whose table name matches *word*."""
        return tuple(
            LocationInfo(uri=spec.metadata.source_path.as_uri())
            for spec in self.stored_contracts
            if str(spec.table) == word
        )

    def resolve_contract_link(self, contract_id: str) -> str | None:
        """Return the file URI for a contract, or None if not found."""
        contract = self.find_contract(contract_id)
        if contract is None:
            return None
        return contract.metadata.source_path.as_uri()

    def contract_id_for(self, uri: str) -> str | None:
        """Reverse-lookup a contract id from its source URI."""
        return next(
            (
                spec.metadata.contract_id
                for spec in self.stored_contracts
                if spec.metadata.source_path.as_uri() == uri
            ),
            None,
        )
