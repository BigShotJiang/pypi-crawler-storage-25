"""Ruamel-backed implementation of the onboarding YamlParser port."""

from __future__ import annotations

from dataclasses import dataclass
from io import StringIO

from ruamel.yaml import YAML, YAMLError

from turbine.core.onboarding.ports import YamlParser


@dataclass(frozen=True, slots=True)
class RuamelYamlParser(YamlParser):
    """YAML parser that swallows parse errors by returning None."""

    def parse(self, text: str) -> object | None:
        try:
            return YAML(typ="safe").load(StringIO(text))
        except YAMLError:
            return None
