"""In-memory ActionInvokedStream adapter — fans out kinds to current subscribers."""

from __future__ import annotations

from collections.abc import Callable

from turbine.core.building_blocks.onboarding_actions import StepActionKind
from turbine.core.onboarding.ports import ActionInvokedStream


class InMemoryActionInvokedStream(ActionInvokedStream):
    """Single-process pub/sub for action invocations.

    Subscribers are notified synchronously in registration order. The stream
    is mutated only from `tour_service`, which itself runs on the LSP main
    loop, so no locking is required.
    """

    def __init__(self) -> None:
        self.subscribers: list[Callable[[StepActionKind], None]] = []

    def publish(self, kind: StepActionKind) -> None:
        for handler in list(self.subscribers):
            handler(kind)

    def subscribe(self, handler: Callable[[StepActionKind], None]) -> Callable[[], None]:
        # Idempotent: a double-subscribe leaks a handler whose unsubscribe()
        # only removes the first occurrence. Reject duplicates instead.
        if handler not in self.subscribers:
            self.subscribers.append(handler)

        def unsubscribe() -> None:
            if handler in self.subscribers:
                self.subscribers.remove(handler)

        return unsubscribe
