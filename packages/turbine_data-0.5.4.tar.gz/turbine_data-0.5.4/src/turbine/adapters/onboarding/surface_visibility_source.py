"""In-memory SurfaceVisibilitySource adapter — single-writer state per surface."""

from __future__ import annotations

from turbine.core.onboarding.ports import SurfaceVisibilitySource


class InMemorySurfaceVisibilitySource(SurfaceVisibilitySource):
    """Single-process map of surface_id -> visible bool.

    The editor (via the LSP ``surfaceVisibilityChanged`` request) is the
    sole writer; ``SurfaceVisible`` watchers are the readers. Reads and
    writes are routed through ``tour_service`` on the main loop, so no
    locking is required.

    A surface not yet reported is treated as hidden — a fresh server has
    no way to know the editor's current state, and watchers should arm
    gated rather than firing on default-true.
    """

    def __init__(self) -> None:
        self.visible_by_surface: dict[str, bool] = {}

    def is_visible(self, surface_id: str) -> bool:
        return self.visible_by_surface.get(surface_id, False)

    def set_visible(self, surface_id: str, *, visible: bool) -> None:
        self.visible_by_surface[surface_id] = visible
