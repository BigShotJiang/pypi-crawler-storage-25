"""DiagnosticSource adapter backed by the LSP client's in-memory diagnostic cache."""

from __future__ import annotations

from collections.abc import Callable, Iterable
from pathlib import Path


class LspDiagnosticSource:
    """Implements ``DiagnosticSource`` against the LSP client's diagnostic cache.

    ``iter_diagnostics_for`` returns whatever records the cache is holding
    for a given URI; the adapter stringifies each record's ``id`` attribute
    and compares it against the requested code.
    """

    def __init__(
        self, *, iter_diagnostics_for: Callable[[str], Iterable[object]], tour_root: Path
    ) -> None:
        self.iter_diagnostics_for = iter_diagnostics_for
        self.tour_root = tour_root

    def has_diagnostic(self, file: str, code: str) -> bool:
        uri = (self.tour_root / file).as_uri()
        return any(str(getattr(diag, "id", "")) == code for diag in self.iter_diagnostics_for(uri))
