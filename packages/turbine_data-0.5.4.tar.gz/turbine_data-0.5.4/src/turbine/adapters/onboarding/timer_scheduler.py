"""threading.Timer-based Scheduler with cancel-and-replace semantics."""

from __future__ import annotations

import threading
from collections.abc import Callable

from turbine.core.onboarding.ports import Scheduler


class TimerScheduler(Scheduler):
    """Debounce scheduler backed by threading.Timer.

    Each ``schedule()`` call cancels any pending timer and starts a fresh one.
    """

    def __init__(self) -> None:
        self.pending: threading.Timer | None = None
        self.lock = threading.Lock()

    def schedule(self, delay_ms: int, callback: Callable[[], None]) -> None:
        with self.lock:
            if self.pending is not None:
                self.pending.cancel()
            timer = threading.Timer(delay_ms / 1000.0, callback)
            timer.daemon = True
            timer.start()
            self.pending = timer

    def cancel(self) -> None:
        with self.lock:
            if self.pending is not None:
                self.pending.cancel()
                self.pending = None
