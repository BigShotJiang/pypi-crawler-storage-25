"""IntrospectionSource adapter backed by the LSP state manager's cache.

Takes a callable that answers the ``has_known_tables`` question so the
adapter stays decoupled from ``IntrospectionCache`` and the tach boundary
between adapters and core.common is respected.
"""

from __future__ import annotations

from collections.abc import Callable

from turbine.core.onboarding.ports import IntrospectionSource


class LspIntrospectionSource(IntrospectionSource):
    """Implements ``IntrospectionSource`` by delegating to a provided callable."""

    def __init__(self, has_known_tables: Callable[[], bool]) -> None:
        self.check = has_known_tables

    def has_known_tables(self) -> bool:
        return self.check()
