"""Discover user @page-decorated functions from a filesystem directory."""

from __future__ import annotations

import importlib.util
import inspect
from collections.abc import Callable
from pathlib import Path

from loguru import logger

from turbine.adapters.dashboard.discovery_helpers import should_skip
from turbine.core.dashboard.components.layout import Page
from turbine.core.dashboard.models import get_page_meta


def load_page_module(py_file: Path) -> object | None:
    """Import a .py file as a module. Returns None on any load failure."""
    module_name = f"turbine_dashboard_pages.{py_file.stem}"
    spec = importlib.util.spec_from_file_location(module_name, py_file)
    if spec is None or spec.loader is None:
        return None
    mod = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(mod)
    except (ImportError, SyntaxError, RuntimeError):
        logger.warning("Failed to load page file: %s", py_file)
        return None
    return mod


def discover_pages(pages_dir: Path) -> list[Callable[..., Page]]:
    """Recursively scan a directory for .py files and collect all @page-decorated functions."""
    if not pages_dir.is_dir():
        return []

    pages: list[Callable[..., Page]] = []
    for py_file in sorted(pages_dir.rglob("*.py")):
        if should_skip(py_file, pages_dir):
            continue
        mod = load_page_module(py_file)
        if mod is None:
            continue
        pages.extend(
            member
            for _, member in inspect.getmembers(mod, inspect.isfunction)
            if hasattr(member, "page_meta")
        )

    pages.sort(key=lambda fn: get_page_meta(fn).order)
    return pages
