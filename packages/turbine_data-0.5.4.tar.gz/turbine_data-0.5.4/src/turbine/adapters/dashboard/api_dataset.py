from __future__ import annotations

from functools import cached_property
from typing import Any

import httpx
from pydantic import BaseModel

from turbine.core.dashboard.dataset import RowFlags
from turbine.core.dashboard.in_memory_dataset import InMemoryDataset

FLAG_METADATA_COLUMNS = frozenset(
    {"failing_checks", "failing_check_count", "last_flagged_at", "last_tested_at", "is_flagged"}
)


class FlaggedRowsResponse(BaseModel):
    """API response envelope for /flagged-rows/{table}."""

    rows: list[dict[str, Any]] = []

    def data_rows(self) -> tuple[dict[str, Any], ...]:
        """Strip quality metadata columns from each row."""
        return tuple(
            {key: value for key, value in raw.items() if not is_flag_metadata_column(key)}
            for raw in self.rows
        )

    def flags(self) -> tuple[RowFlags, ...]:
        """Extract per-row RowFlags from quality metadata columns."""
        return tuple(RowFlags.from_raw_row(raw) for raw in self.rows)


def is_flag_metadata_column(column: str) -> bool:
    """Return True when *column* belongs to Turbine flag metadata, not source data."""
    return column in FLAG_METADATA_COLUMNS


def table_name_from_model(model: type[BaseModel]) -> str:
    """Derive the API table path from a codegen'd model class.

    Checks ``__schema__`` first (new codegen), falls back to
    ``__table_args__["schema"]`` (SQLModel compat).
    """
    table = getattr(model, "__tablename__", None)
    if table is None:
        msg = f"No __tablename__ on {model.__name__}"
        raise ValueError(msg)
    schema = getattr(model, "__schema__", None)
    if schema is None:
        table_args = getattr(model, "__table_args__", {})
        schema = table_args.get("schema") if isinstance(table_args, dict) else None
    if schema:
        return f"{schema}.{table}"
    return table


class ApiDataset[M: BaseModel](InMemoryDataset[M]):
    """Lazy ``InMemoryDataset`` that fetches from /flagged-rows/{table} on first access.

    Inherits every aggregation/finder method from ``InMemoryDataset``. Storage
    (``stored_rows``, ``stored_flags``) is overridden as ``cached_property`` so
    the HTTP call only happens on first access of any row-touching attribute.
    """

    def __init__(
        self,
        model: type[M],
        base_url: str,
        client: httpx.Client,
        picker_value: dict[str, str] | None = None,
    ) -> None:
        self.model_class = model
        self.base_url = base_url
        self.client = client
        self.stored_picker_value: dict[str, str] = picker_value if picker_value is not None else {}
        self.base_dataset: InMemoryDataset[M] | None = None

    @property
    def model(self) -> type[M] | None:
        """Override: ApiDataset knows its model type without forcing a fetch."""
        return self.model_class

    @cached_property
    def payload(self) -> tuple[tuple[M, ...], tuple[RowFlags, ...]]:
        """Fetch and parse the flagged rows. Called once, cached forever."""
        table = table_name_from_model(self.model_class)
        url = f"{self.base_url}/api/v1/manage/flagged-rows/{table}"
        response = self.client.get(url)
        response.raise_for_status()
        envelope = FlaggedRowsResponse.model_validate(response.json())
        rows = self.parse_rows(envelope.rows)
        flags = envelope.flags()
        return rows, flags

    @cached_property
    def stored_rows(self) -> tuple[M, ...]:
        return self.payload[0]

    @cached_property
    def stored_flags(self) -> tuple[RowFlags, ...]:
        return self.payload[1]

    def parse_rows(self, raw_rows: list[dict[str, Any]]) -> tuple[M, ...]:
        """Parse raw dicts into model instances, stripping flag columns."""
        model_fields = set(self.model_class.__annotations__)
        return tuple(
            self.model_class(**{key: val for key, val in raw.items() if key in model_fields})
            for raw in raw_rows
        )

    def with_picker_value(self, picker_value: dict[str, str]) -> ApiDataset[M]:
        """Return a new ApiDataset carrying ``picker_value``; preserves model + client."""
        return ApiDataset(
            model=self.model_class, base_url=self.base_url, client=self.client, picker_value=picker_value
        )
