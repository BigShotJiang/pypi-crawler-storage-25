"""Auto-import user @component classes from a dashboard/components/ folder."""

from __future__ import annotations

import importlib
from pathlib import Path

from loguru import logger

from .discovery_helpers import should_skip


def auto_import_components(components_dir: Path, project_root: Path) -> None:
    """Recursively import every .py file under components_dir.

    Each file is imported via its dotted package name (derived from its path
    relative to project_root), triggering any `@component` registration side
    effects. Relies on project_root already being on `sys.path`. Individual
    file failures are logged and skipped so one bad component cannot block
    the rest.
    """
    if not components_dir.is_dir():
        return

    for py_file in sorted(components_dir.rglob("*.py")):
        if should_skip(py_file, components_dir):
            continue
        module_name = dotted_module_name(py_file, project_root)
        try:
            importlib.import_module(module_name)
        except (ImportError, SyntaxError, RuntimeError) as exc:
            logger.warning("Failed to auto-import component module {}: {}", module_name, exc)


def dotted_module_name(py_file: Path, project_root: Path) -> str:
    """Convert `<project_root>/dashboard/components/a/b.py` to `dashboard.components.a.b`."""
    relative = py_file.relative_to(project_root).with_suffix("")
    return ".".join(relative.parts)
