"""Shared helpers for discovering user files under a `dashboard/` folder."""

from __future__ import annotations

from pathlib import Path


def should_skip(py_file: Path, root_dir: Path) -> bool:
    """Skip dunder files and files inside dunder directories."""
    if py_file.name.startswith("__"):
        return True
    return any(part.startswith("__") for part in py_file.relative_to(root_dir).parts)
