"""Import a user-defined `dashboard/backend.py` and call its `backend()` factory."""

from __future__ import annotations

import importlib.util
from pathlib import Path

from turbine.core.dashboard.query import QueryDispatcher


def load_backend_py(backend_py: Path) -> QueryDispatcher:
    """Import `dashboard/backend.py` and call its zero-arg `backend()` function.

    Raises TypeError if `backend()` is missing or returns something that
    isn't a QueryDispatcher (checked structurally for an `execute` method).
    Errors raised *inside* the user module (import errors, runtime errors
    from `backend()`) propagate unchanged.
    """
    spec = importlib.util.spec_from_file_location("turbine_dashboard_backend", backend_py)
    if spec is None or spec.loader is None:
        msg = f"Could not load {backend_py}"
        raise ImportError(msg)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    contract_msg = f"{backend_py} must define a backend() -> QueryDispatcher function"
    backend_fn = getattr(module, "backend", None)
    if not callable(backend_fn):
        raise TypeError(contract_msg)

    dispatcher = backend_fn()
    if not callable(getattr(dispatcher, "execute", None)):
        raise TypeError(contract_msg)
    return dispatcher
