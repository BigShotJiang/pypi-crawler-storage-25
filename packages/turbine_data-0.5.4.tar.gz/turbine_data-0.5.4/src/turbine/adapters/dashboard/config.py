"""Read dashboard configuration from pyproject.toml."""

from __future__ import annotations

import tomllib
from pathlib import Path
from types import MappingProxyType

from pydantic import AliasPath, BaseModel, ConfigDict, Field

DEFAULT_THEME: MappingProxyType[str, str] = MappingProxyType(
    {
        "base": "dark",
        "primaryColor": "#4C90FC",
        "backgroundColor": "#05091D",
        "secondaryBackgroundColor": "#0D1428",
        "textColor": "#E2E4EA",
        "font": "sans serif",
    }
)


class DashboardConfig(BaseModel):
    """Dashboard configuration parsed from [tool.turbine.dashboard]."""

    model_config = ConfigDict(frozen=True, extra="ignore", populate_by_name=True)

    folder: str = Field(
        default="dashboard", validation_alias=AliasPath("tool", "turbine", "dashboard", "folder")
    )
    theme_overrides: dict[str, str] = Field(
        default_factory=dict, validation_alias=AliasPath("tool", "turbine", "dashboard", "theme")
    )

    def theme(self) -> dict[str, str]:
        """Return the merged theme: bundled defaults overridden by user pyproject values."""
        merged = dict(DEFAULT_THEME)
        for key, value in self.theme_overrides.items():
            merged[key] = str(value)
        return merged


def load_dashboard_config(pyproject_path: Path | None = None) -> DashboardConfig:
    """Load dashboard config from pyproject.toml. Returns defaults if not found."""
    path = pyproject_path or Path("pyproject.toml")
    if not path.exists():
        return DashboardConfig()
    with path.open("rb") as fh:
        return DashboardConfig.model_validate(tomllib.load(fh))
