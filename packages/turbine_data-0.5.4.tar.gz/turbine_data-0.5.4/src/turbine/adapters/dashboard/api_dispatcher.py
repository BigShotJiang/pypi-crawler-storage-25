from __future__ import annotations

from functools import singledispatchmethod
from typing import Any

import httpx

from turbine.adapters.dashboard.api_models import (
    CheckCountersApiResponse,
    DimensionScoreResponse,
    FlaggedTablesApiResponse,
)
from turbine.core.common.quality_dimension import QualityDimension
from turbine.core.dashboard.query import (
    AlertEntry,
    AlertList,
    ChainSpec,
    CheckCounters,
    ContractList,
    ContractSummaryData,
    DimensionScores,
    FlaggedTables,
    Resource,
    VerificationRuns,
    VerificationRunSummary,
)
from turbine.core.quality import CheckCounters as CheckCountersData
from turbine.core.quality.check_results import DimensionScore


class ApiQueryDispatcher:
    """Map dashboard Resource queries to turbine serve REST API calls."""

    def __init__(self, base_url: str, client: httpx.Client) -> None:
        self.base_url = base_url
        self.client = client

    @singledispatchmethod
    def execute(self, resource: Resource[Any], spec: ChainSpec) -> Any:
        msg = f"No handler for {type(resource).__name__}"
        raise NotImplementedError(msg)

    @execute.register
    def handle_scores(self, resource: DimensionScores, spec: ChainSpec) -> list[DimensionScore]:  # noqa: ARG002
        params = spec.to_query_params()
        response = self.client.get(f"{self.base_url}/api/v1/manage/scores", params=params)
        response.raise_for_status()
        validated = [DimensionScoreResponse.model_validate(row) for row in response.json()]
        return [
            DimensionScore(
                dimension=QualityDimension(score_row.dimension),
                score=score_row.score,
                checks_passed=score_row.checks_passed,
                checks_total=score_row.checks_total,
            )
            for score_row in validated
        ]

    @execute.register
    def handle_check_counters(
        self,
        resource: CheckCounters,  # noqa: ARG002
        spec: ChainSpec,
    ) -> CheckCountersData:
        params = spec.to_query_params()
        response = self.client.get(f"{self.base_url}/api/v1/manage/checks/counters", params=params)
        response.raise_for_status()
        validated = CheckCountersApiResponse.model_validate(response.json())
        return CheckCountersData(
            total=validated.total,
            passed=validated.passed,
            failed=validated.failed,
            warned=validated.warned,
            skipped=validated.skipped,
        )

    @execute.register
    def handle_flagged_tables(self, resource: FlaggedTables, spec: ChainSpec) -> list[str]:  # noqa: ARG002
        response = self.client.get(f"{self.base_url}/api/v1/manage/flagged-rows/tables")
        response.raise_for_status()
        validated = FlaggedTablesApiResponse.model_validate(response.json())
        return validated.tables

    @execute.register
    def handle_verification_runs(
        self,
        resource: VerificationRuns,  # noqa: ARG002
        spec: ChainSpec,
    ) -> list[VerificationRunSummary]:
        params = spec.to_query_params()
        response = self.client.get(f"{self.base_url}/api/v1/manage/runs/verification", params=params)
        response.raise_for_status()
        return [VerificationRunSummary.model_validate(row) for row in response.json()]

    @execute.register
    def handle_contract_list(
        self,
        resource: ContractList,  # noqa: ARG002
        spec: ChainSpec,
    ) -> list[ContractSummaryData]:
        params = spec.to_query_params()
        response = self.client.get(f"{self.base_url}/api/v1/manage/dashboard/contracts", params=params)
        response.raise_for_status()
        return [ContractSummaryData.model_validate(row) for row in response.json()]

    @execute.register
    def handle_alert_list(
        self,
        resource: AlertList,  # noqa: ARG002
        spec: ChainSpec,
    ) -> list[AlertEntry]:
        params = spec.to_query_params()
        response = self.client.get(f"{self.base_url}/api/v1/manage/alerts", params=params)
        response.raise_for_status()
        return [AlertEntry.model_validate(row) for row in response.json()]
