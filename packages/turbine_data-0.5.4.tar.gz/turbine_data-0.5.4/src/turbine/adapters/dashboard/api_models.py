"""Pydantic models for turbine serve API responses consumed by the dashboard."""

from __future__ import annotations

from pydantic import BaseModel


class DimensionScoreResponse(BaseModel):
    """Single dimension score returned by GET /scores."""

    dimension: str
    score: float
    checks_passed: int
    checks_total: int


class CheckCountersApiResponse(BaseModel):
    """Response from GET /checks/counters."""

    total: int
    passed: int
    failed: int
    warned: int
    skipped: int


class FlaggedTablesApiResponse(BaseModel):
    """Response from GET /flagged-rows/tables."""

    tables: list[str]
