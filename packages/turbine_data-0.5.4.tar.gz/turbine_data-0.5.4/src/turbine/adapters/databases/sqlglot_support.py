"""Shared sqlglot helper for database backends.

Backends compose this class for type resolution and SQL transpilation.
It is not a base class — backends delegate to it, not extend it.
"""

from functools import lru_cache

import sqlglot
from loguru import logger
from sqlglot import exp
from sqlglot.errors import SqlglotError

from turbine.core.common import LogicalType
from turbine.core.common.ports import FlagUpsertParams
from turbine.infra.database.sql_helpers import build_values_clause, compute_mask

DT = exp.DataType.Type

MAX_BIT_POSITION = 63

DEFAULT_TYPE_MAPPING: dict[exp.DataType.Type, LogicalType] = {
    # String types
    DT.VARCHAR: LogicalType.STRING,
    DT.TEXT: LogicalType.STRING,
    DT.CHAR: LogicalType.STRING,
    DT.UUID: LogicalType.STRING,
    DT.BINARY: LogicalType.STRING,
    DT.VARBINARY: LogicalType.STRING,
    DT.NCHAR: LogicalType.STRING,
    DT.NVARCHAR: LogicalType.STRING,
    DT.NAME: LogicalType.STRING,
    # Integer types
    DT.INT: LogicalType.INTEGER,
    DT.BIGINT: LogicalType.INTEGER,
    DT.SMALLINT: LogicalType.INTEGER,
    DT.TINYINT: LogicalType.INTEGER,
    DT.MEDIUMINT: LogicalType.INTEGER,
    DT.INT128: LogicalType.INTEGER,
    DT.INT256: LogicalType.INTEGER,
    DT.UINT: LogicalType.INTEGER,
    DT.UBIGINT: LogicalType.INTEGER,
    DT.USMALLINT: LogicalType.INTEGER,
    DT.UTINYINT: LogicalType.INTEGER,
    DT.UINT128: LogicalType.INTEGER,
    DT.UINT256: LogicalType.INTEGER,
    DT.UMEDIUMINT: LogicalType.INTEGER,
    DT.BIT: LogicalType.INTEGER,
    # Numeric types
    DT.DECIMAL: LogicalType.NUMBER,
    DT.FLOAT: LogicalType.NUMBER,
    DT.DOUBLE: LogicalType.NUMBER,
    DT.MONEY: LogicalType.NUMBER,
    DT.SMALLMONEY: LogicalType.NUMBER,
    # Boolean
    DT.BOOLEAN: LogicalType.BOOLEAN,
    # Timestamp types
    DT.TIMESTAMP: LogicalType.TIMESTAMP,
    DT.TIMESTAMPTZ: LogicalType.TIMESTAMP,
    DT.TIMESTAMPNTZ: LogicalType.TIMESTAMP,
    DT.TIMESTAMPLTZ: LogicalType.TIMESTAMP,
    DT.DATETIME: LogicalType.TIMESTAMP,
    DT.DATETIME64: LogicalType.TIMESTAMP,
    # Date types
    DT.DATE: LogicalType.DATE,
    DT.DATE32: LogicalType.DATE,
    # Time types
    DT.TIME: LogicalType.TIME,
    DT.TIMETZ: LogicalType.TIME,
    # Object/JSON types
    DT.JSON: LogicalType.OBJECT,
    DT.JSONB: LogicalType.OBJECT,
    DT.VARIANT: LogicalType.OBJECT,
    DT.OBJECT: LogicalType.OBJECT,
    DT.STRUCT: LogicalType.OBJECT,
    # Array types
    DT.ARRAY: LogicalType.ARRAY,
    DT.LIST: LogicalType.ARRAY,
    # Geometry types (PostGIS, Snowflake GEOGRAPHY, etc.)
    DT.GEOMETRY: LogicalType.GEOMETRY,
    DT.GEOGRAPHY: LogicalType.GEOMETRY,
    DT.USERDEFINED: LogicalType.GEOMETRY,
}


@lru_cache(maxsize=512)
def cached_transpile(sql: str, read: str, write: str) -> str:
    """Transpile SQL from one dialect to another, with LRU caching."""
    results = sqlglot.transpile(sql, read=read, write=write)
    return results[0]


class SqlglotSupport:
    """Shared type resolution and SQL transpilation, composed by database backends."""

    def __init__(
        self, dialect_name: str, overrides: dict[exp.DataType.Type, LogicalType] | None = None
    ) -> None:
        """Store the dialect name and merge any type mapping overrides."""
        self.dialect_name = dialect_name
        self.mapping: dict[exp.DataType.Type, LogicalType] = {
            **DEFAULT_TYPE_MAPPING,
            **(overrides or {}),
        }

    def resolve_type(self, raw_type: str) -> LogicalType:
        """Convert a raw DB type string to a LogicalType, falling back to STRING for unknowns."""
        try:
            canonical = exp.DataType.build(raw_type, dialect=self.dialect_name).this
        except (SqlglotError, ValueError, KeyError):
            logger.warning(f"Unmapped database type '{raw_type}', falling back to STRING")
            return LogicalType.STRING
        if (result := self.mapping.get(canonical)) is not None:
            return result
        logger.warning(
            f"Unmapped database type '{raw_type}' (canonical: {canonical}), falling back to STRING"
        )
        return LogicalType.STRING

    def transpile(self, sql: str) -> str:
        """Transpile SQL from postgres dialect to this backend's dialect."""
        return cached_transpile(sql, read="postgres", write=self.dialect_name)

    def set_bit_expr(self, column: str, bit: int) -> str:
        """Generate a SQL expression that sets a single bit in a BIGINT column."""
        if bit < 0 or bit > MAX_BIT_POSITION:
            msg = f"bit position must be 0-63, got {bit}"
            raise ValueError(msg)
        mask = 1 << bit
        if mask >= (1 << MAX_BIT_POSITION):
            mask -= 1 << (MAX_BIT_POSITION + 1)
        return self.transpile(f"SELECT {column} | CAST({mask} AS BIGINT)").removeprefix("SELECT ")

    def bit_check_expr(self, column: str, mask: int) -> str:
        """Return ``(column & mask) > 0`` — works for DuckDB and Postgres."""
        return f"({column} & {mask}) > 0"

    def flag_upsert_sql(self, params: FlagUpsertParams) -> tuple[str, ...]:
        """UPDATE existing + INSERT missing (DuckDB / Postgres)."""
        bit_expr = self.set_bit_expr(params.flag_column, params.bit_position)
        mask = compute_mask(params.bit_position)
        values_clause = build_values_clause(params.pks)

        pk_list = ", ".join(params.pk_columns)
        pk_match = " AND ".join(f"f.{c} = v.{c}" for c in params.pk_columns)
        v_cols = ", ".join(f"v.{c}" for c in params.pk_columns)

        update = (
            f"UPDATE {params.table} AS f SET "
            f"{params.flag_column} = {bit_expr}, "
            f"last_checked_at = CURRENT_TIMESTAMP, "
            f"run_id = '{params.run_id}' "
            f"FROM (VALUES {values_clause}) AS v({pk_list}) "
            f"WHERE {pk_match}"
        )
        insert = (
            f"INSERT INTO {params.table} ({pk_list}, {params.flag_column}, last_checked_at, run_id) "
            f"SELECT {v_cols}, CAST({mask} AS BIGINT), CURRENT_TIMESTAMP, '{params.run_id}' "
            f"FROM (VALUES {values_clause}) AS v({pk_list}) "
            f"WHERE NOT EXISTS ("
            f"SELECT 1 FROM {params.table} AS f WHERE {pk_match}"
            f")"
        )
        return (update, insert)
