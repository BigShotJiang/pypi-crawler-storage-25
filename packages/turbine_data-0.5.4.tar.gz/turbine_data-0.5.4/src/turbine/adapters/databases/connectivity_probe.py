"""SQLAlchemy connectivity probe — SELECT 1 with timing."""

import time

from pydantic import ValidationError
from sqlalchemy import text
from sqlalchemy.exc import ArgumentError, DatabaseError, OperationalError, SQLAlchemyError
from sqlalchemy.exc import TimeoutError as SATimeoutError

from turbine.core.building_blocks import TurbineError
from turbine.core.common.datasource import DatasourceConfig
from turbine.core.common.ports import ProbeResult
from turbine.infra.database.engine import create_engine_from_config


class SqlAlchemyConnectivityProbe:
    """Probes datasource connectivity via a disposable SQLAlchemy engine."""

    def probe(self, datasource: DatasourceConfig) -> ProbeResult:
        """Connect to *datasource*, execute SELECT 1, and measure latency."""
        try:
            engine = create_engine_from_config(datasource)
        except TurbineError as exc:
            message = exc.diagnostics[0].message if exc.diagnostics else str(exc)
            return ProbeResult.failed(datasource, message)
        except (ArgumentError, SQLAlchemyError, ValidationError, ValueError) as exc:
            return ProbeResult.failed(datasource, str(exc))
        try:
            start = time.monotonic()
            with engine.connect() as conn:
                conn.execute(text("SELECT 1"))
            elapsed_ms = int((time.monotonic() - start) * 1000)
            return ProbeResult(
                datasource_name=datasource.name,
                datasource_type=datasource.ds_type,
                database=datasource.connection.database or None,
                connected=True,
                latency_ms=elapsed_ms,
            )
        except (OSError, OperationalError, DatabaseError, SATimeoutError, ValueError) as exc:
            return ProbeResult.failed(datasource, str(exc))
        finally:
            engine.dispose()
