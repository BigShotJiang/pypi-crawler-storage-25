"""DuckDB dialect SQL implementation."""

from turbine.adapters.databases.sqlglot_support import SqlglotSupport
from turbine.core.common.identifiers import validate_identifier


class DuckDbDialectSql(SqlglotSupport):
    """Dialect-specific SQL for DuckDB.

    Inherits ``set_bit_expr`` / ``flag_upsert_sql`` / ``bit_check_expr`` /
    ``resolve_type`` / ``transpile`` from ``SqlglotSupport``; overrides only
    the introspection and identifier rules that differ from the shared default.
    """

    def __init__(self) -> None:
        super().__init__("duckdb")

    def add_flag_column_sql(self, table: str, column: str) -> str:
        """Return DDL that adds a flag column to *table*."""
        validate_identifier(table, "table name")
        validate_identifier(column, "column name")
        return f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {column} BIGINT DEFAULT 0"

    def introspect_columns_sql(self, schema: str, table: str) -> tuple[str, dict[str, str]]:
        """Introspect columns via information_schema (fast for local DuckDB)."""
        return (
            "SELECT c.column_name, c.data_type, c.ordinal_position, c.is_nullable, "
            "CASE WHEN kcu.column_name IS NOT NULL THEN 'YES' ELSE 'NO' END "
            "FROM information_schema.columns c "
            "LEFT JOIN information_schema.table_constraints tc "
            "ON tc.table_schema = c.table_schema AND tc.table_name = c.table_name "
            "AND tc.constraint_type = 'PRIMARY KEY' "
            "LEFT JOIN information_schema.key_column_usage kcu "
            "ON kcu.constraint_name = tc.constraint_name "
            "AND kcu.table_schema = tc.table_schema "
            "AND kcu.column_name = c.column_name "
            "WHERE c.table_schema = :schema AND c.table_name = :table "
            "ORDER BY c.ordinal_position",
            {"schema": schema, "table": table},
        )

    def list_tables_sql(self, schema: str | None) -> tuple[str, dict[str, str]]:
        """List tables via information_schema (fast for local DuckDB)."""
        if schema is not None:
            return (
                "SELECT table_schema, table_name FROM information_schema.tables "
                "WHERE table_schema = :schema AND table_type = 'BASE TABLE' "
                "ORDER BY table_schema, table_name",
                {"schema": schema},
            )
        return (
            "SELECT table_schema, table_name FROM information_schema.tables "
            "WHERE table_type = 'BASE TABLE' "
            "AND table_schema NOT IN ('information_schema', 'pg_catalog') "
            "ORDER BY table_schema, table_name",
            {},
        )

    def normalize_identifier(self, identifier: str) -> str:
        """DuckDB identifiers are case-insensitive; return unchanged."""
        return identifier
