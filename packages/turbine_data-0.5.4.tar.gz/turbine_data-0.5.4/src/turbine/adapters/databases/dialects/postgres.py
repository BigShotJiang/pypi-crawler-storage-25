"""PostgreSQL dialect SQL implementation."""

from turbine.adapters.databases.sqlglot_support import SqlglotSupport
from turbine.core.common.identifiers import validate_identifier


class PostgresDialectSql(SqlglotSupport):
    """Dialect-specific SQL for PostgreSQL.

    Inherits ``set_bit_expr`` / ``flag_upsert_sql`` / ``bit_check_expr`` /
    ``resolve_type`` / ``transpile`` from ``SqlglotSupport`` (the upsert
    and bit syntax match generic SQL); overrides only the introspection
    rules that exploit ``pg_catalog`` for performance.
    """

    def __init__(self) -> None:
        super().__init__("postgres")

    def add_flag_column_sql(self, table: str, column: str) -> str:
        """Return DDL that adds a flag column to *table*."""
        validate_identifier(table, "table name")
        validate_identifier(column, "column name")
        return f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {column} BIGINT DEFAULT 0"

    def introspect_columns_sql(self, schema: str, table: str) -> tuple[str, dict[str, str]]:
        """Introspect columns via pg_catalog (115x faster than information_schema)."""
        return (
            "SELECT a.attname, format_type(a.atttypid, a.atttypmod), "
            "a.attnum, "
            "CASE WHEN a.attnotnull THEN 'NO' ELSE 'YES' END, "
            "CASE WHEN co.contype = 'p' THEN 'YES' ELSE 'NO' END "
            "FROM pg_attribute a "
            "JOIN pg_class c ON c.oid = a.attrelid "
            "JOIN pg_namespace n ON n.oid = c.relnamespace "
            "LEFT JOIN pg_constraint co ON co.conrelid = c.oid "
            "AND co.contype = 'p' AND a.attnum = ANY(co.conkey) "
            "WHERE n.nspname = :schema AND c.relname = :table "
            "AND a.attnum > 0 AND NOT a.attisdropped "
            "ORDER BY a.attnum",
            {"schema": schema, "table": table},
        )

    def list_tables_sql(self, schema: str | None) -> tuple[str, dict[str, str]]:
        """List tables via information_schema (respects user privileges)."""
        if schema is not None:
            return (
                "SELECT table_schema, table_name FROM information_schema.tables "
                "WHERE table_schema = :schema AND table_type = 'BASE TABLE' "
                "ORDER BY table_schema, table_name",
                {"schema": schema},
            )
        return (
            "SELECT table_schema, table_name FROM information_schema.tables "
            "WHERE table_type = 'BASE TABLE' "
            "AND table_schema NOT IN ('information_schema', 'pg_catalog') "
            "ORDER BY table_schema, table_name",
            {},
        )

    def normalize_identifier(self, identifier: str) -> str:
        """PostgreSQL identifiers are case-insensitive; return unchanged."""
        return identifier
