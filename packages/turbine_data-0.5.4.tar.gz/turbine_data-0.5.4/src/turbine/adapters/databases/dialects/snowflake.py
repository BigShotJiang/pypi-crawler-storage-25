"""Snowflake dialect SQL implementation."""

from turbine.adapters.databases.sqlglot_support import SqlglotSupport
from turbine.core.common.identifiers import validate_identifier
from turbine.core.common.ports import FlagUpsertParams
from turbine.infra.database.sql_helpers import build_values_clause, compute_mask


class SnowflakeDialectSql(SqlglotSupport):
    """Dialect-specific SQL for Snowflake.

    Inherits ``set_bit_expr`` / ``resolve_type`` / ``transpile`` from
    ``SqlglotSupport``. Overrides ``flag_upsert_sql`` (Snowflake uses
    ``MERGE`` not ``UPDATE ... FROM``) and ``bit_check_expr`` (Snowflake
    spells bitwise-AND as the ``BITAND`` function).
    """

    def __init__(self) -> None:
        super().__init__("snowflake")

    def add_flag_column_sql(self, table: str, column: str) -> str:
        """Return DDL that adds a flag column to *table*."""
        validate_identifier(table, "table name")
        validate_identifier(column, "column name")
        return f"ALTER TABLE {table} ADD COLUMN IF NOT EXISTS {column} BIGINT DEFAULT 0"

    def flag_upsert_sql(self, params: FlagUpsertParams) -> tuple[str, ...]:
        """Return a MERGE statement for Snowflake flag upserts."""
        bit_expr = self.set_bit_expr(params.flag_column, params.bit_position)
        mask = compute_mask(params.bit_position)
        values_clause = build_values_clause(params.pks)

        pk_list = ", ".join(params.pk_columns)
        col_aliases = ", ".join(f"column{i + 1} AS {col}" for i, col in enumerate(params.pk_columns))
        pk_match = " AND ".join(f"f.{c} = v.{c}" for c in params.pk_columns)
        v_cols = ", ".join(f"v.{c}" for c in params.pk_columns)

        merge = (
            f"MERGE INTO {params.table} AS f "
            f"USING (SELECT {col_aliases} FROM VALUES {values_clause}) AS v "
            f"ON {pk_match} "
            f"WHEN MATCHED THEN UPDATE SET "
            f"{params.flag_column} = {bit_expr}, "
            f"last_checked_at = CURRENT_TIMESTAMP, "
            f"run_id = '{params.run_id}' "
            f"WHEN NOT MATCHED THEN INSERT "
            f"({pk_list}, {params.flag_column}, last_checked_at, run_id) "
            f"VALUES ({v_cols}, CAST({mask} AS BIGINT), CURRENT_TIMESTAMP, '{params.run_id}')"
        )
        return (merge,)

    def bit_check_expr(self, column: str, mask: int) -> str:
        """Return ``BITAND(column, mask) > 0`` for Snowflake."""
        return f"BITAND({column}, {mask}) > 0"

    def introspect_columns_sql(self, schema: str, table: str) -> tuple[str, dict[str, str]]:
        """Introspect columns via information_schema for Snowflake."""
        return (
            "SELECT c.column_name, c.data_type, c.ordinal_position, c.is_nullable, "
            "CASE WHEN kcu.column_name IS NOT NULL THEN 'YES' ELSE 'NO' END "
            "FROM information_schema.columns c "
            "LEFT JOIN information_schema.table_constraints tc "
            "ON tc.table_schema = c.table_schema AND tc.table_name = c.table_name "
            "AND tc.constraint_type = 'PRIMARY KEY' "
            "LEFT JOIN information_schema.key_column_usage kcu "
            "ON kcu.constraint_name = tc.constraint_name "
            "AND kcu.table_schema = tc.table_schema "
            "AND kcu.column_name = c.column_name "
            "WHERE c.table_schema = :schema AND c.table_name = :table "
            "ORDER BY c.ordinal_position",
            {"schema": schema.upper(), "table": table.upper()},
        )

    def list_tables_sql(self, schema: str | None) -> tuple[str, dict[str, str]]:
        """List tables via information_schema for Snowflake."""
        if schema is not None:
            return (
                "SELECT table_schema, table_name FROM information_schema.tables "
                "WHERE table_schema = :schema AND table_type = 'BASE TABLE' "
                "ORDER BY table_schema, table_name",
                {"schema": schema.upper()},
            )
        return (
            "SELECT table_schema, table_name FROM information_schema.tables "
            "WHERE table_type = 'BASE TABLE' "
            "AND table_schema != 'INFORMATION_SCHEMA' "
            "ORDER BY table_schema, table_name",
            {},
        )

    def normalize_identifier(self, identifier: str) -> str:
        """Snowflake normalizes unquoted identifiers to upper case."""
        return identifier.upper()
