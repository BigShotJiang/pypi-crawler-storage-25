"""Dialect-specific SQL implementations."""

from turbine.core.common import DataSourceType
from turbine.core.common.ports import DialectSql

from .duckdb import DuckDbDialectSql
from .postgres import PostgresDialectSql
from .snowflake import SnowflakeDialectSql


def get_dialect_sql(dialect: DataSourceType) -> DialectSql:
    """Return the dialect-specific SQL helper for the given dialect."""
    match dialect:
        case DataSourceType.POSTGRES:
            return PostgresDialectSql()
        case DataSourceType.SNOWFLAKE:
            return SnowflakeDialectSql()
        case DataSourceType.DUCKDB:
            return DuckDbDialectSql()


__all__ = ["DuckDbDialectSql", "PostgresDialectSql", "SnowflakeDialectSql", "get_dialect_sql"]
