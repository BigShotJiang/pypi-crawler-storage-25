"""Cross-datasource schema introspection — tries one or many datasources for a table."""

from loguru import logger

from turbine.core.building_blocks import NullDiagnosticSink
from turbine.core.common import DatabaseBackend, DatasourceConfig, TableIdentifier
from turbine.core.common.error_summary import summarize_exception
from turbine.core.common.ports import (
    DatabaseBackendFactory,
    DatasourceError,
    DatasourceRepository,
    IntrospectionError,
    IntrospectionResult,
    ListTablesResult,
)


class MultiDatasourceIntrospector:
    """Introspect a table against one named datasource or fall back to trying all of them."""

    def __init__(
        self, datasource_repo: DatasourceRepository, backend_factory: DatabaseBackendFactory
    ) -> None:
        """Store the datasource repository and backend factory used for introspection."""
        self.datasource_repo = datasource_repo
        self.backend_factory = backend_factory
        self.backend_cache: dict[str, DatabaseBackend] = {}

    def introspect(
        self, table: TableIdentifier, datasource_name: str | None
    ) -> IntrospectionResult | IntrospectionError:
        """Introspect *table* on *datasource_name*, or try every datasource if None."""
        if datasource_name is not None:
            return self.introspect_named(table, datasource_name)
        return self.introspect_any(table)

    def introspect_named(
        self, table: TableIdentifier, datasource_name: str
    ) -> IntrospectionResult | IntrospectionError:
        """Introspect *table* via the datasource identified by *datasource_name*."""
        config = self.datasource_repo.get(datasource_name, NullDiagnosticSink())
        return self.introspect_config(config, table)

    def introspect_config(
        self, config: DatasourceConfig, table: TableIdentifier
    ) -> IntrospectionResult | IntrospectionError:
        """Introspect *table* using a pre-parsed config (bypasses repository lookup)."""
        outcome = self.try_introspect(config, table)
        if isinstance(outcome, IntrospectionResult):
            return outcome
        return IntrospectionError(table=str(table), errors=(outcome,))

    def introspect_any(self, table: TableIdentifier) -> IntrospectionResult | IntrospectionError:
        """Try every known datasource until one returns columns for *table*."""
        datasources = self.datasource_repo.list_datasources(NullDiagnosticSink())
        errors: list[DatasourceError] = []
        for datasource in datasources:
            outcome = self.try_introspect(datasource, table)
            if isinstance(outcome, IntrospectionResult):
                return outcome
            errors.append(outcome)
        logger.warning(f"No datasource could introspect {table}")
        return IntrospectionError(table=str(table), errors=tuple(errors))

    def get_or_create_backend(self, datasource: DatasourceConfig) -> DatabaseBackend:
        """Return a cached backend for the datasource, creating one if needed."""
        cached = self.backend_cache.get(datasource.name)
        if cached is not None:
            return cached
        backend = self.backend_factory.create(datasource, NullDiagnosticSink())
        self.backend_cache[datasource.name] = backend
        return backend

    def invalidate_datasource(self, datasource_name: str) -> None:
        """Evict the cached backend for *datasource_name* and dispose its engine.

        Called when a datasource file changes so the next introspection picks
        up new connection settings and stale SQLAlchemy engines do not leak
        connection pools.
        """
        backend = self.backend_cache.pop(datasource_name, None)
        if backend is None:
            return
        engine = getattr(backend, "engine", None)
        dispose = getattr(engine, "dispose", None)
        if callable(dispose):
            try:
                dispose()
            except Exception:  # noqa: BLE001 — dispose must not raise upwards
                logger.debug(f"Failed to dispose backend for {datasource_name}")

    def try_introspect(
        self, datasource: DatasourceConfig, table: TableIdentifier
    ) -> IntrospectionResult | DatasourceError:
        """Introspect *table* via a cached backend for *datasource*."""
        try:
            backend = self.get_or_create_backend(datasource)
            columns = backend.introspect_schema(table)
        except Exception as exc:  # noqa: BLE001
            logger.debug(f"Datasource {datasource.name} failed for {table}: {exc}")
            return DatasourceError(datasource_name=datasource.name, reason=str(exc))
        if columns is None:
            return DatasourceError(datasource_name=datasource.name, reason="table not found")
        logger.info(f"Introspected {table} via {datasource.name}: {len(columns)} columns")
        return IntrospectionResult(columns=columns, has_constraint_info=True)

    def list_tables_config(self, config: DatasourceConfig, schemas: frozenset[str]) -> ListTablesResult:
        """List tables using a pre-parsed config (bypasses repository lookup)."""
        try:
            backend = self.get_or_create_backend(config)
        except Exception as exc:  # noqa: BLE001
            logger.warning(f"Failed to open backend for {config.name}: {exc}")
            return ListTablesResult.unreachable(summarize_exception(exc))
        return self.collect_tables(backend, schemas, config.name)

    def list_tables_across_schemas(
        self, datasource_name: str, schemas: frozenset[str]
    ) -> ListTablesResult:
        """Return every table in *schemas* on *datasource_name*, plus the default schema.

        Connection failures are surfaced as ``ListTablesResult.unreachable`` so
        callers can tell "datasource is down" apart from "datasource has no
        tables". Per-schema failures are swallowed so one bad schema does not
        blank out the entire completion list, but if every schema fails the
        datasource is treated as unreachable.
        """
        logger.info(f"list_tables_across_schemas: ds={datasource_name} schemas={sorted(schemas)}")
        cached = self.backend_cache.get(datasource_name)
        if cached is not None:
            backend = cached
            logger.info(f"list_tables_across_schemas: cached backend hit for {datasource_name}")
        else:
            try:
                datasource = self.datasource_repo.get(datasource_name, NullDiagnosticSink())
                logger.info(
                    f"list_tables_across_schemas: opening backend for {datasource_name} "
                    f"type={datasource.ds_type.value} connection={datasource.connection}"
                )
                backend = self.get_or_create_backend(datasource)
            except Exception as exc:  # noqa: BLE001
                logger.warning(f"Failed to open backend for {datasource_name}: {exc}")
                return ListTablesResult.unreachable(summarize_exception(exc))
        return self.collect_tables(backend, schemas, datasource_name)

    def collect_tables(
        self, backend: DatabaseBackend, schemas: frozenset[str], label: str
    ) -> ListTablesResult:
        """Scan *schemas* (plus the default schema) on *backend* and return all tables found."""
        targets: set[str] = set(schemas)
        targets.add(backend.default_schema)
        tables: list[TableIdentifier] = []
        first_error: str | None = None
        for schema in targets:
            try:
                tables.extend(backend.list_tables(schema))
            except Exception as exc:  # noqa: BLE001
                if first_error is None:
                    first_error = summarize_exception(exc)
                logger.debug(f"list_tables({schema}) failed on {label}: {exc}")

        if not tables and first_error is not None:
            return ListTablesResult.unreachable(first_error)
        return ListTablesResult.ok(tuple(tables))
