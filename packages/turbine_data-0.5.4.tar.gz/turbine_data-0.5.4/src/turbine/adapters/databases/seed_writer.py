"""DuckDB ``SeedWriter`` adapter.

Translates a contract column list into ``CREATE SCHEMA`` + ``DROP TABLE`` +
``CREATE TABLE`` + parameterized ``INSERT`` against a ``SQLAlchemyBackend``.
The mapping from ``LogicalType`` to DuckDB's column types lives next to the
SQL it generates so future Postgres/Snowflake adapters ship their own table
without coupling to this one.
"""

from __future__ import annotations

from sqlalchemy.exc import SQLAlchemyError

from turbine.core.building_blocks import DatabaseError, DiagnosticBuilder
from turbine.core.building_blocks.diagnostics.ids import DiagnosticId
from turbine.core.common import LogicalType
from turbine.core.common.dataset_spec import ColumnDef
from turbine.core.common.identifiers import TableIdentifier, validate_identifier
from turbine.core.common.ports import QueryExecutor

DUCKDB_TYPES: dict[LogicalType, str] = {
    LogicalType.INTEGER: "INTEGER",
    LogicalType.NUMBER: "DOUBLE",
    LogicalType.STRING: "VARCHAR",
    LogicalType.TEXT: "VARCHAR",
    LogicalType.BOOLEAN: "BOOLEAN",
    LogicalType.TIMESTAMP: "TIMESTAMP",
    LogicalType.DATETIME: "TIMESTAMP",
    LogicalType.DATE: "DATE",
    LogicalType.TIME: "TIME",
}


class BackendSeedWriter:
    """Implements ``SeedWriter`` against any ``SQLAlchemyBackend`` (DuckDB in v1)."""

    def __init__(self, backend: QueryExecutor) -> None:
        self.backend = backend

    def seed_table(
        self, table: TableIdentifier, columns: tuple[ColumnDef, ...], rows: tuple[dict[str, object], ...]
    ) -> int:
        """Drop and recreate *table* with the schema implied by *columns*, then insert *rows*."""
        validate_identifier(table.schema, kind="schema name")
        validate_identifier(table.table, kind="table name")
        for column in columns:
            validate_identifier(column.name, kind="column name")

        column_defs = ", ".join(column_ddl(column) for column in columns)
        pk_columns = tuple(column.name for column in columns if column.primary_key)
        if pk_columns:
            column_defs = f"{column_defs}, PRIMARY KEY ({', '.join(pk_columns)})"
        qualified = f"{table.schema}.{table.table}"

        self.run(f"CREATE SCHEMA IF NOT EXISTS {table.schema}")
        self.run(f"DROP TABLE IF EXISTS {qualified}")
        self.run(f"CREATE TABLE {qualified} ({column_defs})")

        if not rows:
            return 0

        column_names = tuple(column.name for column in columns)
        placeholders = ", ".join(f":{name}" for name in column_names)
        insert_sql = f"INSERT INTO {qualified} ({', '.join(column_names)}) VALUES ({placeholders})"
        for row in rows:
            self.run(insert_sql, params=row)
        return len(rows)

    def run(self, sql: str, params: dict[str, object] | None = None) -> None:
        """Execute *sql* via the backend, wrapping driver errors in ``SEED_WRITE_ERROR``."""
        try:
            self.backend.execute_query(sql, params)
        except (DatabaseError, SQLAlchemyError) as exc:
            raise (
                DiagnosticBuilder.error(
                    DiagnosticId.SEED_WRITE_ERROR, f"failed to execute seed statement: {exc}"
                )
                .help(f"sql: {sql}")
                .into_error()
            ) from exc


def column_ddl(column: ColumnDef) -> str:
    """Render the column part of a DuckDB CREATE TABLE clause.

    Honors ``required: true`` (``nullable=False``) by emitting ``NOT NULL``
    so the schema check sees the same nullability the contract declares.
    Primary-key columns are flagged at the table level, not inline.
    """
    suffix = "" if column.nullable else " NOT NULL"
    return f"{column.name} {sql_type_for(column)}{suffix}"


def sql_type_for(column: ColumnDef) -> str:
    """Return the DuckDB column type for *column*, or raise on unsupported logical types."""
    duckdb_type = DUCKDB_TYPES.get(column.logical_type)
    if duckdb_type is None:
        raise (
            DiagnosticBuilder.error(
                DiagnosticId.SEED_UNSUPPORTED_LOGICAL_TYPE,
                f"cannot seed column {column.name!r}: "
                f"logical type {column.logical_type.value!r} is not supported",
            )
            .help(
                "supported types: integer, number, string, text, boolean, "
                "timestamp, datetime, date, time"
            )
            .into_error()
        )
    return duckdb_type
