"""Pure SQL formatting helpers shared by flag writers and backends."""

MAX_BIT_POSITION = 63


def format_pk_value(value: object) -> str:
    """Format a primary key value as a SQL literal."""
    if value is None:
        return "NULL"
    return f"'{value}'"


def compute_mask(bit_position: int) -> int:
    """Compute bitmask for a bit position, handling BIGINT sign bit."""
    mask = 1 << bit_position
    if mask >= (1 << MAX_BIT_POSITION):
        mask -= 1 << (MAX_BIT_POSITION + 1)
    return mask


def build_values_clause(pks: tuple[tuple[object, ...], ...]) -> str:
    """Build a SQL VALUES clause from primary key tuples."""
    return ", ".join("(" + ", ".join(format_pk_value(v) for v in pk) + ")" for pk in pks)
