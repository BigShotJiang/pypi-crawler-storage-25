"""SQLAlchemy-based database backend.

Single implementation of the DatabaseBackend protocol for all dialects.
Dialect-specific behavior dispatched via engine.dialect.name.
"""

import contextlib

from sqlalchemy import Connection, Engine, text
from sqlalchemy.engine.interfaces import Dialect
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.pool import PoolProxiedConnection

from turbine.adapters.databases.dialects import get_dialect_sql
from turbine.core.building_blocks import DatabaseError
from turbine.core.common import ColumnDef, DataSourceType, TableIdentifier
from turbine.core.common.ports import DialectSql

DEFAULT_SCHEMAS: dict[DataSourceType, str] = {
    DataSourceType.DUCKDB: "main",
    DataSourceType.POSTGRES: "public",
    DataSourceType.SNOWFLAKE: "public",
}


DUCKDB_TX_ERROR = "cannot start a transaction within a transaction"


def patch_duckdb_do_begin(engine: Engine) -> None:
    """Patch duckdb_engine's do_begin to tolerate DuckDB's auto-transaction.

    DuckDB auto-starts transactions after each commit. When SQLAlchemy's
    autobegin calls do_begin, it conflicts. This patch suppresses that
    specific error. Applied once per dialect class (idempotent).
    """
    dialect_cls = type(engine.dialect)
    if getattr(dialect_cls, "do_begin_patched", False):
        return

    original = dialect_cls.do_begin

    def safe_do_begin(dialect_self: Dialect, connection: PoolProxiedConnection) -> None:
        """Call original do_begin, suppressing DuckDB's duplicate-transaction error."""
        try:
            original(dialect_self, connection)
        except Exception as exc:
            if DUCKDB_TX_ERROR in str(exc):
                return
            raise

    do_begin_name = "do_begin"
    patched_flag_name = "do_begin_patched"
    setattr(dialect_cls, do_begin_name, safe_do_begin)
    setattr(dialect_cls, patched_flag_name, True)


class SQLAlchemyBackend:
    """Implements DatabaseBackend protocol via SQLAlchemy engine.

    A single class replaces DuckDBBackend, PostgresBackend, and SnowflakeBackend.
    """

    def __init__(self, engine: Engine) -> None:
        """Initialize from a SQLAlchemy engine and pick the matching dialect helper."""
        self.engine = engine
        self.dialect = DataSourceType.parse(engine.dialect.name)
        self.tx_conn: Connection | None = None
        self.dialect_sql_impl: DialectSql = get_dialect_sql(self.dialect)

        if self.dialect == DataSourceType.DUCKDB:
            patch_duckdb_do_begin(engine)

    @property
    def dialect_sql(self) -> DialectSql:
        """Return the dialect-specific SQL helper for this backend."""
        return self.dialect_sql_impl

    @property
    def default_schema(self) -> str:
        """Return the default schema name for this dialect."""
        return DEFAULT_SCHEMAS.get(self.dialect, "public")

    def execute_query(
        self, sql: str, params: dict[str, object] | None = None
    ) -> tuple[tuple[object, ...], ...]:
        """Execute SQL and return rows. Uses the transaction connection if active."""
        stmt = text(sql)
        bound = params or {}
        tx_conn = self.tx_conn
        connection_ctx: contextlib.AbstractContextManager[Connection] = (
            contextlib.nullcontext(tx_conn) if tx_conn is not None else self.engine.connect()
        )
        try:
            with connection_ctx as conn:
                result = conn.execute(stmt, bound)
                rows = tuple(tuple(row) for row in result) if result.returns_rows else ()
                if tx_conn is None:
                    conn.commit()
                return rows
        except SQLAlchemyError as exc:
            raise DatabaseError(str(getattr(exc, "orig", None) or exc)) from exc

    def introspect_schema(self, table: TableIdentifier) -> tuple[ColumnDef, ...] | None:
        """Query column definitions for a table via the dialect-optimised SQL."""
        schema = self.dialect_sql.normalize_identifier(table.schema)
        table_name = self.dialect_sql.normalize_identifier(table.table)
        query, params = self.dialect_sql.introspect_columns_sql(schema, table_name)
        try:
            with self.engine.connect() as conn:
                rows = conn.execute(text(query), params).fetchall()
        except Exception as exc:
            raise DatabaseError(f"Failed to introspect {schema}.{table_name}: {exc}") from exc
        if not rows:
            return None
        return tuple(
            ColumnDef(
                name=str(row[0]),
                logical_type=self.dialect_sql.resolve_type(str(row[1])),
                nullable=str(row[3]) == "YES",
                primary_key=str(row[4]) == "YES",
                position=int(str(row[2])),
            )
            for row in rows
        )

    def list_tables(self, schema: str | None = None) -> tuple[TableIdentifier, ...]:
        """Return base tables, optionally filtered to a single schema.

        When *schema* is None, returns tables from all non-system schemas.
        SQL generation is delegated to the dialect (e.g. pg_catalog on Postgres).
        """
        try:
            target = self.dialect_sql.normalize_identifier(schema) if schema is not None else None
            query, params = self.dialect_sql.list_tables_sql(target)
            with self.engine.connect() as conn:
                rows = conn.execute(text(query), params).fetchall()
        except (OSError, RuntimeError, SQLAlchemyError, ValueError) as exc:
            raise DatabaseError(f"Failed to list tables: {exc}") from exc
        return tuple(TableIdentifier(schema=str(row[0]), table=str(row[1])) for row in rows)

    def begin(self) -> None:
        """Open a persistent connection for the transaction scope."""
        self.tx_conn = self.engine.connect()

    def commit(self) -> None:
        """Commit and close the persistent transaction connection."""
        if not self.tx_conn:
            return
        self.tx_conn.commit()
        self.tx_conn.close()
        self.tx_conn = None

    def rollback(self) -> None:
        """Roll back and close the persistent transaction connection."""
        if not self.tx_conn:
            return
        self.tx_conn.rollback()
        self.tx_conn.close()
        self.tx_conn = None
