"""BackendFactory: maps DataSourceType to a driver module and builds SQLAlchemy backends."""

import importlib

from turbine.adapters.databases.backend import SQLAlchemyBackend
from turbine.core.building_blocks import DiagnosticBuilder, DiagnosticId, DiagnosticSink, TurbineError
from turbine.core.common import DatabaseBackend, DatabaseBackendFactory, DatasourceConfig, DataSourceType
from turbine.infra.database.engine import create_engine_from_config


class BackendFactory(DatabaseBackendFactory):
    """Maps DataSourceType to a driver module and builds SQLAlchemyBackend.

    Connection validation already happened at parse time (typed
    ``ConnectionProps`` on ``DatasourceConfig``), so this factory only
    checks driver availability before opening the engine.
    """

    def __init__(self) -> None:
        """Initialize an empty datasource type registry."""
        self.registry: dict[DataSourceType, str] = {}

    def register(self, ds_type: DataSourceType, driver_module: str) -> None:
        """Bind *ds_type* to a driver module path."""
        self.registry[ds_type] = driver_module

    def create(self, ds_config: DatasourceConfig, sink: DiagnosticSink) -> DatabaseBackend:
        """Create a SQLAlchemyBackend from a DatasourceConfig."""
        if (driver_module := self.registry.get(ds_config.ds_type)) is None:
            registered = sorted(t.value for t in self.registry)
            diag = (
                DiagnosticBuilder.error(
                    DiagnosticId.DATASOURCE_CONFIG_ERROR,
                    f"Datasource type '{ds_config.ds_type.value}' is not supported by this install.",
                )
                .help(f"Use one of these datasource types: {', '.join(registered)}.")
                .build()
            )
            sink.add(diag)
            raise TurbineError(diag.message, diagnostics=(diag,))

        try:
            importlib.import_module(driver_module)
        except ImportError:
            package_name = f"turbine[{ds_config.ds_type.value}]"
            message = (
                f"The Python package for '{ds_config.ds_type.value}' datasources is not "
                f"installed: {driver_module}."
            )
            builder = DiagnosticBuilder.error(
                DiagnosticId.DATASOURCE_DRIVER_NOT_INSTALLED, message
            ).help(f"Install it with `uv add '{package_name}'` or `pip install '{package_name}'`.")
            if ds_config.source_path is not None:
                builder.span(ds_config.source_path)
            diag = builder.build()
            sink.add(diag)
            raise TurbineError(diag.message, diagnostics=(diag,)) from None

        engine = create_engine_from_config(ds_config)
        return SQLAlchemyBackend(engine)


def create_backend_factory() -> BackendFactory:
    """Create a BackendFactory with all known database drivers registered."""
    factory = BackendFactory()
    factory.register(DataSourceType.POSTGRES, "psycopg")
    factory.register(DataSourceType.SNOWFLAKE, "snowflake.sqlalchemy")
    factory.register(DataSourceType.DUCKDB, "duckdb_engine")
    return factory
