"""Tree-sitter based YAML parser -- walks a CST into plain Python dicts.

Produces the same ``dict[str, Any]`` output as ``ruamel.yaml.YAML().load()``,
using tree-sitter's typed scalar nodes (``boolean_scalar``, ``integer_scalar``,
``float_scalar``, ``null_scalar``) for YAML 1.2 type coercion instead of a
hand-written lookup table.

Does NOT handle anchors, aliases, merge keys, or tags (unused in data contracts).
"""

from __future__ import annotations

from collections import OrderedDict
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import tree_sitter
import tree_sitter_yaml
from loguru import logger

from turbine.core.analysis.context.key_context import KeyContext
from turbine.core.analysis.ports import DocumentTreePort
from turbine.core.building_blocks import Diagnostic, DiagnosticBuilder, DiagnosticId
from turbine.core.building_blocks.diagnostics.types import TextRange
from turbine.core.common import RawSource

YAML_LANGUAGE = tree_sitter.Language(tree_sitter_yaml.language())

BOOLEAN_VALUES: dict[str, bool] = {
    "true": True,
    "True": True,
    "TRUE": True,
    "false": False,
    "False": False,
    "FALSE": False,
}

NULL_VALUES: frozenset[str] = frozenset({"null", "Null", "NULL", "~"})

PAIR_TYPES = frozenset({"block_mapping_pair", "flow_pair"})
PASSTHROUGH_TYPES = frozenset(
    {"flow_node", "flow_pair", "block_node", "block_mapping", "block_sequence"}
)
COVERING_CONTAINER_TYPES = frozenset(
    {"stream", "document", "block_mapping", "block_sequence", "block_node", "block_sequence_item"}
)


def create_parser() -> tree_sitter.Parser:
    """Return a fresh tree-sitter YAML parser."""
    return tree_sitter.Parser(YAML_LANGUAGE)


def parse_tree(text: str) -> tree_sitter.Tree:
    """Parse YAML text into a tree-sitter CST."""
    parser = create_parser()
    return parser.parse(text.encode())


PARSE_CACHE: OrderedDict[tuple[str, int], RawSource] = OrderedDict()
PARSE_CACHE_MAX = 256


def parse_yaml(path: Path, text: str | None = None) -> RawSource:
    """Parse a YAML file into RawSource with position tracking.

    Drop-in replacement for the former ruamel.yaml-backed parser. Uses
    tree-sitter internally for ~16x faster parsing. Same signature, same
    return type, same error semantics.

    Results are memoized in an LRU keyed by ``(path, content_hash)`` so
    multiple LSP features reading the same file share a single parse.
    """
    if text is not None:
        cache_key = (str(path), hash(text))
        if (cached := PARSE_CACHE.get(cache_key)) is not None:
            PARSE_CACHE.move_to_end(cache_key)
            return cached

    logger.debug(f"Parsing YAML file: {path}")
    resolved_text = text if text is not None else read_file_text(path)
    result = do_parse_yaml(path, resolved_text)

    if text is not None:
        PARSE_CACHE[cache_key] = result
        if len(PARSE_CACHE) > PARSE_CACHE_MAX:
            PARSE_CACHE.popitem(last=False)
    return result


def read_file_text(path: Path) -> str:
    """Read file contents or raise a diagnostic error if missing."""
    if not path.exists():
        raise (
            DiagnosticBuilder.error(DiagnosticId.IO, f"file not found: {path}").span(path).into_error()
        )
    return path.read_text()


def do_parse_yaml(path: Path, text: str) -> RawSource:
    """Parse YAML text into a RawSource with tree-sitter.

    Tree-sitter recovers from syntax errors by producing partial trees
    with ERROR nodes. When recovery still yields some mapping/sequence
    content the parse succeeds, but every ERROR node is recorded as a
    non-fatal diagnostic on ``RawSource.parse_diagnostics`` so the lint
    pipeline cannot mark a partially malformed YAML as valid. When
    recovery yields no content at all the parse hard-fails.
    """
    source_bytes = text.encode()
    tree = parse_tree(text)
    root = tree.root_node

    error_nodes = collect_error_nodes(root)
    descendant_errors = [node for node in error_nodes if node is not root]
    if descendant_errors and not has_content(root):
        first = descendant_errors[0]
        line = first.start_point.row + 1
        col = first.start_point.column + 1
        error_range = TextRange(start_line=line, start_col=col, end_line=line, end_col=col + 1)
        raise (
            DiagnosticBuilder.error(
                DiagnosticId.CONTRACT_PARSE_ERROR, f"YAML syntax error at line {line}, column {col}"
            )
            .span(path, error_range)
            .help("check YAML syntax (indentation, colons, special characters)")
            .into_error()
        )

    try:
        data = extract_dict(root, source_bytes)
    except TypeError as exc:
        raise (
            DiagnosticBuilder.error(
                DiagnosticId.CONTRACT_PARSE_ERROR, f"Expected YAML mapping at top level, got {exc}"
            )
            .span(path)
            .help("the file must contain key: value pairs, not a list or scalar")
            .into_error()
        ) from exc

    parse_diagnostics = tuple(build_parse_error(path, node) for node in error_nodes)
    source_map = TreeSitterSourceMap(root, source_bytes)
    logger.debug(f"Built source map with {len(source_map.entries)} position entries")
    return RawSource(
        path=path, text=text, data=data, source_map=source_map, parse_diagnostics=parse_diagnostics
    )


def build_parse_error(path: Path, error_node: tree_sitter.Node) -> Diagnostic:
    """Convert a tree-sitter ERROR node into a non-fatal parse diagnostic."""
    line = error_node.start_point.row + 1
    col = error_node.start_point.column + 1
    error_range = TextRange(start_line=line, start_col=col, end_line=line, end_col=col + 1)
    return (
        DiagnosticBuilder.error(
            DiagnosticId.CONTRACT_PARSE_ERROR, f"YAML syntax error at line {line}, column {col}"
        )
        .span(path, error_range)
        .help("check YAML syntax (indentation, colons, special characters)")
        .build()
    )


def walk_named(node: tree_sitter.Node) -> list[tree_sitter.Node]:
    """Collect all named descendants (flat)."""
    result: list[tree_sitter.Node] = []
    stack = [node]
    while stack:
        current = stack.pop()
        for child in current.named_children:
            result.append(child)
            stack.append(child)
    return result


def collect_error_nodes(root: tree_sitter.Node) -> list[tree_sitter.Node]:
    """Collect every ``ERROR`` node, including the root itself when it is one.

    Tree-sitter's YAML grammar surfaces unparseable structures as ERROR
    nodes. For severely malformed top-level streams the root *is* the
    ERROR, which ``walk_named`` (descendant-only) would miss. Including
    the root keeps the parse-error path complete.
    """
    error_nodes: list[tree_sitter.Node] = []
    if root.type == "ERROR":
        error_nodes.append(root)
    error_nodes.extend(child for child in walk_named(root) if child.type == "ERROR")
    return error_nodes


def has_content(root: tree_sitter.Node) -> bool:
    """Check if the CST has any mapping or sequence content despite errors."""
    return any(
        child.type in ("block_mapping", "flow_mapping", "block_sequence", "flow_sequence")
        for child in walk_named(root)
    )


def extract_dict(root: tree_sitter.Node, source: bytes) -> dict[str, Any]:
    """Walk a tree-sitter YAML CST and produce a plain Python dict.

    Args:
        root: The root node of the parsed tree (``tree.root_node``).
        source: The original YAML text as bytes (needed for node text extraction).

    Returns:
        A plain Python dict matching what ``ruamel.yaml.YAML().load()`` would produce.

    Raises:
        TypeError: If the top-level YAML structure is not a mapping.
    """
    document = find_first_named(root, "document")
    if document is None:
        return {}
    content = find_content_node(document)
    if content is None:
        return {}
    result = convert_node(content, source)
    if not isinstance(result, dict):
        msg = f"Expected top-level mapping, got {type(result).__name__}"
        raise TypeError(msg)
    return result


def convert_node(node: tree_sitter.Node, source: bytes) -> Any:
    """Convert a single CST node to its Python equivalent."""
    handler = DISPATCH.get(node.type)
    if handler is not None:
        return handler(node, source)
    return node_text(node, source)


def convert_mapping(node: tree_sitter.Node, source: bytes) -> dict[str, Any]:
    """Convert a block_mapping or flow_mapping to a Python dict."""
    result: dict[str, Any] = {}
    for child in node.named_children:
        if child.type not in PAIR_TYPES:
            continue
        key, value = convert_mapping_pair(child, source)
        result[key] = value
    return result


def convert_mapping_pair(pair: tree_sitter.Node, source: bytes) -> tuple[str, Any]:
    """Extract key and value from a mapping pair node.

    Tree-sitter's YAML grammar emits ``comment`` nodes as named children of
    mapping pairs, so we must skip them when picking the key and value —
    otherwise an inline comment after ``key:`` is returned as if it were
    the scalar value.
    """
    named = [child for child in pair.named_children if child.type != "comment"]
    if not named:
        return ("", None)

    key_node = named[0]
    key = str(convert_node(key_node, source))

    if len(named) < 2:  # noqa: PLR2004
        return (key, None)

    value_node = named[1]
    value = convert_node(value_node, source)
    return (key, value)


def convert_sequence(node: tree_sitter.Node, source: bytes) -> list[Any]:
    """Convert a block_sequence or flow_sequence to a Python list."""
    items: list[Any] = []
    for child in node.named_children:
        if child.type == "comment":
            continue
        if child.type == "block_sequence_item":
            item_children = [item for item in child.named_children if item.type != "comment"]
            value = convert_node(item_children[0], source) if item_children else None
            items.append(value)
        elif child.type in PASSTHROUGH_TYPES:
            items.append(convert_node(child, source))
    return items


def convert_unwrap(node: tree_sitter.Node, source: bytes) -> Any:
    """Unwrap a flow_node or block_node to its content."""
    for child in node.named_children:
        return convert_node(child, source)
    return None


def convert_plain_scalar(node: tree_sitter.Node, source: bytes) -> Any:
    """Convert a plain_scalar using its typed child node."""
    for child in node.named_children:
        return coerce_typed_scalar(child, source)
    return node_text(node, source)


def coerce_typed_scalar(child: tree_sitter.Node, source: bytes) -> Any:
    """Coerce a typed scalar child (boolean_scalar, integer_scalar, etc.)."""
    child_type = child.type
    text = node_text(child, source)
    if child_type == "boolean_scalar":
        return BOOLEAN_VALUES.get(text, text)
    if child_type == "null_scalar":
        return None
    if child_type == "integer_scalar":
        return coerce_integer(text)
    if child_type == "float_scalar":
        return coerce_float(text)
    return text


def convert_quoted_scalar(node: tree_sitter.Node, source: bytes) -> str:
    """Strip surrounding quotes from a quoted scalar."""
    text = node_text(node, source)
    if len(text) >= 2 and text[0] in ('"', "'") and text[-1] == text[0]:  # noqa: PLR2004
        return text[1:-1]
    return text


def convert_block_scalar(node: tree_sitter.Node, source: bytes) -> str:
    """Process literal (|) or folded (>) block scalars with chomping."""
    text = node_text(node, source)
    if not text:
        return ""
    header, body = split_block_header(text)
    style = header[0] if header else "|"
    chomp = header[-1] if len(header) > 1 and header[-1] in ("-", "+") else ""
    dedented = dedent_lines(body)
    result = fold_lines(dedented) if style == ">" else "\n".join(dedented)
    return apply_chomp(result, chomp)


def split_block_header(text: str) -> tuple[str, str]:
    """Split a block scalar into its header line and body."""
    header_end = text.index("\n") if "\n" in text else len(text)
    header = text[:header_end]
    body = text[header_end + 1 :] if header_end < len(text) else ""
    return header, body


def dedent_lines(body: str) -> list[str]:
    """Split body into lines and strip common indentation."""
    lines = body.split("\n")
    indent = detect_indent(lines)
    return [line[indent:] if len(line) > indent else "" for line in lines]


def apply_chomp(text: str, chomp: str) -> str:
    """Apply YAML chomping indicator to block scalar result."""
    if chomp == "-":
        return text.rstrip("\n")
    if chomp == "+":
        return text
    return text.rstrip("\n") + "\n"


def fold_lines(lines: list[str]) -> str:
    """Apply YAML folded-style line joining."""
    parts: list[str] = []
    for line in lines:
        if not line:
            parts.append("\n")
        elif parts and parts[-1] != "\n":
            parts[-1] += " " + line
        else:
            parts.append(line)
    return "\n".join(parts) + "\n"


def detect_indent(lines: list[str]) -> int:
    """Find the common leading whitespace of non-empty lines."""
    min_indent = float("inf")
    for line in lines:
        stripped = line.lstrip()
        if stripped:
            indent = len(line) - len(stripped)
            min_indent = min(min_indent, indent)
    return int(min_indent) if min_indent != float("inf") else 0


def coerce_integer(text: str) -> int:
    """Parse YAML integer literals including octal (0o) and hex (0x)."""
    clean = text.replace("_", "")
    if clean.startswith(("0x", "0X")):
        return int(clean, 16)
    if clean.startswith(("0o", "0O")):
        return int(clean, 8)
    return int(clean)


def coerce_float(text: str) -> float:
    """Parse YAML float literals including .inf and .nan."""
    clean = text.replace("_", "").lower()
    if clean in (".inf", "+.inf"):
        return float("inf")
    if clean == "-.inf":
        return float("-inf")
    if clean == ".nan":
        return float("nan")
    return float(clean)


def node_text(node: tree_sitter.Node, source: bytes) -> str:
    """Extract the text content of a node."""
    return source[node.start_byte : node.end_byte].decode()


def find_first_named(node: tree_sitter.Node, node_type: str) -> tree_sitter.Node | None:
    """Find the first named child of the given type."""
    for child in node.named_children:
        if child.type == node_type:
            return child
    return None


def find_content_node(document: tree_sitter.Node) -> tree_sitter.Node | None:
    """Drill through document > block_node to the actual content node."""
    for child in document.named_children:
        if child.type == "block_node":
            for grandchild in child.named_children:
                return grandchild
        return child
    return None


Converter = Callable[[tree_sitter.Node, bytes], Any]


class TreeSitterSourceMap:
    """SourceMap backed by tree-sitter node positions.

    Walks the CST once at construction to build a dotted-path index. All
    queries are O(1) dict lookups + node position reads. Multi-line value
    ranges work natively because tree-sitter nodes span the full block.
    """

    def __init__(self, root: tree_sitter.Node, source: bytes) -> None:
        self.source = source
        self.lines = source.decode().splitlines()
        self.entries: dict[str, SourceMapEntry] = {}
        self.collect_entries(root, "")

    MAPPING_TYPES = frozenset({"block_mapping", "flow_mapping"})
    SEQUENCE_TYPES = frozenset({"block_sequence", "flow_sequence"})
    TRANSPARENT_TYPES = frozenset({"block_node", "flow_node", "document", "stream"})

    def collect_entries(self, node: tree_sitter.Node, prefix: str) -> None:
        """Recursively walk the CST building dotted-path entries."""
        if node.type in self.MAPPING_TYPES:
            self.collect_mapping(node, prefix)
        elif node.type in self.SEQUENCE_TYPES:
            self.collect_sequence(node, prefix)
        elif node.type in self.TRANSPARENT_TYPES:
            for child in node.named_children:
                self.collect_entries(child, prefix)

    def collect_mapping(self, node: tree_sitter.Node, prefix: str) -> None:
        """Collect all pairs from a mapping node."""
        for child in node.named_children:
            if child.type in PAIR_TYPES:
                self.collect_pair(child, prefix)

    def collect_sequence(self, node: tree_sitter.Node, prefix: str) -> None:
        """Collect indexed entries from a sequence node.

        Each sequence item is registered under its indexed path (e.g.
        ``schema.0.properties.0``) so ``range_for_block`` covers the full
        item — including all nested children. Without this entry, quick-fixes
        that remove a list item would only delete the first child line and
        leave the rest of the item's nested content orphaned.
        """
        for index, child in enumerate(node.named_children):
            item_prefix = f"{prefix}.{index}" if prefix else str(index)
            content = self.extract_sequence_content(child)
            self.entries[item_prefix] = SourceMapEntry(
                key_node=None, value_node=content, pair_node=child
            )
            if content is not None:
                self.collect_entries(content, item_prefix)

    def collect_pair(self, pair: tree_sitter.Node, prefix: str) -> None:
        """Record a mapping pair's key and value nodes.

        Comment nodes are named children of a pair, so skip them before
        treating ``named[1]`` as the value — an inline ``# comment`` after
        ``key:`` would otherwise be indexed as the value node.
        """
        named = [child for child in pair.named_children if child.type != "comment"]
        if not named:
            return
        key_node = named[0]
        key_leaf = find_leaf_scalar(key_node)
        key_text = node_text(key_leaf, self.source) if key_leaf else node_text(key_node, self.source)
        dotted = f"{prefix}.{key_text}" if prefix else key_text

        value_node = named[1] if len(named) > 1 else None
        entry = SourceMapEntry(key_node=key_leaf or key_node, value_node=value_node, pair_node=pair)
        self.entries[dotted] = entry

        if value_node is not None:
            self.collect_entries(value_node, dotted)

    def extract_sequence_content(self, child: tree_sitter.Node) -> tree_sitter.Node | None:
        """Extract the content node from a sequence item."""
        if child.type == "block_sequence_item":
            return child.named_children[0] if child.named_children else None
        if child.type in ("flow_node", "block_node"):
            return child
        return child

    def range_for_key(self, key_path: str) -> TextRange | None:
        """Return the TextRange spanning the key name at *key_path*.

        Sequence-item entries have no key (they are indexed list elements),
        so ``range_for_key`` returns ``None`` for those paths.
        """
        entry = self.entries.get(key_path)
        if entry is None or entry.key_node is None:
            return None
        node = entry.key_node
        return TextRange(
            start_line=node.start_point.row + 1,
            start_col=node.start_point.column + 1,
            end_line=node.end_point.row + 1,
            end_col=node.end_point.column + 1,
        )

    def range_for_value(self, key_path: str) -> TextRange | None:
        """Return the TextRange spanning the value at *key_path*.

        For multi-line blocks, the range spans all lines of the value.
        """
        entry = self.entries.get(key_path)
        if entry is None or entry.value_node is None:
            return None
        value_leaf = find_value_content(entry.value_node)
        if value_leaf is None:
            return None
        return TextRange(
            start_line=value_leaf.start_point.row + 1,
            start_col=value_leaf.start_point.column + 1,
            end_line=value_leaf.end_point.row + 1,
            end_col=value_leaf.end_point.column + 1,
        )

    def key_paths(self) -> tuple[str, ...]:
        """Return all known dotted key paths."""
        return tuple(self.entries.keys())

    def range_for_block(self, key_path: str) -> TextRange | None:
        """Return the range covering the entire block for key_path."""
        entry = self.entries.get(key_path)
        if entry is None:
            return None
        pair = entry.pair_node
        start_line = pair.start_point.row + 1
        end_line = pair.end_point.row + 1
        end_col = pair.end_point.column + 1
        if end_col <= 1 and end_line > start_line:
            end_line -= 1
            end_col = len(self.lines[end_line - 1]) + 1 if end_line <= len(self.lines) else 1
        return TextRange(start_line=start_line, start_col=1, end_line=end_line, end_col=end_col)

    def range_for_document_root(self) -> TextRange | None:
        """Return the range of the document's first top-level key.

        Top-level keys are entries whose dotted path contains no ``.`` —
        the first one encountered while building the source map. Used
        to anchor whole-document diagnostics (e.g. a missing required
        root field) at a real source position.
        """
        for path, entry in self.entries.items():
            if "." in path or entry.key_node is None:
                continue
            node = entry.key_node
            return TextRange(
                start_line=node.start_point.row + 1,
                start_col=node.start_point.column + 1,
                end_line=node.end_point.row + 1,
                end_col=node.end_point.column + 1,
            )
        return None


@dataclass(frozen=True, slots=True)
class SourceMapEntry:
    """Stored nodes for a single dotted-path entry.

    ``key_node`` is ``None`` for sequence-item entries (indexed list elements
    that have no key). Mapping-pair entries always carry a key.
    """

    key_node: tree_sitter.Node | None
    value_node: tree_sitter.Node | None
    pair_node: tree_sitter.Node


def find_leaf_scalar(node: tree_sitter.Node) -> tree_sitter.Node | None:
    """Drill through flow_node > plain_scalar > string_scalar to the leaf."""
    if node.type in ("string_scalar", "boolean_scalar", "integer_scalar", "float_scalar", "null_scalar"):
        return node
    for child in node.named_children:
        if (result := find_leaf_scalar(child)) is not None:
            return result
    return None


def find_value_content(node: tree_sitter.Node) -> tree_sitter.Node | None:
    """Find the innermost content node of a value (scalar, mapping, or sequence)."""
    if node.type in (
        "string_scalar",
        "boolean_scalar",
        "integer_scalar",
        "float_scalar",
        "null_scalar",
        "double_quote_scalar",
        "single_quote_scalar",
        "block_scalar",
        "block_mapping",
        "flow_mapping",
        "block_sequence",
        "flow_sequence",
    ):
        return node
    for child in node.named_children:
        if (result := find_value_content(child)) is not None:
            return result
    return None


DISPATCH: dict[str, Converter] = {
    "block_mapping": convert_mapping,
    "flow_mapping": convert_mapping,
    "block_sequence": convert_sequence,
    "flow_sequence": convert_sequence,
    "flow_node": convert_unwrap,
    "block_node": convert_unwrap,
    "block_scalar": convert_block_scalar,
    "plain_scalar": convert_plain_scalar,
    "double_quote_scalar": convert_quoted_scalar,
    "single_quote_scalar": convert_quoted_scalar,
    "flow_pair": convert_mapping_pair,
}


# ── Incremental document tree management ───────────────────────────────


def line_col_to_byte_offset(text: str, line: int, col: int) -> int:
    """Convert 1-indexed (line, col) to a byte offset in UTF-8 encoded text.

    Args:
        text: The document text.
        line: 1-indexed line number.
        col: 1-indexed column number (character offset within the line).

    Returns:
        Byte offset into ``text.encode()``.
    """
    lines = text.split("\n")
    byte_offset = 0
    for idx in range(line - 1):
        byte_offset += len(lines[idx].encode()) + 1  # +1 for '\n'
    line_text = lines[line - 1] if line - 1 < len(lines) else ""
    byte_offset += len(line_text[: col - 1].encode())
    return byte_offset


def apply_text_edit(text: str, start_byte: int, end_byte: int, replacement: str) -> str:
    """Apply a byte-range replacement to text, returning the updated string."""
    encoded = text.encode()
    new_encoded = encoded[:start_byte] + replacement.encode() + encoded[end_byte:]
    return new_encoded.decode()


class TreeSitterDocumentStore(DocumentTreePort):
    """Manages one tree-sitter parse tree per open document URI.

    Supports incremental editing: ``apply_edit`` calls ``tree.edit()`` with
    byte-level ranges before re-parsing, so tree-sitter only re-parses the
    changed region.

    Implements ``DocumentTreePort`` from ``core.analysis.ports``.
    """

    def __init__(self) -> None:
        self.documents: dict[str, tuple[tree_sitter.Tree, str]] = {}
        self.parser = create_parser()

    def open(self, uri: str, content: str) -> None:
        """Create the initial parse tree for a newly opened document."""
        tree = self.parser.parse(content.encode())
        self.documents[uri] = (tree, content)

    def close(self, uri: str) -> None:
        """Remove the parse tree for a closed document."""
        self.documents.pop(uri, None)

    def apply_edit(self, uri: str, edit_range: TextRange, text: str) -> None:
        """Apply a text edit by computing new content and re-parsing.

        Benchmarks show tree-sitter's full parse is already so fast that
        incremental ``tree.edit()`` is actually slower than a plain re-parse
        (the byte-offset arithmetic overhead exceeds the parse savings).
        Re-parsing from scratch also eliminates sync bugs where the tree
        would drift out of alignment with the editor's content.
        """
        entry = self.documents.get(uri)
        if entry is None:
            return
        old_text = entry[1]
        start_byte = line_col_to_byte_offset(old_text, edit_range.start_line, edit_range.start_col)
        end_byte = line_col_to_byte_offset(old_text, edit_range.end_line, edit_range.end_col)
        new_text = apply_text_edit(old_text, start_byte, end_byte, text)
        new_tree = self.parser.parse(new_text.encode())
        self.documents[uri] = (new_tree, new_text)

    def resolve_context_at(self, uri: str, line: int, col: int) -> KeyContext | None:
        """Return cursor context at the given 0-indexed position.

        Two-stage resolution inspired by ruff/ty's covering-node pattern:

        1. If the cursor lands on a leaf node (key text, value text, colon),
           walk up the parent chain to find the enclosing pair -- O(log n).
        2. If the cursor lands on a container (block_mapping, block_sequence)
           because it's on whitespace after ``key: ``, search the container's
           children for the pair whose key is on the same line.
        """
        entry = self.documents.get(uri)
        if entry is None:
            return None
        tree, text = entry
        source = text.encode()
        node = tree.root_node.descendant_for_point_range((line, col), (line, col))
        if node is None or node.type in ("stream", "document"):
            return None
        # Stage 1: leaf node — walk up to pair
        if node.type not in COVERING_CONTAINER_TYPES:
            return self.context_from_leaf(node, source)
        # Stage 2: container — find the closest pair child on this line
        return find_line_pair_context(node, source, line, col)

    def context_from_leaf(self, node: tree_sitter.Node, source: bytes) -> KeyContext | None:
        """Build context from a leaf/specific node by walking up to its pair."""
        dotted = walk_to_dotted_path(node, source)
        if dotted is None:
            return None
        pair = find_enclosing_pair(node)
        if pair is None:
            return None
        key_range = extract_key_range(pair)
        is_value = is_on_value_side(node, pair)
        return KeyContext.from_path(dotted, key_range, is_value_position=is_value)


def find_line_pair_context(
    container: tree_sitter.Node, source: bytes, line: int, col: int
) -> KeyContext | None:
    """Find the closest pair whose key starts on *line* within a container node.

    When the cursor is on whitespace after ``key: ``, tree-sitter returns
    the parent container (block_mapping).  This searches the container's
    pair children for one on the same line, then builds a value-position
    context from it.  Walks up through intermediate containers (block_node,
    block_sequence_item) to find mappings.
    """
    mapping = enclosing_mapping(container)
    if mapping is None:
        return None
    best = closest_pair_on_line(mapping, line, col)
    if best is None:
        return None
    return context_from_pair_key(best, source)


def enclosing_mapping(container: tree_sitter.Node) -> tree_sitter.Node | None:
    """Walk up to the nearest block or flow mapping."""
    current: tree_sitter.Node | None = container
    while current is not None and current.type not in ("block_mapping", "flow_mapping"):
        current = current.parent
    return current


def closest_pair_on_line(mapping: tree_sitter.Node, line: int, col: int) -> tree_sitter.Node | None:
    """Return the right-most pair child that starts on *line* before *col*."""
    best: tree_sitter.Node | None = None
    for child in mapping.children:
        if child.type in PAIR_TYPES and child.start_point[0] == line and child.start_point[1] <= col:
            best = child
    return best


def context_from_pair_key(pair: tree_sitter.Node, source: bytes) -> KeyContext | None:
    """Build a value-position key context from a mapping pair's key."""
    named = pair.named_children
    if not named:
        return None
    key_child = find_leaf_scalar(named[0]) or named[0]
    dotted = walk_to_dotted_path(key_child, source)
    if dotted is None:
        return None
    key_range = extract_key_range(pair)
    return KeyContext.from_path(dotted, key_range, is_value_position=True)


def find_enclosing_pair(node: tree_sitter.Node) -> tree_sitter.Node | None:
    """Walk up from *node* to find the nearest block_mapping_pair or flow_pair."""
    current: tree_sitter.Node | None = node
    while current is not None:
        if current.type in PAIR_TYPES:
            return current
        current = current.parent
    return None


def is_on_value_side(node: tree_sitter.Node, pair: tree_sitter.Node) -> bool:
    """Check whether *node* sits on the value side of a mapping pair.

    Handles three cases:
    1. Cursor is a descendant of the pair's second named child (the value).
    2. Cursor is on the colon separator or whitespace after it (no value node).
    3. Cursor is past the key on the same line (e.g. after colon, before newline).
    """
    named = pair.named_children
    key_value_pair_size = 2
    if len(named) >= key_value_pair_size:
        value_node = named[1]
        # Check if cursor node is the value node or a descendant of it
        current: tree_sitter.Node | None = node
        while current is not None:
            if current.id == value_node.id:
                return True
            current = current.parent
    # No value child, or cursor isn't in it — check if past the key
    if named:
        key_node = named[0]
        if node.start_point[0] == key_node.start_point[0] and node.start_byte >= key_node.end_byte:
            return True
    return False


def extract_key_range(pair: tree_sitter.Node) -> TextRange:
    """Extract the TextRange of the key token from a mapping pair (1-indexed)."""
    named = pair.named_children
    if not named:
        row = pair.start_point[0]
        col = pair.start_point[1]
        return TextRange(start_line=row + 1, start_col=col + 1, end_line=row + 1, end_col=col + 2)
    key_node = named[0]
    leaf = find_leaf_scalar(key_node)
    target = leaf if leaf is not None else key_node
    return TextRange(
        start_line=target.start_point[0] + 1,
        start_col=target.start_point[1] + 1,
        end_line=target.end_point[0] + 1,
        end_col=target.end_point[1] + 1,
    )


def find_sequence_index(sequence: tree_sitter.Node, child: tree_sitter.Node) -> int:
    """Find the index of *child* within a sequence node's named children."""
    for idx, sibling in enumerate(sequence.named_children):
        if sibling.id == child.id:
            return idx
        if sibling.type == "block_sequence_item" and any(
            grandchild.id == child.id for grandchild in sibling.named_children
        ):
            return idx
    return 0


def extract_pair_key(pair: tree_sitter.Node, source: bytes) -> str | None:
    """Extract the key text from a mapping pair node."""
    named = pair.named_children
    if not named:
        return None
    key_leaf = find_leaf_scalar(named[0])
    return node_text(key_leaf, source) if key_leaf else node_text(named[0], source)


SEQUENCE_NODE_TYPES = frozenset({"block_sequence", "flow_sequence"})


def walk_to_dotted_path(node: tree_sitter.Node, source: bytes) -> str | None:
    """Walk up from a cursor node through the CST parent chain to build a dotted path.

    Returns the dotted path (e.g. ``"schema.0.name"``) or ``None`` if the node
    is not inside a mapping structure.
    """
    parts: list[str] = []
    current: tree_sitter.Node | None = node

    while current is not None:
        parent = current.parent
        if parent is None:
            break

        if parent.type in PAIR_TYPES:
            if (key_text := extract_pair_key(parent, source)) is not None:
                parts.append(key_text)
        elif parent.type in SEQUENCE_NODE_TYPES:
            parts.append(str(find_sequence_index(parent, current)))

        current = parent

    if not parts:
        return None
    parts.reverse()
    return ".".join(parts)
