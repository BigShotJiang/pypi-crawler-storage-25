"""OTEL semantic conventions for Turbine telemetry."""

from __future__ import annotations

from enum import StrEnum


class SpanNames(StrEnum):
    """Standard span names for Turbine telemetry."""

    SESSION = "turbine.session"
    CHECK_COMMAND = "turbine.check_command"
    CHECK_RUN = "turbine.check_run"
    LINT = "turbine.lint"
    DATASOURCE_CONNECT = "turbine.datasource_connect"
    VALIDATE_SCHEMA = "turbine.validate_schema"
    LOAD_CONTRACT = "turbine.load_contract"
    LOAD_DATASOURCE = "turbine.load_datasource"
    PUBLISH_CONTRACT = "turbine.publish_contract"
    FLAGGING = "turbine.flagging"
