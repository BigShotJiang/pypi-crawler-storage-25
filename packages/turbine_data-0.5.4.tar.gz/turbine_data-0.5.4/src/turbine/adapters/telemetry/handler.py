"""Single telemetry handler driving spans from domain events via the catalog.

TelemetryEventHandler is a thin dispatcher: each incoming domain event is
looked up in SPAN_MAPPINGS and translated into one or more SpanTracer calls.
No per-handler open-span state. No logfire import.

register_telemetry_handler wires the handler into an InMemoryEventBus by
iterating the catalog and subscribing once per (opened_by, closed_by, failed_by)
event type.
"""

from __future__ import annotations

from collections.abc import Callable, Sequence
from typing import Protocol

from turbine.core.building_blocks import DomainEvent

from .mapping import SPAN_MAPPINGS, SpanMapping
from .ports import SpanTracer


class EventSubscriber(Protocol):
    """Structural protocol for event buses that accept typed subscriptions.

    Defined inline so the telemetry adapter does not depend on
    ``turbine.infra.events`` directly.
    """

    def subscribe[E: DomainEvent](self, event_type: type[E], handler: Callable[[E], None]) -> None:
        """Wire *handler* to be called when events of *event_type* are published."""
        ...


class TelemetryEventHandler:
    """Translates domain events into SpanTracer calls using a mapping catalog.

    The handler holds no span state itself; the tracer owns the lifecycle
    registry. Same handler instance can be reused across runs safely because
    RunStarted clears failed-check bookmarks via the tracer.
    """

    def __init__(self, tracer: SpanTracer, mappings: Sequence[SpanMapping] = SPAN_MAPPINGS) -> None:
        """Wire the handler to *tracer*, indexing *mappings* by event type."""
        self.tracer = tracer
        self.open_by_event: dict[type[DomainEvent], SpanMapping] = {
            mapping.opened_by: mapping for mapping in mappings
        }
        self.close_by_event: dict[type[DomainEvent], SpanMapping] = {}
        for mapping in mappings:
            for event_type in close_event_types(mapping):
                self.close_by_event[event_type] = mapping
        self.fail_by_event: dict[type[DomainEvent], SpanMapping] = {
            mapping.failed_by: mapping for mapping in mappings if mapping.failed_by is not None
        }

    def handle_open(self, event: DomainEvent) -> None:
        """Open the span bound to *event* via its mapping, if any."""
        mapping = self.open_by_event.get(type(event))
        if mapping is None:
            return
        if mapping.clears_failed_check_bookmarks_on_open:
            self.tracer.clear_failed_check_bookmarks()
        attributes = mapping.open_attrs(event)
        self.tracer.open_span(
            mapping.key, mapping.name, attributes, link_failed_checks=mapping.link_mode
        )

    def handle_close(self, event: DomainEvent) -> None:
        """Close the span bound to *event*, emitting span events and bookmarks."""
        mapping = self.close_by_event.get(type(event))
        if mapping is None:
            return
        for span_event_name, span_event_attrs in mapping.close_span_events(event):
            self.tracer.add_span_event(mapping.key, span_event_name, span_event_attrs)
        marks_failed = mapping.close_marks_failed_check is not None and mapping.close_marks_failed_check(
            event
        )
        self.tracer.close_span(
            mapping.key, mapping.close_attrs(event), mark_as_failed_check=marks_failed
        )

    def handle_fail(self, event: DomainEvent) -> None:
        """Close the span bound to *event* with an error built from its fields."""
        mapping = self.fail_by_event.get(type(event))
        if mapping is None:
            return
        error_type = getattr(event, "error_type", "Error")
        error_message = getattr(event, "error_message", "")
        error = Exception(f"{error_type}: {error_message}")
        self.tracer.close_span_with_error(mapping.key, error)


def register_telemetry_handler(
    bus: EventSubscriber, tracer: SpanTracer, mappings: Sequence[SpanMapping] = SPAN_MAPPINGS
) -> TelemetryEventHandler:
    """Build a TelemetryEventHandler and subscribe it to *bus* for every mapping.

    Returns the handler so callers that want to inspect or manually dispatch
    can keep a reference.
    """
    handler = TelemetryEventHandler(tracer, mappings)
    for mapping in mappings:
        bus.subscribe(mapping.opened_by, handler.handle_open)
        for event_type in close_event_types(mapping):
            bus.subscribe(event_type, handler.handle_close)
        if mapping.failed_by is not None:
            bus.subscribe(mapping.failed_by, handler.handle_fail)
    return handler


def close_event_types(mapping: SpanMapping) -> tuple[type[DomainEvent], ...]:
    """Return the event types that close *mapping*'s span."""
    if isinstance(mapping.closed_by, tuple):
        return mapping.closed_by
    return (mapping.closed_by,)
