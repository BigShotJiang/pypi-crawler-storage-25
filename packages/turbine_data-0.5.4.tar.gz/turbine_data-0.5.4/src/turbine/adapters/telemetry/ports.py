"""Telemetry ports -- the SpanTracer protocol.

This lives in the adapter layer because no core domain logic depends on it.
Its only consumer is TelemetryEventHandler, which is also an adapter.

The tracer owns all span lifecycle state: the open-span registry, failed-check
bookmarks for cross-span linking, everything. Handlers are stateless dispatchers
that translate domain events into tracer calls.
"""

from __future__ import annotations

from collections.abc import Mapping
from enum import Enum, auto
from typing import TYPE_CHECKING, Any, Literal, Protocol

if TYPE_CHECKING:
    pass

# How a span opening should interact with failed-check bookmarks:
# - "none": ignore bookmarks, open unconditionally.
# - "link": attach bookmarked span contexts as OTEL links, open unconditionally.
# - "link_or_skip": same as "link", but silently do nothing if no bookmarks exist.
type LinkMode = Literal["none", "link", "link_or_skip"]


class SpanKey(Enum):
    """Stable identifiers for concurrently-open spans inside the tracer."""

    SESSION = auto()
    CHECK_COMMAND = auto()
    CHECK_RUN = auto()
    CONTRACT_LOAD = auto()
    DATASOURCE_LOAD = auto()
    LINT = auto()
    PUBLISH = auto()
    VALIDATE = auto()
    FLAGGING = auto()


class SpanTracer(Protocol):
    """Port for span lifecycle operations.

    Implementations own the open-span registry and any bookkeeping needed for
    cross-span linking (failed-check bookmarks). This decouples handlers from a
    specific tracing backend: swap the implementation, swap the backend.
    """

    def open_span(
        self,
        key: SpanKey,
        name: str,
        attributes: Mapping[str, Any],
        *,
        link_failed_checks: LinkMode = "none",
    ) -> None:
        """Open a span identified by *key* with *name* and *attributes*.

        If *link_failed_checks* is ``"link"`` or ``"link_or_skip"``, any failed-check
        bookmarks currently held by the tracer are attached as OTEL span links and
        then consumed. In ``"link_or_skip"`` mode the span is silently omitted when
        no bookmarks exist.
        """
        ...

    def close_span(
        self,
        key: SpanKey,
        attributes: Mapping[str, Any] | None = None,
        *,
        mark_as_failed_check: bool = False,
    ) -> None:
        """Close a previously-opened span, optionally adding final *attributes*.

        If *mark_as_failed_check* is true, the closing span's context is saved as a
        failed-check bookmark so that a subsequent ``link_failed_checks`` open can
        pick it up. No-op if *key* has no open span.
        """
        ...

    def close_span_with_error(self, key: SpanKey, error: BaseException) -> None:
        """Close a previously-opened span with exception information attached.

        No-op if *key* has no open span.
        """
        ...

    def add_span_event(self, key: SpanKey, name: str, attributes: Mapping[str, Any]) -> None:
        """Attach an OTEL span event (not an attribute) to the span at *key*.

        Used for oversize fields like SQL queries that should not live on the
        attribute map. No-op if *key* has no open span.
        """
        ...

    def clear_failed_check_bookmarks(self) -> None:
        """Discard all currently-held failed-check bookmarks.

        Called at the start of a fresh verification so that a previous run's
        failures do not leak into the next run's flagging links.
        """
        ...
