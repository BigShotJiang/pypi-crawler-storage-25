"""Telemetry adapters -- tracing and OTEL conventions.

Logfire-dependent classes (LogfireSpanTracer, TelemetryConfig,
init_telemetry, TelemetryEventHandler) are imported lazily so the LSP and
CLI can start without paying for logfire. Ports, conventions, and SpanKey
are always available.
"""

from .conventions import SpanNames
from .ports import SpanKey, SpanTracer

_LAZY_IMPORTS: dict[str, tuple[str, str]] = {
    "LogfireSpanTracer": (".logfire_tracer", "LogfireSpanTracer"),
    "TelemetryConfig": (".provider", "TelemetryConfig"),
    "build_telemetry_config": (".provider", "build_telemetry_config"),
    "init_telemetry": (".provider", "init_telemetry"),
    "TelemetryEventHandler": (".handler", "TelemetryEventHandler"),
    "register_telemetry_handler": (".handler", "register_telemetry_handler"),
    "SpanMapping": (".mapping", "SpanMapping"),
    "SPAN_MAPPINGS": (".mapping", "SPAN_MAPPINGS"),
}


def __getattr__(name: str) -> object:
    entry = _LAZY_IMPORTS.get(name)
    if entry is None:
        raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
    module_path, attr = entry
    import importlib  # noqa: PLC0415

    module = importlib.import_module(module_path, __name__)
    return getattr(module, attr)


__all__ = [
    "SPAN_MAPPINGS",
    "LogfireSpanTracer",
    "SpanKey",
    "SpanMapping",
    "SpanNames",
    "SpanTracer",
    "TelemetryConfig",
    "TelemetryEventHandler",
    "build_telemetry_config",
    "init_telemetry",
    "register_telemetry_handler",
]
