"""Telemetry provider — initializes logfire and OTEL auto-instrumentation."""

from __future__ import annotations

import contextlib
import importlib
import os
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Protocol, cast

import logfire

TURBINE_NAMESPACE = "turbine"


class TelemetryProject(Protocol):
    """Project identity shape needed to build telemetry config."""

    project_name: str | None
    project_version: str | None


class TelemetrySettings(Protocol):
    """Telemetry settings shape needed to build telemetry config."""

    team: str | None
    environment: str | None


@dataclass(frozen=True, slots=True, kw_only=True)
class TelemetryConfig:
    """Configuration for telemetry initialization.

    service.namespace is always hardcoded to "turbine"; all other identity
    fields come from the ProjectRoot / TurbineConfig and are threaded through
    build_telemetry_config at the composition root.
    """

    enabled: bool = True
    endpoint: str | None = None
    project_name: str | None = None
    project_version: str | None = None
    team: str | None = None
    environment: str | None = None
    debug: bool = False


def init_telemetry(config: TelemetryConfig) -> None:
    """Initialize logfire + OTEL. Call once at startup from the composition root."""
    if not config.enabled:
        return

    set_resource_attributes(config)

    if not config.endpoint and not config.debug:
        logfire.configure(send_to_logfire=False, console=False)
        return

    if config.endpoint:
        os.environ.setdefault("OTEL_EXPORTER_OTLP_ENDPOINT", config.endpoint)

    logfire.configure(
        service_name=config.project_name or TURBINE_NAMESPACE,
        service_version=config.project_version,
        send_to_logfire=False,
        console=None if config.debug else False,
        inspect_arguments=False,
    )

    logfire.instrument_psycopg()
    logfire.instrument_sqlalchemy()
    logfire.instrument_pydantic()
    with contextlib.suppress(RuntimeError):
        logfire.instrument_system_metrics()

    with contextlib.suppress(ImportError):
        sf = importlib.import_module("snowflake.connector")
        otel_dbapi = importlib.import_module("opentelemetry.instrumentation.dbapi")
        otel_dbapi.trace_integration(cast(Callable[..., Any], sf), "connect", "snowflake")


def set_resource_attributes(config: TelemetryConfig) -> None:
    """Build and export OTEL_RESOURCE_ATTRIBUTES for this Turbine invocation."""
    attributes: dict[str, str] = {"service.namespace": TURBINE_NAMESPACE}
    if config.team:
        attributes["turbine.team"] = config.team
    if config.environment:
        attributes["turbine.environment"] = config.environment
    os.environ["OTEL_RESOURCE_ATTRIBUTES"] = ",".join(
        f"{key}={value}" for key, value in attributes.items()
    )


def build_telemetry_config(
    *, project_root: TelemetryProject, turbine_config: TelemetrySettings, debug: bool = False
) -> TelemetryConfig:
    """Thread ProjectRoot + TurbineConfig identity into a TelemetryConfig."""
    return TelemetryConfig(
        project_name=project_root.project_name,
        project_version=project_root.project_version,
        team=turbine_config.team,
        environment=turbine_config.environment,
        debug=debug,
    )
