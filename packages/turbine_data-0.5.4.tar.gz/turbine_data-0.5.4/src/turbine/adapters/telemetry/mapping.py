"""Declarative event-to-span mapping driving the telemetry handler.

Each SpanMapping binds one span lifecycle (open, close, optional fail) to a
triple of domain event types and describes how to extract attributes, span
events, and failed-check bookmarks from them. SPAN_MAPPINGS is the full catalog
consumed by TelemetryEventHandler.

Adding a new span type to Turbine telemetry is a data change: add one entry
here. No handler code needs to move.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass, field
from typing import Any

from turbine.core.building_blocks import DomainEvent
from turbine.core.common.events import SessionCompleted, SessionFailed, SessionStarted
from turbine.core.contract.events import (
    ContractLinted,
    ContractLintStarted,
    ContractLoaded,
    ContractLoadStarted,
    ContractPublished,
    ContractPublishStarted,
    DatasourceLoaded,
    DatasourceLoadStarted,
)
from turbine.core.quality import CheckOutcome
from turbine.core.quality.events import (
    CheckCompleted,
    CheckErrored,
    CheckStarted,
    FlaggingCompleted,
    FlaggingStarted,
    RunAborted,
    RunCompleted,
    RunStarted,
)
from turbine.core.validation.events import SchemaValidationDetected, ValidationStarted

from .conventions import SpanNames
from .ports import LinkMode, SpanKey


def default_attrs(event: DomainEvent) -> Mapping[str, Any]:
    """Flat alias-keyed attribute dict from the event's pydantic serialization."""
    return event.model_dump(mode="json", by_alias=True, exclude_none=True)


def no_events(event: DomainEvent) -> Sequence[tuple[str, Mapping[str, Any]]]:  # noqa: ARG001
    """Span-event extractor that returns nothing."""
    return ()


def terminal_check_attrs(event: DomainEvent) -> Mapping[str, Any]:
    """Terminal check attributes with CheckCompleted nested fields flattened."""
    if isinstance(event, CheckErrored):
        return event.model_dump(mode="json", by_alias=True, exclude_none=True)
    assert isinstance(event, CheckCompleted)
    attrs = event.model_dump(
        mode="json", by_alias=True, exclude_none=True, exclude={"threshold", "numeric_diagnostics"}
    )
    if event.threshold is not None:
        attrs.update(event.threshold.to_telemetry())
    return attrs


def terminal_check_is_failure(event: DomainEvent) -> bool:
    """Return True when the terminal check event represents a failing check."""
    if isinstance(event, CheckErrored):
        return True
    assert isinstance(event, CheckCompleted)
    return event.outcome == CheckOutcome.FAILED


@dataclass(frozen=True, kw_only=True, slots=True)
class SpanMapping:
    """Static description of a single span lifecycle driven by domain events."""

    key: SpanKey
    name: str
    opened_by: type[DomainEvent]
    closed_by: type[DomainEvent] | tuple[type[DomainEvent], ...]
    failed_by: type[DomainEvent] | None = None
    open_attrs: Callable[[DomainEvent], Mapping[str, Any]] = field(default=default_attrs)
    close_attrs: Callable[[DomainEvent], Mapping[str, Any]] = field(default=default_attrs)
    close_span_events: Callable[[DomainEvent], Sequence[tuple[str, Mapping[str, Any]]]] = field(
        default=no_events
    )
    close_marks_failed_check: Callable[[DomainEvent], bool] | None = None
    link_mode: LinkMode = "none"
    clears_failed_check_bookmarks_on_open: bool = False


SPAN_MAPPINGS: tuple[SpanMapping, ...] = (
    SpanMapping(
        key=SpanKey.SESSION,
        name=SpanNames.SESSION,
        opened_by=SessionStarted,
        closed_by=SessionCompleted,
        failed_by=SessionFailed,
    ),
    SpanMapping(
        key=SpanKey.CHECK_COMMAND,
        name=SpanNames.CHECK_COMMAND,
        opened_by=RunStarted,
        closed_by=RunCompleted,
        failed_by=RunAborted,
        clears_failed_check_bookmarks_on_open=True,
    ),
    SpanMapping(
        key=SpanKey.CHECK_RUN,
        name=SpanNames.CHECK_RUN,
        opened_by=CheckStarted,
        closed_by=(CheckCompleted, CheckErrored),
        close_attrs=terminal_check_attrs,
        close_marks_failed_check=terminal_check_is_failure,
    ),
    SpanMapping(
        key=SpanKey.CONTRACT_LOAD,
        name=SpanNames.LOAD_CONTRACT,
        opened_by=ContractLoadStarted,
        closed_by=ContractLoaded,
    ),
    SpanMapping(
        key=SpanKey.DATASOURCE_LOAD,
        name=SpanNames.DATASOURCE_CONNECT,
        opened_by=DatasourceLoadStarted,
        closed_by=DatasourceLoaded,
    ),
    SpanMapping(
        key=SpanKey.LINT, name=SpanNames.LINT, opened_by=ContractLintStarted, closed_by=ContractLinted
    ),
    SpanMapping(
        key=SpanKey.PUBLISH,
        name=SpanNames.PUBLISH_CONTRACT,
        opened_by=ContractPublishStarted,
        closed_by=ContractPublished,
    ),
    SpanMapping(
        key=SpanKey.VALIDATE,
        name=SpanNames.VALIDATE_SCHEMA,
        opened_by=ValidationStarted,
        closed_by=SchemaValidationDetected,
    ),
    SpanMapping(
        key=SpanKey.FLAGGING,
        name=SpanNames.FLAGGING,
        opened_by=FlaggingStarted,
        closed_by=FlaggingCompleted,
        link_mode="link_or_skip",
    ),
)
