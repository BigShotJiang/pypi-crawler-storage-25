"""Logfire-backed implementation of the SpanTracer port.

The tracer owns everything stateful: the dict of open spans keyed by SpanKey,
the open span stack used to preserve parent/child relationships, and the list of
failed-check span contexts that get consumed as OTEL links when the flagging span
opens. Handlers hold no span state.
"""

from __future__ import annotations

from collections.abc import Mapping
from contextvars import Token
from typing import Any, cast

import logfire
from opentelemetry import context as context_api
from opentelemetry.context.context import Context
from opentelemetry.trace import Span, Status, StatusCode, set_span_in_context
from opentelemetry.trace.span import SpanContext
from opentelemetry.util.types import AttributeValue

from .ports import LinkMode, SpanKey, SpanTracer

type ContextToken = Token[Context]


class LogfireSpanTracer(SpanTracer):
    """SpanTracer backed by ``logfire.span``, owning span state + link bookmarks."""

    def __init__(self) -> None:
        """Start with no open spans and no failed-check bookmarks."""
        self.spans: dict[SpanKey, logfire.LogfireSpan] = {}
        self.open_stack: list[SpanKey] = []
        self.failed_check_bookmarks: list[SpanContext] = []

    def open_span(
        self,
        key: SpanKey,
        name: str,
        attributes: Mapping[str, Any],
        *,
        link_failed_checks: LinkMode = "none",
    ) -> None:
        """Create and store a span without leaving it attached to contextvars."""
        if link_failed_checks == "link_or_skip" and not self.failed_check_bookmarks:
            return
        span_kwargs: dict[str, Any] = dict(attributes)
        if link_failed_checks != "none" and self.failed_check_bookmarks:
            span_kwargs["_links"] = [(ctx, {}) for ctx in self.failed_check_bookmarks]
            self.failed_check_bookmarks.clear()
        parent_token = attach_parent_span(self.current_span())
        try:
            span = logfire.span(name, **span_kwargs)
            span.__enter__()
            detach_span(span)
        finally:
            detach_context(parent_token)
        self.spans[key] = span
        self.open_stack.append(key)

    def close_span(
        self,
        key: SpanKey,
        attributes: Mapping[str, Any] | None = None,
        *,
        mark_as_failed_check: bool = False,
    ) -> None:
        """Set final *attributes*, bookmark on failure, then exit the span."""
        span = self.pop_span(key)
        if span is None:
            return
        if attributes:
            for attr_name, attr_value in attributes.items():
                span.set_attribute(attr_name, attr_value)
        if mark_as_failed_check and (ctx := span.context):
            self.failed_check_bookmarks.append(ctx)
        span.__exit__(None, None, None)

    def close_span_with_error(self, key: SpanKey, error: BaseException) -> None:
        """Exit the span at *key* with exception information attached."""
        span = self.pop_span(key)
        if span is None:
            return
        otel_span = logfire_otel_span(span)
        if otel_span is not None:
            otel_span.record_exception(error)
            otel_span.set_status(Status(StatusCode.ERROR, str(error)))
        span.__exit__(None, None, None)

    def add_span_event(self, key: SpanKey, name: str, attributes: Mapping[str, Any]) -> None:
        """Attach an OTEL span event to the span at *key*."""
        span = self.spans.get(key)
        if span is None:
            return
        otel_span = logfire_otel_span(span)
        if otel_span is None:
            return
        otel_span.add_event(name, telemetry_attributes(attributes))

    def clear_failed_check_bookmarks(self) -> None:
        """Drop all failed-check bookmarks so the next run starts clean."""
        self.failed_check_bookmarks.clear()

    def current_span(self) -> logfire.LogfireSpan | None:
        """Return the most recently-opened live span."""
        while self.open_stack:
            key = self.open_stack[-1]
            span = self.spans.get(key)
            if span is not None:
                return span
            self.open_stack.pop()
        return None

    def pop_span(self, key: SpanKey) -> logfire.LogfireSpan | None:
        """Remove a span and its stack entry."""
        span = self.spans.pop(key, None)
        if span is None:
            return None
        if self.open_stack and self.open_stack[-1] is key:
            self.open_stack.pop()
            return span
        self.open_stack = [open_key for open_key in self.open_stack if open_key is not key]
        return span


def attach_parent_span(span: logfire.LogfireSpan | None) -> ContextToken | None:
    """Temporarily attach *span* so a child starts with the right parent."""
    if span is None:
        return None
    otel_span = logfire_otel_span(span)
    if otel_span is None:
        return None
    return context_api.attach(set_span_in_context(otel_span))


def detach_span(span: logfire.LogfireSpan) -> None:
    """Detach a just-started Logfire span in the same context it was attached."""
    token = cast(ContextToken | None, getattr(span, "_token", None))
    if token is None:
        return
    context_api.detach(token)
    object.__setattr__(span, "_token", None)


def detach_context(token: ContextToken | None) -> None:
    """Detach an explicitly-attached parent context."""
    if token is None:
        return
    context_api.detach(token)


def logfire_otel_span(span: logfire.LogfireSpan) -> Span | None:
    """Return the wrapped OTEL span from a Logfire span."""
    return cast(Span | None, getattr(span, "_span", None))


def telemetry_attributes(attributes: Mapping[str, Any]) -> dict[str, AttributeValue]:
    """Coerce arbitrary domain attributes into OTEL-compatible attribute values."""
    coerced: dict[str, AttributeValue] = {}
    for key, value in attributes.items():
        attribute = telemetry_attribute(value)
        if attribute is not None:
            coerced[key] = attribute
    return coerced


def telemetry_attribute(value: Any) -> AttributeValue | None:
    """Coerce one value into an OTEL-compatible attribute value."""
    if value is None:
        return None
    if isinstance(value, str | bool | int | float):
        return value
    return str(value)
