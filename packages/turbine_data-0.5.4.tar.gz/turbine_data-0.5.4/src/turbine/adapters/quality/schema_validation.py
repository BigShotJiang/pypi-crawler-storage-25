"""QualitySpec-specific schema validation context — display context and valid fields.

ContextTracker, resolve_display_context, valid_fields_for_path are used by
FormatDescriptor to customize validation error messages for QualitySpec files.
"""

from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from functools import lru_cache
from typing import Any

from turbine.core.common import FIELD_NAME, resolve_at_path

from .schema_catalog import load_quality_spec_schema


@dataclass(slots=True)
class ContextTracker:
    """Accumulates column and check names while walking a QualitySpec YAML path."""

    column_name: str | None = None
    check_type: str | None = None

    def track_column(self, item: dict[str, object]) -> None:
        """Record the column name if the item has a 'name' key."""
        name = item.get(FIELD_NAME)
        if isinstance(name, str):
            self.column_name = name

    def track_check(self, item: dict[str, object]) -> None:
        """Record the check type (the single key of a check_item dict)."""
        if item:
            self.check_type = next(iter(item))

    def format(self) -> str:
        """Format the accumulated names into a label like 'check `row_count` in column `age`'."""
        if self.check_type and self.column_name:
            return f"check `{self.check_type}` in column `{self.column_name}`"
        if self.check_type:
            return f"check `{self.check_type}`"
        if self.column_name:
            return f"column `{self.column_name}`"
        return ""


def step_into(current: Any, key: str | int) -> Any:
    """Take one step into a nested structure, returning None if the step fails."""
    if isinstance(key, str) and isinstance(current, dict):
        return current.get(key)
    if isinstance(key, int) and isinstance(current, list) and key < len(current):
        return current[key]
    return None


def resolve_display_context(data: dict[str, Any], path: Iterable[str | int]) -> str:
    """Walk QualitySpec YAML data along a validation error's path.

    Produces labels like 'check `row_count` in column `age`'.
    """
    current: Any = data
    tracker = ContextTracker()
    path_list = list(path)

    for depth, key in enumerate(path_list):
        current = step_into(current, key)
        if current is None:
            break
        if not isinstance(key, int) or not isinstance(current, dict) or depth == 0:
            continue
        prev_key = path_list[depth - 1]
        match prev_key:
            case "columns":
                tracker.track_column(current)
            case "checks" | "quality":
                tracker.track_check(current)

    return tracker.format()


def valid_fields_for_path(path: Sequence[str | int]) -> list[str]:
    """Look up the JSON Schema at a given error path and return the sorted valid child field names."""
    return cached_quality_fields(".".join(str(p) for p in path))


@lru_cache(maxsize=256)
def cached_quality_fields(dotted: str) -> list[str]:
    """Look up valid child field names at a dotted schema path, with LRU caching."""
    node = resolve_at_path(dotted, load_quality_spec_schema())
    return sorted(node.children.keys())
