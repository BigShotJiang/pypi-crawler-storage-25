"""Dialect capability descriptors: size/overflow knobs and slice-7e column-fetch shape.

One ``DialectCapabilities`` per supported backend. sqlglot transpiles the
``FILTER (WHERE)``, ``ARRAY_AGG``, and ``QUANTILE_CONT`` constructs to the
target dialect automatically; the renderer therefore needs to know only the
overflow threshold (``pk_cap``), the statement-size cap (``max_sql_len``),
and the ``column_fetch`` shape reserved for slice 7e.
"""

from dataclasses import dataclass
from enum import StrEnum
from typing import Final

from turbine.core.common.datasource_type import DataSourceType


class ColumnFetchShape(StrEnum):
    """How the dialect streams a full column back (reserved for slice 7e)."""

    NATIVE_ITER = "native_iter"
    SERVER_SIDE_CURSOR = "server_side_cursor"
    RESULT_SCAN_ARROW = "result_scan_arrow"


@dataclass(frozen=True, slots=True)
class DialectCapabilities:
    """Per-dialect knobs that drive plan splitting and overflow policy."""

    dialect: DataSourceType
    max_sql_len: int | None
    pk_cap: int | None
    column_fetch: ColumnFetchShape


DUCKDB_CAPS: Final = DialectCapabilities(
    dialect=DataSourceType.DUCKDB,
    max_sql_len=None,
    pk_cap=1_000_000,
    column_fetch=ColumnFetchShape.NATIVE_ITER,
)

POSTGRES_CAPS: Final = DialectCapabilities(
    dialect=DataSourceType.POSTGRES,
    max_sql_len=1_000_000,
    pk_cap=1_000_000,
    column_fetch=ColumnFetchShape.SERVER_SIDE_CURSOR,
)

SNOWFLAKE_CAPS: Final = DialectCapabilities(
    dialect=DataSourceType.SNOWFLAKE,
    max_sql_len=1_000_000,
    pk_cap=100_000,
    column_fetch=ColumnFetchShape.RESULT_SCAN_ARROW,
)
