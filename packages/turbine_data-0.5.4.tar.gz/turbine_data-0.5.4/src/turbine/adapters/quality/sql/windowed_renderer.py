"""Render a windowed anomaly :class:`DatasetPlan` into a single CTE + tag columns.

Every PkSlot whose predicate is a :class:`WindowedRowFilterPredicate`
contributes its window expressions to one shared ``ds_windowed`` CTE.
The outer SELECT emits the standard PkSlot shape expected by the
executor: ``ARRAY_AGG(pk) FILTER (WHERE criterion) AS <slot_id>`` and
``COUNT(*) FILTER (WHERE criterion) AS count_<slot_id>``.

Two predicates on the same frame spec share the CTE regardless of which
column they target; their criteria simply reference different aliased
window columns.
"""

from __future__ import annotations

from sqlglot import exp

from turbine.core.quality.plan.dataset_plan import DatasetPlan
from turbine.core.quality.plan.predicates import WindowedRowFilterPredicate
from turbine.core.quality.plan.slots import PkSlot

from .dialect_capabilities import DialectCapabilities
from .predicate_renderer import array_agg_filtered_pks, count_filtered, row_count_projection

DS_ALIAS = "ds_windowed"


def render_windowed_plan(plan: DatasetPlan, caps: DialectCapabilities) -> str:
    """Return the full SQL statement rendering *plan*'s anomaly slots."""
    return build_windowed_select(plan, caps).sql(dialect=caps.dialect.value)


def render_windowed_pk_fallback(plan: DatasetPlan, slot: PkSlot, caps: DialectCapabilities) -> str:
    """Stream failing PKs for an overflowed windowed slot.

    Reuses the same ``ds_windowed`` CTE shape as the main plan so the
    criterion can reference the slot's aliased window columns. When the
    plan carries an ``outer_filter`` (incremental anomaly runs), it's
    applied here too so streamed PKs stay inside ``[since, until]``.
    """
    predicate = as_windowed(slot)
    cte = build_windowed_cte(plan, (slot,))
    cols: dict[str, exp.Expr] = {
        name: exp.column(aliased(slot, name)) for name in predicate.window_expressions()
    }
    where = predicate.criterion(cols)
    if plan.outer_filter is not None:
        where = exp.and_(where, plan.outer_filter.ast.copy())
    fallback = (
        exp.Select(expressions=[exp.column(column) for column in slot.pk_columns])
        .from_(exp.to_identifier(DS_ALIAS))
        .where(where)
    )
    return fallback.with_(DS_ALIAS, as_=cte).sql(dialect=caps.dialect.value)


def build_windowed_select(plan: DatasetPlan, caps: DialectCapabilities) -> exp.Expr:
    """Build the sqlglot AST for the anomaly plan SELECT (not yet rendered).

    The output layer applies ``plan.outer_filter`` so incremental runs
    only flag rows inside ``[since, until]`` while the CTE still loads
    enough baseline for LAG/OVER to compute correctly.
    """
    windowed_slots = windowed_pk_slots(plan)
    cte = build_windowed_cte(plan, windowed_slots)
    projections: list[exp.Expr] = [row_count_projection()]
    projections.extend(build_tag_projections(windowed_slots, caps))
    outer = exp.Select(expressions=projections).from_(exp.to_identifier(DS_ALIAS))
    if plan.outer_filter is not None:
        outer = outer.where(plan.outer_filter.ast.copy())
    return outer.with_(DS_ALIAS, as_=cte)


def windowed_pk_slots(plan: DatasetPlan) -> tuple[PkSlot, ...]:
    """Extract every PkSlot whose predicate is a ``WindowedRowFilterPredicate``."""
    return tuple(
        slot
        for slot in plan.slots
        if isinstance(slot, PkSlot) and isinstance(slot.predicate, WindowedRowFilterPredicate)
    )


def build_windowed_cte(plan: DatasetPlan, slots: tuple[PkSlot, ...]) -> exp.Select:
    """Build ``SELECT *, <window_exprs aliased per slot> FROM <table> [WHERE filter]``."""
    table_name = str(plan.dataset)
    projections: list[exp.Expr] = [exp.Star()]
    for slot in slots:
        predicate = as_windowed(slot)
        for name, expression in predicate.window_expressions().items():
            alias = aliased(slot, name)
            projections.append(exp.alias_(expression, alias))
    cte = exp.Select(expressions=projections).from_(table_name)
    if plan.filter is None:
        return cte
    return cte.where(plan.filter.ast.copy())


def build_tag_projections(slots: tuple[PkSlot, ...], caps: DialectCapabilities) -> list[exp.Expr]:
    """Yield ``ARRAY_AGG + COUNT`` projections per slot, tagged by slot id."""
    projections: list[exp.Expr] = []
    for slot in slots:
        predicate = as_windowed(slot)
        cols: dict[str, exp.Expr] = {
            name: exp.column(aliased(slot, name)) for name in predicate.window_expressions()
        }
        criterion = predicate.criterion(cols)
        array_expr = array_agg_filtered_pks(slot.pk_columns, criterion.copy(), caps)
        count_expr = count_filtered(criterion.copy())
        projections.append(exp.alias_(array_expr, slot.id))
        projections.append(exp.alias_(count_expr, f"count_{slot.id}"))
    return projections


def aliased(slot: PkSlot, name: str) -> str:
    """Slot-scoped column alias: two predicates never collide on the same plan."""
    return f"{slot.id}_{name}"


def as_windowed(slot: PkSlot) -> WindowedRowFilterPredicate:
    """Narrow a PkSlot's predicate to the windowed base or raise ``TypeError``."""
    if not isinstance(slot.predicate, WindowedRowFilterPredicate):
        msg = f"slot {slot.id} predicate is not a WindowedRowFilterPredicate"
        raise TypeError(msg)
    return slot.predicate
