r"""``BatchedDatasetWriter``: one chunked SQL upsert per ``(dataset, run)``.

Consumes a :class:`FlagPlan`, collapses every request's cells to one row
per ``(pk_uuid, check_name)`` carrying ``had_flag``, and emits a single
multi-row upsert per chunk. The merge happens server-side: existing
``runs_tested`` / ``runs_flagged`` strings are concatenated with the new
run's values via plain SQL ``||``. No per-row roundtrip and no Python-side
bitmap deserialise/serialise.

Storage format
--------------
``runs_tested`` and ``runs_flagged`` are space-separated ``run_seq``
integers (``"1 5 7"``). The format works portably across PostgreSQL,
DuckDB, and Snowflake — every dialect supports ``||`` for VARCHAR/TEXT
and ``CASE WHEN col = ''`` for the empty-state branch.

Per-run contribution from the writer
------------------------------------
Per ``(pk_uuid, check_name)`` the writer always sends ``runs_tested =
str(run_seq)``. ``runs_flagged`` is ``str(run_seq)`` if any cell for that
key in this run was flagged, else ``""``.

Server-side merge (``ON CONFLICT DO UPDATE`` for PG/DuckDB, ``MERGE INTO
... USING`` for Snowflake)::

    runs_tested  = old || ' ' || new            -- always extends
    runs_flagged = case
        when new = ''  then old                  -- not flagged this run
        when old = ''  then new                  -- first flag for this row
        else old || ' ' || new                   -- accumulating flagged runs

The ``check_fingerprint`` and ``quality_checks`` tables are written by
:class:`SqlCheckMetadataWriter` instead.
"""

from __future__ import annotations

from collections.abc import Sequence
from datetime import datetime

from sqlalchemy import Engine, text

from turbine.core.common import DataSourceType
from turbine.core.quality.flagging_types import CellUpdate, DatasetWriteResult, FlagEntry, FlagPlan

DEFAULT_CHUNK_SIZE = 2_000


class BatchedDatasetWriter:
    """Coalesce every check's flag cells for one dataset into one upsert per chunk."""

    def __init__(
        self,
        engine: Engine,
        dialect: DataSourceType,
        datasource: str,
        schema: str,
        chunk_size: int = DEFAULT_CHUNK_SIZE,
    ) -> None:
        """Bind the metadata-store engine, dialect, datasource scope, schema, and chunk size."""
        self.engine = engine
        self.dialect = dialect
        self.datasource = datasource
        self.schema = schema
        self.chunk_size = chunk_size

    @property
    def matrix_table(self) -> str:
        """Fully qualified ``turbine_flag_matrix`` table reference for the configured schema."""
        return f"{self.schema}.turbine_flag_matrix"

    def write(self, plan: FlagPlan, run_seq: int) -> DatasetWriteResult:
        """Upsert flag cells for *plan*, returning per-check :class:`FlagEntry` outcomes."""
        if not plan.requests:
            return DatasetWriteResult(dataset=plan.dataset, rows_flagged=0, entries=())

        self.upsert_cells(plan.dataset, plan.all_cells, run_seq)

        entries = tuple(
            FlagEntry(
                check_name=request.check.name,
                rows_flagged=len({cell.pk_uuid for cell in request.cells}),
                total_failing=request.total_failing,
                streaming=request.streaming,
            )
            for request in plan.requests
        )
        rows_flagged = sum(entry.rows_flagged for entry in entries)
        return DatasetWriteResult(dataset=plan.dataset, rows_flagged=rows_flagged, entries=entries)

    def upsert_cells(self, dataset: str, cells: Sequence[CellUpdate], run_seq: int) -> None:
        """Build per-key rows and flush them in chunked upserts."""
        if not cells:
            return
        rows = build_cell_rows(self.datasource, dataset, cells, run_seq, datetime.now())  # noqa: DTZ005 - DB uses TIMESTAMP WITHOUT TIME ZONE
        for start in range(0, len(rows), self.chunk_size):
            chunk = rows[start : start + self.chunk_size]
            self.flush_chunk(chunk)

    def flush_chunk(self, rows: list[dict[str, object]]) -> None:
        """Dialect-dispatched single-statement upsert of an already-coalesced chunk."""
        if not rows:
            return
        if self.engine.dialect.name == "snowflake":
            self.merge_chunk_snowflake(rows)
            return
        self.upsert_chunk_on_conflict(rows)

    def upsert_chunk_on_conflict(self, rows: list[dict[str, object]]) -> None:
        """PostgreSQL / DuckDB ``INSERT ... ON CONFLICT DO UPDATE`` — one statement per chunk."""
        values_clause, params = build_values_clause(rows)
        stmt = text(
            f"INSERT INTO {self.matrix_table} "
            "(datasource, dataset, pk_uuid, check_name, runs_tested, runs_flagged, "
            "first_tested_at, last_tested_at, last_flagged_at) "
            f"VALUES {values_clause} "
            "ON CONFLICT (datasource, dataset, pk_uuid, check_name) DO UPDATE SET "
            f"runs_tested = {self.matrix_table}.runs_tested || ' ' || EXCLUDED.runs_tested, "
            "runs_flagged = CASE "
            "WHEN EXCLUDED.runs_flagged = '' "
            f"THEN {self.matrix_table}.runs_flagged "
            f"WHEN {self.matrix_table}.runs_flagged = '' "
            "THEN EXCLUDED.runs_flagged "
            f"ELSE {self.matrix_table}.runs_flagged || ' ' || EXCLUDED.runs_flagged "
            "END, "
            "last_tested_at = EXCLUDED.last_tested_at, "
            f"last_flagged_at = COALESCE(EXCLUDED.last_flagged_at, {self.matrix_table}.last_flagged_at)"
        )
        with self.engine.begin() as conn:
            conn.execute(stmt, params)

    def merge_chunk_snowflake(self, rows: list[dict[str, object]]) -> None:
        """Snowflake ``MERGE INTO ... USING`` — one statement per chunk via UNION ALL source rows."""
        select_clauses = []
        params: dict[str, object] = {}
        for index, row in enumerate(rows):
            select_clauses.append(
                f"SELECT :datasource_{index} AS datasource, :dataset_{index} AS dataset, "
                f":pk_{index} AS pk_uuid, :check_{index} AS check_name, "
                f":runs_tested_{index} AS runs_tested, :runs_flagged_{index} AS runs_flagged, "
                f":first_at_{index} AS first_tested_at, :last_at_{index} AS last_tested_at, "
                f":flagged_at_{index} AS last_flagged_at"
            )
            params.update(row_params(index, row))
        source_select = " UNION ALL ".join(select_clauses)
        stmt = text(
            f"MERGE INTO {self.matrix_table} AS target "
            f"USING ({source_select}) AS source "
            "ON target.datasource = source.datasource AND target.dataset = source.dataset "
            "AND target.pk_uuid = source.pk_uuid AND target.check_name = source.check_name "
            "WHEN MATCHED THEN UPDATE SET "
            "runs_tested = target.runs_tested || ' ' || source.runs_tested, "
            "runs_flagged = CASE "
            "WHEN source.runs_flagged = '' THEN target.runs_flagged "
            "WHEN target.runs_flagged = '' THEN source.runs_flagged "
            "ELSE target.runs_flagged || ' ' || source.runs_flagged "
            "END, "
            "last_tested_at = source.last_tested_at, "
            "last_flagged_at = COALESCE(source.last_flagged_at, target.last_flagged_at) "
            "WHEN NOT MATCHED THEN INSERT "
            "(datasource, dataset, pk_uuid, check_name, runs_tested, runs_flagged, "
            "first_tested_at, last_tested_at, last_flagged_at) VALUES "
            "(source.datasource, source.dataset, source.pk_uuid, source.check_name, "
            "source.runs_tested, source.runs_flagged, "
            "source.first_tested_at, source.last_tested_at, source.last_flagged_at)"
        )
        with self.engine.begin() as conn:
            conn.execute(stmt, params)


def build_cell_rows(
    datasource: str, dataset: str, cells: Sequence[CellUpdate], run_seq: int, now: datetime
) -> list[dict[str, object]]:
    """Collapse *cells* to one row per ``(pk_uuid, check_name)`` for *run_seq*.

    A cell flagged in any request for the same key flips the row's
    ``runs_flagged`` to ``str(run_seq)``; otherwise it stays empty.
    """
    flagged_keys: set[tuple[str, str]] = set()
    seen: set[tuple[str, str]] = set()
    seen_order: list[tuple[str, str]] = []
    for cell in cells:
        key = (cell.pk_uuid, cell.check_name)
        if key not in seen:
            seen.add(key)
            seen_order.append(key)
        if cell.flagged:
            flagged_keys.add(key)
    run_seq_str = str(run_seq)
    return [
        {
            "datasource": datasource,
            "dataset": dataset,
            "pk_uuid": pk_uuid,
            "check_name": check_name,
            "runs_tested": run_seq_str,
            "runs_flagged": run_seq_str if (pk_uuid, check_name) in flagged_keys else "",
            "first_tested_at": now,
            "last_tested_at": now,
            "last_flagged_at": now if (pk_uuid, check_name) in flagged_keys else None,
        }
        for pk_uuid, check_name in seen_order
    ]


def build_values_clause(rows: list[dict[str, object]]) -> tuple[str, dict[str, object]]:
    """Return a positional ``VALUES (...), (...)`` clause and the bind dict for *rows*.

    Generates one parameterised VALUES tuple per row so the engine compiles
    a single multi-row INSERT — keeps PostgreSQL's 65535-parameter limit in
    sight by chunking before this is called.
    """
    placeholders: list[str] = []
    params: dict[str, object] = {}
    for index, row in enumerate(rows):
        placeholders.append(
            f"(:datasource_{index}, :dataset_{index}, :pk_{index}, :check_{index}, "
            f":runs_tested_{index}, :runs_flagged_{index}, "
            f":first_at_{index}, :last_at_{index}, :flagged_at_{index})"
        )
        params.update(row_params(index, row))
    return ", ".join(placeholders), params


def row_params(index: int, row: dict[str, object]) -> dict[str, object]:
    """Map one row's fields to the indexed bind names used in the VALUES clause."""
    return {
        f"datasource_{index}": row["datasource"],
        f"dataset_{index}": row["dataset"],
        f"pk_{index}": row["pk_uuid"],
        f"check_{index}": row["check_name"],
        f"runs_tested_{index}": row["runs_tested"],
        f"runs_flagged_{index}": row["runs_flagged"],
        f"first_at_{index}": row["first_tested_at"],
        f"last_at_{index}": row["last_tested_at"],
        f"flagged_at_{index}": row["last_flagged_at"],
    }
