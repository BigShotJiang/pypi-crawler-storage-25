"""``SqlCheckMetadataWriter``: writes ``quality_checks`` + ``check_fingerprint``.

Called unconditionally by the orchestrator on every completed run, so
the cross-run registry of defined checks (``quality_checks``) and the
per-era hash of each check's definition (``check_fingerprint``) stay
correct regardless of ``--flag``.

Deliberately separate from :class:`BatchedDatasetWriter` (flag cells):
those writes are gated on ``--flag`` and on the presence of failing
rows; metadata writes are not. One adapter per concern.
"""

from __future__ import annotations

from collections.abc import Sequence

from sqlalchemy import Engine, text

from turbine.adapters.quality.sql.fingerprint import (
    compute_fp_sha,
    derive_sql_template,
    serialize_threshold,
)
from turbine.core.common import CheckDef, DataSourceType


class SqlCheckMetadataWriter:
    """Upserts ``quality_checks`` + ``check_fingerprint`` for one run."""

    def __init__(self, engine: Engine, dialect: DataSourceType, datasource: str, schema: str) -> None:
        """Bind the metadata-store engine, the dialect, the datasource scope, and the schema."""
        self.engine = engine
        self.dialect = dialect
        self.datasource = datasource
        self.schema = schema

    @property
    def quality_checks_table(self) -> str:
        """Fully qualified ``turbine_quality_checks`` reference for the configured schema."""
        return f"{self.schema}.turbine_quality_checks"

    @property
    def fingerprint_table(self) -> str:
        """Fully qualified ``turbine_check_fingerprint`` reference for the configured schema."""
        return f"{self.schema}.turbine_check_fingerprint"

    def register(  # noqa: PLR0913
        self,
        run_seq: int,
        contract_id: str,
        spec_id: str,
        dataset: str,
        checks: Sequence[CheckDef],
        lifecycle: str,
    ) -> None:
        """Upsert one ``quality_checks`` row + one ``check_fingerprint`` row per check."""
        if not checks:
            return
        registry_rows = [self.registry_row(check, contract_id, spec_id, lifecycle) for check in checks]
        fingerprint_rows = [self.fingerprint_row(dataset, check, run_seq) for check in checks]
        if self.engine.dialect.name == "snowflake":
            self.merge_registry_snowflake(registry_rows)
            self.merge_fingerprints_snowflake(fingerprint_rows)
            return
        self.upsert_registry_on_conflict(registry_rows)
        self.upsert_fingerprints_on_conflict(fingerprint_rows)

    def registry_row(
        self, check: CheckDef, contract_id: str, spec_id: str, lifecycle: str
    ) -> dict[str, object]:
        """Build one ``quality_checks`` upsert row.

        ``check_id`` is a deterministic ``{contract|spec}:{dataset-or-name}``
        composite so the registry is keyed on stable identity rather than
        a hash. The fingerprint table already carries the hash for change
        detection.
        """
        scope = contract_id or spec_id
        return {
            "check_id": f"{scope}:{check.name}",
            "contract_id": contract_id,
            "spec_id": spec_id,
            "check_name": check.name,
            "lifecycle": lifecycle,
        }

    def upsert_registry_on_conflict(self, rows: list[dict[str, object]]) -> None:
        """DuckDB / Postgres path for ``quality_checks`` upsert."""
        stmt = text(
            f"INSERT INTO {self.quality_checks_table} "
            "(check_id, contract_id, spec_id, check_name, lifecycle) "
            "VALUES (:check_id, :contract_id, :spec_id, :check_name, :lifecycle) "
            "ON CONFLICT (check_id) DO UPDATE SET "
            "contract_id = EXCLUDED.contract_id, "
            "spec_id = EXCLUDED.spec_id, "
            "check_name = EXCLUDED.check_name, "
            "lifecycle = EXCLUDED.lifecycle"
        )
        with self.engine.begin() as conn:
            conn.execute(stmt, rows)

    def merge_registry_snowflake(self, rows: list[dict[str, object]]) -> None:
        """Snowflake path: one ``MERGE`` per row (Snowflake MERGE does not multiplex params)."""
        stmt = text(
            f"MERGE INTO {self.quality_checks_table} AS target "
            "USING (SELECT :check_id AS check_id, :contract_id AS contract_id, "
            ":spec_id AS spec_id, :check_name AS check_name, :lifecycle AS lifecycle) AS source "
            "ON target.check_id = source.check_id "
            "WHEN MATCHED THEN UPDATE SET "
            "contract_id = source.contract_id, spec_id = source.spec_id, "
            "check_name = source.check_name, lifecycle = source.lifecycle "
            "WHEN NOT MATCHED THEN INSERT "
            "(check_id, contract_id, spec_id, check_name, lifecycle) VALUES "
            "(source.check_id, source.contract_id, source.spec_id, source.check_name, source.lifecycle)"
        )
        with self.engine.begin() as conn:
            for row in rows:
                conn.execute(stmt, row)

    def fingerprint_row(self, dataset: str, check: CheckDef, run_seq: int) -> dict[str, object]:
        """Build one ``check_fingerprint`` upsert row."""
        return {
            "datasource": self.datasource,
            "dataset": dataset,
            "check_name": check.name,
            "fp_sha": compute_fp_sha(check, dialect=self.dialect),
            "sql_template": derive_sql_template(check),
            "filter_expr": check.filter.raw if check.filter is not None else None,
            "threshold": serialize_threshold(check) or None,
            "dialect": self.dialect.value,
            "run_seq": run_seq,
        }

    def upsert_fingerprints_on_conflict(self, rows: list[dict[str, object]]) -> None:
        """DuckDB / Postgres path for ``check_fingerprint`` upsert."""
        stmt = text(
            f"INSERT INTO {self.fingerprint_table} "
            "(datasource, dataset, check_name, fp_sha, sql_template, filter_expr, threshold, "
            "dialect, first_seen_run, last_seen_run) "
            "VALUES (:datasource, :dataset, :check_name, :fp_sha, :sql_template, :filter_expr, "
            ":threshold, :dialect, :run_seq, :run_seq) "
            "ON CONFLICT (datasource, dataset, check_name, fp_sha) DO UPDATE SET "
            f"last_seen_run = GREATEST({self.fingerprint_table}.last_seen_run, EXCLUDED.last_seen_run)"
        )
        with self.engine.begin() as conn:
            conn.execute(stmt, rows)

    def merge_fingerprints_snowflake(self, rows: list[dict[str, object]]) -> None:
        """Snowflake path for ``check_fingerprint`` upsert; one ``MERGE`` per row."""
        stmt = text(
            f"MERGE INTO {self.fingerprint_table} AS target "
            "USING (SELECT :datasource AS datasource, :dataset AS dataset, "
            ":check_name AS check_name, :fp_sha AS fp_sha, "
            ":sql_template AS sql_template, :filter_expr AS filter_expr, "
            ":threshold AS threshold, :dialect AS dialect, :run_seq AS run_seq) AS source "
            "ON target.datasource = source.datasource AND target.dataset = source.dataset "
            "AND target.check_name = source.check_name AND target.fp_sha = source.fp_sha "
            "WHEN MATCHED THEN UPDATE SET "
            "last_seen_run = GREATEST(target.last_seen_run, source.run_seq) "
            "WHEN NOT MATCHED THEN INSERT "
            "(datasource, dataset, check_name, fp_sha, sql_template, filter_expr, threshold, "
            "dialect, first_seen_run, last_seen_run) VALUES "
            "(source.datasource, source.dataset, source.check_name, source.fp_sha, "
            "source.sql_template, source.filter_expr, source.threshold, source.dialect, "
            "source.run_seq, source.run_seq)"
        )
        with self.engine.begin() as conn:
            for row in rows:
                conn.execute(stmt, row)
