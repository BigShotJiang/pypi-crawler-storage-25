"""@singledispatch renderers from predicates to sqlglot expressions.

Two dispatch surfaces:

* :func:`render_aggregate` — scalar aggregate expression for an
  :class:`AggregateSlot` projection. For PkCapable predicates this wraps
  the failing-rows predicate in ``COUNT(*) FILTER (WHERE ...)``, which
  sqlglot transpiles to ``COUNT(IFF(...))`` on Snowflake automatically.
* :func:`render_failing_rows` — row-level boolean predicate identifying
  failing rows. Drives PkSlot ``ARRAY_AGG`` projections, the overflow
  fallback sibling SELECT, and the PkSlot count projection.

Neither dispatcher takes a dialect capability — sqlglot handles every
dialect-specific transpilation we need. The two places that do care
about the dialect (Snowflake ``ARRAY_COMPACT`` wrap, ``pk_cap`` overflow
guard) live on the helpers :func:`array_agg_filtered_pks` and
:func:`count_filtered`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from functools import singledispatch

import sqlglot
from sqlglot import exp

from turbine.core.common.datasource_type import DataSourceType
from turbine.core.quality.plan.predicates import (
    AggregatePredicate,
    AvgLengthPredicate,
    AvgPredicate,
    DistinctCountPredicate,
    DuplicatePredicate,
    FreshnessPredicate,
    InvalidPredicate,
    InvalidReferencePredicate,
    MaxPredicate,
    MinPredicate,
    MissingPredicate,
    NullCountPredicate,
    PkCapablePredicate,
    QuantilePredicate,
    RetentionPredicate,
    RowCountPredicate,
    StddevPredicate,
    SumPredicate,
)

from .dialect_capabilities import DialectCapabilities


@dataclass
class CteRegistry:
    """Collects subqueries to be hoisted into a shared ``WITH`` clause.

    Repeated subqueries — most notably the duplicate-key set used by every
    DuplicatePredicate's failing-row test — would otherwise be inlined
    verbatim at each call site. PostgreSQL evaluates each occurrence as a
    separate ``SubPlan`` (re-running the GROUP BY / HAVING), so a single
    PkSlot for a duplicate check ends up scanning the input three times for
    one slot's projections (count, ARRAY_AGG, overflow guard). Interning
    each unique subquery here lets the renderer emit it once as a named
    CTE; every reference becomes a cheap hash semi-join probe.

    Dedup is by rendered SQL string in the target dialect, so two
    DuplicatePredicates over the same column set share one CTE.
    """

    counter: int = 0
    ctes: dict[str, exp.Select] = field(default_factory=dict)
    _by_signature: dict[str, str] = field(default_factory=dict)

    def intern(self, name_hint: str, ast: exp.Select, dialect: str) -> str:
        """Register *ast* and return the CTE identifier to reference it by.

        Subsequent calls with an equivalent *ast* (same rendered SQL) reuse
        the existing CTE name instead of allocating a new one.
        """
        signature = ast.sql(dialect=dialect)
        if signature in self._by_signature:
            return self._by_signature[signature]
        self.counter += 1
        name = f"{name_hint}_{self.counter}"
        self.ctes[name] = ast
        self._by_signature[signature] = name
        return name


ROW_COUNT_ALIAS = "turbine_row_count"
VALID_FORMAT_PATTERNS: dict[str, str] = {
    "email": r"^[^@\s]+@[^@\s]+\.[^@\s]+$",
    "uuid": r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$",
}


def row_count_projection() -> exp.Expr:
    """``COUNT(*) AS turbine_row_count`` — projected on every main scan.

    Every plan carries this projection so the executor can report
    ``DatasetMeasurement.row_count`` from the same single pass that
    evaluates aggregate and PK slots. The alias is unquoted and
    namespaced to avoid collisions with user-authored columns.
    """
    count_star = exp.Count(this=exp.Star())
    return exp.alias_(count_star, ROW_COUNT_ALIAS)


@singledispatch
def render_failing_rows(
    predicate: PkCapablePredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Return the row-level boolean predicate that identifies failing rows.

    When *registry* is supplied, predicates whose failing test contains a
    repeatable subquery (currently :class:`DuplicatePredicate`) hoist that
    subquery into a shared CTE so the surrounding SELECT references it by
    name instead of inlining it three times. Other predicates ignore the
    registry — their failing tests are scalar boolean expressions, cheap to
    evaluate per call site. *dialect* is required by the registry's
    deduplication key; ignored when *registry* is None.
    """
    del registry, dialect
    msg = f"no failing-rows renderer for {type(predicate).__name__}"
    raise NotImplementedError(msg)


@render_failing_rows.register
def _(
    predicate: MissingPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """``column IS NULL`` plus any configured missing-value sentinels."""
    del registry, dialect
    col = exp.column(predicate.column)
    null_check = exp.Is(this=col, expression=exp.null())
    if not predicate.missing_values:
        return null_check
    in_list = col.isin(*[exp.convert(value) for value in predicate.missing_values])
    return exp.or_(null_check, in_list)


@render_failing_rows.register
def _(
    predicate: NullCountPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Strict ``column IS NULL`` — ignores ODCS missing-value sentinels."""
    del registry, dialect
    return exp.Is(this=exp.column(predicate.column), expression=exp.null())


@render_failing_rows.register
def _(
    predicate: InvalidPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Conjunction of configured validity clauses, negated to identify invalids."""
    del registry, dialect
    valid_clauses = build_invalid_clauses(predicate)
    if not valid_clauses:
        return exp.false()
    return exp.not_(exp.and_(*valid_clauses))


def build_invalid_clauses(predicate: InvalidPredicate) -> list[exp.Expr]:
    """Translate each configured validity rule into a boolean expression."""
    col = exp.column(predicate.column)
    length = exp.Length(this=col)
    clauses: list[exp.Expr] = []
    if predicate.valid_values is not None:
        clauses.append(col.isin(*[exp.convert(value) for value in predicate.valid_values]))
    if predicate.valid_min is not None:
        clauses.append(col >= exp.convert(predicate.valid_min))
    if predicate.valid_max is not None:
        clauses.append(col <= exp.convert(predicate.valid_max))
    if predicate.valid_regex is not None:
        clauses.append(exp.RegexpLike(this=col, expression=exp.convert(predicate.valid_regex)))
    if predicate.valid_format is not None:
        pattern = valid_format_pattern(predicate.valid_format)
        clauses.append(exp.RegexpLike(this=col, expression=exp.convert(pattern)))
    clauses.extend(build_length_clauses(predicate, length))
    if predicate.invalid_values is not None:
        clauses.append(exp.not_(col.isin(*[exp.convert(value) for value in predicate.invalid_values])))
    if predicate.invalid_regex is not None:
        clauses.append(
            exp.not_(exp.RegexpLike(this=col, expression=exp.convert(predicate.invalid_regex)))
        )
    return clauses


def valid_format_pattern(format_name: str) -> str:
    """Return a regex for a named format, falling back to the raw value as a pattern."""
    return VALID_FORMAT_PATTERNS.get(format_name, format_name)


def build_length_clauses(predicate: InvalidPredicate, length: exp.Expr) -> list[exp.Expr]:
    """Length-based validity clauses (min/max/exact)."""
    clauses: list[exp.Expr] = []
    if predicate.valid_min_length is not None:
        clauses.append(length >= exp.convert(predicate.valid_min_length))
    if predicate.valid_max_length is not None:
        clauses.append(length <= exp.convert(predicate.valid_max_length))
    if predicate.valid_length is not None:
        clauses.append(exp.EQ(this=length, expression=exp.convert(predicate.valid_length)))
    return clauses


@render_failing_rows.register
def _(
    predicate: InvalidReferencePredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Row whose non-null *column* value is missing from the lookup table.

    Renders ``column IS NOT NULL AND column NOT IN (SELECT ref_col FROM
    ref_table WHERE ref_col IS NOT NULL)``. The lookup SELECT is interned
    in *registry* (when supplied) so multiple call sites for the same
    PkSlot — count, ARRAY_AGG, overflow guard — read one CTE rather than
    re-running the lookup three times. NULL filtering on the reference
    column is sound under SQL ``NOT IN`` semantics (a NULL on the lookup
    side never matches anyway) and keeps the lookup set tight.
    """
    col = exp.column(predicate.column)
    not_null = exp.not_(exp.Is(this=col.copy(), expression=exp.null()))
    lookup_select = build_reference_lookup(predicate)
    if registry is not None and dialect is not None:
        cte_name = registry.intern("valid_ref", lookup_select, dialect)
        lookup_select = exp.select(exp.column(predicate.reference_column)).from_(
            exp.to_identifier(cte_name)
        )
    not_in = exp.not_(col.copy().isin(query=lookup_select))
    return exp.and_(not_null, not_in)


def build_reference_lookup(predicate: InvalidReferencePredicate) -> exp.Select:
    """Build ``SELECT ref_col FROM ref_table WHERE ref_col IS NOT NULL``."""
    ref_col = exp.column(predicate.reference_column)
    return (
        exp.select(ref_col)
        .from_(predicate.reference_dataset)
        .where(exp.not_(exp.Is(this=ref_col.copy(), expression=exp.null())))
    )


@render_failing_rows.register
def _(
    predicate: DuplicatePredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Row is in the set of key combinations that appear more than once in ``ds``.

    When *registry* is supplied (main aggregate plan), the duplicate-key
    set is interned as a shared CTE so a single PkSlot's three references
    (count, ARRAY_AGG, overflow guard) hit one HashAggregate instead of
    three. The same hash aggregate is reused by the DuplicatePredicate's
    aggregate to compute distinct keys without a Sort. The fallback path
    renders without a registry and inlines as before — fallback queries
    are single-use so hoisting buys nothing.
    """
    key_cols = [exp.column(column) for column in predicate.columns]
    if registry is not None:
        if dialect is None:
            msg = "DuplicatePredicate hoisting requires a dialect for the CTE registry signature"
            raise ValueError(msg)
        _, dups_name = register_dup_ctes(predicate, registry, dialect)
        cte_ref = exp.select(*[column.copy() for column in key_cols]).from_(exp.to_identifier(dups_name))
        if len(key_cols) == 1:
            return key_cols[0].isin(cte_ref)
        return exp.Tuple(expressions=key_cols).isin(cte_ref)
    group_select = (
        exp.select(*[column.copy() for column in key_cols])
        .from_(exp.to_identifier("ds"))
        .group_by(*[column.copy() for column in key_cols])
        .having(exp.GT(this=exp.Count(this=exp.Star()), expression=exp.convert(1)))
    )
    if len(key_cols) == 1:
        return key_cols[0].isin(group_select)
    return exp.Tuple(expressions=key_cols).isin(group_select)


def register_dup_ctes(
    predicate: DuplicatePredicate, registry: CteRegistry, dialect: str
) -> tuple[str, str]:
    """Intern the ``keycounts`` and ``dups`` CTE pair for *predicate*'s columns.

    Returns ``(keycounts_name, dups_name)``. Both are scoped to the same
    column set so two DuplicatePredicates over identical columns share one
    HashAggregate. ``keycounts`` is the underlying ``GROUP BY <cols>``;
    ``dups`` is its ``cnt > 1`` filter view. Two CTEs (instead of one) so
    :func:`_aggregate_for_duplicate` can compute ``COUNT(DISTINCT cols)``
    as ``(SELECT COUNT(*) FROM keycounts)`` without a Sort, while every
    failing-row probe reads the cheaper ``dups`` filter.
    """
    key_cols = [exp.column(column) for column in predicate.columns]
    keycounts_select = (
        exp.select(
            *[column.copy() for column in key_cols], exp.alias_(exp.Count(this=exp.Star()), "cnt")
        )
        .from_(exp.to_identifier("ds"))
        .group_by(*[column.copy() for column in key_cols])
    )
    keycounts_name = registry.intern("keycounts", keycounts_select, dialect)
    dups_select = (
        exp.select(*[column.copy() for column in key_cols])
        .from_(exp.to_identifier(keycounts_name))
        .where(exp.GT(this=exp.column("cnt"), expression=exp.convert(1)))
    )
    dups_name = registry.intern("dups", dups_select, dialect)
    return keycounts_name, dups_name


@singledispatch
def render_aggregate(
    predicate: AggregatePredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Return the scalar aggregate expression for an :class:`AggregateSlot`.

    Most predicates ignore *registry* and *dialect*; they only matter for
    :class:`DuplicatePredicate`, which uses them to share the ``keycounts``
    HashAggregate with the failing-rows test (avoiding a Sort spill from
    ``COUNT(DISTINCT)``).
    """
    del registry, dialect
    msg = f"no aggregate renderer for {type(predicate).__name__}"
    raise NotImplementedError(msg)


@render_aggregate.register
def _(
    predicate: RowCountPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """``COUNT(*)`` over the filtered dataset."""
    del predicate, registry, dialect
    return exp.Count(this=exp.Star())


FRESHNESS_UNIT_DIVISORS: dict[str, float] = {
    "second": 1.0,
    "minute": 60.0,
    "hour": 3600.0,
    "day": 86400.0,
}


RETENTION_UNIT_DIVISORS: dict[str, float] = {
    "second": 1.0,
    "minute": 60.0,
    "hour": 3600.0,
    "day": 86400.0,
    "week": 604800.0,
}


RETENTION_INTERVAL_UNITS: frozenset[str] = frozenset({"month", "year"})


@render_aggregate.register
def _(
    predicate: FreshnessPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Latency of the most recent row, in *unit*.

    Renders to ``EXTRACT(EPOCH FROM (CURRENT_TIMESTAMP - MAX(column))) /
    divisor``. sqlglot transpiles ``EXTRACT(EPOCH FROM ...)`` to
    ``DATE_PART(EPOCH, ...)`` on Snowflake automatically; PostgreSQL
    additionally wraps the EXTRACT in a ``CAST AS DOUBLE PRECISION`` so
    the division returns a float rather than an integer.
    """
    del registry, dialect
    divisor = FRESHNESS_UNIT_DIVISORS.get(predicate.unit)
    if divisor is None:
        msg = (
            f"unknown freshness unit {predicate.unit!r}; expected one of "
            f"{sorted(FRESHNESS_UNIT_DIVISORS)}"
        )
        raise ValueError(msg)
    column_max = exp.Max(this=exp.column(predicate.column))
    delta = exp.Sub(this=exp.CurrentTimestamp(), expression=column_max)
    epoch_seconds = exp.Extract(this=exp.Var(this="EPOCH"), expression=delta)
    return exp.Div(this=epoch_seconds, expression=exp.convert(divisor))


@render_aggregate.register
def _(
    predicate: RetentionPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Age of the OLDEST row (``MIN(column)``), in *unit*.

    Short units render an age scalar via the epoch divisor; the threshold
    pipeline compares with ``ge`` (lower bound) or ``le`` (upper bound).

    Calendar units (``month`` / ``year``) bake ``value`` into an ``INTERVAL``
    clause to preserve calendar arithmetic — ``CASE WHEN MIN(col) <comparison>
    CURRENT_TIMESTAMP - INTERVAL '<value> <unit>' THEN 1.0 ELSE 0.0 END``.
    ``bound`` selects ``<=`` for lower (minimum-history guarantee) or ``>=``
    for upper (GDPR-style maximum retention).
    """
    del registry, dialect
    if predicate.unit in RETENTION_INTERVAL_UNITS:
        return render_retention_interval(predicate)
    divisor = RETENTION_UNIT_DIVISORS.get(predicate.unit)
    if divisor is None:
        msg = (
            f"unknown retention unit {predicate.unit!r}; expected one of "
            f"{sorted(RETENTION_UNIT_DIVISORS) + sorted(RETENTION_INTERVAL_UNITS)}"
        )
        raise ValueError(msg)
    column_min = exp.Min(this=exp.column(predicate.column))
    delta = exp.Sub(this=exp.CurrentTimestamp(), expression=column_min)
    epoch_seconds = exp.Extract(this=exp.Var(this="EPOCH"), expression=delta)
    return exp.Div(this=epoch_seconds, expression=exp.convert(divisor))


def render_retention_interval(predicate: RetentionPredicate) -> exp.Expr:
    """Build the calendar-unit CASE expression for a RetentionPredicate.

    ``value`` is required (the renderer can't compose ``INTERVAL`` without it).
    Returns a 0/1 scalar; the CheckDef threshold is ``ge 1`` meaning "the
    boolean must hold".
    """
    if predicate.value is None:
        raise ValueError(
            f"value is required for retention unit {predicate.unit!r}; the INTERVAL path "
            "bakes the threshold directly into the SQL"
        )
    interval = exp.Interval(
        this=exp.convert(
            str(int(predicate.value)) if predicate.value.is_integer() else str(predicate.value)
        ),
        unit=exp.Var(this=predicate.unit.upper()),
    )
    deadline = exp.Sub(this=exp.CurrentTimestamp(), expression=interval)
    column_min = exp.Min(this=exp.column(predicate.column))
    comparison: exp.Expr
    comparison = (
        exp.LTE(this=column_min, expression=deadline)
        if predicate.bound == "lower"
        else exp.GTE(this=column_min, expression=deadline)
    )
    return exp.Case(ifs=[exp.If(this=comparison, true=exp.convert(1.0))], default=exp.convert(0.0))


@render_aggregate.register
def _(
    predicate: AvgPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """``AVG(column)``."""
    del registry, dialect
    return exp.Avg(this=exp.column(predicate.column))


@render_aggregate.register
def _(
    predicate: SumPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """``SUM(column)``."""
    del registry, dialect
    return exp.Sum(this=exp.column(predicate.column))


@render_aggregate.register
def _(
    predicate: StddevPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Sample standard deviation; sqlglot handles dialect-specific function name."""
    del registry, dialect
    return exp.Stddev(this=exp.column(predicate.column))


@render_aggregate.register
def _(
    predicate: MinPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """``MIN(column)``."""
    del registry, dialect
    return exp.Min(this=exp.column(predicate.column))


@render_aggregate.register
def _(
    predicate: MaxPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """``MAX(column)``."""
    del registry, dialect
    return exp.Max(this=exp.column(predicate.column))


@render_aggregate.register
def _(
    predicate: DistinctCountPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """``COUNT(DISTINCT column)``."""
    del registry, dialect
    return exp.Count(this=exp.Distinct(expressions=[exp.column(predicate.column)]))


@render_aggregate.register
def _(
    predicate: AvgLengthPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """``AVG(LENGTH(column))``."""
    del registry, dialect
    return exp.Avg(this=exp.Length(this=exp.column(predicate.column)))


@render_aggregate.register
def _(
    predicate: QuantilePredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """``QUANTILE_CONT(col, q)`` — sqlglot transpiles to ``PERCENTILE_CONT`` + WITHIN GROUP."""
    del registry, dialect
    column_sql = exp.column(predicate.column).sql(dialect=DataSourceType.DUCKDB.value)
    return sqlglot.parse_one(
        f"QUANTILE_CONT({column_sql}, {predicate.q})", dialect=DataSourceType.DUCKDB.value
    )


@render_aggregate.register
def _(
    predicate: MissingPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Count of rows matching the missing predicate."""
    return count_filtered(render_failing_rows(predicate, registry, dialect))


@render_aggregate.register
def _(
    predicate: NullCountPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Count of rows where the column is strictly ``NULL``."""
    return count_filtered(render_failing_rows(predicate, registry, dialect))


@render_aggregate.register
def _(
    predicate: InvalidPredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Count of rows that fail validity rules."""
    return count_filtered(render_failing_rows(predicate, registry, dialect))


@render_aggregate.register
def _(
    predicate: InvalidReferencePredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """Count of rows whose non-null *column* value is not in the lookup set."""
    return count_filtered(render_failing_rows(predicate, registry, dialect))


@render_aggregate.register
def _(
    predicate: DuplicatePredicate, registry: CteRegistry | None = None, dialect: str | None = None
) -> exp.Expr:
    """``COUNT(*) - COUNT(DISTINCT (columns))`` — rows that participate in duplicates.

    With a *registry*, this becomes ``COUNT(*) - (SELECT COUNT(*) FROM keycounts)``
    — the distinct-key count is read off the same HashAggregate the
    failing-rows test already builds (see :func:`register_dup_ctes`).
    Without the registry (single-use call sites), falls back to the
    ``COUNT(DISTINCT)`` form which forces a Sort and spills to disk on
    large tables.
    """
    key_cols = [exp.column(column) for column in predicate.columns]
    if registry is not None:
        if dialect is None:
            msg = "DuplicatePredicate aggregate hoisting requires a dialect"
            raise ValueError(msg)
        keycounts_name, _ = register_dup_ctes(predicate, registry, dialect)
        distinct_count = exp.select(exp.Count(this=exp.Star())).from_(exp.to_identifier(keycounts_name))
        return exp.Sub(this=exp.Count(this=exp.Star()), expression=exp.Subquery(this=distinct_count))
    inner = key_cols[0] if len(key_cols) == 1 else exp.Tuple(expressions=key_cols)
    distinct_key = exp.Distinct(expressions=[inner])
    return exp.Sub(this=exp.Count(this=exp.Star()), expression=exp.Count(this=distinct_key))


def count_filtered(failing: exp.Expr) -> exp.Expr:
    """``COUNT(*) FILTER (WHERE failing)`` — sqlglot transpiles to Snowflake's ``COUNT(IFF(...))``."""
    return exp.Filter(this=exp.Count(this=exp.Star()), expression=exp.Where(this=failing))


def array_agg_filtered_pks(
    pk_columns: tuple[str, ...], failing: exp.Expr, caps: DialectCapabilities
) -> exp.Expr:
    """``ARRAY_AGG(pk_identity) FILTER (WHERE failing)`` for single or composite PKs.

    sqlglot transpiles the canonical form to ``ARRAY_AGG(IFF(failing, pk, NULL))``
    on Snowflake, where ARRAY_AGG keeps NULLs. Wrap in ``ARRAY_COMPACT`` so
    the resulting array holds only real PKs regardless of dialect.
    """
    if not pk_columns:
        raise ValueError("array_agg_filtered_pks requires at least one primary key column")
    columns = [exp.column(column) for column in pk_columns]
    pk_expr = columns[0] if len(columns) == 1 else exp.Array(expressions=columns)
    agg = exp.Filter(this=exp.ArrayAgg(this=pk_expr), expression=exp.Where(this=failing))
    if caps.dialect is DataSourceType.SNOWFLAKE:
        return exp.Anonymous(this="ARRAY_COMPACT", expressions=[agg])
    return agg
