"""Detect missing composite indexes that would let windowed checks skip a sort.

Every windowed check (zscore, spike, flatline, pct_change, range) renders
to ``OVER (PARTITION BY <p> ORDER BY <o> <frame>)``. Postgres can serve
that ``OVER`` clause without a sort step only when an index covers
``(<p>..., <o>...)`` as its leading prefix. Without such an index, the
planner inserts a Sort node that scans the whole CTE — on a 16M-row
table that's hundreds of MB spilling to disk per windowed plan.

This advisor is a Postgres-only nudge: it inspects the live table's
indexes once per ``(table, partition_by, order_by)`` triple, and emits a
``logger.warning`` line listing the missing index when none of the
existing indexes would let the planner skip the sort. The warning is
informational — the run still executes correctly, just slower than it
would with the suggested index.

Snowflake / DuckDB are skipped entirely: clustering keys (Snowflake) and
in-process columnar reads (DuckDB) handle window ordering differently
and the heuristic does not apply.
"""

from __future__ import annotations

import logging
from collections.abc import Iterable
from dataclasses import dataclass

from sqlalchemy import Engine, text
from sqlalchemy.exc import SQLAlchemyError

from turbine.core.common.datasource_type import DataSourceType
from turbine.core.common.identifiers import TableIdentifier
from turbine.core.quality.plan.dataset_plan import DatasetPlan
from turbine.core.quality.plan.predicates import WindowedRowFilterPredicate
from turbine.core.quality.plan.slots import PkSlot

from .dialect_capabilities import DialectCapabilities

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class WindowOrdering:
    """The ``(partition_by, order_by)`` pair shared by a windowed plan's slots.

    Two windowed slots on the same plan always share this pair after the
    planner-level grouping (see ``window_signature_of``); the renderer
    rejects mixing different orderings into one ``ds_windowed`` CTE.
    """

    partition_by: tuple[str, ...]
    order_by: tuple[str, ...]

    @property
    def required_prefix(self) -> tuple[str, ...]:
        """Columns an index must cover (in order) to skip the windowed Sort."""
        return self.partition_by + self.order_by


class WindowedIndexAdvisor:
    """Stateful Postgres-only check: warn once per ``(table, ordering)``.

    Memoised so a long run that re-executes the same windowed plan (or
    runs many contracts touching the same table) doesn't spam the log.
    The ``advise`` entry point is a no-op for non-Postgres dialects and
    for plans without windowed slots.
    """

    def __init__(self, engine: Engine, caps: DialectCapabilities) -> None:
        """Bind to the executor's engine and dialect."""
        self.engine = engine
        self.caps = caps
        self._already_warned: set[tuple[str, str, tuple[str, ...]]] = set()

    def advise(self, plan: DatasetPlan) -> None:
        """Inspect *plan* and warn about any missing composite index."""
        if self.caps.dialect is not DataSourceType.POSTGRES:
            return
        ordering = extract_ordering(plan)
        if ordering is None or not ordering.required_prefix:
            return
        cache_key = (plan.dataset.schema, plan.dataset.table, ordering.required_prefix)
        if cache_key in self._already_warned:
            return
        self._already_warned.add(cache_key)
        existing = self.fetch_index_prefixes(plan.dataset)
        if any(covers_prefix(prefix, ordering.required_prefix) for prefix in existing):
            return
        logger.warning(self.format_warning(plan.dataset, ordering))

    def fetch_index_prefixes(self, dataset: TableIdentifier) -> tuple[tuple[str, ...], ...]:
        """Return the leading column tuple of every btree index on *dataset*.

        Includes the primary key. Hash / GIN / GiST indexes are excluded
        because Postgres only uses btree for sort-skipping. Failures (no
        permission, table missing) yield an empty tuple — the advisor
        stays best-effort.
        """
        sql = """
            SELECT
                i.indkey,
                array_agg(a.attname ORDER BY ord.ord) AS columns
            FROM pg_index i
            JOIN pg_class c ON c.oid = i.indrelid
            JOIN pg_namespace n ON n.oid = c.relnamespace
            JOIN pg_class ic ON ic.oid = i.indexrelid
            JOIN pg_am am ON am.oid = ic.relam
            JOIN LATERAL unnest(i.indkey) WITH ORDINALITY AS ord(attnum, ord) ON TRUE
            JOIN pg_attribute a ON a.attrelid = i.indrelid AND a.attnum = ord.attnum
            WHERE n.nspname = :schema
              AND c.relname = :table
              AND am.amname = 'btree'
            GROUP BY i.indkey
        """
        try:
            with self.engine.connect() as conn:
                rows = conn.execute(text(sql), {"schema": dataset.schema, "table": dataset.table})
                return tuple(tuple(row.columns) for row in rows)
        except SQLAlchemyError as exc:
            logger.debug("WindowedIndexAdvisor: index lookup failed for %s: %s", dataset, exc)
            return ()

    def format_warning(self, dataset: TableIdentifier, ordering: WindowOrdering) -> str:
        """Build the human-facing warning message with a CREATE INDEX suggestion."""
        cols = ", ".join(ordering.required_prefix)
        return (
            f"[{DataSourceType.POSTGRES.value}] No btree index on "
            f"{dataset.schema}.{dataset.table} covers ({cols}) — windowed checks "
            f"will sort the full table per query. Consider: "
            f"CREATE INDEX ON {dataset.schema}.{dataset.table} ({cols});"
        )


def extract_ordering(plan: DatasetPlan) -> WindowOrdering | None:
    """Return the ``(partition_by, order_by)`` pair for *plan*'s windowed slots.

    Returns None when the plan has no windowed PkSlot or when the planner
    bucketing somehow let mismatched orderings into one plan (defensive —
    the planner's ``window_signature_of`` should have prevented that).
    """
    seen: set[tuple[tuple[str, ...], tuple[str, ...]]] = set()
    for slot in plan.slots:
        if not isinstance(slot, PkSlot) or not isinstance(slot.predicate, WindowedRowFilterPredicate):
            continue
        seen.add((slot.predicate.partition_by, slot.predicate.order_by))
    if len(seen) != 1:
        return None
    partition_by, order_by = next(iter(seen))
    return WindowOrdering(partition_by=partition_by, order_by=order_by)


def covers_prefix(index_columns: Iterable[str], required: tuple[str, ...]) -> bool:
    """Return True when *required* matches the leading prefix of *index_columns*."""
    index_tuple = tuple(index_columns)
    if len(index_tuple) < len(required):
        return False
    return index_tuple[: len(required)] == required
