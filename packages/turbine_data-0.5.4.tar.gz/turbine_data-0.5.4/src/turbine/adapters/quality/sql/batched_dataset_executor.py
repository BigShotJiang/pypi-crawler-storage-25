"""``BatchedDatasetExecutor``: renders a :class:`DatasetPlan` and executes it.

The executor owns three responsibilities:

* **Main-scan execution** — :meth:`execute` renders the plan into a single
  ``WITH ds AS (...) SELECT ...`` statement, runs it, and parses the single
  result row into typed per-slot buckets on a :class:`DatasetMeasurement`.
* **Overflow fallback** — when a ``PkSlot``'s count projection exceeds
  ``caps.pk_cap``, the main-scan array for that slot is ``NULL`` by design;
  :meth:`fetch_pks` opens a streaming sibling cursor and wraps it in a
  generator whose ``finally`` closes the cursor on either exhaustion or GC.
* **Column fetch** — :meth:`fetch_column_slots` materialises each
  :class:`ColumnFetchSlot` in the plan into a DataFrame via dialect-aware
  streaming. The low-level :meth:`fetch_columns` yields raw
  :class:`pyarrow.RecordBatch` chunks dispatched by
  :attr:`DialectCapabilities.column_fetch`.

Connection strategy: the executor holds the SQLAlchemy ``Engine`` directly
and opens a fresh connection per call. Streaming paths use
``execution_options(stream_results=True, yield_per=...)`` so the server-side
cursor stays open for the generator's lifetime. The Snowflake Arrow path
accesses the underlying DBAPI cursor directly via ``conn.connection.cursor()``
to call ``fetch_arrow_batches()``.
"""

from __future__ import annotations

import time
from collections.abc import Iterator

import pyarrow as pa
from sqlalchemy import Engine, text
from sqlalchemy.exc import SQLAlchemyError

from turbine.adapters.quality.python.data_loader import arrow_to_dataframe
from turbine.core.quality.plan.dataset_plan import DatasetPlan
from turbine.core.quality.plan.errors import PlanExecutionError
from turbine.core.quality.plan.measurement import (
    AggregateResult,
    DataframeHandle,
    DatasetMeasurement,
    FailedRowsResult,
    PkResult,
    SlotError,
)
from turbine.core.quality.plan.slots import AggregateSlot, ColumnFetchSlot, PkSlot, SlotId
from turbine.core.quality.ports import DatasetExecutor
from turbine.core.shared import PrimaryKey, RecordBatch

from .dialect_capabilities import ColumnFetchShape, DialectCapabilities
from .predicate_renderer import ROW_COUNT_ALIAS
from .renderer import (
    is_windowed_plan,
    render_column_fetch,
    render_failed_rows_queries,
    render_pk_fallback,
    render_plan,
)
from .windowed_index_advisor import WindowedIndexAdvisor

PK_FETCH_CHUNK = 5_000
COLUMN_FETCH_CHUNK = 5_000


class BatchedDatasetExecutor(DatasetExecutor):
    """Execute :class:`DatasetPlan` instances against a SQLAlchemy engine."""

    def __init__(self, engine: Engine, caps: DialectCapabilities) -> None:
        """Store the engine, dialect capabilities, and the windowed-index advisor."""
        self.engine = engine
        self.caps = caps
        self.windowed_index_advisor = WindowedIndexAdvisor(engine=engine, caps=caps)

    def execute(self, plan: DatasetPlan) -> DatasetMeasurement | PlanExecutionError:
        """Run *plan* and return the measurement or a plan-level error.

        Before dispatching a windowed plan, the advisor checks (Postgres
        only) whether the dataset has a btree index covering the
        ``(partition_by, order_by)`` prefix and warns once if not. The
        advisor is best-effort and never blocks the run.
        """
        if is_windowed_plan(plan):
            self.windowed_index_advisor.advise(plan)
        sql = render_plan(plan, self.caps)
        started = time.perf_counter()
        try:
            with self.engine.connect() as conn:
                result = conn.execute(text(sql))
                columns = tuple(result.keys())
                rows = tuple(tuple(row) for row in result)
        except SQLAlchemyError as exc:
            return PlanExecutionError(plan=plan, reason=exc)

        column_fetches, column_errors = self.fetch_column_slots(plan)
        failed_rows, failed_rows_errors = self.fetch_failed_rows(plan)
        duration_ms = (time.perf_counter() - started) * 1_000.0
        slot_errors = {**column_errors, **failed_rows_errors}
        return self.build_measurement(
            plan,
            rows,
            columns,
            duration_ms,
            column_fetches=column_fetches,
            failed_rows=failed_rows,
            slot_errors=slot_errors,
        )

    def fetch_failed_rows(
        self, plan: DatasetPlan
    ) -> tuple[dict[SlotId, FailedRowsResult], dict[SlotId, SlotError]]:
        """Execute every :class:`FailedRowsSlot`'s user-authored SELECT.

        Each query runs as an independent statement. Per-slot failures stay
        scoped to the slot via ``SlotError`` so other slots in the same plan
        keep going.
        """
        results: dict[SlotId, FailedRowsResult] = {}
        errors: dict[SlotId, SlotError] = {}
        queries = render_failed_rows_queries(plan)
        if not queries:
            return results, errors
        with self.engine.connect() as conn:
            for slot_id, query in queries.items():
                try:
                    cursor = conn.execute(text(query))
                    columns = tuple(map(str, cursor.keys()))
                    fetched = tuple(tuple(row) for row in cursor)
                except SQLAlchemyError as exc:
                    # Roll back so a failed statement (e.g. SyntaxError) does not
                    # poison the connection and mask the next slot's real error
                    # with "current transaction is aborted".
                    conn.rollback()
                    errors[slot_id] = SlotError(slot_id=slot_id, reason=str(exc), exception=exc)
                    continue
                results[slot_id] = FailedRowsResult(rows=fetched, columns=columns)
        return results, errors

    def fetch_pks(self, plan: DatasetPlan, slot: PkSlot) -> Iterator[PrimaryKey]:
        """Stream primary keys for an overflowed ``PkSlot``.

        The generator opens a server-side cursor via
        ``execution_options(stream_results=True, yield_per=...)`` and closes
        both the cursor and its connection in the ``finally`` block, so
        exhaustion and GC both release resources deterministically.
        """
        return stream_pks(self.engine, render_pk_fallback(plan, slot, self.caps))

    def fetch_columns(self, plan: DatasetPlan) -> Iterator[RecordBatch]:
        """Stream every :class:`ColumnFetchSlot` in *plan* as ``pa.RecordBatch`` chunks.

        Dispatches to the dialect-appropriate streaming strategy via
        :attr:`DialectCapabilities.column_fetch`. Each slot opens its own
        connection; the ``finally`` in :func:`stream_column_slot` closes it
        on exhaustion or GC.
        """
        for _, sql in _column_slot_sqls(plan, self.caps):
            yield from stream_column_slot(self.engine, sql, self.caps)

    def fetch_column_slots(
        self, plan: DatasetPlan
    ) -> tuple[dict[SlotId, DataframeHandle], dict[SlotId, SlotError]]:
        """Materialise every :class:`ColumnFetchSlot` into a DataFrame handle.

        Drains the RecordBatch stream from :func:`stream_column_slot` into a
        PyArrow Table, then converts to pandas or polars per ``slot.library``.
        Per-slot failures stay scoped to the slot via ``SlotError`` — they do
        not abort the plan.
        """
        fetches: dict[SlotId, DataframeHandle] = {}
        errors: dict[SlotId, SlotError] = {}
        for slot, sql in _column_slot_sqls(plan, self.caps):
            try:
                batches = list(stream_column_slot(self.engine, sql, self.caps))
                table = pa.Table.from_batches(batches) if batches else pa.table({})
                df = arrow_to_dataframe(table, slot.library)
                fetches[slot.id] = DataframeHandle(opaque=df)
            except Exception as exc:  # noqa: BLE001 — adapter boundary; surface as SlotError
                errors[slot.id] = SlotError(slot_id=slot.id, reason=str(exc), exception=exc)
        return fetches, errors

    def build_measurement(  # noqa: PLR0913 — six inputs all describe the same plan outcome
        self,
        plan: DatasetPlan,
        rows: tuple[tuple[object, ...], ...],
        columns: tuple[str, ...],
        duration_ms: float,
        *,
        column_fetches: dict[SlotId, DataframeHandle],
        failed_rows: dict[SlotId, FailedRowsResult],
        slot_errors: dict[SlotId, SlotError],
    ) -> DatasetMeasurement:
        """Parse the single main-scan row into per-slot-kind result buckets."""
        row = rows[0] if rows else ()
        by_name = dict(zip(columns, row, strict=False))

        aggregates, aggregate_errors = self.parse_aggregates(plan, by_name)
        pks = self.parse_pks(plan, by_name)
        row_count = self.parse_row_count(by_name)
        errors = {**slot_errors, **aggregate_errors}

        return DatasetMeasurement(
            aggregates=aggregates,
            pks=pks,
            samples={},
            column_fetches=column_fetches,
            failed_rows=failed_rows,
            errors=errors,
            row_count=row_count,
            duration_ms=duration_ms,
        )

    def parse_aggregates(
        self, plan: DatasetPlan, by_name: dict[str, object]
    ) -> tuple[dict[SlotId, AggregateResult], dict[SlotId, SlotError]]:
        """Collect scalar aggregate projections from the main scan."""
        aggregates: dict[SlotId, AggregateResult] = {}
        errors: dict[SlotId, SlotError] = {}
        for slot in plan.slots:
            if not isinstance(slot, AggregateSlot):
                continue
            raw = by_name.get(slot.id)
            try:
                aggregates[slot.id] = AggregateResult(value=coerce_aggregate_value(raw))
            except ValueError as exc:
                errors[slot.id] = SlotError(
                    slot_id=slot.id,
                    reason=f"non-numeric aggregate result for {slot.id}: {raw!r}",
                    exception=exc,
                )
        return aggregates, errors

    def parse_pks(self, plan: DatasetPlan, by_name: dict[str, object]) -> dict[SlotId, PkResult]:
        """Collect PK slot results; route overflowed slots through streaming."""
        pks: dict[SlotId, PkResult] = {}
        for slot in plan.slots:
            if not isinstance(slot, PkSlot):
                continue
            total = coerce_int(by_name.get(f"count_{slot.id}"))
            eager = by_name.get(slot.id)
            if self.is_overflow(total, eager):
                pks[slot.id] = PkResult(total=total, pks=self.fetch_pks(plan, slot), streaming=True)
                continue
            pks[slot.id] = PkResult(total=total, pks=coerce_pk_array(eager), streaming=False)
        return pks

    def is_overflow(self, total: int, eager: object) -> bool:
        """Return whether this slot's main-scan array is the overflow sentinel."""
        if self.caps.pk_cap is None:
            return False
        return total > self.caps.pk_cap or eager is None

    def parse_row_count(self, by_name: dict[str, object]) -> int:
        """Read the ``COUNT(*) AS turbine_row_count`` projection every plan carries."""
        return coerce_int(by_name.get(ROW_COUNT_ALIAS))


def _column_slot_sqls(
    plan: DatasetPlan, caps: DialectCapabilities
) -> Iterator[tuple[ColumnFetchSlot, str]]:
    """Yield (slot, rendered_sql) for each ColumnFetchSlot in *plan*."""
    for slot in plan.slots:
        if isinstance(slot, ColumnFetchSlot):
            yield slot, render_column_fetch(plan, slot, caps)


def stream_pks(engine: Engine, sql: str) -> Iterator[PrimaryKey]:
    """Open a server-side cursor, yield PK tuples, close on exhaustion or GC."""
    conn = engine.connect().execution_options(stream_results=True, yield_per=PK_FETCH_CHUNK)
    try:
        result = conn.execute(text(sql))
        for row in result:
            yield tuple(row)
    finally:
        conn.close()


def stream_column_slot(engine: Engine, sql: str, caps: DialectCapabilities) -> Iterator[pa.RecordBatch]:
    """Stream one ColumnFetchSlot SQL as RecordBatch chunks, dispatching on caps.column_fetch."""
    if caps.column_fetch == ColumnFetchShape.RESULT_SCAN_ARROW:
        yield from _stream_arrow_batches(engine, sql)
    elif caps.column_fetch == ColumnFetchShape.SERVER_SIDE_CURSOR:
        yield from _stream_server_side_cursor_batches(engine, sql)
    else:
        yield from _stream_native_iter_batches(engine, sql)


def _stream_native_iter_batches(engine: Engine, sql: str) -> Iterator[pa.RecordBatch]:
    """Stream via plain cursor iteration, accumulating rows into COLUMN_FETCH_CHUNK batches."""
    conn = engine.connect()
    try:
        result = conn.execute(text(sql))
        columns = tuple(result.keys())
        rows: list[tuple[object, ...]] = []
        for row in result:
            rows.append(tuple(row))
            if len(rows) >= COLUMN_FETCH_CHUNK:
                yield _rows_to_record_batch(columns, rows)
                rows = []
        if rows:
            yield _rows_to_record_batch(columns, rows)
    finally:
        conn.close()


def _stream_server_side_cursor_batches(engine: Engine, sql: str) -> Iterator[pa.RecordBatch]:
    """Stream via SQLAlchemy server-side cursor yield_per, converting partitions to RecordBatches."""
    conn = engine.connect().execution_options(stream_results=True, yield_per=COLUMN_FETCH_CHUNK)
    try:
        result = conn.execute(text(sql))
        columns = tuple(result.keys())
        for partition in result.partitions(COLUMN_FETCH_CHUNK):
            rows = [tuple(row) for row in partition]
            yield _rows_to_record_batch(columns, rows)
    finally:
        conn.close()


def _stream_arrow_batches(engine: Engine, sql: str) -> Iterator[pa.RecordBatch]:
    """Stream Snowflake results via native Arrow cursor (RESULT_SCAN_ARROW shape)."""
    conn = engine.connect()
    try:
        raw_cursor = conn.connection.cursor()
        try:
            raw_cursor.execute(sql)
            for table in raw_cursor.fetch_arrow_batches():
                yield from table.to_batches()
        finally:
            raw_cursor.close()
    finally:
        conn.close()


def _rows_to_record_batch(columns: tuple[str, ...], rows: list[tuple[object, ...]]) -> pa.RecordBatch:
    """Build a PyArrow RecordBatch from a list of row tuples."""
    columns_dict: dict[str, list[object]] = {
        col: [row[i] for row in rows] for i, col in enumerate(columns)
    }
    return pa.RecordBatch.from_pydict(columns_dict)


def coerce_aggregate_value(raw: object) -> int | float | None:
    """Narrow a cursor cell to the :class:`AggregateResult` value type."""
    if raw is None:
        return None
    if isinstance(raw, (int, float)):
        return raw
    return float(str(raw))


def coerce_int(raw: object) -> int:
    """Narrow a cursor cell that must be an integer count."""
    if raw is None:
        return 0
    if isinstance(raw, int):
        return raw
    return int(str(raw))


def coerce_pk_array(raw: object) -> tuple[PrimaryKey, ...]:
    """Normalise a main-scan ``ARRAY_AGG`` cell into a tuple of PK tuples."""
    if raw is None:
        return ()
    if not isinstance(raw, (list, tuple)):
        msg = f"unexpected PK array type: {type(raw).__name__}"
        raise TypeError(msg)
    pks: list[PrimaryKey] = []
    for value in raw:
        if isinstance(value, (list, tuple)):
            pks.append(tuple(value))
            continue
        pks.append((value,))
    return tuple(pks)
