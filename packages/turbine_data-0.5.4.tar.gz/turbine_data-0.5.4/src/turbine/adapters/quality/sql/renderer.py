"""Plan-level SQL renderer: assembles main + sibling SELECTs per :class:`DatasetPlan`.

Every plan renders to one main ``WITH ds AS (...) SELECT ...`` statement for
aggregates and PK arrays, plus two sibling statement shapes when the plan
carries the matching slot kind:

* **ColumnFetchSlot** — ``WITH ds AS (...) SELECT ... FROM ds`` sharing the
  CTE so the filter is pushed down once per read and warehouses can hit the
  result cache when the CTE matches the main-plan CTE.
* **FailedRowsSlot** — the user-authored SELECT executed verbatim. The plan
  filter is not applied; the author's query is respected as-is.

:func:`render_plan_statements` returns all three shapes bundled as
:class:`PlanStatements`. :func:`render_plan` stays as a thin shim returning
only the main SQL for callers that don't need the siblings.

A standalone :func:`render_pk_fallback` still handles the overflowed-PK
streaming path.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, replace

from sqlglot import exp

from turbine.core.quality.plan.dataset_plan import DatasetPlan
from turbine.core.quality.plan.predicates import WindowedRowFilterPredicate
from turbine.core.quality.plan.requester import Requester
from turbine.core.quality.plan.slots import (
    AggregateSlot,
    ColumnFetchSlot,
    FailedRowsSlot,
    PkSlot,
    SampleSlot,
    Slot,
    SlotId,
    dedup_slots,
)

from .dialect_capabilities import DialectCapabilities
from .predicate_renderer import (
    CteRegistry,
    array_agg_filtered_pks,
    count_filtered,
    render_aggregate,
    render_failing_rows,
    row_count_projection,
)
from .windowed_renderer import render_windowed_pk_fallback, render_windowed_plan


@dataclass(frozen=True, slots=True)
class PlanStatements:
    """All SQL statements a :class:`DatasetPlan` needs to run.

    ``main`` is the aggregate + PK scan every plan carries. ``column_fetches``
    is keyed by :class:`ColumnFetchSlot` id; ``failed_rows`` is keyed by
    :class:`FailedRowsSlot` id. Either mapping is empty when the plan has no
    slot of that kind.
    """

    main: str
    column_fetches: Mapping[SlotId, str]
    failed_rows: Mapping[SlotId, str]


def render_plan_statements(plan: DatasetPlan, caps: DialectCapabilities) -> PlanStatements:
    """Render every SQL statement *plan* needs against *caps*'s dialect."""
    return PlanStatements(
        main=render_plan(plan, caps),
        column_fetches=render_column_fetches(plan, caps),
        failed_rows=render_failed_rows_queries(plan),
    )


def render_plan(plan: DatasetPlan, caps: DialectCapabilities) -> str:
    """Return the main aggregate + PK SQL for *plan* in *caps* dialect."""
    if is_windowed_plan(plan):
        return render_windowed_plan(plan, caps)
    return build_plan_select(plan, caps).sql(dialect=caps.dialect.value)


def render_column_fetches(plan: DatasetPlan, caps: DialectCapabilities) -> dict[SlotId, str]:
    """Render each :class:`ColumnFetchSlot` as a sibling SELECT over the ``ds`` CTE."""
    fetches: dict[SlotId, str] = {}
    for slot in plan.slots:
        if isinstance(slot, ColumnFetchSlot):
            fetches[slot.id] = render_column_fetch(plan, slot, caps)
    return fetches


def render_column_fetch(plan: DatasetPlan, slot: ColumnFetchSlot, caps: DialectCapabilities) -> str:
    """Render ``WITH ds AS NOT MATERIALIZED (...) SELECT <cols> FROM ds`` for one ColumnFetchSlot.

    Sharing the ``ds`` CTE with the main plan lets the filter push down once
    per read and lets warehouses serve the second read from the result cache
    when the CTE matches the main-plan CTE. ``NOT MATERIALIZED`` keeps the
    Postgres planner free to inline the CTE so predicate/index pushdown is
    not blocked.
    """
    ds_cte = build_ds_cte(plan)
    projections = [exp.Star() if name == "*" else exp.column(name) for name in slot.columns]
    fetch = exp.Select(expressions=projections).from_(exp.to_identifier("ds"))
    return fetch.with_("ds", as_=ds_cte, materialized=False).sql(dialect=caps.dialect.value)


def render_failed_rows_queries(plan: DatasetPlan) -> dict[SlotId, str]:
    """Collect each :class:`FailedRowsSlot`'s user-authored query verbatim."""
    queries: dict[SlotId, str] = {}
    for slot in plan.slots:
        if isinstance(slot, FailedRowsSlot):
            queries[slot.id] = slot.query
    return queries


def is_windowed_plan(plan: DatasetPlan) -> bool:
    """Return True when any slot's predicate is a ``WindowedRowFilterPredicate``."""
    return any(
        isinstance(slot, PkSlot) and isinstance(slot.predicate, WindowedRowFilterPredicate)
        for slot in plan.slots
    )


def build_plan_select(plan: DatasetPlan, caps: DialectCapabilities) -> exp.Expr:
    """Build the sqlglot AST for the main plan SELECT (not yet rendered).

    Marks ``ds`` as ``NOT MATERIALIZED`` so Postgres can inline the CTE
    instead of materialising the full table for each reference. Without
    this hint, multi-reference CTEs (e.g. when a DuplicatePredicate's
    GROUP BY subquery scans ``ds`` again) force a hash-table copy and
    block index/filter pushdown into the base scan.

    Repeated subqueries inside projections (most importantly the duplicate-
    key set referenced 3x per PkSlot) are interned into a :class:`CteRegistry`
    while building projections, then prepended as their own CTEs ahead of
    ``ds``. Each subquery is computed once; references become hash semi-join
    probes rather than rerun SubPlans.
    """
    registry = CteRegistry()
    ds_cte = build_ds_cte(plan)
    projections = list(build_projections(plan.slots, caps, registry=registry))
    main_select = exp.Select(expressions=projections).from_(exp.to_identifier("ds"))
    main_select = main_select.with_("ds", as_=ds_cte, materialized=False)
    for cte_name, cte_ast in registry.ctes.items():
        main_select = main_select.with_(cte_name, as_=cte_ast)
    return main_select


def build_ds_cte(plan: DatasetPlan) -> exp.Select:
    """Build ``SELECT * FROM <table> WHERE <filter>`` — the shared ``ds`` input."""
    table_name = str(plan.dataset)
    select_star = exp.select(exp.Star()).from_(table_name)
    if plan.filter is None:
        return select_star
    return select_star.where(plan.filter.ast.copy())


def build_projections(
    slots: tuple[Slot, ...], caps: DialectCapabilities, *, registry: CteRegistry | None = None
) -> list[exp.Expr]:
    """Expand *slots* into aliased projection expressions.

    Every plan gets a ``COUNT(*) AS turbine_row_count`` projection so the
    executor can report ``DatasetMeasurement.row_count`` from a single main
    scan — the same "rows tested" figure surfaced on every ``CheckResult``.

    *registry* is forwarded to PkSlot rendering so duplicate-key subqueries
    can be hoisted into shared CTEs by the caller.
    """
    projections: list[exp.Expr] = [row_count_projection()]
    for slot in slots:
        if isinstance(slot, AggregateSlot):
            projections.append(render_aggregate_slot(slot, caps, registry=registry))
        elif isinstance(slot, PkSlot):
            projections.extend(render_pk_slot(slot, caps, registry=registry))
        elif isinstance(slot, (SampleSlot, ColumnFetchSlot, FailedRowsSlot)):
            continue
    return projections


def render_aggregate_slot(
    slot: AggregateSlot, caps: DialectCapabilities, *, registry: CteRegistry | None = None
) -> exp.Expr:
    """Aliased aggregate projection for *slot*.

    Forwards *registry*/dialect so DuplicatePredicate aggregates can share
    the ``keycounts`` CTE with the failing-rows test instead of emitting a
    second sort-spilling ``COUNT(DISTINCT)``.
    """
    expression = render_aggregate(slot.predicate, registry, caps.dialect.value)
    return exp.alias_(expression, slot.id)


def render_pk_slot(
    slot: PkSlot, caps: DialectCapabilities, *, registry: CteRegistry | None = None
) -> list[exp.Expr]:
    """Two projections per PK slot: overflow-wrapped array + companion count.

    Renders the failing-rows predicate once and reuses it (via copies) for
    every projection that needs it. When *registry* is supplied, predicates
    that contain repeatable subqueries hoist into a shared CTE so the three
    references below resolve to one underlying scan.
    """
    failing = render_failing_rows(slot.predicate, registry, caps.dialect.value)
    array_expr = render_pk_array_with_overflow(slot, failing, caps)
    count_expr = count_filtered(failing.copy())
    return [exp.alias_(array_expr, slot.id), exp.alias_(count_expr, f"count_{slot.id}")]


def render_pk_array_with_overflow(
    slot: PkSlot, failing: exp.Expr, caps: DialectCapabilities
) -> exp.Expr:
    """Wrap the PK array in a ``CASE WHEN count > pk_cap THEN NULL ELSE array END`` guard.

    When ``caps.pk_cap`` is ``None`` (DuckDB in-process default), skip the
    overflow guard and emit the plain filtered ARRAY_AGG.
    """
    array_expr = array_agg_filtered_pks(slot.pk_columns, failing.copy(), caps)
    if caps.pk_cap is None:
        return array_expr
    overflow_count = count_filtered(failing.copy())
    condition = exp.GT(this=overflow_count, expression=exp.convert(caps.pk_cap))
    return exp.Case().when(condition, exp.null()).else_(array_expr)


def render_pk_fallback(plan: DatasetPlan, slot: PkSlot, caps: DialectCapabilities) -> str:
    """Sibling SELECT that streams the failing PKs when the main array overflowed."""
    if isinstance(slot.predicate, WindowedRowFilterPredicate):
        return render_windowed_pk_fallback(plan, slot, caps)
    failing = render_failing_rows(slot.predicate)
    pk_columns = [exp.column(column) for column in slot.pk_columns]
    ds_cte = build_ds_cte(plan)
    fallback = exp.Select(expressions=pk_columns).from_(exp.to_identifier("ds")).where(failing)
    return fallback.with_("ds", as_=ds_cte, materialized=False).sql(dialect=caps.dialect.value)


def split_if_oversized(
    plan: DatasetPlan, requesters: tuple[Requester, ...], caps: DialectCapabilities
) -> tuple[tuple[DatasetPlan, tuple[Requester, ...]], ...]:
    """Recursively halve *(plan, requesters)* by requester until each piece fits.

    Splits by requester (not by slot) so every slot a given requester needs
    stays on the same plan; otherwise :meth:`Requester.interpret` would see
    half its binding results missing.
    """
    if caps.max_sql_len is None:
        return ((plan, requesters),)
    rendered = render_plan(plan, caps)
    if len(rendered) <= caps.max_sql_len:
        return ((plan, requesters),)
    if len(requesters) <= 1:
        return ((plan, requesters),)
    midpoint = len(requesters) // 2
    left_plan = rebuild_plan_for_requesters(plan, requesters[:midpoint])
    right_plan = rebuild_plan_for_requesters(plan, requesters[midpoint:])
    return split_if_oversized(left_plan, requesters[:midpoint], caps) + split_if_oversized(
        right_plan, requesters[midpoint:], caps
    )


def rebuild_plan_for_requesters(plan: DatasetPlan, requesters: tuple[Requester, ...]) -> DatasetPlan:
    """Replace *plan*'s slots with the ones from *requesters*' bindings."""
    slots = dedup_slots(
        tuple(binding.slot for requester in requesters for binding in requester.bindings())
    )
    return replace(plan, slots=slots)
