"""SQL adapters for the batched dataset executor."""
