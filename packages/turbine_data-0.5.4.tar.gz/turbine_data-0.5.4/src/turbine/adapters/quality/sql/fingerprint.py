"""Per-check semantic fingerprint used as the era key in ``check_fingerprint``.

The fingerprint is a ``blake2b(16)`` digest over four fields that define a
check's semantic identity:

* ``sql_template``: ``check_type:column:params``, where ``params`` is the
  deterministic JSON dump of the metric config's ``params`` (empty for
  checks without one). Changing the check type, its column, or its params
  flips the hash.
* ``filter_raw``: the per-check filter as written, or ``""`` when absent.
* ``threshold``: ``json.dumps(..., sort_keys=True)`` of the threshold, so
  two thresholds that serialize the same share a fingerprint.
* ``dialect``: the backend the check ran against. Rendered SQL differs per
  backend, and eras should not compare across dialects.

Display name, description, severity tags, quality dimension, and owner are
not part of the fingerprint, so renaming or retagging a check keeps its
history under the same era.

Pure helpers — no SQL, no I/O. The batched writer consumes them when it
packages fingerprint rows for the one-INSERT-per-plan batch.
"""

from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from hashlib import blake2b
from typing import Any

from turbine.core.common import CheckDef, DataSourceType
from turbine.core.common.dataset_spec.checks import MetricCheckConfig

FP_DIGEST_SIZE = 16


def compute_fp_sha(check: CheckDef, *, dialect: DataSourceType) -> bytes:
    """Return the 16-byte fingerprint for *check* under *dialect*."""
    sql_template = derive_sql_template(check)
    filter_raw = check.filter.raw if check.filter is not None else ""
    threshold_blob = serialize_threshold(check)

    payload = f"{sql_template}|{filter_raw}|{threshold_blob}|{dialect.value}"
    return blake2b(payload.encode("utf-8"), digest_size=FP_DIGEST_SIZE).digest()


def derive_sql_template(check: CheckDef) -> str:
    """Return the ``check_type:column:params`` identity string for *check*.

    ``params`` is the deterministic JSON dump of ``MetricCheckConfig.params``
    (``exclude_none=True``), or ``""`` when the check has no metric config
    or no params. ``column`` is ``""`` when the check is column-less.
    """
    column = check.column or ""
    params_blob = ""
    if isinstance(check.config, MetricCheckConfig) and check.config.params is not None:
        params_blob = json.dumps(
            check.config.params.model_dump(exclude_none=True), sort_keys=True, default=str
        )
    return f"{check.check_type}:{column}:{params_blob}"


def serialize_threshold(check: CheckDef) -> str:
    """Return a deterministic JSON blob for *check*'s threshold, or ``""`` if none."""
    threshold = check.threshold
    if threshold is None:
        return ""
    return json.dumps(to_jsonable(threshold), sort_keys=True, default=str)


def to_jsonable(value: Any) -> Any:
    """Recursively coerce dataclasses, tuples, and nested dicts into JSON-safe types."""
    if is_dataclass(value) and not isinstance(value, type):
        return {key: to_jsonable(inner) for key, inner in asdict(value).items()}
    if isinstance(value, (list, tuple)):
        return [to_jsonable(inner) for inner in value]
    if isinstance(value, dict):
        return {key: to_jsonable(inner) for key, inner in value.items()}
    return value
