r"""BatchedCheckRunner: plans + executes derivable (BATCHED + CUSTOM_SQL) checks.

Owns every step of the batched route:

* Builds :class:`RequesterBinding`\ s from each :class:`CheckDef`.
* Groups them into :class:`DatasetPlan`\ s via :class:`DatasetPlanner`.
* Executes each plan through an injected :class:`DatasetExecutor`,
  wrapping the blocking call in ``asyncio.to_thread``.
* Distributes each measurement across requesters via
  :class:`MeasurementDispatcher` to produce per-check outcomes.
* Publishes its own route-specific lifecycle events
  (:class:`DatasetScanned` / :class:`PlanFailed`) onto the injected
  event bus; the orchestrator never reaches into plan internals.

Implements :class:`turbine.core.quality.CheckRunner`. Replaces the
``stream_derivable`` path that used to live inside ``CheckUseCase``.
"""

from __future__ import annotations

import asyncio
import dataclasses
from collections.abc import AsyncIterator, Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from uuid import UUID

from jinja2 import Environment, StrictUndefined, TemplateError

from turbine.adapters.quality.python.data_loader import SqlExecutor
from turbine.adapters.quality.python.requester import PythonRequester
from turbine.adapters.quality.python.runner import ResolvedFunction, validate_python_check
from turbine.core.common import CheckDef, DatasetSpec, DataSourceType, PythonCheckConfig, SqlCheckConfig
from turbine.core.common.dataset_spec.checks import MetricType, classify_metric_type
from turbine.core.quality.check_results import CheckResult
from turbine.core.quality.check_runner import RunnerYield
from turbine.core.quality.check_validation import DataFrameLibrary, introspect_check_function
from turbine.core.quality.events import DatasetScanned, PlanFailed
from turbine.core.quality.plan.dataset_key import DatasetKey
from turbine.core.quality.plan.dataset_plan import DatasetPlan
from turbine.core.quality.plan.errors import PlanExecutionError
from turbine.core.quality.plan.measurement import DatasetMeasurement
from turbine.core.quality.plan.predicates import PkCapablePredicate
from turbine.core.quality.plan.predicates.factory import build_anomaly_predicate, build_predicate
from turbine.core.quality.plan.requester import Requester
from turbine.core.quality.plan.slots import (
    AggregateSlot,
    ColumnFetchSlot,
    FailedRowsSlot,
    PkSlot,
    SlotId,
)
from turbine.core.quality.planning.anomaly_requester import AnomalyRequester
from turbine.core.quality.planning.dispatcher import MeasurementDispatcher
from turbine.core.quality.planning.filter_resolver import FilterResolver
from turbine.core.quality.planning.planner import DatasetPlanner, PlannedWork
from turbine.core.quality.planning.requesters import CheckRequester, CustomSqlRequester
from turbine.core.quality.ports import DatasetExecutor, ExecutionOptions
from turbine.core.shared import FilterExpr

PythonExecutorFactory = Callable[[DataFrameLibrary], SqlExecutor]
type RequesterBuildResult = Requester | CheckResult | None
SQL_TEMPLATE_ENV = Environment(autoescape=False, undefined=StrictUndefined)


@dataclass
class SlotCounters:
    """Emits deterministic slot ids per requester binding, one prefix per family."""

    counts: dict[str, int] = dataclasses.field(default_factory=dict)

    def next_id(self, prefix: str) -> SlotId:
        """Return the next ``{prefix}_N`` id, incrementing the per-prefix counter."""
        index = self.counts.get(prefix, 0)
        self.counts[prefix] = index + 1
        return SlotId(f"{prefix}_{index}")


class BatchedCheckRunner:
    r"""Run derivable checks through the planner + executor + dispatcher pipeline.

    Also owns the Python-check path: ``category: python`` checks become
    :class:`PythonRequester`\ s whose primary DataFrame is materialised
    via the same :class:`DatasetPlan` as every other check.
    ``python_executor_factory`` + ``checks_dir`` are required when the
    contract contains Python checks; both default to ``None`` so non-Python
    pipelines wire up without extra config.
    """

    def __init__(  # noqa: PLR0913 — seven collaborators, all required for mixed SQL + Python plans
        self,
        *,
        dialect: DataSourceType,
        executor: DatasetExecutor,
        planner: DatasetPlanner,
        dispatcher: MeasurementDispatcher,
        filter_resolver: FilterResolver,
        python_executor_factory: PythonExecutorFactory | None = None,
        checks_dir: Path | None = None,
    ) -> None:
        """Store the batched-route collaborators."""
        self.dialect = dialect
        self.executor = executor
        self.planner = planner
        self.dispatcher = dispatcher
        self.filter_resolver = filter_resolver
        self.python_executor_factory = python_executor_factory
        self.checks_dir = checks_dir

    async def run(
        self, checks: Sequence[CheckDef], contract: DatasetSpec, options: ExecutionOptions
    ) -> AsyncIterator[RunnerYield]:
        """Yield the plan event (``DatasetScanned`` or ``PlanFailed``) then per-check results.

        Each per-check result carries the plan's ``duration_ms`` so the
        orchestrator's :class:`CheckCompleted` event preserves timing.
        Per-check requester construction and per-plan execution are both
        isolated: a single broken check or plan turns into an errored
        ``CheckResult`` for that check only, never aborts the run.
        """
        if not checks:
            return
        requesters, build_errors = self.build_requesters(contract, tuple(checks), options)
        for errored in build_errors:
            yield errored
        works = self.planner.plan(requesters)
        for work in works:
            outcome = await self.run_plan_safely(work)
            for item in self.outcome_items(work, outcome, options.run_id):
                yield item

    async def run_plan_safely(self, work: PlannedWork) -> DatasetMeasurement | PlanExecutionError:
        """Execute *work*'s plan, converting an unexpected exception into a PlanExecutionError.

        ``DatasetExecutor.execute`` already returns a :class:`PlanExecutionError`
        for SQLAlchemy errors. Anything else (renderer crash, predicate
        with no failing-rows handler, ...) used to bubble up and abort the
        whole run; we wrap it here so the affected requesters become
        errored CheckResults but every other plan keeps going.
        """
        try:
            return await asyncio.to_thread(self.executor.execute, work.plan)
        except Exception as exc:  # noqa: BLE001 — adapter boundary, surface as plan error
            return PlanExecutionError(plan=work.plan, reason=exc)

    def outcome_items(
        self, work: PlannedWork, outcome: DatasetMeasurement | PlanExecutionError, run_id: UUID
    ) -> list[RunnerYield]:
        """Return the plan's lifecycle event followed by its per-check results."""
        plan = work.plan
        dataset = DatasetKey(datasource_id=plan.datasource_id, dataset=plan.dataset)
        match outcome:
            case DatasetMeasurement() as measurement:
                items: list[RunnerYield] = [scanned_event(plan, measurement, run_id)]
                bundle = self.dispatcher.distribute(dataset, measurement, work.requesters)
                items.extend(
                    dataclasses.replace(result, duration_ms=measurement.duration_ms)
                    for result in bundle.checks
                )
                return items
            case PlanExecutionError() as error:
                errored_items: list[RunnerYield] = [plan_failed_event(plan, error, run_id)]
                errored_items.extend(
                    CheckResult.errored(requester_check(requester), error.reason)
                    for requester in work.requesters
                )
                return errored_items

    def build_requesters(
        self, contract: DatasetSpec, checks: tuple[CheckDef, ...], options: ExecutionOptions
    ) -> tuple[tuple[Requester, ...], tuple[CheckResult, ...]]:
        """Build requesters for *checks*; return them plus per-check construction errors.

        Per-check construction is isolated: a single check that raises during
        requester building (missing PK, unimplemented predicate, malformed
        config, ...) becomes a :class:`CheckResult.errored` for that check
        and the rest of the contract continues to plan and execute.
        """
        dataset_key = DatasetKey(datasource_id=self.dialect.value, dataset=contract.table)
        pk_columns = contract.pk_columns
        counters = SlotCounters()
        requesters: list[Requester] = []
        errors: list[CheckResult] = []

        for check in checks:
            try:
                build_result = self.build_one_requester(
                    check, contract, dataset_key, pk_columns, counters, options
                )
            except Exception as exc:  # noqa: BLE001 — adapter boundary, surface as errored result
                errors.append(CheckResult.errored(check, exc))
                continue
            if isinstance(build_result, CheckResult):
                errors.append(build_result)
                continue
            if build_result is not None:
                requesters.append(build_result)
        return tuple(requesters), tuple(errors)

    def build_one_requester(  # noqa: PLR0913 — one entry per requester input
        self,
        check: CheckDef,
        contract: DatasetSpec,
        dataset_key: DatasetKey,
        pk_columns: tuple[str, ...],
        counters: SlotCounters,
        options: ExecutionOptions,
    ) -> RequesterBuildResult:
        """Build a requester, or a check result when construction itself has an outcome."""
        metric_type = check.metric_type or classify_metric_type(check)
        if metric_type is MetricType.WINDOWED_ROW_FILTER:
            cte_filter, outer_filter = self.filter_resolver.resolve_anomaly_scopes(
                contract, check, options
            )
            return build_anomaly_requester(
                check, dataset_key, cte_filter, pk_columns, counters, outer_filter=outer_filter
            )
        if metric_type is MetricType.PYTHON:
            binding_filter = self.filter_resolver.resolve(contract, check, options)
            return self.build_python_requester(
                check, dataset_key, binding_filter, contract.pk_columns, counters, options
            )
        binding_filter = self.filter_resolver.resolve(contract, check, options)
        return build_requester(
            check, dataset_key, binding_filter, pk_columns, options, counters, self.checks_dir
        )

    def build_python_requester(  # noqa: PLR0913 — six collaborators, all required for Python-check wiring
        self,
        check: CheckDef,
        dataset: DatasetKey,
        filter_expr: FilterExpr | None,
        pk_columns: tuple[str, ...],
        counters: SlotCounters,
        options: ExecutionOptions,
    ) -> PythonRequester | CheckResult:
        """Resolve a Python check and wire it into a :class:`PythonRequester`.

        Resolution failures are already check-level outcomes. Return them
        to the route runner so invalid Python checks are reported instead
        of disappearing from the run plan.
        """
        if self.python_executor_factory is None or self.checks_dir is None:
            return CheckResult.errored(
                check,
                RuntimeError(
                    "python check runner is not configured; provide a Python executor factory and "
                    "checks directory"
                ),
            )
        config = check.require_config(PythonCheckConfig)
        validated = validate_python_check(check, config, self.checks_dir)
        if isinstance(validated, CheckResult):
            return validated
        resolved: ResolvedFunction = validated
        primary_slot = ColumnFetchSlot(
            id=counters.next_id("cols"), columns=("*",), library=resolved.library
        )
        sql_executor = self.python_executor_factory(resolved.library)
        return PythonRequester(
            check=check,
            dataset=dataset,
            config=config,
            resolved=resolved,
            filter=filter_expr,
            primary_slot=primary_slot,
            input_spec=introspect_check_function(resolved.func),
            sql_executor=sql_executor,
            pk_columns=pk_columns,
            flag_rows=options.flag_rows,
        )


def build_requester(  # noqa: PLR0913 — dataset + filter + pk + options + counters + checks_dir is the minimal set
    check: CheckDef,
    dataset: DatasetKey,
    filter_expr: FilterExpr | None,
    pk_columns: tuple[str, ...],
    options: ExecutionOptions,
    counters: SlotCounters,
    checks_dir: Path | None = None,
) -> CheckRequester | CustomSqlRequester | AnomalyRequester:
    """Build the requester that matches *check*'s metric type."""
    metric_type = check.metric_type or classify_metric_type(check)
    if metric_type is MetricType.CUSTOM_SQL:
        return build_custom_sql_requester(
            check, dataset, filter_expr, pk_columns, options, counters, checks_dir
        )
    if metric_type is MetricType.WINDOWED_ROW_FILTER:
        return build_anomaly_requester(check, dataset, filter_expr, pk_columns, counters)
    return build_check_requester(check, dataset, filter_expr, pk_columns, options, counters)


def build_anomaly_requester(  # noqa: PLR0913 — dataset + filter + pk + counters + outer_filter is the minimal set
    check: CheckDef,
    dataset: DatasetKey,
    filter_expr: FilterExpr | None,
    pk_columns: tuple[str, ...],
    counters: SlotCounters,
    *,
    outer_filter: FilterExpr | None = None,
) -> AnomalyRequester:
    """Build an :class:`AnomalyRequester` carrying a single windowed PK slot."""
    if not pk_columns:
        msg = f"anomaly check {check.name!r} requires a primary key on the contract"
        raise ValueError(msg)
    predicate = build_anomaly_predicate(check)
    slot = PkSlot(id=counters.next_id("pk"), predicate=predicate, pk_columns=pk_columns)
    return AnomalyRequester(
        check=check, dataset=dataset, filter=filter_expr, pk_slot=slot, outer_filter=outer_filter
    )


def build_custom_sql_requester(  # noqa: PLR0913 — check + dataset + filter + pk + options + counters + checks_dir is the minimal set
    check: CheckDef,
    dataset: DatasetKey,
    filter_expr: FilterExpr | None,
    pk_columns: tuple[str, ...],
    options: ExecutionOptions,
    counters: SlotCounters,
    checks_dir: Path | None = None,
) -> CustomSqlRequester:
    """Build a requester carrying the user-authored failed-rows SELECT.

    For the predicate form (``SqlCheckConfig.predicate is not None``),
    Turbine renders Jinja placeholders in the predicate and then wraps
    it as ``SELECT * FROM <dataset> WHERE [(filter) AND] NOT
    (<predicate>)`` so ``rows_failed`` and ``rows_tested`` share the
    dataset's filtered scope. For the full-query form, the user's SELECT
    runs verbatim after Jinja rendering.
    """
    table = str(dataset.dataset)
    since = options.since.isoformat() if options.since else None
    until = options.until.isoformat() if options.until else None
    if isinstance(check.config, SqlCheckConfig) and check.config.predicate is not None:
        rendered_predicate = render_sql_check_query(
            check.config.predicate, check.config.params, table=table, since=since, until=until
        )
        # Use the raw filter source so the wrapped scope matches what the user
        # authored. The main-scan ``ds`` CTE renders the filter through sqlglot
        # (renderer.py: build_ds_cte), so dialect-canonicalisation differences
        # between the two scans are theoretically possible; in practice the
        # filter is parsed for the dataset's dialect and ASCII-safe filters
        # round-trip identically. Tracked under ADR 0014 / architecture.md gaps.
        filter_sql = filter_expr.raw if filter_expr is not None else None
        query = wrap_predicate_query(rendered_predicate, table=table, filter_sql=filter_sql)
    else:
        query = extract_query(check, checks_dir)
        if isinstance(check.config, SqlCheckConfig):
            query = render_sql_check_query(
                query, check.config.params, table=table, since=since, until=until
            )
    slot = FailedRowsSlot(id=counters.next_id("rows"), query=query)
    return CustomSqlRequester(
        check=check,
        dataset=dataset,
        filter=filter_expr,
        failed_rows_slot=slot,
        pk_columns=pk_columns,
        flag_rows=options.flag_rows,
    )


def render_sql_check_query(
    query: str,
    params: Mapping[str, object],
    *,
    table: str = "",
    since: str | None = None,
    until: str | None = None,
) -> str:
    """Render Jinja placeholders in a custom SQL query.

    Always-available variables:
    - ``{{ this }}`` — fully-qualified target table name
    - ``{{ since }}`` — ISO datetime string of the incremental lower bound, or None
    - ``{{ until }}`` — ISO datetime string of the incremental upper bound, or None
    - ``{{ var("<key>") }}`` — user-supplied params from the quality spec
    """
    try:

        def var(key: str) -> object:
            return params.get(key)

        return SQL_TEMPLATE_ENV.from_string(query).render(var=var, this=table, since=since, until=until)
    except TemplateError as exc:
        msg = f"cannot render SQL template params: {exc}"
        raise ValueError(msg) from exc


def wrap_predicate_query(predicate: str, *, table: str, filter_sql: str | None) -> str:
    """Wrap a boolean SQL predicate into a failed-rows SELECT.

    Produces ``SELECT * FROM <table> WHERE [(filter_sql) AND] NOT
    (<predicate>)``. The dataset filter is inlined so the wrapped scope
    matches the main scan's filtered ``ds`` CTE; that keeps
    ``rows_failed`` and ``rows_tested`` (= ``outcome.row_count``) on the
    same row population, so ``compare: percent`` has a well-defined
    denominator per ADR 0014.

    The caller is responsible for rendering Jinja placeholders in the
    predicate beforehand (typically via :func:`render_sql_check_query`)
    so the user gets the same template authoring affordances on either
    form.
    """
    if filter_sql:
        return f"SELECT * FROM {table} WHERE ({filter_sql}) AND NOT ({predicate})"
    return f"SELECT * FROM {table} WHERE NOT ({predicate})"


def extract_query(check: CheckDef, checks_dir: Path | None = None) -> str:
    """Return the SELECT text — inline ``query``, or read from ``file_path``."""
    query = getattr(check.config, "query", None)
    if isinstance(query, str):
        return query
    file_path = getattr(check.config, "file_path", None)
    if checks_dir is not None and isinstance(file_path, Path) and str(file_path) not in ("", "."):
        candidate = checks_dir / file_path
        if candidate.is_file():
            return candidate.read_text()
    msg = f"custom-sql check {check.name!r} has no query text"
    raise TypeError(msg)


def build_check_requester(  # noqa: PLR0913 — dataset + filter + pk + options + counters is the minimal set
    check: CheckDef,
    dataset: DatasetKey,
    filter_expr: FilterExpr | None,
    pk_columns: tuple[str, ...],
    options: ExecutionOptions,
    counters: SlotCounters,
) -> CheckRequester:
    """Build an aggregate + optional-PK requester for a derivable check."""
    predicate = build_predicate(check, pk_columns=pk_columns)
    aggregate_slot = AggregateSlot(id=counters.next_id("agg"), predicate=predicate)
    pk_slot: PkSlot | None = None
    if pk_columns and isinstance(predicate, PkCapablePredicate):
        pk_slot = PkSlot(id=counters.next_id("pk"), predicate=predicate, pk_columns=pk_columns)
    effective_pk = pk_slot if options.flag_rows else None
    return CheckRequester(
        check=check,
        dataset=dataset,
        filter=filter_expr,
        aggregate_slot=aggregate_slot,
        pk_slot=effective_pk,
    )


def requester_check(requester: object) -> CheckDef:
    """Return the :class:`CheckDef` attached to *requester*."""
    check = getattr(requester, "check", None)
    if not isinstance(check, CheckDef):
        msg = f"requester {type(requester).__name__} has no CheckDef"
        raise TypeError(msg)
    return check


def scanned_event(plan: DatasetPlan, measurement: DatasetMeasurement, run_id: UUID) -> DatasetScanned:
    """Build a :class:`DatasetScanned` event from a successful plan outcome."""
    return DatasetScanned(
        run_id=run_id,
        datasource_id=plan.datasource_id,
        dataset=str(plan.dataset),
        filter_raw=plan.filter.raw if plan.filter else None,
        duration_ms=measurement.duration_ms,
        row_count=measurement.row_count,
    )


def plan_failed_event(plan: DatasetPlan, error: PlanExecutionError, run_id: UUID) -> PlanFailed:
    """Build a :class:`PlanFailed` event from a plan-level execution error."""
    return PlanFailed(
        run_id=run_id,
        datasource_id=plan.datasource_id,
        dataset=str(plan.dataset),
        filter_raw=plan.filter.raw if plan.filter else None,
        error_type=type(error.reason).__name__,
        error_message=str(error.reason),
    )
