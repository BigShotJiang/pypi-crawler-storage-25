"""``SqlQualityViewWriter``: refresh the user-facing ``{table}_quality`` view.

Defines the view as pure SQL on top of ``{schema}.flag_matrix`` so the
data is never duplicated. The view aggregates the matrix at query time;
``flag_matrix``'s composite indexes on ``(datasource, dataset, …)``
make that scan cheap.

A SQL view can only span schemas inside the same database. So this
writer creates the view only when the data warehouse and the metadata
store share a SQLAlchemy URL — Postgres-data + Postgres-metadata in the
same DB, or DuckDB-data + DuckDB-metadata in the same file. When they
differ (the default DuckDB case, where data lives in ``data.duckdb``
and metadata in ``.turbine/metadata.duckdb``), the writer logs an info
line and skips view creation. End users in that case query
``{schema}.flag_matrix`` in the metadata store directly.

DDL is best-effort: if the connection role lacks ``CREATE VIEW``
permission, the writer logs a warning and the run continues.
``flag_matrix`` in the metadata store remains the source of truth.
"""

from __future__ import annotations

from collections.abc import Sequence

from loguru import logger
from sqlalchemy import Engine, text

VIEW_SUFFIX = "_quality"


class SqlQualityViewWriter:
    """Create a ``{table}_quality`` view that joins the data table with ``flag_matrix``."""

    def __init__(
        self, data_engine: Engine, metadata_engine: Engine, metadata_schema: str, datasource: str
    ) -> None:
        """Bind the data warehouse engine, the metadata engine, and the scoping keys."""
        self.data_engine = data_engine
        self.metadata_engine = metadata_engine
        self.metadata_schema = metadata_schema
        self.datasource = datasource

    def refresh(self, dataset: str, pk_columns: Sequence[str]) -> None:
        """Recreate the ``{table}_quality`` view; no-op without a PK or across DBs."""
        if not pk_columns:
            return
        if not self.same_database():
            logger.info(
                f"metadata store and data warehouse are on different databases; "
                f"skipping {dataset}{VIEW_SUFFIX} view (query "
                f"{self.metadata_schema}.turbine_flag_matrix directly for flag history)"
            )
            return
        try:
            self.create_quality_view(dataset, pk_columns)
        except Exception as exc:  # noqa: BLE001 - DDL on user warehouse is best-effort
            logger.warning(
                f"could not create {dataset}{VIEW_SUFFIX} view "
                f"(metadata still in turbine_flag_matrix): {exc}"
            )

    def same_database(self) -> bool:
        """Return True when data and metadata SQLAlchemy URLs point at the same DB."""
        return self.data_engine.url == self.metadata_engine.url

    def create_quality_view(self, dataset: str, pk_columns: Sequence[str]) -> None:
        """Emit ``CREATE OR REPLACE VIEW`` joining the source table with ``turbine_flag_matrix``."""
        view = qualified_name(dataset, VIEW_SUFFIX)
        join_key = pk_uuid_expr(pk_columns)
        flag_matrix_table = f"{self.metadata_schema}.turbine_flag_matrix"
        sql = (
            f"CREATE OR REPLACE VIEW {view} AS "
            f"SELECT t.*, "
            f"  COALESCE(f.failing_checks, '') AS failing_checks, "
            f"  COALESCE(f.failing_check_count, 0) AS failing_check_count, "
            f"  f.last_flagged_at, "
            f"  f.last_tested_at, "
            f"  (COALESCE(f.failing_check_count, 0) > 0) AS is_flagged "
            f"FROM {dataset} t "
            f"LEFT JOIN ("
            f"  SELECT "
            f"    pk_uuid, "
            f"    string_agg(check_name, ',' ORDER BY check_name) "
            f"      FILTER (WHERE last_flagged_at IS NOT NULL) AS failing_checks, "
            f"    count(*) "
            f"      FILTER (WHERE last_flagged_at IS NOT NULL) AS failing_check_count, "
            f"    max(last_flagged_at) AS last_flagged_at, "
            f"    max(last_tested_at) AS last_tested_at "
            f"  FROM {flag_matrix_table} "
            f"  WHERE datasource = '{escape(self.datasource)}' "
            f"    AND dataset = '{escape(dataset)}' "
            f"  GROUP BY pk_uuid"
            f") f ON {join_key} = f.pk_uuid"
        )
        with self.data_engine.begin() as conn:
            conn.execute(text(sql))


def qualified_name(dataset: str, suffix: str) -> str:
    """Append *suffix* to the table portion of ``schema.table`` (or bare table).

    Preserves the schema prefix so the view sits next to its source table.
    """
    if "." in dataset:
        schema, table = dataset.rsplit(".", maxsplit=1)
        return f"{schema}.{table}{suffix}"
    return f"{dataset}{suffix}"


def pk_uuid_expr(pk_columns: Sequence[str]) -> str:
    """Build the SQL expression that mirrors ``pk_uuid_from_tuple`` for joining.

    Single PK becomes ``CAST(t.col AS VARCHAR)``; composite PKs concatenate
    with the same ``|`` separator and ``str(value)`` semantics Python uses,
    via ``COALESCE(CAST(... AS VARCHAR), 'None')``.
    """
    parts = [f"COALESCE(CAST(t.{col} AS VARCHAR), 'None')" for col in pk_columns]
    return " || '|' || ".join(parts) if len(parts) > 1 else f"CAST(t.{pk_columns[0]} AS VARCHAR)"


def escape(value: str) -> str:
    """Escape single quotes for inline literal embedding in DDL."""
    return value.replace("'", "''")
