"""QualitySpec JSON Schema registry.

Loads quality_spec.schema.json from the core package and caches it.
"""

import json
from functools import cache
from importlib.resources import files

from turbine.core.common import SchemaNode


@cache
def load_quality_spec_schema() -> SchemaNode:
    """Load the quality_spec.schema.json from the core schemas package."""
    schema_dir = files("turbine.core.analysis.schemas")
    schema_text = (schema_dir / "quality_spec.schema.json").read_text()
    return json.loads(schema_text)
