"""Quality spec reader — parse QualitySpec YAML into DatasetSpec.

Implements the FormatReader protocol. Converts a quality spec YAML
file into a single DatasetSpec with checks but no columns (columns
come from the referenced contract when merging).
"""

from collections.abc import Iterable
from dataclasses import dataclass, replace
from typing import Any, Protocol

from loguru import logger
from pydantic import BaseModel, ValidationError

from turbine.core.building_blocks import (
    DiagnosticBuilder,
    DiagnosticId,
    DiagnosticSink,
    TextRange,
    TurbineError,
)
from turbine.core.common import (
    CheckCategory,
    CheckDef,
    CheckSource,
    ContractMetadata,
    ContractStatus,
    DatasetSpec,
    Duration,
    QualityDimension,
    RawSource,
    SchemaValidator,
    TableIdentifier,
)
from turbine.core.common.dataset_spec import CheckConfig, PythonCheckConfig, SqlCheckConfig
from turbine.core.common.duration import ACCEPTED_SHAPES
from turbine.core.quality.spec_models import (
    BODY_MAP,
    CheckItemModel,
    MetricCheckBody,
    PythonCheckBody,
    QualitySpecShellModel,
    SqlCheckBody,
)
from turbine.core.shared import FilterExpr

# Metrics where the target column is part of the check's identity, so the
# generated check name includes the column suffix (e.g. ``missing:order_id``).
COLUMN_SCOPED_METRICS: frozenset[str] = frozenset({"missing", "duplicate", "invalid"})


def has_schema_rejected_metric_compare(
    raw_check: dict[str, Any], invalid_paths: frozenset[str], item_path: str
) -> bool:
    """Return True when schema validation already rejected ``compare`` on an aggregate metric."""
    if len(raw_check) != 1:
        return False
    check_type = next(iter(raw_check))
    body = raw_check[check_type]
    if not isinstance(body, dict) or "compare" not in body:
        return False
    body_cls = BODY_MAP.get(check_type) or MetricCheckBody
    if body_cls is not MetricCheckBody or check_type in MetricCheckBody.COMPARE_MODE_METRICS:
        return False
    check_path = f"{item_path}.{check_type}"
    compare_path = f"{check_path}.compare"
    return check_path in invalid_paths or compare_path in invalid_paths


@dataclass(frozen=True, slots=True)
class ConversionContext:
    """Stable context shared across all check conversions within a single read()."""

    check_source: CheckSource
    source: RawSource
    sink: DiagnosticSink


class ModelParser(Protocol):
    """Parser port for converting raw YAML into Pydantic models."""

    def parse[T: BaseModel](
        self, model_cls: type[T], source: RawSource, sink: DiagnosticSink
    ) -> T | None:
        """Parse *source* into *model_cls*, emitting diagnostics on failure."""
        ...


class QualitySpecReader:
    """Parse QualitySpec YAML into a DatasetSpec instance.

    Quality specs define checks on top of a data contract. The reader
    produces a DatasetSpec with checks but empty columns — merging with
    the target contract adds columns.
    """

    format_label = "quality_spec"

    def __init__(self, schema_validator: SchemaValidator, model_parser: ModelParser) -> None:
        """Store validation dependencies."""
        self.schema_validator = schema_validator
        self.model_parser = model_parser

    def can_read(self, data: dict[str, Any]) -> bool:
        """Return True if data has kind: QualitySpec."""
        return data.get("kind") == "QualitySpec"

    def read(self, source: RawSource, sink: DiagnosticSink) -> tuple[DatasetSpec, ...]:
        """Parse the quality spec and return a single DatasetSpec.

        Checks are validated one at a time so a single malformed check does not
        drop every sibling from the resulting spec. Schema-level diagnostics
        still fire for the bad check through the JSON Schema validator.
        """
        logger.debug(f"Reading quality spec: {source.path}")
        invalid_paths = self.schema_validator.validate(source.data, source, sink)
        shell = self.model_parser.parse(QualitySpecShellModel, source, sink)
        if shell is None:
            return self.fallback_from_yaml(source)
        ctx = ConversionContext(
            check_source=CheckSource(format_label=self.format_label, path=source.path),
            source=source,
            sink=sink,
        )
        checks: list[CheckDef] = []
        for col_idx, col in enumerate(shell.columns):
            parent_column_range = source.source_map.range_for_value(f"columns.{col_idx}.name")
            column_items = self.validate_check_items(
                col.checks, invalid_paths, key_prefix=f"columns.{col_idx}.checks"
            )
            checks.extend(
                self.collect_checks(
                    column_items,
                    ctx,
                    key_prefix=f"columns.{col_idx}.checks",
                    column=col.name,
                    parent_column_range=parent_column_range,
                )
            )
        quality_items = self.validate_check_items(shell.quality, invalid_paths, key_prefix="quality")
        checks.extend(self.collect_checks(quality_items, ctx, key_prefix="quality"))
        metadata = ContractMetadata(
            contract_id=shell.id,
            version=shell.version,
            status=ContractStatus.DRAFT,
            owner=shell.owner,
            source_format=self.format_label,
            source_path=source.path,
        )
        target_contract_source_range = (
            source.source_map.range_for_value("targetContract") if shell.target_contract else None
        )
        dataset_source_range = source.source_map.range_for_value("dataset")
        dataset_spec = DatasetSpec(
            table=TableIdentifier.parse(shell.dataset),
            columns=(),
            checks=tuple(checks),
            sla=None,
            metadata=metadata,
            target_contract=shell.target_contract,
            target_contract_source_range=target_contract_source_range,
            dataset_source_range=dataset_source_range,
        )
        logger.debug(f"Converted quality spec to DatasetSpec: {dataset_spec.table}")
        return (dataset_spec,)

    def validate_check_items(
        self, raw_checks: list[dict[str, Any]], invalid_paths: frozenset[str], key_prefix: str
    ) -> list[tuple[int, CheckItemModel]]:
        """Validate raw check dicts one at a time; return (original_idx, model) pairs.

        Items that fail pydantic validation are skipped silently — the JSON
        Schema validator already emitted diagnostics for them on this same read.
        Preserving the original index keeps source-map lookups accurate in
        ``collect_checks``.
        """
        results: list[tuple[int, CheckItemModel]] = []
        for idx, raw in enumerate(raw_checks):
            if has_schema_rejected_metric_compare(raw, invalid_paths, f"{key_prefix}.{idx}"):
                continue
            try:
                item = CheckItemModel.model_validate(raw)
            except ValidationError:
                continue
            results.append((idx, item))
        return results

    def fallback_from_yaml(self, source: RawSource) -> tuple[DatasetSpec, ...]:
        """Extract a minimal DatasetSpec from raw YAML when pydantic parsing fails.

        Ensures cross-contract rules (target-not-found, dataset-mismatch)
        still fire even when the quality/checks section has validation errors.
        """
        data = source.data
        contract_id = data.get("id")
        dataset = data.get("dataset")
        if not isinstance(contract_id, str) or not isinstance(dataset, str):
            return ()
        target_contract = data.get("targetContract")
        if not isinstance(target_contract, str):
            target_contract = None
        owner = data.get("owner")
        if not isinstance(owner, str):
            owner = None
        metadata = ContractMetadata(
            contract_id=contract_id,
            version=str(data.get("version", "0.0.0")),
            status=ContractStatus.DRAFT,
            owner=owner,
            source_format=self.format_label,
            source_path=source.path,
        )
        dataset_spec = DatasetSpec(
            table=TableIdentifier.parse(dataset),
            columns=(),
            checks=(),
            sla=None,
            metadata=metadata,
            target_contract=target_contract,
            target_contract_source_range=source.source_map.range_for_value("targetContract"),
            dataset_source_range=source.source_map.range_for_value("dataset"),
        )
        return (dataset_spec,)

    def collect_checks(
        self,
        items: Iterable[tuple[int, CheckItemModel]],
        ctx: ConversionContext,
        key_prefix: str,
        column: str | None = None,
        parent_column_range: TextRange | None = None,
    ) -> list[CheckDef]:
        """Convert (original_idx, check_item) pairs into CheckDefs with source ranges.

        The original index must come from the raw check list so that source-map
        lookups (``{key_prefix}.{idx}.{check_type}``) stay aligned when earlier
        siblings are skipped due to validation errors.

        ``parent_column_range`` is used when the check lives under a column
        block (``columns[i].name``) — column references inherit their span
        from that parent ``name:`` value.
        """
        results: list[CheckDef] = []
        for idx, item in items:
            check_key = f"{key_prefix}.{idx}.{item.check_type}"
            source_range = ctx.source.source_map.range_for_value(check_key)
            column_range = (
                ctx.source.source_map.range_for_value(f"{check_key}.column") or parent_column_range
            )
            explicit_name_range = ctx.source.source_map.range_for_value(f"{check_key}.name")
            name_range = explicit_name_range or ctx.source.source_map.range_for_key(check_key)
            if check_def := self.convert_check(
                item,
                ctx,
                column=column,
                source_range=source_range,
                column_source_range=column_range,
                name_source_range=name_range,
                check_key=check_key,
            ):
                results.append(check_def)
        return results

    def convert_check(  # noqa: PLR0913
        self,
        item: CheckItemModel,
        ctx: ConversionContext,
        column: str | None = None,
        source_range: TextRange | None = None,
        column_source_range: TextRange | None = None,
        name_source_range: TextRange | None = None,
        check_key: str = "",
    ) -> CheckDef | None:
        """Convert a parsed CheckItemModel into a CheckDef."""
        try:
            dimension = QualityDimension.parse(item.body.dimension)
        except TurbineError:
            msg = f"Invalid dimension '{item.body.dimension}' for check '{item.check_type}'"
            ctx.sink.add(
                DiagnosticBuilder.error(DiagnosticId.CHECK_DEFINITION_ERROR, msg)
                .span(ctx.source.path, source_range)
                .label(msg)
                .build()
            )
            return None
        check_column = column or item.body.column
        name_column = column or item.body.column if item.check_type in COLUMN_SCOPED_METRICS else column
        name = item.body.name or (f"{item.check_type}:{name_column}" if name_column else item.check_type)
        check_type = item.check_type

        try:
            category = CheckCategory.from_type_string(item.check_type)
        except TurbineError as exc:
            ctx.sink.add(
                DiagnosticBuilder.error(DiagnosticId.CHECK_DEFINITION_ERROR, str(exc))
                .span(ctx.source.path, source_range)
                .label(str(exc))
                .build()
            )
            return None
        if isinstance(item.body, PythonCheckBody) and (
            collision_msg := item.body.validate_python_kwargs()
        ):
            ctx.sink.add(
                DiagnosticBuilder.error(DiagnosticId.CHECK_DEFINITION_ERROR, collision_msg)
                .span(ctx.source.path, source_range)
                .label(collision_msg)
                .build()
            )
            return None

        try:
            match item.body:
                case SqlCheckBody(query=str()):
                    config = item.body.to_config(name)
                    category = CheckCategory.SQL
                case MetricCheckBody() as body:
                    config = body.to_config(item.check_type, check_column)
                case SqlCheckBody() as body:
                    config = body.to_config(name)
                case body:
                    config = body.to_config()
        except TurbineError as exc:
            ctx.sink.add(
                DiagnosticBuilder.error(DiagnosticId.CHECK_DEFINITION_ERROR, str(exc))
                .span(ctx.source.path, source_range)
                .build()
            )
            return None

        window = self.parse_window(item.body.window, ctx, source_range)

        config = self.enrich_config_ranges(config, item, ctx, check_key)
        return CheckDef(
            name=name,
            check_type=check_type,
            dimension=dimension,
            category=category,
            config=config,
            threshold=item.body.to_threshold(),
            unit=getattr(item.body, "unit", None),
            compare_mode=getattr(item.body, "compare", "count"),
            source=ctx.check_source,
            column=check_column,
            window=window,
            filter=(FilterExpr.parse(item.body.filter, dialect="duckdb") if item.body.filter else None),
            source_range=source_range,
            column_source_range=column_source_range,
            name_source_range=name_source_range,
        )

    @staticmethod
    def parse_window(
        raw: str | None, ctx: "ConversionContext", source_range: TextRange | None
    ) -> Duration | None:
        """Parse the window field, emitting WINDOW_INVALID_DURATION on failure."""
        if raw is None:
            return None
        try:
            return Duration.parse(raw)
        except TurbineError:
            ctx.sink.add(
                DiagnosticBuilder.error(
                    DiagnosticId.WINDOW_INVALID_DURATION,
                    f"cannot parse window value '{raw}' as a duration",
                )
                .span(ctx.source.path, source_range)
                .help(ACCEPTED_SHAPES)
                .build()
            )
            return None

    @staticmethod
    def enrich_config_ranges(
        config: CheckConfig, item: CheckItemModel, ctx: ConversionContext, check_key: str
    ) -> CheckConfig:
        """Attach field-level source ranges to SQL and Python configs."""
        source_map = ctx.source.source_map
        if isinstance(config, SqlCheckConfig) and isinstance(item.body, SqlCheckBody):
            name_range = source_map.range_for_value(f"{check_key}.name")
            return replace(config, file_source_range=name_range)
        if isinstance(config, PythonCheckConfig) and isinstance(item.body, PythonCheckBody):
            field_name = "function" if item.body.function else "name"
            func_range = source_map.range_for_value(f"{check_key}.{field_name}")
            return replace(config, function_source_range=func_range)
        return config
