"""In-process execution of user-authored Python check functions."""

import dataclasses
import importlib
import importlib.util
import inspect
import sys
import traceback
from collections.abc import Callable
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any

from turbine.core.building_blocks import Diagnostic, DiagnosticBuilder, DiagnosticId, Span, TextRange
from turbine.core.common import CheckDef, PythonCheckConfig
from turbine.core.common.dataset_spec.thresholds import Threshold, passes_threshold, threshold_scalar
from turbine.core.quality import CheckResult
from turbine.core.quality.check_validation import (
    DataFrameLibrary,
    InputSpec,
    PythonCheckError,
    PythonCheckScalarResult,
    PythonCheckSuccess,
    introspect_check_function,
    validate_input_mapping,
)
from turbine.core.quality.plan.measurement import PkResult
from turbine.core.quality.planning.metric_verdict import failure_allowance_verdict, with_strict_default

from .data_loader import DataLoader

USER_CHECKS_NAMESPACE = "turbine_user_checks"


@dataclass(frozen=True, slots=True)
class ResolvedFunction:
    """Pair a callable with its DataFrame library so the loader picks the right format."""

    func: Callable[..., Any]
    library: DataFrameLibrary

    @classmethod
    def resolve(
        cls, ref: str, checks_dir: Path, source_path: Path, source_range: TextRange | None = None
    ) -> "ResolvedFunction | Diagnostic":
        """Resolve via inline source, dotted import, or file-based convention.

        Multi-line ``ref`` (or one starting with ``def``) is treated as
        inline Python source and exec'd in a fresh namespace; the resulting
        ``check`` callable becomes the resolved function. Single-line refs
        with ``.`` resolve via importlib; bare names resolve to
        ``{checks_dir}/{ref}.py``.
        """
        if cls.looks_inline(ref):
            result = cls.resolve_inline(ref, source_path, source_range)
        elif "." in ref:
            result = cls.resolve_dotted(ref, source_path, source_range)
        else:
            result = cls.resolve_file(ref, checks_dir, source_path, source_range)
        if isinstance(result, Diagnostic):
            return result
        return cls(func=result, library=cls.detect_library(result))

    @staticmethod
    def looks_inline(ref: str) -> bool:
        """Detect inline Python source — multi-line, or starts with ``def``/``async def``/``lambda``."""
        if "\n" in ref:
            return True
        stripped = ref.strip()
        return stripped.startswith(("def ", "async def ", "lambda ", "lambda:"))

    @staticmethod
    def resolve_inline(
        source: str, source_path: Path, source_range: TextRange | None
    ) -> Callable[..., Any] | Diagnostic:
        """Compile inline Python source and return its ``check`` callable.

        The user's source is exec'd in a fresh namespace; the function
        name must be ``check`` (matches the file-based convention's
        single-function expectation). Compile-time and missing-name errors
        surface as diagnostics anchored to the YAML's ``function:`` block.
        """
        namespace: dict[str, Any] = {}
        try:
            compiled = compile(source, f"<{source_path.name}:check>", "exec")
            exec(compiled, namespace)  # noqa: S102 — user-authored check body, run in isolated dict
        except SyntaxError as exc:
            return (
                DiagnosticBuilder.error(
                    DiagnosticId.CHECK_PYTHON_RUNTIME_ERROR,
                    f"Your Python check has a syntax error: {exc.msg}.",
                )
                .span(source_path, source_range)
                .build()
            )
        func = namespace.get("check")
        if not callable(func):
            return (
                DiagnosticBuilder.error(
                    DiagnosticId.CHECK_PYTHON_RUNTIME_ERROR,
                    "Your Python check must define a function named 'check'.",
                )
                .span(source_path, source_range)
                .help("Example: `def check(df): return df`. Rename your function to `check`.")
                .build()
            )
        return func

    @staticmethod
    def resolve_dotted(
        function_ref: str, source_path: Path, source_range: TextRange | None
    ) -> Callable[..., Any] | Diagnostic:
        """Import a dotted reference like ``pkg.module.func`` via importlib."""
        module_path, func_name = function_ref.rsplit(".", 1)
        try:
            module = importlib.import_module(module_path)
        except ModuleNotFoundError:
            return (
                DiagnosticBuilder.error(
                    DiagnosticId.CHECK_PYTHON_RUNTIME_ERROR,
                    f"Python module '{module_path}' was not found.",
                )
                .span(source_path, source_range)
                .help("Install the package or place the module in your project's Python path.")
                .build()
            )
        func = getattr(module, func_name, None)
        if func is None:
            return (
                DiagnosticBuilder.error(
                    DiagnosticId.CHECK_PYTHON_RUNTIME_ERROR,
                    f"function {func_name!r} not found in {module_path!r}",
                )
                .span(source_path, source_range)
                .build()
            )
        return func

    @staticmethod
    def resolve_file(
        function_ref: str, checks_dir: Path, source_path: Path, source_range: TextRange | None
    ) -> Callable[..., Any] | Diagnostic:
        """Load ``{checks_dir}/{ref}.py`` and extract the named function, rejecting path traversal."""
        resolved_dir = checks_dir.resolve()
        file_path = checks_dir / f"{function_ref}.py"
        if not file_path.resolve().is_relative_to(resolved_dir):
            return (
                DiagnosticBuilder.error(
                    DiagnosticId.CHECK_PYTHON_RUNTIME_ERROR,
                    f"The Python check path '{function_ref}' leaves the checks directory.",
                )
                .span(source_path, source_range)
                .help("Reference only Python files inside your checks directory.")
                .build()
            )
        if not file_path.exists():
            return (
                DiagnosticBuilder.error(
                    DiagnosticId.CHECK_PYTHON_RUNTIME_ERROR,
                    f"Python check file '{file_path}' was not found.",
                )
                .span(source_path, source_range)
                .label("check defined here")
                .secondary(Span(path=file_path), f"looked for: {file_path}")
                .help(f"create {file_path} with a function named {function_ref!r}")
                .build()
            )

        module_name = f"{USER_CHECKS_NAMESPACE}.{function_ref}"
        module_spec = importlib.util.spec_from_file_location(module_name, file_path)
        if module_spec is None or module_spec.loader is None:
            return (
                DiagnosticBuilder.error(
                    DiagnosticId.CHECK_PYTHON_RUNTIME_ERROR,
                    f"Python check file '{file_path}' could not be loaded.",
                )
                .span(source_path, source_range)
                .build()
            )

        module = importlib.util.module_from_spec(module_spec)
        sys.modules[module_name] = module
        module_spec.loader.exec_module(module)

        func = getattr(module, function_ref, None)
        if func is None:
            return (
                DiagnosticBuilder.error(
                    DiagnosticId.CHECK_PYTHON_RUNTIME_ERROR,
                    f"function {function_ref!r} not found in {file_path}",
                )
                .span(source_path, source_range)
                .help(f"define a function named {function_ref!r} in {file_path.name}")
                .build()
            )
        return func

    @staticmethod
    def detect_library(func: Callable[..., Any]) -> DataFrameLibrary:
        """Infer the DataFrame library from the ``df`` parameter's type hint."""
        df_param = inspect.get_annotations(func, eval_str=True).get("df")
        if df_param is None:
            return DataFrameLibrary.PANDAS
        module = getattr(df_param, "__module__", "")
        if module.startswith("polars"):
            return DataFrameLibrary.POLARS
        return DataFrameLibrary.PANDAS


def validate_python_check(
    check: CheckDef, config: PythonCheckConfig, checks_dir: Path
) -> ResolvedFunction | CheckResult:
    """Resolve the user function + validate input mapping.

    Returns either a :class:`ResolvedFunction` ready to execute, or a
    ``CheckResult.skipped(...)`` carrying the diagnostic that explains
    why the check cannot run.
    """
    resolved = ResolvedFunction.resolve(
        config.function_ref, checks_dir, check.source.path, check.source_range
    )
    if isinstance(resolved, Diagnostic):
        return CheckResult.skipped(check, resolved)

    input_spec = introspect_check_function(resolved.func)
    if input_spec is not None:
        errors = validate_input_mapping(
            input_spec.dataclass_type, config.extra_tables, config.queries, config.params
        )
        if errors:
            diag = (
                DiagnosticBuilder.error(DiagnosticId.CHECK_DEFINITION_ERROR, errors[0])
                .span(check.source.path, check.source_range)
                .build()
            )
            return CheckResult.skipped(check, diag)
    return resolved


def load_inputs(config: PythonCheckConfig, loader: DataLoader) -> dict[str, Any]:
    """Load every ``extra_table`` + ``query`` + ``param`` declared on *config*.

    Returns the flat kwargs dict: tables and queries materialise via the
    *loader*, params pass through unchanged. Callers that target a typed
    input dataclass filter the result by the dataclass's field names.
    """
    inputs: dict[str, Any] = {}
    for name, table in config.extra_tables.items():
        inputs[name] = loader.load_table(table)
    for name, sql in config.queries.items():
        inputs[name] = loader.load_query(sql)
    inputs.update(config.params)
    return inputs


def build_kwargs_from_primary(
    primary: Any, config: PythonCheckConfig, input_spec: InputSpec | None, loader: DataLoader
) -> dict[str, Any]:
    """Build the kwargs dict the user function receives, given an already-loaded primary df."""
    inputs = load_inputs(config, loader)
    if input_spec is None:
        return {"df": primary, **inputs}
    field_names = {field.name for field in dataclasses.fields(input_spec.dataclass_type)}
    dc_kwargs = {name: value for name, value in inputs.items() if name in field_names}
    instance = input_spec.dataclass_type(**dc_kwargs)
    return {"df": primary, input_spec.param_name: instance}


def evaluate_scalar_outcome(
    check: CheckDef, outcome: PythonCheckScalarResult, threshold: Threshold | None
) -> CheckResult:
    """Compare a scalar metric return against the check's threshold."""
    if threshold is None:
        diag = (
            DiagnosticBuilder.error(
                DiagnosticId.CHECK_DEFINITION_ERROR,
                "python check returned a scalar but no threshold is configured",
            )
            .span(check.source.path, check.source_range)
            .help("add mustBeLessThan, mustBeGreaterThan, or mustBe to the check body")
            .build()
        )
        return CheckResult.skipped(check, diag)
    passed = passes_threshold(outcome.metric_value, threshold)
    if passed:
        return CheckResult.passed(check, rows_tested=1, metric_value=outcome.metric_value)
    return CheckResult.failed(check, rows_tested=1, rows_failed=1, metric_value=outcome.metric_value)


def build_dataframe_outcome(
    check: CheckDef,
    outcome: PythonCheckSuccess,
    data: Any,
    pk_columns: tuple[str, ...],
    *,
    flag_rows: bool,
) -> CheckResult:
    """Convert a DataFrame-producing outcome into the failure-allowance verdict.

    Delegates to :func:`failure_allowance_verdict` so percent-mode python
    checks compute ``100 * rows_failed / rows_tested`` and SKIP on an
    empty scope. A bare python ``mode: failed_rows`` check (no
    ``mustBe*`` operator on the body) defaults to count semantics with
    threshold ``= 0`` — the helper still PASSES on empty count because
    ``rows_failed`` is necessarily 0 too.
    """
    pk_tuples: tuple[tuple[object, ...], ...] = ()
    if flag_rows and outcome.rows_failed > 0 and pk_columns and outcome.result_series is not None:
        pk_tuples = extract_failed_pks(data, outcome.result_series, pk_columns)
    failed_pks = (
        PkResult(total=outcome.rows_failed, pks=pk_tuples, streaming=False) if pk_tuples else None
    )
    return failure_allowance_verdict(
        with_strict_default(check),
        rows_failed=outcome.rows_failed,
        rows_tested=outcome.rows_tested,
        failed_pks=failed_pks,
    )


def extract_failed_pks(
    data: Any, failed_mask: Any, pk_columns: tuple[str, ...]
) -> tuple[tuple[object, ...], ...]:
    """Extract PK tuples from failing rows in either pandas or polars DataFrames.

    Pandas exposes numpy scalars on ``itertuples`` rows; ``.item()`` unwraps
    them to plain Python ints/floats so downstream consumers (audit writers,
    JSON serialisers) don't choke on numpy types.
    """
    if not pk_columns:
        return ()
    lowered_pks = [pk.lower() for pk in pk_columns]
    if "polars" in type(data).__module__:
        return tuple(data.filter(failed_mask).select(lowered_pks).rows())
    pk_data = data.loc[failed_mask, lowered_pks]
    return tuple(
        tuple(value.item() if hasattr(value, "item") else value for value in row)
        for row in pk_data.itertuples(index=False, name=None)
    )


def extract_threshold_value(threshold: Threshold | None) -> float | None:
    """Extract a single numeric value from a Threshold for passing to user functions."""
    return threshold_scalar(threshold)


def check_error_to_result(check: CheckDef, outcome: PythonCheckError) -> CheckResult:
    """Convert a PythonCheckError into a skipped CheckResult."""
    diag = (
        DiagnosticBuilder.error(DiagnosticId.CHECK_PYTHON_RUNTIME_ERROR, outcome.message)
        .span(check.source.path, check.source_range)
        .build()
    )
    if outcome.help_text:
        diag = replace(diag, notes=(outcome.help_text,))
    return CheckResult.skipped(check, diag)


def inject_threshold_kwarg(
    kwargs: dict[str, Any], threshold: Threshold | None, func: Callable[..., Any]
) -> None:
    """Add ``threshold`` to *kwargs* only when *func* declares the parameter."""
    threshold_value = extract_threshold_value(threshold)
    if threshold_value is None:
        return
    sig = inspect.signature(func)
    if "threshold" in sig.parameters or any(
        param.kind is inspect.Parameter.VAR_KEYWORD for param in sig.parameters.values()
    ):
        kwargs["threshold"] = threshold_value


def build_error_diagnostic(check: CheckDef, exc: BaseException) -> Diagnostic:
    """Wrap an exception as a diagnostic with a traceback filtered to user frames."""
    builder = DiagnosticBuilder.error(DiagnosticId.CHECK_PYTHON_RUNTIME_ERROR, str(exc)).span(
        check.source.path, check.source_range
    )
    tb_entries = traceback.extract_tb(exc.__traceback__)
    user_frames = [
        frame
        for frame in tb_entries
        if "turbine" not in frame.filename and "site-packages" not in frame.filename
    ]
    frames = user_frames or list(tb_entries)
    if not frames:
        return builder.build()

    last = frames[-1]
    if last.lineno is not None:
        span = Span(
            path=Path(last.filename),
            range=TextRange(start_line=last.lineno, start_col=0, end_line=last.lineno, end_col=0),
        )
        builder = builder.secondary(span, last.line or "")
    tb_text = "\n".join(f"  {frame.filename}:{frame.lineno} in {frame.name}" for frame in frames)
    return builder.note(f"traceback:\n{tb_text}").build()
