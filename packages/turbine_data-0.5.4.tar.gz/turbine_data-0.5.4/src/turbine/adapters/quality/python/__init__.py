"""Python check adapter: helpers consumed by PythonRequester via the batched pipeline."""
