"""``PythonRequester``: Python checks riding the batched pipeline.

Each ``category: python`` check becomes a :class:`PythonRequester` with
one :class:`ColumnFetchSlot` for the primary ``df`` parameter. The
batched executor materialises the DataFrame into
``measurement.column_fetches``; :meth:`interpret` unwraps it, loads any
``extra_tables``/``queries`` as side queries via the injected
``SqlExecutor``, invokes the user function, and produces a
:class:`CheckResult`.

Extra tables + user queries still run at interpret time rather than as
separate plans. That preserves functional parity with the old bypass
adapter while replacing the top-level runner route with a requester
that flows through the same planner + dispatcher + event pipeline as
every other batched check.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from typing import Any

from turbine.adapters.quality.python.data_loader import DataLoader, SqlExecutor
from turbine.adapters.quality.python.runner import (
    ResolvedFunction,
    build_dataframe_outcome,
    build_error_diagnostic,
    build_kwargs_from_primary,
    check_error_to_result,
    evaluate_scalar_outcome,
    inject_threshold_kwarg,
)
from turbine.core.building_blocks import DiagnosticBuilder, DiagnosticId
from turbine.core.common import CheckDef, PythonCheckConfig
from turbine.core.quality.check_results import CheckResult
from turbine.core.quality.check_validation import (
    InputSpec,
    PythonCheckError,
    PythonCheckScalarResult,
    execute_python_check,
)
from turbine.core.quality.plan.dataset_key import DatasetKey
from turbine.core.quality.plan.errors import PlanExecutionError
from turbine.core.quality.plan.measurement import DatasetMeasurement, SlotError
from turbine.core.quality.plan.requester import DatasetSlotBinding
from turbine.core.quality.plan.slots import ColumnFetchSlot
from turbine.core.quality.planning import unwrap_dataset_outcome
from turbine.core.shared import FilterExpr


@dataclass(frozen=True, slots=True)
class PythonRequester:
    """Requester for ``category: python`` checks — primary df + side loads."""

    check: CheckDef
    dataset: DatasetKey
    config: PythonCheckConfig
    resolved: ResolvedFunction
    filter: FilterExpr | None
    primary_slot: ColumnFetchSlot
    input_spec: InputSpec | None
    sql_executor: SqlExecutor
    pk_columns: tuple[str, ...]
    flag_rows: bool

    def bindings(self) -> tuple[DatasetSlotBinding, ...]:
        """Advertise the primary ColumnFetchSlot binding; extras resolve at interpret time."""
        return (DatasetSlotBinding(dataset=self.dataset, filter=self.filter, slot=self.primary_slot),)

    def interpret(
        self, measurements: Mapping[DatasetKey, DatasetMeasurement | PlanExecutionError]
    ) -> tuple[CheckResult, ...]:
        """Unwrap the primary df, run the user function, and shape the CheckResult."""
        outcome = unwrap_dataset_outcome(measurements, self.dataset, self.check)
        if isinstance(outcome, CheckResult):
            return (outcome,)

        result = outcome.result_for(self.primary_slot)
        if isinstance(result, SlotError):
            diag = (
                DiagnosticBuilder.error(
                    DiagnosticId.CHECK_PYTHON_RUNTIME_ERROR,
                    f"failed to load primary DataFrame for {self.check.name!r}: {result.reason}",
                )
                .span(self.check.source.path, self.check.source_range)
                .build()
            )
            return (CheckResult.skipped(self.check, diag),)

        primary_df: Any = result.opaque
        try:
            loader = DataLoader(self.sql_executor)
            kwargs = build_kwargs_from_primary(primary_df, self.config, self.input_spec, loader)
            inject_threshold_kwarg(kwargs, self.check.threshold, self.resolved.func)
            python_outcome = execute_python_check(self.resolved.func, kwargs)
        except Exception as exc:  # noqa: BLE001 — adapter boundary, surface as skipped
            return (CheckResult.skipped(self.check, build_error_diagnostic(self.check, exc)),)

        if isinstance(python_outcome, PythonCheckError):
            return (check_error_to_result(self.check, python_outcome),)
        if isinstance(python_outcome, PythonCheckScalarResult):
            return (evaluate_scalar_outcome(self.check, python_outcome, self.check.threshold),)
        return (
            build_dataframe_outcome(
                self.check, python_outcome, primary_df, self.pk_columns, flag_rows=self.flag_rows
            ),
        )
