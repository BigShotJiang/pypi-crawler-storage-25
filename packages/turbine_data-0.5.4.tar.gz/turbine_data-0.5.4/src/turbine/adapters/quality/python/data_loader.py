"""DataLoader — loads DataFrames for Python check execution.

Uses connectorx for password-authenticated connections, and native
Arrow interfaces for DuckDB and Snowflake key-pair auth.
"""

import dataclasses
import importlib
from collections.abc import Callable
from dataclasses import dataclass

import pandas as pd
import polars as pl
import pyarrow as pa
from pydantic import BaseModel, ConfigDict

from turbine.core.common import validate_identifier
from turbine.core.quality.check_validation import DataFrameLibrary

DataFrame = pd.DataFrame | pl.DataFrame

SqlExecutor = Callable[[str], DataFrame]


class SnowflakeExtra(BaseModel):
    """Auth-specific Snowflake connector kwargs set alongside the first-class fields."""

    model_config = ConfigDict(extra="forbid")

    password: str | None = None
    private_key: bytes | None = None


def lowercase_columns(df: DataFrame) -> DataFrame:
    """Lowercase all column names for dialect-independent check functions."""
    if isinstance(df, pl.DataFrame):
        return df.rename({col: col.lower() for col in df.columns})
    return df.rename(columns=str.lower)


def arrow_to_dataframe(arrow: pa.Table, library: DataFrameLibrary) -> DataFrame:
    """Convert a PyArrow Table to a pandas or polars DataFrame."""
    if library == DataFrameLibrary.POLARS:
        result = pl.from_arrow(arrow)
        assert isinstance(result, pl.DataFrame)
        return result
    return arrow.to_pandas()


def make_connectorx_executor(connection_string: str, library: DataFrameLibrary) -> SqlExecutor:
    """Return an executor that loads DataFrames via connectorx."""
    try:
        import connectorx  # noqa: PLC0415  # optional install, checked here
    except ImportError as exc:
        raise ImportError("connectorx is required: install with `uv add turbine[checks]`") from exc

    def execute(sql: str) -> DataFrame:
        """Fetch a DataFrame from the database via connectorx."""
        return connectorx.read_sql(connection_string, sql, return_type=library)

    return execute


def make_duckdb_executor(connection_string: str, library: DataFrameLibrary) -> SqlExecutor:
    """Return an executor that loads DataFrames via DuckDB native Arrow."""

    def execute(sql: str) -> DataFrame:
        """Fetch a DataFrame from DuckDB via its native Arrow interface."""
        duckdb = importlib.import_module("duckdb")
        db_path = connection_string.removeprefix("duckdb://")
        conn = duckdb.connect(db_path)
        try:
            arrow = conn.execute(sql).to_arrow_table()
            return arrow_to_dataframe(arrow, library)
        finally:
            conn.close()

    return execute


@dataclass(frozen=True, slots=True)
class SnowflakeNativeConfig:
    """Snowflake connection kwargs for the native connector.

    ``extra`` carries auth-specific kwargs (``password`` for PAT/password
    auth, ``private_key`` bytes for key-pair). Everything else is
    first-class so type-checkers catch missing fields.
    """

    account: str
    database: str
    warehouse: str
    role: str
    schema: str
    user: str
    extra: SnowflakeExtra = dataclasses.field(default_factory=SnowflakeExtra)

    def connect_kwargs(self) -> dict[str, object]:
        """Flatten into kwargs for ``snowflake.connector.connect``."""
        base = {f.name: getattr(self, f.name) for f in dataclasses.fields(self) if f.name != "extra"}
        return {**{k: v for k, v in base.items() if v}, **self.extra.model_dump(exclude_none=True)}


def make_snowflake_native_executor(
    config: SnowflakeNativeConfig, library: DataFrameLibrary
) -> SqlExecutor:
    """Return an executor that loads DataFrames via Snowflake native Arrow.

    ``connectorx`` panics on Snowflake-specific types (``TIMESTAMP_NTZ``,
    certain numerics), so Snowflake always flows through the native
    connector regardless of auth method.
    """

    def execute(sql: str) -> DataFrame:
        """Fetch a DataFrame from Snowflake via its native Arrow interface."""
        sf = importlib.import_module("snowflake.connector")
        conn = sf.connect(**config.connect_kwargs())
        try:
            cursor = conn.cursor()
            cursor.execute(sql)
            arrow = cursor.fetch_arrow_all()
            return arrow_to_dataframe(arrow, library)
        finally:
            conn.close()

    return execute


class DataLoader:
    """Load DataFrames via a pluggable SQL executor (connectorx, DuckDB, or Snowflake)."""

    def __init__(self, executor: SqlExecutor) -> None:
        """Accept the SQL executor strategy."""
        self.executor = executor

    def load_table(self, table_name: str) -> DataFrame:
        """Load a full table as a DataFrame with lowercased columns."""
        validate_identifier(table_name, "table name")
        return lowercase_columns(self.executor(f"SELECT * FROM {table_name}"))

    def load_query(self, sql: str) -> DataFrame:
        """Execute SQL and return a DataFrame with lowercased columns."""
        return lowercase_columns(self.executor(sql))
