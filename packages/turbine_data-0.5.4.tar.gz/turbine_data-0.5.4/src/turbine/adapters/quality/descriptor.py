"""QualitySpec format descriptor — bundles schema infrastructure for quality specs."""

from turbine.core.common import FormatLabel
from turbine.core.contract import FormatDescriptor

from .schema_catalog import load_quality_spec_schema
from .schema_validation import resolve_display_context, valid_fields_for_path

QUALITY_SPEC_DESCRIPTOR = FormatDescriptor(
    format_label=FormatLabel.QUALITY_SPEC,
    schema_loader=load_quality_spec_schema,
    display_context_fn=resolve_display_context,
    valid_fields_fn=valid_fields_for_path,
)
