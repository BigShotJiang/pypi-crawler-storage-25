"""Quality spec adapters — reading, schema validation, and schema resolution."""

from .reader import QualitySpecReader
from .schema_catalog import load_quality_spec_schema

__all__ = ["QualitySpecReader", "load_quality_spec_schema"]
