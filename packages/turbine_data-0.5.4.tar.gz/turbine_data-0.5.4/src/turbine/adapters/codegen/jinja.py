"""Jinja2-based content renderers for scaffolding check stubs."""

from collections.abc import Iterable, Sequence
from pathlib import Path

import jinja2

from turbine.core.codegen import NewCheckConfig, StagedFile


class CheckRenderer:
    """Render check stub files (Python or SQL) from Jinja2 templates."""

    def __init__(self, jinja_env: jinja2.Environment) -> None:
        """Wire up with a Jinja2 environment for template loading."""
        self.jinja_env = jinja_env

    def render(self, items: Sequence[NewCheckConfig], output_dir: Path) -> Iterable[StagedFile]:
        """Yield one check stub per item."""
        for item in items:
            template = self.jinja_env.get_template(item.kind.template_name)
            body = template.render(
                name=item.name,
                multi_table=item.multi_table,
                primary_table=item.primary_table,
                extra_tables=item.extra_tables,
            )
            yield StagedFile(
                path=output_dir / f"{item.name}{item.kind.extension}", content=body, identifier=item.name
            )
