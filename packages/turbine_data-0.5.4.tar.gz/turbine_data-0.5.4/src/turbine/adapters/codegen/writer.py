"""StagedFileWriter: stage file content, flush atomically after formatting.

Implements the :class:`turbine.core.codegen.CodeWriter` Protocol so
content can be batch-formatted before hitting disk.
"""

from pathlib import Path

from turbine.core.codegen.ports import StagedFiles
from turbine.core.common import SyncResult, SyncStatus


class StagedFileWriter:
    """Stage file content in memory, flush after batch formatting.

    Call :meth:`stage` once per file, then hand :meth:`pending` to a
    :class:`BatchFormatter`, then pass the formatted dict to
    :meth:`flush` to write and collect sync results. Flushing clears
    staged state so the writer can be reused across multiple runs.
    """

    def __init__(self) -> None:
        self.staged: StagedFiles = {}

    def stage(self, path: Path, content: str) -> None:
        """Record a pending write of *content* to *path*."""
        self.staged[path] = content

    def pending(self) -> StagedFiles:
        """Return a shallow copy of the staged map."""
        return dict(self.staged)

    def flush(self, formatted: StagedFiles) -> list[SyncResult]:
        """Write each entry in *formatted* to disk, clear staged state."""
        results = [
            SyncResult(path=path, status=write_codegen_file(path, formatted[path]))
            for path in sorted(formatted)
        ]
        self.staged.clear()
        return results


def write_codegen_file(path: Path, content: str) -> SyncStatus:
    """Write generated content and return the resulting sync status."""
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        return SyncStatus.CREATED
    if path.read_text() == content:
        return SyncStatus.UNCHANGED
    path.write_text(content)
    return SyncStatus.UPDATED
