"""Shared naming helpers for the API codegen renderers.

A contract id plus a resource name (``eans`` + ``meter-readings``)
drive every derived label: filename, module path, class base, router
operationId, and OpenAPI tag. Centralising the transforms keeps every
renderer in lock-step and ensures a single rename touches one place.
"""

from turbine.core.codegen import to_table_name

TAG_SEPARATOR = " · "


def slug_to_module_part(slug: str) -> str:
    """Convert a URL slug into a snake-case module part (``meter-readings`` -> ``meter_readings``)."""
    return to_table_name(slug)


def slug_to_pascal(slug: str) -> str:
    """Convert a URL slug into PascalCase (``meter-readings`` -> ``MeterReadings``)."""
    return "".join(part[:1].upper() + part[1:] for part in slug.split("-") if part)


def contract_module_name(contract_id: str, resource: str) -> str:
    """Snake-case filename stem for the ``(contract, resource)`` pair.

    ``eans``, ``meter-readings`` -> ``eans__meter_readings``.
    """
    return f"{to_table_name(contract_id)}__{slug_to_module_part(resource)}"


def contract_class_base(contract_id: str, resource: str) -> str:
    """PascalCase class base for the ``(contract, resource)`` pair.

    ``eans``, ``meter-readings`` -> ``EansMeterReadings``.
    """
    return f"{slug_to_pascal(contract_id)}{slug_to_pascal(resource)}"


def detail_operation_id(contract_id: str, resource: str) -> str:
    """CamelCase operationId for the GET-by-id endpoint per Enexis API-G.

    ``eans``, ``meter-readings`` -> ``getEansMeterReadingsById``.
    """
    return f"get{slug_to_pascal(contract_id)}{slug_to_pascal(resource)}ById"


def list_operation_id(contract_id: str, resource: str) -> str:
    """CamelCase operationId for the list endpoint per Enexis API-G.

    ``eans``, ``meter-readings`` -> ``listEansMeterReadings``.
    """
    return f"list{slug_to_pascal(contract_id)}{slug_to_pascal(resource)}"


def router_module_name(contract_id: str, resource: str) -> str:
    """Router file stem (without extension) for the ``(contract, resource)`` pair."""
    return f"{contract_module_name(contract_id, resource)}_router"


def domain_package_name(domain: str) -> str:
    """Return the Python package segment for a URL domain slug."""
    return to_table_name(domain)


def tag_for(contract_id: str, resource: str, dataset_count: int) -> str:
    """Return the OpenAPI tag for the dataset.

    Multi-dataset contracts get ``{contract_id} · {resource_name}`` so
    the Swagger nav distinguishes siblings; single-dataset contracts get
    just ``{contract_id}`` so the dataset segment doesn't add noise.
    """
    if dataset_count > 1:
        return f"{contract_id}{TAG_SEPARATOR}{resource}"
    return contract_id


def to_camel(snake: str) -> str:
    """Convert ``snake_case`` to ``lowerCamelCase`` (mirrors the runtime helper).

    Used at codegen time to compute the camelCase alias of each filter
    field; the runtime ships its own copy of this so emitted modules
    don't import from Turbine.
    """
    if not snake:
        return snake
    head, *tail = snake.split("_")
    return head + "".join(part[:1].upper() + part[1:] for part in tail)
