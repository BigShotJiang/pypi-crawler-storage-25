"""Build a :class:`CodegenPlan` for the new contract-first API generator.

The plan groups contracts by ``(major_version, domain)`` and emits one
step per group plus an extra step at the package root for runtime,
session, and the mount module. All directory and import-path
conventions come from :class:`ApiLayout` so a layout rename is a
one-file change.
"""

from collections import defaultdict
from collections.abc import Sequence
from pathlib import Path

from turbine.core.codegen import CodegenPlan, CodegenStep
from turbine.core.common import DatasetSpec
from turbine.core.contract.api_rules import filter_specs_for_codegen

from .layout import ApiLayout
from .mount import MountRenderer
from .package_init import DomainPackageInitRenderer, EmptyApiInitRenderer, MajorPackageInitRenderer
from .schema_model import ApiModelRenderer
from .schema_router import ApiRouterRenderer
from .slow_count import at_risk_contract_ids


def find_orphan_codegen_dirs(layout: ApiLayout, active: set[Path]) -> list[Path]:
    """Return every codegen directory on disk that no active group claims.

    Walks ``layout.api_root`` covering three levels — the per-major
    package, each domain package, and the swept leaves under each
    domain. Anything outside *active* is leftover from a previous run
    whose contract was retired or deleted; the sweeper clears every
    ``.py`` underneath so the empty-dir pruning pass can drop the
    directory afterwards.
    """
    if not layout.api_root.exists():
        return []
    found: list[Path] = []
    for major_dir in sorted(layout.api_root.glob("v*")):
        if major_dir.is_dir():
            found.extend(walk_major_dir(major_dir, active))
    return found


def walk_major_dir(major_dir: Path, active: set[Path]) -> list[Path]:
    """Collect orphan codegen dirs under one ``api/v{major}/`` directory."""
    out: list[Path] = []
    if major_dir not in active:
        out.append(major_dir)
    for domain_dir in sorted(major_dir.iterdir()):
        if domain_dir.is_dir():
            out.extend(walk_domain_dir(domain_dir, active))
    return out


def walk_domain_dir(domain_dir: Path, active: set[Path]) -> list[Path]:
    """Collect orphan dirs under one ``api/v{major}/<domain>/`` directory."""
    out: list[Path] = []
    if domain_dir not in active:
        out.append(domain_dir)
    for leaf in ApiLayout.SWEPT_LEAVES:
        leaf_dir = domain_dir / leaf
        if leaf_dir.is_dir() and leaf_dir not in active:
            out.append(leaf_dir)
    return out


def build_codegen_plan(
    specs: Sequence[DatasetSpec],
    output_root: Path,
    *,
    include_drafts: bool = False,
    include_proposed: bool = False,
) -> CodegenPlan:
    """Build the :class:`CodegenPlan` writing into ``<output_root>/api/``.

    Steps:

    * one ``models/`` step per ``(major, domain)`` running
      :class:`ApiModelRenderer` and an empty package init.
    * one ``routers/`` step per ``(major, domain)`` running
      :class:`ApiRouterRenderer` and an empty package init.
    * one ``{domain}/`` step per ``(major, domain)`` running
      :class:`DomainPackageInitRenderer` to roll up routers.
    * one ``v{major}/`` step per major running :class:`MajorPackageInitRenderer`.
    * one root ``api/`` step running :class:`MountRenderer` only.  The
      runtime helpers (Base/AbstractModel, pagination, caching, error
      handlers, the SQLAlchemy session wiring) live in
      ``turbine.api.runtime`` and are imported by the generated code,
      so neither a ``runtime.py`` nor a ``session.py`` is written into
      the user's project.

    RETIRED contracts are always dropped before grouping. DRAFT and
    PROPOSED are dropped unless *include_drafts* / *include_proposed*
    is set.
    """
    layout = ApiLayout(api_root=output_root / "api")
    selected = filter_specs_for_codegen(
        specs, include_drafts=include_drafts, include_proposed=include_proposed
    )
    slow_count = tuple(at_risk_contract_ids(selected))
    grouped = group_by_major_domain(selected)
    active_dirs = layout.active_dirs(grouped)
    steps: list[CodegenStep] = [
        step
        for major, domain in sorted(grouped)
        for step in domain_steps(layout, major=major, domain=domain)
    ]

    steps.extend(
        CodegenStep(output_dir=orphan_dir, renderers=(), sweep=True)
        for orphan_dir in find_orphan_codegen_dirs(layout, active_dirs)
    )

    for major in sorted({key[0] for key in grouped}):
        major_domains = tuple(sorted(domain for (mj, domain) in grouped if mj == major))
        steps.append(
            CodegenStep(
                output_dir=layout.major_dir(major),
                renderers=(MajorPackageInitRenderer(major_domains),),
                sweep=False,
            )
        )

    steps.append(
        CodegenStep(output_dir=layout.api_root, renderers=(MountRenderer(layout),), sweep=False)
    )

    return CodegenPlan(output_root=output_root, steps=tuple(steps), slow_count_at_risk=slow_count)


def group_by_major_domain(specs: Sequence[DatasetSpec]) -> dict[tuple[int, str], list[DatasetSpec]]:
    """Group *specs* by ``(major_version, domain)``."""
    grouped: dict[tuple[int, str], list[DatasetSpec]] = defaultdict(list)
    for spec in specs:
        domain = spec.metadata.domain
        if not domain:
            continue
        grouped[(spec.metadata.major_version, domain)].append(spec)
    return grouped


def domain_steps(layout: ApiLayout, *, major: int, domain: str) -> list[CodegenStep]:
    """Build models/routers/domain-init steps for one ``(major, domain)`` group."""
    return [
        CodegenStep(
            output_dir=layout.models_dir(major, domain),
            renderers=(
                ApiModelRenderer(major=major, domain=domain),
                EmptyApiInitRenderer("Generated models for this domain at this major version."),
            ),
            sweep=True,
        ),
        CodegenStep(
            output_dir=layout.routers_dir(major, domain),
            renderers=(
                ApiRouterRenderer(major=major, domain=domain),
                EmptyApiInitRenderer("Generated routers for this domain at this major version."),
            ),
            sweep=True,
        ),
        CodegenStep(
            output_dir=layout.domain_dir(major, domain),
            renderers=(DomainPackageInitRenderer(major=major, domain=domain),),
            sweep=False,
        ),
    ]
