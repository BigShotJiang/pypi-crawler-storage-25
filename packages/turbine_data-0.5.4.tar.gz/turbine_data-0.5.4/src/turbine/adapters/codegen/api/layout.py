"""Single source of truth for the emitted ``api/`` directory layout.

Every renderer that needs to know where files land — or how the
generated package imports them — goes through :class:`ApiLayout`. The
shape of the emitted package (``api/v{major}/{domain}/(models|routers)``
plus the dotted import paths into those leaves) is named once here so a
layout rename is a one-file change instead of a five-file lockstep edit.
"""

from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import ClassVar

from .naming import contract_module_name, domain_package_name, router_module_name


@dataclass(frozen=True, slots=True)
class ApiLayout:
    """Owns every directory and import-path convention under ``api/``.

    Construct one with the absolute ``api_root`` (typically
    ``output_root / "api"``) and ask it for paths. Module-path accessors
    return strings starting with a single dot — relative imports rooted
    at ``api/__init__.py``.
    """

    api_root: Path

    SWEPT_LEAVES: ClassVar[tuple[str, ...]] = ("models", "routers")

    def major_dir(self, major: int) -> Path:
        """Return ``<api_root>/v{major}``."""
        return self.api_root / f"v{major}"

    def domain_dir(self, major: int, domain: str) -> Path:
        """Return ``<api_root>/v{major}/{domain_package}``."""
        return self.major_dir(major) / domain_package_name(domain)

    def models_dir(self, major: int, domain: str) -> Path:
        """Return the ``models/`` leaf for one (major, domain) group."""
        return self.domain_dir(major, domain) / "models"

    def routers_dir(self, major: int, domain: str) -> Path:
        """Return the ``routers/`` leaf for one (major, domain) group."""
        return self.domain_dir(major, domain) / "routers"

    def model_file(self, major: int, domain: str, contract_id: str, resource: str) -> Path:
        """Return the on-disk path for the dataset's model module.

        Filename convention is ``{contract_id}__{resource_name}.py`` so a
        multi-dataset contract emits N sibling files under one
        ``models/`` directory without a per-contract sub-package.
        """
        return self.models_dir(major, domain) / f"{contract_module_name(contract_id, resource)}.py"

    def router_file(self, major: int, domain: str, contract_id: str, resource: str) -> Path:
        """Return the on-disk path for the dataset's router module."""
        return self.routers_dir(major, domain) / f"{router_module_name(contract_id, resource)}.py"

    def model_module_path(self, major: int, domain: str, contract_id: str, resource: str) -> str:
        """Return the dotted relative import path to the dataset's model module."""
        package = domain_package_name(domain)
        module = contract_module_name(contract_id, resource)
        return f".v{major}.{package}.models.{module}"

    def router_module_path(self, major: int, domain: str, contract_id: str, resource: str) -> str:
        """Return the dotted relative import path to the dataset's router module."""
        package = domain_package_name(domain)
        module = router_module_name(contract_id, resource)
        return f".v{major}.{package}.routers.{module}"

    def active_dirs(self, groups: Iterable[tuple[int, str]]) -> set[Path]:
        """Return every directory the layout owns for the given (major, domain) groups.

        Used by the orphan walker: anything under ``api_root`` that
        matches the layout shape but isn't in this set was emitted by a
        prior run whose contract has since been retired or removed.
        """
        owned: set[Path] = set()
        for major, domain in groups:
            owned.add(self.major_dir(major))
            owned.add(self.domain_dir(major, domain))
            for leaf in self.SWEPT_LEAVES:
                owned.add(self.domain_dir(major, domain) / leaf)
        return owned
