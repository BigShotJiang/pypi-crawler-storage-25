"""Aggregate ``__init__.py`` renderers for the api/ package tree.

Two shapes:

* :class:`DomainPackageInitRenderer` — emits one ``__init__.py`` per
  domain package, collecting every router into a ``routers`` list the
  mount step iterates over.
* :class:`MajorPackageInitRenderer` — emits a one-line ``__init__.py``
  for the major package so Python can import it.

Output paths come from :class:`ApiLayout`; module-level aggregation
lives in these renderers (not the per-contract ones) so domain/major
directory contents stay deterministic regardless of how many contracts
ship in a given run.
"""

from collections.abc import Iterable, Sequence
from pathlib import Path

from turbine.core.codegen import StagedFile
from turbine.core.common import DatasetSpec
from turbine.core.contract.api_rules import resource_name

from .naming import domain_package_name, router_module_name

INIT_FILENAME = "__init__.py"


class EmptyApiInitRenderer:
    """Emit a minimal ``__init__.py`` so the directory is importable."""

    def __init__(self, doc: str) -> None:
        self.doc = doc

    def render(self, items: Sequence[DatasetSpec], output_dir: Path) -> Iterable[StagedFile]:
        """Yield a single ``__init__.py`` regardless of *items*."""
        del items
        body = f'"""{self.doc}"""\n'
        yield StagedFile(
            path=output_dir / INIT_FILENAME, content=body, identifier=str(output_dir / INIT_FILENAME)
        )


class DomainPackageInitRenderer:
    """Emit ``__init__.py`` under a ``{domain}/`` package.

    Imports each contract module + router and exposes a ``routers``
    tuple the mount step uses to register them.  Filters items down
    to its configured ``(major, domain)`` group.
    """

    def __init__(self, major: int, domain: str) -> None:
        self.major = major
        self.domain = domain

    def render(self, items: Sequence[DatasetSpec], output_dir: Path) -> Iterable[StagedFile]:
        """Yield one ``__init__.py`` rolling up every dataset under the domain.

        Each dataset gets its own router import + tuple entry, so a
        multi-dataset contract surfaces N siblings in this domain's
        ``routers`` tuple.
        """
        scoped = [
            spec
            for spec in items
            if spec.metadata.major_version == self.major and spec.metadata.domain == self.domain
        ]
        sorted_items = sorted(
            scoped, key=lambda spec: (spec.metadata.contract_id, resource_name(spec).value)
        )
        names = [
            router_module_name(spec.metadata.contract_id, resource_name(spec).value)
            for spec in sorted_items
        ]
        router_imports = "\n".join(
            f"from .routers.{module} import router as {module}" for module in names
        )
        router_tuple = ", ".join(names)
        suffix = "," if len(sorted_items) == 1 else ""
        doc = '"""Routers for this domain at this major version."""'
        body = f"{doc}\n\n{router_imports}\n\nrouters = ({router_tuple}{suffix})\n"
        yield StagedFile(
            path=output_dir / INIT_FILENAME, content=body, identifier=str(output_dir / INIT_FILENAME)
        )


class MajorPackageInitRenderer:
    """Emit ``__init__.py`` under ``api/v{major}/``.

    Re-exports each domain's ``routers`` so the mount step can flatten
    them with one import per major.
    """

    def __init__(self, domains: tuple[str, ...]) -> None:
        self.domains = tuple(sorted(set(domains)))

    def render(self, items: Sequence[DatasetSpec], output_dir: Path) -> Iterable[StagedFile]:
        """Yield ``__init__.py`` re-exporting per-domain routers."""
        del items
        if not self.domains:
            yield StagedFile(
                path=output_dir / INIT_FILENAME,
                content='"""Major version package."""\n\nrouters = ()\n',
                identifier=str(output_dir / INIT_FILENAME),
            )
            return
        packages = tuple(domain_package_name(domain) for domain in self.domains)
        imports = "\n".join(
            f"from .{package} import routers as {package}_routers" for package in packages
        )
        joined = " + ".join(f"{package}_routers" for package in packages)
        body = f'"""Major version package."""\n\n{imports}\n\nrouters = {joined}\n'
        yield StagedFile(
            path=output_dir / INIT_FILENAME, content=body, identifier=str(output_dir / INIT_FILENAME)
        )
