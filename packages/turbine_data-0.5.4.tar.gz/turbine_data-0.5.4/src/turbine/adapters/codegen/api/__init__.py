"""API generation: contract-first FastAPI codegen.

Emits a per-major-domain ``api/`` package whose generated routers and
models import their runtime helpers directly from
``turbine.api.runtime``. The user's project carries no copy of the
runtime — only the contract-shaped code.
"""

from .mount import MountRenderer
from .package_init import DomainPackageInitRenderer, EmptyApiInitRenderer, MajorPackageInitRenderer
from .plan import build_codegen_plan
from .schema_model import ApiModelRenderer
from .schema_router import ApiRouterRenderer
from .slow_count import at_risk_contract_ids, format_advisory

__all__ = [
    "ApiModelRenderer",
    "ApiRouterRenderer",
    "DomainPackageInitRenderer",
    "EmptyApiInitRenderer",
    "MajorPackageInitRenderer",
    "MountRenderer",
    "at_risk_contract_ids",
    "build_codegen_plan",
    "format_advisory",
]
