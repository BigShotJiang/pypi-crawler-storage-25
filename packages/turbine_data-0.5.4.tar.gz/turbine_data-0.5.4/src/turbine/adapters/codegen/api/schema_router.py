"""Render the per-contract FastAPI router module.

Output path comes from :class:`ApiLayout.router_file`; the convention
is named once in ``layout.py`` instead of being repeated here.
The router exposes a GET-by-id endpoint plus a paginated list endpoint
(GET + HEAD) emitting RFC 8288 ``Link`` headers and ``X-Total-Count``
per the Enexis pagination rules.
"""

import ast
from collections.abc import Iterable, Sequence
from pathlib import Path

from turbine.core.codegen import StagedFile, datetime_import_names, map_type
from turbine.core.common import ColumnDef, DatasetSpec
from turbine.core.contract.api_rules import (
    NO_STORE_CACHE_CONTROL,
    ContractRuntimeInfo,
    description_text,
    detail_cache_control,
    external_docs_url,
    filterable_columns,
    resource_label,
    resource_name,
    resource_path,
    runtime_info,
)

from ..ast_utils import (
    assign,
    attr,
    call,
    const,
    function_def,
    import_from,
    module_to_source,
    name,
    nullable,
    subscript,
    with_block,
)
from .naming import (
    contract_class_base,
    contract_module_name,
    detail_operation_id,
    list_operation_id,
    router_module_name,
    tag_for,
    to_camel,
)
from .schema_model import GENERATED_HEADER, pk_fields

DRAFT_SUMMARY_PREFIX = "[DRAFT] "
PHASE_DB = "db"


def external_docs_dict(url: str) -> ast.Dict:
    """Build ``{'url': url}`` for the ``externalDocs`` openapi extra."""
    return ast.Dict(keys=[const("url")], values=[const(url)], lineno=0, col_offset=0)


def openapi_extra_keyword(spec: DatasetSpec, ctx: ContractRuntimeInfo) -> ast.keyword:
    """Build the ``openapi_extra={...}`` keyword carrying ``x-`` extras + externalDocs."""
    extras = ctx.openapi_extras()
    keys: list[ast.expr | None] = [const(key) for key in extras]
    values: list[ast.expr] = [const(value) for value in extras.values()]
    keys.append(const("externalDocs"))
    values.append(external_docs_dict(external_docs_url(spec)))
    return ast.keyword(
        arg="openapi_extra", value=ast.Dict(keys=keys, values=values, lineno=0, col_offset=0)
    )


def route_params(spec: DatasetSpec) -> tuple[str, ...]:
    """Return the detail-route path parameter names in PK order."""
    return tuple(column.name for column in pk_fields(spec))


LIST_RESPONSE_CODES: tuple[tuple[int, str], ...] = (
    (200, "OK"),
    (206, "Partial Content"),
    (400, "Bad Request"),
    (404, "Not Found"),
    (422, "Validation Error"),
)
DEFAULT_OFFSET = 0
DEFAULT_LIMIT = 50
MAX_LIMIT = 5000
FILTER_OPERATOR_EXAMPLES: tuple[str, ...] = ("42", "1,2,3", ">10", ">=10", "<10", "<=10", "*=.*foo.*")
SORT_DIRECTIVE_DESCRIPTION = (
    "Sort by one or more fields. Prefix with '+' for ascending (default) "
    "or '-' for descending; comma-separated for multi-key sort."
)
FIELDS_DIRECTIVE_DESCRIPTION = (
    "Sparse fieldset selector. Comma-separated field names to include; 'none' returns only id and href."
)
FILTER_DESCRIPTION_TEMPLATE = (
    "Filter by {field}. Supports operators encoded inline in the value: "
    "'=' (default), ',' for IN, '>' '>=' '<' '<=' for ranges, '*=' for regex."
)


def session_param() -> ast.arg:
    """Build ``session: Annotated[Session, Depends(get_session)]``."""
    ann = subscript(
        name("Annotated"), name("Session"), call(name("Depends"), args=[name("get_session")])
    )
    return ast.arg(arg="session", annotation=ann)


def request_param() -> ast.arg:
    """Build ``request: Request``."""
    return ast.arg(arg="request", annotation=name("Request"))


def id_params(spec: DatasetSpec) -> list[ast.arg]:
    """Build typed path parameters for every PK column in contract order."""
    return [
        ast.arg(arg=column.name, annotation=name(map_type(column.logical_type)))
        for column in pk_fields(spec)
    ]


def get_decorator(spec: DatasetSpec, schema_class_name: str, ctx: ContractRuntimeInfo) -> ast.Call:
    """Build the ``@router.get(...)`` decorator carrying operationId + responses."""
    operation_id = detail_operation_id(spec.metadata.contract_id, resource_name(spec).value)
    responses = ast.Dict(
        keys=[const(200), const(404)],
        values=[
            ast.Dict(keys=[const("description")], values=[const("OK")], lineno=0, col_offset=0),
            ast.Dict(keys=[const("description")], values=[const("Not Found")], lineno=0, col_offset=0),
        ],
        lineno=0,
        col_offset=0,
    )
    summary = f"Get {resource_label(spec)} by ID"
    keywords = [
        ast.keyword(arg="response_model", value=name(schema_class_name)),
        ast.keyword(arg="summary", value=const(summary)),
        ast.keyword(arg="description", value=const(description_text(spec))),
        ast.keyword(arg="operation_id", value=const(operation_id)),
        ast.keyword(arg="responses", value=responses),
        openapi_extra_keyword(spec, ctx),
    ]
    if ctx.is_deprecated:
        keywords.append(ast.keyword(arg="deprecated", value=const(True)))
    path = "/" + "/".join(f"{{{param}}}" for param in route_params(spec))
    return call(attr("router", "get"), args=[const(path)], keywords=keywords)


def head_decorator(spec: DatasetSpec) -> ast.Call:
    """Build a ``@router.head(...)`` decorator hidden from the schema.

    HEAD is registered as its own route so Starlette returns 200 with
    the same headers as GET.  ``include_in_schema=False`` keeps the
    OpenAPI document free of duplicate operationIds for client
    generators.
    """
    path = "/" + "/".join(f"{{{param}}}" for param in route_params(spec))
    return call(
        attr("router", "head"),
        args=[const(path)],
        keywords=[ast.keyword(arg="include_in_schema", value=const(False))],
    )


def db_phase_context() -> ast.Call:
    """Build the ``phase(request, "db")`` call used as a ``with`` target."""
    return call(name("phase"), args=[name("request"), const(PHASE_DB)])


def last_modified_expr(spec: DatasetSpec) -> ast.expr:
    """Build the ``last_modified`` keyword value for ``apply_detail_caching``.

    Returns ``latency_imf_fixdate(row.<col>)`` when the contract declares an
    SLA latency column, else the literal ``None`` so the keyword still
    flows uniformly through the rendered call.
    """
    latency = spec.latency_column
    if latency is None:
        return const(None)
    return call(name("latency_imf_fixdate"), args=[attr("row", latency)])


def caching_call(spec: DatasetSpec, model_class_name: str) -> ast.Assign:
    """Build ``cached = apply_detail_caching(response, request=..., ...)``."""
    return assign(
        "cached",
        call(
            name("apply_detail_caching"),
            args=[name("response")],
            keywords=[
                ast.keyword(arg="request", value=name("request")),
                ast.keyword(arg="payload", value=name("payload")),
                ast.keyword(
                    arg="contract_version", value=attr(model_class_name, "__contract_version__")
                ),
                ast.keyword(arg="cache_control", value=const(detail_cache_control(spec))),
                ast.keyword(arg="last_modified", value=last_modified_expr(spec)),
            ],
        ),
    )


def cached_short_circuit() -> ast.If:
    """Emit ``if cached is not None: return cached``."""
    test = ast.Compare(
        left=name("cached"), ops=[ast.IsNot()], comparators=[const(None)], lineno=0, col_offset=0
    )
    return ast.If(
        test=test,
        body=[ast.Return(value=name("cached"), lineno=0, col_offset=0)],
        orelse=[],
        lineno=0,
        col_offset=0,
    )


def detail_endpoint(
    spec: DatasetSpec, model_class_name: str, schema_class_name: str, ctx: ContractRuntimeInfo
) -> ast.FunctionDef:
    """Build the GET-by-id handler with row fetch, schema projection, caching."""
    function_name = detail_operation_id(spec.metadata.contract_id, resource_name(spec).value)
    params = route_params(spec)
    args = ast.arguments(
        posonlyargs=[],
        args=[*id_params(spec), request_param(), response_param(), session_param()],
        kwonlyargs=[],
        kw_defaults=[],
        defaults=[],
    )
    entity_id: ast.expr = name(params[0])
    if len(params) > 1:
        entity_id = ast.Tuple(
            elts=[name(param) for param in params], ctx=ast.Load(), lineno=0, col_offset=0
        )
    fetch_row = assign(
        "row", call(attr(model_class_name, "get_or_404"), args=[name("session"), entity_id])
    )
    build_payload = assign("payload", call(attr("row", "to_schema"), args=[name("request")]))
    body: list[ast.stmt] = [
        with_block(db_phase_context(), [fetch_row]),
        build_payload,
        caching_call(spec, model_class_name),
        cached_short_circuit(),
        ast.Return(value=name("payload"), lineno=0, col_offset=0),
    ]
    return function_def(
        fname=function_name,
        args=args,
        body=body,
        returns=name(schema_class_name),
        decorators=[head_decorator(spec), get_decorator(spec, schema_class_name, ctx)],
    )


def response_param() -> ast.arg:
    """Build ``response: Response`` for setting status / headers in-handler."""
    return ast.arg(arg="response", annotation=name("Response"))


def query_param(field_name: str, alias: str, *, ge: int, le: int | None = None) -> ast.arg:
    """Build ``field: Annotated[int, Query(alias=..., ge=..., le=...)]``."""
    keywords = [ast.keyword(arg="alias", value=const(alias)), ast.keyword(arg="ge", value=const(ge))]
    if le is not None:
        keywords.append(ast.keyword(arg="le", value=const(le)))
    annotation_expr = subscript(name("Annotated"), name("int"), call(name("Query"), keywords=keywords))
    return ast.arg(arg=field_name, annotation=annotation_expr)


def list_responses_dict() -> ast.Dict:
    """Build the ``responses={...}`` dict literal for the list decorator."""
    return ast.Dict(
        keys=[const(code) for code, _ in LIST_RESPONSE_CODES],
        values=[
            ast.Dict(keys=[const("description")], values=[const(label)], lineno=0, col_offset=0)
            for _, label in LIST_RESPONSE_CODES
        ],
        lineno=0,
        col_offset=0,
    )


def list_decorator(spec: DatasetSpec, schema_class_name: str, ctx: ContractRuntimeInfo) -> ast.Call:
    """Build the public ``@router.get('/')`` decorator for list responses."""
    operation_id = list_operation_id(spec.metadata.contract_id, resource_name(spec).value)
    label = resource_label(spec)
    summary = f"{DRAFT_SUMMARY_PREFIX}List {label}" if ctx.is_draft else f"List {label}"
    keywords = [
        ast.keyword(arg="response_model", value=subscript(name("Page"), name(schema_class_name))),
        ast.keyword(arg="summary", value=const(summary)),
        ast.keyword(arg="description", value=const(description_text(spec))),
        ast.keyword(arg="operation_id", value=const(operation_id)),
        ast.keyword(arg="responses", value=list_responses_dict()),
        openapi_extra_keyword(spec, ctx),
    ]
    if ctx.is_deprecated:
        keywords.append(ast.keyword(arg="deprecated", value=const(True)))
    return call(attr("router", "get"), args=[const("/")], keywords=keywords)


def list_head_decorator() -> ast.Call:
    """Build the hidden ``@router.head('/')`` decorator for list responses."""
    return call(
        attr("router", "head"),
        args=[const("/")],
        keywords=[ast.keyword(arg="include_in_schema", value=const(False))],
    )


def list_query_assignment(model_class_name: str) -> ast.Assign:
    """Build ``rows, total = ContractId.list_query(session, ..., filters=filters, sort=sort)``."""
    target = ast.Tuple(
        elts=[
            ast.Name(id="rows", ctx=ast.Store(), lineno=0, col_offset=0),
            ast.Name(id="total", ctx=ast.Store(), lineno=0, col_offset=0),
        ],
        ctx=ast.Store(),
        lineno=0,
        col_offset=0,
    )
    rhs = call(
        attr(model_class_name, "list_query"),
        args=[name("session")],
        keywords=[
            ast.keyword(arg="offset", value=name("offset")),
            ast.keyword(arg="limit", value=name("limit")),
            ast.keyword(arg="filters", value=name("filters")),
            ast.keyword(arg="sort", value=name("sort")),
        ],
    )
    return ast.Assign(targets=[target], value=rhs, lineno=0, col_offset=0)


def apply_headers_call() -> ast.Expr:
    """Build the ``apply_pagination_headers(...)`` statement."""
    expr = call(
        name("apply_pagination_headers"),
        args=[name("response")],
        keywords=[
            ast.keyword(arg="request", value=name("request")),
            ast.keyword(arg="items_count", value=call(name("len"), args=[name("rows")])),
            ast.keyword(arg="total", value=name("total")),
            ast.keyword(arg="offset", value=name("offset")),
            ast.keyword(arg="limit", value=name("limit")),
        ],
    )
    return ast.Expr(value=expr, lineno=0, col_offset=0)


def list_response_return() -> ast.Return:
    """Build ``return build_list_response(rows, ...)`` — branches on ``_fields``."""
    payload = call(
        name("build_list_response"),
        args=[name("rows")],
        keywords=[
            ast.keyword(arg="request", value=name("request")),
            ast.keyword(arg="response", value=name("response")),
            ast.keyword(arg="fields_raw", value=name("fields")),
            ast.keyword(arg="total", value=name("total")),
            ast.keyword(arg="offset", value=name("offset")),
            ast.keyword(arg="limit", value=name("limit")),
        ],
    )
    return ast.Return(value=payload, lineno=0, col_offset=0)


def filter_query_examples(col: ColumnDef) -> tuple[str, ...]:
    """Return the Query examples list — column example first when available."""
    if col.example is None:
        return FILTER_OPERATOR_EXAMPLES
    return (col.example, *FILTER_OPERATOR_EXAMPLES)


def filter_query_param(col: ColumnDef) -> ast.arg:
    """Build a per-column ``Query`` param accepting operator-prefixed values.

    The argument keeps the column's snake_case Python name so handler
    code references it directly; the wire alias is camelCase so the URL
    matches the schema's wire format.
    """
    description = FILTER_DESCRIPTION_TEMPLATE.format(field=col.name)
    examples = ast.List(
        elts=[const(example) for example in filter_query_examples(col)],
        ctx=ast.Load(),
        lineno=0,
        col_offset=0,
    )
    keywords = [
        ast.keyword(arg="alias", value=const(to_camel(col.name))),
        ast.keyword(arg="description", value=const(description)),
        ast.keyword(arg="examples", value=examples),
    ]
    annotation_expr = subscript(
        name("Annotated"), nullable(name("str")), call(name("Query"), keywords=keywords)
    )
    return ast.arg(arg=col.name, annotation=annotation_expr)


def meta_str_query_param(arg_name: str, alias: str, description: str) -> ast.arg:
    """Build a ``str | None`` meta param like ``_sort`` or ``_fields``."""
    keywords = [
        ast.keyword(arg="alias", value=const(alias)),
        ast.keyword(arg="description", value=const(description)),
    ]
    annotation_expr = subscript(
        name("Annotated"), nullable(name("str")), call(name("Query"), keywords=keywords)
    )
    return ast.arg(arg=arg_name, annotation=annotation_expr)


def filters_dict_assign(spec: DatasetSpec) -> ast.Assign:
    """Build ``filters = {col_name: col_arg, ...}`` over the dataset's filterable columns.

    Iterates :func:`filterable_columns` so the dict only carries the
    columns the renderer also exposed as ``Query`` parameters above; an
    untagged column never reaches the ``apply_filters`` clause.
    """
    columns = filterable_columns(spec).columns
    keys: list[ast.expr | None] = [const(col.name) for col in columns]
    values: list[ast.expr] = [name(col.name) for col in columns]
    return assign("filters", ast.Dict(keys=keys, values=values, lineno=0, col_offset=0))


def validate_query_params_call(model_class_name: str) -> ast.Expr:
    """Build ``ContractId.validate_query_params(request)``."""
    return ast.Expr(
        value=call(attr(model_class_name, "validate_query_params"), args=[name("request")]),
        lineno=0,
        col_offset=0,
    )


def list_endpoint_args(spec: DatasetSpec) -> tuple[list[ast.arg], list[ast.expr]]:
    """Build the (positional args, defaults) tuple for the list handler.

    Order matters: the framework binds args in order, so non-default
    args (request, response, session) come first, then offset/limit,
    then sort/fields meta params, then per-column filter params. Filter
    params are gated by :func:`filterable_columns` so wide schemas don't
    explode the parameter count.
    """
    args: list[ast.arg] = [
        request_param(),
        response_param(),
        session_param(),
        query_param("offset", "_offset", ge=0),
        query_param("limit", "_limit", ge=1, le=MAX_LIMIT),
        meta_str_query_param("sort", "_sort", SORT_DIRECTIVE_DESCRIPTION),
        meta_str_query_param("fields", "_fields", FIELDS_DIRECTIVE_DESCRIPTION),
    ]
    defaults: list[ast.expr] = [const(DEFAULT_OFFSET), const(DEFAULT_LIMIT), const(None), const(None)]
    for col in filterable_columns(spec).columns:
        args.append(filter_query_param(col))
        defaults.append(const(None))
    return args, defaults


def list_no_store_assignment() -> ast.Assign:
    """Emit ``response.headers['Cache-Control'] = 'no-store'`` on list responses.

    Per the design, list responses cannot share filter-set-aware ETags, so
    the runtime always opts them out of caching.
    """
    target = ast.Subscript(
        value=attr("response", "headers"),
        slice=const("Cache-Control"),
        ctx=ast.Store(),
        lineno=0,
        col_offset=0,
    )
    return ast.Assign(targets=[target], value=const(NO_STORE_CACHE_CONTROL), lineno=0, col_offset=0)


def list_endpoint(
    spec: DatasetSpec, model_class_name: str, schema_class_name: str, ctx: ContractRuntimeInfo
) -> ast.FunctionDef:
    """Build the paginated list handler with filter / sort / sparse-field wiring."""
    function_name = list_operation_id(spec.metadata.contract_id, resource_name(spec).value)
    args_list, defaults = list_endpoint_args(spec)
    args = ast.arguments(
        posonlyargs=[], args=args_list, kwonlyargs=[], kw_defaults=[], defaults=defaults
    )
    body: list[ast.stmt] = [
        validate_query_params_call(model_class_name),
        filters_dict_assign(spec),
        with_block(db_phase_context(), [list_query_assignment(model_class_name)]),
        apply_headers_call(),
        list_no_store_assignment(),
        list_response_return(),
    ]
    return function_def(
        fname=function_name,
        args=args,
        body=body,
        returns=subscript(name("Page"), name(schema_class_name)),
        decorators=[list_head_decorator(), list_decorator(spec, schema_class_name, ctx)],
    )


def build_imports(spec: DatasetSpec, classes: tuple[str, str]) -> list[ast.stmt]:
    """Build all imports for the router module."""
    model_class_name, schema_class_name = classes
    stmts: list[ast.stmt] = [import_from("typing", ["Annotated"])]
    if dt_names := datetime_import_names(pk_fields(spec)):
        stmts.append(import_from("datetime", dt_names))
    resource = resource_name(spec).value
    runtime_imports = ["Page", "apply_pagination_headers", "build_list_response", "get_session", "phase"]
    if pk_fields(spec):
        runtime_imports.extend(["apply_detail_caching", "latency_imf_fixdate"])
    stmts.extend(
        [
            import_from("fastapi", ["APIRouter", "Depends", "Query", "Request", "Response"]),
            import_from("sqlalchemy.orm", ["Session"]),
            import_from("turbine.api.runtime", runtime_imports),
            import_from(
                f"..models.{contract_module_name(spec.metadata.contract_id, resource)}",
                [model_class_name, schema_class_name],
            ),
        ]
    )
    return stmts


def router_binding(spec: DatasetSpec, dataset_count: int) -> ast.Assign:
    """Build ``router = APIRouter(prefix=resource_path, tags=[tag_for(...)])``.

    The router carries its full URL prefix; the mount template includes
    it flat with no extra prefix injection. Tags are purely OpenAPI
    facing — single-dataset contracts get just the contract id, while
    multi-dataset contracts get ``{contract_id} · {resource_name}`` so
    the Swagger nav distinguishes siblings.
    """
    resource = resource_name(spec).value
    tag = tag_for(spec.metadata.contract_id, resource, dataset_count)
    tags = ast.List(elts=[const(tag)], ctx=ast.Load(), lineno=0, col_offset=0)
    return assign(
        "router",
        call(
            name("APIRouter"),
            keywords=[
                ast.keyword(arg="prefix", value=const(resource_path(spec))),
                ast.keyword(arg="tags", value=tags),
            ],
        ),
    )


def build_module(spec: DatasetSpec, ctx: ContractRuntimeInfo, dataset_count: int) -> ast.Module:
    """Build the full router AST for *spec*.

    *dataset_count* is the number of datasets sharing this contract id
    inside the same ``(major, domain)`` group; it controls the OpenAPI
    tag shape (see :func:`tag_for`).
    """
    resource = resource_name(spec).value
    base = contract_class_base(spec.metadata.contract_id, resource)
    schema_class_name = f"{base}Schema"
    body: list[ast.stmt] = list(build_imports(spec, (base, schema_class_name)))
    body.append(router_binding(spec, dataset_count))
    body.append(list_endpoint(spec, base, schema_class_name, ctx))
    if pk_fields(spec):
        body.append(detail_endpoint(spec, base, schema_class_name, ctx))
    return ast.Module(body=body, type_ignores=[])


def datasets_per_contract(specs: Sequence[DatasetSpec]) -> dict[str, int]:
    """Count datasets per contract id within a single ``(major, domain)`` group."""
    counts: dict[str, int] = {}
    for spec in specs:
        counts[spec.metadata.contract_id] = counts.get(spec.metadata.contract_id, 0) + 1
    return counts


class ApiRouterRenderer:
    """Emit the per-dataset router module under ``routers/``.

    Filters incoming items to the configured ``(major, domain)`` group.
    A multi-dataset contract emits N sibling router files, each named
    ``{contract_id}__{resource_name}_router.py``, each carrying its
    full ``/{domain}/v{major}/{contract_id}/{resource_name}`` prefix.
    """

    def __init__(self, major: int, domain: str) -> None:
        self.major = major
        self.domain = domain

    def render(self, items: Sequence[DatasetSpec], output_dir: Path) -> Iterable[StagedFile]:
        """Yield one staged file per dataset matching the renderer's filter."""
        scoped = [
            spec
            for spec in items
            if spec.metadata.major_version == self.major and spec.metadata.domain == self.domain
        ]
        counts = datasets_per_contract(scoped)
        for spec in scoped:
            ctx = runtime_info(spec, items)
            dataset_count = counts.get(spec.metadata.contract_id, 1)
            module = build_module(spec, ctx, dataset_count)
            source = f"{GENERATED_HEADER}\n{module_to_source(module)}\n"
            resource = resource_name(spec).value
            yield StagedFile(
                path=output_dir / f"{router_module_name(spec.metadata.contract_id, resource)}.py",
                content=source,
                identifier=f"{spec.metadata.contract_id}__{resource}",
            )
