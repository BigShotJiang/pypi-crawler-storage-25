"""Codegen-time advisory for contracts likely to be slow under list counting.

The list endpoint runs ``COUNT(*) OVER ()`` alongside the page query so
``X-Total-Count`` is always populated. On row-store engines (Postgres),
that count cost scales with filter selectivity: contracts whose
filterable columns are unindexed will pay it on every list call.

This module reads contract metadata only and flags contracts whose
non-PK columns are missing the ``sortable`` tag.
"""

from collections.abc import Sequence

from turbine.core.common import DatasetSpec

SORTABLE_TAG = "sortable"


def at_risk_contract_ids(specs: Sequence[DatasetSpec]) -> list[str]:
    """Return contract ids whose list endpoints may be slow under counting.

    A contract is at-risk when it has at least one non-primary-key
    column that is not tagged ``sortable``: filters land there with no
    obvious index hint, so ``COUNT(*) OVER ()`` cost will track scan
    cost. Backend-aware filtering (Snowflake exempt) lands when the
    spec carries datasource type — for now the advisory is the same
    everywhere.
    """
    return [spec.metadata.contract_id for spec in specs if has_unindexed_filterable_column(spec)]


def has_unindexed_filterable_column(spec: DatasetSpec) -> bool:
    """Return True when *spec* has a non-PK column lacking the ``sortable`` tag."""
    return any(not column.primary_key and SORTABLE_TAG not in column.tags for column in spec.columns)


def format_advisory(contract_ids: Sequence[str]) -> str:
    """Format the advisory message for stderr output.

    Returns an empty string when the input is empty so callers can
    treat the result as the printable form unconditionally.
    """
    if not contract_ids:
        return ""
    bullet_list = "\n".join(f"  - {contract_id}" for contract_id in contract_ids)
    return (
        "Slow-count advisory: these contracts have non-key columns without a "
        "'sortable' tag, so the list endpoint's COUNT(*) will scan the full "
        "table on every call:\n"
        f"{bullet_list}\n"
        "Tag the columns you filter or sort by with 'sortable' to let the "
        "backend use an index."
    )
