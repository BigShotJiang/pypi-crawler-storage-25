"""Render the top-level ``api/__init__.py`` with ``mount(app)``.

Aggregates every per-major routers tuple, wires exception handlers
from ``runtime`` onto the master FastAPI app, and includes each router
under ``/{domain}/v{major}/{contract.id}``.  Also computes per-major
:class:`MajorVersionInfo` and emits a ``register_versioned_openapi``
call so each major gets its own filtered ``/v{major}/openapi.json``,
``/docs``, ``/redoc``, ``/__contracts__``, and ``/__schema__`` views.
"""

from collections import defaultdict
from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path

from turbine.core.codegen import StagedFile
from turbine.core.common import DatasetSpec
from turbine.core.contract.api_rules import (
    external_docs_url,
    resource_name,
    runtime_info,
    statuses_for_documentation,
)

from .layout import ApiLayout
from .naming import contract_class_base, detail_operation_id, list_operation_id, slug_to_module_part

INIT_FILENAME = "__init__.py"


@dataclass(frozen=True, slots=True)
class ResourceEntry:
    """One sibling resource under a contract — drives the ``ContractInfo`` literal.

    A multi-dataset contract emits N entries, one per Dataset, sorted
    by resource name so the rendered code stays diff-friendly.
    """

    resource_name: str
    schema_class_name: str
    schema_alias: str
    schema_module_path: str
    list_operation_id: str
    detail_operation_id: str


@dataclass(frozen=True, slots=True)
class ContractEntry:
    """Codegen-side mirror of the runtime ``ContractInfo``.

    Lifecycle stays per-contract (status, sunset, successor); the
    ``resources`` tuple carries one entry per Dataset so the runtime
    introspection endpoints can list every URL the contract serves.
    """

    contract_id: str
    domain: str
    version: str
    status: str
    docs_url: str
    sunset_date: str | None
    successor_href: str | None
    resources: tuple[ResourceEntry, ...]


@dataclass(frozen=True, slots=True)
class MajorVersionPlan:
    """Codegen-side mirror of the runtime ``MajorVersionInfo``.

    Carries everything the mount template needs to render a literal
    ``MajorVersionInfo(...)`` constructor for one major version.
    """

    major: int
    version: str
    description: str
    domain_descriptions: tuple[tuple[str, str], ...]
    contracts: tuple[ContractEntry, ...]


class MountRenderer:
    """Emit ``api/__init__.py`` exposing ``mount(app)``.

    Receives an :class:`ApiLayout` so the rendered ``ContractInfo``
    literals import each contract's schema via the same dotted path
    accessor every other renderer uses.
    """

    def __init__(self, layout: ApiLayout) -> None:
        self.layout = layout

    def render(self, items: Sequence[DatasetSpec], output_dir: Path) -> Iterable[StagedFile]:
        """Yield a single ``__init__.py`` rolled up across every contract."""
        documented = [spec for spec in items if spec.metadata.status in statuses_for_documentation()]
        majors = sorted({spec.metadata.major_version for spec in documented})
        version_plans = compute_major_version_plans(documented, self.layout)
        body = build_mount_source(majors, version_plans)
        yield StagedFile(path=output_dir / INIT_FILENAME, content=body, identifier="api/__init__.py")


def compute_major_version_plans(
    specs: Sequence[DatasetSpec], layout: ApiLayout
) -> list[MajorVersionPlan]:
    """Aggregate *specs* into one :class:`MajorVersionPlan` per major.

    Per-major fields:

    * ``version`` — the highest semver among contracts at that major.
    * ``description`` — sentence-joined ``contract_id``s (or ``name``s
      when populated) so the filtered spec carries something useful;
      issue 012 will replace this with ``description.purpose``.
    * ``domain_descriptions`` — sorted ``(domain, description)`` pairs;
      one entry per distinct domain at that major.
    * ``contracts`` — one :class:`ContractEntry` per contract, sorted
      by id, used by the runtime introspection endpoints.
    """
    by_major: dict[int, list[DatasetSpec]] = defaultdict(list)
    for spec in specs:
        if spec.metadata.domain:
            by_major[spec.metadata.major_version].append(spec)
    return [
        build_major_version_plan(major, by_major[major], specs, layout) for major in sorted(by_major)
    ]


def build_major_version_plan(
    major: int, specs: Sequence[DatasetSpec], all_specs: Sequence[DatasetSpec], layout: ApiLayout
) -> MajorVersionPlan:
    """Roll *specs* (all at the same major) into one :class:`MajorVersionPlan`.

    *all_specs* is the full run so successor references can be resolved
    across majors when ``customProperties.supersededBy`` points to a
    sibling contract.
    """
    version = max(spec.metadata.version for spec in specs)
    description = aggregate_description(specs)
    domain_descriptions = aggregate_domain_descriptions(specs)
    contracts = build_contract_entries(specs, all_specs, layout)
    return MajorVersionPlan(
        major=major,
        version=version,
        description=description,
        domain_descriptions=domain_descriptions,
        contracts=contracts,
    )


def aggregate_description(specs: Sequence[DatasetSpec]) -> str:
    """Sentence-join one description per contract, sorted by id for stability.

    Falls back to a generic line when no contract carries a name so
    the OpenAPI ``info.description`` always renders something.
    """
    sentences: list[str] = []
    for spec in sorted(specs, key=lambda item: item.metadata.contract_id):
        label = spec.metadata.name or spec.metadata.contract_id
        sentences.append(f"{label}.")
    if not sentences:
        return "Generated API."
    return " ".join(sentences)


def aggregate_domain_descriptions(specs: Sequence[DatasetSpec]) -> tuple[tuple[str, str], ...]:
    """Pick the first contract per domain and synthesise a tag description."""
    by_domain: dict[str, DatasetSpec] = {}
    for spec in sorted(specs, key=lambda item: item.metadata.contract_id):
        domain = spec.metadata.domain
        if domain and domain not in by_domain:
            by_domain[domain] = spec
    return tuple(
        (domain, f"Endpoints under the {domain} bounded context.") for domain in sorted(by_domain)
    )


def build_contract_entries(
    specs: Sequence[DatasetSpec], all_specs: Sequence[DatasetSpec], layout: ApiLayout
) -> tuple[ContractEntry, ...]:
    """One :class:`ContractEntry` per contract id, sorted, with a ``resources`` tuple."""
    by_contract: dict[str, list[DatasetSpec]] = defaultdict(list)
    for spec in specs:
        by_contract[spec.metadata.contract_id].append(spec)
    return tuple(
        build_contract_entry(by_contract[contract_id], all_specs, layout)
        for contract_id in sorted(by_contract)
    )


def build_contract_entry(
    contract_specs: Sequence[DatasetSpec], all_specs: Sequence[DatasetSpec], layout: ApiLayout
) -> ContractEntry:
    """Build one :class:`ContractEntry` covering every dataset under one contract id.

    Lifecycle metadata is taken from the first spec (every dataset
    shares the contract's status, sunset, and successor by definition).
    *contract_specs* must be non-empty.
    """
    representative = contract_specs[0]
    ctx = runtime_info(representative, all_specs)
    domain = representative.metadata.domain or ""
    resources = build_resource_entries(contract_specs, layout)
    return ContractEntry(
        contract_id=representative.metadata.contract_id,
        domain=domain,
        version=representative.metadata.version,
        status=representative.metadata.status.value,
        docs_url=external_docs_url(representative),
        sunset_date=ctx.sunset_date,
        successor_href=ctx.successor_href,
        resources=resources,
    )


def build_resource_entries(
    contract_specs: Sequence[DatasetSpec], layout: ApiLayout
) -> tuple[ResourceEntry, ...]:
    """One :class:`ResourceEntry` per dataset, sorted by resource name."""
    sorted_specs = sorted(contract_specs, key=lambda spec: resource_name(spec).value)
    return tuple(build_resource_entry(spec, layout) for spec in sorted_specs)


def build_resource_entry(spec: DatasetSpec, layout: ApiLayout) -> ResourceEntry:
    """Resolve a single dataset into a :class:`ResourceEntry`."""
    resource = resource_name(spec).value
    base = contract_class_base(spec.metadata.contract_id, resource)
    domain = spec.metadata.domain or ""
    return ResourceEntry(
        resource_name=resource,
        schema_class_name=f"{base}Schema",
        schema_alias=schema_alias_for(spec, resource),
        schema_module_path=layout.model_module_path(
            spec.metadata.major_version, domain, spec.metadata.contract_id, resource
        ),
        list_operation_id=list_operation_id(spec.metadata.contract_id, resource),
        detail_operation_id=detail_operation_id(spec.metadata.contract_id, resource),
    )


def schema_alias_for(spec: DatasetSpec, resource: str) -> str:
    """Build a unique import alias scoping the schema by major + contract + resource."""
    contract_part = slug_to_module_part(spec.metadata.contract_id)
    resource_part = slug_to_module_part(resource)
    return f"schema_v{spec.metadata.major_version}_{contract_part}__{resource_part}"


def build_mount_source(majors: list[int], version_plans: list[MajorVersionPlan]) -> str:
    """Assemble the source for ``api/__init__.py``.

    The register block is a flat ``app.include_router(router)`` loop:
    each generated router carries its full
    ``/{domain}/v{major}/{contract_id}/{resource_name}`` prefix, so the
    mount template needs no helper to inject anything in front of it.
    """
    if not majors:
        router_imports = "# no contracts emitted"
        register_block = "    return"
    else:
        router_imports = "\n".join(
            f"from .v{major} import routers as v{major}_routers" for major in majors
        )
        register_lines: list[str] = []
        for major in majors:
            register_lines.append(f"    for router in v{major}_routers:")
            register_lines.append("        app.include_router(router)")
        register_block = "\n".join(register_lines)
    schema_imports = render_schema_imports(version_plans)
    imports = "\n".join(filter(None, [router_imports, schema_imports]))
    version_info_literal = render_version_info_literal(version_plans)
    return MOUNT_TEMPLATE.format(
        imports=imports, register_block=register_block, version_info_literal=version_info_literal
    )


def render_schema_imports(plans: list[MajorVersionPlan]) -> str:
    """Render one ``from ... import ... as alias`` line per (contract, resource) pair.

    The aliases are unique across the whole package so the rendered
    ``ResourceInfo(...)`` literals can reference each schema class
    without ambiguity.
    """
    lines = [
        "from "
        f"{resource.schema_module_path} "
        f"import {resource.schema_class_name} as {resource.schema_alias}"
        for plan in plans
        for entry in plan.contracts
        for resource in entry.resources
    ]
    return "\n".join(lines)


def render_version_info_literal(plans: list[MajorVersionPlan]) -> str:
    """Render *plans* as a Python list literal of ``MajorVersionInfo(...)``."""
    if not plans:
        return "[]"
    entries = [render_major_version_info(plan) for plan in plans]
    return "[\n" + ",\n".join(entries) + ",\n    ]"


def render_major_version_info(plan: MajorVersionPlan) -> str:
    """Render one :class:`MajorVersionPlan` as a constructor call."""
    domains = ", ".join(f"({name!r}, {description!r})" for name, description in plan.domain_descriptions)
    domain_tuple = f"({domains},)" if plan.domain_descriptions else "()"
    contracts_literal = render_contracts_tuple(plan.contracts)
    return (
        f"        MajorVersionInfo(\n"
        f"            major={plan.major},\n"
        f"            version={plan.version!r},\n"
        f"            description={plan.description!r},\n"
        f"            domain_descriptions={domain_tuple},\n"
        f"            contracts={contracts_literal},\n"
        f"        )"
    )


def render_contracts_tuple(contracts: tuple[ContractEntry, ...]) -> str:
    """Render *contracts* as a Python tuple literal of ``ContractInfo(...)``."""
    if not contracts:
        return "()"
    entries = [render_contract_info(entry) for entry in contracts]
    suffix = "," if len(contracts) == 1 else ""
    return "(\n" + ",\n".join(entries) + f"{suffix}\n            )"


def render_contract_info(entry: ContractEntry) -> str:
    """Render one :class:`ContractEntry` as a ``ContractInfo(...)`` call."""
    return (
        f"                ContractInfo(\n"
        f"                    contract_id={entry.contract_id!r},\n"
        f"                    domain={entry.domain!r},\n"
        f"                    version={entry.version!r},\n"
        f"                    status={entry.status!r},\n"
        f"                    docs_url={entry.docs_url!r},\n"
        f"                    sunset_date={entry.sunset_date!r},\n"
        f"                    successor_href={entry.successor_href!r},\n"
        f"                    resources={render_resources_tuple(entry.resources)},\n"
        f"                )"
    )


def render_resources_tuple(resources: tuple[ResourceEntry, ...]) -> str:
    """Render *resources* as a Python tuple literal of ``ResourceInfo(...)``."""
    if not resources:
        return "()"
    entries = [render_resource_info(resource) for resource in resources]
    suffix = "," if len(resources) == 1 else ""
    return "(\n" + ",\n".join(entries) + f"{suffix}\n                    )"


def render_resource_info(resource: ResourceEntry) -> str:
    """Render one :class:`ResourceEntry` as a ``ResourceInfo(...)`` call."""
    return (
        f"                        ResourceInfo(\n"
        f"                            resource_name={resource.resource_name!r},\n"
        f"                            schema_cls={resource.schema_alias},\n"
        f"                            list_operation_id={resource.list_operation_id!r},\n"
        f"                            detail_operation_id={resource.detail_operation_id!r},\n"
        f"                        )"
    )


MOUNT_TEMPLATE = '''# Auto-generated by turbine generate api. Do not edit manually.
"""Public API of the generated package.

``mount(app, datasource=...)`` is the only function callers need: it
binds a SQLAlchemy session to *app*, wires RFC 9457 exception handlers
and middleware, and includes every generated router on the master app.
Each router carries its own
``/{{domain}}/v{{major}}/{{contract_id}}/{{resource_name}}`` prefix, so the
mount step is a flat include loop with no helper functions in front of
it.

Pass exactly one of ``datasource`` (a Turbine ``DatasourceConfig`` from
your project's ``datasources/*.yml``) or ``engine`` (an already-built
SQLAlchemy ``Engine``).
"""

from __future__ import annotations

from fastapi import FastAPI
from sqlalchemy import Engine

from turbine.api.runtime import (
    ContractInfo,
    MajorVersionInfo,
    ResourceInfo,
    bind_datasource,
    register_contract_status_middleware,
    register_exception_handlers,
    register_observability_middleware,
    register_rate_limit_middleware,
    register_versioned_openapi,
)
from turbine.core.common import DatasourceConfig

{imports}


def mount(
    app: FastAPI,
    *,
    datasource: DatasourceConfig | None = None,
    engine: Engine | None = None,
) -> None:
    """Wire datasource binding, middleware, and routers onto *app*."""
    bind_datasource(app, engine=engine, datasource=datasource)
    register_exception_handlers(app)
    register_rate_limit_middleware(app)
    register_observability_middleware(app)
    register_contract_status_middleware(app)
{register_block}
    register_versioned_openapi(app, {version_info_literal})
'''
