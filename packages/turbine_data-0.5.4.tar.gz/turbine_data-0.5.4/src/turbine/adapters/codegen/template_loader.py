"""Shared Jinja2 environment for codegen templates."""

from pathlib import Path

import jinja2

TEMPLATES_DIR = Path(__file__).parent / "templates"


def create_jinja_env() -> jinja2.Environment:
    """Build a Jinja2 environment rooted at the templates/ directory."""
    return jinja2.Environment(
        loader=jinja2.FileSystemLoader(str(TEMPLATES_DIR)), keep_trailing_newline=True, autoescape=False
    )
