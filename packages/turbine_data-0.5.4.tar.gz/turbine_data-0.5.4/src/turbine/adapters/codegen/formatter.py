"""Ruff-backed batch formatter.

``BatchRuffFormatter`` writes a batch of staged ``.py`` files to a
tempdir and runs one ``ruff check --fix --select I`` plus one
``ruff format`` over the whole directory, so a single codegen run
triggers exactly one subprocess pair no matter how many files are
staged. Non-``.py`` files in the pending set pass through untouched.
"""

import hashlib
import shutil
import subprocess
import tempfile
from pathlib import Path

RUFF_TIMEOUT_SECONDS = 30


class BatchRuffFormatter:
    """Format a batch of staged (path, content) pairs in one ruff pair.

    Only ``.py`` files are sent through ruff; every other suffix passes
    through byte-identical. Python files are written under hashed names
    in a per-call tempdir, ``ruff check --fix --select I`` and
    ``ruff format`` each run once over the tempdir, and the results are
    read back. The tempdir is removed when :meth:`format_all` returns.
    """

    def __init__(self) -> None:
        """Locate the ruff binary on PATH."""
        self.ruff_path: str | None = shutil.which("ruff")

    def format_all(self, pending: dict[Path, str]) -> dict[Path, str]:
        """Return *pending* with each ``.py`` value reformatted by ruff.

        Non-Python files always pass through untouched. No-ops on an
        empty dict or when ruff is unavailable.
        """
        result = dict(pending)
        python_pending = {path: content for path, content in pending.items() if path.suffix == ".py"}
        if not python_pending or self.ruff_path is None:
            return result

        ruff_path = self.ruff_path
        with tempfile.TemporaryDirectory() as tmp:
            tmp_dir = Path(tmp)
            mapping: dict[Path, Path] = {
                tmp_dir / self.tempfile_name(real): real for real in python_pending
            }
            for tmp_path, real_path in mapping.items():
                tmp_path.write_text(python_pending[real_path])
            for args in (["check", "--fix", "--select", "I"], ["format"]):
                subprocess.run(
                    [ruff_path, *args, str(tmp_dir)],
                    capture_output=True,
                    check=False,
                    timeout=RUFF_TIMEOUT_SECONDS,
                )
            for tmp_path, real_path in mapping.items():
                result[real_path] = tmp_path.read_text()
        return result

    @staticmethod
    def tempfile_name(real_path: Path) -> str:
        """Hash the real path into a unique ``.py`` filename for the tempdir."""
        digest = hashlib.sha256(str(real_path).encode()).hexdigest()[:16]
        return f"{digest}.py"
