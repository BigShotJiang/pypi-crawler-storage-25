"""AST factory helpers for building Python source trees.

Thin wrappers around ``ast`` nodes that set line/col defaults
and reduce boilerplate in renderer code.
"""

import ast
from types import EllipsisType


def name(identifier: str) -> ast.Name:
    """Create an ``ast.Name`` node."""
    return ast.Name(id=identifier, ctx=ast.Load(), lineno=0, col_offset=0)


def const(value: str | float | bool | EllipsisType | None) -> ast.Constant:  # noqa: FBT001
    """Create an ``ast.Constant`` node."""
    return ast.Constant(value=value, lineno=0, col_offset=0)


def assign(target: str, value: ast.expr) -> ast.Assign:
    """Create a simple ``target = value`` assignment."""
    return ast.Assign(
        targets=[ast.Name(id=target, ctx=ast.Store(), lineno=0, col_offset=0)],
        value=value,
        lineno=0,
        col_offset=0,
    )


def call(
    func: ast.expr, args: list[ast.expr] | None = None, keywords: list[ast.keyword] | None = None
) -> ast.Call:
    """Create a function call expression."""
    return ast.Call(func=func, args=args or [], keywords=keywords or [], lineno=0, col_offset=0)


def import_from(module: str, names: list[str]) -> ast.ImportFrom:
    """Create a ``from module import name1, name2`` statement."""
    return ast.ImportFrom(
        module=module, names=[ast.alias(name=n) for n in names], level=0, lineno=0, col_offset=0
    )


def function_def(
    fname: str,
    args: ast.arguments | None = None,
    body: list[ast.stmt] | None = None,
    returns: ast.expr | None = None,
    decorators: list[ast.expr] | None = None,
) -> ast.FunctionDef:
    """Create a function definition."""
    default_args = ast.arguments(posonlyargs=[], args=[], kwonlyargs=[], kw_defaults=[], defaults=[])
    default_body: list[ast.stmt] = [ast.Pass(lineno=0, col_offset=0)]
    return ast.FunctionDef(
        name=fname,
        args=args or default_args,
        body=body or default_body,
        decorator_list=decorators or [],
        returns=returns,
        type_params=[],
        lineno=0,
        col_offset=0,
    )


def class_def(
    cname: str,
    bases: list[ast.expr] | None = None,
    body: list[ast.stmt] | None = None,
    keywords: list[ast.keyword] | None = None,
) -> ast.ClassDef:
    """Create a class definition."""
    default_body: list[ast.stmt] = [ast.Pass(lineno=0, col_offset=0)]
    return ast.ClassDef(
        name=cname,
        bases=bases or [],
        keywords=keywords or [],
        body=body or default_body,
        decorator_list=[],
        type_params=[],
        lineno=0,
        col_offset=0,
    )


def attr(obj: str, method: str) -> ast.Attribute:
    """Create an ``obj.method`` attribute access node."""
    return ast.Attribute(value=name(obj), attr=method, ctx=ast.Load(), lineno=0, col_offset=0)


def nullable(ann: ast.expr) -> ast.BinOp:
    """Wrap a type annotation in ``X | None``."""
    return ast.BinOp(left=ann, op=ast.BitOr(), right=name("None"), lineno=0, col_offset=0)


def annotation(field_name: str, ann: ast.expr, default: ast.expr | None = None) -> ast.AnnAssign:
    """Create a type-annotated assignment (``name: type = default``)."""
    return ast.AnnAssign(
        target=ast.Name(id=field_name, ctx=ast.Store(), lineno=0, col_offset=0),
        annotation=ann,
        value=default,
        simple=1,
        lineno=0,
        col_offset=0,
    )


def subscript(base: ast.expr, *args: ast.expr) -> ast.Subscript:
    """Create a subscript expression like ``Base[Arg1, Arg2]``."""
    if len(args) == 1:
        slice_node: ast.expr = args[0]
    else:
        slice_node = ast.Tuple(elts=list(args), ctx=ast.Load(), lineno=0, col_offset=0)
    return ast.Subscript(value=base, slice=slice_node, ctx=ast.Load(), lineno=0, col_offset=0)


def module_to_source(module: ast.Module) -> str:
    """Render an AST module to Python source code."""
    ast.fix_missing_locations(module)
    return ast.unparse(module)


def with_block(context_expr: ast.expr, body: list[ast.stmt]) -> ast.With:
    """Wrap *body* in a single-item ``with`` statement using *context_expr*."""
    return ast.With(
        items=[ast.withitem(context_expr=context_expr, optional_vars=None)],
        body=body,
        lineno=0,
        col_offset=0,
    )
