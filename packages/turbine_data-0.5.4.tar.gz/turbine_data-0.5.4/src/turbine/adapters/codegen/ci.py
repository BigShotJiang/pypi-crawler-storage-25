"""GitLab CI YAML generator — produces .gitlab-ci.yml from CIConfig."""

from collections.abc import Iterable, Sequence
from io import StringIO
from pathlib import Path

from pydantic import BaseModel, ConfigDict
from ruamel.yaml import YAML

from turbine.core.codegen import StagedFile
from turbine.core.codegen.model import CIConfig

CI_IMAGE = "$CI_REGISTRY/1000009-python-platform/applications/containers/python_ci:3.13"


class CacheConfig(BaseModel):
    """GitLab CI cache block."""

    model_config = ConfigDict(frozen=True)

    key: str = "uv-${CI_COMMIT_REF_SLUG}"
    paths: list[str] = [".cache/uv", ".venv"]


class ArtifactReports(BaseModel):
    """GitLab CI artifact reports block."""

    model_config = ConfigDict(frozen=True)

    junit: str


class Artifacts(BaseModel):
    """GitLab CI artifacts block."""

    model_config = ConfigDict(frozen=True)

    when: str = "always"
    reports: ArtifactReports


class RuleEntry(BaseModel):
    """Single GitLab CI rule."""

    model_config = ConfigDict(
        frozen=True,
        alias_generator=lambda field: {"condition": "if"}.get(field, field),
        populate_by_name=True,
    )

    condition: str


class CommonBlock(BaseModel):
    """GitLab CI .common hidden job for shared config."""

    model_config = ConfigDict(frozen=True)

    image: str = CI_IMAGE
    tags: list[str] = ["linux"]
    before_script: list[str] = ["uv sync --frozen --no-dev"]
    cache: CacheConfig = CacheConfig()
    rules: list[RuleEntry] = [RuleEntry(condition='$CI_PIPELINE_SOURCE == "merge_request_event"')]
    variables: dict[str, str] = {"UV_CACHE_DIR": "$CI_PROJECT_DIR/.cache/uv"}


class Job(BaseModel):
    """A single GitLab CI job."""

    model_config = ConfigDict(frozen=True)

    extends: str = ".common"
    stage: str
    script: list[str]
    needs: list[str] = []
    artifacts: Artifacts | None = None


class Pipeline(BaseModel):
    """Full GitLab CI pipeline — top-level .gitlab-ci.yml structure."""

    model_config = ConfigDict(
        frozen=True,
        populate_by_name=True,
        alias_generator=lambda field: {"common": ".common"}.get(field, field),
    )

    stages: list[str]
    common: CommonBlock
    lint: Job
    check: Job
    diff: Job


def build_pipeline(config: CIConfig) -> Pipeline:
    """Build the full GitLab CI pipeline from config."""
    lint_job = Job(
        stage="validate",
        script=[
            "uv run turbine lint --all --format junit > reports/lint.xml || true",
            "test -s reports/lint.xml && exit 1 || exit 0",
        ],
        artifacts=Artifacts(reports=ArtifactReports(junit="reports/lint.xml")),
    )

    check_job = Job(
        stage="quality",
        needs=["lint"],
        script=[
            f"uv run turbine check --ci --datasource {config.datasource_name}"
            " --format junit > reports/quality.xml"
        ],
        artifacts=Artifacts(reports=ArtifactReports(junit="reports/quality.xml")),
    )

    diff_job = Job(
        stage="version",
        needs=["check"],
        script=[
            "uv run turbine ci diff --apply",
            # Push version bumps back to the branch
            "git diff --quiet || ("
            '  git config user.name "CI Bot" &&'
            '  git config user.email "ci@turbine" &&'
            "  git add -A &&"
            '  git commit -m "chore: bump contract versions" &&'
            "  git push https://ci-token:${CI_PUSH_TOKEN}@${CI_SERVER_HOST}/${CI_PROJECT_PATH}.git"
            "    HEAD:${CI_MERGE_REQUEST_SOURCE_BRANCH_NAME}"
            ")",
        ],
    )

    return Pipeline(
        stages=["validate", "quality", "version"],
        common=CommonBlock(),
        lint=lint_job,
        check=check_job,
        diff=diff_job,
    )


class GitLabCIRenderer:
    """ContentRenderer[CIConfig] that produces .gitlab-ci.yml."""

    def render(self, items: Sequence[CIConfig], output_dir: Path) -> Iterable[StagedFile]:
        """Yield one ``.gitlab-ci.yml`` per CIConfig."""
        for item in items:
            pipeline = build_pipeline(item).model_dump(by_alias=True, exclude_none=True)
            yaml = YAML()
            yaml.default_flow_style = False
            buf = StringIO()
            yaml.dump(pipeline, buf)
            yield StagedFile(
                path=output_dir / ".gitlab-ci.yml", content=buf.getvalue(), identifier="gitlab-ci"
            )
