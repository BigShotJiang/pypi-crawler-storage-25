"""Contract YAML renderer for scaffolding."""

from collections.abc import Iterable, Sequence
from pathlib import Path

from turbine.core.codegen import ContractSerializer, NewContractConfig, StagedFile, to_table_name
from turbine.core.common import (
    ColumnDef,
    ContractMetadata,
    ContractStatus,
    DatasetSpec,
    LogicalType,
    SlaConfig,
    SlaProperty,
    TableIdentifier,
)


class ContractRenderer:
    """Render a contract YAML stub by building a skeleton spec and delegating to a serializer."""

    def __init__(self, serializer: ContractSerializer) -> None:
        """Wire up with a serializer that turns a DatasetSpec into YAML."""
        self.serializer = serializer

    def render(self, items: Sequence[NewContractConfig], output_dir: Path) -> Iterable[StagedFile]:
        """Yield one contract YAML per item."""
        for item in items:
            yield StagedFile(
                path=output_dir / f"{item.name}.yml",
                content=self.serializer.render(self.build_skeleton(item)),
                identifier=item.name,
            )

    def build_skeleton(self, item: NewContractConfig) -> DatasetSpec:
        """Build a minimal spec with placeholder columns and an SLA stub.

        The SLA is prefilled with ``latency`` pointing at the ``created_at``
        column so the scaffold passes SLA time-column linting out of the
        box; users can edit the value, unit, or element as needed. ``name``
        and ``description.purpose`` are populated with placeholders because
        the ODCS schema (with Turbine's extensions) now requires both at
        the contract root; ``description.usage`` is also included so the
        UsageRecommendedRule does not nudge on a freshly scaffolded file.
        """
        table = TableIdentifier(schema="public", table=to_table_name(item.name))
        skeleton_columns = (
            ColumnDef(
                name="id", logical_type=LogicalType.INTEGER, nullable=False, primary_key=True, position=0
            ),
            ColumnDef(
                name="name",
                logical_type=LogicalType.STRING,
                nullable=True,
                primary_key=False,
                position=1,
            ),
            ColumnDef(
                name="created_at",
                logical_type=LogicalType.TIMESTAMP,
                nullable=False,
                primary_key=False,
                position=2,
            ),
        )
        latency = SlaProperty(
            property="latency",
            value=24.0,
            unit="hour",
            element=f"{table.schema}.{table.table}.created_at",
        )
        return DatasetSpec(
            table=table,
            columns=skeleton_columns,
            checks=(),
            sla=SlaConfig(properties=(latency,)),
            metadata=ContractMetadata(
                contract_id=item.name,
                version="0.1.0",
                status=ContractStatus.DRAFT,
                source_format="odcs",
                source_path=Path(f"{item.name}.yml"),
                domain=item.name,
                name=item.name,
                description_purpose=f"Describe why the {item.name} contract exists.",
                description_usage=f"Describe how downstream consumers should read {item.name}.",
            ),
        )
