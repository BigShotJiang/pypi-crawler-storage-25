"""FilesystemOrphanSweeper: delete generated files no longer backed by a contract.

Implements the :class:`turbine.core.codegen.OrphanSweeper` Protocol and
runs once per step after flush. Any ``.py`` file in the directory that
isn't in the kept set (the filenames produced during the run) is
removed, which keeps the generated output in lockstep with the
contracts.
"""

from pathlib import Path


class FilesystemOrphanSweeper:
    """Delete ``.py`` files in a directory that are not in the kept set."""

    def prune(self, directory: Path, kept: frozenset[str]) -> tuple[Path, ...]:
        """Remove orphaned ``.py`` files, return the paths of deleted files."""
        removed: list[Path] = []
        for path in sorted(directory.glob("*.py")):
            if path.name in kept:
                continue
            path.unlink()
            removed.append(path)
        return tuple(removed)

    def prune_empty_subdirs(self, root: Path) -> tuple[Path, ...]:
        """Remove every empty subdirectory under *root*, bottom-up.

        Walks the tree from leaves up so a chain of newly-empty parents
        all get removed in one pass. *root* itself is never deleted —
        codegen consumers expect the output root to remain so subsequent
        runs don't have to recreate it.
        """
        if not root.exists():
            return ()
        removed: list[Path] = []
        for path in sorted(root.rglob("*"), key=lambda entry: len(entry.parts), reverse=True):
            if path == root or not path.is_dir():
                continue
            if not any(path.iterdir()):
                path.rmdir()
                removed.append(path)
        return tuple(removed)
