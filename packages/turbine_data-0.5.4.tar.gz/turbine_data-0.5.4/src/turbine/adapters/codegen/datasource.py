"""Datasource YAML renderer for scaffolding."""

from collections.abc import Iterable, Sequence
from enum import StrEnum
from io import StringIO
from pathlib import Path

from ruamel.yaml import YAML
from ruamel.yaml.comments import CommentedMap

from turbine.core.codegen import NewDatasourceConfig, StagedFile
from turbine.core.common import DataSourceType
from turbine.core.common.connection_props import CONNECTION_PROPS_BY_TYPE, env_vars, scaffold_value


class DatasourceYamlKey(StrEnum):
    """Top-level keys in a scaffolded datasource YAML document."""

    NAME = "name"
    TYPE = "type"
    CONNECTION = "connection"


class DatasourceRenderer:
    """Render datasource YAML config with env var placeholders."""

    def render(self, items: Sequence[NewDatasourceConfig], output_dir: Path) -> Iterable[StagedFile]:
        """Yield one datasource YAML per item."""
        for item in items:
            yield StagedFile(
                path=output_dir / f"{item.name}.yml",
                content=self.render_yaml(item),
                identifier=item.name,
            )

    def render_yaml(self, item: NewDatasourceConfig) -> str:
        """Produce a YAML string for a datasource config."""
        props_cls = CONNECTION_PROPS_BY_TYPE[item.db_type]
        doc = CommentedMap()
        doc[DatasourceYamlKey.NAME.value] = item.name
        doc[DatasourceYamlKey.TYPE.value] = item.db_type.value
        conn = CommentedMap()
        for field_name, field_info in props_cls.model_fields.items():
            yaml_key = field_info.alias or field_name
            conn[yaml_key] = scaffold_value(props_cls, field_name)
        doc[DatasourceYamlKey.CONNECTION.value] = conn

        yaml = YAML()
        yaml.default_flow_style = False
        stream = StringIO()
        yaml.dump(doc, stream)
        return stream.getvalue()

    def env_vars(self, db_type: DataSourceType) -> list[str]:
        """Return env var names needed for this datasource type."""
        return env_vars(CONNECTION_PROPS_BY_TYPE[db_type])
