"""Analysis adapters — text-edit writers used by LSP and CLI analysis flows."""

from .file_code_writer import FileCodeWriter, apply_text_edits, expand_snippet_tabstops

__all__ = ["FileCodeWriter", "apply_text_edits", "expand_snippet_tabstops"]
