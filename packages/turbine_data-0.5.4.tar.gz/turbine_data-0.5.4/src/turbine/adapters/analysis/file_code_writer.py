"""FileCodeWriter: apply :class:`FileEdits` bundles to files on disk.

Implementation of the :class:`turbine.core.analysis.CodeWriter`
Protocol for CLI-style analysis flows that mutate existing files
directly (add-check, rename, etc.). Distinct from the codegen
pipeline's :class:`turbine.core.codegen.StagedCodeWriter`, which
stages whole files before atomic flush.

Resolves each bundle's ``uri`` via :func:`urllib.parse.urlparse`, reads
the current content, applies every edit in memory, and writes the new
content back. ``urlparse`` is used over :meth:`pathlib.Path.from_uri`
because the latter requires Python 3.13 and we support 3.12 onward.
"""

import re
from collections.abc import Iterable
from pathlib import Path
from urllib.parse import unquote, urlparse

from turbine.core.analysis.ports import CodeWriteError
from turbine.core.common.file_edits import FileEdits, SnippetInsertion, TextEditInfo, TextRange

SNIPPET_TABSTOP_RE = re.compile(r"\$\{\d+:((?:\\.|[^}])*)\}")
SNIPPET_ESCAPE_RE = re.compile(r"\\(.)")


def apply_text_edits(content: str, edits: Iterable[TextEditInfo]) -> str:
    """Apply a sequence of text edits to *content* and return the result.

    Edits are applied from the bottom of the document upward so that
    later positions are not invalidated by earlier ones. Positions are
    1-indexed ``(line, col)`` pairs. A column of ``1`` always means
    "start of the line"; ranges with start_col == end_col == 1 describe
    a half-open span of whole lines. A line one past the last line
    (with ``col == 1``) resolves to ``len(content)``, so ranges ending
    at "start of the line after EOF" correctly span to the end of the
    document.
    """
    line_starts = [0, *(index + 1 for index, char in enumerate(content) if char == "\n")]

    def offset_of(line: int, col: int) -> int:
        if line - 1 >= len(line_starts):
            return len(content)
        return line_starts[line - 1] + col - 1

    bottom_up_edits = sorted(
        edits, key=lambda edit: (edit.range.start_line, edit.range.start_col), reverse=True
    )
    result = content
    for edit in bottom_up_edits:
        start = offset_of(edit.range.start_line, edit.range.start_col)
        end = offset_of(edit.range.end_line, edit.range.end_col)
        result = result[:start] + edit.new_text + result[end:]
    return result


class FileCodeWriter:
    """Applies :class:`FileEdits` bundles to on-disk files."""

    async def write(self, edits: Iterable[FileEdits]) -> None:
        for bundle in edits:
            if not bundle.edits:
                continue
            path = self.resolve_path(bundle.uri)
            if not path.exists():
                raise CodeWriteError(f"file does not exist: {path}")
            current_content = path.read_text()
            new_content = apply_text_edits(current_content, bundle.edits)
            if new_content != current_content:
                path.write_text(new_content)

    async def insert_snippet(self, insertion: SnippetInsertion) -> None:
        """Insert a snippet into an on-disk file after expanding tabstops."""
        edit = TextEditInfo(
            range=TextRange(
                start_line=insertion.position.line,
                start_col=insertion.position.col,
                end_line=insertion.position.line,
                end_col=insertion.position.col,
            ),
            new_text=expand_snippet_tabstops(insertion.snippet_text),
        )
        await self.write((FileEdits(uri=insertion.uri, edits=(edit,)),))

    @staticmethod
    def resolve_path(uri: str) -> Path:
        parsed = urlparse(uri)
        if parsed.scheme != "file":
            raise CodeWriteError(f"unsupported URI scheme: {uri}")
        return Path(unquote(parsed.path))


def expand_snippet_tabstops(snippet_text: str) -> str:
    """Replace `${N:placeholder}` snippet markers with their unescaped default text."""
    return SNIPPET_TABSTOP_RE.sub(
        lambda match: SNIPPET_ESCAPE_RE.sub(r"\1", match.group(1)), snippet_text
    )
