"""Shared filesystem write helper used by codegen and analysis adapters.

``write_if_changed`` writes content to a path only when it differs from
what is already on disk, reporting a :class:`SyncStatus` so callers can
summarise what happened without diffing afterwards.
"""

from pathlib import Path

from turbine.core.common.file_sync import SyncStatus


def write_if_changed(path: Path, content: str) -> SyncStatus:
    """Write *content* to *path*, returning whether anything changed.

    Creates missing parent directories. Returns ``UNCHANGED`` when the
    file already holds *content* byte-for-byte, avoiding a needless
    write.
    """
    if not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(content)
        return SyncStatus.CREATED
    if path.read_text() == content:
        return SyncStatus.UNCHANGED
    path.write_text(content)
    return SyncStatus.UPDATED
