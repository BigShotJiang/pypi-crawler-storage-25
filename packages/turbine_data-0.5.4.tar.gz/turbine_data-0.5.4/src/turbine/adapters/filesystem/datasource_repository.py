"""Filesystem-backed datasource repository.

Reads datasource YAML files from a directory and parses them
into DatasourceConfig instances. Supports ``${env.VAR}`` syntax
for environment variable expansion in connection values.
"""

import os
from collections.abc import Mapping
from pathlib import Path

from loguru import logger

from turbine.core.building_blocks import DiagnosticBuilder, DiagnosticId, DiagnosticSink, TurbineError
from turbine.core.common import (
    DatasourceConfig,
    DatasourceRepository,
    DuckDBConnectionProps,
    SourceParser,
)

from .datasource_model import DatasourceYamlModel

MEMORY_DUCKDB = ":memory:"


def resolve_duckdb_path(config: DatasourceConfig, project_root: Path) -> DatasourceConfig:
    """Rewrite a relative DuckDB ``database`` path so it anchors at *project_root*.

    DuckDB uses a filesystem path instead of a hostname, so the author's
    ``data/orders.duckdb`` must resolve against the project root — not the
    Python process CWD, which is wherever the LSP or CLI happens to launch
    from. ``:memory:`` and absolute paths pass through unchanged.
    """
    if not isinstance(config.connection, DuckDBConnectionProps):
        return config
    database = config.connection.database
    if database == MEMORY_DUCKDB:
        return config
    database_path = Path(database)
    if database_path.is_absolute():
        return config
    absolute = (project_root / database_path).resolve()
    rebased = config.connection.model_copy(update={"database": str(absolute)})
    return config.model_copy(update={"connection": rebased})


class FileSystemDatasourceRepository(DatasourceRepository):
    """Load datasource configs from YAML files, expanding ``${env.VAR}`` in connection values."""

    def __init__(
        self,
        directory: Path,
        parser: SourceParser,
        project_root: Path,
        glob_pattern: str | tuple[str, ...] = ("*.yml", "*.yaml"),
        env: Mapping[str, str] | None = None,
    ) -> None:
        """Store the datasources directory, parser, project root, and env mapping."""
        self.directory = directory
        self.project_root = project_root
        self.glob_patterns: tuple[str, ...] = (
            (glob_pattern,) if isinstance(glob_pattern, str) else tuple(glob_pattern)
        )
        self.parser = parser
        self.env: Mapping[str, str] = env if env is not None else os.environ

    def list_datasources(self, sink: DiagnosticSink) -> tuple[DatasourceConfig, ...]:
        """Discover all datasource YAML files and parse them."""
        items: list[DatasourceConfig] = []
        matches: set[Path] = set()
        for pattern in self.glob_patterns:
            matches.update(self.directory.glob(pattern))
        for path in sorted(matches):
            if not path.is_file():
                continue
            try:
                items.append(self.parse_file(path))
            except TurbineError as exc:
                sink.extend(exc.diagnostics)
        logger.info(f"Found {len(items)} datasources in {self.directory}")
        return tuple(items)

    def get(self, key: str, sink: DiagnosticSink) -> DatasourceConfig:
        """Look up a datasource by name — parses only the matching file.

        Falls back to a full scan only when no ``{key}.yml`` file exists, so the
        error message can list available datasources.
        """
        candidate = self.directory / f"{key}.yml"
        if candidate.is_file():
            try:
                return self.parse_file(candidate)
            except TurbineError as exc:
                sink.extend(exc.diagnostics)
                raise

        items = self.list_datasources(sink)
        for item in items:
            if item.name == key:
                return item
        available = [i.name for i in items]
        available_text = ", ".join(available) or "none"
        raise (
            DiagnosticBuilder.error(
                DiagnosticId.DATASOURCE_CONFIG_ERROR, f"Datasource '{key}' was not found."
            )
            .help(
                f"Create `datasources/{key}.yml`, or choose one of the existing datasources: "
                f"{available_text}."
            )
            .into_error()
        )

    def parse_file(self, path: Path) -> DatasourceConfig:
        """Parse a single datasource YAML file. Raises TurbineError on failure."""
        try:
            source = self.parser(path)
        except TurbineError as exc:
            original = exc.diagnostics[0] if exc.diagnostics else None
            raise (
                DiagnosticBuilder.error(
                    DiagnosticId.DATASOURCE_CONFIG_ERROR, f"Failed to parse YAML: {path.name}"
                )
                .span(path)
                .help(original.message if original else None)
                .into_error()
            ) from exc

        model = DatasourceYamlModel.from_source(source)
        config = model.to_config(path, source.source_map, self.env)
        return resolve_duckdb_path(config, self.project_root)

    def load_from_path(self, path: Path, sink: DiagnosticSink) -> DatasourceConfig:
        """Port impl — parses a datasource config at *path*, routing errors to *sink*."""
        try:
            return self.parse_file(path)
        except TurbineError as exc:
            sink.extend(exc.diagnostics)
            raise
