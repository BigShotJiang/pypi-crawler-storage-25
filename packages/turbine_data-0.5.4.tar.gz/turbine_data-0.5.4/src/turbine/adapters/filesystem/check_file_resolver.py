"""Resolve check file paths from the project filesystem layout."""

from pathlib import Path

from turbine.core.common import CheckCategory, CheckDef, PythonCheckConfig, SqlCheckConfig


class FilesystemCheckFileResolver:
    """Resolve expected file paths for SQL and Python checks.

    Both SQL and Python checks resolve from ``checks_dir``.
    SQL checks use ``{checks_dir}/{file_path}``.
    Python checks use ``{checks_dir}/{function_ref}.py``.
    Other check types (metric, template, schema) have no files to resolve.
    """

    def __init__(self, project_root: Path, checks_dir: Path) -> None:
        """Store the project root and checks directory for resolving check file paths."""
        self.project_root = project_root
        self.checks_dir = checks_dir

    def resolve_path(self, check: CheckDef) -> Path | None:
        """Return the expected file path, or None if this check type has no file."""
        if check.category == CheckCategory.SQL and isinstance(check.config, SqlCheckConfig):
            if check.config.query or check.config.predicate:
                return None  # inline SQL (full query or wrapped predicate) has no file
            return self.checks_dir / check.config.file_path
        if check.category == CheckCategory.PYTHON and isinstance(check.config, PythonCheckConfig):
            if "." in check.config.function_ref:
                return None  # dotted imports resolve via sys.path
            return self.checks_dir / f"{check.config.function_ref}.py"
        return None
