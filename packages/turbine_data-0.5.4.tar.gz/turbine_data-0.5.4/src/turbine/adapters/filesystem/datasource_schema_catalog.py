"""Datasource JSON Schema loader — used by the completion walker and validator."""

import json
from functools import cache
from importlib.resources import files

from turbine.core.common import SchemaNode


@cache
def load_datasource_schema() -> SchemaNode:
    """Load ``datasource.schema.json`` from the package and cache it."""
    schema_dir = files("turbine.adapters.filesystem.schemas")
    schema_text = (schema_dir / "datasource.schema.json").read_text()
    return json.loads(schema_text)
