"""Datasource format descriptor — wires the JSON schema into the FormatRegistry.

Datasources get the same treatment as ODCS contracts and QualitySpecs: the
registry exposes a ``FormatDescriptor`` so completion (via ``SchemaNavigator``)
and validation (via ``Draft201909Validator``) both drive off the same schema.
"""

from turbine.adapters.filesystem.datasource_schema_catalog import load_datasource_schema
from turbine.core.building_blocks import noop_display_context, noop_valid_fields
from turbine.core.common import FormatLabel
from turbine.core.contract import FormatDescriptor

DATASOURCE_DESCRIPTOR = FormatDescriptor(
    format_label=FormatLabel.DATASOURCE,
    schema_loader=load_datasource_schema,
    display_context_fn=noop_display_context,
    valid_fields_fn=noop_valid_fields,
)
