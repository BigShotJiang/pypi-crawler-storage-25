"""Datasource format reader — routes datasource YAMLs through the format registry.

Datasources aren't contracts — they produce ``DatasourceConfig``, not
``DatasetSpec`` — but the registry is still the right home for their
schema-aware plumbing: ``can_read`` catches any YAML with ``type:`` and no
``kind:``, ``read`` runs the JSON-schema validator for the diagnostic path,
and completion pulls child fields off the same descriptor.

The loader that actually builds a live ``DatasourceConfig`` (with env vars
expanded) still lives in ``FileSystemDatasourceRepository`` — this reader is
purely the validation + completion entry point.
"""

from typing import Any

from turbine.core.building_blocks import DiagnosticSink
from turbine.core.common import DatasetSpec, FormatLabel, RawSource, SchemaValidator


class DatasourceReader:
    """FormatReader for datasource YAML files.

    Only validates — the registry expects a tuple of ``DatasetSpec``, and
    datasources never produce any, so ``read`` always returns ``()``. The
    diagnostics from schema validation flow into the caller's sink.
    """

    format_label = FormatLabel.DATASOURCE.value

    def __init__(self, schema_validator: SchemaValidator) -> None:
        """Store the JSON-schema validator built from the datasource descriptor."""
        self.schema_validator = schema_validator

    def can_read(self, data: dict[str, Any]) -> bool:
        """Match any YAML that looks like a datasource — has ``type`` and no ``kind``."""
        return "type" in data and "kind" not in data

    def read(self, source: RawSource, sink: DiagnosticSink) -> tuple[DatasetSpec, ...]:
        """Validate the datasource YAML and return an empty tuple (no ``DatasetSpec``)."""
        self.schema_validator.validate(source.data, source, sink)
        return ()
