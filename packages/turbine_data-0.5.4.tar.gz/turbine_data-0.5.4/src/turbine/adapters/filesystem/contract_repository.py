"""Filesystem-backed contract repository.

Discovers contract YAML files under a directory, parses them into
``RawSource``, and resolves references by file path or contract ID.
"""

from pathlib import Path

from loguru import logger

from turbine.core.building_blocks import (
    DiagnosticBuilder,
    DiagnosticId,
    DiagnosticSink,
    NullDiagnosticSink,
    TurbineError,
)
from turbine.core.common import FIELD_ID, RawSource, SourceParser
from turbine.core.contract import ContractLocation


class FileSystemContractRepository:
    """Load contract YAML files from a directory, resolve by file path or contract ID."""

    def __init__(
        self,
        contracts_dir: Path,
        parser: SourceParser,
        glob_pattern: str | tuple[str, ...] = ("**/*.yml", "**/*.yaml"),
        extra_dirs: list[Path] | None = None,
        *,
        required: bool = True,
    ) -> None:
        """Store the contracts directory, parser, glob patterns, and optional extra directories.

        ``required=False`` tolerates a missing directory (the optional
        ``quality/`` tree, for instance, is frequently absent); discovery
        over it simply yields nothing instead of raising.
        """
        if required and not contracts_dir.is_dir():
            raise (
                DiagnosticBuilder.error(
                    DiagnosticId.CONTRACT_PARSE_ERROR,
                    f"Contracts directory does not exist: {contracts_dir}",
                ).into_error()
            )
        self.contracts_dir = contracts_dir.resolve()
        self.glob_patterns: tuple[str, ...] = (
            (glob_pattern,) if isinstance(glob_pattern, str) else tuple(glob_pattern)
        )
        self.parser = parser
        self.extra_dirs = [d.resolve() for d in (extra_dirs or []) if d.is_dir()]
        self.cached_locations: tuple[ContractLocation, ...] | None = None

    def load(self, path: Path) -> RawSource:
        """Parse a YAML file into a RawSource."""
        return self.parser(path)

    def list_contracts(
        self, sink: DiagnosticSink = NullDiagnosticSink()
    ) -> tuple[ContractLocation, ...]:
        """Glob for contract files in all directories, parse their IDs, and cache the result."""
        if self.cached_locations is not None:
            return self.cached_locations
        locations: list[ContractLocation] = []
        for search_dir in [self.contracts_dir, *self.extra_dirs]:
            logger.debug(f"Searching {search_dir} with patterns={self.glob_patterns}")
            matches: set[Path] = set()
            for pattern in self.glob_patterns:
                matches.update(search_dir.rglob(pattern))
            for path in sorted(matches):
                if not path.is_file():
                    continue
                if (loc := self.try_parse_contract(path, sink)) is not None:
                    locations.append(loc)
        logger.info(f"Found {len(locations)} contracts across {1 + len(self.extra_dirs)} directories")
        result = tuple(locations)
        self.cached_locations = result
        return result

    def try_parse_contract(self, path: Path, sink: DiagnosticSink) -> ContractLocation | None:
        """Try to parse a single contract file. Returns None on failure."""
        try:
            source = self.parser(path)
        except TurbineError as exc:
            self.emit_parse_warning(path, exc, sink)
            return None
        raw_id = source.data.get(FIELD_ID)
        contract_id = raw_id if isinstance(raw_id, str) and raw_id else path.stem
        logger.debug(f"Discovered contract: {path}")
        return ContractLocation(contract_id=contract_id, path=path)

    @staticmethod
    def emit_parse_warning(path: Path, exc: TurbineError, sink: DiagnosticSink) -> None:
        """Emit a warning diagnostic for a file that failed to parse."""
        original = exc.diagnostics[0] if exc.diagnostics else None
        original_span = original.annotations[0].span if original and original.annotations else None
        builder = DiagnosticBuilder.warning(
            DiagnosticId.CONTRACT_PARSE_ERROR, f"Skipping {path.name}: failed to parse"
        )
        if original_span is not None:
            builder.annotate(original_span)
        else:
            builder.span(path)
        builder.help(original.message if original else None)
        sink.add(builder.build())
        logger.debug(f"Skipping unparseable contract: {path}")

    def resolve(self, ref: str) -> RawSource:
        """Look up *ref* as a file path first, then as a contract ID."""
        if path := self.resolve_path(ref):
            return self.load(path)
        return self.resolve_by_id(ref)

    def resolve_path(self, ref: str) -> Path | None:
        """Try to interpret *ref* as a file path. Returns None if not found or outside contracts dir."""
        absolute = Path(ref)
        if absolute.is_absolute() and absolute.is_file():
            if not absolute.resolve().is_relative_to(self.contracts_dir.resolve()):
                return None
            return absolute
        relative = self.contracts_dir / ref
        if not relative.resolve().is_relative_to(self.contracts_dir.resolve()):
            return None
        if relative.is_file():
            return relative
        return None

    def resolve_by_id(self, contract_id: str) -> RawSource:
        """Search discovered contracts for a matching ID."""
        locations = self.list_contracts()
        for location in locations:
            if location.contract_id == contract_id:
                return self.load(location.path)
        raise (
            DiagnosticBuilder.error(
                DiagnosticId.CONTRACT_PARSE_ERROR,
                f"Contract not found: '{contract_id}' is not a valid path or known contract ID",
            )
            .help(f"available contracts: {', '.join(loc.contract_id for loc in locations)}")
            .into_error()
        )
