"""Pydantic model for datasource YAML files."""

import os
import re
from collections.abc import Mapping
from pathlib import Path
from typing import Self, cast

from pydantic import BaseModel, ConfigDict, Field, ValidationError
from pydantic_core import ErrorDetails

from turbine.core.building_blocks import (
    Diagnostic,
    DiagnosticBuilder,
    DiagnosticData,
    DiagnosticId,
    DiagnosticKind,
    SourceMap,
    TurbineError,
)
from turbine.core.common import (
    CONNECTION_PROPS_BY_TYPE,
    ConnectionProps,
    DatasourceConfig,
    DataSourceType,
    RawSource,
)

ENV_VAR_PATTERN = re.compile(r"\$\{\s*(?:env\.)?([a-zA-Z_]\w*)\s*\}")


class DatasourceYamlModel(BaseModel):
    """Validates and deserializes a datasource YAML file.

    Connection-string fields (``host``, ``port``, ``database``, …) belong
    inside the ``connection:`` block. ``extra="forbid"`` rejects them at
    the top level instead of silently dropping them and falling back to
    defaults, which previously produced confusing auth errors at runtime.
    """

    model_config = ConfigDict(frozen=True, extra="forbid")

    name: str | None = None
    type: DataSourceType
    connection: dict[str, str | int | float | bool] = Field(default_factory=dict)

    @classmethod
    def from_source(cls, source: RawSource) -> Self:
        """Parse a RawSource into a validated model. Raises TurbineError on failure."""
        try:
            return cls.model_validate(source.data)
        except ValidationError as exc:
            error = exc.errors()[0]
            field = str(error["loc"][-1]) if error["loc"] else "root"
            message = error["msg"]
            if error["type"] == "extra_forbidden":
                message = (
                    f"unexpected top-level field `{field}` — connection-string "
                    "fields belong inside `connection:`"
                )
            raise (
                DiagnosticBuilder.error(
                    DiagnosticId.DATASOURCE_CONFIG_ERROR,
                    f"invalid datasource config in {source.path.name}: {message}",
                )
                .span(source.path, source.source_map.range_for_value(field))
                .into_error()
            ) from exc

    def to_config(
        self, path: Path, source_map: SourceMap, env: Mapping[str, str] | None = None
    ) -> DatasourceConfig:
        """Build a fully resolved DatasourceConfig with env vars expanded and props validated."""
        expanded = expand_env_vars(self.connection, path, source_map, env)
        props = validate_connection_props(self.type, expanded, path, source_map)
        return DatasourceConfig(
            name=self.name or path.stem, ds_type=self.type, connection=props, source_path=path
        )


def expand_env_vars(
    connection: dict[str, str | int | float | bool],
    path: Path,
    source_map: SourceMap,
    env: Mapping[str, str] | None = None,
) -> dict[str, str | int | float | bool]:
    """Expand ``${env.VAR}`` and ``${VAR}`` references in connection string values."""
    resolved_env = env or os.environ
    return {
        key: resolve_env_string(value, key, path, source_map, resolved_env)
        if isinstance(value, str) and "${" in value
        else value
        for key, value in connection.items()
    }


def resolve_env_string(
    value: str, field: str, path: Path, source_map: SourceMap, env: Mapping[str, str]
) -> str:
    """Replace all ``${env.VAR}`` and ``${VAR}`` occurrences with env values."""
    missing: list[str] = []

    def replacer(match: re.Match[str]) -> str:
        """Return the env value for the matched variable, or collect it as missing."""
        var_name = match.group(1)
        if (env_value := env.get(var_name)) is not None:
            return env_value
        missing.append(var_name)
        return match.group(0)

    expanded = ENV_VAR_PATTERN.sub(replacer, value)
    if not missing:
        return expanded

    names = ", ".join(missing)
    raise (
        DiagnosticBuilder.error(
            DiagnosticId.DATASOURCE_CONFIG_ERROR,
            f"unset environment variable{'s' if len(missing) > 1 else ''}: {names}",
        )
        .span(path, source_map.range_for_value(f"connection.{field}"))
        .into_error()
    )


def validate_connection_props(
    ds_type: DataSourceType,
    expanded: dict[str, str | int | float | bool],
    path: Path,
    source_map: SourceMap,
) -> ConnectionProps:
    """Validate the env-expanded connection dict against the typed props for ``ds_type``.

    Each pydantic ``ValidationError`` becomes its own span-anchored
    ``Diagnostic`` pointing at the offending connection field, so the
    editor highlights the bad value rather than the whole file.
    """
    props_cls = CONNECTION_PROPS_BY_TYPE[ds_type]
    try:
        return cast("ConnectionProps", props_cls.model_validate(expanded))
    except ValidationError as exc:
        diagnostics = tuple(build_field_diagnostic(error, path, source_map) for error in exc.errors())
        bad_fields = ", ".join(d.data.field_name for d in diagnostics if d.data and d.data.field_name)
        summary = (
            f"invalid {ds_type.value} connection — {bad_fields}"
            if bad_fields
            else (f"invalid {ds_type.value} connection")
        )
        raise TurbineError(summary, diagnostics=diagnostics) from exc


def build_field_diagnostic(error: ErrorDetails, path: Path, source_map: SourceMap) -> Diagnostic:
    """Convert one pydantic error into a span-anchored Diagnostic."""
    location = error.get("loc", ())
    field = str(location[-1]) if location else ""
    message = error.get("msg", "validation error")
    return (
        DiagnosticBuilder.error(
            DiagnosticId.DATASOURCE_CONFIG_ERROR,
            f"invalid value for `{field}`: {message}" if field else message,
        )
        .span(path, source_map.range_for_value(f"connection.{field}") if field else None)
        .data(DiagnosticData(kind=DiagnosticKind.TYPE_MISMATCH, field_name=field or None))
        .build()
    )
