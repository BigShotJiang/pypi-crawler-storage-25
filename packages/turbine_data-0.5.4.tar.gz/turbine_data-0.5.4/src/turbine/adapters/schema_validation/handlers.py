"""Generic JSON Schema error-to-diagnostic handlers (jsonschema-rs backend).

Each jsonschema_rs ValidationError is translated into a Diagnostic with:
- a source span pointing to the YAML line/column where the error occurred
- a context label (via injectable display_context_fn)
- a help suggestion (e.g. 'did you mean `status`?')
"""

import heapq
from collections.abc import Iterable, Sequence
from dataclasses import replace
from difflib import get_close_matches
from typing import Any

from jsonschema_rs import ValidationError

from turbine.core.building_blocks import (
    Diagnostic,
    DiagnosticBuilder,
    DiagnosticData,
    DiagnosticId,
    DiagnosticKind,
    DisplayContextFn,
    SchemaKey,
    Span,
    ValidFieldsFn,
    noop_display_context,
    noop_valid_fields,
    resolve_fallback_range,
)
from turbine.core.common import RawSource

SUGGEST_CUTOFF = 0.5

WEAK_VALIDATORS = frozenset({"anyOf", "oneOf"})


def error_to_diagnostics(  # noqa: PLR0911, PLR0913
    error: ValidationError,
    source: RawSource,
    data: dict[str, Any],
    *,
    display_context_fn: DisplayContextFn = noop_display_context,
    valid_fields_fn: ValidFieldsFn = noop_valid_fields,
    root_schema: dict[str, Any] | None = None,
) -> list[Diagnostic]:
    """Route a ValidationError to a type-specific handler that produces Diagnostics."""
    match error.kind.name:
        case "required":
            return [handle_required(error, source, data, display_context_fn=display_context_fn)]
        case "additionalProperties" | "unevaluatedProperties":
            return handle_unknown_properties(
                error,
                source,
                data,
                valid_fields=valid_fields_fn(list(error.instance_path)),
                display_context_fn=display_context_fn,
            )
        case "enum":
            return [handle_enum(error, source, data, display_context_fn=display_context_fn)]
        case "type":
            return [handle_type(error, source, data, display_context_fn=display_context_fn)]
        case "pattern":
            return [
                handle_pattern(
                    error, source, data, display_context_fn=display_context_fn, root_schema=root_schema
                )
            ]
        case "oneOf" | "anyOf":
            return handle_schema_composition(
                error,
                source,
                data,
                display_context_fn=display_context_fn,
                valid_fields_fn=valid_fields_fn,
                root_schema=root_schema,
            )
        case _:
            return [handle_generic(error, source, data, display_context_fn=display_context_fn)]


def format_with_context(
    base_msg: str,
    data: dict[str, Any],
    path: Sequence[str | int],
    *,
    display_context_fn: DisplayContextFn = noop_display_context,
) -> str:
    """Append context (e.g. 'in property `age` of `users`') to a message if available."""
    display_ctx = display_context_fn(data, path)
    return f"{base_msg} in {display_ctx}" if display_ctx else base_msg


def resolve_error_span(
    error: ValidationError, source: RawSource, *, is_key_error: bool, extra_path: str | None = None
) -> Span:
    """Map a validation error to its YAML source location.

    When the primary resolver finds no match (e.g. ``range_for_value``
    on a key with no value node like ``schema:``), the secondary
    resolver is tried with the same path so the diagnostic still
    anchors at the offending key instead of falling back to the bare
    file path.
    """
    path_parts = [*error.instance_path, extra_path] if extra_path else list(error.instance_path)
    dotted = path_to_dotted(path_parts)
    if not dotted:
        return Span(path=source.path, range=None)
    primary = source.source_map.range_for_key if is_key_error else source.source_map.range_for_value
    secondary = source.source_map.range_for_value if is_key_error else source.source_map.range_for_key
    text_range = primary(dotted) or secondary(dotted) or resolve_fallback_range(dotted, primary)
    return Span(path=source.path, range=text_range)


def build_validation(msg: str, span: Span, *, help_text: str | None = None) -> Diagnostic:
    """Create a VALIDATION-level error Diagnostic with a source annotation and optional help text.

    The annotation is always attached so the renderer can print the file path
    even when the source map could not resolve a precise text range (e.g. an
    empty YAML value). Renderers handle ``range=None`` by omitting line/col.
    """
    builder = DiagnosticBuilder.error(DiagnosticId.VALIDATION, msg).annotate(span).label(msg)
    builder.help(help_text)
    return builder.build()


def error_field_name(error: ValidationError) -> str:
    """Return the last segment of an error's path as a field name, or 'root' for top-level errors."""
    path = list(error.instance_path)
    return str(path[-1]) if path else "root"


def build_simple_diagnostic(  # noqa: PLR0913 — six args is the minimal payload for a simple diagnostic
    error: ValidationError,
    source: RawSource,
    data: dict[str, Any],
    msg_template: str,
    *,
    display_context_fn: DisplayContextFn = noop_display_context,
    help_text: str | None = None,
) -> Diagnostic:
    """Shared prologue for simple validation handlers: get field name, format msg, resolve span."""
    field_name = error_field_name(error)
    msg = format_with_context(
        msg_template.format(field=field_name, error=error),
        data,
        list(error.instance_path),
        display_context_fn=display_context_fn,
    )
    span = resolve_error_span(error, source, is_key_error=False)
    return build_validation(msg, span, help_text=help_text)


def handle_required(
    error: ValidationError,
    source: RawSource,
    data: dict[str, Any],
    *,
    display_context_fn: DisplayContextFn = noop_display_context,
) -> Diagnostic:
    """Create a diagnostic for a missing required field, with help text suggesting to add it.

    Anchors the span at the parent object that's missing the field (so the
    user sees ``- type: custom`` rather than the enclosing list's key) by
    falling back through ``range_for_value`` when the key-based resolver
    doesn't have a row for an array-index parent.
    """
    field_name = str(error.kind.value)
    msg = format_with_context(
        f"missing required field `{field_name}`",
        data,
        list(error.instance_path),
        display_context_fn=display_context_fn,
    )
    span = resolve_missing_field_span(error, source)
    diagnostic = build_validation(msg, span, help_text=f"add `{field_name}` to the YAML")
    diag_data = DiagnosticData(
        kind=DiagnosticKind.MISSING_REQUIRED_FIELD,
        field_name=field_name,
        parent_path=path_to_dotted(list(error.instance_path)),
    )
    return replace(diagnostic, data=diag_data)


def resolve_missing_field_span(error: ValidationError, source: RawSource) -> Span:
    """Anchor a missing-required-field error at the offending parent object.

    Tries the value-based resolver first (so an array-element parent like
    ``quality.5`` maps onto its block range), then falls back to the
    standard key-based resolution if that's all the source map has.
    Root-level errors (empty ``instance_path``) anchor at the document's
    first top-level key so the diagnostic always has a real line/col.
    """
    parent_path = path_to_dotted(list(error.instance_path))
    if parent_path and (value_range := source.source_map.range_for_value(parent_path)) is not None:
        return Span(path=source.path, range=value_range)
    span = resolve_error_span(error, source, is_key_error=True)
    if span.range is not None:
        return span
    root_range = source.source_map.range_for_document_root()
    if root_range is not None:
        return Span(path=source.path, range=root_range)
    return span


def handle_unknown_properties(
    error: ValidationError,
    source: RawSource,
    data: dict[str, Any],
    valid_fields: list[str],
    *,
    display_context_fn: DisplayContextFn = noop_display_context,
) -> list[Diagnostic]:
    """Create one diagnostic per unexpected field name.

    Uses error.kind.unexpected (list of property names) directly from the
    Rust validator instead of parsing the error message string.
    """
    unexpected = list(getattr(error.kind, "unexpected", ()) or ())
    if not unexpected:
        return [handle_generic(error, source, data, display_context_fn=display_context_fn)]

    diagnostics: list[Diagnostic] = []
    display_ctx = display_context_fn(data, list(error.instance_path))

    for prop_name in unexpected:
        if is_regex_pattern(prop_name):
            continue
        span = resolve_error_span(error, source, is_key_error=True, extra_path=prop_name)
        base_msg = f"unknown field `{prop_name}`"
        msg = f"{base_msg} in {display_ctx}" if display_ctx else base_msg
        builder = DiagnosticBuilder.error(DiagnosticId.VALIDATION, msg)
        if span.range:
            builder.annotate(span).label(msg)
        builder.suggest(prop_name, valid_fields, fallback="remove it or check spelling")
        matches = get_close_matches(prop_name, valid_fields, n=1, cutoff=SUGGEST_CUTOFF)
        diag_data = DiagnosticData(
            kind=DiagnosticKind.UNKNOWN_FIELD,
            field_name=prop_name,
            suggested_value=matches[0] if matches else None,
        )
        diagnostics.append(replace(builder.build(), data=diag_data))

    return diagnostics


def handle_enum(
    error: ValidationError,
    source: RawSource,
    data: dict[str, Any],
    *,
    display_context_fn: DisplayContextFn = noop_display_context,
) -> Diagnostic:
    """Create a diagnostic listing the allowed enum values and suggesting the closest match."""
    field_name = error_field_name(error)
    enum_values = [str(v) for v in (getattr(error.kind, "options", None) or [])]
    allowed = ", ".join(f"`{v}`" for v in enum_values)
    got = str(error.instance)
    msg = format_with_context(
        f"Field `{field_name}` needs one of {allowed}, but got `{got}`.",
        data,
        list(error.instance_path),
        display_context_fn=display_context_fn,
    )
    span = resolve_error_span(error, source, is_key_error=False)
    builder = DiagnosticBuilder.error(DiagnosticId.VALIDATION, msg)
    if span.range:
        builder.annotate(span).label(msg)
    builder.suggest(got, enum_values)
    matches = get_close_matches(got, enum_values, n=1, cutoff=SUGGEST_CUTOFF)
    diag_data = DiagnosticData(
        kind=DiagnosticKind.INVALID_ENUM,
        field_name=field_name,
        suggested_value=matches[0] if matches else None,
    )
    return replace(builder.build(), data=diag_data)


def handle_pattern(
    error: ValidationError,
    source: RawSource,
    data: dict[str, Any],
    *,
    display_context_fn: DisplayContextFn = noop_display_context,
    root_schema: dict[str, Any] | None = None,
) -> Diagnostic:
    """Create a diagnostic for a pattern (regex) mismatch.

    The raw regex is noise to the user; the schema's ``description`` is
    expected to carry human-readable guidance (what shape is required,
    with examples) — surface that as help text instead.
    """
    field_name = error_field_name(error)
    msg = format_with_context(
        f"`{error.instance}` is not a valid `{field_name}`",
        data,
        list(error.instance_path),
        display_context_fn=display_context_fn,
    )
    span = resolve_error_span(error, source, is_key_error=False)
    description = lookup_schema_description(root_schema, list(error.schema_path)) if root_schema else ""
    help_text = description or f"value must match the expected `{field_name}` format"
    return build_validation(msg, span, help_text=help_text)


def handle_type(
    error: ValidationError,
    source: RawSource,
    data: dict[str, Any],
    *,
    display_context_fn: DisplayContextFn = noop_display_context,
) -> Diagnostic:
    """Create a diagnostic reporting a type mismatch in plain language.

    Adds a focused hint when a ``mustBe*`` operator received a date/timestamp
    string: thresholds are numeric only, and the right tool for date freshness
    is ``check: freshness`` with an SLA-resolved time column.
    """
    field_name = error_field_name(error)
    types = getattr(error.kind, "types", None) or []
    expected = readable_expected_types(types)
    got = readable_instance_type(error.instance)
    field_str = str(field_name)
    msg = f"Field `{field_str}` needs {expected}, but got {got}."
    if error.instance is None:
        msg = f"Field `{field_str}` needs {expected}, but it is empty."
    if (
        field_str.startswith("mustBe")
        and isinstance(error.instance, str)
        and looks_like_date_string(error.instance)
    ):
        return build_simple_diagnostic(
            error,
            source,
            data,
            msg,
            display_context_fn=display_context_fn,
            help_text=(
                "Thresholds need numbers. To check whether timestamps are recent, use "
                "`check: freshness` and set `slaProperties.latency.element` to the timestamp column."
            ),
        )
    help_text = "Add a value or remove the field." if error.instance is None else None
    return build_simple_diagnostic(
        error, source, data, msg, display_context_fn=display_context_fn, help_text=help_text
    )


READABLE_JSON_TYPES: dict[str, str] = {
    "array": "a list",
    "boolean": "true or false",
    "integer": "a whole number",
    "number": "a number",
    "object": "a group of fields",
    "string": "text",
}


def readable_expected_types(types: Sequence[str]) -> str:
    """Return a plain-language type requirement."""
    if not types:
        return "a valid value"
    readable = [READABLE_JSON_TYPES.get(type_name, type_name) for type_name in types]
    if len(readable) == 1:
        return readable[0]
    return f"{', '.join(readable[:-1])}, or {readable[-1]}"


def readable_instance_type(value: object) -> str:
    """Return a plain-language type for the supplied value."""
    if value is None:
        return "an empty value"
    type_labels: tuple[tuple[type[object], str], ...] = (
        (bool, "true or false"),
        (int, "a number"),
        (float, "a number"),
        (str, "text"),
        (list, "a list"),
        (dict, "a group of fields"),
    )
    return next(
        (label for value_type, label in type_labels if isinstance(value, value_type)),
        type(value).__name__,
    )


ISO_DATE_MIN_LENGTH = 8  # YYYY-MM-DD without delimiter padding


def looks_like_date_string(value: str) -> bool:
    """Return True when *value* looks like an ISO date or datetime literal."""
    if len(value) < ISO_DATE_MIN_LENGTH:
        return False
    return value[:4].isdigit() and value[4] == "-"


def handle_schema_composition(  # noqa: PLR0913
    error: ValidationError,
    source: RawSource,
    data: dict[str, Any],
    *,
    display_context_fn: DisplayContextFn = noop_display_context,
    valid_fields_fn: ValidFieldsFn = noop_valid_fields,
    root_schema: dict[str, Any] | None = None,
) -> list[Diagnostic]:
    """Translate a oneOf/anyOf failure into the most-specific child diagnostics.

    The Rust validator stores branch failures in ``error.kind.context`` as a
    list-of-lists (one list per schema branch). We flatten them and apply the
    ported ``best_match`` heuristic to pick the single most-relevant child,
    then recurse via ``error_to_diagnostics`` so it gets handler-specific
    formatting.

    When no child context exists we fall back to a generic "invalid value"
    wrapper with a description looked up from the root schema.

    Special case: the SQL-check-body's predicate-vs-query oneOf gets a
    focused diagnostic when the user has set ``compare: percent``. The default
    best-match heuristic picks the predicate-branch's "missing required field
    `predicate`" error, which is structurally correct but tells the user
    nothing about why their config is wrong. Surface "compare: percent
    requires the predicate form" instead — that names the actual mistake.
    """
    sql_percent_diag = handle_sql_compare_percent_violation(error, source, data, display_context_fn)
    if sql_percent_diag is not None:
        return [sql_percent_diag]
    children = flatten_context(error)
    if children:
        fields = collect_required_alternatives(children)
        if fields:
            return [
                handle_required_alternatives(
                    error, source, data, fields, display_context_fn=display_context_fn
                )
            ]
        chosen = pick_best_match(children)
        if chosen is not None:
            child_diagnostics = error_to_diagnostics(
                chosen,
                source,
                data,
                display_context_fn=display_context_fn,
                valid_fields_fn=valid_fields_fn,
                root_schema=root_schema,
            )
            if child_diagnostics:
                return child_diagnostics
    field_name = error_field_name(error)
    msg = format_with_context(
        f"invalid value for `{field_name}`",
        data,
        list(error.instance_path),
        display_context_fn=display_context_fn,
    )
    span = resolve_error_span(error, source, is_key_error=False)
    description = lookup_schema_description(root_schema, list(error.schema_path)) if root_schema else ""
    help_text = description or "check the field value matches the expected format"
    return [build_validation(msg, span, help_text=help_text)]


def handle_generic(
    error: ValidationError,
    source: RawSource,
    data: dict[str, Any],
    *,
    display_context_fn: DisplayContextFn = noop_display_context,
) -> Diagnostic:
    """Create a diagnostic from the error, for validators without a specific handler."""
    msg = format_with_context(
        error.message, data, list(error.instance_path), display_context_fn=display_context_fn
    )
    span = resolve_error_span(error, source, is_key_error=False)
    return build_validation(msg, span)


# ── helpers ──────────────────────────────────────────────────────────────


def path_to_dotted(path: Sequence[str | int]) -> str:
    """Join a path sequence into a dot-separated string.

    Example: ['schema', 0, 'name'] -> 'schema.0.name'.
    """
    return ".".join(str(p) for p in path)


def is_regex_pattern(value: str) -> bool:
    """Return True if value looks like a regex pattern from patternProperties."""
    return value.startswith("^") or value.endswith("$")


def flatten_context(error: ValidationError) -> list[ValidationError]:
    """Flatten jsonschema-rs's nested list-of-lists context into a flat list.

    The Rust validator stores oneOf/anyOf branch failures as a list of lists
    (one inner list per schema branch). This flattens them for ranking.
    """
    context = getattr(error.kind, "context", None)
    if not context:
        return []
    result: list[ValidationError] = []
    for branch in context:
        if isinstance(branch, list):
            result.extend(branch)
        else:
            result.append(branch)
    return result


def collect_required_alternatives(errors: Iterable[ValidationError]) -> tuple[str, ...]:
    """Return field names when a composition only says "one of these fields is required"."""
    fields: list[str] = []
    instance_path: tuple[str | int, ...] | None = None
    for error in errors:
        if error.kind.name != "required":
            return ()
        field_name = getattr(error.kind, "value", None)
        if not isinstance(field_name, str):
            return ()
        path = tuple(error.instance_path)
        if instance_path is None:
            instance_path = path
        elif path != instance_path:
            return ()
        fields.append(field_name)
    return tuple(dict.fromkeys(fields)) if len(fields) > 1 else ()


def handle_required_alternatives(
    error: ValidationError,
    source: RawSource,
    data: dict[str, Any],
    fields: Sequence[str],
    *,
    display_context_fn: DisplayContextFn = noop_display_context,
) -> Diagnostic:
    """Create one diagnostic for anyOf branches that require alternative fields."""
    field_list = format_code_list(fields)
    msg = format_with_context(
        f"missing required field: add one of {field_list}",
        data,
        list(error.instance_path),
        display_context_fn=display_context_fn,
    )
    span = resolve_error_span(error, source, is_key_error=False)
    return build_validation(msg, span, help_text=f"add one of {field_list} to the YAML")


SQL_CHECK_BODY_KEY = "sql_check_body"


def handle_sql_compare_percent_violation(
    error: ValidationError, source: RawSource, data: dict[str, Any], display_context_fn: DisplayContextFn
) -> Diagnostic | None:
    """Emit a focused diagnostic when a SQL check sets ``compare: percent`` wrong.

    The schema's ``sql_check_body.oneOf`` branches the check shape into a
    predicate form (allows count or percent) and a full-query form (count
    only). When the user pairs ``compare: percent`` with the full-query form
    or omits ``predicate:`` entirely, both branches fail and the default
    best-match picks the predicate branch's "missing required field
    `predicate`" — accurate but unhelpful. This handler detects the shape
    and replaces that message with one that names the actual mistake.

    Returns ``None`` when the failure is not the SQL-body oneOf, or when
    the user has not asked for percent.
    """
    if SQL_CHECK_BODY_KEY not in list(error.schema_path):
        return None
    instance = walk_instance(data, list(error.instance_path))
    if not isinstance(instance, dict) or instance.get("compare") != "percent":
        return None
    msg = format_with_context(
        "`compare: percent` is allowed only when `predicate:` is set; "
        "the SQL template form and `query:` use a count-only verdict",
        data,
        list(error.instance_path),
        display_context_fn=display_context_fn,
    )
    span = resolve_error_span(error, source, is_key_error=True, extra_path="compare")
    return build_validation(
        msg, span, help_text="rewrite the check using `predicate:` or remove `compare: percent`"
    )


def walk_instance(root: dict[str, Any], path: Sequence[str | int]) -> Any:
    """Walk a YAML/JSON instance along ``path``, returning ``None`` on a missing step."""
    node: Any = root
    for segment in path:
        node = step_into_schema(node, segment)
        if node is None:
            return None
    return node


def format_code_list(values: Sequence[str]) -> str:
    """Format names as markdown-code comma list for diagnostics."""
    return ", ".join(f"`{value}`" for value in values)


def error_relevance(error: ValidationError) -> tuple[int, list[str | int], bool]:
    """Score an error for best_match ranking.

    Ported from jsonschema.exceptions.relevance: deeper path wins,
    non-weak validators (oneOf/anyOf) are penalized.
    """
    path = list(error.instance_path)
    return (-len(path), path, error.kind.name not in WEAK_VALIDATORS)


def pick_best_match(errors: Iterable[ValidationError]) -> ValidationError | None:
    """Pick the most specific error, porting jsonschema's best_match heuristic.

    Starts with the highest-relevance error, then descends into nested
    oneOf/anyOf context as long as there is a unique best child.
    """
    best = max(errors, key=error_relevance, default=None)
    if best is None:
        return None
    while children := flatten_context(best):
        smallest = heapq.nsmallest(2, children, key=error_relevance)
        if len(smallest) == 2 and error_relevance(smallest[0]) == error_relevance(smallest[1]):  # noqa: PLR2004
            return best
        best = smallest[0]
    return best


def step_into_schema(node: Any, segment: str | int) -> Any:
    """Take one step into a nested JSON Schema structure."""
    if isinstance(node, dict) and isinstance(segment, str):
        return node.get(segment)
    if isinstance(node, list) and isinstance(segment, int) and segment < len(node):
        return node[segment]
    return None


def walk_schema(root: dict[str, Any], path: Sequence[str | int]) -> Any:
    """Walk a JSON Schema dict along a path, returning None if any step fails."""
    node: Any = root
    for segment in path:
        node = step_into_schema(node, segment)
        if node is None:
            return None
    return node


def lookup_schema_description(root_schema: dict[str, Any] | None, schema_path: list[str | int]) -> str:
    """Walk the root schema along schema_path (minus the failing keyword) to find a description."""
    if not root_schema or not schema_path:
        return ""
    parent = walk_schema(root_schema, schema_path[:-1])
    if isinstance(parent, dict):
        return parent.get(SchemaKey.DESCRIPTION, "")
    return ""
