"""DescriptorSchemaValidator — generic schema validator driven by FormatDescriptor."""

from typing import Any

from turbine.core.building_blocks import DiagnosticSink
from turbine.core.common import RawSource
from turbine.core.contract import FormatDescriptor

from .validator import build_schema_validator, validate_schema


class DescriptorSchemaValidator:
    """Schema validator driven by a FormatDescriptor.

    Replaces per-format validator classes with a single class parameterized by descriptor.
    """

    def __init__(self, descriptor: FormatDescriptor) -> None:
        """Build the JSON Schema validator from the descriptor's schema loader."""
        schema = descriptor.schema_loader()
        self.validator = build_schema_validator(schema)
        self.schema = schema
        self.descriptor = descriptor

    def validate(self, data: dict[str, Any], source: RawSource, sink: DiagnosticSink) -> frozenset[str]:
        """Run JSON Schema validation with format-specific context from the descriptor.

        Returns the set of dotted key paths that were flagged by the schema, so
        adapter-level fallbacks can skip re-reporting them.
        """
        return validate_schema(
            data,
            source,
            sink,
            self.validator,
            display_context_fn=self.descriptor.display_context_fn,
            valid_fields_fn=self.descriptor.valid_fields_fn,
            root_schema=self.schema,
        )
