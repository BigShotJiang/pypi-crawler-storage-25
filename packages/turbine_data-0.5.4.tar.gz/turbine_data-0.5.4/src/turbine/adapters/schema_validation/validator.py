"""Generic JSON Schema validation that converts errors to Diagnostics.

Provides validate_schema() which iterates over jsonschema ValidationErrors
and translates them into deduplicated Diagnostics via the handlers module.
Also provides shared helpers: parse_pydantic_model() for pydantic-to-diagnostic
conversion and build_schema_validator() for JSON Schema validator creation.
"""

from typing import Any

import jsonschema_rs
from loguru import logger
from pydantic import BaseModel, ValidationError
from pydantic_core import ErrorDetails

from turbine.core.building_blocks import (
    Annotation,
    Diagnostic,
    DiagnosticBuilder,
    DiagnosticId,
    DiagnosticSink,
    DisplayContextFn,
    ValidFieldsFn,
    noop_display_context,
    noop_valid_fields,
    resolve_fallback_range,
)
from turbine.core.common import RawSource

from .handlers import error_to_diagnostics


def validate_schema(  # noqa: PLR0913
    data: dict[str, Any],
    source: RawSource,
    sink: DiagnosticSink,
    validator: jsonschema_rs.Validator,
    *,
    display_context_fn: DisplayContextFn | None = None,
    valid_fields_fn: ValidFieldsFn | None = None,
    root_schema: dict[str, Any] | None = None,
) -> frozenset[str]:
    """Run JSON Schema validation on data and write deduplicated diagnostics to sink.

    Duplicate diagnostics (same message and annotations) are suppressed.
    Returns the set of dotted key paths that were flagged, so downstream
    adapter-level fallbacks can dedupe against it.
    """
    errors = suppress_cascading_unevaluated(list(validator.iter_errors(data)))
    seen: set[tuple[str, tuple[Annotation, ...]]] = set()
    flagged_paths: set[str] = set()
    error_count = 0
    for error in errors:
        flagged_paths.add(".".join(str(part) for part in error.instance_path))
        for diag in error_to_diagnostics(
            error,
            source,
            data,
            display_context_fn=display_context_fn or noop_display_context,
            valid_fields_fn=valid_fields_fn or noop_valid_fields,
            root_schema=root_schema,
        ):
            if (key := (diag.message, diag.annotations)) not in seen:
                seen.add(key)
                sink.add(diag)
                error_count += 1
    if error_count:
        logger.debug(f"Schema validation found {error_count} errors")
    else:
        logger.debug("Schema validation passed")
    return frozenset(flagged_paths)


def suppress_cascading_unevaluated(
    errors: list[jsonschema_rs.ValidationError],
) -> list[jsonschema_rs.ValidationError]:
    """Drop `unevaluatedProperties` errors whose path already has a sibling error.

    When a conditional branch (e.g. `if/then` or `oneOf`) inside a schema with
    `unevaluatedProperties: false` fails, the branch's property annotations
    are never emitted, so the outer validator reports those properties as
    "unknown" on top of the real branch-failure error — two errors at the
    same instance path, the second one misleading. Suppressing it here lets
    the branch failure surface alone.

    Tradeoff: if the user has a typo *and* a failed conditional at the same
    path, the typo stays hidden until the branch succeeds. The LSP
    re-validates on every edit, so it resurfaces as soon as the branch
    issue is fixed. Intentional.
    """
    paths_with_other_errors = {
        tuple(err.instance_path) for err in errors if err.kind.name != "unevaluatedProperties"
    }
    return [
        err
        for err in errors
        if err.kind.name != "unevaluatedProperties"
        or tuple(err.instance_path) not in paths_with_other_errors
    ]


def parse_pydantic_model[T: BaseModel](
    model_cls: type[T], source: RawSource, sink: DiagnosticSink
) -> T | None:
    """Parse raw YAML data into a pydantic model, emitting diagnostics on failure.

    Each pydantic ValidationError field is converted to a diagnostic with
    the source location from the SourceMap. Returns None if parsing fails.
    """
    try:
        return model_cls.model_validate(source.data)
    except ValidationError as exc:
        for error in exc.errors():
            sink.add(pydantic_error_to_diagnostic(error, source))
        return None


def pydantic_error_to_diagnostic(error: ErrorDetails, source: RawSource) -> Diagnostic:
    """Route a pydantic validation error to a type-specific diagnostic message."""
    loc_parts = error["loc"]
    loc_path = ".".join(str(p) for p in loc_parts)
    field_name = str(loc_parts[-1]) if loc_parts else "root"
    resolver = source.source_map.range_for_key
    text_range = resolver(loc_path) or resolve_fallback_range(loc_path, resolver)

    error_type = error["type"]
    error_msg = error["msg"]

    match error_type:
        case "missing":
            msg = f"missing required field `{field_name}`"
            help_text = f"add `{field_name}` to the YAML"
        case "string_type":
            input_val = error.get("input")
            type_name = type(input_val).__name__ if input_val is not None else "unknown"
            msg = f"expected string for `{field_name}`, got {type_name}"
            help_text = None
        case "extra_forbidden":
            msg = f"unknown field `{field_name}`"
            help_text = "remove it or check spelling"
        case _:
            msg = f"validation error at `{field_name}`: {error_msg}"
            help_text = None

    builder = DiagnosticBuilder.error(DiagnosticId.CONTRACT_INVALID_SCHEMA, msg)
    builder.span(source.path, text_range)
    if help_text:
        builder.help(help_text)
    return builder.build()


def build_schema_validator(schema: dict[str, Any]) -> jsonschema_rs.Validator:
    """Create a Rust-backed JSON Schema validator (Draft 2019-09 compatible)."""
    return jsonschema_rs.validator_for(schema)
