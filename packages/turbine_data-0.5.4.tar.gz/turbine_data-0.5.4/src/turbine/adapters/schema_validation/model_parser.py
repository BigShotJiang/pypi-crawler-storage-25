"""PydanticModelParser — adapter implementing the ModelParser port from core."""

from pydantic import BaseModel

from turbine.core.building_blocks import DiagnosticSink
from turbine.core.common import RawSource

from .validator import parse_pydantic_model


class PydanticModelParser:
    """Parses raw YAML data into Pydantic models with diagnostic collection."""

    def parse[T: BaseModel](
        self, model_cls: type[T], source: RawSource, sink: DiagnosticSink
    ) -> T | None:
        """Parse into model_cls, emitting diagnostics on failure."""
        return parse_pydantic_model(model_cls, source, sink)
