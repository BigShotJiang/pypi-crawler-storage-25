"""Resolves contract ids across a fan of ContractRepository instances."""

from pathlib import Path

from turbine.core.contract import ContractLookup, ContractRepository
from turbine.core.contract.diagnostic_collector import ContractDiagnosticCollector
from turbine.core.contract.errors import ContractNotFoundError


class RepoListContractLookup(ContractLookup):
    """Walks each repository in order, returning the first matching contract id.

    Parse diagnostics emitted by any repo while scanning are collected and
    attached to ``ContractNotFoundError`` when the id is missing everywhere.
    """

    def __init__(self, repos: tuple[ContractRepository, ...]) -> None:
        """Bind the lookup to an immutable tuple of repositories."""
        self.repos = repos

    def find(self, contract_id: str) -> Path:
        """Return the first matching path or raise ``ContractNotFoundError``."""
        sink = ContractDiagnosticCollector()
        for repo in self.repos:
            for location in repo.list_contracts(sink):
                if location.contract_id == contract_id:
                    return location.path
        raise ContractNotFoundError(contract_id=contract_id, diagnostics=tuple(sink.items))
