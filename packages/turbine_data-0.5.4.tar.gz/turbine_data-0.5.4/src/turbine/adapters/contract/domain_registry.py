"""YAML-backed registry of approved Contract domain values."""

from dataclasses import dataclass
from importlib.resources import files
from pathlib import Path
from typing import cast

from ruamel.yaml import YAML, YAMLError


@dataclass(slots=True)
class YamlDomainRegistry:
    """Loads approved Contract domains from project override, then bundled defaults."""

    workspace_file: Path
    bundle_package: str = "turbine.data"
    bundle_name: str = "enexis_domains.yml"
    cache_loaded: bool = False
    cached_allowed: tuple[str, ...] | None = None

    def allowed(self) -> tuple[str, ...] | None:
        """Return approved Contract domains, or None when no registry exists."""
        if self.cache_loaded:
            return self.cached_allowed
        self.cached_allowed = self.load_allowed()
        self.cache_loaded = True
        return self.cached_allowed

    def load_allowed(self) -> tuple[str, ...] | None:
        """Load allowed domains using project-file-over-bundle precedence."""
        if self.workspace_file.exists():
            return load_allowed_file(self.workspace_file)
        return self.load_bundle_allowed()

    def load_bundle_allowed(self) -> tuple[str, ...] | None:
        """Load allowed domains from the bundled package data file when present."""
        try:
            text = (files(self.bundle_package) / self.bundle_name).read_text(encoding="utf-8")
        except (FileNotFoundError, ModuleNotFoundError, OSError):
            return None
        return parse_allowed_domains(text)


def load_allowed_file(path: Path) -> tuple[str, ...] | None:
    """Parse allowed domains from a filesystem YAML file."""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return None
    return parse_allowed_domains(text)


def parse_allowed_domains(text: str) -> tuple[str, ...] | None:
    """Extract the ``allowed:`` string list from YAML text."""
    yaml = YAML(typ="safe")
    try:
        loaded: object = yaml.load(text)
    except YAMLError:
        return None
    if not isinstance(loaded, dict):
        return None
    loaded_dict = cast(dict[str, object], loaded)
    allowed = loaded_dict.get("allowed")
    if not isinstance(allowed, list):
        return None

    values: list[str] = []
    seen: set[str] = set()
    for item in allowed:
        if not isinstance(item, str) or not item:
            return None
        if item in seen:
            continue
        values.append(item)
        seen.add(item)
    return tuple(values)
