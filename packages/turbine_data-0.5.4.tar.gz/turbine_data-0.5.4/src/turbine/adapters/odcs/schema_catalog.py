"""ODCS JSON Schema registry.

Loads schema.json from the ODCS package, merges Turbine-specific
extensions via RFC 7396 JSON Merge Patch, and caches a Draft 2019-09
validator.

Two layers of extensions are applied on top of the ODCS base:

1. **Static** — ``schema_extensions.json``: SQL identifier pattern on
   ``SchemaObject.name`` and numeric narrowing on
   ``DataQualityOperators.mustBe`` / ``mustNotBe``.
2. **Dynamic** — Pydantic-derived shapes: ``MetricParams`` for
   ``DataQualityLibrary.arguments`` and the turbine check-body discriminated
   union for ``DataQualityCustom.implementation`` (when ``engine: turbine``).
   Generating these from the Pydantic models keeps the JSON schema and the
   runtime validation in sync automatically.
"""

import importlib.resources
import json
from functools import cache
from typing import Any

from pydantic import BaseModel
from pydantic.fields import FieldInfo

from turbine.core.common import SchemaNode
from turbine.core.common.dataset_spec.checks import ALL_KNOWN_TYPES, MetricParams
from turbine.core.common.quality_dimension import QualityDimension
from turbine.core.quality.spec_models import BODY_MAP, MetricCheckBody


def load_package_json(package: str, filename: str) -> SchemaNode:
    """Load and parse a JSON file from a Python package's data directory."""
    text = importlib.resources.files(package).joinpath(filename).read_text(encoding="utf-8")
    return json.loads(text)


def field_accepted_names(field_name: str, field: FieldInfo) -> set[str]:
    """Return non-canonical validation aliases for a Pydantic field.

    The canonical name (``field.alias`` when an ``alias_generator`` runs, else
    ``field_name``) is already emitted by Pydantic's ``model_json_schema`` and
    doesn't need to be re-added. This helper only returns the *extra* names
    contributed by an explicit ``AliasChoices`` or a string ``validation_alias``
    — the cases where multiple equally-external names are intentionally valid
    (e.g. ``MetricParams`` accepts both ``valid_values`` and ``enum``). The
    Python field name is deliberately omitted when an ``alias_generator`` is
    in play: the snake_case form would be duplicative noise in completion,
    and no YAML in the repo uses it.
    """
    names: set[str] = set()
    validation_alias = field.validation_alias
    if isinstance(validation_alias, str):
        names.add(validation_alias)
    choices = getattr(validation_alias, "choices", None)
    if choices:
        names.update(str(choice) for choice in choices)
    # Only include field_name when there's no alias and no AliasChoices —
    # i.e. canonical == field_name already, so adding it is a no-op via setdefault.
    if not field.alias and not validation_alias:
        names.add(field_name)
    return names


def duplicate_properties_under_aliases(schema: SchemaNode, model_cls: type[BaseModel]) -> SchemaNode:
    """For each field, add the property entry under every extra accepted name.

    Canonical names are already in the Pydantic-generated schema. This only
    extends the schema with non-canonical aliases (e.g. ``AliasChoices``
    entries) so JSON-Schema validation accepts the same names Pydantic does.
    """
    properties: dict[str, SchemaNode] = schema.get("properties", {})
    for field_name, field in model_cls.model_fields.items():
        canonical = field.alias or field_name
        entry = properties.get(canonical)
        if entry is None:
            continue
        for name in field_accepted_names(field_name, field):
            properties.setdefault(name, entry)
    schema["properties"] = properties
    return schema


def pydantic_schema_with_aliases(model_cls: type[BaseModel]) -> SchemaNode:
    """Return the Pydantic JSON schema for *model_cls* with alias names duplicated."""
    schema = model_cls.model_json_schema(by_alias=True)
    return duplicate_properties_under_aliases(schema, model_cls)


def lift_pydantic_defs(
    model_cls: type[BaseModel], prefix: str = "Turbine"
) -> tuple[SchemaNode, SchemaNode]:
    """Generate a Pydantic schema and lift its ``$defs`` into a prefixed namespace.

    Pydantic emits nested ``$defs`` with their original class names, which
    would collide with the ODCS base schema when merged at the root. Using
    ``ref_template``, every ``$ref`` inside the schema is rewritten to point
    at ``{prefix}{name}``; this helper also renames the ``$defs`` keys to
    match so the caller can merge them into the root ``$defs`` safely.
    """
    ref_template = "#/$defs/" + prefix + "{model}"
    schema = model_cls.model_json_schema(by_alias=True, ref_template=ref_template)
    schema = duplicate_properties_under_aliases(schema, model_cls)
    defs = schema.pop("$defs", {})
    lifted = {f"{prefix}{name}": body for name, body in defs.items()}
    return schema, lifted


THRESHOLD_OPERATORS: tuple[str, ...] = (
    "mustBe",
    "mustNotBe",
    "mustBeGreaterThan",
    "mustBeGreaterThanOrEqual",
    "mustBeLessThan",
    "mustBeLessThanOrEqual",
    "mustBeBetween",
    "mustBeNotBetween",
)

# Check types that don't carry a pass/fail row-count verdict (shape assertion).
# Kept in sync with ``THRESHOLD_EXEMPT_METRIC_TYPES`` in
# ``core/contract/lint_rules.py``.
THRESHOLD_EXEMPT_CHECK_TYPES: frozenset[str] = frozenset({"schema"})


def threshold_any_of() -> SchemaNode:
    """Return the ``anyOf`` that requires at least one ``mustBe*`` operator on an implementation body."""
    return {"anyOf": [{"required": [op]} for op in THRESHOLD_OPERATORS]}


def turbine_pydantic_extensions() -> SchemaNode:
    """Build the dynamic extensions layer from Pydantic models.

    Narrows ``DataQualityLibrary.arguments`` to ``MetricParams`` and — when
    ``engine: turbine`` — narrows ``DataQualityCustom.implementation`` to the
    ``MetricCheckBody`` shape so type errors like ``valid_min: "not-a-number"``
    become JSON schema validation errors with precise source ranges.

    Also requires a ``mustBe*`` verdict operator on every non-exempt check
    body so threshold-missing shows up as an editor-time schema error rather
    than a post-parse lint finding. ``check: schema`` is exempt (shape
    assertion, no row-count verdict).
    """
    metric_params_schema = pydantic_schema_with_aliases(MetricParams)
    all_defs: dict[str, SchemaNode] = {}

    check_values = sorted(ALL_KNOWN_TYPES)

    def body_shape_for(body_cls: type[BaseModel]) -> SchemaNode:
        schema, defs = lift_pydantic_defs(body_cls)
        all_defs.update(defs)
        properties = schema.get("properties", {})
        return {
            "type": "object",
            "properties": {"check": {"type": "string", "enum": check_values}, **properties},
            "unevaluatedProperties": False,
        }

    for body_cls in {MetricCheckBody, *BODY_MAP.values()}:
        all_defs["Turbine" + body_cls.__name__] = body_shape_for(body_cls)
    structural_types = list(BODY_MAP.keys())

    def body_with_threshold(body_ref: str, check_type: str) -> SchemaNode:
        """Wrap a body ``$ref`` with the threshold ``anyOf`` unless exempt."""
        if check_type in THRESHOLD_EXEMPT_CHECK_TYPES:
            return {"$ref": body_ref}
        return {"allOf": [{"$ref": body_ref}, threshold_any_of()]}

    check_branches: list[SchemaNode] = [
        {
            "if": {"properties": {"check": {"const": check_type}}, "required": ["check"]},
            "then": body_with_threshold("#/$defs/Turbine" + body_cls.__name__, check_type),
        }
        for check_type, body_cls in BODY_MAP.items()
    ]
    # Non-structural check types (missing, invalid, row_count, freshness, ...) all use
    # MetricCheckBody and need a threshold; ``schema`` is handled by its own branch in
    # ``check_branches`` via :class:`SchemaCheckBody`.
    metric_fallback: SchemaNode = {
        "if": {"properties": {"check": {"not": {"enum": structural_types}}}, "required": ["check"]},
        "then": {"allOf": [{"$ref": "#/$defs/TurbineMetricCheckBody"}, threshold_any_of()]},
    }
    turbine_body_shape: SchemaNode = {
        "properties": {"check": {"type": "string", "enum": check_values}},
        "required": ["check"],
        "allOf": [*check_branches, metric_fallback],
    }
    return {
        "$defs": {
            **all_defs,
            "DataQualityLibrary": {"properties": {"arguments": metric_params_schema}},
            "DataQualityCustom": {
                "allOf": [
                    {
                        "if": {
                            "properties": {
                                "engine": {"const": "turbine"},
                                "implementation": {"type": "object"},
                            },
                            "required": ["engine", "implementation"],
                        },
                        "then": {"properties": {"implementation": turbine_body_shape}},
                    }
                ]
            },
        }
    }


@cache
def load_merged_schema() -> SchemaNode:
    """Load the ODCS base schema and overlay Turbine's extensions on top.

    Applies the static ``schema_extensions.json`` first, then the dynamic
    Pydantic-derived shapes. Uses RFC 7396 JSON Merge Patch with array
    deduplication for both layers. After both merges, the
    ``DataQuality.dimension`` enum is hard-replaced with Turbine's five
    canonical dimensions — the JSON-patch union semantics would otherwise
    leave the ODCS-only names (``conformity``, ``coverage``, ``uniqueness``)
    in the accepted set.
    """
    base = load_odcs_schema()
    extensions = load_package_json("turbine.adapters.odcs", "schema_extensions.json")
    merged = merge_json_patch(base, extensions) if extensions else base
    merged = merge_json_patch(merged, turbine_pydantic_extensions())
    overlay_turbine_dimensions(merged)
    return merged


def overlay_turbine_dimensions(schema: SchemaNode) -> None:
    """Replace the upstream ``DataQuality.dimension`` enum with Turbine's five.

    Single source of truth lives in :class:`QualityDimension`; this function
    keeps the JSON schema validator in lockstep so the user sees the same
    five values everywhere — error messages, autocomplete, hover.
    """
    data_quality = schema.get("$defs", {}).get("DataQuality", {})
    dimension = data_quality.get("properties", {}).get("dimension")
    if isinstance(dimension, dict):
        dimension["enum"] = [d.value for d in QualityDimension]


def union_lists(base: list[Any], patch: list[Any]) -> list[Any]:
    """Concatenate two lists, dropping duplicate entries.

    Dicts are compared by their JSON-serialized form; scalars by equality.
    """
    seen: set[Any] = set()
    merged: list[Any] = []
    for item in [*base, *patch]:
        hashable = json.dumps(item, sort_keys=True) if isinstance(item, dict) else item
        if hashable not in seen:
            seen.add(hashable)
            merged.append(item)
    return merged


def merge_json_patch(base: SchemaNode, patch: SchemaNode) -> SchemaNode:
    """Apply a JSON Merge Patch (RFC 7396) to a base dict.

    Unlike standard RFC 7396, arrays are merged by union instead of replaced.
    """
    result = dict(base)
    for key, patch_value in patch.items():
        if patch_value is None:
            result.pop(key, None)
        elif isinstance(patch_value, dict) and isinstance(result.get(key), dict):
            result[key] = merge_json_patch(result[key], patch_value)
        elif isinstance(patch_value, list) and isinstance(result.get(key), list):
            result[key] = union_lists(result[key], patch_value)
        else:
            result[key] = patch_value
    return result


@cache
def load_odcs_schema() -> SchemaNode:
    """Load schema.json from the open_data_contract_standard package."""
    return load_package_json("open_data_contract_standard", "schema.json")
