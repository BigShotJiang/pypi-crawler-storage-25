"""JSON Schema validation for the ``implementation:`` block of contract-embedded checks.

The ODCS contract schema only declares ``implementation`` as ``oneOf: [string, object]``,
so it never validates the inner shape (``check``, ``unit``, ``column``, threshold operators,
``params``, etc.). Authors writing freshness/missing/aggregate/anomaly checks inline
on a contract therefore got zero feedback when fields were missing or mistyped.

This module reuses the QualitySpec ``check_item`` ``$def`` to validate
``{<check>: <implementation - check>}`` and routes errors through the same diagnostic
handlers used elsewhere, with paths translated back to the contract's source map so
spans land on the offending key inside the ``implementation:`` block.
"""

from __future__ import annotations

import json
from dataclasses import dataclass, replace
from functools import cache
from importlib.resources import files
from typing import Any

import jsonschema_rs

from turbine.adapters.schema_validation.validator import validate_schema
from turbine.core.building_blocks import DiagnosticSink
from turbine.core.building_blocks.diagnostics.source_map import SourceMap
from turbine.core.building_blocks.diagnostics.types import TextRange
from turbine.core.common import RawSource


@cache
def load_check_item_validator() -> tuple[jsonschema_rs.Validator, dict[str, Any]]:
    """Build a validator for a single ``check_item`` with the QualitySpec ``$defs`` available.

    Returns the compiled validator alongside the wrapping schema dict, which downstream
    handlers use as ``root_schema`` when looking up field descriptions for help text.
    """
    schema_dir = files("turbine.core.analysis.schemas")
    full_schema = json.loads((schema_dir / "quality_spec.schema.json").read_text())
    wrapper = {"$ref": "#/$defs/check_item", "$defs": full_schema["$defs"]}
    return jsonschema_rs.validator_for(wrapper), wrapper


@dataclass(frozen=True, slots=True)
class PrefixedSourceMap(SourceMap):
    """Source map that rewrites ``<check_type>.<rest>`` paths to ``<field_path>.implementation.<rest>``.

    The validator runs against ``{<check_type>: implementation}``, so error
    instance paths begin with the check-type segment. Diagnostics need to point
    inside the contract's ``implementation:`` block, which lives at
    ``<field_path>.implementation`` in the wrapped source map.
    """

    inner: SourceMap
    field_path: str

    def translate(self, key_path: str) -> str:
        """Drop the leading check-type segment and rewrite onto the contract path."""
        parts = key_path.split(".", 1)
        suffix = parts[1] if len(parts) > 1 else ""
        return f"{self.field_path}.implementation.{suffix}".rstrip(".")

    def range_for_key(self, key_path: str) -> TextRange | None:
        """Resolve a key range against the contract source map after translation."""
        return self.inner.range_for_key(self.translate(key_path))

    def range_for_value(self, key_path: str) -> TextRange | None:
        """Resolve a value range against the contract source map after translation."""
        return self.inner.range_for_value(self.translate(key_path))

    def range_for_block(self, key_path: str) -> TextRange | None:
        """Resolve a block range against the contract source map after translation."""
        return self.inner.range_for_block(self.translate(key_path))

    def key_paths(self) -> tuple[str, ...]:
        """Pass-through; handlers use this only for additionalProperties suggestions."""
        return self.inner.key_paths()

    def range_for_document_root(self) -> TextRange | None:
        """Pass-through to the wrapped contract source map."""
        return self.inner.range_for_document_root()


@dataclass(frozen=True, slots=True)
class ImplementationValidationRequest:
    """Inputs for validating one contract-embedded ``implementation:`` block."""

    implementation: dict[str, Any] | None
    field_path: str
    source: RawSource
    sink: DiagnosticSink
    outer_dimension: str | None = None
    outer_column: str | None = None


def validate_implementation(request: ImplementationValidationRequest) -> bool:
    """Validate a contract-embedded ``implementation:`` block as a single ``check_item``.

    Mirrors the field-merging done by ``OdcsReader.parse_turbine_implementation``:
    the outer ``dimension:`` (declared on the quality item itself) and the implicit
    ``column:`` (when the check sits under a column entry) are injected before
    validation so they are not reported as missing. Anything else absent or
    mistyped becomes a diagnostic on the contract source.

    Returns ``True`` when validation produces no errors. ``False`` when at least
    one diagnostic was emitted, which means downstream coercion should be skipped.
    Non-dict implementations and missing/non-string ``check`` are not validated
    here — those are handled by the existing pydantic / coercion path.
    """
    if not isinstance(request.implementation, dict):
        return True
    check_type = request.implementation.get("check")
    if not isinstance(check_type, str):
        return True
    body: dict[str, Any] = {
        key: value for key, value in request.implementation.items() if key != "check"
    }
    if request.outer_dimension and "dimension" not in body:
        body["dimension"] = request.outer_dimension
    if request.outer_column and "column" not in body:
        body["column"] = request.outer_column
    document = {check_type: body}
    validator, wrapper_schema = load_check_item_validator()
    wrapped_source = replace(
        request.source, source_map=PrefixedSourceMap(request.source.source_map, request.field_path)
    )
    pre_count = sink_size(request.sink)
    validate_schema(document, wrapped_source, request.sink, validator, root_schema=wrapper_schema)
    return sink_size(request.sink) == pre_count


def sink_size(sink: DiagnosticSink) -> int:
    """Return the number of diagnostics already in *sink*, or 0 when it cannot be sized.

    ``DiagnosticSink`` is a Protocol; the production collector implements ``__len__``
    via its ``items`` tuple, so this preserves a count to detect new emissions.
    Returning 0 for sinks without a length means we treat them as never-blocked,
    which is the safe default — implementation validation only ever ADDS diagnostics.
    """
    items = getattr(sink, "items", None)
    return len(items) if items is not None else 0
