"""ODCS-specific schema validation context — display context and valid fields.

ContextTracker, resolve_display_context, valid_fields_for_path are used by
FormatDescriptor to customize validation error messages for ODCS contracts.
"""

from collections.abc import Iterable, Sequence
from dataclasses import dataclass
from enum import StrEnum
from functools import lru_cache
from typing import Any

from turbine.core.common import resolve_at_path

from .schema_catalog import load_merged_schema


class OdcsPathKey(StrEnum):
    """ODCS YAML structure keys used in context path tracking."""

    SCHEMA = "schema"
    PROPERTIES = "properties"
    NAME = "name"


@dataclass(slots=True)
class ContextTracker:
    """Accumulates schema and property names while walking a YAML path."""

    schema_name: str | None = None
    prop_name: str | None = None
    parent_name: str | None = None

    def track(self, item: dict[str, object], prev_key: str | int | None) -> None:
        """Record the 'name' field of a dict if it appears under a 'schema' or 'properties' key."""
        name = item.get(OdcsPathKey.NAME)
        if not isinstance(name, str):
            return
        if prev_key == OdcsPathKey.SCHEMA:
            self.schema_name = name
        elif prev_key == OdcsPathKey.PROPERTIES:
            self.parent_name = self.prop_name or self.schema_name
            self.prop_name = name

    def format(self) -> str:
        """Format the accumulated names into a label like 'property `age` of `users`'."""
        if self.prop_name and self.parent_name:
            return f"property `{self.prop_name}` of `{self.parent_name}`"
        if self.prop_name:
            return f"property `{self.prop_name}`"
        if self.schema_name:
            return f"schema `{self.schema_name}`"
        return ""


def resolve_display_context(data: dict[str, Any], path: Iterable[str | int]) -> str:
    """Walk YAML data along a validation error's path."""
    current: Any = data
    tracker = ContextTracker()
    path_list = list(path)

    for i, key in enumerate(path_list):
        if isinstance(key, str) and isinstance(current, dict):
            current = current.get(key)
            continue
        if not (isinstance(key, int) and isinstance(current, list) and key < len(current)):
            break
        item = current[key]
        if isinstance(item, dict):
            tracker.track(item, path_list[i - 1] if i > 0 else None)
        current = item

    return tracker.format()


def valid_fields_for_path(path: Sequence[str | int]) -> list[str]:
    """Look up the JSON Schema at a given error path and return the sorted valid child field names."""
    return cached_odcs_fields(".".join(str(p) for p in path))


@lru_cache(maxsize=4096)
def cached_odcs_fields(dotted: str) -> list[str]:
    """Look up valid child field names at a dotted schema path, with LRU caching."""
    node = resolve_at_path(dotted, load_merged_schema())
    return sorted(node.children.keys())
