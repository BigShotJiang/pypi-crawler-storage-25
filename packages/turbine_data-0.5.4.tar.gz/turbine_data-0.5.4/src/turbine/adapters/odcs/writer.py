"""ODCS format writer: DatasetSpec -> ODCS v3.1.0 YAML.

Constructs the OpenDataContractStandard model directly from DatasetSpec
and serializes via model_dump(by_alias=True).
"""

from io import StringIO

from open_data_contract_standard.model import (
    Description,
    OpenDataContractStandard,
    SchemaObject,
    SchemaProperty,
    ServiceLevelAgreementProperty,
)
from ruamel.yaml import YAML

from turbine.core.common import ContractMetadata, DatasetSpec, FormatLabel, SlaProperty

ODCS_API_VERSION = "v3.1.0"


class OdcsWriter:
    """Serialize DatasetSpec to ODCS v3.1.0 YAML."""

    format_label = FormatLabel.ODCS
    yaml = YAML()
    yaml.default_flow_style = False

    def render(self, item: DatasetSpec) -> str:
        """Render dataset spec as ODCS YAML string."""
        properties = [
            SchemaProperty(
                name=col.name,
                logicalType=str(col.logical_type),
                required=not col.nullable,
                primaryKey=col.primary_key or None,
                description=str(col.description) if col.description else None,
                tags=list(col.tags) if col.tags else None,
            )
            for col in item.columns
        ]
        schema_obj = SchemaObject(name=str(item.table), properties=properties)
        sla_properties = [self.serialize_sla(prop) for prop in (item.sla.properties if item.sla else ())]
        contract = OpenDataContractStandard.model_construct(
            kind="DataContract",
            apiVersion=ODCS_API_VERSION,
            id=item.metadata.contract_id,
            version=item.metadata.version,
            status=str(item.metadata.status),
            name=item.metadata.name,
            domain=item.metadata.domain,
            description=self.serialize_description(item.metadata),
            slaProperties=sla_properties or None,
            schema_=[schema_obj],
        )
        yaml_dict = contract.model_dump(by_alias=True, exclude_none=True)
        stream = StringIO()
        self.yaml.dump(yaml_dict, stream)
        return stream.getvalue()

    @staticmethod
    def serialize_description(metadata: ContractMetadata) -> Description | None:
        """Emit a ``description:`` block when purpose or usage is set.

        The ODCS JSON schema requires ``description.purpose`` at the contract
        root, so scaffolds populate the field with a placeholder. Returns
        ``None`` when neither field has content so we do not write an empty
        block for contracts that never had a description.
        """
        purpose = metadata.description_purpose
        usage = metadata.description_usage
        if not purpose and not usage:
            return None
        return Description(purpose=purpose, usage=usage)

    @staticmethod
    def serialize_sla(prop: SlaProperty) -> ServiceLevelAgreementProperty:
        """Convert a domain SlaProperty into the ODCS wire model.

        Integer-valued SLAs (``value: 24``) are serialized as ints so the
        YAML reads as ``value: 24`` instead of ``value: 24.0`` — the
        domain model holds floats but ODCS accepts either, and the
        integer form is what users write by hand.
        """
        value = prop.value
        if value is not None and float(value).is_integer():
            value = int(value)
        return ServiceLevelAgreementProperty(
            property=prop.property, value=value, unit=prop.unit, element=prop.element
        )

    def filename(self, item: DatasetSpec) -> str:
        """Derive output filename from contract ID."""
        return f"{item.metadata.contract_id}.yml"
