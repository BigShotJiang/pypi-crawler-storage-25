"""ODCS format descriptor — bundles schema infrastructure for ODCS contracts."""

from turbine.core.common import FormatLabel
from turbine.core.contract import FormatDescriptor

from .schema_catalog import load_merged_schema
from .schema_validation import resolve_display_context, valid_fields_for_path

ODCS_DESCRIPTOR = FormatDescriptor(
    format_label=FormatLabel.ODCS,
    schema_loader=load_merged_schema,
    display_context_fn=resolve_display_context,
    valid_fields_fn=valid_fields_for_path,
)
