"""ODCS format reader — parse ODCS DataContract YAML into DatasetSpec.

A single ODCS contract file can contain multiple schema objects (tables).
Each named schema produces a separate DatasetSpec with its own columns
and derived quality checks. Implements the FormatReader protocol.
"""

from collections.abc import Callable
from dataclasses import dataclass, replace
from pathlib import Path
from typing import Any, Literal, Protocol

from loguru import logger
from open_data_contract_standard.model import (
    DataQuality,
    OpenDataContractStandard,
    SchemaObject,
    SchemaProperty,
    ServiceLevelAgreementProperty,
)
from pydantic import BaseModel, ValidationError

from turbine.adapters.odcs.implementation_validation import (
    ImplementationValidationRequest,
    validate_implementation,
)
from turbine.adapters.odcs.sla_intake import SlaIntake
from turbine.core.building_blocks import (
    Annotation,
    DiagnosticBuilder,
    DiagnosticId,
    DiagnosticSink,
    Span,
    TextRange,
    TurbineError,
)
from turbine.core.building_blocks.diagnostics.source_map import resolve_fallback_range
from turbine.core.common import (
    BetweenRange,
    CheckCategory,
    CheckDef,
    CheckSource,
    ColumnDef,
    ComparisonThreshold,
    ContractMetadata,
    ContractStatus,
    CustomProperty,
    DatasetSpec,
    Duration,
    ExactThreshold,
    LogicalType,
    MetricCheckConfig,
    MetricParams,
    PythonCheckConfig,
    QualityDimension,
    RangeThreshold,
    RawSource,
    SchemaValidator,
    SlaConfig,
    SqlCheckConfig,
    TableIdentifier,
    Threshold,
    WindowCheckConfig,
)
from turbine.core.quality.spec_models import (
    BODY_MAP,
    AnomalyCheckBody,
    CheckBodyBase,
    CheckBodyShared,
    MetricCheckBody,
    PythonCheckBody,
    SchemaCheckBody,
    SqlCheckBody,
)
from turbine.core.shared import FilterExpr

ODCS_METRIC_MAP: dict[str, str] = {
    "nullValues": "missing",
    "missingValues": "missing",
    "invalidValues": "invalid",
    "duplicateValues": "duplicate",
    "rowCount": "row_count",
}


def sla_element_schema_name(element: str) -> str | None:
    """Return the schema/table part of an SLA element like ``public.orders.updated_at``."""
    if "." not in element:
        return None
    return element.rsplit(".", maxsplit=1)[0]


def sla_element_column_name(element: str) -> str:
    """Return the column part of an SLA element."""
    return element.rsplit(".", maxsplit=1)[-1]


def schema_match_names(schema: SchemaObject) -> frozenset[str]:
    """Return schema identifiers that can be targeted by SLA elements."""
    return frozenset(name for name in (schema.name, schema.physicalName) if name)


def sla_targets_schema(element: str, schema: SchemaObject) -> bool:
    """Return True when an SLA element targets the given schema object."""
    target = sla_element_schema_name(element)
    if target is None:
        return True
    return target in schema_match_names(schema)


def targeted_sla(sla: object, schema: SchemaObject) -> ServiceLevelAgreementProperty | None:
    """Return the SLA as a typed object when it targets this schema."""
    if not isinstance(sla, ServiceLevelAgreementProperty):
        return None
    if not sla.element:
        return None
    if not sla_targets_schema(sla.element, schema):
        return None
    return sla


def parse_filter_expr(raw: str | None, dialect: str = "duckdb") -> FilterExpr | None:
    """Parse a filter body into :class:`FilterExpr`; return ``None`` when empty.

    The ODCS reader doesn't know the runtime dialect (that arrives with the
    datasource), so parsing defaults to ``duckdb`` here. A later
    ``read_resolved`` pass re-parses with the actual datasource dialect if
    it differs — the round-trip is cheap.
    """
    if not raw:
        return None
    return FilterExpr.parse(raw, dialect=dialect)


def extract_custom_properties(contract: OpenDataContractStandard) -> tuple[CustomProperty, ...]:
    """Convert ODCS ``customProperties`` entries into :class:`CustomProperty` tuples.

    Skips entries with no ``property`` name. Values are stringified so
    downstream code (deprecation headers, codegen extras) can rely on
    consistent types regardless of the YAML literal form.
    """
    if not contract.customProperties:
        return ()
    return tuple(
        CustomProperty(property=entry.property, value=str(entry.value))
        for entry in contract.customProperties
        if entry.property and entry.value is not None
    )


def parse_optional_dimension(raw: str | None) -> QualityDimension | None:
    """Parse a ``dimension`` value, returning ``None`` when missing or unparseable.

    A missing or invalid value leaves ``CheckDef.dimension`` as ``None`` so the
    ``CheckDimensionRequiredRule`` lint rule can diagnose it. Previously this
    helper silently fell back to ``ACCURACY``.
    """
    if not raw:
        return None
    try:
        return QualityDimension.parse(raw)
    except TurbineError:
        return None


@dataclass(frozen=True, slots=True)
class DerivedCheckRule:
    """Maps a schema constraint to the metric + dimension it implies.

    `default_threshold` makes an implicit verdict explicit: a `required: true`
    column means zero missing rows are allowed, so the derived `missing` check
    carries `mustBe: 0`. Structural derivations (schema) stay unthresholded.
    """

    metric: str
    dimension: QualityDimension
    default_threshold: ExactThreshold | None = None

    def to_check(
        self, column: str | None, source: CheckSource, params: MetricParams | None = None
    ) -> CheckDef:
        check = CheckDef.metric(self.metric, column, self.dimension, source, params=params)
        if self.default_threshold is None:
            return check
        return replace(check, threshold=self.default_threshold)


ZERO_VIOLATIONS = ExactThreshold(value=0)

REQUIRED_RULE = DerivedCheckRule(
    metric="missing", dimension=QualityDimension.COMPLETENESS, default_threshold=ZERO_VIOLATIONS
)
UNIQUE_RULE = DerivedCheckRule(
    metric="duplicate", dimension=QualityDimension.ACCURACY, default_threshold=ZERO_VIOLATIONS
)
VALIDITY_RULE = DerivedCheckRule(
    metric="invalid", dimension=QualityDimension.ACCURACY, default_threshold=ZERO_VIOLATIONS
)
SCHEMA_RULE = DerivedCheckRule(metric="schema", dimension=QualityDimension.CONSISTENCY)


def parse_with_dedup[EnumT](  # noqa: PLR0913
    parser: Callable[[str], EnumT],
    raw: str | None,
    *,
    default: EnumT,
    field_path: str,
    source: RawSource,
    sink: DiagnosticSink,
    flagged_paths: frozenset[str],
) -> EnumT:
    """Run ``.parse()``, skipping the diagnostic if the schema validator already flagged the path.

    Returns *default* when *raw* is None or the parser raises ``TurbineError``.
    When emitting, the parser's own diagnostic (with its fuzzy suggestion) is
    re-annotated with the precise value range from the source map.
    """
    if raw is None:
        return default
    try:
        return parser(raw)
    except TurbineError as exc:
        if field_path in flagged_paths:
            return default
        text_range = source.source_map.range_for_value(field_path)
        primary_span = Span(path=source.path, range=text_range)
        for diag in exc.diagnostics:
            primary = Annotation(span=primary_span, message=diag.message, is_primary=True)
            sink.add(replace(diag, annotations=(primary,)))
        return default


def coerce_exact_threshold(value: object, *, negate: bool = False) -> ExactThreshold | None:
    """Build an ``ExactThreshold`` from an ODCS ``mustBe``/``mustNotBe`` value.

    The JSON schema extension narrows ``mustBe`` to number/boolean/null, so
    anything else here means the schema validator already flagged it — we
    silently drop the threshold. ``None`` inputs also yield ``None``.
    """
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, int | float):
        return ExactThreshold(value=float(value), negate=negate)
    return None


def safely[T](  # noqa: PLR0913
    fn: Callable[[], T],
    *,
    fallback: T,
    field_path: str,
    operation: str,
    source: RawSource,
    sink: DiagnosticSink,
) -> T:
    """Execute *fn*, converting any unexpected exception into a diagnostic.

    The adapter boundary must be total over JSON-schema-valid input: every
    raise here means a shape we didn't anticipate slipped through our
    coercions. The traceback is logged, an ``INTERNAL`` diagnostic is
    anchored at *field_path* (walking up to the nearest known parent if the
    exact key isn't in the source map), and *fallback* is returned so the
    rest of the contract still renders.
    """
    try:
        return fn()
    except Exception as exc:  # noqa: BLE001
        logger.opt(exception=exc).error(f"ODCS reader failed during {operation}")
        range_for_key = source.source_map.range_for_key
        text_range = range_for_key(field_path) or resolve_fallback_range(field_path, range_for_key)
        sink.add(
            DiagnosticBuilder.error(DiagnosticId.INTERNAL, f"Turbine could not {operation}: {exc}")
            .span(source.path, text_range)
            .help("this shape is accepted by the ODCS JSON schema but Turbine couldn't process it")
            .build()
        )
        return fallback


@dataclass(frozen=True, slots=True)
class QualitySourceRanges:
    """Source ranges for a quality check's three useful spans.

    The diagnostic span fallback chain prefers ``column`` (squiggle on the
    referenced column), then ``name`` (the check's identity line), then
    ``block`` (the whole quality item). Bundling the trio lets converters
    pass one value through to ``CheckDef`` without four-arg signatures.
    """

    name: TextRange | None = None
    column: TextRange | None = None
    block: TextRange | None = None


class ModelParser(Protocol):
    """Parser port for converting raw YAML into Pydantic models."""

    def parse[T: BaseModel](
        self, model_cls: type[T], source: RawSource, sink: DiagnosticSink
    ) -> T | None:
        """Parse *source* into *model_cls*, emitting diagnostics on failure."""
        ...


class OdcsReader:
    """Parse ODCS DataContract YAML into DatasetSpec instances.

    Each named schema object in the ODCS contract becomes a separate
    DatasetSpec with its columns, quality checks, and incremental config.
    """

    format_label = "odcs"

    def __init__(self, schema_validator: SchemaValidator, model_parser: ModelParser) -> None:
        """Store validation dependencies."""
        self.schema_validator = schema_validator
        self.model_parser = model_parser

    def can_read(self, data: dict[str, Any]) -> bool:
        """Return True if data has kind: DataContract, indicating ODCS format."""
        return data.get("kind") == "DataContract"

    def read(self, source: RawSource, sink: DiagnosticSink) -> tuple[DatasetSpec, ...]:
        """Parse the ODCS contract and return one DatasetSpec per named schema object.

        Runs JSON Schema validation, parses the pydantic model, extracts schemas,
        and builds columns and checks for each. Each extraction step is wrapped
        in ``safely`` so any shape the JSON schema accepts but our coercions
        didn't anticipate becomes a diagnostic instead of an internal error.
        """
        logger.debug(f"Reading ODCS contract: {source.path}")
        contract, schemas, flagged_paths = self.parse_and_validate(source, sink)
        if contract is None or schemas is None:
            return ()
        logger.debug(f"Pydantic model validated for {source.path}")
        sla_config = safely(
            lambda: self.extract_sla_config(contract, source),
            fallback=SlaConfig(properties=()),
            field_path="slaProperties",
            operation="extract SLA properties",
            source=source,
            sink=sink,
        )
        status = parse_with_dedup(
            ContractStatus.parse,
            contract.status,
            default=ContractStatus.DRAFT,
            field_path="status",
            source=source,
            sink=sink,
            flagged_paths=flagged_paths,
        )
        metadata = ContractMetadata(
            contract_id=contract.id or "unknown",
            version=contract.version or "0.0.0",
            status=status,
            owner=None,
            name=contract.name,
            source_format=self.format_label,
            source_path=source.path,
            is_contract=True,
            domain=contract.domain,
            custom_properties=extract_custom_properties(contract),
            description_purpose=contract.description.purpose if contract.description else None,
            description_usage=contract.description.usage if contract.description else None,
            description_source_range=source.source_map.range_for_key("description"),
            description_purpose_source_range=source.source_map.range_for_key("description.purpose"),
            contract_id_source_range=source.source_map.range_for_value("id"),
            domain_source_range=source.source_map.range_for_value("domain"),
            version_source_range=source.source_map.range_for_value("version"),
        )
        self.warn_unqualified_sla_elements(contract, source, sink)
        SlaIntake(format_label=self.format_label, source_path=source.path).emit_diagnostics(
            contract, source=source, sink=sink
        )
        specs = [
            self.build_spec(schema, idx, source, sink, flagged_paths, metadata, sla_config, contract)
            for idx, schema in enumerate(schemas)
        ]
        for dataset_spec in specs:
            logger.debug(f"Converted to DatasetSpec: {dataset_spec.table}")
        logger.trace(f"DatasetSpec fields: {specs}")
        return tuple(specs)

    def build_spec(  # noqa: PLR0913
        self,
        schema: SchemaObject,
        idx: int,
        source: RawSource,
        sink: DiagnosticSink,
        flagged_paths: frozenset[str],
        metadata: ContractMetadata,
        sla_config: SlaConfig,
        contract: OpenDataContractStandard,
    ) -> DatasetSpec:
        """Build one DatasetSpec for a single schema object, guarded by ``safely``."""
        schema_label = schema.name or f"schema[{idx}]"
        table = parse_with_dedup(
            TableIdentifier.parse,
            schema.name,
            default=TableIdentifier(schema="public", table="unknown"),
            field_path=f"schema.{idx}.name",
            source=source,
            sink=sink,
            flagged_paths=flagged_paths,
        )
        columns = safely(
            lambda: tuple(self.build_columns(schema, source, sink, flagged_paths, idx)),
            fallback=(),
            field_path=f"schema.{idx}.properties",
            operation=f"build columns for {schema_label}",
            source=source,
            sink=sink,
        )
        derived_checks = safely(
            lambda: self.derive_checks(schema, source, idx),
            fallback=[],
            field_path=f"schema.{idx}",
            operation=f"derive checks for {schema_label}",
            source=source,
            sink=sink,
        )
        quality_checks = safely(
            lambda: self.parse_quality_checks(schema, source, sink, idx),
            fallback=[],
            field_path=f"schema.{idx}.quality",
            operation=f"parse quality checks for {schema_label}",
            source=source,
            sink=sink,
        )
        sla_checks = safely(
            lambda: self.derive_sla_checks(contract, schema, source),
            fallback=[],
            field_path="slaProperties",
            operation=f"derive SLA checks for {schema_label}",
            source=source,
            sink=sink,
        )
        return DatasetSpec(
            table=table,
            columns=columns,
            checks=tuple(derived_checks + quality_checks + sla_checks),
            sla=sla_config,
            metadata=metadata,
            schema_index=idx,
            schema_name_source_range=source.source_map.range_for_value(f"schema.{idx}.name"),
            odcs_schema_name=schema.name,
        )

    @staticmethod
    def warn_unqualified_sla_elements(
        contract: OpenDataContractStandard, source: RawSource, sink: DiagnosticSink
    ) -> None:
        """Warn when an SLA element omits the schema/table qualifier."""
        for index, sla in enumerate(contract.slaProperties or []):
            if not isinstance(sla, ServiceLevelAgreementProperty):
                continue
            if not sla.element or "." in sla.element:
                continue
            text_range = source.source_map.range_for_value(f"slaProperties.{index}.element")
            sink.add(
                DiagnosticBuilder.warning(
                    DiagnosticId.SLA_INVALID_ELEMENT,
                    f"SLA element `{sla.element}` is not schema-qualified",
                )
                .span(source.path, text_range)
                .help(
                    "use `<schema-name>.<column>` where `<schema-name>` matches `schema[].name`, "
                    "for example `public.orders.updated_at`"
                )
                .docs(DiagnosticId.SLA_INVALID_ELEMENT)
                .build()
            )

    def parse_and_validate(
        self, source: RawSource, sink: DiagnosticSink
    ) -> tuple[OpenDataContractStandard | None, list[SchemaObject] | None, frozenset[str]]:
        """Run schema validation, parse the model, and resolve schemas.

        Returns ``(contract, schemas, flagged_paths)`` where *contract* or
        *schemas* may be None on failure, and *flagged_paths* is the set of
        dotted key paths the JSON schema validator flagged (used downstream
        to dedupe adapter-level enum fallbacks).
        """
        flagged_paths = self.schema_validator.validate(source.data, source, sink)
        contract = self.parse_model(source, sink)
        if contract is None:
            return None, None, flagged_paths
        schemas = self.resolve_schemas(contract, source, sink)
        return contract, schemas, flagged_paths

    def parse_model(self, source: RawSource, sink: DiagnosticSink) -> OpenDataContractStandard | None:
        """Parse raw YAML data into the ODCS pydantic model.

        Uses the shared parse_pydantic_model for diagnostic emission.
        If strict parsing fails, attempts a lenient re-parse so downstream
        code still gets a model. Returns None if both fail.
        """
        if result := self.model_parser.parse(OpenDataContractStandard, source, sink):
            return result
        try:
            return OpenDataContractStandard.model_validate(source.data, context={"strict": False})
        except ValidationError:
            return None

    @staticmethod
    def resolve_schemas(
        contract: OpenDataContractStandard, source: RawSource, sink: DiagnosticSink
    ) -> list[SchemaObject] | None:
        """Extract named schema objects from the contract.

        Returns None and emits an error diagnostic if no schemas have a name field.
        """
        schemas = [schema for schema in (contract.schema_ or []) if schema.name]
        if schemas:
            return schemas
        text_range = source.source_map.range_for_key("schema")
        sink.add(
            DiagnosticBuilder.error(
                DiagnosticId.CONTRACT_INVALID_SCHEMA, "Contract has no named schema definitions"
            )
            .span(source.path, text_range)
            .build()
        )
        return None

    @staticmethod
    def build_columns(
        schema: SchemaObject,
        source: RawSource,
        sink: DiagnosticSink,
        flagged_paths: frozenset[str],
        schema_idx: int,
    ) -> list[ColumnDef]:
        """Convert each named SchemaProperty into a ColumnDef with source range."""
        columns: list[ColumnDef] = []
        for position, prop in enumerate(schema.properties or []):
            if not prop.name:
                continue
            name_path = f"schema.{schema_idx}.properties.{position}.name"
            logical_type_path = f"schema.{schema_idx}.properties.{position}.logicalType"
            required_path = f"schema.{schema_idx}.properties.{position}.required"
            primary_key_path = f"schema.{schema_idx}.properties.{position}.primaryKey"
            logical_type = parse_with_dedup(
                LogicalType.parse,
                prop.logicalType,
                default=LogicalType.STRING,
                field_path=logical_type_path,
                source=source,
                sink=sink,
                flagged_paths=flagged_paths,
            )
            columns.append(
                ColumnDef(
                    name=prop.name,
                    logical_type=logical_type,
                    nullable=not (prop.required or False),
                    primary_key=prop.primaryKey or False,
                    position=position,
                    description=str(prop.description) if prop.description else None,
                    tags=tuple(prop.tags) if prop.tags else (),
                    source_range=source.source_map.range_for_key(name_path),
                    example=str(prop.examples[0]) if prop.examples else None,
                    required=prop.required,
                    required_source_range=source.source_map.range_for_value(required_path),
                    primary_key_source_range=source.source_map.range_for_key(primary_key_path),
                )
            )
        return columns

    def derive_checks(self, schema: SchemaObject, source: RawSource, schema_idx: int) -> list[CheckDef]:
        """Generate quality checks from schema property constraints.

        The derived schema check anchors on ``schema[idx].name`` so a failure
        squiggles the failing schema, not line 1 of the contract.
        """
        check_source = CheckSource(format_label=self.format_label, path=source.path, is_contract=True)
        checks = [
            check
            for prop in (schema.properties or [])
            if prop.name
            for check in self.checks_for_property(prop, check_source)
        ]
        if schema.properties:
            schema_range = source.source_map.range_for_value(f"schema.{schema_idx}.name")
            checks.append(replace(SCHEMA_RULE.to_check(None, check_source), source_range=schema_range))
        return checks

    def checks_for_property(self, prop: SchemaProperty, check_source: CheckSource) -> list[CheckDef]:
        """Derive checks from a single schema property's constraints."""
        checks: list[CheckDef] = []
        if prop.required:
            checks.append(REQUIRED_RULE.to_check(prop.name, check_source))
        if prop.unique or prop.primaryKey:
            checks.append(UNIQUE_RULE.to_check(prop.name, check_source))
        if validity_params := self.extract_validity_params(prop):
            checks.append(VALIDITY_RULE.to_check(prop.name, check_source, params=validity_params))
        return checks

    def derive_sla_checks(
        self, contract: OpenDataContractStandard, schema: SchemaObject, source: RawSource
    ) -> list[CheckDef]:
        """Project this schema's SLA-derived checks via :class:`SlaIntake`.

        Thin wrapper so :func:`safely` callers (and tests that fault-inject on
        this method) keep a stable target.  The SlaIntake module handles all
        per-property logic — freshness, latency, retention (with optional
        upper bound), frequency (duration + cron), timeOfAvailability — and
        emits zero CheckDefs for metadata-only properties.
        """
        intake = SlaIntake(format_label=self.format_label, source_path=source.path)
        return list(intake.build_sla_checks(contract, schema, source))

    @staticmethod
    def extract_validity_params(prop: SchemaProperty) -> MetricParams | None:
        """Map ODCS logicalTypeOptions to MetricParams via Pydantic alias resolution.

        Handles ``exclusiveMinimum`` / ``exclusiveMaximum`` by converting them
        to ``valid_min`` / ``valid_max`` plus ``invalid_values`` containing the
        boundary, so values equal to the boundary are rejected.
        """
        if not prop.logicalTypeOptions:
            return None
        options = dict(prop.logicalTypeOptions)
        boundary_exclusions: list[int | float] = []
        if (exc_min := options.pop("exclusiveMinimum", None)) is not None:
            options.setdefault("minimum", exc_min)
            boundary_exclusions.append(exc_min)
        if (exc_max := options.pop("exclusiveMaximum", None)) is not None:
            options.setdefault("maximum", exc_max)
            boundary_exclusions.append(exc_max)
        if boundary_exclusions:
            existing = list(options.get("invalid_values") or [])
            existing.extend(boundary_exclusions)
            options["invalid_values"] = existing
        return MetricParams.from_schema_property(options)

    def parse_quality_checks(
        self, schema: SchemaObject, source: RawSource, sink: DiagnosticSink, schema_idx: int
    ) -> list[CheckDef]:
        """Parse ODCS quality blocks from schema-level and property-level into CheckDefs.

        The JSON schema validator covers the contract envelope; the
        ``implementation:`` block of custom/turbine checks is validated separately
        by ``convert_custom_quality`` against the QualitySpec ``check_item`` def,
        so missing/mistyped fields surface as diagnostics here.
        """
        check_source = CheckSource(format_label=self.format_label, path=source.path, is_contract=True)
        table_checks = [
            check
            for dq_idx, dq_item in enumerate(schema.quality or [])
            if (
                check := self.convert_quality_item(
                    dq_item, None, check_source, source, sink, f"schema.{schema_idx}.quality.{dq_idx}"
                )
            )
        ]
        column_checks: list[CheckDef] = []
        for prop_idx, prop in enumerate(schema.properties or []):
            if not prop.name:
                continue
            for dq_idx, dq_item in enumerate(prop.quality or []):
                field_path = f"schema.{schema_idx}.properties.{prop_idx}.quality.{dq_idx}"
                check = self.convert_quality_item(
                    dq_item, prop.name, check_source, source, sink, field_path
                )
                if check is not None:
                    column_checks.append(check)
        return table_checks + column_checks

    def quality_name_source_range(self, source: RawSource, field_path: str) -> TextRange | None:
        """Range for a quality item's ``name:`` value, else a discriminator key.

        Priority: explicit ``name:`` value, then ``metric:`` (library checks),
        then ``type:`` (sql / custom checks). Returns ``None`` only when none
        of those keys exist in the source map.
        """
        source_map = source.source_map
        for sub_key in ("name", "metric", "type"):
            text_range = source_map.range_for_value(f"{field_path}.{sub_key}")
            if text_range is not None:
                return text_range
        return None

    def quality_column_source_range(self, source: RawSource, field_path: str) -> TextRange | None:
        """Range for the check's ``column:`` value, scanning where ODCS allows it.

        Library/sql checks place ``column`` at the top level of the quality
        item; custom turbine checks nest it under ``implementation``. Try both.
        """
        source_map = source.source_map
        for sub_path in ("column", "implementation.column"):
            text_range = source_map.range_for_value(f"{field_path}.{sub_path}")
            if text_range is not None:
                return text_range
        return None

    def convert_quality_item(  # noqa: PLR0913
        self,
        dq: DataQuality,
        column: str | None,
        check_source: CheckSource,
        source: RawSource,
        sink: DiagnosticSink,
        field_path: str,
    ) -> CheckDef | None:
        """Convert a single ODCS DataQuality entry into a CheckDef.

        Handles library, sql, and custom (turbine engine) types. Returns
        None for unsupported or skipped entries. Library and SQL coercions
        are silent — the contract JSON schema covers them. Custom/turbine
        checks run an extra ``implementation:`` validation pass that emits
        its own diagnostics into *sink*.
        """
        dimension = parse_optional_dimension(dq.dimension)
        threshold = self.extract_odcs_threshold(dq)
        ranges = QualitySourceRanges(
            name=self.quality_name_source_range(source, field_path),
            column=self.quality_column_source_range(source, field_path),
            block=source.source_map.range_for_value(field_path),
        )

        if dq.type == "library":
            return self.convert_library_quality(dq, column, check_source, dimension, threshold, ranges)
        if dq.type == "sql":
            return self.convert_sql_quality(dq, column, check_source, dimension, threshold, ranges)
        if dq.type == "custom":
            return self.convert_custom_quality(
                dq, column, check_source, dimension, threshold, ranges, source, sink, field_path
            )

        logger.warning(f"Unsupported ODCS quality type '{dq.type}', skipping")
        return None

    @staticmethod
    def convert_library_quality(  # noqa: PLR0913
        dq: DataQuality,
        column: str | None,
        check_source: CheckSource,
        dimension: QualityDimension | None,
        threshold: Threshold | None,
        ranges: QualitySourceRanges,
    ) -> CheckDef | None:
        """Convert an ODCS library-type quality item to a metric CheckDef."""
        if not dq.metric:
            logger.warning("Library quality item has no metric, skipping")
            return None
        turbine_metric = ODCS_METRIC_MAP.get(dq.metric, dq.metric)
        name = dq.name or (f"{turbine_metric}:{column}" if column else turbine_metric)
        params: MetricParams | None = None
        if dq.arguments:
            try:
                params = MetricParams.model_validate(dict(dq.arguments))
            except ValidationError:
                return None
        return CheckDef(
            name=name,
            check_type=turbine_metric,
            dimension=dimension,
            category=CheckCategory.METRIC,
            config=MetricCheckConfig(metric=turbine_metric, column=column, params=params),
            source=check_source,
            threshold=threshold,
            unit=dq.unit,
            column=column,
            source_range=ranges.block,
            column_source_range=ranges.column,
            name_source_range=ranges.name,
        )

    @staticmethod
    def convert_sql_quality(  # noqa: PLR0913
        dq: DataQuality,
        column: str | None,
        check_source: CheckSource,
        dimension: QualityDimension | None,
        threshold: Threshold | None,
        ranges: QualitySourceRanges,
    ) -> CheckDef | None:
        """Convert an ODCS sql-type quality item to a SQL CheckDef with inline query."""
        if not dq.query:
            logger.warning("SQL quality item has no query, skipping")
            return None
        name = dq.name or "sql"
        return CheckDef(
            name=name,
            check_type="sql",
            dimension=dimension,
            category=CheckCategory.SQL,
            config=SqlCheckConfig(file_path=Path(), params={}, query=dq.query),
            source=check_source,
            threshold=threshold,
            unit=dq.unit,
            column=column,
            source_range=ranges.block,
            column_source_range=ranges.column,
            name_source_range=ranges.name,
        )

    @staticmethod
    def convert_custom_quality(  # noqa: PLR0913
        dq: DataQuality,
        column: str | None,
        check_source: CheckSource,
        dimension: QualityDimension | None,
        threshold: Threshold | None,
        ranges: QualitySourceRanges,
        source: RawSource,
        sink: DiagnosticSink,
        field_path: str,
    ) -> CheckDef | None:
        """Convert an ODCS custom-type quality item; only ``engine: turbine`` is supported."""
        if dq.engine != "turbine":
            sink.add(
                DiagnosticBuilder.error(
                    DiagnosticId.CHECK_DEFINITION_ERROR,
                    f"unsupported custom check engine `{dq.engine}`; only `engine: turbine` is executed",
                )
                .span(source.path, ranges.block)
                .help("set `engine: turbine`, or remove this check if another tool runs it")
                .build()
            )
            return None
        if not validate_implementation(
            ImplementationValidationRequest(
                implementation=dq.implementation if isinstance(dq.implementation, dict) else None,
                field_path=field_path,
                source=source,
                sink=sink,
                outer_dimension=dq.dimension,
                outer_column=column,
            )
        ):
            return None
        parsed = OdcsReader.parse_turbine_implementation(dq.implementation, column, dq.dimension)
        if parsed is None:
            return None
        check_type, body = parsed
        category = CheckCategory.from_type_string(check_type)
        name = dq.name or body.name or (f"{check_type}:{column}" if column else check_type)
        try:
            config = OdcsReader.body_to_config(body, check_type, name, column)
        except TurbineError as exc:
            sink.add(
                DiagnosticBuilder.error(DiagnosticId.CHECK_DEFINITION_ERROR, str(exc))
                .span(source.path, ranges.block)
                .build()
            )
            return None
        # Schema checks are shape-only; row scope and threshold operators do not apply.
        body_column = body.column if isinstance(body, CheckBodyBase) else None
        body_filter = body.filter if isinstance(body, CheckBodyBase) else None
        body_window_raw = body.window if isinstance(body, CheckBodyBase) else None
        body_threshold = body.to_threshold() if isinstance(body, CheckBodyBase) else None
        window = Duration.parse(body_window_raw) if body_window_raw else None
        return CheckDef(
            name=name,
            check_type=check_type,
            dimension=dimension,
            category=category,
            config=config,
            source=check_source,
            threshold=body_threshold or threshold,
            unit=getattr(body, "unit", None) or dq.unit,
            compare_mode=getattr(body, "compare", "count"),
            column=column or body_column,
            window=window,
            filter=parse_filter_expr(body_filter),
            source_range=ranges.block,
            column_source_range=ranges.column,
            name_source_range=ranges.name,
        )

    @staticmethod
    def parse_turbine_implementation(
        implementation: str | dict[str, Any] | None, column: str | None, dimension: str | None
    ) -> tuple[str, CheckBodyShared] | None:
        """Parse a custom/turbine implementation dict into (check_type, body).

        Returns None for non-dict implementations, missing ``check`` field, or
        a Pydantic shape mismatch; the JSON schema validator has already
        emitted the user-facing diagnostic for the last case.
        """
        if not isinstance(implementation, dict):
            logger.warning("Custom/turbine quality item has no dict implementation, skipping")
            return None
        check_type = implementation.get("check")
        if not isinstance(check_type, str):
            logger.warning("Custom/turbine implementation missing 'check' field, skipping")
            return None
        body_cls = BODY_MAP.get(check_type, MetricCheckBody)
        body_fields = {key: val for key, val in implementation.items() if key != "check"}
        body_fields.setdefault("dimension", dimension or "accuracy")
        if column and body_cls is not SchemaCheckBody:
            body_fields.setdefault("column", column)
        try:
            body = body_cls.model_validate(body_fields)
        except ValidationError as exc:
            logger.warning(
                "Custom/turbine implementation for check {!r} failed validation, skipping: {}",
                check_type,
                exc,
            )
            return None
        return check_type, body

    @staticmethod
    def body_to_config(
        body: CheckBodyShared, check_type: str, name: str, column: str | None
    ) -> MetricCheckConfig | SqlCheckConfig | PythonCheckConfig | WindowCheckConfig:
        """Convert a check body into the matching CheckConfig."""
        match body:
            case SchemaCheckBody() as schema_body:
                return schema_body.to_config()
            case MetricCheckBody() as metric_body:
                return metric_body.to_config(check_type, column or metric_body.column)
            case SqlCheckBody() as sql_body:
                return sql_body.to_config(name)
            case PythonCheckBody() as python_body:
                return python_body.to_config()
            case AnomalyCheckBody() as anomaly_body:
                return anomaly_body.to_config()
            case _:  # pragma: no cover
                raise TypeError(f"Unexpected body type: {type(body).__name__}")

    @staticmethod
    def extract_odcs_threshold(dq: DataQuality) -> Threshold | None:
        """Convert ODCS threshold fields (mustBe, mustBeGreaterOrEqualTo, etc.) to a Threshold.

        ``mustBe`` and ``mustNotBe`` are narrowed to numeric by the JSON
        schema extension layer, so a non-numeric value here means the schema
        validator already emitted a diagnostic and we silently skip the
        threshold.
        """
        if (exact := coerce_exact_threshold(dq.mustBe)) is not None:
            return exact
        if (exact := coerce_exact_threshold(dq.mustNotBe, negate=True)) is not None:
            return exact
        comparison_operators: list[tuple[float | int | None, Literal["gt", "gte", "lt", "lte"]]] = [
            (dq.mustBeGreaterThan, "gt"),
            (dq.mustBeGreaterOrEqualTo, "gte"),
            (dq.mustBeLessThan, "lt"),
            (dq.mustBeLessOrEqualTo, "lte"),
        ]
        for value, operator in comparison_operators:
            if value is not None:
                return ComparisonThreshold(operator=operator, value=value)
        if (between := dq.mustBeBetween) is not None:
            return RangeThreshold(
                bounds=BetweenRange(greater_than_or_equal=between[0], less_than_or_equal=between[1])
            )
        if (not_between := dq.mustNotBeBetween) is not None:
            return RangeThreshold(
                bounds=BetweenRange(
                    greater_than_or_equal=not_between[0], less_than_or_equal=not_between[1]
                ),
                negate=True,
            )
        return None

    def extract_sla_config(self, contract: OpenDataContractStandard, source: RawSource) -> SlaConfig:
        """Project the contract's SLA properties via :class:`SlaIntake`.

        Thin wrapper kept so the existing ``safely()`` callsite (and tests
        that fault-inject on this method) keep a stable target.
        """
        intake = SlaIntake(format_label=self.format_label, source_path=source.path)
        return intake.build_sla_config(contract, source)
