"""ODCS ``slaProperties`` to ``SlaConfig`` + ``CheckDef`` projection.

One class owns the whole table:

* Five **temporal** properties (``latency`` / ``freshness`` / ``retention`` /
  ``frequency`` / ``timeOfAvailability``) emit ``CheckDef``s; the first four
  share :class:`FreshnessPredicate` at the SQL layer, ``retention`` gets
  :class:`RetentionPredicate` plus an optional second CheckDef when
  ``valueExt`` is set (GDPR-style upper bound).
* Four **metadata** properties (``availability`` / ``generalAvailability`` /
  ``endOfSupport`` / ``endOfLife``) parse into typed metadata on
  :class:`SlaConfig.lifecycle`; no CheckDef is emitted.

Replaces the inline ``derive_sla_checks`` / ``build_freshness_check`` /
``build_retention_check`` / ``parse_sla_value`` / ``extract_sla_config``
helpers that used to live in :mod:`reader`.  Old Jinja-SQL retention path
is gone; everything routes through the predicate factory now.
"""

from __future__ import annotations

import re
from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path

from croniter import croniter
from open_data_contract_standard.model import (
    OpenDataContractStandard,
    SchemaObject,
    ServiceLevelAgreementProperty,
)

from turbine.core.building_blocks import DiagnosticBuilder, DiagnosticId, DiagnosticSink
from turbine.core.common import (
    CheckCategory,
    CheckDef,
    CheckSource,
    LifecycleMetadata,
    MetricCheckConfig,
    MetricName,
    Percent,
    QualityDimension,
    SlaConfig,
    SlaProperty,
)
from turbine.core.common.dataset_spec.thresholds import ComparisonThreshold

UNIT_ALIASES: dict[str, str] = {
    "s": "second",
    "sec": "second",
    "seconds": "second",
    "second": "second",
    "m": "minute",
    "min": "minute",
    "minutes": "minute",
    "minute": "minute",
    "h": "hour",
    "hr": "hour",
    "hours": "hour",
    "hour": "hour",
    "d": "day",
    "days": "day",
    "day": "day",
    "w": "week",
    "weeks": "week",
    "week": "week",
    "months": "month",
    "month": "month",
    "y": "year",
    "yr": "year",
    "years": "year",
    "year": "year",
}


UNIT_TO_SECONDS: dict[str, int] = {
    "second": 1,
    "minute": 60,
    "hour": 3600,
    "day": 86400,
    "week": 604800,
    "month": 2592000,
    "year": 31536000,
}


METADATA_PROPERTIES: frozenset[str] = frozenset(
    {"availability", "generalAvailability", "endOfSupport", "endOfLife"}
)


LIFECYCLE_DATE_PROPERTIES: frozenset[str] = frozenset(
    {"generalAvailability", "endOfSupport", "endOfLife"}
)


CRON_PRESET_ALIASES: dict[str, str] = {
    "daily": "@daily",
    "hourly": "@hourly",
    "weekly": "@weekly",
    "monthly": "@monthly",
    "yearly": "@yearly",
    "annually": "@yearly",
}


TIME_OF_AVAILABILITY_RE = re.compile(
    r"^(?P<hour>\d{2}):(?P<minute>\d{2})(?::\d{2})?(?P<offset>Z|[+-]\d{2}(?::?\d{2})?)?$"
)


OFFSET_HOUR_DIGITS = 2

END_OF_LIFE_NEAR_DAYS = 30


def normalize_unit(raw: str | None) -> str | None:
    """Return the long-form unit name (``day``) for an alias (``d`` / ``days``)."""
    if raw is None:
        return None
    return UNIT_ALIASES.get(raw.lower())


def seconds_for_unit(unit: str) -> int:
    """Seconds-per-unit multiplier for a normalized unit name."""
    return UNIT_TO_SECONDS.get(unit, 86400)


def parse_lifecycle_value(raw: object) -> datetime | None:
    """Parse ``generalAvailability`` / ``endOfSupport`` / ``endOfLife`` value.

    Accepts ISO 8601 dates and datetimes.  Bare dates become midnight UTC;
    naive datetimes are assumed UTC; explicit offsets are preserved.  Rejects
    anything ``datetime.fromisoformat`` won't take.
    """
    if not isinstance(raw, str):
        return None
    text = raw.strip()
    try:
        parsed = datetime.fromisoformat(text)
    except ValueError:
        try:
            parsed = datetime.combine(datetime.fromisoformat(text).date(), datetime.min.time())
        except ValueError:
            return None
    return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=UTC)


def parse_availability_value(raw: object) -> Percent | None:
    """Parse ``availability`` value into a 0-1 fraction.

    ``'99.9%'`` strips the percent and normalizes; bare numbers ``> 1`` are
    treated as percentages and divided by 100; fractions ``<= 1`` are kept.
    """
    number = coerce_to_float(raw)
    if number is None:
        return None
    fraction = number / 100 if number > 1 else number
    return Percent(value=fraction)


def coerce_to_float(raw: object) -> float | None:
    """Convert ``raw`` to ``float``, stripping a trailing ``%`` from strings."""
    if isinstance(raw, bool):
        return None
    if isinstance(raw, (int, float)):
        return float(raw)
    if not isinstance(raw, str):
        return None
    text = raw.strip().rstrip("%").strip()
    try:
        return float(text)
    except ValueError:
        return None


def parse_value_and_unit(raw_value: object, raw_unit: str | None) -> tuple[float | None, str | None]:
    """Resolve an SLA ``value`` and ``unit`` pair into ``(number, normalized-unit)``.

    Accepts the canonical numeric form (``value: 24, unit: hour``) and the
    shorthand string form (``value: "1 day"``) where the unit is inlined in
    the value.  An explicit ``unit`` argument wins over an inlined one, so
    authors can override.  Returns ``(None, normalized_unit)`` when *raw_value*
    isn't parseable as a number — callers treat ``None`` as "skip".
    """
    if isinstance(raw_value, str) and " " in raw_value.strip():
        head, _, tail = raw_value.strip().partition(" ")
        number = coerce_to_float(head)
        inline_unit = tail.strip() or None
        chosen_unit = raw_unit if raw_unit is not None else inline_unit
        return number, normalize_unit(chosen_unit) if chosen_unit else None
    number = coerce_to_float(raw_value)
    return number, normalize_unit(raw_unit)


def normalize_cron_schedule(schedule: str) -> str | None:
    """Map turbine-side bare aliases (``daily``) to croniter-friendly form.

    Returns ``None`` if the schedule isn't parseable by croniter even after
    alias expansion.
    """
    candidate = CRON_PRESET_ALIASES.get(schedule.strip().lower(), schedule.strip())
    return candidate if croniter.is_valid(candidate) else None


@dataclass(frozen=True, slots=True)
class TimeOfAvailability:
    """Translated time-of-day SLA value: ``HH:MM[:SS][offset]`` → cron + tz."""

    schedule: str
    tz: str


def translate_time_of_availability(value: str) -> TimeOfAvailability | None:
    """Translate ``09:00-08:00`` / ``17:00Z`` / ``07:30`` into a cron schedule + tz.

    Returns ``None`` when the input doesn't match the accepted shape
    (``HH:MM`` with optional seconds + offset).  Bare times default to UTC.
    """
    if not isinstance(value, str):
        return None
    match = TIME_OF_AVAILABILITY_RE.match(value.strip())
    if match is None:
        return None
    hour = int(match.group("hour"))
    minute = int(match.group("minute"))
    offset_raw = match.group("offset")
    schedule = f"{minute} {hour} * * *"
    tz = "UTC" if offset_raw in (None, "Z") else iana_zone_for_offset(offset_raw)
    return TimeOfAvailability(schedule=schedule, tz=tz or "UTC")


def iana_zone_for_offset(offset: str) -> str | None:
    """Best-effort fixed-offset zone for ``+02:00`` / ``-08:00`` style strings.

    Returns ``Etc/GMT+N`` (POSIX-style with inverted sign) which is what the
    architecture specified; falls back to ``UTC`` for malformed input.
    """
    sign = -1 if offset.startswith("+") else 1
    digits = offset.lstrip("+-").replace(":", "")
    if len(digits) < OFFSET_HOUR_DIGITS or not digits[:OFFSET_HOUR_DIGITS].isdigit():
        return "UTC"
    hours = int(digits[:OFFSET_HOUR_DIGITS])
    return f"Etc/GMT{'+' if sign > 0 else '-'}{hours}"


@dataclass(frozen=True, slots=True)
class SlaIntake:
    """Project ODCS ``slaProperties`` onto ``SlaConfig`` and per-schema ``CheckDef``s.

    Initialise once per reader instance with the contract source's
    ``format_label`` and on-disk ``path``.  Each ``build_*`` call returns
    immutable values; the intake itself is stateless.
    """

    format_label: str
    source_path: Path

    @property
    def check_source(self) -> CheckSource:
        return CheckSource(format_label=self.format_label, path=self.source_path, is_contract=True)

    def build_sla_config(self, contract: OpenDataContractStandard, source: object = None) -> SlaConfig:
        """Project ``slaProperties`` into ``SlaConfig`` (typed metadata + property list).

        ``source`` accepts a ``RawSource | None`` so source ranges flow through
        when available; in tests the parameter is ``None`` and ranges stay
        empty.  Metadata-only properties land on ``lifecycle``; behavioural
        properties land on ``properties`` with their unit normalized.
        """
        del source
        properties: list[SlaProperty] = []
        lifecycle = LifecycleMetadata()
        for sla in self.iter_slas(contract):
            name = sla.property or ""
            if name in METADATA_PROPERTIES:
                lifecycle = self.fold_into_lifecycle(lifecycle, name, sla.value)
                continue
            properties.append(self.to_sla_property(sla))
        return SlaConfig(properties=tuple(properties), lifecycle=lifecycle)

    def build_sla_checks(
        self, contract: OpenDataContractStandard, schema: SchemaObject, source: object = None
    ) -> tuple[CheckDef, ...]:
        """Emit zero or more ``CheckDef``s per SLA entry targeting *schema*.

        ``retention`` with ``valueExt`` emits two checks (lower + upper
        bound).  Metadata-only properties emit none.  SLA entries targeting a
        different schema are skipped silently — the targeted-schema filter
        keeps cross-table SLAs out of every dataset's check list.
        """
        del source
        checks: list[CheckDef] = []
        for sla in self.iter_slas(contract):
            checks.extend(self.derive_checks_for(sla, schema))
        return tuple(checks)

    def iter_slas(self, contract: OpenDataContractStandard) -> list[ServiceLevelAgreementProperty]:
        """Return slaProperties as typed objects, dropping anything not parseable."""
        return [
            sla
            for sla in (contract.slaProperties or [])
            if isinstance(sla, ServiceLevelAgreementProperty)
        ]

    def emit_diagnostics(
        self,
        contract: OpenDataContractStandard,
        source: object = None,
        sink: DiagnosticSink | None = None,
    ) -> None:
        """Emit parse-time diagnostics about the contract's SLA section.

        Three families:

        * **Retired property**: any literal ``endOfBusinessDay`` entry gets an
          ERROR diagnostic that names ``timeOfAvailability`` as the replacement.
        * **Deprecated alias**: a top-level ``slaDefaultElement:`` field (gone
          in ODCS 4.0) gets an INFO diagnostic so authors can clean it up
          before the next major.
        * **Lifecycle state**: parsed lifecycle dates drive four time-of-day
          diagnostics — pre-live (``generalAvailability`` future), post-end
          (``endOfSupport`` past, ``endOfLife`` past), and near-EoL
          (``endOfLife`` < 30 days from now).  Wall-clock is read from
          ``datetime.now(tz=UTC)`` so tests can drive it via ``freezegun``.
        """
        del source
        if sink is None:
            return
        self.emit_retired_property_diagnostics(contract, sink)
        self.emit_default_element_diagnostic(contract, sink)
        self.emit_lifecycle_state_diagnostics(contract, sink)

    def emit_retired_property_diagnostics(
        self, contract: OpenDataContractStandard, sink: DiagnosticSink
    ) -> None:
        """Emit an ERROR for any ``endOfBusinessDay`` SLA entry with the migration recipe."""
        for sla in self.iter_slas(contract):
            if sla.property != "endOfBusinessDay":
                continue
            sink.add(
                DiagnosticBuilder.error(
                    DiagnosticId.SLA_END_OF_BUSINESS_DAY_RETIRED,
                    "`endOfBusinessDay` is not a recognised SLA property",
                )
                .help(
                    "use `timeOfAvailability` instead; replace the numeric value+unit "
                    "with an `HH:MM[:SS][offset]` time-of-day string and drop `unit:`."
                )
                .docs(DiagnosticId.SLA_END_OF_BUSINESS_DAY_RETIRED)
                .build()
            )

    def emit_default_element_diagnostic(
        self, contract: OpenDataContractStandard, sink: DiagnosticSink
    ) -> None:
        """Emit an INFO when ``slaDefaultElement`` is present (deprecated in ODCS 3.1)."""
        if getattr(contract, "slaDefaultElement", None) is None:
            return
        sink.add(
            DiagnosticBuilder.info(
                DiagnosticId.SLA_DEFAULT_ELEMENT_DEPRECATED,
                "`slaDefaultElement` is deprecated in ODCS 3.1 and removed in 4.0",
            )
            .help("set `element:` on each SLA property entry instead")
            .docs(DiagnosticId.SLA_DEFAULT_ELEMENT_DEPRECATED)
            .build()
        )

    def emit_lifecycle_state_diagnostics(
        self, contract: OpenDataContractStandard, sink: DiagnosticSink
    ) -> None:
        """Emit time-aware diagnostics on parsed lifecycle dates."""
        now = datetime.now(tz=UTC)
        for sla in self.iter_slas(contract):
            if sla.property not in LIFECYCLE_DATE_PROPERTIES:
                continue
            parsed = parse_lifecycle_value(sla.value)
            if parsed is None:
                continue
            self.emit_lifecycle_diagnostic_for(sla.property, parsed, now, sink)

    def emit_lifecycle_diagnostic_for(
        self, property_name: str, parsed: datetime, now: datetime, sink: DiagnosticSink
    ) -> None:
        """Emit the right diagnostic (or none) for one lifecycle date."""
        if property_name == "generalAvailability" and parsed > now:
            sink.add(
                DiagnosticBuilder.info(
                    DiagnosticId.SLA_GENERAL_AVAILABILITY_FUTURE,
                    f"contract is not yet generally available (live: {parsed.date().isoformat()})",
                )
                .docs(DiagnosticId.SLA_GENERAL_AVAILABILITY_FUTURE)
                .build()
            )
            return
        if property_name == "endOfSupport" and parsed < now:
            sink.add(
                DiagnosticBuilder.warning(
                    DiagnosticId.SLA_END_OF_SUPPORT_PAST,
                    f"support ended {parsed.date().isoformat()}; downstream consumers should migrate",
                )
                .docs(DiagnosticId.SLA_END_OF_SUPPORT_PAST)
                .build()
            )
            return
        if property_name == "endOfLife":
            self.emit_end_of_life_diagnostic(parsed, now, sink)

    def emit_end_of_life_diagnostic(self, parsed: datetime, now: datetime, sink: DiagnosticSink) -> None:
        """Emit the WARN/INFO/none verdict for an ``endOfLife`` date."""
        if parsed < now:
            days_ago = (now - parsed).days
            sink.add(
                DiagnosticBuilder.warning(
                    DiagnosticId.SLA_END_OF_LIFE_PAST,
                    f"contract reached endOfLife on {parsed.date().isoformat()} "
                    f"({days_ago} days ago); consumers must migrate",
                )
                .docs(DiagnosticId.SLA_END_OF_LIFE_PAST)
                .build()
            )
            return
        delta_days = (parsed - now).days
        if delta_days <= END_OF_LIFE_NEAR_DAYS:
            sink.add(
                DiagnosticBuilder.info(
                    DiagnosticId.SLA_END_OF_LIFE_NEAR,
                    f"contract reaches endOfLife on {parsed.date().isoformat()} "
                    f"({delta_days} days from now)",
                )
                .docs(DiagnosticId.SLA_END_OF_LIFE_NEAR)
                .build()
            )

    def fold_into_lifecycle(
        self, lifecycle: LifecycleMetadata, name: str, raw_value: object
    ) -> LifecycleMetadata:
        """Apply a single metadata-only SLA onto the running ``LifecycleMetadata``."""
        if name == "availability":
            return LifecycleMetadata(
                availability=parse_availability_value(raw_value),
                general_availability=lifecycle.general_availability,
                end_of_support=lifecycle.end_of_support,
                end_of_life=lifecycle.end_of_life,
            )
        if name not in LIFECYCLE_DATE_PROPERTIES:
            return lifecycle
        parsed = parse_lifecycle_value(raw_value)
        return self.assign_lifecycle_date(lifecycle, name, parsed)

    def assign_lifecycle_date(
        self, lifecycle: LifecycleMetadata, name: str, parsed: datetime | None
    ) -> LifecycleMetadata:
        """Return a copy of *lifecycle* with *name*'s slot set to *parsed*."""
        if name == "generalAvailability":
            return LifecycleMetadata(
                availability=lifecycle.availability,
                general_availability=parsed,
                end_of_support=lifecycle.end_of_support,
                end_of_life=lifecycle.end_of_life,
            )
        if name == "endOfSupport":
            return LifecycleMetadata(
                availability=lifecycle.availability,
                general_availability=lifecycle.general_availability,
                end_of_support=parsed,
                end_of_life=lifecycle.end_of_life,
            )
        return LifecycleMetadata(
            availability=lifecycle.availability,
            general_availability=lifecycle.general_availability,
            end_of_support=lifecycle.end_of_support,
            end_of_life=parsed,
        )

    def to_sla_property(self, sla: ServiceLevelAgreementProperty) -> SlaProperty:
        """Convert a typed ODCS SLA entry into the domain ``SlaProperty``."""
        number, unit = parse_value_and_unit(sla.value, sla.unit)
        value_ext = coerce_to_float(sla.valueExt) if sla.valueExt is not None else None
        return SlaProperty(
            property=sla.property or "",
            value=number,
            value_ext=value_ext,
            unit=unit,
            element=sla.element,
            schedule=sla.schedule,
            scheduler=sla.scheduler,
            driver=sla.driver,
        )

    def derive_checks_for(
        self, sla: ServiceLevelAgreementProperty, schema: SchemaObject
    ) -> list[CheckDef]:
        """Build per-SLA ``CheckDef``s, filtering to *schema* and property kind.

        Metadata properties and SLAs targeting a different schema produce
        nothing.  The five behavioural property kinds each route to their
        dedicated builder via :data:`CHECK_BUILDERS`; unknown property
        names fall through to an empty list.
        """
        if sla.property in METADATA_PROPERTIES:
            return []
        if not sla.element or not sla_targets_schema(sla.element, schema):
            return []
        builder = CHECK_BUILDERS.get(sla.property or "")
        if builder is None:
            return []
        column = sla.element.rsplit(".", maxsplit=1)[-1]
        number, unit = parse_value_and_unit(sla.value, sla.unit)
        return builder(self, sla, column, unit, number)

    def build_freshness_shaped_check(
        self, sla: ServiceLevelAgreementProperty, column: str, unit: str | None, number: float | None
    ) -> list[CheckDef]:
        """Build a single freshness-shaped ``CheckDef`` (latency or freshness)."""
        if number is None:
            return []
        check_type = MetricName.LATENCY if sla.property == "latency" else MetricName.FRESHNESS
        return [
            self.make_check(
                name=f"{check_type}:{column}",
                check_type=check_type,
                column=column,
                unit=unit or "day",
                threshold=ComparisonThreshold(operator="lt", value=number),
            )
        ]

    def build_retention_checks(
        self, sla: ServiceLevelAgreementProperty, column: str, unit: str | None, number: float | None
    ) -> list[CheckDef]:
        """Build one or two retention ``CheckDef``s depending on ``valueExt``.

        ``value`` (lower bound) is required; ``valueExt`` (upper bound) is
        optional.  Lower bound uses ``gte`` (min-age must be ≥ value); upper
        bound uses ``lte`` (min-age must be ≤ valueExt).
        """
        if number is None:
            return []
        unit_norm = unit or "day"
        checks = [
            self.make_check(
                name=f"retention:{column}",
                check_type=MetricName.RETENTION,
                column=column,
                unit=unit_norm,
                threshold=ComparisonThreshold(operator="gte", value=number),
            )
        ]
        if (upper := coerce_to_float(sla.valueExt)) is not None:
            checks.append(
                self.make_check(
                    name=f"retention_max:{column}",
                    check_type=MetricName.RETENTION_MAX,
                    column=column,
                    unit=unit_norm,
                    threshold=ComparisonThreshold(operator="lte", value=upper),
                )
            )
        return checks

    def build_frequency_checks(
        self, sla: ServiceLevelAgreementProperty, column: str, unit: str | None, number: float | None
    ) -> list[CheckDef]:
        """Build a frequency ``CheckDef`` from duration mode or cron mode.

        Cron mode wins when both ``schedule`` and ``value+unit`` are set; the
        threshold is the delta from the previous cron firing plus the
        optional ``valueExt`` tolerance window.  Duration mode (no cron)
        uses ``value`` directly as the staleness threshold.
        """
        if sla.schedule is not None:
            cron = normalize_cron_schedule(sla.schedule)
            if cron is None:
                return []
            threshold_seconds = self.cron_threshold_seconds(cron, sla.valueExt, unit)
            return [
                self.make_check(
                    name=f"frequency:{column}",
                    check_type=MetricName.FREQUENCY,
                    column=column,
                    unit="second",
                    threshold=ComparisonThreshold(operator="lt", value=threshold_seconds),
                )
            ]
        if number is None:
            return []
        tolerance = coerce_to_float(sla.valueExt) or 0.0
        return [
            self.make_check(
                name=f"frequency:{column}",
                check_type=MetricName.FREQUENCY,
                column=column,
                unit=unit or "day",
                threshold=ComparisonThreshold(operator="lt", value=number + tolerance),
            )
        ]

    def build_time_of_availability_checks(
        self, sla: ServiceLevelAgreementProperty, column: str, unit: str | None, number: float | None
    ) -> list[CheckDef]:
        """Translate a ``HH:MM[offset]`` value into the frequency cron machinery.

        ``unit`` and ``number`` are accepted for signature uniformity with
        the other builders but unused — ``value`` here is a time-of-day
        string, not a numeric duration.
        """
        del unit, number
        value = sla.value if isinstance(sla.value, str) else None
        if value is None:
            return []
        translated = translate_time_of_availability(value)
        if translated is None:
            return []
        threshold_seconds = self.cron_threshold_seconds(translated.schedule, sla.valueExt, None)
        suffix = f":{sla.driver}" if sla.driver else ""
        return [
            self.make_check(
                name=f"time_of_availability:{column}{suffix}",
                check_type=MetricName.TIME_OF_AVAILABILITY,
                column=column,
                unit="second",
                threshold=ComparisonThreshold(operator="lt", value=threshold_seconds),
            )
        ]

    def cron_threshold_seconds(self, schedule: str, value_ext: object, unit: str | None) -> float:
        """Compute the freshness threshold (seconds) from a cron schedule.

        Threshold = ``(now - previous_cron_firing) + (valueExt * unit_seconds)``.
        ``valueExt`` is the tolerance window; defaults to zero.
        """
        now = datetime.now(tz=UTC)
        previous = croniter(schedule, now).get_prev(datetime)
        if previous.tzinfo is None:
            previous = previous.replace(tzinfo=UTC)
        baseline = (now - previous).total_seconds()
        tolerance = coerce_to_float(value_ext) or 0.0
        tolerance_seconds = tolerance * seconds_for_unit(unit or "second")
        return baseline + tolerance_seconds

    def make_check(
        self, *, name: str, check_type: str, column: str, unit: str, threshold: ComparisonThreshold
    ) -> CheckDef:
        """Construct a metric ``CheckDef`` with the timeliness dimension and SLA provenance."""
        return CheckDef(
            name=name,
            check_type=check_type,
            dimension=QualityDimension.TIMELINESS,
            category=CheckCategory.METRIC,
            config=MetricCheckConfig(metric=check_type, column=column),
            source=self.check_source,
            threshold=threshold,
            unit=unit,
            column=column,
        )


def sla_targets_schema(element: str, schema: SchemaObject) -> bool:
    """Return ``True`` when an SLA *element* targets *schema*.

    Mirrors the existing :func:`reader.sla_targets_schema` logic without
    importing from the reader (keeps the dependency direction one-way).
    Unqualified elements (bare column name) match every schema and let the
    cross-schema lint rule resolve them.
    """
    if "." not in element:
        return True
    target = element.rsplit(".", maxsplit=1)[0]
    candidates = {name for name in (schema.name, schema.physicalName) if name}
    return target in candidates


type CheckBuilder = Callable[
    [SlaIntake, ServiceLevelAgreementProperty, str, str | None, float | None], list[CheckDef]
]

CHECK_BUILDERS: dict[str, CheckBuilder] = {
    "latency": SlaIntake.build_freshness_shaped_check,
    "freshness": SlaIntake.build_freshness_shaped_check,
    "retention": SlaIntake.build_retention_checks,
    "frequency": SlaIntake.build_frequency_checks,
    "timeOfAvailability": SlaIntake.build_time_of_availability_checks,
}
