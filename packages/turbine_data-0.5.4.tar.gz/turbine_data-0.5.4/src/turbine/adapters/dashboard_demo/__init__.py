"""Dashboard demo-mode wiring: mock dispatcher + sample dataset factory."""
