"""Demo Pydantic models and dataset factory for dashboard demo mode."""

from __future__ import annotations

from pydantic import BaseModel

from turbine.core.dashboard.dataset import FlaggedRow, RowFlags
from turbine.core.dashboard.in_memory_dataset import InMemoryDataset


class DemoOrdersModel(BaseModel):
    """Demo model for the orders table."""

    __tablename__ = "orders"

    order_id: int
    customer: str
    amount: float
    status: str


class DemoCustomersModel(BaseModel):
    """Demo model for the customers table."""

    __tablename__ = "customers"

    customer_id: str
    name: str
    email: str
    tier: str


class DemoProductsModel(BaseModel):
    """Demo model for the products table."""

    __tablename__ = "products"

    product_id: int
    name: str
    price: float
    category: str
    in_stock: bool


class DemoPaymentsModel(BaseModel):
    """Demo model for the payments table."""

    __tablename__ = "payments"

    payment_id: int
    order_id: int
    amount: float
    method: str
    status: str


NO_FLAGS = RowFlags(failed_checks=(), last_checked_at=None, run_id=None)


def row(data: BaseModel, checks: tuple[str, ...] = ()) -> FlaggedRow[BaseModel]:
    """Create a FlaggedRow, optionally with failed checks."""
    flags = RowFlags(
        failed_checks=checks,
        last_checked_at="2026-04-01T12:00:00Z" if checks else None,
        run_id="run-demo" if checks else None,
    )
    return FlaggedRow(data=data, flags=flags)


def demo_dataset[M](entries: tuple[FlaggedRow[M], ...]) -> InMemoryDataset[M]:
    """Build an InMemoryDataset from paired row+flags entries."""
    rows = tuple(entry.data for entry in entries)
    flags = tuple(entry.flags for entry in entries)
    return InMemoryDataset(rows=rows, flags=flags)


class DemoDatasetFactory:
    """Maps table names to pre-built demo datasets with sample flagged rows."""

    def __init__(self) -> None:
        self.registry: dict[str, InMemoryDataset[BaseModel]] = {
            "orders": self.build_orders(),
            "customers": self.build_customers(),
            "products": self.build_products(),
            "payments": self.build_payments(),
        }

    def resolve(self, table_name: str) -> InMemoryDataset[BaseModel]:
        """Resolve a dataset by table name."""
        if table_name not in self.registry:
            msg = f"No demo data for table '{table_name}'"
            raise KeyError(msg)
        return self.registry[table_name]

    @staticmethod
    def build_orders() -> InMemoryDataset[BaseModel]:
        return demo_dataset(
            entries=(
                row(
                    DemoOrdersModel(
                        order_id=1001, customer="Alice Johnson", amount=249.99, status="shipped"
                    )
                ),
                row(
                    DemoOrdersModel(order_id=1002, customer="Bob Smith", amount=89.50, status="pending")
                ),
                row(
                    DemoOrdersModel(
                        order_id=1003, customer="Carol White", amount=0.00, status="cancelled"
                    ),
                    checks=("null_check_amount",),
                ),
                row(
                    DemoOrdersModel(
                        order_id=1004, customer="Dave Brown", amount=1299.00, status="shipped"
                    )
                ),
                row(
                    DemoOrdersModel(
                        order_id=1005, customer="Eve Davis", amount=-15.00, status="refunded"
                    ),
                    checks=("range_check_amount", "validity_check_amount"),
                ),
                row(
                    DemoOrdersModel(
                        order_id=1006, customer="Frank Miller", amount=54.99, status="shipped"
                    )
                ),
                row(
                    DemoOrdersModel(order_id=1007, customer="Grace Lee", amount=320.00, status="pending")
                ),
            )
        )

    @staticmethod
    def build_customers() -> InMemoryDataset[BaseModel]:
        return demo_dataset(
            entries=(
                row(
                    DemoCustomersModel(
                        customer_id="C001", name="Alice Johnson", email="alice@example.com", tier="gold"
                    )
                ),
                row(
                    DemoCustomersModel(
                        customer_id="C002", name="Bob Smith", email="bob@example.com", tier="silver"
                    )
                ),
                row(
                    DemoCustomersModel(customer_id="C003", name="Carol White", email="", tier="bronze"),
                    checks=("completeness_check_email",),
                ),
                row(
                    DemoCustomersModel(
                        customer_id="C004", name="Dave Brown", email="dave@example.com", tier="gold"
                    )
                ),
                row(
                    DemoCustomersModel(
                        customer_id="C005", name="Eve Davis", email="eve@example", tier="silver"
                    ),
                    checks=("format_check_email",),
                ),
                row(
                    DemoCustomersModel(
                        customer_id="C006", name="Frank Miller", email="frank@example.com", tier="bronze"
                    )
                ),
            )
        )

    @staticmethod
    def build_products() -> InMemoryDataset[BaseModel]:
        return demo_dataset(
            entries=(
                row(
                    DemoProductsModel(
                        product_id=1, name="Widget A", price=9.99, category="tools", in_stock=True
                    )
                ),
                row(
                    DemoProductsModel(
                        product_id=2, name="Widget B", price=24.99, category="tools", in_stock=True
                    )
                ),
                row(
                    DemoProductsModel(
                        product_id=3,
                        name="Gadget X",
                        price=-5.00,
                        category="electronics",
                        in_stock=False,
                    ),
                    checks=("range_check_price",),
                ),
                row(
                    DemoProductsModel(
                        product_id=4,
                        name="Gadget Y",
                        price=149.99,
                        category="electronics",
                        in_stock=True,
                    )
                ),
                row(
                    DemoProductsModel(
                        product_id=5, name="Part Z", price=0.50, category="parts", in_stock=True
                    )
                ),
            )
        )

    @staticmethod
    def build_payments() -> InMemoryDataset[BaseModel]:
        return demo_dataset(
            entries=(
                row(
                    DemoPaymentsModel(
                        payment_id=9001, order_id=1001, amount=249.99, method="card", status="captured"
                    )
                ),
                row(
                    DemoPaymentsModel(
                        payment_id=9002, order_id=1002, amount=89.50, method="card", status="pending"
                    )
                ),
                row(
                    DemoPaymentsModel(
                        payment_id=9003, order_id=1003, amount=0.00, method="wire", status="failed"
                    ),
                    checks=("amount_positive",),
                ),
                row(
                    DemoPaymentsModel(
                        payment_id=9004, order_id=1004, amount=1299.00, method="card", status="captured"
                    )
                ),
                row(
                    DemoPaymentsModel(
                        payment_id=9005, order_id=9999, amount=15.00, method="card", status="captured"
                    ),
                    checks=("order_id_exists",),
                ),
                row(
                    DemoPaymentsModel(
                        payment_id=9006, order_id=1006, amount=54.99, method="paypal", status="captured"
                    )
                ),
                row(
                    DemoPaymentsModel(
                        payment_id=9007, order_id=1007, amount=320.00, method="card", status="pending"
                    )
                ),
            )
        )
