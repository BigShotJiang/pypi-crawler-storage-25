"""DemoDispatcher: return realistic mock data for demo/development."""

from __future__ import annotations

import random
from datetime import UTC, datetime, timedelta
from typing import Any

from turbine.core.common.quality_dimension import QualityDimension
from turbine.core.dashboard.query import (
    AlertEntry,
    AlertList,
    AlertSeverity,
    ChainSpec,
    CheckCounters,
    CheckCountersData,
    CheckRegistryEntryData,
    ContractList,
    ContractSummaryData,
    DimensionScores,
    FlaggedTables,
    Resource,
    VerificationRuns,
    VerificationRunSummary,
)
from turbine.core.quality.check_results import DimensionScore

INCIDENT_DAY_START = 5
INCIDENT_DAY_END = 8
REGRESSION_DAY_START = 14
REGRESSION_DAY_END = 16


DEMO_CONTRACTS: list[ContractSummaryData] = [
    ContractSummaryData(
        contract_id="ecommerce-orders-v2",
        name="E-Commerce Orders",
        table="orders",
        check_count=9,
        overall_score=91.5,
        passed_checks=8,
        last_run_at="2026-04-09T06:00:00Z",
        checks=[
            CheckRegistryEntryData(
                check_id="ord_001",
                name="not_null_order_id",
                dimension=QualityDimension.COMPLETENESS,
                check_type="null",
            ),
            CheckRegistryEntryData(
                check_id="ord_002",
                name="not_null_amount",
                dimension=QualityDimension.COMPLETENESS,
                check_type="null",
            ),
            CheckRegistryEntryData(
                check_id="ord_003",
                name="not_null_customer_id",
                dimension=QualityDimension.COMPLETENESS,
                check_type="null",
            ),
            CheckRegistryEntryData(
                check_id="ord_004",
                name="amount_positive",
                dimension=QualityDimension.ACCURACY,
                check_type="range",
            ),
            CheckRegistryEntryData(
                check_id="ord_005",
                name="valid_status",
                dimension=QualityDimension.ACCURACY,
                check_type="accepted_values",
            ),
            CheckRegistryEntryData(
                check_id="ord_006",
                name="amount_below_max",
                dimension=QualityDimension.ACCURACY,
                check_type="range",
            ),
            CheckRegistryEntryData(
                check_id="ord_007",
                name="unique_order_id",
                dimension=QualityDimension.CONSISTENCY,
                check_type="unique",
            ),
            CheckRegistryEntryData(
                check_id="ord_008",
                name="order_date_not_future",
                dimension=QualityDimension.CONSISTENCY,
                check_type="sql",
            ),
            CheckRegistryEntryData(
                check_id="ord_009",
                name="created_at_fresh",
                dimension=QualityDimension.TIMELINESS,
                check_type="freshness",
            ),
        ],
    ),
    ContractSummaryData(
        contract_id="crm-customers-v1",
        name="CRM Customers",
        table="customers",
        check_count=7,
        overall_score=86.2,
        passed_checks=5,
        last_run_at="2026-04-09T06:00:00Z",
        checks=[
            CheckRegistryEntryData(
                check_id="cust_001",
                name="not_null_customer_id",
                dimension=QualityDimension.COMPLETENESS,
                check_type="null",
            ),
            CheckRegistryEntryData(
                check_id="cust_002",
                name="not_null_name",
                dimension=QualityDimension.COMPLETENESS,
                check_type="null",
            ),
            CheckRegistryEntryData(
                check_id="cust_003",
                name="not_null_email",
                dimension=QualityDimension.COMPLETENESS,
                check_type="null",
            ),
            CheckRegistryEntryData(
                check_id="cust_004",
                name="email_format_valid",
                dimension=QualityDimension.ACCURACY,
                check_type="regex",
            ),
            CheckRegistryEntryData(
                check_id="cust_005",
                name="valid_tier",
                dimension=QualityDimension.ACCURACY,
                check_type="accepted_values",
            ),
            CheckRegistryEntryData(
                check_id="cust_006",
                name="unique_customer_id",
                dimension=QualityDimension.CONSISTENCY,
                check_type="unique",
            ),
            CheckRegistryEntryData(
                check_id="cust_007",
                name="unique_email",
                dimension=QualityDimension.CONSISTENCY,
                check_type="unique",
            ),
        ],
    ),
    ContractSummaryData(
        contract_id="qs-products-v1",
        name="Product Catalog QS",
        table="products",
        check_count=6,
        overall_score=95.0,
        passed_checks=6,
        last_run_at="2026-04-09T06:00:00Z",
        checks=[
            CheckRegistryEntryData(
                check_id="prod_001",
                name="not_null_product_id",
                dimension=QualityDimension.COMPLETENESS,
                check_type="null",
            ),
            CheckRegistryEntryData(
                check_id="prod_002",
                name="not_null_name",
                dimension=QualityDimension.COMPLETENESS,
                check_type="null",
            ),
            CheckRegistryEntryData(
                check_id="prod_003",
                name="price_positive",
                dimension=QualityDimension.ACCURACY,
                check_type="range",
            ),
            CheckRegistryEntryData(
                check_id="prod_004",
                name="valid_category",
                dimension=QualityDimension.ACCURACY,
                check_type="accepted_values",
            ),
            CheckRegistryEntryData(
                check_id="prod_005",
                name="unique_product_id",
                dimension=QualityDimension.CONSISTENCY,
                check_type="unique",
            ),
            CheckRegistryEntryData(
                check_id="prod_006",
                name="updated_at_fresh",
                dimension=QualityDimension.TIMELINESS,
                check_type="freshness",
            ),
        ],
    ),
    ContractSummaryData(
        contract_id="qs-payments-v1",
        name="Payments QS",
        table="payments",
        check_count=8,
        overall_score=78.3,
        passed_checks=6,
        last_run_at="2026-04-09T06:00:00Z",
        checks=[
            CheckRegistryEntryData(
                check_id="pay_001",
                name="not_null_payment_id",
                dimension=QualityDimension.COMPLETENESS,
                check_type="null",
            ),
            CheckRegistryEntryData(
                check_id="pay_002",
                name="not_null_order_id",
                dimension=QualityDimension.COMPLETENESS,
                check_type="null",
            ),
            CheckRegistryEntryData(
                check_id="pay_003",
                name="amount_positive",
                dimension=QualityDimension.ACCURACY,
                check_type="range",
            ),
            CheckRegistryEntryData(
                check_id="pay_004",
                name="valid_method",
                dimension=QualityDimension.ACCURACY,
                check_type="accepted_values",
            ),
            CheckRegistryEntryData(
                check_id="pay_005",
                name="valid_status",
                dimension=QualityDimension.ACCURACY,
                check_type="accepted_values",
            ),
            CheckRegistryEntryData(
                check_id="pay_006",
                name="order_id_exists",
                dimension=QualityDimension.CONSISTENCY,
                check_type="referential",
            ),
            CheckRegistryEntryData(
                check_id="pay_007",
                name="unique_payment_id",
                dimension=QualityDimension.CONSISTENCY,
                check_type="unique",
            ),
            CheckRegistryEntryData(
                check_id="pay_008",
                name="processed_at_fresh",
                dimension=QualityDimension.TIMELINESS,
                check_type="freshness",
            ),
        ],
    ),
]

DEMO_ALERTS_RAW: list[tuple[str, str, QualityDimension, int, str]] = [
    ("not_null_amount", "orders", QualityDimension.COMPLETENESS, 6, "2026-04-09T06:00:00Z"),
    ("amount_positive", "orders", QualityDimension.ACCURACY, 3, "2026-04-09T06:00:00Z"),
    ("not_null_email", "customers", QualityDimension.COMPLETENESS, 8, "2026-04-09T06:00:00Z"),
    ("email_format_valid", "customers", QualityDimension.ACCURACY, 5, "2026-04-09T06:00:00Z"),
    ("valid_tier", "customers", QualityDimension.ACCURACY, 2, "2026-04-08T18:00:00Z"),
    ("price_positive", "products", QualityDimension.ACCURACY, 1, "2026-04-08T06:00:00Z"),
    ("amount_positive", "payments", QualityDimension.ACCURACY, 4, "2026-04-09T06:00:00Z"),
    ("order_id_exists", "payments", QualityDimension.CONSISTENCY, 7, "2026-04-09T06:00:00Z"),
]

CRITICAL_THRESHOLD = 5
WARNING_THRESHOLD = 3


def severity_for(consecutive: int) -> AlertSeverity:
    """Map consecutive failure count to severity level."""
    if consecutive >= CRITICAL_THRESHOLD:
        return AlertSeverity.CRITICAL
    if consecutive >= WARNING_THRESHOLD:
        return AlertSeverity.WARNING
    return AlertSeverity.INFO


class DemoDispatcher:
    """Return mock data for demo/development when no API is available."""

    def execute(self, resource: Resource[Any], spec: ChainSpec) -> Any:  # noqa: ARG002
        if isinstance(resource, DimensionScores):
            return [
                DimensionScore(QualityDimension.ACCURACY, score=89.4, checks_passed=16, checks_total=18),
                DimensionScore(
                    QualityDimension.COMPLETENESS, score=84.6, checks_passed=11, checks_total=13
                ),
                DimensionScore(
                    QualityDimension.CONSISTENCY, score=93.3, checks_passed=14, checks_total=15
                ),
                DimensionScore(QualityDimension.TIMELINESS, score=97.5, checks_passed=3, checks_total=4),
            ]
        if isinstance(resource, CheckCounters):
            return CheckCountersData(total=50, passed=44, failed=4, warned=1, skipped=1)
        if isinstance(resource, FlaggedTables):
            return ["orders", "customers", "products", "payments"]
        if isinstance(resource, VerificationRuns):
            return generate_runs()
        if isinstance(resource, ContractList):
            return DEMO_CONTRACTS
        if isinstance(resource, AlertList):
            return generate_alerts()
        msg = f"No demo handler for {type(resource).__name__}"
        raise NotImplementedError(msg)


def generate_alerts() -> list[AlertEntry]:
    """Generate realistic alerts with mixed severities across all demo tables."""
    return [
        AlertEntry(
            check_name=name,
            table=table,
            dimension=dimension,
            consecutive_failures=failures,
            severity=severity_for(failures),
            last_failure_at=last_at,
        )
        for name, table, dimension, failures, last_at in DEMO_ALERTS_RAW
    ]


def generate_runs() -> list[VerificationRunSummary]:
    """Generate 21 days of deterministic fake verification runs.

    Simulates a realistic pattern: a degradation around days 5-8,
    recovery, then a smaller dip near day 15.
    """
    rng = random.Random(42)  # noqa: S311
    base_date = datetime(2026, 3, 20, tzinfo=UTC)
    total_checks = 50

    runs: list[VerificationRunSummary] = []
    for day in range(21):
        timestamp = base_date + timedelta(days=day)

        base_rate = 92.0
        if INCIDENT_DAY_START <= day <= INCIDENT_DAY_END:
            base_rate = 78.0
        elif REGRESSION_DAY_START <= day <= REGRESSION_DAY_END:
            base_rate = 85.0
        jitter = rng.uniform(-3.0, 3.0)
        pass_rate = round(max(60.0, min(99.0, base_rate + jitter)), 1)

        failed_checks = round(total_checks * (100 - pass_rate) / 100)
        duration_ms = rng.randint(1200, 4500)
        run = VerificationRunSummary(
            run_id=f"run-{day + 1:03d}",
            timestamp=timestamp.isoformat(),
            pass_rate=pass_rate,
            total_checks=total_checks,
            failed_checks=failed_checks,
            duration_ms=duration_ms,
        )
        runs.append(run)
    return runs
