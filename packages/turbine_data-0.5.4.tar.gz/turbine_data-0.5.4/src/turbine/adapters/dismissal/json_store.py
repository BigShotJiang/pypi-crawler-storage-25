"""JSON-on-disk adapter for both ``DismissalStore`` and ``OnboardingDismissalStore``.

Persists records to ``<project_root>/.turbine/state.json``. The file is small,
so the adapters re-read it on every call: they favor correctness and simplicity
over performance for v1. Writes are atomic (write to a sibling tempfile then
``Path.replace``) so a crashed write can never leave a half-formed file behind.

Two stores share the file: diagnostic dismissals live under the ``dismissals``
key, phase-card soft dismissals under ``phase_dismissals``. The shared
``StateFileIO`` helper centralises the load/write dance so neither adapter
clobbers the other's records.
"""

import json
import tempfile
from collections.abc import Iterable
from pathlib import Path

from pydantic import BaseModel, Field

from turbine.core.building_blocks import DiagnosticKind
from turbine.core.contract.dismissal import DismissalKey, DismissalStore
from turbine.core.onboarding.dismissal import OnboardingDismissalKey, OnboardingDismissalStore
from turbine.core.onboarding.phase import Phase
from turbine.core.onboarding.tour_progress import TourProgressKey, TourProgressRecord, TourProgressStore


class DismissedRecord(BaseModel, frozen=True):
    """One persisted diagnostic-dismissal entry."""

    file_uri: str
    rule_id: str
    anchor: str | None
    kind: DiagnosticKind


class PhaseDismissedRecord(BaseModel, frozen=True):
    """One persisted phase-card soft-dismissal entry."""

    workspace_folder_uri: str
    phase_kind: Phase


class PersistedTourProgress(BaseModel, frozen=True):
    """One persisted tour-progress entry keyed by ``(workspace_folder_uri, tour_id)``."""

    workspace_folder_uri: str
    tour_id: str
    last_step_id: str | None
    completed_step_ids: tuple[str, ...]
    finished: bool


class StateFile(BaseModel):
    """Top-level shape of ``.turbine/state.json``."""

    version: int = 1
    dismissals: list[DismissedRecord] = Field(default_factory=list)
    phase_dismissals: list[PhaseDismissedRecord] = Field(default_factory=list)
    tour_progress: list[PersistedTourProgress] = Field(default_factory=list)


class StateFileIO:
    """Shared load/write helpers for the state file.

    Both adapters bind to the same path and route mutations through this
    helper so the file's other section is preserved on every write.
    """

    def __init__(self, state_path: Path) -> None:
        self.state_path = state_path

    def load(self) -> StateFile:
        """Read the JSON file, returning an empty state when absent or unreadable."""
        if not self.state_path.exists():
            return StateFile()
        text = self.state_path.read_text()
        if not text.strip():
            return StateFile()
        payload = json.loads(text)
        return StateFile.model_validate(payload)

    def write(self, state: StateFile) -> None:
        """Atomically persist *state* to the JSON file.

        ``mkdir(parents=True, exist_ok=True)`` is lazy so cold projects don't
        produce a stray ``.turbine/`` directory. The temp-file plus
        ``Path.replace`` dance keeps readers from observing a half-written file.
        """
        self.state_path.parent.mkdir(parents=True, exist_ok=True)
        payload = state.model_dump(mode="json")
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            dir=self.state_path.parent,
            prefix=self.state_path.name,
            suffix=".tmp",
            delete=False,
        ) as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
            tmp_path = Path(handle.name)
        tmp_path.replace(self.state_path)


class JsonDismissalStore(DismissalStore):
    """Read/write diagnostic dismissals as a single JSON file on disk.

    Each call re-reads the file from disk (the dataset is tiny) so concurrent
    writers see consistent state. Writes go through a temp file plus
    ``Path.replace`` so the on-disk file is never observed half-written.
    """

    def __init__(self, state_path: Path) -> None:
        """Bind the store to *state_path*.

        The parent directory is created lazily on first ``dismiss`` so that a
        read-only or never-dismissed project does not produce a ``.turbine/``
        folder.
        """
        self.io = StateFileIO(state_path)

    @property
    def state_path(self) -> Path:
        return self.io.state_path

    def is_dismissed(self, key: DismissalKey) -> bool:
        """Return True when *key* has been dismissed and not since invalidated."""
        state = self.io.load()
        record_key = (key.file_uri, key.rule_id, key.anchor)
        for record in state.dismissals:
            if (record.file_uri, record.rule_id, record.anchor) == record_key:
                return True
        return False

    def dismiss(self, key: DismissalKey, kind: DiagnosticKind) -> None:
        """Persist a dismissal for *key* with its associated diagnostic kind."""
        state = self.io.load()
        new_record = DismissedRecord(
            file_uri=key.file_uri, rule_id=key.rule_id, anchor=key.anchor, kind=kind
        )
        record_key = (key.file_uri, key.rule_id, key.anchor)
        retained = [
            record
            for record in state.dismissals
            if (record.file_uri, record.rule_id, record.anchor) != record_key
        ]
        retained.append(new_record)
        state.dismissals = retained
        self.io.write(state)

    def purge_invalid(self, file_uri: str, active: Iterable[DismissalKey]) -> None:
        """Drop entries for *file_uri* whose key is not in *active*."""
        active_keys = {(k.file_uri, k.rule_id, k.anchor) for k in active}
        state = self.io.load()
        retained: list[DismissedRecord] = []
        for record in state.dismissals:
            if record.file_uri != file_uri:
                retained.append(record)
                continue
            if (record.file_uri, record.rule_id, record.anchor) in active_keys:
                retained.append(record)
        state.dismissals = retained
        self.io.write(state)


class JsonOnboardingDismissalStore(OnboardingDismissalStore):
    """Read/write phase-card soft dismissals as a single JSON file on disk.

    Shares the ``state.json`` file with ``JsonDismissalStore``; reads and
    writes the ``phase_dismissals`` section while leaving the diagnostic
    ``dismissals`` section untouched.
    """

    def __init__(self, state_path: Path) -> None:
        self.io = StateFileIO(state_path)

    @property
    def state_path(self) -> Path:
        return self.io.state_path

    def is_dismissed(self, key: OnboardingDismissalKey) -> bool:
        state = self.io.load()
        for record in state.phase_dismissals:
            if (
                record.workspace_folder_uri == key.workspace_folder_uri
                and record.phase_kind == key.phase_kind
            ):
                return True
        return False

    def dismiss(self, key: OnboardingDismissalKey) -> None:
        state = self.io.load()
        retained = [
            record
            for record in state.phase_dismissals
            if not (
                record.workspace_folder_uri == key.workspace_folder_uri
                and record.phase_kind == key.phase_kind
            )
        ]
        retained.append(
            PhaseDismissedRecord(
                workspace_folder_uri=key.workspace_folder_uri, phase_kind=key.phase_kind
            )
        )
        state.phase_dismissals = retained
        self.io.write(state)

    def clear(self, workspace_folder_uri: str) -> None:
        state = self.io.load()
        state.phase_dismissals = [
            record
            for record in state.phase_dismissals
            if record.workspace_folder_uri != workspace_folder_uri
        ]
        self.io.write(state)


class JsonTourProgressStore(TourProgressStore):
    """Read/write tour-progress records as a single JSON file on disk.

    Shares ``state.json`` with ``JsonDismissalStore`` and
    ``JsonOnboardingDismissalStore``; reads and writes the ``tour_progress``
    section while leaving the other sections untouched.
    """

    def __init__(self, state_path: Path) -> None:
        self.io = StateFileIO(state_path)

    @property
    def state_path(self) -> Path:
        return self.io.state_path

    def load(self, key: TourProgressKey) -> TourProgressRecord | None:
        state = self.io.load()
        for entry in state.tour_progress:
            if entry.workspace_folder_uri == key.workspace_folder_uri and entry.tour_id == key.tour_id:
                return TourProgressRecord(
                    workspace_folder_uri=entry.workspace_folder_uri,
                    tour_id=entry.tour_id,
                    last_step_id=entry.last_step_id,
                    completed_step_ids=tuple(entry.completed_step_ids),
                    finished=entry.finished,
                )
        return None

    def save(self, record: TourProgressRecord) -> None:
        state = self.io.load()
        retained = [
            existing
            for existing in state.tour_progress
            if not (
                existing.workspace_folder_uri == record.workspace_folder_uri
                and existing.tour_id == record.tour_id
            )
        ]
        retained.append(
            PersistedTourProgress(
                workspace_folder_uri=record.workspace_folder_uri,
                tour_id=record.tour_id,
                last_step_id=record.last_step_id,
                completed_step_ids=tuple(record.completed_step_ids),
                finished=record.finished,
            )
        )
        state.tour_progress = retained
        self.io.write(state)

    def all_finished_for(self, workspace_folder_uri: str) -> tuple[str, ...]:
        state = self.io.load()
        return tuple(
            record.tour_id
            for record in state.tour_progress
            if record.workspace_folder_uri == workspace_folder_uri and record.finished
        )

    def clear(self, workspace_folder_uri: str) -> None:
        state = self.io.load()
        state.tour_progress = [
            record
            for record in state.tour_progress
            if record.workspace_folder_uri != workspace_folder_uri
        ]
        self.io.write(state)
