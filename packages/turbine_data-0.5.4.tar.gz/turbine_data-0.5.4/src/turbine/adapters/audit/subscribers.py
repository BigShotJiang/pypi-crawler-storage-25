"""Audit subscribers: @on handlers that route run events to AuditTrailWriter.

Replaces the direct ``audit.start_run`` / ``audit.complete_run`` /
``audit.fail_run`` calls that used to live in ``CheckUseCase``. The
composition root installs the writer via :func:`install` before
``discover`` registers the subscribers on the bus.

``RunPolicy=OFF`` runs are silenced at the *registration* layer: the LSP
composition root simply skips ``discover``ing this module, so none of
these handlers subscribe and the audit table stays untouched.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from turbine.adapters.audit.run_buffer import RUN_BUFFER, RunBuffer
from turbine.adapters.events import on
from turbine.core.quality import (
    AuditTrailWriter,
    CheckCompleted,
    CheckErrored,
    CheckResult,
    NoOpAuditWriter,
    RunAborted,
    RunCompleted,
    RunStarted,
)


@dataclass
class AuditDeps:
    """Mutable injection point for the writer + buffer used by subscribers."""

    writer: AuditTrailWriter = field(default_factory=NoOpAuditWriter)
    buffer: RunBuffer = field(default_factory=lambda: RUN_BUFFER)


DEPS = AuditDeps()


def install(writer: AuditTrailWriter, buffer: RunBuffer = RUN_BUFFER) -> None:
    """Wire the writer + buffer the subscribers will call at publish time.

    Called once by each composition root (``cli/commands/check.py``,
    ``cli/commands/ci.py``, ``cli/commands/serve.py``) before
    ``discover(audit_subscribers, event_bus)``. The LSP intentionally
    skips this install so editor sessions never write an audit row.
    """
    DEPS.writer = writer
    DEPS.buffer = buffer


@on(RunStarted)
def start_audit_run(event: RunStarted) -> None:
    """Open an audit-trail row and stash the returned ``run_seq`` for downstream writers."""
    contract_id = event.contract.metadata.contract_id
    run_seq = DEPS.writer.start_run(
        event.run_id, contract_id, contract_id, str(event.contract.table), mode=event.run_mode.value
    )
    DEPS.buffer.store_run_seq(event.run_id, run_seq)


@on(CheckCompleted)
def buffer_check_for_audit(event: CheckCompleted) -> None:
    """Stash the completed check's result for the eventual complete_run batch."""
    if event.run_id is None:
        return
    DEPS.buffer.append(event.run_id, CheckResult.from_event(event))


@on(CheckErrored)
def buffer_errored_check_for_audit(event: CheckErrored) -> None:
    """Stash the errored check's result for the eventual complete_run batch."""
    if event.run_id is None:
        return
    DEPS.buffer.append(event.run_id, event.to_result())


@on(RunCompleted)
def complete_audit_run(event: RunCompleted) -> None:
    """Close the audit row, flushing buffered results in one transaction.

    ``score_overall is None`` means every check skipped (empty incremental
    window, filter excluded all rows). Route that case to ``NO_DATA`` so the
    next ``--incremental`` run still advances its watermark but a stalled
    pipeline doesn't masquerade as a green ``COMPLETED``.
    """
    results = DEPS.buffer.drain(event.run_id)
    DEPS.writer.complete_run(event.run_id, results, no_data=event.score_overall is None)


@on(RunAborted)
def fail_audit_run(event: RunAborted) -> None:
    """Mark the run failed and discard any buffered partial results."""
    DEPS.buffer.clear(event.run_id)
    DEPS.writer.fail_run(event.run_id)
