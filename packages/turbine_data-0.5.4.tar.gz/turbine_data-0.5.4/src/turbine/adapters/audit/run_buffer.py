"""RunBuffer: accumulates CheckResult objects per run for the audit writer.

The audit subscriber appends on every ``CheckCompleted`` and drains on
``RunCompleted``. Keyed by ``run_id`` so concurrent runs in the same process
don't leak into one another's audit rows.

The module-level singleton ``RUN_BUFFER`` is the default; tests build their
own ``RunBuffer()`` to stay isolated and call ``clear(run_id)`` between cases.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Final
from uuid import UUID

from turbine.core.quality import CheckResult, RunSeqStore


@dataclass
class RunBuffer(RunSeqStore):
    """Thread-safe, per-run check accumulator drained by the audit subscriber.

    Also holds the ``run_seq`` handed back by the audit writer at
    ``start_run`` so downstream consumers (e.g. FlaggingWriter) can stamp
    rows with a monotonically-increasing per-contract sequence without
    threading the seq through CheckUseCase.
    """

    results: dict[UUID, list[CheckResult]] = field(default_factory=dict)
    run_seqs: dict[UUID, int] = field(default_factory=dict)
    lock: threading.Lock = field(default_factory=threading.Lock)

    def append(self, run_id: UUID, result: CheckResult) -> None:
        """Append *result* to the list for *run_id*, creating it if absent."""
        with self.lock:
            self.results.setdefault(run_id, []).append(result)

    def drain(self, run_id: UUID) -> tuple[CheckResult, ...]:
        """Remove and return the accumulated results for *run_id*.

        A subsequent ``drain`` of the same ``run_id`` returns an empty
        tuple. Returning a tuple (not a list) so downstream writers can
        pass the result straight to ``AuditTrailWriter.complete_run``.
        """
        with self.lock:
            bucket = self.results.pop(run_id, None)
        return tuple(bucket or ())

    def store_run_seq(self, run_id: UUID, run_seq: int) -> None:
        """Remember the writer-assigned run_seq for *run_id*."""
        with self.lock:
            self.run_seqs[run_id] = run_seq

    def get_run_seq(self, run_id: UUID, default: int = 0) -> int:
        """Return the stored run_seq for *run_id*, or *default* if absent."""
        with self.lock:
            return self.run_seqs.get(run_id, default)

    def clear(self, run_id: UUID) -> None:
        """Forget any results and run_seq buffered for *run_id*."""
        with self.lock:
            self.results.pop(run_id, None)
            self.run_seqs.pop(run_id, None)


RUN_BUFFER: Final = RunBuffer()
