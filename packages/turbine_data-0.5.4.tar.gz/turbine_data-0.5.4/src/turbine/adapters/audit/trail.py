"""DatabaseAuditTrail: records check run lifecycle and results via raw SQL.

Uses raw ``text()`` statements rather than the SQLModel ORM so the
target schema can be overridden at runtime via
``TURBINE_METADATA_SCHEMA``. The SQLModel classes in
``turbine.infra.database.models`` remain authoritative for migrations
(Alembic autogenerate) but are not used as a query surface here.
"""

from datetime import datetime
from uuid import UUID

from sqlalchemy import bindparam, text
from sqlalchemy.orm import Session, sessionmaker

from turbine.core.quality.check_results import CheckResult
from turbine.infra.database.models import RunStatus


class DatabaseAuditTrail:
    """Manages the full run lifecycle: start, complete (with results), fail.

    Bound at construction to a single ``datasource`` string that gets stamped
    on every audit_trail row this writer produces, so a single metadata store
    can serve postgres + snowflake without PK collisions. The ``schema``
    argument follows ``TURBINE_METADATA_SCHEMA`` so all writes target the
    same schema Alembic created.
    """

    def __init__(self, session_factory: sessionmaker[Session], datasource: str, schema: str) -> None:
        self.session_factory = session_factory
        self.datasource = datasource
        self.schema = schema

    @property
    def audit_trail_table(self) -> str:
        """Fully qualified ``turbine_audit_trail`` reference."""
        return f"{self.schema}.turbine_audit_trail"

    @property
    def check_results_table(self) -> str:
        """Fully qualified ``turbine_check_results`` reference."""
        return f"{self.schema}.turbine_check_results"

    def start_run(  # noqa: PLR0913
        self,
        run_id: UUID,
        contract_id: str,
        spec_id: str,
        table_name: str,
        *,
        contract_sha: bytes | None = None,
        mode: str = "full",
    ) -> int:
        """Insert a STARTED row for this run; return the DB-allocated ``run_seq``.

        DuckDB generates ``run_seq`` from a sequence default, Postgres from
        ``GENERATED ALWAYS AS IDENTITY``, Snowflake from ``NUMBER
        AUTOINCREMENT``. The insert uses ``RETURNING run_seq`` (supported by
        all three dialects) so the server-generated value comes back in the
        same round-trip; we never send ``run_seq`` ourselves.
        """
        stmt = text(
            f"INSERT INTO {self.audit_trail_table} "
            "(run_id, datasource, contract_id, spec_id, table_name, "
            "started_at, status, contract_sha, mode) "
            "VALUES (:run_id, :datasource, :contract_id, :spec_id, :table_name, "
            "CURRENT_TIMESTAMP, :status, :contract_sha, :mode) "
            "RETURNING run_seq"
        )
        with self.session_factory.begin() as session:
            result = session.execute(
                stmt,
                {
                    "run_id": str(run_id),
                    "datasource": self.datasource,
                    "contract_id": contract_id,
                    "spec_id": spec_id,
                    "table_name": table_name,
                    "status": RunStatus.STARTED.value,
                    "contract_sha": contract_sha,
                    "mode": mode,
                },
            )
            return int(result.scalar_one())

    def complete_run(
        self, run_id: UUID, results: tuple[CheckResult, ...] = (), *, no_data: bool = False
    ) -> None:
        """Mark the run completed (or NO_DATA) and persist check results.

        ``no_data=True`` records ``RunStatus.NO_DATA`` so downstream consumers
        can distinguish "every check skipped" from "all checks passed". The
        watermark still advances either way — incremental's next run starts
        from this run's ``started_at``.
        """
        status = RunStatus.NO_DATA if no_data else RunStatus.COMPLETED
        update_stmt = text(
            f"UPDATE {self.audit_trail_table} "
            "SET status = :status, completed_at = CURRENT_TIMESTAMP "
            "WHERE run_id = :run_id"
        )
        insert_stmt = text(
            f"INSERT INTO {self.check_results_table} "
            "(run_id, check_name, dimension, outcome, rows_tested, rows_failed, executed_at) "
            "VALUES (:run_id, :check_name, :dimension, :outcome, :rows_tested, :rows_failed, "
            "CURRENT_TIMESTAMP)"
        )
        with self.session_factory.begin() as session:
            session.execute(update_stmt, {"status": status.value, "run_id": str(run_id)})
            if not results:
                return
            result_rows = [
                {
                    "run_id": str(run_id),
                    "check_name": result.name,
                    "dimension": str(result.dimension),
                    "outcome": result.outcome.value,
                    "rows_tested": result.rows_tested,
                    "rows_failed": result.rows_failed,
                }
                for result in results
            ]
            session.execute(insert_stmt, result_rows)

    def fail_run(self, run_id: UUID) -> None:
        """Mark a run as FAILED."""
        stmt = text(
            f"UPDATE {self.audit_trail_table} "
            "SET status = :status, completed_at = CURRENT_TIMESTAMP "
            "WHERE run_id = :run_id"
        )
        with self.session_factory.begin() as session:
            session.execute(stmt, {"status": RunStatus.FAILED.value, "run_id": str(run_id)})

    def get_last_completed_at(self, contract_id: str, table_name: str) -> datetime | None:
        """Return started_at of the most recent successful run on this datasource, or None.

        Accepts both ``COMPLETED`` (real verdict) and ``NO_DATA`` (every check
        skipped because the window was empty) — both advance the watermark
        for the next ``--incremental`` run. ``FAILED`` runs do not. Scoped to
        ``self.datasource`` because incremental-mode time-window filtering
        reads data from one warehouse at a time; "last completed" across
        warehouses is meaningless for that query.
        """
        stmt = text(
            f"SELECT started_at FROM {self.audit_trail_table} "
            "WHERE datasource = :datasource AND contract_id = :contract_id "
            "AND table_name = :table_name AND status IN (:completed, :no_data) "
            "ORDER BY started_at DESC LIMIT 1"
        ).bindparams(
            bindparam("datasource"),
            bindparam("contract_id"),
            bindparam("table_name"),
            bindparam("completed"),
            bindparam("no_data"),
        )
        with self.session_factory() as session:
            result = session.execute(
                stmt,
                {
                    "datasource": self.datasource,
                    "contract_id": contract_id,
                    "table_name": table_name,
                    "completed": RunStatus.COMPLETED.value,
                    "no_data": RunStatus.NO_DATA.value,
                },
            ).scalar()
            if not isinstance(result, datetime):
                return None
            return result
