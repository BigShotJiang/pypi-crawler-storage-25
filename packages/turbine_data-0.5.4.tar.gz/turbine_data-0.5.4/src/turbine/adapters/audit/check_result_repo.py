"""SqlAlchemy-backed repository for historical check results."""

from collections import Counter
from datetime import datetime

from sqlalchemy import DateTime, Engine, bindparam, text
from sqlalchemy.sql.elements import BindParameter

from turbine.core.quality import CheckCounters, CheckResultRepository
from turbine.core.quality.events import CheckOutcome


class SqlCheckResultRepository(CheckResultRepository):
    """Aggregates the check_results table into CheckCounters with a SQL GROUP BY.

    Uses raw SQL keyed off the configured metadata-store schema so the
    repository honours ``TURBINE_METADATA_SCHEMA`` end-to-end.
    """

    def __init__(self, engine: Engine, schema: str) -> None:
        """Bind the repository to the metadata-store engine and schema."""
        self.engine = engine
        self.schema = schema

    def counters(self, since: datetime | None, until: datetime | None) -> CheckCounters:
        """Group rows by outcome and aggregate into a CheckCounters record."""
        clauses: list[str] = []
        binds: list[BindParameter] = []
        params: dict[str, object] = {}
        if since is not None:
            clauses.append("executed_at >= :since")
            binds.append(bindparam("since", type_=DateTime))
            params["since"] = since
        if until is not None:
            clauses.append("executed_at <= :until")
            binds.append(bindparam("until", type_=DateTime))
            params["until"] = until
        where = f"WHERE {' AND '.join(clauses)}" if clauses else ""
        stmt = text(
            f"SELECT outcome, COUNT(*) FROM {self.schema}.turbine_check_results {where} GROUP BY outcome"
        )
        if binds:
            stmt = stmt.bindparams(*binds)

        counts: Counter[CheckOutcome] = Counter()
        with self.engine.connect() as conn:
            for outcome_value, total in conn.execute(stmt, params).all():
                counts[CheckOutcome(outcome_value)] = int(total)

        return CheckCounters.from_outcome_counts(counts)
