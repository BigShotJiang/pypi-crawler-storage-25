"""Audit trail adapter — records check run lifecycle."""

from .trail import DatabaseAuditTrail

__all__ = ["DatabaseAuditTrail"]
