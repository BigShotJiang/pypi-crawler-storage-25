"""Base classes for generated data models.

Codegen'd models inherit from `AbstractModel[FilterT, IdT]`, which provides:

  - A SQLAlchemy 2.0 `DeclarativeBase` registry via `Base`
  - Common query helpers: `base_query`, `list_query`, `get`, `get_or_404`
  - Primary-key normalization via `__id_field__`

Columns are declared with `Mapped[T] = mapped_column(...)` so static type
checkers (ty, mypy without plugins) see `Model.column` as
`InstrumentedAttribute[T]`. This is what makes the dashboard DSL's
`data.sum(Order.amount)` column references type-check correctly.

A companion Pydantic schema class is emitted per model for API
serialization (see codegen model renderer).
"""

from __future__ import annotations

from http import HTTPStatus
from typing import Any, ClassVar, Self

try:
    from fastapi import HTTPException
    from pydantic import BaseModel
    from sqlalchemy import Select, select
    from sqlalchemy.orm import DeclarativeBase, Session
except ImportError as exc:
    raise ImportError("Install the api extra: uv add 'turbine-data[api]'") from exc


class Base(DeclarativeBase):
    """Shared DeclarativeBase for every codegen'd model."""


class AbstractModel[F: BaseModel, ID](Base):
    """Abstract base for generated data models.

    Type parameters:
        F: The filter class type for this model.
        ID: The primary-key type (`int`, `str`, or `tuple[...]` for composite).
    """

    __abstract__ = True
    __id_field__: ClassVar[str | tuple[str, ...]] = "id"

    @classmethod
    def id_fields(cls) -> tuple[str, ...]:
        """Normalize `__id_field__` to a tuple of field names."""
        if isinstance(cls.__id_field__, tuple):
            return cls.__id_field__
        return (cls.__id_field__,)

    @classmethod
    def get_id_columns(cls) -> tuple[Any, ...]:
        """Return column attributes for all primary-key fields."""
        return tuple(getattr(cls, field) for field in cls.id_fields())

    @classmethod
    def base_query(cls) -> Select[tuple[Self]]:
        """Create a base `select` ordered by primary-key column(s)."""
        return select(cls).order_by(*cls.get_id_columns())

    @classmethod
    def get(cls, session: Session, entity_id: ID) -> Self | None:
        """Get a single entity by primary key, or `None` if missing."""
        return session.get(cls, entity_id)

    @classmethod
    def get_or_404(cls, session: Session, entity_id: ID) -> Self:
        """Get a single entity by primary key or raise HTTP 404."""
        entity = session.get(cls, entity_id)
        if entity is None:
            raise HTTPException(HTTPStatus.NOT_FOUND, f"{cls.__name__} not found")
        return entity

    @classmethod
    def list_query(cls, filters: F | None = None) -> Select[tuple[Self]]:
        """Build a filtered, ordered `select` for listing entities."""
        query = cls.base_query()
        if filters is None:
            return query
        return cls.apply_filters(query, filters)

    @classmethod
    def apply_filters(cls, query: Select[tuple[Self]], filters: F) -> Select[tuple[Self]]:
        """Apply non-None filter values as WHERE clauses."""
        for field, value in filters.model_dump(exclude_none=True).items():
            query = query.where(getattr(cls, field) == value)
        return query
