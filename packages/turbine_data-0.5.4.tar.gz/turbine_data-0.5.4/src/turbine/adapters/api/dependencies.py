"""FastAPI dependencies for generated API routers.

Generated routers import ``get_session`` from this module via
``Depends(get_session)``. The engine must be stored on ``app.state.engine``
by the serve layer before any request is handled.
"""

from collections.abc import Generator

from fastapi import Request
from sqlalchemy.orm import Session


def get_session(request: Request) -> Generator[Session]:
    """Yield a database session from the app's engine.

    The engine is expected on ``request.app.state.engine``, set by
    ``create_app()`` in the presentation layer.
    """
    with Session(request.app.state.engine) as session:
        yield session
