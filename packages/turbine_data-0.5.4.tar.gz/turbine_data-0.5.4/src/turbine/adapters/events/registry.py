"""@on decorator and discover() walker: wire handlers onto an EventBus by tag.

Handlers tag themselves with ``@on(EventType)``; ``discover(module, bus)``
imports a module tree and registers every tagged handler. Keeps subscriber
modules independently disable-able: if the module is not discovered, its
handlers never subscribe.
"""

from __future__ import annotations

import importlib
import inspect
import pkgutil
from collections.abc import Callable
from dataclasses import dataclass
from types import ModuleType
from typing import cast

from turbine.core.building_blocks import DomainEvent, EventBus

ON_EVENT_MARKER = "turbine_on_event"


def on[E: DomainEvent](event_type: type[E]) -> Callable[[Callable[[E], None]], Callable[[E], None]]:
    """Mark *handler* as a subscriber for *event_type*.

    The decorator attaches a class attribute the ``discover`` walker uses
    to find handlers. The handler's signature and return type are
    preserved so IDEs continue to type-check calls.
    """

    def decorate(handler: Callable[[E], None]) -> Callable[[E], None]:
        setattr(handler, ON_EVENT_MARKER, event_type)
        return handler

    return decorate


@dataclass(frozen=True, slots=True)
class Subscription:
    """One concrete (event_type, handler) pair discovered in a module."""

    event_type: type[DomainEvent]
    handler: Callable[[DomainEvent], None]
    module: str
    qualname: str


def discover(package: str | ModuleType, bus: EventBus) -> tuple[Subscription, ...]:
    """Import *package* (recursively) and subscribe every ``@on``-tagged handler.

    Returns the subscriptions registered, so tests can assert the expected
    set landed without peeking at bus internals.
    """
    module = importlib.import_module(package) if isinstance(package, str) else package
    subscriptions: list[Subscription] = []
    for member in walk(module):
        subscriptions.extend(find_in(member))
    for sub in subscriptions:
        bus.subscribe(sub.event_type, sub.handler)
    return tuple(subscriptions)


def walk(module: ModuleType) -> list[ModuleType]:
    """Return *module* and every sub-module, importing them eagerly."""
    modules = [module]
    if not hasattr(module, "__path__"):
        return modules
    infos = pkgutil.walk_packages(module.__path__, prefix=f"{module.__name__}.")
    modules.extend(importlib.import_module(info.name) for info in infos)
    return modules


def find_in(module: ModuleType) -> list[Subscription]:
    """Return every ``@on``-tagged handler declared in *module*."""
    found: list[Subscription] = []
    for _, candidate in inspect.getmembers(module, inspect.isfunction):
        if getattr(candidate, "__module__", None) != module.__name__:
            continue
        event_type = getattr(candidate, ON_EVENT_MARKER, None)
        if event_type is None:
            continue
        found.append(
            Subscription(
                event_type=event_type,
                handler=cast("Callable[[DomainEvent], None]", candidate),
                module=module.__name__,
                qualname=candidate.__qualname__,
            )
        )
    return found
