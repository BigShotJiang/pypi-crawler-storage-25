"""Decorator-based event subscription: ``@on`` + ``discover``."""

from .registry import Subscription, discover, on

__all__ = ["Subscription", "discover", "on"]
