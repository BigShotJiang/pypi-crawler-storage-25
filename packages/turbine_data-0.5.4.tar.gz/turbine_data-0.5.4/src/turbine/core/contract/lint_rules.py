"""Concrete lint rules and default rule factory.

Protocols (LintRule, CrossContractRule, RuleCategory) live in ports.py.
"""

from dataclasses import dataclass, replace
from difflib import get_close_matches
from functools import singledispatch
from pathlib import Path

from turbine.core.building_blocks import (
    Diagnostic,
    DiagnosticBuilder,
    DiagnosticData,
    DiagnosticId,
    DiagnosticKind,
    DiagnosticSink,
    Severity,
    SnippetEdit,
    TextRange,
)
from turbine.core.common import (
    CheckDef,
    ColumnDef,
    DatasetSpec,
    PythonCheckConfig,
    SlaProperty,
    SqlCheckConfig,
    WindowCheckConfig,
    closest_match,
)
from turbine.core.common.dataset_spec.checks import MetricType, classify_metric_type
from turbine.core.common.dataset_spec.spec import ContractStatus, resolve_sla_property_time_column
from turbine.core.common.dataset_spec.time_column import resolve_time_column
from turbine.core.common.identifiers import OdcsNameParser, OdcsNameValidity, TableIdentifier
from turbine.core.common.logical_type import LogicalType

from .api_rules import is_codegen_eligible, resource_name, resource_name_rule
from .ports import (
    CheckFileResolver,
    CrossContractRule,
    CrossSchemaRule,
    DomainRegistry,
    LintRule,
    RuleCategory,
    RuleScope,
    TargetContractContext,
)


class DuplicateColumnsRule:
    """Check for duplicate column names in the contract."""

    name = "duplicate-columns"
    category = RuleCategory.STRUCTURE
    scope = RuleScope.PER_SCHEMA

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit an error for each repeated column name."""
        seen: set[str] = set()
        for col in spec.columns:
            if col.name not in seen:
                seen.add(col.name)
                continue
            sink.add(
                DiagnosticBuilder.error(
                    DiagnosticId.VALIDATION,
                    f"duplicate column `{col.name}` is defined more than once in this contract.",
                )
                .span(spec.metadata.source_path)
                .help("Remove or rename one copy so each column name is unique.")
                .build()
            )


class UniqueCheckNamesRule:
    """Check that check names within a contract are unique."""

    name = "unique-check-names"
    category = RuleCategory.NAMING
    scope = RuleScope.PER_SCHEMA

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit an error for each repeated check name."""
        seen: set[str] = set()
        for check in spec.checks:
            if check.name not in seen:
                seen.add(check.name)
                continue
            sink.add(
                DiagnosticBuilder.error(
                    DiagnosticId.VALIDATION,
                    f"Check `{check.name}` is defined more than once in this contract.",
                )
                .span(spec.metadata.source_path)
                .help("rename one of the copies so each check name is unique.")
                .build()
            )


def emit_column_ref_diagnostic(
    check: CheckDef,
    target_columns: set[str],
    target_table: TableIdentifier,
    source_path: Path,
    sink: DiagnosticSink,
) -> None:
    """Emit a single ``check.column does not exist on target`` diagnostic.

    Shared by the cross-contract ``ColumnRefsRule`` (validates a
    QualitySpec against its target) and ``DataContractColumnRefsRule``
    (validates a DataContract against its own owning schema). Splitting
    this out is the only way to keep the two rules' messages identical
    without duplicating the get_close_matches/help logic.
    """
    msg = (
        f"Check `{check.name}` uses column `{check.column}`, but that column does not exist on "
        f"`{target_table}`."
    )
    # Fallback chain: prefer the `column:` line, else the check's `name:` line
    # (always populated by the ODCS reader), else the whole check block.
    span_range = check.column_source_range or check.name_source_range or check.source_range
    builder = DiagnosticBuilder.error(DiagnosticId.VALIDATION, msg).span(source_path, span_range)
    matches = get_close_matches(check.column or "", list(target_columns), n=1, cutoff=0.6)
    if matches:
        # Attaching DiagnosticData (kind + suggested_value) is what wires up the
        # "Did you mean 'X'?" Quick Fix in the editor — the LSP code-action
        # handler dispatches on data.kind, and the `suggested_value_action`
        # generic factory turns suggested_value into a single text edit on the
        # diagnostic's range (which is the column value, so the rename is clean).
        builder.help(f"did you mean `{matches[0]}`?").data(
            DiagnosticData(
                kind=DiagnosticKind.UNKNOWN_COLUMN_REF,
                field_name=check.column,
                suggested_value=matches[0],
            )
        )
    else:
        builder.help(f"available columns: {', '.join(sorted(target_columns))}")
    sink.add(builder.build())


class ColumnRefsRule:
    """Verify that column-level checks reference columns that exist on the target contract."""

    name = "column-refs"
    category = RuleCategory.CROSS_CONTRACT

    def check(self, spec: DatasetSpec, context: TargetContractContext, sink: DiagnosticSink) -> None:
        """Emit an error for each check referencing a non-existent column."""
        target = context.selected
        target_columns = {col.name for col in target.columns}
        for check in spec.checks:
            if check.column is None or check.column in target_columns:
                continue
            emit_column_ref_diagnostic(
                check, target_columns, target.table, spec.metadata.source_path, sink
            )


class DataContractColumnRefsRule:
    """Verify that a DataContract's own checks reference columns on the same schema.

    A multi-schema ODCS contract produces one ``DatasetSpec`` per
    ``schema[i]``, each with its own ``columns`` and its own parsed
    ``checks`` (schema-level + property-level). This rule fires once per
    spec, so a ``column:`` ref under ``schema[0]`` validates against
    ``schema[0].properties`` only — sibling schemas don't bleed in.
    """

    name = "data-contract-column-refs"
    category = RuleCategory.STRUCTURE
    scope = RuleScope.PER_SCHEMA

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit an error for each check referencing a column missing from this spec."""
        own_columns = {col.name for col in spec.columns}
        for check in spec.checks:
            if check.column is None or check.column in own_columns:
                continue
            emit_column_ref_diagnostic(check, own_columns, spec.table, spec.metadata.source_path, sink)


class PrimaryKeyPresentRule:
    """Warn when the target contract has no primary key columns."""

    name = "primary-key-present"
    category = RuleCategory.CROSS_CONTRACT

    def check(self, spec: DatasetSpec, context: TargetContractContext, sink: DiagnosticSink) -> None:
        """Emit a warning when the target dataset lacks a primary key.

        The diagnostic lands on the quality spec's ``dataset:`` line because
        primary-key presence is a property of the dataset (table), not of the
        contract reference.
        """
        target = context.selected
        if any(col.primary_key for col in target.columns):
            return
        sink.add(
            DiagnosticBuilder(
                diagnostic_id=DiagnosticId.QUALITY_ROW_IDENTIFIERS,
                severity=Severity.WARNING,
                message=(
                    f"Cannot show which rows failed in `{target.table}` because no primary key "
                    "is defined."
                ),
            )
            .span(spec.metadata.source_path, spec.dataset_source_range)
            .help(
                "Add `primaryKey: true` to one or more columns in the target contract to enable "
                "row-level failure details."
            )
            .build()
        )


class PrimaryKeyPresentOnSchemaRule:
    """Warn when a contract schema has no primary key columns."""

    name = "primary-key-present-on-schema"
    category = RuleCategory.STRUCTURE
    scope = RuleScope.PER_SCHEMA

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit a dismissible warning when this schema lacks a primary key."""
        if not spec.metadata.is_contract:
            return
        if any(col.primary_key for col in spec.columns):
            return
        schema_name = str(spec.table)
        sink.add(
            DiagnosticBuilder.warning(
                DiagnosticId.QUALITY_ROW_IDENTIFIERS,
                f"Cannot show which rows failed in `{schema_name}` because no primary key is defined. "
                "Add `primaryKey: true` to one or more columns to enable row-level failure details.",
            )
            .span(spec.metadata.source_path, spec.schema_name_source_range)
            .data(
                DiagnosticData(
                    kind=DiagnosticKind.PRIMARY_KEY_PRESENT_ON_SCHEMA, schema_name=schema_name
                )
            )
            .dismissible(schema_name)
            .build()
        )


class ResourceNameDerivedRule:
    """Warn in the editor when the API URL slug Turbine derived for this dataset isn't a pass-through.

    Wraps :func:`turbine.core.contract.api_rules.resource_name_rule` so the
    same per-dataset check that the codegen pipeline runs surfaces in the
    LSP. Gated on contract eligibility — Quality Specs, contracts without
    a domain, and RETIRED contracts produce no diagnostic. The dismissal
    anchor is ``f"{table}::{slug}"`` so renaming the underlying table
    invalidates the dismissal automatically.
    """

    name = "resource-name-derived"
    category = RuleCategory.NAMING
    scope = RuleScope.PER_SCHEMA

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit a dismissible warning when the helper returns a diagnostic for this spec."""
        if not spec.metadata.is_contract:
            return
        domain = spec.metadata.domain
        if domain is None or not domain.strip():
            return
        if not is_codegen_eligible(spec, include_drafts=True, include_proposed=True):
            return
        diagnostic = resource_name_rule(spec)
        if diagnostic is None:
            return
        derived = resource_name(spec)
        anchor = f"{spec.table}::{derived.value}"
        builder = (
            DiagnosticBuilder.warning(diagnostic.id, diagnostic.message)
            .span(spec.metadata.source_path, spec.schema_name_source_range or spec.dataset_source_range)
            .data(
                DiagnosticData(
                    kind=DiagnosticKind.RESOURCE_NAME_DERIVED,
                    schema_name=str(spec.table),
                    suggested_value=derived.value,
                )
            )
            .dismissible(anchor)
        )
        for sub in diagnostic.subs:
            builder.help(sub.message)
        sink.add(builder.build())


class DomainNotInAllowedListRule:
    """Warn when a Contract domain is outside the approved registry."""

    name = "domain-not-in-allowed-list"
    category = RuleCategory.NAMING
    scope = RuleScope.PER_CONTRACT

    def __init__(self, registry: DomainRegistry) -> None:
        """Store the registry of approved domain values."""
        self.registry = registry

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit a dismissible warning when this Contract domain is not approved."""
        if not spec.metadata.is_contract:
            return
        domain_value = spec.metadata.domain
        if domain_value is None or not domain_value.strip():
            return
        allowed = self.registry.allowed()
        if allowed is None or domain_value in allowed:
            return
        sink.add(
            DiagnosticBuilder.warning(
                DiagnosticId.VALIDATION, f"domain '{domain_value}' is not in the approved list"
            )
            .span(spec.metadata.source_path, spec.metadata.domain_source_range)
            .data(
                DiagnosticData(
                    kind=DiagnosticKind.DOMAIN_NOT_IN_ALLOWED_LIST,
                    field_name="domain",
                    contract_value=domain_value,
                )
            )
            .dismissible(domain_value)
            .build()
        )


class ColumnDescriptionRequiredRule:
    """Info when contract columns have no human-written description."""

    name = "column-description-required"
    category = RuleCategory.SCHEMA

    def check(self, specs: tuple[DatasetSpec, ...], sink: DiagnosticSink) -> None:
        """Emit dismissible info diagnostics for columns without descriptions."""
        contract_specs = tuple(spec for spec in specs if spec.metadata.is_contract)
        if not contract_specs:
            return
        has_multiple_schemas = len(contract_specs) > 1
        for spec in contract_specs:
            for column in spec.columns:
                if column.description is not None and column.description.strip():
                    continue
                sink.add(self.build_diagnostic(spec, column, has_multiple_schemas=has_multiple_schemas))

    @staticmethod
    def build_diagnostic(
        spec: DatasetSpec, column: ColumnDef, *, has_multiple_schemas: bool
    ) -> Diagnostic:
        """Build the missing-description diagnostic for one column."""
        schema_name = str(spec.table)
        anchor = f"{schema_name}.{column.name}" if has_multiple_schemas else column.name
        builder = (
            DiagnosticBuilder.info(DiagnosticId.VALIDATION, f"column '{column.name}' has no description")
            .span(spec.metadata.source_path, column.source_range)
            .data(
                DiagnosticData(
                    kind=DiagnosticKind.COLUMN_DESCRIPTION_REQUIRED,
                    field_name=column.name,
                    schema_name=schema_name,
                )
            )
            .dismissible(anchor)
        )
        snippet = ColumnDescriptionRequiredRule.description_snippet(column)
        if snippet is not None:
            builder.fix("Add `description:` placeholder", snippet=snippet, preferred=True)
        return builder.build()

    @staticmethod
    def description_snippet(column: ColumnDef) -> SnippetEdit | None:
        """Build the snippet that inserts a `description:` child into a column block.

        Inserts on the line *after* the column header (``- name: …``) at the
        same indentation as the ``name:`` key — siblings inside a YAML list
        item share that column. ``source_range`` is set via ``range_for_key``
        on the ``name`` path, so ``start_col`` already lands on the key itself.
        Returns ``None`` when no source range is available — the rule still
        emits the info diagnostic without an inline fix in that case.
        """
        text_range = column.source_range
        if text_range is None:
            return None
        insert_line = text_range.start_line + 1
        indent = " " * (text_range.start_col - 1)
        snippet_text = f"{indent}description: ${{1:Describe {column.name}}}\n"
        return SnippetEdit(line=insert_line, col=1, snippet_text=snippet_text)


class OdcsNameUnqualifiedRule:
    """Info when an ODCS schema ``name:`` omits the schema qualifier."""

    name = "odcs-name-unqualified"
    category = RuleCategory.SCHEMA

    def check(self, specs: tuple[DatasetSpec, ...], sink: DiagnosticSink) -> None:
        """Emit dismissible info diagnostics for bare schema names."""
        for spec in specs:
            if not spec.metadata.is_contract or spec.odcs_schema_name is None:
                continue
            parsed = OdcsNameParser.parse(spec.odcs_schema_name)
            if parsed.validity is not OdcsNameValidity.UNQUALIFIED:
                continue
            suggested_name = f"{parsed.schema}.{parsed.table}"
            sink.add(
                DiagnosticBuilder.info(
                    DiagnosticId.ODCS_NAME_UNQUALIFIED,
                    f"Use the full table path '{suggested_name}' instead of '{spec.odcs_schema_name}'.",
                )
                .span(spec.metadata.source_path, spec.schema_name_source_range)
                .help(
                    "Use `schema.table` to make the database lookup explicit, or dismiss this "
                    "if your datasource default schema is intentional."
                )
                .data(
                    DiagnosticData(
                        kind=DiagnosticKind.ODCS_NAME_UNQUALIFIED,
                        schema_name=suggested_name,
                        suggested_value=suggested_name,
                    )
                )
                .dismissible(str(spec.schema_index))
                .build()
            )


class OdcsNameMalformedRule:
    """Error when an ODCS schema ``name:`` cannot be interpreted as ``schema.table``."""

    name = "odcs-name-malformed"
    category = RuleCategory.SCHEMA

    def check(self, specs: tuple[DatasetSpec, ...], sink: DiagnosticSink) -> None:
        """Emit non-dismissible errors for malformed schema names."""
        for spec in specs:
            if not spec.metadata.is_contract or spec.odcs_schema_name is None:
                continue
            parsed = OdcsNameParser.parse(spec.odcs_schema_name)
            if parsed.validity is not OdcsNameValidity.MALFORMED:
                continue
            sink.add(
                DiagnosticBuilder.error(
                    DiagnosticId.ODCS_NAME_MALFORMED,
                    f"Table name '{spec.odcs_schema_name}' has too many parts.",
                )
                .span(spec.metadata.source_path, spec.schema_name_source_range)
                .help("Use either a table name or exactly two dot-separated parts: `schema.table`.")
                .data(DiagnosticData(kind=DiagnosticKind.ODCS_NAME_MALFORMED))
                .build()
            )


class RequiredFalsePrimaryKeyRule:
    """Reject columns marked both ``required: false`` and ``primaryKey: true``."""

    name = "required-false-primary-key"
    category = RuleCategory.STRUCTURE
    scope = RuleScope.PER_SCHEMA

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit an error for each primary-key column explicitly marked nullable."""
        for column in spec.columns:
            if column.required is not False or not column.primary_key:
                continue
            sink.add(self.build_diagnostic(spec, column))

    @staticmethod
    def build_diagnostic(spec: DatasetSpec, column: ColumnDef) -> Diagnostic:
        """Build the primary-key nullability diagnostic for one column."""
        return (
            DiagnosticBuilder.error(
                DiagnosticId.VALIDATION,
                f"column '{column.name}' is marked primaryKey: true but required: false — "
                "primary keys must be NOT NULL",
            )
            .span(spec.metadata.source_path, column.primary_key_source_range or column.source_range)
            .data(
                DiagnosticData(
                    kind=DiagnosticKind.REQUIRED_FALSE_PRIMARY_KEY,
                    field_name=column.name,
                    required_range=column.required_source_range,
                )
            )
            .build()
        )


DEPRECATED_STATUSES = frozenset({ContractStatus.DEPRECATED, ContractStatus.RETIRED})


class DeprecatedTargetRule:
    """Flag quality specs that reference a deprecated or retired contract.

    Emits a tagged diagnostic so the ``targetContract:`` value is rendered
    with strikethrough styling in the editor. Severity tracks how bad the
    reference is:

    - ``deprecated`` → warning (advisory, the contract still exists but is
      being phased out)
    - ``retired``    → error (hard break, the contract should not be
      referenced at all)
    """

    name = "deprecated-target-contract"
    category = RuleCategory.CROSS_CONTRACT

    def check(self, spec: DatasetSpec, context: TargetContractContext, sink: DiagnosticSink) -> None:
        """Emit a tagged diagnostic when the referenced contract is deprecated/retired."""
        target = context.selected
        status = target.metadata.status
        if status not in DEPRECATED_STATUSES:
            return
        label = status.value
        contract_id = target.metadata.contract_id
        is_retired = status == ContractStatus.RETIRED
        severity = Severity.ERROR if is_retired else Severity.WARNING
        help_text = (
            f"this contract is marked `status: {label}` — it should no longer be used"
            if is_retired
            else f"this contract is marked `status: {label}` — prefer an active replacement"
        )
        sink.add(
            DiagnosticBuilder(
                diagnostic_id=DiagnosticId.VALIDATION,
                severity=severity,
                message=f"contract `{contract_id}` is {label}",
            )
            .span(spec.metadata.source_path, spec.target_contract_source_range)
            .help(help_text)
            .deprecated()
            .build()
        )


class EmptyTargetRule:
    """Warn when the target contract has no columns defined."""

    name = "empty-target-contract"
    category = RuleCategory.CROSS_CONTRACT

    def check(self, spec: DatasetSpec, context: TargetContractContext, sink: DiagnosticSink) -> None:
        """Emit a warning when the target contract has zero columns."""
        target = context.selected
        if target.columns:
            return
        contract_id = target.metadata.contract_id
        sink.add(
            DiagnosticBuilder.warning(
                DiagnosticId.VALIDATION,
                f"target contract `{contract_id}` has no columns defined"
                " — column-level checks will not match anything",
            )
            .span(spec.metadata.source_path, spec.target_contract_source_range)
            .help("add `properties:` under the contract schema to declare columns")
            .build()
        )


class DatasetNotInTargetRule:
    """Error when a quality spec's ``dataset:`` is not in the target Contract."""

    name = "dataset-not-in-target"
    category = RuleCategory.CROSS_CONTRACT

    def check(self, spec: DatasetSpec, context: TargetContractContext, sink: DiagnosticSink) -> None:
        """Emit an error when spec.dataset is not one of the target Contract datasets."""
        dataset_name = str(spec.table)
        valid_dataset_names = context.valid_dataset_names
        if dataset_name in valid_dataset_names:
            return

        suggestion = closest_match(dataset_name, valid_dataset_names, max_distance=3)
        sink.add(
            DiagnosticBuilder.error(
                DiagnosticId.DATASET_NOT_IN_TARGET,
                f"dataset `{dataset_name}` does not exist on target contract `{context.contract_id}`",
            )
            .span(spec.metadata.source_path, spec.dataset_source_range)
            .help(f"valid datasets: {', '.join(valid_dataset_names)}")
            .docs(DiagnosticId.DATASET_NOT_IN_TARGET)
            .data(
                DiagnosticData(
                    kind=DiagnosticKind.DATASET_MISMATCH,
                    field_name=dataset_name,
                    suggested_value=suggestion,
                )
            )
            .build()
        )


class CheckFileExistsRule:
    """Verify that check files referenced in the spec exist on disk.

    Delegates path resolution to a ``CheckFileResolver`` (adapter concern),
    keeping this rule free of filesystem layout knowledge.
    """

    name = "check-file-exists"
    category = RuleCategory.STRUCTURE
    scope = RuleScope.PER_SCHEMA

    def __init__(self, resolver: CheckFileResolver) -> None:
        """Store the file resolver used to locate check files."""
        self.resolver = resolver

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit an error for each check referencing a file that doesn't exist."""
        for check_def in spec.checks:
            if self.diagnose_missing_python_ref(check_def, spec, sink):
                continue
            if (expected_path := self.resolver.resolve_path(check_def)) is None:
                continue
            if expected_path.exists():
                continue
            ref_range = self.ref_source_range(check_def.config)
            sink.add(
                DiagnosticBuilder.error(
                    DiagnosticId.QUALITY_CHECK_FILE_NOT_FOUND, f"check file not found: {expected_path}"
                )
                .span(spec.metadata.source_path, ref_range or check_def.source_range)
                .label(f"file does not exist: {expected_path.name}")
                .help(f"create {expected_path} or fix the path")
                .build()
            )

    @staticmethod
    def diagnose_missing_python_ref(
        check_def: CheckDef, spec: DatasetSpec, sink: DiagnosticSink
    ) -> bool:
        """Emit a focused diagnostic when a python check has no resolvable function reference.

        Returns True when a diagnostic was added so the caller skips the
        generic ``check file not found`` path.
        """
        config = check_def.config
        if not isinstance(config, PythonCheckConfig):
            return False
        if config.function_ref:
            return False
        sink.add(
            DiagnosticBuilder.error(
                DiagnosticId.QUALITY_CHECK_FILE_NOT_FOUND,
                f"python check `{check_def.name}` has no `function:` reference",
            )
            .span(spec.metadata.source_path, check_def.source_range)
            .label("missing `function:` inside the implementation block")
            .help(
                "add `function: <name>` inside `implementation:`. "
                "the runtime resolves it to `checks/<name>.py` and looks up the "
                "function called `<name>` inside that file (or import it as a dotted "
                "module path like `pkg.mod.func`)"
            )
            .build()
        )
        return True

    @staticmethod
    def ref_source_range(config: object) -> TextRange | None:
        """Extract the source range pointing to the file/function reference value."""
        return ref_source_range(config)


@singledispatch
def ref_source_range(config: object) -> TextRange | None:
    """Extract the source range from a check config, dispatched by type.

    Returns None for unrecognized config types.
    """
    del config
    return None


@ref_source_range.register
def sql_ref_source_range(config: SqlCheckConfig) -> TextRange | None:
    """Source range for SQL check file reference."""
    return config.file_source_range


@ref_source_range.register
def python_ref_source_range(config: PythonCheckConfig) -> TextRange | None:
    """Source range for Python check function reference."""
    return config.function_source_range


TIME_LIKE_LOGICAL_TYPES: frozenset[LogicalType] = frozenset(
    {LogicalType.TIMESTAMP, LogicalType.DATETIME, LogicalType.DATE}
)

TIME_COLUMN_ELEMENT_PLACEHOLDER = "<schema>.<table>.<column>"
QUALIFIED_ELEMENT_PART_COUNT = 3


def suggest_time_column_element(specs: tuple[DatasetSpec, ...]) -> str:
    """Pick the fully-qualified element string a missing time-column quick-fix should insert."""
    for spec in specs:
        for column in spec.columns:
            if column.logical_type in TIME_LIKE_LOGICAL_TYPES:
                return qualify_sla_element(spec.table, column.name)
    return TIME_COLUMN_ELEMENT_PLACEHOLDER


def qualify_sla_element(table: TableIdentifier, column_name: str) -> str:
    """Join the non-empty parts of *table* with *column_name* into ``schema.table.column``."""
    parts = tuple(part for part in (table.schema, table.table, column_name) if part)
    return ".".join(parts) if parts else column_name


def element_resolves_to_spec(element: str | None, spec: DatasetSpec) -> bool:
    """Return True when *element* points at one of *spec*'s columns."""
    if element is None:
        return False
    prop = SlaProperty(property="time-column", element=element)
    return resolve_sla_property_time_column(prop, spec) is not None


def replace_sla_element_segment(element: str, segment_index: int, replacement: str) -> str:
    """Return *element* with one dotted segment replaced."""
    parts = element.split(".")
    parts[segment_index] = replacement
    return ".".join(parts)


def segment_source_range(
    element: str, segment_index: int, source_range: TextRange | None
) -> TextRange | None:
    """Return a source range for one dotted segment inside an SLA element value."""
    if source_range is None:
        return None
    parts = element.split(".")
    start_offset = sum(len(part) + 1 for part in parts[:segment_index])
    token = parts[segment_index]
    return TextRange(
        start_line=source_range.start_line,
        start_col=source_range.start_col + start_offset,
        end_line=source_range.start_line,
        end_col=source_range.start_col + start_offset + len(token),
    )


class SlaTimeColumnPerSchemaRule:
    """Require each schema to have an SLA element pointing at one of its columns."""

    name = "sla-time-column-per-schema"
    category = RuleCategory.SCHEMA
    scope = RuleScope.CROSS_SCHEMA

    def check(self, specs: tuple[DatasetSpec, ...], sink: DiagnosticSink) -> None:
        """Emit errors when SLA time-column entries are missing or invalid."""
        contract_specs = tuple(spec for spec in specs if spec.metadata.is_contract)
        if not contract_specs:
            return
        first = contract_specs[0]
        sla_properties = first.sla.properties if first.sla else ()
        for prop in sla_properties:
            self.validate_qualified_element(prop, contract_specs, first.metadata.source_path, sink)
        for spec in contract_specs:
            if any(element_resolves_to_spec(prop.element, spec) for prop in sla_properties):
                continue
            sink.add(self.build_missing_diagnostic(spec))

    @staticmethod
    def build_missing_diagnostic(spec: DatasetSpec) -> Diagnostic:
        """Build the missing time-column diagnostic for one schema."""
        diagnostic = (
            DiagnosticBuilder.error(
                DiagnosticId.SLA_MISSING_TIME_COLUMN,
                f"Table `{spec.table}` needs a date or timestamp column for time-based checks.",
            )
            .span(spec.metadata.source_path)
            .help("Add an `slaProperties` entry whose `element` points to a date or timestamp column.")
            .build()
        )
        return replace(
            diagnostic,
            data=DiagnosticData(
                kind=DiagnosticKind.SLA_MISSING_TIME_COLUMN,
                suggested_value=suggest_time_column_element((spec,)),
            ),
        )

    @staticmethod
    def validate_qualified_element(
        prop: SlaProperty, specs: tuple[DatasetSpec, ...], source_path: Path, sink: DiagnosticSink
    ) -> None:
        """Validate ``schema.table.column`` SLA elements one segment at a time."""
        element = prop.element
        source_range = prop.source_range
        if element is None:
            return
        parts = element.split(".")
        if len(parts) != QUALIFIED_ELEMENT_PART_COUNT:
            return
        schema_name, table_name, column_name = parts
        schema_names = sorted({spec.table.schema for spec in specs if spec.table.schema})
        if schema_name not in schema_names:
            sink.add(
                build_sla_segment_diagnostic(
                    SlaSegmentDiagnosticRequest(
                        element=element,
                        token=schema_name,
                        valid_values=schema_names,
                        segment_index=0,
                        source_path=source_path,
                        source_range=source_range,
                        segment_name="schema",
                    )
                )
            )
            return
        table_names = sorted({spec.table.table for spec in specs if spec.table.schema == schema_name})
        if table_name not in table_names:
            sink.add(
                build_sla_segment_diagnostic(
                    SlaSegmentDiagnosticRequest(
                        element=element,
                        token=table_name,
                        valid_values=table_names,
                        segment_index=1,
                        source_path=source_path,
                        source_range=source_range,
                        segment_name="table",
                    )
                )
            )
            return
        column_names = sorted(
            {
                column.name
                for spec in specs
                if spec.table.schema == schema_name and spec.table.table == table_name
                for column in spec.columns
            }
        )
        if column_name in column_names:
            return
        sink.add(
            build_sla_segment_diagnostic(
                SlaSegmentDiagnosticRequest(
                    element=element,
                    token=column_name,
                    valid_values=column_names,
                    segment_index=2,
                    source_path=source_path,
                    source_range=source_range,
                    segment_name="column",
                )
            )
        )


@dataclass(frozen=True, slots=True)
class SlaSegmentDiagnosticRequest:
    """Inputs needed to build an invalid SLA element diagnostic."""

    element: str
    token: str
    valid_values: list[str]
    segment_index: int
    source_path: Path
    source_range: TextRange | None
    segment_name: str


def build_sla_segment_diagnostic(request: SlaSegmentDiagnosticRequest) -> Diagnostic:
    """Build an invalid SLA element diagnostic for one bad dotted segment."""
    suggestion = sla_segment_suggestion(request.token, request.valid_values)
    suggested_value = (
        replace_sla_element_segment(request.element, request.segment_index, suggestion)
        if suggestion is not None
        else None
    )
    builder = DiagnosticBuilder.error(
        DiagnosticId.SLA_INVALID_ELEMENT,
        f"SLA element `{request.element}` has an unknown {request.segment_name}: `{request.token}`.",
    ).span(
        request.source_path,
        segment_source_range(request.element, request.segment_index, request.source_range),
    )
    if suggestion is not None:
        builder.help(f"did you mean `{suggestion}`?")
    else:
        builder.help(f"available {request.segment_name}s: {', '.join(request.valid_values)}")
    return (
        builder.docs(DiagnosticId.SLA_INVALID_ELEMENT)
        .data(
            DiagnosticData(
                kind=DiagnosticKind.SLA_INVALID_ELEMENT,
                field_name=request.token,
                suggested_value=suggested_value,
            )
        )
        .build()
    )


def sla_segment_suggestion(token: str, valid_values: list[str]) -> str | None:
    """Return the closest valid segment, falling back to the only valid value."""
    matches = get_close_matches(token, valid_values, n=1, cutoff=0.5)
    if matches:
        return matches[0]
    if len(valid_values) == 1:
        return valid_values[0]
    return None


NO_WINDOW_CHECK_TYPES = frozenset({"schema", "freshness"})


class WindowRequiresSlaElementRule:
    """A check with ``window:`` requires a resolvable SLA time column."""

    name = "window-requires-sla-element"
    category = RuleCategory.SCHEMA
    scope = RuleScope.PER_CONTRACT

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        if spec.time_column is not None:
            return
        for check_def in spec.checks:
            if check_def.window is not None:
                sink.add(
                    DiagnosticBuilder.error(
                        DiagnosticId.WINDOW_REQUIRES_SLA_ELEMENT,
                        f"Check `{check_def.name}` uses `window`, but no date or timestamp "
                        "column is set.",
                    )
                    .span(spec.metadata.source_path, check_def.source_range)
                    .help("Add an `slaProperties` entry whose `element` points to a timestamp column.")
                    .build()
                )


class WindowNotApplicableRule:
    """``window:`` is not meaningful on schema or freshness checks."""

    name = "window-not-applicable"
    category = RuleCategory.SCHEMA
    scope = RuleScope.PER_CONTRACT

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        for check_def in spec.checks:
            if check_def.window is not None and check_def.check_type in NO_WINDOW_CHECK_TYPES:
                sink.add(
                    DiagnosticBuilder.error(
                        DiagnosticId.WINDOW_NOT_APPLICABLE,
                        f"`window` cannot be used on `{check_def.check_type}` checks.",
                    )
                    .span(spec.metadata.source_path, check_def.source_range)
                    .help(f"Remove `window` from this `{check_def.check_type}` check.")
                    .build()
                )


class AnomalyTimeColumnRequiredRule:
    """A time-based anomaly window needs a time column on the check or the SLA.

    Row-based anomaly windows (``size: N``) order by any column and do
    not need a time dimension. Time-based windows (``window: 2d``)
    cannot render without a resolvable time column; the renderer would
    produce an ``ORDER BY`` that points at nothing and the scan would
    silently pick an arbitrary order.
    """

    name = "anomaly-time-column-required"
    category = RuleCategory.SCHEMA
    scope = RuleScope.PER_CONTRACT

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit an error for every time-based anomaly check without a time column."""
        for check_def in spec.checks:
            config = check_def.config
            if not isinstance(config, WindowCheckConfig):
                continue
            if config.window is None:
                continue
            if self.has_time_column(check_def, spec):
                continue
            sink.add(self.build_diagnostic(check_def, spec))

    @staticmethod
    def has_time_column(check_def: CheckDef, spec: DatasetSpec) -> bool:
        """Return True when the precedence check.order_by → SLA time column yields a column."""
        return resolve_time_column(check_def, spec) is not None

    @staticmethod
    def build_diagnostic(check_def: CheckDef, spec: DatasetSpec) -> Diagnostic:
        """Construct the missing-time-column diagnostic for one anomaly check."""
        return (
            DiagnosticBuilder.error(
                DiagnosticId.WINDOW_REQUIRES_SLA_ELEMENT,
                (
                    f"Anomaly check `{check_def.name}` uses a time-based window but no date "
                    "or timestamp column is set."
                ),
            )
            .span(spec.metadata.source_path, check_def.source_range)
            .help(
                "Set `order_by` on the check, or add an `slaProperties` entry whose `element` "
                "points to a timestamp column."
            )
            .build()
        )


class WindowAndSizeExclusiveRule:
    """An anomaly check cannot set both ``window:`` and ``size:``."""

    name = "window-and-size-exclusive"
    category = RuleCategory.SCHEMA
    scope = RuleScope.PER_CONTRACT

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        for check_def in spec.checks:
            config = check_def.config
            if not isinstance(config, WindowCheckConfig):
                continue
            if config.window is not None and config.size is not None:
                sink.add(
                    DiagnosticBuilder.error(
                        DiagnosticId.WINDOW_AND_SIZE_EXCLUSIVE,
                        f"anomaly check '{check_def.name}' sets both window and size",
                    )
                    .span(spec.metadata.source_path, check_def.source_range)
                    .help("use either window (time-based) or size (row-based), not both")
                    .build()
                )


# MetricTypes structurally exempt from CheckThresholdRequiredRule.
# A schema check is a shape assertion: pass/fail comes from the column
# list match, not from a row-count verdict. Custom-SQL checks have an
# implicit ``mustBe: 0`` verdict (pass when zero rows come back) so a
# missing threshold is unambiguous; the runtime fills it in. Every other
# metric — including anomaly-family checks like flatline, zscore, spike —
# carries a row-count verdict and needs an explicit mustBe* threshold.
# Keep in sync with the `takes_threshold` flag on check_catalog entries.
THRESHOLD_EXEMPT_METRIC_TYPES: frozenset[MetricType] = frozenset(
    {MetricType.SCHEMA, MetricType.CUSTOM_SQL}
)


@dataclass(frozen=True, slots=True)
class ThresholdMissingCopy:
    """Copy for a `threshold missing` diagnostic, keyed by source kind."""

    diagnostic_id: DiagnosticId
    severity: Severity
    message_template: str
    help_text: str


CONTRACT_THRESHOLD_COPY = ThresholdMissingCopy(
    diagnostic_id=DiagnosticId.CHECK_THRESHOLD_REQUIRED_ERROR,
    severity=Severity.ERROR,
    message_template=("Contract check `{name}` needs a pass/fail verdict condition."),
    help_text=("Add a `mustBe*` field, for example `mustBe: 0` or `mustBeLessThan: 10`."),
)

SPEC_THRESHOLD_COPY = ThresholdMissingCopy(
    diagnostic_id=DiagnosticId.CHECK_THRESHOLD_REQUIRED_ERROR,
    severity=Severity.ERROR,
    message_template="Check `{name}` needs a pass/fail condition.",
    help_text=("Add a `mustBe*` field, for example `mustBe: 0` or `mustBeLessThan: 10`."),
)


class CheckThresholdRequiredRule:
    """Require a threshold operator on non-structural checks.

    Fires ERROR on every non-exempt check missing a ``mustBe*`` field. Check
    types in the exempt allowlist are skipped.
    """

    name = "check-threshold-required"
    category = RuleCategory.SCHEMA
    scope = RuleScope.PER_CONTRACT

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit a diagnostic for every non-exempt check missing a threshold."""
        for check_def in spec.checks:
            if self.should_skip(check_def):
                continue
            sink.add(self.build_diagnostic(check_def, spec))

    @staticmethod
    def should_skip(check_def: CheckDef) -> bool:
        """Return True when the check already has a threshold or its metric type is exempt."""
        if check_def.threshold is not None:
            return True
        metric_type = check_def.metric_type or classify_metric_type(check_def)
        return metric_type in THRESHOLD_EXEMPT_METRIC_TYPES

    @staticmethod
    def build_diagnostic(check_def: CheckDef, spec: DatasetSpec) -> Diagnostic:
        """Construct the diagnostic for a single thresholdless check."""
        copy = CONTRACT_THRESHOLD_COPY if check_def.is_contract else SPEC_THRESHOLD_COPY
        text_range = check_def.name_source_range or check_def.source_range
        return (
            DiagnosticBuilder(
                diagnostic_id=copy.diagnostic_id,
                severity=copy.severity,
                message=copy.message_template.format(name=check_def.name),
            )
            .span(spec.metadata.source_path, text_range)
            .help(copy.help_text)
            .build()
        )


class CheckDimensionRequiredRule:
    """Every check must declare an explicit ``dimension``.

    ODCS contracts previously fell back to ``accuracy`` when ``dimension``
    was absent; that silent default hid intent. The reader now keeps the
    value as ``None`` and this rule surfaces it as an ERROR on both
    DataContract and QualitySpec files.
    """

    name = "check-dimension-required"
    category = RuleCategory.SCHEMA
    scope = RuleScope.PER_CONTRACT

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit a diagnostic for every check whose dimension is None."""
        for check_def in spec.checks:
            if check_def.dimension is not None:
                continue
            sink.add(self.build_diagnostic(check_def, spec))

    @staticmethod
    def build_diagnostic(check_def: CheckDef, spec: DatasetSpec) -> Diagnostic:
        """Construct the missing-dimension diagnostic for a single check."""
        text_range = check_def.name_source_range or check_def.source_range
        return (
            DiagnosticBuilder.error(
                DiagnosticId.CHECK_DIMENSION_REQUIRED,
                f"check `{check_def.name}` is missing required field `dimension`",
            )
            .span(spec.metadata.source_path, text_range)
            .help(
                "add a `dimension:` field with one of: accuracy, completeness, consistency, timeliness"
            )
            .build()
        )


class MissingOwnerRule:
    """Quality specs should identify a human or team owner."""

    name = "missing-owner"
    category = RuleCategory.SCHEMA
    scope = RuleScope.PER_CONTRACT

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit a warning when a Quality Spec has no non-blank owner."""
        if self.should_skip(spec):
            return
        sink.add(self.build_diagnostic(spec))

    @staticmethod
    def should_skip(spec: DatasetSpec) -> bool:
        """Return True when owner validation does not apply or owner is present."""
        if spec.metadata.is_contract:
            return True
        if spec.metadata.source_format != "quality_spec":
            return True
        return bool(spec.metadata.owner and spec.metadata.owner.strip())

    @staticmethod
    def build_diagnostic(spec: DatasetSpec) -> Diagnostic:
        """Construct the missing-owner diagnostic for a Quality Spec."""
        builder = (
            DiagnosticBuilder.warning(
                DiagnosticId.QUALITY_SPEC_OWNER_MISSING, "quality spec is missing `owner`"
            )
            .span(spec.metadata.source_path)
            .help("add top-level `owner:` with a team, channel, or contact handle")
            .docs(DiagnosticId.QUALITY_SPEC_OWNER_MISSING)
            .data(DiagnosticData(kind=DiagnosticKind.MISSING_OWNER))
            .dismissible(None)
        )
        anchor = MissingOwnerRule.owner_insert_anchor(spec)
        if anchor is not None:
            builder.fix(
                "Add `owner:` placeholder",
                snippet=SnippetEdit(line=anchor, col=1, snippet_text="owner: ${1:team-or-channel}\n"),
                preferred=True,
            )
        return builder.build()

    @staticmethod
    def owner_insert_anchor(spec: DatasetSpec) -> int | None:
        """Return the 1-indexed line *after* the last known top-level metadata key.

        Prefers the last of ``version:`` / ``id:`` / ``dataset:`` we can locate.
        ``None`` skips the inline fix — the rule still emits the warning, just
        without a quick action.
        """
        candidates = (
            spec.metadata.version_source_range,
            spec.metadata.contract_id_source_range,
            spec.dataset_source_range,
            spec.target_contract_source_range,
        )
        anchors = [text_range.end_line + 1 for text_range in candidates if text_range is not None]
        return max(anchors) if anchors else None


class UsageRecommendedRule:
    """Info: when a contract fills in `description:`, suggest also writing `usage:`.

    `purpose:` is required by the JSON schema, so by the time this rule runs the
    `description:` block is always present on valid contracts. `usage:` is still
    optional, but it is the section consumers reach for when they want to know
    how to read the data — so we nudge once per contract, dismissible by the
    author. When the `purpose:` source range is known the diagnostic carries an
    inline snippet that inserts a sibling `usage:` placeholder at the matching
    indentation.
    """

    name = "usage-recommended"
    category = RuleCategory.SCHEMA
    scope = RuleScope.PER_CONTRACT

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit a dismissible info when description is present but usage is empty."""
        if not spec.metadata.is_contract:
            return
        if spec.metadata.description_source_range is None:
            return
        usage = spec.metadata.description_usage
        if usage and usage.strip():
            return
        builder = (
            DiagnosticBuilder.info(
                DiagnosticId.VALIDATION,
                "Add `description.usage` — consumers use it to learn how to read this dataset.",
            )
            .span(spec.metadata.source_path, spec.metadata.description_source_range)
            .help("Describe how downstream users should interpret the data, with examples or caveats.")
            .data(DiagnosticData(kind=DiagnosticKind.USAGE_RECOMMENDED))
            .dismissible(None)
        )
        snippet = UsageRecommendedRule.usage_snippet(spec)
        if snippet is not None:
            builder.fix("Add `usage:` placeholder", snippet=snippet, preferred=True)
        sink.add(builder.build())

    @staticmethod
    def usage_snippet(spec: DatasetSpec) -> SnippetEdit | None:
        """Build the snippet that inserts a sibling `usage:` under `description:`.

        Lands one line after `purpose:` at the same indentation, so the inserted
        key sits as a YAML sibling rather than a child. Returns ``None`` when the
        `purpose:` source range is unknown — the diagnostic still fires, just
        without an inline fix.
        """
        purpose_range = spec.metadata.description_purpose_source_range
        if purpose_range is None:
            return None
        indent = " " * (purpose_range.start_col - 1)
        snippet_text = f"{indent}usage: ${{1:How consumers should read and interpret this dataset.}}\n"
        return SnippetEdit(line=purpose_range.end_line + 1, col=1, snippet_text=snippet_text)


class CustomSqlReturnsFailingRowsRule:
    """Custom-SQL checks must return failing rows, not a scalar count.

    A ``SELECT count(*) ...`` returns a single row holding the count value;
    ``len(rows)`` is then 1 regardless of the actual count, so the check
    appears to fail forever even when zero rows would match. The verdict
    is "row count returned by the SELECT" — so the SELECT must produce
    one row per failure.
    """

    name = "custom-sql-returns-failing-rows"
    category = RuleCategory.STRUCTURE
    scope = RuleScope.PER_CONTRACT

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Emit a warning for each custom-SQL check whose query is a count(*) shape."""
        for check_def in spec.checks:
            config = check_def.config
            if not isinstance(config, SqlCheckConfig):
                continue
            if not config.query:
                continue
            if not is_count_only_query(config.query):
                continue
            sink.add(self.build_diagnostic(check_def, spec))

    @staticmethod
    def build_diagnostic(check_def: CheckDef, spec: DatasetSpec) -> Diagnostic:
        """Construct the count-shape diagnostic for one custom-SQL check."""
        return (
            DiagnosticBuilder.error(
                DiagnosticId.CHECK_DEFINITION_ERROR,
                f"custom-sql check `{check_def.name}` returns a count, not failing rows",
            )
            .span(spec.metadata.source_path, check_def.source_range)
            .help(
                "rewrite the query to project one row per failure instead of "
                "`SELECT count(*) ...`. example:\n"
                "  query: |\n"
                "    SELECT pk_col, offending_col\n"
                "    FROM <table>\n"
                "    WHERE <bad-row predicate>"
            )
            .build()
        )


def is_count_only_query(query: str) -> bool:
    """Return True when *query* is a single-row scalar SELECT (count(*), avg, ...).

    Conservative: only flags a SELECT whose top-level projections are all
    pure aggregates with no GROUP BY. A subquery containing aggregates is
    fine — only the outer shape matters.
    """
    import sqlglot  # noqa: PLC0415 — keep sqlglot off the cold-start path

    try:
        tree = sqlglot.parse_one(query, dialect=None)
    except sqlglot.errors.ParseError:
        return False
    if not isinstance(tree, sqlglot.exp.Select):
        return False
    if tree.args.get("group"):
        return False
    projections = tree.expressions or []
    if not projections:
        return False
    aggregate_types: tuple[type[sqlglot.exp.Expression], ...] = (
        sqlglot.exp.Count,
        sqlglot.exp.Sum,
        sqlglot.exp.Avg,
        sqlglot.exp.Min,
        sqlglot.exp.Max,
        sqlglot.exp.Stddev,
    )
    return all(isinstance(strip_alias(projection), aggregate_types) for projection in projections)


def strip_alias(expression: object) -> object:
    """Return the inner expression of an aliased projection, else *expression*."""
    import sqlglot  # noqa: PLC0415

    if isinstance(expression, sqlglot.exp.Alias):
        return expression.this
    return expression


def default_rules(domain_registry: DomainRegistry | None = None) -> tuple[LintRule, ...]:
    """Return all built-in single-contract lint rules."""
    registry_rules: tuple[LintRule, ...] = (
        (DomainNotInAllowedListRule(domain_registry),) if domain_registry is not None else ()
    )
    return (
        DuplicateColumnsRule(),
        DataContractColumnRefsRule(),
        PrimaryKeyPresentOnSchemaRule(),
        ResourceNameDerivedRule(),
        *registry_rules,
        RequiredFalsePrimaryKeyRule(),
        UniqueCheckNamesRule(),
        WindowRequiresSlaElementRule(),
        WindowNotApplicableRule(),
        WindowAndSizeExclusiveRule(),
        AnomalyTimeColumnRequiredRule(),
        CheckThresholdRequiredRule(),
        CheckDimensionRequiredRule(),
        MissingOwnerRule(),
        UsageRecommendedRule(),
        CustomSqlReturnsFailingRowsRule(),
    )


def default_cross_schema_rules() -> tuple[CrossSchemaRule, ...]:
    """Return all built-in rules that need every schema of a contract at once."""
    return (
        SlaTimeColumnPerSchemaRule(),
        ColumnDescriptionRequiredRule(),
        OdcsNameUnqualifiedRule(),
        OdcsNameMalformedRule(),
    )


def default_cross_rules() -> tuple[CrossContractRule, ...]:
    """Return all built-in cross-contract lint rules."""
    return (
        ColumnRefsRule(),
        PrimaryKeyPresentRule(),
        DeprecatedTargetRule(),
        EmptyTargetRule(),
        DatasetNotInTargetRule(),
    )
