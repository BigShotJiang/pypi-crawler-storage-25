"""Ports for the contract bounded context: reading, writing, and storing contracts."""

from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Any, Protocol, runtime_checkable

from turbine.core.building_blocks import (
    DiagnosticSink,
    DisplayContextFn,
    NullDiagnosticSink,
    ValidFieldsFn,
)
from turbine.core.common import CheckDef, DatasetSpec, RawSource, SchemaNode
from turbine.core.common.analysis_types import LocationInfo, WorkspaceSymbolInfo


class RuleCategory(StrEnum):
    """Categories for grouping lint rules."""

    SCHEMA = "schema"
    STRUCTURE = "structure"
    NAMING = "naming"
    CROSS_CONTRACT = "cross-contract"


class RuleScope(StrEnum):
    """How a lint rule should be dispatched across the specs of a multi-schema contract.

    PER_SCHEMA fires per ``DatasetSpec``; the rule sees one schema at a time.
    PER_CONTRACT fires once per contract on the first spec — adequate when the
    rule only reads contract-level metadata (status, version, etc.).
    CROSS_SCHEMA fires once per contract but receives every spec for that
    contract as a tuple — required when the rule cross-references contract-level
    fields (e.g. SLA element) against schema-level data (column lists).
    """

    PER_SCHEMA = "per-schema"
    PER_CONTRACT = "per-contract"
    CROSS_SCHEMA = "cross-schema"


class CheckFileResolver(Protocol):
    """Resolve the expected filesystem path for a check's referenced file."""

    def resolve_path(self, check: CheckDef) -> Path | None:
        """Return the expected file path, or None if this check type has no file."""
        ...


class LintRule(Protocol):
    """A single-contract lint rule that checks a DatasetSpec for issues."""

    name: str
    category: RuleCategory
    scope: RuleScope

    def check(self, spec: DatasetSpec, sink: DiagnosticSink) -> None:
        """Run this rule against a single contract."""
        ...


class DomainRegistry(Protocol):
    """Approved Contract domain registry."""

    def allowed(self) -> tuple[str, ...] | None:
        """Return approved Contract domains, or None when no registry exists."""
        ...


@dataclass(frozen=True, slots=True)
class TargetContractContext:
    """All target specs for one Contract plus the selected Dataset."""

    contract_id: str
    specs: tuple[DatasetSpec, ...]
    selected: DatasetSpec

    @property
    def valid_dataset_names(self) -> tuple[str, ...]:
        """Return Dataset names in declaration order."""
        return tuple(str(spec.table) for spec in self.specs)


class CrossContractRule(Protocol):
    """A cross-contract lint rule that validates one contract against another."""

    name: str
    category: RuleCategory

    def check(self, spec: DatasetSpec, context: TargetContractContext, sink: DiagnosticSink) -> None:
        """Run this rule against a contract and its target context."""
        ...


class CrossSchemaRule(Protocol):
    """A lint rule that validates a contract using all of its schemas at once.

    Receives every ``DatasetSpec`` belonging to a single contract in
    declaration order. Use when the rule must cross-reference contract-level
    fields (``slaProperties``, ``servers``) against schema-level data
    (column lists, primary keys) — a single-spec view drops the columns
    of every schema after the first.
    """

    name: str
    category: RuleCategory

    def check(self, specs: tuple[DatasetSpec, ...], sink: DiagnosticSink) -> None:
        """Run this rule against every spec belonging to one contract."""
        ...


@dataclass(frozen=True, slots=True)
class ContractLocation:
    """A reference to a contract in a repository."""

    contract_id: str
    path: Path
    format_label: str | None = None


class FormatReader(Protocol):
    """Reads one contract format (ODCS, quality spec, DBT, etc.) into DatasetSpec."""

    format_label: str

    def can_read(self, data: dict[str, Any]) -> bool:
        """Return True if *data* matches the format this reader handles."""
        ...

    def read(self, source: RawSource, sink: DiagnosticSink) -> tuple[DatasetSpec, ...]:
        """Turn raw source into one or more DatasetSpec values."""
        ...


class ContractReaderRegistry(Protocol):
    """Port: dispatch contract reading to the right format reader."""

    @property
    def readers(self) -> Sequence[FormatReader]:
        """Return all registered format readers."""
        ...

    def read(self, source: RawSource, sink: DiagnosticSink) -> tuple[DatasetSpec, ...]:
        """Detect the format and delegate to the matching reader."""
        ...


class ContractRepository(Protocol):
    """Discover and load contract files from a storage backend.

    Returns ``RawSource`` (parsed YAML with source positions), not
    ``DatasetSpec``. Format detection and IR conversion happen in
    ``FormatRegistry``.
    """

    def load(self, path: Path) -> RawSource:
        """Parse a file into a RawSource."""
        ...

    def resolve(self, ref: str) -> RawSource:
        """Look up *ref* and return the parsed YAML as a RawSource."""
        ...

    def list_contracts(
        self, sink: DiagnosticSink = NullDiagnosticSink()
    ) -> tuple[ContractLocation, ...]:
        """Discover all contract locations in the repository."""
        ...


class PreviousVersionReader(Protocol):
    """Reads the committed text of a contract file, or None if not available."""

    def read(self, path: Path, ref: str = "HEAD") -> str | None:
        """Return *path*'s text at git *ref*, or None when unavailable."""
        ...


class ContractLookup(Protocol):
    """Resolves a contract id to an on-disk path across one or more repositories.

    Adapters collect parse diagnostics while scanning and surface them via
    ``ContractNotFoundError`` so callers can render "not found" responses
    together with the underlying cause.
    """

    def find(self, contract_id: str) -> Path:
        """Return the file path for *contract_id* or raise ``ContractNotFoundError``."""
        ...


@runtime_checkable
class ProjectIndex(Protocol):
    """Read-only index over a set of contracts for fast lookup."""

    revision: int
    """Unique, monotonically increasing identity of this index instance.

    Stamped at construction and stable for the index's lifetime. Caches keyed
    on the live index (notably the diagnostic lint cache) use this instead of
    ``id()`` so a rebuilt index always invalidates, even when the previous
    index's memory address is recycled.
    """

    def contracts(self) -> tuple[DatasetSpec, ...]:
        """Return all indexed contracts."""
        ...

    def find_contract(self, contract_id: str) -> DatasetSpec | None:
        """Look up a single contract by its unique ID."""
        ...

    def find_specs_for_contract(self, contract_id: str) -> tuple[DatasetSpec, ...]:
        """Return all quality specs that reference *contract_id* via target_contract."""
        ...

    def quality_specs(self) -> tuple[DatasetSpec, ...]:
        """Return all specs that have a target_contract set (i.e. quality specs)."""
        ...

    def search_symbols(self, query: str) -> tuple[WorkspaceSymbolInfo, ...]:
        """Search contracts, schemas, and quality specs by name."""
        ...

    def find_contract_id_locations(self, word: str) -> tuple[LocationInfo, ...]:
        """Find quality specs whose target_contract matches *word*."""
        ...

    def find_table_locations(self, word: str) -> tuple[LocationInfo, ...]:
        """Find contracts whose table name matches *word*."""
        ...

    def resolve_contract_link(self, contract_id: str) -> str | None:
        """Return the file URI for a contract, or None if not found."""
        ...

    def contract_id_for(self, uri: str) -> str | None:
        """Reverse-lookup a contract id from its source URI."""
        ...


type IndexFactory = Callable[[Iterable[DatasetSpec]], ProjectIndex]


@dataclass(frozen=True, slots=True)
class FormatDescriptor:
    """Per-format schema infrastructure for validation and resolution."""

    format_label: str
    schema_loader: Callable[[], SchemaNode]
    display_context_fn: DisplayContextFn
    valid_fields_fn: ValidFieldsFn
