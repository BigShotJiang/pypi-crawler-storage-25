"""Semver classification and version bumping for contract changes."""

import re
from collections.abc import Sequence
from enum import IntEnum
from typing import Self

from pydantic import BaseModel, ConfigDict, Field

from turbine.core.common.change_types import ChangeType, ContractChange
from turbine.core.contract.errors import ContractVersionError

SEMVER_RE = re.compile(r"^(\d+)\.(\d+)\.(\d+)")
VERSION_LINE_RE = re.compile(r"^(version:\s*)([\"']?)(\d+\.\d+\.\d+)(\2)(?=\s*(?:#.*)?$)", re.MULTILINE)


class Version(BaseModel):
    """Parsed semver triple. Renders back to ``major.minor.patch`` via ``str()``."""

    model_config = ConfigDict(frozen=True)

    major: int = Field(ge=0)
    minor: int = Field(ge=0)
    patch: int = Field(ge=0)

    @classmethod
    def parse(cls, value: str) -> Self:
        match = SEMVER_RE.match(value)
        if not match:
            msg = f"invalid semver version: {value!r}"
            raise ContractVersionError(msg)
        return cls(major=int(match.group(1)), minor=int(match.group(2)), patch=int(match.group(3)))

    def __str__(self) -> str:
        return f"{self.major}.{self.minor}.{self.patch}"

    def as_tuple(self) -> tuple[int, int, int]:
        """Return the version as a comparable ``(major, minor, patch)`` tuple."""
        return (self.major, self.minor, self.patch)

    def __ge__(self, other: "Version") -> bool:
        return self.as_tuple() >= other.as_tuple()

    def __gt__(self, other: "Version") -> bool:
        return self.as_tuple() > other.as_tuple()

    def __le__(self, other: "Version") -> bool:
        return self.as_tuple() <= other.as_tuple()

    def __lt__(self, other: "Version") -> bool:
        return self.as_tuple() < other.as_tuple()

    def bump(self, level: "SemverBump") -> "Version":
        if level == SemverBump.MAJOR:
            return Version(major=self.major + 1, minor=0, patch=0)
        if level == SemverBump.MINOR:
            return Version(major=self.major, minor=self.minor + 1, patch=0)
        if level == SemverBump.PATCH:
            return Version(major=self.major, minor=self.minor, patch=self.patch + 1)
        return self


class SemverBump(IntEnum):
    """Semver bump level, ordered so max() returns the highest."""

    NONE = 0
    PATCH = 1
    MINOR = 2
    MAJOR = 3

    @property
    def label(self) -> str:
        """Human-readable label: 'none' for NONE, lowercase name otherwise."""
        return "none" if self == SemverBump.NONE else self.name.lower()


CHANGE_CLASSIFICATION: dict[ChangeType, SemverBump] = {
    ChangeType.COLUMN_REMOVED: SemverBump.MAJOR,
    ChangeType.COLUMN_TYPE_CHANGED: SemverBump.MAJOR,
    ChangeType.COLUMN_ADDED: SemverBump.MINOR,
    ChangeType.CHECK_ADDED: SemverBump.MINOR,
    ChangeType.CHECK_REMOVED: SemverBump.MINOR,
    ChangeType.SCHEMA_REMOVED: SemverBump.MAJOR,
    ChangeType.PK_COLUMN_REMOVED: SemverBump.MAJOR,
    ChangeType.PK_COLUMN_ADDED: SemverBump.MINOR,
    ChangeType.CHECK_THRESHOLD_CHANGED: SemverBump.MINOR,
    ChangeType.COLUMN_DESCRIPTION_ADDED: SemverBump.PATCH,
    ChangeType.COLUMN_DESCRIPTION_REMOVED: SemverBump.PATCH,
    ChangeType.COLUMN_DESCRIPTION_CHANGED: SemverBump.PATCH,
    ChangeType.SLA_ELEMENT_CHANGED: SemverBump.MAJOR,
    ChangeType.COLUMN_REQUIRED_TIGHTENED: SemverBump.MAJOR,
}


def classify_change(change: ContractChange) -> SemverBump:
    """Classify a single contract change into a semver bump level."""
    if change.change_type == ChangeType.COLUMN_NULLABLE_CHANGED:
        if change.old_nullable and not change.new_nullable:
            return SemverBump.MAJOR
        return SemverBump.MINOR

    bump = CHANGE_CLASSIFICATION.get(change.change_type)
    if bump is None:
        msg = f"unsupported contract change type for semver classification: {change.change_type.value}"
        raise ContractVersionError(msg)
    return bump


def classify_diff(changes: Sequence[ContractChange]) -> SemverBump:
    """Return the highest semver bump across all changes. Empty = NONE."""
    if not changes:
        return SemverBump.NONE
    return max(classify_change(change) for change in changes)


def bump_version(current: str, bump: SemverBump) -> str:
    """Increment the version string according to the bump level."""
    if bump == SemverBump.NONE:
        return current
    return str(Version.parse(current).bump(bump))


def read_version_from_yaml(content: str) -> str | None:
    """Return the first top-level YAML version string matched by the semver regex."""
    match = VERSION_LINE_RE.search(content)
    if match is None:
        return None
    return match.group(3)


def replace_version_in_yaml(content: str, new_version: str) -> str:
    """Replace the top-level version field value in YAML content via regex."""
    replaced, count = VERSION_LINE_RE.subn(rf"\g<1>\g<2>{new_version}\g<4>", content, count=1)
    if count == 0:
        msg = "no version field found in YAML content"
        raise ContractVersionError(msg)
    return replaced
