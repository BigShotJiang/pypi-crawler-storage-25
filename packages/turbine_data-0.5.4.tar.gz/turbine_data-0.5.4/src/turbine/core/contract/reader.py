"""``read_resolved``: single entry point that returns a fully-resolved spec.

The legacy pipeline read a :class:`DatasetSpec` from ODCS, then had
``CheckUseCase`` fan out into three post-processing steps at runtime:
``merge_target`` (pull columns/checks from a target contract), re-parse
filters per dialect, and attach ``column_meta``. Tier 6 collapses all of
that into one reader-side pass so the orchestrator consumes resolved
specs directly.

The function is dependency-light by design — it takes the pieces it
needs (registry, repository, datasource/dialect) rather than a whole
use case — so every surface (CLI/API/LSP) can call it.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import replace

from turbine.core.building_blocks import Diagnostic, DiagnosticBuilder, DiagnosticId, DiagnosticSink
from turbine.core.common import CheckDef, ColumnDef, DatasetSpec, RawSource, TableIdentifier
from turbine.core.common.dataset_spec.checks import classify_execution_route, classify_metric_type
from turbine.core.common.datasource_type import DataSourceType
from turbine.core.shared import FilterExpr

from .ports import ContractReaderRegistry, ContractRepository, ProjectIndex

IndexProvider = Callable[[], ProjectIndex]


def read_resolved(  # noqa: PLR0913 — every parameter is part of the orchestration contract
    source: RawSource,
    registry: ContractReaderRegistry,
    sink: DiagnosticSink,
    *,
    dialect: DataSourceType,
    repository: ContractRepository | None = None,
    index_provider: IndexProvider | None = None,
) -> tuple[DatasetSpec, ...]:
    """Parse *source* into specs and run ``resolve_spec`` on each one."""
    raw_specs = registry.read(source, sink)
    return tuple(
        resolve_spec(
            spec, registry, sink, dialect=dialect, repository=repository, index_provider=index_provider
        )
        for spec in raw_specs
    )


def resolve_spec(  # noqa: PLR0913 — every parameter mirrors read_resolved's signature
    spec: DatasetSpec,
    registry: ContractReaderRegistry,
    sink: DiagnosticSink,
    *,
    dialect: DataSourceType,
    repository: ContractRepository | None = None,
    index_provider: IndexProvider | None = None,
) -> DatasetSpec:
    """Merge any target contract, re-parse filters per dialect, attach column_meta."""
    merged = merge_target(spec, registry, sink, repository=repository, index_provider=index_provider)
    resolved_checks = resolve_checks(merged.checks, merged.columns, dialect=dialect)
    return replace(merged, checks=resolved_checks)


def merge_target(
    spec: DatasetSpec,
    registry: ContractReaderRegistry,
    sink: DiagnosticSink,
    *,
    repository: ContractRepository | None,
    index_provider: IndexProvider | None = None,
) -> DatasetSpec:
    """Merge *spec*'s target contract's columns + checks in additively.

    When *spec* references a target contract (QualitySpec → DataContract),
    pull the target's columns, table, and SLA, and merge the two check
    lists with QualitySpec taking precedence on name collisions. Emits
    a diagnostic per duplicate name.

    Resolution order: ``repository`` (CLI-style filesystem lookup) first,
    then ``index_provider`` (LSP-style in-memory project index). One of the
    two paths must be wired or the spec returns unchanged and the
    cross-contract pass surfaces "target X not found".
    """
    if not spec.target_contract:
        return spec

    target_specs = resolve_target_specs(spec, registry, sink, repository, index_provider)
    if not target_specs:
        return spec

    target = select_target_spec(target_specs, spec.table)
    if target is None:
        return spec
    merged_checks = merge_checks(spec.checks, target.checks, sink=sink)
    return replace(
        spec,
        columns=target.columns,
        table=target.table,
        checks=merged_checks,
        sla=target.sla or spec.sla,
    )


def resolve_target_specs(
    spec: DatasetSpec,
    registry: ContractReaderRegistry,
    sink: DiagnosticSink,
    repository: ContractRepository | None,
    index_provider: IndexProvider | None,
) -> tuple[DatasetSpec, ...]:
    """Look up the target contract via *repository*, falling back to *index_provider*.

    The repository path re-reads from disk so any unsaved-on-disk changes
    are reflected. The index path serves the in-memory snapshot the LSP
    has been maintaining as the user edits, which works in editors that
    haven't written to disk yet.
    """
    if spec.target_contract is None:
        return ()
    if repository is not None:
        target_source = repository.resolve(spec.target_contract)
        return registry.read(target_source, sink)
    if index_provider is None:
        return ()
    return target_specs_from_index(index_provider(), spec.target_contract)


def target_specs_from_index(index: ProjectIndex, contract_id: str) -> tuple[DatasetSpec, ...]:
    """Return every DataContract spec with *contract_id* from an in-memory index.

    Multi-schema DataContracts produce one ``DatasetSpec`` per schema while sharing
    one contract id. ``ProjectIndex.find_contract`` returns a single representative,
    so QualitySpec resolution must scan ``contracts()`` to preserve every candidate
    and let callers choose the schema matching ``QualitySpec.dataset``.
    """
    return tuple(
        candidate
        for candidate in index.contracts()
        if candidate.metadata.contract_id == contract_id and candidate.target_contract is None
    )


def select_target_spec(
    target_specs: tuple[DatasetSpec, ...], dataset: TableIdentifier | str | None
) -> DatasetSpec | None:
    """Choose the target schema matching *dataset*, falling back to the first spec."""
    if not target_specs:
        return None
    if dataset is None:
        return target_specs[0]
    dataset_label = str(dataset)
    return next(
        (candidate for candidate in target_specs if str(candidate.table) == dataset_label),
        target_specs[0],
    )


def merge_checks(
    spec_checks: tuple[CheckDef, ...], target_checks: tuple[CheckDef, ...], *, sink: DiagnosticSink
) -> tuple[CheckDef, ...]:
    """Additively merge; QualitySpec wins on duplicate names; diagnose duplicates."""
    existing_names = {check.name for check in spec_checks}
    merged: list[CheckDef] = list(spec_checks)
    contract_only = (check for check in target_checks if check.is_contract)
    for check in contract_only:
        if check.name in existing_names:
            sink.add(build_duplicate_check_diagnostic(check))
            continue
        merged.append(check)
    return tuple(merged)


def build_duplicate_check_diagnostic(check: CheckDef) -> Diagnostic:
    """Produce the error diagnostic for a duplicate check name."""
    return (
        DiagnosticBuilder.error(
            DiagnosticId.CHECK_DEFINITION_ERROR,
            f"Duplicate check name '{check.name}' — "
            f"defined in both contract ({check.source.path}) and QualitySpec. "
            "Using QualitySpec version.",
        )
        .span(check.source.path, check.source_range)
        .build()
    )


def resolve_checks(
    checks: tuple[CheckDef, ...], columns: tuple[ColumnDef, ...], *, dialect: DataSourceType
) -> tuple[CheckDef, ...]:
    """Populate ``execution_route``, ``column_meta`` and re-parse ``filter``."""
    columns_by_name = {column.name: column for column in columns}
    return tuple(resolve_check(check, columns_by_name, dialect=dialect) for check in checks)


def resolve_check(
    check: CheckDef, columns_by_name: dict[str, ColumnDef], *, dialect: DataSourceType
) -> CheckDef:
    """Re-parse filter per dialect; classify route + metric type; attach column_meta."""
    resolved_filter = reparse_filter(check.filter, dialect)
    resolved_route = classify_execution_route(check)
    resolved_metric_type = classify_metric_type(check)
    resolved_column_meta = columns_by_name.get(check.column) if check.column else None
    return replace(
        check,
        filter=resolved_filter,
        execution_route=resolved_route,
        metric_type=resolved_metric_type,
        column_meta=resolved_column_meta,
    )


def reparse_filter(filter_expr: FilterExpr | None, dialect: DataSourceType) -> FilterExpr | None:
    """Re-parse *filter_expr* under *dialect* if it was parsed elsewhere.

    The ODCS reader parses filters with a ``duckdb`` default (it has no
    dialect context). When the actual datasource runs a different dialect,
    canonicalisation changes — we re-parse so the AST and fingerprint line
    up with what the executor will render.
    """
    if filter_expr is None:
        return None
    return FilterExpr.parse(filter_expr.raw, dialect=dialect.value)
