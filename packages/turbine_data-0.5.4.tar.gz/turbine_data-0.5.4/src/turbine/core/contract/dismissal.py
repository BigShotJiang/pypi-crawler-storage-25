"""Per-occurrence dismissal of INFO/WARNING diagnostics.

ERROR severity is never dismissible. The key is the most stable identity a
finding can produce: the file URI, the rule's id, and an optional anchor that
the rule itself picks (column name, ``schema.column``, or ``None`` for
file-level findings). Renaming the underlying anchor invalidates the
dismissal automatically because the key no longer matches.
"""

from collections.abc import Iterable
from dataclasses import dataclass
from typing import Protocol

from turbine.core.building_blocks import DiagnosticKind


@dataclass(frozen=True, slots=True)
class DismissalKey:
    """Identity used to look up and persist a dismissed diagnostic.

    ``anchor`` is the rule's choice of stable id: column name,
    ``"schema.column"``, or ``None`` for file-level findings. Renaming the
    underlying anchor invalidates the dismissal automatically (key no longer
    matches).
    """

    file_uri: str
    rule_id: str
    anchor: str | None


class DismissalStore(Protocol):
    """Per-occurrence dismissal of INFO/WARNING diagnostics. ERROR is never dismissible."""

    def is_dismissed(self, key: DismissalKey) -> bool:
        """Return True when *key* has been dismissed and not since invalidated."""
        ...

    def dismiss(self, key: DismissalKey, kind: DiagnosticKind) -> None:
        """Persist a dismissal for *key* with its associated diagnostic kind."""
        ...

    def purge_invalid(self, file_uri: str, active: Iterable[DismissalKey]) -> None:
        """Drop any dismissed entries for *file_uri* whose key is not in *active*."""
        ...
