"""API-eligibility and runtime-metadata rules for ``DatasetSpec``.

Pure domain rules that answer "can this contract be served as an API?"
(diagnostic-producing) and "what URLs, headers, and OpenAPI extras
does the API expose for this contract?" (runtime-metadata). The CLI
``generate api`` flow, the LSP, the codegen renderers, and any future
programmatic caller all import from here so the same answers surface
everywhere.
"""

import re
from collections.abc import Sequence
from dataclasses import dataclass, replace
from enum import StrEnum

from turbine.core.building_blocks.diagnostics import (
    Diagnostic,
    DiagnosticBuilder,
    DiagnosticData,
    DiagnosticId,
    DiagnosticKind,
    Span,
)
from turbine.core.codegen.type_system import is_jsonschema_mappable
from turbine.core.common.dataset_spec import ColumnDef, ContractStatus, DatasetSpec

CONTRACT_ID_PATTERN = re.compile(r"^[a-z]([a-z0-9-]*[a-z0-9])?$")
DOUBLE_HYPHEN_PATTERN = re.compile(r"--")
SEMVER_PATTERN = re.compile(r"^\d+\.\d+(\.\d+)?$")
URN_PREFIXES = frozenset({"urn", "datacontract", "data", "schema"})
VERSION_SUFFIX_PATTERN = re.compile(r"v\d+")
NUMERIC_PREFIX_PATTERN = re.compile(r"(\d+)-(.+)")
PLURAL_SUFFIXES: tuple[str, ...] = ("s", "en")
MIN_ES_LENGTH = 3
FALLBACK_SLUG = "contract"

TABLE_PREFIXES: frozenset[str] = frozenset(
    {"f", "d", "v", "vw", "fact", "dim", "stg", "tmp", "view", "raw"}
)
TABLE_VERSION_SUFFIX_PATTERN = re.compile(r"_v\d+(?:_[a-z0-9]+)*$")
FILTERABLE_TAG = "filterable"

SUNSET_PROPERTY = "sunsetDate"
SUPERSEDED_BY_PROPERTY = "supersededBy"
DOCS_URL_PROPERTY = "docsUrl"
CACHE_CONTROL_PROPERTY = "cacheControl"
CACHEABLE_PROPERTY = "cacheable"
CACHEABLE_FALSE = "false"
DEFAULT_DOCS_URL_TEMPLATE = "/contract-docs/{contract_id}"
CONTRACT_DOCS_LINK_TEMPLATE = "[Data contract](/contract-docs/{contract_id})"
DEFAULT_DETAIL_CACHE_CONTROL = "public, max-age=300"
NO_STORE_CACHE_CONTROL = "no-store"

GENERATING_STATUSES: frozenset[ContractStatus] = frozenset(
    {ContractStatus.ACTIVE, ContractStatus.DEPRECATED}
)
DOCUMENTED_STATUSES: frozenset[ContractStatus] = frozenset(
    {ContractStatus.ACTIVE, ContractStatus.DEPRECATED, ContractStatus.DRAFT}
)


def validate_for_api(spec: DatasetSpec) -> Sequence[Diagnostic]:
    """Run every per-spec URI-compliance rule against *spec* and return the findings."""
    diagnostics: list[Diagnostic] = []
    if charset_diag := charset_rule(spec):
        diagnostics.append(charset_diag)
    elif plural_diag := plural_rule(spec):
        diagnostics.append(plural_diag)
    if domain_diag := domain_rule(spec):
        diagnostics.append(domain_diag)
    if version_diag := version_rule(spec):
        diagnostics.append(version_diag)
    diagnostics.extend(column_type_rule(spec))
    if resource_diag := resource_name_rule(spec):
        diagnostics.append(resource_diag)
    if filterable_diag := filterable_fallback_rule(spec):
        diagnostics.append(filterable_diag)
    return diagnostics


def validate_uniqueness(specs: Sequence[DatasetSpec]) -> Sequence[Diagnostic]:
    """Reject datasets that resolve to the same per-resource URL.

    Specs missing a usable ``domain`` or a parseable ``major_version`` are
    skipped because :func:`validate_for_api` already flags those individually.
    Each conflict produces one diagnostic whose annotations carry the source
    ranges of every colliding dataset.
    """
    groups: dict[tuple[str, int, str, str], list[DatasetSpec]] = {}
    for spec in specs:
        if (key := uniqueness_key(spec)) is not None:
            groups.setdefault(key, []).append(spec)
    return [
        build_conflict_diagnostic(domain, major, contract_id, resource, conflicting)
        for (domain, major, contract_id, resource), conflicting in groups.items()
        if len(conflicting) > 1
    ]


def uniqueness_key(spec: DatasetSpec) -> tuple[str, int, str, str] | None:
    """Return ``(domain, major, contract_id, resource_name)`` if usable for routing.

    The widened key ensures a single contract that names two datasets is
    not a self-conflict; only datasets that share *all four* fields are
    flagged. ``None`` means the spec is missing a domain or a parseable
    semver and was already flagged by :func:`validate_for_api`.
    """
    domain = spec.metadata.domain
    if not domain or not domain.strip():
        return None
    if SEMVER_PATTERN.fullmatch(spec.metadata.version) is None:
        return None
    return (domain, spec.metadata.major_version, spec.metadata.contract_id, resource_name(spec).value)


def build_conflict_diagnostic(
    domain: str, major: int, contract_id: str, resource: str, conflicting: Sequence[DatasetSpec]
) -> Diagnostic:
    """Assemble the conflict diagnostic with one annotation per colliding dataset."""
    url = f"/{domain}/v{major}/{contract_id}/{resource}"
    first, *rest = conflicting
    builder = (
        DiagnosticBuilder.error(
            DiagnosticId.API_CONTRACT_TUPLE_CONFLICT,
            f"duplicate API path {url!r}: {len(conflicting)} datasets share "
            f"(domain={domain!r}, major={major}, contract_id={contract_id!r}, "
            f"resource_name={resource!r})",
        )
        .span(first.metadata.source_path, first.metadata.contract_id_source_range)
        .help(
            "rename one contract id, move one to a different domain or major version, "
            "or rename the underlying table so the resource slug differs"
        )
    )
    for other in rest:
        span = Span(path=other.metadata.source_path, range=other.metadata.contract_id_source_range)
        builder = builder.secondary(span, label=f"also claims {url!r}")
    return builder.build()


def is_charset_valid(contract_id: str) -> bool:
    """Return True when *contract_id* matches the URI-safe pattern with no ``--``."""
    return (
        CONTRACT_ID_PATTERN.fullmatch(contract_id) is not None
        and DOUBLE_HYPHEN_PATTERN.search(contract_id) is None
    )


def charset_rule(spec: DatasetSpec) -> Diagnostic | None:
    """Reject any contract id that can't become a Python identifier or URL path.

    Pattern is ``^[a-z][a-z0-9-]*[a-z0-9]$`` per Enexis URI-G; on failure the
    diagnostic carries a :class:`NAMING_VIOLATION` quick-fix payload with a
    suggested slug so editors offer a one-click rename.
    """
    contract_id = spec.metadata.contract_id
    if is_charset_valid(contract_id):
        return None
    suggestion = suggest_slug(contract_id)
    diag = (
        DiagnosticBuilder.error(
            DiagnosticId.API_CONTRACT_ID_CHARSET,
            f"contract id {contract_id!r} must match {CONTRACT_ID_PATTERN.pattern}",
        )
        .span(spec.metadata.source_path, spec.metadata.contract_id_source_range)
        .help(f"rename to {suggestion!r}")
        .build()
    )
    data = DiagnosticData(
        kind=DiagnosticKind.NAMING_VIOLATION, field_name=contract_id, suggested_value=suggestion
    )
    return replace(diag, data=data)


def plural_rule(spec: DatasetSpec) -> Diagnostic | None:
    """Warn when the last hyphen segment doesn't look like an English/Dutch plural."""
    contract_id = spec.metadata.contract_id
    last_segment = contract_id.rsplit("-", maxsplit=1)[-1]
    if last_segment.endswith(PLURAL_SUFFIXES):
        return None
    return (
        DiagnosticBuilder.warning(
            DiagnosticId.API_CONTRACT_ID_PLURAL,
            f"contract id should be plural per URI-G-05: {contract_id!r}",
        )
        .span(spec.metadata.source_path, spec.metadata.contract_id_source_range)
        .help("rename to a plural noun (resources are collections)")
        .build()
    )


def domain_rule(spec: DatasetSpec) -> Diagnostic | None:
    """Reject contracts that don't carry a non-empty ``domain`` field.

    The domain becomes the first URL segment (``/{domain}/v{major}/{id}``) and
    the OpenAPI tag, so an empty value would break route grouping.
    """
    domain = spec.metadata.domain
    if domain is not None and domain.strip():
        return None
    return (
        DiagnosticBuilder.error(
            DiagnosticId.API_DOMAIN_REQUIRED, "contract metadata must include a non-empty `domain`"
        )
        .span(spec.metadata.source_path, spec.metadata.domain_source_range)
        .help("set `domain` on the contract; it forms the URL `/{domain}/v{major}/{contract_id}/`")
        .build()
    )


def version_rule(spec: DatasetSpec) -> Diagnostic | None:
    """Reject versions that don't parse as ``major.minor[.patch]``."""
    version = spec.metadata.version
    if SEMVER_PATTERN.fullmatch(version) is not None:
        return None
    return (
        DiagnosticBuilder.error(
            DiagnosticId.API_VERSION_INVALID,
            f"contract version {version!r} must match major.minor[.patch] (e.g. '1.0' or '2.3.1')",
        )
        .span(spec.metadata.source_path, spec.metadata.version_source_range)
        .help("use a numeric version like `1.0` or `2.0.1`; 'latest' and 'rolling' are not accepted")
        .build()
    )


def column_type_rule(spec: DatasetSpec) -> Sequence[Diagnostic]:
    """Reject every column whose ``logical_type`` lacks a JSON-schema mapping."""
    return [
        (
            DiagnosticBuilder.error(
                DiagnosticId.API_COLUMN_TYPE_UNMAPPABLE,
                f"column {column.name!r} has type {column.logical_type.value!r} which "
                f"can't be mapped to a JSON-schema primitive",
            )
            .span(spec.metadata.source_path, column.source_range)
            .help("use one of: string, integer, number, boolean, array, object, datetime")
            .build()
        )
        for column in spec.columns
        if not is_jsonschema_mappable(column.logical_type)
    ]


def suggest_slug(value: str) -> str:
    """Rewrite *value* into the closest charset-valid contract id."""
    base = strip_urn_segments(value) if ":" in value else value
    base = re.sub(r"[\s_.]+", "-", base.lower())
    base = re.sub(r"[^a-z0-9-]", "", base)
    base = re.sub(r"-+", "-", base).strip("-")
    base = move_numeric_prefix(base)
    return base or FALLBACK_SLUG


def strip_urn_segments(value: str) -> str:
    """Drop URN-style namespace and ``vN`` version segments from a colon-separated id."""
    parts = [part for part in value.split(":") if part]
    parts = [part for part in parts if part.lower() not in URN_PREFIXES]
    if parts and VERSION_SUFFIX_PATTERN.fullmatch(parts[-1].lower()):
        parts = parts[:-1]
    return "-".join(parts) if parts else ""


def move_numeric_prefix(value: str) -> str:
    """Reorder ``2024-events`` into ``event-2024`` so the slug starts with a letter."""
    if not value or not value[0].isdigit():
        return value
    match = NUMERIC_PREFIX_PATTERN.fullmatch(value)
    if match is None:
        return value
    digits, rest = match.groups()
    return f"{singularize(rest)}-{digits}"


def singularize(word: str) -> str:
    """Roughly singularize *word* using the same heuristic the plural rule looks for."""
    if word.endswith("ies"):
        return f"{word[:-3]}y"
    if word.endswith("es") and len(word) >= MIN_ES_LENGTH:
        return word[:-2]
    if word.endswith("s") and not word.endswith("ss"):
        return word[:-1]
    return word


class DerivationStatus(StrEnum):
    """Outcome of :func:`resource_name` — drives which lint diagnostic the rule emits.

    ``CLEAN`` means the input was already URL-friendly; no warning needed.
    ``TRANSFORMED`` means table prefixes, version suffixes, or charset
    normalization rewrote the input non-trivially. ``FALLBACK`` means the
    input could not produce a usable slug and ``contract`` was used.
    """

    CLEAN = "clean"
    TRANSFORMED = "transformed"
    FALLBACK = "fallback"


@dataclass(frozen=True, slots=True)
class ResourceName:
    """Result of :func:`resource_name` — the URL slug plus how it was derived."""

    value: str
    status: DerivationStatus


@dataclass(frozen=True, slots=True)
class FilterableColumns:
    """Result of :func:`filterable_columns` — the column tuple plus the no-tags flag.

    ``fell_back_to_all`` is True when no column carries the ``filterable``
    tag and the renderer fell back to "all columns filterable" for this
    release; the lint rule reads it to decide between INFO and silence.
    """

    columns: tuple[ColumnDef, ...]
    fell_back_to_all: bool


def strip_table_decorations(value: str) -> str:
    """Strip a leading DB prefix and trailing version suffixes from *value*.

    Operates on the lowercased table name. ``f_meter_readings_v2_2026q1``
    -> ``meter_readings`` after dropping the ``f_`` fact prefix and the
    ``_v2_2026q1`` version suffix. URN-style colons are handed to
    :func:`strip_urn_segments` first.
    """
    pruned = value
    if ":" in pruned:
        pruned = strip_urn_segments(pruned)
    head, _, tail = pruned.partition("_")
    if head in TABLE_PREFIXES and tail:
        pruned = tail
    while True:
        match = TABLE_VERSION_SUFFIX_PATTERN.search(pruned)
        if match is None:
            break
        pruned = pruned[: match.start()]
    return pruned


def resource_name(spec: DatasetSpec) -> ResourceName:
    """Derive a URL-friendly resource slug from *spec*'s table name.

    Reuses the existing slug primitives so the deriver stays in lockstep
    with :func:`charset_rule` / :func:`suggest_slug`. A clean
    already-URL-safe table name passes through with ``CLEAN`` status; any
    table-prefix or version-suffix rewriting yields ``TRANSFORMED``;
    empty input or a slug that collapses to nothing yields ``FALLBACK``.
    """
    raw = spec.table.table
    if not raw:
        return ResourceName(value=FALLBACK_SLUG, status=DerivationStatus.FALLBACK)
    lowered = raw.lower()
    pruned = strip_table_decorations(lowered)
    slug = suggest_slug(pruned) if pruned else ""
    if not slug:
        return ResourceName(value=FALLBACK_SLUG, status=DerivationStatus.FALLBACK)
    status = DerivationStatus.CLEAN if slug == lowered else DerivationStatus.TRANSFORMED
    return ResourceName(value=slug, status=status)


def resource_path(spec: DatasetSpec) -> str:
    """Return ``/{domain}/v{major}/{contract_id}/{resource_name}`` for *spec*.

    Single source of truth used by the router prefix, the operationId
    namespace, the ``Link: rel="self"`` header, the pagination ``Link``
    headers, and the per-row ``href`` resolver. Callers must have already
    validated that *spec* carries a usable domain (via :func:`domain_rule`).
    """
    domain = spec.metadata.domain or ""
    return (
        f"/{domain}/v{spec.metadata.major_version}"
        f"/{spec.metadata.contract_id}/{resource_name(spec).value}"
    )


def filterable_columns(spec: DatasetSpec) -> FilterableColumns:
    """Return the columns that the list endpoint exposes as query parameters.

    Wraps :attr:`DatasetSpec.filterable_column_defs` with the
    no-tags fallback: contracts where no column carries the
    ``filterable`` tag fall back to "all columns filterable" for this
    release so existing contracts keep working. ``fell_back_to_all`` is
    True in that case so the lint rule can nudge the author to curate.
    """
    tagged = spec.filterable_column_defs
    if tagged:
        return FilterableColumns(columns=tagged, fell_back_to_all=False)
    return FilterableColumns(columns=spec.columns, fell_back_to_all=True)


def resource_name_rule(spec: DatasetSpec) -> Diagnostic | None:
    """Warn when the derived URL slug differs non-trivially from the table name.

    Status ``CLEAN`` produces no diagnostic. ``TRANSFORMED`` emits a
    WARNING naming the original table and the slug consumers will see.
    ``FALLBACK`` emits a WARNING naming the cause (empty table or charset
    violation post-derivation) so the author can fix the input or rely on
    the explicit per-dataset override (todo 029) once it lands.
    """
    derived = resource_name(spec)
    if derived.status is DerivationStatus.CLEAN:
        return None
    span_range = spec.schema_name_source_range or spec.dataset_source_range
    return (
        DiagnosticBuilder.warning(
            DiagnosticId.API_RESOURCE_NAME_DERIVED, resource_name_message(spec, derived)
        )
        .span(spec.metadata.source_path, span_range)
        .help("verify the URL your consumers will see, or rename the table")
        .build()
    )


def resource_name_message(spec: DatasetSpec, derived: ResourceName) -> str:
    """Compose the WARNING prose, branching on derivation status."""
    if derived.status is DerivationStatus.TRANSFORMED:
        return f"resource name for table {spec.table.table!r} derived as {derived.value!r}"
    raw = spec.table.table
    if not raw:
        return f"table name is empty; using fallback resource name {derived.value!r} for the URL slug"
    return f"table name {raw!r} could not be parsed into a URL slug; using fallback {derived.value!r}"


def filterable_fallback_rule(spec: DatasetSpec) -> Diagnostic | None:
    """Emit an INFO when no column carries ``filterable`` and the fallback fired.

    The fallback is transitional: the list endpoint exposes every column
    as a query parameter today, but flips to "no columns filterable"
    once the lint has been visible long enough to act on. The diagnostic
    is the trip wire that reminds the author to curate before the flip.
    """
    if not filterable_columns(spec).fell_back_to_all:
        return None
    return (
        DiagnosticBuilder.info(
            DiagnosticId.API_FILTERABLE_FALLBACK,
            (
                f"contract {spec.metadata.contract_id!r} has no columns tagged "
                "'filterable'; every column is currently exposed as a query parameter"
            ),
        )
        .span(spec.metadata.source_path, spec.schema_name_source_range)
        .help("tag the columns you want consumers to filter on with 'filterable'")
        .build()
    )


@dataclass(frozen=True, slots=True)
class ContractRuntimeInfo:
    """Wire-level metadata threaded into route decorators and OpenAPI extras.

    Captures everything the codegen renderer (and any other caller)
    learned from the contract's lifecycle status and customProperties so
    downstream code paths don't have to reach back into the spec map.
    """

    status: ContractStatus
    contract_id: str
    contract_version: str
    sunset_date: str | None = None
    successor_href: str | None = None

    @property
    def is_deprecated(self) -> bool:
        return self.status is ContractStatus.DEPRECATED

    @property
    def is_draft(self) -> bool:
        return self.status is ContractStatus.DRAFT

    def openapi_extras(self) -> dict[str, str]:
        """Build the ``openapi_extra`` dict for the route decorator."""
        extras: dict[str, str] = {
            "x-contract-status": self.status.value,
            "x-contract-id": self.contract_id,
            "x-contract-version": self.contract_version,
        }
        if self.is_deprecated and self.sunset_date is not None:
            extras["x-sunset-date"] = self.sunset_date
        if self.is_deprecated and self.successor_href is not None:
            extras["x-successor-href"] = self.successor_href
        return extras


def statuses_for_codegen(*, include_drafts: bool, include_proposed: bool) -> frozenset[ContractStatus]:
    """Return the status set eligible for code generation under the given flags.

    ACTIVE + DEPRECATED always make the cut. DRAFT and PROPOSED are
    gated by their flags so the CLI can opt them in. RETIRED is never
    eligible.
    """
    allowed: set[ContractStatus] = set(GENERATING_STATUSES)
    if include_drafts:
        allowed.add(ContractStatus.DRAFT)
    if include_proposed:
        allowed.add(ContractStatus.PROPOSED)
    return frozenset(allowed)


def statuses_for_documentation() -> frozenset[ContractStatus]:
    """Return the status set surfaced in per-major OpenAPI views."""
    return DOCUMENTED_STATUSES


def is_codegen_eligible(spec: DatasetSpec, *, include_drafts: bool, include_proposed: bool) -> bool:
    """Return True when *spec* should be emitted by the codegen pipeline."""
    return spec.metadata.status in statuses_for_codegen(
        include_drafts=include_drafts, include_proposed=include_proposed
    )


def filter_specs_for_codegen(
    specs: Sequence[DatasetSpec], *, include_drafts: bool, include_proposed: bool = False
) -> list[DatasetSpec]:
    """Drop RETIRED contracts; gate DRAFT and PROPOSED behind their flags.

    The orphan sweeper deletes any prior generated files for skipped
    contracts so disk state stays in lockstep with the active set.
    """
    allowed = statuses_for_codegen(include_drafts=include_drafts, include_proposed=include_proposed)
    return [spec for spec in specs if spec.metadata.status in allowed]


def successor_href(spec: DatasetSpec, all_specs: Sequence[DatasetSpec]) -> str | None:
    """Resolve ``customProperties.supersededBy`` against *all_specs* into a URL.

    Returns ``None`` when the contract declares no successor or when the
    referenced id is not present in the current run; downstream
    rendering then omits the ``Link: rel="successor-version"`` header
    entirely (per the design doc's graceful-fallback rule).
    """
    successor_id = spec.metadata.custom_property(SUPERSEDED_BY_PROPERTY)
    if successor_id is None:
        return None
    match = next((entry for entry in all_specs if entry.metadata.contract_id == successor_id), None)
    if match is None or not match.metadata.domain:
        return None
    return f"/{match.metadata.domain}/v{match.metadata.major_version}/{match.metadata.contract_id}"


def sunset_date(spec: DatasetSpec) -> str | None:
    """Return ``customProperties.sunsetDate`` verbatim, or ``None``."""
    return spec.metadata.custom_property(SUNSET_PROPERTY)


def runtime_info(spec: DatasetSpec, all_specs: Sequence[DatasetSpec]) -> ContractRuntimeInfo:
    """Build the :class:`ContractRuntimeInfo` describing *spec*'s lifecycle state."""
    return ContractRuntimeInfo(
        status=spec.metadata.status,
        contract_id=spec.metadata.contract_id,
        contract_version=spec.metadata.version,
        sunset_date=sunset_date(spec),
        successor_href=successor_href(spec, all_specs),
    )


def external_docs_url(spec: DatasetSpec) -> str:
    """Resolve the externalDocs URL — ``customProperties.docsUrl`` overrides the default."""
    override = spec.metadata.custom_property(DOCS_URL_PROPERTY)
    if override is not None:
        return override
    return DEFAULT_DOCS_URL_TEMPLATE.format(contract_id=spec.metadata.contract_id)


def detail_cache_control(spec: DatasetSpec) -> str:
    """Pick the Cache-Control value baked into the detail handler.

    ``customProperties.cacheable: false`` short-circuits to ``no-store``;
    an explicit ``customProperties.cacheControl`` overrides the default
    with its verbatim value; otherwise the design's
    ``public, max-age=300`` default applies.
    """
    cacheable = spec.metadata.custom_property(CACHEABLE_PROPERTY)
    if cacheable is not None and cacheable.lower() == CACHEABLE_FALSE:
        return NO_STORE_CACHE_CONTROL
    override = spec.metadata.custom_property(CACHE_CONTROL_PROPERTY)
    if override is not None:
        return override
    return DEFAULT_DETAIL_CACHE_CONTROL


def resource_label(spec: DatasetSpec) -> str:
    """Pick a human label: ``metadata.name`` or the PascalCased contract id."""
    return spec.metadata.name or pascal_case_id(spec.metadata.contract_id)


def description_text(spec: DatasetSpec) -> str:
    """Combine ``description.purpose`` and the contract-docs link into one description."""
    link = CONTRACT_DOCS_LINK_TEMPLATE.format(contract_id=spec.metadata.contract_id)
    if spec.metadata.description_purpose:
        return f"{spec.metadata.description_purpose}\n\n{link}"
    return link


def pascal_case_id(contract_id: str) -> str:
    """PascalCase a hyphenated contract id (``ms-t-bundels`` -> ``MsTBundels``)."""
    return "".join(part[:1].upper() + part[1:] for part in contract_id.split("-") if part)
