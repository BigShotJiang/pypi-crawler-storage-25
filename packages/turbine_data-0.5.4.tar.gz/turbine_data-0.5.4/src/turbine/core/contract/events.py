"""Domain events emitted during contract validation."""

from __future__ import annotations

from enum import StrEnum
from pathlib import Path

from pydantic import Field, computed_field

from turbine.core.building_blocks import DomainEvent, event


class ConnectionState(StrEnum):
    """Last-known outcome of a datasource connection probe."""

    UNTESTED = "untested"
    OK = "ok"
    FAILED = "failed"


@event
class ContractLintStarted(DomainEvent):
    """Fired when contract linting begins."""

    path: Path = Field(serialization_alias="turbine.contract.path")


@event
class ContractLinted(DomainEvent):
    """Fired after a contract file finishes linting."""

    path: Path = Field(serialization_alias="turbine.contract.path")
    diagnostic_count: int = Field(serialization_alias="turbine.diagnostics.count")
    has_errors: bool = Field(serialization_alias="turbine.diagnostics.has_errors")
    contract_id: str | None = Field(default=None, serialization_alias="turbine.contract.id")

    @computed_field(alias="turbine.outcome")
    @property
    def outcome(self) -> str:
        """Pass/fail derived from has_errors."""
        return "fail" if self.has_errors else "pass"


@event
class ContractPublishStarted(DomainEvent):
    """Fired when contract publishing begins."""

    path: Path = Field(serialization_alias="turbine.contract.path")


@event
class ContractPublished(DomainEvent):
    """Fired after a contract is published."""

    path: Path = Field(serialization_alias="turbine.contract.path")
    contract_id: str = Field(serialization_alias="turbine.contract.id")


@event
class ContractLoadStarted(DomainEvent):
    """Fired when contract loading begins."""

    contract_path: Path = Field(serialization_alias="turbine.contract.path")


@event
class ContractLoaded(DomainEvent):
    """Fired after a contract is loaded."""

    contract_id: str = Field(serialization_alias="turbine.contract.id")
    contract_version: str = Field(serialization_alias="turbine.contract.version")


@event
class DatasourceLoadStarted(DomainEvent):
    """Fired when datasource loading begins."""

    datasource_path: Path = Field(serialization_alias="turbine.datasource.path")


@event
class DatasourceLoaded(DomainEvent):
    """Fired after a datasource is loaded."""

    datasource_type: str = Field(serialization_alias="turbine.datasource.type")
    outcome: str = Field(default="success", serialization_alias="turbine.outcome")


@event
class DatasourceConnectionTested(DomainEvent):
    """Fired after a datasource connection probe completes."""

    name: str = Field(serialization_alias="turbine.datasource.name")
    project_root: Path = Field(serialization_alias="turbine.datasource.project_root")
    state: ConnectionState = Field(serialization_alias="turbine.datasource.state")


@event
class DiagnosticDismissed(DomainEvent):
    """Fired after a per-occurrence diagnostic dismissal is persisted.

    Carries the contract URI so subscribers can scope their reaction to that
    contract instead of refreshing the whole project.
    """

    uri: str = Field(serialization_alias="turbine.contract.uri")
    rule_id: str = Field(serialization_alias="turbine.diagnostic.rule_id")


@event
class ProjectIndexRebuilt(DomainEvent):
    """Fired after the project index is swapped in following a watched-file change.

    Carries the paths that were added and removed so subscribers can react
    granularly. The workspace tree currently treats any rebuild as a full
    invalidation; finer-grained narrowing can be added later by inspecting
    these fields.
    """

    added_paths: tuple[Path, ...] = Field(default=(), serialization_alias="turbine.index.added_paths")
    removed_paths: tuple[Path, ...] = Field(
        default=(), serialization_alias="turbine.index.removed_paths"
    )


@event
class ChecksRun(DomainEvent):
    """Fired after a ``turbine/runCheck`` result is stored on the session."""

    uri: str = Field(serialization_alias="turbine.contract.uri")


@event
class ValidationRun(DomainEvent):
    """Fired after a ``turbine/validateSchema`` result is stored on the session."""

    uri: str = Field(serialization_alias="turbine.contract.uri")
