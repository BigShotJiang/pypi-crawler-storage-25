"""DiffComputer — pure structural diff between two snapshots of contract specs."""

from turbine.core.common import DatasetSpec
from turbine.core.common.change_types import ChangeType, ContractChange
from turbine.core.common.dataset_spec.checks import CheckDef, CompareMode
from turbine.core.common.dataset_spec.columns import ColumnDef
from turbine.core.common.dataset_spec.spec import SlaConfig, SlaProperty
from turbine.core.common.dataset_spec.thresholds import Threshold, format_threshold


def format_threshold_with_compare(threshold: Threshold | None, compare_mode: CompareMode) -> str | None:
    """Render *threshold* with a ``percent`` suffix when *compare_mode* is percent.

    Wraps :func:`format_threshold` so the count-side renderer stays
    unit-blind. Returns ``None`` when *threshold* is ``None`` so callers
    that pass the renderer's output straight to
    :class:`ContractChange.old_value` / ``new_value`` handle the absent
    side cleanly.
    """
    if threshold is None:
        return None
    base = format_threshold(threshold)
    return f"{base} percent" if compare_mode == "percent" else base


class DiffComputer:
    """Pure structural diff between two snapshots of contract specs."""

    @classmethod
    def compute(
        cls, current_specs: tuple[DatasetSpec, ...], previous_specs: tuple[DatasetSpec, ...]
    ) -> tuple[ContractChange, ...]:
        """Compare two spec snapshots and return all detected structural changes."""
        current_by_id = {spec.metadata.contract_id: spec for spec in current_specs}
        previous_by_id = {spec.metadata.contract_id: spec for spec in previous_specs}

        changes: list[ContractChange] = []
        for contract_id, previous_spec in previous_by_id.items():
            current_spec = current_by_id.get(contract_id)
            is_quality_spec = previous_spec.target_contract is not None
            if current_spec is None:
                if not is_quality_spec:
                    changes.append(
                        ContractChange(change_type=ChangeType.SCHEMA_REMOVED, contract_id=contract_id)
                    )
                continue
            if not is_quality_spec:
                changes.extend(cls.diff_columns(contract_id, previous_spec, current_spec))
                changes.extend(cls.diff_sla(contract_id, previous_spec.sla, current_spec.sla))
            changes.extend(cls.diff_checks(contract_id, previous_spec, current_spec))
        return tuple(changes)

    @classmethod
    def diff_columns(
        cls, contract_id: str, previous: DatasetSpec, current: DatasetSpec
    ) -> list[ContractChange]:
        """Diff columns between two specs of the same contract."""
        previous_cols = {column.name: column for column in previous.columns}
        current_cols = {column.name: column for column in current.columns}

        changes: list[ContractChange] = []
        for name, previous_col in previous_cols.items():
            if name not in current_cols:
                changes.append(
                    ContractChange(
                        change_type=ChangeType.COLUMN_REMOVED, contract_id=contract_id, column_name=name
                    )
                )
                continue
            changes.extend(cls.diff_single_column(contract_id, previous_col, current_cols[name]))

        changes.extend(
            ContractChange(
                change_type=ChangeType.COLUMN_ADDED, contract_id=contract_id, column_name=name
            )
            for name in current_cols
            if name not in previous_cols
        )
        return changes

    @classmethod
    def diff_single_column(
        cls, contract_id: str, previous: ColumnDef, current: ColumnDef
    ) -> list[ContractChange]:
        """Diff a single column's attributes (type, nullable, PK, description)."""
        changes: list[ContractChange] = []
        previous_type = str(previous.logical_type)
        current_type = str(current.logical_type)
        if previous_type != current_type:
            changes.append(
                ContractChange(
                    change_type=ChangeType.COLUMN_TYPE_CHANGED,
                    contract_id=contract_id,
                    column_name=previous.name,
                    old_type=previous_type,
                    new_type=current_type,
                )
            )
        if previous.nullable != current.nullable:
            if previous.nullable and not current.nullable:
                changes.append(
                    ContractChange(
                        change_type=ChangeType.COLUMN_REQUIRED_TIGHTENED,
                        contract_id=contract_id,
                        column_name=previous.name,
                        old_value="false",
                        new_value="true",
                    )
                )
            else:
                changes.append(
                    ContractChange(
                        change_type=ChangeType.COLUMN_NULLABLE_CHANGED,
                        contract_id=contract_id,
                        column_name=previous.name,
                        old_nullable=previous.nullable,
                        new_nullable=current.nullable,
                    )
                )
        changes.extend(cls.diff_primary_key(contract_id, previous, current))
        changes.extend(cls.diff_description(contract_id, previous, current))
        return changes

    @classmethod
    def diff_primary_key(
        cls, contract_id: str, previous: ColumnDef, current: ColumnDef
    ) -> list[ContractChange]:
        """Detect a primary-key flag flip between two columns of the same name."""
        if previous.primary_key == current.primary_key:
            return []
        change_type = ChangeType.PK_COLUMN_ADDED if current.primary_key else ChangeType.PK_COLUMN_REMOVED
        return [
            ContractChange(change_type=change_type, contract_id=contract_id, column_name=previous.name)
        ]

    @classmethod
    def diff_description(
        cls, contract_id: str, previous: ColumnDef, current: ColumnDef
    ) -> list[ContractChange]:
        """Detect description add/remove/change between two columns."""
        if previous.description == current.description:
            return []
        if previous.description is None:
            change_type = ChangeType.COLUMN_DESCRIPTION_ADDED
        elif current.description is None:
            change_type = ChangeType.COLUMN_DESCRIPTION_REMOVED
        else:
            change_type = ChangeType.COLUMN_DESCRIPTION_CHANGED
        return [
            ContractChange(
                change_type=change_type,
                contract_id=contract_id,
                column_name=previous.name,
                old_value=previous.description,
                new_value=current.description,
            )
        ]

    @classmethod
    def diff_sla(
        cls, contract_id: str, previous: SlaConfig | None, current: SlaConfig | None
    ) -> list[ContractChange]:
        """Detect SLA element changes by matching properties on `property` field."""
        previous_props = previous.properties if previous is not None else ()
        current_props = current.properties if current is not None else ()

        changes: list[ContractChange] = []
        previous_by_key = cls.index_sla_properties(previous_props)
        current_by_key = cls.index_sla_properties(current_props)
        for key, previous_prop in previous_by_key.items():
            current_prop = current_by_key.get(key)
            if current_prop is None:
                continue
            if previous_prop.element == current_prop.element:
                continue
            changes.append(
                ContractChange(
                    change_type=ChangeType.SLA_ELEMENT_CHANGED,
                    contract_id=contract_id,
                    old_value=previous_prop.element,
                    new_value=current_prop.element,
                )
            )
        return changes

    @classmethod
    def index_sla_properties(cls, properties: tuple[SlaProperty, ...]) -> dict[str | int, SlaProperty]:
        """Index SLA properties by `property` value when set, else by their position."""
        indexed: dict[str | int, SlaProperty] = {}
        for position, prop in enumerate(properties):
            indexed[prop.property or position] = prop
        return indexed

    @classmethod
    def diff_checks(
        cls, contract_id: str, previous: DatasetSpec, current: DatasetSpec
    ) -> list[ContractChange]:
        """Diff checks by name between two specs of the same contract."""
        previous_checks = {check.name: check for check in previous.checks}
        current_checks = {check.name: check for check in current.checks}

        changes: list[ContractChange] = [
            ContractChange(
                change_type=ChangeType.CHECK_REMOVED, contract_id=contract_id, check_name=name
            )
            for name in sorted(previous_checks.keys() - current_checks.keys())
        ]
        changes.extend(
            ContractChange(change_type=ChangeType.CHECK_ADDED, contract_id=contract_id, check_name=name)
            for name in sorted(current_checks.keys() - previous_checks.keys())
        )
        for name in sorted(previous_checks.keys() & current_checks.keys()):
            threshold_change = cls.diff_threshold(
                contract_id, previous_checks[name], current_checks[name]
            )
            if threshold_change is not None:
                changes.append(threshold_change)
        return changes

    @classmethod
    def diff_threshold(
        cls, contract_id: str, previous: CheckDef, current: CheckDef
    ) -> ContractChange | None:
        """Emit ``CHECK_THRESHOLD_CHANGED`` when ``(threshold, metric)`` differs.

        A same-numeric flip from ``compare: count`` to ``compare: percent``
        (or vice versa) is a verdict-semantics change per ADR 0014 and
        bumps MINOR via the same neutral change-type as a numeric edit
        per ADR 0013. Direction is not tracked.
        """
        previous_pair = (previous.threshold, previous.compare_mode)
        current_pair = (current.threshold, current.compare_mode)
        if previous_pair == current_pair:
            return None
        return ContractChange(
            change_type=ChangeType.CHECK_THRESHOLD_CHANGED,
            contract_id=contract_id,
            check_name=previous.name,
            old_value=format_threshold_with_compare(previous.threshold, previous.compare_mode),
            new_value=format_threshold_with_compare(current.threshold, current.compare_mode),
        )
