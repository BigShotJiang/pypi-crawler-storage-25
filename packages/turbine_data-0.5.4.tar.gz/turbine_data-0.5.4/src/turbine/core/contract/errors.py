"""Domain exceptions raised by contract lookup."""

from turbine.core.building_blocks import Diagnostic, TurbineError


class ContractNotFoundError(TurbineError):
    """Raised when a contract id cannot be resolved in any repository."""

    def __init__(self, *, contract_id: str, diagnostics: tuple[Diagnostic, ...] = ()) -> None:
        """Record which id was missing, along with any diagnostics collected while searching."""
        super().__init__(f"contract '{contract_id}' not found", diagnostics=diagnostics)
        self.contract_id = contract_id


class ContractVersionError(TurbineError):
    """Raised when a contract version cannot be parsed or rewritten."""
