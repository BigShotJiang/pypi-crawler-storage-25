"""Diagnostic collector for contract repository scans."""

from collections.abc import Iterable
from dataclasses import dataclass, field

from turbine.core.building_blocks import Diagnostic


@dataclass(slots=True)
class ContractDiagnosticCollector:
    """Keeps diagnostics emitted while scanning contract repositories."""

    items: list[Diagnostic] = field(default_factory=list)

    def add(self, diagnostic: Diagnostic) -> None:
        """Append one diagnostic."""
        self.items.append(diagnostic)

    def extend(self, diagnostics: Iterable[Diagnostic]) -> None:
        """Append all diagnostics from an iterable."""
        self.items.extend(diagnostics)
