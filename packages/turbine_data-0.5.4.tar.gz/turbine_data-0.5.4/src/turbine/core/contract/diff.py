"""Pydantic models for contract diff results."""

from pathlib import Path

from pydantic import BaseModel, Field, field_serializer

from turbine.core.common.change_types import ChangeType, ContractChange
from turbine.core.contract.semver import SemverBump


class ChangeEntry(BaseModel, frozen=True):
    """One change in a contract diff, serialization-ready."""

    type: ChangeType
    column: str | None = None
    check: str | None = None
    old_value: str | None = None
    new_value: str | None = None
    old_nullable: bool | None = None
    new_nullable: bool | None = None

    @field_serializer("type")
    @classmethod
    def serialize_type(cls, change_type: ChangeType) -> str:
        return change_type.value

    @classmethod
    def from_change(cls, change: ContractChange) -> "ChangeEntry":
        return cls(
            type=change.change_type,
            column=change.column_name,
            check=change.check_name,
            old_value=change.old_value,
            new_value=change.new_value,
            old_nullable=change.old_nullable,
            new_nullable=change.new_nullable,
        )


class ContractDiffEntry(BaseModel, frozen=True):
    """Diff result for a single contract or quality spec."""

    contract_id: str
    source_path: Path = Field(exclude=True)
    changes: tuple[ChangeEntry, ...]
    bump: SemverBump
    old_version: str
    new_version: str
    is_new: bool

    @field_serializer("bump")
    @classmethod
    def serialize_bump(cls, bump: SemverBump) -> str:
        return bump.label


class DiffResult(BaseModel, frozen=True):
    """Aggregate diff result across all contracts and quality specs."""

    entries: tuple[ContractDiffEntry, ...]
    highest_bump: SemverBump

    @field_serializer("highest_bump")
    @classmethod
    def serialize_highest_bump(cls, bump: SemverBump) -> str:
        return bump.label
