"""Health rule parsing and evaluation for scalar dashboard components.

A ``HealthRule`` pairs a comparison operator with a numeric threshold. The
``KPI`` and ``Gauge`` components accept SQLAlchemy ``BinaryExpression``
instances (``Run.failed == 0``, ``Run.pass_rate >= 0.95``) via the
``healthy=`` parameter; those expressions are parsed here into the
typed value object so the renderer consumes a single shape.

The parser mirrors the access path used by ``filter_translator.py``:
``expression.operator.__name__`` for the comparison op, and
``expression.right.value`` for the literal threshold. Column-to-column
comparisons, compound boolean expressions, and non-numeric thresholds
are rejected at parse time so the mismatch surfaces at page
construction, not at render.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Any


class Op(Enum):
    """Supported comparison operators for a ``HealthRule``."""

    EQ = "eq"
    NE = "ne"
    LT = "lt"
    LE = "le"
    GT = "gt"
    GE = "ge"


OPERATOR_NAME_TO_OP: dict[str, Op] = {op.value: op for op in Op}


COMPARE: dict[Op, Any] = {
    Op.EQ: lambda value, threshold: value == threshold,
    Op.NE: lambda value, threshold: value != threshold,
    Op.LT: lambda value, threshold: value < threshold,
    Op.LE: lambda value, threshold: value <= threshold,
    Op.GT: lambda value, threshold: value > threshold,
    Op.GE: lambda value, threshold: value >= threshold,
}


@dataclass(frozen=True)
class HealthRule:
    """A comparison of a scalar value against a numeric threshold."""

    op: Op
    threshold: float

    @classmethod
    def from_expression(cls, expression: Any) -> HealthRule:
        """Parse a SQLAlchemy ``BinaryExpression`` into a ``HealthRule``.

        Accepts only the six comparison operators (``==``, ``!=``, ``<``,
        ``<=``, ``>``, ``>=``) against a numeric literal right-hand side.
        Anything else raises ``ValueError`` so the mismatch surfaces at
        ``Page(...)`` construction time.
        """
        if hasattr(expression, "clauses"):
            msg = f"healthy= does not support compound expressions: {expression!r}"
            raise ValueError(msg)
        operator_name = getattr(getattr(expression, "operator", None), "__name__", "")
        matched_op = OPERATOR_NAME_TO_OP.get(operator_name)
        if matched_op is None:
            msg = f"healthy= unsupported operator: {operator_name or type(expression).__name__}"
            raise ValueError(msg)
        right = getattr(expression, "right", None)
        if not hasattr(right, "value"):
            msg = f"healthy= right-hand side must be a literal, got: {right!r}"
            raise ValueError(msg)
        threshold = right.value
        if not isinstance(threshold, (int, float)) or isinstance(threshold, bool):
            msg = f"healthy= threshold must be numeric, got: {threshold!r}"
            raise ValueError(msg)  # noqa: TRY004  # shape-validation parser, not a type guard
        return cls(op=matched_op, threshold=threshold)


def evaluate(rule: HealthRule, value: float | None) -> bool | None:
    """Evaluate ``rule`` against ``value``; return ``None`` when value is missing."""
    if value is None:
        return None
    return bool(COMPARE[rule.op](value, rule.threshold))


def normalize_healthy(healthy: Any, value: Any, component_name: str) -> HealthRule | None:
    """Return ``healthy`` as a ``HealthRule | None``, parsing an expression if needed.

    Pure function. Accepts a pre-built ``HealthRule``, a SQLAlchemy
    ``BinaryExpression``, or ``None``. Raises ``TypeError`` when ``healthy``
    is set on a component whose ``value`` is a ``str`` — string values can't
    participate in numeric comparison, so the mismatch surfaces at
    ``Page(...)`` construction time.

    Consumed by ``KPI.__post_init__`` / ``Gauge.__post_init__`` which store
    the result in a ``healthy_rule`` field; the user-supplied ``healthy``
    slot is left untouched so the frozen contract holds for every
    caller-visible field.
    """
    if healthy is None:
        return None
    if isinstance(value, str):
        msg = f"{component_name}: healthy= is not supported on string values (got {value!r})"
        raise TypeError(msg)
    if isinstance(healthy, HealthRule):
        return healthy
    return HealthRule.from_expression(healthy)
