"""Dashboard DSL errors."""

from __future__ import annotations


class PickerError(ValueError):
    """Raised when a typed Picker can't be resolved to a matching Dataset on the page."""
