from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ThemeColors:
    """Color palette for the dashboard UI."""

    background: str
    surface: str
    text: str
    accent: str
    grid: str
    muted: str


@dataclass(frozen=True)
class ChartPalette:
    """Colors for chart rendering."""

    series: tuple[str, ...]
    positive: str
    warning: str
    negative: str
    fill_opacity: float


@dataclass(frozen=True)
class Theme:
    """Complete dashboard theme configuration."""

    name: str
    colors: ThemeColors
    chart: ChartPalette


DARK_THEME = Theme(
    name="dark",
    colors=ThemeColors(
        background="#0A1020",
        surface="#0D1428",
        text="#E2E4EA",
        accent="#4C90FC",
        grid="#1E293B",
        muted="#8A94A6",
    ),
    chart=ChartPalette(
        series=("#4C90FC", "#34D399", "#FBBF24", "#F87171", "#6BABFF"),
        positive="#34D399",
        warning="#FBBF24",
        negative="#F87171",
        fill_opacity=0.08,
    ),
)
