"""Public extension API for user-defined dashboard components.

The ``@component`` decorator turns a plain class into a frozen dataclass and
appends it to ``USER_COMPONENTS``. The presentation renderer reads that list
at construction time and wires each entry into its singledispatch map.

    @component
    class MetricCard:
        title: str
        value: float

        def render(self) -> Component:
            return KPI(label=self.title, value=self.value)

The core module stays framework-free: it knows nothing about Streamlit or
the renderer. The renderer imports ``USER_COMPONENTS`` and builds handlers
on its own.
"""

from __future__ import annotations

from dataclasses import dataclass, is_dataclass
from typing import Any, dataclass_transform

USER_COMPONENTS: list[type] = []


@dataclass_transform(frozen_default=True)
def component[T](cls: type[T]) -> type[T]:
    """Register a class as a renderable dashboard component.

    Applies ``@dataclass(frozen=True)`` to the class and appends it to
    ``USER_COMPONENTS``. The renderer reads that list at startup and
    dispatches to ``render()`` for each instance it finds on a page.

    The class must define type-annotated fields and a ``render(self)``
    method that returns a built-in ``Component`` such as ``KPI``,
    ``BarChart``, or ``Table`` (see ``turbine.core.dashboard.components``).
    Do not stack ``@dataclass`` on top; ``@component`` is the only
    decorator needed.

    Args:
        cls: The component class to register.

    Returns:
        The same class, transformed into a frozen dataclass.

    Raises:
        TypeError: If ``cls`` is already a ``@dataclass`` or lacks a
            callable ``render`` attribute.

    Example:
        @component
        class MetricCard:
            title: str
            value: float

            def render(self) -> Component:
                return KPI(label=self.title, value=self.value)

        @page(title="Sales")
        def sales() -> Page:
            return Page(content=[MetricCard(title="Revenue", value=42_000)])
    """
    validate_component_class(cls)
    cls = dataclass(frozen=True)(cls)
    USER_COMPONENTS.append(cls)
    return cls


def validate_component_class(cls: type[Any]) -> None:
    """Raise TypeError if cls can't become a valid component."""
    if is_dataclass(cls):
        msg = f"{cls.__name__} is already a @dataclass. Remove @dataclass and let @component handle it."
        raise TypeError(msg)
    if not callable(getattr(cls, "render", None)):
        msg = f"@component class {cls.__name__} must define a render() method"
        raise TypeError(msg)
