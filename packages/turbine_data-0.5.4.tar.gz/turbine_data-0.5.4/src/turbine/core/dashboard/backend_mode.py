"""Backend selection mode for the dashboard."""

from __future__ import annotations

from enum import StrEnum


class BackendMode(StrEnum):
    """Which QueryDispatcher implementation the dashboard should use."""

    DEMO = "demo"
    API = "api"
