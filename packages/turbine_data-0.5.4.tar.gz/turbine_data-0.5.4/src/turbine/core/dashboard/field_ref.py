"""Typed column references for the dashboard DSL.

`FieldRef[M, V]` is a structural protocol that any column-ref object can
satisfy. SQLModel's `sqlalchemy.orm.InstrumentedAttribute` satisfies it at
call sites without core/ needing to import sqlalchemy: both `.key` and
`.class_` are already present on every SQLModel column descriptor.

Users write `data.sum(Order.amount)`, the dashboard runtime introspects
`.key` to get the column name and `.class_` to get the model class.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable


@runtime_checkable
class FieldRef[M, V](Protocol):
    """Column reference over model `M` with value type `V`.

    Structural shape matches SQLAlchemy's `InstrumentedAttribute[V]`:
    `.key` is the column name, `.class_` is the owning model class.
    """

    @property
    def key(self) -> str: ...

    @property
    def class_(self) -> type[M]: ...
