"""Shared chart data resolution helpers.

Pure domain logic: resolve axis data from either explicit tuples or
FieldRef + Dataset. When both axes are FieldRefs with a dataset attached,
values are extracted via `data.col()` and auto-aggregated via
`data.group_by()` so duplicate x values collapse into a single bar / point.

Chart dataclasses call these helpers from their `extract()` methods.
"""

from __future__ import annotations

import logging
from collections.abc import Callable, Sequence
from dataclasses import dataclass, replace
from datetime import date, datetime, timedelta
from statistics import mean as stats_mean
from statistics import quantiles
from typing import Any, Literal, SupportsFloat, SupportsIndex, get_type_hints

from turbine.core.dashboard.dataset import Dataset, HistogramBin
from turbine.core.dashboard.field_ref import FieldRef

chart_data_logger = logging.getLogger(__name__)

NUMERIC_TYPES: tuple[type, ...] = (int, float)

MIN_SANKEY_STAGES: int = 2

type AggregateOp = Literal["sum", "mean", "count", "max", "min"]
type TimeBucket = Literal["hour", "day", "week", "month"]
type NetworkLayout = Literal["force", "kamada_kawai", "layered"]

MIN_BOXPLOT_SAMPLE: int = 2


class ChartDataError(ValueError):
    """Raised when a chart can't be resolved to a concrete data shape."""


@dataclass(frozen=True)
class BarChartData:
    """Resolved x/y tuples for a BarChart."""

    x: tuple[Any, ...]
    y: tuple[float, ...]


@dataclass(frozen=True)
class TrendChartData:
    """Resolved x/y tuples for a TrendChart."""

    x: tuple[Any, ...]
    y: tuple[float, ...]


@dataclass(frozen=True)
class HeatmapData:
    """Resolved x/y labels and z matrix for a Heatmap."""

    x_labels: tuple[str, ...]
    y_labels: tuple[str, ...]
    z: tuple[tuple[float, ...], ...]


@dataclass(frozen=True)
class CategoryValueData:
    """Paired category labels and numeric values for Doughnut / Funnel."""

    labels: tuple[Any, ...]
    values: tuple[float, ...]


@dataclass(frozen=True)
class HistogramChartData:
    """Binned values for a Histogram."""

    bins: tuple[HistogramBin, ...]


@dataclass(frozen=True)
class BoxplotCategoryStats:
    """Five-number summary plus outliers for one boxplot category."""

    category: str
    low: float
    q1: float
    median: float
    q3: float
    high: float
    outliers: tuple[float, ...]


@dataclass(frozen=True)
class BoxplotData:
    """Resolved per-category stats for a Boxplot."""

    categories: tuple[BoxplotCategoryStats, ...]


@dataclass(frozen=True)
class RadarData:
    """Resolved subject + indicator values for a Radar."""

    subject: str
    indicator_names: tuple[str, ...]
    max_values: tuple[float, ...]
    values: tuple[float, ...]


@dataclass(frozen=True)
class ScatterData:
    """Resolved x/y points with optional color dimension for a ScatterPlot."""

    x: tuple[float, ...]
    y: tuple[float, ...]
    color_field: str = ""
    color_values: tuple[Any, ...] = ()
    is_color_categorical: bool = False


@dataclass(frozen=True)
class BubbleData:
    """Resolved x/y/size points with optional color dimension for a BubbleChart."""

    x: tuple[float, ...]
    y: tuple[float, ...]
    size: tuple[float, ...]
    color_field: str = ""
    color_values: tuple[Any, ...] = ()
    is_color_categorical: bool = False


@dataclass(frozen=True)
class ParallelData:
    """Resolved per-row dimension values for a Parallel coordinates chart."""

    dim_names: tuple[str, ...]
    rows: tuple[tuple[float, ...], ...]
    color_dim_index: int | None = None
    color_values: tuple[float, ...] = ()


@dataclass(frozen=True)
class TimelineEvent:
    """One point on an EventTimeline: a timestamp on a named lane."""

    time: datetime
    lane: str
    label: str = ""


@dataclass(frozen=True)
class EventTimelineData:
    """Resolved events + ordered lane list for an EventTimeline."""

    events: tuple[TimelineEvent, ...] = ()
    lanes: tuple[str, ...] = ()


@dataclass(frozen=True)
class GanttTask:
    """One bar on a GanttTimeline: a [start, end] range on a named lane."""

    lane: str
    start: datetime
    end: datetime
    label: str = ""


@dataclass(frozen=True)
class GanttTimelineData:
    """Resolved tasks + ordered lane list for a GanttTimeline."""

    tasks: tuple[GanttTask, ...] = ()
    lanes: tuple[str, ...] = ()


@dataclass(frozen=True)
class CalendarHeatmapPoint:
    """One day-cell on a CalendarHeatmap: an ISO date string plus its value."""

    date: str
    value: float


@dataclass(frozen=True)
class CalendarHeatmapData:
    """Resolved per-day values for a CalendarHeatmap."""

    points: tuple[CalendarHeatmapPoint, ...] = ()
    year: int | None = None


@dataclass(frozen=True)
class SankeyNode:
    """One node on a Sankey: a unique name plus its stage index."""

    name: str
    stage: int


@dataclass(frozen=True)
class SankeyLink:
    """One flow on a Sankey: source, target, value, and the source name for coloring."""

    source: str
    target: str
    value: float


@dataclass(frozen=True)
class SankeyData:
    """Resolved nodes + links for a Sankey diagram."""

    nodes: tuple[SankeyNode, ...] = ()
    links: tuple[SankeyLink, ...] = ()


@dataclass(frozen=True)
class TreeNode:
    """One node on a Tree: name, optional value, and ordered children."""

    name: str
    value: float = 0.0
    children: tuple[TreeNode, ...] = ()


@dataclass(frozen=True)
class TreeData:
    """Resolved root for a Tree component."""

    root: TreeNode | None = None


@dataclass(frozen=True)
class HierarchyNode:
    """One node in a TreeMap / Sunburst hierarchy.

    ``value`` is the aggregated ``size`` of every row that sits at or below
    this node (so intermediate nodes already equal the sum of their children,
    which is what Plotly's ``branchvalues='total'`` expects). ``color_value``
    is the mean of the color column across the same rows, or ``None`` when
    no color field was supplied.
    """

    name: str
    value: float = 0.0
    color_value: float | None = None
    children: tuple[HierarchyNode, ...] = ()


@dataclass(frozen=True)
class HierarchyData:
    """Resolved root for a TreeMap or Sunburst component."""

    root: HierarchyNode | None = None

    def descend(self, values: Sequence[str]) -> DescentResult:
        """Walk the hierarchy down ``values`` and return a descent snapshot.

        Each value is matched against the current node's children by name and
        descent stops at the first non-matching value. The returned
        ``DescentResult`` carries the deepest data still on the path plus
        ``requested_depth`` / ``matched_depth`` so callers can detect a stale
        drill path. Empty input or an empty hierarchy yields self unchanged
        with ``matched_depth == requested_depth == 0`` (i.e. fully descended).
        """
        requested = len(values)
        if not values or self.root is None:
            return DescentResult(data=self, requested_depth=requested, matched_depth=0)
        current = self.root
        matched = 0
        for value in values:
            match = next((child for child in current.children if child.name == value), None)
            if match is None:
                break
            current = match
            matched += 1
        descended = self if current is self.root else HierarchyData(root=current)
        return DescentResult(data=descended, requested_depth=requested, matched_depth=matched)


@dataclass(frozen=True)
class DescentResult:
    """A snapshot of ``HierarchyData.descend``: data plus path-match metadata.

    ``fully_descended`` is False when the requested drill path went deeper than
    the data could match — typically because a level value was renamed or
    deleted. Renderers use it to surface a stale-drill warning rather than
    silently showing the wrong level.
    """

    data: HierarchyData
    requested_depth: int
    matched_depth: int

    @property
    def fully_descended(self) -> bool:
        """True when the descent reached every level the caller asked for."""
        return self.matched_depth == self.requested_depth


@dataclass(frozen=True)
class GraphNode:
    """One node on a NetworkGraph with an optional layered position."""

    name: str
    value: float = 0.0
    category: str = ""
    x: float | None = None
    y: float | None = None


@dataclass(frozen=True)
class GraphLink:
    """One edge on a NetworkGraph between two named nodes."""

    source: str
    target: str
    value: float = 1.0


@dataclass(frozen=True)
class NetworkGraphData:
    """Resolved nodes + links for a NetworkGraph."""

    nodes: tuple[GraphNode, ...] = ()
    links: tuple[GraphLink, ...] = ()
    has_positions: bool = False


@dataclass(frozen=True)
class ChoroplethMapData:
    """Resolved per-region values for a ChoroplethMap.

    ``regions`` and ``values`` are parallel tuples in geojson feature order,
    one entry per matched region. ``unmatched`` lists dataset region names
    that had no matching geojson feature (warned at build time, dropped from
    the main arrays so the chart renders them blank).
    """

    regions: tuple[str, ...] = ()
    values: tuple[float, ...] = ()
    unmatched: tuple[str, ...] = ()


def is_numeric_field(ref: FieldRef[Any, Any]) -> bool:
    """Return True when the FieldRef points to an int/float column on its model."""
    hints = get_type_hints(ref.class_)
    dtype = hints.get(ref.key)
    if dtype is None:
        return False
    return any(issubclass(dtype, numeric) for numeric in NUMERIC_TYPES if isinstance(dtype, type))


def resolve_xy(
    x: object, y: object, data: Dataset[Any] | None, aggregate: AggregateOp, component_name: str
) -> tuple[tuple[Any, ...], tuple[float, ...]]:
    """Shared resolver for BarChart / TrendChart axis pairs."""
    x_is_ref = isinstance(x, FieldRef)
    y_is_ref = isinstance(y, FieldRef)
    if x_is_ref != y_is_ref:
        msg = f"{component_name}: x and y must be both FieldRef or both tuples"
        raise ChartDataError(msg)
    if not x_is_ref:
        if not isinstance(x, Sequence) or not isinstance(y, Sequence):
            msg = f"{component_name}: x and y must be sequences when not using FieldRef axes"
            raise ChartDataError(msg)
        return tuple(x), tuple(parse_float_axis_value(value, component_name) for value in y)
    if data is None:
        msg = f"{component_name}: FieldRef axes require `data` to be set"
        raise ChartDataError(msg)
    if not isinstance(x, FieldRef) or not isinstance(y, FieldRef):
        msg = f"{component_name}: x and y must be both FieldRef or both tuples"
        raise ChartDataError(msg)
    return build_aggregated_xy(data, x, y, aggregate)


def parse_float_axis_value(value: object, component_name: str) -> float:
    """Convert a tuple-backed y-axis value to float or raise a chart error."""
    if not isinstance(value, str | bytes | bytearray | SupportsFloat | SupportsIndex):
        msg = f"{component_name}: y values must be numeric"
        raise ChartDataError(msg)
    try:
        return float(value)
    except (TypeError, ValueError) as exc:
        msg = f"{component_name}: y values must be numeric"
        raise ChartDataError(msg) from exc


def build_aggregated_xy(
    data: Dataset[Any], x_field: FieldRef[Any, Any], y_field: FieldRef[Any, Any], aggregate: AggregateOp
) -> tuple[tuple[Any, ...], tuple[float, ...]]:
    """Group ``data`` by ``x_field`` and aggregate ``y_field`` per group."""
    if data.total_count == 0:
        return (), ()
    grouped = data.group_by(x_field)
    reducer = pick_reducer(aggregate)
    aggregated = reducer(grouped, y_field)
    items = list(aggregated.items())
    x_values = tuple(key for key, _ in items)
    y_values = tuple(float(value) for _, value in items)
    return x_values, y_values


def pick_reducer(aggregate: AggregateOp) -> Callable[[Any, FieldRef[Any, Any]], dict[Any, float]]:
    """Return the Grouped method matching the aggregate name."""
    match aggregate:
        case "sum":
            return lambda grouped, field: grouped.sum(field)
        case "mean":
            return lambda grouped, field: grouped.mean(field)
        case "max":
            return lambda grouped, field: grouped.max(field)
        case "min":
            return lambda grouped, field: grouped.min(field)
        case "count":
            return lambda grouped, _field: {key: float(value) for key, value in grouped.count().items()}


def date_trunc(value: Any, bucket: TimeBucket) -> Any:
    """Truncate a datetime value to the start of its bucket.

    Returns the value unchanged when it is not a datetime, so callers can
    apply this lazily over heterogeneous tuples without blowing up on
    string axes.
    """
    if not isinstance(value, datetime):
        return value
    match bucket:
        case "hour":
            return value.replace(minute=0, second=0, microsecond=0)
        case "day":
            return value.replace(hour=0, minute=0, second=0, microsecond=0)
        case "week":
            day_floor = value.replace(hour=0, minute=0, second=0, microsecond=0)
            return day_floor - timedelta(days=day_floor.weekday())
        case "month":
            return value.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def bucket_aggregate_xy(
    x_values: tuple[Any, ...], y_values: tuple[float, ...], bucket: TimeBucket, aggregate: AggregateOp
) -> tuple[tuple[Any, ...], tuple[float, ...]]:
    """Re-bucket pre-resolved x/y pairs by truncating x values then aggregating.

    No-op for non-temporal x because date_trunc returns those untouched and
    the resulting groups stay one-to-one with the originals.
    """
    if not x_values:
        return x_values, y_values
    grouped: dict[Any, list[float]] = {}
    for x_value, y_value in zip(x_values, y_values, strict=True):
        grouped.setdefault(date_trunc(x_value, bucket), []).append(y_value)
    reducer = pick_scalar_reducer(aggregate)
    new_x = tuple(grouped.keys())
    new_y = tuple(reducer(values) for values in grouped.values())
    return new_x, new_y


def pick_scalar_reducer(aggregate: AggregateOp) -> Callable[[list[float]], float]:
    """Return a reducer that collapses a list of floats to a single value."""
    match aggregate:
        case "sum":
            return lambda values: float(sum(values))
        case "mean":
            return lambda values: float(stats_mean(values))
        case "max":
            return lambda values: float(max(values))
        case "min":
            return lambda values: float(min(values))
        case "count":
            return lambda values: float(len(values))


def compute_boxplot_stats(category: str, values: tuple[float, ...]) -> BoxplotCategoryStats:
    """Reduce raw values for one category to a five-number summary and outliers.

    Uses statistics.quantiles for q1/median/q3, then the 1.5*IQR rule to
    separate outliers. Whiskers clamp to values inside the IQR fences.
    """
    if not values:
        return BoxplotCategoryStats(
            category=category, low=0.0, q1=0.0, median=0.0, q3=0.0, high=0.0, outliers=()
        )
    sorted_values = sorted(values)
    if len(sorted_values) < MIN_BOXPLOT_SAMPLE:
        only = sorted_values[0]
        return BoxplotCategoryStats(
            category=category, low=only, q1=only, median=only, q3=only, high=only, outliers=()
        )
    q1, median, q3 = quantiles(sorted_values, n=4, method="inclusive")
    iqr = q3 - q1
    lower_fence = q1 - 1.5 * iqr
    upper_fence = q3 + 1.5 * iqr
    inliers = [value for value in sorted_values if lower_fence <= value <= upper_fence]
    outliers = tuple(value for value in sorted_values if value < lower_fence or value > upper_fence)
    low = inliers[0] if inliers else sorted_values[0]
    high = inliers[-1] if inliers else sorted_values[-1]
    return BoxplotCategoryStats(
        category=category, low=low, q1=q1, median=median, q3=q3, high=high, outliers=outliers
    )


def build_boxplot_data(
    data: Dataset[Any], category_field: FieldRef[Any, Any], value_field: FieldRef[Any, Any]
) -> BoxplotData:
    """Group ``data`` by category and compute per-group box statistics."""
    if data.total_count == 0:
        return BoxplotData(categories=())
    grouped = data.group_by(category_field)
    stats = tuple(
        compute_boxplot_stats(str(key), tuple(float(value) for value in subset.col(value_field)))
        for key, subset in grouped
    )
    return BoxplotData(categories=stats)


def iso_day_key(value: Any) -> str:
    """Format a date/datetime as 'YYYY-MM-DD', or str() anything else."""
    if isinstance(value, datetime):
        return value.strftime("%Y-%m-%d")
    if isinstance(value, date):
        return value.strftime("%Y-%m-%d")
    return str(value)


def build_calendar_heatmap_data(
    data: Dataset[Any],
    date_field: FieldRef[Any, Any],
    value_field: FieldRef[Any, Any] | None,
    aggregate: AggregateOp,
    year: int | None,
) -> CalendarHeatmapData:
    """Bucket ``date_field`` values to day and aggregate one cell per day.

    When ``value_field`` is None each row contributes 1.0 so the default
    ``"count"`` aggregate collapses to row counts. When ``year`` is set,
    days outside that year are dropped from the result.
    """
    if data.total_count == 0:
        return CalendarHeatmapData(year=year)
    dates_raw = data.col(date_field)
    values_raw: tuple[Any, ...] = (
        data.col(value_field) if value_field is not None else tuple(1.0 for _ in dates_raw)
    )
    per_day: dict[str, list[float]] = {}
    for raw_date, raw_value in zip(dates_raw, values_raw, strict=True):
        day = iso_day_key(raw_date)
        if year is not None and not day.startswith(f"{year}-"):
            continue
        per_day.setdefault(day, []).append(float(raw_value))
    reducer = pick_scalar_reducer(aggregate)
    points = tuple(
        CalendarHeatmapPoint(date=day, value=reducer(values)) for day, values in sorted(per_day.items())
    )
    return CalendarHeatmapData(points=points, year=year)


def build_heatmap_data(
    data: Dataset[Any],
    x_field: FieldRef[Any, Any],
    y_field: FieldRef[Any, Any],
    z_field: FieldRef[Any, Any],
    aggregate: AggregateOp,
) -> HeatmapData:
    """Group ``data`` by (x, y) and aggregate z per cell into a 2D matrix."""
    if data.total_count == 0:
        return HeatmapData(x_labels=(), y_labels=(), z=())
    x_labels = tuple(str(value) for value in data.distinct(x_field))
    y_labels = tuple(str(value) for value in data.distinct(y_field))
    grouped_by_x = data.group_by(x_field)
    reducer = pick_reducer(aggregate)
    cells: dict[tuple[str, str], float] = {}
    for x_key, x_subset in grouped_by_x:
        inner = x_subset.group_by(y_field)
        reduced = reducer(inner, z_field)
        for y_key, value in reduced.items():
            cells[(str(x_key), str(y_key))] = float(value)
    z_matrix = tuple(
        tuple(cells.get((x_label, y_label), 0.0) for x_label in x_labels) for y_label in y_labels
    )
    return HeatmapData(x_labels=x_labels, y_labels=y_labels, z=z_matrix)


def stage_node_name(stage_index: int, raw_value: Any) -> str:
    """Make a per-stage unique sankey node name so identical labels in two stages don't merge."""
    return f"s{stage_index}:{raw_value}"


def build_sankey_data(
    data: Dataset[Any], stages: tuple[FieldRef[Any, Any], ...], value_field: FieldRef[Any, Any] | None
) -> SankeyData:
    """Build Sankey nodes + links by walking adjacent stage columns row by row."""
    if len(stages) < MIN_SANKEY_STAGES or data.total_count == 0:
        return SankeyData()
    cols: tuple[FieldRef[Any, Any], ...] = stages if value_field is None else (*stages, value_field)
    rows = data.rows(cols)
    node_lookup: dict[str, SankeyNode] = {}
    flows: dict[tuple[str, str], float] = {}
    for row in rows:
        weight = float(row[value_field.key]) if value_field is not None else 1.0
        register_sankey_nodes(row, stages, node_lookup)
        accumulate_sankey_flows(row, stages, weight, flows)
    nodes = tuple(node_lookup.values())
    links = tuple(
        SankeyLink(source=source, target=target, value=value)
        for (source, target), value in flows.items()
    )
    return SankeyData(nodes=nodes, links=links)


def register_sankey_nodes(
    row: dict[str, Any], stages: tuple[FieldRef[Any, Any], ...], node_lookup: dict[str, SankeyNode]
) -> None:
    """Add a SankeyNode for every non-null stage value in this row."""
    for stage_index, stage_field in enumerate(stages):
        raw = row[stage_field.key]
        if raw is None:
            continue
        name = stage_node_name(stage_index, raw)
        node_lookup.setdefault(name, SankeyNode(name=name, stage=stage_index))


def accumulate_sankey_flows(
    row: dict[str, Any],
    stages: tuple[FieldRef[Any, Any], ...],
    weight: float,
    flows: dict[tuple[str, str], float],
) -> None:
    """Add this row's weight to every (stage_n, stage_n+1) flow it touches."""
    for stage_index in range(len(stages) - 1):
        source_raw = row[stages[stage_index].key]
        target_raw = row[stages[stage_index + 1].key]
        if source_raw is None or target_raw is None:
            continue
        source_name = stage_node_name(stage_index, source_raw)
        target_name = stage_node_name(stage_index + 1, target_raw)
        key = (source_name, target_name)
        flows[key] = flows.get(key, 0.0) + weight


def build_tree_data(
    data: Dataset[Any],
    name_field: FieldRef[Any, Any],
    parent_field: FieldRef[Any, Any],
    value_field: FieldRef[Any, Any] | None,
) -> TreeData:
    """Walk a parent/child adjacency dataset and assemble the tree from its first root."""
    if data.total_count == 0:
        return TreeData()
    cols: tuple[FieldRef[Any, Any], ...] = (
        (name_field, parent_field) if value_field is None else (name_field, parent_field, value_field)
    )
    rows = data.rows(cols)
    children_by_parent: dict[str | None, list[tuple[str, float]]] = {}
    for row in rows:
        name = str(row[name_field.key])
        parent_raw = row[parent_field.key]
        parent_name = None if parent_raw in (None, "") else str(parent_raw)
        value = float(row[value_field.key]) if value_field is not None else 0.0
        children_by_parent.setdefault(parent_name, []).append((name, value))
    roots = children_by_parent.get(None, [])
    if not roots:
        return TreeData()
    root_name, root_value = roots[0]
    return TreeData(root=build_tree_node(root_name, root_value, children_by_parent))


def build_tree_node(
    name: str, value: float, children_by_parent: dict[str | None, list[tuple[str, float]]]
) -> TreeNode:
    """Recursively assemble a TreeNode from a parent->children adjacency map."""
    children = tuple(
        build_tree_node(child_name, child_value, children_by_parent)
        for child_name, child_value in children_by_parent.get(name, [])
    )
    return TreeNode(name=name, value=value, children=children)


@dataclass(frozen=True)
class HierarchySpec:
    """Column-name bundle passed through recursive HierarchyNode construction."""

    level_keys: tuple[str, ...]
    size_key: str
    color_key: str | None = None


def build_hierarchy_data(
    data: Dataset[Any],
    levels: tuple[FieldRef[Any, Any], ...],
    size_field: FieldRef[Any, Any],
    color_field: FieldRef[Any, Any] | None,
) -> HierarchyData:
    """Walk ``levels`` left-to-right grouping rows and aggregating size/color.

    Intermediate nodes carry the sum of their descendants' sizes so Plotly's
    ``branchvalues='total'`` treemap renders without explicit parent totals.
    Color is aggregated as the mean across all rows under the node.
    """
    if not levels or data.total_count == 0:
        return HierarchyData()
    cols: tuple[FieldRef[Any, Any], ...] = (*levels, size_field)
    if color_field is not None:
        cols = (*cols, color_field)
    rows = data.rows(cols)
    spec = HierarchySpec(
        level_keys=tuple(level.key for level in levels),
        size_key=size_field.key,
        color_key=color_field.key if color_field is not None else None,
    )
    return HierarchyData(root=build_hierarchy_node("root", rows, spec, depth=0))


def build_hierarchy_node(
    name: str, rows: tuple[dict[str, Any], ...], spec: HierarchySpec, depth: int
) -> HierarchyNode:
    """Recursively assemble a HierarchyNode by grouping ``rows`` at ``depth``."""
    aggregated_size = float(sum(float(row[spec.size_key]) for row in rows))
    color_value = hierarchy_color_mean(rows, spec.color_key)
    if depth >= len(spec.level_keys):
        return HierarchyNode(name=name, value=aggregated_size, color_value=color_value)
    grouped = group_rows_by_key(rows, spec.level_keys[depth])
    children = tuple(
        build_hierarchy_node(child_name, child_rows, spec, depth + 1)
        for child_name, child_rows in grouped.items()
    )
    return HierarchyNode(name=name, value=aggregated_size, color_value=color_value, children=children)


def hierarchy_color_mean(rows: tuple[dict[str, Any], ...], color_key: str | None) -> float | None:
    """Mean of the color column across ``rows``; None when no color field set."""
    if color_key is None or not rows:
        return None
    values = [float(row[color_key]) for row in rows]
    return sum(values) / len(values)


def group_rows_by_key(
    rows: tuple[dict[str, Any], ...], key: str
) -> dict[str, tuple[dict[str, Any], ...]]:
    """Group rows by ``row[key]`` preserving first-seen order."""
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        grouped.setdefault(str(row[key]), []).append(row)
    return {name: tuple(bucket) for name, bucket in grouped.items()}


@dataclass(frozen=True)
class GraphNodeBinding:
    """Bundle of optional node FieldRefs so build_network_graph_data stays under arg-count limits."""

    name: FieldRef[Any, Any]
    value: FieldRef[Any, Any] | None = None
    category: FieldRef[Any, Any] | None = None
    x: FieldRef[Any, Any] | None = None
    y: FieldRef[Any, Any] | None = None


@dataclass(frozen=True)
class GraphEdgeBinding:
    """Bundle of edge FieldRefs to mirror GraphNodeBinding."""

    source: FieldRef[Any, Any]
    target: FieldRef[Any, Any]
    value: FieldRef[Any, Any] | None = None


def build_network_graph_data(
    nodes_data: Dataset[Any],
    edges_data: Dataset[Any],
    node_binding: GraphNodeBinding,
    edge_binding: GraphEdgeBinding,
    layout: NetworkLayout,
) -> NetworkGraphData:
    """Resolve node + edge datasets and apply the chosen layout."""
    if nodes_data.total_count == 0:
        return NetworkGraphData()
    nodes = read_graph_nodes(nodes_data, node_binding)
    links = read_graph_links(edges_data, edge_binding)
    return apply_network_layout(nodes, links, layout)


def read_graph_nodes(nodes_data: Dataset[Any], binding: GraphNodeBinding) -> tuple[GraphNode, ...]:
    """Project a nodes dataset into GraphNode tuples, picking up optional position fields."""
    optional_fields = (binding.value, binding.category, binding.x, binding.y)
    cols: tuple[FieldRef[Any, Any], ...] = (
        binding.name,
        *(field for field in optional_fields if field is not None),
    )
    rows = nodes_data.rows(cols)
    return tuple(
        GraphNode(
            name=str(row[binding.name.key]),
            value=float(row[binding.value.key]) if binding.value is not None else 0.0,
            category=str(row[binding.category.key]) if binding.category is not None else "",
            x=float(row[binding.x.key]) if binding.x is not None else None,
            y=float(row[binding.y.key]) if binding.y is not None else None,
        )
        for row in rows
    )


def read_graph_links(edges_data: Dataset[Any], binding: GraphEdgeBinding) -> tuple[GraphLink, ...]:
    """Project an edges dataset into GraphLink tuples, defaulting weight to 1.0."""
    if edges_data.total_count == 0:
        return ()
    cols: tuple[FieldRef[Any, Any], ...] = (
        (binding.source, binding.target)
        if binding.value is None
        else (binding.source, binding.target, binding.value)
    )
    rows = edges_data.rows(cols)
    return tuple(
        GraphLink(
            source=str(row[binding.source.key]),
            target=str(row[binding.target.key]),
            value=float(row[binding.value.key]) if binding.value is not None else 1.0,
        )
        for row in rows
    )


def apply_network_layout(
    nodes: tuple[GraphNode, ...], links: tuple[GraphLink, ...], layout: NetworkLayout
) -> NetworkGraphData:
    """Pick the right positioning strategy for the requested layout."""
    if layout == "kamada_kawai":
        positions = compute_kamada_kawai_positions(nodes, links)
        positioned = tuple(
            replace(node, x=positions[node.name][0], y=positions[node.name][1]) for node in nodes
        )
        return NetworkGraphData(nodes=positioned, links=links, has_positions=True)
    if layout == "layered":
        if any(node.x is None or node.y is None for node in nodes):
            msg = "NetworkGraph: layered layout requires node_x and node_y FieldRefs on every row"
            raise ChartDataError(msg)
        return NetworkGraphData(nodes=nodes, links=links, has_positions=True)
    return NetworkGraphData(nodes=nodes, links=links, has_positions=False)


@dataclass(frozen=True)
class ChoroplethBinding:
    """Bundle of choropleth inputs: region/value fields plus geojson join info."""

    region: FieldRef[Any, Any]
    value: FieldRef[Any, Any]
    aggregate: AggregateOp
    geojson: dict[str, Any]
    join_key: str


def build_choropleth_data(data: Dataset[Any], binding: ChoroplethBinding) -> ChoroplethMapData:
    """Aggregate ``binding.value`` per region then join to ``binding.geojson``.

    Dataset regions that don't exist as a feature property under
    ``binding.join_key`` are logged as a warning and returned via ``unmatched``;
    feature regions missing from the dataset are silently rendered blank by
    ECharts.
    """
    if data.total_count == 0:
        return ChoroplethMapData()
    grouped = data.group_by(binding.region)
    reducer = pick_reducer(binding.aggregate)
    aggregated = reducer(grouped, binding.value)
    feature_names = extract_feature_names(binding.geojson, binding.join_key)
    feature_set = set(feature_names)
    matched: dict[str, float] = {}
    unmatched_names: list[str] = []
    for raw_region, numeric in aggregated.items():
        region_name = str(raw_region)
        if region_name in feature_set:
            matched[region_name] = float(numeric)
            continue
        unmatched_names.append(region_name)
    if unmatched_names:
        chart_data_logger.warning(
            "ChoroplethMap: %d region(s) have no matching geojson feature on '%s': %s",
            len(unmatched_names),
            binding.join_key,
            ", ".join(sorted(unmatched_names)),
        )
    regions = tuple(name for name in feature_names if name in matched)
    values = tuple(matched[name] for name in regions)
    return ChoroplethMapData(regions=regions, values=values, unmatched=tuple(unmatched_names))


def extract_feature_names(geojson: dict[str, Any], join_key: str) -> tuple[str, ...]:
    """Pull the join-key property off every feature in a GeoJSON FeatureCollection."""
    features = geojson.get("features", [])
    names: list[str] = []
    for feature in features:
        properties = feature.get("properties") or {}
        value = properties.get(join_key)
        if value is None:
            continue
        names.append(str(value))
    return tuple(names)


def compute_kamada_kawai_positions(
    nodes: tuple[GraphNode, ...], links: tuple[GraphLink, ...]
) -> dict[str, tuple[float, float]]:
    """Lay out a graph with networkx.kamada_kawai_layout, which delegates to scipy.optimize."""
    try:
        import scipy  # noqa: F401, PLC0415
    except ImportError as exc:
        msg = "NetworkGraph: kamada_kawai layout requires scipy. Install via `uv add turbine[graph]`."
        raise ChartDataError(msg) from exc
    import networkx as nx  # noqa: PLC0415

    graph = nx.Graph()
    for node in nodes:
        graph.add_node(node.name)
    for link in links:
        graph.add_edge(link.source, link.target)
    raw_positions = nx.kamada_kawai_layout(graph)
    return {name: (float(point[0]), float(point[1])) for name, point in raw_positions.items()}
