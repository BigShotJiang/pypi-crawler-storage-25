"""Typed position-path keys for dashboard components.

A ``KeyPath`` is an immutable sequence of ``(segment_name, index)`` pairs
that identifies a component by its structural position in the page tree.
It renders to strings like ``page:0:section:1:barchart:0`` for use as
Streamlit widget keys and ``session_state`` addresses.

Paths are threaded through dispatch as a function parameter, not stored
on the component. ``dataclasses.replace`` inside the render pipeline
produces new chart instances with new ``id()`` values, but the path is
derived from the caller's position so the key stays stable.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class KeyPath:
    """Position-path identifying a component within a page tree."""

    segments: tuple[tuple[str, int], ...]

    @classmethod
    def root(cls) -> KeyPath:
        return cls(segments=())

    def append(self, name: str, index: int) -> KeyPath:
        return KeyPath(segments=(*self.segments, (name, index)))

    def as_key(self) -> str:
        return ":".join(f"{name}:{index}" for name, index in self.segments)

    def is_root(self) -> bool:
        return not self.segments
