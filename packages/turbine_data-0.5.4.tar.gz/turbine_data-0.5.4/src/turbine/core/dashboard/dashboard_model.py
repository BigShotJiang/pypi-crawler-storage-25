"""Pydantic base model with FieldRef-compatible class attributes.

Plain Pydantic models expose ``FieldInfo`` at the class level and their
fields are typed as the declared annotation (``dimension: QualityDimension``),
which lacks the ``.key`` / ``.class_`` shape that the dashboard DSL expects.
``DashboardModel`` installs ``ColumnRef`` instances as non-data descriptors
for every declared field so ``MyModel.score`` returns a ``ColumnRef`` that
satisfies ``FieldRef`` at both runtime and static-type-checking time, while
instance access (``instance.score``) returns the real value as usual.

Usage::

    class Score(DashboardModel):
        dimension: str
        value: float

    Score.dimension.key      # "dimension"
    Score.dimension.class_   # Score
    isinstance(Score.dimension, FieldRef)  # True

    score = Score(dimension="accuracy", value=95.0)
    score.dimension          # "accuracy"  (normal instance access)
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Literal, overload

from pydantic import BaseModel, ConfigDict

ComparisonOp = Literal["eq", "ne", "gt", "ge", "lt", "le"]
BoolOp = Literal["and", "or"]


@dataclass(frozen=True)
class ColumnExpr:
    """Filter clause produced by ``ColumnRef`` comparisons.

    Lets page authors write ``Model.field > 0`` instead of
    ``lambda row: row.field > 0``. Consumed by ``filter_translator``.
    """

    column: str
    op: ComparisonOp
    value: Any

    def __and__(self, other: ColumnExpr | BoolExpr) -> BoolExpr:
        return combine_bool("and", self, other)

    def __or__(self, other: ColumnExpr | BoolExpr) -> BoolExpr:
        return combine_bool("or", self, other)


@dataclass(frozen=True)
class BoolExpr:
    """Composite filter clause combining sub-expressions with and/or.

    Produced by ``&`` and ``|`` on ``ColumnExpr`` / ``BoolExpr``. Same-op
    chains flatten (``a & b & c`` -> one 3-clause ``BoolExpr``).
    """

    op: BoolOp
    clauses: tuple[ColumnExpr | BoolExpr, ...]

    def __and__(self, other: ColumnExpr | BoolExpr) -> BoolExpr:
        return combine_bool("and", self, other)

    def __or__(self, other: ColumnExpr | BoolExpr) -> BoolExpr:
        return combine_bool("or", self, other)


def combine_bool(op: BoolOp, left: ColumnExpr | BoolExpr, right: ColumnExpr | BoolExpr) -> BoolExpr:
    """Combine two expressions under ``op``, flattening same-op BoolExprs."""
    left_clauses = left.clauses if isinstance(left, BoolExpr) and left.op == op else (left,)
    right_clauses = right.clauses if isinstance(right, BoolExpr) and right.op == op else (right,)
    return BoolExpr(op=op, clauses=left_clauses + right_clauses)


class ColumnRef:
    """Non-data descriptor satisfying the ``FieldRef[M, V]`` protocol.

    Installed as a class attribute on ``DashboardModel`` subclasses. At the
    class level, ``__get__`` returns the descriptor itself (a ``ColumnRef``);
    static type checkers pick up the overloaded return type and see
    ``MyModel.field`` as ``ColumnRef``. Since it has no ``__set__``, instance
    access falls through to ``instance.__dict__``, leaving Pydantic's
    runtime semantics intact.

    Comparison operators return ``ColumnExpr`` rather than ``bool`` so
    ``Dataset.where(Model.field > 0)`` works without lambdas. Same trade-off
    SQLAlchemy makes on its column descriptors. ``__hash__`` is restored to
    identity-based so ``ColumnRef`` stays usable as a dict key.
    """

    __slots__ = ("column", "model")

    def __init__(self, column: str, model: type) -> None:
        self.column = column
        self.model = model

    @property
    def key(self) -> str:
        return self.column

    @property
    def class_(self) -> type:
        return self.model

    def __gt__(self, other: Any) -> ColumnExpr:
        return ColumnExpr(self.column, "gt", other)

    def __ge__(self, other: Any) -> ColumnExpr:
        return ColumnExpr(self.column, "ge", other)

    def __lt__(self, other: Any) -> ColumnExpr:
        return ColumnExpr(self.column, "lt", other)

    def __le__(self, other: Any) -> ColumnExpr:
        return ColumnExpr(self.column, "le", other)

    @overload
    def __get__(self, instance: None, owner: type | None = None) -> ColumnRef: ...

    @overload
    def __get__(self, instance: object, owner: type | None = None) -> Any: ...

    def __get__(self, instance: object | None, owner: type | None = None) -> Any:
        if instance is None:
            return self
        return instance.__dict__[self.column]

    def __repr__(self) -> str:
        return f"ColumnRef({self.model.__name__}.{self.column})"


def column_ref_eq(self: ColumnRef, other: object) -> ColumnExpr:
    """Build an equality filter expression for ``ColumnRef == value``."""
    return ColumnExpr(self.column, "eq", other)


def column_ref_ne(self: ColumnRef, other: object) -> ColumnExpr:
    """Build an inequality filter expression for ``ColumnRef != value``."""
    return ColumnExpr(self.column, "ne", other)


eq_method_name = "__eq__"
ne_method_name = "__ne__"
hash_method_name = "__hash__"
setattr(ColumnRef, eq_method_name, column_ref_eq)
setattr(ColumnRef, ne_method_name, column_ref_ne)
setattr(ColumnRef, hash_method_name, object.__hash__)


class DashboardModel(BaseModel):
    """Pydantic model whose class attributes satisfy ``FieldRef``.

    Subclass this instead of ``BaseModel`` when the model will be used
    with ``Dataset[M]`` and the chart DSL (``BarChart(x=M.col, ...)``).
    Frozen by default since dashboard data models should be immutable.
    """

    model_config = ConfigDict(frozen=True)

    @classmethod
    def __pydantic_init_subclass__(cls, **kwargs: object) -> None:
        super().__pydantic_init_subclass__(**kwargs)
        for name in cls.model_fields:
            setattr(cls, name, ColumnRef(name, cls))
