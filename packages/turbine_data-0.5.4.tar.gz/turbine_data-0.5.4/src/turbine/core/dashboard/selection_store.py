"""Page-scoped, URL-backed selection + drill-stack store.

Holds the crossfilter state for a single dashboard page: a set of
``{field -> value}`` selections and an ordered stack of drill-down levels.
Round-trips through ``st.query_params`` so URLs are bookmarkable and
shareable.

URL encoding (flat prefixed keys):

- Selections: ``sel.{ModelName}.{column}={value}`` (one entry per selection)
- Drill stack: ``drill={ModelName}.{column}:{value}`` as a multi-value list
  param; order is preserved

This module stays framework-free: the presentation layer owns the actual
``st.query_params`` read/write. Tests feed plain mappings to
``from_params`` / consume plain dicts from ``to_params``.
"""

from __future__ import annotations

from collections.abc import Mapping, MutableMapping
from dataclasses import dataclass, field
from typing import Any

from turbine.core.dashboard.field_ref import FieldRef

SEL_PREFIX = "sel."
DRILL_PARAM = "drill"
DRILL_SEP = ":"


@dataclass(frozen=True)
class FieldKey:
    """Stable identity for a FieldRef: model class name + column name."""

    model_name: str
    column: str

    @classmethod
    def of(cls, ref: FieldRef[Any, Any]) -> FieldKey:
        """Build a FieldKey from any FieldRef-shaped object."""
        return cls(model_name=ref.class_.__name__, column=ref.key)

    def as_token(self) -> str:
        """Serialize as ``{ModelName}.{column}``."""
        return f"{self.model_name}.{self.column}"

    @classmethod
    def from_token(cls, token: str) -> FieldKey:
        """Parse ``{ModelName}.{column}`` back into a FieldKey."""
        model_name, _, column = token.partition(".")
        return cls(model_name=model_name, column=column)


@dataclass(frozen=True)
class DrillLevel:
    """One level in the drill-down stack: a ``(field, value)`` pair."""

    field: FieldKey
    value: str


@dataclass
class SelectionStore:
    """Per-page crossfilter and drill state, serializable to URL params."""

    selections: dict[FieldKey, str] = field(default_factory=dict)
    drill_stack: tuple[DrillLevel, ...] = ()

    @property
    def is_empty(self) -> bool:
        """True when there are no selections and no drill levels."""
        return not self.selections and not self.drill_stack

    def get(self, ref: FieldRef[Any, Any]) -> str | None:
        """Return the current selection for ``ref`` or None."""
        return self.selections.get(FieldKey.of(ref))

    def set(self, ref: FieldRef[Any, Any], value: str) -> None:
        """Set the selection for ``ref`` to ``value``."""
        self.selections[FieldKey.of(ref)] = value

    def clear(self, ref: FieldRef[Any, Any]) -> None:
        """Drop any selection on ``ref``. Safe when unset."""
        self.selections.pop(FieldKey.of(ref), None)

    def push_drill(self, ref: FieldRef[Any, Any], value: str) -> None:
        """Append a new drill level to the top of the stack."""
        self.drill_stack = (*self.drill_stack, DrillLevel(field=FieldKey.of(ref), value=value))

    def pop_drill(self) -> None:
        """Remove the top drill level. No-op on an empty stack."""
        self.drill_stack = self.drill_stack[:-1]

    def truncate_drill(self, keep: int) -> None:
        """Keep the first ``keep`` drill levels and drop the rest.

        Used by breadcrumb navigation: clicking the n-th crumb truncates the
        stack to length ``n``. Out-of-range values are clamped silently so
        callers don't need to bounds-check.
        """
        self.drill_stack = self.drill_stack[: max(keep, 0)]

    def clear_all(self) -> None:
        """Reset every selection and drill level."""
        self.selections = {}
        self.drill_stack = ()

    def selections_for(
        self, model_class: type, exclude: FieldRef[Any, Any] | None = None
    ) -> dict[str, str]:
        """Return ``{column: value}`` selections matching ``model_class``.

        Used as ``Dataset.where(**store.selections_for(Order))`` to apply
        active crossfilter state. Pass ``exclude`` to omit a chart's own
        scope_to column (self-exclusion rule: a chart never filters
        itself on its scoping dimension so the excluded subset stays
        visible for highlighting).
        """
        skip = FieldKey.of(exclude) if exclude is not None else None
        model_name = model_class.__name__
        return {
            field_key.column: value
            for field_key, value in self.selections.items()
            if field_key.model_name == model_name and field_key != skip
        }

    def to_params(self) -> dict[str, list[str]]:
        """Serialize the store to a flat mapping of URL params."""
        params: dict[str, list[str]] = {}
        for field_key, value in self.selections.items():
            params[f"{SEL_PREFIX}{field_key.as_token()}"] = [value]
        if self.drill_stack:
            params[DRILL_PARAM] = [
                f"{level.field.as_token()}{DRILL_SEP}{level.value}" for level in self.drill_stack
            ]
        return params

    @classmethod
    def from_params(cls, params: Mapping[str, str | list[str]]) -> SelectionStore:
        """Build a store from URL params. Ignores unrelated keys."""
        selections: dict[FieldKey, str] = {}
        for key, raw in params.items():
            if not key.startswith(SEL_PREFIX):
                continue
            token = key[len(SEL_PREFIX) :]
            selections[FieldKey.from_token(token)] = first_value(raw)
        drill_stack = tuple(parse_drill_levels(params.get(DRILL_PARAM)))
        return cls(selections=selections, drill_stack=drill_stack)


def first_value(raw: str | list[str]) -> str:
    """Pick the first value from a Streamlit-style scalar-or-list param."""
    if isinstance(raw, list):
        return raw[0] if raw else ""
    return raw


def commit_to_params(store: SelectionStore, params: MutableMapping[str, Any]) -> None:
    """Write ``store`` into ``params``, replacing any stale sel.*/drill entries.

    Keys outside the SelectionStore namespace (anything that doesn't start
    with ``sel.`` and isn't the ``drill`` param) are left untouched, so
    sibling query params (page routing, debug flags, etc.) survive.
    """
    stale = [key for key in params if key.startswith(SEL_PREFIX) or key == DRILL_PARAM]
    for key in stale:
        del params[key]
    for key, value in store.to_params().items():
        params[key] = value


def parse_drill_levels(raw: str | list[str] | None) -> list[DrillLevel]:
    """Parse the ``drill`` multi-value param into ordered DrillLevel entries."""
    if raw is None:
        return []
    items = raw if isinstance(raw, list) else [raw]
    levels: list[DrillLevel] = []
    for item in items:
        token, sep, value = item.partition(DRILL_SEP)
        if not sep:
            continue
        levels.append(DrillLevel(field=FieldKey.from_token(token), value=value))
    return levels
