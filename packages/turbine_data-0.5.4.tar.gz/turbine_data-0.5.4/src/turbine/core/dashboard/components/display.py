from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class SeverityLevel(StrEnum):
    """Alert severity level."""

    INFO = "info"
    WARNING = "warning"
    ERROR = "error"


@dataclass(frozen=True)
class Alert:
    """Notification banner with a severity level."""

    message: str
    severity: SeverityLevel = SeverityLevel.INFO
