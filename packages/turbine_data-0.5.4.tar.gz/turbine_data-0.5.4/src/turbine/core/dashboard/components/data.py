from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from enum import StrEnum
from typing import TYPE_CHECKING, Any, ClassVar, Protocol, Self, runtime_checkable

from pydantic import BaseModel, ConfigDict, model_validator

from turbine.core.dashboard.dataset import Dataset, FlaggedRow
from turbine.core.dashboard.field_ref import FieldRef
from turbine.core.dashboard.interactions import Interaction
from turbine.core.dashboard.query import Resource

if TYPE_CHECKING:
    from turbine.core.dashboard.components.layout import Component

type DetailCallback = Callable[[Any], Component]

ALL_VALUE = "All"

type CellValue = str | float | int | bool | None
type RowData = Mapping[str, CellValue]
type PickerValues = type[StrEnum] | tuple[str, ...] | None


@runtime_checkable
class DataclassInstance(Protocol):
    """Structural type for dataclass instances (runtime-checkable)."""

    __dataclass_fields__: ClassVar[dict[str, Any]]


type RowInput = RowData | BaseModel | DataclassInstance


class ColumnType(StrEnum):
    """Data type for a table column."""

    NUMBER = "number"
    TEXT = "text"


class ColumnWidth(StrEnum):
    """Display width hint for a table column."""

    SMALL = "small"
    MEDIUM = "medium"
    LARGE = "large"


@dataclass(frozen=True)
class ColumnConfig:
    """Column display configuration for Table and RowViewer components."""

    name: str
    column_type: ColumnType = ColumnType.TEXT
    fmt: str = ""
    width: ColumnWidth | None = None


@dataclass(frozen=True)
class Table:
    """Tabular data display with optional column config and download."""

    data: tuple[RowInput, ...] = ()
    columns: tuple[ColumnConfig, ...] = ()
    dataset: Dataset[Any] | None = None
    title: str = ""
    height: int = 320
    hide_index: bool = True
    downloadable: bool = False
    empty_message: str = "No data"


@dataclass(frozen=True)
class RowViewer:
    """Data table with expandable row detail.

    When ``detail`` is set, clicking a row opens a drawer rendered from
    ``detail(row)``. The ``detail`` callback receives the clicked row and
    returns a Component. Multiple ``RowViewer(detail=fn)`` on the same page
    get distinct auto-keyed drawer state.
    """

    data: tuple[RowInput, ...] = ()
    columns: tuple[ColumnConfig, ...] = ()
    dataset: Dataset[Any] | None = None
    expandable: bool = True
    on_click: Interaction | None = None
    title: str = ""
    height: int = 320
    hide_index: bool = True
    empty_message: str = "No data"
    detail: DetailCallback | None = None


@dataclass(frozen=True)
class Column:
    """Typed column spec: accepts a FieldRef and resolves the column name via ``.key``."""

    field: FieldRef[Any, Any]
    fmt: str | None = None
    width: ColumnWidth | None = None

    @property
    def name(self) -> str:
        return self.field.key


@dataclass(frozen=True)
class DefinitionList:
    """Key/value display rendering items in insertion order."""

    items: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class FlagPanel:
    """Panel showing all quality-check flags for a single flagged row."""

    row: FlaggedRow[Any]


@dataclass(frozen=True, init=False)
class Drawer:
    """Slide-out panel with positional children and explicit open/close control.

    Rendered inline when ``open`` is True; emits nothing when False. Multiple
    drawers on one page are auto-keyed by position so their state doesn't
    collide in session_state.
    """

    children: tuple[Any, ...]
    open: bool
    title: str | None

    def __init__(self, *children: Any, open: bool = False, title: str | None = None) -> None:  # noqa: A002
        object.__setattr__(self, "children", children)
        object.__setattr__(self, "open", open)
        object.__setattr__(self, "title", title)


class Picker(BaseModel):
    """Selection widget. Supports two mutually exclusive modes.

    Typed mode: ``Picker(column=Order.status)`` auto-scopes the matching
    ``Dataset[Order]`` on the page. Values come from the column enum or from
    distinct values discovered on the dataset when ``values`` is None.

    Generic mode: ``Picker(label="Table", source=FlaggedTables())`` drives the
    value from a Resource; used when the model isn't known at page-definition
    time (e.g. the built-in flagged-rows page).
    """

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    label: str = ""
    source: Resource[list[str]] | None = None
    column: FieldRef[Any, Any] | None = None
    values: PickerValues = None
    default: str = ALL_VALUE
    key: str = ""

    @model_validator(mode="after")
    def column_or_source_set(self) -> Self:
        if self.column is None and self.source is None:
            raise ValueError("Picker requires at least one of `column` or `source` to be set")
        return self

    def widget_key(self) -> str:
        """Stable non-empty identifier for Streamlit widget keys.

        Falls through key → label → column.key → ``picker-<SourceClass>``.
        ``__post_init__`` guarantees one of column/source is set, so the final
        branch always yields something.
        """
        if self.key:
            return self.key
        if self.label:
            return self.label
        if self.column is not None:
            return self.column.key
        return f"picker-{type(self.source).__name__}"
