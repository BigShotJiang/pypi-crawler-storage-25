from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
from functools import cached_property
from typing import Any, Literal, Self

from pydantic import BaseModel, ConfigDict, computed_field, model_validator

from turbine.core.dashboard.chart_data import (
    AggregateOp,
    BarChartData,
    BoxplotData,
    BubbleData,
    CalendarHeatmapData,
    CategoryValueData,
    ChartDataError,
    ChoroplethBinding,
    ChoroplethMapData,
    EventTimelineData,
    GanttTask,
    GanttTimelineData,
    GraphEdgeBinding,
    GraphNodeBinding,
    HeatmapData,
    HierarchyData,
    HistogramChartData,
    NetworkGraphData,
    NetworkLayout,
    ParallelData,
    RadarData,
    SankeyData,
    ScatterData,
    TimelineEvent,
    TreeData,
    TrendChartData,
    bucket_aggregate_xy,
    build_boxplot_data,
    build_calendar_heatmap_data,
    build_choropleth_data,
    build_heatmap_data,
    build_hierarchy_data,
    build_network_graph_data,
    build_sankey_data,
    build_tree_data,
    is_numeric_field,
    resolve_xy,
)
from turbine.core.dashboard.dataset import Dataset, HistogramBin
from turbine.core.dashboard.field_ref import FieldRef
from turbine.core.dashboard.health import HealthRule, normalize_healthy
from turbine.core.dashboard.interactions import Interaction

type ChartRenderer = Literal["echarts", "plotly"]
type AxisValues = tuple[str | float | datetime | date, ...]
# ``AxisField`` is typed as ``Any`` because Pydantic special-cases
# ``DashboardModel`` class attributes (``MyModel.dimension``) to the declared
# field type (``QualityDimension``, ``str``, etc.) rather than the installed
# ``ColumnRef`` descriptor. Widening here keeps user pages (``BarChart(x=M.col)``)
# clean; runtime callers still validate via ``isinstance(value, FieldRef)``.
type AxisField = Any
type HistogramStyle = Literal["solid", "gradient", "threshold"]
type GaugeVariant = Literal["ring", "speedometer"]
type BarOrientation = Literal["vertical", "horizontal"]
type TimeBucket = Literal["hour", "day", "week", "month"]
type CalendarColorMode = Literal["gradient", "piecewise"]


@dataclass(frozen=True)
class GaugeThreshold:
    """Color threshold for gauge rendering. Value is the lower bound for this color."""

    value: float
    color: str


DEFAULT_THRESHOLDS = (GaugeThreshold(90, "#34D399"), GaugeThreshold(80, "#FBBF24"))


class Gauge(BaseModel):
    """Radial gauge displaying a single metric with color-coded thresholds."""

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    label: str
    value: float | None
    min_value: float = 0
    max_value: float = 100
    thresholds: tuple[GaugeThreshold, ...] = DEFAULT_THRESHOLDS
    variant: GaugeVariant = "ring"
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"
    healthy: Any = None

    @computed_field
    @cached_property
    def healthy_rule(self) -> HealthRule | None:
        return normalize_healthy(self.healthy, self.value, "Gauge")

    @model_validator(mode="after")
    def force_healthy_rule(self) -> Self:
        _ = self.healthy_rule
        return self


@dataclass(frozen=True)
class TrendChart:
    """Line chart with optional fill and SLA reference line.

    ``x`` and ``y`` accept a SQLModel column reference (``FieldRef``) with
    ``data`` supplied, or an explicit ``tuple`` of values when no dataset is
    attached. With both FieldRefs and a dataset, values are extracted via
    ``data.col()`` and aggregated (default sum) grouped by x.
    """

    x: AxisField = ()
    y: AxisField = ()
    data: Dataset[Any] | None = None
    aggregate: AggregateOp = "sum"
    on_click: Interaction | None = None
    title: str = ""
    x_label: str = ""
    y_label: str = ""
    sla_line: float | None = None
    fill: bool = True
    height: int = 320
    bucket: TimeBucket | None = None
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> TrendChartData:
        """Resolve axis data into explicit x/y tuples, applying bucket if set."""
        x_vals, y_vals = resolve_xy(self.x, self.y, self.data, self.aggregate, "TrendChart")
        if self.bucket is not None:
            x_vals, y_vals = bucket_aggregate_xy(x_vals, y_vals, self.bucket, self.aggregate)
        return TrendChartData(x=x_vals, y=y_vals)


@dataclass(frozen=True)
class BarChart:
    """Vertical bar chart.

    ``x`` and ``y`` accept a ``FieldRef`` with ``data`` supplied, or an
    explicit ``tuple``. With both FieldRefs and a dataset, values are
    extracted via ``data.col()`` and aggregated (default sum) grouped by x.
    """

    x: AxisField = ()
    y: AxisField = ()
    data: Dataset[Any] | None = None
    aggregate: AggregateOp = "sum"
    on_click: Interaction | None = None
    title: str = ""
    x_label: str = ""
    y_label: str = ""
    color: str = "#6BABFF"
    height: int = 320
    orientation: BarOrientation = "vertical"
    stack: str | None = None
    race: bool = False
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> BarChartData:
        """Resolve axis data into explicit x/y tuples."""
        x_vals, y_vals = resolve_xy(self.x, self.y, self.data, self.aggregate, "BarChart")
        return BarChartData(x=x_vals, y=y_vals)


@dataclass(frozen=True)
class Heatmap:
    """2D heatmap with labeled axes and color gradient.

    Two construction modes:
      Explicit: ``Heatmap(x_labels, y_labels, z=<matrix>)``.
      Typed:    ``Heatmap(x=Order.status, y=Order.region, z=Order.amount, data=ds)``
                where z is aggregated (default sum) over each (x, y) cell.
    """

    x: FieldRef[Any, Any] | None = None
    y: FieldRef[Any, Any] | None = None
    z: FieldRef[Any, Any] | tuple[tuple[float, ...], ...] = ()
    data: Dataset[Any] | None = None
    aggregate: AggregateOp = "sum"
    on_click: Interaction | None = None
    x_labels: tuple[str, ...] = ()
    y_labels: tuple[str, ...] = ()
    title: str = ""
    z_fmt: str = ".1f%"
    height: int = 260
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> HeatmapData:
        """Resolve heatmap data from either explicit labels/matrix or FieldRefs."""
        if self.x is None and self.y is None and not isinstance(self.z, FieldRef):
            return HeatmapData(x_labels=self.x_labels, y_labels=self.y_labels, z=self.z)
        if not (
            isinstance(self.x, FieldRef)
            and isinstance(self.y, FieldRef)
            and isinstance(self.z, FieldRef)
        ):
            msg = "Heatmap: x, y, and z must all be FieldRefs when not using explicit labels + z matrix"
            raise ChartDataError(msg)
        if self.data is None:
            msg = "Heatmap: FieldRef axes require `data` to be set"
            raise ChartDataError(msg)
        return build_heatmap_data(self.data, self.x, self.y, self.z, self.aggregate)


@dataclass(frozen=True)
class Doughnut:
    """Pie chart with a hollow center, one slice per category."""

    x: AxisField = ()
    y: AxisField = ()
    data: Dataset[Any] | None = None
    aggregate: AggregateOp = "sum"
    on_click: Interaction | None = None
    title: str = ""
    palette: tuple[str, ...] = ()
    inner_radius: str = "40%"
    outer_radius: str = "70%"
    height: int = 320
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> CategoryValueData:
        """Resolve labels/values from explicit tuples or FieldRef + dataset."""
        labels, values = resolve_xy(self.x, self.y, self.data, self.aggregate, "Doughnut")
        return CategoryValueData(labels=labels, values=values)


@dataclass(frozen=True)
class Funnel:
    """Funnel chart: ordered descending by value to show stage drop-off."""

    x: AxisField = ()
    y: AxisField = ()
    data: Dataset[Any] | None = None
    aggregate: AggregateOp = "sum"
    on_click: Interaction | None = None
    title: str = ""
    palette: tuple[str, ...] = ()
    height: int = 320
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> CategoryValueData:
        """Resolve labels/values from explicit tuples or FieldRef + dataset."""
        labels, values = resolve_xy(self.x, self.y, self.data, self.aggregate, "Funnel")
        return CategoryValueData(labels=labels, values=values)


@dataclass(frozen=True)
class Histogram:
    """Binned distribution of a numeric column.

    ``value`` accepts a ``FieldRef`` with ``data`` supplied, or an explicit
    tuple of pre-computed ``HistogramBin`` entries. Three style variants
    drive bar coloring: ``solid``, ``gradient``, or ``threshold``.
    """

    value: FieldRef[Any, Any] | tuple[HistogramBin, ...] = ()
    data: Dataset[Any] | None = None
    on_click: Interaction | None = None
    bins: int | tuple[float, ...] = 20
    style: HistogramStyle = "solid"
    solid_color: str = "#6BABFF"
    gradient_start: str = "#6BABFF"
    gradient_end: str = "#A78BFA"
    threshold: float = 0.0
    below_color: str = "#34D399"
    above_color: str = "#F87171"
    title: str = ""
    x_label: str = ""
    y_label: str = ""
    height: int = 320
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> HistogramChartData:
        """Return pre-computed bins or bin ``data`` on the fly via ``FieldRef``."""
        if isinstance(self.value, FieldRef):
            if self.data is None:
                msg = "Histogram: FieldRef value requires `data` to be set"
                raise ChartDataError(msg)
            return HistogramChartData(bins=self.data.histogram(self.value, self.bins))
        return HistogramChartData(bins=tuple(self.value))


@dataclass(frozen=True)
class BoxplotCategoryColor:
    """Override the fill color for one boxplot category."""

    category: str
    color: str


@dataclass(frozen=True)
class Boxplot:
    """Per-category five-number summary with outlier scatter overlay.

    Pass ``category`` + ``value`` FieldRefs with ``data`` to group rows and
    compute stats automatically, or pass pre-computed ``explicit`` stats.
    """

    category: FieldRef[Any, Any] | None = None
    value: FieldRef[Any, Any] | None = None
    data: Dataset[Any] | None = None
    on_click: Interaction | None = None
    explicit: BoxplotData | None = None
    colors: tuple[BoxplotCategoryColor, ...] = ()
    default_color: str = "#6BABFF"
    outlier_color: str = "#F87171"
    title: str = ""
    x_label: str = ""
    y_label: str = ""
    height: int = 320
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> BoxplotData:
        """Return explicit stats or compute per-category stats from the dataset."""
        if self.explicit is not None:
            return self.explicit
        if self.category is None or self.value is None:
            return BoxplotData(categories=())
        if self.data is None:
            msg = "Boxplot: FieldRef category/value require `data` to be set"
            raise ChartDataError(msg)
        return build_boxplot_data(self.data, self.category, self.value)


@dataclass(frozen=True)
class RadarIndicator:
    """Single axis on a radar chart: name plus upper-bound value."""

    name: str
    max_value: float


@dataclass(frozen=True)
class Radar:
    """Radar (spider) chart comparing one subject across multiple indicators."""

    subject: str = ""
    indicators: tuple[RadarIndicator, ...] = ()
    values: tuple[float, ...] = ()
    title: str = ""
    color: str = "#6BABFF"
    fill: bool = True
    height: int = 320
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> RadarData:
        """Flatten indicators + values into a resolved RadarData snapshot."""
        if self.values and len(self.values) != len(self.indicators):
            msg = "Radar: values length must match indicators length"
            raise ChartDataError(msg)
        return RadarData(
            subject=self.subject,
            indicator_names=tuple(indicator.name for indicator in self.indicators),
            max_values=tuple(indicator.max_value for indicator in self.indicators),
            values=tuple(float(value) for value in self.values),
        )


DEFAULT_SAMPLE: int = 5000


@dataclass(frozen=True)
class ScatterPlot:
    """Scatter plot of two numeric fields with an optional color dimension.

    When ``color`` is set, its dtype on the model class decides rendering:
    string columns become categorical (one series per category), numeric
    columns drive a continuous visualMap. ``sample`` caps the row count so
    very large datasets stay responsive.
    """

    x: FieldRef[Any, Any] | None = None
    y: FieldRef[Any, Any] | None = None
    color: FieldRef[Any, Any] | None = None
    data: Dataset[Any] | None = None
    on_click: Interaction | None = None
    sample: int | None = DEFAULT_SAMPLE
    title: str = ""
    x_label: str = ""
    y_label: str = ""
    point_color: str = "#6BABFF"
    palette: tuple[str, ...] = ()
    height: int = 320
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> ScatterData:
        """Project x/y (and optional color) columns from ``data`` into points."""
        if self.x is None or self.y is None:
            return ScatterData(x=(), y=())
        if self.data is None:
            msg = "ScatterPlot: x and y require `data` to be set"
            raise ChartDataError(msg)
        cols: tuple[FieldRef[Any, Any], ...] = (
            (self.x, self.y) if self.color is None else (self.x, self.y, self.color)
        )
        rows = self.data.rows(cols, limit=self.sample)
        x_vals = tuple(float(row[self.x.key]) for row in rows)
        y_vals = tuple(float(row[self.y.key]) for row in rows)
        if self.color is None:
            return ScatterData(x=x_vals, y=y_vals)
        color_vals = tuple(row[self.color.key] for row in rows)
        return ScatterData(
            x=x_vals,
            y=y_vals,
            color_field=self.color.key,
            color_values=color_vals,
            is_color_categorical=not is_numeric_field(self.color),
        )


@dataclass(frozen=True)
class BubbleChart:
    """Bubble chart over three numeric fields with optional color dimension.

    ``size`` drives bubble radius via a JsCode ``symbolSize`` function; the
    optional ``color`` field is auto-categorized the same way ScatterPlot
    handles it.
    """

    x: FieldRef[Any, Any] | None = None
    y: FieldRef[Any, Any] | None = None
    size: FieldRef[Any, Any] | None = None
    color: FieldRef[Any, Any] | None = None
    data: Dataset[Any] | None = None
    on_click: Interaction | None = None
    sample: int | None = DEFAULT_SAMPLE
    title: str = ""
    x_label: str = ""
    y_label: str = ""
    point_color: str = "#6BABFF"
    palette: tuple[str, ...] = ()
    size_min: int = 4
    size_max: int = 40
    height: int = 320
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> BubbleData:
        """Project x/y/size (and optional color) columns from ``data`` into points."""
        if self.x is None or self.y is None or self.size is None:
            return BubbleData(x=(), y=(), size=())
        if self.data is None:
            msg = "BubbleChart: x, y, and size require `data` to be set"
            raise ChartDataError(msg)
        cols: tuple[FieldRef[Any, Any], ...] = (
            (self.x, self.y, self.size)
            if self.color is None
            else (self.x, self.y, self.size, self.color)
        )
        rows = self.data.rows(cols, limit=self.sample)
        x_vals = tuple(float(row[self.x.key]) for row in rows)
        y_vals = tuple(float(row[self.y.key]) for row in rows)
        size_vals = tuple(float(row[self.size.key]) for row in rows)
        if self.color is None:
            return BubbleData(x=x_vals, y=y_vals, size=size_vals)
        color_vals = tuple(row[self.color.key] for row in rows)
        return BubbleData(
            x=x_vals,
            y=y_vals,
            size=size_vals,
            color_field=self.color.key,
            color_values=color_vals,
            is_color_categorical=not is_numeric_field(self.color),
        )


@dataclass(frozen=True)
class Parallel:
    """Parallel coordinates over N numeric dimensions.

    Each dimension is one vertical axis; one polyline per row connects its
    values across axes. ``color`` selects which dimension drives a visualMap
    coloring (must be one of ``dimensions``); when omitted all lines share
    the same default color.
    """

    dimensions: tuple[FieldRef[Any, Any], ...] = ()
    color: FieldRef[Any, Any] | None = None
    data: Dataset[Any] | None = None
    on_click: Interaction | None = None
    sample: int | None = DEFAULT_SAMPLE
    title: str = ""
    line_color: str = "#6BABFF"
    line_opacity: float = 0.5
    height: int = 420
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> ParallelData:
        """Project each dimension column into a row matrix for ECharts parallel."""
        if not self.dimensions:
            return ParallelData(dim_names=(), rows=())
        dim_names = tuple(dim.key for dim in self.dimensions)
        if self.data is None:
            msg = "Parallel: dimensions require `data` to be set"
            raise ChartDataError(msg)
        raw_rows = self.data.rows(self.dimensions, limit=self.sample)
        matrix = tuple(tuple(float(row[name]) for name in dim_names) for row in raw_rows)
        if self.color is None:
            return ParallelData(dim_names=dim_names, rows=matrix)
        color_index = dim_names.index(self.color.key) if self.color.key in dim_names else None
        color_values = tuple(row[color_index] for row in matrix) if color_index is not None else ()
        return ParallelData(
            dim_names=dim_names, rows=matrix, color_dim_index=color_index, color_values=color_values
        )


@dataclass(frozen=True)
class EventTimeline:
    """Diamond markers on a time axis, one lane per category.

    ``time`` and ``lane`` are required FieldRefs projected out of ``data``;
    ``label`` is optional tooltip text. Each row becomes one event marker
    and lanes are auto-extracted in first-seen order for the y axis.
    """

    time: FieldRef[Any, Any] | None = None
    lane: FieldRef[Any, Any] | None = None
    label: FieldRef[Any, Any] | None = None
    data: Dataset[Any] | None = None
    on_click: Interaction | None = None
    sample: int | None = DEFAULT_SAMPLE
    title: str = ""
    x_label: str = ""
    y_label: str = ""
    palette: tuple[str, ...] = ()
    height: int = 320
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> EventTimelineData:
        """Project time/lane (and optional label) columns into timeline events."""
        if self.time is None or self.lane is None:
            return EventTimelineData()
        if self.data is None:
            msg = "EventTimeline: time and lane require `data` to be set"
            raise ChartDataError(msg)
        cols: tuple[FieldRef[Any, Any], ...] = (
            (self.time, self.lane) if self.label is None else (self.time, self.lane, self.label)
        )
        rows = self.data.rows(cols, limit=self.sample)
        label_key = self.label.key if self.label is not None else None
        events = tuple(
            TimelineEvent(
                time=row[self.time.key],
                lane=str(row[self.lane.key]),
                label=str(row[label_key]) if label_key is not None else "",
            )
            for row in rows
        )
        lanes = tuple(dict.fromkeys(event.lane for event in events))
        return EventTimelineData(events=events, lanes=lanes)


@dataclass(frozen=True)
class GanttTimeline:
    """Rounded bars spanning start/end on a time axis, one row per lane.

    ``lane``, ``start``, and ``end`` are required FieldRefs; ``label`` is an
    optional per-task caption. Lanes stay in first-seen order so the y axis
    mirrors the source dataset order.
    """

    lane: FieldRef[Any, Any] | None = None
    start: FieldRef[Any, Any] | None = None
    end: FieldRef[Any, Any] | None = None
    label: FieldRef[Any, Any] | None = None
    data: Dataset[Any] | None = None
    on_click: Interaction | None = None
    sample: int | None = DEFAULT_SAMPLE
    title: str = ""
    palette: tuple[str, ...] = ()
    height: int = 320
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> GanttTimelineData:
        """Project lane/start/end (and optional label) columns into Gantt tasks."""
        if self.lane is None or self.start is None or self.end is None:
            return GanttTimelineData()
        if self.data is None:
            msg = "GanttTimeline: lane, start, and end require `data` to be set"
            raise ChartDataError(msg)
        cols: tuple[FieldRef[Any, Any], ...] = (
            (self.lane, self.start, self.end)
            if self.label is None
            else (self.lane, self.start, self.end, self.label)
        )
        rows = self.data.rows(cols, limit=self.sample)
        label_key = self.label.key if self.label is not None else None
        tasks = tuple(
            GanttTask(
                lane=str(row[self.lane.key]),
                start=row[self.start.key],
                end=row[self.end.key],
                label=str(row[label_key]) if label_key is not None else "",
            )
            for row in rows
        )
        lanes = tuple(dict.fromkeys(task.lane for task in tasks))
        return GanttTimelineData(tasks=tasks, lanes=lanes)


@dataclass(frozen=True)
class CalendarHeatmap:
    """Daily cells over a calendar grid with gradient or piecewise coloring.

    ``date`` is a required FieldRef; ``value`` is optional and defaults to
    row counts when omitted. ``aggregate`` picks the reducer applied to
    each day bucket (``"count"`` by default). ``color_mode`` chooses between
    a continuous visualMap gradient or a discrete piecewise binning.
    """

    date: FieldRef[Any, Any] | None = None
    value: FieldRef[Any, Any] | None = None
    data: Dataset[Any] | None = None
    on_click: Interaction | None = None
    aggregate: AggregateOp = "count"
    color_mode: CalendarColorMode = "gradient"
    year: int | None = None
    title: str = ""
    palette: tuple[str, ...] = ()
    height: int = 200
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> CalendarHeatmapData:
        """Bucket rows to day and aggregate per-day values via the dataset."""
        if self.date is None:
            return CalendarHeatmapData(year=self.year)
        if self.data is None:
            msg = "CalendarHeatmap: date requires `data` to be set"
            raise ChartDataError(msg)
        return build_calendar_heatmap_data(self.data, self.date, self.value, self.aggregate, self.year)


@dataclass(frozen=True)
class Sankey:
    """Multi-stage flow diagram colored by source node.

    ``stages`` is an ordered tuple of FieldRefs naming the columns to walk
    left-to-right. Adjacent stage values become source/target pairs and the
    optional ``value`` FieldRef weighs each flow (defaults to row counts).
    """

    stages: tuple[FieldRef[Any, Any], ...] = ()
    value: FieldRef[Any, Any] | None = None
    data: Dataset[Any] | None = None
    on_click: Interaction | None = None
    title: str = ""
    palette: tuple[str, ...] = ()
    node_width: int = 16
    node_gap: int = 8
    height: int = 420
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> SankeyData:
        """Walk the dataset row by row and aggregate flows between adjacent stages."""
        if not self.stages:
            return SankeyData()
        if self.data is None:
            msg = "Sankey: stages require `data` to be set"
            raise ChartDataError(msg)
        return build_sankey_data(self.data, self.stages, self.value)


@dataclass(frozen=True)
class Tree:
    """Hierarchical tree diagram with orthogonal LR layout and expand/collapse.

    ``name`` and ``parent`` FieldRefs describe a parent/child adjacency over
    rows in ``data``; ``value`` is optional per-node payload. The first row
    whose parent is null becomes the root.
    """

    name: FieldRef[Any, Any] | None = None
    parent: FieldRef[Any, Any] | None = None
    value: FieldRef[Any, Any] | None = None
    data: Dataset[Any] | None = None
    on_click: Interaction | None = None
    title: str = ""
    initial_depth: int = 2
    line_color: str = "#6BABFF"
    symbol_size: int = 10
    height: int = 420
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> TreeData:
        """Build a tree from name/parent rows. Returns an empty TreeData if no root."""
        if self.name is None or self.parent is None:
            return TreeData()
        if self.data is None:
            msg = "Tree: name and parent require `data` to be set"
            raise ChartDataError(msg)
        return build_tree_data(self.data, self.name, self.parent, self.value)


@dataclass(frozen=True)
class NetworkGraph:
    """Force / kamada_kawai / layered network graph over dual node + edge datasets.

    ``nodes_data`` and ``edges_data`` are independent datasets joined by
    ``node_name`` <-> ``edge_source``/``edge_target``. The ``layout`` field
    picks how positions are computed:

    - ``force``: ECharts native force-directed layout, no extra deps.
    - ``kamada_kawai``: pre-computed via networkx (requires scipy at runtime).
    - ``layered``: caller supplies ``node_x`` / ``node_y`` for every row.
    """

    nodes_data: Dataset[Any] | None = None
    edges_data: Dataset[Any] | None = None
    node_name: FieldRef[Any, Any] | None = None
    edge_source: FieldRef[Any, Any] | None = None
    edge_target: FieldRef[Any, Any] | None = None
    node_value: FieldRef[Any, Any] | None = None
    node_category: FieldRef[Any, Any] | None = None
    node_x: FieldRef[Any, Any] | None = None
    node_y: FieldRef[Any, Any] | None = None
    edge_value: FieldRef[Any, Any] | None = None
    on_click: Interaction | None = None
    layout: NetworkLayout = "force"
    title: str = ""
    palette: tuple[str, ...] = ()
    symbol_size: int = 24
    repulsion: int = 200
    height: int = 420
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> NetworkGraphData:
        """Resolve nodes + edges from their datasets and apply the chosen layout."""
        if (
            self.nodes_data is None
            or self.edges_data is None
            or self.node_name is None
            or self.edge_source is None
            or self.edge_target is None
        ):
            return NetworkGraphData()
        node_binding = GraphNodeBinding(
            name=self.node_name,
            value=self.node_value,
            category=self.node_category,
            x=self.node_x,
            y=self.node_y,
        )
        edge_binding = GraphEdgeBinding(
            source=self.edge_source, target=self.edge_target, value=self.edge_value
        )
        return build_network_graph_data(
            self.nodes_data, self.edges_data, node_binding, edge_binding, self.layout
        )


@dataclass(frozen=True)
class TreeMap:
    """Plotly treemap over N hierarchical levels with a continuous color gradient.

    ``levels`` is an ordered tuple of FieldRefs walked left-to-right to nest
    rows. ``size`` is the required numeric column that drives tile area;
    ``color`` optionally drives the RdYlGn gradient. ``on_click=drill_down()``
    pushes the clicked tile onto the page's SelectionStore drill stack.
    """

    levels: tuple[FieldRef[Any, Any], ...] = ()
    size: FieldRef[Any, Any] | None = None
    color: FieldRef[Any, Any] | None = None
    data: Dataset[Any] | None = None
    on_click: Interaction | None = None
    title: str = ""
    height: int = 420
    renderer: ChartRenderer = "plotly"
    empty_message: str = "No data"

    def extract(self) -> HierarchyData:
        """Walk the hierarchy rows into a HierarchyData snapshot."""
        if not self.levels or self.size is None:
            return HierarchyData()
        if self.data is None:
            msg = "TreeMap: levels and size require `data` to be set"
            raise ChartDataError(msg)
        return build_hierarchy_data(self.data, self.levels, self.size, self.color)


@dataclass(frozen=True)
class Sunburst:
    """ECharts radial sunburst with click-to-zoom over hierarchical levels.

    Shares the same data model as TreeMap: ``levels``, ``size``, and optional
    ``color``. Clicking a wedge with ``on_click=drill_down()`` advances the
    SelectionStore drill stack so sibling components can filter to that path.
    """

    levels: tuple[FieldRef[Any, Any], ...] = ()
    size: FieldRef[Any, Any] | None = None
    color: FieldRef[Any, Any] | None = None
    data: Dataset[Any] | None = None
    on_click: Interaction | None = None
    title: str = ""
    palette: tuple[str, ...] = ()
    height: int = 420
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> HierarchyData:
        """Walk the hierarchy rows into a HierarchyData snapshot."""
        if not self.levels or self.size is None:
            return HierarchyData()
        if self.data is None:
            msg = "Sunburst: levels and size require `data` to be set"
            raise ChartDataError(msg)
        return build_hierarchy_data(self.data, self.levels, self.size, self.color)


@dataclass(frozen=True)
class GeoLayer:
    """GeoJSON feature collection plus the property key that joins to dataset regions.

    ``geojson`` is the parsed FeatureCollection object (``dict``, not a path).
    ``join_key`` names a property on each feature whose value matches the
    dataset's region column, e.g. ``"name"`` or ``"iso_a3"``.
    """

    geojson: dict[str, Any]
    join_key: str = "name"


@dataclass(frozen=True)
class ChoroplethMap:
    """Region-colored map rendered as an ECharts map series.

    ``region`` and ``value`` FieldRefs project region names + metrics out of
    ``data``; values are aggregated per region (default sum). ``layer`` is the
    GeoLayer whose ``geojson`` features get registered with ECharts and whose
    ``join_key`` is used to match dataset regions to features. Regions in the
    dataset that don't match any feature are logged as a warning and rendered
    blank.
    """

    region: FieldRef[Any, Any] | None = None
    value: FieldRef[Any, Any] | None = None
    data: Dataset[Any] | None = None
    layer: GeoLayer | None = None
    aggregate: AggregateOp = "sum"
    on_click: Interaction | None = None
    map_name: str = "choropleth"
    title: str = ""
    height: int = 420
    renderer: ChartRenderer = "echarts"
    empty_message: str = "No data"

    def extract(self) -> ChoroplethMapData:
        """Resolve regions + values via dataset aggregation and geojson join."""
        if self.region is None or self.value is None or self.layer is None:
            return ChoroplethMapData()
        if self.data is None:
            msg = "ChoroplethMap: region and value require `data` to be set"
            raise ChartDataError(msg)
        binding = ChoroplethBinding(
            region=self.region,
            value=self.value,
            aggregate=self.aggregate,
            geojson=self.layer.geojson,
            join_key=self.layer.join_key,
        )
        return build_choropleth_data(self.data, binding)


@dataclass(frozen=True)
class Surface3D:
    """3D surface plot over a grid of (x, y, z) values, rendered by Plotly.

    Mirrors ``Heatmap``: either pass explicit ``x_labels``, ``y_labels``, and
    a ``z`` matrix, or pass ``x``, ``y``, and ``z`` FieldRefs with ``data``
    to aggregate the z column per (x, y) cell.
    """

    x: FieldRef[Any, Any] | None = None
    y: FieldRef[Any, Any] | None = None
    z: FieldRef[Any, Any] | tuple[tuple[float, ...], ...] = ()
    data: Dataset[Any] | None = None
    aggregate: AggregateOp = "sum"
    on_click: Interaction | None = None
    x_labels: tuple[str, ...] = ()
    y_labels: tuple[str, ...] = ()
    title: str = ""
    colorscale: str = "Viridis"
    height: int = 420
    renderer: ChartRenderer = "plotly"
    empty_message: str = "No data"

    def extract(self) -> HeatmapData:
        """Resolve surface data from either explicit labels/matrix or FieldRefs."""
        if self.x is None and self.y is None and not isinstance(self.z, FieldRef):
            return HeatmapData(x_labels=self.x_labels, y_labels=self.y_labels, z=self.z)
        if not (
            isinstance(self.x, FieldRef)
            and isinstance(self.y, FieldRef)
            and isinstance(self.z, FieldRef)
        ):
            msg = (
                "Surface3D: x, y, and z must all be FieldRefs when not using explicit labels + z matrix"
            )
            raise ChartDataError(msg)
        if self.data is None:
            msg = "Surface3D: FieldRef axes require `data` to be set"
            raise ChartDataError(msg)
        return build_heatmap_data(self.data, self.x, self.y, self.z, self.aggregate)
