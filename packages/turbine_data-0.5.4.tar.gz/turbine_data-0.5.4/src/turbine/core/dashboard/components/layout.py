from __future__ import annotations

from dataclasses import dataclass
from functools import cached_property
from typing import Any, Self, cast

from pydantic import BaseModel, ConfigDict, computed_field, model_validator

from turbine.core.dashboard.components.charts import (
    BarChart,
    BubbleChart,
    CalendarHeatmap,
    ChoroplethMap,
    EventTimeline,
    GanttTimeline,
    Gauge,
    Heatmap,
    NetworkGraph,
    Parallel,
    Sankey,
    ScatterPlot,
    Surface3D,
    Tree,
    TrendChart,
)
from turbine.core.dashboard.components.data import (
    DefinitionList,
    Drawer,
    FlagPanel,
    Picker,
    RowViewer,
    Table,
)
from turbine.core.dashboard.components.display import Alert
from turbine.core.dashboard.dataset import Dataset
from turbine.core.dashboard.field_ref import FieldRef
from turbine.core.dashboard.health import HealthRule, normalize_healthy


class KPI(BaseModel):
    """Metric card displaying a label, value, optional delta, and optional sparkline trend."""

    model_config = ConfigDict(frozen=True, arbitrary_types_allowed=True)

    label: str
    value: int | float | str | None
    fmt: str = ""
    delta: int | float | str | None = None
    delta_fmt: str = ""
    trend: FieldRef[Any, Any] | tuple[float, ...] = ()
    trend_data: Dataset[Any] | None = None
    empty_message: str = "No data"
    healthy: Any = None

    @computed_field
    @cached_property
    def healthy_rule(self) -> HealthRule | None:
        return normalize_healthy(self.healthy, self.value, "KPI")

    @model_validator(mode="after")
    def force_healthy_rule(self) -> Self:
        _ = self.healthy_rule
        return self

    def extract_trend(self) -> tuple[float, ...]:
        """Resolve the sparkline series from explicit values or a FieldRef + dataset."""
        if isinstance(self.trend, FieldRef):
            if self.trend_data is None:
                return ()
            return tuple(float(value) for value in self.trend_data.col(self.trend))
        return tuple(float(value) for value in self.trend)


@dataclass(frozen=True)
class Header:
    """Section heading with a configurable level."""

    text: str
    level: int = 5


@dataclass(frozen=True)
class Divider:
    """Visual separator between sections."""


@dataclass(frozen=True)
class Row:
    """Horizontal layout container for child components."""

    children: tuple[Component, ...]


@dataclass(frozen=True, init=False)
class Page:
    """Top-level page container with positional children and an optional title."""

    title: str | None
    children: tuple[Component, ...]

    def __init__(self, *children: Component, title: str | None = None) -> None:
        object.__setattr__(self, "title", title)
        object.__setattr__(self, "children", children)


@dataclass(frozen=True, init=False)
class Section:
    """Titled block with optional subtitle and child components."""

    title: str
    children: tuple[Component, ...]
    subtitle: str | None

    def __init__(self, title: str, *children: Component, subtitle: str | None = None) -> None:
        object.__setattr__(self, "title", title)
        object.__setattr__(self, "children", children)
        object.__setattr__(self, "subtitle", subtitle)


@dataclass(frozen=True, init=False)
class Strip[T]:
    """Horizontal strip that collapses to a single empty card when all children are empty."""

    children: tuple[T, ...]
    empty_message: str

    def __init__(self, *children: T, empty_message: str = "No data") -> None:
        object.__setattr__(self, "children", children)
        object.__setattr__(self, "empty_message", empty_message)


class KpiStrip(Strip[KPI]):
    """Horizontal strip of KPIs."""


class GaugeStrip(Strip[Gauge]):
    """Horizontal strip of Gauges."""


@dataclass(frozen=True)
class TabItem:
    """Single tab with a label and child components."""

    label: str
    children: tuple[Component, ...]


@dataclass(frozen=True, init=False)
class Tabs:
    """Tabbed container with selectable child panels.

    Two construction forms:
      Positional:  Tabs(TabItem("A", children=(...)), TabItem("B", children=(...)))
      Kwargs:      Tabs(A=component_a, B=(comp_b1, comp_b2))
    Mixing both raises ValueError.
    """

    items: tuple[TabItem, ...]

    def __init__(self, *items: TabItem, **named_children: Component | tuple[Component, ...]) -> None:
        if items and named_children:
            msg = "Tabs: positional TabItems and keyword children are mutually exclusive"
            raise ValueError(msg)
        if named_children:
            tab_items = tuple(
                TabItem(label=label, children=wrap_children(child))
                for label, child in named_children.items()
            )
            object.__setattr__(self, "items", tab_items)
        else:
            object.__setattr__(self, "items", items)


def wrap_children(child: Component | tuple[Component, ...]) -> tuple[Component, ...]:
    """Normalize a Tabs kwarg into a tuple of components."""
    if isinstance(child, tuple):
        return cast("tuple[Component, ...]", child)
    return (child,)


type Component = (
    Page
    | Section
    | Row
    | KPI
    | KpiStrip
    | GaugeStrip
    | Header
    | Divider
    | Gauge
    | TrendChart
    | BarChart
    | Heatmap
    | ScatterPlot
    | BubbleChart
    | Parallel
    | EventTimeline
    | GanttTimeline
    | CalendarHeatmap
    | Sankey
    | Tree
    | NetworkGraph
    | ChoroplethMap
    | Surface3D
    | Table
    | RowViewer
    | Picker
    | Tabs
    | TabItem
    | Alert
    | Drawer
    | DefinitionList
    | FlagPanel
)
