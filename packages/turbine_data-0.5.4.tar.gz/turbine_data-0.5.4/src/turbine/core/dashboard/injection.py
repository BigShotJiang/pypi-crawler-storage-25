from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any, overload

from pydantic import BaseModel

from turbine.core.dashboard.components.data import Picker
from turbine.core.dashboard.dataset import Dataset
from turbine.core.dashboard.field_ref import FieldRef
from turbine.core.dashboard.query import Resource


class DependsMarker:
    """Internal sentinel created by Depends(). Users interact with the Depends function."""

    def __init__(
        self, dependency: type[Any] | Any, picker: Picker | tuple[Picker, ...] | None = None
    ) -> None:
        self.dependency = dependency
        self.picker = picker


@overload
def Depends[M: BaseModel](
    dependency: type[M], *, picker: Picker | tuple[Picker, ...] | None = None
) -> Dataset[M]: ...


@overload
def Depends(dependency: Resource[Any], *, picker: Picker | tuple[Picker, ...] | None = None) -> Any: ...


@overload
def Depends(
    dependency: Param | Selection | State, *, picker: Picker | tuple[Picker, ...] | None = None
) -> Any: ...


@overload
def Depends[T](dependency: type[T], *, picker: Picker | tuple[Picker, ...] | None = None) -> T: ...


@overload
def Depends[T](dependency: T, *, picker: Picker | tuple[Picker, ...] | None = None) -> T: ...


def Depends(dependency: Any, *, picker: Picker | tuple[Picker, ...] | None = None) -> Any:  # noqa: N802
    """Mark a parameter for dependency injection.

    Accepts a type (e.g. Query, Order) or an instance, with an optional
    ``picker=`` that binds a Picker (or tuple of Pickers) to the dataset.
    Returns a sentinel at runtime; the type checker sees a ``Resource``
    instance as ``Any`` (so the parameter's own annotation wins, whether
    that's ``list[T]`` or the auto-wrapped ``Dataset[T]``), a
    ``BaseModel`` subclass as ``Dataset[M]``, and other inputs as themselves.
    """
    return DependsMarker(dependency, picker=picker)


class DependencyRegistry:
    """Register and resolve dependencies for @page functions.

    Resolution precedence for ``resolve(dep_type)``:

    1. ``factories[dep_type]`` -- explicit registrations (register / register_value)
    2. ``fallback_factory``    -- catch-all for typed models (register_dataset_factory)

    DI markers (Param, Selection, State, Resource) bypass ``resolve()`` entirely.
    The page resolver classifies them from the function signature and dispatches
    to their own readers (param_reader, state_reader) or runs Resource instances
    through the injected executor. Pickers are resolved via ``picker_resolver``
    during dataset binding.
    """

    def __init__(self) -> None:
        self.factories: dict[type[Any], Callable[[], Any]] = {}
        self.fallback_factory: Callable[[type[Any]], Any] | None = None
        self.picker_resolver: Callable[[Picker], Any] | None = None
        self.param_reader: Callable[[str], str | None] | None = None
        self.state_reader: Callable[[str, str], Any] | None = None
        self.page_key: str = ""

    def register(self, dep_type: type[Any], factory: Callable[[], Any]) -> None:
        """Register a lazy factory for a dependency type."""
        self.factories[dep_type] = factory

    def register_value(self, dep_type: type[Any], value: Any) -> None:
        """Register an eager concrete value for a dependency type."""
        self.factories[dep_type] = lambda: value

    def register_dataset_factory(self, factory: Callable[[type[Any]], Any]) -> None:
        """Register a fallback factory for unregistered model types (Dataset[M])."""
        self.fallback_factory = factory

    def register_picker_resolver(self, resolver: Callable[[Picker], Any]) -> None:
        """Register a resolver for Picker dependencies."""
        self.picker_resolver = resolver

    def register_param_reader(self, reader: Callable[[str], str | None]) -> None:
        """Register a callback that reads a URL query param by name."""
        self.param_reader = reader

    def register_state_reader(self, reader: Callable[[str, str], Any]) -> None:
        """Register a callback that reads page-scoped state by (page_key, key)."""
        self.state_reader = reader

    def resolve(self, dep_type: type[Any]) -> Any:
        """Resolve a dependency. Explicit registrations win over dataset fallback."""
        if dep_type in self.factories:
            return self.factories[dep_type]()
        if self.fallback_factory is not None:
            return self.fallback_factory(dep_type)
        msg = f"No dependency registered for {dep_type.__name__}"
        raise KeyError(msg)


@dataclass(frozen=True)
class Param:
    """URL query param marker. Resolved by reading ``st.query_params``.

    ``name`` defaults to the parameter name in the function signature.
    ``target_type`` is called on the raw string to coerce (e.g. ``int``).
    """

    name: str | None = None
    target_type: type = field(default=str)
    default: Any = None


@dataclass(frozen=True)
class Selection:
    """Returns the current selection value for a column, or None when unset."""

    field: FieldRef[Any, Any]


@dataclass(frozen=True)
class State:
    """Arbitrary per-page session state. Reads ``session_state[page_key][key]``."""

    key: str
    default: Any = None
