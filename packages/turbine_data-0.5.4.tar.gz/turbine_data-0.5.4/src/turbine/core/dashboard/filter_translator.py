"""Translate SQL-style column expressions into Python row predicates.

The dashboard never executes SQL. When a page author writes
`data.where(Order.amount > 1000, Order.status == "paid")`, SQLAlchemy
builds a `BinaryExpression` tree. This module walks that tree
structurally (no sqlalchemy import) and returns a `Callable[[row], bool]`
that evaluates the same logic against in-memory row objects.

Operators are identified by `.operator.__name__`, which is stable across
Python's `operator` module (`eq`, `ne`, `gt`, `ge`, `lt`, `le`, `and_`,
`or_`) and `sqlalchemy.sql.operators` (`in_op`, `not_in_op`, `between_op`,
`startswith_op`, `contains_op`).
"""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from turbine.core.dashboard.dashboard_model import BoolExpr, ColumnExpr

Predicate = Callable[[Any], bool]


class FilterTranslationError(ValueError):
    """Raised when an expression can't be translated to a Python predicate."""


COMPARISON_OPS: dict[str, Callable[[Any, Any], bool]] = {
    "eq": lambda left, right: left == right,
    "ne": lambda left, right: left != right,
    "gt": lambda left, right: left > right,
    "ge": lambda left, right: left >= right,
    "lt": lambda left, right: left < right,
    "le": lambda left, right: left <= right,
}


def translate_to_predicate(expression: Any) -> Predicate:
    """Translate a SQL-style expression into a Python row predicate."""
    if isinstance(expression, ColumnExpr):
        return translate_column_expr(expression)
    if isinstance(expression, BoolExpr):
        return translate_bool_expr(expression)
    operator_name = getattr(getattr(expression, "operator", None), "__name__", "")
    if operator_name in ("and_", "or_") and hasattr(expression, "clauses"):
        return translate_boolean(expression)
    if hasattr(expression, "left") and hasattr(expression, "right"):
        return translate_binary(expression)
    msg = f"Unsupported filter expression: {type(expression).__name__}"
    raise FilterTranslationError(msg)


def translate_column_expr(expression: ColumnExpr) -> Predicate:
    """Translate a ColumnExpr (DashboardModel-native) into a row predicate."""
    compare = COMPARISON_OPS[expression.op]
    column = expression.column
    literal = expression.value
    return lambda row: compare(getattr(row, column), literal)


def translate_bool_expr(expression: BoolExpr) -> Predicate:
    """Translate a BoolExpr (and/or composite) into a composed predicate."""
    children = tuple(translate_to_predicate(clause) for clause in expression.clauses)
    if expression.op == "and":
        return lambda row: all(predicate(row) for predicate in children)
    return lambda row: any(predicate(row) for predicate in children)


def translate_boolean(expression: Any) -> Predicate:
    """Translate a BooleanClauseList (and_/or_) into a composed predicate."""
    children = tuple(translate_to_predicate(clause) for clause in expression.clauses)
    operator_name = expression.operator.__name__
    match operator_name:
        case "and_":
            return lambda row: all(predicate(row) for predicate in children)
        case "or_":
            return lambda row: any(predicate(row) for predicate in children)
        case _:
            msg = f"Unsupported boolean operator: {operator_name}"
            raise FilterTranslationError(msg)


def translate_binary(expression: Any) -> Predicate:
    """Translate a BinaryExpression into a row predicate."""
    column_key = expression.left.key
    operator_name = expression.operator.__name__
    match operator_name:
        case "eq" | "ne" | "gt" | "ge" | "lt" | "le":
            compare = COMPARISON_OPS[operator_name]
            literal = expression.right.value
            return lambda row: compare(getattr(row, column_key), literal)
        case "in_op":
            members = tuple(expression.right.value)
            return lambda row: getattr(row, column_key) in members
        case "not_in_op":
            members = tuple(expression.right.value)
            return lambda row: getattr(row, column_key) not in members
        case "between_op":
            low = expression.right.clauses[0].value
            high = expression.right.clauses[1].value
            return lambda row: low <= getattr(row, column_key) <= high
        case "startswith_op":
            prefix = expression.right.value
            return lambda row: str(getattr(row, column_key)).startswith(prefix)
        case "contains_op":
            substring = expression.right.value
            return lambda row: substring in str(getattr(row, column_key))
        case _:
            msg = f"Unsupported operator: {operator_name}"
            raise FilterTranslationError(msg)
