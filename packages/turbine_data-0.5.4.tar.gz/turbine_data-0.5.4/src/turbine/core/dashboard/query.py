from __future__ import annotations

from dataclasses import dataclass, replace
from enum import StrEnum
from typing import Protocol

from pydantic import BaseModel, ConfigDict, Field

from turbine.core.common.quality_dimension import QualityDimension
from turbine.core.dashboard.dashboard_model import DashboardModel
from turbine.core.dashboard.models import TimeRange
from turbine.core.quality import CheckCounters as CheckCountersData
from turbine.core.quality.check_results import DimensionScore


class ThresholdType(StrEnum):
    """Tag for ThresholdData variants. Mirrors server ThresholdResponse.type."""

    EXACT = "exact"
    COMPARISON = "comparison"
    RANGE = "range"


class ThresholdData(BaseModel):
    """Serialized threshold carried on a check registry entry.

    Flat, 1:1 with the server's ThresholdResponse. Fields unused by a given
    variant stay None (e.g. COMPARISON fills operator+value, leaves negate).
    """

    model_config = ConfigDict(frozen=True)

    type: ThresholdType
    operator: str | None = None
    value: float | None = None
    negate: bool | None = None


@dataclass(frozen=True)
class ChainSpec:
    """Immutable state captured by a QueryChain."""

    since: TimeRange | None = None

    def to_query_params(self) -> dict[str, str]:
        """Serialize this spec to the query-string params an HTTP backend expects."""
        if self.since is None:
            return {}
        start, end = self.since.bounds()
        return {"since": start.isoformat(), "until": end.isoformat()}


@dataclass(frozen=True)
class Resource[T]:
    """Marker for queryable resources. The dispatcher knows how to execute each subtype.

    Resources are pure declarative data. Execute one with ``query(resource).fetch()``.
    """


@dataclass(frozen=True)
class DimensionScores(Resource[list[DimensionScore]]):
    """Fetch dimension scores from the /scores endpoint."""


@dataclass(frozen=True)
class CheckCounters(Resource[CheckCountersData]):
    """Fetch aggregate check counters from /checks/counters."""


@dataclass(frozen=True)
class FlaggedTables(Resource[list[str]]):
    """Fetch table names that have quality views from /flagged-rows/tables."""


class CheckRegistryEntryData(DashboardModel):
    """A single check definition from the registry."""

    check_id: str
    name: str
    dimension: QualityDimension
    check_type: str
    threshold: ThresholdData | None = None


class VerificationRunSummary(DashboardModel):
    """Single verification run summary."""

    run_id: str
    timestamp: str
    pass_rate: float
    total_checks: int
    failed_checks: int
    duration_ms: int


@dataclass(frozen=True)
class VerificationRuns(Resource[list[VerificationRunSummary]]):
    """Fetch verification run history."""


class ContractSummaryData(DashboardModel):
    """Summary of a single contract with quality scores and embedded checks."""

    contract_id: str
    name: str
    table: str
    check_count: int
    overall_score: float
    passed_checks: int
    last_run_at: str | None
    checks: list[CheckRegistryEntryData] = Field(default_factory=list)


@dataclass(frozen=True)
class ContractList(Resource[list[ContractSummaryData]]):
    """Fetch all contracts with their quality summaries."""


class AlertSeverity(StrEnum):
    """Alert severity based on consecutive failure count."""

    INFO = "info"
    WARNING = "warning"
    CRITICAL = "critical"


class AlertEntry(DashboardModel):
    """A check with consecutive failures triggering an alert."""

    check_name: str
    table: str
    dimension: QualityDimension
    consecutive_failures: int
    severity: AlertSeverity
    last_failure_at: str | None


@dataclass(frozen=True)
class AlertList(Resource[list[AlertEntry]]):
    """Fetch active alerts based on consecutive failure detection."""


class QueryDispatcher(Protocol):
    """Port for executing resource queries against a backend."""

    def execute[R](self, resource: Resource[R], spec: ChainSpec) -> R: ...


@dataclass(frozen=True)
class QueryChain[T]:
    """Immutable query builder. ``.since()`` returns a new chain."""

    resource: Resource[T]
    spec: ChainSpec
    dispatcher: QueryDispatcher

    def since(self, time_range: TimeRange) -> QueryChain[T]:
        return QueryChain(
            resource=self.resource, spec=replace(self.spec, since=time_range), dispatcher=self.dispatcher
        )

    def fetch(self) -> T:
        return self.dispatcher.execute(self.resource, self.spec)


class Query:
    """Callable wrapper around a QueryDispatcher. Injected via Depends(Query)."""

    def __init__(self, dispatcher: QueryDispatcher) -> None:
        self.dispatcher = dispatcher

    def __call__[T](self, resource: Resource[T]) -> QueryChain[T]:
        return QueryChain(resource=resource, spec=ChainSpec(), dispatcher=self.dispatcher)
