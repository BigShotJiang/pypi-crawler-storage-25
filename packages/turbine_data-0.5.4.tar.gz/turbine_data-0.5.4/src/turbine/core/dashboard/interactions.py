"""Interaction types for the dashboard DSL.

Each factory returns a frozen dataclass describing the *intent* of a click
handler. The presentation renderer inspects the dataclass at render time and
wires the appropriate Streamlit callback (st.switch_page, query_params
update, session-state mutation, or a side-effect function call).
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

from turbine.core.dashboard.field_ref import FieldRef


@dataclass(frozen=True)
class NavigateTo:
    """Switch to another page, passing URL params extracted from the clicked row."""

    target: Callable[..., Any] | type
    param_map: dict[str, FieldRef[Any, Any]]


@dataclass(frozen=True)
class OpenDrawer:
    """Open a URL-state drawer with params extracted from the clicked row."""

    param_map: dict[str, FieldRef[Any, Any]]


@dataclass(frozen=True)
class ScopeTo:
    """Set a page-level selection on a column so sibling components auto-filter."""

    field: FieldRef[Any, Any]


@dataclass(frozen=True)
class RunAction:
    """Execute a side-effect function with params extracted from the clicked row."""

    action: Callable[..., Any]
    param_map: dict[str, FieldRef[Any, Any]]


@dataclass(frozen=True)
class DrillDown:
    """Advance a hierarchical chart to the next level on click.

    The renderer infers ``(field, value)`` from the chart's ``levels`` tuple
    and the clicked cell, then pushes that pair onto the page-scoped
    SelectionStore drill stack. Charts like TreeMap/Sunburst read the stack
    to decide which level to display on the next render.
    """


type Interaction = NavigateTo | OpenDrawer | ScopeTo | RunAction | DrillDown


def navigate_to(target: Callable[..., Any] | type, **param_map: FieldRef[Any, Any]) -> NavigateTo:
    """Build a NavigateTo intent for cross-page navigation."""
    return NavigateTo(target=target, param_map=dict(param_map))


def open_drawer(**param_map: FieldRef[Any, Any]) -> OpenDrawer:
    """Build an OpenDrawer intent for bookmarkable drawers."""
    return OpenDrawer(param_map=dict(param_map))


def scope_to(column: FieldRef[Any, Any]) -> ScopeTo:
    """Build a ScopeTo intent for linked chart-to-table filtering."""
    return ScopeTo(field=column)


def run_action(action: Callable[..., Any], **param_map: FieldRef[Any, Any]) -> RunAction:
    """Build a RunAction intent for side-effect buttons."""
    return RunAction(action=action, param_map=dict(param_map))


def drill_down() -> DrillDown:
    """Build a DrillDown intent for hierarchical charts."""
    return DrillDown()
