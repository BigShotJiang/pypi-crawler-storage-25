"""TableView — dynamic table data resolved at runtime.

Used when the table schema is not known at page-definition time
(e.g. the built-in flagged-rows page). Rows are plain dicts.
Implements the Dataset Protocol so RowViewer accepts it unchanged.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any

from turbine.core.dashboard.dataset import RowFlags
from turbine.core.dashboard.in_memory_dataset import InMemoryDataset


class TableView(InMemoryDataset[dict[str, Any]]):
    """Dataset backed by dict rows with a ``table_name`` label.

    Inherits all Dataset operations from InMemoryDataset. Adds
    ``table_name`` (which table was selected) and ``column_names``
    (discovered from the first row's keys).
    """

    def __init__(
        self, table_name: str, rows: Sequence[dict[str, Any]], flags: Sequence[RowFlags] | None = None
    ) -> None:
        super().__init__(rows=rows, flags=flags)
        self.table_name = table_name

    @property
    def column_names(self) -> tuple[str, ...]:
        if not self.stored_rows:
            return ()
        return tuple(self.stored_rows[0].keys())
