from __future__ import annotations

from collections.abc import Callable, Iterator, Sequence
from dataclasses import dataclass
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict

from turbine.core.dashboard.field_ref import FieldRef


@dataclass(frozen=True)
class HistogramBin:
    """Single histogram bin with edges and count."""

    low: float
    high: float
    count: int


class RowFlags(BaseModel):
    """Per-row quality check results from the flagging view."""

    model_config = ConfigDict(frozen=True)

    failed_checks: tuple[str, ...] = ()
    last_checked_at: str | None = None
    run_id: str | None = None

    @classmethod
    def from_raw_row(cls, raw: dict[str, Any]) -> RowFlags:
        """Build from an API row dict by extracting quality-view flag columns."""
        return cls(
            failed_checks=failed_checks_from_aggregate(raw.get("failing_checks")),
            last_checked_at=optional_string(raw.get("last_tested_at")),
        )


def failed_checks_from_aggregate(value: object) -> tuple[str, ...]:
    """Parse the comma-separated failing_checks value emitted by quality views."""
    if not isinstance(value, str):
        return ()
    if not value:
        return ()
    return tuple(check for check in (item.strip() for item in value.split(",")) if check)


def optional_string(value: object) -> str | None:
    """Convert optional metadata values from API JSON/DB rows to strings."""
    if value is None:
        return None
    return str(value)


@dataclass(frozen=True)
class FlaggedRow[M]:
    """A model row paired with its quality check flags."""

    data: M
    flags: RowFlags


@runtime_checkable
class Dataset[M](Protocol):
    """Lazy, read-only typed dataset. Rows are fetched on first access."""

    @property
    def model(self) -> type[M] | None: ...

    @property
    def picker_value(self) -> dict[str, str]: ...

    @property
    def records(self) -> Sequence[M]: ...

    @property
    def flagged_count(self) -> int: ...

    @property
    def total_count(self) -> int: ...

    @property
    def has_flags(self) -> bool: ...

    @property
    def flags(self) -> Sequence[RowFlags]: ...

    @property
    def flagged_rows(self) -> Sequence[FlaggedRow[M]]: ...

    def sum(self, field: FieldRef[M, Any]) -> float: ...

    def mean(self, field: FieldRef[M, Any]) -> float: ...

    def min(self, field: FieldRef[M, Any]) -> float: ...

    def max(self, field: FieldRef[M, Any]) -> float: ...

    def count(self) -> int: ...

    def distinct(self, field: FieldRef[M, Any]) -> tuple[Any, ...]: ...

    def where(self, *filters: Any, **kwargs: Any) -> Dataset[M]: ...

    def filter(self, predicate: Callable[[M], bool]) -> Dataset[M]: ...

    def order_by(self, field: FieldRef[M, Any], *, descending: bool = False) -> Dataset[M]: ...

    def limit(self, n: int) -> Dataset[M]: ...

    def group_by(self, field: FieldRef[M, Any]) -> Grouped[M]: ...

    def col(self, field: FieldRef[M, Any]) -> tuple[Any, ...]: ...

    def rows(
        self, cols: tuple[FieldRef[M, Any], ...], limit: int | None = None
    ) -> tuple[dict[str, Any], ...]: ...

    def histogram(
        self, col: FieldRef[M, Any], bins: int | tuple[float, ...] = 20
    ) -> tuple[HistogramBin, ...]: ...

    def with_picker_value(self, picker_value: dict[str, str]) -> Dataset[M]: ...

    @property
    def all(self) -> Dataset[M]: ...

    @property
    def pass_rate(self) -> float: ...


@dataclass(frozen=True)
class Grouped[M]:
    """Result of Dataset.group_by(). Groups keyed by distinct field values."""

    groups: dict[Any, Dataset[M]]

    def sum(self, field: FieldRef[M, Any]) -> dict[Any, float]:
        return {key: dataset.sum(field) for key, dataset in self.groups.items()}

    def mean(self, field: FieldRef[M, Any]) -> dict[Any, float]:
        return {key: dataset.mean(field) for key, dataset in self.groups.items()}

    def max(self, field: FieldRef[M, Any]) -> dict[Any, float]:
        return {key: dataset.max(field) for key, dataset in self.groups.items()}

    def min(self, field: FieldRef[M, Any]) -> dict[Any, float]:
        return {key: dataset.min(field) for key, dataset in self.groups.items()}

    def count(self) -> dict[Any, int]:
        return {key: dataset.count() for key, dataset in self.groups.items()}

    def __iter__(self) -> Iterator[tuple[Any, Dataset[M]]]:
        return iter(self.groups.items())

    def __len__(self) -> int:
        return len(self.groups)
