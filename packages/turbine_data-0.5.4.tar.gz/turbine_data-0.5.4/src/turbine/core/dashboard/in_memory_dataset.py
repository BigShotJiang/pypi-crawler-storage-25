"""In-memory Dataset implementation. Pure Python, no infrastructure deps.

Used by ApiDataset for derived views (order_by, limit, group_by) and
by demo/test code as a lightweight Dataset implementation.
"""

from __future__ import annotations

import builtins
from collections.abc import Callable, Sequence
from functools import cached_property
from typing import Any

from turbine.core.dashboard.dataset import Dataset, FlaggedRow, Grouped, HistogramBin, RowFlags
from turbine.core.dashboard.field_ref import FieldRef
from turbine.core.dashboard.filter_translator import translate_to_predicate


class InMemoryDataset[M](Dataset[M]):
    """Dataset backed by pre-fetched in-memory rows. No HTTP.

    Returned by ApiDataset methods like order_by(), limit(), group_by()
    to maintain immutability without re-fetching. Filtered views retain
    a reference to the unfiltered `base` so `.all` always returns the
    underlying dataset regardless of how many `.where()` calls chain.
    """

    def __init__(
        self,
        rows: Sequence[M],
        flags: Sequence[RowFlags] | None = None,
        base: InMemoryDataset[M] | None = None,
        picker_value: dict[str, str] | None = None,
    ) -> None:
        self.stored_rows = tuple(rows)
        self.stored_flags = tuple(flags) if flags is not None else tuple(RowFlags() for _ in rows)
        self.base_dataset = base
        self.stored_picker_value: dict[str, str] = picker_value if picker_value is not None else {}

    @property
    def model(self) -> type[M] | None:
        if not self.stored_rows:
            return None
        return type(self.stored_rows[0])

    @property
    def picker_value(self) -> dict[str, str]:
        return self.stored_picker_value

    def with_picker_value(self, picker_value: dict[str, str]) -> InMemoryDataset[M]:
        """Return a copy carrying ``picker_value``; preserves rows, flags, base."""
        return InMemoryDataset(
            self.stored_rows, self.stored_flags, base=self.base_dataset, picker_value=picker_value
        )

    @property
    def records(self) -> Sequence[M]:
        return self.stored_rows

    @property
    def flags(self) -> Sequence[RowFlags]:
        return self.stored_flags

    @cached_property
    def flagged_rows(self) -> Sequence[FlaggedRow[M]]:
        return tuple(
            FlaggedRow(data=row, flags=flag)
            for row, flag in zip(self.stored_rows, self.stored_flags, strict=True)
        )

    @property
    def total_count(self) -> int:
        return len(self.stored_rows)

    @property
    def flagged_count(self) -> int:
        return builtins.sum(1 for flag in self.stored_flags if flag.failed_checks)

    @property
    def has_flags(self) -> bool:
        return self.flagged_count > 0

    def field_values(self, field: FieldRef[M, Any]) -> tuple[Any, ...]:
        """Extract a column of values from stored rows."""
        return tuple(getattr(row, field.key) for row in self.stored_rows)

    def sum(self, field: FieldRef[M, Any]) -> float:
        values = self.field_values(field)
        return float(builtins.sum(values)) if values else 0.0

    def mean(self, field: FieldRef[M, Any]) -> float:
        values = self.field_values(field)
        return float(builtins.sum(values)) / len(values) if values else 0.0

    def min(self, field: FieldRef[M, Any]) -> float:
        values = self.field_values(field)
        return float(builtins.min(values)) if values else 0.0

    def max(self, field: FieldRef[M, Any]) -> float:
        values = self.field_values(field)
        return float(builtins.max(values)) if values else 0.0

    def count(self) -> int:
        return len(self.stored_rows)

    def distinct(self, field: FieldRef[M, Any]) -> tuple[Any, ...]:
        return tuple(dict.fromkeys(getattr(row, field.key) for row in self.stored_rows))

    def where(self, *filters: Any, **kwargs: Any) -> InMemoryDataset[M]:
        predicates: list[Callable[[M], bool]] = [translate_to_predicate(expr) for expr in filters]
        for field_name, value in kwargs.items():
            predicates.append(lambda row, name=field_name, val=value: getattr(row, name) == val)
        if not predicates:
            return self
        return self.build_filtered(lambda row: all(pred(row) for pred in predicates))

    def filter(self, predicate: Callable[[M], bool]) -> InMemoryDataset[M]:
        return self.build_filtered(predicate)

    def build_filtered(self, predicate: Callable[[M], bool]) -> InMemoryDataset[M]:
        pairs = [
            (row, flag)
            for row, flag in zip(self.stored_rows, self.stored_flags, strict=True)
            if predicate(row)
        ]
        filtered_rows = [row for row, _ in pairs]
        filtered_flags = [flag for _, flag in pairs]
        return InMemoryDataset(
            filtered_rows, filtered_flags, base=self.all, picker_value=self.picker_value
        )

    def order_by(self, field: FieldRef[M, Any], *, descending: bool = False) -> InMemoryDataset[M]:
        indices = sorted(
            range(len(self.stored_rows)),
            key=lambda idx: getattr(self.stored_rows[idx], field.key),
            reverse=descending,
        )
        sorted_rows = [self.stored_rows[idx] for idx in indices]
        sorted_flags = [self.stored_flags[idx] for idx in indices]
        return InMemoryDataset(sorted_rows, sorted_flags, base=self.all, picker_value=self.picker_value)

    def limit(self, n: int) -> InMemoryDataset[M]:
        return InMemoryDataset(
            list(self.stored_rows[:n]),
            list(self.stored_flags[:n]),
            base=self.all,
            picker_value=self.picker_value,
        )

    def group_by(self, field: FieldRef[M, Any]) -> Grouped[M]:
        buckets: dict[Any, tuple[list[M], list[RowFlags]]] = {}
        for row, flag in zip(self.stored_rows, self.stored_flags, strict=True):
            key = getattr(row, field.key)
            bucket = buckets.setdefault(key, ([], []))
            bucket[0].append(row)
            bucket[1].append(flag)
        groups: dict[Any, Dataset[M]] = {
            key: InMemoryDataset(rows, flags) for key, (rows, flags) in buckets.items()
        }
        return Grouped(groups=groups)

    def col(self, field: FieldRef[M, Any]) -> tuple[Any, ...]:
        return tuple(getattr(row, field.key) for row in self.stored_rows)

    def rows(
        self, cols: tuple[FieldRef[M, Any], ...], limit: int | None = None
    ) -> tuple[dict[str, Any], ...]:
        """Project selected columns into row dicts, optionally limited."""
        source = self.stored_rows[:limit] if limit is not None else self.stored_rows
        return tuple({col.key: getattr(row, col.key) for col in cols} for row in source)

    def histogram(
        self, col: FieldRef[M, Any], bins: int | tuple[float, ...] = 20
    ) -> tuple[HistogramBin, ...]:
        """Bin column values into histogram bins."""
        values = [float(val) for val in self.field_values(col)]
        if not values:
            return ()
        lo = builtins.min(values)
        hi = builtins.max(values)
        if lo == hi:
            return (HistogramBin(low=lo, high=hi, count=len(values)),)
        if isinstance(bins, tuple):
            edges = bins
        else:
            width = (hi - lo) / bins
            edges = tuple(lo + idx * width for idx in range(bins + 1))
        result: list[HistogramBin] = []
        for idx in range(len(edges) - 1):
            edge_lo = edges[idx]
            edge_hi = edges[idx + 1]
            is_last = idx == len(edges) - 2
            count = sum(1 for val in values if edge_lo <= val < edge_hi or (is_last and val == edge_hi))
            result.append(HistogramBin(low=edge_lo, high=edge_hi, count=count))
        return tuple(result)

    @property
    def all(self) -> InMemoryDataset[M]:
        return self.base_dataset if self.base_dataset is not None else self

    @property
    def pass_rate(self) -> float:
        if not self.stored_rows:
            return 1.0
        return 1 - self.flagged_count / self.total_count
