from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime, timedelta
from enum import StrEnum


class TimeRange(StrEnum):
    """Preset time ranges for dashboard filtering."""

    LAST_24H = "24h"
    LAST_7D = "7d"
    LAST_30D = "30d"
    LAST_90D = "90d"

    def bounds(self) -> tuple[datetime, datetime]:
        now = datetime.now(UTC)
        delta = {
            TimeRange.LAST_24H: timedelta(hours=24),
            TimeRange.LAST_7D: timedelta(days=7),
            TimeRange.LAST_30D: timedelta(days=30),
            TimeRange.LAST_90D: timedelta(days=90),
        }[self]
        return (now - delta, now)


class RefreshInterval(StrEnum):
    """Auto-refresh interval options."""

    OFF = "Off"
    THIRTY_SECONDS = "30s"
    ONE_MINUTE = "1m"
    FIVE_MINUTES = "5m"

    def to_timedelta(self) -> timedelta | None:
        """Convert to timedelta, or None if off."""
        mapping: dict[RefreshInterval, timedelta | None] = {
            RefreshInterval.OFF: None,
            RefreshInterval.THIRTY_SECONDS: timedelta(seconds=30),
            RefreshInterval.ONE_MINUTE: timedelta(minutes=1),
            RefreshInterval.FIVE_MINUTES: timedelta(minutes=5),
        }
        return mapping[self]


@dataclass(frozen=True)
class PageMeta:
    """Metadata stored on @page-decorated functions."""

    title: str
    icon: str
    order: int


def get_page_meta(fn: Callable[..., object]) -> PageMeta:
    """Extract PageMeta from a @page-decorated function, or return a default."""
    return getattr(fn, "page_meta", PageMeta(title="Page", icon="", order=100))


def page[PageFn: Callable[..., object]](
    title: str, icon: str = "", order: int = 100
) -> Callable[[PageFn], PageFn]:
    """Mark a function as a dashboard page with metadata."""

    def decorator(fn: PageFn) -> PageFn:
        fn.page_meta = PageMeta(title=title, icon=icon, order=order)
        return fn

    return decorator
