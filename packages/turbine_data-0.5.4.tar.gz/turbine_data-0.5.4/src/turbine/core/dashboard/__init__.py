"""Dashboard domain: public API.

Everything re-exported here is the stable surface external packages
(presentation, adapters, demo, user code) should import from. Deep-module
imports are reserved for internal wiring inside this package.
"""

from turbine.core.dashboard.components.charts import BarChart, Gauge, GaugeThreshold, Heatmap, TrendChart
from turbine.core.dashboard.components.data import (
    CellValue,
    ColumnConfig,
    ColumnType,
    ColumnWidth,
    DataclassInstance,
    Picker,
    RowData,
    RowInput,
    RowViewer,
    Table,
)
from turbine.core.dashboard.components.display import Alert, SeverityLevel
from turbine.core.dashboard.components.layout import (
    KPI,
    Component,
    Divider,
    Header,
    Page,
    Row,
    TabItem,
    Tabs,
)
from turbine.core.dashboard.dashboard_model import DashboardModel
from turbine.core.dashboard.dataset import Dataset, FlaggedRow, Grouped, RowFlags
from turbine.core.dashboard.ext import USER_COMPONENTS, component
from turbine.core.dashboard.field_ref import FieldRef
from turbine.core.dashboard.health import HealthRule, Op
from turbine.core.dashboard.in_memory_dataset import InMemoryDataset
from turbine.core.dashboard.injection import DependencyRegistry, Depends, Param, Selection, State
from turbine.core.dashboard.interactions import navigate_to, open_drawer, run_action, scope_to
from turbine.core.dashboard.models import PageMeta, RefreshInterval, TimeRange, get_page_meta, page
from turbine.core.dashboard.query import (
    AlertEntry,
    AlertList,
    AlertSeverity,
    ChainSpec,
    CheckCounters,
    CheckRegistryEntryData,
    ContractList,
    ContractSummaryData,
    DimensionScores,
    FlaggedTables,
    Query,
    QueryChain,
    QueryDispatcher,
    Resource,
    ThresholdData,
    ThresholdType,
    VerificationRuns,
    VerificationRunSummary,
)
from turbine.core.dashboard.theme import DARK_THEME, ChartPalette, Theme, ThemeColors

__all__ = [
    "DARK_THEME",
    "KPI",
    "USER_COMPONENTS",
    "Alert",
    "AlertEntry",
    "AlertList",
    "AlertSeverity",
    "BarChart",
    "CellValue",
    "ChainSpec",
    "ChartPalette",
    "CheckCounters",
    "CheckRegistryEntryData",
    "ColumnConfig",
    "ColumnType",
    "ColumnWidth",
    "Component",
    "ContractList",
    "ContractSummaryData",
    "DashboardModel",
    "DataclassInstance",
    "Dataset",
    "DependencyRegistry",
    "Depends",
    "DimensionScores",
    "Divider",
    "FieldRef",
    "FlaggedRow",
    "FlaggedTables",
    "Gauge",
    "GaugeThreshold",
    "Grouped",
    "Header",
    "HealthRule",
    "Heatmap",
    "InMemoryDataset",
    "Op",
    "Page",
    "PageMeta",
    "Param",
    "Picker",
    "Query",
    "QueryChain",
    "QueryDispatcher",
    "RefreshInterval",
    "Resource",
    "Row",
    "RowData",
    "RowFlags",
    "RowInput",
    "RowViewer",
    "Selection",
    "SeverityLevel",
    "State",
    "TabItem",
    "Table",
    "Tabs",
    "Theme",
    "ThemeColors",
    "ThresholdData",
    "ThresholdType",
    "TimeRange",
    "TrendChart",
    "VerificationRunSummary",
    "VerificationRuns",
    "component",
    "get_page_meta",
    "navigate_to",
    "open_drawer",
    "page",
    "run_action",
    "scope_to",
]
