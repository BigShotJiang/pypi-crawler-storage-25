"""Code generation and scaffolding domain types."""

from .model import (
    STANDARD_DIRS,
    CheckKind,
    CIConfig,
    InitConfig,
    LayoutChoice,
    NewCheckConfig,
    NewContractConfig,
    NewDatasourceConfig,
    StagedFile,
    TableSchema,
)
from .naming import singularize, to_class_name, to_table_name
from .plan import CodegenPlan, CodegenStep
from .ports import BatchFormatter, ContentRenderer, ContractSerializer, OrphanSweeper, StagedCodeWriter
from .report import CodegenReport
from .type_system import (
    DATETIME_TYPES,
    JSONSCHEMA_UNMAPPABLE,
    LOGICAL_TO_PYTHON,
    TYPING_TYPES,
    datetime_import_names,
    is_jsonschema_mappable,
    map_type,
    needs_typing_any,
)

__all__ = [
    "DATETIME_TYPES",
    "JSONSCHEMA_UNMAPPABLE",
    "LOGICAL_TO_PYTHON",
    "STANDARD_DIRS",
    "TYPING_TYPES",
    "BatchFormatter",
    "CIConfig",
    "CheckKind",
    "CodegenPlan",
    "CodegenReport",
    "CodegenStep",
    "ContentRenderer",
    "ContractSerializer",
    "InitConfig",
    "LayoutChoice",
    "NewCheckConfig",
    "NewContractConfig",
    "NewDatasourceConfig",
    "OrphanSweeper",
    "StagedCodeWriter",
    "StagedFile",
    "TableSchema",
    "datetime_import_names",
    "is_jsonschema_mappable",
    "map_type",
    "needs_typing_any",
    "singularize",
    "to_class_name",
    "to_table_name",
]
