"""Codegen outcome value object.

A `CodegenReport` is what `CodegenUseCase.execute` returns: a list of
flushed files plus the slow-count advisory the plan carried so callers
(CLI, LSP, programmatic facade) can format banners without re-walking
specs.
"""

from dataclasses import dataclass

from turbine.core.common import SyncResult


@dataclass(frozen=True, slots=True)
class CodegenReport:
    """Outcome of one ``CodegenUseCase.execute`` call."""

    sync_results: tuple[SyncResult, ...] = ()
    slow_count_at_risk: tuple[str, ...] = ()
