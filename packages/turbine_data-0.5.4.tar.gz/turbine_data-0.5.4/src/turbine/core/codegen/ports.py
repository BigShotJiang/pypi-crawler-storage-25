"""Ports for the codegen bounded context.

Protocols that adapters implement to render content, stage files,
format a batch, and sweep orphans.
"""

from collections.abc import Iterable, Sequence
from pathlib import Path
from typing import Protocol, runtime_checkable

from turbine.core.codegen.model import StagedFile
from turbine.core.common import DatasetSpec
from turbine.core.common.file_sync import SyncResult

type StagedFiles = dict[Path, str]


@runtime_checkable
class ContentRenderer[T](Protocol):
    """Render a batch of domain objects into staged files.

    Each renderer absorbs its own per-item-vs-aggregate loop and yields
    :class:`StagedFile` values carrying the output path, the file
    content, and a short human-readable ``identifier`` used in
    duplicate-filename diagnostics.
    """

    def render(self, items: Sequence[T], output_dir: Path) -> Iterable[StagedFile]:
        """Yield every file the renderer wants to stage for *items*."""
        ...


@runtime_checkable
class ContractSerializer(Protocol):
    """Serialize a :class:`DatasetSpec` into an on-wire contract format.

    Injected into :class:`ContractRenderer` so the scaffolding flow can
    stay format-agnostic. ``OdcsWriter`` is the default implementation.
    """

    def render(self, item: DatasetSpec) -> str:
        """Return the serialized contract for *item*."""
        ...


@runtime_checkable
class StagedCodeWriter(Protocol):
    """Stage file content in memory, then flush to disk after batch formatting.

    ``stage`` records a pending write. ``pending`` exposes the staged
    map to the formatter. ``flush`` writes the formatted content to
    disk and reports a :class:`SyncResult` per file. Distinct from
    :class:`turbine.core.common.ports.CodeWriter`, which applies
    text-edit bundles via an async interface.
    """

    def stage(self, path: Path, content: str) -> None:
        """Record a pending write of *content* to *path*."""
        ...

    def pending(self) -> StagedFiles:
        """Return a copy of the staged (path, content) map."""
        ...

    def flush(self, formatted: StagedFiles) -> list[SyncResult]:
        """Write *formatted* content to disk, clearing staged state."""
        ...


@runtime_checkable
class BatchFormatter(Protocol):
    """Format a batch of staged files in one pass."""

    def format_all(self, pending: StagedFiles) -> StagedFiles:
        """Return *pending* with each value reformatted."""
        ...


@runtime_checkable
class OrphanSweeper(Protocol):
    """Delete files in a directory that were not emitted this run."""

    def prune(self, directory: Path, kept: frozenset[str]) -> tuple[Path, ...]:
        """Remove files in *directory* not in *kept*, return removed paths."""
        ...

    def prune_empty_subdirs(self, root: Path) -> tuple[Path, ...]:
        """Remove empty subdirectories under *root*, return removed paths."""
        ...
