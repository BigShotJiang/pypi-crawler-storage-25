"""Value objects for code generation and scaffolding."""

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path
from typing import Self

from turbine.core.common import DataSourceType
from turbine.core.common.parsing import parse_strenum


class LayoutChoice(StrEnum):
    """Project directory layout for ``turbine init``."""

    FLAT = "flat"
    SRC = "src"


class CheckKind(StrEnum):
    """Custom check file type for ``turbine new check``."""

    PYTHON = "python"
    SQL = "sql"

    @property
    def extension(self) -> str:
        """File extension including the leading dot."""
        return ".py" if self == CheckKind.PYTHON else ".sql"

    @property
    def template_name(self) -> str:
        """Jinja template filename for this check kind."""
        return f"check_{self.value}{self.extension}.jinja"

    @classmethod
    def parse(cls, raw: str) -> Self:
        """Parse a check kind string case-insensitively.

        Raises TurbineError with fuzzy suggestions on mismatch.
        """
        return parse_strenum(cls, raw)


@dataclass(frozen=True, slots=True)
class StagedFile:
    """A file staged in memory before formatting and disk write.

    ``identifier`` names the originating domain object (contract id,
    datasource name, ...) and is used by the orchestrator in
    duplicate-filename diagnostics.
    """

    path: Path
    content: str
    identifier: str


STANDARD_DIRS = ("contracts", "datasources", "checks", "quality", "data")


@dataclass(frozen=True, slots=True)
class CIConfig:
    """Configuration for CI pipeline generation (e.g. GitLab CI)."""

    datasource_name: str


@dataclass(frozen=True, slots=True)
class InitConfig:
    """User choices collected by the ``turbine init`` wizard."""

    project_name: str
    layout: LayoutChoice
    db_type: DataSourceType
    ci_config: CIConfig | None = None
    include_dashboard: bool = True


@dataclass(frozen=True, slots=True)
class NewContractConfig:
    """Configuration for ``turbine new contract``."""

    name: str
    from_db: bool = False


@dataclass(frozen=True, slots=True)
class TableSchema:
    """Lightweight schema info for check scaffolding — just table name and column names."""

    qualified_name: str
    columns: tuple[str, ...]

    @property
    def kwarg_name(self) -> str:
        """Derive the Python kwarg name from the last segment of the qualified name."""
        return self.qualified_name.rsplit(".", maxsplit=1)[-1]


@dataclass(frozen=True, slots=True)
class NewCheckConfig:
    """Configuration for ``turbine new check``."""

    name: str
    kind: CheckKind
    multi_table: bool = False
    primary_table: TableSchema | None = None
    extra_tables: tuple[TableSchema, ...] = ()


@dataclass(frozen=True, slots=True)
class NewDatasourceConfig:
    """Configuration for ``turbine new datasource``."""

    name: str
    db_type: DataSourceType
