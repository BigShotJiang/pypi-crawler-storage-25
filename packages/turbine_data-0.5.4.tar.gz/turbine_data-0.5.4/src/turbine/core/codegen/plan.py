"""Plan-shape value objects for a codegen run."""

from dataclasses import dataclass
from pathlib import Path

from .ports import ContentRenderer


@dataclass(frozen=True, slots=True)
class CodegenStep:
    """One output directory and the renderers that fill it.

    Each renderer decides internally whether it fires per-item or
    aggregates the full list — the step only cares about the output
    directory and whether orphans should be swept after flush.
    """

    output_dir: Path
    renderers: tuple[ContentRenderer, ...]
    sweep: bool


@dataclass(frozen=True, slots=True)
class CodegenPlan:
    """Ordered steps driving a single codegen run.

    ``slow_count_at_risk`` is an advisory computed at plan-build time so
    the use case can surface it on its return value instead of every
    caller re-deriving it.
    """

    output_root: Path
    steps: tuple[CodegenStep, ...]
    slow_count_at_risk: tuple[str, ...] = ()
