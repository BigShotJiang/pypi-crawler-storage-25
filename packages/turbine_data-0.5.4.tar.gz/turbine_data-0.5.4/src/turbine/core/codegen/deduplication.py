"""Contract deduplication — pure domain rule for codegen.

When multiple contracts define the same table, keep only the first
occurrence and report the duplicates as warnings.
"""

from turbine.core.building_blocks import Diagnostic, DiagnosticBuilder, DiagnosticId
from turbine.core.common import DatasetSpec, TableIdentifier


def deduplicate_contracts(contracts: list[DatasetSpec]) -> tuple[list[DatasetSpec], list[Diagnostic]]:
    """Remove contracts with duplicate table identifiers, keeping the first occurrence.

    Returns the deduplicated list and any warning diagnostics for skipped duplicates.
    """
    seen: dict[TableIdentifier, DatasetSpec] = {}
    warnings: list[Diagnostic] = []
    for contract in contracts:
        if contract.table not in seen:
            seen[contract.table] = contract
            continue
        first = seen[contract.table]
        warnings.append(
            DiagnosticBuilder.warning(
                DiagnosticId.CODEGEN_DUPLICATE_TABLE,
                f"duplicate table '{contract.table}' in '{contract.metadata.source_path}' "
                f"— already defined in '{first.metadata.source_path}', skipping",
            ).build()
        )
    return list(seen.values()), warnings
