"""LogicalType to Python type mapping for code generation.

Defines the canonical mapping from domain logical types to Python
type strings. All codegen renderers consume this mapping — they
never define their own type rules.
"""

from collections.abc import Iterable

from turbine.core.building_blocks import TurbineError
from turbine.core.common import ColumnDef, LogicalType

LOGICAL_TO_PYTHON: dict[LogicalType, str] = {
    LogicalType.STRING: "str",
    LogicalType.TEXT: "str",
    LogicalType.INTEGER: "int",
    LogicalType.NUMBER: "float",
    LogicalType.BOOLEAN: "bool",
    LogicalType.TIMESTAMP: "datetime",
    LogicalType.DATE: "date",
    LogicalType.TIME: "time",
    LogicalType.DATETIME: "datetime",
    LogicalType.ARRAY: "list[Any]",
    LogicalType.OBJECT: "dict[str, Any]",
    LogicalType.GEOMETRY: "str",
}

DATETIME_TYPES: frozenset[LogicalType] = frozenset(
    {LogicalType.TIMESTAMP, LogicalType.DATETIME, LogicalType.DATE, LogicalType.TIME}
)

TYPING_TYPES: frozenset[LogicalType] = frozenset({LogicalType.ARRAY, LogicalType.OBJECT})

JSONSCHEMA_UNMAPPABLE: frozenset[LogicalType] = frozenset({LogicalType.GEOMETRY})


def is_jsonschema_mappable(logical_type: LogicalType) -> bool:
    """Return True when *logical_type* survives JSON-schema rendering for an API.

    Tied to ``LOGICAL_TO_PYTHON``: every type with a Python mapping is a candidate,
    and exclusions live in ``JSONSCHEMA_UNMAPPABLE`` so a future addition fails
    loudly until both sides agree.
    """
    return logical_type in LOGICAL_TO_PYTHON and logical_type not in JSONSCHEMA_UNMAPPABLE


def map_type(logical_type: LogicalType) -> str:
    """Map a LogicalType to its Python type string.

    Raises TurbineError if the logical type has no mapping.
    """
    if (result := LOGICAL_TO_PYTHON.get(logical_type)) is not None:
        return result

    raise TurbineError(f"No Python type mapping for {logical_type!r}")


def datetime_import_names(columns: Iterable[ColumnDef]) -> list[str]:
    """Collect distinct Python datetime type names needed by the columns."""
    return sorted({map_type(col.logical_type) for col in columns if col.logical_type in DATETIME_TYPES})


def needs_typing_any(columns: Iterable[ColumnDef]) -> bool:
    """Return True if any column uses a type requiring ``from typing import Any``."""
    return any(col.logical_type in TYPING_TYPES for col in columns)
