"""Naming conventions for code generation.

Singularization, class naming, and table naming rules shared
across all codegen renderers. Adapters consume these — they
never invent their own naming logic.
"""


def singularize(word: str) -> str:
    """Best-effort English singularization.

    Handles common suffixes: -ies, -ses, -xes, -zes, -s.
    Returns the word unchanged when no rule applies.
    """
    min_ies_length = 4
    if word.endswith("ies") and len(word) >= min_ies_length:
        return word[:-3] + "y"
    if word.endswith(("ses", "xes", "zes")):
        return word[:-2]
    if word.endswith("s") and not word.endswith("ss") and not word.endswith("us"):
        return word[:-1]
    return word


def to_class_name(table_name: str) -> str:
    """Convert a snake_case table name to PascalCase singular.

    Example: ``energy_readings`` -> ``EnergyReading``.
    """
    parts = table_name.split("_")
    parts[-1] = singularize(parts[-1])
    return "".join(part.capitalize() for part in parts)


def to_table_name(name: str) -> str:
    """Convert a kebab-case name to snake_case for table usage.

    Example: ``my-contract`` -> ``my_contract``.
    """
    return name.replace("-", "_")
