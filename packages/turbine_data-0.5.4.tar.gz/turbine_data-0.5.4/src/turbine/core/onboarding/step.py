"""Tour step dataclasses."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Literal

from turbine.core.building_blocks.onboarding_actions import StepAction, StepKind
from turbine.core.building_blocks.onboarding_content import StepContentBlock

from .completions import StepCompletion
from .targets import HighlightTarget


@dataclass(frozen=True, slots=True, kw_only=True)
class SkipEdit:
    """Declarative edit applied when the user clicks Skip on an edit-style step."""

    file: str
    yaml_path: str
    value: str
    mode: Literal["replace_value", "append_child"] = "replace_value"


@dataclass(frozen=True, slots=True, kw_only=True)
class RunCheck:
    """Skip action that runs a named check against a dataset."""

    dataset: str
    check_name: str


@dataclass(frozen=True, slots=True, kw_only=True)
class RunIntrospection:
    """Skip action that triggers datasource introspection."""

    datasource: str


SkipAction = SkipEdit | RunCheck | RunIntrospection


@dataclass(frozen=True, slots=True, kw_only=True)
class Step:
    """A single, self-contained step in an onboarding tour.

    ``completion`` gates the Next button. ``None`` means narration: Next is
    enabled immediately. Setting any leaf variant (`FieldEquals`, `Timer`,
    `ActionFired`, ...) freezes Next until the variant fires `StepCompleted`.
    """

    id: str
    title: str
    content: tuple[StepContentBlock, ...]
    target: HighlightTarget
    kind: StepKind = StepKind.READ
    action: StepAction | None = None
    completion: StepCompletion | None = None
    skip: SkipAction | None = None
