"""Onboarding highlight target vocabulary."""

from turbine.core.building_blocks.onboarding_targets import (
    CheckTarget,
    ColumnFieldTarget,
    ContractFieldTarget,
    DatasetTarget,
    HighlightTarget,
    HighlightTargetKind,
    QualitySpecFieldTarget,
    RangeKind,
    ResolvedHighlight,
    ResolvedHighlightKind,
    SourceRangeTarget,
    SourceTextTarget,
    SqlTextTarget,
    UiTarget,
    YamlFieldTarget,
    target_file,
)

__all__ = [
    "CheckTarget",
    "ColumnFieldTarget",
    "ContractFieldTarget",
    "DatasetTarget",
    "HighlightTarget",
    "HighlightTargetKind",
    "QualitySpecFieldTarget",
    "RangeKind",
    "ResolvedHighlight",
    "ResolvedHighlightKind",
    "SourceRangeTarget",
    "SourceTextTarget",
    "SqlTextTarget",
    "UiTarget",
    "YamlFieldTarget",
    "target_file",
]
