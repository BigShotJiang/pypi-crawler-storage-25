"""Soft-dismissal port for onboarding phase cards.

Distinct from the diagnostic ``DismissalStore`` (``core/contract/dismissal.py``):
phase dismissals are keyed on ``(workspace_folder_uri, phase_kind)`` and the
invalidation rule is "until the phase changes again". The two stores share
the on-disk file (``<root>/.turbine/state.json``) but have different in-process
contracts.
"""

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from turbine.core.onboarding.phase import Phase


@dataclass(frozen=True, slots=True)
class OnboardingDismissalKey:
    """Identity of a soft-dismissed phase card."""

    workspace_folder_uri: str
    phase_kind: Phase


@runtime_checkable
class OnboardingDismissalStore(Protocol):
    """Per-workspace, per-phase soft dismissal."""

    def is_dismissed(self, key: OnboardingDismissalKey) -> bool:
        """Return True when *key* is currently dismissed."""
        ...

    def dismiss(self, key: OnboardingDismissalKey) -> None:
        """Record a dismissal for *key*."""
        ...

    def clear(self, workspace_folder_uri: str) -> None:
        """Drop every dismissal recorded for *workspace_folder_uri*."""
        ...
