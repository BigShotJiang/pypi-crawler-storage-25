"""Ports (Protocols) required by onboarding core logic."""

from __future__ import annotations

from collections.abc import Callable
from typing import Protocol

from turbine.core.building_blocks.onboarding_actions import StepActionKind


class YamlParser(Protocol):
    """Parses YAML text into a Python object tree.

    Implementations must never raise: malformed input returns None so that
    completions evaluated mid-edit never crash the tour.
    """

    def parse(self, text: str) -> object | None:
        """Return the parsed YAML value, or None if the text is malformed."""
        ...


class Scheduler(Protocol):
    """Schedules a single pending callback with cancel-and-replace semantics.

    Each call to `schedule` cancels any previously scheduled callback and
    replaces it with the new one. Implementations may be timer-based
    (production) or synchronous (tests).
    """

    def schedule(self, delay_ms: int, callback: Callable[[], None]) -> None:
        """Cancel any pending callback and schedule `callback` after `delay_ms`."""
        ...


class DiagnosticSource(Protocol):
    """Queries the LSP diagnostic cache for the presence of a specific rule code.

    The onboarding `DiagnosticCleared` completion reads from this port so core
    stays independent of the concrete LSP client. `file` is sandbox-relative.
    """

    def has_diagnostic(self, file: str, code: str) -> bool:
        """Return True if `file` currently has a diagnostic with the given `code`."""
        ...


class IntrospectionSource(Protocol):
    """Queries the introspection cache for table presence.

    The onboarding `IntrospectionPopulated` completion reads from this port
    so core stays independent of the concrete cache implementation.
    """

    def has_known_tables(self) -> bool:
        """Return True when introspection found at least one table."""
        ...


class SurfaceVisibilitySource(Protocol):
    """In-process state of editor surface (tree view, panel) visibility.

    The onboarding ``SurfaceVisible`` completion reads from this port so it
    can fire on arm when the surface is already visible — the user opened
    the sidebar before the step was reached. ``tour_service`` is the sole
    writer, fed by the LSP ``surfaceVisibilityChanged`` request the editor
    sends on view toggle (and on activation, to seed initial state).
    """

    def is_visible(self, surface_id: str) -> bool:
        """Return True when the surface identified by *surface_id* is currently visible."""
        ...

    def set_visible(self, surface_id: str, *, visible: bool) -> None:
        """Record the latest visibility for *surface_id*."""
        ...


class ActionInvokedStream(Protocol):
    """In-memory publish/subscribe surface for action invocations.

    Action invocation is a UX-loop signal scoped to the active tour Step,
    not a project-wide domain fact, so it gets its own port instead of a
    DomainEvent. The LSP's `tour_service` publishes into this stream from
    two paths:

    - the editor's ``turbine/onboarding/actionInvoked`` request (editor-only
      actions like `open_all_contracts`, `open_dashboard`).
    - the LSP-routed action handlers that intrinsically observe their own
      invocation (`run_validate`, `run_single_check`, `run_sandbox_checks`).

    An `ActionFired` completion subscribes for one specific kind and fires
    `StepCompleted` on a match.
    """

    def publish(self, kind: StepActionKind) -> None:
        """Fan out *kind* to every current subscriber synchronously."""
        ...

    def subscribe(self, handler: Callable[[StepActionKind], None]) -> Callable[[], None]:
        """Register *handler*; return a callable that detaches it."""
        ...
