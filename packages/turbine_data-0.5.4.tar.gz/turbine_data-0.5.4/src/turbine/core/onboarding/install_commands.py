"""Pure builder for the install-command list.

The editor never assembles install commands itself. The LSP sends
``turbine/onboarding/installCommands`` with a database choice and the editor
runs the resulting ordered command list verbatim through its task API.
Keeping the catalogue and the order here makes the wire shape and the policy
shippable from a single place.
"""

from dataclasses import dataclass

from turbine.core.onboarding.phase import DatabaseChoice, DatabaseChoiceId

DATABASE_CHOICES: tuple[DatabaseChoice, ...] = (
    DatabaseChoice(
        id=DatabaseChoiceId.POSTGRES, label="PostgreSQL", description="Install Turbine for PostgreSQL"
    ),
    DatabaseChoice(
        id=DatabaseChoiceId.SNOWFLAKE, label="Snowflake", description="Install Turbine for Snowflake"
    ),
    DatabaseChoice(
        id=DatabaseChoiceId.DUCKDB,
        label="DuckDB",
        description="Install Turbine for local files and demos",
    ),
    DatabaseChoice(
        id=DatabaseChoiceId.LSP_ONLY, label="LSP only", description="Install only the language server"
    ),
)

EXTRA_BY_CHOICE: dict[DatabaseChoiceId, str] = {
    DatabaseChoiceId.POSTGRES: "postgres",
    DatabaseChoiceId.SNOWFLAKE: "snowflake",
    DatabaseChoiceId.DUCKDB: "duckdb",
    DatabaseChoiceId.LSP_ONLY: "lsp",
}


@dataclass(frozen=True, slots=True)
class WorkspaceState:
    """Workspace facts the builder needs to decide which commands to prepend or skip."""

    has_pyproject: bool
    has_tool_turbine: bool


def build(choice: DatabaseChoiceId, state: WorkspaceState) -> tuple[str, ...]:
    """Return the ordered shell-command list for *choice* in *state*.

    Prepends ``uv init --python 3.13`` when ``pyproject.toml`` is missing,
    appends ``uv add "turbine-data[<extra>]"`` for the chosen extra, and
    appends ``uv run turbine init`` only when ``[tool.turbine]`` is missing
    AND the choice is not ``lsp-only`` (LSP-only setups don't need a Turbine
    project to function).
    """
    extra = EXTRA_BY_CHOICE[choice]
    commands: list[str] = []
    if not state.has_pyproject:
        commands.append("uv init --python 3.13")
    commands.append(f'uv add "turbine-data[{extra}]"')
    if not state.has_tool_turbine and choice is not DatabaseChoiceId.LSP_ONLY:
        commands.append("uv run turbine init")
    return tuple(commands)
