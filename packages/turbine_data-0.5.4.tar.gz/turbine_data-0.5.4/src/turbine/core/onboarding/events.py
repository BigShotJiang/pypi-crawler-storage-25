"""Events published during interactive onboarding tours."""

from __future__ import annotations

from pydantic import Field

from turbine.core.building_blocks import DomainEvent, event


@event
class DirtyBufferChanged(DomainEvent):
    """Published when a text document's dirty buffer changes in the editor."""

    uri: str = Field(serialization_alias="turbine.onboarding.uri")
    text: str = Field(serialization_alias="turbine.onboarding.text")


@event
class SurfaceVisibilityChanged(DomainEvent):
    """Published when an editor surface (tree view, panel) toggles visibility.

    ``surface_id`` is an opaque agreement between editor and server (e.g.
    ``"all-contracts"``); it must match the id used in any
    ``SurfaceVisible`` completion that watches the same surface.
    """

    surface_id: str = Field(serialization_alias="turbine.onboarding.surface_id")
    visible: bool = Field(serialization_alias="turbine.onboarding.visible")


@event
class StepCompleted(DomainEvent):
    """Published when an onboarding step's completion fires."""

    tour_id: str = Field(serialization_alias="turbine.onboarding.tour_id")
    step_id: str = Field(serialization_alias="turbine.onboarding.step_id")
