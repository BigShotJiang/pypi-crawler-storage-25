"""YAML-path planner for ``SkipEdit`` actions.

The planner builds ``TextEditInfo`` bundles from semantic YAML paths. It is
pure: callers provide the current file text, source map, and edit request.
"""

from __future__ import annotations

from turbine.core.building_blocks import SourceMap, TextEditInfo, TextRange

from .step import SkipEdit


def plan_skip_edit(text: str, source_map: SourceMap, edit: SkipEdit) -> tuple[TextEditInfo, ...] | None:
    """Dispatch on ``edit.mode`` and build the edit bundle."""
    if edit.mode == "append_child":
        return append_child_at_path(text, source_map, edit.yaml_path, edit.value)
    return replace_value_at_path(text, source_map, edit.yaml_path, edit.value)


def replace_value_at_path(
    text: str, source_map: SourceMap, yaml_path: str, value: str
) -> tuple[TextEditInfo, ...] | None:
    """Rewrite the scalar mapping value at ``yaml_path``."""
    key_range = source_map.range_for_key(yaml_path)
    if key_range is None:
        return None
    lines = text.splitlines(keepends=True)
    if not 1 <= key_range.start_line <= len(lines):
        return None
    original_line = lines[key_range.start_line - 1]
    parsed = parse_mapping_line(original_line)
    if parsed is None:
        return None
    indent, key = parsed
    new_line = f"{indent}{key}: {value}\n"
    text_range = TextRange(
        start_line=key_range.start_line,
        start_col=1,
        end_line=key_range.start_line,
        end_col=len(original_line) + 1,
    )
    return (TextEditInfo(range=text_range, new_text=new_line),)


def append_child_at_path(
    text: str, source_map: SourceMap, yaml_path: str, value: str
) -> tuple[TextEditInfo, ...] | None:
    """Append ``value`` as a child under the YAML block at ``yaml_path``."""
    key_range = source_map.range_for_key(yaml_path)
    block_range = source_map.range_for_block(yaml_path)
    if key_range is None or block_range is None:
        return None
    lines = text.splitlines(keepends=True)
    if not 1 <= key_range.start_line <= len(lines):
        return None
    key_line = lines[key_range.start_line - 1]
    base_indent = leading_whitespace(key_line)
    child_indent = f"{base_indent}  "
    new_text = indent_value(value, child_indent)
    insertion_line = block_range.end_line + 1
    text_range = TextRange(start_line=insertion_line, start_col=1, end_line=insertion_line, end_col=1)
    return (TextEditInfo(range=text_range, new_text=new_text),)


def parse_mapping_line(line: str) -> tuple[str, str] | None:
    """Return ``(indent, key)`` for a YAML mapping line."""
    stripped = line.lstrip()
    indent = line[: len(line) - len(stripped)]
    key, separator, _value = stripped.partition(":")
    if not separator or not key.strip():
        return None
    return indent, key.strip()


def leading_whitespace(line: str) -> str:
    """Return leading whitespace from ``line``."""
    return line[: len(line) - len(line.lstrip())]


def indent_value(value: str, indent: str) -> str:
    """Indent every non-empty line in ``value`` and end with a newline."""
    return "".join(f"{indent}{line}\n" if line.strip() else "\n" for line in value.split("\n"))
