"""Onboarding phase value objects.

The four workspace-state phases the LSP computes (``needs-pyproject``,
``needs-turbine``, ``ready-tour-pending``, ``ready``) plus the wire-side DTO
the editor renders. The DTO carries everything the panel needs to draw a
phase card; the editor never makes a semantic decision about what a phase
*means*, only how to lay it out.
"""

from dataclasses import dataclass
from enum import StrEnum


class Phase(StrEnum):
    """Workspace-state phase computed by the LSP."""

    NEEDS_PYPROJECT = "needs-pyproject"
    NEEDS_TURBINE = "needs-turbine"
    READY_TOUR_PENDING = "ready-tour-pending"
    READY = "ready"


class DatabaseChoiceId(StrEnum):
    """Identifier the editor sends back when the user picks a database."""

    POSTGRES = "postgres"
    SNOWFLAKE = "snowflake"
    DUCKDB = "duckdb"
    LSP_ONLY = "lsp-only"


@dataclass(frozen=True, slots=True)
class DatabaseChoice:
    """One entry in the database picker rendered for ``needs-turbine``."""

    id: DatabaseChoiceId
    label: str
    description: str


@dataclass(frozen=True, slots=True)
class TourEntry:
    """One entry in the tour picker rendered for ``ready-tour-pending``."""

    id: str
    title: str
    completed: bool


@dataclass(frozen=True, slots=True)
class PrimaryAction:
    """Optional primary action button on a phase card."""

    id: str
    label: str


@dataclass(frozen=True, slots=True)
class PhaseDto:
    """Phase payload pushed to the editor over ``turbine/onboardingPhase``.

    ``workspace_folder_uri`` keys the payload so the multi-root editor can
    route it to the right folder card. ``choices`` is populated for
    ``needs-turbine``; ``tours`` for ``ready-tour-pending``;
    ``primary_action`` for any phase that has one button (``needs-pyproject``
    → "Initialize Python project", ``ready`` → "Reset onboarding").
    """

    workspace_folder_uri: str
    kind: Phase
    title: str
    body: str
    choices: tuple[DatabaseChoice, ...] = ()
    tours: tuple[TourEntry, ...] = ()
    primary_action: PrimaryAction | None = None
