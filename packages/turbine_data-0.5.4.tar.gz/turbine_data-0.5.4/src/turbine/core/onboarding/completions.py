"""Step completion variants and their self-armed watchers.

A ``Step`` gates its Next button on a single ``StepCompletion`` value. Seven
leaf variants ship: five state-based ones (``FieldEquals``, ``FieldPresent``,
``DiagnosticCleared``, ``IntrospectionPopulated``, ``SurfaceVisible``) plus
``ActionFired`` (the user invoked the Step's action — click only, not
result-of-run) and ``Timer`` (wall clock). Each variant is self-arming via
``completion.watch(ctx)`` and returns a ``Watcher`` that the caller stops
when the Step changes.

State-based variants over editor buffers share ``StateBasedWatcher``:
subscribe to ``DirtyBufferChanged``, debounce 300 ms, re-evaluate, fire on
the false→true edge. ``SurfaceVisible`` listens to ``SurfaceVisibilityChanged``
and reads ``SurfaceVisibilitySource``. ``Timer`` schedules once.
``ActionFired`` subscribes to the ``ActionInvokedStream`` and fires once when
its kind matches.

Adding a new completion variant is a Python-only change: one dataclass, one
``.watch()`` method.
"""

from __future__ import annotations

from collections.abc import Callable, Mapping
from dataclasses import dataclass
from typing import Any, Protocol, cast, runtime_checkable

from turbine.core.building_blocks import EventBus
from turbine.core.building_blocks.onboarding_actions import StepActionKind
from turbine.core.onboarding.events import DirtyBufferChanged, StepCompleted, SurfaceVisibilityChanged
from turbine.core.onboarding.ports import (
    ActionInvokedStream,
    DiagnosticSource,
    IntrospectionSource,
    Scheduler,
    SurfaceVisibilitySource,
    YamlParser,
)

DEBOUNCE_MS = 300


class NullIntrospectionSource(IntrospectionSource):
    """Fallback IntrospectionSource: never reports tables.

    Used when the LSP is wired without a live introspection cache (e.g. an
    onboarding sandbox whose datasource has not been introspected yet). An
    `IntrospectionPopulated` watcher armed against this source stays gated
    until the real source replaces it.
    """

    def has_known_tables(self) -> bool:
        return False


@runtime_checkable
class Watcher(Protocol):
    """A self-armed step-completion observer that owns its own teardown."""

    def stop(self) -> None:
        """Idempotent: cancel schedules, drop subscriptions, release handles."""
        ...


@dataclass(frozen=True, slots=True, kw_only=True)
class WatchContext:
    """Bundle of ports a `StepCompletion` variant may need to arm itself.

    Variants pull only what they
    need; unused ports are ignored. ``buffers`` is a live mapping owned by
    ``TourService`` so all state-based watchers share the same dirty-buffer
    snapshot the LSP routes via ``DirtyBufferChanged``.
    """

    tour_id: str
    step_id: str
    yaml_parser: YamlParser
    diagnostics: DiagnosticSource
    introspection_source: IntrospectionSource
    surface_visibility_source: SurfaceVisibilitySource
    scheduler: Scheduler
    event_bus: EventBus
    action_invoked_stream: ActionInvokedStream
    translate_uri: Callable[[str], str | None]
    buffers: Mapping[str, str]


@runtime_checkable
class StepCompletion(Protocol):
    """A Step's gating condition. Variants implement self-arming via .watch()."""

    def watch(self, ctx: WatchContext) -> Watcher:
        """Arm the gate and return a `Watcher`.

        Implementations evaluate-on-arm so a Step whose state is already
        satisfied (user typed the right value before the tour started, or
        returns to a previously-satisfied step) fires `StepCompleted` before
        ``.watch()`` returns control.
        """
        ...


def lookup_path(parsed: object, dotted_path: str) -> object | None:
    """Walk *parsed* along a dotted YAML path, returning None if any step misses."""
    current: object = parsed
    for key in dotted_path.split("."):
        if not isinstance(current, Mapping):
            return None
        mapping = cast("Mapping[Any, Any]", current)
        next_value = mapping.get(key)
        if next_value is None:
            return None
        current = next_value
    return current


def fire(ctx: WatchContext) -> None:
    """Publish the StepCompleted event for the Step bound to *ctx*."""
    ctx.event_bus.publish(StepCompleted(tour_id=ctx.tour_id, step_id=ctx.step_id))


class StateBasedWatcher:
    """Shared subscribe-debounce-evaluate-edge loop for state-based variants.

    The variant supplies only an evaluator closure that reads the live
    ``buffers`` mapping (and any other port it cares about — captured in the
    closure). The watcher subscribes to ``DirtyBufferChanged``, debounces via
    ``Scheduler``, and fires ``StepCompleted`` exactly once on the false→true
    edge. Stop is idempotent.
    """

    def __init__(self, *, ctx: WatchContext, evaluate: Callable[[], bool]) -> None:
        self.ctx = ctx
        self.evaluator = evaluate
        self.last_result: bool = False
        self.active: bool = True
        ctx.event_bus.subscribe(DirtyBufferChanged, self.on_change)
        self.evaluate_now()

    def on_change(self, event: DirtyBufferChanged) -> None:
        if not self.active:
            return
        if self.ctx.translate_uri(event.uri) is None:
            return
        self.ctx.scheduler.schedule(DEBOUNCE_MS, self.evaluate_now)

    def evaluate_now(self) -> None:
        if not self.active:
            return
        result = self.evaluator()
        if result and not self.last_result:
            fire(self.ctx)
        self.last_result = result

    def stop(self) -> None:
        self.active = False


class TimerWatcher:
    """Schedules a single fire after the configured delay."""

    def __init__(self, *, ctx: WatchContext, ms: int) -> None:
        self.ctx = ctx
        self.active: bool = True
        ctx.scheduler.schedule(ms, self.fire_once)

    def fire_once(self) -> None:
        if not self.active:
            return
        fire(self.ctx)

    def stop(self) -> None:
        self.active = False


class SurfaceVisibilityWatcher:
    """Fires on the false→true edge of a surface's visibility.

    Evaluates the source on arm so a Step armed when the surface is already
    visible unlocks immediately. Subsequent ``SurfaceVisibilityChanged``
    events for the same ``surface_id`` re-evaluate against the source and
    fire only on the false→true transition. Stop is idempotent.
    """

    def __init__(self, *, ctx: WatchContext, surface_id: str) -> None:
        self.ctx = ctx
        self.surface_id = surface_id
        self.last_result: bool = False
        self.active: bool = True
        ctx.event_bus.subscribe(SurfaceVisibilityChanged, self.on_change)
        self.evaluate_now()

    def on_change(self, event: SurfaceVisibilityChanged) -> None:
        if not self.active:
            return
        if event.surface_id != self.surface_id:
            return
        self.evaluate_now()

    def evaluate_now(self) -> None:
        if not self.active:
            return
        result = self.ctx.surface_visibility_source.is_visible(self.surface_id)
        if result and not self.last_result:
            fire(self.ctx)
        self.last_result = result

    def stop(self) -> None:
        self.active = False


class ActionFiredWatcher:
    """Fires once when the matching action kind is published on the stream."""

    def __init__(self, *, ctx: WatchContext, kind: StepActionKind) -> None:
        self.ctx = ctx
        self.kind = kind
        self.active: bool = True
        self.fired: bool = False
        self.detach = ctx.action_invoked_stream.subscribe(self.on_action_invoked)

    def on_action_invoked(self, kind: StepActionKind) -> None:
        if not self.active:
            return
        if kind is not self.kind:
            return
        if self.fired:
            return
        self.fired = True
        fire(self.ctx)

    def stop(self) -> None:
        if not self.active:
            return
        self.active = False
        self.detach()


@dataclass(frozen=True, slots=True, kw_only=True)
class FieldEquals(StepCompletion):
    """Completion: ``yaml_path`` in ``file`` parses to a value whose string form equals ``expected``."""

    file: str
    yaml_path: str
    expected: str

    def watch(self, ctx: WatchContext) -> Watcher:
        def evaluate() -> bool:
            text = ctx.buffers.get(self.file)
            if text is None:
                return False
            parsed = ctx.yaml_parser.parse(text)
            if parsed is None:
                return False
            value = lookup_path(parsed, self.yaml_path)
            if value is None:
                return False
            return str(value) == self.expected

        return StateBasedWatcher(ctx=ctx, evaluate=evaluate)


@dataclass(frozen=True, slots=True, kw_only=True)
class FieldPresent(StepCompletion):
    """Completion: ``yaml_path`` in ``file`` resolves to a non-empty value."""

    file: str
    yaml_path: str

    def watch(self, ctx: WatchContext) -> Watcher:
        def evaluate() -> bool:
            text = ctx.buffers.get(self.file)
            if text is None:
                return False
            parsed = ctx.yaml_parser.parse(text)
            if parsed is None:
                return False
            value = lookup_path(parsed, self.yaml_path)
            if value is None:
                return False
            return str(value) != ""

        return StateBasedWatcher(ctx=ctx, evaluate=evaluate)


@dataclass(frozen=True, slots=True, kw_only=True)
class DiagnosticCleared(StepCompletion):
    """Completion: the LSP diagnostic ``code`` is absent from ``file``."""

    file: str
    code: str

    def watch(self, ctx: WatchContext) -> Watcher:
        def evaluate() -> bool:
            return not ctx.diagnostics.has_diagnostic(self.file, self.code)

        return StateBasedWatcher(ctx=ctx, evaluate=evaluate)


@dataclass(frozen=True, slots=True, kw_only=True)
class IntrospectionPopulated(StepCompletion):
    """Completion: the introspection cache holds at least one table."""

    def watch(self, ctx: WatchContext) -> Watcher:
        def evaluate() -> bool:
            return ctx.introspection_source.has_known_tables()

        return StateBasedWatcher(ctx=ctx, evaluate=evaluate)


@dataclass(frozen=True, slots=True, kw_only=True)
class SurfaceVisible(StepCompletion):
    """Completion: the editor surface identified by ``surface_id`` is visible.

    Use this instead of ``ActionFired`` when the gate models a piece of UI
    state (a tree view or panel being open) rather than a one-shot click.
    Fires on arm if the surface is already visible — closing and reopening
    is never required to satisfy the step.
    """

    surface_id: str

    def watch(self, ctx: WatchContext) -> Watcher:
        return SurfaceVisibilityWatcher(ctx=ctx, surface_id=self.surface_id)


@dataclass(frozen=True, slots=True, kw_only=True)
class ActionFired(StepCompletion):
    """Completion: the user invoked the Step's action button (click only)."""

    kind: StepActionKind

    def watch(self, ctx: WatchContext) -> Watcher:
        return ActionFiredWatcher(ctx=ctx, kind=self.kind)


@dataclass(frozen=True, slots=True, kw_only=True)
class Timer(StepCompletion):
    """Completion: wall clock — fire once after ``ms`` milliseconds."""

    ms: int

    def watch(self, ctx: WatchContext) -> Watcher:
        return TimerWatcher(ctx=ctx, ms=self.ms)
