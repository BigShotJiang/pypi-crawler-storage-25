"""Impact analysis: diff two ProjectIndex snapshots and build diagnostics for affected specs."""

from collections import defaultdict

from turbine.core.analysis.impact.model import ChangeType, ContractChange, ImpactReport
from turbine.core.building_blocks.diagnostics import Diagnostic, DiagnosticId, Severity
from turbine.core.contract import ProjectIndex
from turbine.core.contract.diff_computer import DiffComputer

CHANGE_TYPE_TO_DIAGNOSTIC: dict[ChangeType, tuple[DiagnosticId, Severity]] = {
    ChangeType.COLUMN_REMOVED: (DiagnosticId.IMPACT_COLUMN_REMOVED, Severity.ERROR),
    ChangeType.COLUMN_TYPE_CHANGED: (DiagnosticId.IMPACT_COLUMN_TYPE_CHANGED, Severity.WARNING),
    ChangeType.COLUMN_ADDED: (DiagnosticId.IMPACT_COLUMN_ADDED, Severity.INFO),
    ChangeType.COLUMN_NULLABLE_CHANGED: (DiagnosticId.IMPACT_COLUMN_NULLABLE_CHANGED, Severity.WARNING),
    ChangeType.CHECK_ADDED: (DiagnosticId.IMPACT_CHECK_ADDED, Severity.INFO),
    ChangeType.CHECK_REMOVED: (DiagnosticId.IMPACT_CHECK_REMOVED, Severity.WARNING),
    ChangeType.SCHEMA_REMOVED: (DiagnosticId.IMPACT_SCHEMA_REMOVED, Severity.ERROR),
}


def diff_indexes(old: ProjectIndex, new: ProjectIndex) -> tuple[ContractChange, ...]:
    """Compare two project index snapshots and return all detected contract changes.

    Delegates to ``DiffComputer.compute``. ``DiffComputer.compute`` accepts
    arguments in (current, previous) order while ``diff_indexes`` keeps its
    legacy (old, new) order, so the parameters flip on the way through.

    Args:
        old: The previous index snapshot.
        new: The current index snapshot.

    Returns:
        All detected changes between the two snapshots, possibly empty.
    """
    return DiffComputer.compute(new.contracts(), old.contracts())


_MESSAGE_TEMPLATES: dict[ChangeType, str] = {
    ChangeType.COLUMN_REMOVED: "Column '{col}' was removed from contract '{cid}'",
    ChangeType.COLUMN_TYPE_CHANGED: (
        "Column '{col}' type changed from '{old}' to '{new}' in contract '{cid}'"
    ),
    ChangeType.COLUMN_ADDED: "Column '{col}' was added to contract '{cid}'",
    ChangeType.COLUMN_NULLABLE_CHANGED: "Column '{col}' nullability changed in contract '{cid}'",
    ChangeType.CHECK_ADDED: "Check '{check}' was added to contract '{cid}'",
    ChangeType.CHECK_REMOVED: "Check '{check}' was removed from contract '{cid}'",
    ChangeType.SCHEMA_REMOVED: "Contract '{cid}' schema was removed",
}


def _make_message(change: ContractChange) -> str:
    """Build a human-readable message for an impact change."""
    template = _MESSAGE_TEMPLATES.get(change.change_type)
    if template is None:
        return f"Change '{change.change_type.value}' in contract '{change.contract_id}'"
    return template.format(
        cid=change.contract_id,
        col=change.column_name,
        old=change.old_type,
        new=change.new_type,
        check=change.check_name,
    )


def build_impact_diagnostics(
    changes: tuple[ContractChange, ...], index: ProjectIndex
) -> dict[str, tuple[Diagnostic, ...]]:
    """Turn contract changes into diagnostics grouped by affected quality spec URI.

    For each change with a known diagnostic mapping, finds quality specs
    referencing that contract via reverse-dep lookup and creates a diagnostic
    for each affected spec. Changes whose ``ChangeType`` has no diagnostic
    mapping (PK / threshold / description / SLA / required-tightened from
    ``DiffComputer``) are skipped silently — the impact-analysis surface only
    renders the seven legacy types.

    Args:
        changes: Contract changes from ``diff_indexes``.
        index: Current project index for reverse-dependency lookups.

    Returns:
        Mapping of quality spec URIs to their diagnostic tuples. Empty when
        no changes affect any quality specs.
    """
    if not changes:
        return {}

    uri_diags: dict[str, list[Diagnostic]] = defaultdict(list)

    for change in changes:
        mapping = CHANGE_TYPE_TO_DIAGNOSTIC.get(change.change_type)
        if mapping is None:
            continue
        diag_id, severity = mapping
        message = _make_message(change)
        affected_specs = index.find_specs_for_contract(change.contract_id)

        for spec in affected_specs:
            uri = spec.metadata.source_path.as_uri()
            uri_diags[uri].append(Diagnostic(id=diag_id, severity=severity, message=message))

    return {uri: tuple(diags) for uri, diags in uri_diags.items()}


def run_impact_analysis(
    previous_index: ProjectIndex | None, current_index: ProjectIndex
) -> tuple[ImpactReport, dict[str, tuple[Diagnostic, ...]]]:
    """Diff two index snapshots and produce impact diagnostics for affected specs.

    Orchestrates the full impact pipeline: diff, report, and diagnostic mapping.

    Args:
        previous_index: The prior index snapshot, or None on first run.
        current_index: The current index snapshot after file changes.

    Returns:
        A 2-tuple of (ImpactReport, diagnostics-by-URI). Both are empty
        when previous_index is None or no changes are detected.
    """
    if previous_index is None:
        return ImpactReport(), {}

    changes = diff_indexes(previous_index, current_index)
    report = ImpactReport(changes=changes)

    if not changes:
        return report, {}

    diag_map = build_impact_diagnostics(changes, current_index)
    return report, diag_map
