"""Impact analysis: diff project index snapshots and build diagnostics."""

from .analyzer import build_impact_diagnostics, diff_indexes, run_impact_analysis
from .model import ChangeType, ContractChange, ImpactReport

__all__ = [
    "ChangeType",
    "ContractChange",
    "ImpactReport",
    "build_impact_diagnostics",
    "diff_indexes",
    "run_impact_analysis",
]
