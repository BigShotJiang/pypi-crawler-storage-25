"""Impact analysis value objects — re-exports shared change types plus ImpactReport."""

from dataclasses import dataclass

from turbine.core.common.change_types import ChangeType, ContractChange

__all__ = ["ChangeType", "ContractChange", "ImpactReport"]


@dataclass(frozen=True, slots=True)
class ImpactReport:
    """Aggregate impact of all changes between two index snapshots."""

    changes: tuple[ContractChange, ...] = ()
