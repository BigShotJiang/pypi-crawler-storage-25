"""Code analysis domain types, context resolvers, tokenization, and impact analysis."""

from .context import (
    SCHEMA_NAME_PATTERN,
    KeyContext,
    SqlFileContext,
    extract_value_text,
    resolve_context_at_position,
    uri_to_path,
)
from .features.code_action import CodeActionInfo, CodeActionKind, CommandRef, CreateFileInfo
from .features.code_lens import CodeLensInfo
from .features.completion import CompletionItemInfo, CompletionKind
from .features.document_link import LinkInfo
from .features.hover import HoverInfo
from .features.rename import FileEdits, PrepareRenameInfo, RenameResult
from .features.semantic_tokens import SemanticTokenInfo
from .features.symbols import DocumentSymbolInfo
from .impact import build_impact_diagnostics, diff_indexes, run_impact_analysis
from .model import LocationInfo, SemanticTokenType, SymbolKind, TextEditInfo
from .ports import CodeWriteError, CodeWriter, SchemaResolver
from .tokenization import SqlTokenType, tokenize_sql

__all__ = [
    "SCHEMA_NAME_PATTERN",
    "CodeActionInfo",
    "CodeActionKind",
    "CodeLensInfo",
    "CodeWriteError",
    "CodeWriter",
    "CommandRef",
    "CompletionItemInfo",
    "CompletionKind",
    "CreateFileInfo",
    "DocumentSymbolInfo",
    "FileEdits",
    "HoverInfo",
    "KeyContext",
    "LinkInfo",
    "LocationInfo",
    "PrepareRenameInfo",
    "RenameResult",
    "SchemaResolver",
    "SemanticTokenInfo",
    "SemanticTokenType",
    "SqlFileContext",
    "SqlTokenType",
    "SymbolKind",
    "TextEditInfo",
    "build_impact_diagnostics",
    "diff_indexes",
    "extract_value_text",
    "resolve_context_at_position",
    "run_impact_analysis",
    "tokenize_sql",
    "uri_to_path",
]
