"""``RunRollup``: typed projection of a Run Result that every renderer consumes.

Centralises the "strict-PASSED count / worst-outcome / run errored?" math
that previously appeared inline at four sites (the Contract Health row
description, the Quality section header, the Quality Spec leaf
description, and the audit-trail success flag).

See `CONTEXT.md` (Run Rollup) for the domain definition.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from typing import Protocol, runtime_checkable

from turbine.core.analysis.protocol import CheckResultItem
from turbine.core.analysis.tree_protocol import TreeIcon
from turbine.core.common.check_outcome import CheckOutcome

# Worst-outcome → header icon. Lives here (not in quality_leaves) so the
# rollup can answer "what icon should the section header carry?" itself.
_WORST_OUTCOME_TO_ICON: dict[CheckOutcome, TreeIcon] = {
    CheckOutcome.FAILED: TreeIcon.FAIL,
    CheckOutcome.ERRORED: TreeIcon.FAIL,
    CheckOutcome.WARNED: TreeIcon.WARNING,
    CheckOutcome.PASSED: TreeIcon.PASS,
}


@runtime_checkable
class RunLike(Protocol):
    """Anything carrying ``outcomes`` + ``error`` — RunCheckResult or ContractQuality."""

    outcomes: tuple[CheckResultItem, ...]
    error: str | None


# Worst-outcome precedence: FAILED > ERRORED > WARNED > PASSED.
# SKIPPED never wins; UNKNOWN is the absent-from-outcomes case.
WORST_OUTCOME_PRECEDENCE: tuple[CheckOutcome, ...] = (
    CheckOutcome.FAILED,
    CheckOutcome.ERRORED,
    CheckOutcome.WARNED,
    CheckOutcome.PASSED,
)


@dataclass(frozen=True, slots=True)
class RunRollup:
    """What the system knows about a contract's (or spec's) latest run.

    ``is_run`` is False when no result row exists yet — every count field
    is zero, ``worst_outcome`` and ``last_run_at`` are None, ``succeeded``
    is False (gating sites read this as "the run hasn't passed because it
    hasn't happened").

    ``succeeded`` is the lenient gating answer: the run completed without
    a run-level error and produced no FAILED or ERRORED outcomes. WARNED
    is permitted (per the domain rule that WARNED is "not a hard failure").
    Display sites use ``passed``/``total`` instead — those count strict
    PASSED only, surfacing WARNED separately via the icon.
    """

    is_run: bool
    passed: int
    warned: int
    failed: int
    errored: int
    skipped: int
    worst_outcome: CheckOutcome | None
    succeeded: bool
    error: str | None
    last_run_at: datetime | None

    @property
    def total(self) -> int:
        """Total recorded outcomes (sum of the five buckets)."""
        return self.passed + self.warned + self.failed + self.errored + self.skipped

    @property
    def icon(self) -> TreeIcon:
        """Section / schema-group header icon: ``UNKNOWN`` if no worst outcome."""
        if self.worst_outcome is None:
            return TreeIcon.UNKNOWN
        return _WORST_OUTCOME_TO_ICON[self.worst_outcome]

    @classmethod
    def no_run(cls) -> RunRollup:
        """Sentinel rollup for "no result row exists yet"."""
        return cls(
            is_run=False,
            passed=0,
            warned=0,
            failed=0,
            errored=0,
            skipped=0,
            worst_outcome=None,
            succeeded=False,
            error=None,
            last_run_at=None,
        )

    @classmethod
    def from_run(cls, result: RunLike | None, *, last_run_at: datetime | None = None) -> RunRollup:
        """Bucket-count *result*; returns :meth:`no_run` when *result* is None.

        Accepts any object with ``outcomes`` + ``error`` attributes —
        ``RunCheckResult`` (wire DTO) and ``ContractQuality`` (derived
        dashboard projection) both qualify. Folding the None branch in
        keeps every call site one :meth:`from_run` invocation rather than
        a ``if quality is None`` ladder repeated at every renderer.
        """
        if result is None:
            return cls.no_run()
        return cls.from_outcomes(result.outcomes, error=result.error, last_run_at=last_run_at)

    @classmethod
    def from_outcomes(
        cls,
        outcomes: tuple[CheckResultItem, ...],
        *,
        error: str | None = None,
        last_run_at: datetime | None = None,
    ) -> RunRollup:
        """Bucket-count a raw outcomes tuple — used for schema-scoped subviews.

        Always returns a rolled-up (``is_run=True``) result; callers that
        want the no-run sentinel use :meth:`no_run` directly.
        """
        counts: dict[CheckOutcome, int] = dict.fromkeys(CheckOutcome, 0)
        for item in outcomes:
            counts[item.outcome] += 1
        worst = next((outcome for outcome in WORST_OUTCOME_PRECEDENCE if counts[outcome]), None)
        succeeded = (
            error is None and counts[CheckOutcome.FAILED] == 0 and counts[CheckOutcome.ERRORED] == 0
        )
        return cls(
            is_run=True,
            passed=counts[CheckOutcome.PASSED],
            warned=counts[CheckOutcome.WARNED],
            failed=counts[CheckOutcome.FAILED],
            errored=counts[CheckOutcome.ERRORED],
            skipped=counts[CheckOutcome.SKIPPED],
            worst_outcome=worst,
            succeeded=succeeded,
            error=error,
            last_run_at=last_run_at,
        )
