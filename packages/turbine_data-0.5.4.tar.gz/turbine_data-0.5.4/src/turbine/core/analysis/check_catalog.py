"""Check catalog: registry of available check types for the Add Check flow.

Each entry describes a check type the user can add via the code lens picker.
Future slices add entries here without modifying plumbing.
"""

from dataclasses import dataclass
from enum import StrEnum
from functools import cache


class CheckScope(StrEnum):
    """Where a check type can be applied."""

    COLUMN = "column"
    DATASET = "dataset"


class CheckBucket(StrEnum):
    """User-facing grouping for the check picker."""

    COMMON = "Common checks"
    AGGREGATE = "Aggregate values"
    ANOMALY = "Anomaly detection"
    CUSTOM = "Custom logic"


@dataclass(frozen=True, slots=True)
class CheckCatalogEntry:
    """A single check type in the catalog."""

    id: str
    description: str
    scopes: frozenset[CheckScope]
    bucket: CheckBucket
    takes_threshold: bool
    needs_column: bool = False


CHECK_CATALOG: tuple[CheckCatalogEntry, ...] = (
    # ── Common checks ──
    CheckCatalogEntry(
        id="missing",
        description="Counts rows where the column value is null or empty",
        scopes=frozenset({CheckScope.COLUMN, CheckScope.DATASET}),
        bucket=CheckBucket.COMMON,
        takes_threshold=True,
        needs_column=True,
    ),
    CheckCatalogEntry(
        id="duplicate",
        description="Counts rows with duplicate values in the column",
        scopes=frozenset({CheckScope.COLUMN, CheckScope.DATASET}),
        bucket=CheckBucket.COMMON,
        takes_threshold=True,
        needs_column=True,
    ),
    CheckCatalogEntry(
        id="row_count",
        description="Counts the total number of rows in the dataset",
        scopes=frozenset({CheckScope.DATASET}),
        bucket=CheckBucket.COMMON,
        takes_threshold=True,
    ),
    CheckCatalogEntry(
        id="freshness",
        description="Measures how recently the data was updated",
        scopes=frozenset({CheckScope.COLUMN, CheckScope.DATASET}),
        bucket=CheckBucket.COMMON,
        takes_threshold=True,
        needs_column=True,
    ),
    CheckCatalogEntry(
        id="invalid",
        description="Counts rows failing validity constraints like regex, min, or max",
        scopes=frozenset({CheckScope.COLUMN, CheckScope.DATASET}),
        bucket=CheckBucket.COMMON,
        takes_threshold=True,
        needs_column=True,
    ),
    # ── Aggregate values ──
    CheckCatalogEntry(
        id="avg",
        description="Computes the average value of a numeric column",
        scopes=frozenset({CheckScope.COLUMN}),
        bucket=CheckBucket.AGGREGATE,
        takes_threshold=True,
        needs_column=True,
    ),
    CheckCatalogEntry(
        id="min",
        description="Finds the minimum value in a column",
        scopes=frozenset({CheckScope.COLUMN}),
        bucket=CheckBucket.AGGREGATE,
        takes_threshold=True,
        needs_column=True,
    ),
    CheckCatalogEntry(
        id="max",
        description="Finds the maximum value in a column",
        scopes=frozenset({CheckScope.COLUMN}),
        bucket=CheckBucket.AGGREGATE,
        takes_threshold=True,
        needs_column=True,
    ),
    CheckCatalogEntry(
        id="sum",
        description="Computes the total sum of a numeric column",
        scopes=frozenset({CheckScope.COLUMN}),
        bucket=CheckBucket.AGGREGATE,
        takes_threshold=True,
        needs_column=True,
    ),
    # ── Anomaly detection ──
    CheckCatalogEntry(
        id="zscore",
        description="Detects statistical outliers using z-score over a window",
        scopes=frozenset({CheckScope.COLUMN}),
        bucket=CheckBucket.ANOMALY,
        takes_threshold=True,
        needs_column=True,
    ),
    CheckCatalogEntry(
        id="spike",
        description="Detects sudden value increases between consecutive rows",
        scopes=frozenset({CheckScope.COLUMN}),
        bucket=CheckBucket.ANOMALY,
        takes_threshold=True,
        needs_column=True,
    ),
    CheckCatalogEntry(
        id="flatline",
        description="Detects windows where all values are identical",
        scopes=frozenset({CheckScope.COLUMN}),
        bucket=CheckBucket.ANOMALY,
        takes_threshold=True,
        needs_column=True,
    ),
    CheckCatalogEntry(
        id="pct_change",
        description="Detects rows with large percentage changes from the previous row",
        scopes=frozenset({CheckScope.COLUMN}),
        bucket=CheckBucket.ANOMALY,
        takes_threshold=True,
        needs_column=True,
    ),
    CheckCatalogEntry(
        id="range",
        description="Detects rows falling outside a rolling statistical range",
        scopes=frozenset({CheckScope.COLUMN}),
        bucket=CheckBucket.ANOMALY,
        takes_threshold=True,
        needs_column=True,
    ),
    # ── Custom logic ──
    CheckCatalogEntry(
        id="sql",
        description="Runs a custom SQL query and evaluates the result",
        scopes=frozenset({CheckScope.COLUMN, CheckScope.DATASET}),
        bucket=CheckBucket.CUSTOM,
        takes_threshold=True,
    ),
    CheckCatalogEntry(
        id="python",
        description="Runs a custom Python function and evaluates the result",
        scopes=frozenset({CheckScope.COLUMN, CheckScope.DATASET}),
        bucket=CheckBucket.CUSTOM,
        takes_threshold=True,
    ),
)


@cache
def column_required_check_types() -> frozenset[str]:
    """Return every check type that must emit a ``column:`` placeholder at dataset scope."""
    return frozenset(entry.id for entry in CHECK_CATALOG if entry.needs_column)
