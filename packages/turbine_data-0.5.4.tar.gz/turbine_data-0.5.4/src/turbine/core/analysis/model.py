"""Shared value objects for code analysis features.

Types in this module are used by multiple feature modules (e.g. ``LocationInfo``
is shared between definition.py and references.py).  Single-use types live in
their respective feature modules under ``features/``.

``LocationInfo``, ``SymbolKind``, and ``TextEditInfo`` are re-exported from
``core.common`` where they now live to avoid dependency violations.
"""

from enum import StrEnum

from turbine.core.common.analysis_types import LocationInfo, SymbolKind
from turbine.core.common.file_edits import TextEditInfo

__all__ = ["LocationInfo", "SemanticTokenType", "SymbolKind", "TextEditInfo"]


class SemanticTokenType(StrEnum):
    """Token category for semantic syntax highlighting in contract files.

    Each member maps 1:1 to an LSP ``SemanticTokenTypes`` constant via the
    presentation layer's token legend.

    Members:
        TYPE: Type name (e.g. ``string``, ``integer``).
        KEYWORD: Turbine-recognized keyword (e.g. ``contract_id``).
        VARIABLE: User-defined variable reference.
        PARAMETER: Named parameter inside an expression.
        OPERATOR: Operator symbol.
        STRING: String literal value.
        NUMBER: Numeric literal value.
        COMMENT: Comment text.
    """

    TYPE = "type"
    KEYWORD = "keyword"
    VARIABLE = "variable"
    PARAMETER = "parameter"
    OPERATOR = "operator"
    STRING = "string"
    NUMBER = "number"
    COMMENT = "comment"
