"""Source-map span helpers for locating YAML key values by text content.

These helpers walk a source map once with a caller-supplied path predicate
and return the ``TextRange`` + already-decoded value for every match. Every
diagnostic locator (column span, table span, column-name block range) is
built on top of this single loop — keeping the guard logic (line bounds,
range lookup, text slicing) in exactly one place.
"""

from collections.abc import Callable, Iterator
from pathlib import Path

from turbine.core.building_blocks import Span, TextRange
from turbine.core.building_blocks.diagnostics.source_map import SourceMap
from turbine.core.common import CheckDef, RawSource

PathPredicate = Callable[[str], bool]

TABLE_NAME_PATH_SEGMENTS = 3  # schema . N . name


def is_column_name_path(path: str) -> bool:
    """Return True for paths like ``schema.0.properties.3.name``."""
    return ".properties." in path and path.endswith(".name")


def is_table_name_path(path: str) -> bool:
    """Return True for top-level schema entry names like ``schema.0.name``."""
    if not path.startswith("schema.") or not path.endswith(".name"):
        return False
    return len(path.split(".")) == TABLE_NAME_PATH_SEGMENTS


def iter_named_values_from_parts(
    source_map: SourceMap, text: str, predicate: PathPredicate
) -> Iterator[tuple[str, str, TextRange]]:
    """Yield ``(dotted_path, value_text, value_range)`` for every path matching *predicate*.

    Works from the raw primitives (source_map + text) so callers that already
    parsed the file into a ``CodeActionQuery`` can reuse the scan without
    rebuilding a ``RawSource``.
    """
    lines = text.splitlines()
    for path in source_map.key_paths():
        if not predicate(path):
            continue
        value_range = source_map.range_for_value(path)
        if value_range is None:
            continue
        if not 1 <= value_range.start_line <= len(lines):
            continue
        line_text = lines[value_range.start_line - 1]
        value_text = line_text[value_range.start_col - 1 : value_range.end_col - 1].strip()
        yield path, value_text, value_range


def iter_named_values(
    source: RawSource, predicate: PathPredicate
) -> Iterator[tuple[str, str, TextRange]]:
    """Yield ``(dotted_path, value_text, value_range)`` for every path matching *predicate*."""
    return iter_named_values_from_parts(source.source_map, source.text, predicate)


def find_column_span(source: RawSource, source_path: Path, column_name: str) -> Span | None:
    """Return a ``Span`` pointing at the ``name: column_name`` value, or ``None``."""
    for _path, value_text, value_range in iter_named_values(source, is_column_name_path):
        if value_text == column_name:
            return Span(path=source_path, range=value_range)
    return None


def find_table_span(source: RawSource, source_path: Path, table_name: str) -> Span | None:
    """Return a ``Span`` pointing at the ``schema[n].name`` value, or ``None``."""
    for _path, value_text, value_range in iter_named_values(source, is_table_name_path):
        if value_text == table_name:
            return Span(path=source_path, range=value_range)
    return None


def pick_check_span(check: CheckDef | None) -> TextRange | None:
    """First non-None range from the check's fallback chain.

    Order: ``name_source_range`` -> ``column_source_range`` -> ``source_range``
    -> ``column_meta.source_range`` -> ``None``.

    The chain is name-first (most precise) and degrades to the enclosing
    block, then to the column-meta fallback used for synthetic checks.
    """
    if check is None:
        return None
    column_meta_range = check.column_meta.source_range if check.column_meta else None
    return (
        check.name_source_range or check.column_source_range or check.source_range or column_meta_range
    )
