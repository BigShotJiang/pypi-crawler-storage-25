"""Code lens — produce lens items for contract schemas and datasources.

Deep module owning the port protocol, query/result types, and pure
code-lens construction logic.
"""

import re
from dataclasses import dataclass

from turbine.core.analysis.context import SCHEMA_NAME_PATTERN
from turbine.core.building_blocks import TextRange
from turbine.core.common.constants import ContractKind


@dataclass(frozen=True, slots=True)
class CodeLensInfo:
    """Inline annotation rendered above a code block (e.g. "Run checks" above a contract).

    Clicking the lens triggers the named *command* on the server side.

    Attributes:
        title: Label displayed in the editor (e.g. ``"Run checks"``).
        command: Server-side command identifier to execute on click.
        range: Source range the lens is anchored to.
        arguments: Extra arguments forwarded to the command handler.

    Example::

        lens = CodeLensInfo(
            title="Run checks",
            command="turbine.runChecks",
            range=TextRange(line=0, col=0, end_line=0, end_col=0),
            arguments=("orders",),
        )
    """

    title: str
    command: str
    range: TextRange
    arguments: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class CodeLensQuery:
    """Request for code lenses in a file."""

    uri: str
    content: str


SCHEMA_NAME_RE = re.compile(SCHEMA_NAME_PATTERN)
CONTRACT_ID_RE = re.compile(r"^id:\s*(.+?)(?:\s*#.*)?$", re.MULTILINE)
KIND_RE = re.compile(r"^kind:\s*(\S+)\s*(?:#.*)?$", re.MULTILINE)
TARGET_CONTRACT_RE = re.compile(r"^targetContract:\s*(.+?)(?:\s*#.*)?$", re.MULTILINE)
DATASOURCE_TYPE_RE = re.compile(
    r"^type:\s*(postgres|snowflake|duckdb|bigquery|redshift|mysql)\s*(?:#.*)?$", re.MULTILINE
)
DATASET_RE = re.compile(r"^dataset:\s*(.+)$", re.MULTILINE)
PROPERTY_NAME_RE = re.compile(r"^\s+-\s+name:\s*(.+)$")


def strip_inline_comment(line: str) -> str:
    """Return the line content with any trailing ``# ...`` comment removed."""
    hash_pos = line.find("#")
    if hash_pos < 0:
        return line.rstrip()
    return line[:hash_pos].rstrip()


def find_schema_positions(content: str) -> list[tuple[int, str]]:
    """Find schema-level name declarations and their 1-indexed line numbers."""
    schema_lines = extract_schema_section(content)
    return extract_names_at_top_indent(schema_lines)


def extract_schema_section(content: str) -> list[tuple[int, str]]:
    """Return (line_number, line) pairs belonging to the ``schema:`` section."""
    lines: list[tuple[int, str]] = []
    in_section = False
    for line_num, line in enumerate(content.splitlines(), start=1):
        stripped = strip_inline_comment(line).strip()
        if stripped == "schema:":
            in_section = True
            continue
        if not in_section or not stripped:
            continue
        indent = len(line) - len(line.lstrip())
        if indent == 0 and not stripped.startswith("- "):
            break
        lines.append((line_num, line))
    return lines


def extract_names_at_top_indent(lines: list[tuple[int, str]]) -> list[tuple[int, str]]:
    """Extract ``- name: X`` entries at the first list-item indent level."""
    top_indent: int | None = None
    results: list[tuple[int, str]] = []
    for line_num, line in lines:
        stripped = line.strip()
        indent = len(line) - len(line.lstrip())
        if top_indent is None and stripped.startswith("- "):
            top_indent = indent
        if indent == top_indent and (match := SCHEMA_NAME_RE.match(line)):
            results.append((line_num, match.group(1).strip()))
    return results


def extract_contract_id(content: str) -> str:
    """Extract the contract ID from file content."""
    if (match := CONTRACT_ID_RE.search(content)) is not None:
        return match.group(1).strip()
    return ""


def detect_kind(content: str) -> ContractKind | None:
    """Extract the ``kind:`` field from file content and return the matching enum, or None."""
    match = KIND_RE.search(content)
    if match is None:
        return None
    raw = match.group(1).strip()
    try:
        return ContractKind(raw)
    except ValueError:
        return None


def extract_target_contract(content: str) -> str:
    """Extract the ``targetContract:`` value from a quality spec."""
    if (match := TARGET_CONTRACT_RE.search(content)) is not None:
        return match.group(1).strip()
    return ""


def is_datasource_file(content: str) -> bool:
    """Check if content looks like a datasource configuration file."""
    return DATASOURCE_TYPE_RE.search(content) is not None


def extract_dataset(content: str) -> str:
    """Extract the ``dataset:`` value from a quality spec."""
    if (match := DATASET_RE.search(content)) is not None:
        return match.group(1).strip()
    return ""


def schema_block_ranges(
    schema_lines: list[tuple[int, str]],
) -> list[tuple[int, str, list[tuple[int, str]]]]:
    """Split the schema section into per-schema blocks.

    Returns ``(schema_start_line, schema_name, block_lines)`` triples where
    ``block_lines`` contains every schema line after the ``- name:`` entry
    and before the next schema's ``- name:`` entry.
    """
    schema_names = extract_names_at_top_indent(schema_lines)
    line_to_idx = {line_num: idx for idx, (line_num, _) in enumerate(schema_lines)}
    total = len(schema_lines)

    blocks: list[tuple[int, str, list[tuple[int, str]]]] = []
    for idx, (schema_start_line, schema_name) in enumerate(schema_names):
        start_idx = line_to_idx[schema_start_line]
        end_idx = line_to_idx[schema_names[idx + 1][0]] if idx + 1 < len(schema_names) else total
        blocks.append((schema_start_line, schema_name, schema_lines[start_idx + 1 : end_idx]))

    return blocks


def walk_section_in_block(block_lines: list[tuple[int, str]], section_key: str) -> list[tuple[int, str]]:
    """Return lines inside a named subsection (e.g. ``properties:`` or ``quality:``).

    Stops at the next line whose indent is less than or equal to the section
    header's indent, matching YAML's scoping rules.
    """
    header = f"{section_key}:"
    section_indent: int | None = None
    collected: list[tuple[int, str]] = []

    for line_num, raw_line in block_lines:
        stripped = raw_line.strip()
        indent = len(raw_line) - len(raw_line.lstrip())
        if section_indent is None:
            section_indent = indent if stripped == header else None
            continue
        if section_boundary_reached(stripped, indent, section_indent):
            break
        collected.append((line_num, raw_line))

    return collected


def section_boundary_reached(stripped: str, indent: int, section_indent: int) -> bool:
    """Return whether a generic nested YAML section ended."""
    same_indent_non_item = indent == section_indent and not stripped.startswith("- ")
    return bool(stripped) and (indent < section_indent or same_indent_non_item)


def top_level_property_names(property_lines: list[tuple[int, str]]) -> list[tuple[int, int, str, int]]:
    """Return ``(index, line_num, property_name, entry_indent)`` for top-level properties."""
    top_indent: int | None = None
    results: list[tuple[int, int, str, int]] = []
    for idx, (line_num, raw_line) in enumerate(property_lines):
        if (match := PROPERTY_NAME_RE.match(raw_line)) is None:
            continue
        indent = len(raw_line) - len(raw_line.lstrip())
        if top_indent is None:
            top_indent = indent
        if indent == top_indent:
            results.append((idx, line_num, match.group(1).strip(), indent))
    return results


def find_property_quality_line(prop_block: list[tuple[int, str]], property_indent: int) -> int | None:
    """Return the line of the ``quality:`` child key inside a single property block."""
    child_indent = property_indent + 2
    for line_num, raw_line in prop_block:
        indent = len(raw_line) - len(raw_line.lstrip())
        if indent != child_indent:
            continue
        if strip_inline_comment(raw_line).strip() == "quality:":
            return line_num
    return None


def find_schema_quality_end_lines(content: str) -> list[tuple[int, str]]:
    """Find the last content line in each schema's ``quality:`` block.

    Returns ``(last_line_number, schema_name)`` pairs. Only schema-level
    ``quality:`` blocks count; nested per-property ``quality:`` blocks are
    ignored. Schemas without a schema-level ``quality:`` block are omitted.
    """
    if not content.strip():
        return []

    schema_lines = extract_schema_section(content)
    if not schema_lines:
        return []

    results: list[tuple[int, str]] = []
    for _, schema_name, block_lines in schema_block_ranges(schema_lines):
        child_indent = schema_child_indent(block_lines)
        if child_indent is None:
            continue
        quality_lines = walk_section_at_indent(block_lines, "quality", child_indent)
        last_content_line = next(
            (line_num for line_num, raw_line in reversed(quality_lines) if raw_line.strip()), None
        )
        if last_content_line is not None:
            results.append((last_content_line, schema_name))

    return results


def schema_child_indent(block_lines: list[tuple[int, str]]) -> int | None:
    """Return the direct-child indent of a schema entry (the minimum non-blank indent)."""
    indents = [len(raw_line) - len(raw_line.lstrip()) for _, raw_line in block_lines if raw_line.strip()]
    return min(indents) if indents else None


def walk_section_at_indent(
    block_lines: list[tuple[int, str]], section_key: str, required_indent: int
) -> list[tuple[int, str]]:
    """Return lines inside a ``<section_key>:`` header that sits at *required_indent*."""
    header = f"{section_key}:"
    in_section = False
    collected: list[tuple[int, str]] = []

    for line_num, raw_line in block_lines:
        stripped = strip_inline_comment(raw_line).strip()
        indent = len(raw_line) - len(raw_line.lstrip())
        if not in_section:
            in_section = stripped == header and indent == required_indent
            continue
        if section_boundary_reached(stripped, indent, required_indent):
            break
        collected.append((line_num, raw_line))

    return collected
