"""Code actions — quick-fix and source actions from diagnostics.

Deep module owning the port protocol, query/result types, and pure
fix-generator logic.  The ``CodeActionService`` lives in the application
layer (``turbine.application.analysis.code_action``).
"""

import re
from collections.abc import Callable
from dataclasses import dataclass
from difflib import get_close_matches
from enum import StrEnum
from typing import cast

from turbine.core.analysis.context import SCHEMA_NAME_PATTERN
from turbine.core.analysis.features.snippet_builder import build_snippet, scalar_key_snippet
from turbine.core.analysis.model import TextEditInfo
from turbine.core.analysis.ports import SchemaResolver
from turbine.core.analysis.source_spans import is_column_name_path, iter_named_values_from_parts
from turbine.core.building_blocks import (
    DiagnosticData,
    DiagnosticKind,
    FixAction,
    Severity,
    SourceMap,
    TextRange,
)
from turbine.core.common.commands import CommandId
from turbine.core.common.dataset_spec.spec import ColumnDef
from turbine.core.common.identifiers import TableIdentifier
from turbine.core.common.introspection_cache import IntrospectionCache
from turbine.core.common.logical_type import TIME_LIKE_LOGICAL_TYPES


class CodeActionKind(StrEnum):
    """Category for code actions surfaced via the lightbulb menu.

    Members:
        QUICK_FIX: Automatic fix for a diagnostic (e.g. add a missing field).
        SOURCE: Whole-file refactoring (e.g. sort columns alphabetically).
    """

    QUICK_FIX = "quickfix"
    SOURCE = "source"


@dataclass(frozen=True, slots=True)
class CreateFileInfo:
    """Workspace edit that creates a brand-new file with pre-filled content.

    Paired with a ``CodeActionInfo`` so the editor can create scaffold files
    (e.g. a new quality spec) in a single action.

    Attributes:
        uri: File URI for the new file.
        content: Full text to write into the file.

    Example::

        create = CreateFileInfo(
            uri="file:///project/contracts/quality/orders_quality.yaml",
            content="contract_id: orders_quality",
        )
    """

    uri: str
    content: str


@dataclass(frozen=True, slots=True)
class CommandRef:
    """Reference to a workspace command triggered when the user selects this action.

    Attributes:
        command_id: The workspace command identifier (e.g. ``CommandId.GENERATE_QUALITY_SPEC``).
        arguments: Positional arguments forwarded to the command handler. The
            LSP wire shape allows arbitrary JSON values; we support strings
            and ints so commands like ``insertSnippetAt`` can carry a
            ``(uri, line, character, snippetText)`` quadruple.
    """

    command_id: str
    arguments: tuple[str | int, ...] = ()


@dataclass(frozen=True, slots=True)
class CodeActionInfo:
    """Actionable fix or refactoring shown in the editor's lightbulb menu.

    Can carry text edits to an existing file, a file-creation instruction,
    a command reference, or a combination.  The presentation layer translates
    this into an LSP ``CodeAction``.

    Attributes:
        title: Human-readable label shown in the quick-fix menu.
        kind: Whether this is a quick fix or a source-level action.
        uri: File URI the edits apply to.
        edits: In-place text replacements within the file.
        create_file: Optional instruction to create a new file alongside the edits.
        command_ref: Optional command to execute when the action is selected.
        is_preferred: If ``True``, the editor auto-applies this action on save or
            via a keyboard shortcut.
    """

    title: str
    kind: CodeActionKind
    uri: str
    edits: tuple[TextEditInfo, ...] = ()
    create_file: CreateFileInfo | None = None
    command_ref: CommandRef | None = None
    is_preferred: bool = False


@dataclass(frozen=True, slots=True)
class DiagnosticContext:
    """A diagnostic from the LSP client, converted to domain types.

    ``severity`` is threaded from the LSP diagnostic so severity-aware
    collectors (notably ``collect_dismiss_actions``) can gate on it without
    re-querying. Defaults to ``WARNING`` so existing call sites that only
    care about fix-generation continue to work without changes.
    """

    range: TextRange
    message: str
    data: DiagnosticData
    severity: Severity = Severity.WARNING


@dataclass(frozen=True, slots=True)
class PropertyBlock:
    """A contiguous block of YAML lines for a single property (- name: X + children)."""

    name: str
    start_line: int
    end_line: int
    text: str


@dataclass(frozen=True, slots=True)
class CodeActionQuery:
    """Request for code actions at a given document."""

    uri: str
    diagnostics: tuple[DiagnosticContext, ...] = ()
    content: str = ""
    source_map: SourceMap | None = None
    introspection_cache: IntrospectionCache | None = None
    data: dict[str, object] | None = None
    schema_resolver: SchemaResolver | None = None


VALIDATION_LABELS: dict[DiagnosticKind, str] = {
    DiagnosticKind.VALIDATE_COLUMN_ADDED: "added column",
    DiagnosticKind.VALIDATE_COLUMN_REMOVED: "removed column",
    DiagnosticKind.VALIDATE_TYPE_CHANGED: "type change",
    DiagnosticKind.VALIDATE_NULLABILITY_CHANGED: "nullability change",
}


def unknown_field_actions(query: CodeActionQuery, diag: DiagnosticContext) -> list[CodeActionInfo]:
    """Generate 'Remove' and optional 'Did you mean?' actions for unknown fields."""
    field = diag.data.field_name or "field"
    actions: list[CodeActionInfo] = []
    remove_range = TextRange(
        start_line=diag.range.start_line, start_col=1, end_line=diag.range.start_line + 1, end_col=1
    )
    actions.append(
        CodeActionInfo(
            title=f"Remove '{field}'",
            kind=CodeActionKind.QUICK_FIX,
            uri=query.uri,
            edits=(TextEditInfo(range=remove_range, new_text=""),),
        )
    )
    if diag.data.suggested_value:
        actions.append(
            CodeActionInfo(
                title=f"Did you mean '{diag.data.suggested_value}'?",
                kind=CodeActionKind.QUICK_FIX,
                uri=query.uri,
                edits=(TextEditInfo(range=diag.range, new_text=diag.data.suggested_value),),
                is_preferred=True,
            )
        )
    return actions


def missing_field_actions(query: CodeActionQuery, diag: DiagnosticContext) -> list[CodeActionInfo]:
    """Generate 'Add required field' action for missing required fields.

    When the schema resolver and parsed document are available, emits a
    snippet-aware action through ``INSERT_SNIPPET_AT`` so tab stops survive
    and the placeholder comes from the schema (examples / type / default) —
    matching the shape completion produces for the same key. Otherwise
    falls back to a plain ``TextEditInfo`` with an empty value.
    """
    field = diag.data.field_name
    if not field:
        return []
    indent = " " * (diag.range.start_col - 1)
    insert_line = diag.range.end_line + 1  # 1-indexed line for the new field
    snippet_body = build_missing_field_snippet(query, diag, field)
    if snippet_body is not None:
        snippet_text = f"{indent}{snippet_body}\n"
        return [
            CodeActionInfo(
                title=f"Add required field '{field}'",
                kind=CodeActionKind.QUICK_FIX,
                uri=query.uri,
                command_ref=CommandRef(
                    command_id=CommandId.INSERT_SNIPPET_AT,
                    arguments=(query.uri, insert_line - 1, 0, snippet_text),
                ),
                is_preferred=True,
            )
        ]
    insert_point = TextRange(start_line=insert_line, start_col=1, end_line=insert_line, end_col=1)
    default_value = diag.data.suggested_value or ""
    new_text = f"{indent}{field}: {default_value}\n"
    return [
        CodeActionInfo(
            title=f"Add required field '{field}'",
            kind=CodeActionKind.QUICK_FIX,
            uri=query.uri,
            edits=(TextEditInfo(range=insert_point, new_text=new_text),),
            is_preferred=True,
        )
    ]


def build_missing_field_snippet(
    query: CodeActionQuery, diag: DiagnosticContext, field: str
) -> str | None:
    """Build the snippet body (``field: ${1:...}``) for the missing field, or ``None``.

    Mirrors completion's key snippet so the quickfix lands with the same
    tabstop + example placeholder. Returns ``None`` when any of data, the
    resolver, the parent path, or the field's schema info is unavailable
    so the caller can fall back to a plain text edit.
    """
    data = query.data
    resolver = query.schema_resolver
    parent_path = diag.data.parent_path
    if data is None or resolver is None or parent_path is None:
        return None
    resolved = resolver.resolve_children(data, parent_path)
    raw = resolved.raw_children.get(field)
    navigator = resolved.navigator
    if (
        raw is not None
        and navigator is not None
        and (multiline := build_snippet(field, raw, navigator, lambda _path: None)) is not None
    ):
        return multiline
    field_doc = resolved.children.get(field)
    if field_doc is None:
        return None
    return scalar_key_snippet(field, field_doc)


SLA_TIME_COLUMN_PLACEHOLDER = "<schema>.<table>.<column>"


def add_value_ext_deadline_actions(query: CodeActionQuery) -> list[CodeActionInfo]:
    """Offer ``valueExt:`` insertion on retention SLA entries lacking it.

    One action per applicable entry; the LSP client filters by cursor range.
    Skips entries that already have ``valueExt`` and entries whose ``property``
    isn't ``retention``.  The inserted line carries a comment naming this as
    the GDPR-style delete-after deadline so authors know what to fill in.
    """
    return add_value_ext_actions(
        query,
        property_kind="retention",
        title="Add valueExt (delete-after deadline)",
        default_value="365",
        comment="delete-after deadline",
    )


def add_value_ext_tolerance_actions(query: CodeActionQuery) -> list[CodeActionInfo]:
    """Offer ``valueExt:`` insertion on frequency SLA entries lacking it.

    Mirror of :func:`add_value_ext_deadline_actions` for frequency entries
    where ``valueExt`` is the cadence tolerance window.  Skips retention and
    other property kinds.
    """
    return add_value_ext_actions(
        query,
        property_kind="frequency",
        title="Add valueExt (tolerance window)",
        default_value="1",
        comment="tolerance window",
    )


def add_value_ext_actions(
    query: CodeActionQuery, *, property_kind: str, title: str, default_value: str, comment: str
) -> list[CodeActionInfo]:
    """Build value-ext-insertion actions for every SLA entry matching *property_kind*.

    Each action's edit inserts ``valueExt: <default_value>  # <comment>`` at the
    line after the entry's block.  The LSP client decides which actions to
    surface based on the cursor; we just emit one per applicable entry.
    """
    if query.data is None or query.source_map is None:
        return []
    sla_entries = query.data.get("slaProperties")
    if not isinstance(sla_entries, list):
        return []
    actions: list[CodeActionInfo] = []
    for index, entry in enumerate(sla_entries):
        if not isinstance(entry, dict):
            continue
        typed_entry = cast("dict[str, object]", entry)
        if typed_entry.get("property") != property_kind:
            continue
        if typed_entry.get("valueExt") is not None:
            continue
        block = query.source_map.range_for_block(f"slaProperties.{index}")
        if block is None:
            continue
        insert_line = block.end_line + 1
        insert_range = TextRange(start_line=insert_line, start_col=1, end_line=insert_line, end_col=1)
        new_text = f"    valueExt: {default_value}  # {comment}\n"
        actions.append(
            CodeActionInfo(
                title=title,
                kind=CodeActionKind.QUICK_FIX,
                uri=query.uri,
                edits=(TextEditInfo(range=insert_range, new_text=new_text),),
            )
        )
    return actions


def sla_missing_time_column_actions(
    query: CodeActionQuery, diag: DiagnosticContext
) -> list[CodeActionInfo]:
    """Insert a stub ``slaProperties`` block before ``schema:``.

    The lint rule pre-resolves a fully-qualified element string in
    ``DiagnosticData.suggested_value`` — ``schemaB.tableB.event_ts`` when a
    time-like column exists in any schema of the contract, or
    ``SLA_TIME_COLUMN_PLACEHOLDER`` when none qualifies.
    """
    element = diag.data.suggested_value or SLA_TIME_COLUMN_PLACEHOLDER
    is_placeholder = element == SLA_TIME_COLUMN_PLACEHOLDER
    insert_range, appends_to_existing_block = sla_time_column_insert(query)
    title = (
        "Add SLA time column (edit element before saving)"
        if is_placeholder
        else f"Add SLA time column ('{element}')"
    )
    new_text = (
        render_time_column_entry(element)
        if appends_to_existing_block
        else render_time_column_block(element)
    )
    return [
        CodeActionInfo(
            title=title,
            kind=CodeActionKind.QUICK_FIX,
            uri=query.uri,
            edits=(TextEditInfo(range=insert_range, new_text=new_text),),
            is_preferred=not is_placeholder,
        )
    ]


def sla_time_column_insert(query: CodeActionQuery) -> tuple[TextRange, bool]:
    """Return the insertion range and whether it appends to an existing SLA block."""
    if query.source_map is not None:
        sla_block = query.source_map.range_for_block("slaProperties")
        if sla_block is not None:
            insert_line = sla_block.end_line + 1
            return TextRange(start_line=insert_line, start_col=1, end_line=insert_line, end_col=1), True
    return sla_block_insert_range(query), False


def sla_block_insert_range(query: CodeActionQuery) -> TextRange:
    """Compute the insertion range for the new ``slaProperties`` block.

    Prefers the start line of the top-level ``schema:`` block — that puts
    the new entry between contract metadata and the schema, matching the
    layout ``render_sla_block`` produces for the scaffold path. Falls back
    to end-of-file when no ``schema:`` is parseable.
    """
    if query.source_map is not None:
        schema_block = query.source_map.range_for_block("schema")
        if schema_block is not None:
            return TextRange(
                start_line=schema_block.start_line,
                start_col=1,
                end_line=schema_block.start_line,
                end_col=1,
            )
    last_line = len(query.content.splitlines()) + 1
    return TextRange(start_line=last_line, start_col=1, end_line=last_line, end_col=1)


def render_time_column_block(element: str) -> str:
    """Render the canonical ``slaProperties`` block with a time-column entry.

    Mirrors the shape produced by ``render_sla_block`` for the scaffold
    path so contracts created via either route look identical. Trailing
    blank line keeps a clean separator from whatever follows.
    """
    return f"slaProperties:\n{render_time_column_entry(element)}\n"


def render_time_column_entry(element: str) -> str:
    """Render one canonical ``slaProperties`` list item."""
    return f"  - property: latency\n    value: 24\n    unit: hour\n    element: {element}\n"


def inline_fix_actions(query: CodeActionQuery, diag: DiagnosticContext) -> list[CodeActionInfo]:
    """Translate the diagnostic's pre-computed ``fixes`` into ``CodeActionInfo``.

    Rules attach these via ``DiagnosticBuilder.fix(...)`` when they already
    know the local context for the fix (insertion range, default value).
    Snippet fixes are routed through the ``INSERT_SNIPPET_AT`` command so
    tab stops survive in the editor; plain edits become ``WorkspaceEdit``.
    """
    return [fix_action_to_code_action(query.uri, fix) for fix in diag.data.fixes]


def fix_action_to_code_action(uri: str, fix: FixAction) -> CodeActionInfo:
    """Map a single ``FixAction`` onto a ``CodeActionInfo`` for the LSP layer.

    Snippet edits live in 1-indexed domain coordinates; the LSP wire is
    0-indexed, so the line/col get shifted by one when packing the command
    arguments.
    """
    if fix.snippet is not None:
        return CodeActionInfo(
            title=fix.title,
            kind=CodeActionKind.QUICK_FIX,
            uri=uri,
            command_ref=CommandRef(
                command_id=CommandId.INSERT_SNIPPET_AT,
                arguments=(uri, fix.snippet.line - 1, fix.snippet.col - 1, fix.snippet.snippet_text),
            ),
            is_preferred=fix.is_preferred,
        )
    return CodeActionInfo(
        title=fix.title,
        kind=CodeActionKind.QUICK_FIX,
        uri=uri,
        edits=fix.edits,
        is_preferred=fix.is_preferred,
    )


FixGenerator = Callable[[CodeActionQuery, DiagnosticContext], list[CodeActionInfo]]


def suggested_value_action(title_template: str) -> FixGenerator:
    """Create a fix generator that replaces text with the suggested value."""

    def generate(query: CodeActionQuery, diag: DiagnosticContext) -> list[CodeActionInfo]:
        if not diag.data.suggested_value:
            return []
        title = title_template.format(value=diag.data.suggested_value)
        return [
            CodeActionInfo(
                title=title,
                kind=CodeActionKind.QUICK_FIX,
                uri=query.uri,
                edits=(TextEditInfo(range=diag.range, new_text=diag.data.suggested_value),),
                is_preferred=True,
            )
        ]

    return generate


def required_false_primary_key_actions(
    query: CodeActionQuery, diag: DiagnosticContext
) -> list[CodeActionInfo]:
    """Generate a quick fix that makes an offending primary-key column required."""
    if diag.data.required_range is None:
        return []
    return [
        CodeActionInfo(
            title="Set required: true",
            kind=CodeActionKind.QUICK_FIX,
            uri=query.uri,
            edits=(TextEditInfo(range=diag.data.required_range, new_text="true"),),
            is_preferred=True,
        )
    ]


def validation_actions(query: CodeActionQuery, diag: DiagnosticContext) -> list[CodeActionInfo]:
    """Generate 'Accept database schema' and 'Accept contract' actions for validation findings.

    The diagnostic's own range points at the column ``name:`` value (chosen so
    the red squiggle highlights the column). Accepting the database schema must
    instead rewrite the *sibling* key that actually differs — ``logicalType:``
    for type drift, ``required:`` for nullability drift — so we locate that
    sibling via the source map. When no valid edit can be produced (no source
    map, sibling key not present, or an unsupported drift shape like PK/unique
    mismatches we don't yet fix automatically), we skip the accept-database
    action rather than emit a broken one.
    """
    label = VALIDATION_LABELS.get(diag.data.kind, "change")
    field = diag.data.field_name or "field"
    actions: list[CodeActionInfo] = []
    accept_db_edit = build_accept_db_edit(query, diag)
    if accept_db_edit is not None:
        actions.append(
            CodeActionInfo(
                title=f"Accept database schema ({label} on '{field}')",
                kind=CodeActionKind.QUICK_FIX,
                uri=query.uri,
                edits=(accept_db_edit,),
                is_preferred=True,
            )
        )
    actions.append(
        CodeActionInfo(
            title=f"Accept contract (keep '{field}' as-is)",
            kind=CodeActionKind.QUICK_FIX,
            uri=query.uri,
            edits=(),
        )
    )
    return actions


def build_accept_db_edit(query: CodeActionQuery, diag: DiagnosticContext) -> TextEditInfo | None:
    """Build the text edit that pulls the database value into the right YAML key."""
    field_name = diag.data.field_name
    if not field_name:
        return None
    builder = ACCEPT_DB_EDIT_BUILDERS.get(diag.data.kind)
    if builder is None:
        return None
    return builder(query, diag, field_name)


def build_type_change_edit(
    query: CodeActionQuery, diag: DiagnosticContext, field_name: str
) -> TextEditInfo | None:
    """Replace the ``logicalType:`` value with the DB-reported type."""
    new_text = diag.data.suggested_value
    if not new_text:
        return None
    value_range = find_column_sibling_value_range(query, field_name, "logicalType")
    if value_range is None:
        return None
    return TextEditInfo(range=value_range, new_text=new_text)


def build_nullability_change_edit(
    query: CodeActionQuery, diag: DiagnosticContext, field_name: str
) -> TextEditInfo | None:
    """Replace the ``required:`` value with ``true``/``false`` for a nullability finding."""
    new_text = required_value_for_db(diag.data.db_value)
    if new_text is None:
        return None
    value_range = find_column_sibling_value_range(query, field_name, "required")
    if value_range is None:
        return None
    return TextEditInfo(range=value_range, new_text=new_text)


AcceptDbEditBuilder = Callable[[CodeActionQuery, DiagnosticContext, str], "TextEditInfo | None"]

ACCEPT_DB_EDIT_BUILDERS: dict[DiagnosticKind, AcceptDbEditBuilder] = {
    DiagnosticKind.VALIDATE_TYPE_CHANGED: build_type_change_edit,
    DiagnosticKind.VALIDATE_NULLABILITY_CHANGED: build_nullability_change_edit,
}


def find_column_sibling_value_range(
    query: CodeActionQuery, field_name: str, sibling_key: str
) -> TextRange | None:
    """Locate a sibling key's value range inside a column property block.

    Walks the source map looking for a ``...properties.N.name`` whose value
    matches *field_name*, then asks the map for the range of the same block's
    ``<sibling_key>`` value. Returns None if either side is missing.
    """
    if query.source_map is None:
        return None
    for path, value_text, _value_range in iter_named_values_from_parts(
        query.source_map, query.content, is_column_name_path
    ):
        if value_text != field_name:
            continue
        block_prefix = path.rsplit(".", 1)[0]
        return query.source_map.range_for_value(f"{block_prefix}.{sibling_key}")
    return None


def required_value_for_db(db_value: str | None) -> str | None:
    """Translate a nullability finding's ``db_value`` into the YAML ``required`` literal.

    The validation layer emits ``"NOT NULL"`` / ``"NULL"`` for nullable_mismatch
    findings, but PK / unique drift (also mapped to
    ``VALIDATE_NULLABILITY_CHANGED``) produces values like ``"PRIMARY KEY"``
    which don't map onto ``required`` — return None for those so the caller
    skips the accept-database action instead of writing a junk value.
    """
    if db_value == "NOT NULL":
        return "true"
    if db_value == "NULL":
        return "false"
    return None


CONTRACT_ID_RE = re.compile(r"^id:\s*(.+)$", re.MULTILINE)
SCHEMA_NAME_RE = re.compile(SCHEMA_NAME_PATTERN, re.MULTILINE)
PROP_BLOCK_RE = re.compile(r"^(\s+)-\s*name:\s*(.+)$")
QUALITY_SPEC_COMMENT = '# Add your first check below or via the "Add dataset check" lens.'


def generate_quality_spec_content(contract_id: str, dataset: str, spec_id: str, owner: str) -> str:
    """Build the YAML content for a new quality spec file."""
    return (
        f"kind: QualitySpec\n"
        f"id: {spec_id}\n"
        f'version: "1.0.0"\n'
        f"targetContract: {contract_id}\n"
        f"dataset: {dataset}\n"
        f"owner: {owner}\n"
        f"quality:\n"
        f"  {QUALITY_SPEC_COMMENT}\n"
    )


def generate_data_contract_content(
    contract_id: str, tables: tuple[tuple[TableIdentifier, tuple[ColumnDef, ...]], ...]
) -> str:
    """Build the YAML content for a new DataContract from introspected tables.

    Emits canonical ODCS v3.1 structure with one schema object per table,
    each containing ``properties`` entries for its columns. Prefills a
    ``slaProperties`` entry pointing at the first time-like column discovered
    across the introspected tables, so the scaffold passes SLA time-column linting.
    """
    header = (
        f"kind: DataContract\n"
        f"apiVersion: v3.1.0\n"
        f"id: {contract_id}\n"
        f'version: "1.0.0"\n'
        f"status: active\n"
        f"domain: {contract_id}\n"
        f"\n"
        f"{render_sla_block(tables)}"
        f"schema:\n"
    )
    schema_blocks: list[str] = []
    for table, columns in tables:
        block = f"  - name: {table.schema}.{table.table}\n    properties:\n"
        property_lines: list[str] = []
        for column in columns:
            lines = [
                f"      - name: {column.name}",
                f"        logicalType: {column.logical_type.value}",
                f"        required: {'true' if not column.nullable else 'false'}",
            ]
            if column.primary_key:
                lines.append("        primaryKey: true")
            property_lines.append("\n".join(lines))
        block += "\n".join(property_lines)
        schema_blocks.append(block)
    return header + "\n".join(schema_blocks) + "\n"


def render_sla_block(tables: tuple[tuple[TableIdentifier, tuple[ColumnDef, ...]], ...]) -> str:
    """Render an ``slaProperties`` block pinned to the first time-like column found.

    Falls back to a placeholder element (``<schema>.<table>.<column>``) when
    none of the introspected tables expose a timestamp/date column, so the
    user still gets the full structure to edit rather than having to guess
    the shape.
    """
    element = first_timeseries_element(tables) or placeholder_element(tables)
    if element is None:
        return ""
    return (
        "slaProperties:\n"
        "  - property: latency\n"
        "    value: 24\n"
        "    unit: hour\n"
        f"    element: {element}\n"
        "\n"
    )


def first_timeseries_element(
    tables: tuple[tuple[TableIdentifier, tuple[ColumnDef, ...]], ...],
) -> str | None:
    """Return the qualified element of the first time-like column across *tables*."""
    for table, columns in tables:
        for column in columns:
            if column.logical_type in TIME_LIKE_LOGICAL_TYPES:
                return f"{table.schema}.{table.table}.{column.name}"
    return None


def placeholder_element(tables: tuple[tuple[TableIdentifier, tuple[ColumnDef, ...]], ...]) -> str | None:
    """Return ``<schema>.<table>.<first-column>`` for the first table, or None if empty."""
    for table, columns in tables:
        if columns:
            return f"{table.schema}.{table.table}.{columns[0].name}"
    return None


def extract_contract_metadata(content: str) -> tuple[str, str]:
    """Extract contract ID and dataset name from content.

    Returns:
        (contract_id, dataset) tuple, both empty strings if not found.
    """
    contract_id = ""
    if (match := CONTRACT_ID_RE.search(content)) is not None:
        contract_id = match.group(1).strip()
    dataset = ""
    if (match := SCHEMA_NAME_RE.search(content)) is not None:
        dataset = match.group(1).strip()
    return contract_id, dataset


def finalize_block(name: str, start_line: int, lines: list[str], end_line: int) -> PropertyBlock:
    """Create a PropertyBlock from accumulated lines."""
    return PropertyBlock(name=name, start_line=start_line, end_line=end_line, text="".join(lines))


def parse_property_blocks(content: str) -> list[PropertyBlock]:
    """Parse YAML content into property blocks within the first properties section."""
    prop_lines = extract_properties_section(content)
    if not prop_lines:
        return []

    return split_into_blocks(prop_lines)


def extract_properties_section(content: str) -> list[tuple[int, str]]:
    """Return (line_number, line) pairs belonging to the first properties: section."""
    lines: list[tuple[int, str]] = []
    in_section = False
    for line_num, line in enumerate(content.splitlines(keepends=True), start=1):
        stripped = line.strip()
        if stripped == "properties:":
            in_section = True
            continue
        if not in_section:
            continue
        indent = len(line) - len(line.lstrip())
        if stripped and indent == 0:
            break
        lines.append((line_num, line))
    return lines


def is_block_header(match: re.Match[str] | None, indent: int, prop_indent: int | None) -> bool:
    """Check whether a line starts a new property block at the expected indentation."""
    return match is not None and (prop_indent is None or indent == prop_indent)


def flush_pending_block(
    blocks: list[PropertyBlock], name: str, start: int, lines: list[str], end_line: int
) -> None:
    """Append a PropertyBlock to *blocks* if there are accumulated lines."""
    if lines:
        blocks.append(finalize_block(name, start, lines, end_line))


def split_into_blocks(prop_lines: list[tuple[int, str]]) -> list[PropertyBlock]:
    """Split property-section lines into individual PropertyBlock entries."""
    prop_indent: int | None = None
    blocks: list[PropertyBlock] = []
    current_name = ""
    current_start = 0
    current_lines: list[str] = []

    for line_num, line in prop_lines:
        indent = len(line) - len(line.lstrip())
        match = PROP_BLOCK_RE.match(line)

        if not is_block_header(match, indent, prop_indent):
            if current_lines:
                current_lines.append(line)
            continue

        flush_pending_block(blocks, current_name, current_start, current_lines, line_num - 1)
        if prop_indent is None:
            prop_indent = indent
        assert match is not None  # guaranteed by is_block_header
        current_name = match.group(2).strip()
        current_start = line_num
        current_lines = [line]

    flush_pending_block(
        blocks, current_name, current_start, current_lines, current_start + len(current_lines) - 1
    )
    return blocks


def drift_column_added_actions(query: CodeActionQuery, diag: DiagnosticContext) -> list[CodeActionInfo]:
    """Insert a new property block for a column that was added in the database."""
    field_name = diag.data.field_name
    if not field_name or not query.source_map:
        return []

    # Find the last property in the schema to insert after it. Use the
    # sequence-item path (without ``.name``) so ``range_for_block`` returns
    # the full column block — otherwise the insertion point lands inside
    # the previous column, between its ``name:`` and its other fields.
    property_paths = [
        path.removesuffix(".name")
        for path in query.source_map.key_paths()
        if ".properties." in path and path.endswith(".name")
    ]
    if not property_paths:
        return []

    last_prop_path = property_paths[-1]
    last_block = query.source_map.range_for_block(last_prop_path)
    if not last_block:
        return []

    db_type = diag.data.db_value or "string"
    new_block = f"\n        - name: {field_name}\n          logicalType: {db_type}\n"

    insert_range = TextRange(
        start_line=last_block.end_line + 1, start_col=1, end_line=last_block.end_line + 1, end_col=1
    )

    return [
        CodeActionInfo(
            title=f"Add property '{field_name}' from database",
            kind=CodeActionKind.QUICK_FIX,
            uri=query.uri,
            edits=(TextEditInfo(range=insert_range, new_text=new_block),),
            is_preferred=True,
        )
    ]


def find_column_name_range(
    query: CodeActionQuery, field_name: str
) -> tuple[TextRange, TextRange] | None:
    """Locate a column property block by name. Returns ``(value_range, block_range)``.

    ``block_range`` covers the entire sequence-item (the full ``- name: foo``
    block including all nested children), not just the ``name:`` pair. That
    makes it safe to use as the deletion range for "remove property" fixes.
    """
    if query.source_map is None:
        return None
    for path, value_text, value_range in iter_named_values_from_parts(
        query.source_map, query.content, path_ends_with_name
    ):
        if value_text != field_name:
            continue
        item_path = path.removesuffix(".name")
        block_range = query.source_map.range_for_block(item_path)
        if block_range is None:
            return None
        return value_range, block_range
    return None


def path_ends_with_name(path: str) -> bool:
    """Return True for any source-map key path ending in ``.name``."""
    return path.endswith(".name")


def close_db_column_match(query: CodeActionQuery, diag: DiagnosticContext) -> str | None:
    """Return the closest-matching DB column name for a REMOVED drift finding, if any.

    Consults the introspection cache using the diagnostic's ``schema_name`` so
    we only suggest renames within the same table. ``field_name`` must be the
    contract's current (typo) column name.
    """
    cache = query.introspection_cache
    field_name = diag.data.field_name
    schema_name = diag.data.schema_name
    if cache is None or not field_name or not schema_name:
        return None
    db_table = cache.get_table(schema_name)
    if db_table is None:
        return None
    db_names = [col.name for col in db_table.columns]
    matches = get_close_matches(field_name, db_names, n=1, cutoff=0.6)
    return matches[0] if matches else None


def drift_column_removed_actions(
    query: CodeActionQuery, diag: DiagnosticContext
) -> list[CodeActionInfo]:
    """Quick-fix: rename (preferred) or remove a column that no longer exists in the DB."""
    field_name = diag.data.field_name
    if not field_name:
        return []
    ranges = find_column_name_range(query, field_name)
    if ranges is None:
        return []
    value_range, block_range = ranges

    actions: list[CodeActionInfo] = []
    suggestion = close_db_column_match(query, diag)
    if suggestion is not None:
        actions.append(
            CodeActionInfo(
                title=f"Rename '{field_name}' to '{suggestion}'",
                kind=CodeActionKind.QUICK_FIX,
                uri=query.uri,
                edits=(TextEditInfo(range=value_range, new_text=suggestion),),
                is_preferred=True,
            )
        )
    actions.append(
        CodeActionInfo(
            title=f"Remove property '{field_name}'",
            kind=CodeActionKind.QUICK_FIX,
            uri=query.uri,
            edits=(TextEditInfo(range=block_range, new_text=""),),
            is_preferred=suggestion is None,
        )
    )
    return actions


DIAGNOSTIC_DISPATCH: dict[DiagnosticKind, FixGenerator] = {}


def register_dispatch() -> None:
    """Populate the dispatch table after all fix generators are defined."""
    DIAGNOSTIC_DISPATCH.update(
        {
            DiagnosticKind.UNKNOWN_FIELD: unknown_field_actions,
            DiagnosticKind.MISSING_REQUIRED_FIELD: missing_field_actions,
            DiagnosticKind.TYPE_MISMATCH: suggested_value_action("Replace with '{value}'"),
            DiagnosticKind.INVALID_ENUM: suggested_value_action("Did you mean '{value}'?"),
            DiagnosticKind.SLA_INVALID_ELEMENT: suggested_value_action("Did you mean '{value}'?"),
            DiagnosticKind.SLA_MISSING_TIME_COLUMN: sla_missing_time_column_actions,
            DiagnosticKind.VALIDATE_COLUMN_ADDED: drift_column_added_actions,
            DiagnosticKind.VALIDATE_COLUMN_REMOVED: drift_column_removed_actions,
            DiagnosticKind.VALIDATE_TYPE_CHANGED: validation_actions,
            DiagnosticKind.VALIDATE_NULLABILITY_CHANGED: validation_actions,
            DiagnosticKind.SQL_UNKNOWN_COLUMN: suggested_value_action("Did you mean '{value}'?"),
            DiagnosticKind.NAMING_VIOLATION: suggested_value_action("Rename to '{value}'"),
            DiagnosticKind.DATASOURCE_TABLE_NOT_FOUND: suggested_value_action("Did you mean '{value}'?"),
            DiagnosticKind.TARGET_CONTRACT_NOT_FOUND: suggested_value_action("Did you mean '{value}'?"),
            DiagnosticKind.DATASET_MISMATCH: suggested_value_action("Replace with '{value}'"),
            DiagnosticKind.UNKNOWN_COLUMN_REF: suggested_value_action("Did you mean '{value}'?"),
            DiagnosticKind.REQUIRED_FALSE_PRIMARY_KEY: required_false_primary_key_actions,
        }
    )


def generate_quality_spec_action(query: CodeActionQuery) -> CodeActionInfo | None:
    """Generate a 'Create Quality Spec' source action for DataContract files.

    Routes through the workspace command handler so the user gets prompted
    for a spec name and the file lands in the quality directory.
    """
    if "kind: DataContract" not in query.content:
        return None
    contract_id, dataset = extract_contract_metadata(query.content)
    return CodeActionInfo(
        title="Create Quality Spec",
        kind=CodeActionKind.SOURCE,
        uri=query.uri,
        command_ref=CommandRef(
            command_id=CommandId.GENERATE_QUALITY_SPEC, arguments=(contract_id, dataset)
        ),
    )


def build_sort_fields_action(query: CodeActionQuery, cache: IntrospectionCache) -> CodeActionInfo | None:
    """Build a sort-fields action if any schema's columns are not in DB ordinal order."""
    _, schema_name = extract_contract_metadata(query.content)

    db_table = cache.get_table(schema_name)
    if db_table is None:
        return None

    db_order = {col.name: col.position for col in db_table.columns}
    blocks = parse_property_blocks(query.content)
    if not blocks:
        return None

    current_order = [b.name for b in blocks]
    sorted_order = sorted(current_order, key=lambda n: db_order.get(n, float("inf")))
    if current_order == sorted_order:
        return None

    sorted_blocks = sorted(blocks, key=lambda b: db_order.get(b.name, float("inf")))
    new_text = "".join(b.text for b in sorted_blocks)

    first_block = blocks[0]
    last_block = blocks[-1]
    edit_range = TextRange(
        start_line=first_block.start_line, start_col=1, end_line=last_block.end_line + 1, end_col=1
    )

    return CodeActionInfo(
        title="Sort fields by DB column order",
        kind=CodeActionKind.SOURCE,
        uri=query.uri,
        edits=(TextEditInfo(range=edit_range, new_text=new_text),),
    )


register_dispatch()
