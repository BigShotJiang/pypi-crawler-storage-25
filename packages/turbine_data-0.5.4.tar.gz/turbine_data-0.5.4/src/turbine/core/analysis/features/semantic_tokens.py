"""Semantic token extraction — highlight type values in YAML and syntax in SQL.

Deep module owning the port protocol, query/result types, and pure
tokenization logic.
"""

from dataclasses import dataclass

from turbine.core.analysis.model import SemanticTokenType
from turbine.core.analysis.tokenization import SqlTokenType, tokenize_sql
from turbine.core.building_blocks import SourceMap


@dataclass(frozen=True, slots=True)
class SemanticTokenInfo:
    """One semantic token emitted by the analysis layer for syntax coloring.

    The presentation layer delta-encodes these into the LSP wire format.

    Attributes:
        line: 0-indexed line number.
        col: 0-indexed column offset of the token's first character.
        length: Number of characters the token spans.
        token_type: Category that determines the color/style applied.

    Example::

        tok = SemanticTokenInfo(line=1, col=0, length=11, token_type=SemanticTokenType.KEYWORD)
    """

    line: int
    col: int
    length: int
    token_type: SemanticTokenType


TYPE_VALUE_KEYS = frozenset({"logicalType", "physicalType"})

SQL_TO_SEMANTIC: dict[SqlTokenType, SemanticTokenType] = {
    SqlTokenType.KEYWORD: SemanticTokenType.KEYWORD,
    SqlTokenType.VARIABLE: SemanticTokenType.VARIABLE,
    SqlTokenType.PARAMETER: SemanticTokenType.PARAMETER,
    SqlTokenType.OPERATOR: SemanticTokenType.OPERATOR,
    SqlTokenType.STRING: SemanticTokenType.STRING,
    SqlTokenType.NUMBER: SemanticTokenType.NUMBER,
    SqlTokenType.COMMENT: SemanticTokenType.COMMENT,
}


def sql_tokens_to_semantic(content: str) -> tuple[SemanticTokenInfo, ...]:
    """Classify SQL + Jinja2 tokens for semantic highlighting."""
    sql_tokens = tokenize_sql(content)
    return tuple(
        SemanticTokenInfo(
            line=t.line, col=t.col, length=t.length, token_type=SQL_TO_SEMANTIC[t.token_type]
        )
        for t in sql_tokens
    )


def yaml_type_tokens(source_map: SourceMap) -> tuple[SemanticTokenInfo, ...]:
    """Extract type-value tokens from a YAML source map."""
    tokens: list[SemanticTokenInfo] = []
    for dotted in source_map.key_paths():
        key_name = dotted.rsplit(".", 1)[-1] if "." in dotted else dotted
        if key_name not in TYPE_VALUE_KEYS:
            continue
        value_range = source_map.range_for_value(dotted)
        if value_range is None:
            continue
        tokens.append(
            SemanticTokenInfo(
                line=value_range.start_line - 1,  # 1-indexed → 0-indexed
                col=value_range.start_col - 1,  # 1-indexed → 0-indexed
                length=value_range.end_col - value_range.start_col,
                token_type=SemanticTokenType.TYPE,
            )
        )

    tokens.sort(key=lambda t: (t.line, t.col))
    return tuple(tokens)
