"""Cursor-role classifier — the text-side primitive of the completion lattice.

``detect_role`` decides what the user is typing on the cursor line, derived
from the line text alone with no consultation of tree-sitter or the YAML
parser. Four roles: ``KEY``, ``VALUE``, ``DASH_ITEM``, ``EMPTY``. Comment
truncation, quoted-string colon-skipping, dash-recursion on
``- key: value`` lines, and inline-flow bracket detection are all hidden
inside this module — callers see two scalars in, one enum out.
"""

from dataclasses import dataclass, replace
from enum import StrEnum

__all__ = ["CursorRole", "detect_role"]


class CursorRole(StrEnum):
    """What the user is typing on the cursor line."""

    KEY = "key"
    VALUE = "value"
    DASH_ITEM = "dash_item"
    EMPTY = "empty"


def detect_role(line_text: str, col: int) -> CursorRole:
    """Classify the cursor position from the cursor line alone. ``col`` is 1-indexed.

    Priority order (top wins):

    1. blank/whitespace-only line → EMPTY.
    2. cursor inside a ``#`` comment outside quotes → EMPTY.
    3. cursor inside an inline-flow ``[...]``/``{...}`` outside quotes → DASH_ITEM.
    4. line is ``<indent>- [content]``: at or before the position right after
       ``- `` → DASH_ITEM; otherwise recurse on the inner content with an
       adjusted column.
    5. find the first colon outside quotes/brackets: no colon, or cursor at or
       before colon → KEY; cursor past colon → VALUE.
    """
    if not line_text.strip():
        role = CursorRole.EMPTY
    else:
        state = scan_to_cursor(line_text, col)
        if state.in_comment:
            role = CursorRole.EMPTY
        elif state.bracket_depth > 0:
            role = CursorRole.DASH_ITEM
        else:
            role = detect_non_comment_role(line_text, col)
    return role


def detect_non_comment_role(line_text: str, col: int) -> CursorRole:
    """Classify a non-empty, non-comment cursor line."""
    inner_start = dash_inner_start(line_text)
    if inner_start is not None:
        if col <= inner_start:
            return CursorRole.DASH_ITEM
        offset = inner_start - 1
        return detect_role(line_text[offset:], col - offset)
    colon_col = find_separating_colon(line_text)
    if colon_col is None or col <= colon_col:
        return CursorRole.KEY
    return CursorRole.VALUE


@dataclass(frozen=True, slots=True)
class CursorContext:
    """Lexical state of the line up to (but excluding) the 1-indexed cursor column."""

    in_comment: bool
    bracket_depth: int


@dataclass(frozen=True, slots=True)
class LineScanState:
    """Mutable-looking lexical scan state represented immutably."""

    in_single: bool = False
    in_double: bool = False
    in_comment: bool = False
    bracket_depth: int = 0


def scan_to_cursor(line_text: str, col: int) -> CursorContext:
    """Walk *line_text* up to *col* and return whether the cursor sits in a comment or bracket."""
    state = LineScanState()
    for char in line_text[: max(col - 1, 0)]:
        state = advance_scan_state(state, char)
    return CursorContext(in_comment=state.in_comment, bracket_depth=state.bracket_depth)


def advance_scan_state(state: LineScanState, char: str) -> LineScanState:
    """Advance the single-line YAML scanner by one character."""
    next_state = state
    if not state.in_comment:
        if char == "'" and not state.in_double:
            next_state = replace(state, in_single=not state.in_single)
        elif char == '"' and not state.in_single:
            next_state = replace(state, in_double=not state.in_double)
        elif not state_is_quoted(state):
            next_state = advance_plain_scan_state(state, char)
    return next_state


def advance_plain_scan_state(state: LineScanState, char: str) -> LineScanState:
    """Advance scanner state for a character outside quotes and comments."""
    next_state = state
    if char == "#":
        next_state = replace(state, in_comment=True)
    elif char in "[{":
        next_state = replace(state, bracket_depth=state.bracket_depth + 1)
    elif char in "]}":
        next_state = replace(state, bracket_depth=state.bracket_depth - 1)
    return next_state


def state_is_quoted(state: LineScanState) -> bool:
    """Return True when the scanner is inside either quote flavor."""
    return state.in_single or state.in_double


def dash_inner_start(line_text: str) -> int | None:
    """Return the 1-indexed column right after a ``<indent>- `` prefix, or None when absent."""
    stripped = line_text.lstrip(" ")
    if not stripped.startswith("- "):
        return None
    leading = len(line_text) - len(stripped)
    return leading + 3


def find_separating_colon(line_text: str) -> int | None:
    """Return the 1-indexed column of the first colon outside quotes, brackets, and comments."""
    state = LineScanState()
    colon_col: int | None = None
    for index, char in enumerate(line_text):
        if char == "#" and state_is_plain(state):
            break
        if char == ":" and state_is_plain(state) and state.bracket_depth == 0:
            colon_col = index + 1
            break
        state = advance_scan_state(state, char)
    return colon_col


def state_is_plain(state: LineScanState) -> bool:
    """Return True when the scanner is outside quotes and comments."""
    return not state.in_comment and not state_is_quoted(state)
