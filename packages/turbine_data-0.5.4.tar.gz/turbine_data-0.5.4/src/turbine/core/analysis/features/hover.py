"""Hover — show field documentation on hover.

Deep module owning the port protocol, query/result types, and pure
hover-content logic.
"""

import re
from dataclasses import dataclass

from turbine.core.analysis.context import SqlFileContext
from turbine.core.building_blocks import TextRange
from turbine.core.common import ColumnDef, FieldDoc, SqlCheckConfig
from turbine.core.contract import ProjectIndex


@dataclass(frozen=True, slots=True)
class HoverInfo:
    """Hover tooltip shown when a user hovers over a symbol in a contract file.

    Wraps markdown-formatted content (e.g. field docs, type info) together with
    the text range to highlight in the editor.

    Attributes:
        content: Markdown string displayed inside the hover popup.
        range: Text range to highlight in the editor; ``None`` means the editor
            picks its own highlight range based on cursor position.

    Example::

        info = HoverInfo(
            content="**name** — the customer's full name",
            range=TextRange(line=3, col=4, end_line=3, end_col=8),
        )
    """

    content: str
    range: TextRange | None = None


@dataclass(frozen=True, slots=True)
class HoverQuery:
    """Captures cursor state for a hover documentation request.

    Attrs:
        uri: Document URI (file path or scheme-prefixed).
        content: Full document text at the time of the request.
        line: 1-indexed line number of the cursor.
        col: 1-indexed column number of the cursor.
    """

    uri: str
    content: str
    line: int
    col: int


JINJA_PARAM_RE = re.compile(r'\{\{\s*var\(\s*["\']([\w]+)["\']')
JINJA_VAR_RE = re.compile(r"\{\{\s*(\w+)")
WORD_RE = re.compile(r"\w+")
SCHEMA_NAME_PATH_RE = re.compile(r"^schema\.\d+\.name$")
COLUMN_NAME_PATH_RE = re.compile(r"^schema\.\d+\.properties\.\d+\.name$")


def format_allowed_values(values: tuple[str, ...], descriptions: dict[str, str]) -> str:
    """Render an ``Allowed:`` block for an enum, with per-value descriptions when present.

    Falls back to the compact ``Allowed: a | b | c`` form when no value carries
    a description, so unannotated enums render the same as before.
    """
    if not any(value in descriptions for value in values):
        return "Allowed: " + " | ".join(f"`{value}`" for value in values)
    lines = ["Allowed:"]
    for value in values:
        text = descriptions.get(value)
        lines.append(f"- `{value}` — {text}" if text else f"- `{value}`")
    return "\n".join(lines)


def format_field_hover(key_name: str, field_doc: FieldDoc) -> str:
    """Build markdown hover content from a schema field definition."""
    parts: list[str] = []

    header = f"**{key_name}**"
    if field_doc.value_type:
        header += f" `{field_doc.value_type}`"
    if field_doc.required:
        header += " (required)"
    parts.append(header)

    if field_doc.description:
        parts.append("")
        parts.append(field_doc.description)

    if field_doc.enum_values:
        parts.append("")
        parts.append(format_allowed_values(field_doc.enum_values, field_doc.enum_descriptions))

    if field_doc.examples:
        examples = ", ".join(f"`{e}`" for e in field_doc.examples)
        parts.append("")
        parts.append(f"Examples: {examples}")

    if field_doc.default is not None:
        parts.append("")
        parts.append(f"Default: `{field_doc.default}`")

    if field_doc.deprecated:
        parts.append("")
        parts.append("*Deprecated*")

    return "\n".join(parts)


def resolve_jinja_hover(line_text: str, col: int, ctx: SqlFileContext) -> HoverInfo | None:
    """Check if cursor is inside a Jinja expression and return hover info."""
    for match in JINJA_PARAM_RE.finditer(line_text):
        param_name = match.group(1)
        if match.start(1) <= col < match.end(1) and param_name in ctx.params:
            value = ctx.params[param_name]
            return HoverInfo(content=f"**var('{param_name}')** \n\nParameter value: `{value}`")

    for match in JINJA_VAR_RE.finditer(line_text):
        if match.start(1) <= col < match.end(1):
            doc = jinja_variable_doc(match.group(1), ctx)
            if doc is not None:
                return HoverInfo(content=doc)

    return None


def jinja_variable_doc(var_name: str, ctx: SqlFileContext) -> str | None:
    """Return markdown documentation for a built-in Jinja variable."""
    if var_name == "this":
        return f"**this**\n\nTarget table: `{ctx.dataset}`"
    if var_name == "since":
        return (
            "**since**\n\nIncremental lower bound as an ISO datetime string. "
            "`None` when `--since` was not passed."
        )
    if var_name == "until":
        return (
            "**until**\n\nIncremental upper bound as an ISO datetime string. "
            "`None` when `--until` was not passed."
        )
    return None


def resolve_column_hover(line_text: str, col: int, ctx: SqlFileContext) -> HoverInfo | None:
    """Check if cursor is on a column name and return hover info."""
    col_map: dict[str, ColumnDef] = {c.name: c for c in ctx.columns}

    for match in WORD_RE.finditer(line_text):
        if match.start() <= col < match.end() and (column := col_map.get(match.group())):
            parts = [f"**{column.name}** `{column.logical_type}`"]
            if not column.nullable:
                parts[0] += " (required)"
            if column.description:
                parts.append("")
                parts.append(column.description)
            return HoverInfo(content="\n".join(parts))

    return None


def resolve_value(data: dict[str, object], dotted_path: str) -> object:
    """Navigate a nested dict/list structure using a dotted path like 'schema.0.name'."""
    current: object = data
    for part in dotted_path.split("."):
        current = step_into(current, part)
        if current is None:
            return None
    return current


def step_into(current: object, part: str) -> object:
    """Take one step along a dotted path: index into a dict by key or a list by int."""
    if isinstance(current, dict):
        for existing_key, value in current.items():
            if existing_key == part:
                return value
        return None
    if isinstance(current, list) and part.isdigit():
        idx = int(part)
        return current[idx] if idx < len(current) else None
    return None


def format_schema_refs(contract_id: str, index: ProjectIndex) -> str | None:
    """Build a 'Referenced by' line listing quality specs referencing a contract."""
    specs = index.find_specs_for_contract(contract_id)
    if not specs:
        return None
    names = ", ".join(spec.metadata.contract_id for spec in specs)
    return f"Referenced by: {names}"


def sql_check_matches(config: SqlCheckConfig, pattern: re.Pattern[str]) -> str | None:
    """Return the file name if the SQL check's file contains *pattern*, else None."""
    try:
        content = config.file_path.read_text()
    except OSError:
        return None
    return config.file_path.name if pattern.search(content) else None


def format_column_refs(column_name: str, index: ProjectIndex) -> str | None:
    """Build a 'Referenced by' line listing SQL files that use a column name."""
    pattern = re.compile(rf"\b{re.escape(column_name)}\b")
    file_names: list[str] = [
        name
        for spec in index.quality_specs()
        for check in spec.checks
        if isinstance(check.config, SqlCheckConfig)
        and (name := sql_check_matches(check.config, pattern))
    ]
    if not file_names:
        return None
    return f"Referenced by: {', '.join(file_names)}"
