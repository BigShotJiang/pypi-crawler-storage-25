"""Turn a JSON Schema field definition into an LSP-style tabstop snippet.

Given the schema of a field (e.g. ``slaProperties``), produce an insert-text
string with ``${N:placeholder}`` tabstops for every required subfield.  Enum
fields become ``${N|a,b,c|}`` choice tabstops; plain scalars return ``None``
so the caller can keep the existing label-only completion behaviour.

Discriminated unions (``if/then/else`` or multi-branch ``oneOf``/``anyOf``)
are deliberately skipped: at completion time the discriminator value is not
yet typed, so we can't pick the right branch — returning ``None`` lets the
user fill in the discriminator first and then triggers another completion
round against the concrete branch schema.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from turbine.core.building_blocks import SchemaKey
from turbine.core.common import FieldDoc
from turbine.core.common.schema_walker import SchemaNavigator, SchemaNode, extract_enum_values

if TYPE_CHECKING:
    from turbine.core.common.schema_walker import SchemaNode as _SchemaNode  # noqa: F401


MAX_DEPTH = 5


@dataclass(frozen=True, slots=True)
class Prefill:
    """A prefill value the snippet builder should inject at a given path."""

    value: str


type PrefillFn = Callable[[str], Prefill | None]


@dataclass(frozen=True, slots=True)
class PrefillLookup:
    """Maps dotted schema paths to per-document prefill resolvers.

    Each resolver receives the parsed document *data* and returns a
    :class:`Prefill` or ``None``.  The snippet builder asks the lookup once
    per leaf path, so callers must ensure the lookup has been closed over the
    current *data* via ``bind(data)``.
    """

    entries: dict[str, Callable[[dict[str, object]], Prefill | None]] = field(default_factory=dict)

    def __call__(self, data: dict[str, object], path: str) -> Prefill | None:
        """Resolve *path* against the registered entries."""
        resolver = self.entries.get(path)
        if resolver is None:
            return None
        return resolver(data)

    def bind(self, data: dict[str, object]) -> PrefillFn:
        """Return a single-argument lookup that closes over *data*."""
        return lambda path: self(data, path)


class Counter:
    """Monotonic integer source for LSP tabstop indices."""

    def __init__(self) -> None:
        self.value = 0

    def next(self) -> int:
        """Advance and return the next tabstop index (1-based)."""
        self.value += 1
        return self.value


@dataclass(frozen=True, slots=True)
class SnippetContext:
    """Per-invocation state threaded through the recursive snippet builder.

    Carries the :class:`SchemaNavigator` (for $ref resolution), the prefill
    lookup, and the shared tabstop :class:`Counter`.  Passing this around
    instead of four positional arguments keeps the recursive signatures
    readable and avoids a line-length / arg-count balloon.
    """

    navigator: SchemaNavigator
    prefill: PrefillFn
    counter: Counter


def build_snippet(
    key_name: str, raw_schema: SchemaNode, navigator: SchemaNavigator, prefill: PrefillFn
) -> str | None:
    """Build the insert-text for *key_name* when its schema is *raw_schema*.

    Returns ``None`` when no worthwhile expansion exists (plain scalar,
    discriminated union, or empty-required object) so the caller can fall
    back to plain label insertion.
    """
    ctx = SnippetContext(navigator=navigator, prefill=prefill, counter=Counter())
    resolved = navigator.resolve_ref(raw_schema)
    if has_discriminator(resolved):
        return None

    if choices := choice_values(resolved):
        return f"{key_name}: {choice_tabstop(ctx.counter, choices)}"

    body = object_body_for_field(resolved, key_name, ctx)
    if body is None:
        return None
    return f"{key_name}:\n{body}"


def object_body_for_field(resolved: SchemaNode, key_name: str, ctx: SnippetContext) -> str | None:
    """Return the indented object/array body snippet for a field key, or ``None``."""
    type_ = resolved.get(SchemaKey.TYPE)
    if type_ == "array":
        items = ctx.navigator.resolve_array_items(resolved)
        if items is None or has_discriminator(items):
            return None
        body = build_object_body(items, f"{key_name}.0", ctx, depth=1, visited=set())
        return prefix_lines(body, "    ", first_prefix="  - ") if body is not None else None

    if type_ == "object":
        body = build_object_body(resolved, key_name, ctx, depth=1, visited=set())
        return prefix_lines(body, "  ", first_prefix="  ") if body is not None else None

    return None


def build_object_body(
    schema: SchemaNode, path: str, ctx: SnippetContext, *, depth: int, visited: set[int]
) -> str | None:
    """Emit one ``key: value`` line per REQUIRED subfield of *schema*.

    Recurses into nested required objects up to ``MAX_DEPTH``.  Returns
    ``None`` when the object has no required fields — the caller should fall
    back to plain label insertion in that case.  ``visited`` tracks the
    ``id()`` of schema nodes we've entered so $ref cycles can't explode.
    """
    if depth > MAX_DEPTH or id(schema) in visited:
        return None

    ordered = required_in_declaration_order(schema, ctx.navigator)
    if not ordered:
        return None

    visited = visited | {id(schema)}
    props, _ = ctx.navigator.collect_fields(schema)

    lines: list[str] = []
    for name in ordered:
        child = ctx.navigator.resolve_ref(props[name])
        value_text = build_value(child, f"{path}.{name}", ctx, depth=depth + 1, visited=visited)
        lines.append(f"{name}: {value_text}")
    return "\n".join(lines)


def build_value(
    schema: SchemaNode, path: str, ctx: SnippetContext, *, depth: int, visited: set[int]
) -> str:
    """Build the right-hand-side snippet text for one key-value pair.

    Emits a choice tabstop for enums, a ``${N:...}`` placeholder for scalars
    (using the prefill value when available, else the schema type name), and
    a nested indented block for required subobjects — falling back to a
    single placeholder when the nested object has no required fields, hits
    the recursion cap, or carries a discriminator.
    """
    if choices := choice_values(schema):
        return choice_tabstop(ctx.counter, choices)

    if block := nested_object_value(schema, path, ctx, depth, visited):
        return block
    if block := array_object_value(schema, path, ctx, depth, visited):
        return block
    placeholder = prefill_or_default(ctx.prefill, path, schema)
    return f"${{{ctx.counter.next()}:{placeholder}}}"


def nested_object_value(
    schema: SchemaNode, path: str, ctx: SnippetContext, depth: int, visited: set[int]
) -> str | None:
    """Render a nested object snippet value when the schema can expand deterministically."""
    type_name = schema.get(SchemaKey.TYPE)
    if type_name not in ("object", None) or has_discriminator(schema):
        return None
    nested = build_object_body(schema, path, ctx, depth=depth, visited=visited)
    return None if nested is None else "\n" + prefix_lines(nested, "  ", first_prefix="  ")


def array_object_value(
    schema: SchemaNode, path: str, ctx: SnippetContext, depth: int, visited: set[int]
) -> str | None:
    """Render an array item object snippet value when the item schema is deterministic."""
    if schema.get(SchemaKey.TYPE) != "array":
        return None
    items = ctx.navigator.resolve_array_items(schema)
    if items is None or has_discriminator(items):
        return None
    body = build_object_body(items, f"{path}.0", ctx, depth=depth, visited=visited)
    return None if body is None else "\n" + prefix_lines(body, "    ", first_prefix="  - ")


def choice_values(schema: SchemaNode) -> tuple[str, ...]:
    """Return a finite list of suggested values suitable for a choice tabstop.

    Only promotes *closed* sets — true ``enum`` / ``const`` / boolean — into
    the ``${N|a,b,c|}`` choice syntax.  ``examples`` are deliberately left
    out: VSCode dismisses an active choice dropdown on any keystroke
    including space, which makes open-ended fields frustrating to edit.
    The first example still surfaces via :func:`prefill_or_default` so the
    placeholder stays informative, and ``Ctrl+Space`` still pulls the full
    list through the normal value-completion path.
    """
    return extract_enum_values(schema, "")


def prefill_or_default(prefill: PrefillFn, path: str, schema: SchemaNode) -> str:
    """Pick the placeholder text for a scalar tabstop.

    Prefers a live-looked-up :class:`Prefill` value, falls back to the first
    ``examples`` entry, then to the JSON-schema ``type`` name, then to a
    generic ``value``.  The result is embedded inside ``${N:...}``.
    """
    if (prefilled := prefill(path)) is not None:
        return prefilled.value
    examples = schema.get(SchemaKey.EXAMPLES)
    if isinstance(examples, list) and examples:
        return str(examples[0])
    raw_type = schema.get(SchemaKey.TYPE)
    if isinstance(raw_type, str):
        return raw_type
    return "value"


def choice_tabstop(counter: Counter, values: tuple[str, ...]) -> str:
    """Render a ``${N|a,b,c|}`` LSP choice tabstop for a finite enum."""
    return f"${{{counter.next()}|{','.join(values)}|}}"


def required_in_declaration_order(schema: SchemaNode, navigator: SchemaNavigator) -> list[str]:
    """Return required field names in their schema-declared order.

    ``SchemaNavigator.collect_fields`` returns ``required`` as a set, losing
    the order the user would want us to emit fields in.  This walks the
    merged ``required`` list from the node plus any conjunctive branches
    (``$ref`` + ``allOf``) and preserves first-occurrence ordering.
    """
    ordered: list[str] = []
    seen: set[str] = set()
    props, _ = navigator.collect_fields(schema)

    append_required_names(ordered, seen, schema.get(SchemaKey.REQUIRED, []), props)

    if SchemaKey.REF in schema:
        ref_target = navigator.resolve_ref_target(schema[SchemaKey.REF])
        append_required_names(ordered, seen, ref_target.get(SchemaKey.REQUIRED, []), props)

    for branch in schema.get(SchemaKey.ALL_OF, []):
        resolved = navigator.resolve_ref(branch)
        append_required_names(ordered, seen, resolved.get(SchemaKey.REQUIRED, []), props)

    return ordered


def append_required_names(
    ordered: list[str], seen: set[str], names: object, props: dict[str, SchemaNode]
) -> None:
    """Append unseen required names that are present in the merged properties."""
    if not isinstance(names, list):
        return
    for name in names:
        if isinstance(name, str) and name in props and name not in seen:
            ordered.append(name)
            seen.add(name)


def has_discriminator(schema: SchemaNode) -> bool:
    """Report whether the node's required shape depends on a yet-to-be-typed field.

    Covers ODCS's ``DataQuality`` pattern (``allOf`` with ``if/then/else``
    branches) and any multi-branch ``oneOf``/``anyOf`` at object level.
    At completion time the discriminating value isn't known, so expanding
    would emit fields from the wrong branch.
    """
    for branch in schema.get(SchemaKey.ALL_OF, []):
        if isinstance(branch, dict) and SchemaKey.IF in branch:
            return True

    for key in (SchemaKey.ONE_OF, SchemaKey.ANY_OF):
        variants = [v for v in schema.get(key, []) if isinstance(v, dict)]
        object_variants = [
            v for v in variants if v.get(SchemaKey.TYPE) == "object" or SchemaKey.REF in v
        ]
        if len(object_variants) > 1:
            return True

    return False


def prefix_lines(text: str, indent: str, *, first_prefix: str) -> str:
    """Indent every line of *text* with *indent*, using *first_prefix* for line 1."""
    lines = text.split("\n")
    if not lines:
        return text
    result = [f"{first_prefix}{lines[0]}"]
    result.extend(f"{indent}{line}" for line in lines[1:])
    return "\n".join(result)


def scalar_key_snippet(name: str, field_doc: FieldDoc) -> str:
    """Return a ``key: ${1:placeholder}`` snippet for a scalar field.

    Shared by the completion path and the ``Add required field`` quickfix so
    both surfaces emit the same shape, with the same placeholder precedence.
    """
    return f"{name}: ${{1:{placeholder_for_field(field_doc)}}}"


def placeholder_for_field(field_doc: FieldDoc) -> str:
    """Pick useful placeholder text for a scalar snippet.

    Precedence: explicit ``default`` → first ``examples`` entry → the
    declared ``value_type`` → a generic ``value`` fallback. The result is
    safe to embed inside ``${N:...}`` because every branch passes the
    string through :func:`escape_snippet_placeholder`.
    """
    if field_doc.default is not None:
        return escape_snippet_placeholder(field_doc.default)
    if field_doc.examples:
        return escape_snippet_placeholder(field_doc.examples[0])
    if field_doc.value_type:
        return escape_snippet_placeholder(field_doc.value_type)
    return "value"


def escape_snippet_placeholder(value: str) -> str:
    """Escape text embedded inside a VS Code/LSP snippet placeholder."""
    return value.replace("\\", "\\\\").replace("$", "\\$").replace("}", "\\}")
