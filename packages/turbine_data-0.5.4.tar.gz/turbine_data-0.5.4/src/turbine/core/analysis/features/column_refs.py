"""Column-reference completion resolver — declarative via ``x-turbine-ref``.

Adapters expose the ``x-turbine-ref`` extension at a cursor path through the
``SchemaResolver`` port; this resolver dispatches on the extension's ``kind``
and produces typed ``ColumnSuggestion`` values. Presentation is the caller's
job: this module knows what columns are valid, not how to render them.

Kinds:
    column            Bare column name. DataContract reads its own ``schema[]``;
                      QualitySpec follows ``targetContract`` through
                      ``ProjectIndex``.
    qualified-column  ``<schema_name>.<column_name>`` from the document's own
                      ``schema[]``.
    db_table          Table name from the validated datasource's introspection
                      cache. Sourced from ``IntrospectionCache.known_table_names``.
    db_column         Column name from the introspection entry for the schema
                      that owns the cursor's dotted path, excluding columns
                      already declared in the contract.

An empty result tuple means "the kind matched but no columns are declared yet."
``None`` means "this arm cannot answer — fall through to other strategies."
The application layer decides whether to surface a hint to the user.
"""

import re
from dataclasses import dataclass
from typing import Any

from turbine.core.analysis.features.completion import collect_existing_columns, resolve_schema_table
from turbine.core.common import FIELD_DATASET, FIELD_KIND, FIELD_TARGET_CONTRACT, ContractKind
from turbine.core.common.column_ref_metadata import REF_KIND_FIELD, ColumnRefKind, column_ref
from turbine.core.common.contract_walk import iter_columns_for_schema, iter_schema_properties
from turbine.core.common.introspection_cache import IntrospectionCache
from turbine.core.contract import ProjectIndex, select_target_spec, target_specs_from_index

SCHEMA_INDEX_RE = re.compile(r"^schema\.(\d+)(?:\.|$)")

__all__ = ["ColumnRefKind", "ColumnSuggestion", "column_ref", "resolve_column_ref"]


@dataclass(frozen=True, slots=True)
class ColumnSuggestion:
    """A single column-name suggestion produced by the resolver.

    Domain-shaped: carries the bare label and a short detail string. The
    application layer projects this into the LSP completion item, applying
    sort prefixes and other presentation policy at the boundary.
    """

    label: str
    detail: str
    documentation: str = ""


def resolve_column_ref(
    doc_data: dict[str, object],
    extension: dict[str, Any],
    index: ProjectIndex | None,
    dotted_path: str | None = None,
    introspection: IntrospectionCache | None = None,
) -> tuple[ColumnSuggestion, ...] | None:
    """Dispatch the ``x-turbine-ref`` extension to the matching column source.

    ``dotted_path`` is the YAML path of the cursor (e.g. ``"schema.0.quality.0.implementation.column"``);
    when supplied, DataContract column suggestions scope to the schema
    that owns the cursor, so a ``column:`` ref under
    ``schema[i].quality[*]`` only sees ``schema[i]``'s columns and not
    sibling schemas'. The same path is used by ``db_column`` to pick the
    schema entry whose table's columns to project.

    ``introspection`` drives the ``db_table`` / ``db_column`` arms.

    Returns ``None`` when the extension's ``kind`` is unknown, when the
    arm cannot answer (e.g. ``db_table`` without an introspection cache),
    or when the document kind is not understood. Callers treat ``None``
    as "fall through to other strategies." Returns an empty tuple when
    the kind matched but no values are available.
    """
    kind_value = extension.get(REF_KIND_FIELD)
    if not isinstance(kind_value, str):
        return None
    try:
        kind = ColumnRefKind(kind_value)
    except ValueError:
        return None

    match kind:
        case ColumnRefKind.QUALIFIED_COLUMN:
            return qualified_column_suggestions(doc_data)
        case ColumnRefKind.COLUMN:
            return column_suggestions(doc_data, index, dotted_path)
        case ColumnRefKind.DB_TABLE:
            return db_table_suggestions(introspection)
        case ColumnRefKind.DB_COLUMN:
            return db_column_suggestions(doc_data, dotted_path, introspection)


def column_suggestions(
    doc_data: dict[str, object], index: ProjectIndex | None, dotted_path: str | None
) -> tuple[ColumnSuggestion, ...] | None:
    """Dispatch the ``column`` kind by the owning document's kind."""
    doc_kind = doc_data.get(FIELD_KIND)
    if doc_kind == ContractKind.QUALITY_SPEC:
        return quality_spec_column_suggestions(doc_data, index)
    if doc_kind == ContractKind.DATA_CONTRACT:
        return data_contract_column_suggestions(doc_data, dotted_path)
    return None


def db_table_suggestions(
    introspection: IntrospectionCache | None,
) -> tuple[ColumnSuggestion, ...] | None:
    """Project the validated datasource's known table names into ColumnSuggestion values.

    Returns ``None`` when no introspection cache is configured so the caller
    can fall through; the lattice's ``db.complete_table`` consumes this and
    emits the ``schema.table`` snippet in that case.
    Returns ``()`` when a cache exists but no tables are known.
    """
    if introspection is None:
        return None
    return tuple(
        ColumnSuggestion(
            label=table_name, detail="DB table", documentation="Table from validated datasource"
        )
        for table_name in sorted(introspection.known_table_names)
    )


def db_column_suggestions(
    doc_data: dict[str, object], dotted_path: str | None, introspection: IntrospectionCache | None
) -> tuple[ColumnSuggestion, ...] | None:
    """Project the owning schema's table columns, minus columns already declared.

    The cursor's dotted path identifies the schema entry whose table to
    introspect; columns already declared under that schema's ``properties[]``
    are filtered out so the user only sees what's still missing.

    Returns ``None`` when the arm cannot answer — no cache, no dotted path,
    the path does not resolve to a schema entry, or the table is not in
    the cache. The dispatcher's ``db.complete_column`` returns ``()`` in
    that case (no fallback offered for property-name lookups).
    """
    if introspection is None or dotted_path is None:
        return None
    table_name = resolve_schema_table(doc_data, dotted_path)
    if table_name is None:
        return None
    table_info = introspection.get_table(table_name)
    if table_info is None:
        return None
    declared = collect_existing_columns(doc_data, dotted_path)
    return tuple(
        ColumnSuggestion(
            label=column.name,
            detail=f"DB column: {column.logical_type.value}",
            documentation=f"Column from database table {table_name}",
        )
        for column in table_info.columns_by_ordinal()
        if column.name not in declared
    )


def qualified_column_suggestions(doc_data: dict[str, object]) -> tuple[ColumnSuggestion, ...]:
    """Build ``<schema_name>.<column_name>`` suggestions from the document's own schema[]."""
    return tuple(
        ColumnSuggestion(
            label=f"{table}.{column}",
            detail="qualified column",
            documentation=f"Column `{column}` on `{table}`.",
        )
        for table, column in iter_qualified_pairs(doc_data)
    )


def schema_index_from_path(dotted_path: str | None) -> int | None:
    """Extract the integer ``i`` from a path like ``schema.<i>.…``, else ``None``."""
    if dotted_path is None:
        return None
    match = SCHEMA_INDEX_RE.match(dotted_path)
    return int(match.group(1)) if match else None


def data_contract_column_suggestions(
    doc_data: dict[str, object], dotted_path: str | None = None
) -> tuple[ColumnSuggestion, ...]:
    """List bare column names, scoped to the cursor's parent schema when known.

    When ``dotted_path`` resolves to a schema index, only that schema's
    columns are suggested — a ``column:`` ref under
    ``schema[i].quality[*]`` should not see columns of sibling schemas.
    Without a path (or when the path lies outside any schema), fall back
    to the deduped union across all schemas.
    """
    schema_idx = schema_index_from_path(dotted_path)
    if schema_idx is not None:
        return tuple(
            ColumnSuggestion(label=name, detail="column")
            for name in iter_columns_for_schema(doc_data, schema_idx)
        )
    return tuple(
        ColumnSuggestion(label=name, detail="column")
        for name in dict.fromkeys(iter_column_names(doc_data))
    )


def quality_spec_column_suggestions(
    doc_data: dict[str, object], index: ProjectIndex | None
) -> tuple[ColumnSuggestion, ...] | None:
    """Resolve columns by following targetContract through ProjectIndex."""
    if index is None:
        return None
    target_id = doc_data.get(FIELD_TARGET_CONTRACT)
    if not isinstance(target_id, str) or not target_id:
        return None
    dataset = doc_data.get(FIELD_DATASET)
    target = select_target_spec(
        target_specs_from_index(index, target_id), dataset if isinstance(dataset, str) else None
    )
    if target is None:
        return None
    return tuple(
        ColumnSuggestion(
            label=column.name, detail=str(column.logical_type), documentation=column.description or ""
        )
        for column in target.columns
    )


def iter_qualified_pairs(doc_data: dict[str, object]) -> list[tuple[str, str]]:
    """Yield ``(schema_name, column_name)`` from each declared property."""
    return [(table, str(prop["name"])) for table, prop in iter_schema_properties(doc_data)]


def iter_column_names(doc_data: dict[str, object]) -> list[str]:
    """Yield bare column names from each declared property."""
    return [str(prop["name"]) for _, prop in iter_schema_properties(doc_data)]
