"""Definition — jump to definitions from SQL templates.

Deep module owning the port protocol, query/result types, and pure
definition-resolution logic.
"""

import re
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from turbine.core.analysis.context import SqlFileContext, extract_value_text
from turbine.core.analysis.model import LocationInfo
from turbine.core.common import RawSource
from turbine.core.contract import ProjectIndex, select_target_spec, target_specs_from_index

JINJA_PARAM_RE = re.compile(r'\{\{\s*var\(\s*["\']([\w]+)["\']')
WORD_RE = re.compile(r"\w+")
SCHEMA_NAME_PATH_RE = re.compile(r"^schema\.(\d+)\.name$")
PROPERTY_NAME_PATH_RE = re.compile(r"^schema\.(\d+)\.properties\.\d+\.name$")


@dataclass(frozen=True, slots=True)
class DefinitionQuery:
    """Captures cursor state for a go-to-definition request.

    Attrs:
        uri: Document URI of the file being edited.
        content: Full document text at the time of the request.
        line: 1-indexed line number of the cursor.
        col: 1-indexed column number of the cursor.
    """

    uri: str
    content: str
    line: int
    col: int


def resolve_param_definition(
    line_text: str, col: int, ctx: SqlFileContext, parser: Callable[[Path, str], RawSource]
) -> LocationInfo | None:
    """Find the definition of a Jinja param under the cursor in the quality spec."""
    for match in JINJA_PARAM_RE.finditer(line_text):
        param_name = match.group(1)
        if match.start(1) <= col < match.end(1) and param_name in ctx.params:
            return find_param_location(ctx.quality_spec_path, param_name, parser)
    return None


def resolve_column_definition(
    line_text: str,
    col: int,
    ctx: SqlFileContext,
    index: ProjectIndex,
    parser: Callable[[Path, str], RawSource],
) -> LocationInfo | None:
    """Find the contract field definition for a column name under the cursor."""
    col_names = {c.name for c in ctx.columns}
    contract = select_target_spec(target_specs_from_index(index, ctx.target_contract_id), ctx.dataset)
    if contract is None:
        return None

    for match in WORD_RE.finditer(line_text):
        if match.start() <= col < match.end() and match.group() in col_names:
            return find_column_location(
                contract.metadata.source_path, match.group(), parser, dataset=ctx.dataset
            )
    return None


def find_column_location(
    contract_path: Path,
    column_name: str,
    parser: Callable[[Path, str], RawSource],
    *,
    dataset: str | None = None,
) -> LocationInfo | None:
    """Find the Location of a column's property definition in the data contract."""
    try:
        text = contract_path.read_text()
        source = parser(contract_path, text)
    except Exception:  # noqa: BLE001
        return None

    schema_idx = schema_index_for_dataset(source, dataset)
    for dotted in source.source_map.key_paths():
        if not is_column_name_path(dotted, schema_idx):
            continue
        value_range = source.source_map.range_for_value(dotted)
        if value_range is None:
            continue
        value_text = extract_value_text(source.text, value_range)
        if value_text == column_name:
            return LocationInfo(uri=contract_path.as_uri(), range=value_range)
    return None


def schema_index_for_dataset(source: RawSource, dataset: str | None) -> int | None:
    """Return the schema[] index whose ``name`` equals *dataset*, if known."""
    if dataset is None:
        return None
    for dotted in source.source_map.key_paths():
        match = SCHEMA_NAME_PATH_RE.match(dotted)
        if match is None:
            continue
        value_range = source.source_map.range_for_value(dotted)
        if value_range is not None and extract_value_text(source.text, value_range) == dataset:
            return int(match.group(1))
    return None


def is_column_name_path(dotted: str, schema_idx: int | None) -> bool:
    """Return whether *dotted* points to a property name in the selected schema."""
    match = PROPERTY_NAME_PATH_RE.match(dotted)
    if match is None:
        return False
    return schema_idx is None or int(match.group(1)) == schema_idx


def find_param_location(
    quality_spec_path: Path, param_name: str, parser: Callable[[Path, str], RawSource]
) -> LocationInfo | None:
    """Find the Location of a param key in the quality spec YAML."""
    try:
        text = quality_spec_path.read_text()
        source = parser(quality_spec_path, text)
    except Exception:  # noqa: BLE001
        return None

    for dotted in source.source_map.key_paths():
        if dotted.endswith(f".{param_name}") and "params" in dotted:
            return LocationInfo(
                uri=quality_spec_path.as_uri(), range=source.source_map.range_for_key(dotted)
            )

    return LocationInfo(uri=quality_spec_path.as_uri(), range=None)
