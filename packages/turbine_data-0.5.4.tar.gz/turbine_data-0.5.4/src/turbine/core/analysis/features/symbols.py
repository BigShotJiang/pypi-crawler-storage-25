"""Document symbols — build outline hierarchy from contracts.

Deep module owning the port protocol, query/result types, and pure
symbol-construction logic.
"""

from dataclasses import dataclass

from turbine.core.analysis.model import SymbolKind
from turbine.core.building_blocks import SourceMap, TextRange
from turbine.core.common import DatasetSpec


@dataclass(frozen=True, slots=True)
class DocumentSymbolInfo:
    """Hierarchical symbol shown in the editor's outline / breadcrumb bar.

    Mirrors the tree structure of a contract file: a CONTRACT node at the root,
    SCHEMA nodes below it, and COLUMN leaves under each schema.

    Attributes:
        name: Display name (e.g. ``"orders"``, ``"customer_id"``).
        kind: What this symbol represents in the contract domain.
        range: Source range of the full symbol block; ``None`` if not available.
        detail: Extra info rendered next to the name (e.g. column type).
        children: Nested symbols forming the outline tree.

    Example::

        symbol = DocumentSymbolInfo(
            name="orders",
            kind=SymbolKind.CONTRACT,
            children=(
                DocumentSymbolInfo(name="id", kind=SymbolKind.COLUMN),
            ),
        )
    """

    name: str
    kind: SymbolKind
    range: TextRange | None = None
    detail: str | None = None
    children: tuple["DocumentSymbolInfo", ...] = ()


def build_schema_symbol(spec: DatasetSpec, source_map: SourceMap) -> DocumentSymbolInfo:
    """Build a schema symbol node with one child per column.

    Args:
        spec: The dataset spec containing the schema and column definitions.
        source_map: Source map for resolving key ranges.

    Returns:
        A ``DocumentSymbolInfo`` for the schema, with ``SymbolKind.COLUMN``
        children for each column in the spec.
    """
    schema_key = f"schema.{spec.schema_index}.name"
    column_symbols = tuple(
        DocumentSymbolInfo(
            name=col.name, kind=SymbolKind.COLUMN, range=col.source_range, detail=str(col.logical_type)
        )
        for col in spec.columns
    )
    return DocumentSymbolInfo(
        name=str(spec.table),
        kind=SymbolKind.SCHEMA,
        range=source_map.range_for_key(schema_key),
        detail=str(spec.table),
        children=column_symbols,
    )


def build_contract_symbol(
    contract_id: str,
    version: str,
    source_map: SourceMap,
    schema_children: tuple[DocumentSymbolInfo, ...],
) -> DocumentSymbolInfo:
    """Build the top-level contract symbol with schema children."""
    return DocumentSymbolInfo(
        name=contract_id,
        kind=SymbolKind.CONTRACT,
        range=source_map.range_for_key("id"),
        detail=f"v{version}",
        children=schema_children,
    )
