"""Completion generation — schema-aware YAML and SQL completions.

Provides the pure helper functions (scaffolds, Jinja completions, SQL keywords)
and domain types.  The ``CompletionService`` that orchestrates them lives in the
application layer (``turbine.application.analysis.completion``).
"""

import re
from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path

from pydantic import BaseModel, ConfigDict

from turbine.core.analysis.context import SqlFileContext
from turbine.core.building_blocks import SourceMap
from turbine.core.common import FIELD_SCHEMA, FIELD_TARGET_CONTRACT, ContractStatus, FieldDoc
from turbine.core.contract import ProjectIndex, target_specs_from_index


class PropertyEntry(BaseModel):
    """Single property inside a schema entry (parsed from YAML).

    Fields are lenient (accept None) because the user may be mid-edit.
    """

    model_config = ConfigDict(frozen=True, coerce_numbers_to_str=True)

    name: str | None = None


class SchemaEntry(BaseModel):
    """One schema block in a DataContract (parsed from YAML)."""

    model_config = ConfigDict(frozen=True, coerce_numbers_to_str=True)

    name: str | None = None
    properties: list[PropertyEntry] = []


class CompletionKind(StrEnum):
    """Category tag for autocomplete suggestions.

    Maps to LSP ``CompletionItemKind`` values in the presentation layer, but
    stays domain-focused here so the core never imports protocol types.

    Members:
        FIELD: A schema field name (e.g. ``description``, ``type``).
        ENUM_VALUE: One of a fixed set of allowed values.
        SNIPPET: A multi-line template with tab stops.
        KEYWORD: A YAML key recognized by Turbine.
        VARIABLE: A user-defined variable reference.
    """

    FIELD = "field"
    ENUM_VALUE = "enum_value"
    SNIPPET = "snippet"
    KEYWORD = "keyword"
    VARIABLE = "variable"
    FILE = "file"


@dataclass(frozen=True, slots=True)
class CompletionItemInfo:
    """Single autocomplete suggestion offered to the user as they type.

    Carries enough information for the presentation layer to build an LSP
    ``CompletionItem`` without needing to reach back into the core.

    Attributes:
        label: Display text shown in the completion menu.
        kind: Category used to pick an icon and filter results.
        detail: Short secondary text (e.g. the expected type).
        documentation: Longer description rendered in the detail pane.
        insert_text: Text actually inserted on accept; ``None`` means use *label*.
        sort_prefix: Prefix prepended to the sort key so important items float
            to the top of the list.

    Example::

        item = CompletionItemInfo(
            label="description",
            kind=CompletionKind.FIELD,
            detail="string",
            documentation="Human-readable description of the contract.",
        )
    """

    label: str
    kind: CompletionKind
    detail: str = ""
    documentation: str = ""
    insert_text: str | None = None
    sort_prefix: str = ""
    deprecated: bool = False
    is_snippet: bool = False


@dataclass(frozen=True, slots=True)
class CompletionQuery:
    """Captures everything needed to compute completions at a cursor position.

    Attrs:
        uri: Document URI (file path or scheme-prefixed).
        content: Full document text at the time of the request.
        line: 1-indexed line number of the cursor.
        col: 1-indexed column number of the cursor.
    """

    uri: str
    content: str
    line: int
    col: int


SQL_CHECK_NAME_PATH_RE = re.compile(r"^quality\.\d+\.sql\.name$")

MIN_SCHEMA_PATH_DEPTH = 4

CONTRACT_SCAFFOLD = """\
kind: ${1|DataContract,QualitySpec|}
id: ${2:my-contract}
version: "${3:1.0.0}"
status: ${4|active,draft,retired|}
schema:
  - name: ${5:schema.table_name}
    properties:
      - name: ${6:column_name}
        logicalType: ${7:string}
        required: ${8|true,false|}
$0"""

QUALITY_SCAFFOLD = """\
kind: QualitySpec
id: ${1:my-quality}
version: "${2:1.0.0}"
targetContract: ${3:contract-id}
dataset: ${4:schema.table_name}
$0"""

POSTGRES_SCAFFOLD = """\
type: postgres
connection:
  host: \\${env.PG_HOST}
  port: 5432
  database: \\${env.PG_DATABASE}
  user: \\${env.PG_USER}
  password: \\${env.PG_PASSWORD}
$0"""

SNOWFLAKE_SCAFFOLD = """\
type: snowflake
connection:
  account: \\${env.SF_ACCOUNT}
  database: \\${env.SF_DATABASE}
  warehouse: \\${env.SF_WAREHOUSE}
  schema: \\${env.SF_SCHEMA}
  user: \\${env.SF_USER}
  password: \\${env.SF_PASSWORD}
$0"""

DUCKDB_SCAFFOLD = """\
type: duckdb
connection:
  database: ${1:data/local.duckdb}
$0"""

JINJA_PARAMS_PREFIX_RE = re.compile(r'\{\{\s*var\(\s*["\']\s*$')

SQL_KEYWORDS: tuple[str, ...] = (
    "SELECT",
    "FROM",
    "WHERE",
    "JOIN",
    "LEFT",
    "RIGHT",
    "INNER",
    "OUTER",
    "FULL",
    "CROSS",
    "ON",
    "AND",
    "OR",
    "NOT",
    "IN",
    "BETWEEN",
    "LIKE",
    "IS",
    "NULL",
    "AS",
    "ORDER",
    "BY",
    "GROUP",
    "HAVING",
    "LIMIT",
    "OFFSET",
    "UNION",
    "ALL",
    "DISTINCT",
    "INSERT",
    "INTO",
    "VALUES",
    "UPDATE",
    "SET",
    "DELETE",
    "CREATE",
    "TABLE",
    "ALTER",
    "DROP",
    "INDEX",
    "EXISTS",
    "CASE",
    "WHEN",
    "THEN",
    "ELSE",
    "END",
    "WITH",
    "COUNT",
    "SUM",
    "AVG",
    "MIN",
    "MAX",
    "COALESCE",
    "CAST",
    "ASC",
    "DESC",
)

JINJA_BUILTINS: tuple[str, ...] = ("this", "since", "until")


def scaffold_completions() -> tuple[CompletionItemInfo, ...]:
    """Offer full-document scaffold snippets for empty / unrecognized YAML files."""
    return (
        CompletionItemInfo(
            label="DataContract",
            kind=CompletionKind.SNIPPET,
            detail="New data contract",
            documentation="Insert a complete DataContract scaffold",
            insert_text=CONTRACT_SCAFFOLD,
            sort_prefix="0",
        ),
        CompletionItemInfo(
            label="QualitySpec",
            kind=CompletionKind.SNIPPET,
            detail="New quality spec",
            documentation="Insert a complete QualitySpec scaffold",
            insert_text=QUALITY_SCAFFOLD,
            sort_prefix="1",
        ),
        CompletionItemInfo(
            label="Datasource: Postgres",
            kind=CompletionKind.SNIPPET,
            detail="New Postgres datasource",
            documentation=(
                "Insert a Postgres datasource scaffold with `${env.PG_*}` credential "
                "references so secrets stay out of the YAML."
            ),
            insert_text=POSTGRES_SCAFFOLD,
            sort_prefix="2",
        ),
        CompletionItemInfo(
            label="Datasource: Snowflake",
            kind=CompletionKind.SNIPPET,
            detail="New Snowflake datasource",
            documentation=(
                "Insert a Snowflake datasource scaffold with `${env.SF_*}` credential "
                "references so secrets stay out of the YAML."
            ),
            insert_text=SNOWFLAKE_SCAFFOLD,
            sort_prefix="3",
        ),
        CompletionItemInfo(
            label="Datasource: DuckDB",
            kind=CompletionKind.SNIPPET,
            detail="New DuckDB datasource",
            documentation="Insert a DuckDB datasource scaffold pointing at a local file.",
            insert_text=DUCKDB_SCAFFOLD,
            sort_prefix="4",
        ),
    )


def cursor_in_jinja_block(line_text: str, col: int) -> bool:
    """Return True if the 0-indexed column is inside a {{ ... }} block."""
    prefix = line_text[:col]
    last_open = prefix.rfind("{{")
    if last_open == -1:
        return False
    last_close = prefix.rfind("}}")
    return last_close < last_open


def jinja_completions(line_text: str, col: int, ctx: SqlFileContext) -> tuple[CompletionItemInfo, ...]:
    """Return Jinja-specific completions: builtins, params, and column names."""
    prefix = line_text[:col]
    if JINJA_PARAMS_PREFIX_RE.search(prefix):
        return param_completions(ctx)
    return builtin_variable_completions(ctx) + column_name_completions(ctx)


def builtin_variable_completions(ctx: SqlFileContext) -> tuple[CompletionItemInfo, ...]:
    """Return completions for supported SQL template Jinja built-in variables."""
    docs = {
        "this": f"Target table: `{ctx.dataset}`",
        "since": "Incremental lower bound (ISO datetime string, None when not set)",
        "until": "Incremental upper bound (ISO datetime string, None when not set)",
    }
    return tuple(
        CompletionItemInfo(
            label=name,
            kind=CompletionKind.VARIABLE,
            detail="Jinja built-in",
            documentation=docs.get(name, ""),
            sort_prefix="0",
        )
        for name in JINJA_BUILTINS
    )


def param_completions(ctx: SqlFileContext) -> tuple[CompletionItemInfo, ...]:
    """Return completions for quality spec params ({{ var("key") }})."""
    return tuple(
        CompletionItemInfo(
            label=name,
            kind=CompletionKind.VARIABLE,
            detail=f"Parameter: {value}",
            documentation=f"Quality spec parameter `{name}` = `{value}`",
            sort_prefix="0",
        )
        for name, value in ctx.params.items()
    )


def column_name_completions(ctx: SqlFileContext) -> tuple[CompletionItemInfo, ...]:
    """Return completions for column names from the target contract."""
    return tuple(
        CompletionItemInfo(
            label=column.name,
            kind=CompletionKind.FIELD,
            detail=str(column.logical_type),
            documentation=column.description or "",
            sort_prefix="1",
        )
        for column in ctx.columns
    )


def sql_plain_completions(ctx: SqlFileContext) -> tuple[CompletionItemInfo, ...]:
    """Return SQL keyword + column name completions for outside Jinja blocks."""
    keywords = tuple(
        CompletionItemInfo(label=kw, kind=CompletionKind.KEYWORD, detail="SQL keyword", sort_prefix="2")
        for kw in SQL_KEYWORDS
    )
    return column_name_completions(ctx) + keywords


def field_to_completion(
    name: str, field_doc: FieldDoc, insert_text: str | None = None
) -> CompletionItemInfo:
    """Turn a schema field definition into a completion item.

    When *insert_text* is a snippet string (tabstops), the returned item is
    flagged ``is_snippet=True`` so the presentation layer routes it to
    ``InsertTextFormat.Snippet``.  Callers that want plain-label insertion
    should leave *insert_text* as ``None``.
    """
    detail_parts: list[str] = []
    if field_doc.value_type:
        detail_parts.append(field_doc.value_type)
    if field_doc.required:
        detail_parts.append("required")

    return CompletionItemInfo(
        label=name,
        kind=CompletionKind.FIELD,
        detail=" ".join(detail_parts),
        documentation=field_doc.description,
        sort_prefix="0" if field_doc.required else "1",
        insert_text=insert_text,
        is_snippet=insert_text is not None,
    )


CONTEXT_KEYWORDS: dict[str, str] = {
    "properties:": "schema.0.properties.0",
    "- properties:": "schema.0.properties.0",
    "schema:": "schema.0",
    "- name:": "schema.0",
    "columns:": "columns.0",
    "checks:": "columns.0.checks.0",
}


def match_context_keyword(stripped: str) -> str | None:
    """Return the schema path if the stripped line starts with a known context keyword."""
    for keyword, path in CONTEXT_KEYWORDS.items():
        if stripped.startswith(keyword):
            return path
    return None


def path_from_indentation(text: str, line: int) -> str:
    """Estimate a dotted schema path by scanning backwards from cursor for context keywords."""
    lines = text.splitlines()
    if line <= 0 or line > len(lines):
        return ""

    current_line = lines[line - 1]
    current_indent = (
        len(current_line) - len(current_line.lstrip())
        if current_line.strip()
        else infer_indent(lines, line)
    )
    if current_line.lstrip().startswith("- "):
        current_indent += 1

    for scan_idx in range(line - 2, -1, -1):
        raw = lines[scan_idx]
        stripped = raw.lstrip()
        indent = len(raw) - len(stripped)
        if indent >= current_indent:
            continue
        if (path := match_context_keyword(stripped)) is not None:
            return path
    return ""


def resolve_parent_from_indent(
    content: str, line: int, source_map: SourceMap, col: int | None = None
) -> str:
    """Determine the parent schema path from indentation on an empty line.

    When *col* is given and the cursor line is blank, it overrides the
    indent inferred from the nearest non-blank line above. This matters
    when the user dedents manually: the cursor column (col - 1) is the
    indent level they are committing to, while ``infer_indent`` would
    instead copy the previous line's indent and pick the wrong parent.
    """
    lines = content.splitlines()
    if line < 1 or line > len(lines):
        return ""

    current_indent = cursor_indent(lines, line, col)
    return find_nearest_parent(source_map, line, current_indent)


def cursor_indent(lines: list[str], line: int, col: int | None) -> int:
    """Pick the indent used for parent resolution at the cursor.

    On a non-blank line, use that line's leading whitespace. On a blank
    line, prefer the cursor column (when provided) over the inferred
    indent from the previous non-blank line.
    """
    current_line = lines[line - 1]
    if current_line.strip():
        return len(current_line) - len(current_line.lstrip())
    if col is not None and col >= 1:
        return col - 1
    return infer_indent(lines, line)


def find_nearest_parent(source_map: SourceMap, line: int, indent: int) -> str:
    """Walk source map keys above the cursor and return the nearest parent with lower indent."""
    best_path = ""
    best_line = 0
    for dotted in source_map.key_paths():
        key_range = source_map.range_for_key(dotted)
        if key_range is None or key_range.start_line >= line:
            continue
        if key_range.start_col < indent and key_range.start_line > best_line:
            best_path = dotted
            best_line = key_range.start_line
    return best_path


def infer_indent(lines: list[str], line: int) -> int:
    """For a blank line, infer indent from the previous non-blank line."""
    for idx in range(line - 2, -1, -1):
        if lines[idx].strip():
            return len(lines[idx]) - len(lines[idx].lstrip())
    return 0


def resolve_schema_item(data: dict[str, object], dotted_path: str) -> SchemaEntry | None:
    """Extract the schema dict at the index encoded in *dotted_path* (e.g. ``schema.0.…``)."""
    parts = dotted_path.split(".")
    if len(parts) < MIN_SCHEMA_PATH_DEPTH or parts[0] != FIELD_SCHEMA or not parts[1].isdigit():
        return None
    schema_list = data.get(FIELD_SCHEMA)
    if not isinstance(schema_list, list):
        return None
    idx = int(parts[1])
    if idx >= len(schema_list):
        return None
    item = schema_list[idx]
    return SchemaEntry.model_validate(item) if isinstance(item, dict) else None


def resolve_schema_table(data: dict[str, object], dotted_path: str) -> str | None:
    """Extract the schema table name for a column path like 'schema.0.properties.1.name'."""
    schema_item = resolve_schema_item(data, dotted_path)
    if schema_item is None or not schema_item.name:
        return None
    return schema_item.name


def collect_existing_columns(data: dict[str, object], dotted_path: str) -> set[str]:
    """Collect column names already defined in the same schema block."""
    schema_item = resolve_schema_item(data, dotted_path)
    if schema_item is None:
        return set()
    return {entry.name for entry in schema_item.properties if entry.name}


def sql_check_name_completions(checks_dir: Path) -> tuple[CompletionItemInfo, ...]:
    """Suggest .sql filenames from the checks directory."""
    if not checks_dir.is_dir():
        return ()
    return tuple(
        CompletionItemInfo(label=path.stem, kind=CompletionKind.FILE, detail="SQL check")
        for path in sorted(checks_dir.iterdir())
        if path.suffix == ".sql" and path.is_file()
    )


def contract_id_completions(index: ProjectIndex) -> tuple[CompletionItemInfo, ...]:
    """Suggest each DataContract ID once, excluding Quality Specs."""
    seen: set[str] = set()
    items: list[CompletionItemInfo] = []
    for spec in index.contracts():
        if spec.target_contract is not None:
            continue
        contract_id = spec.metadata.contract_id
        if contract_id in seen:
            continue
        seen.add(contract_id)
        items.append(
            CompletionItemInfo(
                label=contract_id,
                kind=CompletionKind.ENUM_VALUE,
                detail=f"Contract: {spec.table}",
                sort_prefix="0",
                deprecated=spec.metadata.status in (ContractStatus.DEPRECATED, ContractStatus.RETIRED),
            )
        )
    return tuple(items)


def dataset_completions(
    data: dict[str, object], index: ProjectIndex
) -> tuple[CompletionItemInfo, ...] | None:
    """Suggest dataset (table) names belonging to the referenced target contract."""
    target_id = data.get(FIELD_TARGET_CONTRACT)
    if not isinstance(target_id, str) or not target_id:
        return None
    items = tuple(
        CompletionItemInfo(
            label=str(spec.table),
            kind=CompletionKind.ENUM_VALUE,
            detail="Dataset from target contract",
            sort_prefix="0",
        )
        for spec in target_specs_from_index(index, target_id)
    )
    return items or None
