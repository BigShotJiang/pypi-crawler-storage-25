"""Schema-side primitive of the completion lattice — the typed classification result.

``CompletionTarget`` is a sealed union of the twelve shapes a cursor's resolved
path can take. The dispatcher branches on the variant; no priority arm reads
internal flags or path-regexes. ``ArrayOfScalars`` is a first-class variant —
today's resolver bug exists because that shape has no name.

This module defines types only; ``target_at`` (in ``application/analysis/completion``)
produces them and ``dispatch`` (later issue) consumes them.
"""

from dataclasses import dataclass
from enum import StrEnum

from turbine.core.common import ResolvedNode
from turbine.core.common.column_ref_metadata import ColumnRefKind

__all__ = [
    "ArrayOfObjects",
    "ArrayOfScalars",
    "ColumnRef",
    "CompletionTarget",
    "ContractRef",
    "DatasetRef",
    "DbColumn",
    "DbTable",
    "DomainRef",
    "NotInSchema",
    "NotInSchemaReason",
    "ObjectShape",
    "Scalar",
    "SqlCheckRef",
]


class NotInSchemaReason(StrEnum):
    """Why a cursor position fell off the schema."""

    PATH_DOES_NOT_EXIST = "path_does_not_exist"
    FIELD_NOT_ALLOWED_HERE = "field_not_allowed_here"


@dataclass(frozen=True, slots=True)
class ObjectShape:
    """The cursor's resolved path is an object — its allowed child keys are the target."""

    node: ResolvedNode


@dataclass(frozen=True, slots=True)
class ArrayOfObjects:
    """The cursor's resolved path is an array whose items are objects."""

    item_node: ResolvedNode


@dataclass(frozen=True, slots=True)
class ArrayOfScalars:
    """The cursor's resolved path is an array of scalars — the missing primitive."""

    item_node: ResolvedNode


@dataclass(frozen=True, slots=True)
class Scalar:
    """The cursor's resolved path is a scalar slot — its FieldDoc carries enums/examples."""

    node: ResolvedNode
    key_name: str


@dataclass(frozen=True, slots=True)
class ColumnRef:
    """Path declared as ``x-turbine-ref: column`` or ``qualified-column``."""

    kind: ColumnRefKind


@dataclass(frozen=True, slots=True)
class DbTable:
    """Path declared as ``x-turbine-ref: db_table`` (kind added in issue 002)."""


@dataclass(frozen=True, slots=True)
class DbColumn:
    """Path declared as ``x-turbine-ref: db_column`` (kind added in issue 002)."""


@dataclass(frozen=True, slots=True)
class DomainRef:
    """Top-level ``domain`` field on a DataContract when a registry allow-list exists."""


@dataclass(frozen=True, slots=True)
class ContractRef:
    """``targetContract`` field on a QualitySpec — values come from the project index."""


@dataclass(frozen=True, slots=True)
class DatasetRef:
    """``dataset`` field on a QualitySpec — values come from the target contract's schemas."""


@dataclass(frozen=True, slots=True)
class SqlCheckRef:
    """``.sql`` filename references under a configured checks directory."""


@dataclass(frozen=True, slots=True)
class NotInSchema:
    """Cursor sits at a position the schema does not validate.

    The dispatcher treats both reasons as silent-empty; reason is preserved for
    future quick-fix authoring and telemetry.
    """

    reason: NotInSchemaReason


type CompletionTarget = (
    ObjectShape
    | ArrayOfObjects
    | ArrayOfScalars
    | Scalar
    | ColumnRef
    | DbTable
    | DbColumn
    | DomainRef
    | ContractRef
    | DatasetRef
    | SqlCheckRef
    | NotInSchema
)
