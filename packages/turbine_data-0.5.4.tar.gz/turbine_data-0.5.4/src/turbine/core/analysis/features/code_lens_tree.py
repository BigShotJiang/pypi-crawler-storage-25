"""Tree-sitter-backed structural views for code-lens and listChecks discovery.

Indent-tolerant alternative to the regex finders in ``code_lens.py``. Walks
the tree-sitter source map's dotted-path index, so check/property/schema
discovery works regardless of how the formatter normalizes whitespace.
"""

from collections.abc import Iterable
from dataclasses import dataclass
from typing import Any, cast

from turbine.core.building_blocks import SourceMap
from turbine.core.common import RawSource


@dataclass(frozen=True, slots=True)
class ContractCheckEntry:
    """A check inside a DataContract ``quality:`` block (schema- or property-scoped)."""

    line: int
    schema_name: str
    check_name: str
    check_type: str | None
    column: str | None
    is_custom: bool


@dataclass(frozen=True, slots=True)
class ContractPropertyEntry:
    """A property under a schema's ``properties:`` block."""

    name: str
    name_line: int
    quality_anchor_line: int
    checks: tuple[ContractCheckEntry, ...]


@dataclass(frozen=True, slots=True)
class ContractSchemaEntry:
    """A single entry under a DataContract's ``schema:`` list."""

    name: str
    name_line: int
    quality_anchor_line: int
    quality_end_line: int | None
    properties: tuple[ContractPropertyEntry, ...]
    schema_checks: tuple[ContractCheckEntry, ...]


@dataclass(frozen=True, slots=True)
class ContractLensView:
    """Structural view of a DataContract used for lens + listChecks rendering."""

    schemas: tuple[ContractSchemaEntry, ...]


@dataclass(frozen=True, slots=True)
class QualitySpecCheck:
    """A single check inside a QualitySpec, anchored at the list-item start."""

    line: int
    check_type: str
    column: str | None
    check_name: str


@dataclass(frozen=True, slots=True)
class QualitySpecColumnEntry:
    """A column under a QualitySpec ``columns:`` block."""

    name: str
    name_line: int
    checks: tuple[QualitySpecCheck, ...]


@dataclass(frozen=True, slots=True)
class QualitySpecLensView:
    """Structural view of a QualitySpec file."""

    columns_section_line: int | None
    columns: tuple[QualitySpecColumnEntry, ...]
    quality_section_line: int | None
    quality_end_line: int | None
    quality_checks: tuple[QualitySpecCheck, ...]


@dataclass(frozen=True, slots=True)
class CheckScope:
    """Address of a ``quality:`` list inside a contract — used for check resolution."""

    quality_path: str
    schema_name: str
    default_column: str | None


META_KEYS: frozenset[str] = frozenset({"name", "fail", "warn", "filter", "samples", "attributes"})


def as_mapping(value: Any) -> dict[str, Any] | None:
    """Cast a parsed YAML value to ``dict[str, Any]`` when it is a mapping."""
    if isinstance(value, dict):
        return cast(dict[str, Any], value)
    return None


def as_list(value: Any) -> list[Any] | None:
    """Cast a parsed YAML value to ``list[Any]`` when it is a sequence."""
    if isinstance(value, list):
        return cast(list[Any], value)
    return None


def as_str(value: Any) -> str | None:
    """Cast a parsed YAML value to ``str`` when it is a non-empty string."""
    if isinstance(value, str) and value:
        return value
    return None


def build_contract_view(source: RawSource) -> ContractLensView:
    """Construct a ContractLensView from a parsed DataContract."""
    schema_list = as_list(source.data.get("schema"))
    if schema_list is None:
        return ContractLensView(schemas=())
    entries: list[ContractSchemaEntry] = []
    for idx, raw in enumerate(schema_list):
        mapping = as_mapping(raw)
        if mapping is None or as_str(mapping.get("name")) is None:
            continue
        entries.append(build_schema_entry(source.source_map, idx, mapping))
    return ContractLensView(schemas=tuple(entries))


def build_schema_entry(source_map: SourceMap, idx: int, raw: dict[str, Any]) -> ContractSchemaEntry:
    """Build one schema entry with its properties + schema-level checks."""
    schema_name = str(raw["name"])
    name_line = key_line(source_map, f"schema.{idx}.name") or 1
    quality_path = f"schema.{idx}.quality"
    quality_line = key_line(source_map, quality_path)
    quality_block_end = block_end_line(source_map, quality_path)
    properties = build_property_entries(source_map, idx, raw, schema_name)
    schema_checks = build_check_entries(
        source_map,
        raw,
        CheckScope(quality_path=quality_path, schema_name=schema_name, default_column=None),
    )
    return ContractSchemaEntry(
        name=schema_name,
        name_line=name_line,
        quality_anchor_line=quality_line if quality_line is not None else name_line,
        quality_end_line=quality_block_end,
        properties=properties,
        schema_checks=schema_checks,
    )


def build_property_entries(
    source_map: SourceMap, schema_idx: int, schema_raw: dict[str, Any], schema_name: str
) -> tuple[ContractPropertyEntry, ...]:
    """Build property entries from a schema's ``properties:`` list."""
    props = as_list(schema_raw.get("properties"))
    if props is None:
        return ()
    results: list[ContractPropertyEntry] = []
    for prop_idx, raw in enumerate(props):
        mapping = as_mapping(raw)
        if mapping is None or as_str(mapping.get("name")) is None:
            continue
        results.append(build_property_entry(source_map, schema_idx, prop_idx, mapping, schema_name))
    return tuple(results)


def build_property_entry(
    source_map: SourceMap, schema_idx: int, prop_idx: int, raw: dict[str, Any], schema_name: str
) -> ContractPropertyEntry:
    """Build one property entry with its inline ``quality:`` checks."""
    prop_name = str(raw["name"])
    base = f"schema.{schema_idx}.properties.{prop_idx}"
    name_line = key_line(source_map, f"{base}.name") or 1
    quality_path = f"{base}.quality"
    quality_line = key_line(source_map, quality_path)
    checks = build_check_entries(
        source_map,
        raw,
        CheckScope(quality_path=quality_path, schema_name=schema_name, default_column=prop_name),
    )
    return ContractPropertyEntry(
        name=prop_name,
        name_line=name_line,
        quality_anchor_line=quality_line if quality_line is not None else name_line,
        checks=checks,
    )


def build_check_entries(
    source_map: SourceMap, container: dict[str, Any], scope: CheckScope
) -> tuple[ContractCheckEntry, ...]:
    """Build check entries for the ``quality:`` block addressed by *scope*."""
    quality = as_list(container.get("quality"))
    if quality is None:
        return ()
    results: list[ContractCheckEntry] = []
    for check_idx, raw in enumerate(quality):
        mapping = as_mapping(raw)
        if mapping is None:
            continue
        entry = build_check_entry(source_map, scope, check_idx, mapping)
        if entry is not None:
            results.append(entry)
    return tuple(results)


def build_check_entry(
    source_map: SourceMap, scope: CheckScope, check_idx: int, raw: dict[str, Any]
) -> ContractCheckEntry | None:
    """Build one check entry from an item in a ``quality:`` list."""
    line = list_item_line(source_map, scope.quality_path, check_idx, raw)
    if line is None:
        return None
    is_custom = raw.get("type") == "custom"
    check_type, column = resolve_custom_kind(raw, scope.default_column)
    if check_type is None and "type" not in raw:
        check_type, column = resolve_builtin_wrapper(raw, scope.default_column)
    check_name = resolve_check_display_name(raw, check_type, column)
    if check_name is None:
        return None
    return ContractCheckEntry(
        line=line,
        schema_name=scope.schema_name,
        check_name=check_name,
        check_type=check_type,
        column=column,
        is_custom=is_custom,
    )


def resolve_builtin_wrapper(
    raw: dict[str, Any], default_column: str | None
) -> tuple[str | None, str | None]:
    """Pull (check kind, column) from a built-in wrapper-key contract entry.

    Built-in checks omit ``type:`` and use the check kind as the wrapper key,
    e.g. ``- missing: { column: email, mustBe: 0 }``. The column lives on the
    inner mapping; falls back to the scope's default column.
    """
    kind = first_non_meta_key(raw)
    if kind is None:
        return None, default_column
    inner = as_mapping(raw.get(kind))
    if inner is not None:
        explicit_column = as_str(inner.get("column"))
        if explicit_column is not None:
            return kind, explicit_column
    return kind, default_column


def resolve_custom_kind(
    raw: dict[str, Any], default_column: str | None
) -> tuple[str | None, str | None]:
    """Pull (check kind, column) from a custom check.

    Supports both ODCS spec shape (under ``implementation:``) and the flat
    shape used by Turbine quality blocks (``check:`` / ``column:`` siblings of
    ``type: custom``).
    """
    implementation = as_mapping(raw.get("implementation"))
    if implementation is not None:
        kind = as_str(implementation.get("check"))
        explicit_column = as_str(implementation.get("column"))
        return kind, explicit_column or default_column
    kind = as_str(raw.get("check"))
    explicit_column = as_str(raw.get("column"))
    return kind, explicit_column or default_column


def resolve_check_display_name(
    raw: dict[str, Any], check_type: str | None, column: str | None
) -> str | None:
    """Derive the display/lookup name used by lens labels and listChecks."""
    if (name := as_str(raw.get("name"))) is not None:
        return name
    if check_type:
        return f"{check_type}:{column}" if column else check_type
    if (metric := as_str(raw.get("metric"))) is not None:
        return f"{metric}:{column}" if column else metric
    return None


def build_quality_spec_view(source: RawSource) -> QualitySpecLensView:
    """Construct a QualitySpecLensView from a parsed QualitySpec."""
    columns_line = key_line(source.source_map, "columns")
    columns = build_quality_spec_columns(source)
    quality_line = key_line(source.source_map, "quality")
    quality_end = block_end_line(source.source_map, "quality")
    quality_checks = build_quality_spec_quality_checks(source)
    return QualitySpecLensView(
        columns_section_line=columns_line,
        columns=columns,
        quality_section_line=quality_line,
        quality_end_line=quality_end,
        quality_checks=quality_checks,
    )


def build_quality_spec_columns(source: RawSource) -> tuple[QualitySpecColumnEntry, ...]:
    """Build per-column entries with their nested ``checks:`` items."""
    columns = as_list(source.data.get("columns"))
    if columns is None:
        return ()
    results: list[QualitySpecColumnEntry] = []
    for idx, raw in enumerate(columns):
        mapping = as_mapping(raw)
        if mapping is None or as_str(mapping.get("name")) is None:
            continue
        results.append(build_quality_spec_column(source.source_map, idx, mapping))
    return tuple(results)


def build_quality_spec_column(
    source_map: SourceMap, idx: int, raw: dict[str, Any]
) -> QualitySpecColumnEntry:
    """Build one column entry, including its ``checks:`` list."""
    name = str(raw["name"])
    name_line = key_line(source_map, f"columns.{idx}.name") or 1
    checks_list = as_list(raw.get("checks")) or []
    checks = build_check_position_list(source_map, checks_list, f"columns.{idx}.checks", column=name)
    return QualitySpecColumnEntry(name=name, name_line=name_line, checks=checks)


def build_quality_spec_quality_checks(source: RawSource) -> tuple[QualitySpecCheck, ...]:
    """Build top-level ``quality:`` list checks for a QualitySpec."""
    quality_list = as_list(source.data.get("quality")) or []
    return build_check_position_list(source.source_map, quality_list, "quality", column=None)


def build_check_position_list(
    source_map: SourceMap, items: list[Any], list_path: str, column: str | None
) -> tuple[QualitySpecCheck, ...]:
    """Build QualitySpecCheck entries for each item in *items* (already resolved)."""
    results: list[QualitySpecCheck] = []
    for idx, raw in enumerate(items):
        mapping = as_mapping(raw)
        if mapping is None:
            continue
        check = build_quality_spec_check(source_map, list_path, idx, mapping, column)
        if check is not None:
            results.append(check)
    return tuple(results)


def build_quality_spec_check(
    source_map: SourceMap, list_path: str, idx: int, raw: dict[str, Any], column: str | None
) -> QualitySpecCheck | None:
    """Build one QualitySpecCheck from a list item under columns[].checks or top-level quality."""
    line = list_item_line(source_map, list_path, idx, raw)
    if line is None:
        return None
    check_type = first_non_meta_key(raw)
    if check_type is None:
        return None
    inner = as_mapping(raw.get(check_type))
    nested_name = as_str(raw.get("name")) or (as_str(inner.get("name")) if inner else None)
    check_name = nested_name or (f"{check_type}:{column}" if column else check_type)
    return QualitySpecCheck(line=line, check_type=check_type, column=column, check_name=check_name)


def first_non_meta_key(raw: dict[str, Any]) -> str | None:
    """Return the first non-meta mapping key — that's the check type for QualitySpec entries."""
    for key in raw:
        if key not in META_KEYS:
            return str(key)
    return None


def key_line(source_map: SourceMap, dotted: str) -> int | None:
    """Return the 1-indexed line number of *dotted*'s key, or None when absent."""
    text_range = source_map.range_for_key(dotted)
    return text_range.start_line if text_range is not None else None


def list_item_line(source_map: SourceMap, list_path: str, idx: int, raw: dict[str, Any]) -> int | None:
    """Return the line of the first known child key under *list_path*[idx].

    The tree-sitter source map indexes mapping pairs but not sequence items
    themselves, so we anchor each list item on the first child key that the
    parser recorded — the dict preserves YAML insertion order, so this is the
    visually-first line of the item.
    """
    for key in raw:
        line = key_line(source_map, f"{list_path}.{idx}.{key}")
        if line is not None:
            return line
    return None


def block_end_line(source_map: SourceMap, dotted: str) -> int | None:
    """Return the 1-indexed last content line of *dotted*'s block, or None when absent."""
    text_range = source_map.range_for_block(dotted)
    return text_range.end_line if text_range is not None else None


def iter_contract_checks(view: ContractLensView) -> Iterable[ContractCheckEntry]:
    """Yield every check entry across schemas + properties in a contract view."""
    for schema in view.schemas:
        yield from schema.schema_checks
        for prop in schema.properties:
            yield from prop.checks
