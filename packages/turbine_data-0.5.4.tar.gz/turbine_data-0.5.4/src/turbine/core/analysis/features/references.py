"""References — find all references to columns, contracts, and schemas.

Deep module owning the port protocol, query/result types, and pure
text-matching logic.
"""

import re

from turbine.core.analysis.model import LocationInfo
from turbine.core.building_blocks import TextRange


def find_word_locations(content: str, word: str, file_uri: str) -> list[LocationInfo]:
    """Find word-boundary matches in text and return their locations.

    Args:
        content: Full text content to search.
        word: The word to find (matched with word boundaries).
        file_uri: URI to embed in each resulting LocationInfo.

    Returns:
        Locations with precise range for each match found.
    """
    pattern = re.compile(rf"\b{re.escape(word)}\b")
    results: list[LocationInfo] = []

    for match in pattern.finditer(content):
        line_num = content[: match.start()].count("\n") + 1
        line_start = content.rfind("\n", 0, match.start()) + 1
        col_start = match.start() - line_start
        location_info = LocationInfo(
            uri=file_uri,
            range=TextRange(
                start_line=line_num,
                start_col=col_start + 1,
                end_line=line_num,
                end_col=col_start + len(word) + 1,
            ),
        )
        results.append(location_info)

    return results
