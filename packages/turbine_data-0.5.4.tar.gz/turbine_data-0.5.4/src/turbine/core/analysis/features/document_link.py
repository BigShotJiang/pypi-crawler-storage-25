"""Document links — clickable links in quality specs and SQL files.

Deep module owning the port protocol, query/result types, and pure
link-resolution logic.
"""

import re
from dataclasses import dataclass

from turbine.core.building_blocks import TextRange


@dataclass(frozen=True, slots=True)
class LinkInfo:
    """Clickable document link rendered inline (e.g. a contract reference you can Cmd-click).

    Used by the LSP ``textDocument/documentLink`` handler to let users navigate
    from one contract file to another.

    Attributes:
        range: Source range in the document that becomes the clickable span.
        target_uri: File URI the link points to.
        tooltip: Optional hover text shown before clicking.

    Example::

        link = LinkInfo(
            range=TextRange(line=5, col=0, end_line=5, end_col=12),
            target_uri="file:///project/contracts/customers.yaml",
            tooltip="Open customers contract",
        )
    """

    range: TextRange
    target_uri: str
    tooltip: str | None = None


WORD_RE = re.compile(r"\w+")
