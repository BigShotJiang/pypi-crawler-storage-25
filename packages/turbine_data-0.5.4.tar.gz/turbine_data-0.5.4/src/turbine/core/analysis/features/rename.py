"""Rename — F2 cross-file rename for columns, contract IDs, and schema names.

Deep module owning the port protocols, query/result types, and pure
rename-classification logic.  Service implementations live in the
application layer (``turbine.application.analysis.rename``).
"""

import re
from dataclasses import dataclass

from turbine.core.building_blocks import TextRange
from turbine.core.common.file_edits import FileEdits, TextEditInfo


@dataclass(frozen=True, slots=True)
class PrepareRenameInfo:
    """Pre-flight result confirming a symbol is renameable.

    Returned by ``textDocument/prepareRename`` so the editor can pre-fill the
    rename dialog with the current name and highlight the correct range.

    Attributes:
        name: Current name of the symbol (pre-filled in the rename input box).
        range: Source range of the name token in the document.

    Example::

        prep = PrepareRenameInfo(
            name="customer_id",
            range=TextRange(line=5, col=4, end_line=5, end_col=15),
        )
    """

    name: str
    range: TextRange


@dataclass(frozen=True, slots=True)
class RenameResult:
    """Full rename outcome: all text edits across every affected file.

    Returned by ``textDocument/rename`` and translated into an LSP
    ``WorkspaceEdit`` by the presentation layer.

    Attributes:
        file_edits: Per-file edit bundles; one ``FileEdits`` per affected document.

    Example::

        result = RenameResult(
            file_edits=(
                FileEdits(uri="file:///a.yaml", edits=(e1,)),
                FileEdits(uri="file:///b.yaml", edits=(e2,)),
            ),
        )
    """

    file_edits: tuple[FileEdits, ...]


@dataclass(frozen=True, slots=True)
class PrepareRenameQuery:
    """Carries the cursor location and file content needed to check if a rename is possible.

    Attributes:
        uri: File URI of the document (e.g. ``file:///path/to/contract.yaml``).
        content: Full text content of the document at the time of the request.
        line: 0-indexed line number of the cursor.
        col: 0-indexed column number of the cursor.
    """

    uri: str
    content: str
    line: int
    col: int


@dataclass(frozen=True, slots=True)
class RenameQuery:
    """Carries everything needed to perform a cross-file rename operation.

    Attributes:
        uri: File URI of the document containing the rename target.
        content: Full text content of the document at the time of the request.
        line: 0-indexed line number of the cursor.
        col: 0-indexed column number of the cursor.
        new_name: The replacement name chosen by the user.
    """

    uri: str
    content: str
    line: int
    col: int
    new_name: str


RENAMEABLE_PATHS = re.compile(r"^(id|schema\.\d+\.name|schema\.\d+\.properties\.\d+\.name)$")


def is_renameable(dotted_path: str) -> bool:
    """Check if a dotted YAML path supports rename."""
    return RENAMEABLE_PATHS.match(dotted_path) is not None


def classify_rename(path: str) -> str | None:
    """Classify a dotted path into a rename category.

    Returns:
        ``"contract_id"``, ``"column"``, ``"schema"``, or ``None``.
    """
    if path == "id":
        return "contract_id"
    if re.match(r"schema\.\d+\.properties\.\d+\.name$", path):
        return "column"
    if re.match(r"schema\.\d+\.name$", path):
        return "schema"
    return None


def find_regex_edits(content: str, pattern: re.Pattern[str], new_name: str) -> list[TextEditInfo]:
    """Find all regex matches in content and produce TextEditInfo for each.

    Args:
        content: Text content to search.
        pattern: Compiled regex pattern.
        new_name: Replacement text for every match.

    Returns:
        List of text edits, one per match.
    """
    edits: list[TextEditInfo] = []
    for match in pattern.finditer(content):
        line_num = content[: match.start()].count("\n") + 1
        line_start = content.rfind("\n", 0, match.start()) + 1
        col_start = match.start() - line_start
        edits.append(
            TextEditInfo(
                range=TextRange(
                    start_line=line_num,
                    start_col=col_start + 1,
                    end_line=line_num,
                    end_col=col_start + len(match.group()) + 1,
                ),
                new_text=new_name,
            )
        )
    return edits
