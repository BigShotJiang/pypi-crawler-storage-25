"""Pure leaf-level primitives for the Quality subtree.

Owns the encoding / per-leaf rendering: node-id constructors, leaf
``TreeNode`` builders, header text functions, and per-outcome icon
lookup. Orchestration (placeholder / single / multi-schema dispatch,
schema-group rendering) lives in :mod:`quality_source`.
"""

from __future__ import annotations

from enum import StrEnum

from turbine.core.analysis.protocol import CheckResultItem
from turbine.core.analysis.run_rollup import RunRollup
from turbine.core.analysis.source_spans import pick_check_span
from turbine.core.analysis.tree_protocol import (
    NODE_SEPARATOR,
    OpenFileCommand,
    TreeCollapsibleState,
    TreeIcon,
    TreeNode,
)
from turbine.core.common import CheckDef
from turbine.core.common.check_outcome import CheckOutcome


class QualitySegment(StrEnum):
    """Segments inside Quality-section node IDs.

    Referenced via dotted-attribute access in match/case arms (a bare
    name in a case pattern binds instead of comparing).
    """

    SCHEMA = "schema"
    CHECK = "check"


# Per-leaf icon for one outcome. The section / schema-group header icon
# uses :attr:`RunRollup.icon` directly instead of going through this dict.
LEAF_ICONS: dict[CheckOutcome, TreeIcon] = {
    CheckOutcome.PASSED: TreeIcon.PASS,
    CheckOutcome.WARNED: TreeIcon.WARNING,
    CheckOutcome.FAILED: TreeIcon.FAIL,
    CheckOutcome.ERRORED: TreeIcon.FAIL,
    CheckOutcome.SKIPPED: TreeIcon.UNKNOWN,
}


def schema_group_node_id(section_node_id: str, schema_name: str) -> str:
    """ID for a schema-group node under a multi-schema Quality section."""
    return NODE_SEPARATOR.join((section_node_id, QualitySegment.SCHEMA, schema_name))


def check_node_id(section_node_id: str, schema_name: str | None, check_name: str) -> str:
    """ID for a check leaf; ``schema_name=None`` skips the schema segment."""
    if schema_name is None:
        return NODE_SEPARATOR.join((section_node_id, QualitySegment.CHECK, check_name))
    return NODE_SEPARATOR.join(
        (section_node_id, QualitySegment.SCHEMA, schema_name, QualitySegment.CHECK, check_name)
    )


def quality_section_label(rollup: RunRollup) -> str:
    """Header label: ``Quality (no run | run failed | X/Y)``."""
    if not rollup.is_run:
        return "Quality (no run)"
    if rollup.error is not None:
        return "Quality (run failed)"
    return f"Quality ({rollup.passed}/{rollup.total})"


def quality_spec_description(rollup: RunRollup) -> str:
    """Quality Spec leaf description: ``not run | run failed | X/Y passed``."""
    if not rollup.is_run:
        return "not run"
    if rollup.error is not None:
        return "run failed"
    return f"{rollup.passed}/{rollup.total} passed"


def leaf_description(item: CheckResultItem) -> str:
    """Render the description for one quality leaf (row-based vs aggregate)."""
    if item.is_row_based:
        if item.rows_tested == 0:
            return "no rows tested"
        return f"{item.rows_failed}/{item.rows_tested} failed"
    if item.measured_value is not None:
        return f"{item.check_name} = {item.measured_value:g}"
    if item.diagnostics:
        return item.diagnostics[0]
    return ""


def quality_leaf_from_outcome(
    *, uri: str, section_node_id: str, schema_name: str | None, item: CheckResultItem
) -> TreeNode:
    """Leaf rendering one ``CheckResultItem`` (real icon, description, tooltip)."""
    return TreeNode(
        id=check_node_id(section_node_id, schema_name, item.check_name),
        label=item.check_name,
        icon=LEAF_ICONS[item.outcome],
        collapsible_state=TreeCollapsibleState.NONE,
        description=leaf_description(item) or None,
        tooltip="\n".join(item.diagnostics) if item.diagnostics else None,
        command=OpenFileCommand(uri=uri, line=item.start_line or 1),
    )


def quality_leaf_from_defined_check(
    *, uri: str, section_node_id: str, schema_name: str | None, check: CheckDef
) -> TreeNode:
    """UNKNOWN leaf for a defined check that has no run outcome.

    Click-to-source uses :func:`pick_check_span`; description / tooltip
    are deliberately omitted (nothing to describe before a run).
    """
    span = pick_check_span(check)
    line = span.start_line if span is not None else 1
    return TreeNode(
        id=check_node_id(section_node_id, schema_name, check.name),
        label=check.name,
        icon=TreeIcon.UNKNOWN,
        collapsible_state=TreeCollapsibleState.NONE,
        command=OpenFileCommand(uri=uri, line=line),
    )
