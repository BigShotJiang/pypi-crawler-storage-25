"""Regex-based tokenizer for SQL + Jinja2 semantic highlighting."""

import re
from dataclasses import dataclass
from enum import StrEnum


class SqlTokenType(StrEnum):
    """Semantic token categories used by the LSP semantic-tokens provider.

    Each variant maps to an LSP ``SemanticTokenType`` so the editor can
    apply syntax-aware highlighting to SQL + Jinja2 files.

    Members:
        KEYWORD: SQL keywords like ``SELECT``, ``FROM``, ``GROUP BY``.
        VARIABLE: Jinja2 expressions (``{{ ... }}``) and blocks (``{% ... %}``).
        PARAMETER: Jinja2 parameter references (``{{ params.x }}``).
        OPERATOR: Comparison and assignment operators (``=``, ``<>``, ``>=``).
        STRING: Single-quoted string literals.
        NUMBER: Integer and decimal numeric literals.
        COMMENT: Single-line (``--``) and block (``/* */``) comments.
    """

    KEYWORD = "keyword"
    VARIABLE = "variable"
    PARAMETER = "parameter"
    OPERATOR = "operator"
    STRING = "string"
    NUMBER = "number"
    COMMENT = "comment"


@dataclass(frozen=True, slots=True)
class SqlToken:
    """A single token emitted by the SQL tokenizer, positioned in the source.

    Positions are 0-indexed to align with the LSP semantic-tokens delta
    encoding format.

    Attributes:
        line: 0-indexed line number where the token starts.
        col: 0-indexed column (character offset from line start).
        length: Number of characters the token spans on this line.
        token_type: Semantic category of the token.
    """

    line: int
    col: int
    length: int
    token_type: SqlTokenType


SQL_MULTI_KEYWORDS = [
    "GROUP BY",
    "ORDER BY",
    "LEFT JOIN",
    "RIGHT JOIN",
    "INNER JOIN",
    "FULL JOIN",
    "CROSS JOIN",
    "IS NOT NULL",
    "IS NULL",
    "NOT IN",
    "NOT LIKE",
    "NOT BETWEEN",
    "NOT EXISTS",
]

SQL_SINGLE_KEYWORDS = [
    "SELECT",
    "FROM",
    "WHERE",
    "HAVING",
    "JOIN",
    "ON",
    "AS",
    "AND",
    "OR",
    "NOT",
    "IN",
    "BETWEEN",
    "LIKE",
    "EXISTS",
    "CASE",
    "WHEN",
    "THEN",
    "ELSE",
    "END",
    "DISTINCT",
    "UNION",
    "ALL",
    "INSERT",
    "UPDATE",
    "DELETE",
    "SET",
    "INTO",
    "VALUES",
    "CREATE",
    "DROP",
    "ALTER",
    "TABLE",
    "INDEX",
    "TRUE",
    "FALSE",
    "NULL",
    "CAST",
    "BOOLEAN",
    "COUNT",
    "SUM",
    "AVG",
    "MIN",
    "MAX",
    "LIMIT",
    "OFFSET",
    "WITH",
    "RECURSIVE",
    "OVER",
    "PARTITION",
    "ROWS",
    "RANGE",
    "UNBOUNDED",
    "PRECEDING",
    "FOLLOWING",
    "CURRENT",
    "ROW",
]

MULTI_KW_PATTERN = "|".join(re.escape(kw) for kw in SQL_MULTI_KEYWORDS)
SINGLE_KW_PATTERN = "|".join(re.escape(kw) for kw in SQL_SINGLE_KEYWORDS)

TOKEN_PATTERNS: list[tuple[str, SqlTokenType]] = [
    (r"/\*[\s\S]*?\*/", SqlTokenType.COMMENT),
    (r"--[^\n]*", SqlTokenType.COMMENT),
    (r"'(?:[^'\\]|\\.)*'", SqlTokenType.STRING),
    (r"\{\{\s*params\.\w+\s*\}\}", SqlTokenType.PARAMETER),
    (r"\{\{[^}]*\}\}", SqlTokenType.VARIABLE),
    (r"\{%[^%]*%\}", SqlTokenType.VARIABLE),
    (rf"\b(?:{MULTI_KW_PATTERN})\b", SqlTokenType.KEYWORD),
    (rf"\b(?:{SINGLE_KW_PATTERN})\b", SqlTokenType.KEYWORD),
    (r"[<>!]=|<>|[=<>]", SqlTokenType.OPERATOR),
    (r"\b\d+(?:\.\d+)?\b", SqlTokenType.NUMBER),
]

COMBINED_PATTERN = re.compile(
    "|".join(f"(?P<t{i}>{pattern})" for i, (pattern, _) in enumerate(TOKEN_PATTERNS)), re.IGNORECASE
)

GROUP_TO_TYPE: dict[str, SqlTokenType] = {
    f"t{i}": token_type for i, (_, token_type) in enumerate(TOKEN_PATTERNS)
}


def tokenize_sql(text: str) -> list[SqlToken]:
    """Tokenize SQL + Jinja2 text into semantic tokens sorted by (line, col).

    Runs a single pass of the combined regex over *text*, converting each
    match into a ``SqlToken``. Multi-line tokens (block comments) are split
    into one token per line so the LSP delta encoding stays correct.

    Args:
        text: Full content of an SQL (or SQL + Jinja2) file.

    Returns:
        Tokens in source order, ready for LSP semantic-token delta encoding.

    Example::

        tokens = tokenize_sql("SELECT id FROM users WHERE active = TRUE")
        assert tokens[0].token_type == SqlTokenType.KEYWORD  # SELECT
    """
    line_starts = [0] + [i + 1 for i, ch in enumerate(text) if ch == "\n"]
    tokens: list[SqlToken] = []

    for match in COMBINED_PATTERN.finditer(text):
        if (group_name := match.lastgroup) is None:
            continue
        token_type = GROUP_TO_TYPE[group_name]
        matched_text = match.group()
        line_idx = _offset_to_line(match.start(), line_starts)
        col = match.start() - line_starts[line_idx]

        if "\n" in matched_text and token_type == SqlTokenType.COMMENT:
            tokens.extend(_split_multiline_token(line_idx, col, matched_text, token_type))
            continue
        tokens.append(SqlToken(line=line_idx, col=col, length=len(matched_text), token_type=token_type))

    return tokens


def _split_multiline_token(
    start_line: int, start_col: int, text: str, token_type: SqlTokenType
) -> list[SqlToken]:
    """Split a multiline token (e.g. block comment) into per-line tokens."""
    return [
        SqlToken(
            line=start_line + idx,
            col=start_col if idx == 0 else 0,
            length=len(line_text),
            token_type=token_type,
        )
        for idx, line_text in enumerate(text.split("\n"))
        if line_text
    ]


def _offset_to_line(offset: int, line_starts: list[int]) -> int:
    """Convert a character offset to a 0-indexed line number via binary search."""
    lo, hi = 0, len(line_starts) - 1
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if line_starts[mid] <= offset:
            lo = mid
        else:
            hi = mid - 1
    return lo
