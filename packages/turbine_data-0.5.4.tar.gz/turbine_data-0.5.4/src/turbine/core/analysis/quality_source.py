"""``QualitySource``: one renderable Quality (sub)tree.

The Contract row's Quality section and a Quality Spec leaf's expansion
are two construction sites of the same type — once the URI is resolved,
the rendering is identical (same shape, same ``RunRollup`` math, same
leaves). This module owns the orchestration; ``quality_leaves`` keeps
only the leaf-level primitives (id constructors, header text, individual
leaf TreeNode builders).

Public interface: ``QualitySource.from_snapshot``, ``render_top``,
``render_schema``, and the ``rollup`` property — that is the test
surface and the only thing callers learn. The leaf-construction helpers
(``leaves_for``, ``schema_group``, ``scoped_rollup``, ``outcomes_for``)
are module-private.

See ``CONTEXT.md`` (Quality Source) for the domain definition.
"""

from __future__ import annotations

from dataclasses import dataclass

from turbine.core.analysis.protocol import CheckResultItem, RunCheckResult
from turbine.core.analysis.quality_leaves import (
    NODE_SEPARATOR,
    quality_leaf_from_defined_check,
    quality_leaf_from_outcome,
    schema_group_node_id,
)
from turbine.core.analysis.run_rollup import RunRollup
from turbine.core.analysis.tree_builder import TreeSnapshotData
from turbine.core.analysis.tree_protocol import TreeCollapsibleState, TreeIcon, TreeNode
from turbine.core.common import DatasetSpec


def dataset_specs_for(snapshot: TreeSnapshotData, uri: str) -> tuple[DatasetSpec, ...]:
    """Every ``DatasetSpec`` the project index holds for *uri* (one per schema)."""
    return tuple(
        spec for spec in snapshot.project_index.contracts() if spec.metadata.source_path.as_uri() == uri
    )


@dataclass(frozen=True, slots=True)
class QualitySource:
    """One renderable Quality (sub)tree.

    Encapsulates the four facts a Quality renderer needs: *render_uri*
    (which file the leaves point to), *section_node_id* (where the leaves
    anchor in the tree), *dataset_specs* (per-schema check definitions),
    and *quality* (the latest Run Result, or None).
    """

    render_uri: str
    section_node_id: str
    dataset_specs: tuple[DatasetSpec, ...]
    quality: RunCheckResult | None

    @property
    def rollup(self) -> RunRollup:
        """``RunRollup`` for the section header (label + icon)."""
        return RunRollup.from_run(self.quality)

    @classmethod
    def from_snapshot(
        cls, snapshot: TreeSnapshotData, render_uri: str, *, section_node_id: str
    ) -> QualitySource:
        """Resolve a source from a workspace snapshot keyed by *render_uri*."""
        return cls(
            render_uri=render_uri,
            section_node_id=section_node_id,
            dataset_specs=dataset_specs_for(snapshot, render_uri),
            quality=snapshot.check_results.get(render_uri),
        )

    def render_top(self) -> tuple[TreeNode, ...]:
        """Top-level Quality children: placeholder, flat leaves, or schema groups."""
        total_defined = sum(len(spec.checks) for spec in self.dataset_specs)
        if total_defined == 0:
            return (
                TreeNode(
                    id=NODE_SEPARATOR.join((self.section_node_id, "placeholder")),
                    label="No checks defined",
                    icon=TreeIcon.INFO,
                    collapsible_state=TreeCollapsibleState.NONE,
                ),
            )
        if len(self.dataset_specs) == 1:
            return leaves_for(self, self.dataset_specs[0], schema_name=None)
        return tuple(schema_group(self, spec) for spec in self.dataset_specs)

    def render_schema(self, schema_name: str) -> tuple[TreeNode, ...]:
        """Leaves under one schema-group node (multi-schema contracts)."""
        spec = next((s for s in self.dataset_specs if s.table.table == schema_name), None)
        if spec is None:
            return ()
        return leaves_for(self, spec, schema_name=schema_name)


def leaves_for(
    source: QualitySource, spec: DatasetSpec, *, schema_name: str | None
) -> tuple[TreeNode, ...]:
    """One leaf per defined check; outcome-driven if a matching result exists."""
    by_name: dict[str, CheckResultItem] = {item.check_name: item for item in outcomes_for(source, spec)}
    return tuple(
        quality_leaf_from_outcome(
            uri=source.render_uri,
            section_node_id=source.section_node_id,
            schema_name=schema_name,
            item=by_name[check.name],
        )
        if check.name in by_name
        else quality_leaf_from_defined_check(
            uri=source.render_uri,
            section_node_id=source.section_node_id,
            schema_name=schema_name,
            check=check,
        )
        for check in spec.checks
    )


def schema_group(source: QualitySource, spec: DatasetSpec) -> TreeNode:
    """Collapsed group node for one schema; icon comes from a scoped rollup."""
    return TreeNode(
        id=schema_group_node_id(source.section_node_id, spec.table.table),
        label=spec.table.table,
        icon=scoped_rollup(source, spec).icon,
        collapsible_state=TreeCollapsibleState.COLLAPSED,
    )


def scoped_rollup(source: QualitySource, spec: DatasetSpec) -> RunRollup:
    """Rollup restricted to *spec*'s checks; ``no_run`` if the run errored."""
    if source.quality is None or source.quality.error is not None:
        return RunRollup.no_run()
    return RunRollup.from_outcomes(outcomes_for(source, spec))


def outcomes_for(source: QualitySource, spec: DatasetSpec) -> tuple[CheckResultItem, ...]:
    """Outcomes whose ``(check_name, dataset)`` match *spec*'s checks.

    ``dataset == ""`` is the unknown-sentinel from older / hand-built
    results — those match by name only so legacy results still render.
    """
    if source.quality is None:
        return ()
    names = {check.name for check in spec.checks}
    spec_id = str(spec.table)
    return tuple(
        item
        for item in source.quality.outcomes
        if item.check_name in names and item.dataset in {"", spec_id}
    )
