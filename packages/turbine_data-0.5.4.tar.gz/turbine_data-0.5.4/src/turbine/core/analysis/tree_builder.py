"""Port for tree-view builders.

A ``TreeBuilder`` renders one ``TreeId`` lazily. Builders are stateless
w.r.t. the client: ``node_id`` is opaque to the protocol but
self-describing within each builder, so any client expanding the same
node sees the same children. Adapters live in
``presentation/lsp/api/trees/``; the registry composes them and routes
``turbine/tree/*`` requests + change notifications.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import ClassVar, Protocol

from turbine.core.analysis.contract_health import DiagnosticCountsPort
from turbine.core.analysis.diagnostic_store import DiagnosticStore
from turbine.core.analysis.protocol import RunCheckResult
from turbine.core.analysis.tree_protocol import TreeId, TreeNode
from turbine.core.contract import ProjectIndex
from turbine.core.contract.dismissal import DismissalStore


class TreeSnapshotData(Protocol):
    """Per-call read-only data tree builders pull from at build time.

    Implementations expose the project index, latest run results, unified
    diagnostics, the diagnostic counts port the overview service reads from,
    and the dismissal store so per-occurrence dismissals can be filtered out
    of validation rows. ``WorkspaceSnapshot`` subclasses this explicitly;
    tests can build a small stub matching the same shape.
    """

    project_index: ProjectIndex
    diagnostic_counts: DiagnosticCountsPort
    check_results: dict[str, RunCheckResult]
    diagnostic_store: DiagnosticStore
    dismissal_store: DismissalStore


@dataclass(frozen=True, slots=True)
class TreeContext:
    """Per-request scoping passed to every builder call.

    ``active_uri`` is the editor's foreground document, when relevant.
    ``snapshot`` carries the per-request read-only data (project index,
    check results, validation results) for trees that aggregate
    multi-contract state. Workspace-scoped trees that need only static
    config ignore both fields.
    """

    active_uri: str | None = None
    snapshot: TreeSnapshotData | None = None


@dataclass(frozen=True, slots=True)
class TreeInvalidation:
    """How a builder reacts to a domain event.

    ``full=True`` triggers a full refetch. Otherwise ``node_ids`` lists
    specific subtrees whose children changed. ``empty`` means the event
    is irrelevant to this builder.
    """

    full: bool = False
    node_ids: tuple[str, ...] = ()

    @classmethod
    def none(cls) -> TreeInvalidation:
        return cls()

    @classmethod
    def all(cls) -> TreeInvalidation:
        return cls(full=True)

    @classmethod
    def nodes(cls, *ids: str) -> TreeInvalidation:
        return cls(node_ids=tuple(ids))

    @property
    def empty(self) -> bool:
        return not self.full and not self.node_ids


class TreeBuilder(Protocol):
    """Renders one tree. Implementations must subclass explicitly."""

    tree_id: ClassVar[TreeId]

    def build_root(self, ctx: TreeContext) -> tuple[TreeNode, ...]: ...

    def build_children(self, node_id: str, ctx: TreeContext) -> tuple[TreeNode, ...]: ...

    def invalidation_for(self, event: object) -> TreeInvalidation: ...
