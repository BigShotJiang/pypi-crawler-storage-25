"""Unified diagnostic store keyed by document URI and diagnostic source."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import StrEnum

from turbine.core.analysis.contract_health import DiagnosticCounts
from turbine.core.building_blocks import Diagnostic, Severity


class DiagnosticSource(StrEnum):
    """Source bucket for diagnostics sharing one document URI."""

    LINT = "lint"
    DRIFT = "drift"


@dataclass(frozen=True, slots=True)
class DiagnosticStoreKey:
    """Composite key for source-specific diagnostic replacement."""

    uri: str
    source: DiagnosticSource


@dataclass(frozen=True, slots=True)
class DiagnosticStore:
    """Immutable store for per-URI diagnostics from lint and drift producers."""

    entries: dict[DiagnosticStoreKey, tuple[Diagnostic, ...]] = field(default_factory=dict)

    @classmethod
    def empty(cls) -> DiagnosticStore:
        """Return an empty store."""
        return cls(entries={})

    def replace(
        self, uri: str, source: DiagnosticSource, diagnostics: tuple[Diagnostic, ...]
    ) -> DiagnosticStore:
        """Replace all diagnostics for one URI/source bucket."""
        key = DiagnosticStoreKey(uri=uri, source=source)
        return DiagnosticStore(entries={**self.entries, key: diagnostics})

    def clear(self, uri: str, source: DiagnosticSource) -> DiagnosticStore:
        """Remove one URI/source bucket."""
        key = DiagnosticStoreKey(uri=uri, source=source)
        if key not in self.entries:
            return self
        return DiagnosticStore(
            entries={entry_key: value for entry_key, value in self.entries.items() if entry_key != key}
        )

    def latest_for_uri(self, uri: str) -> tuple[Diagnostic, ...]:
        """Return the lint + drift union for *uri* in stable source order."""
        diagnostics: list[Diagnostic] = []
        for source in DiagnosticSource:
            diagnostics.extend(self.entries.get(DiagnosticStoreKey(uri=uri, source=source), ()))
        return tuple(diagnostics)

    def counts_for(self, uri: str) -> DiagnosticCounts:
        """Return error/warning counts for the lint + drift union."""
        errors = 0
        warnings = 0
        for diagnostic in self.latest_for_uri(uri):
            if diagnostic.severity == Severity.ERROR:
                errors += 1
            elif diagnostic.severity == Severity.WARNING:
                warnings += 1
        return DiagnosticCounts(errors=errors, warnings=warnings)

    def has_source(self, uri: str, source: DiagnosticSource) -> bool:
        """Return True when *uri* has a bucket for *source*, even when it is empty."""
        return DiagnosticStoreKey(uri=uri, source=source) in self.entries
