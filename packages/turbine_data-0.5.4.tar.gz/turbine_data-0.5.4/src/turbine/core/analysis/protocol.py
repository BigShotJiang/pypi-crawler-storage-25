"""Custom turbine/* LSP protocol types for IDE extension communication.

Defines typed request/response dataclasses for 11 custom LSP methods,
capability negotiation types, and supporting enums.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from turbine.core.building_blocks.onboarding_actions import StepAction, StepActionKind, StepKind
from turbine.core.building_blocks.onboarding_content import StepContentBlock
from turbine.core.building_blocks.onboarding_targets import HighlightTarget, ResolvedHighlight
from turbine.core.common import CheckOutcome

TURBINE_RUN_CHECK = "turbine/runCheck"
TURBINE_VALIDATE_SCHEMA = "turbine/validateSchema"
TURBINE_OVERVIEW_DATA = "turbine/overviewData"
TURBINE_REFERENCES_DATA = "turbine/referencesData"
TURBINE_ONBOARDING_PHASE = "turbine/onboardingPhase"
TURBINE_ONBOARDING_INSTALL_COMMANDS = "turbine/onboarding/installCommands"
TURBINE_ONBOARDING_DISMISS = "turbine/onboarding/dismiss"
TURBINE_ONBOARDING_RESET = "turbine/onboarding/reset"
TURBINE_ONBOARDING_SAVE_TOUR_PROGRESS = "turbine/onboarding/saveTourProgress"
TURBINE_ONBOARDING_GET_TOUR_PROGRESS = "turbine/onboarding/getTourProgress"
TURBINE_ONBOARDING_LIST_TOURS = "turbine/onboarding/listTours"
TURBINE_ONBOARDING_WATCH_STEP = "turbine/onboarding/watchStep"
TURBINE_ONBOARDING_UNWATCH_STEP = "turbine/onboarding/unwatchStep"
TURBINE_ONBOARDING_STEP_COMPLETED = "turbine/onboarding/stepCompleted"
TURBINE_ONBOARDING_ACTION_INVOKED = "turbine/onboarding/actionInvoked"
TURBINE_ONBOARDING_SURFACE_VISIBILITY_CHANGED = "turbine/onboarding/surfaceVisibilityChanged"
TURBINE_ONBOARDING_RUN_STEP = "turbine/onboarding/runStep"
TURBINE_SCAFFOLD_PROJECT = "turbine/scaffoldProject"
TURBINE_CLEANUP_TOUR_SCAFFOLD = "turbine/cleanupTourScaffold"
TURBINE_CHECK_WORKSPACE_EMPTY = "turbine/checkWorkspaceEmpty"
TURBINE_CONFIRM_SCAFFOLD = "turbine/onboarding/confirmScaffold"
TURBINE_CHECK_LOG = "turbine/checkLog"
TURBINE_WORKSPACE_CONFIG = "turbine/workspaceConfig"
TURBINE_FILE_CONTEXT = "turbine/fileContext"
TURBINE_LIST_DATASOURCES = "turbine/listDatasources"
TURBINE_TEST_DATASOURCE = "turbine/testDatasource"
TURBINE_TUNE_PREPARE_SESSION = "turbine/tune/prepareSession"
TURBINE_TUNE_QUERY_CURRENT_VALUE = "turbine/tune/queryCurrentValue"
TURBINE_TUNE_APPLY_EDIT = "turbine/tune/applyEdit"
TURBINE_TUNE_LIST_COLUMNS = "turbine/tune/listColumns"
TURBINE_LIST_CHECKS = "turbine/listChecks"


class DriftChangeKind(StrEnum):
    """Kind of drift between contract definition and actual database schema."""

    ADDED = "added"
    REMOVED = "removed"
    TYPE_CHANGED = "type_changed"
    NULLABLE_CHANGED = "nullable_changed"
    PK_CHANGED = "pk_changed"
    UNIQUE_CHANGED = "unique_changed"


class ReferenceKind(StrEnum):
    """Type of cross-contract reference."""

    QUALITY_SPEC = "quality_spec"
    FIELD_REFERENCE = "field_reference"


class RunStepOutcome(StrEnum):
    """Outcome of a turbine/onboarding/runStep RunCheck dispatch.

    Maps the success path (PASSED/FAILED) onto the wire and keeps a dedicated
    ERROR value for handler-level failures (parse error, missing datasource,
    executor exception) so the panel can render a red banner without having
    to guess from rows_tested==0.
    """

    PASSED = "PASSED"
    FAILED = "FAILED"
    ERROR = "ERROR"


@dataclass(frozen=True, slots=True)
class CheckResultItem:
    """Outcome of a single check execution.

    ``is_row_based`` is server-derived from the underlying check type. Row-
    based checks (missing, duplicate, freshness, custom SQL) measure rows;
    structural checks (schema) do not. The flag lets the client suppress
    the misleading ``(N/M rows)`` suffix without having to know which
    check types are structural — that policy lives in the server.

    ``measured_value`` is the scalar metric the check produced (e.g. a
    missing-percent or a row count). ``None`` when the check has no scalar
    measurement (schema, structural) or when the result was never measured
    (errored, skipped).

    ``start_line`` / ``start_col`` / ``end_line`` / ``end_col`` are 1-indexed
    source positions in the originating YAML — populated by the server when
    the check has a resolved span. ``None`` on all four when no location is
    available; the client should fall back to (0, 0).

    ``contract_id`` is the id of the contract this check belongs to. It
    carries per-item attribution so a multi-contract ``RunCheckResult``
    (run-all) keeps each outcome's parent contract grouped on the client
    side without inferring from name prefixes or call order.

    ``dataset`` is the schema-qualified table this check ran against. It
    disambiguates same-named checks in multi-dataset contracts; empty string
    means unknown.
    """

    check_name: str
    is_row_based: bool
    outcome: CheckOutcome
    rows_tested: int
    rows_failed: int
    contract_id: str = ""
    dataset: str = ""
    diagnostics: tuple[str, ...] = ()
    measured_value: float | None = None
    start_line: int | None = None
    start_col: int | None = None
    end_line: int | None = None
    end_col: int | None = None


@dataclass(frozen=True, slots=True)
class DriftColumn:
    """A single column that drifted between contract and database.

    ``start_line`` / ``start_col`` / ``end_line`` / ``end_col`` are 1-indexed
    source positions in the contract YAML — populated by the server when the
    column can be located (MISSING_IN_DB lands on the column itself, EXTRA_IN_DB
    lands on the enclosing schema/table line). ``None`` on all four when no
    location is available; the client should fall back to (0, 0).
    """

    name: str
    change: DriftChangeKind
    expected_type: str | None = None
    actual_type: str | None = None
    start_line: int | None = None
    start_col: int | None = None
    end_line: int | None = None
    end_col: int | None = None


@dataclass(frozen=True, slots=True)
class SchemaDrift:
    """Drift results for one schema within a contract."""

    schema_name: str
    columns: tuple[DriftColumn, ...]


@dataclass(frozen=True, slots=True)
class RunCheckParams:
    """Parameters for turbine/runCheck request.

    When both ``dataset`` and ``check_name`` are set the run narrows to
    that single check; otherwise the full contract at ``uri`` runs.

    *datasource* is optional: when omitted, the server resolves a default
    via ``RunCheckResolver.default_datasource_provider`` (the first
    datasource visible to the contract). Letting the server pick keeps
    bulk callers like ``turbine.runQualityWorkspace`` free of per-contract
    datasource lookups.

    Setting ``all`` widens the run to every contract discovered in the
    project. The ``uri`` is still required (the resolver uses it to pick
    a default datasource and to anchor the project root) but the run
    expands to an ``AllContracts`` target rather than the file at *uri*.
    """

    uri: str
    datasource: str | None = None
    dataset: str | None = None
    check_name: str | None = None
    all: bool = False
    work_done_token: int | str | None = None


@dataclass(frozen=True, slots=True)
class RunCheckResult:
    """Result of turbine/runCheck request.

    ``cancelled`` flips to True when the run exited at a check boundary in
    response to a cooperative cancel (toast [✕] or ``$/cancelRequest``).
    The N completed outcomes still arrive on the wire — cancel is not a
    rollback. Clients use the flag to render a "Cancelled at N/T" badge
    instead of the success / failure summary.
    """

    contract_id: str
    outcomes: tuple[CheckResultItem, ...]
    passed: bool
    error: str | None = None
    cancelled: bool = False


@dataclass(frozen=True, slots=True)
class ValidateSchemaParams:
    """Parameters for turbine/validateSchema request."""

    uri: str
    datasource: str | None = None


@dataclass(frozen=True, slots=True)
class ValidateSchemaLspResult:
    """Result of turbine/validateSchema request."""

    contract_id: str
    schemas: tuple[SchemaDrift, ...]
    has_drift: bool
    error: str | None = None


@dataclass(frozen=True, slots=True)
class OverviewDataParams:
    """Parameters for turbine/overviewData request (workspace-level)."""


class ContractStatus(StrEnum):
    """Aggregate health of a single contract row."""

    ERROR = "error"
    WARNING = "warning"
    PASSING = "passing"
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class ContractHealth:
    """Health summary for a single contract in the overview."""

    contract_id: str
    uri: str
    error_count: int
    warning_count: int
    check_status: CheckOutcome | None = None
    status: ContractStatus = ContractStatus.UNKNOWN
    description: str = ""


@dataclass(frozen=True, slots=True)
class OverviewDataResult:
    """Result of turbine/overviewData request."""

    contracts: tuple[ContractHealth, ...]


@dataclass(frozen=True, slots=True)
class ContractQuality:
    """Quality check results for a single contract.

    ``error`` carries the run-level error string (set when the run itself
    failed before producing per-check outcomes — e.g. connection refused).
    Renderers branch on it to show ``"run failed"`` instead of ``"X/Y"``.
    """

    contract_id: str
    uri: str
    outcomes: tuple[CheckResultItem, ...]
    passed: bool
    error: str | None = None

    @classmethod
    def from_run_result(cls, result: RunCheckResult, uri: str) -> ContractQuality:
        return cls(
            contract_id=result.contract_id,
            uri=uri,
            outcomes=result.outcomes,
            passed=result.passed,
            error=result.error,
        )


@dataclass(frozen=True, slots=True)
class ContractDrift:
    """Drift status for a single contract."""

    contract_id: str
    uri: str
    schemas: tuple[SchemaDrift, ...]
    has_drift: bool
    error: str | None = None


@dataclass(frozen=True, slots=True)
class ReferencesDataParams:
    """Parameters for turbine/referencesData request (workspace-level)."""


@dataclass(frozen=True, slots=True)
class ContractReference:
    """A cross-contract reference edge."""

    source_contract_id: str
    target_contract_id: str
    reference_type: ReferenceKind
    source_uri: str | None = None
    target_uri: str | None = None


@dataclass(frozen=True, slots=True)
class ReferencesDataResult:
    """Result of turbine/referencesData request."""

    references: tuple[ContractReference, ...]


@dataclass(frozen=True, slots=True)
class OnboardingStatusResult:
    """Internal facts the phase service reads from a workspace folder.

    Not on the wire any longer; the editor consumes ``PhaseDto`` instead.
    Kept as the return shape of ``ProjectSetupService.get_status()`` because
    the existing service is reused as a building block by
    ``OnboardingPhaseService``.
    """

    has_pyproject: bool
    has_contracts: bool
    has_quality: bool
    has_datasources: bool
    has_tool_turbine: bool = False
    turbine_version: str | None = None


@dataclass(frozen=True, slots=True)
class InstallCommandsParams:
    """Parameters for turbine/onboarding/installCommands request."""

    workspace_folder_uri: str
    choice: str


@dataclass(frozen=True, slots=True)
class InstallCommandsResult:
    """Ordered shell-command list for the chosen database extra."""

    commands: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class OnboardingDismissParams:
    """Parameters for turbine/onboarding/dismiss request."""

    workspace_folder_uri: str
    phase_kind: str


@dataclass(frozen=True, slots=True)
class OnboardingDismissResult:
    """Empty result for turbine/onboarding/dismiss; the editor only awaits the ack."""


@dataclass(frozen=True, slots=True)
class OnboardingResetParams:
    """Parameters for turbine/onboarding/reset request."""

    workspace_folder_uri: str


@dataclass(frozen=True, slots=True)
class OnboardingResetResult:
    """Empty result for turbine/onboarding/reset; the editor only awaits the ack."""


@dataclass(frozen=True, slots=True)
class TourProgressDto:
    """One tour's progress snapshot keyed by ``(workspace_folder_uri, tour_id)``.

    The tuple-keyed shape is the load-bearing contract: resuming a tour in
    folder A must never surface folder B's saved step.
    """

    workspace_folder_uri: str
    tour_id: str
    last_step_id: str | None
    completed_step_ids: tuple[str, ...]
    finished: bool


@dataclass(frozen=True, slots=True)
class SaveTourProgressParams:
    """Params for turbine/onboarding/saveTourProgress."""

    record: TourProgressDto


@dataclass(frozen=True, slots=True)
class SaveTourProgressResult:
    """Empty ack for turbine/onboarding/saveTourProgress."""


@dataclass(frozen=True, slots=True)
class GetTourProgressParams:
    """Params for turbine/onboarding/getTourProgress."""

    workspace_folder_uri: str
    tour_id: str


@dataclass(frozen=True, slots=True)
class GetTourProgressResult:
    """Result for turbine/onboarding/getTourProgress; ``record`` is None when no save exists."""

    record: TourProgressDto | None


class ScaffoldVariant(StrEnum):
    """Which content tree ``ProjectScaffoldService.scaffold`` copies.

    ``DEMO`` copies the self-contained onboarding-tour project (pyproject.toml,
    contracts, datasources, quality spec, checks, .duckdb fixtures) to the
    workspace root. ``BARE`` writes a starter contract and a per-dialect
    datasource template; the dialect is chosen by the accompanying
    ``DatabaseChoiceId``.
    """

    DEMO = "demo"
    BARE = "bare"


@dataclass(frozen=True, slots=True)
class ScaffoldProjectParams:
    """Parameters for turbine/scaffoldProject request."""

    variant: str = "bare"
    database: str | None = None


@dataclass(frozen=True, slots=True)
class ScaffoldProjectResult:
    """Result of turbine/scaffoldProject request."""

    created_files: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class CleanupTourScaffoldParams:
    """Parameters for turbine/cleanupTourScaffold request.

    Empty payload — the handler always cleans the active project layout's
    root using the manifest persisted in ``.turbine/tour-scaffold.json``.
    """


@dataclass(frozen=True, slots=True)
class CleanupTourScaffoldResult:
    """Result of turbine/cleanupTourScaffold request.

    ``deleted_files`` lists every workspace-relative path the handler
    actually removed. ``missing_files`` lists manifest entries that no
    longer existed on disk — useful for editor logs but not an error.
    """

    deleted_files: tuple[str, ...]
    missing_files: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ConfirmScaffoldParams:
    """Parameters for the server -> client turbine/onboarding/confirmScaffold request.

    Sent when the user tries to enter the demo tour in a non-empty workspace.
    ``reasons`` mirrors :class:`CheckWorkspaceEmptyResult.reasons` so the editor
    can render a precise "tour will write the following kinds of files" hint
    before asking for consent.
    """

    reasons: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class ConfirmScaffoldResult:
    """Result of the server -> client turbine/onboarding/confirmScaffold request.

    The editor returns ``confirmed=True`` when the user clicked Yes, else
    ``False``. No "Cancel" variant — anything other than explicit consent is
    treated as a refusal.
    """

    confirmed: bool


@dataclass(frozen=True, slots=True)
class CheckWorkspaceEmptyParams:
    """Parameters for turbine/checkWorkspaceEmpty request.

    Empty payload — the handler always inspects the active project layout's
    root. Callers send an empty object.
    """


@dataclass(frozen=True, slots=True)
class CheckWorkspaceEmptyResult:
    """Result of turbine/checkWorkspaceEmpty request.

    ``empty`` is True when the workspace has no user-authored Turbine content
    that the demo tour scaffold would step on. ``reasons`` enumerates the
    blocking files / dirs so the editor can surface a precise hint when it
    redirects the user to a fresh-folder picker.
    """

    empty: bool
    reasons: tuple[str, ...]


class StepSkipKind(StrEnum):
    """Discriminator over the four panel button states a step can present.

    ``NONE`` is a narration step. ``EDIT`` and ``RUN_INTROSPECTION`` both render
    as a Skip button (Turbine fills the field / runs introspection for the
    user). ``RUN_CHECK`` renders the Run check button.
    """

    NONE = "none"
    EDIT = "edit"
    RUN_CHECK = "run_check"
    RUN_INTROSPECTION = "run_introspection"


@dataclass(frozen=True, slots=True)
class StepDto:
    """One onboarding step with a semantic highlight target.

    ``gated`` is true when the Step has a `StepCompletion`: the editor must
    keep Next disabled until the LSP sends `turbine/onboarding/stepCompleted`.
    The variant identity stays server-side; the editor never sees it.
    """

    id: str
    title: str
    content: tuple[StepContentBlock, ...]
    target: HighlightTarget
    resolved_target: ResolvedHighlight | None
    kind: StepKind
    action: StepAction | None
    skip_kind: StepSkipKind = StepSkipKind.NONE
    gated: bool = False


@dataclass(frozen=True, slots=True)
class TourDto:
    """One tour returned by turbine/onboarding/listTours."""

    id: str
    title: str
    steps: tuple[StepDto, ...]


@dataclass(frozen=True, slots=True)
class ListToursParams:
    """Parameters for turbine/onboarding/listTours request (no input fields)."""


@dataclass(frozen=True, slots=True)
class ListToursResult:
    """Result of turbine/onboarding/listTours request."""

    tours: tuple[TourDto, ...]


@dataclass(frozen=True, slots=True)
class WatchStepParams:
    """Params for turbine/onboarding/watchStep."""

    tour_id: str
    step_id: str


@dataclass(frozen=True, slots=True)
class UnwatchStepParams:
    """Parameters for turbine/onboarding/unwatchStep request (no input fields)."""


@dataclass(frozen=True, slots=True)
class StepCompletedParams:
    """Notification params for turbine/onboarding/stepCompleted (server to client)."""

    tour_id: str
    step_id: str


@dataclass(frozen=True, slots=True)
class ActionInvokedParams:
    """Params for turbine/onboarding/actionInvoked (editor to server).

    Sent when the user clicks an editor-only action button (e.g.
    ``open_all_contracts``, ``open_dashboard``). LSP-routed actions like
    ``run_validate`` and ``run_single_check`` are observed intrinsically by
    their request handlers; the editor does not send this for those.
    """

    tour_id: str
    step_id: str
    kind: StepActionKind


@dataclass(frozen=True, slots=True)
class SurfaceVisibilityChangedParams:
    """Params for turbine/onboarding/surfaceVisibilityChanged (editor to server).

    The editor sends this whenever a tour-relevant surface (tree view,
    panel) toggles visibility, and once on activation to seed initial
    state. ``surface_id`` is an opaque agreement with the server tours
    (e.g. ``"all-contracts"`` for the Turbine sidebar).
    """

    surface_id: str
    visible: bool


@dataclass(frozen=True, slots=True)
class FailingSample:
    """Up to N rows of a failing check, with column headers for the panel table."""

    columns: tuple[str, ...]
    rows: tuple[tuple[object, ...], ...] = ()


@dataclass(frozen=True, slots=True)
class RunStepResult:
    """Response for turbine/onboarding/runStep when the skip action is a RunCheck.

    ``outcome`` is the discriminator: PASSED / FAILED carry row counts and
    (on FAILED) a capped ``failing_sample``; ERROR carries a human message
    in ``error`` and leaves the counters at zero.
    """

    outcome: RunStepOutcome
    rows_tested: int = 0
    rows_failed: int = 0
    failing_sample: FailingSample | None = None
    total_failing: int = 0
    error: str | None = None


@dataclass(frozen=True, slots=True)
class RunStepParams:
    """Params for turbine/onboarding/runStep — identifies a tour step to skip-run."""

    tour_id: str
    step_id: str


@dataclass(frozen=True, slots=True)
class DatasourceInfo:
    """A datasource available in the workspace."""

    name: str
    ds_type: str
    uri: str


@dataclass(frozen=True, slots=True)
class ListDatasourcesParams:
    """Parameters for turbine/listDatasources request.

    The optional ``uri`` narrows the lookup to the project enclosing that file
    (so a sandbox contract sees only its sandbox's ``local.yml``); when
    omitted, the workspace-root catalogue is returned.
    """

    uri: str | None = None


@dataclass(frozen=True, slots=True)
class ListDatasourcesResult:
    """Result of turbine/listDatasources request."""

    datasources: tuple[DatasourceInfo, ...]


@dataclass(frozen=True, slots=True)
class TestDatasourceParams:
    """Request params for turbine/testDatasource.

    *uri* is an anchor inside the project that owns the datasource —
    typically the datasource YAML file itself, taken from
    ``TreeNode.resourceUri`` on the sidebar row that triggered the
    request. The server uses it to resolve the right per-project
    datasource repository so two projects can both define ``local``
    without collision.
    """

    __test__ = False

    name: str
    uri: str


@dataclass(frozen=True, slots=True)
class TestDatasourceResult:
    """Result of turbine/testDatasource request."""

    name: str
    ok: bool
    latency_ms: int | None = None
    error: str | None = None


@dataclass(frozen=True, slots=True)
class CheckLogParams:
    """Notification params for turbine/checkLog (server to client)."""

    uri: str
    line: str
    excerpt: str | None = None
    operation_token: int | str | None = None


@dataclass(frozen=True, slots=True)
class TuneRequestParams:
    """Params for turbine/tune/queryCurrentValue.

    A contract URI, the check name inside that contract, and an optional
    datasource name.
    """

    uri: str
    check_name: str
    datasource: str | None = None


@dataclass(frozen=True, slots=True)
class TunePrepareSessionParams:
    """Params for turbine/tune/prepareSession.

    Adds an optional ``time_column`` override on top of the shared tune
    inputs so the panel can pin a specific column when the contract's
    SLA latency element is missing.
    """

    uri: str
    check_name: str
    datasource: str | None = None
    time_column: str | None = None


@dataclass(frozen=True, slots=True)
class TuneListColumnsParams:
    """Params for turbine/tune/listColumns."""

    uri: str
    datasource: str


@dataclass(frozen=True, slots=True)
class TuneListColumnsResult:
    """Result of turbine/tune/listColumns -- column name/type/isTemporal entries."""

    columns: tuple[dict[str, str | bool], ...]


@dataclass(frozen=True, slots=True)
class TuneCurrentValueResult:
    """Result of turbine/tune/queryCurrentValue \u2014 a single scalar metric value."""

    value: float | None
    error: str | None = None


@dataclass(frozen=True, slots=True)
class TuneApplyEditParams:
    """Request params for turbine/tune/applyEdit."""

    uri: str
    check_name: str
    draft_config: dict[str, object]


@dataclass(frozen=True, slots=True)
class TuneApplyEditResult:
    """Result of turbine/tune/applyEdit.

    The server applies edits via the injected ``CodeWriter``; the
    client only needs to know whether the operation succeeded.
    """

    applied: bool = False
    error: str | None = None


@dataclass(frozen=True, slots=True)
class WorkspaceConfigParams:
    """Notification params for turbine/workspaceConfig (server to client).

    Sent once after ``initialized`` so the client can update its document
    selectors and file watchers from the authoritative server-resolved layout
    instead of re-parsing pyproject.toml with a regex.
    """

    root: str
    contracts_dir: str
    quality_dir: str
    checks_dir: str
    datasources_dir: str


class FileKind(StrEnum):
    """Recognised Turbine document kinds reported on ``turbine/fileContext``."""

    DATA_CONTRACT = "DataContract"
    QUALITY_SPEC = "QualitySpec"
    DATASOURCE = "Datasource"


@dataclass(frozen=True, slots=True)
class FileContextParams:
    """Notification params for turbine/fileContext (server to client).

    Fired from ``did_open`` and ``did_change`` after the document is classified
    so the client can update the ``turbine.isTurbineFile`` context key and
    enable/disable menus without re-parsing the file with a regex.
    """

    uri: str
    is_turbine_file: bool
    file_kind: FileKind | None


@dataclass(frozen=True, slots=True)
class ListChecksParams:
    """Request params for ``turbine/listChecks`` (client to server)."""

    uri: str


@dataclass(frozen=True, slots=True)
class CheckEntry:
    """A single check discovered in a contract or quality-spec file."""

    check_name: str
    schema_name: str
    line: int


@dataclass(frozen=True, slots=True)
class ListChecksResult:
    """Result for ``turbine/listChecks``."""

    checks: tuple[CheckEntry, ...]
