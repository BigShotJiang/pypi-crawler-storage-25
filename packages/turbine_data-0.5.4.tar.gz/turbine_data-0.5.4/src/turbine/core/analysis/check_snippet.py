"""Build YAML fragments for new checks from schema definitions.

Pure function: takes a request and the JSON schema, returns the YAML text
to insert and which section it belongs in. No I/O.
"""

import re
from dataclasses import dataclass
from enum import StrEnum
from typing import Any

from turbine.core.analysis.add_check_request import AddCheckRequest
from turbine.core.analysis.check_catalog import CheckScope, column_required_check_types
from turbine.core.common import SchemaNode
from turbine.core.common.constants import ContractKind

INDENT = "    "

DEFAULT_THRESHOLD_KEY = "x-defaultThreshold"
THRESHOLD_PLACEHOLDER_DESCRIPTION = (
    "pass/fail condition (mustBe, mustBeGreaterThan, mustBeLessThan, mustBeBetween, ...)"
)


class SchemaKey(StrEnum):
    """JSON Schema keys used to walk check body definitions."""

    DEFS = "$defs"
    CHECK_ITEM = "check_item"
    PATTERN_PROPERTIES = "patternProperties"
    REF = "$ref"
    REQUIRED = "required"
    PROPERTIES = "properties"
    DESCRIPTION = "description"
    SNIPPET_REQUIRED_ANY_OF = "x-turbine-snippet-required-any-of"
    SNIPPET_PROMPT = "x-turbine-snippet-prompt"


@dataclass(frozen=True, slots=True)
class SnippetAlternativeBlock:
    """One schema-declared group of alternative required field sets."""

    alternatives: tuple[tuple[str, ...], ...]


@dataclass(frozen=True, slots=True)
class SnippetPromptOverride:
    """Per-field snippet prompt override declared on a property schema."""

    field_name: str
    prompt: str


@dataclass(frozen=True, slots=True)
class CheckSnippetKeywords:
    """Schema extension keyword values used to scaffold Add Check snippets."""

    required_fields: tuple[str, ...]
    alternatives: tuple[SnippetAlternativeBlock, ...]
    prompt_overrides: tuple[SnippetPromptOverride, ...]


class FieldName(StrEnum):
    """Check body field names emitted with special handling."""

    NAME = "name"
    DIMENSION = "dimension"
    COLUMN = "column"


class YamlSection(StrEnum):
    """Target section in a YAML file for check insertion."""

    QUALITY = "quality"
    COLUMNS = "columns"
    SCHEMA_QUALITY = "schema_quality"


@dataclass(frozen=True, slots=True)
class CheckSnippet:
    """YAML fragment ready for insertion into a file."""

    yaml_text: str
    section: YamlSection


@dataclass(slots=True)
class SnippetTabstopCounter:
    """Allocates increasing snippet tabstop placeholders."""

    next_index: int = 1

    def placeholder(self, text: str) -> str:
        """Return a VS Code snippet placeholder and advance the counter."""
        marker = f"${{{self.next_index}:{escape_snippet_placeholder(text)}}}"
        self.next_index += 1
        return marker


def escape_snippet_placeholder(text: str) -> str:
    """Escape placeholder text for VS Code snippet syntax."""
    return text.replace("\\", "\\\\").replace("$", "\\$").replace("}", "\\}")


def required_value_placeholder(description: str, tabstops: SnippetTabstopCounter) -> str:
    """Render a required YAML scalar snippet placeholder."""
    return tabstops.placeholder(description)


def resolve_check_body(schema: SchemaNode, check_type: str) -> SchemaNode:
    """Find the JSON-schema body definition for *check_type*.

    Walks ``$defs/check_item/patternProperties`` to match the check type
    against regex keys, then resolves the ``$ref`` to the body definition.
    Returns an empty dict when no pattern matches.
    """
    defs: SchemaNode = schema.get(SchemaKey.DEFS, {})
    check_item: SchemaNode = defs.get(SchemaKey.CHECK_ITEM, {})
    pattern_props: SchemaNode = check_item.get(SchemaKey.PATTERN_PROPERTIES, {})

    for pattern, ref_obj in pattern_props.items():
        if not re.fullmatch(pattern, check_type):
            continue
        ref_path: str = ref_obj.get(SchemaKey.REF, "")
        def_name = ref_path.rsplit("/", maxsplit=1)[-1]
        body: SchemaNode = defs.get(def_name, {})
        return body

    return {}


@dataclass(frozen=True, slots=True)
class PreparedBody:
    """Resolved body definition plus its rendered-fields context."""

    properties: SchemaNode
    required: list[str]
    default_threshold: dict[str, Any] | None
    snippet_keywords: CheckSnippetKeywords


def read_check_snippet_keywords(body_schema: SchemaNode) -> CheckSnippetKeywords:
    """Read snippet-oriented extension keywords from a check body schema."""
    raw_required = body_schema.get(SchemaKey.REQUIRED, [])
    required_fields: tuple[str, ...] = ()
    if isinstance(raw_required, list):
        required_fields = tuple(field for field in raw_required if isinstance(field, str))

    alternatives: list[SnippetAlternativeBlock] = []
    raw_alternatives = body_schema.get(SchemaKey.SNIPPET_REQUIRED_ANY_OF, [])
    if isinstance(raw_alternatives, list):
        field_sets = tuple(
            field_set
            for candidate in raw_alternatives
            if isinstance(candidate, list)
            and (field_set := tuple(field for field in candidate if isinstance(field, str)))
        )
        if field_sets:
            alternatives.append(SnippetAlternativeBlock(alternatives=field_sets))

    raw_properties = body_schema.get(SchemaKey.PROPERTIES, {})
    properties: SchemaNode = raw_properties if isinstance(raw_properties, dict) else {}
    prompt_overrides = tuple(
        SnippetPromptOverride(field_name=field_name, prompt=prompt)
        for field_name, property_schema in properties.items()
        if isinstance(field_name, str)
        and isinstance(property_schema, dict)
        and isinstance(prompt := property_schema.get(SchemaKey.SNIPPET_PROMPT), str)
        and prompt
    )

    return CheckSnippetKeywords(
        required_fields=required_fields,
        alternatives=tuple(alternatives),
        prompt_overrides=prompt_overrides,
    )


def prepare_body(
    request: AddCheckRequest, schema: SchemaNode, *, exclude_fields: frozenset[str] = frozenset()
) -> PreparedBody:
    """Resolve the body definition and compute its required-field list.

    Starts from the schema's ``required`` array, appends ``column`` when the
    catalog marks the check type as column-requiring (covers the dataset-scope
    column requirement that JSON Schema can't express on a shared body), then
    filters out any fields in *exclude_fields* (used by DataContract wrapping,
    where ``name`` and ``dimension`` live at an outer level).

    Also extracts ``x-defaultThreshold`` — an ``{operator: value}`` dict the
    snippet builder renders after required fields so the skeleton ships a
    valid verdict operator. An empty dict means "threshold required, pick one"
    and renders as a placeholder; a missing key means the check type is
    threshold-exempt (only ``schema``) and no line is emitted.
    """
    body_def = resolve_check_body(schema, request.check_type)
    properties: SchemaNode = body_def.get(SchemaKey.PROPERTIES, {})

    snippet_keywords = read_check_snippet_keywords(body_def)
    required: list[str] = list(snippet_keywords.required_fields)
    if request.check_type in column_required_check_types() and FieldName.COLUMN not in required:
        required.append(FieldName.COLUMN.value)
    required = [field for field in required if field not in exclude_fields]

    raw_default = body_def.get(DEFAULT_THRESHOLD_KEY)
    default_threshold = raw_default if isinstance(raw_default, dict) else None
    return PreparedBody(
        properties=properties,
        required=required,
        default_threshold=default_threshold,
        snippet_keywords=snippet_keywords,
    )


def render_threshold_lines(
    default_threshold: dict[str, Any] | None, tabstops: SnippetTabstopCounter
) -> list[str]:
    """Emit verdict-operator lines from *default_threshold*.

    - ``None``: the check is threshold-exempt (``schema``) — emit nothing.
    - ``{}``: threshold is required but no sensible default exists — emit a
      ``mustBe: ${N:<hint>}`` placeholder so the user picks.
    - Non-empty dict: emit one ``key: value`` line per entry. Values that
      are themselves dicts (e.g. ``mustBeBetween``) are emitted as a nested
      block; scalars go on a single line.
    """
    if default_threshold is None:
        return []
    if not default_threshold:
        placeholder = required_value_placeholder(THRESHOLD_PLACEHOLDER_DESCRIPTION, tabstops)
        return [f"{INDENT}mustBe: {placeholder}"]
    lines: list[str] = []
    for key, value in default_threshold.items():
        if isinstance(value, dict):
            lines.append(f"{INDENT}{key}:")
            lines.extend(f"{INDENT}{INDENT}{sub_key}: {sub_val}" for sub_key, sub_val in value.items())
        else:
            lines.append(f"{INDENT}{key}: {value}")
    return lines


def build_check_snippet(
    request: AddCheckRequest, schema: SchemaNode, *, nested: bool = False
) -> CheckSnippet:
    """Build a YAML fragment for a new check entry.

    Reads required fields from the per-type body definition and emits each
    as a scalar snippet placeholder drawn from the JSON schema property
    description. Fields the flow already supplies
    (``dimension``, and ``column`` when the user picked one) are emitted
    with their value instead of a placeholder.

    For DataContract files, wraps the body in
    ``type: custom, engine: turbine, implementation: { ... }``. When *nested*
    is True (insertion under a property's own ``quality:`` block), the
    ``column:`` line is elided because the column is implicit from the
    parent property.
    """
    if request.file_kind == ContractKind.DATA_CONTRACT:
        return build_contract_check_snippet(request, schema, nested=nested)
    return build_qualityspec_check_snippet(request, schema)


def build_qualityspec_check_snippet(request: AddCheckRequest, schema: SchemaNode) -> CheckSnippet:
    """Build a native QualitySpec snippet (``- <check_type>: { ... }``)."""
    prepared = prepare_body(request, schema)
    skip_column = request.scope == CheckScope.COLUMN

    tabstops = SnippetTabstopCounter()
    name_desc = property_prompt(prepared.properties, FieldName.NAME, prepared.snippet_keywords)
    name_value = request.check_name or required_value_placeholder(name_desc, tabstops)
    lines = [f"- {request.check_type}:", f"{INDENT}name: {name_value}"]
    lines.extend(render_required_lines(prepared, request, skip_column=skip_column, tabstops=tabstops))
    lines.extend(render_alternative_lines(prepared.properties, prepared.snippet_keywords, tabstops))
    lines.extend(render_threshold_lines(prepared.default_threshold, tabstops))

    yaml_text = "\n".join(lines) + "\n"
    section = YamlSection.COLUMNS if request.scope == CheckScope.COLUMN else YamlSection.QUALITY
    return CheckSnippet(yaml_text=yaml_text, section=section)


def build_contract_check_snippet(
    request: AddCheckRequest, schema: SchemaNode, *, nested: bool = False
) -> CheckSnippet:
    """Build a DataContract snippet wrapped in ``type: custom, engine: turbine``.

    ``name`` and ``dimension`` live at the outer ``DataQuality`` level so that
    :class:`~turbine.adapters.odcs.reader.OdcsReader` picks them up. The custom
    ``implementation:`` block only carries fields the Turbine check body itself
    understands (``check``, ``column``, and any schema-required fields beyond
    name/dimension).

    When *nested* is True, the ``column:`` line is omitted because the column
    is implicit from the surrounding property.
    """
    prepared = prepare_body(
        request, schema, exclude_fields=frozenset({FieldName.NAME.value, FieldName.DIMENSION.value})
    )

    tabstops = SnippetTabstopCounter()
    impl_lines: list[str] = [f"{INDENT}check: {request.check_type}"]
    impl_lines.extend(render_required_lines(prepared, request, skip_column=nested, tabstops=tabstops))
    impl_lines.extend(render_alternative_lines(prepared.properties, prepared.snippet_keywords, tabstops))
    impl_lines.extend(render_threshold_lines(prepared.default_threshold, tabstops))

    name_value = request.check_name or required_value_placeholder(
        "Name of the data quality check", tabstops
    )
    lines = [
        f"- name: {name_value}",
        "  type: custom",
        "  engine: turbine",
        f"  dimension: {request.dimension}",
        "  implementation:",
        *impl_lines,
    ]

    yaml_text = "\n".join(lines) + "\n"
    return CheckSnippet(yaml_text=yaml_text, section=YamlSection.SCHEMA_QUALITY)


def render_required_lines(
    prepared: PreparedBody,
    request: AddCheckRequest,
    *,
    skip_column: bool,
    tabstops: SnippetTabstopCounter,
) -> list[str]:
    """Emit YAML lines for *required* fields in a stable order.

    Order: ``dimension``, ``column``, then remaining required fields in schema
    order. ``dimension`` takes its value from the request; ``column`` takes the
    request value when provided (unless *skip_column* is True), otherwise a
    snippet placeholder. Every other required field becomes a placeholder
    line. ``name`` is intentionally not emitted here — callers prepend it when
    the body is the outermost entry (QualitySpec) and omit it when name lives
    at an outer level (DataContract).
    """
    lines: list[str] = []

    if FieldName.DIMENSION in prepared.required:
        lines.append(f"{INDENT}dimension: {request.dimension}")

    if FieldName.COLUMN in prepared.required and not skip_column:
        desc = property_prompt(prepared.properties, FieldName.COLUMN, prepared.snippet_keywords)
        if request.column:
            lines.append(f"{INDENT}column: {request.column}")
        else:
            lines.append(f"{INDENT}column: {required_value_placeholder(desc, tabstops)}")

    reserved = {FieldName.NAME, FieldName.DIMENSION, FieldName.COLUMN}
    for field in prepared.required:
        if field in reserved:
            continue
        desc = property_prompt(prepared.properties, field, prepared.snippet_keywords)
        lines.append(f"{INDENT}{field}: {required_value_placeholder(desc, tabstops)}")

    return lines


def render_alternative_lines(
    properties: SchemaNode, snippet_keywords: CheckSnippetKeywords, tabstops: SnippetTabstopCounter
) -> list[str]:
    """Emit schema-declared alternative guidance and a tabstop for the first option."""
    lines: list[str] = []
    for block in snippet_keywords.alternatives:
        first_field = first_alternative_field(block)
        if first_field is None:
            continue
        labels = ", ".join(format_alternative_label(alternative) for alternative in block.alternatives)
        desc = property_prompt(properties, first_field, snippet_keywords)
        lines.append(f"{INDENT}# set at least one of: {labels}")
        lines.append(f"{INDENT}{first_field}: {required_value_placeholder(desc, tabstops)}")
    return lines


def first_alternative_field(block: SnippetAlternativeBlock) -> str | None:
    """Return the first field from the first non-empty alternative."""
    for alternative in block.alternatives:
        if alternative:
            return alternative[0]
    return None


def format_alternative_label(alternative: tuple[str, ...]) -> str:
    """Render one alternative set for a human-facing snippet comment."""
    return " + ".join(alternative)


def property_prompt(properties: SchemaNode, field: str, snippet_keywords: CheckSnippetKeywords) -> str:
    """Return the snippet prompt for *field*, falling back to JSON Schema description."""
    for override in snippet_keywords.prompt_overrides:
        if override.field_name == field:
            return override.prompt
    return property_description(properties, field)


def property_description(properties: SchemaNode, field: str) -> str:
    """Return the JSON Schema description for *field*, or the field name as fallback."""
    desc = properties.get(field, {}).get(SchemaKey.DESCRIPTION)
    return desc if isinstance(desc, str) and desc else field
