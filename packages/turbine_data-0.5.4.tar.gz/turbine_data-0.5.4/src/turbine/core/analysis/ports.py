"""Ports for code analysis features."""

from collections.abc import Iterable
from typing import Any, Protocol, runtime_checkable

from turbine.core.analysis.context.key_context import KeyContext
from turbine.core.building_blocks.diagnostics.types import TextRange
from turbine.core.common import FieldDoc, ResolvedNode
from turbine.core.common.file_edits import FileEdits, SnippetInsertion


class CodeWriteError(Exception):
    """Raised when a ``CodeWriter`` fails to apply one or more file edits.

    Adapters raise this when the underlying I/O channel rejects the
    edit (for example, when ``workspace/applyEdit`` returns
    ``applied=False`` or when a file write fails on disk).
    """


@runtime_checkable
class CodeWriter(Protocol):
    """Applies a batch of text edits to workspace files.

    Use cases that need to mutate files (add-check, rename)
    depend on this port rather than on a specific I/O channel. Adapters
    fan the edits out to disk (CLI) or to ``workspace/applyEdit`` (LSP).

    Implementations must raise :class:`CodeWriteError` on failure so the
    caller can surface a single, uniform error type regardless of the
    channel.
    """

    async def write(self, edits: Iterable[FileEdits]) -> None:
        """Apply every edit bundle in *edits*.

        Raises:
            CodeWriteError: If the adapter could not apply one or more
                bundles. The call may be partially applied from the
                workspace's point of view; callers should treat this as
                an indeterminate outcome.
        """
        ...

    async def insert_snippet(self, insertion: SnippetInsertion) -> None:
        """Insert one guided snippet into one workspace file.

        Raises:
            CodeWriteError: If the adapter could not apply the snippet.
        """
        ...


class SchemaResolver(Protocol):
    """Port for looking up field documentation and valid children from a schema.

    Each resolver knows about one type of contract document (e.g. data contracts,
    quality specs).  The analysis layer tries each registered resolver via
    ``can_resolve`` and delegates to the first one that matches.

    Implementations live in the adapters layer (e.g. ``JsonSchemaResolver``).

    Example::

        if resolver.can_resolve(doc_data):
            field = resolver.resolve_field(doc_data, "columns.customer_id", "type")
    """

    def can_resolve(self, data: dict[str, object]) -> bool:
        """Check whether this resolver understands the given document structure.

        Args:
            data: Parsed YAML document as a nested dictionary.

        Returns:
            ``True`` if this resolver can provide schema info for *data*.
        """
        ...

    def resolve_field(
        self,
        data: dict[str, object],
        parent_path: str,
        key_name: str,
        sibling_context: dict[str, str] | None = None,
    ) -> FieldDoc | None:
        """Look up documentation for a specific field in the schema.

        Args:
            data: Parsed YAML document as a nested dictionary.
            parent_path: Dot-separated path to the parent node
                (e.g. ``"columns.customer_id"``).
            key_name: Name of the field within the parent (e.g. ``"type"``).
            sibling_context: Optional ``{sibling_key: sibling_value}`` map used
                to resolve ``x-contextDescriptions`` on the target field
                (e.g. ``{"property": "retention"}`` to pick the retention
                description for ``valueExt``).

        Returns:
            A ``FieldDoc`` with the field's description, type info, and allowed
            values, or ``None`` if the field is not recognized.
        """
        ...

    def resolve_children(self, data: dict[str, object], path: str) -> ResolvedNode:
        """List all valid child keys, enum values, and examples at a schema path.

        Used by the completion engine to suggest what can appear under a given
        YAML key.

        Args:
            data: Parsed YAML document as a nested dictionary.
            path: Dot-separated schema path to resolve children for.

        Returns:
            A ``ResolvedNode`` containing child field names, allowed enum values,
            and example snippets.
        """
        ...

    def resolve_children_any(self, path: str) -> ResolvedNode:
        """Return valid children from any registered schema at the given path.

        Unlike ``resolve_children``, this does not require a parsed document —
        it tries every known schema and returns the first match.  Used as a
        fallback when the YAML is broken and no document data is available.

        Args:
            path: Dot-separated schema path to resolve children for.

        Returns:
            A ``ResolvedNode`` with child field names from the first matching
            schema, or an empty node if none match.
        """
        ...

    def turbine_ref_at(self, data: dict[str, object], dotted_path: str) -> dict[str, Any] | None:
        """Return the ``x-turbine-ref`` extension at *dotted_path*, or None.

        Adapters walk their own merged schema and read the extension keyword
        directly; callers don't see raw JSON-Schema. ``None`` means either
        no format matched the document or the leaf carries no extension.
        """
        ...


class DocumentTreePort(Protocol):
    """Port for incremental document tree management.

    Manages one tree-sitter parse tree per open document URI. Handlers call
    ``open``/``close`` on document lifecycle events and ``apply_edit`` on
    each incremental text change. Query methods (``resolve_context_at``,
    ``get_node_text``) provide O(log n) position lookups used by
    completion, hover, and definition features.
    """

    def resolve_context_at(self, uri: str, line: int, col: int) -> KeyContext | None:
        """Return cursor context at the given 0-indexed position.

        Args:
            uri: Document URI.
            line: 0-indexed line number.
            col: 0-indexed column (UTF-16 code units).

        Returns:
            KeyContext with dotted path, key range, and is_value_position,
            or ``None`` if no key covers the position.
        """
        ...

    def apply_edit(self, uri: str, edit_range: TextRange, text: str) -> None:
        """Apply an incremental text edit to the document tree.

        Computes byte offsets from the edit range, calls ``tree.edit()`` on the
        existing tree, then re-parses with the old tree for incremental update.

        Args:
            uri: Document URI.
            edit_range: The range being replaced (1-indexed lines and columns).
            text: The replacement text.
        """
        ...

    def open(self, uri: str, content: str) -> None:
        """Create the initial parse tree for a newly opened document.

        Args:
            uri: Document URI.
            content: Full document text.
        """
        ...

    def close(self, uri: str) -> None:
        """Remove the parse tree for a closed document.

        Args:
            uri: Document URI.
        """
        ...
