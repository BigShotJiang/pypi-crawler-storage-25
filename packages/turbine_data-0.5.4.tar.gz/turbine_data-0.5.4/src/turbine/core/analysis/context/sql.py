"""Resolve SQL template file context — links SQL files to quality specs and contracts."""

from dataclasses import dataclass
from pathlib import Path
from typing import Self

from turbine.core.common import ColumnDef, DatasetSpec, SqlCheckConfig
from turbine.core.contract import ProjectIndex, select_target_spec, target_specs_from_index


@dataclass(frozen=True, slots=True)
class SqlFileContext:
    """Resolved context linking an open SQL template back to its contract.

    When an SQL file is opened in the editor, the LSP needs to know which
    quality spec references it and what the target contract looks like so it
    can offer completions for columns and template parameters.

    Attributes:
        quality_spec_path: Filesystem path of the quality spec that owns this SQL file.
        target_contract_id: Contract ID that the quality spec targets.
        dataset: Fully-qualified table name from the quality spec dataset.
        columns: Column definitions from the target contract, used for completions.
        params: Template parameters declared in the SQL check config.
    """

    quality_spec_path: Path
    target_contract_id: str
    dataset: str
    columns: tuple[ColumnDef, ...]
    params: dict[str, str]

    @classmethod
    def from_path(
        cls, sql_path: Path, index: ProjectIndex, checks_dir: Path | None = None
    ) -> Self | None:
        """Find the quality spec that references *sql_path* and resolve its target contract.

        Walks every contract in the index, looks for a ``SqlCheckConfig`` whose
        ``file_path`` resolves under *checks_dir* and matches *sql_path*, then
        resolves the target contract to pull in columns while keeping the quality
        spec dataset as the template target.

        Args:
            sql_path: Filesystem path of the SQL template file.
            index: Project-wide index of contracts and quality specs.
            checks_dir: Configured checks directory for file-backed SQL checks.

        Returns:
            A fully-resolved ``SqlFileContext`` if a matching spec and target
            contract are found, or ``None`` otherwise.
        """
        for contract in index.contracts():
            if contract.target_contract is None:
                continue
            match = find_sql_check(contract, sql_path, checks_dir)
            if match is None:
                continue
            target = select_target_spec(
                target_specs_from_index(index, contract.target_contract), contract.table
            )
            if target is None:
                return None
            return cls(
                quality_spec_path=contract.metadata.source_path,
                target_contract_id=contract.target_contract,
                dataset=str(contract.table),
                columns=target.columns,
                params=match.params,
            )
        return None


def find_sql_check(
    contract: DatasetSpec, sql_path: Path, checks_dir: Path | None = None
) -> SqlCheckConfig | None:
    """Find a ``SqlCheckConfig`` in *contract* whose ``file_path`` matches *sql_path*.

    Args:
        contract: A dataset spec (contract or quality spec) to search.
        sql_path: Filesystem path of the SQL template file.
        checks_dir: Configured checks directory for file-backed SQL checks.

    Returns:
        The matching ``SqlCheckConfig``, or ``None`` if none of the checks
        reference this SQL file.
    """
    return next(
        (
            check.config
            for check in contract.checks
            if isinstance(check.config, SqlCheckConfig)
            and sql_check_path_matches(check.config.file_path, contract, sql_path, checks_dir)
        ),
        None,
    )


def sql_check_path_matches(
    file_path: Path, contract: DatasetSpec, sql_path: Path, checks_dir: Path | None
) -> bool:
    """Return whether *file_path* points at the open SQL file."""
    if checks_dir is not None:
        return (checks_dir / file_path).resolve() == sql_path.resolve()
    spec_dir = contract.metadata.source_path.parent
    return (spec_dir / file_path).resolve() == sql_path.resolve()
