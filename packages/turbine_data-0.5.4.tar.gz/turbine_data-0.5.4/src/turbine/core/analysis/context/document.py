"""Unified document context resolution for LSP features.

Composes cursor, SQL, and text context resolution into a single
entry point that handles file-type dispatch and error recovery.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum

from turbine.core.analysis.context.cursor import KeyContext
from turbine.core.analysis.context.sql import SqlFileContext
from turbine.core.common import RawSource


class FileType(StrEnum):
    """Supported document file types for LSP analysis."""

    YAML = "yaml"
    SQL = "sql"
    UNKNOWN = "unknown"


@dataclass(frozen=True, slots=True)
class DocumentContext:
    """Resolved editing context at a cursor position.

    Bundles file-type detection, parsed YAML source (with cursor context),
    and SQL file context into a single object. Features use this to avoid
    repeating file-type dispatch, parsing, and error handling.

    Attributes:
        uri: Document URI.
        content: Full document text.
        line: 1-indexed line number.
        col: 1-indexed column number.
        file_type: Detected file type from the URI extension.
        source: Parsed YAML source (None for non-YAML or on parse error).
        key_context: Resolved YAML key at cursor (None when not on a key/value).
        sql_context: Resolved SQL template context (None for non-SQL files).
    """

    uri: str
    content: str
    line: int
    col: int
    file_type: FileType
    source: RawSource | None = None
    key_context: KeyContext | None = None
    sql_context: SqlFileContext | None = None
