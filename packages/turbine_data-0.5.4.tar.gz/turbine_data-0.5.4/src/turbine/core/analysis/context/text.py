"""Shared text utilities for analysis handlers."""

from pathlib import Path
from urllib.parse import unquote, urlparse

from turbine.core.building_blocks import TextRange

SCHEMA_NAME_PATTERN = r"^\s*-\s*name:\s*(.+)$"


def uri_to_path(uri: str) -> Path:
    """Convert a ``file://`` URI to a filesystem ``Path``, decoding percent-encoding.

    Falls back to treating *uri* as a plain path string when it does not
    use the ``file`` scheme.

    Args:
        uri: A file URI (e.g. ``file:///home/user/contract.yaml``) or a
            plain filesystem path.

    Returns:
        Resolved ``Path`` object.

    Example::

        uri_to_path("file:///tmp/my%20file.yaml")  # => Path("/tmp/my file.yaml")
    """
    parsed = urlparse(uri)
    if parsed.scheme == "file":
        return Path(unquote(parsed.path))
    return Path(uri)


def extract_value_text(text: str, value_range: TextRange) -> str:
    """Extract the text slice that a ``TextRange`` points to in *text*.

    Lines and columns in ``TextRange`` are 1-indexed. The returned string
    is stripped of leading/trailing whitespace.

    Args:
        text: Full source text to slice from.
        value_range: 1-indexed range identifying the target substring.

    Returns:
        The trimmed substring, or an empty string if the range is out of
        bounds.
    """
    lines = text.splitlines()
    if value_range.start_line < 1 or value_range.start_line > len(lines):
        return ""
    line = lines[value_range.start_line - 1]
    return line[value_range.start_col - 1 : value_range.end_col - 1].strip()
