"""Cursor context data type for YAML key resolution."""

from dataclasses import dataclass
from typing import Self

from turbine.core.building_blocks import TextRange


@dataclass(frozen=True, slots=True)
class KeyContext:
    """Resolved cursor context within a YAML document.

    Tells you which key the cursor is on (or whose value it's editing),
    the full dotted path to that key, and its source range.

    Attrs:
        key_name: Leaf key name (e.g. ``"name"`` from ``"schema.0.name"``).
        dotted_path: Full path from root (e.g. ``"schema.0.properties.1.name"``).
        key_range: Source range spanning the key token in the YAML.
        is_value_position: True when the cursor is on the value side of the colon.
    """

    key_name: str
    dotted_path: str
    key_range: TextRange
    is_value_position: bool

    @classmethod
    def from_path(cls, dotted: str, key_range: TextRange, *, is_value_position: bool) -> Self:
        """Build a context from a dotted YAML path, extracting the leaf key name.

        Args:
            dotted: Full dotted path (e.g. ``"schema.0.name"``).
            key_range: Source range of the key token.
            is_value_position: Whether the cursor is past the colon.

        Returns:
            A new KeyContext with the leaf key extracted from *dotted*.
        """
        return cls(
            key_name=dotted.rsplit(".", 1)[-1],
            dotted_path=dotted,
            key_range=key_range,
            is_value_position=is_value_position,
        )
