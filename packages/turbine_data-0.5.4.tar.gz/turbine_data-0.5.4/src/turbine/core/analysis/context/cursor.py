"""Cursor position to YAML key resolution for LSP hover, completion, and definition."""

from turbine.core.analysis.context.key_context import KeyContext
from turbine.core.analysis.ports import DocumentTreePort


def resolve_context_at_position(
    tree_port: DocumentTreePort, uri: str, line: int, col: int
) -> KeyContext | None:
    """Find which YAML key the cursor is on or in the value of.

    Delegates to ``DocumentTreePort`` for O(log n) tree-sitter lookup.
    Converts 1-indexed (line, col) to 0-indexed before calling the port.

    Args:
        tree_port: Document tree for position queries.
        uri: Document URI.
        line: 1-indexed line number.
        col: 1-indexed column number.
    """
    return tree_port.resolve_context_at(uri, line - 1, col - 1)
