"""Generic tree-view protocol for IDE sidebar/explorer integrations.

A client-agnostic shape for hierarchical tree data. Each editor
(VSCode TreeDataProvider, JetBrains tool window, Zed sidebar) maps the
fixed ``TreeIcon`` enum and the ``OpenFileCommand`` payload onto its
native primitives. Builders register per ``TreeId`` and are queried
lazily on expand. Subscribers receive ``didChange`` notifications when
domain events invalidate a subtree.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Literal, Protocol, runtime_checkable

TURBINE_TREE_GET_ROOT = "turbine/tree/getRoot"
TURBINE_TREE_GET_CHILDREN = "turbine/tree/getChildren"
TURBINE_TREE_SUBSCRIBE = "turbine/tree/subscribe"
TURBINE_TREE_UNSUBSCRIBE = "turbine/tree/unsubscribe"
TURBINE_TREE_DID_CHANGE = "turbine/tree/didChange"

NODE_SEPARATOR = "|"
"""Segment separator for opaque tree node ids.

URIs, schema names, and column names never contain ``|``, so split-on-pipe
parses cleanly. Builders compose ids by joining segments with this constant
and parse incoming ids by splitting on it; node ids are otherwise opaque
to the protocol.
"""


class TreeId(StrEnum):
    """One of the well-known trees the server publishes."""

    WORKSPACE = "workspace"
    DATASOURCES = "datasources"


class TreeIcon(StrEnum):
    """Closed icon set; editors map these to native icons.

    Section and entity icons pre-compose with status when an overlay
    applies (e.g. a checks section where all checks pass returns
    ``PASS``, not ``SECTION_CHECKS``).
    """

    PASS = "pass"
    FAIL = "fail"
    WARNING = "warning"
    INFO = "info"
    UNKNOWN = "unknown"
    LOADING = "loading"
    DIFF_ADDED = "diff_added"
    DIFF_REMOVED = "diff_removed"
    DIFF_MODIFIED = "diff_modified"
    CONTRACT = "contract"
    REFERENCE = "reference"
    QUALITY_SPEC = "quality_spec"
    DATASOURCE = "datasource"
    SECTION_VALIDATION = "section_validation"
    SECTION_REFERENCES = "section_references"
    SECTION_QUALITY_SPECS = "section_quality_specs"


class TreeCollapsibleState(StrEnum):
    """Whether a node has children and how it should appear by default."""

    NONE = "none"
    COLLAPSED = "collapsed"
    EXPANDED = "expanded"


@dataclass(frozen=True, slots=True)
class OpenFileCommand:
    """Open a file at an optional 1-indexed position."""

    uri: str
    line: int | None = None
    column: int | None = None
    kind: Literal["openFile"] = "openFile"


@dataclass(frozen=True, slots=True)
class DismissTarget:
    """Args the editor passes back to ``turbine.dismissDiagnostic``.

    ``rule_id`` is the ``DiagnosticKind.value`` round-tripped through the LSP
    command, and ``anchor`` is ``""`` for file-level findings (the wire layer
    only carries strings). Mirrors the tuple shape used by the editor-side
    code action so both surfaces hit the same command handler.
    """

    uri: str
    rule_id: str
    anchor: str


@dataclass(frozen=True, slots=True)
class TreeNode:
    """One row in a tree.

    ``id`` is opaque to the protocol; clients pass it back to
    ``getChildren`` verbatim. Encoding is the builder's concern.
    """

    id: str
    label: str
    icon: TreeIcon
    collapsible_state: TreeCollapsibleState
    description: str | None = None
    tooltip: str | None = None
    context_value: str | None = None
    resource_uri: str | None = None
    command: OpenFileCommand | None = None
    revealed: bool = False
    dismiss: DismissTarget | None = None


@dataclass(frozen=True, slots=True)
class TreeGetRootParams:
    """Request the top-level rows of a tree."""

    tree_id: TreeId
    context_uri: str | None = None


@dataclass(frozen=True, slots=True)
class TreeGetChildrenParams:
    """Request the children of a previously returned node."""

    tree_id: TreeId
    node_id: str
    context_uri: str | None = None


@dataclass(frozen=True, slots=True)
class TreeNodesResult:
    """Envelope for both ``getRoot`` and ``getChildren`` responses."""

    nodes: tuple[TreeNode, ...]


@dataclass(frozen=True, slots=True)
class TreeSubscribeParams:
    """Begin receiving ``didChange`` notifications for a tree."""

    tree_id: TreeId
    context_uri: str | None = None


@dataclass(frozen=True, slots=True)
class TreeSubscribeResult:
    """Server-issued handle returned from ``subscribe``."""

    subscription_id: str


@dataclass(frozen=True, slots=True)
class TreeUnsubscribeParams:
    """Cancel a subscription previously returned from ``subscribe``."""

    subscription_id: str


@dataclass(frozen=True, slots=True)
class TreeDidChangeParams:
    """Server-to-client notification that a subtree needs refetching.

    Empty ``invalidated_node_ids`` means refetch everything from
    ``getRoot``.
    """

    tree_id: TreeId
    invalidated_node_ids: tuple[str, ...] = ()


@runtime_checkable
class TreeNotifier(Protocol):
    """Sink for ``turbine/tree/didChange`` notifications.

    The tree registry holds notifiers (not LSP clients) so editor adapters
    can swap in their own delivery mechanism without touching the registry.
    """

    def notify_tree_changed(self, params: TreeDidChangeParams) -> None: ...
