"""Request and result types for the Add Check use case."""

from dataclasses import dataclass

from turbine.core.analysis.check_catalog import CheckScope
from turbine.core.common.constants import ContractKind
from turbine.core.common.quality_dimension import QualityDimension


@dataclass(frozen=True, slots=True)
class AddCheckRequest:
    """Immutable request to insert a new check into a YAML file."""

    file_uri: str
    file_kind: ContractKind
    check_type: str
    dimension: QualityDimension
    scope: CheckScope
    column: str | None = None
    schema_name: str | None = None
    check_name: str | None = None


@dataclass(frozen=True, slots=True)
class AddCheckResult:
    """Outcome of an add-check operation."""

    applied: bool
    error: str | None = None
