"""Pure domain functions for contract health derivation.

``derive_status`` and ``derive_description`` collapse quality + drift +
diagnostic signals into the aggregate health surfaced on the workspace
overview (and any other client that wants the same one-line summary).

``DiagnosticCountsPort`` is the abstraction over per-URI diagnostic
counters; presentation-layer adapters subclass it explicitly so the
overview service stays free of editor concerns. ``dedupe_overview``
collapses multi-table ODCS contracts (one ``ContractHealth`` per schema
entry) down to one row per file URI.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from turbine.core.analysis.protocol import ContractDrift, ContractHealth, ContractQuality, ContractStatus
from turbine.core.analysis.run_rollup import RunRollup

STATUS_RANK: dict[ContractStatus, int] = {
    ContractStatus.ERROR: 0,
    ContractStatus.WARNING: 1,
    ContractStatus.UNKNOWN: 2,
    ContractStatus.PASSING: 3,
}


@dataclass(frozen=True, slots=True)
class DiagnosticCounts:
    """Errors and warnings for a single URI."""

    errors: int
    warnings: int


@runtime_checkable
class DiagnosticCountsPort(Protocol):
    """Source of per-URI diagnostic counts.

    Adapters around the lint/diagnostics handler implement this so the
    overview service can compose health without depending on the LSP
    diagnostics infrastructure.
    """

    def counts_for(self, uri: str) -> DiagnosticCounts: ...


def derive_status(
    *, quality: ContractQuality | None, drift: ContractDrift | None, errors: int, warnings: int
) -> ContractStatus:
    """Aggregate health into one status used for the row icon and sort.

    Precedence: any error signal trumps everything; any warning signal
    trumps the clean states; a clean contract with check results is
    PASSING; absence of check data leaves it UNKNOWN.
    """
    rollup = RunRollup.from_run(quality)
    has_drift = drift is not None and drift.has_drift
    has_drift_error = drift is not None and drift.error is not None
    if errors > 0 or rollup.failed > 0 or has_drift or has_drift_error:
        return ContractStatus.ERROR
    if warnings > 0 or rollup.warned > 0:
        return ContractStatus.WARNING
    if rollup.is_run:
        return ContractStatus.PASSING
    return ContractStatus.UNKNOWN


def derive_description(
    *,
    quality: ContractQuality | None,
    drift: ContractDrift | None,
    errors: int,
    warnings: int,
    status: ContractStatus,
) -> str:
    """Format the inline grey description shown after the contract name.

    Sections, in order: ``{passed}/{total}`` / ``no run`` / ``run failed`` for quality;
    ``in sync`` / ``{n} drift`` / ``drift error`` for drift; ``{e}E {w}W``
    for diagnostics. UNKNOWN rows with no other signals get
    ``not validated`` appended so the user knows nothing has been computed.
    """
    parts = [quality_description(quality)]
    if drift_text := drift_description(drift):
        parts.append(drift_text)
    if diagnostic_text := diagnostic_description(errors, warnings):
        parts.append(diagnostic_text)
    if status == ContractStatus.UNKNOWN and len(parts) == 1:
        parts.append("not validated")
    return " · ".join(parts)


def quality_description(quality: ContractQuality | None) -> str:
    """Return the quality part of a health description.

    Mirrors the Quality section header vocabulary (per CONTEXT.md):
    ``"X/Y"`` after a run, ``"no run"`` before any run, ``"run failed"``
    when the run errored.
    """
    rollup = RunRollup.from_run(quality)
    if not rollup.is_run:
        return "no run"
    if rollup.error is not None:
        return "run failed"
    return f"{rollup.passed}/{rollup.total}"


def drift_description(drift: ContractDrift | None) -> str | None:
    """Return the drift part of a health description, if drift was checked."""
    if drift is None:
        return None
    if drift.error is not None:
        return "drift error"
    if drift.has_drift:
        change_count = sum(len(schema.columns) for schema in drift.schemas)
        return f"{change_count} drift"
    return "in sync"


def diagnostic_description(errors: int, warnings: int) -> str | None:
    """Return the compact diagnostic count text."""
    chunks: list[str] = []
    if errors > 0:
        chunks.append(f"{errors}E")
    if warnings > 0:
        chunks.append(f"{warnings}W")
    return " ".join(chunks) or None


def dedupe_overview(contracts: tuple[ContractHealth, ...]) -> tuple[ContractHealth, ...]:
    """Return the first ``ContractHealth`` seen per URI, preserving order.

    Multi-table ODCS contracts produce one ``ContractHealth`` per schema
    entry, but the workspace overview shows one row per file.
    """
    seen: set[str] = set()
    result: list[ContractHealth] = []
    for contract in contracts:
        if contract.uri in seen:
            continue
        seen.add(contract.uri)
        result.append(contract)
    return tuple(result)
