"""Pure builders for the Validations subtree under a contract row.

Inputs: contract URI, section node id, the unified diagnostic tuple from
``DiagnosticStore.latest_for_uri(uri)``. Lint wins on
``(line, col, field_name)`` collisions because lint precedes drift in
``DiagnosticSource`` declaration order. No LSP types reach this module.
"""

from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass

from turbine.core.analysis.tree_protocol import (
    NODE_SEPARATOR,
    DismissTarget,
    OpenFileCommand,
    TreeCollapsibleState,
    TreeIcon,
    TreeNode,
)
from turbine.core.building_blocks import Diagnostic, Severity
from turbine.core.contract.dismissal import DismissalKey, DismissalStore


@dataclass(frozen=True, slots=True)
class DismissalContext:
    """Optional dismissal-aware extras for ``build_validation_rows``.

    When *store* is set, dismissed warning/info findings are filtered out.
    When *context_value* is set, dismissible rows that survive the filter
    carry that context value (so editor menus can target them) and a
    :class:`DismissTarget` payload.
    """

    store: DismissalStore | None = None
    context_value: str | None = None


LEAF_SEGMENT = "diag"

SEVERITY_ICONS: dict[Severity, TreeIcon] = {
    Severity.ERROR: TreeIcon.FAIL,
    Severity.WARNING: TreeIcon.WARNING,
    Severity.INFO: TreeIcon.INFO,
}
SEVERITY_RANK: dict[TreeIcon, int] = {TreeIcon.FAIL: 0, TreeIcon.WARNING: 1, TreeIcon.INFO: 2}


def primary_location(diag: Diagnostic) -> tuple[int, int] | None:
    """Return ``(start_line, start_col)`` of the primary annotation, or ``None``."""
    primary = next((annotation for annotation in diag.annotations if annotation.is_primary), None)
    if primary is None or primary.span.range is None:
        return None
    return primary.span.range.start_line, primary.span.range.start_col


def validation_dedupe_key(diag: Diagnostic) -> tuple[int | None, int | None, str | None]:
    """Identity for one finding: ``(line, col, field_name)``; first-seen wins on dupe."""
    location = primary_location(diag)
    field_name = diag.data.field_name if diag.data is not None else None
    line, col = location if location is not None else (None, None)
    return line, col, field_name


def severity_count(rows: Iterable[TreeNode], icon: TreeIcon) -> int:
    """Count rows whose icon matches *icon* (errors / warnings / info)."""
    return sum(1 for row in rows if row.icon == icon)


def severity_sort_key(row: TreeNode) -> int:
    """Sort errors first, warnings second, info last; unknown icons go to the end."""
    return SEVERITY_RANK.get(row.icon, 99)


def validation_section_label(rows: tuple[TreeNode, ...], *, drift_run: bool = False) -> str:
    """Render the Validations section header.

    Tri-state mirrors the Quality section's ``no run | run failed | X/Y``:

    * ``Validations (N errors, M warnings)`` when any finding is present
      (info dropped from the count when errors/warnings are also present).
    * ``Validations (K info)`` when only info-level findings remain.
    * ``Validations (passed)`` when *drift_run* is True and findings are empty.
    * ``Validations (no run)`` when *drift_run* is False and findings are empty.
    """
    if not rows:
        return "Validations (passed)" if drift_run else "Validations (no run)"
    errors = severity_count(rows, TreeIcon.FAIL)
    warnings = severity_count(rows, TreeIcon.WARNING)
    parts: list[str] = []
    if errors:
        parts.append(f"{errors} error{'s' if errors != 1 else ''}")
    if warnings:
        parts.append(f"{warnings} warning{'s' if warnings != 1 else ''}")
    if not parts:
        info = severity_count(rows, TreeIcon.INFO)
        if info:
            parts.append(f"{info} info")
    return f"Validations ({', '.join(parts)})" if parts else "Validations"


def validation_section_icon(rows: tuple[TreeNode, ...], *, drift_run: bool = False) -> TreeIcon:
    """Pick the section icon: worst severity for non-empty rows, otherwise pass/section glyph.

    A green PASS check fires only when *drift_run* is True so the user
    distinguishes "validate ran cleanly" from "haven't pressed Validate yet".
    """
    if not rows:
        return TreeIcon.PASS if drift_run else TreeIcon.SECTION_VALIDATION
    if severity_count(rows, TreeIcon.FAIL):
        return TreeIcon.FAIL
    if severity_count(rows, TreeIcon.WARNING):
        return TreeIcon.WARNING
    return TreeIcon.INFO


def validation_leaf_id(section_node_id: str, idx: int) -> str:
    """Stable id for the *idx*-th diagnostic leaf under *section_node_id*."""
    return NODE_SEPARATOR.join((section_node_id, LEAF_SEGMENT, str(idx)))


def is_dismissible(diag: Diagnostic) -> bool:
    """Return True for non-ERROR diagnostics whose rule opted into dismissal."""
    return diag.data is not None and diag.data.dismissible and diag.severity != Severity.ERROR


def dismiss_target_for(uri: str, diag: Diagnostic) -> DismissTarget | None:
    """Return the editor-bound dismiss args for *diag*, or ``None`` if not dismissible."""
    if not is_dismissible(diag) or diag.data is None:
        return None
    return DismissTarget(uri=uri, rule_id=diag.data.kind.value, anchor=diag.data.anchor or "")


def diagnostic_row(
    *, uri: str, section_node_id: str, idx: int, diag: Diagnostic, context_value: str | None = None
) -> TreeNode:
    """Build a leaf node for one ``Diagnostic`` with click-to-open command.

    Dismissible non-ERROR diagnostics get a :class:`DismissTarget` payload so
    the editor can round-trip ``(uri, rule_id, anchor)`` back to the
    ``turbine.dismissDiagnostic`` command without a second LSP round-trip.
    """
    location = primary_location(diag)
    line_desc = f"L{location[0]}" if location is not None else None
    first_line = diag.message.splitlines()[0] if diag.message else ""
    command = OpenFileCommand(uri=uri, line=location[0]) if location is not None else None
    return TreeNode(
        id=validation_leaf_id(section_node_id, idx),
        label=first_line,
        icon=SEVERITY_ICONS.get(diag.severity, TreeIcon.INFO),
        collapsible_state=TreeCollapsibleState.NONE,
        description=line_desc,
        tooltip=diag.message,
        context_value=context_value,
        command=command,
        dismiss=dismiss_target_for(uri, diag),
    )


def is_dismissed(uri: str, diag: Diagnostic, store: DismissalStore | None) -> bool:
    """Return True when *diag* is dismissible and the store has recorded a dismissal."""
    if store is None or not is_dismissible(diag) or diag.data is None:
        return False
    key = DismissalKey(file_uri=uri, rule_id=diag.data.kind.value, anchor=diag.data.anchor)
    return store.is_dismissed(key)


def build_validation_rows(
    *,
    uri: str,
    section_node_id: str,
    diagnostics: tuple[Diagnostic, ...],
    context_value: str | None = None,
    dismissal: DismissalContext = DismissalContext(),
) -> tuple[TreeNode, ...]:
    """Deduped, severity-sorted leaf list for the Validations section.

    Caller passes the merged lint+drift tuple in lint-before-drift order
    (the natural emission order of ``DiagnosticStore.latest_for_uri``). When
    *dismissal.store* is supplied, dismissible warning/info diagnostics with
    a recorded dismissal are filtered out so the sidebar mirrors the editor.
    Dismissible rows that survive the filter use ``dismissal.context_value``
    when set so editor menus can target them with a more specific when-clause.
    """
    seen_keys: set[tuple[int | None, int | None, str | None]] = set()
    kept: list[TreeNode] = []
    for idx, diag in enumerate(diagnostics):
        if is_dismissed(uri, diag, dismissal.store):
            continue
        key = validation_dedupe_key(diag)
        if key in seen_keys:
            continue
        seen_keys.add(key)
        row_context = (
            dismissal.context_value
            if dismissal.context_value is not None and is_dismissible(diag)
            else context_value
        )
        kept.append(
            diagnostic_row(
                uri=uri, section_node_id=section_node_id, idx=idx, diag=diag, context_value=row_context
            )
        )
    return tuple(sorted(kept, key=severity_sort_key))
