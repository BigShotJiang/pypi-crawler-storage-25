"""Typed content blocks for Guided Onboarding steps."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Literal


class StepContentBlockKind(StrEnum):
    """Kinds of content blocks a Guided Onboarding Step can render."""

    PARAGRAPH = "paragraph"
    CALLOUT = "callout"
    IMAGE = "image"


class CalloutTone(StrEnum):
    """Visual tone for a Step callout block."""

    INFO = "info"
    TIP = "tip"
    WARNING = "warning"
    ERROR = "error"
    SUCCESS = "success"


@dataclass(frozen=True, slots=True, kw_only=True)
class ParagraphBlock:
    """Paragraph content with limited inline markdown."""

    markdown: str
    kind: Literal[StepContentBlockKind.PARAGRAPH] = StepContentBlockKind.PARAGRAPH


@dataclass(frozen=True, slots=True, kw_only=True)
class CalloutBlock:
    """Structured callout content with a visual tone and optional title."""

    tone: CalloutTone
    markdown: str
    title: str | None = None
    kind: Literal[StepContentBlockKind.CALLOUT] = StepContentBlockKind.CALLOUT


@dataclass(frozen=True, slots=True, kw_only=True)
class ImageBlock:
    """Bundled image content referenced by sandbox-independent asset path."""

    asset_path: str
    alt: str
    caption_markdown: str | None = None
    kind: Literal[StepContentBlockKind.IMAGE] = StepContentBlockKind.IMAGE


StepContentBlock = ParagraphBlock | CalloutBlock | ImageBlock
