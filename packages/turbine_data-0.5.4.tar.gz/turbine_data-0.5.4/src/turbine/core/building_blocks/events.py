"""Domain event base class, event bus port, and handler registration."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from datetime import UTC, datetime
from functools import partial
from typing import Protocol, dataclass_transform
from uuid import UUID, uuid4

from pydantic import BaseModel, ConfigDict, Field


class DomainEvent(BaseModel, frozen=True):
    """Base for all domain events. The bus routes by concrete type."""

    model_config = ConfigDict(populate_by_name=True, frozen=True)

    event_id: UUID = Field(default_factory=uuid4)
    occurred_at: datetime = Field(default_factory=partial(datetime.now, UTC))


class EventBus(Protocol):
    """Dispatches events to subscribers and accepts new subscriptions."""

    def publish(self, event: DomainEvent) -> None:
        """Send an event to all registered handlers."""
        ...

    def subscribe[E: DomainEvent](self, event_type: type[E], handler: Callable[[E], None]) -> None:
        """Register a handler to run whenever an event of this type is published."""
        ...


@dataclass_transform(frozen_default=True, kw_only_default=True)
def event[T](cls: type[T]) -> type[T]:
    """Mark a DomainEvent subclass as frozen and keyword-only."""
    if isinstance(cls, type) and issubclass(cls, BaseModel):
        return cls
    return dataclass(frozen=True, slots=True, kw_only=True)(cls)
