"""Typed action metadata for onboarding steps."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum


class StepKind(StrEnum):
    """How a guided onboarding step advances."""

    READ = "read"
    ACTION = "action"


class StepActionKind(StrEnum):
    """User-facing action kinds available from onboarding steps."""

    NONE = "none"
    OPEN_ALL_CONTRACTS = "open_all_contracts"
    OPEN_ADD_CHECK = "open_add_check"
    RUN_VALIDATE = "run_validate"
    RUN_SINGLE_CHECK = "run_single_check"
    GENERATE_API = "generate_api"
    START_API_SERVER = "start_api_server"
    OPEN_DATA_SWAGGER = "open_data_swagger"
    OPEN_MANAGEMENT_SWAGGER = "open_management_swagger"
    RUN_SANDBOX_CHECKS = "run_sandbox_checks"
    OPEN_DASHBOARD = "open_dashboard"
    FINAL_HANDOFF = "final_handoff"


@dataclass(frozen=True, slots=True, kw_only=True)
class StepAction:
    """Action button metadata for one onboarding step."""

    kind: StepActionKind
    label: str
    file: str | None = None
    dataset: str | None = None
    check_name: str | None = None
    check_type: str | None = None
    column: str | None = None
    datasource: str = "local"
    url: str | None = None
