"""Domain-specific diagnostic identifiers."""

from enum import StrEnum


class DiagnosticId(StrEnum):
    """Categories for diagnostics.

    Catch sites match on ``TurbineError.has_id(DiagnosticId.CONTRACT_NOT_FOUND)``
    instead of relying on exception subclasses.
    """

    # Contract
    CONTRACT_NOT_FOUND = "contract-not-found"
    CONTRACT_PARSE_ERROR = "contract-parse-error"
    CONTRACT_INVALID_SCHEMA = "contract-invalid-schema"
    BREAKING_CHANGE_WITHOUT_MAJOR_BUMP = "breaking-change-without-major-bump"

    # Datasource
    DATASOURCE_TABLE_NOT_FOUND = "datasource-table-not-found"
    DATASOURCE_CONFIG_ERROR = "datasource-config-error"
    DATASOURCE_DRIVER_NOT_INSTALLED = "datasource-driver-not-installed"

    # Check
    CHECK_SQL_ERROR = "check-sql-error"
    CHECK_PYTHON_RUNTIME_ERROR = "check-python-runtime-error"
    CHECK_NOT_REGISTERED = "check-not-registered"
    CHECK_DEFINITION_ERROR = "check-definition-error"
    CHECK_THRESHOLD_REQUIRED_ERROR = "check-threshold-required-error"
    CHECK_THRESHOLD_REQUIRED_WARNING = "check-threshold-required-warning"
    CHECK_DIMENSION_REQUIRED = "check-dimension-required"
    CHECK_SKIPPED_DUE_TO_SCHEMA = "check-skipped-due-to-schema"

    # Validation
    VALIDATE_COLUMN_ADDED = "validate-column-added"
    VALIDATE_COLUMN_REMOVED = "validate-column-removed"
    VALIDATE_TYPE_CHANGED = "validate-type-changed"
    VALIDATE_NULLABILITY_CHANGED = "validate-nullability-changed"

    # Impact analysis
    IMPACT_COLUMN_REMOVED = "impact-column-removed"
    IMPACT_COLUMN_TYPE_CHANGED = "impact-column-type-changed"
    IMPACT_COLUMN_ADDED = "impact-column-added"
    IMPACT_COLUMN_NULLABLE_CHANGED = "impact-column-nullable-changed"
    IMPACT_CHECK_ADDED = "impact-check-added"
    IMPACT_CHECK_REMOVED = "impact-check-removed"
    IMPACT_SCHEMA_REMOVED = "impact-schema-removed"

    # Quality spec
    QUALITY_ROW_IDENTIFIERS = "quality-row-identifiers"
    QUALITY_CHECK_FILE_NOT_FOUND = "quality-check-file-not-found"
    QUALITY_SPEC_OWNER_MISSING = "quality-spec-owner-missing"
    DATASET_NOT_IN_TARGET = "dataset-not-in-target"

    # Schema / codegen
    SCHEMA_ERROR = "schema-error"
    ODCS_NAME_UNQUALIFIED = "odcs-name-unqualified"
    ODCS_NAME_MALFORMED = "odcs-name-malformed"
    CODEGEN_DUPLICATE_FILENAME = "codegen-duplicate-filename"
    CODEGEN_DUPLICATE_TABLE = "codegen-duplicate-table"

    # API codegen validation
    API_CONTRACT_ID_CHARSET = "api-contract-id-charset"
    API_CONTRACT_ID_PLURAL = "api-contract-id-plural"
    API_DOMAIN_REQUIRED = "api-domain-required"
    API_VERSION_INVALID = "api-version-invalid"
    API_COLUMN_TYPE_UNMAPPABLE = "api-column-type-unmappable"
    API_CONTRACT_TUPLE_CONFLICT = "api-contract-tuple-conflict"
    API_CONTRACT_FILTERED = "api-contract-filtered"
    API_NO_CONTRACTS_SELECTED = "api-no-contracts-selected"
    API_RESOURCE_NAME_DERIVED = "api-resource-name-derived"
    API_FILTERABLE_FALLBACK = "api-filterable-fallback"

    # SLA
    SLA_MISSING_TIME_COLUMN = "sla-missing-time-column"
    SLA_INVALID_ELEMENT = "sla-invalid-element"
    SLA_END_OF_BUSINESS_DAY_RETIRED = "sla-end-of-business-day-retired"
    SLA_DEFAULT_ELEMENT_DEPRECATED = "sla-default-element-deprecated"
    SLA_NON_TEMPORAL_ELEMENT = "sla-non-temporal-element"
    SLA_GENERAL_AVAILABILITY_FUTURE = "sla-general-availability-future"
    SLA_END_OF_SUPPORT_PAST = "sla-end-of-support-past"
    SLA_END_OF_LIFE_NEAR = "sla-end-of-life-near"
    SLA_END_OF_LIFE_PAST = "sla-end-of-life-past"
    SLA_FREQUENCY_MALFORMED = "sla-frequency-malformed"

    # Incremental
    INCREMENTAL_NO_PRIOR_RUN = "incremental-no-prior-run"
    INCREMENTAL_NO_CONFIG = "incremental-no-config"

    # Window
    WINDOW_REQUIRES_SLA_ELEMENT = "window-requires-sla-element"
    WINDOW_NOT_APPLICABLE = "window-not-applicable"
    WINDOW_AND_SIZE_EXCLUSIVE = "window-and-size-exclusive"
    WINDOW_INVALID_DURATION = "window-invalid-duration"
    WINDOW_MISSING_COMPOSITE_INDEX = "window-missing-composite-index"

    # Metadata store
    METADATA_STORE_LOCKED = "metadata-store-locked"

    # Serve
    ROUTER_IMPORT_ERROR = "router-import-error"
    ROUTER_ATTRIBUTE_MISSING = "router-attribute-missing"
    ROUTER_INVALID_TYPE = "router-invalid-type"

    # Plan execution
    PLAN_EXECUTION_ERROR = "plan-execution-error"

    # Seed
    SEED_UNSUPPORTED_LOGICAL_TYPE = "seed-unsupported-logical-type"
    SEED_WRITE_ERROR = "seed-write-error"

    # Generic fallbacks
    VALIDATION = "validation"
    PARSE = "parse"
    IO = "io"
    INTERNAL = "internal"
