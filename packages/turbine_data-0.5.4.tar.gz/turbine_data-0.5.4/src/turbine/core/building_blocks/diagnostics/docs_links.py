"""Docs URL construction for in-editor authoring escape hatches."""

from dataclasses import dataclass

from .ids import DiagnosticId

DEFAULT_DOCS_BASE_URL = "https://turbine.dev"


@dataclass(frozen=True, slots=True)
class DocsLinkBuilder:
    """Build configured external documentation URLs for LSP surfaces."""

    base_url: str = DEFAULT_DOCS_BASE_URL

    @property
    def normalized_base_url(self) -> str:
        """Return the base URL without trailing slash separators."""
        return self.base_url.rstrip("/")

    def diagnostic_url(self, diagnostic_id: DiagnosticId) -> str:
        """Return the per-diagnostic docs URL."""
        return f"{self.normalized_base_url}/diagnostics/{diagnostic_id.value}/"

    def check_url(self, check_type: str) -> str:
        """Return the per-check-type docs URL."""
        return f"{self.normalized_base_url}/checks/{check_type}/"
