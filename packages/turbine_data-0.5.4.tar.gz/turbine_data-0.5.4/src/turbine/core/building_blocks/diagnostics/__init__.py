"""Diagnostic system for structured error reporting.

Re-exports the most commonly used types so callers can write::

    from turbine.core.building_blocks.diagnostics import (
        Diagnostic, DiagnosticBuilder, DiagnosticId, Severity, TurbineError,
    )
"""

from .builder import DiagnosticBuilder
from .docs_links import DEFAULT_DOCS_BASE_URL, DocsLinkBuilder
from .exceptions import DatabaseError, TurbineError, TurbineFatalError
from .ids import DiagnosticId
from .sink import DiagnosticSink, NullDiagnosticSink
from .source_map import SourceMap, resolve_fallback_range
from .types import (
    Annotation,
    Diagnostic,
    DiagnosticData,
    DiagnosticKind,
    FixAction,
    Severity,
    SnippetEdit,
    Span,
    SubDiagnostic,
    SubSeverity,
    TextEditInfo,
    TextRange,
)

__all__ = [
    "DEFAULT_DOCS_BASE_URL",
    "Annotation",
    "DatabaseError",
    "Diagnostic",
    "DiagnosticBuilder",
    "DiagnosticData",
    "DiagnosticId",
    "DiagnosticKind",
    "DiagnosticSink",
    "DocsLinkBuilder",
    "FixAction",
    "NullDiagnosticSink",
    "Severity",
    "SnippetEdit",
    "SourceMap",
    "Span",
    "SubDiagnostic",
    "SubSeverity",
    "TextEditInfo",
    "TextRange",
    "TurbineError",
    "TurbineFatalError",
    "resolve_fallback_range",
]
