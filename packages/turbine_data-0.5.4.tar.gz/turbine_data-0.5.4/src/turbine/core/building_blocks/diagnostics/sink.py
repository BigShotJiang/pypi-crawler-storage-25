"""Ports for collecting diagnostics."""

from collections.abc import Iterable
from typing import Protocol

from .types import Diagnostic


class DiagnosticSink(Protocol):
    """Accepts diagnostics. Implementations decide where they go (list, logger, /dev/null)."""

    def add(self, diagnostic: Diagnostic) -> None:
        """Record a single diagnostic."""
        ...

    def extend(self, diagnostics: Iterable[Diagnostic]) -> None:
        """Record multiple diagnostics."""
        ...


class NullDiagnosticSink:
    """Silently drops every diagnostic it receives."""

    __slots__ = ()

    def add(self, diagnostic: Diagnostic) -> None:
        """Discard the diagnostic."""

    def extend(self, diagnostics: Iterable[Diagnostic]) -> None:
        """Discard all diagnostics."""
