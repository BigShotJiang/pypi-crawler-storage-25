"""SourceMap protocol for position tracking in parsed files."""

from collections.abc import Callable
from typing import Protocol

from .types import TextRange


class SourceMap(Protocol):
    """Maps dotted key paths to their source positions in a file."""

    def range_for_key(self, key_path: str) -> TextRange | None:
        """Return the TextRange of the key at *key_path*, or None if unknown."""
        ...

    def range_for_value(self, key_path: str) -> TextRange | None:
        """Return the TextRange of the value at *key_path*, or None if unknown."""
        ...

    def key_paths(self) -> tuple[str, ...]:
        """Return all known dotted key paths in this source map."""
        ...

    def range_for_block(self, key_path: str) -> TextRange | None:
        """Return the range of the block for key_path (key line to next sibling - 1)."""
        ...

    def range_for_document_root(self) -> TextRange | None:
        """Return the range of the document's first top-level key, or None if empty.

        Used to anchor diagnostics about the document as a whole (e.g. a
        root-level missing required field) so the renderer can show a
        real line/column instead of just the file path.
        """
        ...


def resolve_fallback_range(dotted: str, resolver: Callable[[str], TextRange | None]) -> TextRange | None:
    """Walk up a dotted path ('a.b.c' -> 'a.b' -> 'a') until the resolver finds a match.

    Used when the SourceMap has no entry for the full path, so we point to the
    nearest parent that does have a known location.
    """
    parts = dotted.split(".")
    for depth in range(len(parts) - 1, 0, -1):
        if (text_range := resolver(".".join(parts[:depth]))) is not None:
            return text_range
    return None
