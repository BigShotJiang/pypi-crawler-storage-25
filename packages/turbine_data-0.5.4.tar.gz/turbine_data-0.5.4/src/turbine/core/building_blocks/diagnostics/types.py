"""Severity levels, source locations, and the Diagnostic value object."""

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path

from pydantic import BaseModel

from .ids import DiagnosticId


class Severity(StrEnum):
    """Error, warning, or info."""

    ERROR = "error"
    WARNING = "warning"
    INFO = "info"


class SubSeverity(StrEnum):
    """Help or note, used in sub-diagnostics."""

    HELP = "help"
    NOTE = "note"


class DiagnosticKind(StrEnum):
    """Machine-readable category so code actions know what to fix."""

    UNKNOWN_FIELD = "unknown-field"
    MISSING_REQUIRED_FIELD = "missing-required-field"
    TYPE_MISMATCH = "type-mismatch"
    INVALID_ENUM = "invalid-enum"
    SLA_INVALID_ELEMENT = "sla-invalid-element"
    SLA_MISSING_TIME_COLUMN = "sla-missing-time-column"
    VALIDATE_COLUMN_ADDED = "validate-column-added"
    VALIDATE_COLUMN_REMOVED = "validate-column-removed"
    VALIDATE_TYPE_CHANGED = "validate-type-changed"
    VALIDATE_NULLABILITY_CHANGED = "validate-nullability-changed"
    VALIDATE_PRIMARY_KEY_CHANGED = "validate-primary-key-changed"
    VALIDATE_UNIQUE_CHANGED = "validate-unique-changed"
    SQL_UNKNOWN_COLUMN = "sql-unknown-column"
    NAMING_VIOLATION = "naming-violation"
    DATASOURCE_TABLE_NOT_FOUND = "datasource-table-not-found"
    TARGET_CONTRACT_NOT_FOUND = "target-contract-not-found"
    DATASET_MISMATCH = "dataset-mismatch"
    INVALID_CONTRACT_ID = "invalid-contract-id"
    UNKNOWN_COLUMN_REF = "unknown-column-ref"
    REQUIRED_FALSE_PRIMARY_KEY = "required-false-primary-key"
    PRIMARY_KEY_PRESENT_ON_SCHEMA = "primary-key-present-on-schema"
    COLUMN_DESCRIPTION_REQUIRED = "column-description-required"
    DOMAIN_NOT_IN_ALLOWED_LIST = "domain-not-in-allowed-list"
    MISSING_OWNER = "missing-owner"
    USAGE_RECOMMENDED = "usage-recommended"
    ODCS_NAME_UNQUALIFIED = "odcs-name-unqualified"
    ODCS_NAME_MALFORMED = "odcs-name-malformed"
    RESOURCE_NAME_DERIVED = "resource-name-derived"
    BREAKING_CHANGE_WITHOUT_MAJOR_BUMP = "breaking-change-without-major-bump"


@dataclass(frozen=True, slots=True)
class TextRange:
    """Start and end positions in a source file (1-indexed lines and columns)."""

    start_line: int
    start_col: int
    end_line: int
    end_col: int


@dataclass(frozen=True, slots=True)
class TextEditInfo:
    """Single text replacement: swap the content at *range* with *new_text*."""

    range: TextRange
    new_text: str


@dataclass(frozen=True, slots=True)
class Span:
    """File path with optional text range."""

    path: Path
    range: TextRange | None = None


@dataclass(frozen=True, slots=True)
class Annotation:
    """Points to a source location and optionally labels it."""

    span: Span
    message: str | None = None
    is_primary: bool = True


@dataclass(frozen=True, slots=True)
class SubDiagnostic:
    """Extra context (help text or note) nested under a Diagnostic."""

    severity: SubSeverity
    message: str
    annotations: tuple[Annotation, ...] = ()


@dataclass(frozen=True, slots=True)
class SnippetEdit:
    """Snippet insertion bound to a diagnostic's file.

    ``line``/``col`` are 1-indexed to match the rest of the domain (``TextRange``,
    column source ranges). The presentation layer converts to 0-indexed for the
    LSP wire. ``snippet_text`` may contain LSP snippet syntax such as
    ``${1:placeholder}``; these tab stops survive only when the code action is
    routed through a client-side ``insertSnippet`` command — they are flattened
    by a plain ``WorkspaceEdit``.
    """

    line: int
    col: int
    snippet_text: str


@dataclass(frozen=True, slots=True)
class FixAction:
    """A quick fix the diagnostic-emitting rule pre-computed for itself.

    Exactly one of ``edits`` or ``snippet`` carries the change. Plain edits
    are surfaced as a ``WorkspaceEdit``; snippet edits are routed through a
    client-side command so tab stops behave interactively in the editor.
    """

    title: str
    edits: tuple[TextEditInfo, ...] = ()
    snippet: SnippetEdit | None = None
    is_preferred: bool = False


class DiagnosticData(BaseModel, frozen=True):
    """Carries structured data a code action needs to apply a fix."""

    kind: DiagnosticKind
    field_name: str | None = None
    parent_path: str | None = None
    suggested_value: str | None = None
    schema_name: str | None = None
    contract_value: str | None = None
    db_value: str | None = None
    dismissible: bool = False
    anchor: str | None = None
    required_range: TextRange | None = None
    fixes: tuple[FixAction, ...] = ()


@dataclass(frozen=True, slots=True)
class Diagnostic:
    """One error, warning, or info pointing to source locations with notes and help text.

    ``deprecated`` maps to LSP's ``DiagnosticTag.Deprecated`` so the underlying
    text range is rendered with strikethrough styling in the editor.
    """

    id: DiagnosticId
    severity: Severity
    message: str
    annotations: tuple[Annotation, ...] = ()
    subs: tuple[SubDiagnostic, ...] = ()
    data: DiagnosticData | None = None
    deprecated: bool = False
    documentation_id: DiagnosticId | None = None
