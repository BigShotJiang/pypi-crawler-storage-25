"""Chainable builder for assembling Diagnostic instances."""

from collections.abc import Sequence
from difflib import SequenceMatcher, get_close_matches
from functools import lru_cache
from pathlib import Path
from typing import Self

from .exceptions import TurbineError
from .ids import DiagnosticId
from .types import (
    Annotation,
    Diagnostic,
    DiagnosticData,
    FixAction,
    Severity,
    SnippetEdit,
    Span,
    SubDiagnostic,
    SubSeverity,
    TextEditInfo,
    TextRange,
)

CONFIDENCE_THRESHOLD = 0.8


class DiagnosticBuilder:
    """Builds a Diagnostic through chained method calls, then freezes it."""

    __slots__ = (
        "deprecated_tag",
        "diagnostic_data",
        "diagnostic_id",
        "dismissible_anchor",
        "dismissible_flag",
        "documentation_id",
        "inline_fixes",
        "message",
        "primary_label",
        "primary_span",
        "secondary_annotations",
        "severity",
        "sub_diagnostics",
    )

    def __init__(self, diagnostic_id: DiagnosticId, severity: Severity, message: str) -> None:
        """Start a diagnostic with the given id, severity, and message."""
        self.diagnostic_id = diagnostic_id
        self.severity = severity
        self.message = message
        self.primary_span: Span | None = None
        self.primary_label: str | None = None
        self.secondary_annotations: list[Annotation] = []
        self.sub_diagnostics: list[SubDiagnostic] = []
        self.deprecated_tag: bool = False
        self.diagnostic_data: DiagnosticData | None = None
        self.documentation_id: DiagnosticId | None = None
        self.dismissible_flag: bool = False
        self.dismissible_anchor: str | None = None
        self.inline_fixes: tuple[FixAction, ...] = ()

    @classmethod
    def error(cls, diagnostic_id: DiagnosticId, message: str) -> Self:
        """Create a builder preset to ERROR severity."""
        return cls(diagnostic_id, Severity.ERROR, message)

    @classmethod
    def warning(cls, diagnostic_id: DiagnosticId, message: str) -> Self:
        """Create a builder preset to WARNING severity."""
        return cls(diagnostic_id, Severity.WARNING, message)

    @classmethod
    def info(cls, diagnostic_id: DiagnosticId, message: str) -> Self:
        """Create a builder preset to INFO severity."""
        return cls(diagnostic_id, Severity.INFO, message)

    def span(self, path: Path, text_range: TextRange | None = None) -> Self:
        """Point the primary annotation at a file and optional range."""
        self.primary_span = Span(path=path, range=text_range)
        return self

    def annotate(self, span: Span | None) -> Self:
        """Set the primary annotation from a Span. No-op if None."""
        if span is not None:
            self.primary_span = span
        return self

    def label(self, text: str) -> Self:
        """Set label on the primary annotation. No-op if no span set."""
        if self.primary_span is not None:
            self.primary_label = text
        return self

    def secondary(self, span: Span, label: str | None = None) -> Self:
        """Add a secondary annotation."""
        self.secondary_annotations.append(Annotation(span=span, message=label, is_primary=False))
        return self

    def help(self, text: str | None) -> Self:
        """Add a help sub-diagnostic. No-op if None."""
        if text is not None:
            self.sub_diagnostics.append(SubDiagnostic(severity=SubSeverity.HELP, message=text))
        return self

    def note(self, text: str | None) -> Self:
        """Add a note sub-diagnostic. No-op if None."""
        if text is not None:
            self.sub_diagnostics.append(SubDiagnostic(severity=SubSeverity.NOTE, message=text))
        return self

    def suggest(
        self, got: str, options: Sequence[str], *, fallback: str | None = None, cutoff: float = 0.5
    ) -> Self:
        """Fuzzy-match against options and add a "did you mean X?" hint, or fall back."""
        hint = cached_suggest(got, tuple(options), cutoff)
        return self.help(hint or fallback)

    def deprecated(self) -> Self:
        """Mark the diagnostic as a deprecation hint (strikethrough rendering)."""
        self.deprecated_tag = True
        return self

    def docs(self, diagnostic_id: DiagnosticId) -> Self:
        """Mark the diagnostic as having a per-diagnostic docs page."""
        self.documentation_id = diagnostic_id
        return self

    def data(self, data: DiagnosticData) -> Self:
        """Attach structured data so code actions can target the fix."""
        self.diagnostic_data = data
        return self

    def fix(
        self,
        title: str,
        *,
        edits: tuple[TextEditInfo, ...] = (),
        snippet: SnippetEdit | None = None,
        preferred: bool = False,
    ) -> Self:
        """Attach a precomputed quick fix the rule already has the context for.

        Exactly one of ``edits`` and ``snippet`` must be supplied. Snippet
        fixes preserve tab stops because the LSP layer routes them through
        a client-side command; a ``WorkspaceEdit`` would flatten them.
        Calling ``.fix(...)`` multiple times accumulates fixes; they appear
        in the editor's lightbulb menu in the order they were attached.
        Requires ``.data(...)`` to have been called: the fix list is merged
        into ``DiagnosticData`` so it crosses the LSP boundary.
        """
        if (snippet is None) == (not edits):
            raise ValueError(".fix() requires exactly one of edits=... or snippet=...")
        self.inline_fixes = (
            *self.inline_fixes,
            FixAction(title=title, edits=edits, snippet=snippet, is_preferred=preferred),
        )
        return self

    def dismissible(self, anchor: str | None) -> Self:
        """Mark the diagnostic dismissible with *anchor* as the stable anchor id.

        ``anchor`` is the rule's choice of stable identity (column name,
        ``"schema.column"``, or ``None`` for file-level findings). Renaming
        the underlying anchor invalidates the dismissal automatically.
        Requires ``.data(...)`` to have been called: the ``DismissalKey`` is
        keyed on ``DiagnosticData.kind`` at the LSP boundary.
        """
        self.dismissible_flag = True
        self.dismissible_anchor = anchor
        return self

    def build(self) -> Diagnostic:
        """Freeze and return the finished Diagnostic."""
        annotations: list[Annotation] = []
        if self.primary_span is not None:
            annotations.append(
                Annotation(span=self.primary_span, message=self.primary_label, is_primary=True)
            )
        annotations.extend(self.secondary_annotations)

        return Diagnostic(
            id=self.diagnostic_id,
            severity=self.severity,
            message=self.message,
            annotations=tuple(annotations),
            subs=tuple(self.sub_diagnostics),
            data=self.resolve_data(),
            deprecated=self.deprecated_tag,
            documentation_id=self.documentation_id,
        )

    def resolve_data(self) -> DiagnosticData | None:
        """Merge dismissibility and inline fixes into the attached data, if any."""
        if not self.dismissible_flag and not self.inline_fixes:
            return self.diagnostic_data
        if self.diagnostic_data is None:
            raise ValueError(
                ".dismissible() / .fix() require .data() — DiagnosticData carries them over the wire"
            )
        update: dict[str, object] = {}
        if self.dismissible_flag:
            update["dismissible"] = True
            update["anchor"] = self.dismissible_anchor
        if self.inline_fixes:
            update["fixes"] = self.inline_fixes
        return self.diagnostic_data.model_copy(update=update)

    def into_error(self) -> TurbineError:
        """Build and wrap in a TurbineError for the caller to raise."""
        return TurbineError(self.message, diagnostics=(self.build(),))


@lru_cache(maxsize=1024)
def cached_suggest(got: str, options: tuple[str, ...], cutoff: float) -> str | None:
    """Return a 'did you mean X?' hint, cached on (got, options, cutoff)."""
    matches = get_close_matches(got, options, n=3, cutoff=cutoff)
    if not matches:
        return None
    best_ratio = SequenceMatcher(None, got, matches[0]).ratio()
    if best_ratio >= CONFIDENCE_THRESHOLD or len(matches) == 1:
        return f"did you mean `{matches[0]}`?"
    formatted = ", ".join(f"`{m}`" for m in matches[:-1]) + f", or `{matches[-1]}`"
    return f"did you mean {formatted}?"
