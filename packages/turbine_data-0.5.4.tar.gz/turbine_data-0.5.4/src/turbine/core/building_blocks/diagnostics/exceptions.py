"""Exceptions that carry structured diagnostics."""

from .ids import DiagnosticId
from .types import Diagnostic


class TurbineError(Exception):
    """Recoverable error carrying structured diagnostics (exit 1)."""

    def __init__(self, message: str, *, diagnostics: tuple[Diagnostic, ...] = ()) -> None:
        """Create with a message and optional diagnostics."""
        super().__init__(message)
        self.diagnostics = diagnostics

    def has_id(self, *ids: DiagnosticId) -> bool:
        """Check whether any attached diagnostic matches one of the given ids."""
        return any(diag.id in ids for diag in self.diagnostics)


class DatabaseError(TurbineError):
    """Database or network error raised by an adapter."""


class TurbineFatalError(TurbineError):
    """Unrecoverable error that aborts the entire run (exit 2)."""
