"""Constants and type aliases for JSON Schema infrastructure.

Centralizes string literals and callback signatures used across schema
validation adapters to prevent typos and enable IDE navigation.
"""

from collections.abc import Callable, Iterable, Sequence
from enum import StrEnum
from typing import Any


class SchemaKey(StrEnum):
    """Standard JSON Schema keywords."""

    TYPE = "type"
    PROPERTIES = "properties"
    REQUIRED = "required"
    REF = "$ref"
    DEFS = "$defs"
    ENUM = "enum"
    CONST = "const"
    EXAMPLES = "examples"
    DEFAULT = "default"
    DESCRIPTION = "description"
    TITLE = "title"
    DEPRECATED = "deprecated"
    ONE_OF = "oneOf"
    ANY_OF = "anyOf"
    ALL_OF = "allOf"
    IF = "if"
    THEN = "then"
    ELSE = "else"
    NOT = "not"
    ITEMS = "items"
    FORMAT = "format"
    PATTERN_PROPERTIES = "patternProperties"
    ENUM_DESCRIPTIONS = "x-enumDescriptions"
    CONTEXT_DESCRIPTIONS = "x-contextDescriptions"


type DisplayContextFn = Callable[[dict[str, Any], Iterable[str | int]], str]
type ValidFieldsFn = Callable[[Sequence[str | int]], list[str]]


def noop_display_context(_data: dict[str, Any], _path: Iterable[str | int]) -> str:
    """Return an empty string as the default display context."""
    return ""


def noop_valid_fields(_path: Sequence[str | int]) -> list[str]:
    """Return an empty list as the default valid-fields fallback."""
    return []
