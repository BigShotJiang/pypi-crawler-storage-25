"""Typed highlight targets for onboarding steps."""

from __future__ import annotations

from dataclasses import dataclass
from enum import StrEnum
from typing import Literal


class HighlightTargetKind(StrEnum):
    """Kinds of onboarding highlight target."""

    CONTRACT_FIELD = "contract_field"
    DATASET = "dataset"
    COLUMN_FIELD = "column_field"
    QUALITY_SPEC_FIELD = "quality_spec_field"
    CHECK = "check"
    SQL_TEXT = "sql_text"
    SOURCE_TEXT = "source_text"
    SOURCE_RANGE = "source_range"
    UI_TARGET = "ui_target"
    YAML_FIELD = "yaml_field"


class ResolvedHighlightKind(StrEnum):
    """Kinds of resolved onboarding highlight."""

    EDITOR_RANGE = "editor_range"
    UI_TARGET = "ui_target"


RangeKind = Literal["key", "value", "block"]


@dataclass(frozen=True, slots=True, kw_only=True)
class YamlFieldTarget:
    """Highlight a field in a YAML file by source-map path."""

    file: str
    path: str
    range_kind: RangeKind = "value"
    kind: HighlightTargetKind = HighlightTargetKind.YAML_FIELD


@dataclass(frozen=True, slots=True, kw_only=True)
class ContractFieldTarget:
    """Highlight a top-level Contract field."""

    file: str
    contract_id: str
    field: str
    range_kind: RangeKind = "value"
    kind: HighlightTargetKind = HighlightTargetKind.CONTRACT_FIELD


@dataclass(frozen=True, slots=True, kw_only=True)
class DatasetTarget:
    """Highlight a Dataset declaration inside a Contract."""

    file: str
    contract_id: str
    dataset: str
    kind: HighlightTargetKind = HighlightTargetKind.DATASET


@dataclass(frozen=True, slots=True, kw_only=True)
class ColumnFieldTarget:
    """Highlight a field on a named Dataset column."""

    file: str
    dataset: str
    column: str
    field: str
    range_kind: RangeKind = "value"
    kind: HighlightTargetKind = HighlightTargetKind.COLUMN_FIELD


@dataclass(frozen=True, slots=True, kw_only=True)
class QualitySpecFieldTarget:
    """Highlight a top-level Quality Spec field."""

    file: str
    spec_id: str
    field: str
    range_kind: RangeKind = "value"
    kind: HighlightTargetKind = HighlightTargetKind.QUALITY_SPEC_FIELD


@dataclass(frozen=True, slots=True, kw_only=True)
class CheckTarget:
    """Highlight a check in a Contract or Quality Spec file."""

    file: str
    source_id: str
    check_type: str
    dataset: str | None = None
    column: str | None = None
    name: str | None = None
    kind: HighlightTargetKind = HighlightTargetKind.CHECK


@dataclass(frozen=True, slots=True, kw_only=True)
class SqlTextTarget:
    """Highlight a unique text snippet in a SQL file."""

    file: str
    text: str
    kind: HighlightTargetKind = HighlightTargetKind.SQL_TEXT


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceTextTarget:
    """Highlight a unique text snippet in a source file."""

    file: str
    text: str
    kind: HighlightTargetKind = HighlightTargetKind.SOURCE_TEXT


@dataclass(frozen=True, slots=True, kw_only=True)
class SourceRangeTarget:
    """Highlight an explicit 1-indexed line range in a source file."""

    file: str
    start_line: int
    end_line: int
    start_col: int = 1
    end_col: int | None = None
    kind: HighlightTargetKind = HighlightTargetKind.SOURCE_RANGE


@dataclass(frozen=True, slots=True, kw_only=True)
class UiTarget:
    """Highlight a non-file UI target."""

    target_id: str
    kind: HighlightTargetKind = HighlightTargetKind.UI_TARGET


HighlightTarget = (
    YamlFieldTarget
    | ContractFieldTarget
    | DatasetTarget
    | ColumnFieldTarget
    | QualitySpecFieldTarget
    | CheckTarget
    | SqlTextTarget
    | SourceTextTarget
    | SourceRangeTarget
    | UiTarget
)


@dataclass(frozen=True, slots=True, kw_only=True)
class ResolvedHighlight:
    """Resolved editor range or UI target for one onboarding step."""

    kind: ResolvedHighlightKind
    file: str | None = None
    range: tuple[int, int, int, int] | None = None
    target_id: str | None = None


def target_file(target: HighlightTarget) -> str | None:
    """Return the sandbox-relative file for file targets."""
    if isinstance(target, UiTarget):
        return None
    return target.file
