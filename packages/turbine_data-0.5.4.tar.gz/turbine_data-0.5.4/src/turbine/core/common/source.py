"""Container for a parsed YAML file with position tracking.

Bundles file path, raw text, parsed data, and a SourceMap so format
readers can build domain models while preserving source positions
for diagnostics.
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from turbine.core.building_blocks import Diagnostic, SourceMap


@dataclass(frozen=True, slots=True)
class RawSource:
    """Carries parsed file content alongside a SourceMap for diagnostic spans.

    ``parse_diagnostics`` carries non-fatal diagnostics produced during
    YAML parsing (e.g. tree-sitter ERROR nodes that did not prevent a
    partial parse). Linters fold these into their result so a partially
    invalid YAML cannot pass as "Contract is valid".
    """

    path: Path
    text: str
    data: dict[str, Any]
    source_map: SourceMap
    parse_diagnostics: tuple[Diagnostic, ...] = field(default_factory=tuple)
