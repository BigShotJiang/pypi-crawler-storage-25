"""Shared analysis types used across core layers.

These types were relocated from core/analysis/ to core/common/ so that
ProjectIndex (in core/contract/) can return them without creating a
dependency from core/contract/ to core/analysis/.
"""

from dataclasses import dataclass
from enum import StrEnum

from turbine.core.building_blocks import TextRange


class SymbolKind(StrEnum):
    """Category for symbols that appear in the document outline or workspace search.

    Maps to LSP ``SymbolKind`` in the presentation layer.
    """

    CONTRACT = "contract"
    SCHEMA = "schema"
    COLUMN = "column"


@dataclass(frozen=True, slots=True)
class LocationInfo:
    """Target location returned by go-to-definition or find-references.

    Points to a specific file (and optionally a range within it) so the editor
    can jump the cursor there.
    """

    uri: str
    range: TextRange | None = None


@dataclass(frozen=True, slots=True)
class WorkspaceSymbolInfo:
    """Symbol entry returned by workspace-wide search (Cmd+T / ``workspace/symbol``).

    Unlike ``DocumentSymbolInfo`` which is scoped to one file, this carries a
    *uri* so the editor knows which file to open.
    """

    name: str
    kind: SymbolKind
    uri: str
    container_name: str | None = None
