"""Workspace command IDs -- used by code lenses, routing, and command handler."""

from enum import StrEnum


class CommandId(StrEnum):
    """LSP workspace command identifiers."""

    ADD_CHECK = "turbine.addCheck"
    CREATE_BLANK_CONTRACT = "turbine.createBlankContract"
    CREATE_CONTRACT_FROM_DATASOURCE = "turbine.createContractFromDatasource"
    CREATE_DATASOURCE = "turbine.createDatasource"
    DISMISS_DIAGNOSTIC = "turbine.dismissDiagnostic"
    GENERATE_QUALITY_SPEC = "turbine.generateQualitySpec"
    GO_TO_CONTRACT = "turbine.goToContract"
    INSERT_SNIPPET = "turbine.insertSnippet"
    INSERT_SNIPPET_AT = "turbine.insertSnippetAt"
    RUN_QUALITY_CHECK = "turbine.runQualityCheck"
    RUN_SINGLE_CHECK = "turbine.runSingleCheck"
    SHOW_REFERENCES = "turbine.showReferences"
    TEST_DATASOURCE_CONNECTION = "turbine.testDatasourceConnection"
    VALIDATE_CONTRACT = "turbine.validateContract"
