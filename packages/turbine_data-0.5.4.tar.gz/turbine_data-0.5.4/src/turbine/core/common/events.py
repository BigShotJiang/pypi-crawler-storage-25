"""Session lifecycle events.

These events track CLI session start/completion/failure. They flow
through the EventBus and are consumed by telemetry adapters.
"""

from __future__ import annotations

from enum import StrEnum
from uuid import UUID

from pydantic import Field

from turbine.core.building_blocks import DomainEvent, event


class CommandOutcome(StrEnum):
    """Outcome of a CLI command execution."""

    SUCCESS = "success"


class RunMode(StrEnum):
    """Whether a session runs all checks or only incremental ones."""

    FULL = "FULL"
    INCREMENTAL = "INCREMENTAL"


@event
class SessionStarted(DomainEvent):
    """Published when a CLI session begins."""

    run_id: UUID = Field(serialization_alias="run.id")
    command_name: str = Field(serialization_alias="turbine.command.name")
    cli_version: str = Field(serialization_alias="cli.version")
    run_mode: RunMode = Field(default=RunMode.FULL, serialization_alias="turbine.run.mode")
    team: str | None = Field(default=None, serialization_alias="turbine.team")
    run_trigger: str | None = Field(default=None, serialization_alias="turbine.run.trigger")
    environment: str | None = Field(default=None, serialization_alias="turbine.environment")
    service_namespace: str | None = Field(default=None, serialization_alias="turbine.service.namespace")


@event
class SessionCompleted(DomainEvent):
    """Published when a CLI session finishes successfully."""

    run_id: UUID = Field(serialization_alias="run.id")
    duration_ms: float = Field(serialization_alias="turbine.session.duration_ms")
    outcome: CommandOutcome = Field(serialization_alias="turbine.command.outcome")


@event
class SessionFailed(DomainEvent):
    """Published when a CLI session fails with an unhandled error."""

    run_id: UUID = Field(serialization_alias="run.id")
    error_message: str = Field(serialization_alias="turbine.error.message")
    error_type: str = Field(serialization_alias="turbine.error.type")
