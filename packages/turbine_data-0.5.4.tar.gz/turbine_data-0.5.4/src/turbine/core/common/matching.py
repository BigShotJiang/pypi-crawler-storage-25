"""String matching helpers for typo-style diagnostics."""

from collections.abc import Sequence


def closest_match(needle: str, candidates: Sequence[str], max_distance: int = 3) -> str | None:
    """Return the nearest candidate within max_distance using Levenshtein distance."""
    if max_distance < 0:
        return None

    best_candidate: str | None = None
    best_distance = max_distance + 1
    for candidate in candidates:
        distance = levenshtein_distance(needle, candidate)
        if distance >= best_distance:
            continue
        best_candidate = candidate
        best_distance = distance

    return best_candidate


def levenshtein_distance(left: str, right: str) -> int:
    """Return the Levenshtein edit distance between two strings."""
    if left == right:
        return 0
    if not left:
        return len(right)
    if not right:
        return len(left)

    previous_row = list(range(len(right) + 1))
    for left_index, left_char in enumerate(left, start=1):
        current_row: list[int] = [left_index]
        for right_index, right_char in enumerate(right, start=1):
            insertion_cost = current_row[right_index - 1] + 1
            deletion_cost = previous_row[right_index] + 1
            substitution_cost = previous_row[right_index - 1] + int(left_char != right_char)
            current_row.append(min(insertion_cost, deletion_cost, substitution_cost))
        previous_row = current_row
    return previous_row[-1]
