"""Typed connection properties for each datasource backend.

Each concrete props class is a pydantic value type that validates the
connection mapping from a datasource YAML. Per-field scaffolding
metadata (env var name, scaffold default) rides along the type via
``Annotated[..., ConnectionFieldMeta(...)]`` so the codegen renderer
can read it without a parallel registry.

``ConnectionProps`` is a discriminated-union alias of the concrete
classes — declaring a field as ``ConnectionProps`` lets type checkers
infer attribute access (``connection.database``) over all variants.
"""

from dataclasses import dataclass
from typing import Annotated, ClassVar

from pydantic import AliasChoices, BaseModel, ConfigDict, Field

from .datasource_type import DataSourceType


@dataclass(frozen=True, slots=True)
class ConnectionFieldMeta:
    """Scaffolding metadata for a single connection field."""

    env_var: str = ""
    scaffold_default: str | None = None


class ConnectionPropsBase(BaseModel):
    """Internal base — owns shared model config and the ds_type tag."""

    model_config = ConfigDict(frozen=True, populate_by_name=True)

    ds_type: ClassVar[DataSourceType]


class DuckDBConnectionProps(ConnectionPropsBase):
    """Typed connection properties for DuckDB."""

    ds_type: ClassVar[DataSourceType] = DataSourceType.DUCKDB

    database: Annotated[str, ConnectionFieldMeta(scaffold_default="data/local.duckdb")] = ":memory:"


class PostgresConnectionProps(ConnectionPropsBase):
    """Typed connection properties for PostgreSQL.

    Accepts both ``database`` and the libpq-native ``dbname`` as the
    database key.
    """

    ds_type: ClassVar[DataSourceType] = DataSourceType.POSTGRES

    host: Annotated[str, ConnectionFieldMeta(env_var="PG_HOST")] = "localhost"
    port: Annotated[int, ConnectionFieldMeta(env_var="PG_PORT")] = 5432
    database: Annotated[
        str,
        ConnectionFieldMeta(env_var="PG_DATABASE"),
        Field(default="", validation_alias=AliasChoices("database", "dbname")),
    ] = ""
    user: Annotated[str, ConnectionFieldMeta(env_var="PG_USER")] = ""
    password: Annotated[str, ConnectionFieldMeta(env_var="PG_PASSWORD")] = ""


class SnowflakeConnectionProps(ConnectionPropsBase):
    """Typed connection properties for Snowflake.

    Supports password and key-pair auth: set ``password`` or one of
    ``private_key_content`` / ``private_key_path``. Key-pair takes precedence.
    """

    ds_type: ClassVar[DataSourceType] = DataSourceType.SNOWFLAKE

    account: Annotated[str, ConnectionFieldMeta(env_var="SF_ACCOUNT")] = ""
    database: Annotated[str, ConnectionFieldMeta(env_var="SF_DATABASE")] = ""
    warehouse: Annotated[str, ConnectionFieldMeta(env_var="SF_WAREHOUSE")] = ""
    role: Annotated[str, ConnectionFieldMeta(env_var="SF_ROLE")] = ""
    schema_name: Annotated[str, ConnectionFieldMeta(env_var="SF_SCHEMA"), Field(alias="schema")] = ""
    user: Annotated[str, ConnectionFieldMeta(env_var="SF_USER")] = ""
    password: Annotated[str, ConnectionFieldMeta(env_var="SF_PASSWORD")] = ""
    private_key_content: Annotated[str, ConnectionFieldMeta(env_var="SF_PRIVATE_KEY_CONTENT")] = ""
    private_key_path: Annotated[str, ConnectionFieldMeta(env_var="SF_PRIVATE_KEY_PATH")] = ""

    @property
    def uses_key_pair(self) -> bool:
        """True when key-pair auth is configured."""
        return bool(self.private_key_content or self.private_key_path)


ConnectionProps = DuckDBConnectionProps | PostgresConnectionProps | SnowflakeConnectionProps


CONNECTION_PROPS_BY_TYPE: dict[DataSourceType, type[ConnectionPropsBase]] = {
    DataSourceType.POSTGRES: PostgresConnectionProps,
    DataSourceType.DUCKDB: DuckDBConnectionProps,
    DataSourceType.SNOWFLAKE: SnowflakeConnectionProps,
}


def field_meta(props_cls: type[ConnectionPropsBase], field_name: str) -> ConnectionFieldMeta:
    """Return the scaffolding metadata for a field. Empty meta if none attached."""
    field = props_cls.model_fields.get(field_name)
    if field is None:
        return ConnectionFieldMeta()
    for entry in field.metadata:
        if isinstance(entry, ConnectionFieldMeta):
            return entry
    return ConnectionFieldMeta()


def scaffold_value(props_cls: type[ConnectionPropsBase], field_name: str) -> str:
    """Pick the value the scaffolding renderer should emit for a field."""
    meta = field_meta(props_cls, field_name)
    if meta.env_var:
        return f"${{env.{meta.env_var}}}"
    if meta.scaffold_default is not None:
        return meta.scaffold_default
    field = props_cls.model_fields.get(field_name)
    default = field.default if field is not None else ""
    return str(default) if default is not None else ""


def env_vars(props_cls: type[ConnectionPropsBase]) -> list[str]:
    """All env var names declared by fields on the props class, in field order."""
    return [
        meta.env_var for name in props_cls.model_fields if (meta := field_meta(props_cls, name)).env_var
    ]
