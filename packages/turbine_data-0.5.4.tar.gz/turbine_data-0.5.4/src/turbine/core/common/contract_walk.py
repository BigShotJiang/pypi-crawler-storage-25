"""Walk a parsed DataContract document yielding well-known nested shapes.

Centralizes the ``schema[].properties[]`` traversal so consumers (column-ref
completion, prefill, drift detection) all read the same fields the same way.
Without this, callers reinvent the walk with raw string literals and the two
copies inevitably drift on field name or type.
"""

from collections.abc import Iterator
from typing import cast

from turbine.core.common.constants import FIELD_NAME, FIELD_SCHEMA

PROPERTIES_FIELD = "properties"


def iter_schema_properties(doc_data: dict[str, object]) -> Iterator[tuple[str, dict[str, object]]]:
    """Yield ``(schema_name, property_dict)`` for every declared property.

    Walks ``data["schema"][N]["properties"][M]`` skipping entries whose
    shape doesn't match the contract's expectations (non-dict items,
    missing schema name, etc.) — callers iterate over what's actually
    well-formed in the document.
    """
    for table_name, properties in iter_schema_property_lists(doc_data):
        for prop_dict in iter_named_properties(properties):
            yield table_name, prop_dict


def iter_schema_property_lists(doc_data: dict[str, object]) -> Iterator[tuple[str, list[object]]]:
    """Yield each schema table name with its raw properties list."""
    schemas = doc_data.get(FIELD_SCHEMA)
    if not isinstance(schemas, list):
        return
    for schema_entry in schemas:
        if not isinstance(schema_entry, dict):
            continue
        entry = cast(dict[str, object], schema_entry)
        table_name = entry.get(FIELD_NAME)
        properties = entry.get(PROPERTIES_FIELD)
        if isinstance(table_name, str) and isinstance(properties, list):
            yield table_name, cast(list[object], properties)


def iter_named_properties(properties: list[object]) -> Iterator[dict[str, object]]:
    """Yield property dictionaries that declare a non-empty name."""
    for prop in properties:
        if not isinstance(prop, dict):
            continue
        prop_dict = cast(dict[str, object], prop)
        name = prop_dict.get(FIELD_NAME)
        if isinstance(name, str) and name:
            yield prop_dict


def iter_columns_for_schema(doc_data: dict[str, object], schema_idx: int) -> Iterator[str]:
    """Yield column names declared on ``schema[schema_idx].properties``.

    Out-of-range indices yield nothing so completion can fall back
    silently when the cursor isn't actually inside a known schema.
    """
    schemas = doc_data.get(FIELD_SCHEMA)
    if not isinstance(schemas, list) or not 0 <= schema_idx < len(schemas):
        return
    schema_entry = schemas[schema_idx]
    if not isinstance(schema_entry, dict):
        return
    entry = cast(dict[str, object], schema_entry)
    properties = entry.get(PROPERTIES_FIELD)
    if not isinstance(properties, list):
        return
    for prop in properties:
        if not isinstance(prop, dict):
            continue
        prop_dict = cast(dict[str, object], prop)
        name = prop_dict.get(FIELD_NAME)
        if isinstance(name, str) and name:
            yield name
