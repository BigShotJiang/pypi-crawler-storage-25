"""DatasourceConfig: name, type, typed connection props, and source path."""

from pathlib import Path
from typing import Any

from pydantic import BaseModel, ConfigDict, Field, model_validator

from .connection_props import CONNECTION_PROPS_BY_TYPE, ConnectionProps
from .datasource_type import DataSourceType


class DatasourceConfig(BaseModel):
    """Holds the validated, env-expanded connection details for a datasource."""

    model_config = ConfigDict(frozen=True, populate_by_name=True)

    name: str
    ds_type: DataSourceType = Field(serialization_alias="type")
    connection: ConnectionProps
    source_path: Path | None = None

    @model_validator(mode="before")
    @classmethod
    def coerce_connection_dict(cls, data: Any) -> Any:
        """Lift a raw connection dict into the typed props for ``ds_type``.

        Lets callers (tests, ad-hoc construction) pass ``connection={...}``
        without first picking the right props class. The YAML pipeline
        already passes typed instances, so this is a no-op there.
        """
        if not isinstance(data, dict):
            return data
        connection = data.get("connection")
        if not isinstance(connection, dict):
            return data
        ds_type_raw = data.get("ds_type") or data.get("type")
        if ds_type_raw is None:
            return data
        ds_type = ds_type_raw if isinstance(ds_type_raw, DataSourceType) else DataSourceType(ds_type_raw)
        props_cls = CONNECTION_PROPS_BY_TYPE[ds_type]
        return {**data, "connection": props_cls.model_validate(connection)}
