"""Ports for schema validation — protocols that adapters implement."""

from typing import Any, Protocol

from turbine.core.building_blocks import DiagnosticSink

from .source import RawSource


class SchemaValidator(Protocol):
    """Validate raw YAML data against a JSON Schema and emit diagnostics."""

    def validate(self, data: dict[str, Any], source: RawSource, sink: DiagnosticSink) -> frozenset[str]:
        """Run schema validation and write errors to *sink*.

        Returns the set of dotted key paths that were flagged, so adapter-level
        fallbacks can dedupe against it.
        """
        ...
