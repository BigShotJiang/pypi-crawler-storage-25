"""Cached database introspection results for DB-aware LSP features."""

from dataclasses import dataclass, field

from .dataset_spec.spec import ColumnDef


@dataclass(frozen=True, slots=True)
class DbTableInfo:
    """A table discovered by database introspection, with its full column specs.

    Columns are stored as ``ColumnDef`` (the same type contracts use) so the
    drift validator can consume them directly on every pull-diagnostic run —
    no lossy conversion, no stale findings when the user edits their contract.
    """

    table_name: str
    columns: tuple[ColumnDef, ...]

    def columns_by_ordinal(self) -> tuple[ColumnDef, ...]:
        """Return columns sorted by their ordinal position in the database."""
        return tuple(sorted(self.columns, key=lambda col: col.position))


@dataclass(frozen=True, slots=True)
class IntrospectionCache:
    """Holds cached database schema metadata for DB-aware LSP features.

    Populated each time the user runs ``turbine/validateSchema`` with a
    datasource picked. Replaced atomically on each run.

    Attributes:
        tables: Column-level info, keyed by fully-qualified table name.
            Only populated for tables whose contract was actually validated —
            so column autocompletion only lights up for tables the user cares
            about.
        known_table_names: Every fully-qualified table name that exists on the
            datasource (fetched via ``list_tables``). Powers table-name
            autocomplete and the ``DATASOURCE_TABLE_NOT_FOUND`` lint rule.
        validated_uris: Contract file URIs that were included in the last
            validate run. The lint rule only flags missing tables for contracts
            in this set, so opening an unrelated contract against the wrong
            datasource does not produce false positives.
    """

    tables: dict[str, DbTableInfo]
    known_table_names: frozenset[str] = field(default_factory=frozenset)
    validated_uris: frozenset[str] = field(default_factory=frozenset)

    @classmethod
    def empty(cls) -> "IntrospectionCache":
        """Create an empty cache with no tables."""
        return cls(tables={})

    def get_table(self, table_id: str) -> DbTableInfo | None:
        """Look up a table by its fully-qualified identifier (e.g. 'public.orders')."""
        return self.tables.get(table_id)

    def has_known_tables(self) -> bool:
        """Return True when at least one table was fetched from the datasource."""
        return bool(self.known_table_names)
