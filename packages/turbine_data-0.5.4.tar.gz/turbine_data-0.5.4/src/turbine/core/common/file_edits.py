"""Shared file-edit value objects and diff utilities.

These types describe text edits against workspace files and are used by
multiple features (rename, add-check) and the ``CodeWriter``
port.  They live in ``core.common`` so both ``core.analysis`` and
``core.common.ports`` can depend on them without violating layer rules.
"""

import difflib
from dataclasses import dataclass

from turbine.core.building_blocks import TextEditInfo, TextRange


@dataclass(frozen=True, slots=True)
class TextPosition:
    """A 1-indexed source position."""

    line: int
    col: int


@dataclass(frozen=True, slots=True)
class SnippetInsertion:
    """A guided snippet insertion targeting one position in one file."""

    uri: str
    position: TextPosition
    snippet_text: str


@dataclass(frozen=True, slots=True)
class FileEdits:
    """Bundle of text edits targeting a single file.

    Attributes:
        uri: File URI the edits apply to.
        edits: Ordered sequence of replacements within the file.
    """

    uri: str
    edits: tuple[TextEditInfo, ...]


def diff_to_text_edits(before: str, after: str) -> tuple[TextEditInfo, ...]:
    """Compute minimal TextEditInfos from a line-level diff of before vs after."""
    before_lines = before.splitlines(keepends=True)
    after_lines = after.splitlines(keepends=True)
    matcher = difflib.SequenceMatcher(a=before_lines, b=after_lines)
    edits: list[TextEditInfo] = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        new_text = "".join(after_lines[j1:j2])
        text_range = TextRange(start_line=i1 + 1, start_col=1, end_line=i2 + 1, end_col=1)
        edits.append(TextEditInfo(range=text_range, new_text=new_text))
    return tuple(edits)
