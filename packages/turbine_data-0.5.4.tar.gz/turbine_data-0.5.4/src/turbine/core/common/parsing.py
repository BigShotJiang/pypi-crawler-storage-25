"""Shared parsing utilities for StrEnum types."""

from collections.abc import Mapping
from enum import StrEnum

from turbine.core.building_blocks import DiagnosticBuilder, DiagnosticId


def parse_strenum[E: StrEnum](
    enum_cls: type[E], raw: str, *, aliases: Mapping[str, str] | None = None
) -> E:
    """Parse a string into a StrEnum member case-insensitively.

    Optionally resolves aliases before matching.
    Raises TurbineError with fuzzy suggestions on mismatch.
    """
    normalized = raw.lower()
    resolved = aliases.get(normalized, normalized) if aliases else normalized
    try:
        return enum_cls(resolved)
    except ValueError:
        valid = [m.value for m in enum_cls]
        raise (
            DiagnosticBuilder.error(DiagnosticId.VALIDATION, f"unknown {enum_cls.__name__}: {raw!r}")
            .suggest(resolved, valid, fallback=f"valid options: {', '.join(valid)}")
            .into_error()
        ) from None
