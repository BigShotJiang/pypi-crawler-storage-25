"""SQL identifier validation and qualified table name parsing.

Validates identifier character sets before they reach SQL generation
and splits qualified names like ``schema.table`` into parts.
"""

import re
from dataclasses import dataclass
from enum import StrEnum
from typing import Self

from turbine.core.building_blocks import DiagnosticBuilder, DiagnosticId

SEGMENT = r'(?:"[^"]+"|[a-zA-Z_][a-zA-Z0-9_]*)'
IDENTIFIER_PATTERN = re.compile(rf"^{SEGMENT}(\.{SEGMENT})*$")

MIN_QUALIFIED_PARTS = 2
ODCS_NAME_PARTS = 2


def is_valid_identifier(name: str) -> bool:
    """Return whether *name* is a legal SQL identifier."""
    return IDENTIFIER_PATTERN.match(name) is not None


def parse_identifier_parts(name: str) -> tuple[str, ...] | None:
    """Return validated dot-separated identifier parts, or None when invalid."""
    if not name or not is_valid_identifier(name):
        return None
    segments = re.findall(r'"[^"]+"|[^."]+', name)
    return tuple(segment.strip('"') for segment in segments)


def validate_identifier(name: str, kind: str = "identifier") -> str:
    """Check that *name* is a legal SQL identifier and return it unchanged.

    Accepts plain identifiers (``my_table``), dot-qualified names
    (``schema.table``), and double-quoted segments (``"My Table"``).

    Raises TurbineError with a SCHEMA_ERROR diagnostic when the name
    contains characters outside the allowed set.
    """
    if is_valid_identifier(name):
        return name
    raise (
        DiagnosticBuilder.error(DiagnosticId.SCHEMA_ERROR, f"Invalid SQL {kind}: {name!r}")
        .help("use alphanumeric characters and underscores, optionally double-quoted")
        .into_error()
    )


class OdcsNameValidity(StrEnum):
    """Validity states for ODCS schema ``name:`` values."""

    OK = "ok"
    UNQUALIFIED = "unqualified"
    MALFORMED = "malformed"


@dataclass(frozen=True, slots=True)
class ParsedOdcsName:
    """Parsed ODCS schema ``name:`` value."""

    schema: str | None
    table: str | None
    validity: OdcsNameValidity


class OdcsNameParser:
    """Parse ODCS schema ``name:`` values using ``schema.table`` semantics."""

    @staticmethod
    def parse(value: str, default_schema: str = "public") -> ParsedOdcsName:
        """Return the parsed ODCS name and its validity."""
        parts = parse_identifier_parts(value)
        if parts is None:
            return ParsedOdcsName(schema=None, table=None, validity=OdcsNameValidity.MALFORMED)
        if len(parts) == 1:
            return ParsedOdcsName(
                schema=default_schema, table=parts[0], validity=OdcsNameValidity.UNQUALIFIED
            )
        if len(parts) == ODCS_NAME_PARTS:
            return ParsedOdcsName(schema=parts[0], table=parts[1], validity=OdcsNameValidity.OK)
        return ParsedOdcsName(schema=None, table=None, validity=OdcsNameValidity.MALFORMED)


@dataclass(frozen=True, slots=True)
class TableIdentifier:
    """Splits a qualified table name into schema and table.

    Accepts ``schema.table`` and bare ``table`` (defaults to ``public``).
    Double-quoted segments are stripped of their quotes.
    """

    schema: str
    table: str

    def __str__(self) -> str:
        """Format as ``schema.table``."""
        return f"{self.schema}.{self.table}"

    @classmethod
    def parse(cls, qualified_name: str, default_schema: str = "public") -> Self:
        """Validate and parse a dot-separated table reference.

        Validates that qualified_name contains only legal SQL identifier
        characters, then splits it into schema and table parts. Bare
        table names use ``default_schema`` (defaults to ``"public"``).

        Examples::

            TableIdentifier.parse("users")            -> ("public", "users")
            TableIdentifier.parse("users", "main")    -> ("main", "users")
            TableIdentifier.parse("analytics.events") -> ("analytics", "events")
        """
        parts = parse_identifier_parts(qualified_name)
        if parts is None:
            raise (
                DiagnosticBuilder.error(
                    DiagnosticId.SCHEMA_ERROR, f"Invalid SQL table name: {qualified_name!r}"
                )
                .help("use `schema.table` or a bare table name")
                .into_error()
            )
        if len(parts) >= MIN_QUALIFIED_PARTS:
            return cls(parts[-2], parts[-1])
        return cls(default_schema, parts[-1])
