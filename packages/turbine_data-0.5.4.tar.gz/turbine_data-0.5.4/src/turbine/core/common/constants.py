"""Type-safe constants replacing scattered string literals."""

from enum import StrEnum


class ContractKind(StrEnum):
    """Document kind field values."""

    DATA_CONTRACT = "DataContract"
    QUALITY_SPEC = "QualitySpec"


class FormatLabel(StrEnum):
    """Renderer / reader format identifiers used on adapters."""

    CHECK = "check"
    CONTRACT = "contract"
    DATASOURCE = "datasource"
    FASTAPI = "fastapi"
    ODCS = "odcs"
    QUALITY_SPEC = "quality_spec"
    RESOURCE = "resource"
    SQLMODEL = "sqlmodel"


SQL_EXT = ".sql"
YAML_EXTS: tuple[str, str] = (".yml", ".yaml")
FIELD_KIND = "kind"
FIELD_ID = "id"
FIELD_SCHEMA = "schema"
FIELD_TARGET_CONTRACT = "targetContract"
FIELD_DATASET = "dataset"
FIELD_DOMAIN = "domain"
FIELD_NAME = "name"
FIELD_CHECKS = "checks"
FIELD_SQL = "sql"
FIELD_FILE = "file"
