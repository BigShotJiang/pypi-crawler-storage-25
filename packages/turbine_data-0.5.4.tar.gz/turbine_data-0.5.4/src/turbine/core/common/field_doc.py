"""FieldDoc — structured metadata for one JSON Schema property."""

from dataclasses import dataclass, field


@dataclass(frozen=True, slots=True)
class FieldDoc:
    """Structured metadata for one JSON Schema property.

    Captures type, description, enum constraints, examples, and defaults.
    ``enum_descriptions`` carries the per-value docs sourced from the
    ``x-enumDescriptions`` schema extension; missing entries fall back to
    the bare value name in hover and completion rendering.
    """

    description: str
    value_type: str
    enum_values: tuple[str, ...] = ()
    enum_descriptions: dict[str, str] = field(default_factory=dict)
    examples: tuple[str, ...] = ()
    default: str | None = None
    required: bool = False
    deprecated: bool = False
