"""Duration value object — compact human-readable time spans.

Parses and serializes strings like ``1w``, ``7d``, ``12h``, ``30m``, ``45s``,
and combinations such as ``1w3d`` or ``1d12h``. Renders to
``datetime.timedelta`` for Python arithmetic and to a sqlglot ``Interval`` AST
for SQL emission.
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from datetime import timedelta
from typing import Self

from sqlglot import exp

from turbine.core.building_blocks.diagnostics import TurbineError
from turbine.core.common.datasource_type import DataSourceType

UNIT_ORDER: tuple[str, ...] = ("w", "d", "h", "m", "s")
UNIT_LABELS: dict[str, str] = {"w": "weeks", "d": "days", "h": "hours", "m": "minutes", "s": "seconds"}
ACCEPTED_SHAPES = "accepted shapes: 1w, 7d, 12h, 30m, 45s, 1w3d, 1d12h, 2h30m"
TOKEN_RE = re.compile(r"(\d+)([a-zA-Z])")


@dataclass(frozen=True, slots=True)
class Duration:
    """A positive time span composed of weeks, days, hours, minutes, and seconds."""

    weeks: int = 0
    days: int = 0
    hours: int = 0
    minutes: int = 0
    seconds: int = 0

    @classmethod
    def parse(cls, text: str) -> Self:
        """Parse a compact duration string into a Duration.

        Raises TurbineError on empty input, unknown units, duplicate units,
        non-descending order, or any value that does not match the accepted
        shapes.
        """
        if not text:
            raise TurbineError(f"empty duration string; {ACCEPTED_SHAPES}")
        tokens = TOKEN_RE.findall(text)
        if not tokens or "".join(amount + unit for amount, unit in tokens) != text:
            raise TurbineError(f"could not parse duration {text!r}; {ACCEPTED_SHAPES}")
        values = collect_values(text, tokens)
        if not any(values.values()):
            raise TurbineError(f"duration {text!r} must be non-zero; {ACCEPTED_SHAPES}")
        return cls(
            weeks=values.get("w", 0),
            days=values.get("d", 0),
            hours=values.get("h", 0),
            minutes=values.get("m", 0),
            seconds=values.get("s", 0),
        )

    def to_canonical(self) -> str:
        """Serialize to the canonical compact form (round-trip stable)."""
        parts: list[str] = []
        for unit, amount in zip(UNIT_ORDER, self.as_tuple(), strict=True):
            if amount:
                parts.append(f"{amount}{unit}")
        return "".join(parts)

    def to_timedelta(self) -> timedelta:
        """Convert to a ``datetime.timedelta``."""
        return timedelta(
            weeks=self.weeks,
            days=self.days,
            hours=self.hours,
            minutes=self.minutes,
            seconds=self.seconds,
        )

    def to_sqlglot_interval(self, dialect: DataSourceType) -> exp.Interval:
        """Build a sqlglot ``Interval`` AST for this duration.

        The literal is rendered Postgres-style (``'1 days 12 hours'``) so the
        same node can be emitted by every supported dialect. The ``dialect``
        argument is part of the contract for future per-dialect AST shaping.
        """
        del dialect
        literal = " ".join(
            f"{amount} {UNIT_LABELS[unit]}"
            for unit, amount in zip(UNIT_ORDER, self.as_tuple(), strict=True)
            if amount
        )
        return exp.Interval(this=exp.Literal.string(literal))

    def as_tuple(self) -> tuple[int, int, int, int, int]:
        """Return ``(weeks, days, hours, minutes, seconds)`` for unit iteration."""
        return (self.weeks, self.days, self.hours, self.minutes, self.seconds)


def collect_values(text: str, tokens: list[tuple[str, str]]) -> dict[str, int]:
    """Validate the parsed token list and return ``unit -> amount``."""
    values: dict[str, int] = {}
    last_index = -1
    for amount, unit in tokens:
        unit_lower = unit.lower()
        if unit_lower not in UNIT_ORDER:
            raise TurbineError(f"unknown unit {unit!r} in {text!r}; {ACCEPTED_SHAPES}")
        if unit_lower in values:
            raise TurbineError(f"duplicate unit {unit_lower!r} in {text!r}; {ACCEPTED_SHAPES}")
        index = UNIT_ORDER.index(unit_lower)
        if index <= last_index:
            raise TurbineError(f"units in {text!r} must appear in descending order (w > d > h > m > s)")
        last_index = index
        values[unit_lower] = int(amount)
    return values
