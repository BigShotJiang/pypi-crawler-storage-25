"""Quality dimensions for check scoring and flag allocation.

Contracts and quality specs tag each check with one of five
dimensions. Scores and flag bits roll up per dimension.
"""

from enum import StrEnum
from typing import Self

from .parsing import parse_strenum

DIMENSION_ALIASES: dict[str, str] = {"uniqueness": "consistency", "unique": "consistency"}


class QualityDimension(StrEnum):
    """Groups checks into five scoring categories.

    Accuracy     -- values are factually correct.
    Completeness -- all expected rows and values are present.
    Consistency  -- values agree with each other and with the rules; includes uniqueness.
    Timeliness   -- data arrived on time.
    Validity     -- values match a defined shape, format, or allowed set.
    """

    ACCURACY = "accuracy"
    COMPLETENESS = "completeness"
    CONSISTENCY = "consistency"
    TIMELINESS = "timeliness"
    VALIDITY = "validity"

    @classmethod
    def parse(cls, raw: str) -> Self:
        """Parse a dimension string case-insensitively, with common aliases.

        ``uniqueness`` / ``unique`` map to ``consistency``;
        ``validity`` / ``valid`` map to ``accuracy``.

        Raises TurbineError with fuzzy suggestions when the input
        does not match any known dimension.
        """
        return parse_strenum(cls, raw, aliases=DIMENSION_ALIASES)

    @classmethod
    def from_string(cls, raw: str) -> Self | None:
        """Return the matching dimension or None for unknown input.

        Use when an invalid value is recoverable (e.g. wire payload
        from the editor) and the caller wants to skip rather than
        surface a parsing error.
        """
        try:
            return cls(raw)
        except ValueError:
            return None
