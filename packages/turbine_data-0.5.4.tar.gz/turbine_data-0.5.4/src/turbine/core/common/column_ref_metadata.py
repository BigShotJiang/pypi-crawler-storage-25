"""Column-reference JSON Schema metadata shared by quality and analysis."""

from enum import StrEnum


class ColumnRefKind(StrEnum):
    """Closed set of values valid for the ``x-turbine-ref.kind`` extension keyword."""

    COLUMN = "column"
    QUALIFIED_COLUMN = "qualified-column"
    DB_TABLE = "db_table"
    DB_COLUMN = "db_column"


X_TURBINE_REF = "x-turbine-ref"
REF_KIND_FIELD = "kind"


def column_ref(kind: ColumnRefKind) -> dict[str, dict[str, str]]:
    """Build the Pydantic ``json_schema_extra`` metadata for a column reference."""
    return {X_TURBINE_REF: {REF_KIND_FIELD: kind.value}}
