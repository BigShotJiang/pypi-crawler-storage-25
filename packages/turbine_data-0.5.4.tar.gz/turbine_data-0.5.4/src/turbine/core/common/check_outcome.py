"""Shared check outcome vocabulary."""

from enum import StrEnum


class CheckOutcome(StrEnum):
    """Pass, fail, warn, skip, or error."""

    PASSED = "passed"
    FAILED = "failed"
    WARNED = "warned"
    SKIPPED = "skipped"
    ERRORED = "errored"
