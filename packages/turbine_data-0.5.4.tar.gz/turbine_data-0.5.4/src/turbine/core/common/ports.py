"""Ports for shared domain concepts: database access and parsing."""

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol, runtime_checkable

from turbine.core.building_blocks import DiagnosticSink

from .dataset_spec import ColumnDef
from .datasource import DatasourceConfig
from .datasource_type import DataSourceType
from .identifiers import TableIdentifier
from .logical_type import LogicalType
from .source import RawSource


@dataclass(frozen=True, slots=True)
class ProbeResult:
    """Result of a single datasource connectivity probe."""

    datasource_name: str
    datasource_type: DataSourceType
    database: str | None
    connected: bool
    latency_ms: int | None = None
    error: str | None = None

    @classmethod
    def failed(cls, datasource: "DatasourceConfig", error: str) -> "ProbeResult":
        """Build a failure result from a datasource config and error message."""
        return cls(
            datasource_name=datasource.name,
            datasource_type=datasource.ds_type,
            database=datasource.connection.database or None,
            connected=False,
            error=error,
        )


@runtime_checkable
class ConnectivityProbe(Protocol):
    """Probes a datasource to check if it is reachable."""

    def probe(self, datasource: DatasourceConfig) -> ProbeResult:
        """Probe *datasource* and return the result."""
        ...


@runtime_checkable
class SourceParser(Protocol):
    """Reads a file and returns a RawSource with source-map positions."""

    def __call__(self, path: Path) -> RawSource:
        """Read *path* and return a RawSource with position tracking."""
        ...


@runtime_checkable
class DatasourceRepository(Protocol):
    """Finds and loads datasource configs by name."""

    def list_datasources(self, sink: DiagnosticSink) -> tuple[DatasourceConfig, ...]:
        """Return every known datasource config."""
        ...

    def get(self, key: str, sink: DiagnosticSink) -> DatasourceConfig:
        """Look up one datasource by name."""
        ...

    def load_from_path(self, path: Path, sink: DiagnosticSink) -> DatasourceConfig:
        """Parse a datasource config from a specific file path.

        Raises TurbineError when the file cannot be read or the YAML fails
        validation.
        """
        ...


@runtime_checkable
class QueryExecutor(Protocol):
    """Executes SQL and returns results as tuples."""

    def execute_query(
        self, sql: str, params: dict[str, object] | None = None
    ) -> tuple[tuple[object, ...], ...]:
        """Execute SQL and return all rows as a tuple of tuples.

        When *params* is provided, *sql* should use named placeholders
        (e.g. ``:name``) and the backend binds them safely, avoiding
        SQL injection.
        """
        ...


@dataclass(frozen=True, slots=True)
class DatasourceError:
    """A single datasource failure with context."""

    datasource_name: str
    reason: str


@dataclass(frozen=True, slots=True)
class IntrospectionError:
    """Introspection failed — carries per-datasource failure reasons."""

    table: str
    errors: tuple[DatasourceError, ...]

    def summary(self) -> str:
        """Human-readable summary of all failures for this table."""
        details = "; ".join(f"{err.datasource_name}: {err.reason}" for err in self.errors)
        return f"Could not introspect {self.table} ({details})"


@dataclass(frozen=True, slots=True)
class IntrospectionResult:
    """Result of introspecting a table — columns plus capability flags.

    Capability flags let validators skip rules when the database backend
    cannot report certain metadata (e.g. constraint or precision info).
    """

    columns: tuple[ColumnDef, ...]
    has_constraint_info: bool = False
    has_precision_info: bool = False


@dataclass(frozen=True, slots=True)
class ListTablesResult:
    """Outcome of listing tables on a datasource — success or unreachable."""

    tables: tuple[TableIdentifier, ...]
    error: str | None = None

    @classmethod
    def ok(cls, tables: tuple[TableIdentifier, ...]) -> "ListTablesResult":
        """Return a successful result carrying the discovered tables."""
        return cls(tables=tables)

    @classmethod
    def unreachable(cls, error: str) -> "ListTablesResult":
        """Return a failure result carrying the reason the datasource could not be reached."""
        return cls(tables=(), error=error)

    @property
    def reachable(self) -> bool:
        """Return True when the datasource responded, even if it had no tables."""
        return self.error is None


@runtime_checkable
class SchemaIntrospector(Protocol):
    """Queries a live database for table and column metadata."""

    def introspect_schema(self, table: TableIdentifier) -> tuple[ColumnDef, ...] | None:
        """Return column definitions for a table, or None if the table does not exist."""
        ...

    def list_tables(self, schema: str | None = None) -> tuple[TableIdentifier, ...]:
        """Return base tables, optionally filtered to a single schema.

        When *schema* is None, returns tables from all non-system schemas.
        """
        ...


@dataclass(frozen=True, slots=True)
class FlagUpsertParams:
    """Carries the raw inputs for a flag upsert operation."""

    table: str
    flag_column: str
    bit_position: int
    pk_columns: tuple[str, ...]
    pks: tuple[tuple[object, ...], ...]
    run_id: str


@runtime_checkable
class DialectSql(Protocol):
    """Generates dialect-specific SQL for quality row-flagging operations."""

    def set_bit_expr(self, column: str, bit: int) -> str:
        """Return an expression that sets bit *bit* in *column*."""
        ...

    def add_flag_column_sql(self, table: str, column: str) -> str:
        """Return DDL that adds a flag column to *table*."""
        ...

    def flag_upsert_sql(self, params: FlagUpsertParams) -> tuple[str, ...]:
        """Return SQL statement(s) that upsert flag bits for the given PKs."""
        ...

    def bit_check_expr(self, column: str, mask: int) -> str:
        """Return ``(column & mask) > 0`` in dialect-appropriate syntax."""
        ...

    def list_tables_sql(self, schema: str | None) -> tuple[str, dict[str, str]]:
        """Return SQL + params to list base tables.

        When *schema* is None, returns all non-system-schema tables.
        When given, filters to that schema only.
        """
        ...

    def introspect_columns_sql(self, schema: str, table: str) -> tuple[str, dict[str, str]]:
        """Return SQL + params to introspect column definitions for a table.

        The query must return rows with these columns in order:
        column_name, data_type, ordinal_position, is_nullable ('YES'/'NO'),
        is_primary_key ('YES'/'NO').
        """
        ...

    def normalize_identifier(self, identifier: str) -> str:
        """Normalize an identifier for the target dialect (e.g. upper-case for Snowflake)."""
        ...

    def resolve_type(self, raw_type: str) -> LogicalType:
        """Convert a raw DB type string to a LogicalType, falling back to STRING."""
        ...


@runtime_checkable
class TransactionManager(Protocol):
    """Controls transaction boundaries on a database connection."""

    def begin(self) -> None:
        """Start a new transaction."""
        ...

    def commit(self) -> None:
        """Commit the current transaction."""
        ...

    def rollback(self) -> None:
        """Roll back the current transaction."""
        ...


@runtime_checkable
class DatabaseBackend(QueryExecutor, SchemaIntrospector, TransactionManager, Protocol):
    """Combines query execution, schema introspection, and transaction control.

    Consumers should depend on the narrow protocol they need, not
    on DatabaseBackend directly.
    """

    @property
    def default_schema(self) -> str:
        """Return the database's default schema name."""
        ...

    @property
    def dialect_sql(self) -> DialectSql:
        """Return the dialect-specific SQL helper for this backend."""
        ...


@runtime_checkable
class DatabaseBackendFactory(Protocol):
    """Builds a DatabaseBackend from a DatasourceConfig."""

    def create(self, ds_config: DatasourceConfig, sink: DiagnosticSink) -> DatabaseBackend:
        """Validate *ds_config*, import the driver, and build a DatabaseBackend.

        Raises TurbineError and emits diagnostics on unknown type, missing
        driver, or invalid connection config.
        """
        ...


@runtime_checkable
class DatasourceIntrospector(Protocol):
    """Port for per-datasource schema introspection.

    Models the operations the application layer needs: list tables in one
    or more schemas, introspect a single table's columns, and evict any
    cached backend when a datasource's config changes on disk. Concrete
    adapters back these with SQLAlchemy; callers depend on the port so
    registries and services do not need the heavy import.
    """

    def list_tables_across_schemas(
        self, datasource_name: str, schemas: frozenset[str]
    ) -> "ListTablesResult":
        """Return every table in *schemas* on *datasource_name*."""
        ...

    def introspect(
        self, table: TableIdentifier, datasource_name: str | None
    ) -> "IntrospectionResult | IntrospectionError":
        """Introspect *table* on *datasource_name*, or try every datasource if None."""
        ...

    def introspect_config(
        self, config: DatasourceConfig, table: TableIdentifier
    ) -> "IntrospectionResult | IntrospectionError":
        """Introspect *table* using a pre-parsed config (bypasses repository lookup)."""
        ...

    def list_tables_config(
        self, config: DatasourceConfig, schemas: frozenset[str]
    ) -> "ListTablesResult":
        """List tables using a pre-parsed config (bypasses repository lookup)."""
        ...

    def invalidate_datasource(self, datasource_name: str) -> None:
        """Evict the cached backend for *datasource_name*."""
        ...
