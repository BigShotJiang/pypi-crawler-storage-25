"""Project layout protocol — directory structure of a Turbine project."""

from pathlib import Path
from typing import Protocol


class ProjectLayout(Protocol):
    """Read-only view of the Turbine project directory layout.

    The concrete implementation lives in ``infra.config``. Application and
    core layers depend only on this Protocol.
    """

    @property
    def root(self) -> Path: ...

    @property
    def contracts_dir(self) -> Path: ...

    @property
    def quality_dir(self) -> Path: ...

    @property
    def datasources_dir(self) -> Path: ...

    @property
    def checks_dir(self) -> Path: ...
