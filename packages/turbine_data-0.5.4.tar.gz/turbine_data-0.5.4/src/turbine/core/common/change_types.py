"""Change tracking value objects — shared across contract and analysis domains."""

from dataclasses import dataclass
from enum import StrEnum


class ChangeType(StrEnum):
    """Kind of schema change detected between two index snapshots."""

    COLUMN_REMOVED = "column-removed"
    COLUMN_TYPE_CHANGED = "column-type-changed"
    COLUMN_ADDED = "column-added"
    COLUMN_NULLABLE_CHANGED = "column-nullable-changed"
    CHECK_ADDED = "check-added"
    CHECK_REMOVED = "check-removed"
    SCHEMA_REMOVED = "schema-removed"
    PK_COLUMN_ADDED = "pk-column-added"
    PK_COLUMN_REMOVED = "pk-column-removed"
    CHECK_THRESHOLD_CHANGED = "check-threshold-changed"
    COLUMN_DESCRIPTION_ADDED = "column-description-added"
    COLUMN_DESCRIPTION_REMOVED = "column-description-removed"
    COLUMN_DESCRIPTION_CHANGED = "column-description-changed"
    SLA_ELEMENT_CHANGED = "sla-element-changed"
    COLUMN_REQUIRED_TIGHTENED = "column-required-tightened"


@dataclass(frozen=True, slots=True)
class ContractChange:
    """One change detected between two snapshots of a contract."""

    change_type: ChangeType
    contract_id: str
    column_name: str | None = None
    old_type: str | None = None
    new_type: str | None = None
    check_name: str | None = None
    old_nullable: bool | None = None
    new_nullable: bool | None = None
    old_value: str | None = None
    new_value: str | None = None
