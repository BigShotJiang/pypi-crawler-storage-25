"""Walk a JSON Schema to resolve valid keys and values at any cursor position.

resolve_at_path() is the main entry point: given a dotted YAML path like
'schema.0.properties.0', it returns the valid child fields, enum values,
and examples at that position. Used by validation for suggestions and
by the LSP for autocompletions. SchemaNavigator handles $ref/$defs resolution.
"""

import re
from collections.abc import Iterator, Mapping
from dataclasses import dataclass, field
from typing import Any

from turbine.core.building_blocks import SchemaKey

from .field_doc import FieldDoc

type SchemaNode = dict[str, Any]
"""A node in a JSON Schema tree (recursive, so TypedDict doesn't apply)."""


@dataclass(frozen=True, slots=True)
class ResolvedNode:
    """Child fields, enum values, and examples at a schema path position.

    ``raw_children`` carries the raw JSON Schema for each child field so
    completion-time consumers (e.g. the snippet builder) can recurse into
    required subfields without re-walking the schema.  ``navigator`` is
    attached so those consumers can resolve ``$ref``s against the same
    ``$defs`` table that produced the children.
    """

    children: dict[str, FieldDoc]
    enum_values: tuple[str, ...] = ()
    examples: tuple[str, ...] = ()
    is_array: bool = False
    raw_children: dict[str, "SchemaNode"] = field(default_factory=dict)
    navigator: "SchemaNavigator | None" = None


EMPTY = ResolvedNode(children={})


def resolve_type(prop_schema: SchemaNode, defs: dict[str, SchemaNode]) -> str:
    """Determine the type string for a JSON Schema property definition.

    Handles direct ``type`` keys (scalar or list, e.g. ``["string", "integer"]``),
    ``$ref`` lookups into ``$defs``, and ``oneOf``/``anyOf`` unions (returned as
    ``"string | integer"``). Falls back to ``"any"`` for unrecognized shapes.
    """
    raw_type = prop_schema.get(SchemaKey.TYPE)
    if isinstance(raw_type, list):
        return " | ".join(str(variant) for variant in raw_type) or "any"
    if isinstance(raw_type, str):
        return raw_type
    if SchemaKey.REF in prop_schema:
        ref_name = prop_schema[SchemaKey.REF].rsplit("/", 1)[-1]
        return str(defs.get(ref_name, {}).get(SchemaKey.TYPE, "object"))
    if variants := prop_schema.get(SchemaKey.ONE_OF) or prop_schema.get(SchemaKey.ANY_OF):
        types = dict.fromkeys(resolve_type(v, defs) for v in variants if isinstance(v, dict))
        return " | ".join(types) or "any"
    return "any"


def prop_to_field_doc(
    prop_schema: SchemaNode,
    *,
    required: bool,
    defs: dict[str, SchemaNode],
    sibling_context: dict[str, str] | None = None,
) -> FieldDoc:
    """Build a FieldDoc from a raw JSON Schema property dict and the root schema's $defs.

    When ``sibling_context`` is supplied, an ``x-contextDescriptions`` entry on
    the property whose key matches a sibling field and whose inner value matches
    the sibling's literal value overrides the static ``description``.  Falls back
    to ``description`` (or ``title``) when no override applies.
    """
    default_val = prop_schema.get(SchemaKey.DEFAULT)
    value_type = annotate_format(resolve_type(prop_schema, defs), prop_schema.get(SchemaKey.FORMAT))
    static_description = prop_schema.get(SchemaKey.TITLE) or prop_schema.get(SchemaKey.DESCRIPTION, "")
    description = extract_context_description(prop_schema, sibling_context) or static_description
    return FieldDoc(
        description=description,
        value_type=value_type,
        enum_values=extract_enum_values(prop_schema, value_type),
        enum_descriptions=extract_enum_descriptions(prop_schema),
        examples=tuple(str(v) for v in prop_schema.get(SchemaKey.EXAMPLES, ())),
        default=str(default_val) if default_val is not None else None,
        required=required,
        deprecated=prop_schema.get(SchemaKey.DEPRECATED, False),
    )


def extract_context_description(
    prop_schema: SchemaNode, sibling_context: dict[str, str] | None
) -> str | None:
    """Return the context-overridden description, or ``None`` when no override applies.

    ``x-contextDescriptions`` lets a field's description vary by a sibling
    field's value.  The extension shape is ``{sibling_key: {sibling_value: description}}``.
    Returns ``None`` when the extension is missing, malformed, the context lacks
    the sibling key, or the sibling value isn't in the table — callers then fall
    back to the static ``description``.
    """
    if not sibling_context:
        return None
    raw = prop_schema.get(SchemaKey.CONTEXT_DESCRIPTIONS)
    if not isinstance(raw, dict):
        return None
    for sibling_key, value_table in raw.items():
        if not isinstance(value_table, dict):
            continue
        sibling_value = sibling_context.get(sibling_key)
        if sibling_value is None:
            continue
        description = value_table.get(sibling_value)
        if isinstance(description, str):
            return description
    return None


def annotate_format(value_type: str, schema_format: object) -> str:
    """Return ``"string<date-time>"`` style when a format hint is present."""
    if not isinstance(schema_format, str) or not schema_format:
        return value_type
    return f"{value_type}<{schema_format}>"


def extract_enum_descriptions(prop_schema: SchemaNode) -> dict[str, str]:
    """Read the ``x-enumDescriptions`` extension into a value→description map.

    Returns an empty dict when the extension is missing or malformed; callers
    treat missing keys as "no description for this value" and fall back to
    the bare value name.
    """
    raw = prop_schema.get(SchemaKey.ENUM_DESCRIPTIONS)
    if not isinstance(raw, dict):
        return {}
    return {str(value): str(text) for value, text in raw.items() if isinstance(text, str)}


def extract_enum_values(prop_schema: SchemaNode, value_type: str) -> tuple[str, ...]:
    """Return the allowed literal values for a schema property.

    JSON Schema expresses enumerability three ways: an explicit ``const`` (one
    value), an ``enum`` list, or ``type: boolean`` (exactly true/false).
    Completion-wise they're all the same — a finite set of literal values the
    user can pick. Synthesising ``("true", "false")`` for booleans here means
    every boolean field gets value completion without each caller special-casing.
    """
    if SchemaKey.CONST in prop_schema:
        return (str(prop_schema[SchemaKey.CONST]),)
    if enum := prop_schema.get(SchemaKey.ENUM, ()):
        return tuple(str(v) for v in enum)
    if value_type == "boolean":
        return ("true", "false")
    return ()


class SchemaNavigator:
    """Walk a JSON Schema tree, resolving $ref pointers against root $defs."""

    def __init__(self, schema: SchemaNode) -> None:
        """Extract $defs from the root schema for later $ref resolution."""
        self.defs: dict[str, SchemaNode] = schema.get(SchemaKey.DEFS, {})

    def build_node(
        self, schema_node: SchemaNode, *, sibling_context: dict[str, str] | None = None
    ) -> ResolvedNode:
        """Gather fields, enums, and examples from a schema node into a ResolvedNode.

        ``sibling_context`` is threaded into ``prop_to_field_doc`` so child
        ``FieldDoc`` descriptions can be overridden by ``x-contextDescriptions``
        when a sibling field's value selects an alternative.
        """
        props, required = self.collect_fields(schema_node)
        is_array = schema_node.get(SchemaKey.TYPE) == "array"

        enum_values = extract_enum_values(schema_node, resolve_type(schema_node, self.defs))
        examples = tuple(str(v) for v in schema_node.get(SchemaKey.EXAMPLES, []))

        raw_children = {name: self.resolve_ref(prop) for name, prop in props.items()}
        children = {
            name: prop_to_field_doc(
                raw, required=name in required, defs=self.defs, sibling_context=sibling_context
            )
            for name, raw in raw_children.items()
        }

        return ResolvedNode(
            children=children,
            enum_values=enum_values,
            examples=examples,
            is_array=is_array,
            raw_children=raw_children,
            navigator=self,
        )

    def collect_fields(self, schema_node: SchemaNode) -> tuple[dict[str, SchemaNode], set[str]]:
        """Gather properties and required names, following ``$ref``, ``allOf``, ``oneOf``, ``anyOf``.

        ``allOf`` is conjunctive — every branch's required fields apply, so we
        union both props and required. ``oneOf``/``anyOf`` are disjunctive:
        we union the *possible* properties so completion can offer every valid
        key the user might choose, but we do NOT union ``required`` because a
        given property is only required when its specific variant is selected
        (the validator enforces that at check time, not the completion layer).

        ``patternProperties`` regex keys are expanded into concrete names
        (e.g. ``^(sql|python)$`` becomes entries for ``sql`` and ``python``).
        """
        props: dict[str, SchemaNode] = dict(schema_node.get(SchemaKey.PROPERTIES, {}))
        required: set[str] = set(schema_node.get(SchemaKey.REQUIRED, []))

        self.merge_pattern_properties(schema_node, props)
        self.merge_conjunctive(schema_node, props, required)
        self.merge_disjunctive(schema_node, props)
        return props, required

    def merge_pattern_properties(self, schema_node: SchemaNode, props: dict[str, SchemaNode]) -> None:
        """Expand ``patternProperties`` regex keys into concrete property entries.

        Handles ``^name$`` (literal) and ``^(a|b|c)$`` (alternation) patterns,
        which cover all quality-spec check-type schemas.
        """
        for pattern, body_schema in schema_node.get(SchemaKey.PATTERN_PROPERTIES, {}).items():
            resolved_body = self.resolve_ref(body_schema)
            for name in expand_pattern_names(pattern):
                props.setdefault(name, resolved_body)

    def merge_conjunctive(
        self, schema_node: SchemaNode, props: dict[str, SchemaNode], required: set[str]
    ) -> None:
        """Merge ``$ref`` + ``allOf`` branches into *props* and *required* (conjunctive union).

        Local properties (already in *props* from ``schema_node.properties``) win
        over inherited definitions pulled in via ``$ref`` or ``allOf``: a child
        schema refining a parent's property — e.g. ``SchemaObject.name`` adding
        an ``x-turbine-ref`` over the bare ``SchemaElement.name`` — must keep
        its refinement. ``required`` is union-merged (conjunctive).
        """
        if SchemaKey.REF in schema_node:
            ref_props, ref_req = self.collect_fields(self.resolve_ref_target(schema_node[SchemaKey.REF]))
            for name, prop in ref_props.items():
                props.setdefault(name, prop)
            required |= ref_req
        for item in schema_node.get(SchemaKey.ALL_OF, []):
            child_props, child_req = self.collect_fields(self.resolve_ref(item))
            for name, prop in child_props.items():
                props.setdefault(name, prop)
            required |= child_req

    def merge_disjunctive(self, schema_node: SchemaNode, props: dict[str, SchemaNode]) -> None:
        """Merge ``oneOf``/``anyOf`` variants into *props* (disjunctive — skip required)."""
        for union_key in (SchemaKey.ONE_OF, SchemaKey.ANY_OF):
            for variant in schema_node.get(union_key, []):
                if not isinstance(variant, dict):
                    continue
                variant_props, _ = self.collect_fields(self.resolve_ref(variant))
                for name, prop in variant_props.items():
                    props.setdefault(name, prop)

    def resolve_ref(self, schema_node: SchemaNode) -> SchemaNode:
        """Follow $ref chains to the target definition, merging sibling keys on top."""
        if SchemaKey.REF not in schema_node:
            return schema_node
        ref_def = self.resolve_ref_target(schema_node[SchemaKey.REF])
        ref_def = self.resolve_ref(ref_def)
        siblings = {k: v for k, v in schema_node.items() if k != SchemaKey.REF}
        if not siblings:
            return ref_def
        merged = dict(ref_def)
        merged.update(siblings)
        return merged

    def resolve_ref_target(self, ref: str) -> SchemaNode:
        """Look up a $ref string like '#/$defs/SchemaObject' in the schema's $defs."""
        ref_name = ref.rsplit("/", 1)[-1]
        return self.defs.get(ref_name, {})

    def iter_array_candidates(self, schema_node: SchemaNode) -> Iterator[SchemaNode]:
        """Yield schema nodes that could be arrays: the node itself plus any oneOf/anyOf variants."""
        yield schema_node
        for key in (SchemaKey.ONE_OF, SchemaKey.ANY_OF):
            for variant in schema_node.get(key, []):
                match variant:
                    case {SchemaKey.REF: ref}:
                        yield variant
                        yield self.resolve_ref_target(ref)
                    case dict():
                        yield variant

    def resolve_array_items(self, schema_node: SchemaNode) -> SchemaNode | None:
        """Return the items schema if this node (or a oneOf/anyOf variant) is an array."""
        for candidate in self.iter_array_candidates(schema_node):
            if candidate.get(SchemaKey.TYPE) == "array" and SchemaKey.ITEMS in candidate:
                return self.resolve_ref(candidate[SchemaKey.ITEMS])
        return None

    def walk_to_leaf(
        self, dotted_path: str, schema: SchemaNode, *, yaml_data: Mapping[str, object] | None = None
    ) -> SchemaNode | None:
        """Walk *dotted_path* against *schema* and return the resolved leaf, or None.

        Steps integer segments through ``items`` and string segments through
        properties; applies conditionals against *yaml_data* so ``if/then``
        branches resolve to the matching variant. Returns ``None`` when a
        segment cannot be resolved.
        """
        if not dotted_path:
            return schema

        current: SchemaNode = schema
        yaml_cursor: Any = yaml_data
        for segment in dotted_path.split("."):
            if segment.isdigit():
                resolved_items = self.resolve_array_items(current)
                if resolved_items is None:
                    return None
                current = resolved_items
                yaml_cursor = navigate_yaml(yaml_cursor, int(segment))
                continue
            current = self.apply_conditionals(current, yaml_cursor)
            props, _ = self.collect_fields(current)
            if segment not in props:
                return None
            current = self.resolve_ref(props[segment])
            yaml_cursor = navigate_yaml(yaml_cursor, segment)
        return self.apply_conditionals(current, yaml_cursor)

    def apply_conditionals(self, schema_node: SchemaNode, yaml_cursor: Any) -> SchemaNode:
        """Evaluate if/then/else in allOf against yaml_cursor and merge matching properties.

        Then/else branches are frequently authored as ``$ref`` pointers
        (e.g. ODCS ``DataQuality`` points at ``DataQualitySql`` /
        ``DataQualityLibrary`` / ``DataQualityCustom``). We run each matching
        branch through ``collect_fields`` so its own $ref chain and allOf
        merges contribute their properties, not just whatever happens to sit
        inline on the branch node.

        Recurses into the resolved branch before collecting fields, because
        branches commonly have their *own* nested if/then — e.g.
        ``DataQualityCustom`` carries an inner ``if: engine == turbine`` that
        overrides ``implementation`` to the turbine check-body shape, and
        that shape in turn carries per-``check:`` branches. Without the
        recursion the outer match picks the right branch but every nested
        discriminator stays invisible to completion.
        """
        all_of = schema_node.get(SchemaKey.ALL_OF, [])
        if not all_of:
            return schema_node

        merged = dict(schema_node)
        extra_props: dict[str, SchemaNode] = {}

        for item in all_of:
            resolved = self.resolve_ref(item)
            if SchemaKey.IF not in resolved:
                continue

            branch: SchemaNode | None = None
            if evaluate_condition(resolved[SchemaKey.IF], yaml_cursor):
                branch = resolved.get(SchemaKey.THEN)
            elif SchemaKey.ELSE in resolved:
                branch = resolved[SchemaKey.ELSE]

            if not isinstance(branch, dict):
                continue

            resolved_branch = self.apply_conditionals(self.resolve_ref(branch), yaml_cursor)
            branch_props, _ = self.collect_fields(resolved_branch)
            extra_props.update(branch_props)

        if extra_props:
            existing = dict(merged.get(SchemaKey.PROPERTIES, {}))
            merged[SchemaKey.PROPERTIES] = merge_schema_props(existing, extra_props)

        return merged


def resolve_at_path(
    dotted_path: str,
    schema: SchemaNode,
    *,
    yaml_data: Mapping[str, object] | None = None,
    sibling_context: dict[str, str] | None = None,
) -> ResolvedNode:
    """Walk a dotted path through the schema, returning valid children/enums at that position.

    ``sibling_context`` is forwarded to ``build_node`` so child descriptions
    that opt in via ``x-contextDescriptions`` can vary by a sibling field's
    value (e.g. ``valueExt`` whose meaning depends on ``property``).
    """
    nav = SchemaNavigator(schema)
    raw = nav.walk_to_leaf(dotted_path, schema, yaml_data=yaml_data)
    return EMPTY if raw is None else nav.build_node(raw, sibling_context=sibling_context)


def resolve_raw_at_path(
    dotted_path: str, schema: SchemaNode, *, yaml_data: Mapping[str, object] | None = None
) -> SchemaNode | None:
    """Walk a dotted path and return the raw schema node at that position.

    Preserves extension keywords (e.g. ``x-turbine-ref``) on the leaf because
    it skips the ``ResolvedNode`` projection. Returns ``None`` when the path
    doesn't resolve.
    """
    return SchemaNavigator(schema).walk_to_leaf(dotted_path, schema, yaml_data=yaml_data)


_ALTERNATION_RE = re.compile(r"^\^\(([a-zA-Z0-9_]+(?:\|[a-zA-Z0-9_]+)*)\)\$$")
_LITERAL_RE = re.compile(r"^\^([a-zA-Z0-9_]+)\$$")


def expand_pattern_names(pattern: str) -> list[str]:
    """Extract concrete key names from a ``patternProperties`` regex.

    Handles two forms used in Turbine schemas:
    - ``^name$`` (single literal) → ``["name"]``
    - ``^(a|b|c)$`` (alternation group) → ``["a", "b", "c"]``

    Returns an empty list for patterns that don't match either form.
    """
    if match := _LITERAL_RE.match(pattern):
        return [match.group(1)]
    if match := _ALTERNATION_RE.match(pattern):
        return match.group(1).split("|")
    return []


def merge_schema_props(
    base: dict[str, SchemaNode], overlay: dict[str, SchemaNode]
) -> dict[str, SchemaNode]:
    """Merge two property dicts: nested dicts are shallow-merged, other values are overwritten."""
    merged = dict(base)
    for key, val in overlay.items():
        if key in merged and isinstance(merged[key], dict) and isinstance(val, dict):
            merged[key] = {**merged[key], **val}
            continue
        merged[key] = val
    return merged


def matches_properties(properties: dict[str, SchemaNode], yaml_cursor: dict[str, Any]) -> bool:
    """Return True if the YAML cursor satisfies every property-level constraint.

    Covers the four discriminator shapes used in the ODCS and turbine extension
    schemas: ``const`` (exact match), ``enum`` (one of a list), ``not: {const}``
    (anything but), and ``not: {enum}`` (anything outside a list). A property
    without a value in the YAML cursor is treated as unknown and fails every
    positive constraint — the fallback branches keyed on ``check: not in [...]``
    rely on that so they only fire when ``check:`` is actually present.
    """
    return all(
        property_condition_matches(yaml_cursor.get(prop_name), prop_condition)
        for prop_name, prop_condition in properties.items()
        if isinstance(prop_condition, dict)
    )


def property_condition_matches(value: Any, prop_condition: SchemaNode) -> bool:
    """Return whether one YAML value satisfies one schema property condition."""
    if SchemaKey.CONST in prop_condition and value != prop_condition[SchemaKey.CONST]:
        return False
    if SchemaKey.ENUM in prop_condition and value not in prop_condition[SchemaKey.ENUM]:
        return False
    negation = prop_condition.get(SchemaKey.NOT)
    return not isinstance(negation, dict) or negated_condition_matches(value, negation)


def negated_condition_matches(value: Any, negation: SchemaNode) -> bool:
    """Return whether one YAML value passes a ``not`` condition."""
    if value is None:
        return False
    if SchemaKey.CONST in negation and value == negation[SchemaKey.CONST]:
        return False
    return not (SchemaKey.ENUM in negation and value in negation[SchemaKey.ENUM])


def evaluate_condition(condition: SchemaNode, yaml_cursor: Any) -> bool:
    """Evaluate a JSON Schema if-condition (properties, anyOf, allOf) against YAML data."""
    if yaml_cursor is None or not isinstance(yaml_cursor, dict):
        return False
    if SchemaKey.PROPERTIES in condition:
        return matches_properties(condition[SchemaKey.PROPERTIES], yaml_cursor)
    if SchemaKey.ANY_OF in condition:
        return any(evaluate_condition(sub, yaml_cursor) for sub in condition[SchemaKey.ANY_OF])
    if SchemaKey.ALL_OF in condition:
        return all(evaluate_condition(sub, yaml_cursor) for sub in condition[SchemaKey.ALL_OF])
    return False


def navigate_yaml(yaml_cursor: Any, key: str | int) -> Any:
    """Step one level into YAML data by dict key or list index, or None on mismatch."""
    match yaml_cursor, key:
        case list() as lst, int(idx) if idx < len(lst):
            return lst[idx]
        case dict() as d, str(k):
            return d.get(k)
        case _:
            return None
