"""Pure string-manipulation helpers for shortening verbose driver errors.

Lives in core/common so LSP feature handlers can surface short error text
without having to pull in the sqlalchemy-heavy adapters.databases subtree.
"""

NOISY_DELIMITERS = ("\n", "Multiple connection attempts", "(Background", "[SQL:")


def summarize_exception(exc: BaseException) -> str:
    """Return a one-line summary of a verbose SQLAlchemy/psycopg error.

    Unwraps any ``BaseExceptionGroup`` to the first underlying leaf so the
    caller sees the real cause instead of ``"event handler errors (1
    sub-exception)"``. Strips SQLAlchemy's class-name prefix, psycopg's
    multi-host retry detail, and the documentation-link footer that turn a
    short connection error into a 600-character wall of text. The result is
    safe to show in a VS Code notification toast.
    """
    leaf = unwrap_to_leaf(exc)
    message = str(leaf).strip()
    if not message:
        return type(leaf).__name__
    for delimiter in NOISY_DELIMITERS:
        if delimiter in message:
            message = message.split(delimiter, 1)[0].strip()
    if message.startswith("(") and ") " in message:
        message = message.split(") ", 1)[1]
    return message[:200] or type(leaf).__name__


def unwrap_to_leaf(exc: BaseException) -> BaseException:
    """Return the first non-group exception inside *exc* (recursive).

    ``BaseExceptionGroup`` is informative for telemetry but useless in user
    output — ``str(group)`` reads ``"... (1 sub-exception)"`` regardless of
    what actually broke. This helper walks the first branch of nested groups
    until it finds a real exception.
    """
    current: BaseException = exc
    while isinstance(current, BaseExceptionGroup) and current.exceptions:
        current = current.exceptions[0]
    return current
