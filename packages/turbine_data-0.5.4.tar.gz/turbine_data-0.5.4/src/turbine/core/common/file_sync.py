"""Generic file-write outcome types.

``SyncStatus`` and ``SyncResult`` describe what happened to a single
file on disk after a write. They are not specific to code generation
— any adapter that materialises content to disk and wants to report
create/update/unchanged/skipped outcomes depends on these.
"""

from dataclasses import dataclass
from enum import StrEnum
from pathlib import Path


class SyncStatus(StrEnum):
    """Outcome of writing a file."""

    CREATED = "created"
    UPDATED = "updated"
    UNCHANGED = "unchanged"
    SKIPPED = "skipped"


@dataclass(frozen=True, slots=True)
class SyncResult:
    """Outcome of writing a single file."""

    path: Path
    status: SyncStatus
