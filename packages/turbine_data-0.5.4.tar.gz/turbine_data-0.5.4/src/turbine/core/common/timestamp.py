"""Pure timestamp parsing for CLI ``--since`` and ``--until`` flags.

Accepts either a compact duration (``1d``, ``2h30m``, ``1w``) or an ISO 8601
timestamp. Duration strings are subtracted from the injected ``now`` to
produce an absolute ``datetime``; ISO strings are returned verbatim. A single
unified error message covers both failure modes.
"""

from __future__ import annotations

from datetime import datetime

from turbine.core.building_blocks.diagnostics import TurbineError
from turbine.core.common.duration import ACCEPTED_SHAPES, Duration


def parse_since_or_until(raw: str, now: datetime) -> datetime:
    """Resolve a ``--since`` / ``--until`` argument to an absolute datetime.

    Tries duration parsing first (``1d`` -> ``now - timedelta(days=1)``), then
    falls back to ``datetime.fromisoformat``. Raises ``TurbineError`` with a
    single unified message when neither shape matches.
    """
    duration = try_parse_duration(raw)
    if duration is not None:
        return now - duration.to_timedelta()

    iso = try_parse_iso(raw)
    if iso is not None:
        return iso

    raise TurbineError(
        f"could not parse {raw!r}; expected a duration ({ACCEPTED_SHAPES}) "
        "or ISO 8601 timestamp like 2026-04-14T00:00:00"
    )


def try_parse_duration(raw: str) -> Duration | None:
    """Return a ``Duration`` or ``None`` if *raw* is not a valid duration."""
    try:
        return Duration.parse(raw)
    except TurbineError:
        return None


def try_parse_iso(raw: str) -> datetime | None:
    """Return a ``datetime`` or ``None`` if *raw* is not a valid ISO 8601 string."""
    try:
        return datetime.fromisoformat(raw)
    except ValueError:
        return None
