"""Threshold types for quality check pass/fail decisions."""

from dataclasses import dataclass
from typing import Literal, Self

from pydantic import BaseModel, ConfigDict, model_validator
from pydantic.alias_generators import to_camel


class BetweenRange(BaseModel):
    """Bounds for a between/not-between threshold operator.

    Doubles as the YAML deserializer for the QualitySpec ``mustBeBetween`` /
    ``mustBeNotBetween`` fields — the camelCase alias generator covers both
    Python (``greater_than``) and YAML (``greaterThan``) naming.
    """

    model_config = ConfigDict(
        frozen=True, alias_generator=to_camel, populate_by_name=True, extra="forbid"
    )

    greater_than: int | float | None = None
    greater_than_or_equal: int | float | None = None
    less_than: int | float | None = None
    less_than_or_equal: int | float | None = None

    @model_validator(mode="after")
    def at_least_one_bound(self) -> Self:
        if not any(
            value is not None
            for value in (
                self.greater_than,
                self.greater_than_or_equal,
                self.less_than,
                self.less_than_or_equal,
            )
        ):
            raise ValueError("BetweenRange requires at least one bound")
        return self


@dataclass(frozen=True, slots=True)
class ExactThreshold:
    """Exact match threshold: must_be / must_not_be."""

    value: int | float
    negate: bool = False


@dataclass(frozen=True, slots=True)
class ComparisonThreshold:
    """Comparison threshold: gt, gte, lt, lte."""

    operator: Literal["gt", "gte", "lt", "lte"]
    value: int | float


@dataclass(frozen=True, slots=True)
class RangeThreshold:
    """Range threshold: between / not_between."""

    bounds: BetweenRange
    negate: bool = False


type Threshold = ExactThreshold | ComparisonThreshold | RangeThreshold


def in_range(metric: float, bounds: BetweenRange) -> bool:
    """Return True when *metric* falls inside *bounds*."""
    if bounds.greater_than is not None and metric <= bounds.greater_than:
        return False
    if bounds.greater_than_or_equal is not None and metric < bounds.greater_than_or_equal:
        return False
    if bounds.less_than is not None and metric >= bounds.less_than:
        return False
    return not (bounds.less_than_or_equal is not None and metric > bounds.less_than_or_equal)


def evaluate_exact(metric: float, threshold: ExactThreshold) -> bool:
    """Return True when *metric* equals the exact threshold (or differs, if negated)."""
    return metric != threshold.value if threshold.negate else metric == threshold.value


def evaluate_comparison(metric: float, threshold: ComparisonThreshold) -> bool:
    """Return True when *metric* satisfies the comparison operator."""
    match threshold.operator:
        case "gt":
            return metric > threshold.value
        case "gte":
            return metric >= threshold.value
        case "lt":
            return metric < threshold.value
        case "lte":
            return metric <= threshold.value


def threshold_scalar(threshold: Threshold | None) -> float | None:
    """Return *threshold*'s comparison value as a float, or ``None`` for range/unset.

    Centralises the ``threshold.value`` extraction every adapter repeats:
    ``ComparisonThreshold`` and ``ExactThreshold`` both expose a single
    numeric value, ``RangeThreshold`` doesn't (callers needing the bounds
    walk the ``BetweenRange`` directly), and ``None`` propagates as ``None``.
    """
    if isinstance(threshold, (ComparisonThreshold, ExactThreshold)):
        return float(threshold.value)
    return None


def passes_threshold(metric: float, threshold: Threshold) -> bool:
    """Return True when *metric* satisfies *threshold* (check passes)."""
    match threshold:
        case ExactThreshold():
            return evaluate_exact(metric, threshold)
        case ComparisonThreshold():
            return evaluate_comparison(metric, threshold)
        case RangeThreshold(bounds=bounds, negate=negate):
            result = in_range(metric, bounds)
            return not result if negate else result


def format_threshold(threshold: Threshold) -> str:
    """Render *threshold* as a short human-readable string (e.g. ``gte 95``)."""
    match threshold:
        case ComparisonThreshold(operator=operator, value=value):
            return f"{operator} {value}"
        case ExactThreshold(value=value, negate=negate):
            symbol = "!=" if negate else "="
            return f"{symbol} {value}"
        case RangeThreshold(bounds=bounds, negate=negate):
            rendered = format_range_bounds(bounds)
            return f"not {rendered}" if negate else rendered


def format_range_bounds(bounds: BetweenRange) -> str:
    """Render the bounds of a between range as a math-style interval."""
    if bounds.greater_than is not None:
        lower_bracket, lower = "(", bounds.greater_than
    elif bounds.greater_than_or_equal is not None:
        lower_bracket, lower = "[", bounds.greater_than_or_equal
    else:
        lower_bracket, lower = "(", "-inf"

    if bounds.less_than is not None:
        upper, upper_bracket = bounds.less_than, ")"
    elif bounds.less_than_or_equal is not None:
        upper, upper_bracket = bounds.less_than_or_equal, "]"
    else:
        upper, upper_bracket = "inf", ")"

    return f"{lower_bracket}{lower}, {upper}{upper_bracket}"
