"""Contract intermediate representation.

All contract formats (ODCS, quality spec, DBT, etc.) translate into
DatasetSpec. Downstream consumers — check execution, scoring, schema
validation, codegen — read from it. The IR is immutable: once built,
it represents a point-in-time snapshot of a contract.
"""

from .checks import (
    ALL_KNOWN_TYPES,
    CATEGORY_MAP,
    KNOWN_METRIC_TYPES,
    CheckCategory,
    CheckConfig,
    CheckDef,
    CheckScope,
    CheckSource,
    CompareMode,
    MetricCheckConfig,
    MetricName,
    MetricParams,
    PythonCheckConfig,
    SchemaCheckConfig,
    SqlCheckConfig,
    StructuralCheckType,
    WindowCheckConfig,
)
from .spec import (
    ColumnDef,
    ContractMetadata,
    ContractStatus,
    CustomProperty,
    DatasetSpec,
    LifecycleMetadata,
    Percent,
    SlaConfig,
    SlaProperty,
)
from .thresholds import BetweenRange, ComparisonThreshold, ExactThreshold, RangeThreshold, Threshold

__all__ = [
    "ALL_KNOWN_TYPES",
    "CATEGORY_MAP",
    "KNOWN_METRIC_TYPES",
    "BetweenRange",
    "CheckCategory",
    "CheckConfig",
    "CheckDef",
    "CheckScope",
    "CheckSource",
    "ColumnDef",
    "CompareMode",
    "ComparisonThreshold",
    "ContractMetadata",
    "ContractStatus",
    "CustomProperty",
    "DatasetSpec",
    "ExactThreshold",
    "LifecycleMetadata",
    "MetricCheckConfig",
    "MetricName",
    "MetricParams",
    "Percent",
    "PythonCheckConfig",
    "RangeThreshold",
    "SchemaCheckConfig",
    "SlaConfig",
    "SlaProperty",
    "SqlCheckConfig",
    "StructuralCheckType",
    "Threshold",
    "WindowCheckConfig",
]
