"""``ColumnDef``: a single column's schema entry in a contract."""

from __future__ import annotations

from dataclasses import dataclass

from turbine.core.building_blocks import TextRange

from ..logical_type import LogicalType


@dataclass(frozen=True, slots=True)
class ColumnDef:
    """Defines a single column in a contract's table schema."""

    name: str
    logical_type: LogicalType
    nullable: bool
    primary_key: bool
    position: int
    description: str | None = None
    tags: tuple[str, ...] = ()
    source_range: TextRange | None = None
    example: str | None = None
    required: bool | None = None
    required_source_range: TextRange | None = None
    primary_key_source_range: TextRange | None = None
