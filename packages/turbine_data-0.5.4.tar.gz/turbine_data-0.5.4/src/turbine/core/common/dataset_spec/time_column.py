"""Resolve a check's effective time column from YAML + contract SLA.

Precedence:

1. ``check.order_by[0]`` — explicit YAML override, wins outright.
2. ``dataset.time_column`` — the SLA-declared time dimension.
3. ``None`` — the lint stage surfaces this as an error for time-based
   windows; row-based windows accept no resolvable column.
"""

from __future__ import annotations

from .checks import CheckDef, WindowCheckConfig
from .spec import DatasetSpec


def resolve_time_column(check: CheckDef, spec: DatasetSpec) -> str | None:
    """Return the effective time column for *check* on *spec*, or ``None``."""
    if isinstance(check.config, WindowCheckConfig) and check.config.order_by:
        return check.config.order_by[0]
    return spec.time_column
