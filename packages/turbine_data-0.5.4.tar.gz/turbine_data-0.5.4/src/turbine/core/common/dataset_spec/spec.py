"""Contract spec types: metadata, columns, and the DatasetSpec aggregate."""

from dataclasses import dataclass, field
from datetime import datetime
from enum import StrEnum
from pathlib import Path
from typing import Self

from turbine.core.building_blocks import TextRange

from ..identifiers import TableIdentifier
from ..parsing import parse_strenum
from .checks import CheckDef
from .columns import ColumnDef


class ContractStatus(StrEnum):
    """Lifecycle status of a data contract per the ODCS specification."""

    PROPOSED = "proposed"
    DRAFT = "draft"
    ACTIVE = "active"
    DEPRECATED = "deprecated"
    RETIRED = "retired"

    @classmethod
    def parse(cls, raw: str) -> Self:
        """Parse a status string case-insensitively.

        Raises TurbineError with fuzzy suggestions when the input
        does not match any known status.
        """
        return parse_strenum(cls, raw)


@dataclass(frozen=True, slots=True)
class SlaProperty:
    """A single SLA property from the ODCS slaProperties section.

    ``value_ext`` carries ODCS ``valueExt`` for the "second value" pattern
    (retention upper bound + frequency tolerance window).  ``schedule`` is a
    cron expression for cron-mode frequency; ``scheduler`` is the open
    scheduler tag (``cron`` / ``airflow`` / ...).  ``tz`` is a turbine
    extension carrying an IANA timezone for cron + timeOfAvailability.
    ``driver`` tags timeOfAvailability with its motivating reason
    (``regulatory`` / ``analytics`` / ...).
    """

    property: str
    value: float | None = None
    value_ext: float | None = None
    unit: str | None = None
    element: str | None = None
    schedule: str | None = None
    scheduler: str | None = None
    tz: str | None = None
    driver: str | None = None
    source_range: TextRange | None = None

    @property  # noqa: A003
    def column_name(self) -> str | None:
        """Extract the bare column name from the dotted element path.

        E.g. ``public.orders.updated_at`` becomes ``updated_at``.
        """
        if self.element is None:
            return None
        return self.element.rsplit(".", maxsplit=1)[-1]


@dataclass(frozen=True, slots=True)
class Percent:
    """A percentage stored as a 0.0-1.0 fraction.

    ``99.9%`` and bare ``99.9`` both normalize to ``Percent(0.999)``; bare
    ``0.999`` is kept as-is.  The reader handles the input normalization;
    consumers see only the fraction form.
    """

    value: float


@dataclass(frozen=True, slots=True)
class LifecycleMetadata:
    """Lifecycle metadata parsed from ``availability`` + the three date properties.

    Metadata-only — no CheckDefs are derived from these.  ``availability`` is
    a documented uptime target (turbine doesn't probe for it).  The three
    date fields drive LSP state diagnostics (pre-live, post-end-of-support,
    near/past end-of-life) but never gate check execution.  Source ranges
    point at each property's YAML entry so diagnostics underline the right
    line.
    """

    availability: Percent | None = None
    general_availability: datetime | None = None
    end_of_support: datetime | None = None
    end_of_life: datetime | None = None
    availability_source_range: TextRange | None = None
    general_availability_source_range: TextRange | None = None
    end_of_support_source_range: TextRange | None = None
    end_of_life_source_range: TextRange | None = None


@dataclass(frozen=True, slots=True)
class SlaConfig:
    """Carries SLA metadata and properties for a contract."""

    owner: str | None = None
    properties: tuple[SlaProperty, ...] = ()
    lifecycle: LifecycleMetadata = field(default_factory=LifecycleMetadata)


@dataclass(frozen=True, slots=True)
class CustomProperty:
    """A single ``customProperties`` entry from an ODCS contract."""

    property: str
    value: str


@dataclass(frozen=True, slots=True)
class ContractMetadata:
    """Tracks provenance, version, and lifecycle status for a contract."""

    contract_id: str
    version: str
    source_format: str
    source_path: Path
    status: ContractStatus = ContractStatus.DRAFT
    owner: str | None = None
    name: str | None = None
    is_contract: bool = False
    domain: str | None = None
    custom_properties: tuple[CustomProperty, ...] = ()
    description_purpose: str | None = None
    description_usage: str | None = None
    description_source_range: TextRange | None = None
    description_purpose_source_range: TextRange | None = None
    contract_id_source_range: TextRange | None = None
    domain_source_range: TextRange | None = None
    version_source_range: TextRange | None = None

    @property
    def major_version(self) -> int:
        """Parse the leading numeric component from ``version`` (e.g. ``2`` from ``2.1.0``)."""
        return int(self.version.split(".", maxsplit=1)[0])

    def custom_property(self, key: str) -> str | None:
        """Return the first ``customProperties`` entry whose property is *key*, or None."""
        return next((prop.value for prop in self.custom_properties if prop.property == key), None)


@dataclass(frozen=True, slots=True)
class DatasetSpec:
    """Normalizes any contract format into a single structure.

    All contract formats translate into this structure. Downstream
    consumers read from it without knowing the original format.
    """

    table: TableIdentifier
    columns: tuple[ColumnDef, ...]
    checks: tuple[CheckDef, ...]
    sla: SlaConfig | None
    metadata: ContractMetadata
    target_contract: str | None = None
    target_contract_source_range: TextRange | None = None
    dataset_source_range: TextRange | None = None
    schema_index: int = 0
    schema_name_source_range: TextRange | None = None
    odcs_schema_name: str | None = None

    @property
    def pk_columns(self) -> tuple[str, ...]:
        """Collect primary key column names from the column definitions."""
        return tuple(col.name for col in self.columns if col.primary_key)

    @property
    def pk_column_defs(self) -> tuple[ColumnDef, ...]:
        """Return column definitions marked as primary keys."""
        return tuple(col for col in self.columns if col.primary_key)

    @property
    def filterable_column_defs(self) -> tuple[ColumnDef, ...]:
        """Return column definitions tagged as filterable."""
        return tuple(col for col in self.columns if "filterable" in col.tags)

    @property
    def time_column(self) -> str | None:
        """Return the bare time column from the first qualifying SLA property, or None.

        ADR 0001 defines a dataset's time column as any SLA property with an
        ``element`` that points at one of this schema's columns. The SLA
        ``property`` value is informational; ``latency`` is not special.
        """
        if self.sla is None:
            return None
        for prop in self.sla.properties:
            column_name = resolve_sla_property_time_column(prop, self)
            if column_name is not None:
                return column_name
        return None

    @property
    def latency_column(self) -> str | None:
        """Compatibility alias for the dataset's SLA-declared time column."""
        return self.time_column


def resolve_sla_property_time_column(prop: SlaProperty, spec: DatasetSpec) -> str | None:
    """Return the SLA element's column when it resolves to *spec*, otherwise None."""
    column_name = prop.column_name
    if prop.element is None or column_name is None:
        return None
    if not sla_element_matches_table(prop.element, spec.table):
        return None
    column_names = {column.name for column in spec.columns}
    if column_names and column_name not in column_names:
        return None
    return column_name


UNQUALIFIED_ELEMENT_PART_COUNT = 1
TABLE_ELEMENT_PART_COUNT = 2
QUALIFIED_ELEMENT_PART_COUNT = 3


def sla_element_matches_table(element: str, table: TableIdentifier) -> bool:
    """Return True when an SLA element's qualifiers match *table*."""
    parts = element.split(".")
    if len(parts) == UNQUALIFIED_ELEMENT_PART_COUNT:
        return True
    if len(parts) == TABLE_ELEMENT_PART_COUNT:
        return parts[0] == table.table
    if len(parts) == QUALIFIED_ELEMENT_PART_COUNT:
        schema_matches = table.schema == "" or parts[0] == table.schema
        return schema_matches and parts[1] == table.table
    return False
