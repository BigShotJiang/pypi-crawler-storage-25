"""Check definitions, categories, and config types."""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from difflib import get_close_matches
from enum import StrEnum
from pathlib import Path
from typing import Any, Literal, Self

from pydantic import AliasChoices, BaseModel, ConfigDict, field_validator
from pydantic import Field as PydField

from turbine.core.building_blocks import TextRange, TurbineError
from turbine.core.shared import FilterExpr

from ..duration import Duration
from ..quality_dimension import QualityDimension
from .columns import ColumnDef
from .thresholds import Threshold


class CheckCategory(StrEnum):
    """Routes a quality check to the right execution strategy."""

    METRIC = "metric"
    SQL = "sql"
    TEMPLATE = "template"
    PYTHON = "python"

    @classmethod
    def from_type_string(cls, check_type: str) -> CheckCategory:
        """Map a check type name to its execution category.

        Raises TurbineError with fuzzy suggestions on unknown type.
        """
        if check_type in CATEGORY_MAP:
            return CATEGORY_MAP[check_type]
        if check_type in KNOWN_METRIC_TYPES or is_quantile_metric(check_type):
            return cls.METRIC
        msg = f"Unknown check type '{check_type}'."
        if suggestions := get_close_matches(check_type, ALL_KNOWN_TYPES, n=2, cutoff=0.6):
            msg += f" Did you mean: {', '.join(suggestions)}?"
        else:
            msg += f" Valid types: {', '.join(sorted(ALL_KNOWN_TYPES))}"
        raise TurbineError(msg)


class StructuralCheckType(StrEnum):
    """Check types that carry dedicated config models; everything else is a metric."""

    SQL = "sql"
    PYTHON = "python"
    ZSCORE = "zscore"
    SPIKE = "spike"
    FLATLINE = "flatline"
    PCT_CHANGE = "pct_change"
    RANGE = "range"


CATEGORY_MAP: dict[str, CheckCategory] = {
    StructuralCheckType.SQL: CheckCategory.SQL,
    StructuralCheckType.PYTHON: CheckCategory.PYTHON,
    StructuralCheckType.ZSCORE: CheckCategory.TEMPLATE,
    StructuralCheckType.SPIKE: CheckCategory.TEMPLATE,
    StructuralCheckType.FLATLINE: CheckCategory.TEMPLATE,
    StructuralCheckType.PCT_CHANGE: CheckCategory.TEMPLATE,
    StructuralCheckType.RANGE: CheckCategory.TEMPLATE,
}


class MetricName(StrEnum):
    """Well-known metric check types used in contract derivation and query building."""

    AVG = "avg"
    AVG_LENGTH = "avg_length"
    DISTINCT_COUNT = "distinct_count"
    DUPLICATE = "duplicate"
    FREQUENCY = "frequency"
    FRESHNESS = "freshness"
    INVALID = "invalid"
    LATENCY = "latency"
    MAX = "max"
    MIN = "min"
    MISSING = "missing"
    NULL_COUNT = "null_count"
    RETENTION = "retention"
    RETENTION_MAX = "retention_max"
    ROW_COUNT = "row_count"
    SCHEMA = "schema"
    STDDEV = "stddev"
    SUM = "sum"
    TIME_OF_AVAILABILITY = "time_of_availability"


KNOWN_METRIC_TYPES: frozenset[str] = frozenset(MetricName)
QUANTILE_METRIC_PATTERN = re.compile(r"^quantile_[0-9]+(?:_[0-9]+)?$")
QUANTILE_METRIC_LABEL = "quantile_<n>"


def is_quantile_metric(check_type: str) -> bool:
    """Return True for quantile metric names such as ``quantile_95`` or ``quantile_99_9``."""
    return QUANTILE_METRIC_PATTERN.fullmatch(check_type) is not None


ALL_KNOWN_TYPES: frozenset[str] = frozenset(CATEGORY_MAP) | KNOWN_METRIC_TYPES | {QUANTILE_METRIC_LABEL}


type CompareMode = Literal["count", "percent"]
"""Failure Allowance discriminator: count (default) or percent (0-100 scale)."""


class CheckScope(StrEnum):
    """Distinguishes column-level checks from dataset-level checks."""

    COLUMN = "column"
    DATASET = "dataset"


class ExecutionRoute(StrEnum):
    """Who runs the check.

    Two routes today: ``BATCHED`` (the SQL executor — covers metric, custom-SQL,
    Python, and anomaly checks via per-shape requesters) and ``SCHEMA``
    (the structural shape-assertion runner). Orthogonal to :class:`MetricType`
    (what the check measures).
    """

    BATCHED = "batched"
    SCHEMA = "schema"


class MetricType(StrEnum):
    """What a check measures.

    Orthogonal to :class:`ExecutionRoute`. Drives predicate selection and
    lint rules that need to reason about check shape rather than the
    executor that happens to run it.
    """

    AGGREGATE = "aggregate"
    WINDOWED_ROW_FILTER = "windowed_row_filter"
    SCHEMA = "schema"
    CUSTOM_SQL = "custom_sql"
    PYTHON = "python"


WINDOWED_ROW_FILTER_TYPES: frozenset[str] = frozenset(
    {
        StructuralCheckType.ZSCORE,
        StructuralCheckType.SPIKE,
        StructuralCheckType.FLATLINE,
        StructuralCheckType.PCT_CHANGE,
        StructuralCheckType.RANGE,
    }
)

STRUCTURAL_CHECK_TYPES: frozenset[str] = frozenset({MetricName.SCHEMA})


def is_row_based_check_type(check_type: str) -> bool:
    """Return True when *check_type* measures rows (so row counts are meaningful).

    Structural checks (``schema``) compare contract metadata to the live
    database — their findings count drift items, not rows, so display
    sites must omit any ``(N rows)`` suffix.
    """
    return check_type not in STRUCTURAL_CHECK_TYPES


CATEGORY_METRIC_TYPES: dict[CheckCategory, MetricType] = {
    CheckCategory.SQL: MetricType.CUSTOM_SQL,
    CheckCategory.PYTHON: MetricType.PYTHON,
}

CHECK_TYPE_METRIC_TYPES: dict[str, MetricType] = {MetricName.SCHEMA: MetricType.SCHEMA}


def classify_metric_type(check: CheckDef) -> MetricType:
    """Classify *check* by what it measures."""
    if category_match := CATEGORY_METRIC_TYPES.get(check.category):
        return category_match
    if type_match := CHECK_TYPE_METRIC_TYPES.get(check.check_type):
        return type_match
    if check.check_type in WINDOWED_ROW_FILTER_TYPES:
        return MetricType.WINDOWED_ROW_FILTER
    return MetricType.AGGREGATE


def classify_execution_route(check: CheckDef) -> ExecutionRoute:
    """Classify *check* by which executor runs it.

    Schema checks go to the structural runner. Everything else — metric,
    custom-SQL, Python, and windowed anomaly templates — runs through the
    batched executor (each gets its own requester shape).
    """
    if check.check_type == MetricName.SCHEMA:
        return ExecutionRoute.SCHEMA
    return ExecutionRoute.BATCHED


class MetricParams(BaseModel):
    """Carries validity parameters for metric checks.

    Accepts both Python field names (valid_min) and ODCS YAML names
    (minimum) so logicalTypeOptions parse directly.
    """

    model_config = ConfigDict(populate_by_name=True, frozen=True, extra="forbid")

    missing_values: tuple[str | int | float, ...] | None = PydField(
        default=None, validation_alias=AliasChoices("missing_values", "missingValues")
    )
    valid_values: tuple[str | int | float, ...] | None = PydField(
        default=None, validation_alias=AliasChoices("valid_values", "validValues", "enum")
    )
    valid_regex: str | None = PydField(
        default=None, validation_alias=AliasChoices("valid_regex", "validRegex", "pattern")
    )
    valid_format: str | None = PydField(
        default=None, validation_alias=AliasChoices("valid_format", "validFormat", "format")
    )
    valid_min: int | float | None = PydField(
        default=None, validation_alias=AliasChoices("valid_min", "validMin", "minimum")
    )
    valid_max: int | float | None = PydField(
        default=None, validation_alias=AliasChoices("valid_max", "validMax", "maximum")
    )
    valid_length: int | None = PydField(
        default=None, validation_alias=AliasChoices("valid_length", "validLength")
    )
    valid_min_length: int | None = PydField(
        default=None, validation_alias=AliasChoices("valid_min_length", "validMinLength", "minLength")
    )
    valid_max_length: int | None = PydField(
        default=None, validation_alias=AliasChoices("valid_max_length", "validMaxLength", "maxLength")
    )
    invalid_values: tuple[str | int | float, ...] | None = PydField(
        default=None, validation_alias=AliasChoices("invalid_values", "invalidValues")
    )
    invalid_regex: str | None = PydField(
        default=None, validation_alias=AliasChoices("invalid_regex", "invalidRegex")
    )
    columns: tuple[str, ...] | None = PydField(
        default=None, validation_alias=AliasChoices("columns", "properties")
    )
    valid_reference_data: dict[str, str] | None = PydField(
        default=None, validation_alias=AliasChoices("valid_reference_data", "validReferenceData")
    )

    @field_validator("valid_values", "missing_values", "invalid_values", mode="before")
    @classmethod
    def empty_sequence_to_none(cls, value: object) -> object:
        """Coerce empty lists/tuples and non-sequence inputs to ``None``."""
        if isinstance(value, (list, tuple)) and not value:
            return None
        if not isinstance(value, (list, tuple)):
            return None
        return value

    @classmethod
    def from_schema_property(cls, options: dict[str, Any]) -> Self | None:
        """Build from ODCS logicalTypeOptions via alias resolution. None if empty."""
        params = cls.model_validate(options)
        return params if params.model_dump(exclude_none=True) else None


@dataclass(frozen=True, slots=True)
class MetricCheckConfig:
    """Configures a metric check (column, freshness, row_count, etc.)."""

    metric: str
    column: str | None = None
    params: MetricParams | None = None


@dataclass(frozen=True, slots=True)
class SchemaCheckConfig:
    """Marker for a schema validation check derived from column definitions."""


@dataclass(frozen=True, slots=True)
class SqlCheckConfig:
    """Configures a custom SQL check from a file, inline query, or wrapped predicate.

    ``predicate`` and ``query`` are mutually exclusive (enforced at the
    pydantic body layer). When ``predicate`` is set, the runner wraps it
    via ``wrap_predicate_query`` against the dataset's filtered scope so
    ``compare: percent`` has a well-defined denominator. When ``query`` is
    set, the runner ships it verbatim. Falling back to ``file_path`` is
    the legacy load-from-file shape and is treated as the full-query
    branch.
    """

    file_path: Path
    params: dict[str, str]
    query: str | None = None
    predicate: str | None = None
    file_source_range: TextRange | None = None


@dataclass(frozen=True, slots=True)
class PythonCheckConfig:
    """Configures a Python function check with optional extra tables and queries."""

    function_ref: str
    params: dict[str, Any]
    extra_tables: dict[str, str] = field(default_factory=dict)
    queries: dict[str, str] = field(default_factory=dict)
    function_source_range: TextRange | None = None


@dataclass(frozen=True, slots=True)
class WindowCheckConfig:
    """Configures a window function check with partition, ordering, and expression.

    ``sensitivity`` is the anomaly-detection knob rendered into the SQL
    template (z-score multiplier, spike delta, pct-change fraction, rolling
    band width).  It is distinct from ``CheckDef.threshold`` which governs
    the row-count verdict applied to the returned rows.
    """

    partition_by: tuple[str, ...]
    expression: str
    order_by: tuple[str, ...] = ()
    window: Duration | None = None
    size: int | None = None
    sensitivity: float | None = None


type CheckConfig = (
    MetricCheckConfig | SchemaCheckConfig | SqlCheckConfig | PythonCheckConfig | WindowCheckConfig
)


@dataclass(frozen=True, slots=True)
class CheckSource:
    """Records where a check definition originated (format, path, contract vs. quality spec)."""

    format_label: str
    path: Path
    is_contract: bool = False


@dataclass(frozen=True, slots=True)
class CheckDef:
    """Represents a single quality check from a contract or quality spec.

    ``dimension`` is ``None`` when the source file omits it. Consumers that
    render or group by dimension must guard against ``None``; the
    ``CheckDimensionRequiredRule`` lint rule surfaces the missing field.

    ``filter`` arrives as a raw string at parse time; the ODCS reader's
    ``read_resolved`` step parses it into a :class:`FilterExpr` once so
    downstream code never re-parses. ``execution_route``, ``metric_type``,
    and ``column_meta`` are populated by the reader too and carry
    classification + target-column data the planner and bypasses would
    otherwise recompute.
    """

    name: str
    check_type: str
    dimension: QualityDimension | None
    category: CheckCategory
    config: CheckConfig
    source: CheckSource
    threshold: Threshold | None = None
    unit: str | None = None
    column: str | None = None
    window: Duration | None = None
    filter: FilterExpr | None = None
    execution_route: ExecutionRoute | None = None
    metric_type: MetricType | None = None
    column_meta: ColumnDef | None = None
    source_range: TextRange | None = None
    column_source_range: TextRange | None = None
    name_source_range: TextRange | None = None
    compare_mode: CompareMode = "count"

    @property
    def is_contract(self) -> bool:
        """True when the check originates from a DataContract (not a QualitySpec)."""
        return self.source.is_contract

    @classmethod
    def metric(
        cls,
        check_type: str,
        column: str | None,
        dimension: QualityDimension | None,
        source: CheckSource,
        *,
        params: MetricParams | None = None,
    ) -> Self:
        """Build a metric check from minimal fields."""
        name = f"{check_type}:{column}" if column else check_type
        return cls(
            name=name,
            check_type=check_type,
            dimension=dimension,
            category=CheckCategory.METRIC,
            config=MetricCheckConfig(metric=check_type, column=column, params=params),
            source=source,
            column=column,
        )

    @property
    def scope(self) -> CheckScope:
        """Derive scope from column: COLUMN if set, DATASET otherwise."""
        return CheckScope.COLUMN if self.column else CheckScope.DATASET

    def require_config[T](self, config_type: type[T]) -> T:
        """Narrow config to *config_type* or raise TurbineError."""
        if not isinstance(self.config, config_type):
            raise TurbineError(f"Expected {config_type.__name__}, got {type(self.config).__name__}")
        return self.config
