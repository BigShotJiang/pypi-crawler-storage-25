"""Supported datasource types for database backends.

Each member identifies a database engine that Turbine can connect to.
The BackendFactory uses DataSourceType as its registry key.
"""

from enum import StrEnum
from typing import Self

from .parsing import parse_strenum

ALIASES: dict[str, str] = {"postgresql": "postgres"}


SCAFFOLD_NAMES: dict[str, str] = {"duckdb": "local"}


class DataSourceType(StrEnum):
    """Supported database engines."""

    POSTGRES = "postgres"
    SNOWFLAKE = "snowflake"
    DUCKDB = "duckdb"

    @classmethod
    def parse(cls, raw: str) -> Self:
        """Parse a datasource type string case-insensitively.

        Handles known aliases (e.g. ``postgresql`` -> ``postgres``).
        Raises TurbineError with fuzzy suggestions when the input
        does not match any known type or alias.
        """
        return parse_strenum(cls, raw, aliases=ALIASES)

    @property
    def scaffold_name(self) -> str:
        """Sensible default datasource file name (e.g. DuckDB → 'local')."""
        return SCAFFOLD_NAMES.get(self.value, str(self))
