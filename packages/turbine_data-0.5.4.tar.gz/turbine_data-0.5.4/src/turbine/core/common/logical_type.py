"""Logical types for column definitions.

Maps database-native types (VARCHAR, BIGINT, TIMESTAMPTZ, etc.)
to semantic categories so downstream code never deals with
dialect-specific type strings.
"""

from enum import StrEnum
from typing import Self

from .parsing import parse_strenum


class LogicalType(StrEnum):
    """Groups database-native types (VARCHAR, BIGINT, etc.) into semantic categories."""

    STRING = "string"
    TEXT = "text"
    INTEGER = "integer"
    NUMBER = "number"
    BOOLEAN = "boolean"
    TIMESTAMP = "timestamp"
    DATE = "date"
    TIME = "time"
    DATETIME = "datetime"
    ARRAY = "array"
    OBJECT = "object"
    GEOMETRY = "geometry"

    @classmethod
    def is_time_like(cls, value: object) -> bool:
        """Return True when *value* matches a date/time-bearing logical type."""
        return value in TIME_LIKE_LOGICAL_TYPES

    @classmethod
    def parse(cls, raw: str) -> Self:
        """Parse a logical type string case-insensitively.

        Raises TurbineError with fuzzy suggestions when the input
        does not match any known logical type.
        """
        return parse_strenum(cls, raw)


TIME_LIKE_LOGICAL_TYPES: frozenset[LogicalType] = frozenset(
    {LogicalType.TIMESTAMP, LogicalType.DATETIME, LogicalType.DATE}
)
