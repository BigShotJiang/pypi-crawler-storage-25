"""RunPlan value object: enumerates DatasetSpec units a target will execute."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True, slots=True)
class SchemaCount:
    """One row in a run plan: a single DatasetSpec the run will execute."""

    contract_path: Path
    dataset: str
    check_count: int


@dataclass(frozen=True, slots=True)
class RunPlan:
    """Resolution-time enumeration of every DatasetSpec a target will run.

    Ordered identically to ``CheckUseCase.stream`` traversal: outer index is
    contract, inner index is schema-within-contract. Surfaces consume it to
    build determinate progress with the right nesting level.
    """

    units: tuple[SchemaCount, ...]

    @property
    def total_checks(self) -> int:
        return sum(unit.check_count for unit in self.units)

    @property
    def schema_count(self) -> int:
        return len(self.units)

    @property
    def contract_count(self) -> int:
        if len(self.units) <= 1:
            return len(self.units)
        return len({unit.contract_path for unit in self.units})

    @property
    def is_nested(self) -> bool:
        return self.schema_count > 1 or self.contract_count > 1

    def unit_by_dataset(self) -> dict[str, SchemaCount]:
        """Return a dataset-keyed lookup of plan units.

        Surfaces (CLI reporter, LSP nested progress) need to find a unit by
        its ``dataset`` label when a ``RunStarted`` event lands. Building
        the dict here keeps the lookup the plan's responsibility instead of
        making each surface rebuild the same map.
        """
        return {unit.dataset: unit for unit in self.units}
