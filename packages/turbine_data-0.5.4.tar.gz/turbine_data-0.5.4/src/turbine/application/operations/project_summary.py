"""Fold a ``RunSummary`` into a ``ProjectCheckResult`` for multi-contract rendering.

The CLI's ``turbine check --all`` and ``turbine check --ci`` drain the streamed
events into a :class:`~turbine.application.operations.collector.RunCollector`
and then pass the resulting :class:`RunSummary` here to get the display
shape that ``render_multi_contract_report`` expects.

Aggregate scoring excludes checks from aborted contracts so a missing summary never looks green.
"""

from __future__ import annotations

from turbine.application.operations.collector import ContractSummary, RunSummary
from turbine.application.operations.project_results import (
    ContractCheckResult,
    ContractError,
    ProjectCheckResult,
)
from turbine.core.quality.check_results import CheckResult, QualityScore


def project_result_from_summary(summary: RunSummary) -> ProjectCheckResult:
    """Build a ``ProjectCheckResult`` with per-contract and aggregate scores from *summary*."""
    contracts = tuple(contract_entry(contract) for contract in summary.contracts)
    aggregate_score = QualityScore.compute(tuple(aggregate_checks(summary)))
    return ProjectCheckResult(contracts=contracts, aggregate_score=aggregate_score)


def contract_entry(contract_summary: ContractSummary) -> ContractCheckResult:
    """Build one ``ContractCheckResult`` from a ``ContractSummary``."""
    path = contract_summary.contract.metadata.source_path
    if contract_summary.aborted_reason is not None:
        return ContractCheckResult(path=path, result=contract_error_from_summary(contract_summary))

    return ContractCheckResult(path=path, result=contract_summary)


def contract_error_from_summary(contract_summary: ContractSummary) -> ContractError:
    """Rebuild a ``ContractError`` from the aborted fields a collector captured.

    Falls back to the coarse ``aborted_reason`` bucket when no underlying
    error identity was recorded (shouldn't happen for real RunAborted
    events but keeps the type total for synthetic test summaries).
    """
    reason = contract_summary.aborted_reason or "aborted"
    return ContractError(
        message=contract_summary.aborted_error_message or reason,
        error_type=contract_summary.aborted_error_type or "RunAborted",
        diagnostics=contract_summary.diagnostics,
    )


def aggregate_checks(summary: RunSummary) -> list[CheckResult]:
    """Pool checks from every non-aborted contract."""
    checks: list[CheckResult] = []
    for contract in summary.contracts:
        if contract.aborted_reason is not None:
            continue
        checks.extend(contract.checks)
    return checks
