"""Seed use case: generate rows for each contract spec and hand them to a writer."""

from __future__ import annotations

from datetime import UTC, datetime

from turbine.core.seed.ports import SeedWriter
from turbine.core.seed.row_generator import generate_rows
from turbine.core.seed.types import SeedRequest, SeedResult, SeedTableResult


class SeedUseCase:
    """Generates synthetic rows for every spec in *request* and writes them.

    Fail-fast: the first ``TurbineError`` from row generation or the writer
    aborts the run. Success means every table got data. Tests inject a
    ``wall_clock`` so timestamp generation is deterministic.
    """

    def __init__(self, writer: SeedWriter, wall_clock: datetime | None = None) -> None:
        self.writer = writer
        self.wall_clock = wall_clock

    def execute(self, request: SeedRequest) -> SeedResult:
        """Seed every spec in *request* and return one ``SeedTableResult`` per table."""
        anchor = self.wall_clock if self.wall_clock is not None else datetime.now(tz=UTC)
        outcomes: list[SeedTableResult] = []
        for spec in request.specs:
            rows = generate_rows(spec.columns, request.row_count, wall_clock=anchor)
            inserted = self.writer.seed_table(spec.table, spec.columns, rows)
            outcomes.append(SeedTableResult(table=spec.table, rows_inserted=inserted))
        return SeedResult(tables=tuple(outcomes))
