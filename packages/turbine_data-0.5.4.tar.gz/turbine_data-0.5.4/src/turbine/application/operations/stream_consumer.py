"""``consume``: drain a ``CheckUseCase.stream`` into a :class:`RunSummary`.

Every surface (CLI, LSP, API) iterates ``use_case.stream(target, ctx)`` and
feeds the events into a :class:`RunCollector`. This helper centralises the
loop so each surface only provides its side-effects (progress ticks, LSP
notifications) via ``on_event`` and its early-exit criterion via
``stop_predicate``. Streaming exceptions are caught and surfaced as a
second tuple member so callers can render a partial summary.

Cancellation is cooperative: each ``__anext__`` is wrapped in
``asyncio.shield`` so a hard task-cancel cannot tear down a runner mid-await
(would leak a DuckDB session txn). Callers flip ``ctx.cancel_event``; the
loop checks it after every event lands and exits cleanly with a partial
summary plus a :class:`CancelState`. ``CancelledError`` is a BaseException
and still propagates — reserved for hard shutdown.
"""

from __future__ import annotations

import asyncio
import inspect
from collections.abc import AsyncIterator, Awaitable, Callable
from dataclasses import dataclass
from typing import Protocol

from turbine.application.operations.collector import RunCollector, RunEvent, RunSummary
from turbine.application.operations.run_plan import RunPlan
from turbine.core.common.error_summary import summarize_exception
from turbine.core.quality.events import is_terminal_check_event
from turbine.core.quality.run_context import RunContext
from turbine.core.quality.targets import RunTarget


@dataclass(frozen=True, slots=True)
class CancelState:
    """Outcome of a cancel-aware drain.

    ``completed_checks`` is the number of terminal check events
    (:class:`CheckCompleted` or :class:`CheckErrored`) the collector saw
    before the loop exited. ``total_checks`` is left ``None`` here —
    ``consume`` does not know the plan denominator;
    surface code (LSP / CLI) fills it in from ``plan.total_checks`` when
    rendering the cancel message.
    """

    cancelled: bool
    completed_checks: int
    total_checks: int | None


class StreamingCheckUseCase(Protocol):
    """Small port for use cases that stream quality run events."""

    def stream(self, target: RunTarget, ctx: RunContext) -> AsyncIterator[RunEvent]:
        """Yield run events for the requested target."""
        ...

    def plan(self, target: RunTarget) -> RunPlan:
        """Enumerate the ``DatasetSpec`` units ``target`` will run, without running them."""
        ...


async def consume(
    use_case: StreamingCheckUseCase,
    target: RunTarget,
    ctx: RunContext,
    *,
    on_event: Callable[[RunEvent], Awaitable[None] | None] | None = None,
    stop_predicate: Callable[[RunEvent], bool] | None = None,
) -> tuple[RunSummary, str | None, CancelState]:
    """Drain ``use_case.stream(target, ctx)`` honouring ``ctx.cancel_event``.

    ``on_event`` fires after each event is pushed to the collector. It
    accepts a sync or async callable. ``stop_predicate`` breaks the loop
    (after the event is pushed and the callback fires) so a caller can
    short-circuit on the first :class:`CheckCompleted` without discarding
    that event.

    Each ``__anext__`` is wrapped in :func:`asyncio.shield` so a hard
    cancel cannot interrupt a runner mid-await; the in-flight check
    finishes and its txn closes before the loop returns. A pre-flipped
    ``ctx.cancel_event`` short-circuits before the first ``__anext__``.

    Returns a ``(RunSummary, error, CancelState)`` triple. ``CancelState``
    reports whether the cooperative flag fired and how many
    :class:`CheckCompleted` events landed before the loop exited.
    """
    if ctx.cancel_event.is_requested():
        return (
            collector_finalize(RunCollector()),
            None,
            CancelState(cancelled=True, completed_checks=0, total_checks=None),
        )

    collector = RunCollector()
    state = DrainState()
    iterator = use_case.stream(target, ctx)
    try:
        await drain_until_done(iterator, collector, ctx, state, on_event, stop_predicate)
    except Exception as exc:  # noqa: BLE001 — adapter boundary, surface to caller as string
        state.stream_error = summarize_exception(exc)
    cancel_state = CancelState(
        cancelled=state.cancelled, completed_checks=state.completed_checks, total_checks=None
    )
    return collector.finalize(), state.stream_error, cancel_state


@dataclass(slots=True)
class DrainState:
    """Mutable counters and flags that ``drain_until_done`` updates per event."""

    completed_checks: int = 0
    cancelled: bool = False
    stream_error: str | None = None


async def drain_until_done(
    iterator: AsyncIterator[RunEvent],
    collector: RunCollector,
    ctx: RunContext,
    state: DrainState,
    on_event: Callable[[RunEvent], Awaitable[None] | None] | None,
    stop_predicate: Callable[[RunEvent], bool] | None,
) -> None:
    """Pull events through ``asyncio.shield`` until the stream ends, cancel, or stop fires.

    ``state`` is mutated in place so the caller can read counters even when
    the loop exits early via cancel or ``stop_predicate``.
    """
    while True:
        try:
            event = await asyncio.shield(iterator.__anext__())
        except StopAsyncIteration:
            return
        should_stop = await consume_event(event, collector, on_event, stop_predicate)
        if is_terminal_check_event(event):
            state.completed_checks += 1
        if ctx.cancel_event.is_requested():
            state.cancelled = True
            return
        if should_stop:
            return


def collector_finalize(collector: RunCollector) -> RunSummary:
    """Trivial helper so the cancel-short-circuit branch reads cleanly."""
    return collector.finalize()


async def consume_event(
    event: RunEvent,
    collector: RunCollector,
    on_event: Callable[[RunEvent], Awaitable[None] | None] | None,
    stop_predicate: Callable[[RunEvent], bool] | None,
) -> bool:
    """Push one event, run hooks, and return whether streaming should stop."""
    collector.push(event)
    if on_event is not None:
        outcome = on_event(event)
        if inspect.isawaitable(outcome):
            await outcome
    return stop_predicate is not None and stop_predicate(event)
