"""Aggregates results across multiple contracts in a project-wide check run.

Lives in the application layer because ``ContractCheckResult.result`` wraps
either a :class:`ContractSummary` (produced by ``RunCollector``) or a
:class:`ContractError`, and presentation renderers consume both shapes.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from turbine.application.operations.collector import ContractSummary
from turbine.core.building_blocks import Diagnostic
from turbine.core.quality.check_results import QualityScore


@dataclass(frozen=True, slots=True)
class ContractError:
    """Captures why a contract failed to load or execute."""

    message: str
    error_type: str
    diagnostics: tuple[Diagnostic, ...]


@dataclass(frozen=True, slots=True)
class ContractCheckResult:
    """One contract's summary or error."""

    path: Path
    result: ContractSummary | ContractError


@dataclass(frozen=True, slots=True)
class ProjectCheckResult:
    """Combined results and score across all contracts in a project."""

    contracts: tuple[ContractCheckResult, ...]
    aggregate_score: QualityScore

    @property
    def is_passed(self) -> bool:
        return all(
            not isinstance(contract.result, ContractError) and contract.result.is_passed
            for contract in self.contracts
        )
