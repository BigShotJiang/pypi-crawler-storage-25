r"""``FlagCoalescer``: emit the event stream for pre-computed flag outcomes.

Consumes a sequence of :class:`DatasetWriteResult`\ s captured during a
run and yields ``FlaggingStarted`` → one ``FlagsWritten`` per dataset →
``FlaggingCompleted``. Pure emission; no side effects.
"""

from __future__ import annotations

from collections.abc import Iterator, Sequence
from uuid import UUID

from turbine.core.quality.events import FlaggingCompleted, FlaggingStarted, FlagsWritten
from turbine.core.quality.flagging_types import DatasetWriteResult

FlagEvent = FlaggingStarted | FlagsWritten | FlaggingCompleted


class FlagCoalescer:
    """Yield the event stream describing per-dataset flag writes."""

    @staticmethod
    def stream(
        *, outcomes: Sequence[DatasetWriteResult], run_id: UUID, contract_id: str, table: str
    ) -> Iterator[FlagEvent]:
        """Yield FlaggingStarted, one FlagsWritten per outcome, then FlaggingCompleted.

        An empty *outcomes* sequence yields nothing — flagging was
        skipped for this run. The caller (the :class:`CheckUseCase`
        stream) decides whether to invoke the coalescer by checking
        ``options.flag_rows`` and the planner's output.
        """
        if not outcomes:
            return

        yield FlaggingStarted(run_id=run_id, contract_id=contract_id, table=table)

        total_rows = 0
        total_checks = 0
        for outcome in outcomes:
            yield FlagsWritten(
                run_id=run_id,
                dataset=outcome.dataset,
                rows_flagged=outcome.rows_flagged,
                checks_flagged=outcome.checks_flagged,
            )
            total_rows += outcome.rows_flagged
            total_checks += outcome.checks_flagged

        yield FlaggingCompleted(
            run_id=run_id, contract_id=contract_id, rows_flagged=total_rows, checks_flagged=total_checks
        )
