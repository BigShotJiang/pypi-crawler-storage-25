"""DiffProjectUseCase — compare current contracts against a baseline and classify changes."""

from collections import defaultdict

from turbine.core.analysis.impact import diff_indexes
from turbine.core.common import DatasetSpec
from turbine.core.common.change_types import ContractChange
from turbine.core.contract.diff import ChangeEntry, ContractDiffEntry, DiffResult
from turbine.core.contract.ports import IndexFactory
from turbine.core.contract.semver import SemverBump, bump_version, classify_diff, replace_version_in_yaml


class DiffProjectUseCase:
    """Compare current contracts against a baseline and classify changes."""

    def __init__(
        self,
        current_specs: tuple[DatasetSpec, ...],
        baseline_specs: tuple[DatasetSpec, ...],
        index_factory: IndexFactory,
    ) -> None:
        self.current_specs = current_specs
        self.baseline_specs = baseline_specs
        self.index_factory = index_factory

    def run(self, *, apply: bool = False) -> DiffResult:
        """Diff current vs baseline, classify changes, optionally bump versions."""
        current_index = self.index_factory(self.current_specs)
        baseline_index = self.index_factory(self.baseline_specs)

        changes = diff_indexes(baseline_index, current_index)

        baseline_ids = {spec.metadata.contract_id for spec in self.baseline_specs}
        grouped: defaultdict[str, list[ContractChange]] = defaultdict(list)
        for change in changes:
            grouped[change.contract_id].append(change)
        changes_by_contract = {cid: tuple(items) for cid, items in grouped.items()}

        entries: list[ContractDiffEntry] = []

        for spec in self.current_specs:
            cid = spec.metadata.contract_id
            is_new = cid not in baseline_ids
            contract_changes = changes_by_contract.get(cid, ())

            if is_new:
                entry = ContractDiffEntry(
                    contract_id=cid,
                    source_path=spec.metadata.source_path,
                    changes=tuple(ChangeEntry.from_change(ch) for ch in contract_changes),
                    bump=SemverBump.NONE,
                    old_version=spec.metadata.version,
                    new_version=spec.metadata.version,
                    is_new=True,
                )
                entries.append(entry)
                continue

            if not contract_changes:
                continue

            bump = classify_diff(contract_changes)
            old_version = spec.metadata.version
            new_version = bump_version(old_version, bump)

            if apply:
                content = spec.metadata.source_path.read_text()
                updated = replace_version_in_yaml(content, new_version)
                spec.metadata.source_path.write_text(updated)

            entry = ContractDiffEntry(
                contract_id=cid,
                source_path=spec.metadata.source_path,
                changes=tuple(ChangeEntry.from_change(ch) for ch in contract_changes),
                bump=bump,
                old_version=old_version,
                new_version=new_version,
                is_new=False,
            )
            entries.append(entry)

        result_entries = tuple(entries)
        changed_bumps = [
            entry.bump for entry in result_entries if not entry.is_new and entry.bump != SemverBump.NONE
        ]
        highest = max(changed_bumps) if changed_bumps else SemverBump.NONE

        return DiffResult(entries=result_entries, highest_bump=highest)
