"""Run quality checks on a contract via a route-keyed :class:`CheckRunner` dict.

The orchestrator owns the contract lifecycle (parse, lint, incremental
resolution, score, flag writes, :class:`RunStarted`/:class:`RunCompleted`)
and delegates the per-route execution to a runner looked up by
:class:`ExecutionRoute`. Each runner publishes its own route-specific
lifecycle events (``DatasetScanned``, ``PlanFailed``); the orchestrator
emits only the generic per-check events.
"""

from __future__ import annotations

from collections.abc import AsyncIterator, Iterator, Sequence
from dataclasses import replace
from datetime import datetime
from pathlib import Path
from uuid import UUID, uuid4

from turbine.application.diagnostics import DiagnosticCollector
from turbine.application.operations.flag_coalescer import FlagCoalescer
from turbine.application.operations.flag_planner import FlagPlanner
from turbine.application.operations.run_plan import RunPlan, SchemaCount
from turbine.core.building_blocks import (
    Diagnostic,
    DiagnosticBuilder,
    DiagnosticId,
    DiagnosticSink,
    EventBus,
    TurbineError,
)
from turbine.core.common import CheckDef, DatasetSpec, DataSourceType, RunMode, SourceParser
from turbine.core.common.dataset_spec.checks import ExecutionRoute
from turbine.core.contract import ContractRepository, LintRule, read_resolved
from turbine.core.contract.ports import ContractReaderRegistry
from turbine.core.contract.reader import IndexProvider
from turbine.core.quality import (
    CheckCompleted,
    CheckErrored,
    CheckMetadataWriter,
    CheckOutcome,
    CheckResult,
    CheckRunner,
    CheckStarted,
    DatasetWriter,
    DatasetWriteResult,
    ExecutionOptions,
    FlaggingResult,
    NoOpCheckMetadataWriter,
    NoOpQualityViewWriter,
    NoOpRunSeqStore,
    QualityScore,
    QualityViewWriter,
    RunAborted,
    RunCompleted,
    RunSeqStore,
    RunStarted,
    validate_run_window,
)
from turbine.core.quality.check_runner import RunnerYield
from turbine.core.quality.events import DatasetScanned, DiagnosticEmitted, RunEvent, ScoreComputed
from turbine.core.quality.flagging_types import FlagEntry
from turbine.core.quality.planning.partition import CheckPartition, partition_checks_by_route
from turbine.core.quality.ports import LastRunReader
from turbine.core.quality.run_context import RunContext
from turbine.core.quality.targets import ContractTarget, RunTarget


class CheckUseCase:
    """Parses a contract, dispatches each route to its runner, scores, flags."""

    def __init__(
        self,
        registry: ContractReaderRegistry,
        parser: SourceParser,
        dialect: DataSourceType,
        runners: dict[ExecutionRoute, CheckRunner],
        event_bus: EventBus,
        sink: DiagnosticSink,
        *,
        repository: ContractRepository | None = None,
        last_run_reader: LastRunReader | None = None,
        flag_writer: DatasetWriter | None = None,
        metadata_writer: CheckMetadataWriter = NoOpCheckMetadataWriter(),
        quality_view_writer: QualityViewWriter = NoOpQualityViewWriter(),
        run_seq_store: RunSeqStore = NoOpRunSeqStore(),
        rules: tuple[LintRule, ...] = (),
        index_provider: IndexProvider | None = None,
    ) -> None:
        """Store injected dependencies for the dispatching check pipeline.

        ``index_provider`` is the LSP fallback for ``targetContract``
        resolution: the editor doesn't hand a ``ContractRepository`` down
        but does maintain a project-wide ``ProjectIndex`` of in-memory
        specs. ``read_resolved`` consults it when ``repository`` is None.

        ``metadata_writer`` records ``quality_checks`` + ``check_fingerprint``
        unconditionally on every completed run; defaults to a no-op so
        the LSP and unit-test paths don't need a metadata store.
        """
        self.registry = registry
        self.parser = parser
        self.dialect = dialect
        self.runners = runners
        self.event_bus = event_bus
        self.sink = sink
        self.repository = repository
        self.last_run_reader = last_run_reader
        self.flag_writer = flag_writer
        self.metadata_writer = metadata_writer
        self.quality_view_writer = quality_view_writer
        self.run_seq_store = run_seq_store
        self.rules = rules
        self.index_provider = index_provider

    def start_run(
        self, contract: DatasetSpec, options: ExecutionOptions, datasource_path: Path
    ) -> RunStarted:
        """Publish and return the ``RunStarted`` event for this contract run."""
        has_time_filter = options.since is not None or options.until is not None
        run_mode = RunMode.INCREMENTAL if has_time_filter else RunMode.FULL
        started = RunStarted.from_contract(
            run_id=options.run_id, contract=contract, datasource_path=datasource_path, run_mode=run_mode
        )
        self.event_bus.publish(started)
        return started

    @staticmethod
    def apply_check_filter(contract: DatasetSpec, target: ContractTarget) -> DatasetSpec:
        """Narrow *contract*'s checks to those passing the target's filter, if any."""
        if target.check_filter is None:
            return contract
        return replace(contract, checks=tuple(c for c in contract.checks if target.check_filter(c)))

    def plan(self, target: RunTarget) -> RunPlan:
        """Enumerate the ``DatasetSpec`` units *target* will run, without running them.

        Mirrors ``stream_contract``'s resolution (parse → ``read_resolved`` →
        ``select_contracts`` → ``apply_check_filter``) and produces one
        :class:`SchemaCount` per resolved spec. Order matches ``stream``
        traversal so surfaces can index into the plan as the run progresses.

        Lint errors are *not* honoured: a spec with lint errors still
        contributes its checks to the plan. The runner will yield
        ``RunAborted`` instead of per-check events, so the determinate bar
        would otherwise stay stuck. ``CheckErrored`` (slice 5) makes the bar
        advance through aborted partitions; until then the planner and the
        runner agree on the happy path only.
        """
        sink = DiagnosticCollector()
        units: list[SchemaCount] = []
        for contract_target in target.expand():
            source = self.parser(contract_target.path)
            contracts = read_resolved(
                source,
                self.registry,
                sink,
                dialect=self.dialect,
                repository=self.repository,
                index_provider=self.index_provider,
            )
            for spec in select_contracts(contracts, contract_target.dataset):
                filtered = self.apply_check_filter(spec, contract_target)
                units.append(
                    SchemaCount(
                        contract_path=contract_target.path,
                        dataset=f"{spec.table.schema}.{spec.table.table}",
                        check_count=len(filtered.checks),
                    )
                )
        return RunPlan(units=tuple(units))

    def abort_from_lint(
        self,
        contract: DatasetSpec,
        lint_errors: tuple[Diagnostic, ...],
        run_id: UUID,
        run_sink: DiagnosticSink,
    ) -> Iterator[RunEvent]:
        """Yield a ``DiagnosticEmitted`` per lint error, then a lint-reason ``RunAborted``."""
        for diagnostic in lint_errors:
            run_sink.add(diagnostic)
            yield DiagnosticEmitted(run_id=run_id, diagnostic=diagnostic)
        lint_exc = TurbineError(
            f"contract failed lint ({len(lint_errors)} error(s)): fix before running checks"
        )
        aborted = RunAborted.from_error(run_id, contract, lint_exc, reason="lint")
        self.event_bus.publish(aborted)
        yield aborted

    def collect_lint_errors(self, contract: DatasetSpec) -> tuple[Diagnostic, ...]:
        """Run configured lint rules and return ERROR diagnostics only."""
        collector = DiagnosticCollector()
        for rule in self.rules:
            rule.check(contract, collector)
        return tuple(collector.errors)

    async def stream(self, target: RunTarget, ctx: RunContext) -> AsyncIterator[RunEvent]:
        """Stream RunEvents for every contract *target* expands to."""
        for contract_target in target.expand():
            async for event in self.stream_contract(contract_target, ctx):
                yield event

    async def stream_contract(self, target: ContractTarget, ctx: RunContext) -> AsyncIterator[RunEvent]:
        """Stream events for one or every DatasetSpec parsed from ``target.path``.

        ``target.dataset`` selects a single named spec inside a multi-schema
        ODCS file; ``None`` fans out across every spec the file resolves to.
        Each spec runs the full lifecycle (parse + lint + ``RunStarted`` →
        route dispatch → score + flag + ``RunCompleted``) under its own
        run-scoped ``EventPublishingSink``.
        """
        from turbine.application.diagnostics import EventPublishingSink  # noqa: PLC0415 — avoid cycle

        base_options = (
            ctx.options if target.run_id is None else replace(ctx.options, run_id=target.run_id)
        )
        bootstrap_sink = EventPublishingSink(
            underlying=self.sink, bus=self.event_bus, run_id=base_options.run_id
        )
        source = self.parser(target.path)
        contracts = read_resolved(
            source,
            self.registry,
            bootstrap_sink,
            dialect=self.dialect,
            repository=self.repository,
            index_provider=self.index_provider,
        )
        if not contracts:
            return

        for contract in select_contracts(contracts, target.dataset):
            async for event in self.stream_dataset_spec(contract, target, base_options):
                yield event

    async def stream_dataset_spec(
        self, contract: DatasetSpec, target: ContractTarget, base_options: ExecutionOptions
    ) -> AsyncIterator[RunEvent]:
        """Run the full per-spec lifecycle for one resolved ``DatasetSpec``.

        Mints a fresh ``run_id`` for this spec so multi-schema fan-outs and
        run-all expansions keep each spec's audit row, OpenLineage run, and
        Logfire span tree isolated. Symmetric with ``AllContracts.expand``,
        which mints fresh per location; nested progress (slice 3) keys its
        unit toasts on this id and would otherwise see collisions across
        specs in one file.
        """
        from turbine.application.diagnostics import EventPublishingSink  # noqa: PLC0415 — avoid cycle

        options = replace(base_options, run_id=uuid4())
        run_sink = EventPublishingSink(underlying=self.sink, bus=self.event_bus, run_id=options.run_id)

        lint_errors = self.collect_lint_errors(contract)
        if lint_errors:
            for event in self.abort_from_lint(contract, lint_errors, options.run_id, run_sink):
                yield event
            return

        options = self.apply_time_defaults(self.resolve_incremental_since(contract, options, run_sink))
        if (warning := validate_run_window(contract, options)) is not None:
            run_sink.add(warning)
            yield DiagnosticEmitted(run_id=options.run_id, diagnostic=warning)

        if (warning := row_flagging_disabled_diagnostic(contract, options)) is not None:
            run_sink.add(warning)
            yield DiagnosticEmitted(run_id=options.run_id, diagnostic=warning)

        yield self.start_run(contract, options, target.path)
        contract = self.apply_check_filter(contract, target)
        contract_id = contract.metadata.contract_id
        partition = partition_checks_by_route(contract.checks)
        results: list[CheckResult] = []
        scanned_rows: list[int] = []

        try:
            async for event in self.dispatch_partitions(
                partition, contract, options, contract_id, results, scanned_rows
            ):
                yield event
        except Exception as exc:  # noqa: BLE001 — unexpected orchestration failure becomes RunAborted
            aborted = RunAborted.from_error(options.run_id, contract, exc, reason="exception")
            self.event_bus.publish(aborted)
            yield aborted
            return

        try:
            async for event in self.stream_run_finalization(
                contract, options, tuple(results), contract_id, sum(scanned_rows)
            ):
                yield event
        except Exception as exc:  # noqa: BLE001 — finalize failure must not orphan audit_trail in STARTED
            aborted = RunAborted.from_error(options.run_id, contract, exc, reason="finalize")
            self.event_bus.publish(aborted)
            yield aborted

    async def dispatch_partitions(
        self,
        partition: CheckPartition,
        contract: DatasetSpec,
        options: ExecutionOptions,
        contract_id: str,
        results: list[CheckResult],
        scanned_rows: list[int],
    ) -> AsyncIterator[RunEvent]:
        """Dispatch each non-empty route to its runner and emit per-check events.

        Schema runs first: when any schema check is non-PASSED, the row-based
        checks downstream are guaranteed to fail with column-not-found errors,
        so we mark them ``SKIPPED`` with an explanatory diagnostic instead of
        running them. BATCHED and CUSTOM_SQL share the ``derivable`` bucket —
        the partitioner collapses them — so the caller only needs to register
        a BATCHED runner, which handles both metric types internally.

        When the schema runner is unregistered but schema checks exist, the
        gate fails open: dependents run as today so registries that only
        wire up BATCHED keep working.
        """
        async for event in self.run_partition(
            ExecutionRoute.SCHEMA,
            partition.schema,
            contract,
            options,
            contract_id,
            results,
            scanned_rows,
        ):
            yield event

        dependents = ((ExecutionRoute.BATCHED, partition.derivable),)
        if schema_failed_in(results):
            skipped_checks = tuple(check for _, checks in dependents for check in checks)
            for event in self.emit_skipped_dependents(
                skipped_checks, contract_id, options.run_id, results
            ):
                yield event
            return

        for route, checks in dependents:
            async for event in self.run_partition(
                route, checks, contract, options, contract_id, results, scanned_rows
            ):
                yield event

    async def run_partition(
        self,
        route: ExecutionRoute,
        checks: Sequence[CheckDef],
        contract: DatasetSpec,
        options: ExecutionOptions,
        contract_id: str,
        results: list[CheckResult],
        scanned_rows: list[int],
    ) -> AsyncIterator[RunEvent]:
        """Run *checks* through the registered runner for *route*, if any."""
        if not checks:
            return
        runner = self.runners.get(route)
        if runner is None:
            return
        async for event in self.run_route(
            runner, checks, contract, options, contract_id, results, scanned_rows
        ):
            yield event

    async def run_route(
        self,
        runner: CheckRunner,
        checks: Sequence[CheckDef],
        contract: DatasetSpec,
        options: ExecutionOptions,
        contract_id: str,
        results: list[CheckResult],
        scanned_rows: list[int],
    ) -> AsyncIterator[RunEvent]:
        """Drain a single route's runner, fan out events, and append results."""
        completed_names: set[str] = set()
        try:
            async for item in runner.run(checks, contract, options):
                for event in self.process_runner_item(
                    item, contract_id, options.run_id, results, completed_names, scanned_rows
                ):
                    yield event
        except Exception:  # noqa: BLE001 — runner boundary, retry remaining checks individually
            async for event in self.run_remaining_checks_individually(
                runner, checks, contract, options, contract_id, results, completed_names
            ):
                yield event

    def process_runner_item(
        self,
        item: RunnerYield,
        contract_id: str,
        run_id: UUID,
        results: list[CheckResult],
        completed_names: set[str],
        scanned_rows: list[int],
    ) -> Iterator[RunEvent]:
        """Publish and yield events for one runner item."""
        if not isinstance(item, CheckResult):
            if isinstance(item, DatasetScanned):
                scanned_rows.append(item.row_count)
            self.event_bus.publish(item)
            yield item
            return
        completed_names.add(item.name)
        yield from self.publish_check_result(item, contract_id, run_id)
        results.append(item)

    async def run_remaining_checks_individually(
        self,
        runner: CheckRunner,
        checks: Sequence[CheckDef],
        contract: DatasetSpec,
        options: ExecutionOptions,
        contract_id: str,
        results: list[CheckResult],
        completed_names: set[str],
    ) -> AsyncIterator[RunEvent]:
        """Retry unfinished checks one at a time after a route-level runner failure."""
        for check in checks:
            if check.name in completed_names:
                continue
            async for event in self.run_single_check_after_error(
                runner, check, contract, options, contract_id, results, completed_names
            ):
                yield event

    async def run_single_check_after_error(
        self,
        runner: CheckRunner,
        check: CheckDef,
        contract: DatasetSpec,
        options: ExecutionOptions,
        contract_id: str,
        results: list[CheckResult],
        completed_names: set[str],
    ) -> AsyncIterator[RunEvent]:
        """Run one retry check and convert its exception into one errored result."""
        scanned_rows: list[int] = []  # retry path drops scan accounting; failure handled per-check
        try:
            async for item in runner.run((check,), contract, options):
                for event in self.process_runner_item(
                    item, contract_id, options.run_id, results, completed_names, scanned_rows
                ):
                    yield event
        except Exception as exc:  # noqa: BLE001 — per-check retry boundary, surface as errored result
            if check.name in completed_names:
                return
            result = CheckResult.errored(check, exc)
            for event in self.publish_check_result(result, contract_id, options.run_id):
                yield event
            results.append(result)

    def publish_check_result(
        self, result: CheckResult, contract_id: str, run_id: UUID
    ) -> Iterator[RunEvent]:
        """Publish and yield the per-check event pair for *result*."""
        for event in per_check_events(result, contract_id, run_id):
            self.event_bus.publish(event)
            yield event

    def emit_skipped_dependents(
        self, checks: Sequence[CheckDef], contract_id: str, run_id: UUID, results: list[CheckResult]
    ) -> Iterator[RunEvent]:
        """Publish a SKIPPED CheckResult per dependent check when schema gates the run."""
        if not checks:
            return
        diagnostic = schema_blocked_diagnostic()
        for check in checks:
            result = CheckResult.skipped(check, diagnostic)
            for event in per_check_events(result, contract_id, run_id):
                self.event_bus.publish(event)
                yield event
            results.append(result)

    async def stream_run_finalization(
        self,
        contract: DatasetSpec,
        options: ExecutionOptions,
        results: tuple[CheckResult, ...],
        contract_id: str,
        rows_scanned: int,
    ) -> AsyncIterator[RunEvent]:
        """Emit ``ScoreComputed`` + flagging events + ``RunCompleted`` from collected results."""
        score = QualityScore.compute(results, rows_scanned=rows_scanned)
        score_event = ScoreComputed(
            run_id=options.run_id,
            contract_id=contract_id,
            score_overall=score.overall,
            checks_total=score.checks_total,
            checks_passed=score.checks_passed,
        )
        self.event_bus.publish(score_event)
        yield score_event

        self.register_check_metadata(contract, options, contract_id)
        write_outcomes = self.coalesce_flag_writes(results, contract, options)
        for event in FlagCoalescer.stream(
            outcomes=write_outcomes,
            run_id=options.run_id,
            contract_id=contract_id,
            table=str(contract.table),
        ):
            self.event_bus.publish(event)
            yield event

        is_passed = all(
            result.outcome not in {CheckOutcome.FAILED, CheckOutcome.ERRORED} for result in results
        )
        flagging = flagging_result_from(write_outcomes)
        completed = RunCompleted(
            run_id=options.run_id,
            contract=contract,
            is_passed=is_passed,
            checks_total=score.checks_total,
            checks_passed=score.checks_passed,
            checks_failed=score.checks_total - score.checks_passed,
            score_overall=score.overall,
            rows_flagged=flagging.total_rows_flagged if flagging else None,
        )
        self.event_bus.publish(completed)
        yield completed

    def coalesce_flag_writes(
        self, results: tuple[CheckResult, ...], contract: DatasetSpec, options: ExecutionOptions
    ) -> tuple[DatasetWriteResult, ...]:
        """Plan flag writes per dataset, write cells, then refresh the user-facing view."""
        if not options.flag_rows or self.flag_writer is None:
            return ()
        plans = FlagPlanner.plan(results, contract)
        if not plans:
            return ()
        run_seq = self.run_seq_store.get_run_seq(options.run_id)
        outcomes = tuple(self.flag_writer.write(plan, run_seq) for plan in plans)
        for plan in plans:
            self.quality_view_writer.refresh(plan.dataset, contract.pk_columns)
        return outcomes

    def register_check_metadata(
        self, contract: DatasetSpec, options: ExecutionOptions, contract_id: str
    ) -> None:
        """Upsert ``quality_checks`` + ``check_fingerprint`` for every executed check.

        Runs unconditionally — the registry and the per-era fingerprint
        must reflect every run, regardless of ``--flag`` and regardless
        of pass/fail. No-op when the contract has zero checks (e.g.
        lint-aborted runs that never ran a real check).
        """
        if not contract.checks:
            return
        run_seq = self.run_seq_store.get_run_seq(options.run_id)
        self.metadata_writer.register(
            run_seq=run_seq,
            contract_id=contract_id,
            spec_id=contract_id,
            dataset=str(contract.table),
            checks=contract.checks,
            lifecycle=contract.metadata.status.value,
        )

    def resolve_incremental_since(
        self, contract: DatasetSpec, options: ExecutionOptions, sink: DiagnosticSink
    ) -> ExecutionOptions:
        """When --incremental without --since, look up the last completed run."""
        if not options.incremental or options.since is not None:
            return options
        if self.last_run_reader is None:
            return options

        contract_id = contract.metadata.contract_id
        table_name = str(contract.table)
        last_completed = self.last_run_reader.get_last_completed_at(contract_id, table_name)

        if last_completed is None:
            diagnostic = (
                DiagnosticBuilder.warning(
                    DiagnosticId.INCREMENTAL_NO_PRIOR_RUN,
                    f"This is the first incremental run for `{table_name}`, so Turbine will scan "
                    "the full table.",
                )
                .help("Future incremental runs will use this run as the baseline.")
                .build()
            )
            sink.add(diagnostic)
            return options

        return replace(options, since=last_completed)

    @staticmethod
    def apply_time_defaults(options: ExecutionOptions) -> ExecutionOptions:
        """Fill in ``until=now()`` when the user gave --since but not --until."""
        if options.since is not None and options.until is None:
            return replace(options, until=datetime.now())  # noqa: DTZ005 — naive to match DB NOW()
        return options


def row_flagging_disabled_diagnostic(
    contract: DatasetSpec, options: ExecutionOptions
) -> Diagnostic | None:
    """Warn when the user asked for row flags but the dataset has no row identity."""
    if not options.flag_rows or contract.pk_columns:
        return None
    schema_name = str(contract.table)
    span_range = contract.schema_name_source_range or contract.dataset_source_range
    return (
        DiagnosticBuilder.warning(
            DiagnosticId.QUALITY_ROW_IDENTIFIERS,
            f"Cannot show which rows failed in `{schema_name}` because no primary key is defined. "
            "Add `primaryKey: true` to one or more columns to enable row-level failure details.",
        )
        .span(contract.metadata.source_path, span_range)
        .build()
    )


def select_contracts(contracts: tuple[DatasetSpec, ...], dataset: str | None) -> tuple[DatasetSpec, ...]:
    """Pick every DatasetSpec to run for *dataset*: a single match, or all of them.

    *dataset* is the qualified ``schema.table`` name from the run target.
    ``None`` means "no narrowing" — multi-schema files fan out across every
    parsed spec instead of silently picking the first one.
    """
    if dataset is None:
        return contracts
    for contract in contracts:
        if f"{contract.table.schema}.{contract.table.table}" == dataset:
            return (contract,)
    return ()


def per_check_events(result: CheckResult, contract_id: str, run_id: UUID) -> Iterator[RunEvent]:
    """Yield ``CheckStarted`` then the terminal event for *result*.

    Terminal event duration comes from ``result.duration_ms``, which the
    batched runner populates from the plan's scan duration. Other runners
    leave it ``None``.
    """
    yield CheckStarted(
        run_id=run_id,
        check_name=result.name,
        check_type=result.check_type,
        dimension=result.dimension,
        column=result.column,
        contract_id=contract_id,
    )
    if result.outcome == CheckOutcome.ERRORED:
        yield CheckErrored.from_result(
            result, contract_id=contract_id, run_id=run_id, duration_ms=result.duration_ms
        )
        return
    yield CheckCompleted.from_result(
        result, contract_id=contract_id, run_id=run_id, duration_ms=result.duration_ms
    )


def flagging_result_from(outcomes: tuple[DatasetWriteResult, ...]) -> FlaggingResult | None:
    r"""Flatten every outcome's per-check :class:`FlagEntry`\ s into a single result."""
    if not outcomes:
        return None
    entries: tuple[FlagEntry, ...] = tuple(entry for outcome in outcomes for entry in outcome.entries)
    return FlaggingResult(entries=entries)


def schema_failed_in(results: Sequence[CheckResult]) -> bool:
    """Return True when any schema check in *results* finished non-PASSED."""
    return any(
        result.check_type == "schema" and result.outcome != CheckOutcome.PASSED for result in results
    )


def schema_blocked_diagnostic() -> Diagnostic:
    """Diagnostic explaining why a row-based check was skipped after schema fail."""
    return (
        DiagnosticBuilder.warning(
            DiagnosticId.CHECK_SKIPPED_DUE_TO_SCHEMA,
            "This check was skipped because the table structure does not match the contract.",
        )
        .help("Run `turbine validate` to see the differences, then update the contract or database.")
        .build()
    )
