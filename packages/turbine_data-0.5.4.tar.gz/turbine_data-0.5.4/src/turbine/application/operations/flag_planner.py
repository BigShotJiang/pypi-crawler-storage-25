"""``FlagPlanner``: group :class:`CheckResult`s into per-dataset :class:`FlagPlan`s.

Pure function. Given a sequence of results and the contract they ran
against, returns one :class:`FlagPlan` per dataset (at most one today,
since a :class:`DatasetSpec` represents one ``(schema, table)`` pair).
Results without ``failed_pks`` (schema / freshness / raw row_count) or
without an attached :class:`CheckDef` are skipped.
"""

from __future__ import annotations

from collections.abc import Sequence

from turbine.core.common import DatasetSpec
from turbine.core.quality.check_results import CheckResult
from turbine.core.quality.flagging_types import CellUpdate, CheckFlagRequest, FlagPlan


class FlagPlanner:
    """Build per-dataset :class:`FlagPlan`s from completed :class:`CheckResult`s."""

    @staticmethod
    def plan(results: Sequence[CheckResult], contract: DatasetSpec) -> tuple[FlagPlan, ...]:
        """Return at most one :class:`FlagPlan` for *contract*'s dataset.

        Empty return tuple when no result identifies failing rows. A
        non-empty tuple always contains exactly one plan today; the
        tuple shape is preserved for multi-dataset contracts later.
        """
        requests = tuple(build_request(result) for result in results if is_flaggable(result))
        if not requests:
            return ()
        return (FlagPlan(dataset=str(contract.table), requests=requests),)


def is_flaggable(result: CheckResult) -> bool:
    """Return True when *result* has both an attached check and materialised failing PKs."""
    return result.check is not None and result.failed_pks is not None


def build_request(result: CheckResult) -> CheckFlagRequest:
    """Build one :class:`CheckFlagRequest` from a flaggable :class:`CheckResult`."""
    check = result.check
    pks = result.failed_pks
    if check is None or pks is None:
        msg = "build_request requires a flaggable CheckResult (guard with is_flaggable first)"
        raise ValueError(msg)
    cells = tuple(
        CellUpdate(pk_uuid=pk_uuid_from_tuple(pk_tuple), check_name=result.name, flagged=True)
        for pk_tuple in pks.pks
    )
    return CheckFlagRequest(check=check, cells=cells, total_failing=pks.total, streaming=pks.streaming)


def pk_uuid_from_tuple(pk_tuple: tuple[object, ...]) -> str:
    """Serialize a composite PK tuple deterministically as a pipe-joined string."""
    return "|".join(str(value) for value in pk_tuple)
