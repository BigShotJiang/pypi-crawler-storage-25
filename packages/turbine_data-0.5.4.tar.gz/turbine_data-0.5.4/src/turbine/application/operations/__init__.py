"""Application-layer operations: check, schema validation, and flag-coalescing use cases."""

from turbine.application.operations.project_results import (
    ContractCheckResult,
    ContractError,
    ProjectCheckResult,
)
from turbine.core.quality import FlaggingResult

from .bump_contract import BumpContractUseCase
from .check import CheckUseCase
from .check_connectivity import CheckConnectivityUseCase
from .diff_contract import DiffContractUseCase
from .diff_project import DiffProjectUseCase
from .flag_coalescer import FlagCoalescer
from .flag_planner import FlagPlanner
from .project_summary import project_result_from_summary
from .validate_schema import ValidateSchemaResult, ValidateSchemaUseCase

__all__ = [
    "BumpContractUseCase",
    "CheckConnectivityUseCase",
    "CheckUseCase",
    "ContractCheckResult",
    "ContractError",
    "DiffContractUseCase",
    "DiffProjectUseCase",
    "FlagCoalescer",
    "FlagPlanner",
    "FlaggingResult",
    "ProjectCheckResult",
    "ValidateSchemaResult",
    "ValidateSchemaUseCase",
    "project_result_from_summary",
]
