"""Check connectivity use case — probe all datasources in parallel."""

from concurrent.futures import ThreadPoolExecutor
from concurrent.futures import TimeoutError as FuturesTimeoutError

from turbine.core.common.datasource import DatasourceConfig
from turbine.core.common.ports import ConnectivityProbe, ProbeResult

PROBE_TIMEOUT_SECONDS = 5


class CheckConnectivityUseCase:
    """Probes all datasources in parallel and returns ordered results."""

    def __init__(self, probe: ConnectivityProbe) -> None:
        self.probe = probe

    def execute(self, datasources: tuple[DatasourceConfig, ...]) -> tuple[ProbeResult, ...]:
        """Probe all *datasources* concurrently, returning results in input order."""
        if not datasources:
            return ()

        from sqlalchemy.exc import SQLAlchemyError  # noqa: PLC0415

        results: dict[int, ProbeResult] = {}
        with ThreadPoolExecutor(max_workers=len(datasources)) as executor:
            futures = {
                executor.submit(self.probe.probe, datasource): index
                for index, datasource in enumerate(datasources)
            }
            for future, index in futures.items():
                datasource = datasources[index]
                try:
                    results[index] = future.result(timeout=PROBE_TIMEOUT_SECONDS)
                except FuturesTimeoutError:
                    results[index] = ProbeResult.failed(
                        datasource, f"timeout ({PROBE_TIMEOUT_SECONDS}s)"
                    )
                except (OSError, SQLAlchemyError) as exc:
                    results[index] = ProbeResult.failed(datasource, str(exc))

        return tuple(results[index] for index in range(len(datasources)))
