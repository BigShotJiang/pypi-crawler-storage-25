"""DiffContractUseCase — diff one contract against its previous git version."""

from collections.abc import Callable
from pathlib import Path

from turbine.core.building_blocks import NullDiagnosticSink
from turbine.core.common import DatasetSpec, RawSource
from turbine.core.common.change_types import ContractChange
from turbine.core.contract.diff import ChangeEntry, ContractDiffEntry, DiffResult
from turbine.core.contract.diff_computer import DiffComputer
from turbine.core.contract.ports import ContractReaderRegistry, PreviousVersionReader
from turbine.core.contract.semver import SemverBump, classify_diff, read_version_from_yaml

ContractParser = Callable[[Path, str | None], RawSource]


class DiffContractUseCase:
    """Diff a single contract against its previous git version and classify changes."""

    def __init__(
        self,
        registry: ContractReaderRegistry,
        parser: ContractParser,
        previous_reader: PreviousVersionReader,
    ) -> None:
        self.registry = registry
        self.parser = parser
        self.previous_reader = previous_reader

    def run(self, path: Path, ref: str = "HEAD") -> DiffResult:
        """Parse current + previous contracts and return a DiffResult."""
        previous_text = self.previous_reader.read(path, ref)
        return self.run_with_previous_text(path, previous_text)

    def run_with_previous_text(
        self, path: Path, previous_text: str | None, current_text: str | None = None
    ) -> DiffResult:
        """Parse current + supplied previous contract text and return a DiffResult."""
        current_specs = self.parse_specs(path, text=current_text)
        if previous_text is None:
            return DiffResult(entries=(), highest_bump=SemverBump.NONE)

        previous_specs = self.parse_specs(path, text=previous_text)
        changes = DiffComputer.compute(current_specs, previous_specs)
        bump = classify_diff(changes)

        if not current_specs:
            return self.result_for_removed_schema(path, previous_specs, changes, bump, current_text)

        spec = current_specs[0]
        contract_id = spec.metadata.contract_id
        contract_changes = tuple(change for change in changes if change.contract_id == contract_id)
        if not contract_changes:
            return DiffResult(entries=(), highest_bump=SemverBump.NONE)

        entry = ContractDiffEntry(
            contract_id=contract_id,
            source_path=spec.metadata.source_path,
            changes=tuple(ChangeEntry.from_change(change) for change in contract_changes),
            bump=bump,
            old_version=previous_version_for(contract_id, previous_specs),
            new_version=spec.metadata.version,
            is_new=False,
        )
        return DiffResult(entries=(entry,), highest_bump=bump)

    def result_for_removed_schema(
        self,
        path: Path,
        previous_specs: tuple[DatasetSpec, ...],
        changes: tuple[ContractChange, ...],
        bump: SemverBump,
        current_text: str | None,
    ) -> DiffResult:
        """Return a diff entry when the current file no longer yields specs."""
        if not previous_specs or not changes:
            return DiffResult(entries=(), highest_bump=bump)
        previous_spec = previous_specs[0]
        source_text = current_text if current_text is not None else path.read_text()
        current_version = read_version_from_yaml(source_text) or previous_spec.metadata.version
        entry = ContractDiffEntry(
            contract_id=previous_spec.metadata.contract_id,
            source_path=path,
            changes=tuple(ChangeEntry.from_change(change) for change in changes),
            bump=bump,
            old_version=previous_spec.metadata.version,
            new_version=current_version,
            is_new=False,
        )
        return DiffResult(entries=(entry,), highest_bump=bump)

    def parse_specs(self, path: Path, text: str | None) -> tuple[DatasetSpec, ...]:
        """Parse *path* (optionally from *text*) and return the resulting specs."""
        sink = NullDiagnosticSink()
        raw_source = self.parser(path, text)
        return self.registry.read(raw_source, sink)


def previous_version_for(contract_id: str, previous_specs: tuple[DatasetSpec, ...]) -> str:
    """Return the previous version for *contract_id*."""
    for spec in previous_specs:
        if spec.metadata.contract_id == contract_id:
            return spec.metadata.version
    return ""
