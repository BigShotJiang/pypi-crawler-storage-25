"""RunCollector: folds a ``CheckUseCase.stream`` event sequence into a ``RunSummary``.

Surfaces (CLI, LSP, API) iterate ``use_case.stream(target, ctx)`` and push each
event into a ``RunCollector``. After the iterator is drained, ``finalize()``
returns a ``RunSummary`` that every surface renders from a single shape.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Self
from uuid import UUID

from turbine.core.building_blocks import Diagnostic, Severity
from turbine.core.common import DatasetSpec
from turbine.core.quality import (
    CheckCompleted,
    CheckErrored,
    CheckResult,
    DiagnosticEmitted,
    FlagsWritten,
    QualityScore,
    RunAborted,
    RunCompleted,
    RunStarted,
)
from turbine.core.quality.events import (
    DatasetScanned,
    FlaggingCompleted,
    FlaggingStarted,
    PlanFailed,
    RunEvent,
    ScoreComputed,
)


@dataclass(frozen=True, slots=True)
class FlaggingSummary:
    """Aggregate row-flagging counts, produced from FlagsWritten events."""

    total_rows_flagged: int
    total_checks_flagged: int
    per_dataset: tuple[FlagsWritten, ...]


@dataclass(frozen=True, slots=True)
class ContractSummary:
    """One contract's roll-up: checks produced by CheckCompleted, score, flagging.

    When the run aborted (lint failure, uncaught exception), ``aborted_reason``
    is set to the coarse bucket and ``aborted_error_type`` / ``aborted_error_message``
    carry the underlying exception identity so callers can rebuild a
    :class:`~turbine.application.operations.project_results.ContractError` without
    holding onto the original exception object.
    """

    run_id: UUID
    contract: DatasetSpec
    is_passed: bool
    score: QualityScore | None
    checks: tuple[CheckResult, ...]
    diagnostics: tuple[Diagnostic, ...]
    plan_failures: tuple[PlanFailed, ...]
    dataset_scans: tuple[DatasetScanned, ...]
    flagging: FlaggingSummary | None
    aborted_reason: str | None = None
    aborted_error_type: str | None = None
    aborted_error_message: str | None = None

    @property
    def contract_id(self) -> str:
        """The contract id of the underlying ``DatasetSpec`` for this run."""
        return self.contract.metadata.contract_id

    @property
    def rows_scanned(self) -> int:
        """Total rows materialised across every dataset scan — never summed per-check."""
        return sum(scan.row_count for scan in self.dataset_scans)

    @property
    def no_checks_ran(self) -> bool:
        """True when zero checks executed and at least one error diagnostic was emitted.

        Distinguishes "passed because nothing failed" from "nothing ran because the
        contract itself was unparseable" — surfaces only need to render a special
        message in the latter case.
        """
        score = self.score or QualityScore.zero()
        if score.checks_total != 0:
            return False
        return any(diag.severity == Severity.ERROR for diag in self.diagnostics)


@dataclass(frozen=True, slots=True)
class RunSummary:
    """Aggregate across every contract a target expanded to."""

    contracts: tuple[ContractSummary, ...]

    @property
    def is_passed(self) -> bool:
        """True when every contract passed without abort."""
        return all(c.is_passed and c.aborted_reason is None for c in self.contracts)

    @property
    def total_checks(self) -> int:
        """Sum of check counts across contracts."""
        return sum(len(c.checks) for c in self.contracts)


@dataclass
class ContractAccumulator:
    """Mutable per-contract buffer used by the collector during streaming."""

    run_id: UUID
    contract: DatasetSpec
    checks: list[CheckResult] = field(default_factory=list)
    diagnostics: list[Diagnostic] = field(default_factory=list)
    plan_failures: list[PlanFailed] = field(default_factory=list)
    dataset_scans: list[DatasetScanned] = field(default_factory=list)
    flags_written: list[FlagsWritten] = field(default_factory=list)
    flagging_completed: FlaggingCompleted | None = None
    completed: RunCompleted | None = None
    aborted: RunAborted | None = None

    def freeze(self) -> ContractSummary:
        """Snapshot into an immutable ContractSummary."""
        if self.aborted is not None:
            return self.frozen_abort()

        completed = self.completed
        score = None
        is_passed = False
        if completed is not None:
            is_passed = completed.is_passed
            score = QualityScore(
                overall=completed.score_overall,
                dimensions=(),
                checks_total=completed.checks_total,
                checks_passed=completed.checks_passed,
            )

        flagging = self.freeze_flagging()
        return ContractSummary(
            run_id=self.run_id,
            contract=self.contract,
            is_passed=is_passed,
            score=score,
            checks=tuple(self.checks),
            diagnostics=tuple(self.diagnostics),
            plan_failures=tuple(self.plan_failures),
            dataset_scans=tuple(self.dataset_scans),
            flagging=flagging,
            aborted_reason=None,
        )

    def frozen_abort(self) -> ContractSummary:
        """Snapshot for an aborted contract (lint failure or exception)."""
        aborted = self.aborted
        assert aborted is not None
        return ContractSummary(
            run_id=self.run_id,
            contract=self.contract,
            is_passed=False,
            score=None,
            checks=tuple(self.checks),
            diagnostics=tuple(self.diagnostics),
            plan_failures=tuple(self.plan_failures),
            dataset_scans=tuple(self.dataset_scans),
            flagging=None,
            aborted_reason=aborted.reason,
            aborted_error_type=aborted.error_type,
            aborted_error_message=aborted.error_message,
        )

    def freeze_flagging(self) -> FlaggingSummary | None:
        """Collapse FlagsWritten events into a FlaggingSummary if any landed."""
        if not self.flags_written and self.flagging_completed is None:
            return None
        if self.flagging_completed is not None:
            return FlaggingSummary(
                total_rows_flagged=self.flagging_completed.rows_flagged,
                total_checks_flagged=self.flagging_completed.checks_flagged,
                per_dataset=tuple(self.flags_written),
            )
        total_rows = sum(event.rows_flagged for event in self.flags_written)
        total_checks = sum(event.checks_flagged for event in self.flags_written)
        return FlaggingSummary(
            total_rows_flagged=total_rows,
            total_checks_flagged=total_checks,
            per_dataset=tuple(self.flags_written),
        )


@dataclass
class RunCollector:
    """Pure accumulator: push events, then finalize.

    Surfaces own the collector; the use case stays stateless. Each contract
    in the stream opens an accumulator on RunStarted and closes on
    RunCompleted or RunAborted.

    Diagnostics emitted before the lifecycle opens (e.g. contract-read
    schema validation, which fires before RunStarted) land in
    ``pending_diagnostics`` and are flushed onto the first accumulator so
    they surface on ``ContractSummary.diagnostics`` even when the run
    aborts without ever starting.
    """

    contracts: list[ContractAccumulator] = field(default_factory=list)
    current: ContractAccumulator | None = None
    frozen: list[ContractSummary] = field(default_factory=list)
    pending_diagnostics: list[Diagnostic] = field(default_factory=list)

    def push(self, event: RunEvent) -> None:
        """Route *event* to the handler matching its concrete type."""
        if self.handle_lifecycle(event):
            return
        if self.current is None:
            if isinstance(event, DiagnosticEmitted):
                self.pending_diagnostics.append(event.diagnostic)
            return
        self.accumulate(event, self.current)

    def handle_lifecycle(self, event: RunEvent) -> bool:
        """Handle RunStarted/RunCompleted/RunAborted; return True if consumed."""
        match event:
            case RunStarted():
                self.open_contract(event)
            case RunCompleted():
                self.close_completed(event)
            case RunAborted():
                self.close_aborted(event)
            case _:
                return False
        return True

    @staticmethod
    def accumulate(event: RunEvent, current: ContractAccumulator) -> None:
        """Fold a non-lifecycle *event* into *current*."""
        match event:
            case CheckCompleted():
                current.checks.append(event.to_result())
            case CheckErrored():
                current.checks.append(event.to_result())
            case DatasetScanned():
                current.dataset_scans.append(event)
            case PlanFailed():
                current.plan_failures.append(event)
            case DiagnosticEmitted():
                current.diagnostics.append(event.diagnostic)
            case FlagsWritten():
                current.flags_written.append(event)
            case FlaggingCompleted():
                current.flagging_completed = event
            case FlaggingStarted() | ScoreComputed():
                pass  # tracked via RunCompleted/FlagsWritten; nothing to fold

    def open_contract(self, event: RunStarted) -> None:
        """Start a new contract accumulator, seeded with any pending diagnostics."""
        self.current = ContractAccumulator(run_id=event.run_id, contract=event.contract)
        self.drain_pending_into(self.current)
        self.contracts.append(self.current)

    def drain_pending_into(self, accumulator: ContractAccumulator) -> None:
        """Move pre-lifecycle diagnostics onto *accumulator* and clear the buffer."""
        if not self.pending_diagnostics:
            return
        accumulator.diagnostics.extend(self.pending_diagnostics)
        self.pending_diagnostics.clear()

    def close_completed(self, event: RunCompleted) -> None:
        """Mark the current contract completed and freeze it."""
        if self.current is None:
            return
        self.current.completed = event
        self.frozen.append(self.current.freeze())
        self.current = None

    def close_aborted(self, event: RunAborted) -> None:
        """Mark the current contract aborted and freeze it.

        Lint-abort runs emit ``RunAborted`` without a preceding
        ``RunStarted`` — the contract never started. Open a synthetic
        accumulator from the event so the summary still surfaces the
        aborted contract with its reason, and flush any buffered
        pre-lifecycle diagnostics onto it.
        """
        if self.current is None:
            self.current = ContractAccumulator(run_id=event.run_id, contract=event.contract)
            self.drain_pending_into(self.current)
            self.contracts.append(self.current)
        self.current.aborted = event
        self.frozen.append(self.current.freeze())
        self.current = None

    def finalize(self) -> RunSummary:
        """Return the immutable RunSummary after the stream is drained."""
        if self.current is not None:
            self.frozen.append(self.current.freeze())
            self.current = None
        return RunSummary(contracts=tuple(self.frozen))

    @classmethod
    def from_events(cls, events: list[RunEvent]) -> Self:
        """Build and drain a collector against *events* in one go."""
        collector = cls()
        for event in events:
            collector.push(event)
        return collector
