"""Validate-schema use case — compare contract schema against live database."""

from dataclasses import dataclass
from pathlib import Path

from loguru import logger

from turbine.application.diagnostics import DiagnosticCollector
from turbine.core.building_blocks import (
    DatabaseError,
    Diagnostic,
    DiagnosticBuilder,
    DiagnosticId,
    EventBus,
)
from turbine.core.common import (
    ColumnDef,
    DatasetSpec,
    RawSource,
    SchemaIntrospector,
    SourceParser,
    TableIdentifier,
)
from turbine.core.contract.ports import ContractReaderRegistry
from turbine.core.validation import (
    SchemaValidationDetected,
    ValidationReport,
    ValidationType,
    compare_columns,
)


@dataclass(frozen=True, slots=True)
class ValidateSchemaResult:
    """Schema validation output bundling reports with their source context."""

    reports: tuple[ValidationReport, ...]
    contracts: tuple[DatasetSpec, ...]
    source: RawSource
    diagnostics: tuple[Diagnostic, ...] = ()


class ValidateSchemaUseCase:
    """Runs schema validation for a contract file.

    Parses the contract, introspects each table's live schema,
    compares columns, and publishes SchemaValidationDetected events.
    """

    def __init__(
        self,
        registry: ContractReaderRegistry,
        parser: SourceParser,
        introspector: SchemaIntrospector,
        event_bus: EventBus,
    ) -> None:
        """Store the registry, parser, introspector, and event bus."""
        self.registry = registry
        self.parser = parser
        self.introspector = introspector
        self.event_bus = event_bus

    def validate(self, contract_path: Path) -> ValidateSchemaResult:
        """Read the contract, compare each table against the live DB schema.

        QualitySpec files (``kind: QualitySpec``) carry no column definitions
        of their own — they attach checks to a target contract — so running
        DB validation against them produces a flood of bogus "column added"
        warnings (every DB column is "extra" against an empty contract).
        Skip those specs early with a clear diagnostic.
        """
        logger.debug(f"Reading contract: {contract_path}")
        source = self.parser(contract_path)
        collector = DiagnosticCollector()
        contracts = self.registry.read(source, collector)

        validatable = tuple(spec for spec in contracts if spec.metadata.is_contract)
        skipped = tuple(spec for spec in contracts if not spec.metadata.is_contract)
        for spec in skipped:
            collector.add(
                DiagnosticBuilder.warning(
                    DiagnosticId.VALIDATION,
                    f"`{spec.metadata.contract_id}` is a QualitySpec, not a contract — "
                    "schema validation needs the target contract instead",
                )
                .span(source.path)
                .help(
                    f"run `turbine validate {spec.target_contract}` against the targeted contract, "
                    "or point this command at the contract file"
                )
                .build()
            )

        reports: list[ValidationReport] = []
        for contract in validatable:
            report = self.validate_table(contract.table, contract.columns)
            reports.append(report)

        return ValidateSchemaResult(
            reports=tuple(reports),
            contracts=validatable,
            source=source,
            diagnostics=tuple(collector.items),
        )

    def validate_table(
        self, table: TableIdentifier, contract_columns: tuple[ColumnDef, ...]
    ) -> ValidationReport:
        """Compare a single table's contract columns against the database."""
        try:
            db_columns = self.introspector.introspect_schema(table)
        except DatabaseError as exc:
            logger.debug(f"Failed to introspect {table}: {exc}")
            return ValidationReport.from_error(table, str(exc))

        if db_columns is None:
            return ValidationReport.from_error(table, f"Table {table} not found or has no columns")

        findings = compare_columns(contract_columns, db_columns)
        report = ValidationReport.from_comparison(table, findings)

        if not report.has_findings:
            return report
        validation_event = SchemaValidationDetected(
            table=table,
            added_columns=len(report.by_type(ValidationType.EXTRA_IN_DB)),
            removed_columns=len(report.by_type(ValidationType.MISSING_IN_DB)),
            changed_columns=len(report.by_type(ValidationType.TYPE_MISMATCH)),
        )
        self.event_bus.publish(validation_event)
        return report
