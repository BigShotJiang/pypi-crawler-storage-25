"""Plan Contract version updates from git changes."""

from enum import StrEnum
from pathlib import Path

from pydantic import BaseModel

from turbine.application.operations.diff_contract import DiffContractUseCase
from turbine.core.contract.diff import ChangeEntry
from turbine.core.contract.ports import PreviousVersionReader
from turbine.core.contract.semver import (
    SemverBump,
    Version,
    bump_version,
    read_version_from_yaml,
    replace_version_in_yaml,
)


class BumpDecision(StrEnum):
    """What happened while checking or writing a Contract version."""

    SKIPPED_NO_GIT = "skipped-no-git"
    NO_CHANGE = "no-change"
    PLANNED = "planned"
    WRITTEN = "written"
    FAILED = "failed"


class ContractBumpPlan(BaseModel, frozen=True):
    """A suggested or written version update for one Contract file.

    ``new_content`` holds the rewritten YAML when an update is planned or
    written. ``apply`` only changes the plan state; the CLI writes the file.
    """

    path: Path
    contract_id: str | None
    old_version: str | None
    new_version: str | None
    bump: SemverBump
    changes: tuple[ChangeEntry, ...]
    decision: BumpDecision
    message: str | None = None
    new_content: str | None = None


class BumpContractUseCase:
    """Plan Contract version updates from git diffs."""

    def __init__(
        self, diff_use_case: DiffContractUseCase, previous_reader: PreviousVersionReader
    ) -> None:
        self.diff_use_case = diff_use_case
        self.previous_reader = previous_reader

    def plan(self, path: Path, ref: str = "HEAD") -> ContractBumpPlan:
        """Work out the needed version update for *path* without writing."""
        previous_text = self.previous_reader.read(path, ref)
        if previous_text is None:
            return self.skipped_plan(
                path, BumpDecision.SKIPPED_NO_GIT, "no git history found; skipped version update"
            )

        result = self.diff_use_case.run_with_previous_text(path, previous_text)
        if not result.entries or result.highest_bump == SemverBump.NONE:
            return self.skipped_plan(path, BumpDecision.NO_CHANGE, "No changes detected")

        entry = result.entries[0]
        base_version = read_version_from_yaml(previous_text) or entry.old_version
        new_version = bump_version(base_version, entry.bump)
        if Version.parse(entry.new_version) >= Version.parse(new_version):
            return ContractBumpPlan(
                path=path,
                contract_id=entry.contract_id,
                old_version=entry.old_version,
                new_version=new_version,
                bump=SemverBump.NONE,
                changes=(),
                decision=BumpDecision.NO_CHANGE,
                message="Version already has the needed update",
            )
        new_content = replace_version_in_yaml(path.read_text(), new_version)
        return ContractBumpPlan(
            path=path,
            contract_id=entry.contract_id,
            old_version=entry.old_version,
            new_version=new_version,
            bump=entry.bump,
            changes=entry.changes,
            decision=BumpDecision.PLANNED,
            new_content=new_content,
        )

    def apply(self, plan: ContractBumpPlan) -> ContractBumpPlan:
        """Mark a planned update as written. The caller writes the file."""
        if plan.decision != BumpDecision.PLANNED:
            return plan
        if plan.new_content is None:
            return plan.model_copy(update={"decision": BumpDecision.NO_CHANGE})
        return plan.model_copy(update={"decision": BumpDecision.WRITTEN})

    @staticmethod
    def skipped_plan(path: Path, decision: BumpDecision, message: str) -> ContractBumpPlan:
        """Build a plan for a file that does not need a version update."""
        return ContractBumpPlan(
            path=path,
            contract_id=None,
            old_version=None,
            new_version=None,
            bump=SemverBump.NONE,
            changes=(),
            decision=decision,
            message=message,
        )
