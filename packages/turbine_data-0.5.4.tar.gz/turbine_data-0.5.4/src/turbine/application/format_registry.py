"""Format registry — detect and dispatch to the right contract reader.

Given a ``RawSource``, the registry iterates registered readers and
delegates to the first one whose ``can_read`` returns True.
"""

from collections.abc import Sequence
from typing import Any

from loguru import logger

from turbine.application.implementation_dispatch import dispatch as dispatch_implementation
from turbine.core.building_blocks import DiagnosticBuilder, DiagnosticId, DiagnosticSink
from turbine.core.common import (
    EMPTY,
    FIELD_KIND,
    DatasetSpec,
    FieldDoc,
    RawSource,
    ResolvedNode,
    resolve_at_path,
)
from turbine.core.common.schema_walker import resolve_raw_at_path
from turbine.core.contract import FormatDescriptor, FormatReader


class FormatRegistry:
    """Registry of format readers with auto-detection and optional schema resolution.

    Readers are tried in registration order. The first reader whose
    ``can_read`` returns True for the given data is selected.

    When *descriptors* are provided (paired 1:1 with readers), schema
    resolution methods (``can_resolve``, ``resolve_field``) become available.
    """

    def __init__(
        self, readers: Sequence[FormatReader], descriptors: Sequence[FormatDescriptor] = ()
    ) -> None:
        """Register format readers and their paired schema descriptors."""
        self.readers = list(readers)
        self.descriptors = list(descriptors)
        self.pairs = list(zip(readers, descriptors, strict=True)) if descriptors else []
        for reader in readers:
            logger.debug(f"Registered reader for format: {reader.format_label}")

    def detect_reader(self, source: RawSource) -> FormatReader:
        """Find the first reader that can handle *source*.

        Raises ``TurbineError`` if no registered reader matches.
        """
        for reader in self.readers:
            if reader.can_read(source.data):
                logger.debug(f"Resolved reader for format: {reader.format_label}")
                return reader
        kind = source.data.get(FIELD_KIND, "(missing)")
        labels = ", ".join(reader.format_label for reader in self.readers)
        kind_range = source.source_map.range_for_value(FIELD_KIND)
        raise (
            DiagnosticBuilder.error(
                DiagnosticId.CONTRACT_PARSE_ERROR, f"Invalid contract type: `kind: {kind}`."
            )
            .span(source.path, kind_range)
            .help(f"Use one of these supported types: {labels}.")
            .into_error()
        )

    def read(self, source: RawSource, sink: DiagnosticSink) -> tuple[DatasetSpec, ...]:
        """Detect the format and read *source* into DatasetSpec values.

        Dispatches to whichever registered reader's ``can_read`` matches the
        document shape — contracts, quality specs, and datasources all flow
        through here. A file that advertises a ``kind:`` but matches no reader
        raises via ``detect_reader`` so typos like ``kind: UnknownFormat``
        surface as an error. Files with no ``kind:`` and no matching reader
        are silently skipped (arbitrary ``.github`` YAMLs, etc.).
        """
        if any(reader.can_read(source.data) for reader in self.readers):
            return self.detect_reader(source).read(source, sink)
        if FIELD_KIND in source.data:
            self.detect_reader(source)  # raises: "unrecognized contract format"
        return ()

    def can_resolve(self, data: dict[str, object]) -> bool:
        """Return True if any registered reader handles this document."""
        return any(reader.can_read(data) for reader in self.readers)

    def resolve_field(
        self,
        data: dict[str, object],
        parent_path: str,
        key_name: str,
        sibling_context: dict[str, str] | None = None,
    ) -> FieldDoc | None:
        """Look up field documentation by dispatching to the matching format's schema.

        When *parent_path* sits inside a contract ``implementation:`` block,
        the lookup pivots onto the matching QualitySpec body schema so keys
        like ``unit``, ``column``, and threshold operators receive the same
        descriptions and types they have in standalone QualitySpec files.
        ``sibling_context`` is forwarded to the walker so fields that opt in
        via ``x-contextDescriptions`` get a description selected by a
        sibling value (e.g. ``valueExt`` keyed off ``property``).
        """
        if (dispatched := dispatch_implementation(data, parent_path)) is not None:
            node = resolve_at_path(
                dispatched.subpath,
                dispatched.body_schema,
                yaml_data=dispatched.impl_data,
                sibling_context=sibling_context,
            )
            return node.children.get(key_name)
        for reader, descriptor in self.pairs:
            if reader.can_read(data):
                schema = descriptor.schema_loader()
                node = resolve_at_path(
                    parent_path, schema, yaml_data=data, sibling_context=sibling_context
                )
                return node.children.get(key_name)
        return None

    def resolve_children(self, data: dict[str, object], path: str) -> ResolvedNode:
        """Return all valid children at a schema path for the matching format.

        Inside a contract ``implementation:`` block, children come from the
        matching QualitySpec body schema (``freshness_body``,
        ``aggregate_column_body``, etc.) so completion offers the right keys.
        """
        if (dispatched := dispatch_implementation(data, path)) is not None:
            return resolve_at_path(
                dispatched.subpath, dispatched.body_schema, yaml_data=dispatched.impl_data
            )
        for reader, descriptor in self.pairs:
            if reader.can_read(data):
                schema = descriptor.schema_loader()
                return resolve_at_path(path, schema, yaml_data=data)
        return EMPTY

    def resolve_children_any(self, path: str) -> ResolvedNode:
        """Return valid children from the first schema that has results at this path."""
        for _, descriptor in self.pairs:
            schema = descriptor.schema_loader()
            node = resolve_at_path(path, schema)
            if node.children:
                return node
        return EMPTY

    def turbine_ref_at(self, data: dict[str, object], dotted_path: str) -> dict[str, Any] | None:
        """Walk the matching format's schema and return the ``x-turbine-ref`` extension.

        Inside a contract ``implementation:`` block, walks the QualitySpec body
        schema instead so column references inside the implementation pick up
        the ``x-turbine-ref`` annotations the QualitySpec defines.
        """
        if (dispatched := dispatch_implementation(data, dotted_path)) is not None:
            leaf = resolve_raw_at_path(
                dispatched.subpath, dispatched.body_schema, yaml_data=dispatched.impl_data
            )
            if leaf is None:
                return None
            extension = leaf.get("x-turbine-ref")
            return extension if isinstance(extension, dict) else None
        for reader, descriptor in self.pairs:
            if not reader.can_read(data):
                continue
            schema = descriptor.schema_loader()
            leaf = resolve_raw_at_path(dotted_path, schema, yaml_data=data)
            if leaf is None:
                return None
            extension = leaf.get("x-turbine-ref")
            return extension if isinstance(extension, dict) else None
        return None
