"""DiagnosticCollector: a sink that keeps every diagnostic for later inspection."""

from collections.abc import Iterable
from dataclasses import dataclass, field
from uuid import UUID

from turbine.core.building_blocks import Diagnostic, DiagnosticSink, EventBus, Severity
from turbine.core.quality.events import DiagnosticEmitted


@dataclass(slots=True)
class DiagnosticCollector:
    """Keeps all received diagnostics in a list for later inspection."""

    items: list[Diagnostic] = field(default_factory=list)

    def add(self, diagnostic: Diagnostic) -> None:
        """Append one diagnostic."""
        self.items.append(diagnostic)

    def extend(self, diagnostics: Iterable[Diagnostic]) -> None:
        """Append all diagnostics from an iterable."""
        self.items.extend(diagnostics)

    @property
    def errors(self) -> list[Diagnostic]:
        """Return all diagnostics with ERROR severity."""
        return [d for d in self.items if d.severity == Severity.ERROR]

    @property
    def warnings(self) -> list[Diagnostic]:
        """Return all diagnostics with WARNING severity."""
        return [d for d in self.items if d.severity == Severity.WARNING]

    @property
    def has_errors(self) -> bool:
        """True if any diagnostic has ERROR severity."""
        return any(d.severity == Severity.ERROR for d in self.items)


@dataclass(slots=True)
class EventPublishingSink:
    """Wraps a :class:`DiagnosticSink` and publishes each diagnostic on the bus.

    Single-site substitute for the bare sink the orchestrator hands around:
    every ``sink.add`` still lands in the underlying collector for the
    VerificationResult, and also fires a :class:`DiagnosticEmitted` on the
    bus so telemetry/LSP subscribers see diagnostics the moment they occur.
    """

    underlying: DiagnosticSink
    bus: EventBus
    run_id: UUID | None = None

    def add(self, diagnostic: Diagnostic) -> None:
        """Forward to the underlying sink and publish a ``DiagnosticEmitted``."""
        self.underlying.add(diagnostic)
        self.bus.publish(DiagnosticEmitted(run_id=self.run_id, diagnostic=diagnostic))

    def extend(self, diagnostics: Iterable[Diagnostic]) -> None:
        """Forward each diagnostic through :meth:`add` so every one publishes."""
        for diagnostic in diagnostics:
            self.add(diagnostic)
