"""Document-formatting service used by the LSP format and rangeFormatting handlers.

Dispatches by URI suffix:

- ``.yaml`` / ``.yml`` → ruamel.yaml round-trip (preserves comments and key order,
  normalises whitespace)
- ``.toml`` → ``tomllib.loads`` + ``tomli_w.dumps`` (normalises whitespace, does NOT
  preserve comments — accepted limitation, see ``009b-format-handlers.md``)
- anything else → ``[]`` (handler runs but yields no edits, per LSP convention)

The returned edit, when present, is a single whole-document replace covering
``(0,0)`` → ``(<line_count>, 0)``. Whole-doc replace is simpler than diff-based
edits and correct for every LSP client.

If the formatted output equals the input, the formatter returns ``[]`` so the
client doesn't render a no-op edit.
"""

import tomllib
from io import StringIO
from typing import Protocol

import tomli_w
from lsprotocol import types
from ruamel.yaml import YAML, YAMLError

YAML_SUFFIXES = (".yaml", ".yml")
TOML_SUFFIX = ".toml"


class FormattingService(Protocol):
    """Format a document's text and return the LSP edits needed to apply it."""

    def format_document(self, uri: str, text: str) -> list[types.TextEdit]:
        """Format *text* for the document at *uri*; return zero or one TextEdit."""
        ...


class ContractFormatter(FormattingService):
    """Default formatter — dispatches by URI suffix to ruamel.yaml or tomli_w."""

    def format_document(self, uri: str, text: str) -> list[types.TextEdit]:
        formatted = format_text(uri, text)
        if formatted is None or formatted == text:
            return []
        return [whole_document_edit(text, formatted)]


def format_text(uri: str, text: str) -> str | None:
    """Return the formatted text for *uri*, or ``None`` if the format failed.

    ``None`` means "leave the source alone" — either the suffix is unknown or
    the parser raised. Callers turn ``None`` into an empty edit list.
    """
    lower = uri.lower()
    if lower.endswith(YAML_SUFFIXES):
        return format_yaml(text)
    if lower.endswith(TOML_SUFFIX):
        return format_toml(text)
    return None


def format_yaml(text: str) -> str | None:
    """Round-trip *text* through ruamel.yaml; return ``None`` on parse failure."""
    yaml = YAML(typ="rt")
    yaml.preserve_quotes = True
    try:
        data = yaml.load(text)
    except YAMLError:
        return None
    buffer = StringIO()
    yaml.dump(data, buffer)
    return buffer.getvalue()


def format_toml(text: str) -> str | None:
    """Round-trip *text* through ``tomllib`` + ``tomli_w``; ``None`` on parse failure."""
    try:
        data = tomllib.loads(text)
    except tomllib.TOMLDecodeError:
        return None
    return tomli_w.dumps(data)


def whole_document_edit(source: str, formatted: str) -> types.TextEdit:
    """Build a single TextEdit that replaces the whole *source* with *formatted*.

    The end position is ``(line_count, 0)`` — one past the last line — which
    every spec-compliant client treats as "everything to the end of the
    document", regardless of whether the source ends with a trailing newline.
    """
    line_count = source.count("\n") + (0 if source.endswith("\n") else 1)
    return types.TextEdit(
        range=types.Range(
            start=types.Position(line=0, character=0), end=types.Position(line=line_count, character=0)
        ),
        new_text=formatted,
    )


def clip_edits_to_range(
    full_edits: list[types.TextEdit], requested_range: types.Range, source: str, uri: str
) -> list[types.TextEdit]:
    """Re-format only the slice of *source* covered by *requested_range*.

    The full-document formatter produces a whole-doc replace, which can't be
    naively clipped (formatted line numbers diverge from source line numbers).
    Instead we extract the source slice covered by ``requested_range``, run
    the formatter against it standalone, and emit a single TextEdit covering
    the requested range.

    Returns ``[]`` if there are no full-document edits (source already
    canonical), the slice can't be parsed standalone, or formatting the slice
    yields no change.
    """
    if not full_edits:
        return []
    slice_text = extract_range_text(source, requested_range)
    formatted_slice = format_text(uri, slice_text)
    if formatted_slice is None or formatted_slice == slice_text:
        return []
    return [types.TextEdit(range=requested_range, new_text=formatted_slice)]


def extract_range_text(source: str, requested_range: types.Range) -> str:
    """Return the substring of *source* covered by the LSP *requested_range*."""
    lines = source.splitlines(keepends=True)
    start_line = requested_range.start.line
    end_line = requested_range.end.line
    start_col = requested_range.start.character
    end_col = requested_range.end.character
    if start_line >= len(lines):
        return ""
    if start_line == end_line:
        return lines[start_line][start_col:end_col]
    head = lines[start_line][start_col:]
    middle = "".join(lines[start_line + 1 : end_line])
    tail = lines[end_line][:end_col] if end_line < len(lines) else ""
    return head + middle + tail
