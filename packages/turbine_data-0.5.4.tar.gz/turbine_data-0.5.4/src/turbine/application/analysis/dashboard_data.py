"""Dashboard data services — overview, quality, drift, references."""

from __future__ import annotations

from turbine.core.analysis.contract_health import (
    DiagnosticCountsPort,
    dedupe_overview,
    derive_description,
    derive_status,
)
from turbine.core.analysis.diagnostic_store import DiagnosticSource, DiagnosticStore, DiagnosticStoreKey
from turbine.core.analysis.protocol import (
    ContractDrift,
    ContractHealth,
    ContractQuality,
    ContractReference,
    DriftChangeKind,
    DriftColumn,
    OverviewDataResult,
    ReferenceKind,
    ReferencesDataResult,
    RunCheckResult,
    SchemaDrift,
)
from turbine.core.building_blocks import Diagnostic, DiagnosticKind, TextRange
from turbine.core.contract import ProjectIndex
from turbine.core.quality import CheckOutcome

DIAGNOSTIC_KIND_TO_DRIFT: dict[DiagnosticKind, DriftChangeKind] = {
    DiagnosticKind.VALIDATE_COLUMN_ADDED: DriftChangeKind.ADDED,
    DiagnosticKind.VALIDATE_COLUMN_REMOVED: DriftChangeKind.REMOVED,
    DiagnosticKind.VALIDATE_TYPE_CHANGED: DriftChangeKind.TYPE_CHANGED,
    DiagnosticKind.VALIDATE_NULLABILITY_CHANGED: DriftChangeKind.NULLABLE_CHANGED,
    DiagnosticKind.VALIDATE_PRIMARY_KEY_CHANGED: DriftChangeKind.PK_CHANGED,
    DiagnosticKind.VALIDATE_UNIQUE_CHANGED: DriftChangeKind.UNIQUE_CHANGED,
}


class OverviewDataService:
    """Build the Overview dashboard payload from an index plus run results."""

    def get_overview(
        self,
        index: ProjectIndex,
        check_results: dict[str, RunCheckResult],
        diagnostic_store: DiagnosticStore,
        diagnostic_counts: DiagnosticCountsPort,
    ) -> OverviewDataResult:
        """Return health status for every base contract in the index."""
        contracts: list[ContractHealth] = []
        for contract in index.contracts():
            if contract.target_contract is not None:
                continue
            uri = contract.metadata.source_path.as_uri()
            check_result = check_results.get(uri)
            quality = quality_for(uri, check_result)
            drift = None
            if diagnostic_store.has_source(uri, DiagnosticSource.DRIFT):
                drift = drift_for_diagnostics(uri, contract.metadata.contract_id, diagnostic_store)
            counts = diagnostic_counts.counts_for(uri)
            status = derive_status(
                quality=quality, drift=drift, errors=counts.errors, warnings=counts.warnings
            )
            description = derive_description(
                quality=quality,
                drift=drift,
                errors=counts.errors,
                warnings=counts.warnings,
                status=status,
            )
            contracts.append(
                ContractHealth(
                    contract_id=contract.metadata.contract_id,
                    uri=uri,
                    error_count=counts.errors,
                    warning_count=counts.warnings,
                    check_status=check_status(check_result),
                    status=status,
                    description=description,
                )
            )

        return OverviewDataResult(contracts=dedupe_overview(tuple(contracts)))


class ReferencesDataService:
    """Build the References dashboard payload from the project index."""

    def get_references(self, index: ProjectIndex) -> ReferencesDataResult:
        """Return all cross-contract references in the index."""
        uri_by_id: dict[str, str] = {}
        for contract in index.contracts():
            uri_by_id[contract.metadata.contract_id] = contract.metadata.source_path.as_uri()

        references: list[ContractReference] = []
        for spec in index.quality_specs():
            uri_by_id[spec.metadata.contract_id] = spec.metadata.source_path.as_uri()
            if spec.target_contract is None:
                continue
            references.append(
                ContractReference(
                    source_contract_id=spec.metadata.contract_id,
                    target_contract_id=spec.target_contract,
                    reference_type=ReferenceKind.QUALITY_SPEC,
                    source_uri=uri_by_id.get(spec.metadata.contract_id),
                    target_uri=uri_by_id.get(spec.target_contract),
                )
            )

        return ReferencesDataResult(references=tuple(references))


def check_status(check_result: RunCheckResult | None) -> CheckOutcome | None:
    """Map a RunCheckResult to a single PASSED/FAILED, or None if no run yet."""
    if check_result is None:
        return None
    return CheckOutcome.PASSED if check_result.passed else CheckOutcome.FAILED


def quality_for(uri: str, check_result: RunCheckResult | None) -> ContractQuality | None:
    """Project a single ``RunCheckResult`` into a ``ContractQuality`` row."""
    if check_result is None:
        return None
    return ContractQuality.from_run_result(check_result, uri)


def drift_for_diagnostics(
    uri: str, contract_id: str, diagnostic_store: DiagnosticStore
) -> ContractDrift:
    """Project drift-source diagnostics for one URI into dashboard drift data."""
    key = DiagnosticStoreKey(uri=uri, source=DiagnosticSource.DRIFT)
    diagnostics = diagnostic_store.entries.get(key, ())
    schemas = schema_drifts_from_diagnostics(diagnostics)
    error = drift_error_from_diagnostics(diagnostics)
    return ContractDrift(
        contract_id=contract_id, uri=uri, schemas=schemas, has_drift=bool(schemas), error=error
    )


def schema_drifts_from_diagnostics(diagnostics: tuple[Diagnostic, ...]) -> tuple[SchemaDrift, ...]:
    """Group drift diagnostics with column data into SchemaDrift rows."""
    by_schema: dict[str, list[DriftColumn]] = {}
    for diagnostic in diagnostics:
        data = diagnostic.data
        if data is None or data.kind not in DIAGNOSTIC_KIND_TO_DRIFT or data.field_name is None:
            continue
        schema_name = data.schema_name or ""
        by_schema.setdefault(schema_name, []).append(
            DriftColumn(
                name=data.field_name,
                change=DIAGNOSTIC_KIND_TO_DRIFT[data.kind],
                expected_type=data.contract_value,
                actual_type=data.db_value,
                start_line=primary_start_line(diagnostic),
                start_col=primary_start_col(diagnostic),
                end_line=primary_end_line(diagnostic),
                end_col=primary_end_col(diagnostic),
            )
        )
    return tuple(
        SchemaDrift(schema_name=schema_name, columns=tuple(columns))
        for schema_name, columns in by_schema.items()
    )


def drift_error_from_diagnostics(diagnostics: tuple[Diagnostic, ...]) -> str | None:
    """Return the first non-column drift diagnostic message, if any."""
    for diagnostic in diagnostics:
        data = diagnostic.data
        if data is None or data.kind not in DIAGNOSTIC_KIND_TO_DRIFT:
            return diagnostic.message
    return None


def primary_start_line(diagnostic: Diagnostic) -> int | None:
    """Return the primary diagnostic range start line, if present."""
    primary = primary_range(diagnostic)
    return None if primary is None else primary.start_line


def primary_start_col(diagnostic: Diagnostic) -> int | None:
    """Return the primary diagnostic range start column, if present."""
    primary = primary_range(diagnostic)
    return None if primary is None else primary.start_col


def primary_end_line(diagnostic: Diagnostic) -> int | None:
    """Return the primary diagnostic range end line, if present."""
    primary = primary_range(diagnostic)
    return None if primary is None else primary.end_line


def primary_end_col(diagnostic: Diagnostic) -> int | None:
    """Return the primary diagnostic range end column, if present."""
    primary = primary_range(diagnostic)
    return None if primary is None else primary.end_col


def primary_range(diagnostic: Diagnostic) -> TextRange | None:
    """Return the primary diagnostic text range, if present."""
    annotation = next(
        (item for item in diagnostic.annotations if item.is_primary and item.span.range is not None),
        None,
    )
    if annotation is None:
        return None
    return annotation.span.range
