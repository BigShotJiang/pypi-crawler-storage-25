"""Sidebar Resource Creation use case for Python-owned VS Code commands."""

import asyncio
from collections.abc import Callable, Iterable, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from turbine.application.analysis.lsp_client_port import DatasourcePick, LspClient, TableRef
from turbine.application.diagnostics import DiagnosticCollector
from turbine.core.analysis.context.text import uri_to_path
from turbine.core.analysis.features.code_action import generate_data_contract_content
from turbine.core.analysis.ports import CodeWriteError, CodeWriter
from turbine.core.building_blocks import TurbineError
from turbine.core.codegen import NewContractConfig, NewDatasourceConfig, StagedFile
from turbine.core.common import (
    ColumnDef,
    DatabaseBackend,
    DatabaseBackendFactory,
    DatasourceConfig,
    DatasourceRepository,
    DataSourceType,
    ProjectLayout,
    TableIdentifier,
)
from turbine.core.common.file_edits import SnippetInsertion, TextPosition

DATASOURCE_TYPE_ACTIONS: tuple[str, ...] = ("Snowflake", "Postgres", "DuckDB")
DATASOURCE_TYPES_BY_ACTION: dict[str, DataSourceType] = {
    "Snowflake": DataSourceType.SNOWFLAKE,
    "Postgres": DataSourceType.POSTGRES,
    "DuckDB": DataSourceType.DUCKDB,
}
CONFLICT_ACTIONS: tuple[str, ...] = ("Open Existing", "Choose Different Name", "Overwrite")
OPEN_EXISTING = "Open Existing"
CHOOSE_DIFFERENT_NAME = "Choose Different Name"
OVERWRITE = "Overwrite"


class DatasourceScaffoldRenderer(Protocol):
    """Renderer seam for canonical datasource scaffolds."""

    def render(self, items: Sequence[NewDatasourceConfig], output_dir: Path) -> Iterable[StagedFile]:
        """Render datasource scaffold files."""
        ...

    def env_vars(self, db_type: DataSourceType) -> list[str]:
        """Return env-var names used by a datasource scaffold."""
        ...


class ContractScaffoldRenderer(Protocol):
    """Renderer seam for canonical blank Contract scaffolds."""

    def render(self, items: Sequence[NewContractConfig], output_dir: Path) -> Iterable[StagedFile]:
        """Render Contract scaffold files."""
        ...


@dataclass(frozen=True, slots=True)
class SidebarCreationTarget:
    """Resolved Turbine project target for sidebar creation."""

    repo_root: Path
    layout: ProjectLayout


@dataclass(frozen=True, slots=True)
class SidebarCreationOutcome:
    """Observable result of a sidebar creation command."""

    uri: str | None
    message: str
    created: bool = False
    opened_existing: bool = False


@dataclass(frozen=True, slots=True)
class PendingResource:
    """A rendered resource waiting for conflict handling and write."""

    path: Path
    content: str


@dataclass(frozen=True, slots=True)
class ContractFromDatasourceRequest:
    """Inputs for Create Contract from Datasource."""

    target_root: Path
    datasource_uri: str | None = None


class SidebarResourceCreation:
    """Create Datasource and blank Contract resources from a selected Turbine root."""

    def __init__(
        self,
        lsp_client: LspClient,
        code_writer: CodeWriter | None,
        layout_resolver: Callable[[Path], ProjectLayout | None],
        datasource_renderer: DatasourceScaffoldRenderer,
        contract_renderer: ContractScaffoldRenderer,
        datasource_repo_for: Callable[[Path], DatasourceRepository] | None = None,
        backend_factory: DatabaseBackendFactory | None = None,
    ) -> None:
        """Store editor, layout, and rendering dependencies.

        ``datasource_repo_for`` resolves an anchor path (the sidebar
        target root, or a datasource YAML URI converted to a path) to
        the per-project ``DatasourceRepository`` for that project. The
        LSP composition root binds it to
        ``project_datasource_services.services_for(path).repo`` so the
        Create Contract from Datasource picker only ever lists
        datasources from the project the user clicked into.
        """
        self.lsp_client = lsp_client
        self.code_writer = code_writer
        self.layout_resolver = layout_resolver
        self.datasource_renderer = datasource_renderer
        self.contract_renderer = contract_renderer
        self.datasource_repo_for = datasource_repo_for
        self.backend_factory = backend_factory

    async def create_datasource(self, target_root: Path) -> SidebarCreationOutcome:
        """Prompt for a datasource type/name and create the YAML scaffold."""
        target = self.resolve_target(target_root)
        if target is None:
            return self.show_initialization_needed(target_root)

        action = await self.lsp_client.show_message_request("Datasource type", DATASOURCE_TYPE_ACTIONS)
        db_type = DATASOURCE_TYPES_BY_ACTION.get(action or "")
        if db_type is None:
            return SidebarCreationOutcome(uri=None, message="Datasource creation cancelled")

        while name := await self.lsp_client.prompt_text("Datasource name", db_type.scaffold_name):
            staged = self.render_one_datasource(name, db_type, target.layout.datasources_dir)
            decision = await self.resolve_conflict(staged.path)
            if decision == CHOOSE_DIFFERENT_NAME:
                continue
            if decision is None:
                return SidebarCreationOutcome(uri=None, message="Datasource creation cancelled")
            if decision == OPEN_EXISTING:
                return await self.open_existing(staged.path)
            return await self.write_datasource(
                target, staged, overwrite=decision == OVERWRITE, db_type=db_type
            )

        return SidebarCreationOutcome(uri=None, message="Datasource creation cancelled")

    async def create_blank_contract(self, target_root: Path) -> SidebarCreationOutcome:
        """Prompt for a Contract id and create a canonical blank Contract YAML scaffold."""
        target = self.resolve_target(target_root)
        if target is None:
            return self.show_initialization_needed(target_root)

        while name := await self.lsp_client.prompt_text("Contract id", "orders"):
            staged = self.render_one_contract(name, target.layout.contracts_dir)
            decision = await self.resolve_conflict(staged.path)
            if decision == CHOOSE_DIFFERENT_NAME:
                continue
            if decision is None:
                return SidebarCreationOutcome(uri=None, message="Blank Contract creation cancelled")
            if decision == OPEN_EXISTING:
                return await self.open_existing(staged.path)
            return await self.write_contract(target, staged, overwrite=decision == OVERWRITE)

        return SidebarCreationOutcome(uri=None, message="Blank Contract creation cancelled")

    async def create_contract_from_datasource(
        self, request: ContractFromDatasourceRequest
    ) -> SidebarCreationOutcome:
        """Generate one Contract from one or more tables in a Datasource."""
        target = self.resolve_target(request.target_root)
        if target is None:
            return self.show_initialization_needed(request.target_root)
        return await self.create_contract_from_datasource_for_target(target, request.datasource_uri)

    async def create_contract_from_datasource_for_target(
        self, target: SidebarCreationTarget, datasource_uri: str | None
    ) -> SidebarCreationOutcome:
        """Run the resolved-target Contract from Datasource state machine."""
        selected_uri = datasource_uri or await self.pick_datasource_uri(target.repo_root)
        if selected_uri is None:
            return SidebarCreationOutcome(uri=None, message="Contract from Datasource cancelled")
        backend_context = self.open_datasource_backend(selected_uri)
        if backend_context is None:
            return SidebarCreationOutcome(uri=None, message="Cannot open datasource")
        config, backend = backend_context
        tables, table_message = await self.pick_datasource_tables(backend, config.name)
        if not tables:
            return SidebarCreationOutcome(
                uri=None, message=table_message or "Contract from Datasource cancelled"
            )
        contract_name = await self.lsp_client.prompt_text(
            "Contract id", placeholder=f"{tables[0].schema}-{tables[0].table}"
        )
        if contract_name is None:
            return SidebarCreationOutcome(uri=None, message="Contract from Datasource cancelled")
        table_schemas = await self.introspect_picked_tables(backend, tables)
        if table_schemas is None:
            return SidebarCreationOutcome(uri=None, message="Cannot introspect selected tables")
        return await self.write_generated_contract(target, contract_name, table_schemas)

    async def pick_datasource_uri(self, anchor: Path) -> str | None:
        """Ask the user which Datasource of the project at *anchor* should seed the Contract."""
        if self.datasource_repo_for is None:
            self.lsp_client.show_message("Datasource operations not configured")
            return None
        repo = self.datasource_repo_for(anchor)
        collector = DiagnosticCollector()
        configs = await asyncio.to_thread(repo.list_datasources, collector)
        options = tuple(datasource_pick(config) for config in configs if config.source_path is not None)
        if not options:
            self.lsp_client.show_message("No Datasources found. Create a Datasource first.")
            return None
        picked = await self.lsp_client.pick_datasource(options)
        return picked.uri if picked is not None else None

    def open_datasource_backend(
        self, datasource_uri: str
    ) -> tuple[DatasourceConfig, DatabaseBackend] | None:
        """Load a Datasource file and create its backend, showing failures to the user."""
        if self.datasource_repo_for is None or self.backend_factory is None:
            self.lsp_client.show_message("Datasource operations not configured")
            return None
        datasource_path = uri_to_path(datasource_uri)
        repo = self.datasource_repo_for(datasource_path)
        collector = DiagnosticCollector()
        try:
            config = repo.load_from_path(datasource_path, collector)
            backend = self.backend_factory.create(config, collector)
        except (OSError, TurbineError) as exc:
            message = (
                exc.diagnostics[0].message
                if isinstance(exc, TurbineError) and exc.diagnostics
                else str(exc)
            )
            self.lsp_client.show_message(f"Cannot open datasource: {message}")
            return None
        return config, backend

    async def pick_datasource_tables(
        self, backend: DatabaseBackend, datasource_name: str
    ) -> tuple[tuple[TableRef, ...], str | None]:
        """Ask the user to pick one or more tables from a Datasource backend."""
        try:
            all_tables = await asyncio.to_thread(backend.list_tables, None)
        except (OSError, TurbineError) as exc:
            detail = (
                exc.diagnostics[0].message
                if isinstance(exc, TurbineError) and exc.diagnostics
                else str(exc)
            )
            message = f"Cannot list tables for {datasource_name}: {detail}"
            self.lsp_client.show_message(message)
            return (), message
        if not all_tables:
            message = f"No tables found in {datasource_name}"
            self.lsp_client.show_message(message)
            return (), message
        refs = tuple(TableRef(schema=table.schema, table=table.table) for table in all_tables)
        picked = await self.lsp_client.pick_tables(refs)
        return picked or (), None

    async def introspect_picked_tables(
        self, backend: DatabaseBackend, picked: tuple[TableRef, ...]
    ) -> tuple[tuple[TableIdentifier, tuple[ColumnDef, ...]], ...] | None:
        """Introspect selected tables for canonical Contract rendering."""
        table_ids = tuple(TableIdentifier(schema=ref.schema, table=ref.table) for ref in picked)
        try:
            results = await asyncio.gather(
                *(asyncio.to_thread(backend.introspect_schema, table_id) for table_id in table_ids)
            )
        except (OSError, TurbineError) as exc:
            detail = (
                exc.diagnostics[0].message
                if isinstance(exc, TurbineError) and exc.diagnostics
                else str(exc)
            )
            self.lsp_client.show_message(f"Cannot introspect selected tables: {detail}")
            return None
        table_schemas: list[tuple[TableIdentifier, tuple[ColumnDef, ...]]] = []
        for table_id, columns in zip(table_ids, results, strict=True):
            if not columns:
                self.lsp_client.show_message(f"Cannot introspect {table_id}")
                return None
            table_schemas.append((table_id, columns))
        return tuple(table_schemas)

    async def write_generated_contract(
        self,
        target: SidebarCreationTarget,
        contract_name: str,
        table_schemas: tuple[tuple[TableIdentifier, tuple[ColumnDef, ...]], ...],
    ) -> SidebarCreationOutcome:
        """Handle conflicts, write, open, and message for a generated Contract."""
        while True:
            spec_path = target.layout.contracts_dir / f"{contract_name}.yml"
            content = generate_data_contract_content(contract_name, table_schemas)
            decision = await self.resolve_conflict(spec_path)
            if decision == CHOOSE_DIFFERENT_NAME:
                next_name = await self.lsp_client.prompt_text("Contract id", contract_name)
                if next_name is None:
                    return SidebarCreationOutcome(uri=None, message="Contract from Datasource cancelled")
                contract_name = next_name
                continue
            if decision is None:
                return SidebarCreationOutcome(uri=None, message="Contract from Datasource cancelled")
            if decision == OPEN_EXISTING:
                return await self.open_existing(spec_path)
            staged = PendingResource(path=spec_path, content=content)
            return await self.write_generated_contract_file(staged, overwrite=decision == OVERWRITE)

    async def write_generated_contract_file(
        self, staged: PendingResource, *, overwrite: bool
    ) -> SidebarCreationOutcome:
        """Write and open a generated Contract from Datasource."""
        staged.path.parent.mkdir(parents=True, exist_ok=True)
        uri = staged.path.as_uri()
        applied = await self.lsp_client.apply_edit(uri, staged.content, overwrite=overwrite)
        if not applied:
            message = f"Failed to create Contract file: {staged.path.name}"
            self.lsp_client.show_message(message)
            return SidebarCreationOutcome(uri=uri, message=message)
        await self.lsp_client.show_document(uri)
        message = f"Contract created: {staged.path.name}"
        self.lsp_client.show_message(message)
        return SidebarCreationOutcome(uri=uri, message=message, created=True)

    def resolve_target(self, target_root: Path) -> SidebarCreationTarget | None:
        """Resolve the selected root into a Turbine layout."""
        layout = self.layout_resolver(target_root)
        if layout is None:
            return None
        return SidebarCreationTarget(repo_root=target_root, layout=layout)

    def show_initialization_needed(self, target_root: Path) -> SidebarCreationOutcome:
        """Return a clear initialization-needed result without creating directories."""
        message = f"No Turbine project layout found at {target_root}. Run Project Initialization first."
        self.lsp_client.show_message(message)
        return SidebarCreationOutcome(uri=None, message=message)

    def render_one_datasource(
        self, name: str, db_type: DataSourceType, output_dir: Path
    ) -> PendingResource:
        """Render one datasource using the injected canonical renderer."""
        staged = next(
            iter(
                self.datasource_renderer.render(
                    [NewDatasourceConfig(name=name, db_type=db_type)], output_dir
                )
            )
        )
        return PendingResource(path=staged.path, content=staged.content)

    def render_one_contract(self, name: str, output_dir: Path) -> PendingResource:
        """Render one blank Contract using the injected canonical renderer."""
        staged = next(iter(self.contract_renderer.render([NewContractConfig(name=name)], output_dir)))
        return PendingResource(path=staged.path, content=staged.content)

    async def resolve_conflict(self, path: Path) -> str | None:
        """Return a conflict decision for an existing file, or None when cancelled."""
        exists = await asyncio.to_thread(path.exists)
        if not exists:
            return ""
        return await self.lsp_client.show_message_request(
            f"'{path.name}' already exists.", CONFLICT_ACTIONS
        )

    async def open_existing(self, path: Path) -> SidebarCreationOutcome:
        """Open an existing resource and report that no write happened."""
        uri = path.as_uri()
        await self.lsp_client.show_document(uri)
        message = f"Opened existing file: {path.name}"
        self.lsp_client.show_message(message)
        return SidebarCreationOutcome(uri=uri, message=message, opened_existing=True)

    async def write_datasource(
        self,
        target: SidebarCreationTarget,
        staged: PendingResource,
        *,
        overwrite: bool,
        db_type: DataSourceType,
    ) -> SidebarCreationOutcome:
        """Write, open, update env example, and place the datasource cursor."""
        staged.path.parent.mkdir(parents=True, exist_ok=True)
        uri = staged.path.as_uri()
        applied = await self.lsp_client.apply_edit(uri, staged.content, overwrite=overwrite)
        if not applied:
            message = f"Failed to create datasource file: {staged.path.name}"
            self.lsp_client.show_message(message)
            return SidebarCreationOutcome(uri=uri, message=message)
        self.append_env_example(target.repo_root, self.datasource_renderer.env_vars(db_type))
        await self.lsp_client.show_document(uri)
        await self.place_datasource_cursor(uri, staged.content)
        message = f"Datasource created: {staged.path.name}. Next: Test Connection."
        self.lsp_client.show_message(message)
        return SidebarCreationOutcome(uri=uri, message=message, created=True)

    async def write_contract(
        self, target: SidebarCreationTarget, staged: PendingResource, *, overwrite: bool
    ) -> SidebarCreationOutcome:
        """Write and open a blank Contract, then show the appropriate next step."""
        staged.path.parent.mkdir(parents=True, exist_ok=True)
        uri = staged.path.as_uri()
        applied = await self.lsp_client.apply_edit(uri, staged.content, overwrite=overwrite)
        if not applied:
            message = f"Failed to create Contract file: {staged.path.name}"
            self.lsp_client.show_message(message)
            return SidebarCreationOutcome(uri=uri, message=message)
        await self.lsp_client.show_document(uri)
        if self.has_datasources(target.layout.datasources_dir):
            message = f"Blank Contract created: {staged.path.name}"
        else:
            message = f"Blank Contract created: {staged.path.name}. Next: New Datasource."
        self.lsp_client.show_message(message)
        return SidebarCreationOutcome(uri=uri, message=message, created=True)

    def has_datasources(self, datasources_dir: Path) -> bool:
        """Return whether a target project already has datasource YAML files."""
        if not datasources_dir.is_dir():
            return False
        return any(datasources_dir.glob("*.yml")) or any(datasources_dir.glob("*.yaml"))

    def append_env_example(self, repo_root: Path, variables: list[str]) -> None:
        """Append missing env-var names to .env.example without touching .env."""
        if not variables:
            return
        path = repo_root / ".env.example"
        existing = path.read_text() if path.exists() else ""
        existing_names = {
            line.split("=", maxsplit=1)[0] for line in existing.splitlines() if "=" in line
        }
        missing = [variable for variable in variables if variable not in existing_names]
        if not missing:
            return
        prefix = "" if not existing or existing.endswith("\n") else "\n"
        path.write_text(existing + prefix + "".join(f"{variable}=\n" for variable in missing))

    async def place_datasource_cursor(self, uri: str, content: str) -> None:
        """Place the editor cursor at the first connection value when snippet support exists."""
        if self.code_writer is None:
            return
        position = first_connection_value_position(content)
        if position is None:
            return
        try:
            await self.code_writer.insert_snippet(
                SnippetInsertion(uri=uri, position=position, snippet_text="")
            )
        except CodeWriteError as exc:
            self.lsp_client.show_message(f"Datasource created, but cursor placement failed: {exc}")


def datasource_pick(config: DatasourceConfig) -> DatasourcePick:
    """Map a Datasource config to the editor picker payload."""
    uri = config.source_path.as_uri() if config.source_path is not None else ""
    return DatasourcePick(name=config.name, ds_type=config.ds_type.value, uri=uri)


def first_connection_value_position(content: str) -> TextPosition | None:
    """Return the 1-indexed position of the first YAML value under ``connection``."""
    in_connection = False
    for line_number, line in enumerate(content.splitlines(), start=1):
        if line.strip() == "connection:":
            in_connection = True
            continue
        if not in_connection:
            continue
        stripped = line.strip()
        if not stripped:
            continue
        if not line.startswith(" ") or ":" not in line:
            return None
        value_start = line.index(":") + 1
        while value_start < len(line) and line[value_start] == " ":
            value_start += 1
        return TextPosition(line=line_number, col=value_start + 1)
    return None
