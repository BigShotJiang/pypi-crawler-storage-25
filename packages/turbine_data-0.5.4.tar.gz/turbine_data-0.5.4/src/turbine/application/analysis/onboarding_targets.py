"""Resolve semantic onboarding targets to editor ranges or UI target ids."""

from __future__ import annotations

from pathlib import Path
from typing import Protocol

from turbine.core.analysis.source_spans import iter_named_values
from turbine.core.building_blocks import SourceMap, TextRange, TurbineError
from turbine.core.common import RawSource
from turbine.core.onboarding.targets import (
    CheckTarget,
    ColumnFieldTarget,
    ContractFieldTarget,
    DatasetTarget,
    HighlightTarget,
    QualitySpecFieldTarget,
    RangeKind,
    ResolvedHighlight,
    ResolvedHighlightKind,
    SourceRangeTarget,
    SourceTextTarget,
    SqlTextTarget,
    UiTarget,
    YamlFieldTarget,
)

DATASET_NAME_PATH_PARTS = 3
MIN_COLUMN_CHECK_PATH_PARTS = 5


class RawSourceParser(Protocol):
    """Parses source text into RawSource with a source map."""

    def __call__(self, path: Path, text: str | None = None) -> RawSource:
        """Return parsed source with source positions."""
        ...


class OnboardingTargetResolver:
    """Resolve onboarding highlight targets against the sandbox."""

    def __init__(self, source_parser: RawSourceParser) -> None:
        self.source_parser = source_parser

    def resolve(self, tour_root: Path, target: HighlightTarget) -> ResolvedHighlight | None:
        """Return the editor range or UI target for ``target``."""
        if isinstance(target, UiTarget):
            return ResolvedHighlight(kind=ResolvedHighlightKind.UI_TARGET, target_id=target.target_id)
        if isinstance(target, SqlTextTarget | SourceTextTarget):
            return self.resolve_text(tour_root, target)
        if isinstance(target, SourceRangeTarget):
            return self.resolve_range(tour_root, target)

        source = self.parse_target_source(tour_root, target.file)
        if source is None:
            return None
        text_range = self.resolve_source_target(source, target)
        if text_range is None:
            return None
        return ResolvedHighlight(
            kind=ResolvedHighlightKind.EDITOR_RANGE,
            file=target.file,
            range=to_protocol_range(text_range),
        )

    def parse_target_source(self, tour_root: Path, file: str) -> RawSource | None:
        """Parse a sandbox file for source-map resolution."""
        path = tour_root / file
        if not path.exists():
            return None
        try:
            return self.source_parser(path, path.read_text())
        except (OSError, TurbineError, TypeError, ValueError):
            return None

    def resolve_source_target(self, source: RawSource, target: HighlightTarget) -> TextRange | None:
        """Resolve a non-SQL file target against a parsed source."""
        text_range: TextRange | None = None
        if isinstance(target, YamlFieldTarget):
            text_range = range_for_path(source.source_map, target.path, target.range_kind)
        elif isinstance(target, ContractFieldTarget | QualitySpecFieldTarget):
            text_range = range_for_path(source.source_map, target.field, target.range_kind)
        elif isinstance(target, DatasetTarget):
            text_range = find_dataset_range(source, target.dataset)
        elif isinstance(target, ColumnFieldTarget):
            text_range = find_column_field_range(source, target)
        elif isinstance(target, CheckTarget):
            text_range = find_check_range(source, target)
        return text_range

    def resolve_text(
        self, tour_root: Path, target: SqlTextTarget | SourceTextTarget
    ) -> ResolvedHighlight | None:
        """Resolve a source text snippet to its line range."""
        path = tour_root / target.file
        if not path.exists():
            return None
        try:
            lines = path.read_text().splitlines()
        except OSError:
            return None
        for line_number, line in enumerate(lines, start=1):
            start_index = line.find(target.text)
            if start_index < 0:
                continue
            start_col = start_index + 1
            end_col = start_col + len(target.text)
            return ResolvedHighlight(
                kind=ResolvedHighlightKind.EDITOR_RANGE,
                file=target.file,
                range=(line_number, start_col, line_number, end_col),
            )
        return None

    def resolve_range(self, tour_root: Path, target: SourceRangeTarget) -> ResolvedHighlight | None:
        """Resolve an explicit source line range to an editor highlight."""
        path = tour_root / target.file
        if not path.exists():
            return None
        try:
            lines = path.read_text().splitlines()
        except OSError:
            return None
        if target.start_line < 1 or target.end_line < target.start_line:
            return None
        if target.end_line > len(lines):
            return None
        end_col = target.end_col if target.end_col is not None else len(lines[target.end_line - 1]) + 1
        if target.start_col < 1 or end_col < target.start_col:
            return None
        return ResolvedHighlight(
            kind=ResolvedHighlightKind.EDITOR_RANGE,
            file=target.file,
            range=(target.start_line, target.start_col, target.end_line, end_col),
        )


def range_for_path(source_map: SourceMap, path: str, range_kind: RangeKind) -> TextRange | None:
    """Return the requested source-map range for ``path``."""
    if range_kind == "key":
        return source_map.range_for_key(path)
    if range_kind == "block":
        return source_map.range_for_block(path)
    return source_map.range_for_value(path) or source_map.range_for_key(path)


def find_dataset_range(source: RawSource, dataset: str) -> TextRange | None:
    """Find a Contract Dataset declaration by schema-qualified table name."""
    for path, value, value_range in iter_named_values(source, is_dataset_name_path):
        if value == dataset:
            return value_range or source.source_map.range_for_key(path)
    dataset_range = source.source_map.range_for_value("dataset")
    if dataset_range is None:
        return None
    return dataset_range if value_at_range(source, dataset_range) == dataset else None


def find_column_field_range(source: RawSource, target: ColumnFieldTarget) -> TextRange | None:
    """Find a column field by Dataset and column name."""
    for column_base in column_bases_for_dataset(source, target.dataset):
        name_range = source.source_map.range_for_value(f"{column_base}.name")
        if name_range is None or value_at_range(source, name_range) != target.column:
            continue
        if target.field == "name":
            return range_for_path(source.source_map, f"{column_base}.name", target.range_kind)
        return range_for_path(source.source_map, f"{column_base}.{target.field}", target.range_kind)
    return None


def find_check_range(source: RawSource, target: CheckTarget) -> TextRange | None:
    """Find a check by check type plus optional name/column constraints."""
    for path in source.source_map.key_paths():
        if not path.endswith(f".{target.check_type}"):
            continue
        if not check_matches(source, path, target):
            continue
        return source.source_map.range_for_key(path) or source.source_map.range_for_block(path)
    return None


def check_matches(source: RawSource, check_path: str, target: CheckTarget) -> bool:
    """Return True when ``check_path`` satisfies the semantic check target."""
    if target.name is not None:
        name_range = source.source_map.range_for_value(f"{check_path}.name")
        if name_range is None or value_at_range(source, name_range) != target.name:
            return False
    if target.column is not None:
        column_base = parent_column_base(check_path)
        if column_base is None:
            return False
        column_range = source.source_map.range_for_value(f"{column_base}.name")
        if column_range is None or value_at_range(source, column_range) != target.column:
            return False
    return True


def column_bases_for_dataset(source: RawSource, dataset: str) -> tuple[str, ...]:
    """Return column base paths for a Contract or Quality Spec source."""
    schema_index = schema_index_for_dataset(source, dataset)
    if schema_index is not None:
        prefix = f"schema.{schema_index}.properties."
        return tuple(
            path.removesuffix(".name")
            for path in source.source_map.key_paths()
            if path.startswith(prefix) and path.endswith(".name")
        )
    dataset_range = source.source_map.range_for_value("dataset")
    if dataset_range is None or value_at_range(source, dataset_range) != dataset:
        return ()
    return tuple(
        path.removesuffix(".name")
        for path in source.source_map.key_paths()
        if path.startswith("columns.") and path.endswith(".name")
    )


def schema_index_for_dataset(source: RawSource, dataset: str) -> str | None:
    """Return the schema index for ``dataset`` in a Contract source."""
    for path, value, _range in iter_named_values(source, is_dataset_name_path):
        if value != dataset:
            continue
        parts = path.split(".")
        if len(parts) == DATASET_NAME_PATH_PARTS:
            return parts[1]
    return None


def parent_column_base(check_path: str) -> str | None:
    """Return ``columns.N`` for a column-level Quality Spec check path."""
    parts = check_path.split(".")
    if len(parts) < MIN_COLUMN_CHECK_PATH_PARTS or parts[0] != "columns" or parts[2] != "checks":
        return None
    return ".".join(parts[:2])


def is_dataset_name_path(path: str) -> bool:
    """Return True for paths like ``schema.0.name``."""
    parts = path.split(".")
    return len(parts) == DATASET_NAME_PATH_PARTS and parts[0] == "schema" and parts[2] == "name"


def value_at_range(source: RawSource, text_range: TextRange) -> str:
    """Return stripped source text covered by ``text_range``."""
    lines = source.text.splitlines()
    if not 1 <= text_range.start_line <= len(lines):
        return ""
    line = lines[text_range.start_line - 1]
    return line[text_range.start_col - 1 : text_range.end_col - 1].strip().strip("\"'")


def to_protocol_range(text_range: TextRange) -> tuple[int, int, int, int]:
    """Convert a TextRange into the onboarding wire range tuple."""
    return (text_range.start_line, text_range.start_col, text_range.end_line, text_range.end_col)
