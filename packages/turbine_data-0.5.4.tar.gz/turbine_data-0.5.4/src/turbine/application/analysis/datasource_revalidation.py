"""Auto-revalidate a datasource when its connection config changes in the dirty buffer.

Watches ``textDocument/didChange`` events for datasource YAML files. When the
``connection`` block changes (detected by hash comparison), schedules a debounced
re-introspection that updates the ``IntrospectionCache`` so drift diagnostics
fire immediately on the next pull for contract files.
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from loguru import logger

from turbine.core.analysis.context import uri_to_path
from turbine.core.common import ConnectionProps, DatasourceConfig, TableIdentifier
from turbine.core.common.introspection_cache import DbTableInfo, IntrospectionCache
from turbine.core.common.ports import IntrospectionError, IntrospectionResult, ListTablesResult
from turbine.core.contract import ProjectIndex
from turbine.core.onboarding.ports import Scheduler

IntrospectConfigFn = Callable[
    [DatasourceConfig, TableIdentifier], IntrospectionResult | IntrospectionError
]
ListTablesConfigFn = Callable[[DatasourceConfig, frozenset[str]], ListTablesResult]


class DatasourceRevalidationService:
    """Re-introspects a datasource when its connection config changes in the dirty buffer.

    Called from ``did_change`` on every keystroke. Filters non-datasource files,
    parses the dirty buffer, compares a hash of the ``connection`` block to the
    last attempt, and schedules a debounced re-introspection on change.
    """

    def __init__(
        self,
        datasources_dir: Path,
        parse_config: Callable[[Path, str], DatasourceConfig | None],
        introspect_config: IntrospectConfigFn,
        list_tables_config: ListTablesConfigFn,
        invalidate_datasource: Callable[[str], None],
        index_provider: Callable[[], ProjectIndex],
        cache_provider: Callable[[], IntrospectionCache | None],
        store_cache: Callable[[IntrospectionCache], None],
        refresh_diagnostics: Callable[[], None],
        report_status: Callable[[str, str | None], None],
        scheduler: Scheduler,
        datasources_dir_for: Callable[[Path], Path] | None = None,
        debounce_ms: int = 500,
    ) -> None:
        self.datasources_dir = datasources_dir.resolve()
        self.datasources_dir_for = datasources_dir_for
        self.parse_config = parse_config
        self.introspect_config = introspect_config
        self.list_tables_config = list_tables_config
        self.invalidate_datasource = invalidate_datasource
        self.index_provider = index_provider
        self.cache_provider = cache_provider
        self.store_cache = store_cache
        self.refresh_diagnostics = refresh_diagnostics
        self.report_status = report_status
        self.scheduler = scheduler
        self.debounce_ms = debounce_ms
        self.connection_hashes: dict[str, str] = {}
        self.latest_configs: dict[str, DatasourceConfig] = {}
        self.latest_uris: dict[str, str] = {}

    def on_buffer_changed(self, uri: str, text: str) -> None:
        """Detect datasource connection changes in a dirty buffer and schedule revalidation."""
        path = uri_to_path(uri)
        if not self.is_datasource(path):
            return

        config = self.parse_config(path, text)
        if config is None:
            return

        conn_hash = hash_connection(config.connection)
        if self.connection_hashes.get(config.name) == conn_hash:
            return

        self.connection_hashes[config.name] = conn_hash
        self.latest_configs[config.name] = config
        self.latest_uris[config.name] = uri
        self.scheduler.schedule(self.debounce_ms, lambda name=config.name: self.revalidate(name))

    def is_datasource(self, path: Path) -> bool:
        """Return True when *path* is a YAML file inside any project's datasources directory.

        With per-URI project resolution, ``path`` may belong to a nested
        project (the onboarding sandbox, a monorepo child) whose own
        ``datasources/`` lives outside the workspace-root configured dir.
        ``datasources_dir_for`` resolves the owning project's directory
        when supplied; ``datasources_dir`` stays as the fallback.
        """
        if path.suffix != ".yml":
            return False
        resolved_parent = path.resolve().parent
        if resolved_parent == self.datasources_dir:
            return True
        if self.datasources_dir_for is None:
            return False
        project_dir = self.datasources_dir_for(path).resolve()
        return resolved_parent == project_dir

    def revalidate(self, datasource_name: str) -> None:
        """Re-introspect the datasource and update the cache.

        Runs in a background thread (via TimerScheduler). Catches all
        exceptions so the timer thread survives any failure.
        """
        try:
            self.run_revalidation(datasource_name)
        except Exception:  # noqa: BLE001
            logger.exception(f"Auto-revalidation failed for {datasource_name}")

    def run_revalidation(self, datasource_name: str) -> None:
        """Execute the re-introspection pipeline for a single datasource."""
        config = self.latest_configs.get(datasource_name)
        uri = self.latest_uris.get(datasource_name, "")
        if config is None:
            return

        self.invalidate_datasource(datasource_name)

        contracts = self.index_provider().contracts()
        schemas = frozenset(contract.table.schema for contract in contracts)

        list_result = self.list_tables_config(config, schemas)
        if list_result.error is not None:
            logger.debug(
                f"Auto-revalidation: datasource '{datasource_name}' unreachable: {list_result.error}"
            )
            self.report_status(uri, list_result.error)
            return

        known_names = frozenset(str(table) for table in list_result.tables)
        tables_info: dict[str, DbTableInfo] = {}
        for contract in contracts:
            table_label = str(contract.table)
            if table_label not in known_names:
                continue
            result = self.introspect_config(config, contract.table)
            if isinstance(result, IntrospectionError):
                continue
            tables_info[table_label] = DbTableInfo(table_name=table_label, columns=result.columns)

        existing_cache = self.cache_provider()
        validated_uris = existing_cache.validated_uris if existing_cache else frozenset()

        cache = IntrospectionCache(
            tables=tables_info, known_table_names=known_names, validated_uris=validated_uris
        )
        self.store_cache(cache)
        self.refresh_diagnostics()
        self.report_status(uri, None)
        logger.debug(
            f"Auto-revalidation: {datasource_name} updated cache with "
            f"{len(known_names)} tables, {len(tables_info)} introspected"
        )


def hash_connection(connection: ConnectionProps) -> str:
    """Stable hash of typed connection props, invariant across Python sessions."""
    return connection.model_dump_json()
