"""Onboarding phase service.

Computes the four workspace-state phases (``needs-pyproject``,
``needs-turbine``, ``ready-tour-pending``, ``ready``) per workspace folder
and pushes ``PhaseDto`` payloads when the phase **kind** changes. Soft
dismissal is honored per ``(folder_uri, phase_kind)`` and survives until the
phase moves to a different kind.

Pure orchestration over injected ports — the file-system read happens in the
``read_status`` callable supplied by the composition root, the per-tour
finished set comes from the ``tour_progress_store``, and the static catalog
of available tours is supplied as ``tours``.

The service mutates from two threads: the main loop (``initialized``,
``didChangeWatchedFiles``, ``didChangeWorkspaceFolders``) and the asyncio
worker pool (``onboarding/dismiss``, ``onboarding/reset``,
``onboarding/saveTourProgress`` request handlers). A re-entrant lock guards
every state read + mutation so the ``StatefulServices`` thread-safety
contract holds.
"""

import threading
from collections.abc import Callable

from turbine.core.analysis.protocol import OnboardingStatusResult
from turbine.core.onboarding.dismissal import OnboardingDismissalKey, OnboardingDismissalStore
from turbine.core.onboarding.install_commands import DATABASE_CHOICES
from turbine.core.onboarding.phase import Phase, PhaseDto, PrimaryAction, TourEntry
from turbine.core.onboarding.tour_progress import TourProgressStore
from turbine.core.onboarding.tours import Tour


class OnboardingPhaseService:
    """Compute and emit ``PhaseDto`` per workspace folder.

    The service is keyed on ``workspace_folder_uri`` so a multi-root window
    can host one cache slot per folder. Each ``recompute`` call re-reads the
    folder's facts via ``read_status`` plus the per-folder finished-tour set
    and emits a new DTO only when the phase kind has moved AND the new kind
    has not been soft-dismissed.
    """

    def __init__(
        self,
        *,
        read_status: Callable[[str], OnboardingStatusResult | None],
        dismissal_store: OnboardingDismissalStore,
        tour_progress_store: TourProgressStore,
        tours: tuple[Tour, ...],
        notify_phase: Callable[[PhaseDto], None],
    ) -> None:
        self.read_status = read_status
        self.dismissal_store = dismissal_store
        self.tour_progress_store = tour_progress_store
        self.tours = tours
        self.notify_phase = notify_phase
        self.last_kind: dict[str, Phase] = {}
        self.lock = threading.RLock()

    def current(self, workspace_folder_uri: str) -> PhaseDto | None:
        """Return the latest computed PhaseDto for *workspace_folder_uri*, or None."""
        status = self.read_status(workspace_folder_uri)
        if status is None:
            return None
        finished = frozenset(self.tour_progress_store.all_finished_for(workspace_folder_uri))
        kind = derive_kind(status, finished, frozenset(tour.id for tour in self.tours))
        return self.build_dto(workspace_folder_uri, kind, finished)

    def recompute(self, workspace_folder_uri: str) -> None:
        """Recompute phase for *workspace_folder_uri*; emit on kind change.

        Dismissal honors the in-session "X'd it, don't pop up again" rule, but
        the **first** emission for a folder always fires regardless of any
        persisted dismissal. Without that, a reloaded editor session would
        sit on ``awaiting-server-phase`` forever — the activity-bar icon is
        always present and clicking it must surface the current phase.
        """
        with self.lock:
            status = self.read_status(workspace_folder_uri)
            if status is None:
                return
            finished = frozenset(self.tour_progress_store.all_finished_for(workspace_folder_uri))
            all_tour_ids = frozenset(tour.id for tour in self.tours)
            kind = derive_kind(status, finished, all_tour_ids)
            previous = self.last_kind.get(workspace_folder_uri)
            if previous == kind:
                return
            is_first_emit = previous is None
            self.last_kind[workspace_folder_uri] = kind
            if not is_first_emit:
                dismissed = self.dismissal_store.is_dismissed(
                    OnboardingDismissalKey(workspace_folder_uri=workspace_folder_uri, phase_kind=kind)
                )
                if dismissed:
                    return
            dto = self.build_dto(workspace_folder_uri, kind, finished)
        self.notify_phase(dto)

    def dismiss(self, workspace_folder_uri: str, phase_kind: Phase) -> None:
        """Record a soft-dismissal so the LSP suppresses re-emission of *phase_kind*."""
        with self.lock:
            self.dismissal_store.dismiss(
                OnboardingDismissalKey(workspace_folder_uri=workspace_folder_uri, phase_kind=phase_kind)
            )

    def reset(self, workspace_folder_uri: str) -> None:
        """Clear all dismissals and tour-progress for *workspace_folder_uri* and re-emit."""
        with self.lock:
            self.dismissal_store.clear(workspace_folder_uri)
            self.tour_progress_store.clear(workspace_folder_uri)
            self.last_kind.pop(workspace_folder_uri, None)
        self.recompute(workspace_folder_uri)

    def on_pyproject_changed(self, workspace_folder_uri: str) -> None:
        """Recompute when ``workspace/didChangeWatchedFiles`` fires for ``pyproject.toml``."""
        self.recompute(workspace_folder_uri)

    def on_tour_progress_changed(self, workspace_folder_uri: str) -> None:
        """Recompute after the editor saves a tour-progress update.

        A finished tour can flip the workspace from ``READY_TOUR_PENDING`` to
        ``READY``; the editor calls this from its save-progress handler so
        the panel advances without waiting for another file-watcher event.
        """
        self.recompute(workspace_folder_uri)

    def build_dto(
        self, workspace_folder_uri: str, kind: Phase, finished_tours: frozenset[str]
    ) -> PhaseDto:
        """Render the user-visible ``PhaseDto`` for *kind*.

        Copy is deliberately textbook-style: it explains what is needed and
        what the next action does, without selling or invoking pain.
        """
        if kind is Phase.NEEDS_PYPROJECT:
            return PhaseDto(
                workspace_folder_uri=workspace_folder_uri,
                kind=kind,
                title="Initialize a Python project",
                body=(
                    "This folder has no `pyproject.toml`. Initialize one so Turbine "
                    "can manage its dependencies through `uv`."
                ),
                primary_action=PrimaryAction(id="init-python", label="Initialize Python project"),
            )
        if kind is Phase.NEEDS_TURBINE:
            return PhaseDto(
                workspace_folder_uri=workspace_folder_uri,
                kind=kind,
                title="Pick a database",
                body=(
                    "Pick how Turbine should connect to your data. The selection "
                    "installs the right `turbine-data` extra and runs `turbine init` "
                    "to lay out the project."
                ),
                choices=DATABASE_CHOICES,
            )
        if kind is Phase.READY_TOUR_PENDING:
            return PhaseDto(
                workspace_folder_uri=workspace_folder_uri,
                kind=kind,
                title="Turbine is ready",
                body="The language server is running. Pick a guided tour to learn the basics.",
                tours=tuple(
                    TourEntry(id=tour.id, title=tour.title, completed=tour.id in finished_tours)
                    for tour in self.tours
                ),
                primary_action=PrimaryAction(id="reset-onboarding", label="Reset onboarding"),
            )
        return PhaseDto(
            workspace_folder_uri=workspace_folder_uri,
            kind=kind,
            title="Turbine is ready",
            body="The language server is running.",
            primary_action=PrimaryAction(id="reset-onboarding", label="Reset onboarding"),
        )


def derive_kind(
    status: OnboardingStatusResult, finished_tours: frozenset[str], all_tour_ids: frozenset[str]
) -> Phase:
    """Map workspace facts plus completion state to a single phase kind.

    The READY transition is tour-completion driven: a workspace advances from
    ``READY_TOUR_PENDING`` to ``READY`` once every tour in the catalog is
    marked finished for the folder. An empty catalog (no tours configured)
    skips ``READY_TOUR_PENDING`` and goes straight to ``READY`` — there is
    nothing left to learn.
    """
    if not status.has_pyproject:
        return Phase.NEEDS_PYPROJECT
    if not status.has_tool_turbine:
        return Phase.NEEDS_TURBINE
    if all_tour_ids and not all_tour_ids.issubset(finished_tours):
        return Phase.READY_TOUR_PENDING
    return Phase.READY
