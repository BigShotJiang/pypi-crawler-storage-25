"""Application-layer rename services for F2 cross-file rename.

Hosts ``PrepareRenameService`` and ``RenameService`` which orchestrate
cursor resolution, classification, and cross-file edit collection.
Pure types, ports, and helpers live in ``turbine.core.analysis.features.rename``.
"""

import re
from collections.abc import Callable
from pathlib import Path

from turbine.core.analysis.context import extract_value_text, resolve_context_at_position
from turbine.core.analysis.features.rename import (
    FileEdits,
    PrepareRenameInfo,
    PrepareRenameQuery,
    RenameQuery,
    RenameResult,
    classify_rename,
    find_regex_edits,
    is_renameable,
)
from turbine.core.analysis.model import TextEditInfo
from turbine.core.analysis.ports import DocumentTreePort
from turbine.core.building_blocks import DiagnosticSink, TextRange, TurbineError
from turbine.core.common import FIELD_TARGET_CONTRACT, RawSource
from turbine.core.common.dataset_spec import SqlCheckConfig
from turbine.core.contract import ProjectIndex
from turbine.core.contract.ports import ContractReaderRegistry


class PrepareRenameService:
    """Validates that the cursor sits on a renameable symbol and reports its range."""

    def __init__(
        self,
        registry: ContractReaderRegistry,
        parser: Callable[[Path, str], RawSource],
        tree_port: DocumentTreePort,
    ) -> None:
        """Store the reader registry, YAML parser, and tree port."""
        self.registry = registry
        self.parser = parser
        self.tree_port = tree_port

    def prepare_rename(
        self, query: PrepareRenameQuery, sink: DiagnosticSink
    ) -> PrepareRenameInfo | None:
        """Resolve the cursor to a renameable symbol and return its current name and range."""
        try:
            source = self.parser(Path(query.uri), query.content)
        except TurbineError as exc:
            sink.extend(exc.diagnostics)
            return None
        ctx = resolve_context_at_position(self.tree_port, query.uri, query.line, query.col)
        if ctx is None or not is_renameable(ctx.dotted_path):
            return None
        value_range = source.source_map.range_for_value(ctx.dotted_path)
        if value_range is None:
            return None
        name = extract_value_text(query.content, value_range)
        return PrepareRenameInfo(name=name, range=value_range)


class RenameService:
    """Produces the full set of cross-file workspace edits for a rename."""

    def __init__(
        self,
        registry: ContractReaderRegistry,
        parser: Callable[[Path, str], RawSource],
        index_provider: Callable[[], ProjectIndex],
        tree_port: DocumentTreePort,
    ) -> None:
        """Store the reader registry, YAML parser, index provider, and tree port."""
        self.registry = registry
        self.parser = parser
        self.index_provider = index_provider
        self.tree_port = tree_port

    def rename(self, query: RenameQuery, sink: DiagnosticSink) -> RenameResult | None:  # noqa: PLR0911
        """Resolve the rename target and collect edits across all affected files."""
        try:
            source = self.parser(Path(query.uri), query.content)
        except TurbineError as exc:
            sink.extend(exc.diagnostics)
            return None

        ctx = resolve_context_at_position(self.tree_port, query.uri, query.line, query.col)
        if ctx is None or not is_renameable(ctx.dotted_path):
            return None

        value_range = source.source_map.range_for_value(ctx.dotted_path)
        if value_range is None:
            return None

        old_name = extract_value_text(query.content, value_range)
        category = classify_rename(ctx.dotted_path)

        if category == "contract_id":
            return self.rename_contract_id(query.uri, value_range, old_name, query.new_name)
        if category == "column":
            return self.rename_column(query.uri, value_range, old_name, query.new_name)
        if category == "schema":
            return self.rename_schema(query.uri, value_range, query.new_name)
        return None

    def rename_contract_id(
        self, uri: str, value_range: TextRange, old_name: str, new_name: str
    ) -> RenameResult | None:
        """Rename a contract ID in its own file and every quality spec that references it."""
        index = self.index_provider()
        if index.find_contract(new_name) is not None:
            return None  # conflict

        file_edits: list[FileEdits] = [
            FileEdits(uri=uri, edits=(TextEditInfo(range=value_range, new_text=new_name),))
        ]

        for spec in index.find_specs_for_contract(old_name):
            edit = self.find_target_contract_edit(spec.metadata.source_path, new_name)
            if edit is not None:
                file_edits.append(edit)

        return RenameResult(file_edits=tuple(file_edits))

    def rename_column(
        self, uri: str, value_range: TextRange, old_name: str, new_name: str
    ) -> RenameResult | None:
        """Rename a column in the contract YAML and every SQL template that references it."""
        file_edits: list[FileEdits] = [
            FileEdits(uri=uri, edits=(TextEditInfo(range=value_range, new_text=new_name),))
        ]

        index = self.index_provider()
        pattern = re.compile(rf"\b{re.escape(old_name)}\b")

        for spec in index.quality_specs():
            for check in spec.checks:
                if not isinstance(check.config, SqlCheckConfig):
                    continue
                try:
                    content = check.config.file_path.read_text()
                except OSError:
                    continue
                sql_edits = find_regex_edits(content, pattern, new_name)
                if sql_edits:
                    file_edits.append(
                        FileEdits(uri=check.config.file_path.as_uri(), edits=tuple(sql_edits))
                    )

        return RenameResult(file_edits=tuple(file_edits))

    def rename_schema(self, uri: str, value_range: TextRange, new_name: str) -> RenameResult | None:
        """Rename a schema (table) name in the contract YAML."""
        file_edits: list[FileEdits] = [
            FileEdits(uri=uri, edits=(TextEditInfo(range=value_range, new_text=new_name),))
        ]
        return RenameResult(file_edits=tuple(file_edits))

    def find_target_contract_edit(self, spec_path: Path, new_name: str) -> FileEdits | None:
        """Locate the ``target_contract`` field in a quality spec and produce an edit for it."""
        try:
            text = spec_path.read_text()
            source = self.parser(spec_path, text)
        except Exception:  # noqa: BLE001
            return None

        for dotted in source.source_map.key_paths():
            if dotted != FIELD_TARGET_CONTRACT:
                continue
            vr = source.source_map.range_for_value(dotted)
            if vr is None:
                continue
            return FileEdits(uri=spec_path.as_uri(), edits=(TextEditInfo(range=vr, new_text=new_name),))
        return None
