"""Project-setup status and scaffold services.

Two independent classes share this module:

- :class:`ProjectSetupService` reads the workspace and reports which Turbine
  artifacts already exist. The onboarding phase machine consumes the result.
- :class:`ProjectScaffoldService` copies one of the packaged template trees
  (``demo`` or ``bare``) into ``layout.root``. The LSP request handler and the
  ``turbine init`` CLI both call this service for file-content emission.
"""

from __future__ import annotations

import filecmp
import importlib.resources
import json
import re
import shutil
import tomllib
from collections.abc import Iterator, Sequence
from datetime import UTC, datetime
from importlib.resources.abc import Traversable
from pathlib import Path

from turbine.core.analysis.protocol import (
    CleanupTourScaffoldResult,
    OnboardingStatusResult,
    ScaffoldProjectResult,
    ScaffoldVariant,
)
from turbine.core.common import ProjectLayout
from turbine.core.onboarding.phase import DatabaseChoiceId

TURBINE_VERSION_RE = re.compile(r"turbine[\w-]*(?:\[[\w,\-\s]*\])?[=<>~!]=*(\d+\.\d+\.\d+)")

TEMPLATES_PACKAGE = "turbine.onboarding.templates"
DEMO_DIR = "demo"
BARE_DIR = "bare"

BARE_CONTRACT_SENTINEL = "example-contract.yml"
BARE_DATASOURCE_SENTINEL = "default.yml"

# Single sentinel marker written by the demo scaffold and consulted by
# ``is_workspace_empty_for_tour``. Its presence is the authoritative signal
# that the workspace was scaffolded by a tour run; tour re-entry (restart,
# different tour, resume-after-finish) consults it first and never redirects
# the user to a fresh folder when it's present.
TOUR_SCAFFOLD_MARKER_RELATIVE = Path(".turbine") / "tour-scaffold.json"


def find_pyproject_path(start: Path) -> Path | None:
    """Walk up from *start* to the nearest ``pyproject.toml``."""
    for current in [start, *start.parents]:
        candidate = current / "pyproject.toml"
        if candidate.is_file():
            return candidate
    return None


def has_tool_turbine_section(pyproject_path: Path) -> bool:
    """Return True when the pyproject.toml has a ``[tool.turbine]`` section."""
    try:
        with pyproject_path.open("rb") as handle:
            data = tomllib.load(handle)
    except (OSError, tomllib.TOMLDecodeError):
        return False
    tool = data.get("tool")
    return isinstance(tool, dict) and "turbine" in tool


class ProjectSetupService:
    """Check project setup status for the onboarding wizard."""

    def __init__(self, layout: ProjectLayout) -> None:
        self.layout = layout

    def get_status(self) -> OnboardingStatusResult:
        """Return structured status of the project setup."""
        pyproject_path = find_pyproject_path(self.layout.root)
        has_pyproject = pyproject_path is not None
        has_contracts = self.layout.contracts_dir.is_dir()
        has_quality = self.layout.quality_dir.is_dir()

        datasources_dir = self.layout.datasources_dir
        has_datasources = datasources_dir.is_dir() and any(
            path for pattern in ("*.yml", "*.yaml") for path in datasources_dir.glob(pattern)
        )

        turbine_version = (
            self.detect_turbine_version(pyproject_path) if pyproject_path is not None else None
        )
        has_tool_turbine = (
            has_tool_turbine_section(pyproject_path) if pyproject_path is not None else False
        )

        return OnboardingStatusResult(
            has_pyproject=has_pyproject,
            has_contracts=has_contracts,
            has_quality=has_quality,
            has_datasources=has_datasources,
            has_tool_turbine=has_tool_turbine,
            turbine_version=turbine_version,
        )

    @staticmethod
    def detect_turbine_version(pyproject_path: Path) -> str | None:
        """Detect a Turbine package presence in pyproject.toml.

        The regex returns the pinned version when found; ``[tool.turbine]``
        presence falls back to a sentinel so the onboarding phase machine
        advances past ``NEEDS_TURBINE``.
        """
        content = pyproject_path.read_text()
        match = TURBINE_VERSION_RE.search(content)
        if match is not None:
            return match.group(1)
        if has_tool_turbine_section(pyproject_path):
            return "configured"
        return None


class ProjectScaffoldService:
    """Copy a packaged template tree into ``layout.root``.

    ``variant=DEMO`` copies the full onboarding-tour project (including its
    own ``pyproject.toml`` and ``.duckdb`` fixtures) to ``layout.root``.
    ``variant=BARE`` writes a single starter contract plus the per-dialect
    datasource template that matches ``database``. Both variants are
    idempotent: files that already exist are left untouched.
    """

    def __init__(self, layout: ProjectLayout) -> None:
        self.layout = layout

    def scaffold(
        self, variant: ScaffoldVariant = ScaffoldVariant.BARE, database: DatabaseChoiceId | None = None
    ) -> ScaffoldProjectResult:
        """Copy the template tree for *variant* into ``layout.root``."""
        if variant is ScaffoldVariant.DEMO:
            return self.scaffold_demo()
        if database is None:
            raise ValueError("variant='bare' requires a database choice")
        return self.scaffold_bare(database)

    def scaffold_demo(self) -> ScaffoldProjectResult:
        """Copy every file under ``templates/demo/`` to ``layout.root``.

        Writes a ``.turbine/tour-scaffold.json`` marker recording the manifest
        of created files. Cleanup uses the manifest to delete only what the
        scaffold wrote and never touch user-authored files in the same tree.
        Re-runs merge new file paths into the existing manifest.
        """
        templates_root = importlib.resources.files(TEMPLATES_PACKAGE)
        demo_root = templates_root / DEMO_DIR
        with importlib.resources.as_file(demo_root) as source_root:
            created = copy_tree_skip_existing(source_root, self.layout.root)
        marker_newly_created = write_tour_scaffold_marker(
            self.layout.root, variant=ScaffoldVariant.DEMO, created_files=created
        )
        if marker_newly_created:
            created.append(TOUR_SCAFFOLD_MARKER_RELATIVE.as_posix())
        return ScaffoldProjectResult(created_files=tuple(created))

    def scaffold_bare(self, database: DatabaseChoiceId) -> ScaffoldProjectResult:
        """Write contracts/example-contract.yml + datasources/default.yml.

        Records every written path in ``.turbine/tour-scaffold.json`` so the
        cleanup flow can roll back only what this scaffold added.
        """
        templates_root = importlib.resources.files(TEMPLATES_PACKAGE)
        bare_root = templates_root / BARE_DIR
        created: list[str] = []
        contract_dest = self.layout.contracts_dir / "example-contract.yml"
        contract_text = read_template_text(bare_root, "contracts/example-contract.yml")
        if write_if_missing(contract_text, contract_dest):
            created.append("contracts/example-contract.yml")
        datasource_filename = datasource_template_filename(database)
        datasource_dest = self.layout.datasources_dir / "default.yml"
        datasource_text = read_template_text(bare_root, f"datasources/{datasource_filename}")
        if write_if_missing(datasource_text, datasource_dest):
            created.append("datasources/default.yml")
        marker_newly_created = write_tour_scaffold_marker(
            self.layout.root, variant=ScaffoldVariant.BARE, created_files=created
        )
        if marker_newly_created:
            created.append(TOUR_SCAFFOLD_MARKER_RELATIVE.as_posix())
        return ScaffoldProjectResult(created_files=tuple(created))


def is_workspace_empty_for_tour(root: Path) -> tuple[bool, list[str]]:
    """Decide whether *root* can host the demo tour scaffold non-destructively.

    Two paths return ``(True, [])``:

    1. The ``.turbine/tour-scaffold.json`` marker exists at *root*. This is
       the authoritative signal that a previous tour run scaffolded this
       workspace, so re-entry (restart, different tour, resume-after-finish)
       is always allowed regardless of what files now live under
       ``contracts/`` / ``quality/`` / ``checks/``.
    2. No marker, and the workspace contains nothing under
       ``contracts/`` / ``quality/`` / ``checks/`` beyond the bare-init
       sentinel ``contracts/example-contract.yml``. This is the first-time
       case: the user just ran ``turbine init`` and is starting their first
       tour.

    Otherwise returns ``(False, [reasons])`` with one human-readable line
    per blocking file. The editor uses the reasons to surface the
    fresh-folder-picker prompt with precise context.
    """
    if tour_scaffold_marker_path(root).is_file():
        return (True, [])

    reasons: list[str] = []

    contracts = root / "contracts"
    if contracts.is_dir():
        extras = sorted(
            entry.name
            for entry in contracts.iterdir()
            if entry.is_file()
            and entry.suffix in {".yml", ".yaml"}
            and entry.name != BARE_CONTRACT_SENTINEL
        )
        if extras:
            reasons.append(f"contracts/ contains user files: {', '.join(extras)}")

    quality = root / "quality"
    if quality.is_dir():
        extras = sorted(
            entry.name
            for entry in quality.rglob("*")
            if entry.is_file() and entry.suffix in {".yml", ".yaml"}
        )
        if extras:
            reasons.append(f"quality/ contains user files: {', '.join(extras)}")

    checks = root / "checks"
    if checks.is_dir():
        extras = sorted(
            entry.name
            for entry in checks.iterdir()
            if entry.is_file() and entry.suffix in {".sql", ".py"} and entry.name != "__init__.py"
        )
        if extras:
            reasons.append(f"checks/ contains user files: {', '.join(extras)}")

    return (len(reasons) == 0, reasons)


def tour_scaffold_marker_path(root: Path) -> Path:
    """Return the absolute path of the tour-scaffold marker for layout *root*."""
    return root / TOUR_SCAFFOLD_MARKER_RELATIVE


def write_tour_scaffold_marker(
    root: Path, *, variant: ScaffoldVariant, created_files: Sequence[str] = ()
) -> bool:
    """Write the tour-scaffold marker at *root*. Returns True when newly created.

    The marker carries the scaffold variant, a UTC ISO-8601 timestamp, and a
    *manifest* of files this scaffold wrote — the manifest is the single source
    of truth for which files the cleanup flow may delete. Re-running a scaffold
    against an existing marker merges any new file paths into the manifest so
    the cleanup remains complete across incremental scaffold calls.
    Idempotent in shape — returns ``False`` when the marker already existed
    (manifest may still have been extended).
    """
    marker = tour_scaffold_marker_path(root)
    existing = read_tour_scaffold_marker(root)
    merged_created = merge_created_files(existing.get("created_files", []), created_files)
    payload = {
        "variant": variant.value,
        "scaffolded_at": existing.get("scaffolded_at") or datetime.now(tz=UTC).isoformat(),
        "created_files": merged_created,
    }
    marker.parent.mkdir(parents=True, exist_ok=True)
    marker.write_text(json.dumps(payload, indent=2) + "\n", encoding="utf-8")
    return not existing


def read_tour_scaffold_marker(root: Path) -> dict[str, object]:
    """Return the parsed marker dict, or ``{}`` when missing or malformed."""
    marker = tour_scaffold_marker_path(root)
    if not marker.is_file():
        return {}
    try:
        data = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def merge_created_files(existing: object, new: Sequence[str]) -> list[str]:
    """Union *existing* (from the on-disk marker) with *new*, preserving order.

    Both lists land in the manifest in the order they were first observed so
    a cleanup pass deletes children before parents naturally.
    """
    existing_list = (
        [item for item in existing if isinstance(item, str)] if isinstance(existing, list) else []
    )
    seen = set(existing_list)
    merged = list(existing_list)
    for path in new:
        if path not in seen:
            seen.add(path)
            merged.append(path)
    return merged


def cleanup_tour_scaffold(root: Path) -> CleanupTourScaffoldResult:
    """Delete every file the demo scaffold wrote into *root*, plus the marker.

    Reads the manifest persisted in ``.turbine/tour-scaffold.json`` and
    deletes each listed path unconditionally — user edits inside a manifest
    file go away too (the user already opted into this flow by invoking
    cleanup). Manifest entries that escape the project root or no longer
    exist on disk land in ``missing_files`` but never abort the call.

    Empty parent directories under *root* are pruned bottom-up after the
    file pass; *root* itself is never removed even when it ends up empty.
    The marker is the last thing deleted so a partial failure still leaves
    the manifest recoverable.
    """
    marker = read_tour_scaffold_marker(root)
    manifest = manifest_paths(marker)
    deleted: list[str] = []
    missing: list[str] = []
    touched_dirs: set[Path] = set()
    resolved_root = root.resolve()
    for relative in manifest:
        target = (root / relative).resolve()
        if not is_inside(target, resolved_root) or not target.exists():
            missing.append(relative)
            continue
        try:
            target.unlink()
        except OSError:
            missing.append(relative)
            continue
        deleted.append(relative)
        touched_dirs.add(target.parent)
    marker_path = tour_scaffold_marker_path(root)
    if marker_path.exists():
        marker_path.unlink()
        touched_dirs.add(marker_path.parent)
    prune_empty_dirs(touched_dirs, resolved_root)
    return CleanupTourScaffoldResult(deleted_files=tuple(deleted), missing_files=tuple(missing))


def manifest_paths(marker: dict[str, object]) -> tuple[str, ...]:
    """Return manifest entries from a parsed marker dict, ignoring malformed shapes."""
    raw = marker.get("created_files", ())
    if not isinstance(raw, list):
        return ()
    return tuple(item for item in raw if isinstance(item, str))


def is_inside(target: Path, root: Path) -> bool:
    """Return True when *target* sits inside *root* after resolving symlinks.

    Cleanup never follows a manifest entry whose resolved path escapes the
    project root — defensive against a tampered marker with ``../`` segments.
    """
    try:
        target.relative_to(root)
    except ValueError:
        return False
    return True


def prune_empty_dirs(dirs: set[Path], root: Path) -> None:
    """Bottom-up remove every empty directory under *root*. Never removes *root*."""
    for directory in sorted(dirs, key=lambda p: len(p.parts), reverse=True):
        current = directory
        while is_inside(current, root) and current != root:
            try:
                next(current.iterdir())
                break
            except StopIteration:
                try:
                    current.rmdir()
                except OSError:
                    break
                current = current.parent
            except FileNotFoundError:
                break


def datasource_template_filename(database: DatabaseChoiceId) -> str:
    """Map a database choice to its bare-template datasource filename.

    The enum value uses hyphens (``lsp-only``); template filenames use
    underscores so they're valid Python identifiers when imported.
    """
    return f"{database.value.replace('-', '_')}.yml"


def read_template_text(template_root: Traversable, relative_path: str) -> str:
    """Read a UTF-8 text file from the packaged template tree."""
    current: Traversable = template_root
    for part in relative_path.split("/"):
        current = current / part
    return current.read_text(encoding="utf-8")


def copy_tree_skip_existing(source_root: Path, destination_root: Path) -> list[str]:
    """Copy every file under ``source_root`` to ``destination_root``.

    Returns the destination-relative paths (POSIX separators, wire-stable) of
    files that were actually written. Files that already exist at the
    destination are skipped so the operation is idempotent and never
    clobbers user edits. Demo DuckDB fixtures are the exception: if a stale
    or empty database already exists at the packaged fixture path, it is
    refreshed from the template so the tour always starts with its expected
    ``public.orders`` and ``public.customers`` tables. A top-level
    ``pyproject.toml`` in the template is also skipped — the user's workspace
    already owns that file, and the scaffold layers content under
    ``layout.root`` (typically ``src/<pkg>/``) which sits below the workspace
    root.
    """
    created: list[str] = []
    for source_file in walk_files(source_root):
        relative = source_file.relative_to(source_root)
        if relative == Path("pyproject.toml"):
            continue
        destination = destination_root / relative
        if destination.exists():
            if should_refresh_demo_duckdb_fixture(relative, source_file, destination):
                shutil.copy2(source_file, destination)
                created.append(relative.as_posix())
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source_file, destination)
        created.append(relative.as_posix())
    return created


def should_refresh_demo_duckdb_fixture(relative: Path, source_file: Path, destination: Path) -> bool:
    """Return True when an existing demo DuckDB fixture differs from the package copy."""
    if relative.suffix != ".duckdb":
        return False
    if not destination.is_file():
        return False
    return not filecmp.cmp(source_file, destination, shallow=False)


def walk_files(root: Path) -> Iterator[Path]:
    """Yield every regular file under *root*, recursively."""
    for path in root.rglob("*"):
        if path.is_file():
            yield path


def write_if_missing(content: str, destination: Path) -> bool:
    """Write *content* to *destination* when missing. Returns True on write."""
    if destination.exists():
        return False
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_text(content)
    return True
