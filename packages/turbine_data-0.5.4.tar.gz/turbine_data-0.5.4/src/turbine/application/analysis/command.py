"""Workspace command handler — dispatches turbine.* commands to real implementations."""

import asyncio
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from loguru import logger

from turbine.application.analysis.add_check import AddCheckUseCase
from turbine.application.analysis.check_catalog_service import filter_catalog
from turbine.application.analysis.dismissal_filter import filter_and_purge
from turbine.application.analysis.lsp_client_port import LspClient, TableRef
from turbine.application.analysis.sidebar_resource_creation import (
    ContractFromDatasourceRequest,
    SidebarCreationOutcome,
)
from turbine.application.diagnostics import DiagnosticCollector
from turbine.core.analysis.add_check_request import AddCheckRequest
from turbine.core.analysis.check_catalog import CheckScope
from turbine.core.analysis.context.text import uri_to_path
from turbine.core.analysis.features.code_action import (
    QUALITY_SPEC_COMMENT,
    generate_quality_spec_content,
)
from turbine.core.analysis.features.code_lens import (
    detect_kind,
    extract_dataset,
    extract_target_contract,
)
from turbine.core.analysis.ports import CodeWriteError, CodeWriter
from turbine.core.building_blocks import Diagnostic, DiagnosticKind, EventBus, TurbineError
from turbine.core.common import (
    CommandId,
    ConnectivityProbe,
    DatabaseBackendFactory,
    DatasetSpec,
    DatasourceRepository,
    RawSource,
)
from turbine.core.common.constants import ContractKind
from turbine.core.common.file_edits import SnippetInsertion, TextPosition
from turbine.core.contract import ProjectIndex, select_target_spec, target_specs_from_index
from turbine.core.contract.dismissal import DismissalKey, DismissalStore
from turbine.core.contract.events import DiagnosticDismissed

DISMISS_REQUIRED_ARGS = 2  # uri + rule_id are mandatory
DISMISS_ANCHOR_INDEX = 2  # anchor is the third positional
CONTRACT_FROM_DATASOURCE_SIDEBAR_ARGS = 2


@dataclass(frozen=True, slots=True)
class CommandResult:
    """Outcome of executing a workspace command."""

    message: str
    success: bool = True


@dataclass(frozen=True, slots=True)
class CommandQuery:
    """A workspace command invocation."""

    command: str
    arguments: tuple[str, ...] = ()


@dataclass(frozen=True, slots=True)
class AddCheckArgs:
    """Parsed Add Check command arguments."""

    uri: str
    scope: CheckScope
    column: str | None
    schema_name: str | None


class LatestDiagnosticsProvider(Protocol):
    """Port exposing the last computed diagnostics for a URI."""

    def latest_for_uri(self, uri: str) -> tuple[Diagnostic, ...]:
        """Return the latest diagnostics for *uri*."""
        ...


class SidebarCreationUseCase(Protocol):
    """Port for Sidebar Resource Creation commands."""

    async def create_datasource(self, target_root: Path) -> SidebarCreationOutcome:
        """Create a Datasource in the selected Turbine project root."""
        ...

    async def create_blank_contract(self, target_root: Path) -> SidebarCreationOutcome:
        """Create a blank Contract in the selected Turbine project root."""
        ...

    async def create_contract_from_datasource(
        self, request: ContractFromDatasourceRequest
    ) -> SidebarCreationOutcome:
        """Create a Contract from a Datasource in the selected Turbine project root."""
        ...


def unpack_add_check_arguments(arguments: tuple[str, ...]) -> AddCheckArgs:
    """Parse Add Check workspace command arguments."""
    padded = (*arguments, "", "", "", "")
    return AddCheckArgs(
        uri=padded[0],
        scope=CheckScope(padded[1]) if padded[1] else CheckScope.DATASET,
        column=padded[2] or None,
        schema_name=padded[3] or None,
    )


def resolve_contract(
    arguments: tuple[str, ...], index: ProjectIndex, lsp_client: LspClient
) -> DatasetSpec | None:
    """Extract contract_id from arguments, look it up in the index.

    Returns None (and shows an error message) if the contract_id is missing or not found.
    """
    contract_id = arguments[0] if arguments else None
    if contract_id is None:
        return None
    contract = select_target_spec(target_specs_from_index(index, contract_id), None)
    if contract is None:
        lsp_client.show_message(f"Contract '{contract_id}' not found")
        return None
    return contract


def table_ref_for_spec(spec: DatasetSpec) -> TableRef:
    """Create a table picker reference from a dataset spec."""
    return TableRef(schema=spec.table.schema, table=spec.table.table)


def table_ref_label(table: TableRef) -> str:
    """Render a table picker reference as ``schema.table``."""
    return f"{table.schema}.{table.table}"


async def pick_quality_dataset(lsp_client: LspClient, specs: tuple[DatasetSpec, ...]) -> str | None:
    """Resolve one dataset from target specs, prompting when there are multiple."""
    if len(specs) == 1:
        return str(specs[0].table)

    picked = await lsp_client.pick_tables(tuple(table_ref_for_spec(spec) for spec in specs))
    if picked is None:
        return None
    if len(picked) != 1:
        lsp_client.show_message("Choose exactly one dataset for the Quality Spec")
        return None
    return table_ref_label(picked[0])


def quality_spec_comment_position(content: str) -> TextPosition | None:
    """Return the 1-indexed cursor position for the new Quality Spec comment line."""
    for line_number, line in enumerate(content.splitlines(), start=1):
        if line.strip() != QUALITY_SPEC_COMMENT:
            continue
        return TextPosition(line=line_number, col=line.index("#") + 1)
    return None


class CommandHandler:
    """Dispatch turbine.* workspace commands to their implementations.

    Dependencies are injected by the composition root (server.py).
    Commands that need I/O run in threads via asyncio.to_thread.
    """

    def __init__(
        self,
        lsp_client: LspClient,
        index_provider: Callable[[], ProjectIndex],
        parser: Callable[[Path, str | None], RawSource],
        datasource_repo_for: Callable[[Path], DatasourceRepository] | None = None,
        connectivity_probe: ConnectivityProbe | None = None,
        backend_factory: DatabaseBackendFactory | None = None,
        contracts_dir: Path | None = None,
        quality_dir: Path | None = None,
        add_check_use_case: AddCheckUseCase | None = None,
        code_writer: CodeWriter | None = None,
        quality_owner_resolver: Callable[[], str | None] | None = None,
        dismissal_store: DismissalStore | None = None,
        diagnostics_handler: LatestDiagnosticsProvider | None = None,
        latest_diagnostics_provider: Callable[[str], tuple[Diagnostic, ...]] | None = None,
        sidebar_creation: SidebarCreationUseCase | None = None,
        event_bus: EventBus | None = None,
    ) -> None:
        """Store dependencies injected by the composition root."""
        self.lsp_client = lsp_client
        self.index_provider = index_provider
        self.parser = parser
        self.datasource_repo_for = datasource_repo_for
        self.connectivity_probe = connectivity_probe
        self.backend_factory = backend_factory
        self.contracts_dir = contracts_dir
        self.quality_dir = quality_dir
        self.add_check_use_case = add_check_use_case
        self.code_writer = code_writer
        self.quality_owner_resolver = quality_owner_resolver
        self.dismissal_store = dismissal_store
        self.diagnostics_handler = diagnostics_handler
        self.latest_diagnostics_provider = latest_diagnostics_provider
        self.sidebar_creation = sidebar_creation
        self.event_bus = event_bus

    async def handle(self, query: CommandQuery) -> CommandResult:
        """Route to the appropriate command implementation."""
        dispatch: dict[str, Callable[[tuple[str, ...]], object]] = {
            CommandId.GENERATE_QUALITY_SPEC: self.generate_quality_spec,
            CommandId.TEST_DATASOURCE_CONNECTION: self.test_datasource_connection,
            CommandId.CREATE_BLANK_CONTRACT: self.create_blank_contract,
            CommandId.CREATE_CONTRACT_FROM_DATASOURCE: self.create_contract_from_datasource,
            CommandId.CREATE_DATASOURCE: self.create_datasource,
            CommandId.ADD_CHECK: self.add_check,
            CommandId.DISMISS_DIAGNOSTIC: self.dismiss_diagnostic,
        }
        handler = dispatch.get(query.command)
        if handler is None:
            return CommandResult(message=f"Unknown command: {query.command}", success=False)
        try:
            result = handler(query.arguments)
            if asyncio.iscoroutine(result):
                result = await result
            if isinstance(result, CommandResult):
                return result
        except (TurbineError, OSError, ValueError) as exc:
            logger.exception(f"Command {query.command} failed")
            self.lsp_client.show_message(f"Command failed: {exc}")
            return CommandResult(message=str(exc), success=False)
        return CommandResult(message=f"{query.command} completed")

    async def create_datasource(self, arguments: tuple[str, ...]) -> CommandResult:
        """Create a Datasource in the selected Turbine project root."""
        if self.sidebar_creation is None:
            self.lsp_client.show_message("Sidebar Resource Creation not configured")
            return CommandResult(message="Sidebar Resource Creation not configured", success=False)
        target_root = self.parse_target_root(arguments)
        if target_root is None:
            self.lsp_client.show_message("New Datasource: no project root provided")
            return CommandResult(message="New Datasource: no project root provided", success=False)
        outcome = await self.sidebar_creation.create_datasource(target_root)
        return CommandResult(message=outcome.message, success=outcome.created or outcome.opened_existing)

    async def create_blank_contract(self, arguments: tuple[str, ...]) -> CommandResult:
        """Create a blank Contract in the selected Turbine project root."""
        if self.sidebar_creation is None:
            self.lsp_client.show_message("Sidebar Resource Creation not configured")
            return CommandResult(message="Sidebar Resource Creation not configured", success=False)
        target_root = self.parse_target_root(arguments)
        if target_root is None:
            self.lsp_client.show_message("Blank Contract: no project root provided")
            return CommandResult(message="Blank Contract: no project root provided", success=False)
        outcome = await self.sidebar_creation.create_blank_contract(target_root)
        return CommandResult(message=outcome.message, success=outcome.created or outcome.opened_existing)

    def parse_target_root(self, arguments: tuple[str, ...]) -> Path | None:
        """Parse the selected project root from command arguments."""
        if not arguments or not arguments[0]:
            return None
        raw = arguments[0]
        return uri_to_path(raw) if raw.startswith("file://") else Path(raw)

    def parse_contract_from_datasource_request(
        self, arguments: tuple[str, ...]
    ) -> ContractFromDatasourceRequest | None:
        """Parse sidebar and CodeLens Create Contract from Datasource arguments."""
        if len(arguments) >= CONTRACT_FROM_DATASOURCE_SIDEBAR_ARGS:
            target_root = self.parse_target_root(arguments)
            if target_root is None:
                return None
            return ContractFromDatasourceRequest(target_root=target_root, datasource_uri=arguments[1])
        if len(arguments) == 1 and arguments[0].startswith("file://"):
            if self.contracts_dir is None:
                return None
            return ContractFromDatasourceRequest(
                target_root=self.contracts_dir.parent, datasource_uri=arguments[0]
            )
        target_root = self.parse_target_root(arguments)
        if target_root is None:
            return None
        return ContractFromDatasourceRequest(target_root=target_root)

    async def dismiss_diagnostic(self, arguments: tuple[str, ...]) -> None:
        """Persist a dismissal and trigger a pull-model diagnostic refresh.

        Arguments are ``(uri, rule_id, anchor_or_empty)``: ``rule_id`` is the
        ``DiagnosticKind.value`` round-tripped through the LSP code action,
        and ``anchor_or_empty`` is ``""`` for file-level findings (the wire
        layer only carries strings). Unknown rule ids and short payloads are
        no-ops so a stale code action lingering in the editor cannot crash
        the command handler.
        """
        if len(arguments) < DISMISS_REQUIRED_ARGS:
            return
        if self.dismissal_store is None:
            self.lsp_client.show_message("Dismissal not configured")
            return
        uri = arguments[0]
        rule_id = arguments[1]
        has_anchor = len(arguments) > DISMISS_ANCHOR_INDEX and arguments[DISMISS_ANCHOR_INDEX]
        anchor = arguments[DISMISS_ANCHOR_INDEX] if has_anchor else None
        try:
            kind = DiagnosticKind(rule_id)
        except ValueError:
            return
        key = DismissalKey(file_uri=uri, rule_id=rule_id, anchor=anchor)
        self.dismissal_store.dismiss(key, kind)
        latest = self.latest_diagnostics(uri)
        if latest:
            visible = filter_and_purge(uri, latest, self.dismissal_store)
            self.lsp_client.publish_diagnostics(uri, visible)
        else:
            self.lsp_client.clear(uri)
        self.lsp_client.refresh_diagnostics()
        if self.event_bus is not None:
            self.event_bus.publish(DiagnosticDismissed(uri=uri, rule_id=rule_id))

    def latest_diagnostics(self, uri: str) -> tuple[Diagnostic, ...]:
        """Return latest diagnostics from either configured diagnostics seam."""
        if self.latest_diagnostics_provider is not None:
            return self.latest_diagnostics_provider(uri)
        if self.diagnostics_handler is not None:
            return self.diagnostics_handler.latest_for_uri(uri)
        return ()

    async def generate_quality_spec(self, arguments: tuple[str, ...]) -> None:
        """Generate a quality spec file for a contract.

        Arguments: (contract_id, schema_name) where schema_name is the
        fully qualified table name from the code lens click.
        """
        contract_id = arguments[0] if arguments else None
        if not contract_id:
            return

        target_dir = self.quality_dir or self.contracts_dir
        if target_dir is None:
            self.lsp_client.show_message("Quality directory not configured")
            return

        dataset = await self.resolve_quality_dataset(arguments)
        if dataset is None:
            return

        default_name = f"{contract_id}-quality"
        spec_name = await self.lsp_client.prompt_text("Quality spec name:", placeholder=default_name)
        if not spec_name:
            return

        owner = self.resolve_quality_owner()
        content = generate_quality_spec_content(contract_id, dataset, spec_id=spec_name, owner=owner)
        spec_path = target_dir / f"{spec_name}.yaml"
        spec_uri = spec_path.as_uri()
        applied = await self.lsp_client.apply_edit(spec_uri, content)
        if not applied:
            self.lsp_client.show_message("Failed to create quality spec file")
            return
        await self.lsp_client.show_document(spec_uri)
        await self.place_quality_spec_cursor(spec_uri, content)
        self.lsp_client.show_message(f"Quality spec created: {spec_path.name}")

    async def place_quality_spec_cursor(self, uri: str, content: str) -> None:
        """Place the editor cursor on the comment line inside the new ``quality:`` block."""
        if self.code_writer is None:
            return
        position = quality_spec_comment_position(content)
        if position is None:
            return
        try:
            await self.code_writer.insert_snippet(
                SnippetInsertion(uri=uri, position=position, snippet_text="")
            )
        except CodeWriteError as exc:
            self.lsp_client.show_message(f"Quality spec created, but cursor placement failed: {exc}")

    def resolve_quality_owner(self) -> str:
        """Resolve the owner string for a new Quality Spec scaffold."""
        if self.quality_owner_resolver is None:
            return ""
        return self.quality_owner_resolver() or ""

    async def resolve_quality_dataset(self, arguments: tuple[str, ...]) -> str | None:
        """Return the requested dataset name or ask the user to choose one."""
        if len(arguments) > 1 and arguments[1]:
            return arguments[1]

        contract_id = arguments[0] if arguments else None
        if contract_id is None:
            return None

        specs = target_specs_from_index(self.index_provider(), contract_id)
        if not specs:
            self.lsp_client.show_message(f"Contract '{contract_id}' not found")
            return None
        return await pick_quality_dataset(self.lsp_client, specs)

    async def test_datasource_connection(self, arguments: tuple[str, ...]) -> None:
        """Open the datasource and run SELECT 1 to verify connectivity."""
        if self.datasource_repo_for is None or self.connectivity_probe is None:
            self.lsp_client.show_message("Datasource operations not configured")
            return
        if not arguments:
            self.lsp_client.show_message("Test Connection: no datasource file provided")
            return

        datasource_path = uri_to_path(arguments[0])
        repo = self.datasource_repo_for(datasource_path)
        collector = DiagnosticCollector()
        try:
            config = repo.load_from_path(datasource_path, collector)
        except TurbineError as exc:
            message = exc.diagnostics[0].message if exc.diagnostics else str(exc)
            self.lsp_client.show_message(f"Cannot load datasource: {message}")
            return

        result = await asyncio.to_thread(self.connectivity_probe.probe, config)
        if result.connected:
            self.lsp_client.show_message(f"Connected to {config.name} ({result.latency_ms} ms)")
        else:
            self.lsp_client.show_message(f"Connection to {config.name} failed: {result.error}")

    async def create_contract_from_datasource(self, arguments: tuple[str, ...]) -> CommandResult:
        """Route Create Contract from Datasource to Sidebar Resource Creation."""
        if self.sidebar_creation is None:
            self.lsp_client.show_message("Sidebar Resource Creation not configured")
            return CommandResult(message="Sidebar Resource Creation not configured", success=False)
        request = self.parse_contract_from_datasource_request(arguments)
        if request is None:
            self.lsp_client.show_message("Create Contract from Datasource: no project root provided")
            return CommandResult(
                message="Create Contract from Datasource: no project root provided", success=False
            )
        outcome = await self.sidebar_creation.create_contract_from_datasource(request)
        return CommandResult(message=outcome.message, success=outcome.created or outcome.opened_existing)

    async def add_check(self, arguments: tuple[str, ...]) -> None:
        """Insert a new check into a DataContract or QualitySpec via the Add Check flow."""
        if self.add_check_use_case is None:
            self.lsp_client.show_message("Add Check not configured")
            return
        if not arguments:
            self.lsp_client.show_message("Add Check: no file URI provided")
            return

        add_check_args = unpack_add_check_arguments(arguments)
        content = self.open_document_content(add_check_args.uri)
        if content is None:
            return
        column = await self.resolve_add_check_column(add_check_args, content)
        if add_check_args.scope == CheckScope.COLUMN and column is None:
            return
        request = await self.build_add_check_request(
            add_check_args.uri, content, add_check_args.scope, column, add_check_args.schema_name
        )
        if request is None:
            return
        result = await self.add_check_use_case.execute(content, request)
        if result.error:
            self.lsp_client.show_message(f"Add Check failed: {result.error}")

    def open_document_content(self, uri: str) -> str | None:
        """Return open document content, showing the Add Check editor error when absent."""
        content = self.lsp_client.get_document_content(uri)
        if content is None:
            self.lsp_client.show_message("Add Check failed: File not open in editor")
        return content

    async def resolve_add_check_column(self, args: AddCheckArgs, content: str) -> str | None:
        """Return the command column, prompting from target contract when needed."""
        if args.scope != CheckScope.COLUMN or args.column is not None:
            return args.column
        return await self.resolve_column_from_contract(content)

    async def build_add_check_request(
        self, uri: str, content: str, scope: CheckScope, column: str | None, schema_name: str | None
    ) -> AddCheckRequest | None:
        """Ask for a catalog check and turn it into an AddCheck request."""
        pick = await self.lsp_client.pick_check(filter_catalog(scope))
        if pick is None:
            return None
        return AddCheckRequest(
            file_uri=uri,
            file_kind=detect_kind(content) or ContractKind.QUALITY_SPEC,
            check_type=pick.check_type,
            dimension=pick.dimension,
            scope=scope,
            column=column,
            schema_name=schema_name,
        )

    async def resolve_column_from_contract(self, content: str) -> str | None:
        """Resolve columns from the target contract and ask the user to pick one."""
        target_id = extract_target_contract(content)
        if not target_id:
            self.lsp_client.show_message("No targetContract found in this file")
            return None

        index = self.index_provider()
        dataset = extract_dataset(content) or None
        contract = select_target_spec(target_specs_from_index(index, target_id), dataset)
        if contract is None:
            self.lsp_client.show_message(f"Contract '{target_id}' not found")
            return None

        column_names = tuple(col.name for col in contract.columns)
        if not column_names:
            self.lsp_client.show_message(f"Contract '{target_id}' has no columns")
            return None

        return await self.lsp_client.pick_column(column_names)
