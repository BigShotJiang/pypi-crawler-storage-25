"""Diagnostics analysis handler — lint a contract from in-memory content."""

from __future__ import annotations

import threading
from collections import OrderedDict
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from turbine.application.diagnostics import DiagnosticCollector
from turbine.core.building_blocks import Diagnostic, DiagnosticSink, TurbineError
from turbine.core.common import DatasetSpec, RawSource

from .lint import LintUseCase
from .versioning_surface import BreakingChangeWithoutMajorBumpRule, ContractVersioningSurfaceProvider

LINT_CACHE_MAX = 64

YAML_SUFFIXES = (".yml", ".yaml")


def is_yaml_uri(uri: str) -> bool:
    """Return True when *uri* points at a YAML document.

    Used to skip the lint pipeline for non-YAML files the editor sends through
    the same diagnostic seam (``.py`` checks, ``.sql`` query files). The YAML
    parser would otherwise raise a parse error on the first line of those
    files and present it as a Turbine diagnostic.
    """
    lowered = uri.lower()
    return any(lowered.endswith(suffix) for suffix in YAML_SUFFIXES)


def extract_schema_name(entry: object) -> str | None:
    """Return the schema entry's ``name`` field if it is a non-empty string."""
    if not isinstance(entry, dict):
        return None
    value: object = None
    for key, raw_value in entry.items():
        if key == "name":
            value = raw_value
            break
    if not isinstance(value, str) or not value:
        return None
    return value


@dataclass(frozen=True, slots=True)
class DiagnosticsQuery:
    """Carries the document URI and its current content for on-the-fly linting.

    Attrs:
        uri: Document URI (file path or scheme-prefixed).
        content: Full document text at the time of the request.
    """

    uri: str
    content: str


@dataclass(frozen=True, slots=True)
class LintCacheEntry:
    """Cached result of a full lint pass for a single document."""

    content_hash: int
    index_id: int
    diagnostics: tuple[Diagnostic, ...]
    contracts: tuple[DatasetSpec, ...]


class DiagnosticsHandler:
    """Lint in-memory document content and feed findings into a diagnostic sink.

    Caches lint results per document so repeated requests for unchanged
    content skip schema validation and domain rules entirely.

    Thread-safety: ``handle`` is called from worker threads (one per
    ``textDocument/diagnostic`` request). ``lint_cache`` is guarded by
    ``cache_lock`` so concurrent eviction can't double-pop.
    """

    def __init__(
        self,
        lint_use_case: LintUseCase,
        parser: Callable[[Path, str], RawSource],
        versioning_provider: ContractVersioningSurfaceProvider | None = None,
    ) -> None:
        """Store the lint use case, parser, datasource validator, and cache reader."""
        self.lint_use_case = lint_use_case
        self.parser = parser
        self.versioning_rule = (
            BreakingChangeWithoutMajorBumpRule(versioning_provider)
            if versioning_provider is not None
            else None
        )
        self.lint_cache: OrderedDict[str, LintCacheEntry] = OrderedDict()
        self.cache_lock = threading.Lock()

    def current_index_id(self) -> int:
        """Return the identity of the current project index for cache invalidation.

        Uses the index's monotonic ``revision`` rather than ``id()``: a rebuilt
        index always carries a fresh revision, so a cached lint entry computed
        against the previous index is invalidated the moment the new index is
        swapped in — without it, an ``id()`` recycled by the allocator left the
        cache returning stale, index-dependent diagnostics until the next edit.
        """
        provider = self.lint_use_case.index_provider
        if provider is None:
            return 0
        return provider().revision

    def handle(self, query: DiagnosticsQuery, sink: DiagnosticSink) -> None:
        """Parse the document and route it through the lint pipeline.

        Returns cached results when the document content and index haven't changed.
        Non-YAML documents (``.py``, ``.sql``) are skipped silently — the YAML
        parser would raise a syntax error on Python source, which is incorrect
        for those file types. Turbine treats SQL/Python files as auxiliary
        artefacts referenced from contracts, not as standalone lint targets.
        """
        if not is_yaml_uri(query.uri):
            return
        entry = self.resolve_lint_entry(query)
        sink.extend(entry.diagnostics)

    def resolve_lint_entry(self, query: DiagnosticsQuery) -> LintCacheEntry:
        """Return a cached or freshly built lint entry, maintaining the LRU cache."""
        content_hash = hash(query.content)
        index_id = self.current_index_id()
        with self.cache_lock:
            cached = self.lint_cache.get(query.uri)
            if (
                cached is not None
                and cached.content_hash == content_hash
                and cached.index_id == index_id
            ):
                self.lint_cache.move_to_end(query.uri)
                return cached
        entry = self.build_lint_entry(query, content_hash, index_id)
        with self.cache_lock:
            self.lint_cache[query.uri] = entry
            self.lint_cache.move_to_end(query.uri)
            while len(self.lint_cache) > LINT_CACHE_MAX:
                self.lint_cache.popitem(last=False)
        return entry

    def build_lint_entry(
        self, query: DiagnosticsQuery, content_hash: int, index_id: int
    ) -> LintCacheEntry:
        """Execute the full lint pipeline and return a cacheable entry."""
        try:
            source = self.parser(Path(query.uri), query.content)
        except TurbineError as exc:
            return LintCacheEntry(
                content_hash=content_hash,
                index_id=index_id,
                diagnostics=tuple(exc.diagnostics),
                contracts=(),
            )

        contracts: tuple[DatasetSpec, ...] = ()
        collector = DiagnosticCollector()
        try:
            lint_collector, contracts = self.lint_use_case.lint_source_with_contracts(source)
            collector.extend(lint_collector.items)
            if self.versioning_rule is not None:
                diagnostic = self.versioning_rule.check(query.uri, query.content)
                if diagnostic is not None:
                    collector.add(diagnostic)
        except TurbineError as exc:
            collector.extend(exc.diagnostics)
        return LintCacheEntry(
            content_hash=content_hash,
            index_id=index_id,
            diagnostics=tuple(collector.items),
            contracts=contracts,
        )
