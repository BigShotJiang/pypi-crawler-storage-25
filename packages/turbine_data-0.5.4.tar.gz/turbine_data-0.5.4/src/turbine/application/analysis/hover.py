"""Application-layer hover service."""

import re
from collections.abc import Callable
from pathlib import Path
from typing import cast

from turbine.core.analysis.context import (
    KeyContext,
    SqlFileContext,
    resolve_context_at_position,
    uri_to_path,
)
from turbine.core.analysis.features.hover import (
    COLUMN_NAME_PATH_RE,
    SCHEMA_NAME_PATH_RE,
    HoverInfo,
    HoverQuery,
    format_column_refs,
    format_field_hover,
    format_schema_refs,
    resolve_column_hover,
    resolve_jinja_hover,
    resolve_value,
)
from turbine.core.analysis.ports import DocumentTreePort, SchemaResolver
from turbine.core.building_blocks import DiagnosticSink, TurbineError
from turbine.core.common import FIELD_ID, SQL_EXT, YAML_EXTS, RawSource
from turbine.core.contract import ProjectIndex
from turbine.core.contract.ports import ContractReaderRegistry

ODCS_SCHEMA_NAME_FORMAT_DOC = (
    'Format: `schema.table` (e.g. `"public.orders"`). Single-segment names are accepted; '
    "the schema defaults to the connection's `search_path`."
)


SLA_PROPERTIES_PATH_RE = re.compile(r"^slaProperties\.(\d+)$")


def extract_sla_sibling_context(data: dict[str, object], parent_path: str) -> dict[str, str] | None:
    """Build sibling-context for the SLA entry whose field is currently being hovered.

    When the hover is on a field inside ``slaProperties[N]``, this returns
    ``{"property": <that-entry's-property-value>}`` so the walker can pick the
    property-specific description from ``x-contextDescriptions`` (e.g. the
    retention vs frequency variants of ``valueExt``).  Returns ``None`` when
    *parent_path* isn't an SLA entry or the property value is missing.
    """
    match = SLA_PROPERTIES_PATH_RE.match(parent_path)
    if match is None:
        return None
    sla_entries = data.get("slaProperties")
    if not isinstance(sla_entries, list):
        return None
    index = int(match.group(1))
    if index >= len(sla_entries):
        return None
    entry: object = sla_entries[index]
    if not isinstance(entry, dict):
        return None
    property_value = cast("dict[str, object]", entry).get("property")
    if not isinstance(property_value, str):
        return None
    return {"property": property_value}


class HoverService:
    """Resolve hover documentation for YAML contracts, quality specs, and SQL files."""

    def __init__(
        self,
        registry: ContractReaderRegistry,
        parser: Callable[[Path, str], RawSource],
        index_provider: Callable[[], ProjectIndex],
        schema_resolver: SchemaResolver,
        tree_port: DocumentTreePort,
        checks_dir: Path | None = None,
    ) -> None:
        """Store the reader registry, parser, index provider, schema resolver, and tree port."""
        self.registry = registry
        self.parser = parser
        self.index_provider = index_provider
        self.schema_resolver = schema_resolver
        self.tree_port = tree_port
        self.checks_dir = checks_dir

    def hover(self, query: HoverQuery, sink: DiagnosticSink) -> HoverInfo | None:
        """Dispatch to YAML or SQL hover resolution based on file extension."""
        uri = query.uri
        if uri.endswith(SQL_EXT):
            return self.hover_sql(query)
        if uri.endswith(YAML_EXTS):
            return self.hover_yaml(query, sink)
        return None

    def hover_yaml(self, query: HoverQuery, sink: DiagnosticSink) -> HoverInfo | None:
        """Show schema field documentation for a key or value in a YAML file."""
        try:
            source = self.parser(Path(query.uri), query.content)
        except TurbineError as exc:
            sink.extend(exc.diagnostics)
            return None

        ctx = resolve_context_at_position(self.tree_port, query.uri, query.line, query.col)
        if ctx is None:
            return None

        parent_path = ctx.dotted_path.rsplit(".", 1)[0] if "." in ctx.dotted_path else ""
        sibling_context = extract_sla_sibling_context(source.data, parent_path)
        field_doc = self.schema_resolver.resolve_field(
            source.data, parent_path, ctx.key_name, sibling_context=sibling_context
        )
        if field_doc is None:
            return None

        content = format_field_hover(ctx.key_name, field_doc)
        if SCHEMA_NAME_PATH_RE.match(ctx.dotted_path):
            content += "\n\n" + ODCS_SCHEMA_NAME_FORMAT_DOC

        if ctx.is_value_position:
            refs = self.resolve_cross_references(source.data, ctx)
            if refs:
                content += "\n\n---\n\n" + refs

        return HoverInfo(content=content, range=ctx.key_range)

    def resolve_cross_references(self, data: dict[str, object], ctx: KeyContext) -> str | None:
        """Build a "Referenced by" section for schema names and column names."""
        contract_id = data.get(FIELD_ID)
        if not isinstance(contract_id, str):
            return None
        index = self.index_provider()

        if SCHEMA_NAME_PATH_RE.match(ctx.dotted_path):
            return format_schema_refs(contract_id, index)

        if COLUMN_NAME_PATH_RE.match(ctx.dotted_path):
            col_name = resolve_value(data, ctx.dotted_path)
            if isinstance(col_name, str):
                return format_column_refs(col_name, index)

        return None

    def hover_sql(self, query: HoverQuery) -> HoverInfo | None:
        """Show documentation for Jinja variables, params, or column names in SQL."""
        sql_path = uri_to_path(query.uri)
        ctx = SqlFileContext.from_path(sql_path, self.index_provider(), self.checks_dir)
        if ctx is None:
            return None

        lines = query.content.splitlines()
        if query.line < 1 or query.line > len(lines):
            return None
        line_text = lines[query.line - 1]
        col = query.col - 1  # convert 1-indexed to 0-indexed for regex

        return resolve_jinja_hover(line_text, col, ctx) or resolve_column_hover(line_text, col, ctx)
