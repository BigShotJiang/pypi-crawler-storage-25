"""Filter dismissed diagnostics out of a publish batch and prune stale dismissals.

The filter sits at every LSP diagnostic-publish seam (push and pull). It
partitions the lint result into kept vs dropped based on the persisted
dismissals, builds the active anchor set from every visible dismissible
diagnostic, and asks the store to drop dismissals whose anchor no longer
appears in that set. Dropping happens in one ``purge_invalid`` call so a
column rename (or schema removal) re-surfaces previously-dismissed warnings on
the very next publish.

ERROR severity is always emitted, regardless of ``data.dismissible``. The flag
is policy from the rule; severity is policy from the diagnostic itself.
Belt-and-braces: even a buggy rule that sets ``dismissible=True`` on an
ERROR-class diagnostic cannot suppress that error.
"""

from turbine.core.building_blocks import Diagnostic, Severity
from turbine.core.contract.dismissal import DismissalKey, DismissalStore


def filter_and_purge(
    uri: str, diagnostics: tuple[Diagnostic, ...], store: DismissalStore
) -> tuple[Diagnostic, ...]:
    """Drop dismissed diagnostics and refresh the store's active-anchor set.

    Iterates *diagnostics* once, keeping every ERROR and every diagnostic
    whose ``DismissalKey`` is not in the store. Builds the active set from
    every visible dismissible entry — including the ones we kept because the
    user has not (yet) dismissed them. Then asks the store to drop dismissals
    whose anchor no longer appears in that active set, scoped to *uri*.
    """
    kept: list[Diagnostic] = []
    active: set[DismissalKey] = set()
    for diagnostic in diagnostics:
        data = diagnostic.data
        if data is None or not data.dismissible:
            kept.append(diagnostic)
            continue
        key = DismissalKey(file_uri=uri, rule_id=data.kind.value, anchor=data.anchor)
        active.add(key)
        if diagnostic.severity != Severity.ERROR and store.is_dismissed(key):
            continue
        kept.append(diagnostic)
    store.purge_invalid(uri, active)
    return tuple(kept)
