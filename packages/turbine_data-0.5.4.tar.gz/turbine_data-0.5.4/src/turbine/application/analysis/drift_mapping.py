"""Conversion helpers from ValidationFinding → Diagnostic.

Three call sites (the CLI ``check validate`` command, the LSP pull-diagnostic
drift pass, and the LSP ``turbine/validateSchema`` request) all need to map a
``ValidationFinding`` to a domain ``Diagnostic`` carrying structured
``DiagnosticData`` for the code-action dispatch to pick up. Keeping that
mapping in one place is the difference between the code-action and CLI paths
staying in sync vs silently drifting (a bug we hit once already when the CLI
mapping was missing four validation types).
"""

from __future__ import annotations

from dataclasses import replace
from pathlib import Path

from turbine.core.analysis.source_spans import find_column_span, find_table_span
from turbine.core.building_blocks import (
    DiagnosticBuilder,
    DiagnosticData,
    DiagnosticKind,
    Severity,
    Span,
)
from turbine.core.building_blocks.diagnostics.types import Diagnostic
from turbine.core.common import RawSource
from turbine.core.validation.model import ValidationFinding, ValidationType


def help_for_finding(finding: ValidationFinding, severity: Severity) -> str | None:
    """Pick a short help hint for drift diagnostics, keyed on the finding type."""
    if finding.validation_type == ValidationType.EXTRA_IN_DB:
        return f"add `{finding.column}` to the contract or drop it from the database"
    if finding.validation_type == ValidationType.MISSING_IN_DB:
        return f"remove `{finding.column}` from the contract or add it to the database"
    if severity in {Severity.WARNING, Severity.ERROR} and finding.db_value is not None:
        return f"database has `{finding.db_value}`"
    return None


def finding_to_diagnostic(
    finding: ValidationFinding, source: RawSource | None, source_path: Path, table_label: str
) -> Diagnostic:
    """Convert a ValidationFinding into a Diagnostic with structured data + span.

    When *source* is provided, the diagnostic is annotated with the narrowest
    available range: the column's ``name:`` value if found, otherwise the
    enclosing ``schema[n].name`` line. When *source* is None the diagnostic
    carries no range — the caller is the CLI reading from disk and may have
    failed to parse.
    """
    diag_id = finding.validation_type.diagnostic_id
    severity = finding.validation_type.severity

    span: Span | None = None
    if source is not None:
        span = find_column_span(source, source_path, finding.column) or find_table_span(
            source, source_path, table_label
        )

    builder = DiagnosticBuilder(
        diag_id, severity, f"{table_label}.{finding.column}: {finding.validation_type.label}"
    )
    builder.annotate(span)
    help_text = help_for_finding(finding, severity)
    if help_text is not None:
        builder.help(help_text)
    diagnostic = builder.build()
    data = DiagnosticData(
        kind=DiagnosticKind(diag_id.value),
        field_name=finding.column,
        schema_name=table_label,
        contract_value=finding.contract_value,
        db_value=finding.db_value,
        suggested_value=finding.db_value,
    )
    return replace(diagnostic, data=data)
