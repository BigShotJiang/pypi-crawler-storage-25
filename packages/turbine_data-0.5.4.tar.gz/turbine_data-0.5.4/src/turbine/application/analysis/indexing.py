"""Index rebuild use case — re-parse changed files and rebuild the project index."""

from collections.abc import Callable, Sequence
from dataclasses import dataclass
from pathlib import Path

from loguru import logger

from turbine.application.diagnostics import DiagnosticCollector
from turbine.core.building_blocks import TurbineError
from turbine.core.common import DatasetSpec, RawSource
from turbine.core.contract import IndexFactory, ProjectIndex
from turbine.core.contract.ports import ContractReaderRegistry


@dataclass(frozen=True, slots=True)
class FileChange:
    """A single file change event from the editor or file watcher.

    Attrs:
        path: Absolute path to the changed file.
        deleted: True if the file was removed, False if created or modified.
    """

    path: Path
    deleted: bool


def rebuild_project_index(
    current_index: ProjectIndex,
    changes: Sequence[FileChange],
    registry: ContractReaderRegistry,
    parser: Callable[[Path], RawSource],
    index_factory: IndexFactory,
) -> ProjectIndex:
    """Incrementally rebuild the project index after file changes.

    Removes contracts from deleted and changed paths, re-parses changed
    files, and merges everything into a fresh index.

    Args:
        current_index: The existing project index to update.
        changes: File change events (creates, modifications, deletions).
        registry: Readers for detecting and parsing contract formats.
        parser: Parses a file path into a RawSource.
        index_factory: Builds a new ProjectIndex from a contract tuple.

    Returns:
        A new ProjectIndex reflecting all applied changes.
    """
    deleted_paths = {c.path for c in changes if c.deleted}
    changed_paths = {c.path for c in changes if not c.deleted}

    removed_paths = deleted_paths | changed_paths
    existing = [c for c in current_index.contracts() if c.metadata.source_path not in removed_paths]

    new_contracts: list[DatasetSpec] = []
    for path in changed_paths:
        new_contracts.extend(parse_contract_file(path, registry, parser))

    all_contracts = tuple(existing + new_contracts)
    logger.debug(f"Index rebuilt: {len(all_contracts)} contracts")
    return index_factory(all_contracts)


def parse_contract_file(
    path: Path, registry: ContractReaderRegistry, parser: Callable[[Path], RawSource]
) -> tuple[DatasetSpec, ...]:
    """Parse a single file into zero or more contract specs.

    Catches parse errors (YAML, OS, Turbine) and logs a warning instead
    of propagating them, so a single bad file doesn't break the index rebuild.

    Args:
        path: Filesystem path to the contract file.
        registry: Readers for detecting and parsing contract formats.
        parser: Parses a file path into a RawSource.

    Returns:
        Parsed contract specs, or an empty tuple on any failure.
    """
    try:
        source = parser(path)
        sink = DiagnosticCollector()
        contracts = registry.read(source, sink)
    except (OSError, TurbineError) as exc:
        logger.warning(f"Failed to parse {path}: {exc}")
        return ()

    if sink.items:
        logger.warning(f"Parse issues in {path}: {len(sink.items)} diagnostic(s)")
    return contracts
