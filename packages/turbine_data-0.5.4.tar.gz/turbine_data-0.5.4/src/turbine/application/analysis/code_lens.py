"""Application-layer code lens service."""

from collections.abc import Callable
from pathlib import Path

from turbine.core.analysis.context import uri_to_path
from turbine.core.analysis.features.code_lens import (
    CodeLensInfo,
    CodeLensQuery,
    detect_kind,
    extract_contract_id,
    extract_dataset,
    extract_target_contract,
    is_datasource_file,
)
from turbine.core.analysis.features.code_lens_tree import (
    ContractCheckEntry,
    ContractLensView,
    QualitySpecCheck,
    QualitySpecLensView,
    build_contract_view,
    build_quality_spec_view,
)
from turbine.core.analysis.features.completion import (
    CONTRACT_SCAFFOLD,
    DUCKDB_SCAFFOLD,
    POSTGRES_SCAFFOLD,
    QUALITY_SCAFFOLD,
    SNOWFLAKE_SCAFFOLD,
)
from turbine.core.building_blocks import TextRange, TurbineError
from turbine.core.common import CommandId, ProjectLayout, RawSource
from turbine.core.common.constants import ContractKind
from turbine.core.contract import ProjectIndex

TOP_LINE_RANGE = TextRange(start_line=1, start_col=1, end_line=1, end_col=1)

DATASOURCE_SCAFFOLDS: tuple[tuple[str, str], ...] = (
    ("Insert Postgres scaffold", POSTGRES_SCAFFOLD),
    ("Insert Snowflake scaffold", SNOWFLAKE_SCAFFOLD),
    ("Insert DuckDB scaffold", DUCKDB_SCAFFOLD),
)


def is_inside_dir(uri: str, directory: Path) -> bool:
    """Return True when the file URI's filesystem path is inside *directory*."""
    try:
        uri_to_path(uri).resolve().relative_to(directory.resolve())
    except (OSError, ValueError):
        return False
    return True


def insert_snippet_lens(title: str, snippet: str) -> CodeLensInfo:
    """Build a code lens whose click fires the client-side insert-snippet command."""
    return CodeLensInfo(
        title=title, command=CommandId.INSERT_SNIPPET, range=TOP_LINE_RANGE, arguments=(snippet,)
    )


def single_line_range(line_num: int) -> TextRange:
    """Build a zero-width TextRange anchored at a single line."""
    return TextRange(start_line=line_num, start_col=1, end_line=line_num, end_col=1)


class CodeLensService:
    """Produce code lens annotations for contract schemas and datasource files."""

    def __init__(
        self,
        index_provider: Callable[[], ProjectIndex],
        parser: Callable[[Path, str], RawSource],
        layout: ProjectLayout | None = None,
    ) -> None:
        """Store the project index provider, YAML parser, and layout."""
        self.index_provider = index_provider
        self.parser = parser
        self.layout = layout

    def code_lenses(self, query: CodeLensQuery) -> tuple[CodeLensInfo, ...]:
        """Produce code lenses based on file type."""
        if not query.content.strip():
            return self.scaffold_lenses(query)
        kind = detect_kind(query.content)
        if kind in (ContractKind.DATA_CONTRACT, ContractKind.QUALITY_SPEC):
            return self.parsed_lenses(query, kind)
        if is_datasource_file(query.content):
            return self.datasource_lenses(query)
        return ()

    def parsed_lenses(self, query: CodeLensQuery, kind: ContractKind) -> tuple[CodeLensInfo, ...]:
        """Parse the document and dispatch to the format-specific lens builder."""
        source = self.try_parse(query)
        if source is None:
            return ()
        if kind == ContractKind.DATA_CONTRACT:
            return self.contract_lenses(query, build_contract_view(source))
        return self.quality_spec_lenses(query, build_quality_spec_view(source))

    def try_parse(self, query: CodeLensQuery) -> RawSource | None:
        """Return the parsed RawSource for *query*, or ``None`` on syntax errors."""
        try:
            return self.parser(Path(query.uri), query.content)
        except TurbineError:
            return None

    def scaffold_lenses(self, query: CodeLensQuery) -> tuple[CodeLensInfo, ...]:
        """Top-line insert-scaffold lenses for empty files inside known layout dirs."""
        if self.layout is None:
            return ()
        if is_inside_dir(query.uri, self.layout.datasources_dir):
            return tuple(insert_snippet_lens(title, snippet) for title, snippet in DATASOURCE_SCAFFOLDS)
        if is_inside_dir(query.uri, self.layout.quality_dir):
            return (insert_snippet_lens("Insert QualitySpec scaffold", QUALITY_SCAFFOLD),)
        if is_inside_dir(query.uri, self.layout.contracts_dir):
            return (insert_snippet_lens("Insert DataContract scaffold", CONTRACT_SCAFFOLD),)
        return ()

    def contract_lenses(self, query: CodeLensQuery, view: ContractLensView) -> tuple[CodeLensInfo, ...]:
        """Build per-schema lenses for a DataContract file."""
        if not view.schemas:
            return ()

        contract_id = extract_contract_id(query.content)
        index = self.index_provider()
        ref_count = len(index.find_specs_for_contract(contract_id))

        schema_count = len(view.schemas)
        lenses: list[CodeLensInfo] = []
        for schema in view.schemas:
            lenses.extend(
                self.schema_action_lenses(contract_id, ref_count, schema.name, schema.name_line)
            )
            lenses.append(
                CodeLensInfo(
                    title=f"Add dataset check on {schema.name}",
                    command=CommandId.ADD_CHECK,
                    range=single_line_range(schema.quality_anchor_line),
                    arguments=(query.uri, "dataset", "", schema.name),
                )
            )
            lenses.extend(self.contract_check_lenses(contract_id, schema.name, schema.schema_checks))
            for prop in schema.properties:
                title = f"Add column check on {prop.name}"
                if schema_count > 1:
                    title = f"Add column check on {schema.name}.{prop.name}"
                lenses.append(
                    CodeLensInfo(
                        title=title,
                        command=CommandId.ADD_CHECK,
                        range=single_line_range(prop.quality_anchor_line),
                        arguments=(query.uri, "column", prop.name, schema.name),
                    )
                )
                lenses.extend(self.contract_check_lenses(contract_id, schema.name, prop.checks))

        return tuple(lenses)

    def schema_action_lenses(
        self, contract_id: str, ref_count: int, schema_name: str, line: int
    ) -> tuple[CodeLensInfo, ...]:
        """Validate / Run Quality / Create Quality Spec / references lenses for a schema entry."""
        anchor = single_line_range(line)
        ref_label = f"{ref_count} reference{'s' if ref_count != 1 else ''}"
        return (
            CodeLensInfo(
                title="Validate Contract",
                command=CommandId.VALIDATE_CONTRACT,
                range=anchor,
                arguments=(contract_id, schema_name),
            ),
            CodeLensInfo(
                title="Run Quality",
                command=CommandId.RUN_QUALITY_CHECK,
                range=anchor,
                arguments=(contract_id, schema_name),
            ),
            CodeLensInfo(
                title="Create Quality Spec",
                command=CommandId.GENERATE_QUALITY_SPEC,
                range=anchor,
                arguments=(contract_id, schema_name),
            ),
            CodeLensInfo(
                title=ref_label,
                command=CommandId.SHOW_REFERENCES,
                range=anchor,
                arguments=(contract_id,),
            ),
        )

    def contract_check_lenses(
        self, contract_id: str, schema_name: str, checks: tuple[ContractCheckEntry, ...]
    ) -> list[CodeLensInfo]:
        """Per-check Run lenses."""
        return [
            CodeLensInfo(
                title=f"Run: {check.check_name}",
                command=CommandId.RUN_SINGLE_CHECK,
                range=single_line_range(check.line),
                arguments=(contract_id, schema_name, check.check_name),
            )
            for check in checks
        ]

    def quality_spec_lenses(
        self, query: CodeLensQuery, view: QualitySpecLensView
    ) -> tuple[CodeLensInfo, ...]:
        """Build lenses for a QualitySpec file."""
        spec_id = extract_contract_id(query.content)
        target_contract = extract_target_contract(query.content)
        dataset = extract_dataset(query.content)

        lenses: list[CodeLensInfo] = [
            CodeLensInfo(
                title="Run Quality",
                command=CommandId.RUN_QUALITY_CHECK,
                range=TOP_LINE_RANGE,
                arguments=(spec_id, dataset),
            )
        ]

        if target_contract:
            lenses.append(
                CodeLensInfo(
                    title=f"Go to {target_contract}",
                    command=CommandId.GO_TO_CONTRACT,
                    range=TOP_LINE_RANGE,
                    arguments=(target_contract,),
                )
            )

        index = self.index_provider()
        ref_count = len(index.find_specs_for_contract(target_contract)) if target_contract else 0
        ref_label = f"{ref_count} reference{'s' if ref_count != 1 else ''}"
        lenses.append(
            CodeLensInfo(
                title=ref_label,
                command=CommandId.SHOW_REFERENCES,
                range=TOP_LINE_RANGE,
                arguments=(spec_id,),
            )
        )

        if view.columns_section_line is not None:
            lenses.append(
                CodeLensInfo(
                    title="Add column check",
                    command=CommandId.ADD_CHECK,
                    range=single_line_range(view.columns_section_line),
                    arguments=(query.uri, "column", ""),
                )
            )

        for column in view.columns:
            lenses.append(
                CodeLensInfo(
                    title=f"Add column check on {column.name}",
                    command=CommandId.ADD_CHECK,
                    range=single_line_range(column.name_line),
                    arguments=(query.uri, "column", column.name),
                )
            )
            lenses.extend(self.quality_spec_check_lenses(spec_id, dataset, column.checks))

        add_check_line = view.quality_section_line or 1
        lenses.append(
            CodeLensInfo(
                title="Add dataset check",
                command=CommandId.ADD_CHECK,
                range=single_line_range(add_check_line),
                arguments=(query.uri, "dataset", ""),
            )
        )

        lenses.extend(self.quality_spec_check_lenses(spec_id, dataset, view.quality_checks))

        return tuple(lenses)

    def quality_spec_check_lenses(
        self, spec_id: str, dataset: str, checks: tuple[QualitySpecCheck, ...]
    ) -> list[CodeLensInfo]:
        """Per-check Run lenses for a QualitySpec."""
        return [
            CodeLensInfo(
                title=f"Run: {check.check_name}",
                command=CommandId.RUN_SINGLE_CHECK,
                range=single_line_range(check.line),
                arguments=(spec_id, dataset, check.check_name),
            )
            for check in checks
        ]

    def datasource_lenses(self, query: CodeLensQuery) -> tuple[CodeLensInfo, ...]:
        """Build Test Connection + Create DataContract lenses for a datasource file."""
        lens_range = TextRange(start_line=1, start_col=1, end_line=1, end_col=1)
        return (
            CodeLensInfo(
                title="Test Connection",
                command=CommandId.TEST_DATASOURCE_CONNECTION,
                range=lens_range,
                arguments=(query.uri,),
            ),
            CodeLensInfo(
                title="Create DataContract",
                command=CommandId.CREATE_CONTRACT_FROM_DATASOURCE,
                range=lens_range,
                arguments=(query.uri,),
            ),
        )
