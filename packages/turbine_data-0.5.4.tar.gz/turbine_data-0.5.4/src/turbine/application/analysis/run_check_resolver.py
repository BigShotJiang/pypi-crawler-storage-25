"""Resolve a ``CheckUseCase`` for a (uri, datasource) pair, capturing errors.

Wraps the ``CheckUseCaseFactory`` Callable so call sites get either a
ready-to-stream ``CheckUseCase`` or a typed error ``RunCheckResult``. The
resolver flattens the two failure modes the factory can produce — raising at
build time or returning ``None`` for an unconfigured datasource — into the
result type the LSP handler eventually sends back to the editor. Keeps the
handler declarative.

Also handles the optional-datasource case: when the caller passes ``None``,
the resolver looks up a default through ``default_datasource_provider``
before invoking the factory. This lets bulk callers (the ``run all
checks`` editor command) skip per-contract datasource resolution.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass

from loguru import logger

from turbine.application.operations.check import CheckUseCase
from turbine.core.analysis.protocol import RunCheckResult
from turbine.core.common.error_summary import summarize_exception

CheckUseCaseFactory = Callable[[str, str], CheckUseCase | None]
DefaultDatasourceProvider = Callable[[str], str | None]


@dataclass(frozen=True, slots=True)
class RunCheckResolver:
    """Build a ``CheckUseCase`` from a uri+datasource, or fold the failure into a result."""

    factory: CheckUseCaseFactory
    default_datasource_provider: DefaultDatasourceProvider

    def resolve(self, uri: str, datasource: str | None) -> CheckUseCase | RunCheckResult:
        """Return the use case or a ``RunCheckResult`` carrying a one-line error.

        ``datasource=None`` triggers a fallback lookup via
        ``default_datasource_provider``. If that yields ``None`` the contract
        has no datasources configured and the user gets a friendly message
        rather than a structured error from deeper in the stack.

        Adapter-boundary errors (factory raising) are surfaced via
        ``summarize_exception`` so callers don't see a raw traceback. Unknown
        datasources (factory returning ``None``) become a friendly
        ``"datasource '<name>' is not configured"`` message.
        """
        actual = datasource if datasource is not None else self.default_datasource_provider(uri)
        if actual is None:
            return error_result(f"no datasource configured for contract at {uri!r}")
        try:
            use_case = self.factory(uri, actual)
        except Exception as exc:  # noqa: BLE001 — adapter boundary, surface to client
            logger.opt(exception=exc).error("run_check: pipeline build failed")
            return error_result(summarize_exception(exc))
        if use_case is None:
            return error_result(f"datasource '{actual}' is not configured")
        return use_case


def error_result(message: str) -> RunCheckResult:
    """Build an empty ``RunCheckResult`` carrying *message* for the client."""
    return RunCheckResult(contract_id="", outcomes=(), passed=False, error=message)
