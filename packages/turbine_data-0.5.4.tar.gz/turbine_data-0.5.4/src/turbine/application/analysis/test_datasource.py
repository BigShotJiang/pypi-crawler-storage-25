"""Application-layer service for the LSP turbine/testDatasource method.

Resolves the project-scoped datasource repository via an injected
callable (the LSP composition root binds it to
``ProjectDatasourceServicesRegistry.services_for(uri).repo``), looks the
name up, and runs a connectivity probe via the existing
:class:`ConnectivityProbe` port. Maps the :class:`ProbeResult` to the
LSP-facing :class:`TestDatasourceResult`.

Taking a callable keeps the application layer free of any
``presentation/`` imports — the registry lives next to the LSP session
because that is where its lifecycle belongs.
"""

from __future__ import annotations

from collections.abc import Callable

from turbine.application.diagnostics import DiagnosticCollector
from turbine.core.analysis.protocol import TestDatasourceParams, TestDatasourceResult
from turbine.core.common.datasource import DatasourceConfig
from turbine.core.common.ports import ConnectivityProbe, DatasourceRepository


class TestDatasourceService:
    """Probe a single datasource by ``(uri, name)`` and return a structured result."""

    __test__ = False

    def __init__(
        self, datasource_repo_for: Callable[[str], DatasourceRepository], probe: ConnectivityProbe
    ) -> None:
        self.datasource_repo_for = datasource_repo_for
        self.probe = probe

    def test(self, params: TestDatasourceParams) -> TestDatasourceResult:
        """Probe ``params.name`` inside the project enclosing ``params.uri``."""
        datasource = self.lookup(params.uri, params.name)
        if datasource is None:
            return TestDatasourceResult(
                name=params.name, ok=False, error=f"datasource `{params.name}` not found"
            )

        result = self.probe.probe(datasource)
        if result.connected:
            return TestDatasourceResult(name=params.name, ok=True, latency_ms=result.latency_ms)
        return TestDatasourceResult(name=params.name, ok=False, error=result.error)

    def lookup(self, uri: str, name: str) -> DatasourceConfig | None:
        """Return the datasource config for *name* in the project at *uri*, or None."""
        repo = self.datasource_repo_for(uri)
        sink = DiagnosticCollector()
        try:
            datasource = repo.get(name, sink)
        except Exception:  # noqa: BLE001
            return None
        if sink.has_errors:
            return None
        return datasource
