"""Document link analysis handler — clickable links in quality specs and contracts.

Column references inside SQL files are handled by ``textDocument/definition``;
they're not document links. Document links carry no destination range, so they
land at line 1 of the contract — which is wrong for identifier-level navigation.
"""

from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path

from turbine.core.analysis import LinkInfo
from turbine.core.building_blocks import DiagnosticSink, TurbineError
from turbine.core.common import RawSource
from turbine.core.contract import ProjectIndex


@dataclass(frozen=True, slots=True)
class StaticCheckReference:
    """A YAML scalar that names a file-backed check."""

    value_path: str
    value: str


@dataclass(frozen=True, slots=True)
class CheckFileLinkTarget:
    """A check file target plus the YAML value path that should become clickable."""

    value_path: str
    file_name: str


def lookup(mapping: object, key: str) -> object:
    """Read *key* from *mapping* if it is a dict; otherwise return None."""
    if not isinstance(mapping, dict):
        return None
    for existing_key, value in mapping.items():
        if existing_key == key:
            return value
    return None


def list_field(mapping: object, key: str) -> list[object]:
    """Read a list field from a YAML mapping."""
    value = lookup(mapping, key)
    if not isinstance(value, list):
        return []
    return list(value)


def string_reference(mapping: object, key: str, value_path: str) -> StaticCheckReference | None:
    """Read a string field and remember its source-map path."""
    value = lookup(mapping, key)
    if not isinstance(value, str):
        return None
    return StaticCheckReference(value_path=value_path, value=value)


def first_string_reference(
    mapping: object, candidates: tuple[tuple[str, str], ...]
) -> StaticCheckReference | None:
    """Return the first present string field from *candidates*."""
    for key, value_path in candidates:
        reference = string_reference(mapping, key, value_path)
        if reference is not None:
            return reference
    return None


def static_python_reference(
    mapping: object, candidates: tuple[tuple[str, str], ...]
) -> StaticCheckReference | None:
    """Return a static Python check reference, skipping dotted imports."""
    reference = first_string_reference(mapping, candidates)
    if reference is None or "." in reference.value:
        return None
    return reference


def sql_check_ref(check: object) -> str | None:
    """Return the SQL check's ``name`` reference if the shape matches and there's no inline query.

    Returns None when the check isn't a dict, the sql block isn't a dict, the
    name isn't a string, or the check carries an inline ``query:`` (which
    takes precedence over a file reference).
    """
    sql_block = lookup(check, "sql")
    name_ref = lookup(sql_block, "name")
    if not isinstance(name_ref, str) or lookup(sql_block, "query") is not None:
        return None
    return name_ref


@dataclass(frozen=True, slots=True)
class DocumentLinkQuery:
    """Request for document links in a file."""

    uri: str
    content: str


class DocumentLinkHandler:
    """Resolve clickable links for quality specs, contracts, and SQL files."""

    def __init__(
        self,
        parser: Callable[[Path, str], RawSource],
        index_provider: Callable[[], ProjectIndex],
        checks_dir: Path,
    ) -> None:
        """Store dependencies for document link resolution."""
        self.parser = parser
        self.index_provider = index_provider
        self.checks_dir = checks_dir

    def handle(self, query: DocumentLinkQuery, sink: DiagnosticSink) -> tuple[LinkInfo, ...]:
        """Return all document links in the file."""
        if not query.uri.endswith((".yml", ".yaml")):
            return ()
        try:
            return self.links_yaml(query)
        except TurbineError as exc:
            sink.extend(exc.diagnostics)
            return ()

    def links_yaml(self, query: DocumentLinkQuery) -> tuple[LinkInfo, ...]:
        """Build document links for contract and quality spec YAML files."""
        try:
            source = self.parser(Path(query.uri), query.content)
        except Exception:  # noqa: BLE001
            return ()

        source_kind = source.data.get("kind")
        if source_kind == "DataContract":
            return tuple(check_file_links(source, self.checks_dir))
        if source_kind != "QualitySpec":
            return ()

        links: list[LinkInfo] = []
        links.extend(self.contract_links(source))
        links.extend(check_file_links(source, self.checks_dir))
        return tuple(links)

    def contract_links(self, source: RawSource) -> list[LinkInfo]:
        """Build links for targetContract references."""
        target = source.data.get("targetContract")
        if not isinstance(target, str):
            return []

        target_uri = self.index_provider().resolve_contract_link(target)
        if target_uri is None:
            return []

        value_range = source.source_map.range_for_value("targetContract")
        if value_range is None:
            return []

        return [LinkInfo(range=value_range, target_uri=target_uri, tooltip=f"Open contract {target}")]


def check_file_links(source: RawSource, checks_dir: Path) -> list[LinkInfo]:
    """Build links for SQL and Python check file references."""
    links: list[LinkInfo] = []
    for target in check_file_targets(source):
        value_range = source.source_map.range_for_value(target.value_path)
        if value_range is None:
            continue
        resolved_path = checks_dir / target.file_name
        links.append(
            LinkInfo(
                range=value_range, target_uri=resolved_path.as_uri(), tooltip=f"Open {target.file_name}"
            )
        )
    return links


def check_file_targets(source: RawSource) -> list[CheckFileLinkTarget]:
    """Collect check file targets from supported YAML document kinds."""
    source_kind = source.data.get("kind")
    if source_kind == "QualitySpec":
        return quality_spec_file_targets(source.data)
    if source_kind == "DataContract":
        return contract_file_targets(source.data)
    return []


def quality_spec_file_targets(data: object) -> list[CheckFileLinkTarget]:
    """Collect check file targets from a QualitySpec document."""
    targets: list[CheckFileLinkTarget] = []
    targets.extend(quality_spec_check_targets(list_field(data, "quality"), "quality"))
    for column_idx, column in enumerate(list_field(data, "columns")):
        targets.extend(
            quality_spec_check_targets(list_field(column, "checks"), f"columns.{column_idx}.checks")
        )
    return targets


def quality_spec_check_targets(checks: list[object], key_prefix: str) -> list[CheckFileLinkTarget]:
    """Collect file targets from a QualitySpec check list."""
    targets: list[CheckFileLinkTarget] = []
    for check_idx, check in enumerate(checks):
        item_path = f"{key_prefix}.{check_idx}"
        sql_target = quality_spec_sql_target(check, item_path)
        if sql_target is not None:
            targets.append(sql_target)
        python_target = quality_spec_python_target(check, item_path)
        if python_target is not None:
            targets.append(python_target)
    return targets


def quality_spec_sql_target(check: object, item_path: str) -> CheckFileLinkTarget | None:
    """Return a QualitySpec SQL file target, if the check is file-backed."""
    name_ref = sql_check_ref(check)
    if name_ref is None:
        return None
    return CheckFileLinkTarget(value_path=f"{item_path}.sql.name", file_name=f"{name_ref}.sql")


def quality_spec_python_target(check: object, item_path: str) -> CheckFileLinkTarget | None:
    """Return a QualitySpec Python file target, if the check is static."""
    python_block = lookup(check, "python")
    reference = static_python_reference(
        python_block,
        (("function", f"{item_path}.python.function"), ("name", f"{item_path}.python.name")),
    )
    if reference is None:
        return None
    return CheckFileLinkTarget(value_path=reference.value_path, file_name=f"{reference.value}.py")


def contract_file_targets(data: object) -> list[CheckFileLinkTarget]:
    """Collect check file targets from embedded contract quality blocks."""
    targets: list[CheckFileLinkTarget] = []
    for schema_idx, schema in enumerate(list_field(data, "schema")):
        targets.extend(
            contract_quality_targets(list_field(schema, "quality"), f"schema.{schema_idx}.quality")
        )
        targets.extend(contract_property_quality_targets(schema, schema_idx))
    return targets


def contract_property_quality_targets(schema: object, schema_idx: int) -> list[CheckFileLinkTarget]:
    """Collect check file targets from a contract schema's property quality blocks."""
    targets: list[CheckFileLinkTarget] = []
    for property_idx, property_item in enumerate(list_field(schema, "properties")):
        targets.extend(
            contract_quality_targets(
                list_field(property_item, "quality"),
                f"schema.{schema_idx}.properties.{property_idx}.quality",
            )
        )
    return targets


def contract_quality_targets(checks: list[object], key_prefix: str) -> list[CheckFileLinkTarget]:
    """Collect file targets from embedded contract custom/turbine checks."""
    targets: list[CheckFileLinkTarget] = []
    for check_idx, check in enumerate(checks):
        target = contract_quality_target(check, f"{key_prefix}.{check_idx}")
        if target is not None:
            targets.append(target)
    return targets


def contract_quality_target(check: object, item_path: str) -> CheckFileLinkTarget | None:
    """Return a contract embedded check file target."""
    if lookup(check, "type") != "custom" or lookup(check, "engine") != "turbine":
        return None
    implementation = lookup(check, "implementation")
    check_type = lookup(implementation, "check")
    if check_type == "python":
        return contract_python_target(implementation, item_path)
    if check_type == "sql":
        return contract_sql_target(check, implementation, item_path)
    return None


def contract_python_target(implementation: object, item_path: str) -> CheckFileLinkTarget | None:
    """Return a contract embedded Python file target, if the reference is static."""
    reference = static_python_reference(
        implementation,
        (
            ("function", f"{item_path}.implementation.function"),
            ("name", f"{item_path}.implementation.name"),
        ),
    )
    if reference is None:
        return None
    return CheckFileLinkTarget(value_path=reference.value_path, file_name=f"{reference.value}.py")


def contract_sql_target(
    check: object, implementation: object, item_path: str
) -> CheckFileLinkTarget | None:
    """Return a contract embedded SQL file target, if the check is file-backed."""
    if lookup(implementation, "query") is not None:
        return None
    reference = first_string_reference(implementation, (("name", f"{item_path}.implementation.name"),))
    if reference is None:
        reference = string_reference(check, "name", f"{item_path}.name")
    if reference is None:
        return None
    return CheckFileLinkTarget(value_path=reference.value_path, file_name=f"{reference.value}.sql")
