"""Application service for interactive onboarding tours.

Orchestrates semantic highlight resolution, step gating, and client notification.
The service owns one active `Watcher` slot at a time (a tour has one current
step) and a live ``dirty_buffers`` mapping that mirrors the editor's dirty
buffers; state-based completions consult that mapping when they re-evaluate.

The service also funnels every action-invocation signal through
``publish_action_invoked``: both the editor's
``turbine/onboarding/actionInvoked`` request and the LSP-routed action handlers
(``run_validate``, ``run_single_check``, ``run_sandbox_checks``) feed this one
funnel, which fans out to the active ``ActionFired`` watcher (if any).
"""

from __future__ import annotations

from collections.abc import Callable
from pathlib import Path

from loguru import logger

from turbine.application.analysis.onboarding_targets import OnboardingTargetResolver, RawSourceParser
from turbine.core.analysis.protocol import ListToursResult, StepDto, StepSkipKind, TourDto
from turbine.core.building_blocks import EventBus, TurbineError
from turbine.core.building_blocks.onboarding_actions import StepActionKind
from turbine.core.common.file_edits import FileEdits
from turbine.core.onboarding.completions import (
    DiagnosticCleared,
    FieldEquals,
    FieldPresent,
    NullIntrospectionSource,
    WatchContext,
    Watcher,
)
from turbine.core.onboarding.events import DirtyBufferChanged, StepCompleted, SurfaceVisibilityChanged
from turbine.core.onboarding.ports import (
    ActionInvokedStream,
    DiagnosticSource,
    IntrospectionSource,
    Scheduler,
    SurfaceVisibilitySource,
    YamlParser,
)
from turbine.core.onboarding.skip_edits import plan_skip_edit
from turbine.core.onboarding.step import RunCheck, RunIntrospection, SkipAction, SkipEdit, Step
from turbine.core.onboarding.tours import Tour


class TourService:
    """Lists tours with resolved semantic targets and manages the active watcher."""

    def __init__(
        self,
        *,
        tours: tuple[Tour, ...],
        yaml_parser: YamlParser,
        diagnostics: DiagnosticSource,
        event_bus: EventBus,
        scheduler: Scheduler,
        notify_step_completed: Callable[[str, str], None],
        source_parser: RawSourceParser,
        action_invoked_stream: ActionInvokedStream,
        surface_visibility_source: SurfaceVisibilitySource,
        introspection_source: IntrospectionSource | None = None,
    ) -> None:
        self.tours = {tour.id: tour for tour in tours}
        self.yaml_parser = yaml_parser
        self.diagnostics = diagnostics
        self.event_bus = event_bus
        self.scheduler = scheduler
        self.notify_step_completed = notify_step_completed
        self.source_parser = source_parser
        self.action_invoked_stream = action_invoked_stream
        self.surface_visibility_source = surface_visibility_source
        self.target_resolver = OnboardingTargetResolver(source_parser)
        # Substitute the null source at construction so WatchContext never
        # has to fall back; downstream watchers see one stable Protocol.
        self.introspection_source: IntrospectionSource = (
            introspection_source if introspection_source is not None else NullIntrospectionSource()
        )
        self.watcher: Watcher | None = None
        self.dirty_buffers: dict[str, str] = {}
        self.translate_uri: Callable[[str], str | None] = lambda uri: None  # noqa: ARG005 — replaced on watch_step
        # Subscribe once; per-watch subscriptions would leak handlers and
        # re-fire notify_step_completed N times after N watch cycles. The
        # dirty-buffer dispatcher updates the shared buffers mapping that
        # state-based watchers consult during evaluation.
        self.event_bus.subscribe(StepCompleted, self.on_step_completed)
        self.event_bus.subscribe(DirtyBufferChanged, self.on_dirty_buffer_changed)

    def list_tours(self, tour_root: Path) -> ListToursResult:
        tour_dtos: list[TourDto] = []
        for tour in self.tours.values():
            step_dtos: list[StepDto] = []
            for step in tour.steps:
                step_dto = StepDto(
                    id=step.id,
                    title=step.title,
                    content=step.content,
                    target=step.target,
                    resolved_target=self.target_resolver.resolve(tour_root, step.target),
                    kind=step.kind,
                    action=step.action,
                    skip_kind=classify_skip(step.skip),
                    gated=step.completion is not None,
                )
                step_dtos.append(step_dto)
            tour_dto = TourDto(id=tour.id, title=tour.title, steps=tuple(step_dtos))
            tour_dtos.append(tour_dto)
        return ListToursResult(tours=tuple(tour_dtos))

    def watch_step(
        self,
        tour_id: str,
        step_id: str,
        translate_uri: Callable[[str], str | None],
        tour_root: Path | None = None,
    ) -> None:
        logger.info(f"tour_service.watch_step called: tour={tour_id} step={step_id}")
        tour = self.tours.get(tour_id)
        if tour is None:
            logger.error(f"tour_service.watch_step: unknown tour {tour_id}")
            raise KeyError(tour_id)
        step = next((step for step in tour.steps if step.id == step_id), None)
        if step is None:
            logger.error(f"tour_service.watch_step: unknown step {step_id}")
            raise KeyError(step_id)
        if step.completion is None:
            logger.info(f"tour_service.watch_step: step {step_id} is narration -- no gate")
            return

        completion_name = type(step.completion).__name__
        logger.info(f"tour_service.watch_step: arming {step_id} completion={completion_name}")

        self.translate_uri = translate_uri
        if self.watcher is not None:
            self.watcher.stop()

        if tour_root is not None:
            seed_buffers_from_disk(self.dirty_buffers, step, tour_root)

        ctx = WatchContext(
            tour_id=tour_id,
            step_id=step_id,
            yaml_parser=self.yaml_parser,
            diagnostics=self.diagnostics,
            introspection_source=self.introspection_source,
            surface_visibility_source=self.surface_visibility_source,
            scheduler=self.scheduler,
            event_bus=self.event_bus,
            action_invoked_stream=self.action_invoked_stream,
            translate_uri=translate_uri,
            buffers=self.dirty_buffers,
        )
        self.watcher = step.completion.watch(ctx)

    def unwatch_step(self) -> None:
        if self.watcher is not None:
            logger.info("tour_service.unwatch_step: stopping active watcher")
            self.watcher.stop()
            self.watcher = None

    def publish_action_invoked(self, kind: StepActionKind) -> None:
        """Single funnel for action-invocation signals to active ActionFired watchers."""
        logger.info(f"tour_service.publish_action_invoked: kind={kind}")
        self.action_invoked_stream.publish(kind)

    def publish_surface_visibility(self, surface_id: str, *, visible: bool) -> None:
        """Record a surface's latest visibility and notify active SurfaceVisible watchers.

        Writes to the source first so a watcher reacting to the event sees
        the new state when it re-evaluates. State updates that don't change
        the recorded value still fan out — watchers fire only on the
        false→true edge, so a redundant ``visible=True`` is a cheap no-op.
        """
        logger.info(f"tour_service.publish_surface_visibility: {surface_id}={visible}")
        self.surface_visibility_source.set_visible(surface_id, visible=visible)
        self.event_bus.publish(SurfaceVisibilityChanged(surface_id=surface_id, visible=visible))

    def on_dirty_buffer_changed(self, event: DirtyBufferChanged) -> None:
        """Update the shared buffers mapping so state-based watchers re-evaluate against fresh text."""
        sandbox_path = self.translate_uri(event.uri)
        if sandbox_path is None:
            return
        self.dirty_buffers[sandbox_path] = event.text

    def on_step_completed(self, event: StepCompleted) -> None:
        logger.info(f"tour_service.on_step_completed: tour={event.tour_id} step={event.step_id}")
        self.notify_step_completed(event.tour_id, event.step_id)

    def build_step_edits(self, tour_id: str, step_id: str, tour_root: Path) -> FileEdits | None:
        """Build a :class:`FileEdits` bundle for a step's SkipEdit action.

        Returns ``None`` when the step has no skip action, the action is
        not a ``SkipEdit``, the target file is missing, or the YAML path
        cannot be resolved. The caller (an LSP handler or CLI runner)
        applies the bundle through a :class:`CodeWriter`.
        """
        tour = self.tours.get(tour_id)
        if tour is None:
            raise KeyError(tour_id)
        step = next((step for step in tour.steps if step.id == step_id), None)
        if step is None:
            raise KeyError(step_id)
        if not isinstance(step.skip, SkipEdit):
            return None

        file_path = tour_root / step.skip.file
        if not file_path.exists():
            return None

        text = file_path.read_text()
        try:
            source = self.source_parser(file_path, text)
        except (OSError, TurbineError, TypeError, ValueError):
            return None

        edits = plan_skip_edit(text, source.source_map, step.skip)
        if edits is None:
            return None
        return FileEdits(uri=file_path.as_uri(), edits=edits)


def seed_buffers_from_disk(buffers: dict[str, str], step: Step, tour_root: Path) -> None:
    """Pre-load disk content for a state-based completion's target file.

    The completion model evaluates-on-arm, so a Step whose state is already
    satisfied (file on disk holds the expected value) fires immediately.
    Without this seed, the first edit after arming would be the first
    DirtyBufferChanged the watcher sees — and we would miss the
    already-satisfied case.

    Variants whose evaluator does not consult `buffers` (Timer, ActionFired,
    IntrospectionPopulated) are skipped silently; their gates either don't
    need disk content or read from a different source.
    """
    completion = step.completion
    if not isinstance(completion, FieldEquals | FieldPresent | DiagnosticCleared):
        return
    file = completion.file
    path = tour_root / file
    if path.exists() and file not in buffers:
        buffers[file] = path.read_text()


def classify_skip(skip: SkipAction | None) -> StepSkipKind:
    """Map a runtime SkipAction onto its wire-shape discriminator."""
    if isinstance(skip, SkipEdit):
        return StepSkipKind.EDIT
    if isinstance(skip, RunCheck):
        return StepSkipKind.RUN_CHECK
    if isinstance(skip, RunIntrospection):
        return StepSkipKind.RUN_INTROSPECTION
    return StepSkipKind.NONE
