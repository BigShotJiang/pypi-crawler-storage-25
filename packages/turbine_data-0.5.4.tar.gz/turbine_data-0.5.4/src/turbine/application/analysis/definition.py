"""Application-layer definition service."""

from collections.abc import Callable
from pathlib import Path

from turbine.core.analysis.context import SqlFileContext, uri_to_path
from turbine.core.analysis.features.definition import (
    DefinitionQuery,
    resolve_column_definition,
    resolve_param_definition,
)
from turbine.core.analysis.model import LocationInfo
from turbine.core.building_blocks import DiagnosticSink, TurbineError
from turbine.core.common import SQL_EXT, RawSource
from turbine.core.contract import ProjectIndex
from turbine.core.contract.ports import ContractReaderRegistry


class DefinitionService:
    """Resolve go-to-definition for SQL template files.

    Supports two jump targets:

    * **Jinja params** (``{{ params.xxx }}``) jump to the param key in the
      quality spec YAML.
    * **Column names** jump to the property definition in the data contract.

    Example::

        service = DefinitionService(registry, parser, index_provider, checks_dir)
        location = service.definition(query, sink)
    """

    def __init__(
        self,
        registry: ContractReaderRegistry,
        parser: Callable[[Path, str], RawSource],
        index_provider: Callable[[], ProjectIndex],
        checks_dir: Path | None = None,
    ) -> None:
        """Store the reader registry, YAML parser, project index provider, and checks dir."""
        self.registry = registry
        self.parser = parser
        self.index_provider = index_provider
        self.checks_dir = checks_dir

    def definition(self, query: DefinitionQuery, sink: DiagnosticSink) -> LocationInfo | None:
        """Locate the definition of a Jinja param or column name in a SQL file.

        Only operates on ``.sql`` files; returns None for other file types.

        Args:
            query: Cursor position and SQL document content.
            sink: Collects any parse diagnostics on failure.

        Returns:
            Location pointing to the definition site, or None.
        """
        if not query.uri.endswith(SQL_EXT):
            return None
        try:
            return self.definition_sql(query)
        except TurbineError as exc:
            sink.extend(exc.diagnostics)
            return None

    def definition_sql(self, query: DefinitionQuery) -> LocationInfo | None:
        """Resolve definition for a SQL template file.

        Tries Jinja param resolution first, then falls back to column name
        resolution against the target contract.

        Args:
            query: Cursor position and SQL document content.

        Returns:
            Location of the definition, or None if the word under cursor
            doesn't match any known param or column.
        """
        sql_path = uri_to_path(query.uri)
        ctx = SqlFileContext.from_path(sql_path, self.index_provider(), self.checks_dir)
        if ctx is None:
            return None

        lines = query.content.splitlines()
        if query.line < 1 or query.line > len(lines):
            return None
        line_text = lines[query.line - 1]
        col = query.col - 1  # 1-indexed to 0-indexed

        return resolve_param_definition(line_text, col, ctx, self.parser) or resolve_column_definition(
            line_text, col, ctx, self.index_provider(), self.parser
        )
