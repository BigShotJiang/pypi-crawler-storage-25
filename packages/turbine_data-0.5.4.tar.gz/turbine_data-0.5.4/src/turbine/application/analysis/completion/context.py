"""Bundled context handed to every completer arm.

Built once per request by the service, then read by the dispatcher's arms. The
dataclass is the canonical seam: adding a new port for a future completer is
one field here, one assignment in the service, and one read in the arm.
"""

from dataclasses import dataclass
from pathlib import Path

from turbine.core.analysis.ports import SchemaResolver
from turbine.core.building_blocks import SourceMap
from turbine.core.common import IntrospectionCache
from turbine.core.contract import DomainRegistry, ProjectIndex

__all__ = ["CompletionContext"]


@dataclass(frozen=True, slots=True)
class CompletionContext:
    """Everything a completer arm needs, built once per request."""

    data: dict[str, object]
    path: str
    source_map: SourceMap
    schema_resolver: SchemaResolver
    index: ProjectIndex | None
    introspection: IntrospectionCache | None
    domain_registry: DomainRegistry | None
    checks_dir: Path | None
