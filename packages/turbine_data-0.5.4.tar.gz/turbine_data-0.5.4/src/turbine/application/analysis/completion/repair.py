"""Single-attempt YAML repair for half-typed keys.

Tree-sitter handles most broken YAML via ERROR nodes, but a half-typed key
(e.g. ``di`` without ``:``) corrupts the entire parse into an ERROR spanning
the whole file. We recover by appending ``:`` to the cursor line and reparsing
once. No double-attempt, no compare-by-shape — if the repair doesn't produce
a resolvable document, the dispatcher's catch-all returns ``()``.
"""

from collections.abc import Callable
from pathlib import Path

from turbine.core.analysis.features.completion import CompletionQuery
from turbine.core.analysis.ports import SchemaResolver
from turbine.core.building_blocks import TurbineError
from turbine.core.common import RawSource

__all__ = ["append_colon_at_cursor", "parse_or_repair"]


def parse_or_repair(
    parser: Callable[[Path, str], RawSource], schema_resolver: SchemaResolver, query: CompletionQuery
) -> RawSource | None:
    """Parse *query.content*; on failure (or unresolvable kind), repair-and-reparse once.

    Returns ``None`` when both attempts fail to produce a parse the schema
    resolver can classify — the caller's contract is to return ``()`` in that
    case rather than guessing from indentation.
    """
    source = parse_silently(parser, query.uri, query.content)
    if source is not None and schema_resolver.can_resolve(source.data):
        return source
    repaired_content = append_colon_at_cursor(query.content, query.line)
    if repaired_content is None:
        return None
    repaired = parse_silently(parser, query.uri, repaired_content)
    if repaired is None or not schema_resolver.can_resolve(repaired.data):
        return None
    return repaired


def parse_silently(parser: Callable[[Path, str], RawSource], uri: str, content: str) -> RawSource | None:
    """Parse *content* through *parser*, swallowing TurbineError into ``None``."""
    try:
        return parser(Path(uri), content)
    except TurbineError:
        return None


def append_colon_at_cursor(content: str, line: int) -> str | None:
    """Append ``:`` to the 1-indexed *line* so a half-typed key becomes valid YAML.

    Returns the repaired content, or ``None`` if the cursor line is out of
    bounds, blank, or already ends with a colon/value.
    """
    lines = content.splitlines(keepends=True)
    if line <= 0 or line > len(lines):
        return None
    idx = line - 1
    raw = lines[idx]
    stripped = raw.rstrip("\n").rstrip()
    if not stripped or ":" in stripped:
        return None
    suffix = "\n" if raw.endswith("\n") else ""
    lines[idx] = stripped + ":" + suffix
    return "".join(lines)
