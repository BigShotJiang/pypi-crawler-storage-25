"""Array-item completers — the ``(DASH_ITEM | EMPTY, ArrayOf*)`` dispatcher arms.

``complete_object_item`` offers the array item's keys (mirrors today's
``CompletionService.key_completions`` walking ``parent.0``). ``complete_scalar_item``
is the lattice's missing primitive: when the array's items are scalars, suggest
enum + example values directly instead of leaking outer keys.
"""

from dataclasses import replace

from turbine.application.analysis.completion.completers import object_keys
from turbine.application.analysis.completion.context import CompletionContext
from turbine.core.analysis.features.completion import CompletionItemInfo, CompletionKind
from turbine.core.analysis.features.completion_targets import ArrayOfObjects, ArrayOfScalars, ObjectShape

__all__ = ["complete_object_item", "complete_scalar_item"]


def complete_object_item(
    target: ArrayOfObjects, ctx: CompletionContext
) -> tuple[CompletionItemInfo, ...]:
    """Suggest the array item's keys (filtered by what's already typed on this item)."""
    item_path = f"{ctx.path}.0" if ctx.path else "0"
    item_ctx = replace(ctx, path=item_path)
    return object_keys.complete(ObjectShape(node=target.item_node), item_ctx)


def complete_scalar_item(
    target: ArrayOfScalars, ctx: CompletionContext
) -> tuple[CompletionItemInfo, ...]:
    """Suggest scalar values for an array of scalars (enum + example, deduped)."""
    del ctx
    item_node = target.item_node
    enum_items = tuple(
        CompletionItemInfo(label=value, kind=CompletionKind.ENUM_VALUE, detail="value", sort_prefix="0")
        for value in item_node.enum_values
    )
    example_items = tuple(
        CompletionItemInfo(
            label=value, kind=CompletionKind.ENUM_VALUE, detail="example", sort_prefix="1"
        )
        for value in item_node.examples
        if value not in item_node.enum_values
    )
    return enum_items + example_items
