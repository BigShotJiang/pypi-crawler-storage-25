"""Database introspection completers — ``(VALUE, DbTable)`` and ``(VALUE, DbColumn)`` arms.

Reads the introspection cache through ``ctx``. When no cache is configured or
the cache is empty, ``complete_table`` falls back to the ``schema.table``
snippet so the user can still produce a syntactically-correct ODCS name.
"""

from turbine.application.analysis.completion.context import CompletionContext
from turbine.core.analysis.features.column_refs import db_column_suggestions, db_table_suggestions
from turbine.core.analysis.features.completion import CompletionItemInfo, CompletionKind

__all__ = ["SCHEMA_TABLE_SNIPPET", "complete_column", "complete_table"]


SCHEMA_TABLE_SNIPPET = CompletionItemInfo(
    label="schema.table",
    kind=CompletionKind.SNIPPET,
    detail="ODCS schema name",
    documentation="Insert an explicit ODCS schema/table name.",
    insert_text="${1:schema}.${2:table}",
    sort_prefix="0",
    is_snippet=True,
)


def complete_table(ctx: CompletionContext) -> tuple[CompletionItemInfo, ...]:
    """Suggest known DB tables; emit the schema.table snippet when no introspection exists.

    Single-snippet fallback fires when the cache provider is absent or the
    cache exists but has no known tables — the user still needs a placeholder
    that produces a valid ODCS name.
    """
    suggestions = db_table_suggestions(ctx.introspection)
    if not suggestions:
        return (SCHEMA_TABLE_SNIPPET,)
    return tuple(
        CompletionItemInfo(
            label=suggestion.label,
            kind=CompletionKind.ENUM_VALUE,
            detail=suggestion.detail,
            documentation=suggestion.documentation,
            sort_prefix="0",
        )
        for suggestion in suggestions
    )


def complete_column(ctx: CompletionContext) -> tuple[CompletionItemInfo, ...]:
    """Suggest DB columns from the schema's table, minus columns already declared."""
    suggestions = db_column_suggestions(ctx.data, ctx.path, ctx.introspection)
    if not suggestions:
        return ()
    return tuple(
        CompletionItemInfo(
            label=suggestion.label,
            kind=CompletionKind.FIELD,
            detail=suggestion.detail,
            documentation=suggestion.documentation,
            sort_prefix="0",
        )
        for suggestion in suggestions
    )
