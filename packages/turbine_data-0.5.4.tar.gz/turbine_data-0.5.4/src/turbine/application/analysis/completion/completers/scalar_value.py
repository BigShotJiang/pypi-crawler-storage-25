"""Scalar value completer — the ``(VALUE, Scalar)`` dispatcher arm.

Suggests enum values and examples for the field under the cursor. The parent
schema node is re-resolved to grab the FieldDoc with its ``x-enumDescriptions``
documentation; the leaf node from the target alone doesn't carry per-value
documentation strings.
"""

from turbine.application.analysis.completion.context import CompletionContext
from turbine.core.analysis.features.completion import CompletionItemInfo, CompletionKind
from turbine.core.analysis.features.completion_targets import Scalar
from turbine.core.common import FieldDoc

__all__ = ["complete"]


def complete(target: Scalar, ctx: CompletionContext) -> tuple[CompletionItemInfo, ...]:
    """Project the field's enum + example values into completion items."""
    parent_path = ctx.path.rsplit(".", 1)[0] if "." in ctx.path else ""
    parent_node = ctx.schema_resolver.resolve_children(ctx.data, parent_path)
    field_doc = parent_node.children.get(target.key_name)
    if field_doc is None:
        return ()
    return enum_and_example_items(field_doc, target.key_name)


def enum_and_example_items(field_doc: FieldDoc, key_name: str) -> tuple[CompletionItemInfo, ...]:
    """Build completion items from a field's enum values + examples, deduped.

    Per-value documentation from ``x-enumDescriptions`` rides into each enum
    item's ``documentation`` so the editor can show the difference between
    options as the user cycles through suggestions.
    """
    enum_items = tuple(
        CompletionItemInfo(
            label=value,
            kind=CompletionKind.ENUM_VALUE,
            detail=f"{key_name} value",
            documentation=field_doc.enum_descriptions.get(value, ""),
            sort_prefix="0",
        )
        for value in field_doc.enum_values
    )
    example_items = tuple(
        CompletionItemInfo(
            label=value, kind=CompletionKind.ENUM_VALUE, detail=f"{key_name} example", sort_prefix="1"
        )
        for value in field_doc.examples
        if value not in field_doc.enum_values
    )
    return enum_items + example_items
