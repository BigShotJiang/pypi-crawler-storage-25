"""Object-keys completer — the ``(KEY | EMPTY, ObjectShape)`` dispatcher arm.

Suggests schema-allowed keys filtered against keys already present at the
cursor's parent path. Each suggestion whose schema shape is an object (or
array of objects) with required subfields is returned with a tabstop snippet
so the user gets the full structure prefilled instead of a bare ``key:``.
"""

from turbine.application.analysis.completion.context import CompletionContext
from turbine.core.analysis.features.completion import CompletionItemInfo, field_to_completion
from turbine.core.analysis.features.completion_targets import ObjectShape
from turbine.core.analysis.features.snippet_builder import (
    Prefill,
    PrefillFn,
    PrefillLookup,
    build_snippet,
    scalar_key_snippet,
)
from turbine.core.building_blocks import SourceMap
from turbine.core.common.contract_walk import iter_schema_properties
from turbine.core.common.logical_type import LogicalType
from turbine.core.common.schema_walker import ResolvedNode

__all__ = ["complete", "find_siblings", "snippet_for_child"]


def complete(target: ObjectShape, ctx: CompletionContext) -> tuple[CompletionItemInfo, ...]:
    """Suggest schema-allowed keys, filtering out keys already present at the path."""
    node = target.node
    siblings = find_siblings(ctx.path, ctx.source_map)
    prefill = DEFAULT_PREFILLS.bind(ctx.data)
    items: list[CompletionItemInfo] = []
    for name, field_doc in node.children.items():
        if name in siblings:
            continue
        snippet = snippet_for_child(node, name, prefill)
        if snippet is None:
            snippet = scalar_key_snippet(name, field_doc)
        items.append(field_to_completion(name, field_doc, insert_text=snippet))
    return tuple(items)


def snippet_for_child(node: ResolvedNode, name: str, prefill: PrefillFn) -> str | None:
    """Build a tabstop snippet for *name* when the resolver surfaced its raw schema."""
    raw = node.raw_children.get(name)
    navigator = node.navigator
    if raw is None or navigator is None:
        return None
    return build_snippet(name, raw, navigator, prefill)


def find_siblings(parent_path: str, source_map: SourceMap) -> set[str]:
    """Collect key names already present under the given parent path."""
    if not parent_path:
        return {path for path in source_map.key_paths() if "." not in path}
    prefix = f"{parent_path}."
    return {
        path[len(prefix) :]
        for path in source_map.key_paths()
        if path.startswith(prefix) and "." not in path[len(prefix) :]
    }


def first_timestamp_element(data: dict[str, object]) -> Prefill | None:
    """Return ``<schema>.<column>`` for the first time-like column in *data*.

    Used to prefill ``slaProperties[].element`` at completion time so the
    user doesn't have to type it out. Walks the same shape consumed by the
    column-ref resolver, so the two stay in lockstep on field naming.
    """
    for table, prop in iter_schema_properties(data):
        if LogicalType.is_time_like(prop.get("logicalType")):
            return Prefill(value=f"{table}.{prop['name']}")
    return None


def default_sla_value(data: dict[str, object]) -> Prefill | None:
    """Seed ``slaProperties[].value`` with a plausible duration the user can edit."""
    del data
    return Prefill(value="24")


DEFAULT_PREFILLS = PrefillLookup(
    entries={
        "slaProperties.0.element": first_timestamp_element,
        "slaProperties.0.value": default_sla_value,
    }
)
