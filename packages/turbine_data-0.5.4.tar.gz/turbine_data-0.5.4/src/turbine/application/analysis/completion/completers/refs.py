"""Reference-kind completers — the value-position ``*Ref`` dispatcher arms.

Covers column, contract, dataset, sql-check, and approved-domain references.
Each arm reads a single port off ``ctx`` and projects to completion items.
"""

from turbine.application.analysis.completion.context import CompletionContext
from turbine.core.analysis.features.column_refs import ColumnSuggestion, resolve_column_ref
from turbine.core.analysis.features.completion import (
    CompletionItemInfo,
    CompletionKind,
    contract_id_completions,
    dataset_completions,
    sql_check_name_completions,
)
from turbine.core.analysis.features.completion_targets import ColumnRef
from turbine.core.common import FIELD_KIND, ContractKind
from turbine.core.common.column_ref_metadata import REF_KIND_FIELD

__all__ = [
    "EMPTY_SCHEMA_HINT",
    "complete_column",
    "complete_contract",
    "complete_dataset",
    "complete_domain",
    "complete_sql_check",
]


EMPTY_SCHEMA_HINT = CompletionItemInfo(
    label="(no columns declared)",
    kind=CompletionKind.FIELD,
    detail="hint",
    documentation="Add entries under `schema[].properties[]` to see column suggestions here.",
    sort_prefix="9",
)


def complete_column(target: ColumnRef, ctx: CompletionContext) -> tuple[CompletionItemInfo, ...]:
    """Resolve a column-kind reference via the shared resolver and project to LSP items.

    When the kind matches but the document has no columns declared yet, surface
    a hint completion so the user knows why the list is empty rather than
    seeing "No suggestions."
    """
    extension = {REF_KIND_FIELD: target.kind.value}
    suggestions = resolve_column_ref(ctx.data, extension, ctx.index, ctx.path, ctx.introspection)
    if suggestions is None:
        return ()
    if not suggestions:
        return (EMPTY_SCHEMA_HINT,)
    return tuple(to_completion_item(suggestion) for suggestion in suggestions)


def complete_contract(ctx: CompletionContext) -> tuple[CompletionItemInfo, ...]:
    """Suggest known DataContract ids for a QualitySpec's ``targetContract`` value."""
    if ctx.index is None:
        return ()
    return contract_id_completions(ctx.index)


def complete_dataset(ctx: CompletionContext) -> tuple[CompletionItemInfo, ...]:
    """Suggest dataset names from the resolved target contract."""
    if ctx.index is None:
        return ()
    items = dataset_completions(ctx.data, ctx.index)
    return items if items is not None else ()


def complete_sql_check(ctx: CompletionContext) -> tuple[CompletionItemInfo, ...]:
    """Suggest ``.sql`` filenames from the configured checks directory."""
    if ctx.checks_dir is None:
        return ()
    return sql_check_name_completions(ctx.checks_dir)


def complete_domain(ctx: CompletionContext) -> tuple[CompletionItemInfo, ...]:
    """Suggest approved domains for a DataContract's top-level ``domain`` value."""
    if ctx.data.get(FIELD_KIND) != ContractKind.DATA_CONTRACT:
        return ()
    if ctx.domain_registry is None:
        return ()
    allowed = ctx.domain_registry.allowed()
    if allowed is None:
        return ()
    return tuple(
        CompletionItemInfo(
            label=domain,
            kind=CompletionKind.ENUM_VALUE,
            detail="Approved domain",
            documentation="Approved Contract domain from the domain registry.",
            sort_prefix="0",
        )
        for domain in allowed
    )


def to_completion_item(suggestion: ColumnSuggestion) -> CompletionItemInfo:
    """Project a domain ``ColumnSuggestion`` into the LSP-shaped completion item."""
    return CompletionItemInfo(
        label=suggestion.label,
        kind=CompletionKind.FIELD,
        detail=suggestion.detail,
        documentation=suggestion.documentation,
        sort_prefix="0",
    )
