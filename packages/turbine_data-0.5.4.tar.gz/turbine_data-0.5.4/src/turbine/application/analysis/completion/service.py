"""Application-layer completion service — thin router into the lattice.

URI routing matches today's behaviour:

- empty content      → scaffold completions for the URI's layout slot
- ``.sql`` extension → SQL/Jinja completions (unchanged)
- ``.yaml`` extension → YAML completion via the (role x target) lattice
- anything else      → ``()``

The YAML branch builds a single ``CompletionContext`` per request and hands
``(role, target, ctx)`` to ``dispatch.complete``. No internal classifier survives
here: the four-way discriminant, the dual-resolver blank-line compare, and the
indentation-guess fallback are deleted — when the single repair pass fails or
the path falls off the schema, the dispatcher's catch-all returns ``()``.
"""

from collections.abc import Callable
from pathlib import Path

from turbine.application.analysis.completion.context import CompletionContext
from turbine.application.analysis.completion.dispatch import complete as dispatch_complete
from turbine.application.analysis.completion.repair import parse_or_repair
from turbine.application.analysis.completion.schema_target import target_at
from turbine.core.analysis.context import (
    KeyContext,
    SqlFileContext,
    resolve_context_at_position,
    uri_to_path,
)
from turbine.core.analysis.features.completion import (
    CompletionItemInfo,
    CompletionQuery,
    cursor_in_jinja_block,
    jinja_completions,
    resolve_parent_from_indent,
    scaffold_completions,
    sql_plain_completions,
)
from turbine.core.analysis.features.completion_targets import (
    ArrayOfObjects,
    ArrayOfScalars,
    CompletionTarget,
    ObjectShape,
)
from turbine.core.analysis.features.cursor_role import CursorRole, detect_role
from turbine.core.analysis.ports import DocumentTreePort, SchemaResolver
from turbine.core.building_blocks import SourceMap, TextRange
from turbine.core.common import SQL_EXT, YAML_EXTS, IntrospectionCache, ProjectLayout, RawSource
from turbine.core.contract import DomainRegistry, ProjectIndex

__all__ = ["CompletionService", "is_inside"]


DATASOURCE_SCAFFOLD_LABELS = frozenset(
    {"Datasource: Postgres", "Datasource: Snowflake", "Datasource: DuckDB"}
)
ALL_SCAFFOLD_LABELS = DATASOURCE_SCAFFOLD_LABELS | {"DataContract", "QualitySpec"}


class CompletionService:
    """Schema-aware YAML and SQL completions for contract, quality spec, and SQL files."""

    def __init__(
        self,
        parser: Callable[[Path, str], RawSource],
        schema_resolver: SchemaResolver,
        tree_port: DocumentTreePort,
        index_provider: Callable[[], ProjectIndex] | None = None,
        introspection_provider: Callable[[], IntrospectionCache | None] | None = None,
        checks_dir: Path | None = None,
        layout: ProjectLayout | None = None,
        domain_registry: DomainRegistry | None = None,
    ) -> None:
        """Store the YAML parser, schema resolver, tree port, and optional providers."""
        self.parser = parser
        self.schema_resolver = schema_resolver
        self.tree_port = tree_port
        self.index_provider = index_provider
        self.layout = layout
        self.introspection_provider = introspection_provider
        self.checks_dir = checks_dir
        self.domain_registry = domain_registry

    def complete(self, query: CompletionQuery) -> tuple[CompletionItemInfo, ...]:
        """Dispatch by URI: empty → scaffolds, ``.sql`` → SQL/Jinja, ``.yaml`` → lattice."""
        if not query.content.strip():
            return self.scaffolds_for_uri(query.uri)
        if query.uri.endswith(SQL_EXT):
            return self.complete_sql(query)
        if query.uri.endswith(YAML_EXTS):
            return self.complete_yaml(query)
        return ()

    def scaffolds_for_uri(self, uri: str) -> tuple[CompletionItemInfo, ...]:
        """Pick scaffold snippets based on which configured directory the URI sits in."""
        labels = self.scaffold_labels_for_uri(uri)
        return tuple(item for item in scaffold_completions() if item.label in labels)

    def scaffold_labels_for_uri(self, uri: str) -> frozenset[str]:
        """Return the scaffold labels valid for *uri* under the current layout."""
        if self.layout is None:
            return ALL_SCAFFOLD_LABELS
        path = uri_to_path(uri)
        if is_inside(path, self.layout.datasources_dir):
            return DATASOURCE_SCAFFOLD_LABELS
        if is_inside(path, self.layout.quality_dir):
            return frozenset({"QualitySpec"})
        if is_inside(path, self.layout.contracts_dir):
            return frozenset({"DataContract"})
        return ALL_SCAFFOLD_LABELS

    def complete_sql(self, query: CompletionQuery) -> tuple[CompletionItemInfo, ...]:
        """Produce completions for SQL template files."""
        if self.index_provider is None:
            return ()
        sql_path = uri_to_path(query.uri)
        sql_ctx = SqlFileContext.from_path(sql_path, self.index_provider(), self.checks_dir)
        if sql_ctx is None:
            return ()
        lines = query.content.splitlines()
        if query.line < 1:
            return ()
        line_text = lines[query.line - 1] if query.line <= len(lines) else ""
        col = query.col - 1
        if cursor_in_jinja_block(line_text, col):
            return jinja_completions(line_text, col, sql_ctx)
        return sql_plain_completions(sql_ctx)

    def complete_yaml(self, query: CompletionQuery) -> tuple[CompletionItemInfo, ...]:
        """Route a YAML completion request through the lattice."""
        source = parse_or_repair(self.parser, self.schema_resolver, query)
        if source is None:
            return ()
        role = detect_role(line_text_at(query), query.col)
        path = path_for_role(role, self.tree_port, source.source_map, query)
        index = self.provide_index()
        introspection = self.provide_introspection()
        target = target_at(
            source.data,
            path,
            self.schema_resolver,
            index,
            introspection,
            self.domain_registry,
            self.checks_dir,
        )
        role = collapse_role_to_target(role, target)
        ctx = CompletionContext(
            data=source.data,
            path=path,
            source_map=source.source_map,
            schema_resolver=self.schema_resolver,
            index=index,
            introspection=introspection,
            domain_registry=self.domain_registry,
            checks_dir=self.checks_dir,
        )
        return dispatch_complete(role, target, ctx)

    def provide_index(self) -> ProjectIndex | None:
        """Resolve the project index through the configured provider, or ``None``."""
        if self.index_provider is None:
            return None
        return self.index_provider()

    def provide_introspection(self) -> IntrospectionCache | None:
        """Resolve the introspection cache through the configured provider, or ``None``."""
        if self.introspection_provider is None:
            return None
        return self.introspection_provider()


def collapse_role_to_target(role: CursorRole, target: CompletionTarget) -> CursorRole:
    """Pre-dispatch role collapse so the lattice keeps its PRD-meaningful cells.

    ``target_at`` returns the *shape* of the value at the cursor's resolved
    path. When the cursor sits in a key-typing or value-typing position on a
    container-shaped slot, the user wants the container's children:

    - ``KEY``-on-array  (half-typed item without dash) → ``DASH_ITEM`` semantics
    - ``VALUE``-on-array (cursor past ``key: `` of array-typed field) → ``DASH_ITEM``
    - ``VALUE``-on-object (cursor past ``key: `` of object-typed field) → ``KEY``

    The PRD's strict lattice marks the original combinations as
    impossible-by-grammar; the collapse here is the explicit, documented
    bridge between role detection (text-only) and target classification
    (schema-only).
    """
    if isinstance(target, (ArrayOfObjects, ArrayOfScalars)):
        if role in (CursorRole.KEY, CursorRole.VALUE):
            return CursorRole.DASH_ITEM
    elif isinstance(target, ObjectShape) and role is CursorRole.VALUE:
        return CursorRole.KEY
    return role


def is_inside(path: Path, directory: Path) -> bool:
    """Return True when *path* is inside *directory* (or is the directory itself)."""
    try:
        path.resolve().relative_to(directory.resolve())
    except (OSError, ValueError):
        return False
    return True


def line_text_at(query: CompletionQuery) -> str:
    """Return the text of the 1-indexed cursor line, or ``""`` past EOF."""
    lines = query.content.splitlines()
    if query.line < 1 or query.line > len(lines):
        return ""
    return lines[query.line - 1]


def path_for_role(
    role: CursorRole, tree_port: DocumentTreePort, source_map: SourceMap, query: CompletionQuery
) -> str:
    """Return the path ``target_at`` should classify for this cursor role.

    For ``KEY``, ``EMPTY``, and ``DASH_ITEM`` the path is the parent container
    being typed INTO (object or array). For ``VALUE`` it's the dotted path
    of the key whose value the cursor sits on.
    """
    if role is CursorRole.VALUE:
        return value_key_path(tree_port, source_map, query)
    return parent_container_path(tree_port, source_map, query)


def value_key_path(tree_port: DocumentTreePort, source_map: SourceMap, query: CompletionQuery) -> str:
    """Resolve the key-path the cursor sits on for VALUE-role completion."""
    key_ctx = resolve_context_at_position(tree_port, query.uri, query.line, query.col)
    if key_ctx is not None and key_ctx.is_value_position:
        return key_ctx.dotted_path
    map_hit = source_map_context(source_map, query.line, query.col)
    if map_hit is not None and map_hit.is_value_position:
        return map_hit.dotted_path
    return resolve_parent_from_indent(query.content, query.line, source_map, query.col)


def parent_container_path(
    tree_port: DocumentTreePort, source_map: SourceMap, query: CompletionQuery
) -> str:
    """Resolve the parent container path for KEY / EMPTY / DASH_ITEM roles."""
    key_ctx = resolve_context_at_position(tree_port, query.uri, query.line, query.col)
    if key_ctx is None:
        key_ctx = source_map_context(source_map, query.line, query.col)
    if key_ctx is not None and not key_ctx.is_value_position:
        return pop_last_segment(key_ctx.dotted_path)
    return resolve_parent_from_indent(query.content, query.line, source_map, query.col)


def pop_last_segment(dotted_path: str) -> str:
    """Drop the last ``.``-separated segment, returning ``""`` for top-level paths."""
    return dotted_path.rsplit(".", 1)[0] if "." in dotted_path else ""


def source_map_context(source_map: SourceMap, line: int, col: int) -> KeyContext | None:
    """O(n) source-map fallback when tree-sitter returns ``None``.

    Returns the deepest dotted path whose key or value range contains the cursor.
    """
    best: KeyContext | None = None
    for dotted in source_map.key_paths():
        key_range = source_map.range_for_key(dotted)
        if key_range is None:
            continue
        hit = match_position(source_map, dotted, key_range, line, col)
        if hit is None:
            continue
        if best is None or dotted.count(".") > best.dotted_path.count("."):
            best = hit
    return best


def match_position(
    source_map: SourceMap, dotted: str, key_range: TextRange, line: int, col: int
) -> KeyContext | None:
    """Check whether (line, col) falls on the key, its value, or past the colon."""
    if in_range(line, col, key_range) or at_key_end(line, col, key_range):
        return KeyContext.from_path(dotted, key_range, is_value_position=False)
    value_range = source_map.range_for_value(dotted)
    if value_range is not None and in_range(line, col, value_range):
        return KeyContext.from_path(dotted, key_range, is_value_position=True)
    if line == key_range.start_line and col > key_range.end_col:
        return KeyContext.from_path(dotted, key_range, is_value_position=True)
    return None


def in_range(line: int, col: int, text_range: TextRange) -> bool:
    """1-indexed (line, col) containment inside a TextRange (end-exclusive)."""
    if line < text_range.start_line or line > text_range.end_line:
        return False
    if line == text_range.start_line and col < text_range.start_col:
        return False
    return not (line == text_range.end_line and col >= text_range.end_col)


def at_key_end(line: int, col: int, text_range: TextRange) -> bool:
    """Return True when the cursor sits just after a key's last character."""
    return line == text_range.end_line and col == text_range.end_col
