"""The completion lattice — one ``match`` statement over ``(role, target)``.

Every meaningful cell of the cursor-role x completion-target lattice maps to
one completer call. The match is the spec; the catch-all returns ``()`` for
``NotInSchema`` reasons and impossible-by-grammar combinations.

Role/target combinations that the PRD calls "impossible-by-grammar" (e.g.
``(VALUE, ArrayOf*)`` arising when the cursor sits past ``key: `` on an
array-typed field) never reach this match: ``service.collapse_role_to_target``
rewrites them into the corresponding ``DASH_ITEM`` or ``KEY`` role before
dispatch, so the lattice stays faithful to the PRD's enumerated cells.

Adding a new target variant is one variant on ``CompletionTarget``, one rule
in ``target_at``, one arm here, and one completer module — no other surface
needs to change.
"""

from turbine.application.analysis.completion.completers import (
    array_items,
    db,
    object_keys,
    refs,
    scalar_value,
)
from turbine.application.analysis.completion.context import CompletionContext
from turbine.core.analysis.features.completion import CompletionItemInfo
from turbine.core.analysis.features.completion_targets import (
    ArrayOfObjects,
    ArrayOfScalars,
    ColumnRef,
    CompletionTarget,
    ContractRef,
    DatasetRef,
    DbColumn,
    DbTable,
    DomainRef,
    ObjectShape,
    Scalar,
    SqlCheckRef,
)
from turbine.core.analysis.features.cursor_role import CursorRole

__all__ = ["complete"]


# Issue 003 AC2: the dispatcher is one ``match`` statement so the lattice reads
# as a reviewable spec; the resulting branch count is the whole point (one arm
# per meaningful cell) and is suppressed below.
def complete(  # noqa: C901, PLR0911
    role: CursorRole, target: CompletionTarget, ctx: CompletionContext
) -> tuple[CompletionItemInfo, ...]:
    """Return the completion items for the (role, target) cell at *ctx*.

    The catch-all covers ``NotInSchema`` (both reasons) plus the impossible-by-
    grammar combinations such as ``(KEY, Scalar)``.
    """
    match (role, target):
        case (CursorRole.KEY | CursorRole.EMPTY, ObjectShape() as object_target):
            return object_keys.complete(object_target, ctx)
        case (CursorRole.DASH_ITEM | CursorRole.EMPTY, ArrayOfObjects() as object_array):
            return array_items.complete_object_item(object_array, ctx)
        case (CursorRole.DASH_ITEM | CursorRole.EMPTY, ArrayOfScalars() as scalar_array):
            return array_items.complete_scalar_item(scalar_array, ctx)
        case (CursorRole.VALUE, Scalar() as scalar_target):
            return scalar_value.complete(scalar_target, ctx)
        case (CursorRole.VALUE, ColumnRef() as column_target):
            return refs.complete_column(column_target, ctx)
        case (CursorRole.VALUE, DbTable()):
            return db.complete_table(ctx)
        case (CursorRole.VALUE, DbColumn()):
            return db.complete_column(ctx)
        case (CursorRole.VALUE, DomainRef()):
            return refs.complete_domain(ctx)
        case (CursorRole.VALUE, ContractRef()):
            return refs.complete_contract(ctx)
        case (CursorRole.VALUE, DatasetRef()):
            return refs.complete_dataset(ctx)
        case (CursorRole.VALUE, SqlCheckRef()):
            return refs.complete_sql_check(ctx)
        case _:
            return ()
