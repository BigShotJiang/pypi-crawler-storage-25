"""Schema-side classifier for the completion lattice.

``target_at`` returns the ``CompletionTarget`` describing what kind of completion
is valid at *path* in *data*. The function is a priority-ordered table — see the
docstring on ``target_at`` for the full order.
"""

from pathlib import Path

from turbine.core.analysis.features.completion import SQL_CHECK_NAME_PATH_RE
from turbine.core.analysis.features.completion_targets import (
    ArrayOfObjects,
    ArrayOfScalars,
    ColumnRef,
    CompletionTarget,
    ContractRef,
    DatasetRef,
    DbColumn,
    DbTable,
    DomainRef,
    NotInSchema,
    NotInSchemaReason,
    ObjectShape,
    Scalar,
    SqlCheckRef,
)
from turbine.core.analysis.ports import SchemaResolver
from turbine.core.common import (
    FIELD_DATASET,
    FIELD_DOMAIN,
    FIELD_KIND,
    FIELD_TARGET_CONTRACT,
    ContractKind,
    IntrospectionCache,
    ResolvedNode,
)
from turbine.core.common.column_ref_metadata import REF_KIND_FIELD, ColumnRefKind
from turbine.core.contract import DomainRegistry, ProjectIndex

__all__ = ["target_at"]


def target_at(
    data: dict[str, object],
    path: str,
    schema_resolver: SchemaResolver,
    index: ProjectIndex | None,
    introspection: IntrospectionCache | None,
    domain_registry: DomainRegistry | None,
    checks_dir: Path | None,
) -> CompletionTarget:
    """Classify the cursor's resolved path against the schema and runtime ports.

    Priority order (top wins):

    1. ``x-turbine-ref`` declared at *path* → ``ColumnRef`` | ``DbTable`` | ``DbColumn``.
    2. ``domain`` on a DataContract with an active registry → ``DomainRef``.
    3. ``targetContract`` on a QualitySpec → ``ContractRef``.
    4. ``dataset`` on a QualitySpec → ``DatasetRef``.
    5. ``quality.<i>.sql.name`` path with a configured *checks_dir* → ``SqlCheckRef``.
    6. generic JSON-schema shape → ``ObjectShape`` | ``ArrayOfObjects`` |
       ``ArrayOfScalars`` | ``Scalar``.
    7. ``NotInSchema(PATH_DOES_NOT_EXIST | FIELD_NOT_ALLOWED_HERE)`` from a parent walk.
    """
    del index, introspection
    target: CompletionTarget | None = turbine_ref_target(data, path, schema_resolver)
    if target is None and domain_target_applies(data, path, domain_registry):
        target = DomainRef()
    if target is None and quality_spec_field_matches(data, path, FIELD_TARGET_CONTRACT):
        target = ContractRef()
    if target is None and quality_spec_field_matches(data, path, FIELD_DATASET):
        target = DatasetRef()
    if target is None and sql_check_target_applies(path, checks_dir):
        target = SqlCheckRef()
    if target is None:
        target = shape_target(data, path, schema_resolver)
    if target is None:
        target = not_in_schema_target(data, path, schema_resolver)
    return target


def domain_target_applies(
    data: dict[str, object], path: str, domain_registry: DomainRegistry | None
) -> bool:
    """Priority 2: ``domain`` on a DataContract with a registry that declares an allow-list."""
    if path != FIELD_DOMAIN:
        return False
    if data.get(FIELD_KIND) != ContractKind.DATA_CONTRACT:
        return False
    if domain_registry is None:
        return False
    return domain_registry.allowed() is not None


def quality_spec_field_matches(data: dict[str, object], path: str, field: str) -> bool:
    """Priorities 3 and 4: a QualitySpec-only top-level field at *path*."""
    return path == field and data.get(FIELD_KIND) == ContractKind.QUALITY_SPEC


def sql_check_target_applies(path: str, checks_dir: Path | None) -> bool:
    """Priority 5: a ``quality.<i>.sql.name`` reference under a configured checks directory."""
    return checks_dir is not None and SQL_CHECK_NAME_PATH_RE.match(path) is not None


def shape_target(
    data: dict[str, object], path: str, schema_resolver: SchemaResolver
) -> CompletionTarget | None:
    """Priority 6: project a resolved node to ObjectShape | ArrayOf* | Scalar.

    Returns ``None`` when the node carries no signal (no children, no array-ness,
    no enums, no examples) — that case falls through to priority 7.
    """
    node = schema_resolver.resolve_children(data, path)
    if node.is_array:
        return array_target(data, path, schema_resolver)
    if node.children:
        return ObjectShape(node=node)
    if node.enum_values or node.examples:
        return Scalar(node=node, key_name=leaf_key_name(path))
    return None


def array_target(
    data: dict[str, object], path: str, schema_resolver: SchemaResolver
) -> CompletionTarget:
    """Probe ``path.0`` to decide ArrayOfObjects vs ArrayOfScalars."""
    item_path = f"{path}.0" if path else "0"
    item_node = schema_resolver.resolve_children(data, item_path)
    if item_node.children:
        return ArrayOfObjects(item_node=item_node)
    return ArrayOfScalars(item_node=item_node)


def leaf_key_name(path: str) -> str:
    """Return the last segment of *path*, or *path* itself when no separator is present."""
    return path.rsplit(".", 1)[-1] if "." in path else path


def not_in_schema_target(
    data: dict[str, object], path: str, schema_resolver: SchemaResolver
) -> NotInSchema:
    """Priority 7: distinguish PATH_DOES_NOT_EXIST from FIELD_NOT_ALLOWED_HERE.

    Walks parent prefixes of *path* from deepest to shallowest. If a prefix
    resolves to a non-empty node, the leaf failure is local (FIELD_NOT_ALLOWED_HERE
    — e.g. the field is valid on some check-type variants but not this one).
    Otherwise the path walks off the schema entirely (PATH_DOES_NOT_EXIST).
    """
    if not path:
        return NotInSchema(reason=NotInSchemaReason.PATH_DOES_NOT_EXIST)
    segments = path.split(".")
    for cut in range(len(segments) - 1, 0, -1):
        prefix = ".".join(segments[:cut])
        parent = schema_resolver.resolve_children(data, prefix)
        if node_has_content(parent):
            return NotInSchema(reason=NotInSchemaReason.FIELD_NOT_ALLOWED_HERE)
    return NotInSchema(reason=NotInSchemaReason.PATH_DOES_NOT_EXIST)


def node_has_content(node: ResolvedNode) -> bool:
    """Return True when a resolved node carries any signal (children/array/enum/examples)."""
    return bool(node.children) or node.is_array or bool(node.enum_values) or bool(node.examples)


def turbine_ref_target(
    data: dict[str, object], path: str, schema_resolver: SchemaResolver
) -> CompletionTarget | None:
    """Priority 1: project an ``x-turbine-ref`` extension to a typed reference variant.

    Maps ``ColumnRefKind`` values to lattice variants:
      ``COLUMN`` / ``QUALIFIED_COLUMN`` → ``ColumnRef(kind=…)``
      ``DB_TABLE``                       → ``DbTable()``
      ``DB_COLUMN``                      → ``DbColumn()``
    """
    extension = schema_resolver.turbine_ref_at(data, path)
    if extension is None:
        return None
    kind_value = extension.get(REF_KIND_FIELD)
    if not isinstance(kind_value, str):
        return None
    try:
        kind = ColumnRefKind(kind_value)
    except ValueError:
        return None
    match kind:
        case ColumnRefKind.DB_TABLE:
            return DbTable()
        case ColumnRefKind.DB_COLUMN:
            return DbColumn()
        case ColumnRefKind.COLUMN | ColumnRefKind.QUALIFIED_COLUMN:
            return ColumnRef(kind=kind)
