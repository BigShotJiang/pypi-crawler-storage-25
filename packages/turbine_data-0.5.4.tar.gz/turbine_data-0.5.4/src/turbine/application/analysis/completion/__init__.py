"""Application-layer completion service — the YAML lattice + SQL/Jinja paths.

The package exposes ``CompletionService`` as its public surface. Internals
(dispatcher, completers, repair, schema_target) are reachable via submodules
for unit tests but are not re-exported here.
"""

from turbine.application.analysis.completion.service import CompletionService

__all__ = ["CompletionService"]
