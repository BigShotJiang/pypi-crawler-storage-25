"""Per-target-cell completers.

Each module exports free functions that satisfy one or more arms of the
``dispatch.complete`` match statement.
"""
