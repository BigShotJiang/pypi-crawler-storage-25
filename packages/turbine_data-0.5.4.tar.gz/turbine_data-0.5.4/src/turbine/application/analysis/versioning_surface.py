"""Shared LSP versioning surface for Contract diagnostics, actions, and tree rows."""

import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Protocol
from urllib.parse import unquote, urlparse

from turbine.application.operations.diff_contract import DiffContractUseCase
from turbine.core.building_blocks import (
    Diagnostic,
    DiagnosticBuilder,
    DiagnosticData,
    DiagnosticId,
    DiagnosticKind,
    TextEditInfo,
    TextRange,
    TurbineError,
)
from turbine.core.common.change_types import ChangeType, ContractChange
from turbine.core.common.file_edits import diff_to_text_edits
from turbine.core.contract.diff import ChangeEntry
from turbine.core.contract.errors import ContractVersionError
from turbine.core.contract.ports import PreviousVersionReader
from turbine.core.contract.semver import (
    SemverBump,
    Version,
    bump_version,
    classify_change,
    read_version_from_yaml,
    replace_version_in_yaml,
)


@dataclass(frozen=True, slots=True)
class ContractVersionBumpAction:
    """Workspace edit that updates one Contract's version field."""

    title: str
    uri: str
    edit: TextEditInfo
    new_version: str


@dataclass(frozen=True, slots=True)
class ContractChangesSection:
    """Projected All Contracts Changes section for one Contract."""

    label: str
    breaking_count: int
    additive_count: int
    informational_count: int
    changes: tuple[ChangeEntry, ...]
    highest_bump: SemverBump


@dataclass(frozen=True, slots=True)
class VersioningSurface:
    """All LSP projections backed by one Contract diff."""

    diagnostic: Diagnostic | None
    bump_action: ContractVersionBumpAction | None
    changes_section: ContractChangesSection | None


class ContractVersioningSurfaceProvider(Protocol):
    """Port consumed by LSP diagnostics, code actions, and trees."""

    def surface_for(self, uri: str, content: str) -> VersioningSurface: ...

    def invalidate(self, uri: str) -> None: ...

    def remember_content(self, uri: str, content: str) -> None: ...

    def content_for_tree(self, uri: str, fallback_path: Path) -> str | None: ...


class NullContractVersioningSurfaceProvider:
    """No-op versioning provider used when the LSP surface is not wired in tests."""

    def surface_for(self, uri: str, content: str) -> VersioningSurface:
        del uri, content
        return empty_surface()

    def invalidate(self, uri: str) -> None:
        del uri

    def remember_content(self, uri: str, content: str) -> None:
        del uri, content

    def content_for_tree(self, uri: str, fallback_path: Path) -> str | None:
        del uri, fallback_path
        return None


@dataclass(frozen=True, slots=True)
class CachedSurface:
    """Cached surface keyed by exact document content."""

    content: str
    surface: VersioningSurface


class BreakingChangeWithoutMajorBumpRule:
    """Lint-rule-shaped adapter for the diff-backed LSP version hint."""

    name = "breaking-change-without-major-bump"

    def __init__(self, provider: ContractVersioningSurfaceProvider) -> None:
        """Store the shared versioning surface provider."""
        self.provider = provider

    def check(self, uri: str, content: str) -> Diagnostic | None:
        """Return the INFO diagnostic when the shared surface has one."""
        return self.provider.surface_for(uri, content).diagnostic


class ContractVersioningSurfaceService:
    """Build Contract version diagnostics, code actions, and tree sections from one diff."""

    def __init__(
        self, diff_use_case: DiffContractUseCase, previous_reader: PreviousVersionReader
    ) -> None:
        """Store diff ports and initialize small per-URI caches."""
        self.diff_use_case = diff_use_case
        self.previous_reader = previous_reader
        self.surface_cache: dict[str, CachedSurface] = {}
        self.content_cache: dict[str, str] = {}
        self.cache_lock = threading.Lock()

    def surface_for(self, uri: str, content: str) -> VersioningSurface:
        """Return all LSP versioning projections for *uri* and *content*."""
        with self.cache_lock:
            cached = self.surface_cache.get(uri)
            if cached is not None and cached.content == content:
                return cached.surface
        surface = self.build_surface(uri, content)
        with self.cache_lock:
            self.surface_cache[uri] = CachedSurface(content=content, surface=surface)
        return surface

    def diagnostic_for(self, uri: str, content: str) -> Diagnostic | None:
        """Return the major-bump INFO diagnostic, if the current content needs one."""
        return self.surface_for(uri, content).diagnostic

    def changes_section_for(self, uri: str, content: str) -> ContractChangesSection | None:
        """Return the All Contracts Changes section, if the diff is non-empty."""
        return self.surface_for(uri, content).changes_section

    def remember_content(self, uri: str, content: str) -> None:
        """Remember an editor dirty buffer for tree requests that do not carry document text."""
        with self.cache_lock:
            self.content_cache[uri] = content
            self.surface_cache.pop(uri, None)

    def content_for_tree(self, uri: str, fallback_path: Path) -> str | None:
        """Return dirty-buffer content for tree rendering, else current file content."""
        with self.cache_lock:
            cached = self.content_cache.get(uri)
        if cached is not None:
            return cached
        try:
            return fallback_path.read_text()
        except OSError:
            return None

    def invalidate(self, uri: str) -> None:
        """Drop cached diff projections and remembered editor content for one URI."""
        with self.cache_lock:
            self.surface_cache.pop(uri, None)
            self.content_cache.pop(uri, None)

    def build_surface(self, uri: str, content: str) -> VersioningSurface:
        """Compute the current versioning surface, silently omitting unavailable diffs."""
        path = path_from_uri(uri)
        previous_text = self.previous_reader.read(path)
        if previous_text is None:
            return empty_surface()
        current_version = read_version_from_yaml(content)
        previous_version = read_version_from_yaml(previous_text)
        if current_version is None or previous_version is None:
            return empty_surface()
        try:
            diff = self.diff_use_case.run_with_previous_text(path, previous_text, current_text=content)
        except (ContractVersionError, OSError, TurbineError):
            return empty_surface()
        changes = tuple(change for entry in diff.entries for change in entry.changes)
        if not changes or diff.highest_bump == SemverBump.NONE:
            return empty_surface()
        target_version = bump_version(previous_version, diff.highest_bump)
        if Version.parse(current_version) >= Version.parse(target_version):
            section = changes_section(changes, diff.highest_bump)
            return VersioningSurface(diagnostic=None, bump_action=None, changes_section=section)
        section = changes_section(changes, diff.highest_bump)
        action = bump_action(uri, content, target_version, section)
        diagnostic = breaking_diagnostic(path, content, current_version, section)
        return VersioningSurface(diagnostic=diagnostic, bump_action=action, changes_section=section)


def empty_surface() -> VersioningSurface:
    """Return an empty surface projection."""
    return VersioningSurface(diagnostic=None, bump_action=None, changes_section=None)


def path_from_uri(uri: str) -> Path:
    """Convert a file URI or plain path string to a Path."""
    parsed = urlparse(uri)
    if parsed.scheme == "file":
        return Path(unquote(parsed.path))
    return Path(uri)


def bump_action(
    uri: str, content: str, target_version: str, section: ContractChangesSection
) -> ContractVersionBumpAction | None:
    """Build the code action projection from a YAML-preserving version rewrite."""
    try:
        rewritten = replace_version_in_yaml(content, target_version)
    except ContractVersionError:
        return None
    edits = diff_to_text_edits(content, rewritten)
    if not edits:
        return None
    title = (
        f"Bump to v{target_version} — "
        f"{section.breaking_count} breaking, {section.additive_count} additive"
    )
    return ContractVersionBumpAction(title=title, uri=uri, edit=edits[0], new_version=target_version)


def breaking_diagnostic(
    path: Path, content: str, current_version: str, section: ContractChangesSection
) -> Diagnostic | None:
    """Build the dismissible INFO diagnostic for an unbumped breaking change."""
    if section.highest_bump is not SemverBump.MAJOR or section.breaking_count == 0:
        return None
    version_range = version_value_range(content)
    if version_range is None:
        return None
    count = section.breaking_count
    suffix = "change" if count == 1 else "changes"
    return (
        DiagnosticBuilder.info(
            DiagnosticId.BREAKING_CHANGE_WITHOUT_MAJOR_BUMP,
            f"breaking Contract {suffix} detected without a major version bump",
        )
        .span(path, version_range)
        .help(f"bump version to {section.highest_bump.label} level before release")
        .data(DiagnosticData(kind=DiagnosticKind.BREAKING_CHANGE_WITHOUT_MAJOR_BUMP))
        .dismissible(current_version)
        .build()
    )


def version_value_range(content: str) -> TextRange | None:
    """Return the source range covering the top-level version value."""
    lines = content.splitlines()
    for line_number, line in enumerate(lines, start=1):
        if not line.startswith("version:"):
            continue
        key_offset = 0
        value_start = line.find(":") + 1
        while value_start < len(line) and line[value_start].isspace():
            value_start += 1
        value_end = value_start
        while value_end < len(line) and not line[value_end].isspace() and line[value_end] != "#":
            value_end += 1
        return TextRange(
            start_line=line_number,
            start_col=key_offset + value_start + 1,
            end_line=line_number,
            end_col=key_offset + value_end + 1,
        )
    return None


def changes_section(
    changes: tuple[ChangeEntry, ...], highest_bump: SemverBump
) -> ContractChangesSection:
    """Summarize structural changes for the All Contracts Changes section."""
    breaking = sum(1 for change in changes if bump_for_change(change) is SemverBump.MAJOR)
    additive = sum(1 for change in changes if bump_for_change(change) is SemverBump.MINOR)
    informational = len(changes) - breaking - additive
    return ContractChangesSection(
        label=f"Changes ({breaking} breaking, {additive} additive)",
        breaking_count=breaking,
        additive_count=additive,
        informational_count=informational,
        changes=changes,
        highest_bump=highest_bump,
    )


def bump_for_change(change: ChangeEntry) -> SemverBump:
    """Classify a serialized change entry into sidebar severity buckets."""
    return classify_change(contract_change_from_entry(change))


def contract_change_from_entry(change: ChangeEntry) -> ContractChange:
    """Rehydrate enough ContractChange data to reuse the core semver classifier."""
    old_nullable = change.old_nullable if change.type is ChangeType.COLUMN_NULLABLE_CHANGED else None
    new_nullable = change.new_nullable if change.type is ChangeType.COLUMN_NULLABLE_CHANGED else None
    return ContractChange(
        change_type=change.type,
        contract_id="",
        column_name=change.column,
        check_name=change.check,
        old_nullable=old_nullable,
        new_nullable=new_nullable,
        old_value=change.old_value,
        new_value=change.new_value,
    )
