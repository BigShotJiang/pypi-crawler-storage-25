"""Add Check use case — inserts a new check into a YAML file."""

import re
from dataclasses import dataclass

from turbine.core.analysis.add_check_request import AddCheckRequest, AddCheckResult
from turbine.core.analysis.check_catalog import CheckScope
from turbine.core.analysis.check_snippet import YamlSection, build_check_snippet
from turbine.core.analysis.features.code_lens import (
    extract_schema_section,
    find_property_quality_line,
    find_schema_positions,
    find_schema_quality_end_lines,
    schema_block_ranges,
    top_level_property_names,
    walk_section_in_block,
)
from turbine.core.analysis.ports import CodeWriteError, CodeWriter
from turbine.core.common import SchemaNode
from turbine.core.common.constants import ContractKind
from turbine.core.common.file_edits import SnippetInsertion, TextPosition, diff_to_text_edits

TOP_LEVEL_KEY_RE = re.compile(r"^(\S+):\s*$")
COLUMN_NAME_RE = re.compile(r"^(\s*)-\s+name:\s*(.+)$")


class AddCheckUseCase:
    """Inserts a new check into a QualitySpec YAML file.

    Builds a YAML snippet from the schema, finds the insertion point,
    computes text edits, and writes via the CodeWriter port.
    """

    def __init__(self, writer: CodeWriter, schema: SchemaNode) -> None:
        self.writer = writer
        self.schema = schema

    async def execute(self, content: str, request: AddCheckRequest) -> AddCheckResult:
        """Insert a check into *content* and write the result."""
        nested = (
            request.file_kind == ContractKind.DATA_CONTRACT
            and request.scope == CheckScope.COLUMN
            and request.column is not None
        )
        snippet = build_check_snippet(request, self.schema, nested=nested)

        if nested:
            try:
                after = insert_property_check(
                    content, snippet.yaml_text, request.schema_name, request.column
                )
            except AddCheckInsertError as exc:
                return AddCheckResult(applied=False, error=str(exc))
        elif request.file_kind == ContractKind.DATA_CONTRACT:
            try:
                after = insert_contract_check(content, snippet.yaml_text, request.schema_name)
            except AddCheckInsertError as exc:
                return AddCheckResult(applied=False, error=str(exc))
        elif request.scope == CheckScope.COLUMN and request.column:
            after = insert_column_check(content, snippet.yaml_text, request.column)
        else:
            after = insert_snippet_into_content(content, snippet.yaml_text, snippet.section)

        if after == content:
            return AddCheckResult(applied=True)

        insertion = snippet_insertion_from_content_diff(request.file_uri, content, after)
        if insertion is None:
            return AddCheckResult(
                applied=False, error="Add Check could not derive a single snippet insertion"
            )
        try:
            await self.writer.insert_snippet(insertion)
        except CodeWriteError as exc:
            return AddCheckResult(applied=False, error=str(exc))
        return AddCheckResult(applied=True)


def snippet_insertion_from_content_diff(uri: str, before: str, after: str) -> SnippetInsertion | None:
    """Convert a content diff into one pure snippet insertion, when possible."""
    edits = diff_to_text_edits(before, after)
    if len(edits) != 1:
        return None
    edit = edits[0]
    edit_range = edit.range
    if edit_range.start_line != edit_range.end_line or edit_range.start_col != edit_range.end_col:
        return None
    position = TextPosition(line=edit_range.start_line, col=edit_range.start_col)
    return SnippetInsertion(uri=uri, position=position, snippet_text=edit.new_text)


class AddCheckInsertError(Exception):
    """Raised when a check cannot be inserted into a file (e.g. unknown schema)."""


def insert_contract_check(content: str, snippet_yaml: str, schema_name: str | None) -> str:
    """Insert a wrapped check into the target schema's ``quality:`` block.

    Creates the ``quality:`` block when absent. Raises :class:`AddCheckInsertError`
    when ``schema_name`` is missing or the named schema does not exist in *content*.
    """
    if not schema_name:
        raise AddCheckInsertError("Add Check on a DataContract requires a schema name")

    schemas = find_schema_positions(content)
    target = next(((line, name) for line, name in schemas if name == schema_name), None)
    if target is None:
        raise AddCheckInsertError(f"Schema '{schema_name}' not found in contract")

    schema_start_line, _ = target
    lines = content.splitlines(keepends=True)
    dash_indent = leading_spaces(lines[schema_start_line - 1])

    existing_end = next(
        (line for line, name in find_schema_quality_end_lines(content) if name == schema_name), None
    )
    if existing_end is not None:
        return append_to_contract_quality_block(lines, content, schema_name, existing_end, snippet_yaml)

    return create_contract_quality_block(lines, content, schema_name, dash_indent, snippet_yaml)


def append_to_contract_quality_block(
    lines: list[str], content: str, schema_name: str, existing_end_line: int, snippet_yaml: str
) -> str:
    """Append *snippet_yaml* after the last content line of an existing quality block."""
    quality_key_line = find_quality_key_line_in_schema(content, schema_name)
    item_indent = leading_spaces(lines[quality_key_line - 1]) + 2 if quality_key_line else 6
    indented = indent_snippet(snippet_yaml, item_indent)
    lines.insert(existing_end_line, indented)
    return "".join(lines)


def create_contract_quality_block(
    lines: list[str], content: str, schema_name: str, dash_indent: int, snippet_yaml: str
) -> str:
    """Create a new ``quality:`` block inside the target schema."""
    insert_at = find_schema_block_end_position(content, schema_name)
    key_indent = dash_indent + 2
    item_indent = key_indent + 2
    key_line = " " * key_indent + "quality:\n"
    indented = indent_snippet(snippet_yaml, item_indent)
    lines.insert(insert_at, key_line + indented)
    return "".join(lines)


def find_quality_key_line_in_schema(content: str, schema_name: str) -> int | None:
    """Return the 1-indexed line of ``quality:`` within *schema_name*'s block."""
    schema_lines = extract_schema_section(content)
    for _, name, block_lines in schema_block_ranges(schema_lines):
        if name != schema_name:
            continue
        return next(
            (line_num for line_num, raw_line in block_lines if raw_line.strip() == "quality:"), None
        )
    return None


def find_schema_block_end_position(content: str, schema_name: str) -> int:
    """Return the 0-indexed insert position after the last line of *schema_name*'s block."""
    schema_lines = extract_schema_section(content)
    for start_line, name, block_lines in schema_block_ranges(schema_lines):
        if name != schema_name:
            continue
        if block_lines:
            return block_lines[-1][0]  # 1-indexed line → 0-indexed insert after
        return start_line
    return len(content.splitlines())


@dataclass(frozen=True, slots=True)
class PropertyBounds:
    """Line bounds for one property inside a schema's ``properties:`` section."""

    name_line: int
    name_indent: int
    body_end_line: int
    quality_line: int | None
    quality_end_line: int | None


def find_property_bounds(content: str, schema_name: str, property_name: str) -> PropertyBounds | None:
    """Return line bounds for *property_name* inside *schema_name*'s properties block."""
    schema_lines = extract_schema_section(content)
    if not schema_lines:
        return None

    for _, current_schema, block_lines in schema_block_ranges(schema_lines):
        if current_schema == schema_name:
            return find_property_bounds_in_block(block_lines, property_name)
    return None


def find_property_bounds_in_block(
    block_lines: list[tuple[int, str]], property_name: str
) -> PropertyBounds | None:
    """Return property bounds inside one schema block."""
    property_lines = walk_section_in_block(block_lines, "properties")
    name_positions = top_level_property_names(property_lines)
    for pos, (start_idx, name_line, prop_name, prop_indent) in enumerate(name_positions):
        if prop_name != property_name:
            continue
        end_idx = name_positions[pos + 1][0] if pos + 1 < len(name_positions) else len(property_lines)
        prop_block = property_lines[start_idx + 1 : end_idx]
        return build_property_bounds(name_line, prop_indent, prop_block)
    return None


def build_property_bounds(
    name_line: int, prop_indent: int, prop_block: list[tuple[int, str]]
) -> PropertyBounds:
    """Build ``PropertyBounds`` from one property body block."""
    body_end_line = next(
        (line_num for line_num, raw_line in reversed(prop_block) if raw_line.strip()), name_line
    )
    quality_line = find_property_quality_line(prop_block, prop_indent)
    quality_end_line = (
        last_line_under_quality(prop_block, prop_indent, quality_line)
        if quality_line is not None
        else None
    )
    return PropertyBounds(
        name_line=name_line,
        name_indent=prop_indent,
        body_end_line=body_end_line,
        quality_line=quality_line,
        quality_end_line=quality_end_line,
    )


def last_line_under_quality(
    prop_block: list[tuple[int, str]], property_indent: int, quality_line: int
) -> int:
    """Return the last content line inside a property's ``quality:`` block."""
    last_line = quality_line
    quality_key_indent = property_indent + 2
    for line_num, raw_line in prop_block:
        if line_num <= quality_line or not raw_line.strip():
            continue
        indent = len(raw_line) - len(raw_line.lstrip())
        if indent <= quality_key_indent:
            break
        last_line = line_num
    return last_line


def insert_property_check(
    content: str, snippet_yaml: str, schema_name: str | None, property_name: str | None
) -> str:
    """Insert a check into *property_name*'s own nested ``quality:`` block.

    Creates the property's ``quality:`` block when absent. Raises
    :class:`AddCheckInsertError` when the schema or property is missing.
    """
    if not schema_name:
        raise AddCheckInsertError("Add Check per-property requires a schema name")
    if not property_name:
        raise AddCheckInsertError("Add Check per-property requires a property name")

    bounds = find_property_bounds(content, schema_name, property_name)
    if bounds is None:
        raise AddCheckInsertError(f"Property '{property_name}' not found in schema '{schema_name}'")

    lines = content.splitlines(keepends=True)
    item_indent = bounds.name_indent + 4
    indented_snippet = indent_snippet(snippet_yaml, item_indent)

    if bounds.quality_end_line is not None:
        lines.insert(bounds.quality_end_line, indented_snippet)
        return "".join(lines)

    key_indent = bounds.name_indent + 2
    key_line = " " * key_indent + "quality:\n"
    lines.insert(bounds.body_end_line, key_line + indented_snippet)
    return "".join(lines)


def leading_spaces(line: str) -> int:
    """Return the number of leading space characters on *line*."""
    return len(line) - len(line.lstrip())


def insert_column_check(content: str, snippet_yaml: str, column: str) -> str:
    """Insert a check into a specific column's checks block, or auto-create the column entry.

    Three cases:
    1. Column exists with ``checks:`` block -> append check to that block.
    2. Column exists without ``checks:`` block -> insert checks header + check.
    3. Column doesn't exist -> create new column entry with the check.
    """
    lines = content.splitlines(keepends=True)
    column_start = find_column_start(lines, column)

    if column_start is not None:
        checks_end = find_checks_block_end(lines, column_start)
        if checks_end is not None:
            indent = detect_list_indent(lines, checks_end)
            indented = indent_snippet(snippet_yaml, indent)
            lines.insert(checks_end, indented)
            return "".join(lines)
        # Column exists but no checks block: insert checks: header + check
        return insert_checks_block_under_column(lines, column_start, snippet_yaml)

    # Column doesn't exist: build a column entry wrapper
    column_entry = build_column_entry(column, snippet_yaml)
    return insert_snippet_into_content(content, column_entry, YamlSection.COLUMNS)


def insert_checks_block_under_column(lines: list[str], column_start: int, snippet_yaml: str) -> str:
    """Insert a ``checks:`` header and the check right after the column's ``- name:`` line."""
    name_line = lines[column_start]
    col_indent = len(name_line) - len(name_line.lstrip()) + 2  # align with "name" under "- "
    checks_header = " " * col_indent + "checks:\n"
    check_indent = col_indent + 2
    indented_check = indent_snippet(snippet_yaml, check_indent)
    insert_at = column_start + 1
    lines.insert(insert_at, checks_header + indented_check)
    return "".join(lines)


def find_column_start(lines: list[str], column: str) -> int | None:
    """Return the 0-indexed line of ``- name: <column>`` or None."""
    for idx, raw_line in enumerate(lines):
        if (match := COLUMN_NAME_RE.match(raw_line)) is not None and match.group(2).strip() == column:
            return idx
    return None


def find_checks_block_end(lines: list[str], column_start: int) -> int | None:
    """Return the insert position after the last check in the column's checks block."""
    in_checks = False
    last_content_idx: int | None = None

    for idx in range(column_start + 1, len(lines)):
        raw_line = lines[idx]
        stripped = raw_line.strip()

        if COLUMN_NAME_RE.match(raw_line) is not None:
            break

        if stripped == "checks:":
            in_checks = True
            continue

        if in_checks and stripped:
            last_content_idx = idx

    return last_content_idx + 1 if last_content_idx is not None else None


def build_column_entry(column: str, check_snippet: str) -> str:
    """Wrap a check snippet in a new column entry with ``- name:`` and ``checks:``."""
    indented_check = indent_snippet(check_snippet, 4)
    return f"- name: {column}\n  checks:\n{indented_check}"


def insert_snippet_into_content(content: str, snippet_yaml: str, section: YamlSection) -> str:
    """Insert a check snippet into the appropriate section of a YAML file.

    If the target section exists, appends to its end.
    If it doesn't exist, creates the section at the end of the file.
    """
    lines = content.splitlines(keepends=True)
    section_end = find_section_end(lines, section)

    if section_end is not None:
        indent = detect_list_indent(lines, section_end)
        indented_snippet = indent_snippet(snippet_yaml, indent)
        lines.insert(section_end, indented_snippet)
        return "".join(lines)

    # Section doesn't exist: append it at end of file
    trailing_newline = content.endswith("\n")
    prefix = "" if trailing_newline else "\n"
    indented_snippet = indent_snippet(snippet_yaml, 2)
    return content + prefix + f"{section.value}:\n" + indented_snippet


def find_section_end(lines: list[str], section: YamlSection) -> int | None:
    """Find the 0-indexed insert position at the end of a top-level YAML section."""
    header_idx = find_section_header(lines, section)
    if header_idx is None:
        return None
    return last_line_in_section(lines, header_idx) + 1


def find_section_header(lines: list[str], section: YamlSection) -> int | None:
    """Return the index of the line containing ``<section>:`` or None."""
    target = f"{section.value}:"
    return next((idx for idx, line in enumerate(lines) if line.strip() == target), None)


def last_line_in_section(lines: list[str], header_idx: int) -> int:
    """Return the last line index belonging to the section starting at *header_idx*."""
    last_idx = header_idx
    for idx in range(header_idx + 1, len(lines)):
        if is_section_boundary(lines[idx]):
            break
        if lines[idx].strip():
            last_idx = idx
    return last_idx


def is_section_boundary(line: str) -> bool:
    """Return True when *line* starts a new top-level YAML key."""
    stripped = line.strip()
    if not stripped or stripped.startswith("#"):
        return False
    return len(line) - len(line.lstrip()) == 0 and bool(TOP_LEVEL_KEY_RE.match(stripped))


def detect_list_indent(lines: list[str], section_end: int) -> int:
    """Detect the indentation of list items in a section.

    Scans backward from section_end looking for a ``- `` list marker.
    Falls back to 2 spaces if none found.
    """
    for idx in range(section_end - 1, -1, -1):
        line = lines[idx]
        stripped = line.lstrip()
        if stripped.startswith("- "):
            return len(line) - len(stripped)
    return 2


def indent_snippet(snippet_yaml: str, indent: int) -> str:
    """Indent a snippet's lines to match the target section.

    Prepends *indent* spaces while preserving relative indentation within the snippet.
    """
    prefix = " " * indent
    result_lines: list[str] = []
    for line in snippet_yaml.splitlines(keepends=True):
        if not line.strip():
            result_lines.append(line)
            continue
        result_lines.append(prefix + line)
    return "".join(result_lines)
