"""Lint use case — validate a contract and collect diagnostics."""

from collections.abc import Callable
from dataclasses import replace
from difflib import get_close_matches
from pathlib import Path

from loguru import logger

from turbine.application.diagnostics import DiagnosticCollector
from turbine.core.building_blocks import (
    DiagnosticBuilder,
    DiagnosticData,
    DiagnosticId,
    DiagnosticKind,
    DiagnosticSink,
    EventBus,
    NullDiagnosticSink,
    TurbineError,
)
from turbine.core.common import FIELD_KIND, DatasetSpec, RawSource, SourceParser
from turbine.core.contract import (
    ContractLinted,
    ContractLocation,
    ContractRepository,
    CrossContractRule,
    CrossSchemaRule,
    DomainRegistry,
    LintRule,
    ProjectIndex,
    RuleScope,
    TargetContractContext,
    default_cross_rules,
    default_cross_schema_rules,
    default_rules,
    merge_checks,
    merge_target,
    select_target_spec,
    target_specs_from_index,
)
from turbine.core.contract.ports import ContractReaderRegistry


class LintUseCase:
    """Runs contract linting: discovery, schema validation, and domain rules.

    Parsing goes to ``SourceParser``, format detection to
    ``ContractReaderRegistry``, file discovery to ``ContractRepository``.
    Publishes ``ContractLinted`` after each run.
    """

    def __init__(
        self,
        registry: ContractReaderRegistry,
        parser: SourceParser,
        event_bus: EventBus,
        repository: ContractRepository | None = None,
        rules: tuple[LintRule, ...] | None = None,
        cross_rules: tuple[CrossContractRule, ...] | None = None,
        cross_schema_rules: tuple[CrossSchemaRule, ...] | None = None,
        index_provider: Callable[[], ProjectIndex] | None = None,
        domain_registry: DomainRegistry | None = None,
    ) -> None:
        """Store the registry, parser, event bus, optional repository, and lint rules."""
        self.registry = registry
        self.parser = parser
        self.event_bus = event_bus
        self.repository = repository
        self.rules = rules or default_rules(domain_registry=domain_registry)
        self.cross_rules = cross_rules or default_cross_rules()
        self.cross_schema_rules = cross_schema_rules or default_cross_schema_rules()
        self.index_provider = index_provider

    def discover_contracts(self, sink: DiagnosticSink = NullDiagnosticSink()) -> list[ContractLocation]:
        """Scan the repository for YAML files that match a registered contract format.

        Globs all YAML files via the repository, then filters to those that
        at least one registered reader accepts.

        Args:
            sink: Collects diagnostics from the repository scan.

        Returns:
            List of contract locations found in the repository.

        Raises:
            RuntimeError: If no repository is configured.
            TurbineError: If no readable contract files are found.
        """
        if self.repository is None:
            raise RuntimeError("discover_contracts() called without a configured repository")
        logger.info("Discovering contracts")
        contracts = [loc for loc in self.repository.list_contracts(sink=sink) if self.is_readable(loc)]
        if not contracts:
            raise (
                DiagnosticBuilder.error(DiagnosticId.CONTRACT_NOT_FOUND, "No contract YAML files found.")
                .help("Create a file in `contracts/`, or pass a contract path to the command.")
                .into_error()
            )
        return contracts

    def is_readable(self, location: ContractLocation) -> bool:
        """Check if any registered reader can handle the contract at *location*.

        Args:
            location: Contract file location to probe.

        Returns:
            True if at least one reader accepts the parsed data.
        """
        try:
            source = (
                self.repository.resolve(str(location.path))
                if self.repository
                else self.parser(location.path)
            )
        except (TurbineError, OSError):
            return False
        return any(reader.can_read(source.data) for reader in self.registry.readers)

    def lint_path(self, path: Path) -> DiagnosticCollector:
        """Parse a contract file from disk and run the full lint pipeline.

        Publishes a ``ContractLinted`` event after completion.

        Args:
            path: Filesystem path to the contract file.

        Returns:
            Collector containing all diagnostics from schema and domain validation.
        """
        logger.debug(f"Reading contract: {path}")
        source = self.parser(path)
        collector = self.lint_source(source)
        logger.info(f"Lint complete: {len(collector.items)} diagnostics")
        lint_event = ContractLinted(
            path=path, diagnostic_count=len(collector.items), has_errors=collector.has_errors
        )
        logger.debug(f"Publishing ContractLinted event for {path}")
        self.event_bus.publish(lint_event)
        return collector

    def lint_source(self, source: RawSource) -> DiagnosticCollector:
        """Lint a pre-parsed source through schema validation and domain rules.

        Files without a top-level ``kind:`` field (e.g. datasource configs) are
        skipped silently — they are not contracts. If the file claims a ``kind:``
        but a reader returns no contracts without emitting errors, a fallback
        ``CONTRACT_PARSE_ERROR`` catches the silent failure.

        Args:
            source: Already-parsed YAML source with data and source map.

        Returns:
            Collector containing all diagnostics from the lint run.
        """
        collector, _ = self.lint_source_with_contracts(source)
        return collector

    def lint_source_with_contracts(
        self, source: RawSource
    ) -> tuple[DiagnosticCollector, tuple[DatasetSpec, ...]]:
        """Lint *source* and also return the parsed contracts for downstream passes.

        The registry dispatches contracts, quality specs, AND datasource YAMLs
        — every format that owns a ``FormatReader``. Datasources never produce
        ``DatasetSpec``s so the "no contracts and no errors" fallback only
        fires when the document actually claims a ``kind:`` (i.e. it's trying
        to be a contract but the reader couldn't make sense of it).

        QualitySpec specs that declare a ``targetContract`` are merged with
        the target's columns + SLA before per-contract rules run, so column
        and SLA references resolve at lint time the same way they do at
        ``check`` time. The merge prefers the ``ContractRepository`` (CLI
        path) but falls back to the ``index_provider`` (LSP path) so the
        editor and the CLI see the same merged spec. A missing target
        leaves the spec unmerged and the cross-contract pass surfaces it.
        """
        logger.debug(f"Running schema validation on {source.path}")
        collector = DiagnosticCollector()
        for parse_diag in source.parse_diagnostics:
            collector.add(parse_diag)
        contracts = self.registry.read(source, collector)
        if not contracts and not collector.has_errors and FIELD_KIND in source.data:
            collector.add(
                DiagnosticBuilder.error(
                    DiagnosticId.CONTRACT_PARSE_ERROR, "Contract could not be parsed"
                )
                .span(source.path)
                .build()
            )
        contracts = tuple(self.merge_with_target(spec) for spec in contracts)
        per_contract_done: set[tuple[str, str]] = set()
        for contract in contracts:
            logger.debug(f"Running domain validation on {contract.table}")
            self.run_rules(contract, collector, per_contract_done)
            self.run_cross_rules(contract, collector)
        self.run_cross_schema_rules(contracts, collector)
        return collector, tuple(contracts)

    def merge_with_target(self, spec: DatasetSpec) -> DatasetSpec:
        """Merge *spec* with its target contract's columns + SLA when applicable.

        Tries the registered :class:`ContractRepository` first (CLI path),
        falls back to the :class:`ProjectIndex` (LSP path). When both are
        absent or the target can't be resolved, returns *spec* unchanged
        and lets ``run_cross_rules`` raise the missing-target diagnostic.
        """
        if not spec.target_contract:
            return spec
        if self.repository is not None:
            return merge_target(spec, self.registry, NullDiagnosticSink(), repository=self.repository)
        if self.index_provider is None:
            return spec
        targets = target_specs_from_index(self.index_provider(), spec.target_contract)
        target = select_target_spec(targets, spec.table)
        if target is None:
            return spec
        merged_checks = merge_checks(spec.checks, target.checks, sink=NullDiagnosticSink())
        return replace(spec, columns=target.columns, checks=merged_checks, sla=target.sla or spec.sla)

    def run_cross_schema_rules(
        self, contracts: tuple[DatasetSpec, ...], collector: DiagnosticCollector
    ) -> None:
        """Group *contracts* by contract id and run each cross-schema rule once per group.

        Cross-schema rules need every spec belonging to a contract at once
        to validate fields like ``slaProperties`` that live at the contract
        level but reference schema-level data.
        """
        if not self.cross_schema_rules:
            return
        groups: dict[str, list[DatasetSpec]] = {}
        for contract in contracts:
            groups.setdefault(contract.metadata.contract_id, []).append(contract)
        for specs in groups.values():
            spec_tuple = tuple(specs)
            for rule in self.cross_schema_rules:
                rule.check(spec_tuple, collector)

    def run_rules(
        self,
        contract: DatasetSpec,
        collector: DiagnosticCollector,
        per_contract_done: set[tuple[str, str]],
    ) -> None:
        """Apply each lint rule to *contract*, deduping PER_CONTRACT rules across specs."""
        contract_id = contract.metadata.contract_id
        for rule in self.rules:
            if rule.scope is RuleScope.PER_CONTRACT:
                key = (rule.name, contract_id)
                if key in per_contract_done:
                    continue
                per_contract_done.add(key)
            rule.check(contract, collector)

    def run_cross_rules(self, spec: "DatasetSpec", collector: DiagnosticCollector) -> None:
        """Run cross-contract rules if the spec has a target_contract and an index is available."""
        if not self.index_provider:
            return
        if spec.target_contract is None:
            return

        index = self.index_provider()
        context = self.resolve_target_context(spec, index, collector)
        if context is None:
            return

        if self.cross_rules:
            for rule in self.cross_rules:
                rule.check(spec, context, collector)

    def resolve_target_context(
        self, spec: DatasetSpec, index: ProjectIndex, sink: DiagnosticSink
    ) -> TargetContractContext | None:
        """Find the target Contract context, emitting an error if it doesn't exist.

        For multi-table contracts, selects the spec whose table matches the
        quality spec's dataset. Falls back to the first spec with the same
        contract id so other cross-contract rules can still report useful diagnostics.
        """
        contract_id = spec.target_contract
        assert contract_id is not None
        all_targets = target_specs_from_index(index, contract_id)
        if not all_targets:
            self.emit_target_not_found(spec, contract_id, index, sink)
            return None
        selected = select_target_spec(all_targets, spec.table)
        if selected is None:
            return None
        return TargetContractContext(contract_id=contract_id, specs=all_targets, selected=selected)

    def emit_target_not_found(
        self, spec: "DatasetSpec", contract_id: str, index: "ProjectIndex", sink: DiagnosticSink
    ) -> None:
        """Emit an error when targetContract references a non-existent contract."""
        all_ids = sorted({contract.metadata.contract_id for contract in index.contracts()})
        matches = get_close_matches(contract_id, all_ids, n=1, cutoff=0.5)
        best = matches[0] if matches else None
        builder = DiagnosticBuilder.error(
            DiagnosticId.VALIDATION,
            f"This Quality Spec references contract `{contract_id}`, but that contract was not found.",
        ).span(spec.metadata.source_path, spec.target_contract_source_range)
        if best:
            builder.help(f"Change `targetContract` to `{best}`.")
        elif all_ids:
            builder.help(f"Available contracts: {', '.join(all_ids)}.")
        diagnostic = builder.build()
        data = DiagnosticData(
            kind=DiagnosticKind.TARGET_CONTRACT_NOT_FOUND, field_name=contract_id, suggested_value=best
        )
        sink.add(replace(diagnostic, data=data))
