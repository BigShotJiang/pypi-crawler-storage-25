"""Filter the check catalog by scope."""

from turbine.core.analysis.check_catalog import CHECK_CATALOG, CheckCatalogEntry, CheckScope


def filter_catalog(scope: CheckScope) -> tuple[CheckCatalogEntry, ...]:
    """Return catalog entries valid for the given scope."""
    return tuple(entry for entry in CHECK_CATALOG if scope in entry.scopes)
