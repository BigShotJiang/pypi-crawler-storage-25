"""LspClient protocol — driving-side callback for editor communication.

Application layer defines what it needs from the editor.
Presentation layer provides the concrete implementation (wrapping pygls).
"""

from dataclasses import dataclass
from typing import Protocol

from turbine.core.analysis.check_catalog import CheckCatalogEntry
from turbine.core.building_blocks import Diagnostic
from turbine.core.common.quality_dimension import QualityDimension


@dataclass(frozen=True, slots=True)
class TableRef:
    """A schema-qualified table reference used by the table picker."""

    schema: str
    table: str


@dataclass(frozen=True, slots=True)
class DatasourcePick:
    """A Datasource option used by the Datasource picker."""

    name: str
    ds_type: str
    uri: str


@dataclass(frozen=True, slots=True)
class CheckPickResult:
    """The user's selection from the check picker."""

    check_type: str
    dimension: QualityDimension


class LspClient(Protocol):
    """Editor communication port used by workspace commands.

    Async methods are LSP requests (need a response from the editor).
    Sync methods are LSP notifications (fire-and-forget).
    """

    async def apply_edit(self, uri: str, content: str, *, overwrite: bool = False) -> bool:
        """Create or overwrite a file in the workspace via the editor.

        Returns True if the editor applied the edit successfully.
        """
        ...

    async def show_message_request(self, message: str, actions: tuple[str, ...]) -> str | None:
        """Show a message with action buttons and return the user's choice.

        Returns the chosen action label, or None if the user dismissed.
        """
        ...

    async def pick_tables(self, tables: tuple[TableRef, ...]) -> tuple[TableRef, ...] | None:
        """Ask the editor to show a multi-select table picker.

        Sends a ``turbine/pickTables`` server-to-client request. Returns the
        selected tables, or None if the user dismissed the picker.
        """
        ...

    async def pick_datasource(self, datasources: tuple[DatasourcePick, ...]) -> DatasourcePick | None:
        """Ask the editor to show a Datasource picker.

        Sends a ``turbine/pickDatasource`` server-to-client request. Returns the
        selected Datasource, or None if the user dismissed the picker.
        """
        ...

    async def prompt_text(self, message: str, placeholder: str = "") -> str | None:
        """Ask the editor to show an input box and return the entered text.

        Sends a ``turbine/inputText`` server-to-client request. Returns the
        entered text, or None if the user dismissed the input.
        """
        ...

    async def show_document(self, uri: str) -> bool:
        """Ask the editor to open a document and return whether it succeeded."""
        ...

    async def pick_check(self, catalog: tuple[CheckCatalogEntry, ...]) -> CheckPickResult | None:
        """Ask the editor to show a check picker and return the selection.

        Sends a ``turbine/pickCheck`` server-to-client request with the
        filtered catalog. Returns the user's choice (check type + dimension),
        or None if dismissed.
        """
        ...

    async def pick_column(self, columns: tuple[str, ...]) -> str | None:
        """Ask the editor to show a column picker and return the selection.

        Sends a ``turbine/pickColumn`` server-to-client request with column names.
        Returns the selected column name, or None if dismissed.
        """
        ...

    def get_document_content(self, uri: str) -> str | None:
        """Return the current in-editor content for *uri*, or None if not open."""
        ...

    def show_message(self, message: str) -> None:
        """Show a toast notification in the editor."""
        ...

    def clear(self, uri: str) -> None:
        """Clear diagnostics for a URI."""
        ...

    def publish_diagnostics(self, uri: str, diagnostics: tuple[Diagnostic, ...]) -> None:
        """Publish diagnostics for a URI."""
        ...

    def refresh_code_lenses(self) -> None:
        """Tell the editor to re-request code lenses for all open files."""
        ...

    def refresh_diagnostics(self) -> None:
        """Tell the editor to re-pull diagnostics for all open files."""
        ...
