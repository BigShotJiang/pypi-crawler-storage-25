"""Application-layer schema validation service for the LSP turbine/validateSchema method."""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from difflib import get_close_matches
from pathlib import Path

from turbine.application.analysis.diagnostics import extract_schema_name
from turbine.application.analysis.drift_mapping import finding_to_diagnostic
from turbine.core.analysis.context import uri_to_path
from turbine.core.analysis.protocol import (
    DriftChangeKind,
    DriftColumn,
    SchemaDrift,
    ValidateSchemaLspResult,
    ValidateSchemaParams,
)
from turbine.core.analysis.source_spans import find_column_span, find_table_span
from turbine.core.building_blocks import (
    Diagnostic,
    DiagnosticBuilder,
    DiagnosticData,
    DiagnosticId,
    DiagnosticKind,
    Span,
)
from turbine.core.common import FIELD_SCHEMA, DatasetSpec, RawSource, TableIdentifier
from turbine.core.common.introspection_cache import DbTableInfo, IntrospectionCache
from turbine.core.common.ports import IntrospectionError, IntrospectionResult, ListTablesResult
from turbine.core.validation.model import ValidationFinding, ValidationType
from turbine.core.validation.validator import SchemaValidator

IntrospectFn = Callable[[str, TableIdentifier, str | None], IntrospectionResult | IntrospectionError]
ListTablesFn = Callable[[str, str, frozenset[str]], ListTablesResult]


def validation_type_to_drift_kind(validation_type: ValidationType) -> DriftChangeKind:
    """Translate a ValidationType to its DriftChangeKind bucket.

    Total mapping with no fall-through: every ValidationType member maps to exactly
    one DriftChangeKind. ``LENGTH_MISMATCH`` and ``PRECISION_MISMATCH`` collapse
    into ``TYPE_CHANGED`` because they are facets of the column's type rather
    than first-class drift categories.
    """
    match validation_type:
        case ValidationType.MISSING_IN_DB:
            return DriftChangeKind.REMOVED
        case ValidationType.EXTRA_IN_DB:
            return DriftChangeKind.ADDED
        case ValidationType.NULLABLE_MISMATCH:
            return DriftChangeKind.NULLABLE_CHANGED
        case ValidationType.PK_MISMATCH:
            return DriftChangeKind.PK_CHANGED
        case ValidationType.UNIQUE_MISMATCH:
            return DriftChangeKind.UNIQUE_CHANGED
        case (
            ValidationType.TYPE_MISMATCH
            | ValidationType.LENGTH_MISMATCH
            | ValidationType.PRECISION_MISMATCH
        ):
            return DriftChangeKind.TYPE_CHANGED


@dataclass(frozen=True, slots=True)
class ValidationOutcome:
    """LSP drift result plus the fresh introspection cache produced by this run.

    ``cache`` is ``None`` when the run failed before any live introspection
    happened — e.g. the datasource was unreachable. The caller should preserve
    the previous cache in that case so existing diagnostics do not vanish.
    """

    result: ValidateSchemaLspResult
    cache: IntrospectionCache | None
    diagnostics: tuple[Diagnostic, ...]


def finding_to_drift_column(
    finding: ValidationFinding, source: RawSource | None, source_path: Path, table_label: str
) -> DriftColumn:
    """Convert a ValidationFinding to a DriftColumn, attaching a source range when possible."""
    change = validation_type_to_drift_kind(finding.validation_type)
    span: Span | None = None
    if source is not None:
        span = find_column_span(source, source_path, finding.column) or find_table_span(
            source, source_path, table_label
        )
    text_range = span.range if span is not None else None
    return DriftColumn(
        name=finding.column,
        change=change,
        expected_type=finding.contract_value,
        actual_type=finding.db_value,
        start_line=text_range.start_line if text_range else None,
        start_col=text_range.start_col if text_range else None,
        end_line=text_range.end_line if text_range else None,
        end_col=text_range.end_col if text_range else None,
    )


class SchemaValidationService:
    """Compare a contract's schema against the live database and return validation results.

    On every call the service refreshes an ``IntrospectionCache`` snapshot:

    - ``list_tables`` populates ``known_table_names`` for the chosen datasource.
    - Columns are only introspected for contracts whose dataset is actually
      present in the database, so missing-table rows never trigger extra IO.
    - Contracts that were part of this run land in ``validated_uris``, scoping
      the DATASOURCE_TABLE_NOT_FOUND lint rule to the right files.
    """

    def __init__(
        self,
        validator: SchemaValidator | None,
        introspect: IntrospectFn | None = None,
        list_tables: ListTablesFn | None = None,
    ) -> None:
        self.validator = validator
        self.introspect = introspect
        self.list_tables = list_tables

    def validate(
        self, params: ValidateSchemaParams, source: RawSource | None, contracts: tuple[DatasetSpec, ...]
    ) -> ValidationOutcome:
        """Run schema validation for *contracts* parsed from the URI's contents.

        Callers parse the contract YAML upstream and pass the result; this
        keeps the service stateless and free of any live-document closures.
        Returns a ``ValidationOutcome`` whose ``result.error`` is set when the
        datasource is unreachable or when the contract references a table the
        datasource does not expose. On connection failure the outcome's
        ``cache`` is ``None`` so the caller preserves any previously stored
        introspection state instead of wiping it.

        QualitySpecs are filtered out — they declare no columns, so comparing
        them against a real database produces a fake "every column was added"
        diagnostic for every column on every table they touch.
        """
        if not contracts:
            return empty_outcome(contract_id="")

        first_contract_id = contracts[0].metadata.contract_id
        contracts = tuple(spec for spec in contracts if spec.metadata.is_contract)
        if not contracts:
            return non_contract_outcome(first_contract_id)

        contract_id = contracts[0].metadata.contract_id
        if self.validator is None or self.introspect is None:
            return empty_outcome(contract_id=contract_id)

        list_result = self.fetch_known_tables(params.uri, params.datasource, contracts)
        if list_result.error is not None:
            return unreachable_outcome(contract_id, params.datasource, list_result.error)

        known_names = frozenset(str(table) for table in list_result.tables)
        path = uri_to_path(params.uri)
        schemas, tables_info, diagnostics = self.process_contracts(
            params.uri, contracts, known_names, params.datasource, source, path
        )
        missing_tables: tuple[str, ...] = ()
        if params.datasource is not None:
            missing_tables = tuple(
                str(contract.table) for contract in contracts if str(contract.table) not in known_names
            )
        diagnostics = diagnostics + table_not_found_diagnostics(
            source, path, missing_tables, known_names
        )

        cache = IntrospectionCache(
            tables=tables_info, known_table_names=known_names, validated_uris=frozenset({params.uri})
        )
        result = ValidateSchemaLspResult(
            contract_id=contract_id,
            schemas=tuple(schemas),
            has_drift=any(schema.columns for schema in schemas),
            error=missing_tables_error(missing_tables, params.datasource),
        )
        return ValidationOutcome(result=result, cache=cache, diagnostics=diagnostics)

    def process_contracts(
        self,
        uri: str,
        contracts: tuple[DatasetSpec, ...],
        known_names: frozenset[str],
        datasource: str | None,
        source: RawSource | None,
        source_path: Path,
    ) -> tuple[list[SchemaDrift], dict[str, DbTableInfo], tuple[Diagnostic, ...]]:
        """Introspect + drift-check every contract whose table is in *known_names*."""
        schemas: list[SchemaDrift] = []
        tables_info: dict[str, DbTableInfo] = {}
        diagnostics: list[Diagnostic] = []
        for contract in contracts:
            table_label = str(contract.table)
            if table_label not in known_names:
                continue
            drift = self.run_drift(uri, contract, datasource, source, source_path, table_label)
            if drift is None:
                continue
            table_drift, db_table, table_diagnostics = drift
            tables_info[table_label] = db_table
            diagnostics.extend(table_diagnostics)
            if table_drift.columns:
                schemas.append(table_drift)
        return schemas, tables_info, tuple(diagnostics)

    def fetch_known_tables(
        self, uri: str, datasource: str | None, contracts: tuple[DatasetSpec, ...]
    ) -> ListTablesResult:
        """Ask the adapter for every table on *datasource* across used schemas.

        Returns an empty successful result when there is no datasource adapter
        wired up or when the caller did not pick a datasource — both are "no
        live data" states, not connection failures.
        """
        if self.list_tables is None or datasource is None:
            return ListTablesResult.ok(())
        schemas = frozenset(contract.table.schema for contract in contracts)
        return self.list_tables(uri, datasource, schemas)

    def run_drift(
        self,
        uri: str,
        contract: DatasetSpec,
        datasource: str | None,
        source: RawSource | None,
        source_path: Path,
        table_label: str,
    ) -> tuple[SchemaDrift, DbTableInfo, tuple[Diagnostic, ...]] | None:
        """Run drift detection for a single contract and return drift + cache entry."""
        assert self.introspect is not None  # guarded by validate()
        assert self.validator is not None  # guarded by validate()
        result = self.introspect(uri, contract.table, datasource)
        if isinstance(result, IntrospectionError):
            return None

        db_table = DbTableInfo(table_name=table_label, columns=result.columns)
        findings = tuple(self.validator.validate_columns(contract.columns, result))
        drift_columns = tuple(
            finding_to_drift_column(finding, source, source_path, table_label) for finding in findings
        )
        diagnostics = tuple(
            finding_to_diagnostic(finding, source, source_path, table_label) for finding in findings
        )
        return SchemaDrift(schema_name=table_label, columns=drift_columns), db_table, diagnostics


def table_not_found_diagnostics(
    source: RawSource | None,
    source_path: Path,
    missing_tables: tuple[str, ...],
    known_names: frozenset[str],
) -> tuple[Diagnostic, ...]:
    """Build drift-source diagnostics for schema entries absent from the datasource."""
    if not missing_tables:
        return ()
    schema_indexes = schema_indexes_by_name(source)
    diagnostics: list[Diagnostic] = []
    for table_name in missing_tables:
        matches = get_close_matches(table_name, sorted(known_names), n=1, cutoff=0.5)
        best = matches[0] if matches else None
        builder = DiagnosticBuilder.error(
            DiagnosticId.DATASOURCE_TABLE_NOT_FOUND,
            f"Table `{table_name}` was not found in the datasource database.",
        )
        if source is not None and table_name in schema_indexes:
            text_range = source.source_map.range_for_value(
                f"{FIELD_SCHEMA}.{schema_indexes[table_name]}.name"
            )
            builder.annotate(Span(path=source_path, range=text_range))
        if best is not None:
            builder.help(f"Use `{best}`, or check that `{table_name}` exists in the database.")
        else:
            builder.help("Check the table name and datasource connection.")
        builder.data(
            DiagnosticData(
                kind=DiagnosticKind.DATASOURCE_TABLE_NOT_FOUND,
                field_name=table_name,
                suggested_value=best,
            )
        )
        diagnostics.append(builder.build())
    return tuple(diagnostics)


def schema_indexes_by_name(source: RawSource | None) -> dict[str, int]:
    """Return schema-list indexes keyed by table name for source-map lookups."""
    if source is None:
        return {}
    schema_list = source.data.get(FIELD_SCHEMA)
    if not isinstance(schema_list, list):
        return {}
    result: dict[str, int] = {}
    for index, entry in enumerate(schema_list):
        name = extract_schema_name(entry)
        if name is not None:
            result[name] = index
    return result


def empty_outcome(contract_id: str) -> ValidationOutcome:
    """Return a no-op outcome carrying an empty cache and drift-free result."""
    result = ValidateSchemaLspResult(contract_id=contract_id, schemas=(), has_drift=False)
    return ValidationOutcome(result=result, cache=IntrospectionCache.empty(), diagnostics=())


def non_contract_outcome(contract_id: str) -> ValidationOutcome:
    """Return an outcome flagging that the file is a QualitySpec, not a contract.

    Cache is the empty cache (not ``None``) so the editor wipes any stale
    drift state for this URI rather than preserving it — there is nothing
    legitimate to keep when the input cannot be validated.
    """
    result = ValidateSchemaLspResult(
        contract_id=contract_id,
        schemas=(),
        has_drift=False,
        error=(
            f"`{contract_id}` is a QualitySpec, not a contract. "
            "Schema validation needs the target contract — pick the contract file instead."
        ),
    )
    return ValidationOutcome(result=result, cache=IntrospectionCache.empty(), diagnostics=())


def unreachable_outcome(contract_id: str, datasource: str | None, reason: str) -> ValidationOutcome:
    """Return an outcome flagging the datasource as unreachable.

    The ``cache`` is ``None`` so the LSP handler leaves the previously stored
    introspection cache intact so diagnostics are not silently cleared when
    the datasource is down.
    """
    label = f"datasource '{datasource}'" if datasource else "datasource"
    result = ValidateSchemaLspResult(
        contract_id=contract_id, schemas=(), has_drift=False, error=f"Cannot reach {label}: {reason}"
    )
    return ValidationOutcome(result=result, cache=None, diagnostics=())


def missing_tables_error(missing: tuple[str, ...], datasource: str | None) -> str | None:
    """Build a user-facing error when the contract's tables are not on the datasource."""
    if not missing:
        return None
    label = f"datasource '{datasource}'" if datasource else "the datasource"
    joined = ", ".join(f"'{name}'" for name in missing)
    if len(missing) == 1:
        return f"{label} has no table {joined}"
    return f"{label} has no tables: {joined}"
