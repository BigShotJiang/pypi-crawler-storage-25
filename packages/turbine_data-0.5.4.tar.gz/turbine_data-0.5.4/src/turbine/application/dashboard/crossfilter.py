"""Crossfilter primitives: selection filtering and item highlighting.

Owns the two presentation-layer concerns that used to be sprinkled into
``auto_bind`` and ``EChartsOption.from_bar``:

1. Filtering a dataset by the page's active selections (with self-exclusion
   when the chart is the one that set the selection).
2. Projecting a values list into per-item ``itemStyle`` dicts so the
   active bar/slice renders at full opacity and the rest fade out.

Both primitives are pure functions. Handlers in ``renderer.py`` compose
them against ``auto_bind``-bound charts.
"""

from __future__ import annotations

import dataclasses
from collections.abc import Sequence
from typing import Any, cast

from turbine.application.dashboard.autobind import find_model_type
from turbine.core.dashboard.dataset import Dataset
from turbine.core.dashboard.interactions import ScopeTo
from turbine.core.dashboard.selection_store import SelectionStore


def apply_crossfilter[C](chart: C, store: SelectionStore) -> C:
    """Return ``chart`` with its ``data`` filtered by active selections.

    Idempotent on charts without a ``data`` field (KPI, Gauge, layout) and
    on stores with no matching selections. Called as a fixed stage of every
    chart handler so crossfiltering is wired in one place, not per-handler.
    """
    data = getattr(chart, "data", None)
    if data is None or store.is_empty:
        return chart
    model_type = find_model_type(chart)
    if model_type is None:
        return chart
    filtered = apply_selection_filter(data, chart, model_type, store)
    if filtered is data:
        return chart
    return cast("C", dataclasses.replace(cast("Any", chart), data=filtered))


def apply_selection_filter[M](
    dataset: Dataset[M], chart: Any, model_type: type, store: SelectionStore
) -> Dataset[M]:
    """Filter ``dataset`` by active selections matching ``model_type``.

    Skips the chart's own ``scope_to`` field so the excluded rows stay
    available for opacity-based highlighting. Returns ``dataset`` unchanged
    when the store is empty or has no matching selections.
    """
    if store.is_empty:
        return dataset
    on_click = getattr(chart, "on_click", None)
    exclude = on_click.field if isinstance(on_click, ScopeTo) else None
    where_kwargs = store.selections_for(model_type, exclude=exclude)
    if not where_kwargs:
        return dataset
    return dataset.where(**where_kwargs)


ACTIVE_OPACITY = 1.0
FADED_OPACITY = 0.25


def highlight_items(
    values: Sequence[float], categories: Sequence[Any], active_value: str | None, accent_color: str
) -> list[Any]:
    """Project ``values`` into per-item ``itemStyle`` dicts with fade-highlight.

    When ``active_value`` is None, returns a plain list of values (no styling).
    Otherwise returns a list of ``{value, itemStyle: {color, opacity}}`` dicts
    where the entry whose category matches ``active_value`` stays at full
    opacity and the rest fade out.
    """
    if active_value is None:
        return list(values)
    return [
        {
            "value": value,
            "itemStyle": {
                "color": accent_color,
                "opacity": ACTIVE_OPACITY if str(category) == active_value else FADED_OPACITY,
            },
        }
        for category, value in zip(categories, values, strict=True)
    ]
