"""Compute the option list for a Picker widget.

Two modes:

- Generic mode (``source=``): fetch options via the ``Query`` dispatcher,
  scoped to the active ``TimeRange``.
- Typed mode (``column=``): materialize from ``picker.values`` (a ``StrEnum``
  or a tuple of strings), prefixed with the ``"All"`` no-op literal.

Pure function. Presentation-layer composition roots call it to populate
``st.selectbox`` options without leaking Query/TimeRange plumbing into the
renderer.
"""

from __future__ import annotations

from enum import StrEnum

from turbine.core.dashboard.components.data import ALL_VALUE, Picker
from turbine.core.dashboard.models import TimeRange
from turbine.core.dashboard.query import Query, QueryDispatcher


def picker_options(picker: Picker, dispatcher: QueryDispatcher, time_range: TimeRange) -> list[str]:
    """Return the option list for ``picker``.

    Generic mode fetches via ``Query``; typed mode materializes the local
    values. An empty/unset values attribute collapses to ``[ALL_VALUE]``.
    """
    if picker.source is not None:
        fetched: list[str] = Query(dispatcher)(picker.source).since(time_range).fetch()
        return fetched
    values = picker.values
    if values is None:
        return [ALL_VALUE]
    if isinstance(values, tuple):
        return [ALL_VALUE, *values]
    if isinstance(values, type) and issubclass(values, StrEnum):
        return [ALL_VALUE, *(member.value for member in values)]
    return [ALL_VALUE]
