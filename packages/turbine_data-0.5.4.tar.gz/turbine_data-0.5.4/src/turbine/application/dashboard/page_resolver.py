"""Resolve page dependencies with picker-bound datasets.

Scans a ``@page`` function's signature, resolves each ``Depends(...)`` param.
When a ``DependsMarker`` has a ``picker=`` kwarg, the resolver:

- Resolves the picker(s) via the registry's picker_resolver
- Fetches the dataset (via fallback factory or TableView factory)
- Applies typed picker filters (``column=``) as ``.where()`` calls
- Wraps the result with ``.with_picker_value()`` to carry the selection map

The literal string ``"All"`` skips filtering but is still recorded in
``picker_value``.

Resource dependencies (``Depends(CheckCounters())``) are executed via the
``executor`` callable. The default executor pulls ``Query`` and ``TimeRange``
from the registry and runs ``query(resource).since(time_range).fetch()``.
Tests may pass an explicit ``executor`` to short-circuit registry lookup.
"""

from __future__ import annotations

import inspect
import typing
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, get_args, get_origin

from turbine.core.dashboard.components.data import ALL_VALUE, Picker
from turbine.core.dashboard.dataset import Dataset
from turbine.core.dashboard.in_memory_dataset import InMemoryDataset
from turbine.core.dashboard.injection import DependencyRegistry, DependsMarker, Param, Selection, State
from turbine.core.dashboard.models import TimeRange
from turbine.core.dashboard.query import Query, Resource
from turbine.core.dashboard.table_view import TableView


@dataclass(frozen=True)
class PickerDatasetSpec:
    """A dataset dependency with one or more pickers attached."""

    dependency: type[Any]
    pickers: tuple[Picker, ...]


type Marker = Param | Selection | State
type ResourceExecutor = Callable[[Resource[Any]], Any]


@dataclass(frozen=True)
class PageSignature:
    """Classified page parameters, derived from the inspected signature."""

    picker_datasets: dict[str, PickerDatasetSpec]
    dataset_models: dict[str, type]
    markers: dict[str, Marker]
    resources: dict[str, Resource[Any]]
    other_deps: dict[str, Any]


def resolve(
    page_fn: Callable[..., Any],
    registry: DependencyRegistry,
    *,
    executor: ResourceExecutor | None = None,
) -> tuple[dict[str, Any], dict[type, Dataset[Any]]]:
    """Resolve all ``Depends(...)`` params on a page function.

    Returns ``(deps, datasets)`` where ``deps`` is suitable for splatting
    into the page function and ``datasets`` maps each declared model type
    to its resolved ``Dataset`` instance. The datasets map enables
    renderer-level auto-binding of FieldRef-based charts.

    ``executor`` controls how Resource dependencies are executed; when
    omitted, the registry's ``Query`` and ``TimeRange`` are used.
    """
    page_sig = classify_signature(page_fn)
    values = resolve_non_pickers(page_sig, registry)
    values.update(resolve_picker_datasets(page_sig, registry))
    values.update(resolve_resources(page_sig, registry, executor))
    values.update(resolve_markers(page_sig, registry))
    datasets = extract_datasets(page_sig, values)
    return values, datasets


def extract_datasets(page_sig: PageSignature, values: dict[str, Any]) -> dict[type, Dataset[Any]]:
    """Build a ``type -> Dataset`` map from the classified signature and resolved values.

    Used by the renderer to auto-bind FieldRef-based charts to the dataset
    whose model class matches their FieldRef ``.class_``.
    """
    datasets: dict[type, Dataset[Any]] = {}
    for name, model in page_sig.dataset_models.items():
        datasets[model] = values[name]
    for name, spec in page_sig.picker_datasets.items():
        if isinstance(spec.dependency, type):
            datasets[spec.dependency] = values[name]
    return datasets


def classify_signature(page_fn: Callable[..., Any]) -> PageSignature:
    """Walk the signature and bucket params by role."""
    buckets = PageSignature(
        picker_datasets={}, dataset_models={}, markers={}, resources={}, other_deps={}
    )
    hints = typing.get_type_hints(page_fn)
    for name, param in inspect.signature(page_fn).parameters.items():
        if not isinstance(param.default, DependsMarker):
            continue
        classify_dep(name, param.default, hints.get(name), buckets)
    return buckets


def classify_dep(name: str, marker: DependsMarker, hint: Any, buckets: PageSignature) -> None:
    """Route a single dependency into the matching PageSignature bucket."""
    dep = marker.dependency
    if marker.picker is not None:
        pickers = normalize_pickers(marker.picker)
        buckets.picker_datasets[name] = PickerDatasetSpec(dependency=dep, pickers=pickers)
        return
    if isinstance(dep, Param | Selection | State):
        buckets.markers[name] = dep
    elif isinstance(dep, Resource):
        buckets.resources[name] = dep
        model = extract_dataset_model(hint)
        if model is not None:
            buckets.dataset_models[name] = model
    else:
        model = extract_dataset_model(hint)
        if model is not None:
            buckets.dataset_models[name] = model
        buckets.other_deps[name] = dep


def normalize_pickers(picker: Picker | tuple[Picker, ...]) -> tuple[Picker, ...]:
    """Normalize a single Picker or tuple of Pickers into a tuple."""
    if isinstance(picker, Picker):
        return (picker,)
    return picker


def extract_dataset_model(annotation: Any) -> type | None:
    """Extract ``M`` from a ``Dataset[M]`` annotation, or return None."""
    if get_origin(annotation) is not Dataset:
        return None
    args = get_args(annotation)
    if not args:
        return None
    model = args[0]
    return model if isinstance(model, type) else None


def resolve_non_pickers(page_sig: PageSignature, registry: DependencyRegistry) -> dict[str, Any]:
    """Resolve every non-Picker dependency via the registry."""
    return {name: registry.resolve(dep) for name, dep in page_sig.other_deps.items()}


def default_executor(registry: DependencyRegistry) -> ResourceExecutor:
    """Build the default Resource executor from the registry's Query + TimeRange."""
    query = registry.resolve(Query)
    time_range = registry.resolve(TimeRange)

    def execute(resource: Resource[Any]) -> Any:
        return query(resource).since(time_range).fetch()

    return execute


def resolve_resources(
    page_sig: PageSignature, registry: DependencyRegistry, executor: ResourceExecutor | None
) -> dict[str, Any]:
    """Execute Resource dependencies via ``executor``.

    When the page function annotates a Resource parameter as ``Dataset[M]``,
    the fetched list is auto-wrapped in ``InMemoryDataset`` so it participates
    in FieldRef auto-binding and crossfilter.
    """
    if not page_sig.resources:
        return {}
    run = executor if executor is not None else default_executor(registry)
    resolved: dict[str, Any] = {}
    for name, resource in page_sig.resources.items():
        result = run(resource)
        if name in page_sig.dataset_models and isinstance(result, list):
            result = InMemoryDataset(rows=result)
        resolved[name] = result
    return resolved


def resolve_picker_datasets(page_sig: PageSignature, registry: DependencyRegistry) -> dict[str, Any]:
    """Resolve picker-bound datasets: resolve pickers, fetch data, apply filters."""
    if registry.picker_resolver is None:
        return {}
    resolver = registry.picker_resolver
    resolved: dict[str, Any] = {}
    for name, spec in page_sig.picker_datasets.items():
        picker_value = resolve_picker_values(spec.pickers, resolver)
        dataset = fetch_picker_dataset(spec, picker_value, registry)
        resolved[name] = dataset
    return resolved


def resolve_picker_values(
    pickers: tuple[Picker, ...], resolver: Callable[[Picker], Any]
) -> dict[str, str]:
    """Resolve each picker and build the picker_value dict keyed by column.key or picker key."""
    result: dict[str, str] = {}
    for picker in pickers:
        key = picker.column.key if picker.column is not None else picker.widget_key()
        result[key] = str(resolver(picker))
    return result


def fetch_picker_dataset(
    spec: PickerDatasetSpec, picker_value: dict[str, str], registry: DependencyRegistry
) -> Any:
    """Fetch and filter the dataset based on picker selections."""
    if spec.dependency is TableView:
        return resolve_table_view(picker_value, registry)
    return resolve_typed_dataset(spec, picker_value, registry)


def resolve_table_view(picker_value: dict[str, str], registry: DependencyRegistry) -> TableView:
    """Resolve a TableView via the registered TableView factory."""
    table_name = next(iter(picker_value.values()), "All")
    factory = registry.resolve(TableView)
    return factory(table_name)


def resolve_typed_dataset(
    spec: PickerDatasetSpec, picker_value: dict[str, str], registry: DependencyRegistry
) -> Any:
    """Resolve a typed dataset, apply picker filters, attach picker_value via with_picker_value."""
    dataset = registry.resolve(spec.dependency)
    for picker in spec.pickers:
        if picker.column is None:
            continue
        selected = picker_value.get(picker.column.key, ALL_VALUE)
        if selected != ALL_VALUE:
            dataset = dataset.where(**{picker.column.key: selected})
    return dataset.with_picker_value(picker_value)


def resolve_markers(page_sig: PageSignature, registry: DependencyRegistry) -> dict[str, Any]:
    """Resolve Param, Selection, and State markers via their respective readers."""
    resolved: dict[str, Any] = {}
    for name, marker in page_sig.markers.items():
        match marker:
            case Param() as param:
                resolved[name] = resolve_param(name, param, registry)
            case Selection() as sel:
                resolved[name] = resolve_selection(sel, registry)
            case State() as state:
                resolved[name] = resolve_state(state, registry)
    return resolved


def resolve_param(name: str, param: Param, registry: DependencyRegistry) -> Any:
    """Resolve a single Param by reading a URL query param."""
    if registry.param_reader is None:
        return param.default
    param_name = param.name or name
    raw = registry.param_reader(param_name)
    return param.target_type(raw) if raw is not None else param.default


def resolve_selection(sel: Selection, registry: DependencyRegistry) -> Any:
    """Resolve a single Selection by reading page-scoped selection state."""
    if registry.state_reader is None:
        return None
    return registry.state_reader(registry.page_key, sel.field.key)


def resolve_state(state: State, registry: DependencyRegistry) -> Any:
    """Resolve a single State by reading page-scoped session state."""
    if registry.state_reader is None:
        return state.default
    value = registry.state_reader(registry.page_key, state.key)
    return value if value is not None else state.default
