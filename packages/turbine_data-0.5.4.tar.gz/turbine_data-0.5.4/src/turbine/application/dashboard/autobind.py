"""Auto-bind datasets to chart components via FieldRef matching.

At render time, charts may have `data=None` with FieldRef fields pointing
to a model class. This module inspects those FieldRefs, matches `.class_`
to the page's injected datasets, and returns a new chart instance with
`data=` filled via `dataclasses.replace`.
"""

from __future__ import annotations

import dataclasses
from collections.abc import Mapping
from dataclasses import fields
from typing import Any

from turbine.core.dashboard.dataset import Dataset
from turbine.core.dashboard.field_ref import FieldRef

type DataclassChart = Any


def auto_bind[C](chart: C, datasets: Mapping[type, Dataset[Any]]) -> C:
    """Bind a dataset to a chart by matching FieldRef model types.

    Scans the chart's dataclass fields for FieldRef values, collects
    their `.class_` attributes, and looks up a matching dataset.
    Returns `dataclasses.replace(chart, data=matched_dataset)` when a
    match is found and `chart.data` is None.
    Returns the chart unchanged otherwise.
    """
    if not dataclasses.is_dataclass(chart) or isinstance(chart, type):
        return chart
    if not hasattr(chart, "data"):
        return chart
    if chart.data is not None:
        return chart
    model_type = find_model_type(chart)
    if model_type is None:
        return chart
    matched_dataset = datasets.get(model_type)
    if matched_dataset is None:
        return chart
    return dataclasses.replace(chart, data=matched_dataset)


def find_model_type(chart: DataclassChart) -> type | None:
    """Extract the model type from a chart's FieldRef fields.

    Scans all dataclass field values. Returns the ``.class_`` of the first
    FieldRef found. Raises ``ValueError`` when FieldRefs from more than one
    model class appear on the same chart, since auto-binding has no way to
    choose between datasets. Returns ``None`` when no FieldRef fields exist.
    """
    models: dict[type, str] = {}
    for field in fields(chart):
        value = getattr(chart, field.name)
        if isinstance(value, FieldRef):
            models.setdefault(value.class_, field.name)
    if not models:
        return None
    if len(models) > 1:
        pairs = ", ".join(f"{name}={model.__name__}" for model, name in models.items())
        msg = (
            f"{type(chart).__name__}: FieldRefs point to multiple models ({pairs}). "
            "Auto-bind requires a single model per chart."
        )
        raise ValueError(msg)
    return next(iter(models))
