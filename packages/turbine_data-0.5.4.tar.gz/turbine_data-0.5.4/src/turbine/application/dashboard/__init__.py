"""Application-layer dashboard services.

Orchestrates signature scanning, auto-scoping, and dependency resolution
for `@page` functions. Imported by the Streamlit composition root to turn
a typed page signature into a filtered, ready-to-render tree.
"""

from turbine.application.dashboard.autobind import auto_bind
from turbine.application.dashboard.crossfilter import apply_crossfilter, highlight_items
from turbine.application.dashboard.page_resolver import resolve

__all__ = ["apply_crossfilter", "auto_bind", "highlight_items", "resolve"]
