"""Schema dispatch for contract-embedded ``implementation:`` blocks.

The ODCS contract schema models ``implementation`` as ``oneOf: [string, object]``,
so the schema walker that powers completion and hover sees no children inside
the block. The actual shape — ``unit``, ``column``, ``filter``, threshold
operators, ``params`` — is described by the QualitySpec ``check_item`` ``$def``,
keyed by the ``check:`` value.

This module bridges the two: when the cursor sits inside a contract
``implementation:`` block, it picks the matching QualitySpec body schema (e.g.
``freshness_body``, ``aggregate_column_body``) and returns it for the
``FormatRegistry`` to walk. The returned schema embeds the full ``$defs`` table
so ``$ref`` lookups (e.g. ``betweenRange``, ``dimension``) still resolve.
"""

from __future__ import annotations

import json
import re
from collections.abc import Mapping
from dataclasses import dataclass
from functools import cache
from importlib.resources import files
from typing import Any, cast

CONTRACT_IMPL_PATH_RE = re.compile(
    r"^schema\.\d+(?:\.properties\.\d+)?\.quality\.\d+\.implementation(?:\.(.*))?$"
)


@cache
def quality_spec_root() -> dict[str, Any]:
    """Load and cache the QualitySpec JSON Schema."""
    schema_dir = files("turbine.core.analysis.schemas")
    return json.loads((schema_dir / "quality_spec.schema.json").read_text())


@cache
def body_schema_for(check_type: str) -> dict[str, Any] | None:
    """Return the QualitySpec body ``$def`` for *check_type*, with ``$defs`` attached.

    Walks ``check_item.patternProperties`` and returns the first body whose
    pattern matches the literal *check_type*. The result is a fresh dict that
    carries the parent schema's full ``$defs`` table, so any ``$ref`` inside
    the body still resolves under the schema-walker's ``SchemaNavigator``.
    """
    root = quality_spec_root()
    check_item = root["$defs"]["check_item"]
    pattern_props = check_item.get("patternProperties", {})
    for pattern, body_ref in pattern_props.items():
        if not re.match(pattern, check_type):
            continue
        ref = body_ref.get("$ref", "")
        ref_name = ref.rsplit("/", 1)[-1]
        body = root["$defs"].get(ref_name)
        if body is None:
            return None
        return {**body, "$defs": root["$defs"]}
    return None


@dataclass(frozen=True, slots=True)
class ImplementationDispatch:
    """Result of routing a path into a contract-embedded check body.

    ``body_schema`` is a wrapper schema rooted at the matching QualitySpec body
    with ``$defs`` preserved. ``subpath`` is the dotted remainder inside the
    body (e.g. ``""``, ``"unit"``, ``"params.foo"``). ``impl_data`` is the
    YAML mapping of the implementation block, used for conditional ``$ref``
    resolution by the walker.
    """

    body_schema: dict[str, Any]
    subpath: str
    impl_data: dict[str, object]


def dispatch(data: dict[str, object], path: str) -> ImplementationDispatch | None:
    """Return a body-schema dispatch when *path* sits inside a contract ``implementation:``.

    Returns ``None`` when the document is not a DataContract, the path does
    not match the contract-implementation pattern, the implementation block
    has no string ``check:``, or no QualitySpec body claims the check type.
    """
    if data.get("kind") != "DataContract":
        return None
    match = CONTRACT_IMPL_PATH_RE.match(path)
    if not match:
        return None
    subpath = match.group(1) or ""
    impl_block = walk_to_implementation(data, path)
    if impl_block is None:
        return None
    check_type = impl_block.get("check")
    if not isinstance(check_type, str):
        return None
    body = body_schema_for(check_type)
    if body is None:
        return None
    return ImplementationDispatch(body_schema=body, subpath=subpath, impl_data=impl_block)


def walk_to_implementation(data: Mapping[str, object], path: str) -> dict[str, object] | None:
    """Walk *data* down to the ``implementation:`` block named in *path*.

    Stops at the segment named ``implementation`` and returns the dict at that
    position, or ``None`` when the walk hits a missing key, wrong type, or an
    out-of-range list index.
    """
    parts = path.split(".")
    if "implementation" not in parts:
        return None
    impl_idx = parts.index("implementation")
    current: object = data
    for part in parts[: impl_idx + 1]:
        if isinstance(current, Mapping):
            current = cast(Mapping[str, object], current).get(part)
            continue
        if isinstance(current, list):
            try:
                current = current[int(part)]
            except (ValueError, IndexError):
                return None
            continue
        return None
    if not isinstance(current, dict):
        return None
    return cast(dict[str, object], current)
