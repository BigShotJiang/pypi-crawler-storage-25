"""``SchemaCheckRunner``: evaluates schema checks at the LogicalType level.

Runs every ``check_type == "schema"`` check by introspecting the live
database through a :class:`SchemaIntrospector`, comparing the returned
columns against the contract's columns, and emitting per-finding
:class:`Diagnostic` entries on the resulting :class:`CheckResult`.

Comparison is delegated to ``core.validation.compare_columns`` — the same
pure detector the ``turbine validate`` CLI uses — so type drift, nullable
drift, and missing columns surface identically on both paths. Implements
:class:`turbine.core.quality.CheckRunner` so the orchestrator dispatches
schema checks through the unified runner registry.
"""

from __future__ import annotations

import asyncio
from collections.abc import AsyncIterator, Sequence
from dataclasses import dataclass

from turbine.core.building_blocks import Diagnostic, DiagnosticBuilder, DiagnosticId, Severity
from turbine.core.common import CheckDef, DatasetSpec, SchemaIntrospector
from turbine.core.quality import CheckResult, ExecutionOptions
from turbine.core.validation import ValidationFinding, ValidationType, compare_columns


@dataclass(frozen=True, slots=True)
class SchemaCompareOutcome:
    """Outcome of one schema introspection + comparison pass."""

    findings: tuple[ValidationFinding, ...] = ()
    table_missing: bool = False

    def blocking_findings(self) -> tuple[ValidationFinding, ...]:
        """Return findings that make the schema check fail.

        Only ERROR-severity drift blocks: missing columns and type / length /
        precision mismatch. INFO-severity drift — primary key, uniqueness,
        nullability, extra columns in the DB — surfaces as non-blocking. The
        contract's ``primaryKey: true`` is a logical uniqueness assertion the
        runtime trusts (it drives row flagging); a matching ``PRIMARY KEY``
        constraint on the DB column is nice but not required for the schema
        check to pass.
        """
        return tuple(f for f in self.findings if f.validation_type.severity is Severity.ERROR)

    def informational_findings(self) -> tuple[ValidationFinding, ...]:
        """Return findings that should surface as warnings without failing the check."""
        return tuple(f for f in self.findings if f.validation_type.severity is not Severity.ERROR)


class SchemaCheckRunner:
    """Run schema checks by introspecting the live database."""

    def __init__(self, introspector: SchemaIntrospector) -> None:
        """Store the introspector that supplies live column definitions."""
        self.introspector = introspector

    async def run(
        self, checks: Sequence[CheckDef], contract: DatasetSpec, options: ExecutionOptions
    ) -> AsyncIterator[CheckResult]:
        """Yield one :class:`CheckResult` per schema check in *checks*."""
        del options
        if not checks:
            return
        outcome = await asyncio.to_thread(self.compare, contract)
        for check in checks:
            yield self.build_result(check, outcome)

    def compare(self, contract: DatasetSpec) -> SchemaCompareOutcome:
        """Introspect the live schema and compare it against *contract*."""
        db_columns = self.introspector.introspect_schema(contract.table)
        if db_columns is None:
            return SchemaCompareOutcome(table_missing=True)
        findings = compare_columns(contract.columns, tuple(db_columns))
        return SchemaCompareOutcome(findings=tuple(findings))

    def build_result(self, check: CheckDef, outcome: SchemaCompareOutcome) -> CheckResult:
        """Build a PASSED / FAILED result with one diagnostic per finding.

        Blocking (ERROR-severity) drift makes the check FAIL with one
        ERROR diagnostic per finding. Non-blocking (INFO-severity) drift —
        PK / nullable / unique / extra-in-DB — surfaces as INFO-severity
        diagnostics on a PASSED result so the user sees the drift in the
        run output without losing every downstream check.
        """
        if outcome.table_missing:
            diagnostic = missing_table_diagnostic(check)
            return CheckResult.failed(check, rows_tested=0, rows_failed=1, diagnostics=(diagnostic,))
        info_diagnostics = tuple(
            informational_finding_diagnostic(check, finding)
            for finding in outcome.informational_findings()
        )
        drift = outcome.blocking_findings()
        if not drift:
            return CheckResult.passed(check, rows_tested=0).with_diagnostics(*info_diagnostics)
        diagnostics = (*(finding_diagnostic(check, finding) for finding in drift), *info_diagnostics)
        return CheckResult.failed(check, rows_tested=0, rows_failed=len(drift), diagnostics=diagnostics)


def missing_table_diagnostic(check: CheckDef) -> Diagnostic:
    """Diagnostic for a schema check whose target table does not exist."""
    return (
        DiagnosticBuilder.error(
            DiagnosticId.VALIDATE_COLUMN_REMOVED,
            "schema check target table is missing from the live database",
        )
        .span(check.source.path, check.source_range)
        .build()
    )


def finding_diagnostic(check: CheckDef, finding: ValidationFinding) -> Diagnostic:
    """Build an ERROR Diagnostic for a blocking ValidationFinding."""
    builder = DiagnosticBuilder.error(
        finding.validation_type.diagnostic_id, finding_message(finding)
    ).span(check.source.path, check.source_range)
    if (note := finding_note(finding)) is not None:
        builder = builder.note(note)
    return builder.build()


def informational_finding_diagnostic(check: CheckDef, finding: ValidationFinding) -> Diagnostic:
    """Build an INFO Diagnostic for non-blocking schema drift.

    PK / nullable / unique / extra-in-DB drift surfaces here so the user sees
    every difference between the contract and the live database without the
    schema check failing the run.
    """
    builder = DiagnosticBuilder.info(
        finding.validation_type.diagnostic_id, finding_message(finding)
    ).span(check.source.path, check.source_range)
    if (note := finding_note(finding)) is not None:
        builder = builder.note(note)
    return builder.build()


_FINDING_HEADLINE_BY_TYPE: dict[ValidationType, str] = {
    ValidationType.MISSING_IN_DB: "column '{col}' is in the contract but missing from the database",
    ValidationType.EXTRA_IN_DB: "column '{col}' is in the database but not declared in the contract",
    ValidationType.TYPE_MISMATCH: "column '{col}' type mismatch: contract={contract}, database={db}",
    ValidationType.NULLABLE_MISMATCH: (
        "column '{col}' nullability mismatch: contract={contract}, database={db}"
    ),
    ValidationType.PK_MISMATCH: (
        "column '{col}' primary-key mismatch: contract={contract}, database={db} "
        "(non-blocking — contract PK is treated as a logical uniqueness assertion)"
    ),
    ValidationType.UNIQUE_MISMATCH: (
        "column '{col}' uniqueness mismatch: contract={contract}, database={db}"
    ),
}


def finding_message(finding: ValidationFinding) -> str:
    """Short headline describing one schema drift finding."""
    template = _FINDING_HEADLINE_BY_TYPE.get(finding.validation_type)
    if template is None:
        return f"column '{finding.column}': {finding.validation_type.label}"
    return template.format(col=finding.column, contract=finding.contract_value, db=finding.db_value)


def finding_note(finding: ValidationFinding) -> str | None:
    """Secondary human-readable note; ``None`` when the headline says enough."""
    if finding.contract_value is None or finding.db_value is None:
        return None
    return f"expected {finding.contract_value}, actual {finding.db_value}"
