"""Read-side query services for quality data."""

from datetime import datetime

from turbine.core.quality import CheckCounters, CheckResultRepository


class GetCheckCountersQuery:
    """Aggregate outcome counts from the check-result history."""

    def __init__(self, repository: CheckResultRepository) -> None:
        """Bind the query to a CheckResultRepository implementation."""
        self.repository = repository

    def execute(self, since: datetime | None, until: datetime | None) -> CheckCounters:
        """Return the counters for the (since, until] window."""
        return self.repository.counters(since=since, until=until)
