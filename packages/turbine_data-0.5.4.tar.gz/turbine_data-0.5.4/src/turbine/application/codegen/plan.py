"""Pretty-printer for :class:`CodegenPlan` — backs ``--dry-run``.

Renders a plan as a deterministic Unicode tree showing the run label,
output root, every step's output directory + sweep flag, and each
renderer by class name. No side effects, no filesystem access.
"""

from turbine.core.codegen import CodegenPlan, CodegenStep, ContentRenderer


def plan_to_str(plan: CodegenPlan, *, label: str) -> str:
    """Render *plan* as a human-readable Unicode tree.

    The format is stable and suitable for regression snapshots:
    header, one ``Step N`` per :class:`CodegenStep`, and one leaf
    line per renderer.
    """
    lines = [f"Plan {label}  output={plan.output_root}"]
    step_count = len(plan.steps)
    for index, step in enumerate(plan.steps):
        last_step = index == step_count - 1
        lines.extend(render_step(step, index=index, last=last_step))
    return "\n".join(lines) + "\n"


def render_step(step: CodegenStep, *, index: int, last: bool) -> list[str]:
    """Emit the step header line plus one leaf line per renderer."""
    step_branch = "└──" if last else "├──"
    sweep_label = "sweep" if step.sweep else "no-sweep"
    header = f"{step_branch} Step {index + 1}  {step.output_dir}  ({sweep_label})"
    renderer_prefix = "    " if last else "│   "
    renderer_count = len(step.renderers)
    renderer_lines = [
        render_renderer(renderer, prefix=renderer_prefix, last=(renderer_index == renderer_count - 1))
        for renderer_index, renderer in enumerate(step.renderers)
    ]
    return [header, *renderer_lines]


def render_renderer(renderer: ContentRenderer, *, prefix: str, last: bool) -> str:
    """Render a single renderer leaf under its parent step."""
    leaf = "└──" if last else "├──"
    return f"{prefix}{leaf} {type(renderer).__name__}"
