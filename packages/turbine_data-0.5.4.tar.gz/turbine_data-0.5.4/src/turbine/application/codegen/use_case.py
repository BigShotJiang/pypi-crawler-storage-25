"""CodegenUseCase: orchestrate stage → batch-format → flush → sweep.

Drives a :class:`CodegenPlan` through the :class:`StagedCodeWriter` /
:class:`BatchFormatter` / :class:`OrphanSweeper` ports. No disk I/O
here; adapters do that.

Duplicate filenames within a step are hard errors by default: the sink
receives a :attr:`DiagnosticId.CODEGEN_DUPLICATE_FILENAME` error and
the whole run aborts without flushing (nothing half-written). Pass
``allow_collisions=True`` to downgrade each collision to a warning and
keep the last-writer-wins semantics.
"""

from collections.abc import Sequence
from pathlib import Path

from turbine.core.building_blocks import (
    DiagnosticBuilder,
    DiagnosticId,
    DiagnosticSink,
    NullDiagnosticSink,
)
from turbine.core.codegen import (
    BatchFormatter,
    CodegenPlan,
    CodegenReport,
    CodegenStep,
    OrphanSweeper,
    StagedCodeWriter,
)
from turbine.core.common import SyncResult


class CodegenUseCase:
    """Orchestrate a codegen run through its injected ports."""

    def __init__(
        self, writer: StagedCodeWriter, formatter: BatchFormatter, sweeper: OrphanSweeper
    ) -> None:
        self.writer = writer
        self.formatter = formatter
        self.sweeper = sweeper

    def execute(
        self,
        plan: CodegenPlan,
        items: Sequence[object],
        sink: DiagnosticSink = NullDiagnosticSink(),
        *,
        allow_collisions: bool = False,
    ) -> CodegenReport:
        """Run *plan* over *items* and return its :class:`CodegenReport`.

        Directory creation happens at flush time (inside the writer), so
        an aborted validation pass leaves no filesystem residue. On
        collision:

        - default-strict: record an error on *sink* and abort before flush.
        - ``allow_collisions=True``: record a warning, keep the last
          writer staged, and proceed.

        The plan's ``slow_count_at_risk`` advisory flows through
        unchanged so callers can format banners off the returned report.
        """
        for step in plan.steps:
            collided = self.stage_step(step, items, sink, allow_collisions=allow_collisions)
            if collided and not allow_collisions:
                return self.report_from(plan, ())
        pending = self.writer.pending()
        formatted = self.formatter.format_all(pending)
        results = self.writer.flush(formatted)
        self.sweep_orphans(plan, results)
        return self.report_from(plan, tuple(results))

    def report_from(self, plan: CodegenPlan, sync_results: tuple[SyncResult, ...]) -> CodegenReport:
        """Build the report mirroring the plan's advisories."""
        return CodegenReport(sync_results=sync_results, slow_count_at_risk=plan.slow_count_at_risk)

    def stage_step(
        self, step: CodegenStep, items: Sequence[object], sink: DiagnosticSink, *, allow_collisions: bool
    ) -> bool:
        """Stage every :class:`StagedFile` yielded by the step's renderers.

        Returns ``True`` if any collision was detected.
        """
        identifiers: dict[Path, str] = {}
        collided = False
        for renderer in step.renderers:
            for staged in renderer.render(items, step.output_dir):
                if staged.path in identifiers:
                    collided = True
                    self.report_collision(
                        sink,
                        path=staged.path,
                        first_id=identifiers[staged.path],
                        second_id=staged.identifier,
                        allow_collisions=allow_collisions,
                    )
                identifiers[staged.path] = staged.identifier
                self.writer.stage(staged.path, staged.content)
        return collided

    def report_collision(
        self, sink: DiagnosticSink, *, path: Path, first_id: str, second_id: str, allow_collisions: bool
    ) -> None:
        """Emit either a warning or an error for a same-filename collision."""
        message = (
            f"duplicate output filename '{path.name}' — "
            f"'{first_id}' and '{second_id}' both target '{path.name}'"
        )
        builder = DiagnosticBuilder.warning if allow_collisions else DiagnosticBuilder.error
        help_text = (
            "rename one of the contracts, place them under distinct output dirs, "
            "or pass --allow-collisions"
        )
        sink.add(builder(DiagnosticId.CODEGEN_DUPLICATE_FILENAME, message).help(help_text).build())

    def sweep_orphans(self, plan: CodegenPlan, results: list[SyncResult]) -> None:
        """Prune stale files and empty directories under the codegen output root.

        Per-step pruning runs first so each ``sweep=True`` directory ends
        up with only files that the current run produced. A second pass
        walks the whole tree to remove any directory left empty —
        typically the leftover `models/`, `routers/`, or
        `v{major}/{domain}/` subtrees of contracts that were RETIRED,
        deleted, or skipped this run.
        """
        for step in plan.steps:
            if not step.sweep:
                continue
            kept = frozenset(
                result.path.name for result in results if result.path.parent == step.output_dir
            )
            self.sweeper.prune(step.output_dir, kept)
        self.sweeper.prune_empty_subdirs(plan.output_root)
