"""Canonical Project Initialization for ``turbine init``.

The CLI flow that brings Turbine into an *existing* Python repository. Always
uses the ``src/<project_name>/`` layout: contracts, datasources, checks and
quality directories land alongside the user's Python package, and a
``[tool.turbine].root`` entry in ``pyproject.toml`` points at that subdir.

File-content emission is delegated to :class:`ProjectScaffoldService`
(variant=BARE). This module owns the surrounding work the scaffold service
does *not*: validating the host pyproject, writing the turbine-root setting,
creating the four empty directories, the ``.env.example`` for the chosen
database, and the ``.gitignore`` entry. The demo onboarding-tour path
(variant=DEMO) bypasses this module entirely.
"""

from __future__ import annotations

import re
import tomllib
from collections.abc import Callable
from dataclasses import dataclass
from pathlib import Path
from typing import cast

import tomli_w

from turbine.application.analysis.project_setup import ProjectScaffoldService
from turbine.core.analysis.protocol import ScaffoldVariant
from turbine.core.building_blocks import DiagnosticBuilder, DiagnosticId
from turbine.core.common import DataSourceType, SyncResult, SyncStatus
from turbine.core.common.connection_props import CONNECTION_PROPS_BY_TYPE, env_vars
from turbine.core.onboarding.phase import DatabaseChoiceId

ScaffoldFactory = Callable[[Path], ProjectScaffoldService]

PyprojectData = dict[str, object]

MINIMAL_DIRS: tuple[str, ...] = ("contracts", "datasources", "checks", "quality")
GITIGNORE_ENTRIES: tuple[str, ...] = (".turbine/",)

DATASOURCE_TYPE_FOR_DATABASE: dict[DatabaseChoiceId, DataSourceType | None] = {
    DatabaseChoiceId.POSTGRES: DataSourceType.POSTGRES,
    DatabaseChoiceId.SNOWFLAKE: DataSourceType.SNOWFLAKE,
    DatabaseChoiceId.DUCKDB: DataSourceType.DUCKDB,
    DatabaseChoiceId.LSP_ONLY: None,
}


@dataclass(frozen=True, slots=True)
class ProjectInitializationRequest:
    """Inputs for initializing a Turbine project."""

    repo_root: Path
    database: DatabaseChoiceId
    interactive: bool = False


@dataclass(frozen=True, slots=True)
class ProjectInitializationPlan:
    """Resolved project initialization plan."""

    repo_root: Path
    project_name: str
    turbine_root: Path
    turbine_root_setting: str
    database: DatabaseChoiceId


@dataclass(frozen=True, slots=True)
class ProjectInitializationResult:
    """Observable result of Project Initialization."""

    plan: ProjectInitializationPlan
    sync_results: tuple[SyncResult, ...]
    message: str


class ProjectInitializer:
    """Initialize the canonical Turbine project structure under ``src/<name>/``.

    The composition root (CLI) injects ``scaffold_factory`` so this module
    stays inside the application layer (no infra imports). The factory
    receives the resolved ``turbine_root`` and returns a layout-bound
    :class:`ProjectScaffoldService` whose ``scaffold(variant=BARE, ...)`` is
    invoked to write the starter contract and datasource.
    """

    def __init__(self, scaffold_factory: ScaffoldFactory) -> None:
        self.scaffold_factory = scaffold_factory

    def initialize(self, request: ProjectInitializationRequest) -> ProjectInitializationResult:
        """Validate, scaffold, and configure a Turbine project for *request*."""
        validate_pyproject_precondition(request.repo_root)
        plan = build_initialization_plan(request)
        results: list[SyncResult] = []
        results.append(write_turbine_root(plan.repo_root, plan.turbine_root_setting))
        results.extend(create_minimal_directories(plan.turbine_root))
        results.extend(scaffold_starter_files(plan, self.scaffold_factory))
        env_result = write_env_example(plan)
        if env_result is not None:
            results.append(env_result)
        results.append(ensure_gitignore(plan.repo_root))
        return ProjectInitializationResult(
            plan=plan,
            sync_results=tuple(results),
            message=f"Project '{plan.project_name}' initialized at {plan.turbine_root_setting}",
        )


def validate_pyproject_precondition(repo_root: Path) -> None:
    """Refuse to initialize when no Python project exists at ``repo_root``.

    Turbine's first-run flow assumes the host Python project already exists:
    ``pyproject.toml`` must be present and contain a ``[project]`` section with
    a ``name`` field (PEP 621). See ADR 0011.
    """
    pyproject_path = repo_root / "pyproject.toml"
    if not pyproject_path.is_file():
        raise (
            DiagnosticBuilder.error(DiagnosticId.IO, "no pyproject.toml found in this directory")
            .help("Run `uv init --python 3.13` to create a Python project, then re-run `turbine init`.")
            .into_error()
        )
    data = read_pyproject_data(pyproject_path)
    if read_project_name(data) is None:
        raise (
            DiagnosticBuilder.error(
                DiagnosticId.IO, "pyproject.toml has no [project] section with a name"
            )
            .help("Run `uv init --python 3.13` to add a [project] section, then re-run `turbine init`.")
            .into_error()
        )


def build_initialization_plan(request: ProjectInitializationRequest) -> ProjectInitializationPlan:
    """Resolve project name, src path, and database for initialization."""
    project_name = derive_project_name(request.repo_root)
    turbine_root_setting = f"src/{project_name}"
    turbine_root = request.repo_root / "src" / project_name
    return ProjectInitializationPlan(
        repo_root=request.repo_root,
        project_name=project_name,
        turbine_root=turbine_root,
        turbine_root_setting=turbine_root_setting,
        database=request.database,
    )


def derive_project_name(repo_root: Path) -> str:
    """Derive a Python-safe project folder name from ``[project].name``."""
    data = read_pyproject_data(repo_root / "pyproject.toml")
    name = read_project_name(data)
    if name is None:
        raise RuntimeError("validate_pyproject_precondition must run before derive_project_name")
    return normalize_project_name(name)


def normalize_project_name(raw_name: str) -> str:
    """Normalize arbitrary project names to Python-safe folder names."""
    normalized = re.sub(r"\W+", "_", raw_name.strip().lower()).strip("_")
    if not normalized:
        return "turbine_project"
    if normalized[0].isdigit():
        return f"project_{normalized}"
    return normalized


def read_pyproject_data(pyproject_path: Path) -> PyprojectData:
    """Read pyproject TOML into a mutable dictionary."""
    with pyproject_path.open("rb") as pyproject_file:
        return cast(PyprojectData, tomllib.load(pyproject_file))


def read_project_name(data: PyprojectData) -> str | None:
    """Read ``[project].name`` from parsed TOML data."""
    project = data.get("project")
    if not isinstance(project, dict):
        return None
    project_data = cast(PyprojectData, project)
    name = project_data.get("name")
    return name if isinstance(name, str) else None


def write_turbine_root(repo_root: Path, turbine_root_setting: str) -> SyncResult:
    """Write explicit ``[tool.turbine].root`` to an existing pyproject.toml."""
    pyproject_path = repo_root / "pyproject.toml"
    data = read_pyproject_data(pyproject_path)
    tool = ensure_section(data, "tool")
    turbine = ensure_section(tool, "turbine")
    if turbine.get("root") == turbine_root_setting:
        return SyncResult(path=pyproject_path, status=SyncStatus.UNCHANGED)
    turbine["root"] = turbine_root_setting
    pyproject_path.write_text(tomli_w.dumps(data))
    return SyncResult(path=pyproject_path, status=SyncStatus.UPDATED)


def ensure_section(data: PyprojectData, key: str) -> PyprojectData:
    """Return a mutable TOML section, replacing non-table values when needed."""
    current = data.get(key)
    if isinstance(current, dict):
        return cast(PyprojectData, current)
    section: PyprojectData = {}
    data[key] = section
    return section


def create_minimal_directories(turbine_root: Path) -> list[SyncResult]:
    """Create minimal Turbine directories if missing."""
    results: list[SyncResult] = []
    for dirname in MINIMAL_DIRS:
        path = turbine_root / dirname
        existed = path.exists()
        path.mkdir(parents=True, exist_ok=True)
        status = SyncStatus.UNCHANGED if existed else SyncStatus.CREATED
        results.append(SyncResult(path=path, status=status))
    return results


def scaffold_starter_files(
    plan: ProjectInitializationPlan, scaffold_factory: ScaffoldFactory
) -> list[SyncResult]:
    """Delegate starter contract + datasource emission to ProjectScaffoldService."""
    service = scaffold_factory(plan.turbine_root)
    contract_path = plan.turbine_root / "contracts" / "example-contract.yml"
    datasource_path = plan.turbine_root / "datasources" / "default.yml"
    contract_existed = contract_path.exists()
    datasource_existed = datasource_path.exists()
    service.scaffold(variant=ScaffoldVariant.BARE, database=plan.database)
    return [
        sync_result_for(contract_path, existed_before=contract_existed),
        sync_result_for(datasource_path, existed_before=datasource_existed),
    ]


def sync_result_for(path: Path, *, existed_before: bool) -> SyncResult:
    """Map a scaffolded path's pre/post existence to a SyncResult status."""
    if not existed_before:
        return SyncResult(path=path, status=SyncStatus.CREATED)
    return SyncResult(path=path, status=SyncStatus.SKIPPED)


def write_env_example(plan: ProjectInitializationPlan) -> SyncResult | None:
    """Write `.env.example` with the chosen database's env-var keys.

    Returns ``None`` when the database choice has no env vars (``LSP_ONLY``).
    Skips overwriting if the file already exists with the expected content.
    """
    datasource_type = DATASOURCE_TYPE_FOR_DATABASE[plan.database]
    if datasource_type is None:
        return None
    variables = env_vars(CONNECTION_PROPS_BY_TYPE[datasource_type])
    if not variables:
        return None
    content = "".join(f"{variable}=\n" for variable in variables)
    path = plan.repo_root / ".env.example"
    if path.exists():
        status = SyncStatus.UNCHANGED if path.read_text() == content else SyncStatus.SKIPPED
        return SyncResult(path=path, status=status)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)
    return SyncResult(path=path, status=SyncStatus.CREATED)


def ensure_gitignore(repo_root: Path) -> SyncResult:
    """Ensure local Turbine state is ignored while preserving existing content."""
    path = repo_root / ".gitignore"
    existing_lines = path.read_text().splitlines() if path.exists() else []
    missing = [entry for entry in GITIGNORE_ENTRIES if entry not in existing_lines]
    if not missing:
        return SyncResult(path=path, status=SyncStatus.UNCHANGED)
    path.write_text("\n".join([*existing_lines, *missing]) + "\n")
    return SyncResult(path=path, status=SyncStatus.UPDATED if existing_lines else SyncStatus.CREATED)
