---
status: accepted
---

# SLA properties adhere to the Data QoS framework

## Context

ODCS defines an open-ended `slaProperties` array — `property` is a free string,
and the spec only says "check the periodic table" without enumerating it. Left
unconstrained, every contract author would invent their own vocabulary
(`endOfBusinessDay`, `dataAvailableBy`, `cutoff`, ...) and turbine would silently
accept all of them, none of them carrying enforceable semantics across teams.

Jean-Georges Perrin — the original author of ODCS — published the
[Data QoS framework](https://medium.com/profitoptics/what-is-data-qos-and-why-is-it-critical-c524b81e3cc1)
that organises data trustworthiness into two halves, modelled after Mendeleev's
periodic table: **data quality dimensions** (Accuracy, Completeness, Conformity,
Consistency, Coverage, Timeliness, Uniqueness — per the EDM Council) and
**service-level indicators** (Availability, Throughput, Error rate, General
availability, End of support, End of life, Retention, Frequency, Latency, Time
to detect, Time to notify, Time to repair). ODCS `slaProperties` is the
serialisation surface for the service-level half.

## Decision

Turbine's `slaProperties` vocabulary is the Data QoS service-level periodic
table — not a turbine-invented set, not the ad-hoc union of what every importer
happens to write. The closed enum in `adapters/odcs/schema_extensions.json`
contains only Data QoS terms; any property name outside the table is rejected
at parse time with an LSP diagnostic that suggests the closest valid term.

Specifically, we recognise these properties in v1:

| Property              | Data QoS abbreviation                        | Group       |
| --------------------- | -------------------------------------------- | ----------- |
| `freshness`           | Tm (Timeliness, expressed via service level) | Behaviour   |
| `latency`             | Ly                                           | Behaviour   |
| `retention`           | Re                                           | Behaviour   |
| `frequency`           | Fy                                           | Behaviour   |
| `timeOfAvailability`  | (sub-indicator of Fy)                        | Behaviour   |
| `availability`        | Av                                           | Performance |
| `generalAvailability` | Ga                                           | Lifecycle   |
| `endOfSupport`        | Es                                           | Lifecycle   |
| `endOfLife`           | El                                           | Lifecycle   |

The pre-existing turbine-specific `endOfBusinessDay` is **retired** —
replaced by Data QoS's `timeOfAvailability` (a strict generalisation: a daily
cutoff is one value of "time of availability"). `endOfBusinessDay` does not
appear in Data QoS, ODCS reference examples, or datacontract-cli; keeping it
would be non-portable for no semantic gain.

Properties from the Data QoS *time group* (Time to detect, Time to notify, Time
to repair) and the *performance group* (Throughput, Error rate) are out of
scope for v1 — they describe operational response, not the data itself, and
turbine has no probe history to compute them against. Adding them later
extends the enum without renaming anything already shipped.

## Why this matters

1. **Definitions we can agree on.** ITIL's first principle: a shared vocabulary
   precedes shared work. Data QoS gives us terminology authors, dashboards,
   importers (Soda, datacontract-cli, ODCS round-trips), and the LSP all
   converge on.
2. **Compatibility.** Perrin explicitly cites the latency-vs-freshness
   confusion as the reason for separating the two terms ("latency and
   freshness are often interchanged; let's go for latency"). Picking
   either name without picking the framework risks reintroducing the
   ambiguity.
3. **Closed enum, fuzzy-match suggestions.** The LSP can offer
   "did you mean `endOfLife`?" when an author types `endOfLive` —
   only possible against a finite vocabulary.

## Consequences

- The schema extension's `property` enum is the source of truth and must stay
  in sync with this ADR. Adding a Data QoS property to the enum requires
  updating this ADR's table.
- Each property gets per-property required-field rules
  (behavior properties need `element`+`unit`; lifecycle properties don't),
  enforced via JSON Schema `if/then` in the extension overlay.
- Migrating off `endOfBusinessDay` is a breaking change for any existing
  contract that uses it. Migration: replace
  `property: endOfBusinessDay, value: 17, unit: hour`
  with
  `property: timeOfAvailability, value: "17:00", element: <time-col>`.
- This ADR does not constrain the *data quality dimensions* half of Data QoS —
  those live in `quality:` blocks (Accuracy, Completeness, ...), not in
  `slaProperties`. The two halves stay separated in code: SLA properties are
  parsed by `adapters/odcs/reader.py`'s SLA path, quality dimensions by its
  quality path.

## References

- Jean-Georges Perrin, *What is Data QoS, and why is it critical?* (2023).
  <https://medium.com/profitoptics/what-is-data-qos-and-why-is-it-critical-c524b81e3cc1>
- EDM Council, *Data Quality Dimensions glossary.*
  <https://www.edmcportal.org/glossary/data-quality-dimensions/>
- ODCS v3 reference example: `slaProperties` block in
  `tests/fixtures/odcs_v3/full-example.odcs.yaml` (datacontract-cli).
