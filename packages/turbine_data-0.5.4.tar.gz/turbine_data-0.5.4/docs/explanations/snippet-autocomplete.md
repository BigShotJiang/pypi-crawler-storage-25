# Snippet autocomplete flow

Snippet autocomplete lives across LSP request handlers, application services, schema classifiers, snippet builders, and editor write adapters.

## 30,000ft view

```text
┌─────────────────────────────────────────────────────────────────────────────┐
│ Editor action                                                               │
│                                                                             │
│  textDocument/completion                                                    │
│        │                                                                    │
│        ▼                                                                    │
│  Completion.run_with_snapshot()                                             │
│  src/turbine/presentation/lsp/api/requests/completion.py:85                 │
│        │                                                                    │
│        ▼                                                                    │
│  CompletionService.complete()                                               │
│  src/turbine/application/analysis/completion/service.py:84                  │
│        │                                                                    │
│        ├─ empty file scaffold snippets                                      │
│        │  src/turbine/core/analysis/features/completion.py:232              │
│        │                                                                    │
│        ├─ SQL and Jinja completions                                         │
│        │  src/turbine/application/analysis/completion/service.py:108        │
│        │                                                                    │
│        └─ YAML role x target lattice                                        │
│           src/turbine/application/analysis/completion/dispatch.py:49        │
│                                                                             │
│  textDocument/codeLens -> workspace/executeCommand turbine/addCheck          │
│        │                                                                    │
│        ▼                                                                    │
│  CommandHandler.add_check()                                                 │
│  src/turbine/application/analysis/command.py:403                            │
│        │                                                                    │
│        ▼                                                                    │
│  AddCheckUseCase.execute()                                                  │
│  src/turbine/application/analysis/add_check.py:38                           │
│        │                                                                    │
│        ▼                                                                    │
│  build_check_snippet() -> CodeWriter.insert_snippet()                       │
│  src/turbine/core/analysis/check_snippet.py:242                             │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Layers

```text
Presentation LSP
  completion/codeLens/executeCommand handlers
  src/turbine/presentation/lsp/api/requests/completion.py:74
  src/turbine/presentation/lsp/api/requests/code_lens.py:14
  src/turbine/presentation/lsp/api/requests/execute_command.py:16
        │
        ▼
Application services
  CompletionService, CodeLensService, CommandHandler, AddCheckUseCase
  src/turbine/application/analysis/completion/service.py:60
  src/turbine/application/analysis/code_lens.py:66
  src/turbine/application/analysis/command.py:403
  src/turbine/application/analysis/add_check.py:27
        │
        ▼
Core feature logic
  CompletionItemInfo, CompletionTarget, snippet_builder, check_snippet
  src/turbine/core/analysis/features/completion.py:64
  src/turbine/core/analysis/features/completion_targets.py:120
  src/turbine/core/analysis/features/snippet_builder.py:93
  src/turbine/core/analysis/check_snippet.py:242
        │
        ▼
Ports and adapters
  SchemaResolver, CodeWriter, LspCodeWriter, FileCodeWriter
  src/turbine/core/analysis/ports.py:22
  src/turbine/core/analysis/ports.py:45
  src/turbine/presentation/lsp/code_writer.py:61
  src/turbine/adapters/analysis/file_code_writer.py:72
```

## Key abstractions

| Layer       | Abstraction                                                                         | Role                                                                                                                                    |
| ----------- | ----------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------- |
| Core        | `CompletionItemInfo` (`src/turbine/core/analysis/features/completion.py:64`)        | Carries label, docs, insert text, sort key, and `is_snippet` for one suggestion.                                                        |
| Core        | `CompletionQuery` (`src/turbine/core/analysis/features/completion.py:100`)          | Carries URI, full text, and 1-indexed cursor position into completion logic.                                                            |
| Core        | `CompletionTarget` (`src/turbine/core/analysis/features/completion_targets.py:120`) | Sealed union naming schema targets such as object, scalar, column ref, DB table, or SQL check ref.                                      |
| Application | `CompletionContext` (`src/turbine/application/analysis/completion/context.py:20`)   | Bundles parsed data, path, source map, schema resolver, index, introspection cache, domain registry, and checks dir for completer arms. |
| Core        | `SnippetContext` (`src/turbine/core/analysis/features/snippet_builder.py:80`)       | Carries schema navigation, prefill lookup, and tabstop counter through recursive object snippet generation.                             |
| Core        | `AddCheckRequest` (`src/turbine/core/analysis/add_check_request.py:11`)             | Captures file kind, check type, dimension, scope, column, schema name, and optional check name.                                         |
| Core        | `CheckSnippet` (`src/turbine/core/analysis/check_snippet.py:80`)                    | Returns YAML text plus the target section for Add Check insertion.                                                                      |

## Completion request flow

```text
Editor sends textDocument/completion
          │
          ▼
Completion.run_with_snapshot() builds CompletionQuery
src/turbine/presentation/lsp/api/requests/completion.py:85
          │
          ▼
CompletionService.complete() routes by content and URI
src/turbine/application/analysis/completion/service.py:84
          │
          ├────────────────────────────────────────────────────────────┐
          │                                                            │
          ▼                                                            ▼
Empty content                                                  YAML file
scaffold_completions()                                         complete_yaml()
src/turbine/core/analysis/features/completion.py:232           src/turbine/application/analysis/completion/service.py:129
          │                                                            │
          │                                                            ▼
          │                                                   parse_or_repair()
          │                                                   src/turbine/application/analysis/completion/repair.py:21
          │                                                            │
          │                                                            ▼
          │                                                   detect_role()
          │                                                   src/turbine/core/analysis/features/cursor_role.py:26
          │                                                            │
          │                                                            ▼
          │                                                   path_for_role()
          │                                                   src/turbine/application/analysis/completion/service.py:214
          │                                                            │
          │                                                            ▼
          │                                                   target_at()
          │                                                   src/turbine/application/analysis/completion/schema_target.py:43
          │                                                            │
          │                                                            ▼
          │                                                   dispatch.complete()
          │                                                   src/turbine/application/analysis/completion/dispatch.py:49
          │                                                            │
          │                                                            ▼
          │                                                   object_keys.complete(), refs, db, scalar, array arms
          │                                                   src/turbine/application/analysis/completion/completers/object_keys.py:27
          │
          ▼
completion_item_to_lsp() sets InsertTextFormat.Snippet when needed
src/turbine/presentation/lsp/api/requests/completion.py:50
```

For object-key completions, `object_keys.complete()` filters out sibling keys already present in the source map, then asks `snippet_for_child()` to build a guided snippet when the raw child schema can expand into required subfields (`src/turbine/application/analysis/completion/completers/object_keys.py:27`, `src/turbine/application/analysis/completion/completers/object_keys.py:45`). If the child is a plain scalar, it falls back to `scalar_key_snippet()` (`src/turbine/core/analysis/features/snippet_builder.py:314`).

`build_snippet()` resolves `$ref`, rejects discriminated unions, emits choice tabstops for closed enums, and expands required object or array fields (`src/turbine/core/analysis/features/snippet_builder.py:93`). `build_value()` picks enum choices, nested object blocks, array object blocks, or scalar placeholders (`src/turbine/core/analysis/features/snippet_builder.py:161`). Scalar placeholder text comes from live prefill, examples, JSON-schema type, or `value` (`src/turbine/core/analysis/features/snippet_builder.py:222`).

The LSP boundary preserves snippet syntax by setting `InsertTextFormat.Snippet` when `CompletionItemInfo.is_snippet` is true or the kind is `SNIPPET` (`src/turbine/presentation/lsp/api/requests/completion.py:50`, `src/turbine/presentation/lsp/api/requests/completion.py:67`).

## Add Check flow

```text
Editor asks for code lenses
          │
          ▼
CodeLens.run_with_snapshot()
src/turbine/presentation/lsp/api/requests/code_lens.py:25
          │
          ▼
CodeLensService.code_lenses()
src/turbine/application/analysis/code_lens.py:78
          │
          ├─ DataContract Add dataset and Add column lenses
          │  src/turbine/application/analysis/code_lens.py:119
          │
          └─ QualitySpec Add dataset and Add column lenses
             src/turbine/application/analysis/code_lens.py:206
          │
          ▼
User clicks turbine/addCheck, ExecuteCommand.run_with_snapshot()
src/turbine/presentation/lsp/api/requests/execute_command.py:22
          │
          ▼
CommandHandler.add_check()
src/turbine/application/analysis/command.py:403
          │
          ├─ read open editor buffer
          │  src/turbine/application/analysis/command.py:425
          │
          ├─ maybe resolve a column from target contract
          │  src/turbine/application/analysis/command.py:432
          │
          └─ pick check and build AddCheckRequest
             src/turbine/application/analysis/command.py:441
          │
          ▼
AddCheckUseCase.execute()
src/turbine/application/analysis/add_check.py:38
          │
          ▼
build_check_snippet()
src/turbine/core/analysis/check_snippet.py:242
          │
          ├─ QualitySpec shape
          │  src/turbine/core/analysis/check_snippet.py:264
          │
          └─ DataContract custom implementation shape
             src/turbine/core/analysis/check_snippet.py:282
          │
          ▼
Insert at property quality, schema quality, column checks, or top-level quality
src/turbine/application/analysis/add_check.py:96
src/turbine/application/analysis/add_check.py:245
src/turbine/application/analysis/add_check.py:292
src/turbine/application/analysis/add_check.py:410
          │
          ▼
Convert diff to SnippetInsertion and call CodeWriter.insert_snippet()
src/turbine/application/analysis/add_check.py:77
src/turbine/core/analysis/ports.py:45
```

`build_check_snippet()` chooses DataContract or QualitySpec output from `request.file_kind` (`src/turbine/core/analysis/check_snippet.py:242`). `prepare_body()` resolves the selected check type against `quality_spec.schema.json`, reads required fields, appends `column` when the catalog says the check needs one, and reads `x-defaultThreshold` (`src/turbine/core/analysis/check_snippet.py:179`). The schema supplies defaults such as `mustBe: 0` for missing checks and empty thresholds for aggregate or anomaly checks that need user choice (`src/turbine/core/analysis/schemas/quality_spec.schema.json:90`, `src/turbine/core/analysis/schemas/quality_spec.schema.json:241`, `src/turbine/core/analysis/schemas/quality_spec.schema.json:349`).

Prompt text follows one rule: `property_prompt()` uses `x-turbine-snippet-prompt` first, then the field's JSON Schema `description`, then the field name (`src/turbine/core/analysis/check_snippet.py:390`, `src/turbine/core/analysis/check_snippet.py:398`). The schema uses overrides for fields where a shorter prompt beats the full description, such as `validValues`, `predicate`, and `query` (`src/turbine/core/analysis/schemas/quality_spec.schema.json:148`, `src/turbine/core/analysis/schemas/quality_spec.schema.json:292`, `src/turbine/core/analysis/schemas/quality_spec.schema.json:293`). `SnippetTabstopCounter.placeholder()` wraps that text as `${N:...}` and escapes snippet metacharacters (`src/turbine/core/analysis/check_snippet.py:88`, `src/turbine/core/analysis/check_snippet.py:100`).

## Routing table

| Input                   | Classifier                                                                                     | Destination                                                                                             |
| ----------------------- | ---------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| Empty file completion   | `CompletionService.complete()` (`src/turbine/application/analysis/completion/service.py:84`)   | `scaffold_completions()` (`src/turbine/core/analysis/features/completion.py:232`)                       |
| SQL file completion     | `CompletionService.complete()` (`src/turbine/application/analysis/completion/service.py:84`)   | `complete_sql()` (`src/turbine/application/analysis/completion/service.py:108`)                         |
| YAML key in object      | `dispatch.complete()` (`src/turbine/application/analysis/completion/dispatch.py:49`)           | `object_keys.complete()` (`src/turbine/application/analysis/completion/completers/object_keys.py:27`)   |
| YAML scalar value       | `dispatch.complete()` (`src/turbine/application/analysis/completion/dispatch.py:49`)           | `scalar_value.complete()` (`src/turbine/application/analysis/completion/completers/scalar_value.py:15`) |
| Column reference value  | `target_at()` (`src/turbine/application/analysis/completion/schema_target.py:43`)              | `refs.complete_column()` (`src/turbine/application/analysis/completion/completers/refs.py:39`)          |
| DB table value          | `target_at()` (`src/turbine/application/analysis/completion/schema_target.py:43`)              | `db.complete_table()` (`src/turbine/application/analysis/completion/completers/db.py:26`)               |
| Add Check picker result | `CommandHandler.build_add_check_request()` (`src/turbine/application/analysis/command.py:441`) | `AddCheckUseCase.execute()` (`src/turbine/application/analysis/add_check.py:38`)                        |

## Mode variations

| Variation                             | Decision point                                                                                                                                       | Effect                                                                                                                                                                                                                              |
| ------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Editor snippet vs file fallback       | `CodeWriter` port (`src/turbine/core/analysis/ports.py:22`)                                                                                          | `LspCodeWriter` preserves tabstops through `turbine/insertSnippet`; `FileCodeWriter` expands tabstops to default text (`src/turbine/presentation/lsp/code_writer.py:61`, `src/turbine/adapters/analysis/file_code_writer.py:93`).   |
| QualitySpec vs DataContract Add Check | `build_check_snippet()` (`src/turbine/core/analysis/check_snippet.py:242`)                                                                           | QualitySpec uses native `- missing:` shape; DataContract wraps under `type: custom`, `engine: turbine`, and `implementation:` (`src/turbine/core/analysis/check_snippet.py:264`, `src/turbine/core/analysis/check_snippet.py:282`). |
| Dataset vs column scope               | `CheckScope` and `column_required_check_types()` (`src/turbine/core/analysis/check_catalog.py:10`, `src/turbine/core/analysis/check_catalog.py:174`) | Dataset scope may emit `column:` placeholders for column-requiring checks; column scope inherits the column and omits it (`src/turbine/core/analysis/check_snippet.py:322`).                                                        |
| Known DB tables vs no introspection   | `db.complete_table()` (`src/turbine/application/analysis/completion/completers/db.py:26`)                                                            | Known tables become enum completions; missing cache returns the `${1:schema}.${2:table}` snippet (`src/turbine/application/analysis/completion/completers/db.py:15`).                                                               |
| Prompt override vs schema description | `property_prompt()` (`src/turbine/core/analysis/check_snippet.py:390`)                                                                               | `x-turbine-snippet-prompt` wins; otherwise the JSON Schema description becomes placeholder text (`src/turbine/core/analysis/check_snippet.py:398`).                                                                                 |

## Component catalog

| Component                                                                                                                                                                                   | Purpose                                                                                    |
| ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------ |
| `CHECK_CATALOG` (`src/turbine/core/analysis/check_catalog.py:40`)                                                                                                                           | Lists Add Check types, buckets, scopes, threshold support, and column requirement.         |
| Scaffold constants (`src/turbine/core/analysis/features/completion.py:120`, `src/turbine/core/analysis/features/completion.py:133`, `src/turbine/core/analysis/features/completion.py:141`) | Provide full-file snippets for new contracts, quality specs, and datasources.              |
| `FormatRegistry.resolve_children()` (`src/turbine/application/format_registry.py:108`)                                                                                                      | Projects parsed YAML plus schema into valid child fields at a dotted path.                 |
| `FormatRegistry.turbine_ref_at()` (`src/turbine/application/format_registry.py:134`)                                                                                                        | Reads `x-turbine-ref` extension metadata for column, DB table, and DB column completions.  |
| `quality_spec.schema.json` (`src/turbine/core/analysis/schemas/quality_spec.schema.json:258`)                                                                                               | Defines check bodies, required fields, threshold defaults, and Add Check prompt overrides. |

## DI and ambient context

`create_services()` wires the feature in one composition root (`src/turbine/presentation/lsp/server.py:213`). It creates the format registry and tree-sitter document store, then passes them into `CompletionService` (`src/turbine/presentation/lsp/server.py:247`, `src/turbine/presentation/lsp/server.py:313`). It creates one `LspCodeWriter`, passes it to sidebar resource creation and to `CommandHandler`, and constructs `AddCheckUseCase` with `load_quality_spec_schema()` (`src/turbine/presentation/lsp/server.py:304`, `src/turbine/presentation/lsp/server.py:363`, `src/turbine/adapters/quality/schema_catalog.py:14`).

The feature spans about 40 files and 7,564 lines in this repository slice. The core shape is simple: completion resolves cursor role plus schema target, then returns `CompletionItemInfo`; Add Check resolves a catalog entry plus schema body, then sends one `SnippetInsertion` through the `CodeWriter` port.
