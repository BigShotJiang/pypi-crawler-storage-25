export interface InsertSnippetRequestParams {
  uri: string;
  position: {
    line: number;
    character: number;
  };
  snippetText: string;
}

export interface EditorSnippetInsertion {
  uri: string;
  line: number;
  character: number;
  snippetText: string;
}

export interface ApplyEditResult {
  applied: boolean;
  failureReason?: string;
}

export function toEditorSnippetInsertion(
  params: Readonly<InsertSnippetRequestParams>,
): EditorSnippetInsertion {
  return {
    uri: params.uri,
    line: params.position.line,
    character: params.position.character,
    snippetText: params.snippetText,
  };
}

export function failureResult(error: unknown): ApplyEditResult {
  if (error instanceof Error) {
    return { applied: false, failureReason: error.message };
  }
  return { applied: false, failureReason: "snippet insertion failed" };
}
