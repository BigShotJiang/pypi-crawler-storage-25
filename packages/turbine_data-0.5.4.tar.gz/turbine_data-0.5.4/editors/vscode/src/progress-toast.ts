import * as vscode from "vscode";
import type {
  WorkDoneProgressBegin,
  WorkDoneProgressEnd,
  WorkDoneProgressReport,
} from "vscode-languageserver-protocol";

import type { CancelSubscription } from "./progress-cancel";
import { attachCancelListener } from "./progress-cancel";

const COMPLETION_SUMMARY_TOAST_HOLD_MS = 3000;
const COMPLETION_SUMMARY_PREFIXES = ["✓ Quality run finished", "✘ Cancelled at"] as const;

type ProgressToken = string | number;
type WorkDoneEvent = WorkDoneProgressBegin | WorkDoneProgressReport | WorkDoneProgressEnd;

interface ToastEntry {
  resolve: () => void;
  progress: vscode.Progress<{ message?: string; increment?: number }>;
  /** Cumulative reported percentage; used to compute the next increment. */
  reportedPercent: number;
  /** Subscription that forwards cancellation token fires to the server, or null when no listener is attached. */
  cancelSubscription: CancelSubscription | null;
  /** True when the latest report is a terminal completion summary worth leaving visible briefly. */
  holdOnEnd: boolean;
  /** Pending delayed close timer, if the end event is holding the summary toast open. */
  dismissalTimer: ReturnType<typeof setTimeout> | null;
}

export class ProgressToastManager {
  private readonly entries = new Map<ProgressToken, ToastEntry>();

  /**
   * @param sendCancel
   */
  constructor(
    private readonly sendCancel: (token: ProgressToken) => void,
    private readonly completionSummaryHoldMs: number = COMPLETION_SUMMARY_TOAST_HOLD_MS,
  ) {}

  handle(token: ProgressToken, event: WorkDoneEvent): void {
    if (event.kind === "begin") {
      this.begin(token, event);
      return;
    }
    if (event.kind === "report") {
      this.report(token, event);
      return;
    }
    this.end(token);
  }

  /** Close any open toasts. */
  disposeAll(): void {
    for (const [token, entry] of this.entries) {
      this.close(token, entry);
    }
  }

  private begin(token: ProgressToken, event: WorkDoneProgressBegin): void {
    const prior = this.entries.get(token);
    if (prior !== undefined) {
      this.close(token, prior);
    }

    void vscode.window.withProgress(
      {
        location: vscode.ProgressLocation.Notification,
        title: event.title,
        cancellable: true,
      },
      (progress, cancellationToken) =>
        new Promise<void>((resolve) => {
          const entry: ToastEntry = {
            resolve,
            progress,
            reportedPercent: event.percentage ?? 0,
            cancelSubscription: attachCancelListener(token, cancellationToken, this.sendCancel),
            holdOnEnd: isCompletionSummaryMessage(event.message),
            dismissalTimer: null,
          };
          this.entries.set(token, entry);
          if (event.message !== undefined || event.percentage !== undefined) {
            progress.report({
              message: event.message,
              increment: event.percentage,
            });
          }
        }),
    );
  }

  private report(token: ProgressToken, event: WorkDoneProgressReport): void {
    const entry = this.entries.get(token);
    if (entry === undefined) return;
    if (event.message !== undefined) {
      entry.holdOnEnd = isCompletionSummaryMessage(event.message);
    }
    const increment =
      event.percentage === undefined ? undefined : Math.max(0, event.percentage - entry.reportedPercent);
    if (event.percentage !== undefined) {
      entry.reportedPercent = event.percentage;
    }
    entry.progress.report({
      message: event.message,
      increment,
    });
  }

  private end(token: ProgressToken): void {
    const entry = this.entries.get(token);
    if (entry === undefined) return;
    entry.cancelSubscription?.dispose();
    entry.cancelSubscription = null;
    if (entry.holdOnEnd) {
      entry.dismissalTimer = setTimeout(() => this.close(token, entry), this.completionSummaryHoldMs);
      return;
    }
    this.close(token, entry);
  }

  private close(token: ProgressToken, entry: ToastEntry): void {
    if (this.entries.get(token) !== entry) return;
    if (entry.dismissalTimer !== null) {
      clearTimeout(entry.dismissalTimer);
      entry.dismissalTimer = null;
    }
    entry.cancelSubscription?.dispose();
    entry.resolve();
    this.entries.delete(token);
  }
}

function isCompletionSummaryMessage(message: string | undefined): boolean {
  if (message === undefined) return false;
  return COMPLETION_SUMMARY_PREFIXES.some((prefix) => message.startsWith(prefix));
}
