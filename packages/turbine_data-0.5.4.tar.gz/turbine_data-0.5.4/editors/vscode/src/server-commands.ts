export const SERVER_COMMANDS = [
  "turbine.generateQualitySpec",
  "turbine.testDatasourceConnection",
  "turbine.createDatasource",
  "turbine.createBlankContract",
  "turbine.createContractFromDatasource",
  "turbine.addCheck",
  "turbine.dismissDiagnostic",
] as const;
