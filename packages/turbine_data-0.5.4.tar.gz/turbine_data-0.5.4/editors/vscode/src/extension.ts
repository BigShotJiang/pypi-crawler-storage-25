import * as vscode from "vscode";

import { registerCodeLensCommands } from "./commands/codelens-commands";
import { registerOnboardingCommands } from "./commands/onboarding-commands";
import { registerServerCommandBridge } from "./commands/server-command-bridge";
import { registerSidebarCommands } from "./commands/sidebar-commands";
import { registerExecutionCommands } from "./execution";
import { FolderRegistry } from "./lsp/folder-registry";
import { OnboardingComposition } from "./onboarding/composition";
import { registerQuickContractPicker } from "./quick-pick";
import { registerRunAll } from "./run-all";
import { SidebarResourceCreationShell } from "./sidebar-resource-creation";
import { registerTestController } from "./test-controller";
import { TurbineTreeProvider } from "./tree-bridge";

const OUTPUT = vscode.window.createOutputChannel("Turbine LSP", { log: true });
let registry: FolderRegistry | null = null;

export async function activate(context: vscode.ExtensionContext): Promise<void> {
  OUTPUT.appendLine("Turbine LSP extension activating...");

  registry = new FolderRegistry(OUTPUT);

  const workspaceTree = new TurbineTreeProvider(
    "workspace",
    () => registry?.active()?.client,
    () => null,
    OUTPUT,
  );
  const datasourcesTree = new TurbineTreeProvider(
    "datasources",
    () => registry?.active()?.client,
    () => null,
    OUTPUT,
  );
  const workspaceTreeView = vscode.window.createTreeView("turbine.workspaceContracts", {
    treeDataProvider: workspaceTree,
  });
  const datasourcesTreeView = vscode.window.createTreeView("turbine.datasources", {
    treeDataProvider: datasourcesTree,
  });
  context.subscriptions.push(workspaceTreeView, datasourcesTreeView, workspaceTree, datasourcesTree);

  const trees = { workspace: workspaceTree, datasources: datasourcesTree };

  new SidebarResourceCreationShell({
    getTargets: () => registry?.sidebarCreationTargets() ?? [],
    getWorkspaceFolders: () => vscode.workspace.workspaceFolders ?? [],
    runProjectInitialization: (folder) => runProjectInitialization(folder),
    trees: {
      workspace: { provider: workspaceTree, view: workspaceTreeView },
      datasources: { provider: datasourcesTree, view: datasourcesTreeView },
    },
  }).register(context);

  const onboarding = new OnboardingComposition({
    context,
    registry,
    logger: (message) => OUTPUT.appendLine(message),
  });

  const ALL_CONTRACTS_SURFACE = "all-contracts";
  context.subscriptions.push(
    workspaceTreeView.onDidChangeVisibility((event) => {
      onboarding.notifySurfaceVisibility(ALL_CONTRACTS_SURFACE, event.visible);
    }),
  );
  // Seed initial state once a client comes online so a step that arms
  // against an already-visible sidebar fires on arm.
  registry.onClientStarted(() => {
    onboarding.notifySurfaceVisibility(ALL_CONTRACTS_SURFACE, workspaceTreeView.visible);
  });

  registerSidebarCommands(context, registry, trees, OUTPUT);
  registerCodeLensCommands(context, registry);
  registerOnboardingCommands(context, onboarding);
  registerServerCommandBridge(context, registry);
  registerQuickContractPicker(context, () => registry?.active()?.client, OUTPUT);
  registerRunAll(
    context,
    () => registry?.active()?.client,
    OUTPUT,
    () => workspaceTree.refresh(),
  );
  registerExecutionCommands(
    context,
    (uri) => registry?.clientForUri(uri),
    OUTPUT,
    () => workspaceTree.refresh(),
  );
  registerTestController(context, (uri) => registry?.clientForUri(uri));

  context.subscriptions.push(
    vscode.window.onDidChangeActiveTextEditor((editor) => {
      workspaceTree.updateContext(editor?.document.uri.toString() ?? null);
    }),
  );
  workspaceTree.updateContext(vscode.window.activeTextEditor?.document.uri.toString() ?? null);

  registry.onClientStarted(() => {
    setTimeout(() => {
      workspaceTree.refresh();
      datasourcesTree.refresh();
    }, 500);
  });

  context.subscriptions.push(
    vscode.workspace.onDidChangeWorkspaceFolders(async (event) => {
      for (const folder of event.removed) await registry?.stop(folder);
      for (const folder of event.added) await registry?.start(folder);
    }),
  );

  await onboarding.start();
  onboarding.maybeOpenWalkthrough().catch((error: unknown) => {
    OUTPUT.appendLine(
      `[walkthrough] activation failed: ${error instanceof Error ? error.message : String(error)}`,
    );
  });

  const folders = vscode.workspace.workspaceFolders ?? [];
  const startingRegistry = registry;
  await Promise.all(folders.map((folder) => startingRegistry.start(folder)));

  OUTPUT.appendLine(`Turbine LSP activated for ${folders.length} workspace folder(s).`);
}

export async function deactivate(): Promise<void> {
  await registry?.dispose();
  registry = null;
}

async function runProjectInitialization(folder: vscode.WorkspaceFolder): Promise<void> {
  if (registry === null) return;
  const runner = registry.installRunnerFor(folder);
  const result = await runner.runInstall(["uv run turbine init"]);
  if (!result.ok) {
    vscode.window.showErrorMessage(
      `Turbine project initialization failed: ${result.failedCommand ?? ""} (exit ${result.exitCode ?? "?"})`,
    );
  }
}
