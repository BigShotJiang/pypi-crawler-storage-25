/**
 * Typed wrapper around LanguageClient for custom turbine/* LSP methods.
 *
 * Each method maps 1:1 to a method in the protocol schema. The wrapper
 * adds TypeScript generics so callers get typed params and results
 * without casting.
 */

import type { Disposable } from "vscode";
import type { LanguageClient } from "vscode-languageclient/node";

import type {
  ActionInvokedParams,
  CheckLogParams,
  CheckWorkspaceEmptyResult,
  FileContextParams,
  ListChecksResult,
  ListDatasourcesParams,
  ListDatasourcesResult,
  ListToursResult,
  OverviewDataResult,
  ReferencesDataResult,
  RunCheckParams,
  RunCheckResult,
  ScaffoldProjectParams,
  ScaffoldProjectResult,
  StepCompletedParams,
  SurfaceVisibilityChangedParams,
  TestDatasourceParams,
  TestDatasourceResult,
  TreeDidChangeParams,
  TreeGetChildrenParams,
  TreeGetRootParams,
  TreeNodesResult,
  TreeSubscribeParams,
  TreeSubscribeResult,
  TreeUnsubscribeParams,
  ValidateSchemaParams,
  ValidateSchemaResult,
  WatchStepParams,
  WorkspaceConfigParams,
} from "./types";

async function sendRequest<T>(lsp: LanguageClient, method: string, params: object): Promise<T> {
  const raw = await lsp.sendRequest(method, params);
  return raw as T;
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function toCamelKey(key: string): string {
  return key.replaceAll(/_([a-z])/g, (_match: string, letter: string) => letter.toUpperCase());
}

function camelizeKeys(value: unknown): unknown {
  if (Array.isArray(value)) {
    return value.map((item) => camelizeKeys(item));
  }
  if (!isRecord(value)) {
    return value;
  }
  const converted: Record<string, unknown> = {};
  for (const [key, nestedValue] of Object.entries(value)) {
    converted[toCamelKey(key)] = camelizeKeys(nestedValue);
  }
  return converted;
}

export const METHODS = {
  RUN_CHECK: "turbine/runCheck",
  VALIDATE_SCHEMA: "turbine/validateSchema",
  OVERVIEW_DATA: "turbine/overviewData",
  REFERENCES_DATA: "turbine/referencesData",
  CHECK_LOG: "turbine/checkLog",
  LIST_DATASOURCES: "turbine/listDatasources",
  TEST_DATASOURCE: "turbine/testDatasource",
  ONBOARDING_LIST_TOURS: "turbine/onboarding/listTours",
  ONBOARDING_WATCH_STEP: "turbine/onboarding/watchStep",
  ONBOARDING_UNWATCH_STEP: "turbine/onboarding/unwatchStep",
  ONBOARDING_STEP_COMPLETED: "turbine/onboarding/stepCompleted",
  ONBOARDING_ACTION_INVOKED: "turbine/onboarding/actionInvoked",
  ONBOARDING_SURFACE_VISIBILITY_CHANGED: "turbine/onboarding/surfaceVisibilityChanged",
  TREE_GET_ROOT: "turbine/tree/getRoot",
  TREE_GET_CHILDREN: "turbine/tree/getChildren",
  TREE_SUBSCRIBE: "turbine/tree/subscribe",
  TREE_UNSUBSCRIBE: "turbine/tree/unsubscribe",
  TREE_DID_CHANGE: "turbine/tree/didChange",
  WORKSPACE_CONFIG: "turbine/workspaceConfig",
  FILE_CONTEXT: "turbine/fileContext",
  LIST_CHECKS: "turbine/listChecks",
  SCAFFOLD_PROJECT: "turbine/scaffoldProject",
  CLEANUP_TOUR_SCAFFOLD: "turbine/cleanupTourScaffold",
  CHECK_WORKSPACE_EMPTY: "turbine/checkWorkspaceEmpty",
  CONFIRM_SCAFFOLD: "turbine/onboarding/confirmScaffold",
} as const;

export class TurbineClient {
  private treeDidChangeHandlers: Set<(params: TreeDidChangeParams) => void> = new Set();
  private treeDidChangeRegistered = false;

  constructor(readonly lsp: LanguageClient) {}

  async runCheck(params: RunCheckParams): Promise<RunCheckResult> {
    return sendRequest(this.lsp, METHODS.RUN_CHECK, params);
  }

  async validateSchema(params: ValidateSchemaParams): Promise<ValidateSchemaResult> {
    return sendRequest(this.lsp, METHODS.VALIDATE_SCHEMA, params);
  }

  async overviewData(): Promise<OverviewDataResult> {
    return sendRequest(this.lsp, METHODS.OVERVIEW_DATA, {});
  }

  async referencesData(): Promise<ReferencesDataResult> {
    return sendRequest(this.lsp, METHODS.REFERENCES_DATA, {});
  }

  async listDatasources(params?: ListDatasourcesParams): Promise<ListDatasourcesResult> {
    return sendRequest(this.lsp, METHODS.LIST_DATASOURCES, params ?? {});
  }

  async testDatasource(params: TestDatasourceParams): Promise<TestDatasourceResult> {
    return sendRequest(this.lsp, METHODS.TEST_DATASOURCE, params);
  }

  async listChecks(params: { uri: string }): Promise<ListChecksResult> {
    return sendRequest(this.lsp, METHODS.LIST_CHECKS, params);
  }

  onCheckLog(handler: (params: CheckLogParams) => void): Disposable {
    return this.lsp.onNotification(METHODS.CHECK_LOG, (raw: unknown) => {
      handler(raw as CheckLogParams);
    });
  }

  async scaffoldProject(params: ScaffoldProjectParams): Promise<ScaffoldProjectResult> {
    const raw = await sendRequest<unknown>(this.lsp, METHODS.SCAFFOLD_PROJECT, params);
    return camelizeKeys(raw) as ScaffoldProjectResult;
  }

  async checkWorkspaceEmpty(): Promise<CheckWorkspaceEmptyResult> {
    const raw = await sendRequest<unknown>(this.lsp, METHODS.CHECK_WORKSPACE_EMPTY, {});
    return camelizeKeys(raw) as CheckWorkspaceEmptyResult;
  }

  async listTours(): Promise<ListToursResult> {
    const raw = await sendRequest<unknown>(this.lsp, METHODS.ONBOARDING_LIST_TOURS, {});
    return camelizeKeys(raw) as ListToursResult;
  }

  async watchStep(params: WatchStepParams): Promise<void> {
    await sendRequest(this.lsp, METHODS.ONBOARDING_WATCH_STEP, params);
  }

  async unwatchStep(): Promise<void> {
    await sendRequest(this.lsp, METHODS.ONBOARDING_UNWATCH_STEP, {});
  }

  async actionInvoked(params: ActionInvokedParams): Promise<void> {
    await sendRequest(this.lsp, METHODS.ONBOARDING_ACTION_INVOKED, params);
  }

  async surfaceVisibilityChanged(params: SurfaceVisibilityChangedParams): Promise<void> {
    await sendRequest(this.lsp, METHODS.ONBOARDING_SURFACE_VISIBILITY_CHANGED, params);
  }

  onStepCompleted(handler: (params: StepCompletedParams) => void): Disposable {
    return this.lsp.onNotification(METHODS.ONBOARDING_STEP_COMPLETED, (raw: unknown) => {
      handler(raw as StepCompletedParams);
    });
  }

  async treeGetRoot(params: TreeGetRootParams): Promise<TreeNodesResult> {
    return sendRequest(this.lsp, METHODS.TREE_GET_ROOT, params);
  }

  async treeGetChildren(params: TreeGetChildrenParams): Promise<TreeNodesResult> {
    return sendRequest(this.lsp, METHODS.TREE_GET_CHILDREN, params);
  }

  async treeSubscribe(params: TreeSubscribeParams): Promise<TreeSubscribeResult> {
    return sendRequest(this.lsp, METHODS.TREE_SUBSCRIBE, params);
  }

  async treeUnsubscribe(params: TreeUnsubscribeParams): Promise<void> {
    await sendRequest(this.lsp, METHODS.TREE_UNSUBSCRIBE, params);
  }

  onTreeDidChange(handler: (params: TreeDidChangeParams) => void): Disposable {
    // vscode-languageclient.onNotification only retains ONE handler per
    // method; a second registration silently overwrites the first. We
    // register exactly once and fan out to every subscriber ourselves so
    // multiple TurbineTreeProviders (workspace + datasources) both receive
    // every notification.
    if (!this.treeDidChangeRegistered) {
      this.treeDidChangeRegistered = true;
      this.lsp.onNotification(METHODS.TREE_DID_CHANGE, (raw: unknown) => {
        const params = raw as TreeDidChangeParams;
        for (const subscriber of this.treeDidChangeHandlers) {
          subscriber(params);
        }
      });
    }
    this.treeDidChangeHandlers.add(handler);
    return { dispose: () => this.treeDidChangeHandlers.delete(handler) };
  }

  onWorkspaceConfig(handler: (params: WorkspaceConfigParams) => void): Disposable {
    return this.lsp.onNotification(METHODS.WORKSPACE_CONFIG, (raw: unknown) => {
      handler(raw as WorkspaceConfigParams);
    });
  }

  onFileContext(handler: (params: FileContextParams) => void): Disposable {
    return this.lsp.onNotification(METHODS.FILE_CONTEXT, (raw: unknown) => {
      handler(raw as FileContextParams);
    });
  }
}
