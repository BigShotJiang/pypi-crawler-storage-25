import * as vscode from "vscode";
import {
  CloseAction,
  type DocumentFilter,
  ErrorAction,
  LanguageClient,
  type LanguageClientOptions,
  type ServerOptions,
} from "vscode-languageclient/node";
import { WorkDoneProgressCancelNotification } from "vscode-languageserver-protocol";

import { TurbineClient } from "../client";
import { isTurbineFilePath } from "../diagnostic-pull-match";
import { ProgressToastManager } from "../progress-toast";
import { registerPickHandlers } from "./pick-handlers";
import { resolveCommand } from "./resolve-command";

/**
 * Broad document selectors covering all file types Turbine handles.
 *
 * Per Grilled Decision #5: upfront selectors use wide globs so the client
 * receives didOpen/didChange for any YAML, SQL, or Python file. The server
 * ignores files it doesn't know about, so false positives are harmless.
 */
const DOCUMENT_SELECTORS: DocumentFilter[] = [
  { scheme: "file", language: "yaml", pattern: "**/*.yml" },
  { scheme: "file", language: "yaml", pattern: "**/*.yaml" },
  { scheme: "file", language: "sql", pattern: "**/*.sql" },
  { scheme: "file", language: "python", pattern: "**/*.py" },
];

/** File watcher patterns matching all Turbine-relevant files. */
const FILE_WATCHER_PATTERNS: string[] = [
  "**/*.yml",
  "**/*.yaml",
  "**/*.sql",
  "**/*.py",
];

export interface CreatedClient {
  readonly turbineClient: TurbineClient;
  readonly toastManager: ProgressToastManager;
}

export function createTurbineClient(
  folder: vscode.WorkspaceFolder,
  output: vscode.OutputChannel,
): CreatedClient {
  const config = vscode.workspace.getConfiguration("turbine", folder.uri);
  const command = config.get<string[]>("serverCommand", ["uv", "run", "turbine-lsp"]);
  const resolvedBinary = resolveCommand(command[0]);

  output.appendLine(`[${folder.name}] Server command: ${command.join(" ")}`);
  if (resolvedBinary !== command[0]) {
    output.appendLine(`[${folder.name}] Resolved ${command[0]} -> ${resolvedBinary}`);
  }
  output.appendLine(`[${folder.name}] Working directory: ${folder.uri.fsPath}`);

  const serverOptions: ServerOptions = {
    command: resolvedBinary,
    args: command.slice(1),
    options: { cwd: folder.uri.fsPath },
  };

  const fileEvents = FILE_WATCHER_PATTERNS.map((pattern) =>
    vscode.workspace.createFileSystemWatcher(new vscode.RelativePattern(folder, pattern)),
  );

  // Per-client toast manager. The middleware below routes every $/progress
  // event through it so nested runs render two stacked Notification toasts
  // instead of the default ProgressFeature behaviour. The cancel sender
  // forwards [✕] clicks into a `window/workDoneProgress/cancel` for the
  // client whose toast was opened. The client is constructed below; the
  // holder is captured here so the toast manager can forward cancels lazily.
  const clientHolder: { client: LanguageClient | null } = { client: null };
  const toastManager = new ProgressToastManager((progressToken) => {
    if (clientHolder.client === null) return;
    void clientHolder.client.sendNotification(WorkDoneProgressCancelNotification.method, {
      token: progressToken,
    });
  });

  const clientOptions: LanguageClientOptions = {
    documentSelector: DOCUMENT_SELECTORS,
    synchronize: { fileEvents },
    workspaceFolder: folder,
    outputChannel: output,
    // Server uses LSP 3.17 pull-mode diagnostics (advertises `diagnosticProvider`
    // and never sends `publishDiagnostics`). Without this opt-in the
    // DiagnosticFeature registers but never asks for diagnostics, leaving
    // the Problems panel permanently empty.
    diagnosticPullOptions: {
      onChange: true,
      onSave: true,
      onTabs: true,
      match: (documentSelector, resource) => {
        void documentSelector;
        return resource.scheme === "file" && isTurbineFilePath(resource.fsPath);
      },
    },
    middleware: {
      // Intercept all WorkDoneProgress events (begin/report/end) for any
      // token, client- or server-minted. Not calling next() suppresses the
      // default ProgressFeature toast so we don't double up.
      handleWorkDoneProgress: (token, params) => {
        toastManager.handle(token, params);
      },
    },
    // Suppress error popups when uv/turbine-lsp is missing or crashes.
    // Failures are logged to the output channel only — no retry toasts.
    initializationFailedHandler: (error) => {
      output.appendLine(`[${folder.name}] LSP init failed: ${error}`);
      return false;
    },
    errorHandler: {
      error: (_error, _message, count) => ({
        action: count && count > 1 ? ErrorAction.Shutdown : ErrorAction.Continue,
        handled: true,
      }),
      closed: () => ({
        action: CloseAction.DoNotRestart,
        handled: true,
      }),
    },
  };

  const client = new LanguageClient(
    `turbine-lsp-${folder.name}`,
    `Turbine LSP (${folder.name})`,
    serverOptions,
    clientOptions,
  );
  clientHolder.client = client;

  registerPickHandlers(client, output, folder.name);

  return { turbineClient: new TurbineClient(client), toastManager };
}
