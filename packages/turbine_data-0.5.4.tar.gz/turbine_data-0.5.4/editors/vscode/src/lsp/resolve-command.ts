import * as fs from "node:fs";
import * as os from "node:os";
import * as path from "node:path";

/**
 * Resolve a bare command name (like "uv") to its full path.
 *
 * macOS GUI apps inherit a minimal PATH that excludes ~/.local/bin,
 * ~/.cargo/bin, and other user-installed tool locations. This function
 * checks common install directories so the extension works on first
 * launch without requiring the user to configure a full path.
 */
export function resolveCommand(command: string): string {
  if (command.includes(path.sep)) return command;
  const home = os.homedir();
  const candidates = [
    path.join(home, ".local", "bin", command),
    path.join(home, ".cargo", "bin", command),
    `/usr/local/bin/${command}`,
    `/opt/homebrew/bin/${command}`,
  ];
  for (const candidate of candidates) {
    if (fs.existsSync(candidate)) {
      return candidate;
    }
  }
  return command;
}
