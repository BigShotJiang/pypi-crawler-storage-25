import * as vscode from "vscode";
import type { LanguageClient } from "vscode-languageclient/node";

import { insertSnippetAtPosition } from "../editor-snippet";
import { type ApplyEditResult, type InsertSnippetRequestParams } from "../insert-snippet-request";

interface PickTableSelection {
  schema: string;
  table: string;
}

interface PickTableParams {
  tables: PickTableSelection[];
}

type PickTablesResult = PickTableSelection[] | null;

interface PickDatasourceSelection {
  name: string;
  dsType: string;
  uri: string;
}

interface PickDatasourceParams {
  datasources: PickDatasourceSelection[];
}

type PickDatasourceResult = PickDatasourceSelection | null;

interface InputTextParams {
  message: string;
  placeholder?: string;
}

interface PickCheckCatalogEntry {
  id: string;
  description: string;
  bucket: string;
  takesThreshold: boolean;
}

interface PickCheckParams {
  catalog: PickCheckCatalogEntry[];
}

type PickCheckResult = { checkType: string; dimension: string } | null;

const QUALITY_DIMENSIONS: ReadonlyArray<vscode.QuickPickItem> = [
  { label: "completeness", description: "Data is not missing" },
  { label: "accuracy", description: "Data values are correct" },
  { label: "consistency", description: "Data agrees across sources" },
  { label: "timeliness", description: "Data arrives on time" },
];

async function pickTables(params: PickTableParams): Promise<PickTablesResult> {
  const items = params.tables.map((table) => ({
    label: table.table,
    description: table.schema,
    detail: `${table.schema}.${table.table}`,
    selection: { schema: table.schema, table: table.table },
  }));
  const picked = await vscode.window.showQuickPick(items, {
    placeHolder: "Select tables to include in the contract",
    matchOnDescription: true,
    matchOnDetail: true,
    canPickMany: true,
  });
  if (!picked || picked.length === 0) return null;
  return picked.map((item) => item.selection);
}

async function pickDatasource(params: PickDatasourceParams): Promise<PickDatasourceResult> {
  const items = params.datasources.map((datasource) => ({
    label: datasource.name,
    description: datasource.dsType,
    detail: datasource.uri,
    datasource,
  }));
  const picked = await vscode.window.showQuickPick(items, {
    placeHolder: "Select Datasource",
    matchOnDescription: true,
    matchOnDetail: true,
  });
  return picked?.datasource ?? null;
}

async function inputText(params: InputTextParams): Promise<string | null> {
  const value = await vscode.window.showInputBox({
    prompt: params.message,
    placeHolder: params.placeholder ?? "",
  });
  return value ?? null;
}

async function pickColumn(params: { columns: string[] }): Promise<string | null> {
  const items = params.columns.map((col) => ({ label: col }));
  const picked = await vscode.window.showQuickPick(items, {
    placeHolder: "Select a column to add a check to",
  });
  return picked?.label ?? null;
}

async function pickCheck(params: PickCheckParams): Promise<PickCheckResult> {
  const items: (vscode.QuickPickItem & { checkId: string })[] = params.catalog.map((entry) => ({
    label: entry.id,
    description: entry.bucket,
    detail: entry.description,
    checkId: entry.id,
  }));
  const picked = await vscode.window.showQuickPick(items, {
    placeHolder: "Select a check to add",
    matchOnDescription: true,
    matchOnDetail: true,
  });
  if (!picked) return null;

  const dimension = await vscode.window.showQuickPick(QUALITY_DIMENSIONS, {
    placeHolder: "Select a quality dimension",
  });
  if (!dimension) return null;

  return { checkType: picked.checkId, dimension: dimension.label };
}

async function insertSnippet(params: Readonly<InsertSnippetRequestParams>): Promise<ApplyEditResult> {
  return insertSnippetAtPosition(
    params.uri,
    params.position.line,
    params.position.character,
    params.snippetText,
  );
}

interface ConfirmScaffoldParams {
  reasons: string[];
}

interface ConfirmScaffoldResult {
  confirmed: boolean;
}

async function confirmScaffold(
  params: Readonly<ConfirmScaffoldParams>,
): Promise<ConfirmScaffoldResult> {
  const reasonLine = params.reasons.length > 0
    ? `\n\nFiles already in this folder:\n  - ${params.reasons.join("\n  - ")}`
    : "";
  const detail =
    "Starting the tour writes a demo project (contracts, datasources, sample data) " +
    `into this folder. Existing files with the same names are left untouched.${reasonLine}`;
  const choice = await vscode.window.showInformationMessage(
    "Add Turbine demo files to this folder?",
    { modal: true, detail },
    "Yes, add demo files",
  );
  return { confirmed: choice === "Yes, add demo files" };
}

export function registerPickHandlers(
  client: LanguageClient,
  output: vscode.OutputChannel,
  folderName: string,
): void {
  client.onRequest("turbine/pickTables", pickTables);
  client.onRequest("turbine/pickDatasource", pickDatasource);
  client.onRequest("turbine/inputText", inputText);
  client.onRequest("turbine/pickColumn", pickColumn);
  client.onRequest("turbine/pickCheck", pickCheck);
  client.onRequest("turbine/onboarding/confirmScaffold", confirmScaffold);

  output.appendLine(`[${folderName}] Registering turbine/insertSnippet handler.`);
  client.onRequest("turbine/insertSnippet", async (params: InsertSnippetRequestParams) => {
    output.appendLine(`[${folderName}] Handling turbine/insertSnippet for ${params.uri}.`);
    return insertSnippet(params);
  });
}
