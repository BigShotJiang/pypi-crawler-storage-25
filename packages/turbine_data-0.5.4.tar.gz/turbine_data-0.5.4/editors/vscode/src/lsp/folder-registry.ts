import * as path from "node:path";

import * as vscode from "vscode";
import type { LanguageClient } from "vscode-languageclient/node";

import type { TurbineClient } from "../client";
import { VsCodeInstallTaskRunner } from "../onboarding/install-task";
import { PhaseClient } from "../onboarding/phase-client";
import type { ProgressToastManager } from "../progress-toast";
import type { SidebarCreationTarget } from "../sidebar-resource-creation";
import { isExistingTurbineProject } from "../turbine-project";
import type { WorkspaceConfigParams } from "../types";
import { createTurbineClient } from "./client-factory";

export interface FolderEntry {
  readonly folder: vscode.WorkspaceFolder;
  readonly key: string;
  readonly client: TurbineClient;
  readonly phaseClient: PhaseClient;
  readonly toastManager: ProgressToastManager;
  readonly installRunner: VsCodeInstallTaskRunner;
  workspaceConfig: WorkspaceConfigParams;
}

export interface FolderStartFailure {
  readonly key: string;
  readonly message: string;
}

/**
 * Owns all per-folder state for the extension. Replaces five module-level
 * Maps (clients, phaseClients, installRunners, toastManagers,
 * workspaceConfigs) and the four ad-hoc lookup helpers
 * (resolveOwningFolder, findClientForUri, findTurbineClientForUri,
 * getActiveTurbineClient).
 *
 * One LSP client per workspace folder. Folders without [tool.turbine]
 * never get an entry — the onboarding panel is responsible for guiding the
 * user to add Turbine to the project before the LSP starts.
 */
export class FolderRegistry implements vscode.Disposable {
  private readonly entries = new Map<string, FolderEntry>();
  private readonly installRunners = new Map<string, VsCodeInstallTaskRunner>();
  private readonly clientStartedEmitter = new vscode.EventEmitter<FolderEntry>();
  private readonly clientStartFailedEmitter = new vscode.EventEmitter<FolderStartFailure>();
  private readonly beforeStopEmitter = new vscode.EventEmitter<FolderEntry>();
  private readonly afterStopEmitter = new vscode.EventEmitter<string>();

  constructor(private readonly output: vscode.OutputChannel) {}

  readonly onClientStarted: vscode.Event<FolderEntry> = this.clientStartedEmitter.event;
  readonly onClientStartFailed: vscode.Event<FolderStartFailure> = this.clientStartFailedEmitter.event;
  readonly onBeforeStop: vscode.Event<FolderEntry> = this.beforeStopEmitter.event;
  readonly onAfterStop: vscode.Event<string> = this.afterStopEmitter.event;

  /**
   * Look up the install runner for a workspace folder by key. If the folder
   * was gated off (no `[tool.turbine]` yet) so no `FolderEntry` exists, the
   * runner is created on demand from the matching workspace folder so the
   * onboarding panel can still run `uv init` / bootstrap commands.
   */
  installRunnerForKey(key: string): VsCodeInstallTaskRunner | null {
    const existing = this.installRunners.get(key);
    if (existing !== undefined) return existing;
    const folder = (vscode.workspace.workspaceFolders ?? []).find((entry) => entry.uri.toString() === key);
    if (folder === undefined) return null;
    return this.installRunnerFor(folder);
  }

  installRunnerFor(folder: vscode.WorkspaceFolder): VsCodeInstallTaskRunner {
    const key = folder.uri.toString();
    const existing = this.installRunners.get(key);
    if (existing !== undefined) return existing;
    const runner = new VsCodeInstallTaskRunner(folder, (message) => this.output.appendLine(message));
    this.installRunners.set(key, runner);
    return runner;
  }

  async start(folder: vscode.WorkspaceFolder): Promise<FolderEntry | null> {
    const key = folder.uri.toString();
    if (this.entries.has(key)) return this.entries.get(key) ?? null;

    const installRunner = this.installRunnerFor(folder);

    const isTurbine = await isExistingTurbineProject(folder.uri.fsPath);
    if (!isTurbine) {
      this.output.appendLine(`[${folder.name}] No [tool.turbine] found — skipping LSP start.`);
      return null;
    }

    const { turbineClient, toastManager } = createTurbineClient(folder, this.output);
    const phaseClient = new PhaseClient(turbineClient.lsp);
    const entry: FolderEntry = {
      folder,
      key,
      client: turbineClient,
      phaseClient,
      toastManager,
      installRunner,
      workspaceConfig: defaultWorkspaceConfig(folder),
    };

    turbineClient.onWorkspaceConfig((params) => {
      entry.workspaceConfig = params;
      this.output.appendLine(
        `[${folder.name}] Received workspace config: root=${params.root} ` +
          `contracts=${params.contractsDir} quality=${params.qualityDir} ` +
          `checks=${params.checksDir} datasources=${params.datasourcesDir}`,
      );
    });

    turbineClient.onFileContext((params) => {
      const activeUri = vscode.window.activeTextEditor?.document.uri.toString();
      if (activeUri === params.uri) {
        vscode.commands.executeCommand("setContext", "turbine.isTurbineFile", params.isTurbineFile);
      }
    });

    this.entries.set(key, entry);
    this.clientStartedEmitter.fire(entry);

    try {
      await turbineClient.lsp.start();
      this.output.appendLine(`[${folder.name}] Turbine LSP started.`);
      return entry;
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      this.output.appendLine(`[${folder.name}] Turbine LSP failed: ${message}`);
      this.entries.delete(key);
      phaseClient.dispose();
      this.clientStartFailedEmitter.fire({ key, message });
      return null;
    }
  }

  async stop(folder: vscode.WorkspaceFolder): Promise<void> {
    const key = folder.uri.toString();
    const entry = this.entries.get(key);
    if (entry !== undefined) {
      this.beforeStopEmitter.fire(entry);
      this.entries.delete(key);
      await entry.client.lsp.stop();
      this.output.appendLine(`[${folder.name}] Turbine LSP stopped.`);
      entry.phaseClient.dispose();
      entry.toastManager.disposeAll();
    }
    this.installRunners.delete(key);
    this.afterStopEmitter.fire(key);
  }

  get(key: string): FolderEntry | undefined {
    return this.entries.get(key);
  }

  has(key: string): boolean {
    return this.entries.has(key);
  }

  keys(): IterableIterator<string> {
    return this.entries.keys();
  }

  values(): IterableIterator<FolderEntry> {
    return this.entries.values();
  }

  /** Iterable in the shape LspClientStateAggregator expects. */
  *clientEntries(): IterableIterator<readonly [string, TurbineClient]> {
    for (const [key, entry] of this.entries) {
      yield [key, entry.client] as const;
    }
  }

  /**
   * Resolve the entry that owns *uri*. Single-project per folder: the
   * workspace folder containing the URI is the owner. Falls back to a longest-
   * prefix search across known workspace folders for URIs that fall outside
   * the direct mapping (rare; e.g. URIs constructed before the folder was
   * registered).
   */
  resolveByUri(uri: vscode.Uri): FolderEntry | undefined {
    const direct = vscode.workspace.getWorkspaceFolder(uri);
    if (direct !== undefined) {
      return this.entries.get(direct.uri.toString());
    }
    const fsPath = uri.fsPath;
    let best: vscode.WorkspaceFolder | undefined;
    for (const folder of vscode.workspace.workspaceFolders ?? []) {
      if (
        fsPath.startsWith(folder.uri.fsPath) &&
        (best === undefined || folder.uri.fsPath.length > best.uri.fsPath.length)
      ) {
        best = folder;
      }
    }
    if (best === undefined) return undefined;
    return this.entries.get(best.uri.toString());
  }

  clientForUri(uri: vscode.Uri): LanguageClient | undefined {
    return this.resolveByUri(uri)?.client.lsp;
  }

  /**
   * Best entry for "the active project". Prefers the active editor's owner,
   * then any folder with a live entry, then the first entry.
   */
  active(): FolderEntry | undefined {
    const editor = vscode.window.activeTextEditor;
    if (editor !== undefined) {
      const fromEditor = this.resolveByUri(editor.document.uri);
      if (fromEditor !== undefined) return fromEditor;
    }
    for (const folder of vscode.workspace.workspaceFolders ?? []) {
      const entry = this.entries.get(folder.uri.toString());
      if (entry !== undefined) return entry;
    }
    return this.entries.values().next().value;
  }

  configFor(folder: vscode.WorkspaceFolder): WorkspaceConfigParams {
    const entry = this.entries.get(folder.uri.toString());
    return entry?.workspaceConfig ?? defaultWorkspaceConfig(folder);
  }

  /**
   * Build the list of project roots offered to the sidebar "Create…"
   * commands. One target per active turbine folder.
   */
  sidebarCreationTargets(): SidebarCreationTarget[] {
    const targets: SidebarCreationTarget[] = [];
    for (const folder of vscode.workspace.workspaceFolders ?? []) {
      const entry = this.entries.get(folder.uri.toString());
      if (entry === undefined) continue;
      const config = entry.workspaceConfig;
      const relative = path.relative(folder.uri.fsPath, config.root);
      targets.push({
        folder,
        root: config.root,
        label: relative === "" ? "." : relative,
        client: entry.client,
        config,
      });
    }
    return targets;
  }

  async dispose(): Promise<void> {
    const stopPromises: Promise<void>[] = [];
    for (const entry of this.entries.values()) {
      stopPromises.push(entry.client.lsp.stop());
    }
    await Promise.all(stopPromises);
    for (const entry of this.entries.values()) {
      entry.phaseClient.dispose();
      entry.toastManager.disposeAll();
    }
    this.entries.clear();
    this.installRunners.clear();
    this.clientStartedEmitter.dispose();
    this.clientStartFailedEmitter.dispose();
    this.beforeStopEmitter.dispose();
    this.afterStopEmitter.dispose();
  }
}

function defaultWorkspaceConfig(folder: vscode.WorkspaceFolder): WorkspaceConfigParams {
  const root = folder.uri.fsPath;
  return {
    root,
    contractsDir: path.join(root, "contracts"),
    qualityDir: path.join(root, "quality"),
    checksDir: path.join(root, "checks"),
    datasourcesDir: path.join(root, "datasources"),
  };
}
