import * as vscode from "vscode";

import type { FolderRegistry } from "../lsp/folder-registry";
import { SERVER_COMMANDS } from "../server-commands";

/**
 * Forward a fixed set of server-driven commands (code-lens clicks etc.) to
 * the active folder's LSP via `workspace/executeCommand`. Registered globally
 * here because the server deliberately does NOT advertise these in
 * executeCommandProvider — vscode-languageclient would otherwise auto-register
 * them per client and crash on multi-folder workspaces with duplicate IDs.
 */
export function registerServerCommandBridge(
  context: vscode.ExtensionContext,
  registry: FolderRegistry,
): void {
  for (const cmd of SERVER_COMMANDS) {
    context.subscriptions.push(
      vscode.commands.registerCommand(cmd, async (...args: unknown[]) => {
        const editor = vscode.window.activeTextEditor;
        const client = editor === undefined ? undefined : registry.clientForUri(editor.document.uri);
        if (client === undefined) return;
        return client.sendRequest("workspace/executeCommand", {
          command: cmd,
          arguments: args,
        });
      }),
    );
  }
}
