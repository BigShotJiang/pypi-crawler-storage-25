import * as vscode from "vscode";

import type { FolderRegistry } from "../lsp/folder-registry";
import { showLspClientUnavailableMessage } from "../lsp-client-unavailable";
import type { TurbineTreeProvider } from "../tree-bridge";
import type { TreeNode } from "../types";

export interface SidebarTrees {
  readonly workspace: TurbineTreeProvider;
  readonly datasources: TurbineTreeProvider;
}

const DATASOURCE_ID_PREFIX = "datasources:datasource:";
const DATASOURCE_ID_SEPARATOR = "|";
const CONTRACT_ID_PREFIX = "workspace|contract|";

interface DatasourceNodeRef {
  readonly name: string;
  readonly uri: string;
}

function parseDatasourceNode(
  node: { id?: string; resourceUri?: string | null } | undefined,
): DatasourceNodeRef | null {
  const id = node?.id;
  if (typeof id !== "string" || !id.startsWith(DATASOURCE_ID_PREFIX)) return null;
  const payload = id.slice(DATASOURCE_ID_PREFIX.length);
  const separatorIndex = payload.lastIndexOf(DATASOURCE_ID_SEPARATOR);
  const name = separatorIndex === -1 ? payload : payload.slice(separatorIndex + 1);
  const uri = node?.resourceUri ?? null;
  if (!uri) return null;
  return { name, uri };
}

export function registerSidebarCommands(
  context: vscode.ExtensionContext,
  registry: FolderRegistry,
  trees: SidebarTrees,
  output: vscode.OutputChannel,
): void {
  context.subscriptions.push(
    vscode.commands.registerCommand("turbine.workspaceContracts.refresh", () => {
      trees.workspace.refresh();
    }),
    vscode.commands.registerCommand("turbine.datasources.refresh", () => {
      trees.datasources.refresh();
    }),
    vscode.commands.registerCommand(
      "turbine.datasources.testConnection",
      async (node: { id?: string; resourceUri?: string | null } | undefined) => {
        const ref = parseDatasourceNode(node);
        if (ref === null) {
          vscode.window.showWarningMessage("No datasource selected.");
          return;
        }
        const entry = registry.active();
        if (entry === undefined) {
          await showLspClientUnavailableMessage(output);
          return;
        }
        try {
          const result = await entry.client.testDatasource({ name: ref.name, uri: ref.uri });
          if (result.ok) {
            const latency = result.latencyMs === null ? "" : ` (${result.latencyMs}ms)`;
            vscode.window.showInformationMessage(`${ref.name}: connected${latency}`);
          } else {
            vscode.window.showErrorMessage(`${ref.name}: ${result.error ?? "connection failed"}`);
          }
        } catch (error) {
          const message = error instanceof Error ? error.message : String(error);
          vscode.window.showErrorMessage(`testDatasource failed: ${message}`);
        }
      },
    ),
    vscode.commands.registerCommand(
      "turbine.workspaceContracts.runCheck",
      async (node: { id?: string } | undefined) => {
        const id = node?.id;
        if (typeof id !== "string" || !id.startsWith(CONTRACT_ID_PREFIX)) {
          vscode.window.showWarningMessage("No contract selected.");
          return;
        }
        const uri = id.slice(CONTRACT_ID_PREFIX.length);
        const doc = await vscode.workspace.openTextDocument(vscode.Uri.parse(uri));
        await vscode.window.showTextDocument(doc, { preview: false });
        await vscode.commands.executeCommand("turbine.runQualityCheck");
      },
    ),
    vscode.commands.registerCommand(
      "turbine.workspaceContracts.dismissDiagnostic",
      async (node: TreeNode | undefined) => {
        const dismiss = node?.dismiss;
        if (!dismiss) {
          vscode.window.showWarningMessage("No dismissible finding selected.");
          return;
        }
        await vscode.commands.executeCommand(
          "turbine.dismissDiagnostic",
          dismiss.uri,
          dismiss.ruleId,
          dismiss.anchor,
        );
      },
    ),
  );
}
