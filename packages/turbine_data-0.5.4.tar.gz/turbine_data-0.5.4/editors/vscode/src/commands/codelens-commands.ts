import * as vscode from "vscode";

import type { FolderRegistry } from "../lsp/folder-registry";

export function registerCodeLensCommands(context: vscode.ExtensionContext, registry: FolderRegistry): void {
  context.subscriptions.push(
    vscode.commands.registerCommand("turbine.goToContract", async (contractId: string) => {
      const editor = vscode.window.activeTextEditor;
      const entry = editor !== undefined ? registry.resolveByUri(editor.document.uri) : undefined;
      if (entry === undefined) return;
      try {
        const overview = await entry.client.overviewData();
        const contract = overview.contracts.find((candidate) => candidate.contractId === contractId);
        if (contract?.uri) {
          const doc = await vscode.workspace.openTextDocument(vscode.Uri.parse(contract.uri));
          await vscode.window.showTextDocument(doc);
        } else {
          vscode.window.showWarningMessage(`Contract "${contractId}" not found in workspace.`);
        }
      } catch {
        vscode.window.showErrorMessage(`Failed to find contract "${contractId}".`);
      }
    }),

    vscode.commands.registerCommand("turbine.showReferences", async (contractId: string) => {
      const editor = vscode.window.activeTextEditor;
      if (editor === undefined) return;
      const entry = registry.resolveByUri(editor.document.uri);
      if (entry === undefined) return;
      try {
        const refs = await entry.client.referencesData();
        const related = refs.references.filter(
          (ref) => ref.sourceContractId === contractId || ref.targetContractId === contractId,
        );
        if (related.length === 0) {
          vscode.window.showInformationMessage(`No references found for "${contractId}".`);
          return;
        }
        const locations: vscode.Location[] = [];
        for (const ref of related) {
          const targetUri = ref.sourceContractId === contractId ? ref.targetUri : ref.sourceUri;
          if (targetUri) {
            locations.push(new vscode.Location(vscode.Uri.parse(targetUri), new vscode.Position(0, 0)));
          }
        }
        await vscode.commands.executeCommand(
          "editor.action.showReferences",
          editor.document.uri,
          editor.selection.active,
          locations,
        );
      } catch {
        vscode.window.showErrorMessage("Failed to fetch references.");
      }
    }),
  );
}
