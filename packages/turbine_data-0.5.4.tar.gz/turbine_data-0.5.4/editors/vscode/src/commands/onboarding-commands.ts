import * as vscode from "vscode";

import type { OnboardingComposition } from "../onboarding/composition";

export function registerOnboardingCommands(
  context: vscode.ExtensionContext,
  onboarding: OnboardingComposition,
): void {
  context.subscriptions.push(
    vscode.commands.registerCommand("turbine.onboarding.show", async () => {
      await onboarding.show();
    }),
    vscode.commands.registerCommand("turbine.onboarding.startTour", () => {
      onboarding.showTour();
    }),
    vscode.commands.registerCommand("turbine.onboarding.reset", async () => {
      await onboarding.resetActive();
      vscode.window.showInformationMessage("Turbine onboarding reset.");
    }),
  );
}
