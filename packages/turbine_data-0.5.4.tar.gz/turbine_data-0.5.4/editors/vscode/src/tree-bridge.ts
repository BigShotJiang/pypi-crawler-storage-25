/**
 * Generic VSCode TreeDataProvider backed by the turbine/tree/* LSP methods.
 *
 * One instance per registered tree (workspace / datasources). The provider is
 * lazy: it never calls getRoot until VSCode asks for the top level, never
 * calls getChildren until a node expands, and never calls subscribe before
 * the first fetch (so an unopened tree costs nothing).
 *
 * On a turbine/tree/didChange notification it fires onDidChangeTreeData with
 * the right granularity: full refresh when invalidatedNodeIds is empty,
 * targeted per-node refreshes otherwise.
 */

import * as vscode from "vscode";

import type { TurbineClient } from "./client";
import type { TreeCommand, TreeIcon, TreeId, TreeNode } from "./types";

const ICON_THEME: Record<TreeIcon, vscode.ThemeIcon> = {
  pass: new vscode.ThemeIcon("pass", new vscode.ThemeColor("testing.iconPassed")),
  fail: new vscode.ThemeIcon("error", new vscode.ThemeColor("testing.iconFailed")),
  warning: new vscode.ThemeIcon("warning", new vscode.ThemeColor("list.warningForeground")),
  info: new vscode.ThemeIcon("info"),
  unknown: new vscode.ThemeIcon("circle-outline"),
  loading: new vscode.ThemeIcon("sync~spin"),
  diff_added: new vscode.ThemeIcon(
    "diff-added",
    new vscode.ThemeColor("gitDecoration.addedResourceForeground"),
  ),
  diff_removed: new vscode.ThemeIcon(
    "diff-removed",
    new vscode.ThemeColor("gitDecoration.deletedResourceForeground"),
  ),
  diff_modified: new vscode.ThemeIcon(
    "diff-modified",
    new vscode.ThemeColor("gitDecoration.modifiedResourceForeground"),
  ),
  contract: new vscode.ThemeIcon("file-code"),
  reference: new vscode.ThemeIcon("link"),
  quality_spec: new vscode.ThemeIcon("checklist"),
  datasource: new vscode.ThemeIcon("database"),
  section_validation: new vscode.ThemeIcon("shield"),
  section_references: new vscode.ThemeIcon("references"),
  section_quality_specs: new vscode.ThemeIcon("checklist"),
};

const COLLAPSIBLE_STATE: Record<TreeNode["collapsibleState"], vscode.TreeItemCollapsibleState> = {
  none: vscode.TreeItemCollapsibleState.None,
  collapsed: vscode.TreeItemCollapsibleState.Collapsed,
  expanded: vscode.TreeItemCollapsibleState.Expanded,
};

function commandToVscode(cmd: TreeCommand): vscode.Command {
  if (cmd.kind === "openFile") {
    const uri = vscode.Uri.parse(cmd.uri);
    if (cmd.line === null) {
      return { command: "vscode.open", title: "Open", arguments: [uri] };
    }
    const line = Math.max(0, cmd.line - 1);
    const column = Math.max(0, (cmd.column ?? 1) - 1);
    const position = new vscode.Position(line, column);
    return {
      command: "vscode.open",
      title: "Open",
      arguments: [uri, { selection: new vscode.Range(position, position) }],
    };
  }
  if (cmd.kind === "showReferences") {
    const anchor = vscode.Uri.parse(cmd.anchorUri);
    const position = new vscode.Position(cmd.anchorLine, cmd.anchorColumn);
    const locations = cmd.targetUris.map(
      (uri) => new vscode.Location(vscode.Uri.parse(uri), new vscode.Position(0, 0)),
    );
    return {
      command: "editor.action.showReferences",
      title: "Show References",
      arguments: [anchor, position, locations],
    };
  }
  return { command: cmd.command, title: cmd.command, arguments: cmd.arguments };
}

function nodeToTreeItem(node: TreeNode): vscode.TreeItem {
  const item = new vscode.TreeItem(node.label, COLLAPSIBLE_STATE[node.collapsibleState]);
  item.id = node.id;
  item.iconPath = ICON_THEME[node.icon] ?? new vscode.ThemeIcon("circle-outline");
  if (node.description !== null) item.description = node.description;
  if (node.tooltip !== null) item.tooltip = node.tooltip;
  if (node.contextValue !== null) item.contextValue = node.contextValue;
  if (node.resourceUri !== null) item.resourceUri = vscode.Uri.parse(node.resourceUri);
  if (node.command !== null) item.command = commandToVscode(node.command);
  return item;
}

export class TurbineTreeProvider implements vscode.TreeDataProvider<TreeNode>, vscode.Disposable {
  private readonly emitter = new vscode.EventEmitter<TreeNode | undefined>();
  readonly onDidChangeTreeData = this.emitter.event;

  private subscriptionId: string | null = null;
  private didChangeListener: vscode.Disposable | null = null;
  private cachedClient: TurbineClient | null = null;
  private readonly nodesById = new Map<string, TreeNode>();
  private readonly parentIdsByNodeId = new Map<string, string>();
  private currentContextUri: string | null = null;

  constructor(
    private readonly treeId: TreeId,
    private readonly getClient: () => TurbineClient | undefined,
    getContextUri: () => string | null = () => null,
    private readonly output?: vscode.OutputChannel,
  ) {
    this.currentContextUri = getContextUri();
  }

  dispose(): void {
    void this.unsubscribe();
    this.emitter.dispose();
  }

  refresh(): void {
    this.nodesById.clear();
    this.parentIdsByNodeId.clear();
    this.emitter.fire(undefined);
  }

  async refreshRoot(): Promise<TreeNode[]> {
    this.nodesById.clear();
    this.parentIdsByNodeId.clear();
    this.emitter.fire(undefined);
    return this.getChildren();
  }

  findCachedNodeById(nodeId: string): TreeNode | undefined {
    return this.nodesById.get(nodeId);
  }

  findCachedNodeByResourceUri(uri: string): TreeNode | undefined {
    for (const node of this.nodesById.values()) {
      if (node.resourceUri === uri) return node;
    }
    return undefined;
  }

  /** Update the context URI and trigger a full refresh. */
  updateContext(uri: string | null): void {
    this.currentContextUri = uri;
    this.emitter.fire(undefined);
  }

  getTreeItem(node: TreeNode): vscode.TreeItem {
    return nodeToTreeItem(node);
  }

  getParent(node: TreeNode): vscode.ProviderResult<TreeNode> {
    const parentId = this.parentIdsByNodeId.get(node.id);
    if (parentId === undefined) return undefined;
    return this.nodesById.get(parentId);
  }

  async getChildren(node?: TreeNode): Promise<TreeNode[]> {
    const client = this.getClient();
    if (!client) return [];

    await this.ensureSubscribed(client);

    try {
      const result = node
        ? await client.treeGetChildren({
            treeId: this.treeId,
            nodeId: node.id,
            contextUri: this.currentContextUri,
          })
        : await client.treeGetRoot({
            treeId: this.treeId,
            contextUri: this.currentContextUri,
          });
      for (const child of result.nodes) {
        this.nodesById.set(child.id, child);
        if (node === undefined) {
          this.parentIdsByNodeId.delete(child.id);
        } else {
          this.parentIdsByNodeId.set(child.id, node.id);
        }
      }
      return result.nodes;
    } catch (error) {
      this.log(`getChildren failed for ${this.treeId}: ${describeError(error)}`);
      return [];
    }
  }

  private async ensureSubscribed(client: TurbineClient): Promise<void> {
    if (this.subscriptionId !== null && this.cachedClient === client) return;
    if (this.cachedClient !== null && this.cachedClient !== client) {
      await this.unsubscribe();
    }
    this.cachedClient = client;
    try {
      const result = await client.treeSubscribe({
        treeId: this.treeId,
        contextUri: this.currentContextUri,
      });
      this.subscriptionId = result.subscriptionId;
      this.didChangeListener = client.onTreeDidChange((params) => {
        if (params.treeId !== this.treeId) return;
        if (params.invalidatedNodeIds.length === 0) {
          this.nodesById.clear();
          this.parentIdsByNodeId.clear();
          this.emitter.fire(undefined);
          return;
        }
        // Fire the PARENT of each invalidated node, not the node itself.
        // VSCode re-runs getTreeItem(element) using the element instance we
        // pass in, so firing the cached node would re-render its TreeItem
        // from stale data — only its children would be refetched. Firing
        // the parent triggers getChildren(parent), which refetches the
        // invalidated node and replaces it in our cache. Root-level nodes
        // have no parent, so we fall back to a full root refresh.
        const parentsToFire = new Set<string>();
        let needsRootRefresh = false;
        for (const nodeId of params.invalidatedNodeIds) {
          if (!this.nodesById.has(nodeId)) {
            needsRootRefresh = true;
            break;
          }
          const parentId = this.parentIdsByNodeId.get(nodeId);
          if (parentId === undefined) {
            needsRootRefresh = true;
          } else {
            parentsToFire.add(parentId);
          }
        }
        if (needsRootRefresh) {
          this.nodesById.clear();
          this.parentIdsByNodeId.clear();
          this.emitter.fire(undefined);
          return;
        }
        for (const parentId of parentsToFire) {
          const parent = this.nodesById.get(parentId);
          if (parent === undefined) {
            this.nodesById.clear();
            this.parentIdsByNodeId.clear();
            this.emitter.fire(undefined);
            return;
          }
          this.emitter.fire(parent);
        }
      });
    } catch (error) {
      this.log(`subscribe failed for ${this.treeId}: ${describeError(error)}`);
    }
  }

  private async unsubscribe(): Promise<void> {
    this.didChangeListener?.dispose();
    this.didChangeListener = null;
    const client = this.cachedClient;
    const subscriptionId = this.subscriptionId;
    this.cachedClient = null;
    this.subscriptionId = null;
    this.nodesById.clear();
    this.parentIdsByNodeId.clear();
    if (client && subscriptionId) {
      try {
        await client.treeUnsubscribe({ subscriptionId });
      } catch (error) {
        this.log(`unsubscribe failed for ${this.treeId}: ${describeError(error)}`);
      }
    }
  }

  private log(message: string): void {
    this.output?.appendLine(`[tree-bridge] ${message}`);
  }
}

function describeError(error: unknown): string {
  return error instanceof Error ? error.message : String(error);
}
