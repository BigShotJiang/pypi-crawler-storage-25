import * as path from "node:path";

import * as vscode from "vscode";

import type { DatasourceInfo, TreeNode, WorkspaceConfigParams } from "./types";

export type SidebarCreationKind = "datasource" | "blankContract" | "fromDatasource";

export interface SidebarLanguageClient {
  sendRequest(method: string, params: WorkspaceExecuteCommandParams): Promise<unknown>;
}

export interface SidebarTurbineClient {
  readonly lsp: SidebarLanguageClient;
  listDatasources(): Promise<{ datasources: DatasourceInfo[] }>;
}

export interface SidebarCreationTarget {
  readonly folder: vscode.WorkspaceFolder;
  readonly root: string;
  readonly label: string;
  readonly client: SidebarTurbineClient;
  readonly config: WorkspaceConfigParams;
}

export interface SidebarCreationTrees {
  readonly workspace: SidebarTreeHandle;
  readonly datasources: SidebarTreeHandle;
}

export interface SidebarTreeProvider {
  refreshRoot(): Promise<TreeNode[]>;
  findCachedNodeById(nodeId: string): TreeNode | undefined;
  findCachedNodeByResourceUri(uri: string): TreeNode | undefined;
}

export interface SidebarTreeHandle {
  readonly provider: SidebarTreeProvider;
  readonly view: Pick<vscode.TreeView<TreeNode>, "reveal">;
}

export interface SidebarResourceCreationDeps {
  readonly getTargets: () => SidebarCreationTarget[];
  readonly getWorkspaceFolders: () => readonly vscode.WorkspaceFolder[];
  readonly runProjectInitialization: (folder: vscode.WorkspaceFolder) => Promise<void>;
  readonly trees: SidebarCreationTrees;
}

interface WorkspaceExecuteCommandParams {
  readonly command: string;
  readonly arguments: readonly string[];
}

interface WorkspaceCommandResult {
  readonly message: string;
  readonly success: boolean;
}

interface ContractModePick extends vscode.QuickPickItem {
  readonly creationKind: "blankContract" | "fromDatasource";
}

interface TargetPick extends vscode.QuickPickItem {
  readonly target: SidebarCreationTarget;
}

const NEW_DATASOURCE_COMMAND = "turbine.datasources.newDatasource";
const NEW_CONTRACT_COMMAND = "turbine.workspaceContracts.newContract";
const CREATE_DATASOURCE_COMMAND = "turbine.createDatasource";
const CREATE_BLANK_CONTRACT_COMMAND = "turbine.createBlankContract";
const CREATE_CONTRACT_FROM_DATASOURCE_COMMAND = "turbine.createContractFromDatasource";
const CREATE_DATACONTRACT_FROM_DATASOURCE_ROW_COMMAND = "turbine.datasources.createDataContract";
const PROJECT_INITIALIZATION_ACTION = "Project Initialization";
const CONTRACT_MODE_ITEMS: readonly ContractModePick[] = [
  {
    label: "Blank Contract",
    description: "Create an empty Contract scaffold",
    creationKind: "blankContract",
  },
  {
    label: "From Datasource",
    description: "Generate a Contract from an existing Datasource",
    creationKind: "fromDatasource",
  },
];

export class SidebarResourceCreationShell {
  constructor(private readonly deps: SidebarResourceCreationDeps) {}

  register(context: vscode.ExtensionContext): void {
    context.subscriptions.push(
      vscode.commands.registerCommand(NEW_DATASOURCE_COMMAND, () => this.newDatasource()),
      vscode.commands.registerCommand(NEW_CONTRACT_COMMAND, () => this.newContract()),
      vscode.commands.registerCommand(CREATE_DATACONTRACT_FROM_DATASOURCE_ROW_COMMAND, (node: TreeNode) =>
        this.createDataContractFromDatasourceRow(node),
      ),
    );
  }

  async newDatasource(): Promise<void> {
    await this.runCreation("datasource");
  }

  async newContract(): Promise<void> {
    const picked = await vscode.window.showQuickPick(CONTRACT_MODE_ITEMS, {
      placeHolder: "Create Contract",
    });
    if (picked === undefined) return;
    await this.runCreation(picked.creationKind);
  }

  private async runCreation(kind: SidebarCreationKind): Promise<void> {
    const target = await this.resolveTarget();
    if (target === undefined) return;
    if (kind === "datasource") {
      const result = await this.executeServerCommand(target, CREATE_DATASOURCE_COMMAND, [target.root]);
      if (result !== null && !result.success) return;
      await this.refreshAndReveal(this.deps.trees.datasources, "datasource");
      return;
    }
    if (kind === "blankContract") {
      const result = await this.executeServerCommand(target, CREATE_BLANK_CONTRACT_COMMAND, [target.root]);
      if (result !== null && !result.success) return;
      await this.refreshAndReveal(this.deps.trees.workspace, "workspace");
      return;
    }
    await this.createContractFromDatasource(target);
  }

  private async resolveTarget(): Promise<SidebarCreationTarget | undefined> {
    const targets = this.deps.getTargets();
    if (targets.length === 1) return targets[0];
    if (targets.length > 1) {
      return this.pickTarget(targets);
    }
    await this.offerProjectInitialization();
    return undefined;
  }

  private async pickTarget(
    targets: readonly SidebarCreationTarget[],
  ): Promise<SidebarCreationTarget | undefined> {
    const items: TargetPick[] = targets.map((target) => ({
      label: target.label,
      description: target.folder.name,
      detail: target.root,
      target,
    }));
    const picked = await vscode.window.showQuickPick(items, {
      placeHolder: "Select Turbine project root",
      matchOnDescription: true,
      matchOnDetail: true,
    });
    return picked?.target;
  }

  private async offerProjectInitialization(): Promise<void> {
    const folders = this.deps.getWorkspaceFolders();
    if (folders.length === 0) {
      await vscode.window.showWarningMessage("Open a folder before creating Turbine resources.");
      return;
    }
    const folder =
      folders.length === 1
        ? folders[0]
        : await vscode.window.showWorkspaceFolderPick({
            placeHolder: "Select folder to initialize for Turbine",
          });
    if (folder === undefined) return;
    const selection = await vscode.window.showInformationMessage(
      "No Turbine project root found. Run Project Initialization first?",
      PROJECT_INITIALIZATION_ACTION,
    );
    if (selection !== PROJECT_INITIALIZATION_ACTION) return;
    await this.deps.runProjectInitialization(folder);
  }

  private async executeServerCommand(
    target: SidebarCreationTarget,
    command: string,
    args: readonly string[],
  ): Promise<WorkspaceCommandResult | null> {
    const result = await target.client.lsp.sendRequest("workspace/executeCommand", {
      command,
      arguments: args,
    });
    return parseWorkspaceCommandResult(result);
  }

  private async createContractFromDatasource(target: SidebarCreationTarget): Promise<void> {
    const result = await this.executeServerCommand(target, CREATE_CONTRACT_FROM_DATASOURCE_COMMAND, [
      target.root,
    ]);
    if (result !== null && !result.success) return;
    await this.refreshAndReveal(this.deps.trees.workspace, "workspace");
  }

  async createDataContractFromDatasourceRow(node: TreeNode | undefined): Promise<void> {
    const name = this.datasourceNameFromNode(node);
    if (name === undefined) {
      await vscode.window.showWarningMessage("No datasource selected.");
      return;
    }
    const targetAndUri = await this.resolveDatasourceRowTarget(node, name);
    if (targetAndUri === undefined) {
      await vscode.window.showWarningMessage(`Datasource ${name} has no file URI.`);
      return;
    }
    const result = await this.executeServerCommand(
      targetAndUri.target,
      CREATE_CONTRACT_FROM_DATASOURCE_COMMAND,
      [targetAndUri.target.root, targetAndUri.datasourceUri],
    );
    if (result !== null && !result.success) return;
    await this.refreshAndReveal(this.deps.trees.workspace, "workspace");
  }

  private datasourceNameFromNode(node: TreeNode | undefined): string | undefined {
    const id = node?.id;
    const prefix = "datasources:datasource:";
    if (typeof id !== "string" || !id.startsWith(prefix)) return undefined;
    return id.slice(prefix.length);
  }

  private async resolveDatasourceRowTarget(
    node: TreeNode | undefined,
    name: string,
  ): Promise<{ target: SidebarCreationTarget; datasourceUri: string } | undefined> {
    const resourceUri = node?.resourceUri ?? undefined;
    const matches: Array<{ target: SidebarCreationTarget; datasourceUri: string }> = [];
    for (const target of this.deps.getTargets()) {
      const result = await target.client.listDatasources();
      const datasource = result.datasources.find((candidate) =>
        resourceUri === undefined ? candidate.name === name : candidate.uri === resourceUri,
      );
      if (datasource?.uri) {
        matches.push({ target, datasourceUri: datasource.uri });
      }
    }
    if (matches.length === 1) return matches[0];
    if (matches.length > 1) return this.pickDatasourceRowTarget(matches);
    return undefined;
  }

  private async pickDatasourceRowTarget(
    matches: ReadonlyArray<{ target: SidebarCreationTarget; datasourceUri: string }>,
  ): Promise<{ target: SidebarCreationTarget; datasourceUri: string } | undefined> {
    const items = matches.map((match) => ({
      label: match.target.label,
      description: match.target.folder.name,
      detail: match.datasourceUri,
      match,
    }));
    const picked = await vscode.window.showQuickPick(items, {
      placeHolder: "Select Turbine project root",
      matchOnDescription: true,
      matchOnDetail: true,
    });
    return picked?.match;
  }

  private async refreshAndReveal(
    tree: SidebarTreeHandle,
    nodeIdPrefix: "datasource" | "workspace",
  ): Promise<void> {
    await tree.provider.refreshRoot();
    const activeUri = vscode.window.activeTextEditor?.document.uri.toString();
    const node =
      activeUri === undefined
        ? undefined
        : (tree.provider.findCachedNodeByResourceUri(activeUri) ??
          this.findNodeByFallbackId(tree.provider, activeUri, nodeIdPrefix));
    if (node === undefined) return;
    try {
      await tree.view.reveal(node, { select: true, focus: false, expand: false });
    } catch {
      return;
    }
  }

  private findNodeByFallbackId(
    provider: SidebarTreeProvider,
    activeUri: string,
    nodeIdPrefix: "datasource" | "workspace",
  ): TreeNode | undefined {
    if (nodeIdPrefix !== "datasource") return undefined;
    const name = path.basename(vscode.Uri.parse(activeUri).fsPath).replace(/\.ya?ml$/u, "");
    return provider.findCachedNodeById(`datasources:datasource:${name}`);
  }
}

function parseWorkspaceCommandResult(result: unknown): WorkspaceCommandResult | null {
  if (typeof result !== "object" || result === null) return null;
  const candidate = result as { readonly message?: unknown; readonly success?: unknown };
  if (typeof candidate.message !== "string" || typeof candidate.success !== "boolean") return null;
  return { message: candidate.message, success: candidate.success };
}
