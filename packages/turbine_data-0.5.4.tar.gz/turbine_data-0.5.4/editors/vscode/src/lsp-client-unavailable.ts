import * as vscode from "vscode";

export const LSP_CLIENT_UNAVAILABLE_MESSAGE =
  "Turbine LSP client is not running. Reload the window to reconnect.";

const RELOAD_WINDOW_ACTION = "Reload Window";
const SHOW_OUTPUT_ACTION = "Show Output";
const RELOAD_WINDOW_COMMAND = "workbench.action.reloadWindow";

interface OutputPresenter {
  show(preserveFocus?: boolean): void;
}

export async function showLspClientUnavailableMessage(output: OutputPresenter): Promise<void> {
  const selected = await vscode.window.showWarningMessage(
    LSP_CLIENT_UNAVAILABLE_MESSAGE,
    RELOAD_WINDOW_ACTION,
    SHOW_OUTPUT_ACTION,
  );
  await handleLspClientUnavailableAction(selected, output);
}

async function handleLspClientUnavailableAction(
  selected: string | undefined,
  output: OutputPresenter,
): Promise<void> {
  if (selected === RELOAD_WINDOW_ACTION) {
    await vscode.commands.executeCommand(RELOAD_WINDOW_COMMAND);
    return;
  }

  if (selected === SHOW_OUTPUT_ACTION) {
    output.show(true);
  }
}
