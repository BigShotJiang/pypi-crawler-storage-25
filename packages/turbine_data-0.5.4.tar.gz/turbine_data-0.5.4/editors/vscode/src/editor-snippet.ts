import * as vscode from "vscode";

import { type ApplyEditResult, failureResult } from "./insert-snippet-request";

/**
 * Insert a snippet at a position in a document, preserving tab stops.
 *
 * Plain `WorkspaceEdit.TextEdit` flattens snippet syntax to literal text;
 * this routes through `editor.insertSnippet` so `${1:placeholder}` markers
 * remain interactive.
 */
export async function insertSnippetAtPosition(
  uri: string,
  line: number,
  character: number,
  snippetText: string,
): Promise<ApplyEditResult> {
  try {
    const document = await vscode.workspace.openTextDocument(vscode.Uri.parse(uri));
    const editor = await vscode.window.showTextDocument(document, {
      preserveFocus: false,
      preview: false,
    });
    const applied = await editor.insertSnippet(
      new vscode.SnippetString(snippetText),
      new vscode.Position(line, character),
    );
    if (!applied) {
      return { applied: false, failureReason: "editor rejected snippet insertion" };
    }
    return { applied: true };
  } catch (error: unknown) {
    return failureResult(error);
  }
}
