type ProgressToken = string | number;
export type CancelSubscription = { dispose: () => void };

interface CancelListenerSource {
  onCancellationRequested(listener: () => void): { dispose(): void };
}

export function attachCancelListener(
  token: ProgressToken,
  cancellationToken: CancelListenerSource,
  sendCancel: (token: ProgressToken) => void,
): CancelSubscription {
  const subscription = cancellationToken.onCancellationRequested(() => {
    sendCancel(token);
  });
  return { dispose: () => subscription.dispose() };
}
