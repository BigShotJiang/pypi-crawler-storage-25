const TURBINE_FILE_EXTENSIONS = new Set([".yml", ".yaml", ".sql", ".py"]);

export function isTurbineFilePath(fsPath: string): boolean {
  const lower = fsPath.toLowerCase();
  for (const extension of TURBINE_FILE_EXTENSIONS) {
    if (lower.endsWith(extension)) {
      return true;
    }
  }
  return false;
}
