/**
 * Active Onboarding Folder.
 *
 * Single editor-side authority on which workspace folder the Onboarding
 * Panel is currently rendering. Default selection follows the active text
 * editor's owning folder; if no editor is active, the first non-sandbox
 * workspace folder. A manual selection through the panel's dropdown wins
 * until the pinned folder is removed from the workspace, at which point
 * the manual pin clears and default resolution resumes.
 *
 * Sandbox-folder filtering is the responsibility of the
 * `OnboardingFolderSource` adapter; this module trusts the list it gets.
 */

import * as vscode from "vscode";

export interface OnboardingFolder {
  readonly key: string;
  readonly label: string;
  readonly fsPath: string;
}

export type ActiveFolderChangeReason =
  | "active-editor-changed"
  | "manual-selection"
  | "workspace-folders-changed";

export interface ActiveFolderChange {
  readonly key: string | null;
  readonly reason: ActiveFolderChangeReason;
}

export interface OnboardingFolderSource {
  list(): readonly OnboardingFolder[];
  onDidChange(listener: () => void): vscode.Disposable;
}

export interface ActiveEditorSource {
  activeFolderKey(): string | null;
  onDidChange(listener: () => void): vscode.Disposable;
}

export interface ActiveOnboardingFolderDeps {
  readonly folders: OnboardingFolderSource;
  readonly activeEditor: ActiveEditorSource;
}

export class ActiveOnboardingFolder implements vscode.Disposable {
  private readonly folderSource: OnboardingFolderSource;
  private readonly activeEditor: ActiveEditorSource;
  private readonly emitter: vscode.EventEmitter<ActiveFolderChange>;
  private readonly subscriptions: vscode.Disposable[] = [];
  private manualKey: string | null = null;
  private resolvedKey: string | null;

  constructor(deps: ActiveOnboardingFolderDeps) {
    this.folderSource = deps.folders;
    this.activeEditor = deps.activeEditor;
    this.emitter = new vscode.EventEmitter<ActiveFolderChange>();
    this.resolvedKey = this.computeKey();
    this.subscriptions.push(
      this.folderSource.onDidChange(() => this.handleFoldersChanged()),
      this.activeEditor.onDidChange(() => this.handleEditorChanged()),
    );
  }

  get currentKey(): string | null {
    return this.resolvedKey;
  }

  get folders(): readonly OnboardingFolder[] {
    return this.folderSource.list();
  }

  get hasManualSelection(): boolean {
    return this.manualKey !== null;
  }

  get onDidChange(): vscode.Event<ActiveFolderChange> {
    return this.emitter.event;
  }

  select(key: string): void {
    if (!this.knownKey(key)) return;
    if (this.manualKey === key) return;
    this.manualKey = key;
    if (this.resolvedKey === key) return;
    this.transitionTo(key, "manual-selection");
  }

  clearManualSelection(): void {
    if (this.manualKey === null) return;
    this.manualKey = null;
    const next = this.computeKey();
    this.transitionTo(next, "manual-selection");
  }

  dispose(): void {
    for (const subscription of this.subscriptions) subscription.dispose();
    this.subscriptions.length = 0;
    this.emitter.dispose();
  }

  private handleFoldersChanged(): void {
    if (this.manualKey !== null && !this.knownKey(this.manualKey)) {
      this.manualKey = null;
    }
    const next = this.computeKey();
    if (next === this.resolvedKey) return;
    this.transitionTo(next, "workspace-folders-changed");
  }

  private handleEditorChanged(): void {
    if (this.manualKey !== null) return;
    const next = this.computeKey();
    if (next === this.resolvedKey) return;
    this.transitionTo(next, "active-editor-changed");
  }

  private transitionTo(next: string | null, reason: ActiveFolderChangeReason): void {
    this.resolvedKey = next;
    this.emitter.fire({ key: next, reason });
  }

  private computeKey(): string | null {
    if (this.manualKey !== null && this.knownKey(this.manualKey)) {
      return this.manualKey;
    }
    const editorKey = this.activeEditor.activeFolderKey();
    if (editorKey !== null && this.knownKey(editorKey)) {
      return editorKey;
    }
    const list = this.folderSource.list();
    return list.length === 0 ? null : list[0].key;
  }

  private knownKey(key: string): boolean {
    for (const entry of this.folderSource.list()) {
      if (entry.key === key) return true;
    }
    return false;
  }
}
