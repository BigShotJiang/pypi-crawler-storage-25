import * as fs from "node:fs/promises";
import * as path from "node:path";

import * as vscode from "vscode";

import { isExistingTurbineProject } from "../turbine-project";
import type { ActiveOnboardingFolder } from "./active-folder";
import type { ActiveEditorSource, OnboardingFolder, OnboardingFolderSource } from "./active-folder";
import type { TurbineProjectProbe, TurbineProjectState, WorkspaceFolderSource } from "./editor-phase";

export class WorkspaceFolderSourceImpl implements WorkspaceFolderSource {
  hasFolders(): boolean {
    return (vscode.workspace.workspaceFolders ?? []).length > 0;
  }

  onDidChangeFolders(listener: () => void): vscode.Disposable {
    return vscode.workspace.onDidChangeWorkspaceFolders(() => listener());
  }
}

export class WorkspaceOnboardingFolderSource implements OnboardingFolderSource {
  list(): readonly OnboardingFolder[] {
    const folders = vscode.workspace.workspaceFolders ?? [];
    const result: OnboardingFolder[] = [];
    for (const folder of folders) {
      result.push({
        key: folder.uri.toString(),
        label: folder.name,
        fsPath: folder.uri.fsPath,
      });
    }
    return result;
  }

  onDidChange(listener: () => void): vscode.Disposable {
    return vscode.workspace.onDidChangeWorkspaceFolders(() => listener());
  }
}

export class WorkspaceActiveEditorSource implements ActiveEditorSource {
  activeFolderKey(): string | null {
    const editor = vscode.window.activeTextEditor;
    if (editor === undefined) return null;
    const folder = vscode.workspace.getWorkspaceFolder(editor.document.uri);
    if (folder === undefined) return null;
    return folder.uri.toString();
  }

  onDidChange(listener: () => void): vscode.Disposable {
    return vscode.window.onDidChangeActiveTextEditor(() => listener());
  }
}

/**
 * Probes the active onboarding folder for a `pyproject.toml` and a
 * `[tool.turbine]` section. Used by the phase machine to distinguish
 * "the LSP is gated off because this isn't a turbine project yet" from a
 * genuine LSP failure — the panel can then render init / add-turbine actions
 * instead of a useless Retry button.
 */
export class FilesystemTurbineProjectProbe implements TurbineProjectProbe {
  constructor(private readonly active: ActiveOnboardingFolder) {}

  async inspect(): Promise<TurbineProjectState> {
    const folder = this.activeFolderPath();
    if (folder === null) return "no-active-folder";
    const pyprojectPath = path.join(folder, "pyproject.toml");
    const exists = await pathExists(pyprojectPath);
    if (!exists) return "no-pyproject";
    const isTurbine = await isExistingTurbineProject(folder);
    return isTurbine ? "configured" : "no-turbine-config";
  }

  private activeFolderPath(): string | null {
    const key = this.active.currentKey;
    if (key === null) return null;
    const folder = (vscode.workspace.workspaceFolders ?? []).find((entry) => entry.uri.toString() === key);
    return folder?.uri.fsPath ?? null;
  }
}

async function pathExists(absolute: string): Promise<boolean> {
  try {
    await fs.access(absolute);
    return true;
  } catch {
    return false;
  }
}
