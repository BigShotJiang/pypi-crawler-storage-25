/**
 * Sequential install-command runner.
 *
 * Wraps `vscode.tasks.executeTask` so the Onboarding Panel can ask the LSP
 * for an ordered command list and run it in the editor without assembling
 * shell strings. Short-circuits on the first non-zero exit.
 */

import * as vscode from "vscode";

export interface InstallResult {
  readonly ok: boolean;
  readonly failedCommand: string | null;
  readonly exitCode: number | null;
}

export interface InstallTaskRunner {
  runInstall(commands: readonly string[]): Promise<InstallResult>;
}

const TASK_TYPE = "turbine-onboarding";
const TASK_SOURCE = "Turbine";

export class VsCodeInstallTaskRunner implements InstallTaskRunner {
  constructor(
    private readonly folder: vscode.WorkspaceFolder,
    private readonly logger: (message: string) => void,
  ) {}

  async runInstall(commands: readonly string[]): Promise<InstallResult> {
    for (const command of commands) {
      const exitCode = await this.runOne(command);
      if (exitCode !== 0) {
        return { ok: false, failedCommand: command, exitCode };
      }
    }
    return { ok: true, failedCommand: null, exitCode: 0 };
  }

  private async runOne(command: string): Promise<number> {
    this.logger(`[onboarding.install] ${this.folder.name}: ${command}`);
    const task = new vscode.Task(
      { type: TASK_TYPE, command },
      this.folder,
      command,
      TASK_SOURCE,
      new vscode.ShellExecution(command, { cwd: this.folder.uri.fsPath }),
      [],
    );
    task.presentationOptions = {
      echo: true,
      reveal: vscode.TaskRevealKind.Always,
      focus: false,
      panel: vscode.TaskPanelKind.Shared,
      showReuseMessage: false,
      clear: false,
    };

    return new Promise<number>((resolve, reject) => {
      let listener: vscode.Disposable | null = null;
      void vscode.tasks.executeTask(task).then(
        (execution) => {
          listener = vscode.tasks.onDidEndTaskProcess((event) => {
            if (event.execution !== execution) return;
            listener?.dispose();
            resolve(event.exitCode ?? -1);
          });
        },
        (error) => {
          this.logger(
            `[onboarding.install] failed to launch task: ${
              error instanceof Error ? error.message : String(error)
            }`,
          );
          reject(error instanceof Error ? error : new Error(String(error)));
        },
      );
    });
  }
}
