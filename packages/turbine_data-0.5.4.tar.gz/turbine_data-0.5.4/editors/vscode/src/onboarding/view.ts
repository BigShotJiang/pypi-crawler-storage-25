import * as crypto from "node:crypto";

import * as vscode from "vscode";

import type { ActiveOnboardingFolder, OnboardingFolder } from "./active-folder";
import type { EditorPhase, EditorPhaseService } from "./editor-phase";
import type { InstallTaskRunner } from "./install-task";
import type {
  DatabaseChoice,
  DatabaseChoiceId,
  Phase,
  PhaseClient,
  PhaseDto,
  TourEntry,
} from "./phase-client";

export const ONBOARDING_VIEW_ID = "turbine.onboarding";
const SHOW_COMMAND = "workbench.view.extension.turbine-sidebar";
const START_TOUR_COMMAND = "turbine.onboarding.startTour";

const UV_INSTALL_GUIDE_URL = "https://docs.astral.sh/uv/getting-started/installation/";

export interface OnboardingViewDeps {
  readonly phaseService: EditorPhaseService;
  readonly extensionUri: vscode.Uri;
  readonly active: ActiveOnboardingFolder;
  readonly phaseClient: (key: string) => PhaseClient | null;
  readonly installRunner: (key: string) => InstallTaskRunner | null;
  readonly completedToursMachineWide: () => readonly string[];
  readonly logger: (message: string) => void;
}

interface PrimaryActionView {
  readonly id: string;
  readonly label: string;
}

interface CardChoice {
  readonly id: string;
  readonly label: string;
  readonly description: string;
  readonly iconId?: string;
  readonly isDefault?: boolean;
}

interface PhaseCard {
  readonly title: string;
  readonly body: string;
  readonly action: PrimaryActionView | null;
  readonly choices: readonly CardChoice[];
  readonly toursAvailable: number;
  readonly toursCompleted: number;
  readonly dismissable: boolean;
  readonly workspaceFolderUri: string;
  readonly phaseKind: Phase | null;
}

type IncomingMessage =
  | { readonly type: "action"; readonly id: string }
  | { readonly type: "install-choice"; readonly choiceId: string }
  | { readonly type: "dismiss-phase" }
  | { readonly type: "select-folder"; readonly folderKey: string };

const EMPTY_CARD: Omit<PhaseCard, "title" | "body"> = {
  action: null,
  choices: [],
  toursAvailable: 0,
  toursCompleted: 0,
  dismissable: false,
  workspaceFolderUri: "",
  phaseKind: null,
};

/**
 * Client-side fallback for the LSP's `installCommands` request. Used only in
 * the bootstrap path (`needs-turbine-project { subKind: "no-turbine-config" }`)
 * because the LSP is gated off until `[tool.turbine]` lands. Once the LSP is
 * up the server's install-commands stay authoritative — this map is the
 * minimum needed to get there.
 */
const BOOTSTRAP_INSTALL_COMMANDS: Record<DatabaseChoiceId, readonly string[]> = {
  postgres: ['uv add "turbine-data[postgres]"'],
  snowflake: ['uv add "turbine-data[snowflake]"'],
  duckdb: ['uv add "turbine-data[duckdb]"'],
  "lsp-only": ["uv add turbine-data"],
};

const BOOTSTRAP_BACKEND_CHOICES: readonly CardChoice[] = [
  { id: "duckdb", label: "DuckDB", description: "turbine-data[duckdb]", iconId: "duckdb", isDefault: true },
  { id: "postgres", label: "Postgres", description: "turbine-data[postgres]", iconId: "postgres" },
  { id: "snowflake", label: "Snowflake", description: "turbine-data[snowflake]", iconId: "snowflake" },
  { id: "lsp-only", label: "LSP only", description: "turbine-data", iconId: "lsp" },
];

function lspPhaseCard(dto: PhaseDto, machineWideCompleted: readonly string[]): PhaseCard {
  const completedSet = new Set(machineWideCompleted);
  const toursCompleted = dto.tours.reduce((acc: number, tour: TourEntry) => {
    return acc + (tour.completed || completedSet.has(tour.id) ? 1 : 0);
  }, 0);
  // The Start Onboarding button covers the ready phases; suppress whatever
  // primary action the LSP sent (typically "Reset onboarding") so the entry
  // card shows a single CTA. Reset stays available via the command palette
  // and the tour-view kebab menu.
  const isReadyPhase = dto.kind === "ready" || dto.kind === "ready-tour-pending";
  const action =
    isReadyPhase || dto.primaryAction === null
      ? null
      : { id: dto.primaryAction.id, label: dto.primaryAction.label };
  return {
    title: dto.title,
    body: dto.body,
    action,
    workspaceFolderUri: dto.workspaceFolderUri,
    phaseKind: dto.kind,
    dismissable: true,
    choices: dto.choices.map((choice: DatabaseChoice) => ({
      id: choice.id,
      label: choice.label,
      description: choice.description,
    })),
    toursAvailable: dto.tours.length,
    toursCompleted,
  };
}

function cardFor(phase: EditorPhase, machineWideCompleted: readonly string[]): PhaseCard {
  switch (phase.kind) {
    case "no-folder":
      return {
        ...EMPTY_CARD,
        title: "Open a folder",
        body: "Turbine works on the contracts, datasources, and quality files in a project folder. Open one to get started.",
        action: { id: "open-folder", label: "Open Folder" },
      };
    case "needs-uv":
      return {
        ...EMPTY_CARD,
        title: "Install uv",
        body: "Turbine uses uv to manage its Python dependencies. Install uv and reload the window once it is available on your PATH.",
        action: { id: "open-uv-guide", label: "Open uv install guide" },
      };
    case "needs-turbine-project":
      if (phase.subKind === "no-pyproject") {
        return {
          ...EMPTY_CARD,
          title: "Initialize a Python project",
          body: "Turbine installs into a Python project. Run uv init to create a pyproject.toml in this folder.",
          action: { id: "init-python", label: "Initialize Python project" },
        };
      }
      return {
        ...EMPTY_CARD,
        title: "Add Turbine to this project",
        body: "Pick your backend.",
        choices: BOOTSTRAP_BACKEND_CHOICES,
      };
    case "starting-server":
      return {
        ...EMPTY_CARD,
        title: "Starting Turbine",
        body: "The language server is starting up.",
      };
    case "awaiting-server-phase":
      return {
        ...EMPTY_CARD,
        title: "Starting Turbine",
        body: "Reading project state…",
      };
    case "needs-server":
      return {
        ...EMPTY_CARD,
        title: "Turbine LSP stopped",
        body:
          phase.reason === null
            ? "The language server is not running."
            : `The language server is not running. Last error: ${phase.reason}`,
        action: { id: "retry-lsp", label: "Retry" },
      };
    case "lsp-phase":
      return lspPhaseCard(phase.dto, machineWideCompleted);
  }
}

function escapeHtml(value: string): string {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function nonce(): string {
  return crypto.randomBytes(16).toString("base64").replaceAll(/[+/=]/g, "");
}

interface FolderPicker {
  readonly folders: readonly OnboardingFolder[];
  readonly currentKey: string | null;
}

function isReadyCard(card: PhaseCard): boolean {
  return card.phaseKind === "ready" || card.phaseKind === "ready-tour-pending";
}

function readyCardHtml(card: PhaseCard): string {
  if (!isReadyCard(card)) return "";
  const segmentsHtml = renderTourSegments(card.toursAvailable, card.toursCompleted);
  return `<div class="ready-card">
    <div class="ready-header">
      <span class="ready-check" aria-hidden="true">${readyCheckSvg()}</span>
      <h1>${escapeHtml(card.title)}</h1>
    </div>
    ${segmentsHtml}
    <button class="primary start-onboarding-cta" data-action="start-onboarding">
      <span class="play" aria-hidden="true">▶</span>
      <span>Start Onboarding</span>
    </button>
  </div>`;
}

function renderTourSegments(total: number, completed: number): string {
  if (total <= 0) return "";
  const segments: string[] = [];
  for (let index = 0; index < total; index += 1) {
    const filled = index < completed ? " filled" : "";
    segments.push(`<div class="tour-segment${filled}"></div>`);
  }
  return `<div class="tour-progress" role="progressbar" aria-valuenow="${completed}" aria-valuemin="0" aria-valuemax="${total}">${segments.join("")}</div>`;
}

function readyCheckSvg(): string {
  return `<svg viewBox="0 0 16 16" width="20" height="20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
    <circle cx="8" cy="8" r="6.5"/>
    <path d="M5 8.3 L7.2 10.5 L11 6.4"/>
  </svg>`;
}

function backendIconSvg(iconId: string): string {
  switch (iconId) {
    case "duckdb":
      return `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
        <circle cx="16" cy="16" r="13" fill="#FFD43B"/>
        <circle cx="20" cy="13" r="2.4" fill="#1a1a1a"/>
        <circle cx="20.8" cy="12.4" r="0.7" fill="#fff"/>
        <path d="M28 17 L34 17 L34 19 L28 19 Z" fill="#FF8C00"/>
      </svg>`;
    case "postgres":
      return `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" fill="none" stroke="#7AA2C9" stroke-width="1.8">
        <ellipse cx="16" cy="9" rx="10" ry="3.5"/>
        <path d="M6 9 V16 C6 17.93 10.48 19.5 16 19.5 C21.52 19.5 26 17.93 26 16 V9"/>
        <path d="M6 16 V23 C6 24.93 10.48 26.5 16 26.5 C21.52 26.5 26 24.93 26 23 V16"/>
      </svg>`;
    case "snowflake":
      return `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" stroke="#5BC0EB" stroke-width="1.6" stroke-linecap="round" fill="none">
        <line x1="16" y1="4" x2="16" y2="28"/>
        <line x1="5.6" y1="10" x2="26.4" y2="22"/>
        <line x1="5.6" y1="22" x2="26.4" y2="10"/>
        <polyline points="13,6 16,9 19,6"/>
        <polyline points="13,26 16,23 19,26"/>
        <polyline points="6.5,7.4 10.6,8.5 9.5,12.6"/>
        <polyline points="25.5,24.6 21.4,23.5 22.5,19.4"/>
        <polyline points="6.5,24.6 10.6,23.5 9.5,19.4"/>
        <polyline points="25.5,7.4 21.4,8.5 22.5,12.6"/>
      </svg>`;
    case "lsp":
      return `<svg viewBox="0 0 32 32" xmlns="http://www.w3.org/2000/svg" aria-hidden="true" stroke="#8B7BD8" stroke-width="2" stroke-linecap="round" fill="none">
        <line x1="6" y1="11" x2="22" y2="11"/>
        <line x1="6" y1="16" x2="26" y2="16"/>
        <line x1="6" y1="21" x2="18" y2="21"/>
      </svg>`;
    default:
      return "";
  }
}

function richChoiceHtml(choice: CardChoice): string {
  const icon = choice.iconId === undefined ? "" : backendIconSvg(choice.iconId);
  const badge = choice.isDefault === true ? `<span class="default-badge">DEFAULT</span>` : "";
  return `<button class="choice-row" data-choice-id="${escapeHtml(choice.id)}">
    <span class="choice-icon">${icon}</span>
    <span class="choice-text">
      <span class="choice-title">${escapeHtml(choice.label)}${badge}</span>
      <span class="choice-package">${escapeHtml(choice.description)}</span>
    </span>
    <span class="choice-chevron">›</span>
  </button>`;
}

function renderHtml(
  webview: vscode.Webview,
  phase: EditorPhase,
  picker: FolderPicker,
  machineWideCompleted: readonly string[],
): string {
  const card = cardFor(phase, machineWideCompleted);
  const cspNonce = nonce();
  const csp = `default-src 'none'; style-src ${webview.cspSource} 'unsafe-inline'; script-src 'nonce-${cspNonce}';`;
  const isBootstrap = phase.kind === "needs-turbine-project" && phase.subKind === "no-turbine-config";
  const isReady = isReadyCard(card);
  const buttonHtml =
    card.action === null
      ? ""
      : `<button class="primary" data-action="${escapeHtml(card.action.id)}">${escapeHtml(card.action.label)}</button>`;
  const choicesHtml =
    card.choices.length === 0
      ? ""
      : isBootstrap
        ? `<div class="choice-list">${card.choices.map(richChoiceHtml).join("")}</div>`
        : `<div class="choices">${card.choices
            .map(
              (choice) =>
                `<button class="choice" data-choice-id="${escapeHtml(choice.id)}">${escapeHtml(choice.label)}</button>`,
            )
            .join("")}</div>`;
  const bodyHtml = escapeHtml(card.body);
  const dismissHtml =
    card.dismissable && !isBootstrap ? `<button class="dismiss" aria-label="Dismiss">×</button>` : "";
  const pickerHtml =
    picker.folders.length < 2
      ? ""
      : `<div class="folder-picker"><label for="folder-select">Folder</label><select id="folder-select" aria-label="Active onboarding folder">${picker.folders
          .map((entry) => {
            const selected = entry.key === picker.currentKey ? " selected" : "";
            return `<option value="${escapeHtml(entry.key)}"${selected}>${escapeHtml(entry.label)}</option>`;
          })
          .join("")}</select></div>`;

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="Content-Security-Policy" content="${csp}" />
  <title>Turbine Onboarding</title>
  <style>
    body {
      font-family: var(--vscode-font-family);
      font-size: var(--vscode-font-size);
      color: var(--vscode-foreground);
      background: var(--vscode-sideBar-background);
      padding: 14px;
      position: relative;
      margin: 0;
    }
    h1 {
      font-size: 1.15em;
      font-weight: 600;
      margin: 0 0 8px 0;
      color: var(--vscode-foreground);
    }
    p {
      margin: 0 0 16px 0;
      line-height: 1.5;
      color: var(--vscode-descriptionForeground);
    }
    button.primary,
    button.choice {
      background: var(--vscode-button-background);
      color: var(--vscode-button-foreground);
      border: 1px solid transparent;
      border-radius: 6px;
      padding: 8px 14px;
      cursor: pointer;
      font-family: inherit;
      font-size: inherit;
      font-weight: 500;
      transition: background 80ms ease;
    }
    button.primary:hover,
    button.choice:hover {
      background: var(--vscode-button-hoverBackground);
    }
    .choices {
      display: flex;
      flex-direction: column;
      gap: 6px;
      margin: 0 0 12px 0;
    }
    button.choice {
      width: 100%;
      text-align: left;
    }
    .choice-list {
      display: flex;
      flex-direction: column;
      margin: 0 -14px;
      border-top: 1px solid var(--vscode-panel-border);
    }
    button.choice-row {
      display: grid;
      grid-template-columns: 44px 1fr 18px;
      align-items: center;
      gap: 4px;
      width: 100%;
      padding: 12px 14px;
      background: transparent;
      color: var(--vscode-foreground);
      border: none;
      border-bottom: 1px solid var(--vscode-panel-border);
      cursor: pointer;
      text-align: left;
      font-family: inherit;
      font-size: inherit;
      transition: background 80ms ease;
    }
    button.choice-row:hover {
      background: var(--vscode-list-hoverBackground);
    }
    .choice-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: 32px;
      height: 32px;
    }
    .choice-icon svg {
      width: 28px;
      height: 28px;
    }
    .choice-text {
      display: flex;
      flex-direction: column;
      gap: 2px;
      min-width: 0;
    }
    .choice-title {
      display: inline-flex;
      align-items: center;
      gap: 8px;
      font-size: 1em;
      font-weight: 600;
      color: var(--vscode-foreground);
    }
    .default-badge {
      display: inline-block;
      padding: 0px 6px;
      font-size: 0.62em;
      font-weight: 700;
      letter-spacing: 0.05em;
      color: #4FB78A;
      border: 1px solid #4FB78A;
      border-radius: 3px;
      line-height: 1.5;
    }
    .choice-package {
      font-family: var(--vscode-editor-font-family, monospace);
      font-size: 0.88em;
      color: var(--vscode-descriptionForeground);
      opacity: 0.85;
    }
    .choice-chevron {
      color: var(--vscode-descriptionForeground);
      opacity: 0.55;
      font-size: 1.2em;
      text-align: right;
    }
    button.dismiss {
      position: absolute;
      top: 6px;
      right: 6px;
      background: transparent;
      color: var(--vscode-foreground);
      border: none;
      cursor: pointer;
      font-size: 1.1em;
    }
    button.dismiss:hover {
      opacity: 0.7;
    }
    .folder-picker {
      display: flex;
      align-items: center;
      gap: 8px;
      margin-bottom: 12px;
    }
    .folder-picker label {
      font-size: 0.9em;
      opacity: 0.8;
    }
    .folder-picker select {
      flex: 1;
      background: var(--vscode-dropdown-background);
      color: var(--vscode-dropdown-foreground);
      border: 1px solid var(--vscode-dropdown-border);
      padding: 2px 6px;
      font-family: inherit;
      font-size: inherit;
    }
    .ready-header {
      display: flex;
      align-items: center;
      gap: 10px;
      margin: 0 0 14px 0;
    }
    .ready-header h1 {
      margin: 0;
      font-size: 1.1em;
      font-weight: 600;
    }
    .ready-check {
      flex-shrink: 0;
      display: inline-flex;
      color: var(--vscode-testing-iconPassed, #4FB78A);
    }
    .tour-progress {
      display: flex;
      gap: 6px;
      margin: 0 0 18px 0;
    }
    .tour-segment {
      flex: 1;
      height: 3px;
      border-radius: 2px;
      background: var(--vscode-foreground);
      opacity: 0.18;
    }
    .tour-segment.filled {
      opacity: 1;
      background: var(--vscode-button-background);
    }
    button.start-onboarding-cta {
      width: 100%;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      gap: 8px;
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 1em;
    }
    button.start-onboarding-cta .play {
      font-size: 0.85em;
    }
  </style>
</head>
<body>
  ${dismissHtml}
  ${pickerHtml}
  ${
    isReady
      ? readyCardHtml(card)
      : `<h1>${escapeHtml(card.title)}</h1>
  <p>${bodyHtml}</p>
  ${choicesHtml}
  ${buttonHtml}`
  }
  <script nonce="${cspNonce}">
    const vscode = acquireVsCodeApi();
    for (const button of document.querySelectorAll("button.primary")) {
      button.addEventListener("click", () => {
        const id = button.getAttribute("data-action");
        if (id !== null) vscode.postMessage({ type: "action", id });
      });
    }
    for (const button of document.querySelectorAll("button.choice, button.choice-row")) {
      button.addEventListener("click", () => {
        const id = button.getAttribute("data-choice-id");
        if (id !== null) vscode.postMessage({ type: "install-choice", choiceId: id });
      });
    }
    for (const button of document.querySelectorAll("button.dismiss")) {
      button.addEventListener("click", () => {
        vscode.postMessage({ type: "dismiss-phase" });
      });
    }
    const folderSelect = document.getElementById("folder-select");
    if (folderSelect !== null) {
      folderSelect.addEventListener("change", () => {
        vscode.postMessage({ type: "select-folder", folderKey: folderSelect.value });
      });
    }
  </script>
</body>
</html>`;
}

export class OnboardingViewProvider implements vscode.WebviewViewProvider {
  private readonly deps: OnboardingViewDeps;
  private currentView: vscode.WebviewView | null = null;
  private renderedKey: string | null = null;
  private readonly subscriptions: vscode.Disposable[] = [];

  constructor(deps: OnboardingViewDeps) {
    this.deps = deps;
    this.subscriptions.push(
      deps.phaseService.onPhaseChange(() => this.refresh()),
      deps.active.onDidChange(() => {
        this.renderedKey = null;
        this.refresh();
      }),
    );
  }

  resolveWebviewView(view: vscode.WebviewView): void {
    this.currentView = view;
    this.renderedKey = null;
    view.webview.options = { enableScripts: true, localResourceRoots: [this.deps.extensionUri] };
    const messageSubscription = view.webview.onDidReceiveMessage((message: IncomingMessage) =>
      this.handleMessage(message),
    );
    view.onDidDispose(() => {
      messageSubscription.dispose();
      if (this.currentView === view) {
        this.currentView = null;
        this.renderedKey = null;
      }
    });
    this.refresh();
  }

  async show(): Promise<void> {
    if (this.currentView !== null) {
      this.currentView.show(true);
      return;
    }
    await vscode.commands.executeCommand(SHOW_COMMAND);
    await vscode.commands.executeCommand(`${ONBOARDING_VIEW_ID}.focus`);
  }

  dispose(): void {
    for (const subscription of this.subscriptions) subscription.dispose();
    this.subscriptions.length = 0;
  }

  refreshFromExternal(): void {
    this.refresh();
  }

  private refresh(): void {
    const view = this.currentView;
    if (view === null) return;
    const phase = this.deps.phaseService.current;
    const folders = this.deps.active.folders;
    const currentKey = this.deps.active.currentKey;
    const completed = this.deps.completedToursMachineWide();
    const nextKey = phaseKey(phase, folders, currentKey, completed);
    if (this.renderedKey === nextKey) return;
    try {
      view.webview.html = renderHtml(view.webview, phase, { folders, currentKey }, completed);
      this.renderedKey = nextKey;
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      this.deps.logger(`[onboarding.view] refresh failed: ${reason}`);
    }
  }

  private async handleMessage(message: IncomingMessage): Promise<void> {
    try {
      await this.dispatch(message);
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      this.deps.logger(`[onboarding.view] action failed: ${reason}`);
    }
  }

  private async dispatch(message: IncomingMessage): Promise<void> {
    if (message.type === "action") {
      switch (message.id) {
        case "open-folder":
          await vscode.commands.executeCommand("workbench.action.files.openFolder");
          return;
        case "open-uv-guide":
          await vscode.env.openExternal(vscode.Uri.parse(UV_INSTALL_GUIDE_URL));
          return;
        case "retry-lsp":
          await this.deps.phaseService.refresh();
          return;
        case "init-python":
          // --package produces the src/<name>/ layout Turbine expects.
          // `default_layout_root()` in infra/config.py looks for that
          // directory; without it, layout.root falls back to the workspace
          // root and the scaffold lands flat instead of nested.
          await this.runInstallCommands(["uv init --package --python 3.13"]);
          await this.deps.phaseService.refresh();
          return;
        case "reset-onboarding":
          await this.runReset();
          return;
        case "start-onboarding":
          await vscode.commands.executeCommand(START_TOUR_COMMAND);
          return;
      }
      return;
    }
    if (message.type === "install-choice") {
      await this.runInstallForChoice(message.choiceId);
      return;
    }
    if (message.type === "dismiss-phase") {
      await this.runDismiss();
      return;
    }
    if (message.type === "select-folder") {
      this.deps.active.select(message.folderKey);
      return;
    }
  }

  private async runInstallForChoice(rawChoiceId: string): Promise<void> {
    const choiceId = rawChoiceId as DatabaseChoiceId;
    const phase = this.deps.phaseService.current;
    if (phase.kind === "needs-turbine-project") {
      await this.bootstrapWithChoice(choiceId);
      return;
    }
    const key = this.deps.active.currentKey;
    if (key === null) return;
    const phaseClient = this.deps.phaseClient(key);
    if (phaseClient === null) return;
    const { commands } = await phaseClient.installCommands({
      workspaceFolderUri: key,
      choice: choiceId,
    });
    await this.runInstallCommands(commands);
  }

  /**
   * Bootstrap path: LSP is gated off because `[tool.turbine]` is missing, so
   * we cannot ask the server for install commands. Use the hardcoded backend
   * map, then write the section that flips the gate, then offer reload.
   */
  private async bootstrapWithChoice(choiceId: DatabaseChoiceId): Promise<void> {
    const commands = BOOTSTRAP_INSTALL_COMMANDS[choiceId];
    await this.runInstallCommands(commands);
    const wrote = await this.writeTurbineSectionIfMissing();
    if (!wrote) return;
    const reload = "Reload Window";
    const choice = await vscode.window.showInformationMessage(
      "Added [tool.turbine] and installed Turbine. Reload the window to start the language server.",
      reload,
    );
    if (choice === reload) {
      await vscode.commands.executeCommand("workbench.action.reloadWindow");
    }
  }

  private async writeTurbineSectionIfMissing(): Promise<boolean> {
    const key = this.deps.active.currentKey;
    if (key === null) return false;
    const folderUri = vscode.Uri.parse(key);
    const pyprojectUri = vscode.Uri.joinPath(folderUri, "pyproject.toml");
    try {
      const existing = await vscode.workspace.fs.readFile(pyprojectUri);
      const text = new TextDecoder().decode(existing);
      if (/^\s*\[tool\.turbine\](\s|$)/m.test(text)) return true;
      const separator = text.endsWith("\n") ? "" : "\n";
      const next = `${text}${separator}\n[tool.turbine]\n`;
      await vscode.workspace.fs.writeFile(pyprojectUri, new TextEncoder().encode(next));
      return true;
    } catch (error) {
      this.deps.logger(
        `[onboarding.view] write [tool.turbine] failed: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
      return false;
    }
  }

  private async runInstallCommands(commands: readonly string[]): Promise<void> {
    const key = this.deps.active.currentKey;
    if (key === null) return;
    const runner = this.deps.installRunner(key);
    if (runner === null) return;
    const result = await runner.runInstall(commands);
    if (!result.ok) {
      this.deps.logger(
        `[onboarding.view] install failed at command "${result.failedCommand ?? ""}" with exit ${
          result.exitCode ?? "?"
        }`,
      );
    }
  }

  private async runDismiss(): Promise<void> {
    const key = this.deps.active.currentKey;
    if (key === null) return;
    const phase = this.deps.phaseService.current;
    if (phase.kind !== "lsp-phase") return;
    const phaseClient = this.deps.phaseClient(key);
    if (phaseClient === null) return;
    await phaseClient.dismiss({
      workspaceFolderUri: key,
      phaseKind: phase.dto.kind,
    });
  }

  private async runReset(): Promise<void> {
    const key = this.deps.active.currentKey;
    if (key === null) return;
    const phaseClient = this.deps.phaseClient(key);
    if (phaseClient === null) return;
    await phaseClient.reset({ workspaceFolderUri: key });
  }
}

function phaseKey(
  phase: EditorPhase,
  folders: readonly OnboardingFolder[],
  currentKey: string | null,
  machineWideCompleted: readonly string[],
): string {
  const folderIds = folders.map((entry) => entry.key).join(",");
  const pickerSlot = `${currentKey ?? ""}|${folderIds}`;
  const completedSlot = [...machineWideCompleted].sort((a, b) => a.localeCompare(b)).join(",");
  if (phase.kind === "needs-server") {
    return `needs-server:${phase.reason ?? ""}:${pickerSlot}:${completedSlot}`;
  }
  if (phase.kind === "needs-turbine-project") {
    return `needs-turbine-project:${phase.subKind}:${pickerSlot}:${completedSlot}`;
  }
  if (phase.kind === "lsp-phase") {
    return `lsp-phase:${phase.dto.kind}:${phase.dto.workspaceFolderUri}:${phase.dto.choices.length}:${phase.dto.tours.length}:${pickerSlot}:${completedSlot}`;
  }
  return `${phase.kind}:${pickerSlot}:${completedSlot}`;
}
