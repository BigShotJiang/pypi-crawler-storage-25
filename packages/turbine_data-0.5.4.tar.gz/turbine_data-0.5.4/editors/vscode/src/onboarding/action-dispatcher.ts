/**
 * Funnel for onboarding action invocations.
 *
 * ADR 0015: every UI binding that triggers an editor-only action (sidebar
 * button, Codelens Chip, panel hint) routes through this single dispatcher
 * so the LSP can observe the click via `turbine/onboarding/actionInvoked`.
 *
 * Two action kinds:
 * - LSP-routed (`run_validate`, `run_single_check`, `run_sandbox_checks`):
 *   the server-side request handlers publish into the action-invoked
 *   stream intrinsically; the editor MUST NOT also send `actionInvoked` for
 *   those kinds, otherwise the gate fires twice.
 * - Editor-only (everything else): the editor is the sole publisher; the
 *   dispatcher sends `actionInvoked` before running the underlying command.
 *
 * The notification is fire-and-forget — a dropped wire signal never blocks
 * the underlying command.
 */

import type { TurbineClient } from "../client";
import type { StepAction, StepActionKind } from "../types";

const LSP_ROUTED_KINDS: ReadonlySet<StepActionKind> = new Set<StepActionKind>([
  "run_validate",
  "run_single_check",
  "run_sandbox_checks",
]);

export interface ActiveTourSnapshot {
  readonly tourId: string;
  readonly stepId: string;
}

export interface ActionDispatcherDeps {
  /** Returns the active tour's identity, or null when no tour is running. */
  readonly activeTour: () => ActiveTourSnapshot | null;
  /** Returns the LSP client for the workspace folder. May be null on cold start. */
  readonly client: () => TurbineClient | null;
  /** Runs the underlying VS Code command. Tests inject a fake. */
  readonly executeCommand: (command: string, ...args: readonly unknown[]) => Thenable<unknown>;
  /** Opens an external URL (browser / OS handler). Tests inject a fake. */
  readonly openExternal: (url: string) => Thenable<boolean>;
  /** Logs failures from the fire-and-forget actionInvoked call. */
  readonly logger: (message: string) => void;
}

export class OnboardingActionDispatcher {
  private readonly deps: ActionDispatcherDeps;

  constructor(deps: ActionDispatcherDeps) {
    this.deps = deps;
  }

  /**
   * Run a VS Code command on behalf of an editor-only or LSP-routed onboarding
   * action. For editor-only kinds, fires `actionInvoked` to the LSP first so
   * the active step's `ActionFired` watcher unlocks the gate.
   */
  async dispatch(kind: StepActionKind, command: string, ...args: readonly unknown[]): Promise<unknown> {
    this.notifyIfEditorOnly(kind);
    return this.deps.executeCommand(command, ...args);
  }

  /**
   * Open an external URL on behalf of an editor-only action. Always fires
   * `actionInvoked`. Used for `open_dashboard`, `open_data_swagger`,
   * `open_management_swagger`.
   */
  async openUrl(kind: StepActionKind, url: string): Promise<boolean> {
    this.notifyIfEditorOnly(kind);
    return this.deps.openExternal(url);
  }

  /**
   * Fire `actionInvoked` without an underlying command. Used when the user
   * confirms they performed an out-of-editor action (e.g. ran a CLI command
   * in their terminal) so the gate can unlock without the editor running
   * anything itself.
   */
  notify(kind: StepActionKind): void {
    this.notifyIfEditorOnly(kind);
  }

  /**
   * Resolve a typed `StepAction` into the right interaction (command, URL,
   * or notify-only) and dispatch it. The panel calls this when the user
   * clicks the action button on an ACTION-kind step.
   */
  async dispatchStepAction(action: StepAction): Promise<void> {
    const kind = action.kind;
    switch (kind) {
      case "run_validate":
        await this.dispatch(kind, "turbine.validateContract");
        return;
      case "run_single_check":
        await this.dispatch(kind, "turbine.runSingleCheck");
        return;
      case "run_sandbox_checks":
        await this.dispatch(kind, "turbine.runQualityWorkspace");
        return;
      case "open_add_check": {
        const args = [action.file, action.dataset].filter((arg): arg is string => typeof arg === "string");
        await this.dispatch(kind, "turbine.addCheck", ...args);
        return;
      }
      case "open_dashboard":
      case "open_data_swagger":
      case "open_management_swagger":
        if (typeof action.url !== "string" || action.url === "") {
          this.deps.logger(`[onboarding] ${kind} action has no url; firing notify-only`);
          this.notify(kind);
          return;
        }
        await this.openUrl(kind, action.url);
        return;
      case "generate_api":
      case "start_api_server":
        // No editor-side command exists for these; the user runs the
        // matching `uv run turbine ...` in their terminal. The button
        // confirms the action was performed and unlocks the gate.
        this.notify(kind);
        return;
      case "final_handoff":
        await this.dispatch(kind, "turbine.datasources.newDatasource");
        return;
      case "none":
        return;
    }
  }

  private notifyIfEditorOnly(kind: StepActionKind): void {
    if (LSP_ROUTED_KINDS.has(kind)) return;
    const tour = this.deps.activeTour();
    const client = this.deps.client();
    if (tour === null || client === null) return;
    void client.actionInvoked({ tourId: tour.tourId, stepId: tour.stepId, kind }).catch((error: unknown) => {
      const message = error instanceof Error ? error.message : String(error);
      this.deps.logger(`[onboarding] actionInvoked failed for ${kind}: ${message}`);
    });
  }
}
