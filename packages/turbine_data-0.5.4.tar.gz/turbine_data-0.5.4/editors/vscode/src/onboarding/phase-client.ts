/**
 * Typed wrapper around the LSP for the onboarding-phase wire methods.
 *
 * One instance per workspace folder (mirroring `TurbineClient`). The class
 * subscribes to the server-pushed `turbine/onboardingPhase` notification and
 * re-emits it through its own `onPhaseChanged` event. Callers go through
 * `installCommands`, `dismiss`, and `reset` for the three RPC requests so
 * the rest of the codebase never builds a custom JSON-RPC payload by hand.
 */

import { type Disposable, type Event, EventEmitter } from "vscode";
import type { LanguageClient } from "vscode-languageclient/node";

export type Phase = "needs-pyproject" | "needs-turbine" | "ready-tour-pending" | "ready";
export type DatabaseChoiceId = "postgres" | "snowflake" | "duckdb" | "lsp-only";

export interface DatabaseChoice {
  readonly id: DatabaseChoiceId;
  readonly label: string;
  readonly description: string;
}

export interface TourEntry {
  readonly id: string;
  readonly title: string;
  readonly completed: boolean;
}

export interface PrimaryAction {
  readonly id: string;
  readonly label: string;
}

export interface PhaseDto {
  readonly workspaceFolderUri: string;
  readonly kind: Phase;
  readonly title: string;
  readonly body: string;
  readonly choices: readonly DatabaseChoice[];
  readonly tours: readonly TourEntry[];
  readonly primaryAction: PrimaryAction | null;
}

export interface InstallCommandsParams {
  readonly workspaceFolderUri: string;
  readonly choice: DatabaseChoiceId;
}

export interface InstallCommandsResult {
  readonly commands: readonly string[];
}

export interface OnboardingDismissParams {
  readonly workspaceFolderUri: string;
  readonly phaseKind: Phase;
}

export interface OnboardingResetParams {
  readonly workspaceFolderUri: string;
}

export const PHASE_METHODS = {
  PHASE: "turbine/onboardingPhase",
  INSTALL_COMMANDS: "turbine/onboarding/installCommands",
  DISMISS: "turbine/onboarding/dismiss",
  RESET: "turbine/onboarding/reset",
} as const;

export class PhaseClient implements Disposable {
  private readonly emitter = new EventEmitter<PhaseDto>();
  private readonly subscription: Disposable;
  private latest: PhaseDto | null = null;

  constructor(private readonly lsp: LanguageClient) {
    this.subscription = lsp.onNotification(PHASE_METHODS.PHASE, (raw: unknown) => {
      const dto = raw as PhaseDto;
      this.latest = dto;
      this.emitter.fire(dto);
    });
  }

  get current(): PhaseDto | null {
    return this.latest;
  }

  get onPhaseChanged(): Event<PhaseDto> {
    return this.emitter.event;
  }

  async installCommands(params: InstallCommandsParams): Promise<InstallCommandsResult> {
    const raw = await this.lsp.sendRequest(PHASE_METHODS.INSTALL_COMMANDS, params);
    return raw as InstallCommandsResult;
  }

  async dismiss(params: OnboardingDismissParams): Promise<void> {
    await this.lsp.sendRequest(PHASE_METHODS.DISMISS, params);
  }

  async reset(params: OnboardingResetParams): Promise<void> {
    await this.lsp.sendRequest(PHASE_METHODS.RESET, params);
  }

  dispose(): void {
    this.subscription.dispose();
    this.emitter.dispose();
  }
}
