import * as childProcess from "node:child_process";

import type { UvProbe } from "./editor-phase";

export class ChildProcessUvProbe implements UvProbe {
  private readonly binary: string;

  constructor(binary: string = "uv") {
    this.binary = binary;
  }

  isAvailable(): Promise<boolean> {
    return new Promise<boolean>((resolve) => {
      childProcess.execFile(this.binary, ["--version"], (error) => {
        resolve(error === null);
      });
    });
  }
}
