import * as vscode from "vscode";
import { State as LspState } from "vscode-languageclient/node";

import type { TurbineClient } from "../client";
import type { ActiveOnboardingFolder } from "./active-folder";
import type { LspClientState, LspClientStateSource, ServerPhaseSource } from "./editor-phase";
import type { PhaseClient, PhaseDto } from "./phase-client";

export class ServerPhaseAggregator implements ServerPhaseSource, vscode.Disposable {
  private readonly emitter = new vscode.EventEmitter<PhaseDto>();
  private readonly currentEmitter = new vscode.EventEmitter<void>();
  private readonly subscriptions = new Map<string, vscode.Disposable>();
  private readonly latestByKey = new Map<string, PhaseDto>();
  private readonly activeChangeSubscription: vscode.Disposable;

  constructor(private readonly active: ActiveOnboardingFolder) {
    this.activeChangeSubscription = active.onDidChange(() => this.republish());
  }

  get current(): PhaseDto | null {
    const key = this.active.currentKey;
    if (key === null) return null;
    return this.latestByKey.get(key) ?? null;
  }

  onPhaseChange(listener: (dto: PhaseDto) => void): vscode.Disposable {
    return this.emitter.event(listener);
  }

  onCurrentChange(listener: () => void): vscode.Disposable {
    return this.currentEmitter.event(listener);
  }

  attach(key: string, phaseClient: PhaseClient): void {
    this.detach(key);
    const subscription = phaseClient.onPhaseChanged((dto) => {
      this.latestByKey.set(key, dto);
      if (key === this.active.currentKey) this.emitter.fire(dto);
    });
    this.subscriptions.set(key, subscription);
  }

  detach(key: string): void {
    const subscription = this.subscriptions.get(key);
    if (subscription !== undefined) {
      subscription.dispose();
      this.subscriptions.delete(key);
    }
    this.latestByKey.delete(key);
  }

  dispose(): void {
    this.activeChangeSubscription.dispose();
    for (const subscription of this.subscriptions.values()) subscription.dispose();
    this.subscriptions.clear();
    this.latestByKey.clear();
    this.emitter.dispose();
    this.currentEmitter.dispose();
  }

  private republish(): void {
    this.currentEmitter.fire();
    const key = this.active.currentKey;
    if (key === null) return;
    const dto = this.latestByKey.get(key);
    if (dto === undefined) return;
    this.emitter.fire(dto);
  }
}

export class LspClientStateAggregator implements LspClientStateSource, vscode.Disposable {
  private readonly emitter = new vscode.EventEmitter<LspClientState>();
  private readonly subscriptions = new Map<string, vscode.Disposable>();
  private readonly errorByKey = new Map<string, string>();
  private readonly clientLookup: () => Iterable<readonly [string, TurbineClient]>;
  private cachedState: LspClientState = "stopped";

  constructor(clientLookup: () => Iterable<readonly [string, TurbineClient]>) {
    this.clientLookup = clientLookup;
  }

  get currentState(): LspClientState {
    return this.aggregateState();
  }

  get lastErrorMessage(): string | null {
    if (this.errorByKey.size === 0) return null;
    const last = [...this.errorByKey.values()].at(-1);
    return last ?? null;
  }

  onDidChangeState(listener: (state: LspClientState) => void): vscode.Disposable {
    return this.emitter.event(listener);
  }

  attach(key: string, client: TurbineClient): void {
    this.unsubscribe(key);
    const subscription = client.lsp.onDidChangeState(() => this.publishIfChanged());
    this.subscriptions.set(key, subscription);
    this.publishIfChanged();
  }

  unsubscribe(key: string): void {
    const subscription = this.subscriptions.get(key);
    if (subscription !== undefined) {
      subscription.dispose();
      this.subscriptions.delete(key);
    }
    this.publishIfChanged();
  }

  forget(key: string): void {
    this.unsubscribe(key);
    this.errorByKey.delete(key);
  }

  recordError(key: string, message: string): void {
    this.errorByKey.delete(key);
    this.errorByKey.set(key, message);
    this.publishIfChanged();
  }

  clearError(key: string): void {
    this.errorByKey.delete(key);
  }

  dispose(): void {
    for (const subscription of this.subscriptions.values()) subscription.dispose();
    this.subscriptions.clear();
    this.emitter.dispose();
  }

  private aggregateState(): LspClientState {
    let anyStarting = false;
    for (const [, client] of this.clientLookup()) {
      const state = client.lsp.state;
      if (state === LspState.Running) return "running";
      if (state === LspState.Starting) anyStarting = true;
    }
    return anyStarting ? "starting" : "stopped";
  }

  private publishIfChanged(): void {
    const next = this.aggregateState();
    if (next === this.cachedState) return;
    this.cachedState = next;
    this.emitter.fire(next);
  }
}
