/**
 * Editor-side runtime for guided tours.
 *
 * The engine drives steps through the Onboarding Panel webview channel. It
 * delegates demo scaffolding to the LSP via `turbine/scaffoldProject`, checks
 * workspace emptiness via `turbine/checkWorkspaceEmpty`, and only ever writes
 * files at the workspace root (no nested sandbox). When the workspace is not
 * empty for the tour, the engine surfaces a redirect so the panel can open a
 * fresh-folder picker rather than scaffolding into user content.
 *
 * Every collaborator is constructor-injected: `TurbineClient` factory for the
 * LSP wire, `TourPanelChannel` for outbound webview messages,
 * `TourProgressStore` for LSP-backed persistence, `CompletedToursStore` for
 * editor `globalState`, `dispatchStepAction` for routing action-step clicks
 * through the onboarding action dispatcher (so the LSP's ActionFired watcher
 * hears the click), and `schedule` for the deterministic timer.
 */

import type { Disposable } from "vscode";

import type { TurbineClient } from "../client";
import type {
  CheckWorkspaceEmptyResult,
  ResolvedHighlight,
  ScaffoldProjectResult,
  StepAction,
  StepCompletedParams,
  StepDto,
  TourDto,
} from "../types";

const HINT_DELAY_MS = 200;

export type TourEngineOutbound =
  | { readonly type: "tour-preparing-scaffold"; readonly tourId: string }
  | {
      readonly type: "tour-step";
      readonly tourId: string;
      readonly step: StepDto;
      readonly index: number;
      readonly total: number;
    }
  | {
      readonly type: "tour-step-completed";
      readonly tourId: string;
      readonly stepId: string;
    }
  | {
      // Sent when the LSP signals stepCompleted for the active gated step.
      // The panel flips Next from disabled to enabled and hides Skip.
      readonly type: "tour-step-unlocked";
      readonly tourId: string;
      readonly stepId: string;
    }
  | { readonly type: "tour-finished"; readonly tourId: string }
  | { readonly type: "tour-final-handoff-prompt"; readonly tourId: string }
  | {
      // Workspace has user content that the demo would either overwrite or
      // sit awkwardly next to. The panel renders a "Pick an empty folder"
      // button that calls the folder picker.
      readonly type: "tour-needs-fresh-folder";
      readonly tourId: string;
      readonly reasons: readonly string[];
    }
  | {
      readonly type: "tour-error";
      readonly tourId: string;
      readonly message: string;
    };

export type TourEnginePanelMessage =
  | { readonly type: "start-tour"; readonly tourId: string; readonly folderUri: string }
  | { readonly type: "tour-next-step"; readonly tourId: string }
  | { readonly type: "tour-prev-step"; readonly tourId: string }
  | {
      readonly type: "tour-skip-step";
      readonly tourId: string;
      readonly stepId: string;
    }
  | {
      readonly type: "tour-restart";
      readonly tourId: string;
      readonly folderUri: string;
    }
  | { readonly type: "tour-final-handoff-confirmed"; readonly tourId: string };

export interface TourPanelChannel {
  post(message: TourEngineOutbound): void;
}

export interface TourProgressRecord {
  readonly workspaceFolderUri: string;
  readonly tourId: string;
  readonly lastStepId: string | null;
  readonly completedStepIds: readonly string[];
  readonly finished: boolean;
}

export interface TourProgressStore {
  load(workspaceFolderUri: string, tourId: string): Promise<TourProgressRecord | null>;
  save(record: TourProgressRecord): Promise<void>;
}

export interface CompletedToursStore {
  list(): readonly string[];
  markCompleted(tourId: string): Promise<void>;
  clear(): Promise<void>;
}

export interface TourTargetReveal {
  /**
   * Open the file at the resolved highlight (if any) and reveal/select the
   * range.
   *
   * - ``target.file`` is workspace-relative (e.g. ``contracts/foo.yml``) —
   *   the adapter joins it with ``workspaceRoot`` to get an absolute path.
   * - ``target.range`` is **1-indexed** for both line and column (Turbine
   *   convention) — the adapter subtracts 1 before handing to vscode APIs.
   * - ``target === null`` means narration step, no highlight.
   * - ``target.kind === "ui_target"`` means a sidebar/explorer hint, not an
   *   editor range — the adapter may skip it.
   */
  reveal(workspaceRoot: string, target: ResolvedHighlight | null): Promise<void>;
}

export interface TourEngineDeps {
  readonly client: (folderUri: string) => TurbineClient | null;
  readonly workspaceRootFor: (folderUri: string) => string;
  readonly progress: TourProgressStore;
  readonly completed: CompletedToursStore;
  readonly channel: TourPanelChannel;
  /**
   * Dispatch an action-step's StepAction through the onboarding action
   * dispatcher. Handles the LSP `actionInvoked` notification (for editor-
   * only kinds) and runs the underlying interaction.
   */
  readonly dispatchStepAction: (action: StepAction) => Promise<void>;
  readonly reveal: TourTargetReveal;
  readonly logger: (message: string) => void;
  readonly schedule: (callback: () => void, delayMs: number) => Disposable;
}

interface ActiveTour {
  readonly tourId: string;
  readonly folderUri: string;
  readonly steps: readonly StepDto[];
  index: number;
  readonly completedStepIds: string[];
  // Per-tour-run latch of step ids the user has unlocked via Skip or via
  // an LSP stepCompleted notification. Once a step is in here, Next stays
  // enabled even if the user retreats and returns; the latch is cleared
  // when the active tour is replaced or disposed.
  readonly unlockedStepIds: Set<string>;
  watcherSubscription: Disposable | null;
}

export class TourEngine implements Disposable {
  private readonly deps: TourEngineDeps;
  private active: ActiveTour | null = null;
  private cachedTours: readonly TourDto[] | null = null;

  constructor(deps: TourEngineDeps) {
    this.deps = deps;
  }

  /**
   * Return the active tour's identity (tourId + current stepId) or null when
   * no tour is running. Read by the action dispatcher so editor-only action
   * invocations carry the right context to the LSP.
   */
  activeSnapshot(): { tourId: string; stepId: string } | null {
    const active = this.active;
    if (active === null) return null;
    const step = active.steps[active.index];
    if (step === undefined) return null;
    return { tourId: active.tourId, stepId: step.id };
  }

  async handle(message: TourEnginePanelMessage): Promise<void> {
    switch (message.type) {
      case "start-tour":
        await this.startOrResume(message.tourId, message.folderUri);
        return;
      case "tour-next-step":
        await this.advance(message.tourId);
        return;
      case "tour-prev-step":
        await this.retreat(message.tourId);
        return;
      case "tour-skip-step":
        this.latchSkipped(message.tourId, message.stepId);
        await this.advance(message.tourId);
        return;
      case "tour-restart":
        await this.startTour(message.tourId, message.folderUri);
        return;
      case "tour-final-handoff-confirmed": {
        const active = this.active;
        if (active === null) return;
        const currentStep = active.steps[active.index];
        if (currentStep === undefined) return;
        const action = currentStep.action;
        if (action === null) return;
        await this.deps.dispatchStepAction(action);
        return;
      }
    }
  }

  private async startOrResume(tourId: string, folderUri: string): Promise<void> {
    const saved = await this.deps.progress.load(folderUri, tourId);
    if (saved !== null && !saved.finished) {
      // Resume picks the saved index and posts the current step without
      // re-checking emptiness or re-scaffolding — the demo content is
      // already in place.
      const tour = await this.findTour(folderUri, tourId);
      if (tour === null) return;
      const indexAfterLast = this.indexAfterLastCompleted(tour, saved);
      this.bindActive(tour, folderUri, indexAfterLast, saved.completedStepIds);
      await this.presentCurrentStep();
      return;
    }
    await this.startTour(tourId, folderUri);
  }

  dispose(): void {
    this.detachWatcher();
    this.active = null;
  }

  private async startTour(tourId: string, folderUri: string): Promise<void> {
    const client = this.deps.client(folderUri);
    if (client === null) {
      this.deps.channel.post({
        type: "tour-error",
        tourId,
        message: "Turbine LSP is not running for this folder.",
      });
      return;
    }
    // Scaffolding goes ahead unconditionally; when the workspace is not
    // empty, the LSP fires a server -> client `turbine/onboarding/confirmScaffold`
    // request and we ask the user via a modal. A refusal comes back as an
    // empty manifest, which we treat as cancellation — no error toast, no
    // step navigation, the panel stays on the tour picker so the user can
    // back out cleanly.
    const scaffold = await this.scaffoldWithHint(tourId, client);
    if (scaffold === null) return;
    if (scaffold.createdFiles.length === 0 && !(await this.scaffoldAlreadyPresent(client))) {
      // User declined the consent modal. Silently return; the panel keeps
      // its prior state instead of advancing into a half-set-up tour.
      return;
    }
    await this.beginTour(tourId, folderUri);
  }

  private async scaffoldAlreadyPresent(client: TurbineClient): Promise<boolean> {
    // After a confirmed scaffold, an empty createdFiles list means "every
    // file was already there" (idempotent re-run). After a refusal, it means
    // "nothing was written". The two cases share a payload but differ on
    // whether the marker exists — checkWorkspaceEmpty surfaces the marker.
    try {
      const result = await client.checkWorkspaceEmpty();
      // empty=true means the marker is present OR the workspace is bare —
      // either way it's safe to begin the tour.
      return result.empty;
    } catch {
      return false;
    }
  }

  private async checkEmpty(
    client: TurbineClient,
    tourId: string,
  ): Promise<CheckWorkspaceEmptyResult | null> {
    try {
      return await client.checkWorkspaceEmpty();
    } catch (error) {
      this.deps.channel.post({
        type: "tour-error",
        tourId,
        message: `Workspace empty-check failed: ${error instanceof Error ? error.message : String(error)}`,
      });
      return null;
    }
  }

  private async scaffoldWithHint(tourId: string, client: TurbineClient): Promise<ScaffoldProjectResult | null> {
    let scaffoldDone = false;
    const hint = this.deps.schedule(() => {
      if (!scaffoldDone) {
        this.deps.channel.post({ type: "tour-preparing-scaffold", tourId });
      }
    }, HINT_DELAY_MS);
    try {
      return await client.scaffoldProject({ variant: "demo" });
    } catch (error) {
      this.deps.channel.post({
        type: "tour-error",
        tourId,
        message: `Scaffold failed: ${error instanceof Error ? error.message : String(error)}`,
      });
      return null;
    } finally {
      scaffoldDone = true;
      hint.dispose();
    }
  }

  private async beginTour(tourId: string, folderUri: string): Promise<void> {
    const tour = await this.findTour(folderUri, tourId);
    if (tour === null) return;
    this.bindActive(tour, folderUri, 0, []);
    await this.presentCurrentStep();
  }

  private bindActive(
    tour: TourDto,
    folderUri: string,
    index: number,
    completedStepIds: readonly string[],
  ): void {
    this.detachWatcher();
    this.active = {
      tourId: tour.id,
      folderUri,
      steps: tour.steps,
      index,
      completedStepIds: [...completedStepIds],
      unlockedStepIds: new Set<string>(),
      watcherSubscription: null,
    };
  }

  private async presentCurrentStep(): Promise<void> {
    const active = this.active;
    if (active === null) return;
    if (active.index >= active.steps.length) {
      await this.finishActive();
      return;
    }
    const step = active.steps[active.index];
    if (step === undefined) return;
    this.deps.channel.post({
      type: "tour-step",
      tourId: active.tourId,
      step,
      index: active.index,
      total: active.steps.length,
    });
    await this.deps.reveal.reveal(this.deps.workspaceRootFor(active.folderUri), step.resolvedTarget);
    if (step.gated === true && !active.unlockedStepIds.has(step.id)) {
      await this.attachWatcher(active.tourId, step.id, active.folderUri);
    }
  }

  private async attachWatcher(tourId: string, stepId: string, folderUri: string): Promise<void> {
    const client = this.deps.client(folderUri);
    if (client === null) return;
    this.detachWatcher();
    const subscription = client.onStepCompleted((params: StepCompletedParams) => {
      if (params.tourId !== tourId || params.stepId !== stepId) return;
      this.onStepCompletedFromServer(params);
    });
    if (this.active !== null) this.active.watcherSubscription = subscription;
    await client.watchStep({ tourId, stepId });
  }

  private detachWatcher(): void {
    if (this.active === null || this.active.watcherSubscription === null) return;
    this.active.watcherSubscription.dispose();
    this.active.watcherSubscription = null;
    const client = this.deps.client(this.active.folderUri);
    if (client === null) return;
    // Fire-and-forget: the server's watcher slot otherwise stays pinned to
    // the last step and would re-fire stale step-completed events on
    // reconnect. We don't await because dispose paths run synchronously.
    void client.unwatchStep().catch((error) => {
      this.deps.logger(
        `[tour-engine] unwatchStep failed: ${error instanceof Error ? error.message : String(error)}`,
      );
    });
  }

  private onStepCompletedFromServer(params: StepCompletedParams): void {
    // ADR 0015: do NOT auto-advance. Record the unlock in the per-run
    // latch and post tour-step-unlocked so the panel flips Next from
    // disabled to enabled. The user always presses Next themselves.
    const active = this.active;
    if (active?.tourId !== params.tourId) return;
    active.unlockedStepIds.add(params.stepId);
    this.detachWatcher();
    this.deps.channel.post({
      type: "tour-step-unlocked",
      tourId: params.tourId,
      stepId: params.stepId,
    });
  }

  // Skip latches the step locally before advancing so that retreat-and-
  // return doesn't re-lock it. The user gesture is "I don't want to do
  // this myself, do it for me, move on" — the gate is satisfied as far as
  // the editor is concerned. Detach the LSP watcher first so a late-firing
  // stepCompleted from the side effect can't re-arm the gate.
  private latchSkipped(tourId: string, stepId: string): void {
    const active = this.active;
    if (active?.tourId !== tourId) return;
    active.unlockedStepIds.add(stepId);
    this.detachWatcher();
  }

  private async advance(tourId: string): Promise<void> {
    const active = this.active;
    if (active?.tourId !== tourId) return;
    const currentStep = active.steps[active.index];
    if (currentStep === undefined) return;
    if (this.isFinalHandoffStep(currentStep)) {
      this.deps.channel.post({ type: "tour-final-handoff-prompt", tourId });
      return;
    }
    this.detachWatcher();
    if (!active.completedStepIds.includes(currentStep.id)) {
      active.completedStepIds.push(currentStep.id);
    }
    this.deps.channel.post({
      type: "tour-step-completed",
      tourId,
      stepId: currentStep.id,
    });
    active.index += 1;
    await this.persistProgress(active, false, currentStep.id);
    await this.presentCurrentStep();
  }

  // Step back one position. Saved progress (lastStepId, completedStepIds) is
  // unchanged: going back is a transient navigation, not a regression — if
  // the user closes and reopens the tour, they should resume at the furthest
  // step they reached, not the one they retreated to.
  private async retreat(tourId: string): Promise<void> {
    const active = this.active;
    if (active?.tourId !== tourId) return;
    if (active.index === 0) return;
    this.detachWatcher();
    active.index -= 1;
    await this.presentCurrentStep();
  }

  private async finishActive(): Promise<void> {
    const active = this.active;
    if (active === null) return;
    const lastStep = active.steps.at(-1);
    const lastStepId = lastStep === undefined ? null : lastStep.id;
    await this.persistProgress(active, true, lastStepId);
    await this.deps.completed.markCompleted(active.tourId);
    this.deps.channel.post({ type: "tour-finished", tourId: active.tourId });
    this.detachWatcher();
    this.active = null;
  }

  private async persistProgress(
    active: ActiveTour,
    finished: boolean,
    lastStepId: string | null,
  ): Promise<void> {
    await this.deps.progress.save({
      workspaceFolderUri: active.folderUri,
      tourId: active.tourId,
      lastStepId,
      completedStepIds: [...active.completedStepIds],
      finished,
    });
  }

  private isFinalHandoffStep(step: StepDto): boolean {
    return step.action !== null && step.action !== undefined && step.action.kind === "final_handoff";
  }

  private async findTour(folderUri: string, tourId: string): Promise<TourDto | null> {
    if (this.cachedTours === null) {
      const client = this.deps.client(folderUri);
      if (client === null) {
        this.deps.channel.post({
          type: "tour-error",
          tourId,
          message: "Turbine LSP is not running for this folder.",
        });
        return null;
      }
      const result = await client.listTours();
      this.cachedTours = result.tours;
    }
    return this.cachedTours.find((tour) => tour.id === tourId) ?? null;
  }

  private indexAfterLastCompleted(tour: TourDto, record: TourProgressRecord): number {
    if (record.lastStepId === null) return 0;
    const lastIndex = tour.steps.findIndex((step) => step.id === record.lastStepId);
    if (lastIndex === -1) return 0;
    return Math.min(lastIndex + 1, tour.steps.length);
  }
}
