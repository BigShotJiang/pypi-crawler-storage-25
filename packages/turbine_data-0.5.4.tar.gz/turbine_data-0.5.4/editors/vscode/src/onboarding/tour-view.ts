import * as crypto from "node:crypto";

import * as vscode from "vscode";

import type { ActiveOnboardingFolder, OnboardingFolder } from "./active-folder";
import type { EditorPhase, EditorPhaseService } from "./editor-phase";
import type { Phase, TourEntry } from "./phase-client";
import { pickFreshTourFolder } from "./tour-folder-picker";
import type { TourEngine, TourEngineOutbound, TourProgressStore } from "./tour-engine";

export const ONBOARDING_TOUR_PANEL_ID = "turbine.onboardingTour";
const TOUR_PANEL_TITLE = "Turbine Onboarding";

export interface OnboardingTourViewDeps {
  readonly extensionUri: vscode.Uri;
  readonly phaseService: EditorPhaseService;
  readonly active: ActiveOnboardingFolder;
  readonly tourEngine: TourEngine;
  readonly tourProgress: TourProgressStore;
  readonly completedToursMachineWide: () => readonly string[];
  readonly logger: (message: string) => void;
}

interface CardTour {
  readonly id: string;
  readonly title: string;
  readonly completed: boolean;
  readonly completedSteps: number;
}

interface PhaseDataPayload {
  readonly type: "phase-data";
  readonly tours: readonly CardTour[];
  readonly phaseKind: Phase | null;
  readonly workspaceFolderUri: string;
  readonly machineWideCompleted: readonly string[];
  readonly folders: readonly OnboardingFolder[];
  readonly currentFolderKey: string | null;
}

type TourViewOutbound = PhaseDataPayload | TourEngineOutbound;

type TourViewInbound =
  | { readonly type: "start-tour"; readonly tourId: string }
  | { readonly type: "tour-next-step"; readonly tourId: string }
  | { readonly type: "tour-prev-step"; readonly tourId: string }
  | {
      readonly type: "tour-skip-step";
      readonly tourId: string;
      readonly stepId: string;
    }
  | { readonly type: "tour-pick-fresh-folder" }
  | { readonly type: "tour-final-handoff-confirmed"; readonly tourId: string }
  | { readonly type: "select-folder"; readonly folderKey: string }
  | { readonly type: "close-tour-view" };

function nonce(): string {
  return crypto.randomBytes(16).toString("base64").replace(/[+/=]/g, "");
}

export class OnboardingTourPanel implements vscode.Disposable {
  private readonly deps: OnboardingTourViewDeps;
  private panel: vscode.WebviewPanel | null = null;
  private readonly subscriptions: vscode.Disposable[] = [];

  constructor(deps: OnboardingTourViewDeps) {
    this.deps = deps;
    this.subscriptions.push(
      deps.phaseService.onPhaseChange(() => this.refresh()),
      deps.active.onDidChange(() => this.refresh()),
    );
  }

  postToWebview(message: TourEngineOutbound): void {
    this.send(message);
  }

  refreshFromExternal(): void {
    void this.refresh();
  }

  show(): void {
    if (this.panel !== null) {
      this.panel.reveal(vscode.ViewColumn.Beside, false);
      return;
    }
    const panel = vscode.window.createWebviewPanel(
      ONBOARDING_TOUR_PANEL_ID,
      TOUR_PANEL_TITLE,
      { viewColumn: vscode.ViewColumn.Beside, preserveFocus: false },
      {
        enableScripts: true,
        retainContextWhenHidden: true,
        localResourceRoots: [vscode.Uri.joinPath(this.deps.extensionUri, "media", "onboarding")],
      },
    );
    panel.iconPath = vscode.Uri.joinPath(this.deps.extensionUri, "icon.png");
    panel.webview.html = renderHtml(panel.webview, this.deps.extensionUri);
    const messageSubscription = panel.webview.onDidReceiveMessage((message: TourViewInbound) =>
      this.handleMessage(message),
    );
    const disposeSubscription = panel.onDidDispose(() => {
      messageSubscription.dispose();
      disposeSubscription.dispose();
      if (this.panel === panel) this.panel = null;
    });
    this.panel = panel;
    void this.refresh();
  }

  /** Current column of the panel; undefined when not open. */
  get viewColumn(): vscode.ViewColumn | undefined {
    return this.panel?.viewColumn;
  }

  dispose(): void {
    for (const subscription of this.subscriptions) subscription.dispose();
    this.subscriptions.length = 0;
    if (this.panel !== null) {
      this.panel.dispose();
      this.panel = null;
    }
  }

  // Two-pass refresh: first paint syncs the picker structure (titles, completion
  // flags) so the webview never sits empty; the async pass enriches each card
  // with completedSteps from the LSP-backed progress store and reposts.
  private async refresh(): Promise<void> {
    const initial = this.buildPhaseDataPayload({});
    if (initial === null) return;
    this.send(initial);
    if (initial.workspaceFolderUri === "") return;
    const completedByTour: Record<string, number> = {};
    await Promise.all(
      initial.tours.map(async (tour) => {
        try {
          const record = await this.deps.tourProgress.load(initial.workspaceFolderUri, tour.id);
          completedByTour[tour.id] = record !== null ? record.completedStepIds.length : 0;
        } catch (error) {
          const reason = error instanceof Error ? error.message : String(error);
          this.deps.logger(`[onboarding.tour-view] progress load failed for ${tour.id}: ${reason}`);
        }
      }),
    );
    const enriched = this.buildPhaseDataPayload(completedByTour);
    if (enriched === null) return;
    this.send(enriched);
  }

  private buildPhaseDataPayload(completedByTour: Record<string, number>): PhaseDataPayload | null {
    const phase = this.deps.phaseService.current;
    const tours = phaseTours(phase, completedByTour);
    if (tours === null) return null;
    return {
      type: "phase-data",
      tours: tours.entries,
      phaseKind: tours.phaseKind,
      workspaceFolderUri: tours.workspaceFolderUri,
      machineWideCompleted: this.deps.completedToursMachineWide(),
      folders: this.deps.active.folders,
      currentFolderKey: this.deps.active.currentKey,
    };
  }

  private send(message: TourViewOutbound): void {
    const panel = this.panel;
    if (panel === null) return;
    void panel.webview.postMessage(message);
  }

  private async handleMessage(message: TourViewInbound): Promise<void> {
    try {
      await this.dispatch(message);
    } catch (error) {
      const reason = error instanceof Error ? error.message : String(error);
      this.deps.logger(`[onboarding.tour-view] action failed: ${reason}`);
    }
  }

  private async dispatch(message: TourViewInbound): Promise<void> {
    if (message.type === "close-tour-view") {
      if (this.panel !== null) this.panel.dispose();
      return;
    }
    if (message.type === "select-folder") {
      this.deps.active.select(message.folderKey);
      return;
    }
    if (message.type === "start-tour") {
      const folderUri = this.deps.active.currentKey;
      if (folderUri === null) return;
      await this.deps.tourEngine.handle({ type: "start-tour", tourId: message.tourId, folderUri });
      return;
    }
    if (message.type === "tour-next-step") {
      await this.deps.tourEngine.handle({ type: "tour-next-step", tourId: message.tourId });
      return;
    }
    if (message.type === "tour-prev-step") {
      await this.deps.tourEngine.handle({ type: "tour-prev-step", tourId: message.tourId });
      return;
    }
    if (message.type === "tour-skip-step") {
      await this.deps.tourEngine.handle({
        type: "tour-skip-step",
        tourId: message.tourId,
        stepId: message.stepId,
      });
      return;
    }
    if (message.type === "tour-final-handoff-confirmed") {
      await this.deps.tourEngine.handle({ type: "tour-final-handoff-confirmed", tourId: message.tourId });
      return;
    }
    if (message.type === "tour-pick-fresh-folder") {
      await pickFreshTourFolder();
    }
  }
}

function phaseTours(
  phase: EditorPhase,
  completedByTour: Record<string, number>,
): { entries: readonly CardTour[]; phaseKind: Phase | null; workspaceFolderUri: string } | null {
  if (phase.kind !== "lsp-phase") {
    return { entries: [], phaseKind: null, workspaceFolderUri: "" };
  }
  return {
    entries: phase.dto.tours.map((tour: TourEntry) => ({
      id: tour.id,
      title: tour.title,
      completed: tour.completed,
      completedSteps: completedByTour[tour.id] ?? 0,
    })),
    phaseKind: phase.dto.kind,
    workspaceFolderUri: phase.dto.workspaceFolderUri,
  };
}

function renderHtml(webview: vscode.Webview, extensionUri: vscode.Uri): string {
  const cspNonce = nonce();
  const mediaBaseUri = webview.asWebviewUri(vscode.Uri.joinPath(extensionUri, "media", "onboarding"));
  const script = renderTourViewScript(mediaBaseUri.toString());
  const csp = `default-src 'none'; img-src ${webview.cspSource} data:; style-src ${webview.cspSource} 'unsafe-inline'; script-src 'nonce-${cspNonce}'; font-src 'self';`;
  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta http-equiv="Content-Security-Policy" content="${csp}" />
  <title>Turbine Onboarding</title>
  <style>${TOUR_VIEW_CSS}</style>
</head>
<body>
  <div id="root"></div>
  <template id="logo-template">${TURBINE_LOGO_SVG}</template>
  <script nonce="${cspNonce}">${script}</script>
</body>
</html>`;
}

const TURBINE_LOGO_SVG = `<svg width="18" height="18" viewBox="0 0 864 864" aria-hidden="true"><g fill="#4C90FC"><path d="M294.34,505.96l-55.66-44.24c-51.44-40.89-81.42-103.01-81.42-168.73V103.57c0-13.83,14.97-22.47,26.94-15.56l175.7,101.44c8.59,4.96,11.53,15.94,6.57,24.52l-37.5,64.95c-12.48,21.61-19.11,46.1-19.25,71.06l-.82,149c-.04,7.49-8.7,11.64-14.56,6.98Z"/><path d="M359.13,345.49l66.15-26.08c61.13-24.11,129.92-19.01,186.83,13.85l164.04,94.71c11.97,6.91,11.97,24.2,0,31.11l-175.7,101.44c-8.59,4.96-19.56,2.02-24.52-6.57l-37.5-64.95c-12.48-21.61-30.37-39.6-51.91-52.2l-128.63-75.21c-6.47-3.78-5.73-13.35,1.24-16.1Z"/><path d="M463.58,483.23l-10.49,70.33c-9.69,64.99-48.5,122.02-105.41,154.88l-164.04,94.71c-11.97,6.91-26.94-1.73-26.94-15.55v-202.88c0-9.91,8.04-17.95,17.95-17.95h75c24.96,0,49.48-6.5,71.16-18.86l129.45-73.79c6.51-3.71,14.43,1.71,13.32,9.12Z"/></g></svg>`;

const TOUR_VIEW_CSS = `
:root {
  --turbine-bg: #05091D;
  --turbine-bg-2: #0A1020;
  --turbine-surface: #0D1428;
  --turbine-border: #1A2240;
  --turbine-fg: #E2E4EA;
  --turbine-fg-muted: #8A94A6;
  --turbine-blue: #4C90FC;
  --turbine-blue-2: #6BABFF;
  --turbine-teal: #2DD4BF;
  --turbine-amber: #FBBF24;
  --turbine-red: #F87171;
  --turbine-purple: #A78BFA;
  --font-display: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  --font-body: -apple-system, BlinkMacSystemFont, "Segoe UI", system-ui, sans-serif;
  --font-mono: ui-monospace, "SF Mono", Menlo, "Cascadia Code", monospace;
}
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; height: 100%; }
body {
  background: var(--turbine-bg-2);
  color: var(--turbine-fg);
  font-family: var(--font-body);
  font-size: 13px;
  line-height: 1.55;
  -webkit-font-smoothing: antialiased;
}
#root { height: 100%; }
.ob {
  display: flex;
  flex-direction: column;
  height: 100%;
  background: var(--turbine-bg-2);
  overflow: hidden;
}
.ob-titlebar {
  height: 35px;
  border-bottom: 1px solid var(--turbine-border);
  display: flex;
  align-items: center;
  padding: 0 12px;
  gap: 8px;
  flex-shrink: 0;
  background: var(--turbine-bg);
  position: relative;
}
.ob-titlebar .logo {
  width: 18px;
  height: 18px;
  flex-shrink: 0;
  display: grid;
  place-items: center;
}
.ob-titlebar .name {
  font-family: var(--font-display);
  font-weight: 600;
  font-size: 12px;
  color: #fff;
  text-transform: uppercase;
  letter-spacing: 0.06em;
  flex: 1;
}
.ob-titlebar .iconbtn {
  color: var(--turbine-fg-muted);
  cursor: pointer;
  padding: 2px;
  display: inline-flex;
  background: transparent;
  border: 0;
}
.ob-titlebar .iconbtn:hover { color: #fff; }
.ob-menu-wrap { position: relative; display: inline-flex; }
.ob-menu-veil { position: fixed; inset: 0; z-index: 40; }
.ob-menu-pop {
  position: absolute;
  top: calc(100% + 4px);
  right: 0;
  min-width: 180px;
  background: var(--turbine-surface);
  border: 1px solid var(--turbine-border);
  border-radius: 6px;
  z-index: 50;
  padding: 4px;
  box-shadow: 0 6px 18px rgba(0,0,0,0.5);
}
.ob-menu-item {
  display: block;
  width: 100%;
  text-align: left;
  padding: 8px 10px;
  background: transparent;
  border: none;
  color: var(--turbine-red);
  font-family: var(--font-body);
  font-size: 12px;
  cursor: pointer;
  border-radius: 4px;
}
.ob-menu-item:hover { background: rgba(255,255,255,0.04); }
.ob-body {
  flex: 1;
  overflow-y: auto;
  display: flex;
  flex-direction: column;
}
.ob-section { padding: 10px 14px 0 14px; display: flex; flex-direction: column; gap: 10px; }
.ob-section + .ob-section { padding-top: 0; }
.ob-h1 {
  font-family: var(--font-display);
  font-size: 22px;
  font-weight: 700;
  color: #fff;
  margin: 0;
  line-height: 1.2;
  letter-spacing: -0.01em;
}
.ob-h2 {
  font-family: var(--font-display);
  font-size: 16px;
  font-weight: 600;
  color: #fff;
  margin: 0;
  line-height: 1.3;
}
.ob-text { color: var(--turbine-fg); font-size: 13px; line-height: 1.6; margin: 0; }
.ob-text strong { color: var(--turbine-teal); font-weight: 600; }
.ob-text em { color: var(--turbine-purple); font-style: normal; font-weight: 500; }
.ob-text code, code {
  font-family: var(--font-mono);
  font-size: 11.5px;
  background: rgba(255,255,255,0.06);
  color: var(--turbine-teal);
  padding: 1px 5px;
  border-radius: 3px;
}
.ob-muted { color: var(--turbine-fg-muted); font-size: 12px; }
.ob-welcome { padding: 18px 14px 14px 14px; display: flex; flex-direction: column; gap: 10px; }
.ob-welcome .hero { margin-bottom: 6px; }
.ob-welcome .feat {
  background: transparent;
  border: none;
  border-bottom: 1px solid var(--turbine-border);
  border-radius: 0;
  padding: 10px 0;
  display: flex;
  align-items: flex-start;
  gap: 10px;
}
.ob-welcome .feat:last-of-type { border-bottom: 0; }
.ob-welcome .feat .num { display: none; }
.ob-welcome .feat .body { flex: 1; min-width: 0; }
.ob-welcome .feat .title {
  font-family: var(--font-display);
  font-size: 13px;
  font-weight: 600;
  color: #fff;
  line-height: 1.3;
  margin-bottom: 4px;
}
.ob-welcome .feat .desc {
  color: var(--turbine-fg-muted);
  font-size: 12px;
  line-height: 1.5;
}
.ob-tour-card {
  background: transparent;
  border: none;
  border-bottom: 1px solid var(--turbine-border);
  border-radius: 0;
  padding: 22px 0;
  display: flex;
  gap: 16px;
  align-items: flex-start;
  cursor: pointer;
  position: relative;
}
.ob-tour-card:last-of-type { border-bottom: none; }
.ob-tour-card .num { display: none; }
.ob-tour-card .body { flex: 1; min-width: 0; }
.ob-tour-card .ttl {
  font-family: var(--font-display);
  font-weight: 700;
  font-size: 15.5px;
  color: #fff;
  line-height: 1.3;
  margin: 0 0 6px 0;
  letter-spacing: -0.005em;
}
.ob-tour-card .summary {
  color: var(--turbine-fg-muted);
  font-size: 13px;
  line-height: 1.5;
}
.ob-tour-card .meta {
  font-family: var(--font-mono);
  font-size: 12px;
  color: var(--turbine-fg-muted);
  display: flex;
  gap: 10px;
  align-items: center;
  margin-top: 14px;
}
.ob-tour-card .meta .dot { width: 3px; height: 3px; border-radius: 999px; background: currentColor; opacity: 0.5; }
.ob-tour-card .progbar {
  width: 100px;
  flex: 0 0 100px;
  height: 1px;
  background: rgba(255,255,255,0.08);
  position: relative;
  margin-left: auto;
}
.ob-tour-card .progbar .fill {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  background: var(--turbine-blue);
}
.ob-tour-card .progbar .fill.complete { background: var(--turbine-teal); }
.ob-tour-card .card-action {
  align-self: center;
  flex-shrink: 0;
}
.ob-step-head { padding: 14px 14px 0 14px; }
.ob-step-title {
  font-family: var(--font-display);
  font-size: 17px;
  font-weight: 600;
  color: #fff;
  margin: 0;
  line-height: 1.25;
  letter-spacing: -0.005em;
}
.ob-step-body {
  padding: 12px 14px 14px 14px;
  display: flex;
  flex-direction: column;
  gap: 14px;
}
.ob-step-p {
  margin: 0;
  color: var(--turbine-fg);
  font-size: 13px;
  line-height: 1.6;
}
.ob-step-p strong { color: var(--turbine-teal); font-weight: 600; }
.ob-step-p em { color: var(--turbine-purple); font-style: normal; font-weight: 500; }
.ob-step-ul {
  margin: 0;
  padding-left: 18px;
  color: var(--turbine-fg);
  font-size: 13px;
  line-height: 1.6;
}
.ob-step-ul li { margin: 2px 0; }
.ob-step-ul li::marker { color: var(--turbine-fg-muted); }
.ob-step-ul strong { color: var(--turbine-teal); font-weight: 600; }
.ob-step-ul em { color: var(--turbine-purple); font-style: normal; font-weight: 500; }
.ob-code {
  margin: 0;
  border: 1px solid var(--turbine-border);
  border-radius: 6px;
  background: var(--turbine-bg);
  overflow: hidden;
}
.ob-code-bar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
  padding: 4px 6px 4px 10px;
  border-bottom: 1px solid var(--turbine-border);
  background: var(--turbine-surface);
  min-height: 28px;
}
.ob-code-lang {
  color: var(--turbine-fg-muted);
  font-family: var(--font-mono);
  font-size: 11px;
  letter-spacing: 0.04em;
  text-transform: uppercase;
}
.ob-code-copy {
  background: transparent;
  border: 1px solid var(--turbine-border);
  color: var(--turbine-fg-muted);
  font-family: var(--font-body);
  font-size: 11px;
  padding: 3px 8px;
  border-radius: 4px;
  cursor: pointer;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  transition: color 120ms ease, border-color 120ms ease, background 120ms ease;
}
.ob-code-copy:hover { color: var(--turbine-fg); border-color: #2a3458; }
.ob-code-copy.copied {
  color: var(--turbine-teal);
  border-color: rgba(45, 212, 191, 0.5);
  background: rgba(45, 212, 191, 0.08);
}
.ob-code pre {
  margin: 0;
  padding: 10px 12px;
  overflow-x: auto;
  font-family: var(--font-mono);
  font-size: 12.5px;
  line-height: 1.55;
  color: var(--turbine-fg);
  white-space: pre;
}
.ob-code code {
  font-family: var(--font-mono);
  color: var(--turbine-fg);
  background: transparent;
  padding: 0;
}
.ob-banner {
  background: transparent;
  border: none;
  border-left: 2px solid var(--turbine-border);
  border-radius: 0;
  padding: 8px 12px;
  display: flex;
  gap: 10px;
  align-items: flex-start;
}
.ob-banner.warn { border-left-color: var(--turbine-amber); }
.ob-banner.warning { border-left-color: var(--turbine-amber); }
.ob-banner.error { border-left-color: var(--turbine-red); }
.ob-banner.info { border-left-color: var(--turbine-blue); }
.ob-banner.tip { border-left-color: var(--turbine-purple); }
.ob-banner.success { border-left-color: var(--turbine-teal); }
.ob-banner .icn {
  color: var(--turbine-fg-muted);
  font-size: 13px;
  flex-shrink: 0;
  padding-top: 1px;
}
.ob-banner .icn-pass { color: var(--turbine-teal); }
.ob-banner > div { flex: 1; min-width: 0; color: var(--turbine-fg); font-size: 12.5px; line-height: 1.45; }
.ob-banner-title { color: #fff; font-weight: 600; margin-bottom: 3px; }
.ob-image {
  margin: 10px 0 0 0;
  border: 1px solid var(--turbine-border);
  border-radius: 6px;
  background: var(--turbine-surface);
  overflow: hidden;
}
.ob-image img {
  display: block;
  max-width: 100%;
  height: auto;
}
.ob-image figcaption {
  color: var(--turbine-fg-muted);
  font-size: 12px;
  line-height: 1.45;
  padding: 8px 10px;
  border-top: 1px solid var(--turbine-border);
}
.ob-step-progress { padding: 0 14px; flex-shrink: 0; }
.ob-step-progress .sp-hairline {
  height: 1px;
  background: rgba(255,255,255,0.08);
  position: relative;
}
.ob-step-progress .sp-hairline .fill {
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  background: var(--turbine-blue);
  transition: width 200ms ease;
}
.ob-btn {
  font-family: var(--font-body);
  font-size: 13px;
  font-weight: 500;
  padding: 8px 14px;
  border-radius: 5px;
  border: 1px solid transparent;
  cursor: pointer;
  transition: all 180ms cubic-bezier(0.2,0.8,0.2,1);
  display: inline-flex;
  align-items: center;
  gap: 6px;
  line-height: 1;
  background: transparent;
  color: var(--turbine-fg);
}
.ob-btn.primary {
  background: var(--turbine-blue);
  color: var(--turbine-bg);
  font-weight: 600;
}
.ob-btn.primary:hover { background: var(--turbine-blue-2); }
.ob-btn.primary:disabled { background: rgba(76,144,252,0.3); color: rgba(5,9,29,0.6); cursor: not-allowed; }
.ob-btn.secondary {
  border-color: var(--turbine-border);
  color: var(--turbine-fg);
}
.ob-btn.secondary:hover { border-color: var(--turbine-blue); color: var(--turbine-blue); }
.ob-btn.secondary:disabled { opacity: 0.4; cursor: not-allowed; }
.ob-btn.ghost { color: var(--turbine-fg-muted); padding: 8px 8px; }
.ob-btn.ghost:hover { color: #fff; }
.ob-btn.small { font-size: 12px; padding: 6px 10px; }
.ob-btnrow {
  display: flex;
  gap: 8px;
  align-items: center;
  padding: 12px 14px;
  border-top: 1px solid var(--turbine-border);
  background: var(--turbine-bg);
  flex-shrink: 0;
}
.ob-btnrow .spacer { flex: 1; }
.ob-tc { padding: 24px 18px 18px 18px; display: flex; flex-direction: column; gap: 22px; }
.ob-tc-hero { display: flex; flex-direction: column; gap: 6px; }
.ob-tc-check {
  width: 32px;
  height: 32px;
  border-radius: 999px;
  background: var(--turbine-teal);
  color: var(--turbine-bg);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: 6px;
}
.ob-tc-eyebrow {
  font-family: var(--font-body);
  font-size: 11.5px;
  font-weight: 500;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: var(--turbine-teal);
}
.ob-tc-title {
  font-family: var(--font-display);
  font-size: 22px;
  font-weight: 600;
  line-height: 1.2;
  color: var(--turbine-fg);
  margin: 2px 0 0 0;
  letter-spacing: -0.01em;
}
.ob-tc-meta {
  display: flex;
  align-items: center;
  gap: 8px;
  font-family: var(--font-mono);
  font-size: 11px;
  color: var(--turbine-fg-muted);
  margin-top: 6px;
}
.ob-tc-meta .dot { width: 3px; height: 3px; border-radius: 999px; background: currentColor; opacity: 0.5; }
.ob-tc-section { display: flex; flex-direction: column; gap: 10px; }
.ob-tc-label {
  font-family: var(--font-body);
  font-size: 11px;
  font-weight: 500;
  letter-spacing: 0.06em;
  text-transform: uppercase;
  color: var(--turbine-fg-muted);
}
.ob-tc-next {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  text-align: left;
  width: 100%;
  background: var(--turbine-surface);
  border: 1px solid var(--turbine-border);
  border-radius: 8px;
  padding: 14px;
  cursor: pointer;
  transition: border-color 140ms ease, transform 140ms ease;
  font: inherit;
  color: inherit;
}
.ob-tc-next:hover { border-color: var(--turbine-blue); transform: translateY(-1px); }
.ob-tc-next .num {
  font-family: var(--font-mono);
  font-size: 12px;
  color: var(--turbine-blue);
  font-weight: 500;
  flex-shrink: 0;
  padding-top: 1px;
}
.ob-tc-next .body { flex: 1; min-width: 0; }
.ob-tc-next .ttl {
  font-family: var(--font-display);
  font-weight: 600;
  font-size: 14px;
  line-height: 1.3;
  margin-bottom: 4px;
  color: var(--turbine-fg);
}
.ob-tc-next .summary { font-size: 12.5px; line-height: 1.45; color: var(--turbine-fg-muted); }
.ob-tc-next .arrow {
  color: var(--turbine-fg-muted);
  flex-shrink: 0;
  padding-top: 2px;
  transition: transform 140ms ease, color 140ms ease;
}
.ob-tc-next:hover .arrow { color: var(--turbine-blue); transform: translateX(2px); }
.ob-tc-final { font-size: 13px; line-height: 1.5; color: var(--turbine-fg-muted); margin: 0; }
.ob-empty {
  padding: 40px 18px;
  text-align: center;
  color: var(--turbine-fg-muted);
  font-size: 12.5px;
  line-height: 1.6;
}
.folder-picker {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 14px 0 14px;
  font-size: 11px;
  color: var(--turbine-fg-muted);
}
.folder-picker select {
  flex: 1;
  background: var(--turbine-surface);
  color: var(--turbine-fg);
  border: 1px solid var(--turbine-border);
  border-radius: 4px;
  padding: 4px 6px;
  font-family: var(--font-body);
  font-size: 12px;
}
@keyframes obspin {
  to { transform: rotate(360deg); }
}
.ob-spinner {
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255,255,255,0.12);
  border-top-color: var(--turbine-blue);
  border-radius: 999px;
  animation: obspin 0.9s linear infinite;
}
.ob-prep {
  padding: 28px 18px;
  display: flex;
  flex-direction: column;
  align-items: flex-start;
  gap: 12px;
}
.ob-prep .lbl { color: var(--turbine-fg-muted); font-size: 12.5px; }
.ob-prep .lbl { color: var(--turbine-fg-muted); font-size: 12.5px; }
`;

export function renderTourViewScript(mediaBaseUri: string): string {
  return TOUR_VIEW_SCRIPT.replace(
    'const ONBOARDING_MEDIA_BASE_URI = "";',
    `const ONBOARDING_MEDIA_BASE_URI = ${JSON.stringify(mediaBaseUri)};`,
  );
}

const TOUR_VIEW_SCRIPT = `
(function () {
  const vscodeApi = acquireVsCodeApi();
  const root = document.getElementById("root");
  const logoTemplate = document.getElementById("logo-template").innerHTML;
  const ONBOARDING_MEDIA_BASE_URI = "";
  const ALLOWED_IMAGE_EXTENSIONS = [".png", ".jpg", ".jpeg", ".webp", ".gif"];

  // Picker metadata not yet carried by the LSP TourEntry payload (only id /
  // title / completed). Keyed by tour id so adding a tour without seeding
  // here degrades to title + "0 steps" rather than crashing.
  const TOUR_META = {
    "learn-about-data-contracts": {
      summary: "Open a Data Contract, read its ODCS fields, and start from the Turbine Sidebar.",
      steps: 2,
      minutes: 2,
    },
    "foundations": {
      summary: "Get the lay of the land. Datasources, Contracts, Quality Specs, and where everything lives.",
      steps: 14,
      minutes: 14,
    },
    "quality-checks": {
      summary: "Add checks, set thresholds, run validations, and read the failing rows.",
      steps: 18,
      minutes: 18,
    },
    "ship-and-observe": {
      summary: "Run the management API, open the dashboard, and watch results land.",
      steps: 12,
      minutes: 12,
    },
  };

  // ── State ──
  const state = {
    screen: "welcome",
    phaseData: null,        // { tours, phaseKind, workspaceFolderUri, machineWideCompleted, folders, currentFolderKey }
    activeTour: null,       // tour entry from phaseData
    activeStep: null,       // { id, title, content, kind, action, target, resolvedTarget }
    stepIndex: 0,
    stepTotal: 0,
    // ADR 0015: per-tour-run latch of step ids the LSP has signalled
    // unlocked (or that Skip has locally satisfied). Drives Next-disabled
    // and Skip-visibility on gated steps.
    unlockedStepIds: new Set(),
    error: null,
    freshFolderReasons: [],
  };

  function setScreen(next) {
    state.screen = next;
    render();
  }

  function pickRecommended() {
    const data = state.phaseData;
    if (data === null) return null;
    const tours = data.tours;
    const completed = new Set(data.machineWideCompleted);
    for (const tour of tours) {
      if (!tour.completed && !completed.has(tour.id)) return tour.id;
    }
    return null;
  }

  function tourById(id) {
    if (state.phaseData === null) return null;
    return state.phaseData.tours.find((tour) => tour.id === id) || null;
  }

  function tourNumber(tour) {
    if (state.phaseData === null) return "";
    const index = state.phaseData.tours.findIndex((entry) => entry.id === tour.id);
    if (index === -1) return "";
    return String(index + 1).padStart(2, "0");
  }

  function isFinalTour(tour) {
    if (state.phaseData === null) return false;
    const tours = state.phaseData.tours;
    if (tours.length === 0) return false;
    return tours[tours.length - 1].id === tour.id;
  }

  function nextTourAfter(currentId) {
    if (state.phaseData === null) return null;
    const tours = state.phaseData.tours;
    const index = tours.findIndex((tour) => tour.id === currentId);
    if (index === -1 || index + 1 >= tours.length) return null;
    return tours[index + 1];
  }

  function isAllComplete() {
    const data = state.phaseData;
    if (data === null) return false;
    if (data.tours.length === 0) return false;
    const completed = new Set(data.machineWideCompleted);
    return data.tours.every((tour) => tour.completed || completed.has(tour.id));
  }

  // ── Render ──
  function render() {
    const data = state.phaseData;
    if (data === null) {
      root.innerHTML = renderShell(renderEmpty("Loading…"), null);
      attachEvents();
      return;
    }
    if (data.phaseKind === null) {
      root.innerHTML = renderShell(renderEmpty(
        "Onboarding is unavailable until a workspace folder with Turbine is open. Use the Turbine activity-bar entry to resolve setup blockers."
      ), null);
      attachEvents();
      return;
    }
    if (data.phaseKind !== "ready" && data.phaseKind !== "ready-tour-pending") {
      root.innerHTML = renderShell(renderEmpty(
        "Finish setup in the Turbine sidebar first. The tour view becomes interactive once Turbine is ready."
      ), null);
      attachEvents();
      return;
    }
    let body = "";
    let progress = "";
    let footer = "";
    switch (state.screen) {
      case "welcome":
        body = renderWelcome();
        footer = renderFooterRow([
          { label: "Skip for now", id: "skip-welcome", variant: "ghost", spacerBefore: true },
          { label: "Start Onboarding ›", id: "start-welcome", variant: "primary" },
        ]);
        break;
      case "picker":
        body = renderPicker();
        footer = renderFooterRow([
          { label: "Close", id: "close-picker", variant: "ghost", spacerBefore: true },
        ]);
        break;
      case "preparing":
        body = renderPreparing();
        footer = renderFooterRow([
          { label: "All tours", id: "back-to-picker", variant: "ghost", spacerBefore: true },
        ]);
        break;
      case "step": {
        body = renderStep();
        progress = renderStepProgress();
        const activeStep = state.activeStep;
        const stepId = activeStep ? activeStep.id : "";
        const gated = activeStep !== null && activeStep.gated === true;
        const unlocked = state.unlockedStepIds.has(stepId);
        const nextDisabled = gated && !unlocked;
        const buttons = [
          { label: "‹ Back", id: "step-back", variant: "secondary", small: true, disabled: state.stepIndex === 0 },
          { label: "All tours", id: "back-to-picker", variant: "ghost", small: true, spacerBefore: true },
        ];
        if (nextDisabled) {
          // Skip is the manual escape hatch; only render it while the gate
          // is still closed. Once unlocked, Skip disappears and Next takes over.
          buttons.push({ label: "Skip", id: "skip-step", variant: "secondary", small: true, data: { stepId } });
        }
        buttons.push({
          label: state.stepIndex >= state.stepTotal - 1 ? "Finish ›" : "Next ›",
          id: "step-next",
          variant: "primary",
          disabled: nextDisabled,
        });
        footer = renderFooterRow(buttons);
        break;
      }
      case "needsFreshFolder":
        body = renderNeedsFreshFolder();
        footer = renderFooterRow([
          { label: "Back", id: "back-to-picker", variant: "ghost", spacerBefore: true },
          { label: "Pick an empty folder", id: "pick-fresh-folder", variant: "primary" },
        ]);
        break;
      case "finalHandoff":
        body = renderFinalHandoff();
        footer = renderFooterRow([
          { label: "Back", id: "back-to-picker", variant: "ghost", spacerBefore: true },
          { label: "Start real project setup ›", id: "final-handoff-confirm", variant: "primary" },
        ]);
        break;
      case "tourComplete":
        body = renderTourComplete();
        progress = "";
        footer = renderTourCompleteFooter();
        break;
      case "finalComplete":
        body = renderFinalComplete();
        footer = renderFooterRow([
          { label: "Revisit tours", id: "back-to-picker", variant: "secondary", small: true },
          { label: "Done", id: "close-final", variant: "primary", spacerBefore: true },
        ]);
        break;
      case "error":
        body = renderError();
        footer = renderFooterRow([
          { label: "Back to tours", id: "back-to-picker", variant: "ghost", spacerBefore: true },
        ]);
        break;
      default:
        body = renderEmpty("");
    }
    root.innerHTML = renderShell(body, progress, footer);
    attachEvents();
  }

  function renderShell(body, progress, footer) {
    const folder = renderFolderPicker();
    const progressBlock = progress || "";
    const footerBlock = footer || "";
    return \`
      <div class="ob">
        <div class="ob-body">
          \${folder}
          \${body}
        </div>
        \${progressBlock}
        \${footerBlock}
      </div>
    \`;
  }

  function renderFolderPicker() {
    const data = state.phaseData;
    if (data === null) return "";
    if (data.folders.length < 2) return "";
    const options = data.folders
      .map((entry) => {
        const selected = entry.key === data.currentFolderKey ? " selected" : "";
        return \`<option value="\${escapeAttr(entry.key)}"\${selected}>\${escapeText(entry.label)}</option>\`;
      })
      .join("");
    return \`
      <div class="folder-picker">
        <span>Folder</span>
        <select data-event="select-folder">\${options}</select>
      </div>
    \`;
  }

  function renderEmpty(message) {
    return \`<div class="ob-empty">\${escapeText(message)}</div>\`;
  }

  function renderWelcome() {
    return \`
      <div class="ob-welcome">
        <div class="hero">
          <h1 class="ob-h1">Welcome to Turbine.</h1>
          <p class="ob-text" style="margin-top:6px;">A guided tour of Turbine's data-quality workflow: authoring <strong>Data Contracts</strong>, running <strong>checks</strong>, watching results land. Skip around, leave anytime.</p>
        </div>
        <div class="feat">
          <div class="body">
            <div class="title">Hands-on, not slideware</div>
            <div class="desc">You'll edit real YAML, click real Codelenses, and run real CLI commands inside a disposable sandbox.</div>
          </div>
        </div>
        <div class="feat">
          <div class="body">
            <div class="title">Fresh-folder demo</div>
            <div class="desc">The tour scaffolds a demo project at the workspace root. If your folder already has Turbine content, we open a fresh folder for the demo so your real work stays untouched.</div>
          </div>
        </div>
        <div class="feat">
          <div class="body">
            <div class="title">Soft progression</div>
            <div class="desc">Every tour is unlocked from the start. We highlight what to do next, but you choose your own path.</div>
          </div>
        </div>
      </div>
    \`;
  }

  function renderPicker() {
    const data = state.phaseData;
    if (data === null || data.tours.length === 0) {
      return renderEmpty("No tours are available yet. Check that the Turbine LSP is running for this folder.");
    }
    const completed = new Set(data.machineWideCompleted);
    const recId = pickRecommended();
    const allDone = isAllComplete();
    const heading = allDone
      ? \`<h1 class="ob-h1">All tours complete.</h1><p class="ob-text" style="margin-top:6px; color: var(--turbine-fg-muted);">Revisit any tour or jump into your real project.</p>\`
      : \`<h1 class="ob-h1">Pick a tour.</h1><p class="ob-text" style="margin-top:6px; color: var(--turbine-fg-muted);">Start with the recommended tour, or jump anywhere. They all work standalone.</p>\`;
    const cards = data.tours
      .map((tour, index) => {
        const isComplete = tour.completed || completed.has(tour.id);
        const isRec = tour.id === recId;
        const num = String(index + 1).padStart(2, "0");
        const meta = TOUR_META[tour.id] || {};
        const summary = meta.summary || "";
        const stepCount = meta.steps || 0;
        const minutes = meta.minutes || 0;
        const completedSteps = tour.completedSteps || 0;
        const cardClasses = ["ob-tour-card"];
        if (isRec) cardClasses.push("recommended");
        if (isComplete) cardClasses.push("complete");
        const fillClasses = isComplete ? "fill complete" : "fill";
        const pct = isComplete
          ? 100
          : stepCount > 0
            ? Math.min(100, Math.round((completedSteps / stepCount) * 100))
            : 0;
        const action = isComplete ? "Restart" : completedSteps > 0 ? "Resume" : "Start";
        const btnVariant = isRec ? "primary" : "secondary";
        const summaryHtml = summary === "" ? "" : \`<div class="summary">\${escapeText(summary)}</div>\`;
        const metaParts = [];
        if (stepCount > 0) metaParts.push(\`<span>\${stepCount} steps</span>\`);
        if (minutes > 0) metaParts.push(\`<span>~\${minutes} min</span>\`);
        metaParts.push(\`<span>\${pct}%</span>\`);
        const metaInner = metaParts.join('<span class="dot"></span>');
        return \`
          <div class="\${cardClasses.join(" ")}" data-event="pick-tour" data-tour-id="\${escapeAttr(tour.id)}">
            <div class="num">\${isComplete ? "✓" : num}</div>
            <div class="body">
              <div class="ttl">\${escapeText(tour.title)}</div>
              \${summaryHtml}
              <div class="meta">
                \${metaInner}
                <div class="progbar"><div class="\${fillClasses}" style="width:\${pct}%"></div></div>
              </div>
            </div>
            <button class="ob-btn \${btnVariant} small card-action" data-event="pick-tour" data-tour-id="\${escapeAttr(tour.id)}">\${action}</button>
          </div>
        \`;
      })
      .join("");
    return \`
      <div class="ob-section" style="padding-top:18px; gap:0;">\${heading}</div>
      <div class="ob-section" style="margin-top:6px; padding-bottom:24px; gap:0;">\${cards}</div>
    \`;
  }

  function renderPreparing() {
    return \`
      <div class="ob-prep">
        <div class="ob-spinner"></div>
        <div class="lbl">Preparing the demo…</div>
        <div class="ob-muted" style="font-size:12px;">Scaffolding demo files at the workspace root. This takes a moment on the first run.</div>
      </div>
    \`;
  }

  function renderStep() {
    const step = state.activeStep;
    if (step === null) return renderEmpty("No active step.");
    const content = renderStepContent(step.content || []);
    return \`
      <div class="ob-step-head">
        <h2 class="ob-step-title">\${escapeText(step.title)}</h2>
      </div>
      <div class="ob-step-body">
        \${content}
      </div>
    \`;
  }

  function renderStepProgress() {
    const total = Math.max(1, state.stepTotal);
    const done = state.stepIndex;
    const pct = Math.round((done / Math.max(1, total - 1)) * 100);
    const safePct = Math.max(0, Math.min(100, pct));
    return \`
      <div class="ob-step-progress">
        <div class="sp-hairline"><div class="fill" style="width:\${safePct}%"></div></div>
      </div>
    \`;
  }

  function renderStepContent(blocks) {
    if (!Array.isArray(blocks)) return "";
    return blocks.map((block) => renderContentBlock(block)).join("");
  }

  function renderContentBlock(block) {
    if (block === null || typeof block !== "object") return "";
    if (block.kind === "paragraph") return renderParagraphBlock(block);
    if (block.kind === "callout") return renderCalloutBlock(block);
    if (block.kind === "image") return renderImageBlock(block);
    return "";
  }

  function renderParagraphBlock(block) {
    if (typeof block.markdown !== "string") return "";
    return renderMarkdownParagraphs(block.markdown);
  }

  function renderCalloutBlock(block) {
    const tone = normalizeCalloutTone(block.tone);
    const title = typeof block.title === "string" && block.title.trim() !== ""
      ? \`<div class="ob-banner-title">\${renderInline(block.title.trim())}</div>\`
      : "";
    const markdown = typeof block.markdown === "string" ? block.markdown : "";
    const icon = calloutIcon(tone);
    return \`<div class="ob-banner \${tone}"><span class="icn">\${icon}</span><div>\${title}\${renderInline(markdown)}</div></div>\`;
  }

  function renderImageBlock(block) {
    const src = resolveImageSrc(block.assetPath);
    if (src === null) return "";
    const alt = typeof block.alt === "string" ? block.alt : "";
    const caption = typeof block.captionMarkdown === "string" && block.captionMarkdown.trim() !== ""
      ? \`<figcaption>\${renderInline(block.captionMarkdown.trim())}</figcaption>\`
      : "";
    return \`<figure class="ob-image"><img src="\${escapeAttr(src)}" alt="\${escapeAttr(alt)}" />\${caption}</figure>\`;
  }

  function normalizeCalloutTone(tone) {
    if (tone === "tip" || tone === "warning" || tone === "error" || tone === "success") return tone;
    return "info";
  }

  function calloutIcon(tone) {
    if (tone === "tip") return "!";
    if (tone === "warning") return "!";
    if (tone === "error") return "x";
    if (tone === "success") return "ok";
    return "i";
  }

  function renderNeedsFreshFolder() {
    const reasonsHtml = state.freshFolderReasons.length === 0
      ? ""
      : \`<ul class="ob-muted" style="margin:6px 0 0 18px; padding:0;">\${
          state.freshFolderReasons.map((reason) => \`<li>\${escapeText(reason)}</li>\`).join("")
        }</ul>\`;
    return \`
      <div class="ob-section" style="padding:24px 18px 18px 18px;">
        <h1 class="ob-h1">Pick an empty folder for the tour</h1>
        <p class="ob-text">This workspace already has Turbine content. The onboarding tour scaffolds a demo project at the workspace root, so it needs a fresh empty folder to avoid stepping on your work.</p>
        \${reasonsHtml}
        <p class="ob-muted" style="margin-top:12px;">Picking a folder opens it in a new VS Code window. Your current workspace stays untouched.</p>
      </div>
    \`;
  }

  function renderFinalHandoff() {
    return \`
      <div class="ob-section" style="padding:24px 18px 18px 18px;">
        <h1 class="ob-h1">You finished the tour.</h1>
        <p class="ob-text">Connect your own datasource to start a real Turbine project. The demo files stay where they are; clean them up whenever you're done.</p>
      </div>
    \`;
  }

  function renderTourComplete() {
    const tour = state.activeTour;
    if (tour === null) return renderEmpty("");
    const number = tourNumber(tour);
    const next = nextTourAfter(tour.id);
    const checkSvg = '<svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 8l3 3 7-7" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    const arrowSvg = '<svg width="12" height="12" viewBox="0 0 12 12" fill="none"><path d="M4 2l4 4-4 4" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
    const upNext = next === null
      ? \`
        <div class="ob-tc-section">
          <div class="ob-tc-label">All tours complete</div>
          <p class="ob-tc-final">You've finished every tour. Head back to the picker to revisit anything, or jump into your real project.</p>
        </div>
      \`
      : \`
        <div class="ob-tc-section">
          <div class="ob-tc-label">Up next</div>
          <button class="ob-tc-next" data-event="continue-next" data-tour-id="\${escapeAttr(next.id)}">
            <div class="num">\${tourNumber(next)}</div>
            <div class="body">
              <div class="ttl">\${escapeText(next.title)}</div>
            </div>
            <div class="arrow">\${arrowSvg}</div>
          </button>
        </div>
      \`;
    return \`
      <div class="ob-tc">
        <div class="ob-tc-hero">
          <div class="ob-tc-check">\${checkSvg}</div>
          <div class="ob-tc-eyebrow">Tour complete</div>
          <h1 class="ob-tc-title">\${escapeText(tour.title)}</h1>
          <div class="ob-tc-meta"><span>\${number}</span><span class="dot"></span><span>\${state.stepTotal} steps</span></div>
        </div>
        \${upNext}
      </div>
    \`;
  }

  function renderTourCompleteFooter() {
    const tour = state.activeTour;
    const next = tour ? nextTourAfter(tour.id) : null;
    const buttons = [
      { label: "All tours", id: "back-to-picker", variant: "ghost", small: true, spacerBefore: true },
    ];
    if (next === null) {
      buttons.push({ label: "Done ✓", id: "back-to-picker", variant: "primary" });
    } else {
      buttons.push({ label: "Continue ›", id: "continue-next", variant: "primary", data: { "tour-id": next.id } });
    }
    return renderFooterRow(buttons);
  }

  function renderFinalComplete() {
    return \`
      <div class="ob-tc">
        <div class="ob-tc-hero">
          <div class="ob-tc-eyebrow">All tours complete</div>
          <h1 class="ob-tc-title">You're ready for real projects.</h1>
          <p class="ob-tc-final" style="margin-top:8px;">You've covered authoring, foundations, checks, observability, and advanced patterns. Connect your real warehouse and wire Turbine into CI when you're ready.</p>
        </div>
      </div>
    \`;
  }

  function renderError() {
    const message = state.error || "Tour error.";
    return \`
      <div class="ob-section" style="padding:24px 18px 18px 18px;">
        <div class="ob-banner error">
          <span class="icn">⊗</span>
          <div>
            <div style="font-weight:600; color:#fff; margin-bottom:3px;">Something went wrong.</div>
            <div style="color:var(--turbine-fg-muted); font-size:12.5px;">\${escapeText(message)}</div>
          </div>
        </div>
      </div>
    \`;
  }

  function renderFooterRow(buttons) {
    const html = buttons
      .map((btn) => {
        const classes = ["ob-btn", btn.variant];
        if (btn.small) classes.push("small");
        const disabled = btn.disabled === true ? " disabled" : "";
        const data = btn.data ? Object.entries(btn.data).map(([key, value]) => \` data-\${key}="\${escapeAttr(value)}"\`).join("") : "";
        const spacer = btn.spacerBefore === true ? '<div class="spacer"></div>' : "";
        return \`\${spacer}<button class="\${classes.join(" ")}" data-event="\${escapeAttr(btn.id)}"\${data}\${disabled}>\${escapeText(btn.label)}</button>\`;
      })
      .join("");
    return \`<div class="ob-btnrow">\${html}</div>\`;
  }

  function stepSearchText(step) {
    const blocks = Array.isArray(step.content) ? step.content : [];
    return blocks
      .map((block) => {
        if (block === null || typeof block !== "object") return "";
        if (block.kind === "paragraph" || block.kind === "callout") return block.markdown || "";
        if (block.kind === "image") return block.captionMarkdown || "";
        return "";
      })
      .join("\\n\\n");
  }

  function resolveImageSrc(assetPath) {
    if (typeof assetPath !== "string") return null;
    const trimmed = assetPath.trim();
    if (trimmed === "") return null;
    if (trimmed.startsWith("/") || trimmed.includes("\\\\") || trimmed.includes(":")) return null;
    const segments = trimmed.split("/");
    if (segments.some((segment) => segment === "" || segment === "." || segment === "..")) return null;
    const lower = trimmed.toLowerCase();
    if (!ALLOWED_IMAGE_EXTENSIONS.some((extension) => lower.endsWith(extension))) return null;
    return \`\${ONBOARDING_MEDIA_BASE_URI}/\${segments.map((segment) => encodeURIComponent(segment)).join("/")}\`;
  }

  function renderMarkdownParagraphs(markdown) {
    if (!markdown) return "";
    const fenceRe = /\`\`\`([A-Za-z0-9_+-]*)\\n([\\s\\S]*?)\`\`\`/g;
    const parts = [];
    let lastIndex = 0;
    let match;
    while ((match = fenceRe.exec(markdown)) !== null) {
      if (match.index > lastIndex) {
        parts.push({ kind: "prose", text: markdown.slice(lastIndex, match.index) });
      }
      parts.push({ kind: "code", lang: match[1] || "", code: match[2] });
      lastIndex = fenceRe.lastIndex;
    }
    if (lastIndex < markdown.length) {
      parts.push({ kind: "prose", text: markdown.slice(lastIndex) });
    }
    return parts
      .map((part) => (part.kind === "code" ? renderCodeBlock(part.lang, part.code) : renderProseParagraphs(part.text)))
      .join("");
  }

  function renderProseParagraphs(text) {
    if (!text) return "";
    const lines = text.split(/\\n\\s*\\n/);
    return lines
      .map((para) => {
        const trimmed = para.trim();
        if (trimmed === "") return "";
        const bulletItems = extractBulletItems(trimmed);
        if (bulletItems !== null) {
          return \`<ul class="ob-step-ul">\${bulletItems.map((item) => \`<li>\${renderInline(item)}</li>\`).join("")}</ul>\`;
        }
        return \`<p class="ob-step-p">\${renderInline(trimmed)}</p>\`;
      })
      .join("");
  }

  function extractBulletItems(paragraph) {
    const rawLines = paragraph.split(/\\n/);
    const items = [];
    let current = null;
    for (const raw of rawLines) {
      const bulletMatch = raw.match(/^\\s*[-*]\\s+(.*)$/);
      if (bulletMatch !== null) {
        if (current !== null) items.push(current);
        current = bulletMatch[1];
        continue;
      }
      if (current === null) return null;
      const continuation = raw.trim();
      if (continuation === "") return null;
      current = \`\${current} \${continuation}\`;
    }
    if (current !== null) items.push(current);
    if (items.length === 0) return null;
    return items;
  }

  function renderCodeBlock(lang, code) {
    const trimmed = String(code).replace(/\\n+$/, "");
    const langLabel = (lang || "").trim();
    const langChip = langLabel === "" ? "" : \`<span class="ob-code-lang">\${escapeText(langLabel)}</span>\`;
    return \`<div class="ob-code"><div class="ob-code-bar">\${langChip}<button class="ob-code-copy" data-event="copy-code" type="button"><span class="ob-code-copy-label">Copy</span></button></div><pre><code>\${escapeText(trimmed)}</code></pre></div>\`;
  }

  function renderInline(text) {
    let safe = escapeText(text);
    safe = safe.replace(/\\[([^\\]]+)\\]\\(([^)\\s]+)\\)/g, (m, label, url) => {
      const href = url.replace(/"/g, '&quot;');
      return \`<a href="\${href}" target="_blank" rel="noopener noreferrer">\${label}</a>\`;
    });
    safe = safe.replace(/\`([^\`]+)\`/g, '<code>$1</code>');
    safe = safe.replace(/\\*\\*([^*]+)\\*\\*/g, '<strong>$1</strong>');
    safe = safe.replace(/(^|[^*])\\*([^*]+)\\*(?!\\*)/g, '$1<em>$2</em>');
    safe = safe.replace(/\\n/g, '<br/>');
    return safe;
  }

  function escapeText(value) {
    if (value === null || value === undefined) return "";
    return String(value)
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
  }

  function escapeAttr(value) {
    return escapeText(value).replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }

  // ── Events ──
  function attachEvents() {
    const targets = root.querySelectorAll("[data-event]");
    targets.forEach((node) => {
      const event = node.getAttribute("data-event");
      if (event === "select-folder") {
        node.addEventListener("change", () => {
          const value = node.value;
          if (value !== null && value !== "") vscodeApi.postMessage({ type: "select-folder", folderKey: value });
        });
        return;
      }
      node.addEventListener("click", (ev) => {
        ev.stopPropagation();
        handleEvent(event, node);
      });
    });
  }

  function handleEvent(event, node) {
    if (event === "skip-welcome" || event === "close-picker" || event === "close-final") {
      vscodeApi.postMessage({ type: "close-tour-view" });
      return;
    }
    if (event === "start-welcome") {
      setScreen("picker");
      return;
    }
    if (event === "back-to-picker") {
      state.activeTour = null;
      state.activeStep = null;
      state.stepIndex = 0;
      state.stepTotal = 0;
      state.unlockedStepIds = new Set();
      state.error = null;
      setScreen(isAllComplete() ? "finalComplete" : "picker");
      return;
    }
    if (event === "pick-tour") {
      const id = node.getAttribute("data-tour-id");
      if (id === null) return;
      const tour = tourById(id);
      if (tour === null) return;
      state.activeTour = tour;
      state.unlockedStepIds = new Set();
      vscodeApi.postMessage({ type: "start-tour", tourId: id });
      return;
    }
    if (event === "continue-next") {
      const id = node.getAttribute("data-tour-id");
      if (id === null) return;
      const tour = tourById(id);
      if (tour === null) return;
      state.activeTour = tour;
      state.unlockedStepIds = new Set();
      vscodeApi.postMessage({ type: "start-tour", tourId: id });
      return;
    }
    if (event === "step-next") {
      const tour = state.activeTour;
      if (tour === null) return;
      vscodeApi.postMessage({ type: "tour-next-step", tourId: tour.id });
      return;
    }
    if (event === "step-back") {
      const tour = state.activeTour;
      if (tour === null) return;
      vscodeApi.postMessage({ type: "tour-prev-step", tourId: tour.id });
      return;
    }
    if (event === "skip-step") {
      const tour = state.activeTour;
      const step = state.activeStep;
      if (tour === null || step === null) return;
      // Latch locally so the gate stays satisfied if the user retreats
      // back to this step; then ask the engine to advance.
      state.unlockedStepIds.add(step.id);
      vscodeApi.postMessage({ type: "tour-skip-step", tourId: tour.id, stepId: step.id });
      return;
    }
    if (event === "pick-fresh-folder") {
      vscodeApi.postMessage({ type: "tour-pick-fresh-folder" });
      return;
    }
    if (event === "final-handoff-confirm") {
      const tour = state.activeTour;
      if (tour === null) return;
      vscodeApi.postMessage({ type: "tour-final-handoff-confirmed", tourId: tour.id });
      return;
    }
    if (event === "copy-code") {
      const block = node.closest(".ob-code");
      if (block === null) return;
      const codeEl = block.querySelector("pre > code");
      if (codeEl === null) return;
      const text = codeEl.textContent || "";
      copyToClipboard(text).then((ok) => {
        if (!ok) return;
        const label = node.querySelector(".ob-code-copy-label");
        const original = label === null ? "Copy" : label.textContent;
        if (label !== null) label.textContent = "Copied ✓";
        node.classList.add("copied");
        setTimeout(() => {
          node.classList.remove("copied");
          if (label !== null) label.textContent = original;
        }, 1500);
      });
      return;
    }
  }

  function copyToClipboard(text) {
    if (navigator.clipboard && typeof navigator.clipboard.writeText === "function") {
      return navigator.clipboard.writeText(text).then(() => true).catch(() => fallbackCopy(text));
    }
    return Promise.resolve(fallbackCopy(text));
  }

  function fallbackCopy(text) {
    const textarea = document.createElement("textarea");
    textarea.value = text;
    textarea.setAttribute("readonly", "");
    textarea.style.position = "fixed";
    textarea.style.left = "-9999px";
    textarea.style.top = "0";
    document.body.appendChild(textarea);
    textarea.focus();
    textarea.select();
    let ok = false;
    try {
      ok = document.execCommand("copy");
    } catch (err) {
      ok = false;
    }
    document.body.removeChild(textarea);
    return ok;
  }

  // ── Inbound messages ──
  window.addEventListener("message", (event) => {
    const msg = event.data;
    if (msg === null || typeof msg !== "object") return;
    if (msg.type === "phase-data") {
      const wasFresh = state.phaseData === null;
      state.phaseData = msg;
      if (wasFresh && state.screen === "welcome" && msg.machineWideCompleted.length > 0) {
        state.screen = "picker";
      }
      render();
      return;
    }
    if (msg.type === "tour-preparing-scaffold") {
      const tour = tourById(msg.tourId);
      if (tour !== null) state.activeTour = tour;
      setScreen("preparing");
      return;
    }
    if (msg.type === "tour-step") {
      const tour = tourById(msg.tourId);
      if (tour !== null) state.activeTour = tour;
      state.activeStep = msg.step;
      state.stepIndex = msg.index;
      state.stepTotal = msg.total;
      setScreen("step");
      return;
    }
    if (msg.type === "tour-step-completed") {
      // The engine follows up with tour-step or tour-finished.
      return;
    }
    if (msg.type === "tour-step-unlocked") {
      state.unlockedStepIds.add(msg.stepId);
      render();
      return;
    }
    if (msg.type === "tour-final-handoff-prompt") {
      setScreen("finalHandoff");
      return;
    }
    if (msg.type === "tour-needs-fresh-folder") {
      state.freshFolderReasons = Array.isArray(msg.reasons) ? msg.reasons : [];
      setScreen("needsFreshFolder");
      return;
    }
    if (msg.type === "tour-finished") {
      setScreen("tourComplete");
      return;
    }
    if (msg.type === "tour-error") {
      state.error = msg.message || "Tour error.";
      setScreen("error");
      return;
    }
  });

  render();
})();
`;
