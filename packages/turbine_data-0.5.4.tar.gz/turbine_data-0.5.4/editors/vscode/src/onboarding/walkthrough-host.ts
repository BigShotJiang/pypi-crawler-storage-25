/**
 * Owns the install-day Walkthrough surface contributed in package.json.
 *
 * Three responsibilities:
 *
 * - Publish the five derived `turbine.onboarding.*` context keys VS Code's
 *   Walkthrough engine reads to tick steps off, recomputed from
 *   `EditorPhase` and the completed-tours list whenever either changes.
 * - Open the walkthrough once on the first activation after install via
 *   `workbench.action.openWalkthrough`, gated by a `globalState` flag so a
 *   subsequent reload never re-opens it. The flag is written even if the
 *   open command throws so a malformed walkthrough cannot loop.
 * - Reset both surfaces of state on `Reset Onboarding`: clear the
 *   `globalState` flag and write the five keys back to false. VS Code's
 *   per-step completion is best-effort reset via
 *   `workbench.action.resetWalkthroughStepCompletion`; the contract is the
 *   context keys re-deriving truth on the next phase emit.
 */

import type { Disposable } from "vscode";

import type { EditorPhase } from "./editor-phase";

export interface WalkthroughKeys {
  readonly folderOpen: boolean;
  readonly uvInstalled: boolean;
  readonly pyprojectExists: boolean;
  readonly turbineInstalled: boolean;
  readonly tourCompleted: boolean;
}

export const WALKTHROUGH_CONTEXT_KEYS = {
  folderOpen: "turbine.onboarding.folderOpen",
  uvInstalled: "turbine.onboarding.uvInstalled",
  pyprojectExists: "turbine.onboarding.pyprojectExists",
  turbineInstalled: "turbine.onboarding.turbineInstalled",
  tourCompleted: "turbine.onboarding.tourCompleted",
} as const;

export const WALKTHROUGH_CATEGORY_ID = "turbine.onboarding";
export const WALKTHROUGH_FIRST_STEP_ID = "turbine.onboarding.findSidebar";
export const WALKTHROUGH_SHOWN_FLAG = "turbine.walkthroughShown";

/**
 * Extension ID as seen by VS Code: `<publisher>.<name>` from package.json.
 * Used to build the fully-qualified step IDs `welcome.markStepIncomplete`
 * expects.
 */
export const WALKTHROUGH_EXTENSION_ID = "enexis.turbine-lsp";

export const WALKTHROUGH_STEP_IDS = [
  "turbine.onboarding.findSidebar",
  "turbine.onboarding.openFolder",
  "turbine.onboarding.installUv",
  "turbine.onboarding.initPyproject",
  "turbine.onboarding.addTurbine",
  "turbine.onboarding.takeTour",
] as const;

function fullStepId(stepId: string): string {
  return `${WALKTHROUGH_EXTENSION_ID}#${WALKTHROUGH_CATEGORY_ID}#${stepId}`;
}

export function deriveWalkthroughKeys(
  phase: EditorPhase,
  completedTourIds: readonly string[],
): WalkthroughKeys {
  const tourCompleted = completedTourIds.length > 0;
  if (phase.kind === "no-folder") {
    return {
      folderOpen: false,
      uvInstalled: false,
      pyprojectExists: false,
      turbineInstalled: false,
      tourCompleted,
    };
  }
  if (phase.kind === "needs-uv") {
    return {
      folderOpen: true,
      uvInstalled: false,
      pyprojectExists: false,
      turbineInstalled: false,
      tourCompleted,
    };
  }
  if (phase.kind === "needs-turbine-project") {
    const pyprojectExists = phase.subKind !== "no-pyproject";
    return {
      folderOpen: true,
      uvInstalled: true,
      pyprojectExists,
      turbineInstalled: false,
      tourCompleted,
    };
  }
  if (phase.kind !== "lsp-phase") {
    return {
      folderOpen: true,
      uvInstalled: true,
      pyprojectExists: false,
      turbineInstalled: false,
      tourCompleted,
    };
  }
  const dtoKind = phase.dto.kind;
  const pyprojectExists = dtoKind !== "needs-pyproject";
  const turbineInstalled = dtoKind === "ready-tour-pending" || dtoKind === "ready";
  return {
    folderOpen: true,
    uvInstalled: true,
    pyprojectExists,
    turbineInstalled,
    tourCompleted,
  };
}

export interface GlobalStateLike {
  get<T>(key: string): T | undefined;
  update(key: string, value: unknown): Thenable<void>;
}

export interface CommandRunner {
  execute(command: string, ...args: readonly unknown[]): Thenable<unknown>;
  /**
   * Returns the list of known command IDs registered in this editor host.
   * Used to discover which reset-progress command is actually available
   * (VS Code, Cursor, Code-OSS, and other forks differ on which IDs exist).
   */
  list(): Thenable<readonly string[]>;
}

export interface PhaseSource {
  readonly current: EditorPhase;
  onPhaseChange(listener: (phase: EditorPhase) => void): Disposable;
}

export interface CompletedToursSource {
  list(): readonly string[];
}

export interface WalkthroughHostDeps {
  readonly globalState: GlobalStateLike;
  readonly commands: CommandRunner;
  readonly phase: PhaseSource;
  readonly completedTours: CompletedToursSource;
  readonly logger: (message: string) => void;
}

/**
 * `welcome.markStepIncomplete` un-ticks one step at a time and is scoped to
 * this walkthrough only. Preferred over the bulk reset because it does not
 * touch other extensions' walkthroughs (GitLens, "Learn the Fundamentals",
 * etc.).
 */
const MARK_STEP_INCOMPLETE_COMMAND = "welcome.markStepIncomplete";

/**
 * Bulk-reset fallbacks. VS Code, Cursor, and other forks differ on which ID
 * is registered (microsoft/vscode#212819 tracks the missing per-walkthrough
 * API). The bulk reset clears every walkthrough's progress including built-in
 * ones — acceptable as an explicit user action, but only used when the
 * per-step path is unavailable.
 */
const BULK_RESET_CANDIDATES: readonly string[] = [
  "resetGettingStartedProgress",
  "workbench.action.resetGettingStartedProgress",
];
const OPEN_WALKTHROUGH_COMMAND = "workbench.action.openWalkthrough";
const SET_CONTEXT_COMMAND = "setContext";

export class WalkthroughHost implements Disposable {
  private readonly deps: WalkthroughHostDeps;
  private readonly subscriptions: Disposable[] = [];
  private opened = false;
  private started = false;

  constructor(deps: WalkthroughHostDeps) {
    this.deps = deps;
  }

  start(): void {
    if (this.started) return;
    this.started = true;
    this.subscriptions.push(this.deps.phase.onPhaseChange(() => this.publish()));
    this.publish();
  }

  /**
   * Re-publish the five context keys without re-subscribing. Use when an
   * out-of-band signal (a tour finishing) changes a derivable input outside
   * the phase-change channel.
   */
  refresh(): void {
    if (!this.started) return;
    this.publish();
  }

  async maybeOpen(): Promise<void> {
    if (this.opened) return;
    this.opened = true;
    // Strict `=== true` is intentional: a malformed memento value (e.g. "true"
    // string or numeric 1) should not silently bypass the auto-open.
    if (this.deps.globalState.get<boolean>(WALKTHROUGH_SHOWN_FLAG) === true) return;
    try {
      await this.deps.commands.execute(OPEN_WALKTHROUGH_COMMAND, {
        category: WALKTHROUGH_CATEGORY_ID,
        step: WALKTHROUGH_FIRST_STEP_ID,
      });
    } catch (error) {
      this.deps.logger(
        `[walkthrough] open failed: ${error instanceof Error ? error.message : String(error)}`,
      );
    }
    await this.deps.globalState.update(WALKTHROUGH_SHOWN_FLAG, true);
  }

  async reset(): Promise<void> {
    await this.deps.globalState.update(WALKTHROUGH_SHOWN_FLAG, undefined);
    for (const key of Object.values(WALKTHROUGH_CONTEXT_KEYS)) {
      await this.deps.commands.execute(SET_CONTEXT_COMMAND, key, false);
    }
    await this.tryResetStepCompletion();
    this.opened = false;
  }

  private async tryResetStepCompletion(): Promise<void> {
    const known = await this.collectKnownCommands();
    if (await this.tryPerStepIncomplete(known)) return;
    if (await this.tryBulkReset(known)) return;
    const candidates = await this.suggestResetCandidates(known);
    this.deps.logger(
      `[walkthrough] no known reset-progress command succeeded; ` +
        `editor exposes these walkthrough-related ids: ${candidates.join(", ") || "(none)"}`,
    );
  }

  private async tryPerStepIncomplete(known: ReadonlySet<string>): Promise<boolean> {
    if (known.size > 0 && !known.has(MARK_STEP_INCOMPLETE_COMMAND)) return false;
    try {
      for (const stepId of WALKTHROUGH_STEP_IDS) {
        await this.deps.commands.execute(MARK_STEP_INCOMPLETE_COMMAND, fullStepId(stepId));
      }
      this.deps.logger(`[walkthrough] step-completion reset via ${MARK_STEP_INCOMPLETE_COMMAND}`);
      return true;
    } catch (error) {
      this.deps.logger(
        `[walkthrough] ${MARK_STEP_INCOMPLETE_COMMAND} failed: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
      return false;
    }
  }

  private async tryBulkReset(known: ReadonlySet<string>): Promise<boolean> {
    for (const candidate of BULK_RESET_CANDIDATES) {
      if (known.size > 0 && !known.has(candidate)) continue;
      try {
        await this.deps.commands.execute(candidate);
        this.deps.logger(`[walkthrough] step-completion reset via ${candidate} (bulk)`);
        return true;
      } catch (error) {
        this.deps.logger(
          `[walkthrough] bulk reset ${candidate} failed: ${
            error instanceof Error ? error.message : String(error)
          }`,
        );
      }
    }
    return false;
  }

  private async collectKnownCommands(): Promise<ReadonlySet<string>> {
    try {
      return new Set(await this.deps.commands.list());
    } catch (error) {
      this.deps.logger(
        `[walkthrough] command listing unavailable: ${
          error instanceof Error ? error.message : String(error)
        }`,
      );
      return new Set();
    }
  }

  private async suggestResetCandidates(known: ReadonlySet<string>): Promise<readonly string[]> {
    if (known.size === 0) return [];
    const pattern = /walkthrough|gettingstarted|welcome|reset/i;
    return [...known].filter((id) => pattern.test(id)).sort();
  }

  dispose(): void {
    for (const subscription of this.subscriptions) subscription.dispose();
    this.subscriptions.length = 0;
  }

  private publish(): void {
    const keys = deriveWalkthroughKeys(this.deps.phase.current, this.deps.completedTours.list());
    this.setContextKey(WALKTHROUGH_CONTEXT_KEYS.folderOpen, keys.folderOpen);
    this.setContextKey(WALKTHROUGH_CONTEXT_KEYS.uvInstalled, keys.uvInstalled);
    this.setContextKey(WALKTHROUGH_CONTEXT_KEYS.pyprojectExists, keys.pyprojectExists);
    this.setContextKey(WALKTHROUGH_CONTEXT_KEYS.turbineInstalled, keys.turbineInstalled);
    this.setContextKey(WALKTHROUGH_CONTEXT_KEYS.tourCompleted, keys.tourCompleted);
  }

  private setContextKey(key: string, value: boolean): void {
    void this.deps.commands.execute(SET_CONTEXT_COMMAND, key, value);
  }
}
