import * as vscode from "vscode";

import type { PhaseDto } from "./phase-client";

export type EditorPhase =
  | { readonly kind: "no-folder" }
  | { readonly kind: "needs-uv" }
  | { readonly kind: "needs-turbine-project"; readonly subKind: TurbineProjectGap }
  | { readonly kind: "starting-server" }
  | { readonly kind: "needs-server"; readonly reason: string | null }
  | { readonly kind: "awaiting-server-phase" }
  | { readonly kind: "lsp-phase"; readonly dto: PhaseDto };

export type TurbineProjectGap = "no-pyproject" | "no-turbine-config";

export type TurbineProjectState = TurbineProjectGap | "configured" | "no-active-folder";

export type LspClientState = "stopped" | "starting" | "running";

export interface UvProbe {
  isAvailable(): Promise<boolean>;
}

export interface TurbineProjectProbe {
  /**
   * Inspect the active workspace folder for `pyproject.toml` plus a
   * `[tool.turbine]` section. Returns `"no-active-folder"` when no folder is
   * selected so the phase machine can fall back to other branches.
   */
  inspect(): Promise<TurbineProjectState>;
}

export interface WorkspaceFolderSource {
  hasFolders(): boolean;
  onDidChangeFolders(listener: () => void): vscode.Disposable;
}

export interface LspClientStateSource {
  readonly currentState: LspClientState;
  readonly lastErrorMessage: string | null;
  onDidChangeState(listener: (state: LspClientState) => void): vscode.Disposable;
}

export interface ServerPhaseSource {
  readonly current: PhaseDto | null;
  onPhaseChange(listener: (dto: PhaseDto) => void): vscode.Disposable;
  onCurrentChange(listener: () => void): vscode.Disposable;
}

export interface EditorPhaseServiceDeps {
  readonly uv: UvProbe;
  readonly folders: WorkspaceFolderSource;
  readonly lsp: LspClientStateSource;
  readonly serverPhase: ServerPhaseSource;
  readonly turbineProject: TurbineProjectProbe;
}

function phasesEqual(left: EditorPhase, right: EditorPhase): boolean {
  if (left.kind !== right.kind) return false;
  if (left.kind === "needs-server" && right.kind === "needs-server") {
    return left.reason === right.reason;
  }
  if (left.kind === "needs-turbine-project" && right.kind === "needs-turbine-project") {
    return left.subKind === right.subKind;
  }
  if (left.kind === "lsp-phase" && right.kind === "lsp-phase") {
    return left.dto === right.dto;
  }
  return true;
}

function normalizeReason(message: string | null): string | null {
  if (message === null) return null;
  const trimmed = message.trim();
  return trimmed === "" ? null : trimmed;
}

export class EditorPhaseService implements vscode.Disposable {
  private readonly uv: UvProbe;
  private readonly folders: WorkspaceFolderSource;
  private readonly lsp: LspClientStateSource;
  private readonly serverPhase: ServerPhaseSource;
  private readonly turbineProject: TurbineProjectProbe;
  private readonly emitter: vscode.EventEmitter<EditorPhase>;
  private readonly subscriptions: vscode.Disposable[] = [];
  private uvAvailable = false;
  private turbineProjectState: TurbineProjectState = "configured";
  private phase: EditorPhase = { kind: "no-folder" };
  private started = false;

  constructor(deps: EditorPhaseServiceDeps) {
    this.uv = deps.uv;
    this.folders = deps.folders;
    this.lsp = deps.lsp;
    this.serverPhase = deps.serverPhase;
    this.turbineProject = deps.turbineProject;
    this.emitter = new vscode.EventEmitter<EditorPhase>();
  }

  get current(): EditorPhase {
    return this.phase;
  }

  get onPhaseChange(): vscode.Event<EditorPhase> {
    return this.emitter.event;
  }

  async start(): Promise<void> {
    if (this.started) return;
    this.started = true;
    this.subscriptions.push(
      this.folders.onDidChangeFolders(() => this.refreshTurbineProjectThenRecompute()),
      this.lsp.onDidChangeState(() => this.refreshTurbineProjectThenRecompute()),
      this.serverPhase.onPhaseChange(() => this.recompute()),
      this.serverPhase.onCurrentChange(() => this.refreshTurbineProjectThenRecompute()),
    );
    this.uvAvailable = await this.uv.isAvailable();
    this.turbineProjectState = await this.turbineProject.inspect();
    this.recompute();
  }

  async refresh(): Promise<void> {
    this.uvAvailable = await this.uv.isAvailable();
    this.turbineProjectState = await this.turbineProject.inspect();
    this.recompute();
  }

  dispose(): void {
    for (const subscription of this.subscriptions) subscription.dispose();
    this.subscriptions.length = 0;
    this.emitter.dispose();
  }

  private refreshTurbineProjectThenRecompute(): void {
    void this.turbineProject.inspect().then((state) => {
      this.turbineProjectState = state;
      this.recompute();
    });
    // Fire an immediate recompute too so transient states (e.g. LSP starting)
    // surface before the probe resolves.
    this.recompute();
  }

  private recompute(): void {
    const next = this.computePhase();
    if (phasesEqual(this.phase, next)) return;
    this.phase = next;
    this.emitter.fire(next);
  }

  private computePhase(): EditorPhase {
    if (!this.uvAvailable) return { kind: "needs-uv" };
    if (!this.folders.hasFolders()) return { kind: "no-folder" };
    switch (this.lsp.currentState) {
      case "running": {
        const dto = this.serverPhase.current;
        if (dto === null) return { kind: "awaiting-server-phase" };
        return { kind: "lsp-phase", dto };
      }
      case "starting":
        return { kind: "starting-server" };
      case "stopped": {
        const gap = this.turbineProjectGap();
        if (gap !== null) return { kind: "needs-turbine-project", subKind: gap };
        return { kind: "needs-server", reason: normalizeReason(this.lsp.lastErrorMessage) };
      }
    }
  }

  private turbineProjectGap(): TurbineProjectGap | null {
    if (this.turbineProjectState === "no-pyproject") return "no-pyproject";
    if (this.turbineProjectState === "no-turbine-config") return "no-turbine-config";
    return null;
  }
}
