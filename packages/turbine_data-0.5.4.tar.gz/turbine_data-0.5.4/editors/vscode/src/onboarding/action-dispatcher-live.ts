/** Production factory wiring `OnboardingActionDispatcher` to live VS Code APIs.
 *
 * Kept separate from `action-dispatcher.ts` so unit tests can load the pure
 * class without booting a VS Code extension host (the `vscode` module is
 * only available inside the host).
 */

import * as vscode from "vscode";

import type { TurbineClient } from "../client";
import { type ActiveTourSnapshot, OnboardingActionDispatcher } from "./action-dispatcher";

export function buildLiveActionDispatcher(deps: {
  readonly activeTour: () => ActiveTourSnapshot | null;
  readonly client: () => TurbineClient | null;
  readonly logger: (message: string) => void;
}): OnboardingActionDispatcher {
  return new OnboardingActionDispatcher({
    activeTour: deps.activeTour,
    client: deps.client,
    executeCommand: (command, ...args) => vscode.commands.executeCommand(command, ...args),
    openExternal: (url) => vscode.env.openExternal(vscode.Uri.parse(url)),
    logger: deps.logger,
  });
}
