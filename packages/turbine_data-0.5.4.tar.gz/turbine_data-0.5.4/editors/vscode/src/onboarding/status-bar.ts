import * as vscode from "vscode";

import type { EditorPhase, EditorPhaseService } from "./editor-phase";
import type { PhaseDto } from "./phase-client";

const SHOW_COMMAND = "turbine.onboarding.show";

interface PhaseLabel {
  readonly text: string;
  readonly tooltip: string;
}

function labelFor(phase: EditorPhase): PhaseLabel {
  switch (phase.kind) {
    case "no-folder":
      return { text: "$(folder) Turbine: needs setup", tooltip: "Open a folder to start using Turbine." };
    case "needs-uv":
      return { text: "$(warning) Turbine: uv missing", tooltip: "Install uv to set up Turbine." };
    case "starting-server":
      return { text: "$(sync~spin) Turbine: starting…", tooltip: "Turbine LSP is starting." };
    case "awaiting-server-phase":
      return { text: "$(sync~spin) Turbine: starting…", tooltip: "Reading project state." };
    case "needs-server":
      return { text: "$(error) Turbine: stopped", tooltip: phase.reason ?? "Turbine LSP is not running." };
    case "needs-turbine-project":
      if (phase.subKind === "no-pyproject") {
        return { text: "$(folder) Turbine: needs setup", tooltip: "Initialize a Python project." };
      }
      return { text: "$(folder) Turbine: needs setup", tooltip: "Add Turbine to this project." };
    case "lsp-phase":
      return labelForLspPhase(phase.dto.kind);
  }
}

function labelForLspPhase(kind: PhaseDto["kind"]): PhaseLabel {
  switch (kind) {
    case "needs-pyproject":
      return { text: "$(folder) Turbine: needs setup", tooltip: "Initialize a Python project." };
    case "needs-turbine":
      return { text: "$(folder) Turbine: needs setup", tooltip: "Pick a database to install Turbine." };
    case "ready-tour-pending":
      return { text: "$(check) Turbine: ready", tooltip: "Turbine is ready." };
    case "ready":
      return { text: "$(check) Turbine: ready", tooltip: "Turbine is ready." };
  }
}

export class OnboardingStatusBar implements vscode.Disposable {
  private readonly item: vscode.StatusBarItem;
  private readonly subscription: vscode.Disposable;
  private label: PhaseLabel;

  constructor(phaseService: EditorPhaseService) {
    this.item = vscode.window.createStatusBarItem(vscode.StatusBarAlignment.Left, 100);
    this.item.command = SHOW_COMMAND;
    this.label = labelFor(phaseService.current);
    this.applyLabel();
    this.item.show();
    this.subscription = phaseService.onPhaseChange((phase) => {
      this.label = labelFor(phase);
      this.applyLabel();
    });
  }

  get currentLabel(): string {
    return this.label.text;
  }

  dispose(): void {
    this.subscription.dispose();
    this.item.dispose();
  }

  private applyLabel(): void {
    this.item.text = this.label.text;
    this.item.tooltip = this.label.tooltip;
  }
}
