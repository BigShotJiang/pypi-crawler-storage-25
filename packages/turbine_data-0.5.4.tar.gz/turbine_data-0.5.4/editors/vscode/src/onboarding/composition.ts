import * as vscode from "vscode";

import type { FolderRegistry } from "../lsp/folder-registry";
import { resolveCommand } from "../lsp/resolve-command";
import type { StepActionKind } from "../types";
import type { OnboardingActionDispatcher } from "./action-dispatcher";
import { buildLiveActionDispatcher } from "./action-dispatcher-live";
import { ActiveOnboardingFolder } from "./active-folder";
import { LspClientStateAggregator, ServerPhaseAggregator } from "./aggregators";
import { EditorPhaseService } from "./editor-phase";
import { OnboardingStatusBar } from "./status-bar";
import { createTourEngineHost, type TourEngineHost } from "./tour-engine-host";
import { OnboardingTourPanel } from "./tour-view";
import { ChildProcessUvProbe } from "./uv-probe";
import { ONBOARDING_VIEW_ID, OnboardingViewProvider } from "./view";
import {
  FilesystemTurbineProjectProbe,
  WorkspaceActiveEditorSource,
  WorkspaceFolderSourceImpl,
  WorkspaceOnboardingFolderSource,
} from "./vscode-sources";
import { WalkthroughHost } from "./walkthrough-host";

/**
 * A "natural observer" reports whether a tour-relevant editor state is
 * currently true. Whenever the tour engine arms a new step, the composition
 * walks every registered observer; any that report true fire `notify(kind)`
 * so a Step armed-on-arrival with its action already performed unlocks
 * immediately without waiting for a state transition.
 *
 * Observers also subscribe to their underlying VS Code event (e.g.
 * `TreeView.onDidChangeVisibility`) and fire `notify(kind)` directly on
 * transitions for the live case. The composition does not own the
 * subscription; the caller wires it before/after constructing the
 * composition with the dispatcher reference.
 */
export interface NaturalActionObserver {
  readonly kind: StepActionKind;
  readonly isActive: () => boolean;
}

export interface OnboardingCompositionDeps {
  readonly context: vscode.ExtensionContext;
  readonly registry: FolderRegistry;
  readonly logger: (message: string) => void;
  /** Editor states that should unlock a tour step on arming if already true. */
  readonly naturalObservers?: readonly NaturalActionObserver[];
}

/**
 * Composes the onboarding subsystem: aggregators, phase service, entry view,
 * tour view, status bar, and tour host. Subscribes to the FolderRegistry so
 * per-folder lifecycle (start / stop / start failed) is reflected in the
 * aggregators.
 *
 * Initialisation order matters: aggregators must exist before any folder
 * starts, and `phaseService.start()` must run before the first folder is
 * brought up. The constructor builds aggregators; `start()` subscribes to
 * the registry then awaits `phaseService.start()`.
 */
export class OnboardingComposition implements vscode.Disposable {
  readonly stateAggregator: LspClientStateAggregator;
  readonly phaseAggregator: ServerPhaseAggregator;
  readonly activeFolder: ActiveOnboardingFolder;
  readonly phaseService: EditorPhaseService;
  readonly viewProvider: OnboardingViewProvider;
  readonly tourPanel: OnboardingTourPanel;
  readonly statusBar: OnboardingStatusBar;
  readonly tourHost: TourEngineHost;
  readonly walkthroughHost: WalkthroughHost;
  readonly actionDispatcher: OnboardingActionDispatcher;

  private readonly registry: FolderRegistry;
  private readonly subscriptions: vscode.Disposable[] = [];
  private readonly naturalObservers: readonly NaturalActionObserver[];
  private readonly logger: (message: string) => void;

  constructor(deps: OnboardingCompositionDeps) {
    const { context, registry, logger } = deps;
    this.registry = registry;
    this.logger = logger;
    this.naturalObservers = deps.naturalObservers ?? [];

    this.stateAggregator = new LspClientStateAggregator(() => registry.clientEntries());
    this.activeFolder = new ActiveOnboardingFolder({
      folders: new WorkspaceOnboardingFolderSource(),
      activeEditor: new WorkspaceActiveEditorSource(),
    });
    this.phaseAggregator = new ServerPhaseAggregator(this.activeFolder);
    this.phaseService = new EditorPhaseService({
      uv: new ChildProcessUvProbe(resolveCommand("uv")),
      folders: new WorkspaceFolderSourceImpl(),
      lsp: this.stateAggregator,
      serverPhase: this.phaseAggregator,
      turbineProject: new FilesystemTurbineProjectProbe(this.activeFolder),
    });

    this.tourHost = createTourEngineHost({
      context,
      clientFor: (key) => registry.get(key)?.client,
      layoutRootFor: (key) => registry.get(key)?.workspaceConfig.root ?? null,
      logger,
      // Lazy: actionDispatcher is constructed after tourHost (needs the
      // engine for activeSnapshot()). The closure resolves to the live
      // dispatcher whenever the engine actually invokes it (FINAL_HANDOFF).
      dispatchStepAction: (action) => this.actionDispatcher.dispatchStepAction(action),
      panelViewColumn: () => this.tourPanel.viewColumn,
    });

    this.viewProvider = new OnboardingViewProvider({
      phaseService: this.phaseService,
      extensionUri: context.extensionUri,
      active: this.activeFolder,
      phaseClient: (key) => registry.get(key)?.phaseClient ?? null,
      installRunner: (key) => registry.installRunnerForKey(key),
      completedToursMachineWide: () => this.tourHost.completedTours.list(),
      logger,
    });

    this.tourPanel = new OnboardingTourPanel({
      extensionUri: context.extensionUri,
      phaseService: this.phaseService,
      active: this.activeFolder,
      tourEngine: this.tourHost.engine,
      tourProgress: this.tourHost.progress,
      completedToursMachineWide: () => this.tourHost.completedTours.list(),
      logger,
    });

    this.tourHost.panelChannel.post = (message) => {
      this.tourPanel.postToWebview(message);
      if (message.type === "tour-step") {
        // On every step arm, fire actionInvoked for any natural observer
        // whose state is currently true. Covers the "user already opened
        // the All Contracts panel before reaching this step" case where
        // onDidChangeVisibility never fires post-arm.
        this.fireActiveNaturalObservers();
      }
      if (message.type === "tour-step-completed") {
        // Keep the picker's per-tour progress fresh between steps so
        // "All tours" reflects partial progress without a manual refresh.
        this.tourPanel.refreshFromExternal();
      }
      if (message.type === "tour-finished") {
        this.viewProvider.refreshFromExternal();
        this.tourPanel.refreshFromExternal();
        this.walkthroughHost.refresh();
      }
    };

    this.statusBar = new OnboardingStatusBar(this.phaseService);

    // Single funnel for onboarding action invocations. ADR 0015 makes this
    // a one-funnel-per-IDE rule: the dispatcher resolves the active tour
    // from the engine and, for editor-only kinds, notifies the LSP via
    // `turbine/onboarding/actionInvoked` while running the underlying
    // interaction (VS Code command, external URL, or notify-only). LSP-
    // routed kinds (run_validate, run_single_check, run_sandbox_checks)
    // are observed intrinsically by their server-side handlers — the
    // dispatcher knows this and skips the notification for those.
    this.actionDispatcher = buildLiveActionDispatcher({
      activeTour: () => this.tourHost.engine.activeSnapshot(),
      client: () => {
        const key = this.activeFolder.currentKey;
        if (key === null) return null;
        return registry.get(key)?.client ?? null;
      },
      logger,
    });

    this.walkthroughHost = new WalkthroughHost({
      globalState: context.globalState,
      commands: {
        execute: (command, ...args) => vscode.commands.executeCommand(command, ...args),
        list: () => Promise.resolve(vscode.commands.getCommands(true)),
      },
      phase: this.phaseService,
      completedTours: this.tourHost.completedTours,
      logger,
    });

    context.subscriptions.push(
      this.stateAggregator,
      this.activeFolder,
      this.phaseAggregator,
      this.phaseService,
      this.viewProvider,
      this.tourPanel,
      this.tourHost.engine,
      this.statusBar,
      this.walkthroughHost,
      vscode.window.registerWebviewViewProvider(ONBOARDING_VIEW_ID, this.viewProvider),
      // Public command for editor-only action invocations. Sidebar buttons
      // and codelens chips that map to a tour-relevant action call this
      // command instead of `vscode.commands.executeCommand` directly so the
      // LSP's ActionFired watcher hears the click.
      vscode.commands.registerCommand(
        "turbine.onboarding.dispatchAction",
        (kind: StepActionKind, command: string, ...args: readonly unknown[]) =>
          this.actionDispatcher.dispatch(kind, command, ...args),
      ),
    );
  }

  /**
   * Notify the LSP that an editor-only onboarding action kind was performed
   * by the user. Called by natural-action observers (tree-view visibility,
   * URL openers, terminal-command listeners) — anything that captures the
   * user gesture without going through a panel button.
   */
  notifyActionInvoked(kind: StepActionKind): void {
    this.actionDispatcher.notify(kind);
  }

  /**
   * Push the current visibility of an editor surface (tree view, panel) to
   * every active LSP client so server-side ``SurfaceVisible`` watchers can
   * fire on the false→true edge — including the case where the surface is
   * already visible when a tour step arms. Called on every transition and
   * once on activation to seed initial state. Errors are logged
   * fire-and-forget; visibility is signalling, not a request the user is
   * waiting on.
   */
  notifySurfaceVisibility(surfaceId: string, visible: boolean): void {
    for (const [, client] of this.registry.clientEntries()) {
      void client
        .surfaceVisibilityChanged({ surfaceId, visible })
        .catch((error: unknown) => {
          const message = error instanceof Error ? error.message : String(error);
          this.logger(
            `[onboarding] surfaceVisibilityChanged failed for ${surfaceId}: ${message}`,
          );
        });
    }
  }

  private fireActiveNaturalObservers(): void {
    for (const observer of this.naturalObservers) {
      if (observer.isActive()) this.actionDispatcher.notify(observer.kind);
    }
  }

  async start(): Promise<void> {
    this.subscriptions.push(
      this.registry.onClientStarted((entry) => {
        this.stateAggregator.attach(entry.key, entry.client);
        this.stateAggregator.clearError(entry.key);
        this.phaseAggregator.attach(entry.key, entry.phaseClient);
      }),
      this.registry.onClientStartFailed(({ key, message }) => {
        this.stateAggregator.unsubscribe(key);
        this.stateAggregator.recordError(key, message);
        this.phaseAggregator.detach(key);
      }),
      this.registry.onBeforeStop((entry) => {
        this.stateAggregator.forget(entry.key);
        this.phaseAggregator.detach(entry.key);
      }),
    );

    await this.phaseService.start();
    this.walkthroughHost.start();
  }

  async maybeOpenWalkthrough(): Promise<void> {
    await this.walkthroughHost.maybeOpen();
  }

  async resetActive(): Promise<void> {
    const key = this.activeFolder.currentKey;
    const phaseClient = key === null ? null : (this.registry.get(key)?.phaseClient ?? null);
    if (phaseClient !== null && key !== null) {
      await phaseClient.reset({ workspaceFolderUri: key });
    }
    await this.tourHost.completedTours.clear();
    await this.walkthroughHost.reset();
    await this.phaseService.refresh();
    this.viewProvider.refreshFromExternal();
    this.tourPanel.refreshFromExternal();
  }

  async show(): Promise<void> {
    await this.viewProvider.show();
  }

  showTour(): void {
    this.tourPanel.show();
  }

  dispose(): void {
    for (const subscription of this.subscriptions) subscription.dispose();
    this.subscriptions.length = 0;
  }
}
