/**
 * Composition root for the editor-side tour engine.
 *
 * Bundles the four small adapters the engine needs (LSP-backed tour-progress
 * store, globalState-backed completed-tours store, tour-target reveal, panel
 * channel) plus the highlight decoration setup. Pulled out of `extension.ts`
 * so activation orchestration stays single-concern: extension.ts wires
 * subsystems together; this file owns the tour subsystem's plumbing.
 */

import * as path from "node:path";
import * as vscode from "vscode";

import type { TurbineClient } from "../client";
import type { ResolvedHighlight, StepAction } from "../types";
import {
  type CompletedToursStore,
  TourEngine,
  type TourPanelChannel,
  type TourProgressRecord,
  type TourProgressStore,
  type TourTargetReveal,
} from "./tour-engine";

const COMPLETED_TOURS_KEY = "turbine.onboarding.completedTours";

export interface TourEngineHost {
  readonly engine: TourEngine;
  readonly panelChannel: TourPanelChannel;
  readonly completedTours: CompletedToursStore;
  readonly progress: TourProgressStore;
}

interface HostDeps {
  readonly context: vscode.ExtensionContext;
  readonly clientFor: (key: string) => TurbineClient | undefined;
  /**
   * Returns the absolute layout root (typically ``<workspace>/src/<pkg>/``)
   * for *key*, or null when no LSP client is known for the folder yet. Tour
   * step targets are layout-root-relative, so the reveal adapter joins this
   * to ``target.file`` to land on the right file on disk.
   */
  readonly layoutRootFor: (key: string) => string | null;
  readonly logger: (message: string) => void;
  /** Routes the engine's FINAL_HANDOFF (and any future engine-driven action) through the dispatcher. */
  readonly dispatchStepAction: (action: StepAction) => Promise<void>;
  /**
   * Returns the column of the onboarding tour panel (if open). The reveal
   * adapter uses this to keep the panel and the tour-revealed file in
   * different columns when the panel is the sole occupant of column 1.
   */
  readonly panelViewColumn?: () => vscode.ViewColumn | undefined;
}

/**
 * Build the tour engine and its adapter web. The returned `panelChannel`
 * starts with a no-op `post`; the caller (extension.ts) overrides it once the
 * `OnboardingViewProvider` exists. This indirection breaks an otherwise
 * circular construction dependency between the engine and the panel.
 */
export function createTourEngineHost(deps: HostDeps): TourEngineHost {
  const { context, clientFor, layoutRootFor, logger } = deps;

  const progress: TourProgressStore = {
    async load(workspaceFolderUri, tourId) {
      const client = clientFor(workspaceFolderUri);
      if (client === undefined) return null;
      const result = (await client.lsp.sendRequest("turbine/onboarding/getTourProgress", {
        workspaceFolderUri,
        tourId,
      })) as { record: TourProgressRecord | null };
      return result.record;
    },
    async save(record) {
      const client = clientFor(record.workspaceFolderUri);
      if (client === undefined) return;
      await client.lsp.sendRequest("turbine/onboarding/saveTourProgress", { record });
    },
  };

  const completedTours: CompletedToursStore = {
    list() {
      return context.globalState.get<string[]>(COMPLETED_TOURS_KEY) ?? [];
    },
    async markCompleted(tourId) {
      const current = context.globalState.get<string[]>(COMPLETED_TOURS_KEY) ?? [];
      if (current.includes(tourId)) return;
      await context.globalState.update(COMPLETED_TOURS_KEY, [...current, tourId]);
    },
    async clear() {
      await context.globalState.update(COMPLETED_TOURS_KEY, []);
    },
  };

  const reveal = createTargetReveal(context, logger, deps.panelViewColumn ?? (() => undefined));
  const panelChannel: TourPanelChannel = { post: () => undefined };

  const engine = new TourEngine({
    client: (folderUri) => clientFor(folderUri) ?? null,
    workspaceRootFor: (folderUri) => {
      // Prefer the LSP-pushed layout root (e.g. ``<workspace>/src/<pkg>/``)
      // so tour reveals land on the right file when the project follows the
      // src layout. Fall back to the workspace folder fsPath only when the
      // LSP hasn't pushed a workspaceConfig yet (pre-start moments).
      const layoutRoot = layoutRootFor(folderUri);
      if (layoutRoot !== null) return layoutRoot;
      const folder = (vscode.workspace.workspaceFolders ?? []).find(
        (entry) => entry.uri.toString() === folderUri,
      );
      return folder === undefined ? folderUri : folder.uri.fsPath;
    },
    progress,
    completed: completedTours,
    channel: { post: (message) => panelChannel.post(message) },
    dispatchStepAction: deps.dispatchStepAction,
    reveal,
    logger,
    schedule: (callback, delayMs) => {
      const timer = setTimeout(callback, delayMs);
      return { dispose: () => clearTimeout(timer) };
    },
  });

  return { engine, panelChannel, completedTours, progress };
}

/**
 * Build the reveal adapter plus its single shared decoration. The decoration
 * lifetime is tied to the extension context so vscode disposes it on
 * deactivation.
 *
 * `target.file` is workspace-relative (e.g. `contracts/foo.yml`); we resolve
 * it against the workspace root. Turbine ranges are 1-indexed for both line
 * and column; vscode is 0-indexed, so we subtract 1 with a floor at 0.
 */
function createTargetReveal(
  context: vscode.ExtensionContext,
  logger: (message: string) => void,
  panelViewColumn: () => vscode.ViewColumn | undefined,
): TourTargetReveal {
  const decoration = vscode.window.createTextEditorDecorationType({
    borderWidth: "0 0 0 3px",
    borderStyle: "solid",
    borderColor: new vscode.ThemeColor("focusBorder"),
    backgroundColor: new vscode.ThemeColor("editor.findMatchHighlightBackground"),
    isWholeLine: true,
    overviewRulerColor: new vscode.ThemeColor("focusBorder"),
    overviewRulerLane: vscode.OverviewRulerLane.Left,
  });
  context.subscriptions.push(decoration);

  let lastEditor: vscode.TextEditor | null = null;
  function clearLast(): void {
    if (lastEditor !== null) {
      lastEditor.setDecorations(decoration, []);
      lastEditor = null;
    }
  }

  return {
    async reveal(workspaceRoot: string, target: ResolvedHighlight | null): Promise<void> {
      clearLast();
      if (target === null) return;
      if (target.kind !== "editor_range" || target.file === null) return;
      const absolutePath = path.isAbsolute(target.file)
        ? target.file
        : path.join(workspaceRoot, target.file);
      // When the onboarding panel is the only thing in column 1, opening the
      // file at ViewColumn.One adds it to the panel's group (the panel
      // becomes a sibling tab and gets hidden). Open Beside in that case so
      // the file lands in a fresh group, then swap groups so the file ends
      // up on the left and the panel on the right.
      const panelColumn = panelViewColumn();
      const panelInColumnOne = panelColumn === vscode.ViewColumn.One;
      const targetColumn = panelInColumnOne ? vscode.ViewColumn.Beside : vscode.ViewColumn.One;
      try {
        const document = await vscode.workspace.openTextDocument(vscode.Uri.file(absolutePath));
        const editor = await vscode.window.showTextDocument(document, {
          viewColumn: targetColumn,
          preview: true,
          preserveFocus: false,
        });
        if (panelInColumnOne) {
          await vscode.commands.executeCommand("workbench.action.moveActiveEditorGroupLeft");
        }
        if (target.range !== null) {
          const [startLine, , endLine] = target.range;
          const range = new vscode.Range(
            new vscode.Position(Math.max(0, startLine - 1), 0),
            new vscode.Position(Math.max(0, endLine - 1), 0),
          );
          editor.setDecorations(decoration, [range]);
          editor.revealRange(range, vscode.TextEditorRevealType.InCenter);
          lastEditor = editor;
        }
      } catch (error) {
        logger(
          `[tour-engine] reveal failed for ${absolutePath}: ${
            error instanceof Error ? error.message : String(error)
          }`,
        );
      }
    },
  };
}
