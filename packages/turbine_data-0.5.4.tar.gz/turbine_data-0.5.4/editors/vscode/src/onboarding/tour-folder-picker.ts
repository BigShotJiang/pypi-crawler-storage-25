import * as vscode from "vscode";

/**
 * Show a native folder picker and open the chosen folder in a new VS Code
 * window. Used by the tour entry flow when the active workspace is not empty
 * enough to host the demo scaffold without stepping on user content. The new
 * window starts a fresh LSP session in the picked folder; the original
 * window is left untouched so the user's other work stays open.
 *
 * Returns the picked folder URI when the user selected one, or null when the
 * user cancelled.
 */
export async function pickFreshTourFolder(): Promise<vscode.Uri | null> {
  const picked = await vscode.window.showOpenDialog({
    canSelectFolders: true,
    canSelectFiles: false,
    canSelectMany: false,
    openLabel: "Select an empty folder for the tour",
    title: "Pick an empty folder for the Turbine onboarding tour",
  });
  if (picked === undefined || picked.length === 0) return null;
  const folderUri = picked[0];
  if (folderUri === undefined) return null;
  await vscode.commands.executeCommand("vscode.openFolder", folderUri, { forceNewWindow: true });
  return folderUri;
}
