/**
 * Run quality checks on every contract in the workspace.
 *
 * Registered as the `turbine.runQualityWorkspace` command. Sends a single
 * `turbine/runCheck` request with `all: true`; the server expands to every
 * contract location and streams a nested `$/progress` pair (outer
 * "Running all contracts" toast, inner per-schema toast) which the
 * extension-level `ProgressToastManager` renders. The flat outcome list
 * comes back in one `RunCheckResult`.
 */

import { randomUUID } from "node:crypto";

import * as vscode from "vscode";
import { WorkDoneProgress } from "vscode-languageserver-protocol";

import type { TurbineClient } from "./client";
import { pickDatasource } from "./execution";
import { showLspClientUnavailableMessage } from "./lsp-client-unavailable";
import type { CheckResultItem, RunCheckResult } from "./types";

const OUTPUT = vscode.window.createOutputChannel("Turbine Run All");

export function registerRunAll(
  context: vscode.ExtensionContext,
  getClient: () => TurbineClient | undefined,
  lspOutput: vscode.OutputChannel,
  onComplete?: () => void,
): void {
  context.subscriptions.push(
    vscode.commands.registerCommand("turbine.runQualityWorkspace", async () => {
      const client = getClient();
      if (!client) {
        await showLspClientUnavailableMessage(lspOutput);
        return;
      }

      const anchorUri = await resolveAnchorUri(client);
      if (anchorUri === null) {
        vscode.window.showInformationMessage("No contracts in this workspace.");
        return;
      }

      const datasource = await pickDatasource(client.lsp, anchorUri);
      if (datasource === undefined) return;

      const result = await runWholeWorkspace(client, anchorUri, datasource);
      writeOutput(result);
      announceSummary(result);
      onComplete?.();
    }),
    OUTPUT,
  );
}

/**
 * Pick a contract URI to anchor the run-all request.
 *
 * The server uses the anchor to resolve the project root and the per-project
 * datasource catalogue. With one Turbine project per workspace folder, the
 * active editor still decides which folder we're running against in a
 * multi-root workspace; we fall back to the first indexed contract only when
 * no editor is active. Returns null when the workspace has no contracts.
 */
async function resolveAnchorUri(client: TurbineClient): Promise<string | null> {
  const activeUri = vscode.window.activeTextEditor?.document.uri;
  if (activeUri?.scheme === "file" && /\.ya?ml$/i.test(activeUri.fsPath)) {
    return activeUri.toString();
  }
  try {
    const overview = await client.overviewData();
    if (overview.contracts.length === 0) return null;
    return overview.contracts[0].uri;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    vscode.window.showErrorMessage(`Failed to list contracts: ${message}`);
    return null;
  }
}

interface WorkspaceRunOutcome {
  result: RunCheckResult | null;
  error: string | null;
}

async function runWholeWorkspace(
  client: TurbineClient,
  anchorUri: string,
  datasource: string,
): Promise<WorkspaceRunOutcome> {
  const workDoneToken = randomUUID();
  const logSubscription = client.onCheckLog((params) => {
    if (params.operationToken !== workDoneToken) {
      return;
    }
    OUTPUT.appendLine(params.line);
    if (params.excerpt) {
      OUTPUT.appendLine(params.excerpt);
    }
  });
  const progressSubscription = client.lsp.onProgress(WorkDoneProgress.type, workDoneToken, () => undefined);
  try {
    const result = await client.runCheck({
      uri: anchorUri,
      datasource,
      all: true,
      workDoneToken,
    });
    return { result, error: result.error ?? null };
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return { result: null, error: message };
  } finally {
    progressSubscription.dispose();
    logSubscription.dispose();
  }
}

function writeOutput(outcome: WorkspaceRunOutcome): void {
  OUTPUT.appendLine(`\n── Workspace run @ ${new Date().toISOString()} ──`);
  if (outcome.error !== null) {
    OUTPUT.appendLine(`  ✗ workspace run errored: ${outcome.error}`);
    return;
  }
  const result = outcome.result;
  if (result === null) {
    OUTPUT.appendLine("  ? no result");
    return;
  }
  const total = result.outcomes.length;
  const failed = result.outcomes.filter((item) => item.outcome === "failed").length;
  const status = result.passed ? "✓" : "✗";
  OUTPUT.appendLine(`  ${status} ${total - failed}/${total} checks passed`);

  const groups = groupByContract(result.outcomes);
  for (const [contractId, items] of groups) {
    const header = contractId === "" ? "(unknown contract)" : contractId;
    OUTPUT.appendLine(`    ${header}`);
    for (const item of items) {
      if (item.outcome === "passed") continue;
      OUTPUT.appendLine(`      • ${formatFailure(item)}`);
    }
  }
}

function groupByContract(items: CheckResultItem[]): Map<string, CheckResultItem[]> {
  const groups = new Map<string, CheckResultItem[]>();
  for (const item of items) {
    const key = item.contractId ?? "";
    const bucket = groups.get(key);
    if (bucket === undefined) {
      groups.set(key, [item]);
      continue;
    }
    bucket.push(item);
  }
  return groups;
}

function formatFailure(item: CheckResultItem): string {
  const suffix = item.isRowBased ? ` (${item.rowsFailed}/${item.rowsTested} rows)` : "";
  return `${item.checkName}: ${item.outcome}${suffix}`;
}

function announceSummary(outcome: WorkspaceRunOutcome): void {
  if (outcome.error !== null) {
    vscode.window.showErrorMessage(`Workspace run failed: ${outcome.error}`);
    return;
  }
  const result = outcome.result;
  if (result === null) return;
  const total = result.outcomes.length;
  const failed = result.outcomes.filter((item) => item.outcome === "failed").length;
  const passed = total - failed;
  const summary = `Workspace run: ${passed}/${total} checks passed · ${failed} failed`;
  const showDetails = "Show Output";
  vscode.window.showInformationMessage(summary, showDetails).then((picked) => {
    if (picked === showDetails) OUTPUT.show(true);
  });
}
