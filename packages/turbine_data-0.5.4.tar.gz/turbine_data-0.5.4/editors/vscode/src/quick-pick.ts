/**
 * Quick contract picker — fuzzy QuickPick over every contract in the workspace.
 *
 * Registered as the `turbine.jumpToContract` command. Items are sourced from
 * `turbine/overviewData` so the picker reflects the current workspace state.
 */

import * as vscode from "vscode";

import type { TurbineClient } from "./client";
import { showLspClientUnavailableMessage } from "./lsp-client-unavailable";
import type { CheckOutcome } from "./types";

interface ContractPickItem extends vscode.QuickPickItem {
  uri: string;
}

export function registerQuickContractPicker(
  context: vscode.ExtensionContext,
  getClient: () => TurbineClient | undefined,
  output: vscode.OutputChannel,
): void {
  context.subscriptions.push(
    vscode.commands.registerCommand("turbine.jumpToContract", async () => {
      const client = getClient();
      if (!client) {
        await showLspClientUnavailableMessage(output);
        return;
      }
      let items: ContractPickItem[];
      try {
        const overview = await client.overviewData();
        items = overview.contracts.map(
          (contract): ContractPickItem => ({
            label: contract.contractId,
            description: describeStatus(contract.checkStatus),
            uri: contract.uri,
          }),
        );
      } catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        vscode.window.showErrorMessage(`Failed to list contracts: ${message}`);
        return;
      }

      if (items.length === 0) {
        vscode.window.showInformationMessage("No contracts in this workspace.");
        return;
      }

      const picked = await vscode.window.showQuickPick(items, {
        placeHolder: "Jump to contract…",
        matchOnDescription: true,
      });
      if (!picked) return;

      const doc = await vscode.workspace.openTextDocument(vscode.Uri.parse(picked.uri));
      await vscode.window.showTextDocument(doc, { preview: false });
    }),
  );
}

function describeStatus(status: CheckOutcome | null): string {
  if (status === null) return "no checks";
  return status;
}
