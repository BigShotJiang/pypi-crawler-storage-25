import * as fs from "node:fs/promises";
import * as path from "node:path";

const TURBINE_SECTION_RE = /^\s*\[tool\.turbine\](\s|$)/m;

/**
 * Returns true when *workspacePath* contains a `pyproject.toml` that declares
 * a `[tool.turbine]` section. Used by the folder registry to gate LSP startup:
 * only folders that already opted into Turbine get an LSP client.
 */
export async function isExistingTurbineProject(workspacePath: string): Promise<boolean> {
  const pyprojectPath = path.join(workspacePath, "pyproject.toml");
  try {
    const content = await fs.readFile(pyprojectPath, "utf8");
    return TURBINE_SECTION_RE.test(content);
  } catch {
    return false;
  }
}
