import * as assert from "node:assert/strict";

import Module = require("node:module");

import type {
  CompletedToursStore,
  TourEngineDeps,
  TourEngineOutbound,
  TourEnginePanelMessage,
  TourEngine as TourEngineType,
  TourPanelChannel,
  TourProgressRecord,
  TourProgressStore,
  TourTargetReveal,
} from "../../../onboarding/tour-engine";
import type {
  CheckWorkspaceEmptyResult,
  ListToursResult,
  ResolvedHighlight,
  ScaffoldProjectResult,
  StepAction,
  StepCompletedParams,
  StepDto,
} from "../../../types";

type ModuleLoad = (request: string, parent: NodeModule | null | undefined, isMain: boolean) => unknown;

interface FakeDisposable {
  dispose(): void;
}

class FakeEventEmitter<T> {
  private listeners: Array<(value: T) => void> = [];

  readonly event = (listener: (value: T) => void): FakeDisposable => {
    this.listeners.push(listener);
    return {
      dispose: () => {
        this.listeners = this.listeners.filter((entry) => entry !== listener);
      },
    };
  };

  fire(value: T): void {
    for (const listener of [...this.listeners]) listener(value);
  }

  dispose(): void {
    this.listeners = [];
  }
}

const fakeVscode = {
  EventEmitter: FakeEventEmitter,
  Disposable: {
    from(...disposables: FakeDisposable[]): FakeDisposable {
      return {
        dispose: () => {
          for (const disposable of disposables) disposable.dispose();
        },
      };
    },
  },
};

async function loadModule(): Promise<typeof import("../../../onboarding/tour-engine")> {
  const moduleWithLoad = Module as typeof Module & { _load: ModuleLoad };
  const originalLoad = moduleWithLoad._load;
  moduleWithLoad._load = (request, parent, isMain) => {
    if (request === "vscode") return fakeVscode;
    return originalLoad(request, parent, isMain);
  };
  try {
    return await import("../../../onboarding/tour-engine.js");
  } finally {
    moduleWithLoad._load = originalLoad;
  }
}

function step(id: string, gated = false): StepDto {
  return {
    id,
    title: `Step ${id}`,
    content: [],
    target: { kind: "ui", targetId: `tour-panel:${id}` } as unknown as StepDto["target"],
    resolvedTarget: null,
    kind: "narration" as unknown as StepDto["kind"],
    action: null,
    skipKind: "none" as unknown as StepDto["skipKind"],
    gated,
  };
}

function tour(id: string, steps: StepDto[]): { id: string; title: string; steps: StepDto[] } {
  return { id, title: `Tour ${id}`, steps };
}

class FakeChannel implements TourPanelChannel {
  posts: TourEngineOutbound[] = [];
  post(message: TourEngineOutbound): void {
    this.posts.push(message);
  }
}

class FakeProgressStore implements TourProgressStore {
  saved: TourProgressRecord[] = [];
  loaded: TourProgressRecord | null = null;

  async load(): Promise<TourProgressRecord | null> {
    return this.loaded;
  }

  async save(record: TourProgressRecord): Promise<void> {
    this.saved.push(record);
  }
}

class FakeCompletedStore implements CompletedToursStore {
  ids: string[] = [];
  list(): readonly string[] {
    return this.ids;
  }
  async markCompleted(tourId: string): Promise<void> {
    if (!this.ids.includes(tourId)) this.ids.push(tourId);
  }
  async clear(): Promise<void> {
    this.ids = [];
  }
}

class FakeStepActionDispatcher {
  invocations: StepAction[] = [];
  async dispatch(action: StepAction): Promise<void> {
    this.invocations.push(action);
  }
}

class FakeReveal implements TourTargetReveal {
  revealed: Array<{ workspaceRoot: string; target: ResolvedHighlight | null }> = [];
  async reveal(workspaceRoot: string, target: ResolvedHighlight | null): Promise<void> {
    this.revealed.push({ workspaceRoot, target });
  }
}

class FakeTurbineClient {
  listToursImpl: () => Promise<ListToursResult> = async () => ({
    tours: [
      tour("foundations", [step("step-1"), step("step-2")]),
      tour("quality-checks", [step("only-step")]),
    ] as unknown as ListToursResult["tours"],
  });
  checkEmptyImpl: () => Promise<CheckWorkspaceEmptyResult> = async () => ({ empty: true, reasons: [] });
  scaffoldImpl: () => Promise<ScaffoldProjectResult> = async () => ({ createdFiles: [] });
  scaffoldDelay = 0;
  scaffoldCalls = 0;
  watchedSteps: Array<{ tourId: string; stepId: string }> = [];
  unwatched = 0;
  stepCompletedHandlers: Array<(params: StepCompletedParams) => void> = [];

  async listTours(): Promise<ListToursResult> {
    return this.listToursImpl();
  }

  async checkWorkspaceEmpty(): Promise<CheckWorkspaceEmptyResult> {
    return this.checkEmptyImpl();
  }

  async scaffoldProject(): Promise<ScaffoldProjectResult> {
    this.scaffoldCalls += 1;
    if (this.scaffoldDelay > 0) {
      await new Promise<void>((resolve) => setTimeout(resolve, this.scaffoldDelay));
    }
    return this.scaffoldImpl();
  }

  async watchStep(params: { tourId: string; stepId: string }): Promise<void> {
    this.watchedSteps.push(params);
  }

  async unwatchStep(): Promise<void> {
    this.unwatched += 1;
  }

  onStepCompleted(handler: (params: StepCompletedParams) => void): FakeDisposable {
    this.stepCompletedHandlers.push(handler);
    return {
      dispose: () => {
        this.stepCompletedHandlers = this.stepCompletedHandlers.filter((h) => h !== handler);
      },
    };
  }

  fireStepCompleted(params: StepCompletedParams): void {
    for (const handler of [...this.stepCompletedHandlers]) handler(params);
  }
}

interface ScheduledTimer {
  callback: () => void;
  delayMs: number;
  cancelled: boolean;
}

class TestClock {
  scheduled: ScheduledTimer[] = [];

  schedule = (callback: () => void, delayMs: number): FakeDisposable => {
    const timer: ScheduledTimer = { callback, delayMs, cancelled: false };
    this.scheduled.push(timer);
    return {
      dispose: () => {
        timer.cancelled = true;
      },
    };
  };

  fireAll(): void {
    for (const timer of [...this.scheduled]) {
      if (!timer.cancelled) timer.callback();
    }
  }
}

interface TestHarness {
  engine: TourEngineType;
  channel: FakeChannel;
  progress: FakeProgressStore;
  completed: FakeCompletedStore;
  client: FakeTurbineClient;
  reveal: FakeReveal;
  clock: TestClock;
  stepActionDispatcher: FakeStepActionDispatcher;
}

async function makeEngine(deps: Partial<TourEngineDeps> = {}): Promise<TestHarness> {
  const { TourEngine } = await loadModule();
  const channel = new FakeChannel();
  const progress = new FakeProgressStore();
  const completed = new FakeCompletedStore();
  const stepActionDispatcher = new FakeStepActionDispatcher();
  const client = new FakeTurbineClient();
  const reveal = new FakeReveal();
  const clock = new TestClock();

  const engine = new TourEngine({
    client: () => client as unknown as TourEngineDeps["client"] extends (key: string) => infer R ? R : never,
    workspaceRootFor: (folderUri: string) => `/tmp${folderUri.replace("file://", "")}`,
    progress,
    completed,
    channel,
    dispatchStepAction: (action) => stepActionDispatcher.dispatch(action),
    reveal,
    logger: () => undefined,
    schedule: clock.schedule,
    ...deps,
  });

  return { engine, channel, progress, completed, client, reveal, clock, stepActionDispatcher };
}

function postsOfType<T extends TourEngineOutbound["type"]>(
  posts: TourEngineOutbound[],
  type: T,
): Array<Extract<TourEngineOutbound, { type: T }>> {
  return posts.filter((post): post is Extract<TourEngineOutbound, { type: T }> => post.type === type);
}

const startTour = (tourId: string, folderUri = "file:///workspace"): TourEnginePanelMessage => ({
  type: "start-tour",
  tourId,
  folderUri,
});

describe("TourEngine", () => {
  describe("starting a tour in an empty workspace", () => {
    it("scaffolds via the LSP, lists tours, then posts the first step", async () => {
      const { engine, channel, client } = await makeEngine();

      await engine.handle(startTour("foundations"));

      assert.equal(client.scaffoldCalls, 1, "scaffold ran exactly once");
      const stepPosts = postsOfType(channel.posts, "tour-step");
      assert.equal(stepPosts.length, 1);
      assert.equal(stepPosts[0]?.tourId, "foundations");
      assert.equal(stepPosts[0]?.step.id, "step-1");
      assert.equal(stepPosts[0]?.index, 0);
      assert.equal(stepPosts[0]?.total, 2);
    });

    it("does not post the preparing-scaffold hint when scaffold completes before 200ms", async () => {
      const { engine, channel, clock } = await makeEngine();

      await engine.handle(startTour("foundations"));

      assert.equal(postsOfType(channel.posts, "tour-preparing-scaffold").length, 0);
      clock.fireAll();
      assert.equal(postsOfType(channel.posts, "tour-preparing-scaffold").length, 0);
    });

    it("posts the preparing-scaffold hint when scaffold takes longer than 200ms", async () => {
      const { engine, channel, client, clock } = await makeEngine();

      let release: (() => void) | null = null;
      const scaffoldPromise = new Promise<void>((resolve) => {
        release = resolve;
      });
      client.scaffoldImpl = async () => {
        await scaffoldPromise;
        return { createdFiles: [] };
      };

      const settled = engine.handle(startTour("foundations"));
      // Drain pending microtasks so the engine progresses past the
      // progress.load + checkWorkspaceEmpty awaits and lands on schedule().
      await new Promise<void>((resolve) => setImmediate(resolve));
      await new Promise<void>((resolve) => setImmediate(resolve));
      assert.equal(clock.scheduled.length, 1);
      assert.equal(clock.scheduled[0]?.delayMs, 200);

      clock.scheduled[0]?.callback();
      assert.equal(postsOfType(channel.posts, "tour-preparing-scaffold").length, 1);

      if (release !== null) (release as () => void)();
      await settled;
    });
  });

  describe("non-empty workspace", () => {
    it("posts tour-needs-fresh-folder with the reasons and does not scaffold", async () => {
      const { engine, channel, client } = await makeEngine();
      client.checkEmptyImpl = async () => ({
        empty: false,
        reasons: ["contracts/ contains user files: orders.yml"],
      });

      await engine.handle(startTour("foundations"));

      assert.equal(client.scaffoldCalls, 0, "scaffold must not run when workspace is non-empty");
      const redirect = postsOfType(channel.posts, "tour-needs-fresh-folder");
      assert.equal(redirect.length, 1);
      assert.deepEqual(redirect[0]?.reasons, ["contracts/ contains user files: orders.yml"]);
    });
  });

  describe("progress persistence", () => {
    it("saves with the workspaceFolderUri+tourId key shape", async () => {
      const { engine, progress } = await makeEngine();

      await engine.handle(startTour("foundations", "file:///alpha"));
      await engine.handle({ type: "tour-next-step", tourId: "foundations" });

      assert.ok(progress.saved.length >= 1, "save was called at least once");
      const last = progress.saved[progress.saved.length - 1];
      assert.equal(last?.workspaceFolderUri, "file:///alpha");
      assert.equal(last?.tourId, "foundations");
      assert.ok("lastStepId" in (last as TourProgressRecord));
      assert.ok("completedStepIds" in (last as TourProgressRecord));
      assert.ok("finished" in (last as TourProgressRecord));
    });
  });

  describe("step advancement", () => {
    it("tour-next-step advances narration steps", async () => {
      const { engine, channel } = await makeEngine();
      await engine.handle(startTour("foundations"));
      await engine.handle({ type: "tour-next-step", tourId: "foundations" });

      const stepPosts = postsOfType(channel.posts, "tour-step");
      assert.equal(stepPosts.length, 2);
      assert.equal(stepPosts[1]?.step.id, "step-2");
      assert.equal(stepPosts[1]?.index, 1);
    });

    it("gated steps watch the LSP and post tour-step-unlocked on stepCompleted", async () => {
      // ADR 0015: stepCompleted unlocks Next; it does NOT auto-advance.
      const { engine, channel, client } = await makeEngine({});
      client.listToursImpl = async () => ({
        tours: [
          tour("foundations", [step("watch-me", true), step("after")]),
        ] as unknown as ListToursResult["tours"],
      });

      await engine.handle(startTour("foundations"));
      assert.deepEqual(client.watchedSteps[0], { tourId: "foundations", stepId: "watch-me" });

      client.fireStepCompleted({ tourId: "foundations", stepId: "watch-me" });
      await new Promise<void>((resolve) => setImmediate(resolve));

      const stepPosts = postsOfType(channel.posts, "tour-step");
      assert.equal(stepPosts.length, 1);
      assert.equal(stepPosts[0]?.step.id, "watch-me");
      const unlocked = postsOfType(channel.posts, "tour-step-unlocked");
      assert.equal(unlocked.length, 1);
      assert.equal(unlocked[0]?.stepId, "watch-me");
    });

    it("retreating to a previously unlocked step does not re-attach the watcher", async () => {
      const { engine, client } = await makeEngine({});
      client.listToursImpl = async () => ({
        tours: [
          tour("foundations", [step("watch-me", true), step("after")]),
        ] as unknown as ListToursResult["tours"],
      });

      await engine.handle(startTour("foundations"));
      client.fireStepCompleted({ tourId: "foundations", stepId: "watch-me" });
      await new Promise<void>((resolve) => setImmediate(resolve));

      const watchesBefore = client.watchedSteps.length;
      await engine.handle({ type: "tour-next-step", tourId: "foundations" });
      await engine.handle({ type: "tour-prev-step", tourId: "foundations" });

      assert.equal(client.watchedSteps.length, watchesBefore);
    });
  });

  describe("finishing a tour", () => {
    it("marks the tour completed and posts tour-finished on the last narration step", async () => {
      const { engine, channel, completed, progress } = await makeEngine({});

      await engine.handle(startTour("foundations"));
      await engine.handle({ type: "tour-next-step", tourId: "foundations" });
      // step-2 is the last narration step. Finish it.
      await engine.handle({ type: "tour-next-step", tourId: "foundations" });

      assert.deepEqual(completed.ids, ["foundations"]);
      const finishedSave = progress.saved.find((record) => record.finished);
      assert.ok(finishedSave !== undefined, "a save with finished=true was emitted");
      assert.equal(postsOfType(channel.posts, "tour-finished").length, 1);
    });
  });

  describe("final-handoff dispatch", () => {
    it("posts tour-final-handoff-prompt when the last step has FINAL_HANDOFF action", async () => {
      const { engine, channel, client } = await makeEngine();
      client.listToursImpl = async () => ({
        tours: [
          tour("ship-and-observe", [
            {
              ...step("final"),
              kind: "action" as unknown as StepDto["kind"],
              action: { kind: "final_handoff", label: "Choose next step" } as unknown as StepDto["action"],
            },
          ]),
        ] as unknown as ListToursResult["tours"],
      });

      await engine.handle(startTour("ship-and-observe"));
      await engine.handle({ type: "tour-next-step", tourId: "ship-and-observe" });

      assert.equal(postsOfType(channel.posts, "tour-final-handoff-prompt").length, 1);
    });

    it("tour-final-handoff-confirmed dispatches the active step's StepAction", async () => {
      const { engine, stepActionDispatcher, client } = await makeEngine();
      client.listToursImpl = async () => ({
        tours: [
          tour("ship-and-observe", [
            {
              ...step("final"),
              kind: "action" as unknown as StepDto["kind"],
              action: { kind: "final_handoff", label: "Choose next step" } as unknown as StepDto["action"],
            },
          ]),
        ] as unknown as ListToursResult["tours"],
      });

      await engine.handle(startTour("ship-and-observe"));
      await engine.handle({ type: "tour-next-step", tourId: "ship-and-observe" });
      await engine.handle({ type: "tour-final-handoff-confirmed", tourId: "ship-and-observe" });

      assert.equal(stepActionDispatcher.invocations.length, 1);
      assert.equal(stepActionDispatcher.invocations[0]?.kind, "final_handoff");
    });
  });

  describe("resume", () => {
    it("start-tour auto-resumes when an unfinished saved record exists", async () => {
      const { engine, progress, channel, client } = await makeEngine();
      progress.loaded = {
        workspaceFolderUri: "file:///workspace",
        tourId: "foundations",
        lastStepId: "step-1",
        completedStepIds: ["step-1"],
        finished: false,
      };

      await engine.handle(startTour("foundations"));

      assert.equal(client.scaffoldCalls, 0, "resume path skips re-scaffolding");
      const stepPosts = postsOfType(channel.posts, "tour-step");
      assert.equal(stepPosts[0]?.index, 1, "resumed at the next step after lastStepId");
    });

    it("start-tour starts fresh when the saved record is finished", async () => {
      const { engine, progress, client } = await makeEngine();
      progress.loaded = {
        workspaceFolderUri: "file:///workspace",
        tourId: "foundations",
        lastStepId: "step-2",
        completedStepIds: ["step-1", "step-2"],
        finished: true,
      };

      await engine.handle(startTour("foundations"));

      // A finished record does not block re-scaffolding; we start over.
      assert.equal(client.scaffoldCalls, 1);
    });
  });

  describe("highlight reveal", () => {
    it("calls reveal with the workspace root and the step's resolvedTarget on every step", async () => {
      const { engine, client, reveal } = await makeEngine();
      const target: ResolvedHighlight = {
        kind: "editor_range",
        file: "contracts/foo.yml",
        range: [3, 0, 3, 12],
        targetId: null,
      };
      client.listToursImpl = async () => ({
        tours: [
          tour("foundations", [{ ...step("step-1"), resolvedTarget: target }, step("step-2")]),
        ] as unknown as ListToursResult["tours"],
      });

      await engine.handle(startTour("foundations"));

      assert.equal(reveal.revealed.length, 1);
      assert.deepEqual(reveal.revealed[0]?.target, target);
      assert.equal(reveal.revealed[0]?.workspaceRoot, "/tmp/workspace");
    });
  });

  describe("watcher cleanup", () => {
    it("calls LSP unwatchStep when the active watcher is detached", async () => {
      const { engine, client } = await makeEngine();
      client.listToursImpl = async () => ({
        tours: [
          tour("foundations", [step("watch-me", true), step("after")]),
        ] as unknown as ListToursResult["tours"],
      });

      await engine.handle(startTour("foundations"));
      await engine.handle({ type: "tour-next-step", tourId: "foundations" });
      await new Promise<void>((resolve) => setImmediate(resolve));

      assert.ok(client.unwatched >= 1, "unwatchStep was called when the watcher was detached");
    });
  });
});
