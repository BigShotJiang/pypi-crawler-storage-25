import * as assert from "node:assert/strict";
import Module = require("node:module");
import vm = require("node:vm");

import type { StepContentBlock } from "../../../types";

type ModuleLoad = (request: string, parent: NodeModule | null | undefined, isMain: boolean) => unknown;
type MessageListener = (event: { readonly data: unknown }) => void;

interface FakeNode {
  addEventListener(type: string, listener: () => void): void;
  getAttribute(name: string): string | null;
}

interface FakeRoot {
  innerHTML: string;
  querySelectorAll(selector: string): readonly FakeNode[];
}

const fakeVscode = {};

async function loadModule(): Promise<typeof import("../../../onboarding/tour-view")> {
  const moduleWithLoad = Module as typeof Module & { _load: ModuleLoad };
  const originalLoad = moduleWithLoad._load;
  moduleWithLoad._load = (request, parent, isMain) => {
    if (request === "vscode") return fakeVscode;
    return originalLoad(request, parent, isMain);
  };
  try {
    return await import("../../../onboarding/tour-view.js");
  } finally {
    moduleWithLoad._load = originalLoad;
  }
}

function runTourScript(script: string): {
  readonly root: FakeRoot;
  readonly postMessage: (data: unknown) => void;
} {
  const listeners: MessageListener[] = [];
  const root: FakeRoot = {
    innerHTML: "",
    querySelectorAll: () => [],
  };
  const sandbox = {
    acquireVsCodeApi: () => ({ postMessage: () => undefined }),
    document: {
      getElementById: (id: string) => (id === "root" ? root : { innerHTML: "<svg></svg>" }),
    },
    navigator: { clipboard: null },
    setTimeout: () => 0,
    window: {
      addEventListener: (type: string, listener: MessageListener) => {
        if (type === "message") listeners.push(listener);
      },
    },
  };
  vm.runInNewContext(script, sandbox);
  return {
    root,
    postMessage: (data: unknown) => {
      for (const listener of listeners) listener({ data });
    },
  };
}

function renderStepContent(script: string, content: readonly StepContentBlock[]): string {
  const harness = runTourScript(script);
  harness.postMessage({
    type: "phase-data",
    tours: [{ id: "rich", title: "Rich", completed: false, completedSteps: 0 }],
    phaseKind: "ready",
    workspaceFolderUri: "file:///workspace",
    machineWideCompleted: [],
    folders: [],
    currentFolderKey: null,
  });
  harness.postMessage({
    type: "tour-step",
    tourId: "rich",
    step: {
      id: "step-1",
      title: "Rich step",
      content,
      target: { kind: "ui_target", targetId: "tour-panel:test" },
      resolvedTarget: null,
      kind: "read",
      action: null,
      skipKind: "none",
      gated: false,
    },
    index: 0,
    total: 1,
  });
  return harness.root.innerHTML;
}

describe("Onboarding tour view rich content", () => {
  let tourViewScript = "";

  before(async () => {
    const { renderTourViewScript } = await loadModule();
    tourViewScript = renderTourViewScript("vscode-resource://extension/media/onboarding");
  });

  it("renders paragraph, callout, and local image blocks", () => {
    const html = renderStepContent(tourViewScript, [
      { kind: "paragraph", markdown: "Read `this`." },
      { kind: "callout", tone: "tip", title: "Tip", markdown: "Remember **this**." },
      {
        kind: "image",
        assetPath: "project-layout.png",
        alt: "Project layout",
        captionMarkdown: "The **sandbox** layout.",
      },
    ]);

    assert.match(html, /<p class="ob-step-p">Read <code>this<\/code>\.<\/p>/);
    assert.match(html, /<div class="ob-banner tip">/);
    assert.match(html, /<div class="ob-banner-title">Tip<\/div>/);
    assert.match(html, /Remember <strong>this<\/strong>\./);
    assert.match(
      html,
      /<img src="vscode-resource:\/\/extension\/media\/onboarding\/project-layout\.png" alt="Project layout" \/>/,
    );
    assert.match(html, /<figcaption>The <strong>sandbox<\/strong> layout\.<\/figcaption>/);
    assert.doesNotMatch(html, /WHERE TO LOOK/);
    assert.doesNotMatch(html, /DATA CONTRACTS · BEFORE/);
    assert.doesNotMatch(html, /Turbine Sidebar · activity bar/);
  });

  it("renders markdown links as anchor tags opening in a new tab", () => {
    const html = renderStepContent(tourViewScript, [
      {
        kind: "callout",
        tone: "info",
        title: "New to YAML?",
        markdown: "See [YAML explained](https://example.test/yaml) for more.",
      },
    ]);

    assert.match(
      html,
      /<a href="https:\/\/example\.test\/yaml" target="_blank" rel="noopener noreferrer">YAML explained<\/a>/,
    );
  });

  it("rejects unsafe or non-image asset paths", () => {
    const unsafePaths = [
      "../secret.png",
      "/secret.png",
      "https://example.test/image.png",
      "https:example.test/image.png",
      "folder\\secret.png",
      "diagram.svg",
    ];

    for (const assetPath of unsafePaths) {
      const html = renderStepContent(tourViewScript, [
        { kind: "image", assetPath, alt: "Unsafe", captionMarkdown: "Should not render." },
      ]);
      assert.doesNotMatch(html, /<img /, assetPath);
      assert.doesNotMatch(html, /Should not render\./, assetPath);
    }
  });
});
