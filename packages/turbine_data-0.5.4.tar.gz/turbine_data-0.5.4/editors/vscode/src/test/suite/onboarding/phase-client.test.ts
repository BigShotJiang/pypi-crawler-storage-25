import * as assert from "node:assert/strict";

import Module = require("node:module");

import type { PhaseDto } from "../../../onboarding/phase-client";

type ModuleLoad = (request: string, parent: NodeModule | null | undefined, isMain: boolean) => unknown;

interface FakeDisposable {
  dispose(): void;
}

class FakeEventEmitter<T> {
  private listeners: Array<(value: T) => void> = [];

  readonly event = (listener: (value: T) => void): FakeDisposable => {
    this.listeners.push(listener);
    return {
      dispose: () => {
        this.listeners = this.listeners.filter((entry) => entry !== listener);
      },
    };
  };

  fire(value: T): void {
    for (const listener of [...this.listeners]) listener(value);
  }

  dispose(): void {
    this.listeners = [];
  }
}

const fakeVscode = {
  EventEmitter: FakeEventEmitter,
  Disposable: {
    from(...disposables: FakeDisposable[]): FakeDisposable {
      return {
        dispose: () => {
          for (const disposable of disposables) disposable.dispose();
        },
      };
    },
  },
};

type NotificationHandler = (raw: unknown) => void;

class FakeLanguageClient {
  notificationHandlers = new Map<string, NotificationHandler>();
  sentRequests: Array<{ method: string; params: unknown }> = [];
  responses = new Map<string, unknown>();

  onNotification(method: string, handler: NotificationHandler): FakeDisposable {
    this.notificationHandlers.set(method, handler);
    return { dispose: () => this.notificationHandlers.delete(method) };
  }

  fire(method: string, raw: unknown): void {
    const handler = this.notificationHandlers.get(method);
    if (handler !== undefined) handler(raw);
  }

  async sendRequest(method: string, params: unknown): Promise<unknown> {
    this.sentRequests.push({ method, params });
    return this.responses.get(method) ?? {};
  }
}

async function loadModule(): Promise<typeof import("../../../onboarding/phase-client")> {
  const moduleWithLoad = Module as typeof Module & { _load: ModuleLoad };
  const originalLoad = moduleWithLoad._load;
  moduleWithLoad._load = (request, parent, isMain) => {
    if (request === "vscode") return fakeVscode;
    return originalLoad(request, parent, isMain);
  };
  try {
    return await import("../../../onboarding/phase-client.js");
  } finally {
    moduleWithLoad._load = originalLoad;
  }
}

describe("PhaseClient", () => {
  it("emits onPhaseChanged when the server pushes turbine/onboardingPhase", async () => {
    const { PhaseClient, PHASE_METHODS } = await loadModule();
    const lsp = new FakeLanguageClient();
    const client = new PhaseClient(lsp as unknown as import("vscode-languageclient/node").LanguageClient);

    const observed: PhaseDto[] = [];
    client.onPhaseChanged((dto) => observed.push(dto));

    lsp.fire(PHASE_METHODS.PHASE, {
      workspaceFolderUri: "file:///workspace",
      kind: "needs-pyproject",
      title: "Initialize a Python project",
      body: "No pyproject yet.",
      choices: [],
      tours: [],
      primaryAction: null,
    });

    assert.equal(observed.length, 1);
    assert.equal(observed[0]?.kind, "needs-pyproject");
    assert.equal(observed[0]?.workspaceFolderUri, "file:///workspace");
  });

  it("retains the latest pushed PhaseDto on `current`", async () => {
    const { PhaseClient, PHASE_METHODS } = await loadModule();
    const lsp = new FakeLanguageClient();
    const client = new PhaseClient(lsp as unknown as import("vscode-languageclient/node").LanguageClient);

    assert.equal(client.current, null);

    lsp.fire(PHASE_METHODS.PHASE, {
      workspaceFolderUri: "file:///workspace",
      kind: "needs-turbine",
      title: "Pick a database",
      body: "Choose a backend.",
      choices: [],
      tours: [],
      primaryAction: null,
    });

    const current = client.current as PhaseDto | null;
    assert.notEqual(current, null);
    if (current !== null) {
      assert.equal(current.kind, "needs-turbine");
    }
  });

  it("forwards installCommands to the server with the right method id", async () => {
    const { PhaseClient, PHASE_METHODS } = await loadModule();
    const lsp = new FakeLanguageClient();
    lsp.responses.set(PHASE_METHODS.INSTALL_COMMANDS, {
      commands: ['uv add "turbine-data[postgres]"', "uv run turbine init"],
    });
    const client = new PhaseClient(lsp as unknown as import("vscode-languageclient/node").LanguageClient);

    const result = await client.installCommands({
      workspaceFolderUri: "file:///workspace",
      choice: "postgres",
    });

    assert.deepEqual(result.commands, ['uv add "turbine-data[postgres]"', "uv run turbine init"]);
    assert.deepEqual(lsp.sentRequests[0], {
      method: PHASE_METHODS.INSTALL_COMMANDS,
      params: { workspaceFolderUri: "file:///workspace", choice: "postgres" },
    });
  });

  it("forwards dismiss + reset", async () => {
    const { PhaseClient, PHASE_METHODS } = await loadModule();
    const lsp = new FakeLanguageClient();
    const client = new PhaseClient(lsp as unknown as import("vscode-languageclient/node").LanguageClient);

    await client.dismiss({ workspaceFolderUri: "file:///workspace", phaseKind: "needs-pyproject" });
    await client.reset({ workspaceFolderUri: "file:///workspace" });

    assert.deepEqual(
      lsp.sentRequests.map((entry) => entry.method),
      [PHASE_METHODS.DISMISS, PHASE_METHODS.RESET],
    );
  });
});
