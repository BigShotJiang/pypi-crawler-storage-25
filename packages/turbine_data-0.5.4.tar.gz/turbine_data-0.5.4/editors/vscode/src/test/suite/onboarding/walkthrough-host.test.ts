import * as assert from "node:assert/strict";

import type { EditorPhase } from "../../../onboarding/editor-phase";
import type { PhaseDto } from "../../../onboarding/phase-client";
import {
  type CommandRunner,
  type CompletedToursSource,
  type GlobalStateLike,
  type PhaseSource,
  WALKTHROUGH_CATEGORY_ID,
  WALKTHROUGH_CONTEXT_KEYS,
  WALKTHROUGH_FIRST_STEP_ID,
  WALKTHROUGH_SHOWN_FLAG,
  WalkthroughHost,
  type WalkthroughHostDeps,
  deriveWalkthroughKeys,
} from "../../../onboarding/walkthrough-host";

interface FakeDisposable {
  dispose(): void;
}

function makeDto(kind: PhaseDto["kind"]): PhaseDto {
  return {
    workspaceFolderUri: "file:///workspace",
    kind,
    title: kind,
    body: "",
    choices: [],
    tours: [],
    primaryAction: null,
  };
}

class FakeGlobalState implements GlobalStateLike {
  private readonly store = new Map<string, unknown>();

  get<T>(key: string): T | undefined {
    return this.store.get(key) as T | undefined;
  }

  async update(key: string, value: unknown): Promise<void> {
    if (value === undefined) {
      this.store.delete(key);
      return;
    }
    this.store.set(key, value);
  }

  has(key: string): boolean {
    return this.store.has(key);
  }
}

interface RecordedCommand {
  readonly command: string;
  readonly args: readonly unknown[];
}

class FakeCommandRunner implements CommandRunner {
  readonly calls: RecordedCommand[] = [];
  throwOn = new Set<string>();
  knownCommands: readonly string[] = [];
  rejectMessage = "command not found";

  async execute(command: string, ...args: readonly unknown[]): Promise<unknown> {
    this.calls.push({ command, args });
    if (this.throwOn.has(command)) throw new Error(this.rejectMessage);
    return undefined;
  }

  async list(): Promise<readonly string[]> {
    return this.knownCommands;
  }

  callsTo(command: string): RecordedCommand[] {
    return this.calls.filter((entry) => entry.command === command);
  }

  setContextValueFor(key: string): boolean | undefined {
    const matching = this.calls.filter((entry) => entry.command === "setContext" && entry.args[0] === key);
    if (matching.length === 0) return undefined;
    return matching[matching.length - 1]?.args[1] as boolean | undefined;
  }
}

class FakePhaseSource implements PhaseSource {
  current: EditorPhase;
  private listeners: Array<(phase: EditorPhase) => void> = [];

  constructor(initial: EditorPhase) {
    this.current = initial;
  }

  onPhaseChange(listener: (phase: EditorPhase) => void): FakeDisposable {
    this.listeners.push(listener);
    return {
      dispose: () => {
        this.listeners = this.listeners.filter((entry) => entry !== listener);
      },
    };
  }

  push(phase: EditorPhase): void {
    this.current = phase;
    for (const listener of [...this.listeners]) listener(phase);
  }

  listenerCount(): number {
    return this.listeners.length;
  }
}

class FakeCompletedToursSource implements CompletedToursSource {
  ids: readonly string[];

  constructor(ids: readonly string[] = []) {
    this.ids = ids;
  }

  list(): readonly string[] {
    return this.ids;
  }
}

interface HostFixture {
  readonly host: WalkthroughHost;
  readonly globalState: FakeGlobalState;
  readonly commands: FakeCommandRunner;
  readonly phase: FakePhaseSource;
  readonly completedTours: FakeCompletedToursSource;
  readonly logged: string[];
}

function makeHost(
  overrides: { initialPhase?: EditorPhase; completedTours?: readonly string[] } = {},
): HostFixture {
  const globalState = new FakeGlobalState();
  const commands = new FakeCommandRunner();
  const phase = new FakePhaseSource(overrides.initialPhase ?? { kind: "no-folder" });
  const completedTours = new FakeCompletedToursSource(overrides.completedTours ?? []);
  const logged: string[] = [];
  const deps: WalkthroughHostDeps = {
    globalState,
    commands,
    phase,
    completedTours,
    logger: (message: string) => {
      logged.push(message);
    },
  };
  const host = new WalkthroughHost(deps);
  return { host, globalState, commands, phase, completedTours, logged };
}

describe("deriveWalkthroughKeys", () => {
  it("no-folder → all keys false when no tours completed", () => {
    const keys = deriveWalkthroughKeys({ kind: "no-folder" }, []);
    assert.deepEqual(keys, {
      folderOpen: false,
      uvInstalled: false,
      pyprojectExists: false,
      turbineInstalled: false,
      tourCompleted: false,
    });
  });

  it("needs-uv → folderOpen true, all later keys false", () => {
    const keys = deriveWalkthroughKeys({ kind: "needs-uv" }, []);
    assert.deepEqual(keys, {
      folderOpen: true,
      uvInstalled: false,
      pyprojectExists: false,
      turbineInstalled: false,
      tourCompleted: false,
    });
  });

  it("starting-server → folderOpen + uvInstalled true, others false", () => {
    const keys = deriveWalkthroughKeys({ kind: "starting-server" }, []);
    assert.deepEqual(keys, {
      folderOpen: true,
      uvInstalled: true,
      pyprojectExists: false,
      turbineInstalled: false,
      tourCompleted: false,
    });
  });

  it("needs-turbine-project no-pyproject → pyprojectExists false", () => {
    const keys = deriveWalkthroughKeys({ kind: "needs-turbine-project", subKind: "no-pyproject" }, []);
    assert.deepEqual(keys, {
      folderOpen: true,
      uvInstalled: true,
      pyprojectExists: false,
      turbineInstalled: false,
      tourCompleted: false,
    });
  });

  it("needs-turbine-project no-turbine-config → pyprojectExists true, turbineInstalled false", () => {
    const keys = deriveWalkthroughKeys({ kind: "needs-turbine-project", subKind: "no-turbine-config" }, []);
    assert.deepEqual(keys, {
      folderOpen: true,
      uvInstalled: true,
      pyprojectExists: true,
      turbineInstalled: false,
      tourCompleted: false,
    });
  });

  it("needs-server → folderOpen + uvInstalled true, others false", () => {
    const keys = deriveWalkthroughKeys({ kind: "needs-server", reason: "boom" }, []);
    assert.deepEqual(keys, {
      folderOpen: true,
      uvInstalled: true,
      pyprojectExists: false,
      turbineInstalled: false,
      tourCompleted: false,
    });
  });

  it("awaiting-server-phase → folderOpen + uvInstalled true, others false", () => {
    const keys = deriveWalkthroughKeys({ kind: "awaiting-server-phase" }, []);
    assert.deepEqual(keys, {
      folderOpen: true,
      uvInstalled: true,
      pyprojectExists: false,
      turbineInstalled: false,
      tourCompleted: false,
    });
  });

  it("lsp-phase needs-pyproject → pyprojectExists false, turbineInstalled false", () => {
    const keys = deriveWalkthroughKeys({ kind: "lsp-phase", dto: makeDto("needs-pyproject") }, []);
    assert.deepEqual(keys, {
      folderOpen: true,
      uvInstalled: true,
      pyprojectExists: false,
      turbineInstalled: false,
      tourCompleted: false,
    });
  });

  it("lsp-phase needs-turbine → pyprojectExists true, turbineInstalled false", () => {
    const keys = deriveWalkthroughKeys({ kind: "lsp-phase", dto: makeDto("needs-turbine") }, []);
    assert.deepEqual(keys, {
      folderOpen: true,
      uvInstalled: true,
      pyprojectExists: true,
      turbineInstalled: false,
      tourCompleted: false,
    });
  });

  it("lsp-phase ready-tour-pending → turbineInstalled true, tourCompleted from list", () => {
    const keys = deriveWalkthroughKeys({ kind: "lsp-phase", dto: makeDto("ready-tour-pending") }, [
      "foundations",
    ]);
    assert.equal(keys.turbineInstalled, true);
    assert.equal(keys.tourCompleted, true);
  });

  it("lsp-phase ready → turbineInstalled true; tourCompleted false when list empty", () => {
    const keys = deriveWalkthroughKeys({ kind: "lsp-phase", dto: makeDto("ready") }, []);
    assert.equal(keys.turbineInstalled, true);
    assert.equal(keys.tourCompleted, false);
  });

  it("tourCompleted reflects completedTourIds across all phases", () => {
    const phases: EditorPhase[] = [
      { kind: "no-folder" },
      { kind: "needs-uv" },
      { kind: "starting-server" },
      { kind: "lsp-phase", dto: makeDto("ready") },
    ];
    for (const phase of phases) {
      assert.equal(deriveWalkthroughKeys(phase, []).tourCompleted, false, `empty list, phase ${phase.kind}`);
      assert.equal(
        deriveWalkthroughKeys(phase, ["any"]).tourCompleted,
        true,
        `non-empty list, phase ${phase.kind}`,
      );
    }
  });
});

describe("WalkthroughHost.maybeOpen", () => {
  it("flag unset: invokes openWalkthrough with category + first step and sets the flag", async () => {
    const { host, globalState, commands } = makeHost();

    await host.maybeOpen();

    const opens = commands.callsTo("workbench.action.openWalkthrough");
    assert.equal(opens.length, 1);
    assert.deepEqual(opens[0]?.args[0], {
      category: WALKTHROUGH_CATEGORY_ID,
      step: WALKTHROUGH_FIRST_STEP_ID,
    });
    assert.equal(globalState.get<boolean>(WALKTHROUGH_SHOWN_FLAG), true);
  });

  it("flag already set: does not invoke openWalkthrough", async () => {
    const { host, globalState, commands } = makeHost();
    await globalState.update(WALKTHROUGH_SHOWN_FLAG, true);

    await host.maybeOpen();

    assert.equal(commands.callsTo("workbench.action.openWalkthrough").length, 0);
  });

  it("runner throws: flag still set so a malformed walkthrough cannot loop", async () => {
    const { host, globalState, commands, logged } = makeHost();
    commands.throwOn.add("workbench.action.openWalkthrough");

    await host.maybeOpen();

    assert.equal(globalState.get<boolean>(WALKTHROUGH_SHOWN_FLAG), true);
    assert.ok(logged.some((entry) => entry.includes("walkthrough")));
  });

  it("called twice in one session: openWalkthrough invoked exactly once", async () => {
    const { host, commands } = makeHost();

    await host.maybeOpen();
    await host.maybeOpen();

    assert.equal(commands.callsTo("workbench.action.openWalkthrough").length, 1);
  });
});

describe("WalkthroughHost.start", () => {
  it("publishes initial setContext for all five keys derived from the current phase", () => {
    const { host, commands } = makeHost({
      initialPhase: { kind: "lsp-phase", dto: makeDto("needs-turbine") },
    });

    host.start();

    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.folderOpen), true);
    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.uvInstalled), true);
    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.pyprojectExists), true);
    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.turbineInstalled), false);
    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.tourCompleted), false);
  });

  it("recomputes and republishes when the phase changes", () => {
    const { host, commands, phase } = makeHost({ initialPhase: { kind: "needs-uv" } });
    host.start();

    phase.push({ kind: "lsp-phase", dto: makeDto("ready") });

    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.uvInstalled), true);
    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.pyprojectExists), true);
    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.turbineInstalled), true);
  });

  it("ignores a second start() call (idempotent)", () => {
    const { host, phase } = makeHost();
    host.start();
    const firstSubscriberCount = phase.listenerCount();

    host.start();

    assert.equal(phase.listenerCount(), firstSubscriberCount);
  });

  it("dispose() unsubscribes from phase changes", () => {
    const { host, phase } = makeHost();
    host.start();
    assert.equal(phase.listenerCount(), 1);

    host.dispose();

    assert.equal(phase.listenerCount(), 0);
  });
});

describe("WalkthroughHost.refresh", () => {
  it("re-publishes context keys to reflect a tour completion the phase channel did not emit", () => {
    const completedTours = new FakeCompletedToursSource([]);
    const globalState = new FakeGlobalState();
    const commands = new FakeCommandRunner();
    const phase = new FakePhaseSource({ kind: "lsp-phase", dto: makeDto("ready") });
    const logged: string[] = [];
    const host = new WalkthroughHost({
      globalState,
      commands,
      phase,
      completedTours,
      logger: (message: string) => {
        logged.push(message);
      },
    });
    host.start();
    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.tourCompleted), false);

    completedTours.ids = ["foundations"];
    host.refresh();

    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.tourCompleted), true);
  });

  it("is a no-op before start()", () => {
    const { host, commands } = makeHost();

    host.refresh();

    assert.equal(commands.callsTo("setContext").length, 0);
  });
});

describe("WalkthroughHost.reset", () => {
  it("clears the globalState flag and writes false for all five context keys", async () => {
    const { host, globalState, commands } = makeHost({
      initialPhase: { kind: "lsp-phase", dto: makeDto("ready") },
    });
    await globalState.update(WALKTHROUGH_SHOWN_FLAG, true);
    host.start();

    await host.reset();

    assert.equal(globalState.has(WALKTHROUGH_SHOWN_FLAG), false);
    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.folderOpen), false);
    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.uvInstalled), false);
    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.pyprojectExists), false);
    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.turbineInstalled), false);
    assert.equal(commands.setContextValueFor(WALKTHROUGH_CONTEXT_KEYS.tourCompleted), false);
  });

  it("prefers welcome.markStepIncomplete and calls it once per step with the fully-qualified id", async () => {
    const { host, commands } = makeHost();
    commands.knownCommands = ["welcome.markStepIncomplete", "resetGettingStartedProgress"];

    await host.reset();

    const incompleteCalls = commands.callsTo("welcome.markStepIncomplete");
    assert.equal(incompleteCalls.length, 6);
    const ids = incompleteCalls.map((entry) => entry.args[0]);
    assert.deepEqual(ids, [
      "enexis.turbine-lsp#turbine.onboarding#turbine.onboarding.findSidebar",
      "enexis.turbine-lsp#turbine.onboarding#turbine.onboarding.openFolder",
      "enexis.turbine-lsp#turbine.onboarding#turbine.onboarding.installUv",
      "enexis.turbine-lsp#turbine.onboarding#turbine.onboarding.initPyproject",
      "enexis.turbine-lsp#turbine.onboarding#turbine.onboarding.addTurbine",
      "enexis.turbine-lsp#turbine.onboarding#turbine.onboarding.takeTour",
    ]);
    assert.equal(commands.callsTo("resetGettingStartedProgress").length, 0);
  });

  it("falls back to the bulk resetGettingStartedProgress when markStepIncomplete is unavailable", async () => {
    const { host, commands } = makeHost();
    commands.knownCommands = ["resetGettingStartedProgress"];

    await host.reset();

    assert.equal(commands.callsTo("welcome.markStepIncomplete").length, 0);
    assert.equal(commands.callsTo("resetGettingStartedProgress").length, 1);
  });

  it("falls back to bulk reset when markStepIncomplete throws mid-iteration", async () => {
    const { host, commands } = makeHost();
    commands.knownCommands = ["welcome.markStepIncomplete", "resetGettingStartedProgress"];
    commands.throwOn.add("welcome.markStepIncomplete");

    await host.reset();

    assert.equal(commands.callsTo("resetGettingStartedProgress").length, 1);
  });

  it("logs the available walkthrough-related commands when no candidate succeeds", async () => {
    const { host, commands, logged } = makeHost();
    commands.knownCommands = [
      "turbine.runQualityCheck",
      "welcome.showAllWalkthroughs",
      "workbench.action.openWalkthrough",
    ];

    await host.reset();

    const summary = logged.find((line) => line.includes("no known reset-progress command succeeded"));
    assert.ok(summary, "expected a summary log line listing walkthrough-related commands");
    assert.ok(summary.includes("welcome.showAllWalkthroughs"));
    assert.ok(summary.includes("workbench.action.openWalkthrough"));
  });

  it("after reset, maybeOpen() re-opens the walkthrough on the next call", async () => {
    const { host, commands } = makeHost();
    await host.maybeOpen();
    assert.equal(commands.callsTo("workbench.action.openWalkthrough").length, 1);

    await host.reset();
    await host.maybeOpen();

    assert.equal(commands.callsTo("workbench.action.openWalkthrough").length, 2);
  });
});
