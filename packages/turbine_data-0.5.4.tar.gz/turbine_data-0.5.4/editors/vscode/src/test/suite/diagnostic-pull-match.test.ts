import * as assert from "node:assert/strict";

import { isTurbineFilePath } from "../../diagnostic-pull-match";

describe("diagnostic pull match", () => {
  it("matches Turbine file extensions without relying on language id", () => {
    assert.equal(isTurbineFilePath("/workspace/contracts/orders.yml"), true);
    assert.equal(isTurbineFilePath("/workspace/contracts/orders.yaml"), true);
    assert.equal(isTurbineFilePath("/workspace/checks/validity.sql"), true);
    assert.equal(isTurbineFilePath("/workspace/checks/custom.py"), true);
  });

  it("ignores unrelated tab resources", () => {
    assert.equal(isTurbineFilePath("/workspace/README.md"), false);
    assert.equal(isTurbineFilePath("/workspace/contracts/orders.yml.bak"), false);
  });
});
