import * as assert from "node:assert/strict";

import Module = require("node:module");

import { attachCancelListener } from "../../progress-cancel";

import type { ProgressToastManager } from "../../progress-toast";

interface FakeCancellationToken {
  isCancellationRequested: boolean;
  onCancellationRequested(listener: () => void): { dispose(): void };
}

class FakeToken implements FakeCancellationToken {
  isCancellationRequested = false;
  private readonly listeners: Array<() => void> = [];

  onCancellationRequested(listener: () => void): { dispose(): void } {
    this.listeners.push(listener);
    return {
      dispose: () => {
        const index = this.listeners.indexOf(listener);
        if (index !== -1) this.listeners.splice(index, 1);
      },
    };
  }

  fire(): void {
    this.isCancellationRequested = true;
    for (const listener of this.listeners) listener();
  }

  get listenerCount(): number {
    return this.listeners.length;
  }
}

interface ProgressReport {
  message?: string;
  increment?: number;
}

class FakeProgressReporter {
  readonly reports: ProgressReport[] = [];

  report(value: ProgressReport): void {
    this.reports.push(value);
  }
}

interface FakeVscodeState {
  progress: FakeProgressReporter | null;
  token: FakeToken | null;
  resolvedCount: number;
  withProgressCalls: number;
}

type ProgressToastManagerConstructor = typeof ProgressToastManager;
type ModuleLoad = (request: string, parent: NodeModule | null | undefined, isMain: boolean) => unknown;

const fakeVscodeState: FakeVscodeState = {
  progress: null,
  token: null,
  resolvedCount: 0,
  withProgressCalls: 0,
};

const fakeVscode = {
  ProgressLocation: { Notification: 15 },
  window: {
    withProgress: (
      options: unknown,
      task: (progress: FakeProgressReporter, token: FakeToken) => Promise<void>,
    ): Promise<void> => {
      void options;
      fakeVscodeState.withProgressCalls += 1;
      fakeVscodeState.progress = new FakeProgressReporter();
      fakeVscodeState.token = new FakeToken();
      const promise = task(fakeVscodeState.progress, fakeVscodeState.token);
      void promise.then(() => {
        fakeVscodeState.resolvedCount += 1;
      });
      return promise;
    },
  },
};

function resetFakeVscode(): void {
  fakeVscodeState.progress = null;
  fakeVscodeState.token = null;
  fakeVscodeState.resolvedCount = 0;
  fakeVscodeState.withProgressCalls = 0;
}

async function loadProgressToastManager(): Promise<ProgressToastManagerConstructor> {
  const moduleWithLoad = Module as typeof Module & { _load: ModuleLoad };
  const originalLoad = moduleWithLoad._load;
  moduleWithLoad._load = (request, parent, isMain) => {
    if (request === "vscode") return fakeVscode;
    return originalLoad(request, parent, isMain);
  };
  try {
    const managerModule = await import("../../progress-toast.js");
    return managerModule.ProgressToastManager;
  } finally {
    moduleWithLoad._load = originalLoad;
  }
}

function wait(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

describe("ProgressToastManager", () => {
  beforeEach(() => {
    resetFakeVscode();
  });

  it("holds completion summary toasts until the dismissal delay elapses", async () => {
    const Manager = await loadProgressToastManager();
    const manager = new Manager(() => {}, 5);

    manager.handle("tok", { kind: "begin", title: "Run quality" });
    manager.handle("tok", {
      kind: "report",
      message: "✓ Quality run finished\n12 passed • 3 failed • 18s",
      percentage: 100,
    });
    manager.handle("tok", { kind: "end" });

    await wait(0);
    assert.equal(fakeVscodeState.resolvedCount, 0);
    await wait(10);
    assert.equal(fakeVscodeState.resolvedCount, 1);
    assert.equal(
      fakeVscodeState.progress?.reports.at(-1)?.message,
      "✓ Quality run finished\n12 passed • 3 failed • 18s",
    );
  });

  it("closes ordinary progress toasts immediately on end", async () => {
    const Manager = await loadProgressToastManager();
    const manager = new Manager(() => {}, 1000);

    manager.handle("tok", { kind: "begin", title: "Run quality" });
    manager.handle("tok", { kind: "report", message: "orders.row_count", percentage: 50 });
    manager.handle("tok", { kind: "end" });

    await wait(0);
    assert.equal(fakeVscodeState.resolvedCount, 1);
  });

  it("does not keep a zombie token after delayed dismissal", async () => {
    const Manager = await loadProgressToastManager();
    const manager = new Manager(() => {}, 5);

    manager.handle("tok", { kind: "begin", title: "Run quality" });
    manager.handle("tok", { kind: "report", message: "✘ Cancelled at 2/5" });
    manager.handle("tok", { kind: "end" });

    await wait(10);
    const reportCount = fakeVscodeState.progress?.reports.length ?? 0;
    manager.handle("tok", { kind: "report", message: "stale report" });
    manager.handle("tok", { kind: "end" });

    assert.equal(fakeVscodeState.progress?.reports.length, reportCount);
    assert.equal(fakeVscodeState.resolvedCount, 1);
  });
});

describe("attachCancelListener", () => {
  it("invokes sendCancel with the same token when the cancellation token fires", () => {
    const fakeToken = new FakeToken();
    const calls: Array<string | number> = [];
    attachCancelListener("progress-token-7", fakeToken, (token) => {
      calls.push(token);
    });

    fakeToken.fire();

    assert.deepEqual(calls, ["progress-token-7"]);
  });

  it("does not invoke sendCancel before the cancellation token fires", () => {
    const fakeToken = new FakeToken();
    const calls: Array<string | number> = [];
    attachCancelListener("token-a", fakeToken, (token) => {
      calls.push(token);
    });

    assert.deepEqual(calls, []);
  });

  it("returns a disposable that detaches the listener", () => {
    const fakeToken = new FakeToken();
    const calls: Array<string | number> = [];
    const subscription = attachCancelListener("tok", fakeToken, (token) => {
      calls.push(token);
    });

    subscription.dispose();
    fakeToken.fire();

    assert.deepEqual(calls, []);
    assert.equal(fakeToken.listenerCount, 0);
  });

  it("works with numeric progress tokens", () => {
    const fakeToken = new FakeToken();
    const calls: Array<string | number> = [];
    attachCancelListener(42, fakeToken, (token) => {
      calls.push(token);
    });

    fakeToken.fire();

    assert.deepEqual(calls, [42]);
  });
});
