import * as assert from "node:assert/strict";

import Module = require("node:module");

import type { TurbineClient } from "../../client";
import type {
  TreeDidChangeParams,
  TreeGetChildrenParams,
  TreeGetRootParams,
  TreeNode,
  TreeSubscribeParams,
  TreeUnsubscribeParams,
} from "../../types";

type ModuleLoad = (request: string, parent: NodeModule | null | undefined, isMain: boolean) => unknown;

class FakeDisposable {
  dispose(): void {}
}

class FakeEventEmitter<T> {
  readonly fired: T[] = [];
  readonly event = (): FakeDisposable => new FakeDisposable();

  fire(value: T): void {
    this.fired.push(value);
  }

  dispose(): void {}
}

class FakeThemeIcon {
  constructor(
    readonly id: string,
    readonly color?: FakeThemeColor,
  ) {}
}

class FakeThemeColor {
  constructor(readonly id: string) {}
}

class FakeTreeItem {
  constructor(
    readonly label: string,
    readonly collapsibleState: number,
  ) {}
}

class FakePosition {
  constructor(
    readonly line: number,
    readonly character: number,
  ) {}
}

class FakeRange {
  constructor(
    readonly start: FakePosition,
    readonly end: FakePosition,
  ) {}
}

class FakeLocation {
  constructor(
    readonly uri: FakeUri,
    readonly range: FakePosition,
  ) {}
}

class FakeUri {
  private constructor(private readonly value: string) {}

  static parse(uri: string): FakeUri {
    return new FakeUri(uri);
  }

  toString(): string {
    return this.value;
  }
}

const fakeVscode = {
  Disposable: FakeDisposable,
  EventEmitter: FakeEventEmitter,
  Location: FakeLocation,
  Position: FakePosition,
  Range: FakeRange,
  ThemeColor: FakeThemeColor,
  ThemeIcon: FakeThemeIcon,
  TreeItem: FakeTreeItem,
  TreeItemCollapsibleState: {
    None: 0,
    Collapsed: 1,
    Expanded: 2,
  },
  Uri: FakeUri,
};

function node(id: string, label: string, collapsibleState: TreeNode["collapsibleState"]): TreeNode {
  return {
    id,
    label,
    icon: "contract",
    collapsibleState,
    description: null,
    tooltip: null,
    contextValue: null,
    resourceUri: null,
    command: null,
  };
}

class FakeTurbineClient {
  private treeDidChangeHandler: ((params: TreeDidChangeParams) => void) | null = null;
  readonly root = node("workspace:contract:orders", "orders", "collapsed");
  readonly child = node("workspace:contract:orders:quality", "Quality Specs", "none");

  async treeGetRoot(params: TreeGetRootParams): Promise<{ nodes: TreeNode[] }> {
    assert.equal(params.treeId, "workspace");
    return { nodes: [this.root] };
  }

  async treeGetChildren(params: TreeGetChildrenParams): Promise<{ nodes: TreeNode[] }> {
    assert.equal(params.nodeId, this.root.id);
    return { nodes: [this.child] };
  }

  async treeSubscribe(params: TreeSubscribeParams): Promise<{ subscriptionId: string }> {
    assert.equal(params.treeId, "workspace");
    return { subscriptionId: "subscription-1" };
  }

  async treeUnsubscribe(params: TreeUnsubscribeParams): Promise<void> {
    assert.equal(params.subscriptionId, "subscription-1");
  }

  onTreeDidChange(handler: (params: TreeDidChangeParams) => void): FakeDisposable {
    this.treeDidChangeHandler = handler;
    return new FakeDisposable();
  }

  fireDidChange(params: TreeDidChangeParams): void {
    this.treeDidChangeHandler?.(params);
  }
}

describe("TurbineTreeProvider", () => {
  const moduleWithLoad = Module as typeof Module & { _load: ModuleLoad };
  const originalLoad = moduleWithLoad._load;

  beforeEach(() => {
    moduleWithLoad._load = (request, parent, isMain) => {
      if (request === "vscode") return fakeVscode;
      return originalLoad(request, parent, isMain);
    };
  });

  afterEach(() => {
    moduleWithLoad._load = originalLoad;
  });

  it("implements getParent so TreeView.reveal can select cached nodes", async () => {
    const { TurbineTreeProvider } = await import("../../tree-bridge.js");
    const client = new FakeTurbineClient();
    const provider = new TurbineTreeProvider("workspace", () => client as unknown as TurbineClient);

    const roots = await provider.getChildren();
    const children = await provider.getChildren(roots[0]);

    assert.equal(typeof provider.getParent, "function");
    assert.equal(provider.getParent(roots[0]), undefined);
    assert.deepEqual(provider.getParent(children[0]), roots[0]);
  });
});
