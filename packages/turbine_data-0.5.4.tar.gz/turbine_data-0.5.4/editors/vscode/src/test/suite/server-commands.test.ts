import * as assert from "node:assert/strict";

import { SERVER_COMMANDS } from "../../server-commands";

describe("server command forwarding", () => {
  it("registers dismiss diagnostic so code actions can execute", () => {
    assert.ok(SERVER_COMMANDS.includes("turbine.dismissDiagnostic"));
  });

  it("registers sidebar creation server commands", () => {
    assert.ok(SERVER_COMMANDS.includes("turbine.createDatasource"));
    assert.ok(SERVER_COMMANDS.includes("turbine.createBlankContract"));
  });
});
