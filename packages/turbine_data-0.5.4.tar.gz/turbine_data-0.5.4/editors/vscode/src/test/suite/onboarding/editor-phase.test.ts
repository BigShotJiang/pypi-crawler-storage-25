import * as assert from "node:assert/strict";

import Module = require("node:module");

import type { LspClientState } from "../../../onboarding/editor-phase";
import type { PhaseDto } from "../../../onboarding/phase-client";

type ModuleLoad = (request: string, parent: NodeModule | null | undefined, isMain: boolean) => unknown;

interface FakeDisposable {
  dispose(): void;
}

class FakeEventEmitter<T> {
  private listeners: Array<(value: T) => void> = [];

  readonly event = (listener: (value: T) => void): FakeDisposable => {
    this.listeners.push(listener);
    return {
      dispose: () => {
        this.listeners = this.listeners.filter((entry) => entry !== listener);
      },
    };
  };

  fire(value: T): void {
    for (const listener of [...this.listeners]) {
      listener(value);
    }
  }

  dispose(): void {
    this.listeners = [];
  }
}

const fakeVscode = {
  EventEmitter: FakeEventEmitter,
  Disposable: {
    from(...disposables: FakeDisposable[]): FakeDisposable {
      return {
        dispose: () => {
          for (const disposable of disposables) disposable.dispose();
        },
      };
    },
  },
};

class FakeUvProbe {
  available: boolean;
  callCount = 0;

  constructor(available: boolean) {
    this.available = available;
  }

  async isAvailable(): Promise<boolean> {
    this.callCount += 1;
    return this.available;
  }
}

class FakeWorkspaceFolderSource {
  private present: boolean;
  private listeners: Array<() => void> = [];

  constructor(present: boolean) {
    this.present = present;
  }

  hasFolders(): boolean {
    return this.present;
  }

  onDidChangeFolders(listener: () => void): FakeDisposable {
    this.listeners.push(listener);
    return {
      dispose: () => {
        this.listeners = this.listeners.filter((entry) => entry !== listener);
      },
    };
  }

  setPresent(value: boolean): void {
    this.present = value;
    for (const listener of [...this.listeners]) listener();
  }
}

class FakeLspClientStateSource {
  currentState: LspClientState;
  lastErrorMessage: string | null;
  private listeners: Array<(state: LspClientState) => void> = [];

  constructor(initialState: LspClientState, lastErrorMessage: string | null = null) {
    this.currentState = initialState;
    this.lastErrorMessage = lastErrorMessage;
  }

  onDidChangeState(listener: (state: LspClientState) => void): FakeDisposable {
    this.listeners.push(listener);
    return {
      dispose: () => {
        this.listeners = this.listeners.filter((entry) => entry !== listener);
      },
    };
  }

  transition(state: LspClientState, lastErrorMessage: string | null = null): void {
    this.currentState = state;
    this.lastErrorMessage = lastErrorMessage;
    for (const listener of [...this.listeners]) listener(state);
  }
}

class FakeServerPhaseSource {
  current: PhaseDto | null = null;
  private listeners: Array<(dto: PhaseDto) => void> = [];
  private currentListeners: Array<() => void> = [];

  onPhaseChange(listener: (dto: PhaseDto) => void): FakeDisposable {
    this.listeners.push(listener);
    return {
      dispose: () => {
        this.listeners = this.listeners.filter((entry) => entry !== listener);
      },
    };
  }

  onCurrentChange(listener: () => void): FakeDisposable {
    this.currentListeners.push(listener);
    return {
      dispose: () => {
        this.currentListeners = this.currentListeners.filter((entry) => entry !== listener);
      },
    };
  }

  push(dto: PhaseDto): void {
    this.current = dto;
    for (const listener of [...this.listeners]) listener(dto);
  }

  setCurrent(dto: PhaseDto | null): void {
    this.current = dto;
    for (const listener of [...this.currentListeners]) listener();
  }
}

function makeDto(kind: PhaseDto["kind"], workspaceFolderUri = "file:///workspace"): PhaseDto {
  return {
    workspaceFolderUri,
    kind,
    title: kind,
    body: "",
    choices: [],
    tours: [],
    primaryAction: null,
  };
}

async function loadModule(): Promise<typeof import("../../../onboarding/editor-phase")> {
  const moduleWithLoad = Module as typeof Module & { _load: ModuleLoad };
  const originalLoad = moduleWithLoad._load;
  moduleWithLoad._load = (request, parent, isMain) => {
    if (request === "vscode") return fakeVscode;
    return originalLoad(request, parent, isMain);
  };
  try {
    return await import("../../../onboarding/editor-phase.js");
  } finally {
    moduleWithLoad._load = originalLoad;
  }
}

class FakeTurbineProjectProbe {
  state: "no-pyproject" | "no-turbine-config" | "configured" | "no-active-folder";

  constructor(state: FakeTurbineProjectProbe["state"] = "configured") {
    this.state = state;
  }

  async inspect() {
    return this.state;
  }
}

function makeDeps(overrides: {
  uv?: FakeUvProbe;
  folders?: FakeWorkspaceFolderSource;
  lsp?: FakeLspClientStateSource;
  serverPhase?: FakeServerPhaseSource;
  turbineProject?: FakeTurbineProjectProbe;
}) {
  return {
    uv: overrides.uv ?? new FakeUvProbe(true),
    folders: overrides.folders ?? new FakeWorkspaceFolderSource(true),
    lsp: overrides.lsp ?? new FakeLspClientStateSource("stopped"),
    serverPhase: overrides.serverPhase ?? new FakeServerPhaseSource(),
    turbineProject: overrides.turbineProject ?? new FakeTurbineProjectProbe("configured"),
  };
}

describe("EditorPhaseService", () => {
  it("emits 'awaiting-server-phase' when LSP is running but no PhaseDto has arrived yet", async () => {
    const { EditorPhaseService } = await loadModule();
    const service = new EditorPhaseService(
      makeDeps({
        lsp: new FakeLspClientStateSource("running"),
      }),
    );

    await service.start();

    assert.deepEqual(service.current, { kind: "awaiting-server-phase" });
  });

  it("emits 'no-folder' when no folders are open and uv is available", async () => {
    const { EditorPhaseService } = await loadModule();
    const service = new EditorPhaseService(
      makeDeps({
        folders: new FakeWorkspaceFolderSource(false),
      }),
    );

    await service.start();

    assert.deepEqual(service.current, { kind: "no-folder" });
  });

  it("emits 'needs-uv' regardless of folders or LSP state when uv is missing", async () => {
    const { EditorPhaseService } = await loadModule();
    const service = new EditorPhaseService(
      makeDeps({
        uv: new FakeUvProbe(false),
        lsp: new FakeLspClientStateSource("running"),
      }),
    );

    await service.start();

    assert.deepEqual(service.current, { kind: "needs-uv" });
  });

  it("emits 'starting-server' when folders + uv + LSP is starting", async () => {
    const { EditorPhaseService } = await loadModule();
    const service = new EditorPhaseService(
      makeDeps({
        lsp: new FakeLspClientStateSource("starting"),
      }),
    );

    await service.start();

    assert.deepEqual(service.current, { kind: "starting-server" });
  });

  it("emits 'needs-server' with the reason when the LSP is stopped with an error", async () => {
    const { EditorPhaseService } = await loadModule();
    const service = new EditorPhaseService(
      makeDeps({
        lsp: new FakeLspClientStateSource("stopped", "boom"),
      }),
    );

    await service.start();

    assert.deepEqual(service.current, { kind: "needs-server", reason: "boom" });
  });

  it("transitions starting -> lsp-phase when LSP comes up and a PhaseDto arrives", async () => {
    const { EditorPhaseService } = await loadModule();
    const lsp = new FakeLspClientStateSource("starting");
    const serverPhase = new FakeServerPhaseSource();
    const service = new EditorPhaseService(makeDeps({ lsp, serverPhase }));

    const observed: Array<{ kind: string }> = [];
    service.onPhaseChange((phase) => observed.push(phase));
    await service.start();

    lsp.transition("running");
    serverPhase.push(makeDto("needs-pyproject"));

    assert.equal(observed.at(-1)?.kind, "lsp-phase");
    assert.deepEqual(
      observed.map((entry) => entry.kind),
      ["starting-server", "awaiting-server-phase", "lsp-phase"],
    );
  });

  it("re-emits when a new PhaseDto arrives with a different kind", async () => {
    const { EditorPhaseService } = await loadModule();
    const lsp = new FakeLspClientStateSource("running");
    const serverPhase = new FakeServerPhaseSource();
    const service = new EditorPhaseService(makeDeps({ lsp, serverPhase }));

    const observed: PhaseDto["kind"][] = [];
    service.onPhaseChange((phase) => {
      if (phase.kind === "lsp-phase") observed.push(phase.dto.kind);
    });
    await service.start();

    serverPhase.push(makeDto("needs-pyproject"));
    serverPhase.push(makeDto("needs-turbine"));
    serverPhase.push(makeDto("ready-tour-pending"));

    assert.deepEqual(observed.slice(-3), ["needs-pyproject", "needs-turbine", "ready-tour-pending"]);
  });

  it("recomputes when workspace folders change", async () => {
    const { EditorPhaseService } = await loadModule();
    const folders = new FakeWorkspaceFolderSource(false);
    const service = new EditorPhaseService(makeDeps({ folders }));

    const observed: Array<{ kind: string }> = [];
    service.onPhaseChange((phase) => observed.push(phase));
    await service.start();

    folders.setPresent(true);

    assert.equal(observed.at(-1)?.kind, "needs-server");
  });

  it("re-probes uv on refresh() and emits a new phase when availability changes", async () => {
    const { EditorPhaseService } = await loadModule();
    const uv = new FakeUvProbe(false);
    const lsp = new FakeLspClientStateSource("running");
    const service = new EditorPhaseService(makeDeps({ uv, lsp }));

    await service.start();
    assert.deepEqual(service.current, { kind: "needs-uv" });

    uv.available = true;
    await service.refresh();

    assert.equal(service.current.kind, "awaiting-server-phase");
    assert.equal(uv.callCount, 2);
  });

  it("recomputes when the server-side current changes (active folder switch)", async () => {
    const { EditorPhaseService } = await loadModule();
    const lsp = new FakeLspClientStateSource("running");
    const serverPhase = new FakeServerPhaseSource();
    const service = new EditorPhaseService(makeDeps({ lsp, serverPhase }));

    const observed: Array<{ kind: string }> = [];
    service.onPhaseChange((phase) => observed.push(phase));
    serverPhase.push(makeDto("needs-pyproject", "file:///alpha"));
    await service.start();

    serverPhase.setCurrent(null);

    assert.equal(service.current.kind, "awaiting-server-phase");
    assert.equal(observed.at(-1)?.kind, "awaiting-server-phase");
  });

  it("recomputes to a new lsp-phase when the server-side current swaps DTOs", async () => {
    const { EditorPhaseService } = await loadModule();
    const lsp = new FakeLspClientStateSource("running");
    const serverPhase = new FakeServerPhaseSource();
    const service = new EditorPhaseService(makeDeps({ lsp, serverPhase }));

    serverPhase.push(makeDto("needs-pyproject", "file:///alpha"));
    await service.start();

    const observed: Array<{ kind: string }> = [];
    service.onPhaseChange((phase) => observed.push(phase));
    const next = makeDto("ready-tour-pending", "file:///beta");
    serverPhase.setCurrent(next);

    assert.equal(service.current.kind, "lsp-phase");
    if (service.current.kind === "lsp-phase") {
      assert.equal(service.current.dto.workspaceFolderUri, "file:///beta");
    }
    assert.equal(observed.at(-1)?.kind, "lsp-phase");
  });

  it("treats an empty error message as a null reason on needs-server", async () => {
    const { EditorPhaseService } = await loadModule();
    const service = new EditorPhaseService(
      makeDeps({
        lsp: new FakeLspClientStateSource("stopped", "   "),
      }),
    );

    await service.start();

    assert.deepEqual(service.current, { kind: "needs-server", reason: null });
  });

  it("emits 'needs-turbine-project' with subKind 'no-pyproject' when LSP is stopped and pyproject is missing", async () => {
    const { EditorPhaseService } = await loadModule();
    const service = new EditorPhaseService(
      makeDeps({
        turbineProject: new FakeTurbineProjectProbe("no-pyproject"),
      }),
    );

    await service.start();

    assert.deepEqual(service.current, { kind: "needs-turbine-project", subKind: "no-pyproject" });
  });

  it("emits 'needs-turbine-project' with subKind 'no-turbine-config' when pyproject lacks [tool.turbine]", async () => {
    const { EditorPhaseService } = await loadModule();
    const service = new EditorPhaseService(
      makeDeps({
        turbineProject: new FakeTurbineProjectProbe("no-turbine-config"),
      }),
    );

    await service.start();

    assert.deepEqual(service.current, { kind: "needs-turbine-project", subKind: "no-turbine-config" });
  });

  it("falls back to 'needs-server' when pyproject is configured but LSP is stopped (real failure)", async () => {
    const { EditorPhaseService } = await loadModule();
    const service = new EditorPhaseService(
      makeDeps({
        lsp: new FakeLspClientStateSource("stopped", "boom"),
        turbineProject: new FakeTurbineProjectProbe("configured"),
      }),
    );

    await service.start();

    assert.deepEqual(service.current, { kind: "needs-server", reason: "boom" });
  });
});
