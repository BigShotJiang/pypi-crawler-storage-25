import * as assert from "node:assert/strict";

import Module = require("node:module");

import type { ActiveFolderChange, OnboardingFolder } from "../../../onboarding/active-folder";

type ModuleLoad = (request: string, parent: NodeModule | null | undefined, isMain: boolean) => unknown;

interface FakeDisposable {
  dispose(): void;
}

class FakeEventEmitter<T> {
  private listeners: Array<(value: T) => void> = [];

  readonly event = (listener: (value: T) => void): FakeDisposable => {
    this.listeners.push(listener);
    return {
      dispose: () => {
        this.listeners = this.listeners.filter((entry) => entry !== listener);
      },
    };
  };

  fire(value: T): void {
    for (const listener of [...this.listeners]) {
      listener(value);
    }
  }

  dispose(): void {
    this.listeners = [];
  }
}

const fakeVscode = {
  EventEmitter: FakeEventEmitter,
  Disposable: {
    from(...disposables: FakeDisposable[]): FakeDisposable {
      return {
        dispose: () => {
          for (const disposable of disposables) disposable.dispose();
        },
      };
    },
  },
};

class FakeOnboardingFolderSource {
  private current: OnboardingFolder[];
  private listeners: Array<() => void> = [];

  constructor(initial: OnboardingFolder[]) {
    this.current = [...initial];
  }

  list(): readonly OnboardingFolder[] {
    return this.current;
  }

  onDidChange(listener: () => void): FakeDisposable {
    this.listeners.push(listener);
    return {
      dispose: () => {
        this.listeners = this.listeners.filter((entry) => entry !== listener);
      },
    };
  }

  setFolders(next: OnboardingFolder[]): void {
    this.current = [...next];
    for (const listener of [...this.listeners]) listener();
  }
}

class FakeActiveEditorSource {
  private folderKey: string | null;
  private listeners: Array<() => void> = [];

  constructor(initial: string | null) {
    this.folderKey = initial;
  }

  activeFolderKey(): string | null {
    return this.folderKey;
  }

  onDidChange(listener: () => void): FakeDisposable {
    this.listeners.push(listener);
    return {
      dispose: () => {
        this.listeners = this.listeners.filter((entry) => entry !== listener);
      },
    };
  }

  setActiveFolderKey(next: string | null): void {
    this.folderKey = next;
    for (const listener of [...this.listeners]) listener();
  }
}

function folder(name: string): OnboardingFolder {
  const fsPath = `/workspace/${name}`;
  return {
    key: `file://${fsPath}`,
    label: name,
    fsPath,
  };
}

async function loadModule(): Promise<typeof import("../../../onboarding/active-folder")> {
  const moduleWithLoad = Module as typeof Module & { _load: ModuleLoad };
  const originalLoad = moduleWithLoad._load;
  moduleWithLoad._load = (request, parent, isMain) => {
    if (request === "vscode") return fakeVscode;
    return originalLoad(request, parent, isMain);
  };
  try {
    return await import("../../../onboarding/active-folder.js");
  } finally {
    moduleWithLoad._load = originalLoad;
  }
}

describe("ActiveOnboardingFolder", () => {
  it("defaults to the first folder when no editor is active", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([folder("alpha"), folder("beta")]);
    const editor = new FakeActiveEditorSource(null);

    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });

    assert.equal(active.currentKey, folder("alpha").key);
    assert.equal(active.hasManualSelection, false);
    assert.deepEqual(
      active.folders.map((entry) => entry.label),
      ["alpha", "beta"],
    );
  });

  it("defaults to the active editor's owning folder when one is active", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([folder("alpha"), folder("beta")]);
    const editor = new FakeActiveEditorSource(folder("beta").key);

    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });

    assert.equal(active.currentKey, folder("beta").key);
  });

  it("returns null currentKey when no folders are open", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([]);
    const editor = new FakeActiveEditorSource(null);

    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });

    assert.equal(active.currentKey, null);
    assert.equal(active.folders.length, 0);
  });

  it("follows active-editor changes when no manual selection is set", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([folder("alpha"), folder("beta")]);
    const editor = new FakeActiveEditorSource(folder("alpha").key);
    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });

    const observed: ActiveFolderChange[] = [];
    active.onDidChange((change) => observed.push(change));

    editor.setActiveFolderKey(folder("beta").key);

    assert.equal(active.currentKey, folder("beta").key);
    assert.equal(observed.at(-1)?.reason, "active-editor-changed");
    assert.equal(observed.at(-1)?.key, folder("beta").key);
  });

  it("ignores active-editor changes once a manual selection is set", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([folder("alpha"), folder("beta")]);
    const editor = new FakeActiveEditorSource(folder("alpha").key);
    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });

    active.select(folder("beta").key);
    assert.equal(active.hasManualSelection, true);

    const observed: ActiveFolderChange[] = [];
    active.onDidChange((change) => observed.push(change));

    editor.setActiveFolderKey(folder("alpha").key);

    assert.equal(active.currentKey, folder("beta").key);
    assert.equal(observed.length, 0);
  });

  it("emits manual-selection when select() pins a different folder", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([folder("alpha"), folder("beta")]);
    const editor = new FakeActiveEditorSource(folder("alpha").key);
    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });

    const observed: ActiveFolderChange[] = [];
    active.onDidChange((change) => observed.push(change));

    active.select(folder("beta").key);

    assert.equal(active.currentKey, folder("beta").key);
    assert.deepEqual(
      observed.map((entry) => entry.reason),
      ["manual-selection"],
    );
  });

  it("ignores select() with an unknown key", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([folder("alpha"), folder("beta")]);
    const editor = new FakeActiveEditorSource(folder("alpha").key);
    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });

    const observed: ActiveFolderChange[] = [];
    active.onDidChange((change) => observed.push(change));

    active.select("file:///does-not-exist");

    assert.equal(active.currentKey, folder("alpha").key);
    assert.equal(active.hasManualSelection, false);
    assert.equal(observed.length, 0);
  });

  it("is idempotent when select() pins the already-active folder", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([folder("alpha"), folder("beta")]);
    const editor = new FakeActiveEditorSource(folder("alpha").key);
    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });

    const observed: ActiveFolderChange[] = [];
    active.onDidChange((change) => observed.push(change));

    active.select(folder("alpha").key);

    assert.equal(active.currentKey, folder("alpha").key);
    assert.equal(active.hasManualSelection, true);
    assert.equal(observed.length, 0);
  });

  it("preserves the manual pin when a new folder is added to the workspace", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([folder("alpha"), folder("beta")]);
    const editor = new FakeActiveEditorSource(folder("alpha").key);
    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });
    active.select(folder("beta").key);

    const observed: ActiveFolderChange[] = [];
    active.onDidChange((change) => observed.push(change));

    folders.setFolders([folder("alpha"), folder("beta"), folder("gamma")]);

    assert.equal(active.currentKey, folder("beta").key);
    assert.equal(active.hasManualSelection, true);
    assert.equal(observed.length, 0);
  });

  it("falls back to the default when the manually pinned folder is removed", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([folder("alpha"), folder("beta")]);
    const editor = new FakeActiveEditorSource(folder("alpha").key);
    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });
    active.select(folder("beta").key);

    const observed: ActiveFolderChange[] = [];
    active.onDidChange((change) => observed.push(change));

    folders.setFolders([folder("alpha")]);

    assert.equal(active.currentKey, folder("alpha").key);
    assert.equal(active.hasManualSelection, false);
    assert.deepEqual(
      observed.map((entry) => entry.reason),
      ["workspace-folders-changed"],
    );
  });

  it("emits workspace-folders-changed when the default key shifts on folder removal", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([folder("alpha"), folder("beta")]);
    const editor = new FakeActiveEditorSource(null);
    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });

    const observed: ActiveFolderChange[] = [];
    active.onDidChange((change) => observed.push(change));

    folders.setFolders([folder("beta")]);

    assert.equal(active.currentKey, folder("beta").key);
    assert.deepEqual(
      observed.map((entry) => entry.reason),
      ["workspace-folders-changed"],
    );
  });

  it("clearManualSelection restores default-key resolution", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([folder("alpha"), folder("beta")]);
    const editor = new FakeActiveEditorSource(folder("alpha").key);
    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });
    active.select(folder("beta").key);

    const observed: ActiveFolderChange[] = [];
    active.onDidChange((change) => observed.push(change));

    active.clearManualSelection();

    assert.equal(active.currentKey, folder("alpha").key);
    assert.equal(active.hasManualSelection, false);
    assert.deepEqual(
      observed.map((entry) => entry.reason),
      ["manual-selection"],
    );
  });

  it("currentKey becomes null after the last folder is removed", async () => {
    const { ActiveOnboardingFolder } = await loadModule();
    const folders = new FakeOnboardingFolderSource([folder("alpha")]);
    const editor = new FakeActiveEditorSource(folder("alpha").key);
    const active = new ActiveOnboardingFolder({ folders, activeEditor: editor });

    folders.setFolders([]);

    assert.equal(active.currentKey, null);
    assert.equal(active.folders.length, 0);
  });
});
