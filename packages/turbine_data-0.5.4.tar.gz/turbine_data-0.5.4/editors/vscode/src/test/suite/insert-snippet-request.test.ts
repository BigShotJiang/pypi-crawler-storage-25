import * as assert from "node:assert/strict";

import { failureResult, toEditorSnippetInsertion } from "../../insert-snippet-request";

describe("insert snippet request", () => {
  it("keeps the LSP zero-based position and snippet text for VS Code", () => {
    const insertion = toEditorSnippetInsertion({
      uri: "file:///workspace/quality/orders.yml",
      position: { line: 7, character: 4 },
      snippetText: `  - type: \${1:duplicate}\n`,
    });

    assert.deepEqual(insertion, {
      uri: "file:///workspace/quality/orders.yml",
      line: 7,
      character: 4,
      snippetText: `  - type: \${1:duplicate}\n`,
    });
  });

  it("formats Error failures as apply-edit results", () => {
    assert.deepEqual(failureResult(new Error("editor missing")), {
      applied: false,
      failureReason: "editor missing",
    });
  });

  it("formats non-Error failures without leaking unknown shapes", () => {
    assert.deepEqual(failureResult("bad"), {
      applied: false,
      failureReason: "snippet insertion failed",
    });
  });
});
