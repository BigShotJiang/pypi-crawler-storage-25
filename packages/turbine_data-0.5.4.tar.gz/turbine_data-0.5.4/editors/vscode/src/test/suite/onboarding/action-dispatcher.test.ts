import * as assert from "node:assert/strict";

import type { TurbineClient } from "../../../client";
import {
  type ActionDispatcherDeps,
  type ActiveTourSnapshot,
  OnboardingActionDispatcher,
} from "../../../onboarding/action-dispatcher";
import type { ActionInvokedParams, StepAction, StepActionKind } from "../../../types";

class FakeClient {
  invocations: ActionInvokedParams[] = [];
  reject: Error | null = null;

  async actionInvoked(params: ActionInvokedParams): Promise<void> {
    this.invocations.push(params);
    if (this.reject !== null) throw this.reject;
  }
}

interface FakeBackend {
  commands: Array<{ command: string; args: readonly unknown[] }>;
  urls: string[];
  result: unknown;
}

function makeBackend(result: unknown = "ok"): FakeBackend {
  return { commands: [], urls: [], result };
}

function makeDispatcher(options: {
  tour?: ActiveTourSnapshot | null;
  client?: FakeClient | null;
  backend?: FakeBackend;
  logs?: string[];
}): { dispatcher: OnboardingActionDispatcher; backend: FakeBackend } {
  const backend = options.backend ?? makeBackend();
  const client = options.client ?? null;
  const logs = options.logs ?? [];
  const deps: ActionDispatcherDeps = {
    activeTour: () => options.tour ?? null,
    client: () => client as unknown as TurbineClient | null,
    executeCommand: (command, ...args) => {
      backend.commands.push({ command, args });
      return Promise.resolve(backend.result);
    },
    openExternal: (url) => {
      backend.urls.push(url);
      return Promise.resolve(true);
    },
    logger: (message: string) => logs.push(message),
  };
  return { dispatcher: new OnboardingActionDispatcher(deps), backend };
}

const TOUR: ActiveTourSnapshot = { tourId: "foundations", stepId: "step-x" };

describe("OnboardingActionDispatcher", () => {
  describe("dispatch (low-level command)", () => {
    it("runs the underlying VS Code command and resolves with its result", async () => {
      const { dispatcher, backend } = makeDispatcher({ backend: makeBackend("dashboard-opened") });

      const result = await dispatcher.dispatch("open_dashboard" as StepActionKind, "turbine.openDashboard", {
        url: "x",
      });

      assert.equal(result, "dashboard-opened");
      assert.equal(backend.commands.length, 1);
      assert.deepEqual(backend.commands[0]?.command, "turbine.openDashboard");
      assert.deepEqual(backend.commands[0]?.args, [{ url: "x" }]);
    });

    it("fires actionInvoked for editor-only kinds when a tour is active", async () => {
      const client = new FakeClient();
      const { dispatcher } = makeDispatcher({ tour: TOUR, client });

      await dispatcher.dispatch("open_all_contracts" as StepActionKind, "turbine.allContracts.open");

      assert.equal(client.invocations.length, 1);
      assert.deepEqual(client.invocations[0], {
        tourId: "foundations",
        stepId: "step-x",
        kind: "open_all_contracts" as StepActionKind,
      });
    });

    it("does NOT fire actionInvoked for LSP-routed kinds (server publishes those)", async () => {
      const client = new FakeClient();
      const { dispatcher } = makeDispatcher({ tour: TOUR, client });

      await dispatcher.dispatch("run_validate" as StepActionKind, "turbine.validateContract");
      await dispatcher.dispatch("run_single_check" as StepActionKind, "turbine.runSingleCheck");
      await dispatcher.dispatch("run_sandbox_checks" as StepActionKind, "turbine.runQualityWorkspace");

      assert.equal(client.invocations.length, 0);
    });

    it("does not fire actionInvoked when no tour is active", async () => {
      const client = new FakeClient();
      const { dispatcher } = makeDispatcher({ tour: null, client });

      await dispatcher.dispatch("open_dashboard" as StepActionKind, "turbine.openDashboard");

      assert.equal(client.invocations.length, 0);
    });

    it("does not fire actionInvoked when the LSP client is unavailable, but still runs the command", async () => {
      const { dispatcher, backend } = makeDispatcher({ tour: TOUR, client: null });

      await dispatcher.dispatch("open_dashboard" as StepActionKind, "turbine.openDashboard");

      assert.equal(backend.commands.length, 1);
    });

    it("logs and continues when actionInvoked rejects (fire-and-forget)", async () => {
      const client = new FakeClient();
      client.reject = new Error("server unavailable");
      const logs: string[] = [];
      const { dispatcher, backend } = makeDispatcher({
        tour: TOUR,
        client,
        backend: makeBackend("done"),
        logs,
      });

      const result = await dispatcher.dispatch("open_dashboard" as StepActionKind, "turbine.openDashboard");

      assert.equal(result, "done");
      assert.equal(backend.commands.length, 1);
      // Allow the rejected promise's catch handler to run.
      await new Promise<void>((resolve) => setImmediate(resolve));
      assert.equal(logs.length, 1);
      assert.match(logs[0] ?? "", /actionInvoked failed for open_dashboard/);
    });
  });

  describe("openUrl", () => {
    it("opens the URL externally and fires actionInvoked", async () => {
      const client = new FakeClient();
      const { dispatcher, backend } = makeDispatcher({ tour: TOUR, client });

      await dispatcher.openUrl("open_dashboard" as StepActionKind, "http://127.0.0.1:8501");

      assert.deepEqual(backend.urls, ["http://127.0.0.1:8501"]);
      assert.equal(client.invocations.length, 1);
      assert.equal(client.invocations[0]?.kind, "open_dashboard");
    });
  });

  describe("notify", () => {
    it("fires actionInvoked without running any command", async () => {
      const client = new FakeClient();
      const { dispatcher, backend } = makeDispatcher({ tour: TOUR, client });

      dispatcher.notify("generate_api" as StepActionKind);

      assert.equal(backend.commands.length, 0);
      assert.equal(backend.urls.length, 0);
      assert.equal(client.invocations.length, 1);
      assert.equal(client.invocations[0]?.kind, "generate_api");
    });

    it("does not fire for LSP-routed kinds", async () => {
      const client = new FakeClient();
      const { dispatcher } = makeDispatcher({ tour: TOUR, client });

      dispatcher.notify("run_validate" as StepActionKind);

      assert.equal(client.invocations.length, 0);
    });
  });

  describe("dispatchStepAction (StepAction → interaction)", () => {
    function makeAction(kind: StepActionKind, extra: Partial<StepAction> = {}): StepAction {
      return {
        kind,
        label: `Test ${kind}`,
        ...extra,
      } as StepAction;
    }

    it("maps run_validate to turbine.validateContract", async () => {
      const { dispatcher, backend } = makeDispatcher({ tour: TOUR });

      await dispatcher.dispatchStepAction(makeAction("run_validate" as StepActionKind));

      assert.equal(backend.commands[0]?.command, "turbine.validateContract");
    });

    it("maps run_single_check to turbine.runSingleCheck", async () => {
      const { dispatcher, backend } = makeDispatcher({ tour: TOUR });

      await dispatcher.dispatchStepAction(makeAction("run_single_check" as StepActionKind));

      assert.equal(backend.commands[0]?.command, "turbine.runSingleCheck");
    });

    it("maps run_sandbox_checks to turbine.runQualityWorkspace", async () => {
      const { dispatcher, backend } = makeDispatcher({ tour: TOUR });

      await dispatcher.dispatchStepAction(makeAction("run_sandbox_checks" as StepActionKind));

      assert.equal(backend.commands[0]?.command, "turbine.runQualityWorkspace");
    });

    it("maps open_add_check to turbine.addCheck with file/dataset args when present", async () => {
      const { dispatcher, backend } = makeDispatcher({ tour: TOUR });

      await dispatcher.dispatchStepAction(
        makeAction("open_add_check" as StepActionKind, {
          file: "quality/orders.yml",
          dataset: "public.orders",
        }),
      );

      assert.equal(backend.commands[0]?.command, "turbine.addCheck");
      assert.deepEqual(backend.commands[0]?.args, ["quality/orders.yml", "public.orders"]);
    });

    it("opens external URLs for open_dashboard / open_data_swagger / open_management_swagger", async () => {
      const client = new FakeClient();
      const { dispatcher, backend } = makeDispatcher({ tour: TOUR, client });

      await dispatcher.dispatchStepAction(
        makeAction("open_dashboard" as StepActionKind, { url: "http://127.0.0.1:8501" }),
      );
      await dispatcher.dispatchStepAction(
        makeAction("open_data_swagger" as StepActionKind, { url: "http://127.0.0.1:8000/docs" }),
      );
      await dispatcher.dispatchStepAction(
        makeAction("open_management_swagger" as StepActionKind, {
          url: "http://127.0.0.1:8000/manage/docs",
        }),
      );

      assert.deepEqual(backend.urls, [
        "http://127.0.0.1:8501",
        "http://127.0.0.1:8000/docs",
        "http://127.0.0.1:8000/manage/docs",
      ]);
      assert.equal(client.invocations.length, 3);
    });

    it("logs and falls back to notify-only when a URL action has no url", async () => {
      const client = new FakeClient();
      const logs: string[] = [];
      const { dispatcher, backend } = makeDispatcher({ tour: TOUR, client, logs });

      await dispatcher.dispatchStepAction(makeAction("open_dashboard" as StepActionKind));

      assert.equal(backend.urls.length, 0);
      assert.equal(client.invocations.length, 1);
      assert.match(logs[0] ?? "", /open_dashboard action has no url/);
    });

    it("notifies-only for generate_api and start_api_server", async () => {
      const client = new FakeClient();
      const { dispatcher, backend } = makeDispatcher({ tour: TOUR, client });

      await dispatcher.dispatchStepAction(makeAction("generate_api" as StepActionKind));
      await dispatcher.dispatchStepAction(makeAction("start_api_server" as StepActionKind));

      assert.equal(backend.commands.length, 0);
      assert.equal(backend.urls.length, 0);
      assert.equal(client.invocations.length, 2);
    });

    it("maps final_handoff to turbine.datasources.newDatasource", async () => {
      const client = new FakeClient();
      const { dispatcher, backend } = makeDispatcher({ tour: TOUR, client });

      await dispatcher.dispatchStepAction(makeAction("final_handoff" as StepActionKind));

      assert.equal(backend.commands[0]?.command, "turbine.datasources.newDatasource");
      assert.equal(client.invocations[0]?.kind, "final_handoff");
    });
  });
});
