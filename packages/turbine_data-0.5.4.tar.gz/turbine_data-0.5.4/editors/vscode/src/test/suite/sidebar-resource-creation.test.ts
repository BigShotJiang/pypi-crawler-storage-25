import * as assert from "node:assert/strict";
import * as fs from "node:fs";
import * as path from "node:path";

import Module = require("node:module");

import type * as vscode from "vscode";

import type { TreeNode, WorkspaceConfigParams } from "../../types";

interface PackageCommandContribution {
  readonly command: string;
  readonly title: string;
}

interface PackageMenuContribution {
  readonly command: string;
  readonly when: string;
  readonly group: string;
}

interface ExtensionPackageJson {
  readonly contributes: {
    readonly commands: readonly PackageCommandContribution[];
    readonly menus: {
      readonly "view/title": readonly PackageMenuContribution[];
      readonly "view/item/context": readonly PackageMenuContribution[];
    };
  };
}

type ModuleLoad = (request: string, parent: NodeModule | null | undefined, isMain: boolean) => unknown;

interface FakeUri {
  readonly fsPath: string;
  toString(): string;
}

interface FakeWorkspaceFolder {
  readonly index: number;
  readonly name: string;
  readonly uri: FakeUri;
}

interface SentRequest {
  readonly method: string;
  readonly params: {
    readonly command: string;
    readonly arguments: readonly string[];
  };
}

interface FakeCommandResult {
  readonly message: string;
  readonly success: boolean;
}

class FakeLanguageClient {
  readonly sentRequests: SentRequest[] = [];
  nextResults: FakeCommandResult[] = [{ message: "created", success: true }];

  async sendRequest(method: string, params: SentRequest["params"]): Promise<FakeCommandResult> {
    this.sentRequests.push({ method, params });
    return this.nextResults.shift() ?? { message: "created", success: true };
  }
}

interface FakeDatasourceInfo {
  readonly name: string;
  readonly dsType: string;
  readonly uri: string;
}

class FakeTurbineClient {
  readonly lsp = new FakeLanguageClient();

  constructor(private readonly datasources: FakeDatasourceInfo[] = []) {}

  async listDatasources(): Promise<{ datasources: FakeDatasourceInfo[] }> {
    return { datasources: this.datasources };
  }
}

class FakeTreeProvider {
  refreshCount = 0;
  readonly nodesByUri = new Map<string, TreeNode>();
  readonly nodesById = new Map<string, TreeNode>();

  async refreshRoot(): Promise<TreeNode[]> {
    this.refreshCount += 1;
    return [...this.nodesById.values()];
  }

  findCachedNodeByResourceUri(uri: string): TreeNode | undefined {
    return this.nodesByUri.get(uri);
  }

  findCachedNodeById(id: string): TreeNode | undefined {
    return this.nodesById.get(id);
  }
}

class FakeTreeView {
  revealed: TreeNode[] = [];

  throwOnReveal = false;

  async reveal(node: TreeNode): Promise<void> {
    if (this.throwOnReveal) throw new Error("reveal failed");
    this.revealed.push(node);
  }
}

interface FakeVscodeState {
  readonly registeredCommands: Map<string, (...args: readonly unknown[]) => Promise<void> | void>;
  quickPickQueue: unknown[];
  quickPickCalls: readonly unknown[][];
  informationMessageQueue: Array<string | undefined>;
  workspaceFolderPickQueue: FakeWorkspaceFolder[];
  activeUri: string | null;
}

const fakeVscodeState: FakeVscodeState = {
  registeredCommands: new Map(),
  quickPickQueue: [],
  quickPickCalls: [],
  informationMessageQueue: [],
  workspaceFolderPickQueue: [],
  activeUri: null,
};

function fakeUri(filePath: string): FakeUri {
  return {
    fsPath: filePath,
    toString: () => `file://${filePath}`,
  };
}

const fakeVscode = {
  Uri: {
    file: (filePath: string): FakeUri => fakeUri(filePath),
    parse: (uri: string): FakeUri => fakeUri(uri.replace("file://", "")),
  },
  commands: {
    registerCommand: (command: string, callback: (...args: readonly unknown[]) => Promise<void> | void) => {
      fakeVscodeState.registeredCommands.set(command, callback);
      return { dispose: () => undefined };
    },
  },
  window: {
    get activeTextEditor(): { document: { uri: FakeUri } } | undefined {
      if (fakeVscodeState.activeUri === null) return undefined;
      return { document: { uri: fakeUri(fakeVscodeState.activeUri.replace("file://", "")) } };
    },
    showQuickPick: async <T>(items: readonly T[]): Promise<T | undefined> => {
      fakeVscodeState.quickPickCalls = [...fakeVscodeState.quickPickCalls, [...items]];
      const queued = fakeVscodeState.quickPickQueue.shift();
      if (queued === undefined) return undefined;
      if (typeof queued === "number") return items[queued];
      return queued as T;
    },
    showInformationMessage: async (): Promise<string | undefined> => {
      return fakeVscodeState.informationMessageQueue.shift();
    },
    showWorkspaceFolderPick: async (): Promise<FakeWorkspaceFolder | undefined> => {
      return fakeVscodeState.workspaceFolderPickQueue.shift();
    },
    showWarningMessage: async (): Promise<undefined> => undefined,
  },
};

function resetFakeVscode(): void {
  fakeVscodeState.registeredCommands.clear();
  fakeVscodeState.quickPickQueue = [];
  fakeVscodeState.quickPickCalls = [];
  fakeVscodeState.informationMessageQueue = [];
  fakeVscodeState.workspaceFolderPickQueue = [];
  fakeVscodeState.activeUri = null;
}

async function loadShellModule(): Promise<typeof import("../../sidebar-resource-creation")> {
  const moduleWithLoad = Module as typeof Module & { _load: ModuleLoad };
  const originalLoad = moduleWithLoad._load;
  moduleWithLoad._load = (request, parent, isMain) => {
    if (request === "vscode") return fakeVscode;
    return originalLoad(request, parent, isMain);
  };
  try {
    return await import("../../sidebar-resource-creation.js");
  } finally {
    moduleWithLoad._load = originalLoad;
  }
}

function makeFolder(name: string, root: string): FakeWorkspaceFolder {
  return { index: 0, name, uri: fakeUri(root) };
}

function asWorkspaceFolder(folder: FakeWorkspaceFolder): vscode.WorkspaceFolder {
  return folder as unknown as vscode.WorkspaceFolder;
}

function makeConfig(root: string): WorkspaceConfigParams {
  return {
    root,
    contractsDir: `${root}/contracts`,
    qualityDir: `${root}/quality`,
    checksDir: `${root}/checks`,
    datasourcesDir: `${root}/datasources`,
  };
}

function readPackageJson(): ExtensionPackageJson {
  const packagePath = path.resolve(__dirname, "../../../package.json");
  return JSON.parse(fs.readFileSync(packagePath, "utf8")) as ExtensionPackageJson;
}

describe("SidebarResourceCreationShell", () => {
  beforeEach(() => {
    resetFakeVscode();
  });

  it("forwards New Datasource to the only target and refreshes Datasources", async () => {
    const { SidebarResourceCreationShell } = await loadShellModule();
    const folder = makeFolder("project", "/workspace/project");
    const client = new FakeTurbineClient();
    const datasourcesProvider = new FakeTreeProvider();
    const datasourcesView = new FakeTreeView();
    const workspaceProvider = new FakeTreeProvider();
    const workspaceView = new FakeTreeView();
    const shell = new SidebarResourceCreationShell({
      getTargets: () => [
        {
          folder: asWorkspaceFolder(folder),
          root: "/workspace/project",
          label: ".",
          client,
          config: makeConfig("/workspace/project"),
        },
      ],
      getWorkspaceFolders: () => [asWorkspaceFolder(folder)],
      runProjectInitialization: async () => undefined,
      trees: {
        workspace: { provider: workspaceProvider, view: workspaceView },
        datasources: { provider: datasourcesProvider, view: datasourcesView },
      },
    });

    await shell.newDatasource();

    assert.deepEqual(client.lsp.sentRequests, [
      {
        method: "workspace/executeCommand",
        params: {
          command: "turbine.createDatasource",
          arguments: ["/workspace/project"],
        },
      },
    ]);
    assert.equal(datasourcesProvider.refreshCount, 1);
    assert.equal(workspaceProvider.refreshCount, 0);
  });

  it("picks Blank Contract and refreshes All Contracts", async () => {
    const { SidebarResourceCreationShell } = await loadShellModule();
    const folder = makeFolder("project", "/workspace/project");
    const client = new FakeTurbineClient();
    const datasourcesProvider = new FakeTreeProvider();
    const datasourcesView = new FakeTreeView();
    const workspaceProvider = new FakeTreeProvider();
    const workspaceView = new FakeTreeView();
    fakeVscodeState.quickPickQueue.push(0);
    const shell = new SidebarResourceCreationShell({
      getTargets: () => [
        {
          folder: asWorkspaceFolder(folder),
          root: "/workspace/project",
          label: ".",
          client,
          config: makeConfig("/workspace/project"),
        },
      ],
      getWorkspaceFolders: () => [asWorkspaceFolder(folder)],
      runProjectInitialization: async () => undefined,
      trees: {
        workspace: { provider: workspaceProvider, view: workspaceView },
        datasources: { provider: datasourcesProvider, view: datasourcesView },
      },
    });

    await shell.newContract();

    assert.deepEqual(client.lsp.sentRequests, [
      {
        method: "workspace/executeCommand",
        params: {
          command: "turbine.createBlankContract",
          arguments: ["/workspace/project"],
        },
      },
    ]);
    assert.equal(workspaceProvider.refreshCount, 1);
    assert.equal(datasourcesProvider.refreshCount, 0);
  });

  it("routes New Contract From Datasource through Python-owned datasource selection", async () => {
    const { SidebarResourceCreationShell } = await loadShellModule();
    const folder = makeFolder("project", "/workspace/project");
    const client = new FakeTurbineClient();
    const datasourcesProvider = new FakeTreeProvider();
    const datasourcesView = new FakeTreeView();
    const workspaceProvider = new FakeTreeProvider();
    const workspaceView = new FakeTreeView();
    fakeVscodeState.quickPickQueue.push(1);
    const shell = new SidebarResourceCreationShell({
      getTargets: () => [
        {
          folder: asWorkspaceFolder(folder),
          root: "/workspace/project",
          label: ".",
          client,
          config: makeConfig("/workspace/project"),
        },
      ],
      getWorkspaceFolders: () => [asWorkspaceFolder(folder)],
      runProjectInitialization: async () => undefined,
      trees: {
        workspace: { provider: workspaceProvider, view: workspaceView },
        datasources: { provider: datasourcesProvider, view: datasourcesView },
      },
    });

    await shell.newContract();

    assert.deepEqual(client.lsp.sentRequests, [
      {
        method: "workspace/executeCommand",
        params: {
          command: "turbine.createContractFromDatasource",
          arguments: ["/workspace/project"],
        },
      },
    ]);
    assert.equal(workspaceProvider.refreshCount, 1);
  });

  it("routes Datasource row Create DataContract with target root and datasource uri", async () => {
    const { SidebarResourceCreationShell } = await loadShellModule();
    const folder = makeFolder("project", "/workspace/project");
    const client = new FakeTurbineClient([
      {
        name: "warehouse",
        dsType: "postgres",
        uri: "file:///workspace/project/datasources/custom-file.yml",
      },
    ]);
    const workspaceProvider = new FakeTreeProvider();
    const workspaceView = new FakeTreeView();
    const shell = new SidebarResourceCreationShell({
      getTargets: () => [
        {
          folder: asWorkspaceFolder(folder),
          root: "/workspace/project",
          label: ".",
          client,
          config: makeConfig("/workspace/project"),
        },
      ],
      getWorkspaceFolders: () => [asWorkspaceFolder(folder)],
      runProjectInitialization: async () => undefined,
      trees: {
        workspace: { provider: workspaceProvider, view: workspaceView },
        datasources: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
      },
    });

    await shell.createDataContractFromDatasourceRow({
      id: "datasources:datasource:warehouse",
      label: "warehouse",
      icon: "datasource",
      collapsibleState: "none",
      description: null,
      tooltip: null,
      contextValue: "datasource",
      resourceUri: null,
      command: null,
    });

    assert.deepEqual(client.lsp.sentRequests, [
      {
        method: "workspace/executeCommand",
        params: {
          command: "turbine.createContractFromDatasource",
          arguments: ["/workspace/project", "file:///workspace/project/datasources/custom-file.yml"],
        },
      },
    ]);
    assert.equal(workspaceProvider.refreshCount, 1);
  });

  it("Datasource row Create DataContract uses the row-owning target in multi-root workspaces", async () => {
    const { SidebarResourceCreationShell } = await loadShellModule();
    const firstFolder = makeFolder("first", "/workspace/first");
    const secondFolder = makeFolder("second", "/workspace/second");
    const firstClient = new FakeTurbineClient([
      {
        name: "warehouse",
        dsType: "postgres",
        uri: "file:///workspace/first/datasources/warehouse.yml",
      },
    ]);
    const secondClient = new FakeTurbineClient([
      {
        name: "other",
        dsType: "duckdb",
        uri: "file:///workspace/second/datasources/other.yml",
      },
    ]);
    const shell = new SidebarResourceCreationShell({
      getTargets: () => [
        {
          folder: asWorkspaceFolder(firstFolder),
          root: "/workspace/first",
          label: ".",
          client: firstClient,
          config: makeConfig("/workspace/first"),
        },
        {
          folder: asWorkspaceFolder(secondFolder),
          root: "/workspace/second",
          label: ".",
          client: secondClient,
          config: makeConfig("/workspace/second"),
        },
      ],
      getWorkspaceFolders: () => [asWorkspaceFolder(firstFolder), asWorkspaceFolder(secondFolder)],
      runProjectInitialization: async () => undefined,
      trees: {
        workspace: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
        datasources: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
      },
    });

    await shell.createDataContractFromDatasourceRow({
      id: "datasources:datasource:warehouse",
      label: "warehouse",
      icon: "datasource",
      collapsibleState: "none",
      description: null,
      tooltip: null,
      contextValue: "datasource",
      resourceUri: null,
      command: null,
    });

    assert.deepEqual(firstClient.lsp.sentRequests, [
      {
        method: "workspace/executeCommand",
        params: {
          command: "turbine.createContractFromDatasource",
          arguments: ["/workspace/first", "file:///workspace/first/datasources/warehouse.yml"],
        },
      },
    ]);
    assert.equal(secondClient.lsp.sentRequests.length, 0);
    assert.equal(fakeVscodeState.quickPickCalls.length, 0);
  });

  it("asks which Turbine root to target when multiple roots are available", async () => {
    const { SidebarResourceCreationShell } = await loadShellModule();
    const firstFolder = makeFolder("first", "/workspace/first");
    const secondFolder = makeFolder("second", "/workspace/second");
    const firstClient = new FakeTurbineClient();
    const secondClient = new FakeTurbineClient();
    fakeVscodeState.quickPickQueue.push(1);
    const shell = new SidebarResourceCreationShell({
      getTargets: () => [
        {
          folder: asWorkspaceFolder(firstFolder),
          root: "/workspace/first/src/first",
          label: "src/first",
          client: firstClient,
          config: makeConfig("/workspace/first/src/first"),
        },
        {
          folder: asWorkspaceFolder(secondFolder),
          root: "/workspace/second",
          label: ".",
          client: secondClient,
          config: makeConfig("/workspace/second"),
        },
      ],
      getWorkspaceFolders: () => [asWorkspaceFolder(firstFolder), asWorkspaceFolder(secondFolder)],
      runProjectInitialization: async () => undefined,
      trees: {
        workspace: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
        datasources: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
      },
    });

    await shell.newDatasource();

    const targetPickItems = fakeVscodeState.quickPickCalls[0] as Array<{ label: string; detail: string }>;
    assert.deepEqual(
      targetPickItems.map((item) => ({ label: item.label, detail: item.detail })),
      [
        { label: "src/first", detail: "/workspace/first/src/first" },
        { label: ".", detail: "/workspace/second" },
      ],
    );
    assert.equal(firstClient.lsp.sentRequests.length, 0);
    assert.deepEqual(secondClient.lsp.sentRequests[0], {
      method: "workspace/executeCommand",
      params: {
        command: "turbine.createDatasource",
        arguments: ["/workspace/second"],
      },
    });
  });

  it("offers Project Initialization when no Turbine roots are available", async () => {
    const { SidebarResourceCreationShell } = await loadShellModule();
    const folder = makeFolder("project", "/workspace/project");
    const initializedFolders: vscode.WorkspaceFolder[] = [];
    fakeVscodeState.informationMessageQueue.push("Project Initialization");
    const shell = new SidebarResourceCreationShell({
      getTargets: () => [],
      getWorkspaceFolders: () => [asWorkspaceFolder(folder)],
      runProjectInitialization: async (selected) => {
        initializedFolders.push(selected);
      },
      trees: {
        workspace: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
        datasources: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
      },
    });

    await shell.newDatasource();

    assert.deepEqual(initializedFolders, [asWorkspaceFolder(folder)]);
  });

  it("reveals the created Datasource row after refresh when it is cached", async () => {
    const { SidebarResourceCreationShell } = await loadShellModule();
    const folder = makeFolder("project", "/workspace/project");
    const client = new FakeTurbineClient();
    const datasourcesProvider = new FakeTreeProvider();
    const datasourcesView = new FakeTreeView();
    const datasourceNode: TreeNode = {
      id: "datasources:datasource:warehouse",
      label: "warehouse",
      icon: "datasource",
      collapsibleState: "none",
      description: null,
      tooltip: null,
      contextValue: "datasource",
      resourceUri: null,
      command: null,
    };
    datasourcesProvider.nodesById.set(datasourceNode.id, datasourceNode);
    fakeVscodeState.activeUri = "file:///workspace/project/datasources/warehouse.yml";
    const shell = new SidebarResourceCreationShell({
      getTargets: () => [
        {
          folder: asWorkspaceFolder(folder),
          root: "/workspace/project",
          label: ".",
          client,
          config: makeConfig("/workspace/project"),
        },
      ],
      getWorkspaceFolders: () => [asWorkspaceFolder(folder)],
      runProjectInitialization: async () => undefined,
      trees: {
        workspace: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
        datasources: { provider: datasourcesProvider, view: datasourcesView },
      },
    });

    await shell.newDatasource();

    assert.deepEqual(datasourcesView.revealed, [datasourceNode]);
  });

  it("skips refresh and reveal when Contract from Datasource is cancelled", async () => {
    const { SidebarResourceCreationShell } = await loadShellModule();
    const folder = makeFolder("project", "/workspace/project");
    const client = new FakeTurbineClient([
      {
        name: "warehouse",
        dsType: "postgres",
        uri: "file:///workspace/project/datasources/warehouse.yml",
      },
    ]);
    client.lsp.nextResults = [{ message: "Contract from Datasource cancelled", success: false }];
    const workspaceProvider = new FakeTreeProvider();
    const workspaceView = new FakeTreeView();
    fakeVscodeState.activeUri = "file:///workspace/project/contracts/orders.yml";
    const shell = new SidebarResourceCreationShell({
      getTargets: () => [
        {
          folder: asWorkspaceFolder(folder),
          root: "/workspace/project",
          label: ".",
          client,
          config: makeConfig("/workspace/project"),
        },
      ],
      getWorkspaceFolders: () => [asWorkspaceFolder(folder)],
      runProjectInitialization: async () => undefined,
      trees: {
        workspace: { provider: workspaceProvider, view: workspaceView },
        datasources: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
      },
    });

    await shell.createDataContractFromDatasourceRow({
      id: "datasources:datasource:warehouse",
      label: "warehouse",
      icon: "datasource",
      collapsibleState: "none",
      description: null,
      tooltip: null,
      contextValue: "datasource",
      resourceUri: null,
      command: null,
    });

    assert.equal(workspaceProvider.refreshCount, 0);
    assert.deepEqual(workspaceView.revealed, []);
  });

  it("does not fail the creation command when sidebar reveal is unavailable", async () => {
    const { SidebarResourceCreationShell } = await loadShellModule();
    const folder = makeFolder("project", "/workspace/project");
    const client = new FakeTurbineClient();
    const datasourcesProvider = new FakeTreeProvider();
    const datasourcesView = new FakeTreeView();
    const datasourceNode: TreeNode = {
      id: "datasources:datasource:warehouse",
      label: "warehouse",
      icon: "datasource",
      collapsibleState: "none",
      description: null,
      tooltip: null,
      contextValue: "datasource",
      resourceUri: null,
      command: null,
    };
    datasourcesProvider.nodesById.set(datasourceNode.id, datasourceNode);
    datasourcesView.throwOnReveal = true;
    fakeVscodeState.activeUri = "file:///workspace/project/datasources/warehouse.yml";
    const shell = new SidebarResourceCreationShell({
      getTargets: () => [
        {
          folder: asWorkspaceFolder(folder),
          root: "/workspace/project",
          label: ".",
          client,
          config: makeConfig("/workspace/project"),
        },
      ],
      getWorkspaceFolders: () => [asWorkspaceFolder(folder)],
      runProjectInitialization: async () => undefined,
      trees: {
        workspace: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
        datasources: { provider: datasourcesProvider, view: datasourcesView },
      },
    });

    await shell.newDatasource();

    assert.equal(datasourcesProvider.refreshCount, 1);
    assert.deepEqual(datasourcesView.revealed, []);
  });

  it("reveals the created Contract row by resource URI after refresh", async () => {
    const { SidebarResourceCreationShell } = await loadShellModule();
    const folder = makeFolder("project", "/workspace/project");
    const client = new FakeTurbineClient();
    const workspaceProvider = new FakeTreeProvider();
    const workspaceView = new FakeTreeView();
    const contractUri = "file:///workspace/project/contracts/orders.yml";
    const contractNode: TreeNode = {
      id: `workspace|contract|${contractUri}`,
      label: "orders",
      icon: "contract",
      collapsibleState: "none",
      description: null,
      tooltip: null,
      contextValue: "workspace-contract",
      resourceUri: contractUri,
      command: null,
    };
    workspaceProvider.nodesByUri.set(contractUri, contractNode);
    fakeVscodeState.activeUri = contractUri;
    fakeVscodeState.quickPickQueue.push(0);
    const shell = new SidebarResourceCreationShell({
      getTargets: () => [
        {
          folder: asWorkspaceFolder(folder),
          root: "/workspace/project",
          label: ".",
          client,
          config: makeConfig("/workspace/project"),
        },
      ],
      getWorkspaceFolders: () => [asWorkspaceFolder(folder)],
      runProjectInitialization: async () => undefined,
      trees: {
        workspace: { provider: workspaceProvider, view: workspaceView },
        datasources: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
      },
    });

    await shell.newContract();

    assert.deepEqual(workspaceView.revealed, [contractNode]);
  });

  it("registers the visible sidebar commands", async () => {
    const { SidebarResourceCreationShell } = await loadShellModule();
    const context = { subscriptions: [] as Array<{ dispose(): void }> };
    const shell = new SidebarResourceCreationShell({
      getTargets: () => [],
      getWorkspaceFolders: () => [],
      runProjectInitialization: async () => undefined,
      trees: {
        workspace: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
        datasources: { provider: new FakeTreeProvider(), view: new FakeTreeView() },
      },
    });

    shell.register(context as vscode.ExtensionContext);

    assert.equal(fakeVscodeState.registeredCommands.has("turbine.workspaceContracts.newContract"), true);
    assert.equal(fakeVscodeState.registeredCommands.has("turbine.datasources.newDatasource"), true);
    assert.equal(context.subscriptions.length, 3);
  });

  it("contributes New Contract, New Datasource, and Datasource row creation commands", () => {
    const manifest = readPackageJson();
    const commandIds = manifest.contributes.commands.map((entry) => entry.command);
    const viewTitleIds = manifest.contributes.menus["view/title"].map((entry) => entry.command);
    const itemContextIds = manifest.contributes.menus["view/item/context"].map((entry) => entry.command);

    assert.ok(commandIds.includes("turbine.workspaceContracts.newContract"));
    assert.ok(commandIds.includes("turbine.datasources.newDatasource"));
    assert.ok(commandIds.includes("turbine.datasources.createDataContract"));
    assert.ok(viewTitleIds.includes("turbine.workspaceContracts.newContract"));
    assert.ok(viewTitleIds.includes("turbine.datasources.newDatasource"));
    assert.ok(itemContextIds.includes("turbine.datasources.createDataContract"));
  });
});
