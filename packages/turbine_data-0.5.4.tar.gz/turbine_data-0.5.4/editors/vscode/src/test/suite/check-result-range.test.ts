import * as assert from "node:assert/strict";

import { diagnosticRangeForCheckResult } from "../../check-result-range";
import type { CheckResultItem } from "../../types";

function itemWithRange(
  startLine: number | null,
  startCol: number | null,
  endLine: number | null,
  endCol: number | null,
): CheckResultItem {
  return {
    checkName: "test-name",
    isRowBased: true,
    outcome: "failed",
    rowsTested: 16814395,
    rowsFailed: 44999,
    contractId: "orders",
    dataset: "public.orders",
    diagnostics: [],
    startLine,
    startCol,
    endLine,
    endCol,
  };
}

describe("check result diagnostic range", () => {
  it("uses the check source span from turbine/runCheck instead of the file origin", () => {
    const range = diagnosticRangeForCheckResult(itemWithRange(42, 9, 42, 18));

    assert.deepEqual(range, {
      startLine: 41,
      startCharacter: 8,
      endLine: 41,
      endCharacter: 17,
    });
  });

  it("falls back to the origin only when the server has no check span", () => {
    const range = diagnosticRangeForCheckResult(itemWithRange(null, null, null, null));

    assert.deepEqual(range, {
      startLine: 0,
      startCharacter: 0,
      endLine: 0,
      endCharacter: 0,
    });
  });
});
