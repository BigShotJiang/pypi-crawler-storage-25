import * as assert from "node:assert/strict";

import Module = require("node:module");

type ModuleLoad = (request: string, parent: NodeModule | null | undefined, isMain: boolean) => unknown;

interface FakeDisposable {
  dispose(): void;
}

class FakeEventEmitter<T> {
  private listeners: Array<(value: T) => void> = [];

  readonly event = (listener: (value: T) => void): FakeDisposable => {
    this.listeners.push(listener);
    return {
      dispose: () => {
        this.listeners = this.listeners.filter((entry) => entry !== listener);
      },
    };
  };

  fire(value: T): void {
    for (const listener of [...this.listeners]) listener(value);
  }

  dispose(): void {
    this.listeners = [];
  }
}

class FakeShellExecution {
  constructor(
    public commandLine: string,
    public options: unknown,
  ) {}
}

class FakeTask {
  constructor(
    public definition: unknown,
    public scope: unknown,
    public name: string,
    public source: string,
    public execution: FakeShellExecution,
    public problemMatchers: string[],
  ) {}
  presentationOptions: unknown = {};
}

class FakeTaskExecution {
  constructor(public task: FakeTask) {}
}

interface FakeTaskProcessEndEvent {
  execution: FakeTaskExecution;
  exitCode: number | undefined;
}

class FakeTasksApi {
  endEmitter = new FakeEventEmitter<FakeTaskProcessEndEvent>();
  scriptedExitCodes: number[] = [];
  invocations: string[] = [];

  async executeTask(task: FakeTask): Promise<FakeTaskExecution> {
    const execution = new FakeTaskExecution(task);
    this.invocations.push((task.execution as FakeShellExecution).commandLine);
    const exitCode = this.scriptedExitCodes.shift() ?? 0;
    setTimeout(() => this.endEmitter.fire({ execution, exitCode }), 0);
    return execution;
  }

  onDidEndTaskProcess = this.endEmitter.event;
}

const fakeTasks = new FakeTasksApi();

const fakeVscode = {
  EventEmitter: FakeEventEmitter,
  Task: FakeTask,
  ShellExecution: FakeShellExecution,
  TaskRevealKind: { Always: 1, Silent: 2, Never: 3 },
  TaskPanelKind: { Shared: 1, Dedicated: 2, New: 3 },
  tasks: fakeTasks,
  Uri: {
    file: (path: string) => ({ fsPath: path, toString: () => `file://${path}` }),
  },
};

interface FakeWorkspaceFolder {
  readonly name: string;
  readonly uri: { fsPath: string; toString: () => string };
}

const fakeFolder: FakeWorkspaceFolder = {
  name: "demo",
  uri: { fsPath: "/tmp/demo", toString: () => "file:///tmp/demo" },
};

async function loadModule(): Promise<typeof import("../../../onboarding/install-task")> {
  const moduleWithLoad = Module as typeof Module & { _load: ModuleLoad };
  const originalLoad = moduleWithLoad._load;
  moduleWithLoad._load = (request, parent, isMain) => {
    if (request === "vscode") return fakeVscode;
    return originalLoad(request, parent, isMain);
  };
  try {
    return await import("../../../onboarding/install-task.js");
  } finally {
    moduleWithLoad._load = originalLoad;
  }
}

describe("VsCodeInstallTaskRunner", () => {
  beforeEach(() => {
    fakeTasks.invocations = [];
    fakeTasks.scriptedExitCodes = [];
    fakeTasks.endEmitter.dispose();
    fakeTasks.endEmitter = new FakeEventEmitter();
    (fakeVscode.tasks as FakeTasksApi).onDidEndTaskProcess = fakeTasks.endEmitter.event;
  });

  it("runs commands sequentially in order", async () => {
    const { VsCodeInstallTaskRunner } = await loadModule();
    const runner = new VsCodeInstallTaskRunner(fakeFolder as never, () => undefined);

    const result = await runner.runInstall(["uv init --python 3.13", "uv add x", "uv run y"]);

    assert.deepEqual(fakeTasks.invocations, ["uv init --python 3.13", "uv add x", "uv run y"]);
    assert.deepEqual(result, { ok: true, failedCommand: null, exitCode: 0 });
  });

  it("short-circuits on the first non-zero exit", async () => {
    const { VsCodeInstallTaskRunner } = await loadModule();
    const runner = new VsCodeInstallTaskRunner(fakeFolder as never, () => undefined);
    fakeTasks.scriptedExitCodes = [0, 5, 0];

    const result = await runner.runInstall(["a", "b", "c"]);

    assert.deepEqual(fakeTasks.invocations, ["a", "b"]);
    assert.deepEqual(result, { ok: false, failedCommand: "b", exitCode: 5 });
  });

  it("propagates a non-zero exit on a single command", async () => {
    const { VsCodeInstallTaskRunner } = await loadModule();
    const runner = new VsCodeInstallTaskRunner(fakeFolder as never, () => undefined);
    fakeTasks.scriptedExitCodes = [42];

    const result = await runner.runInstall(["uv add x"]);

    assert.equal(result.ok, false);
    assert.equal(result.failedCommand, "uv add x");
    assert.equal(result.exitCode, 42);
  });

  it("forwards the LSP-supplied command list verbatim with no editor-side rewriting", async () => {
    // The architecture pins the LSP as the single author of the install-command
    // list (core/onboarding/install_commands.py). Any rewriting on the editor
    // side would split the source of truth, so the runner must hand the
    // strings to the task API exactly as it received them.
    const { VsCodeInstallTaskRunner } = await loadModule();
    const runner = new VsCodeInstallTaskRunner(fakeFolder as never, () => undefined);

    const lspCommands = ["uv init --python 3.13", 'uv add "turbine-data[postgres]"', "uv run turbine init"];

    await runner.runInstall(lspCommands);

    assert.deepEqual(fakeTasks.invocations, lspCommands);
  });

  it("reports completion via ok=true so the caller can advance the phase", async () => {
    // The runner has no pyproject.toml watcher of its own. A successful run
    // (exit code 0 across every command) is the signal the caller relies on
    // to trigger phase recompute; the LSP-side WATCHER_PATTERNS picks up the
    // pyproject.toml that `uv init` writes out and re-emits the next
    // PhaseDto. This test pins the runner's half of that contract.
    const { VsCodeInstallTaskRunner } = await loadModule();
    const runner = new VsCodeInstallTaskRunner(fakeFolder as never, () => undefined);

    const result = await runner.runInstall(["uv init --python 3.13", 'uv add "turbine-data[postgres]"']);

    assert.equal(result.ok, true);
    assert.equal(result.failedCommand, null);
    assert.equal(result.exitCode, 0);
  });
});
