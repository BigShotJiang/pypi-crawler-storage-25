import { runTests } from "@vscode/test-electron";
import * as path from "node:path";

async function main(): Promise<void> {
  try {
    const extensionDevelopmentPath = path.resolve(__dirname, "..", "..");
    const extensionTestsPath = path.resolve(__dirname, "./suite/index");
    await runTests({ extensionDevelopmentPath, extensionTestsPath });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Failed to run tests: ${message}`);
    process.exit(1);
  }
}

void main();
