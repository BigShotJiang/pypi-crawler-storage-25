/**
 * Command handlers for inline execution — "Run Quality" and "Validate Contract".
 *
 * Each handler is wired to a code lens command. When triggered, it sends
 * the corresponding custom LSP request and renders results as inline
 * diagnostics in the editor.
 */

import { randomUUID } from "node:crypto";

import * as vscode from "vscode";
import type { LanguageClient } from "vscode-languageclient/node";
import { diagnosticRangeForCheckResult } from "./check-result-range";
import { TurbineClient } from "./client";
import { insertSnippetAtPosition } from "./editor-snippet";
import { showLspClientUnavailableMessage } from "./lsp-client-unavailable";
import type { CheckLogParams, CheckResultItem, RunCheckResult, ValidateSchemaResult } from "./types";

const checkDiagnostics = vscode.languages.createDiagnosticCollection("turbine-checks");
const resultsOutput = vscode.window.createOutputChannel("Turbine Check Results");
const executionGeneration = new Map<string, number>();

function nextGeneration(uri: string): number {
  const gen = (executionGeneration.get(uri) ?? 0) + 1;
  executionGeneration.set(uri, gen);
  return gen;
}

function isStale(uri: string, generation: number): boolean {
  return executionGeneration.get(uri) !== generation;
}

interface RunQualityArgs {
  uri: string;
  dataset?: string;
  checkName?: string;
}

function resolveRunQualityArgs(args: unknown[]): RunQualityArgs | undefined {
  // Schema-level code lens passes (contractId, schemaName); we honor the
  // schema name so the run scopes to that DatasetSpec. Other entry points
  // (context menu, keyboard shortcut, file-level lens) pass no schema and
  // run every schema in the file.
  const editor = vscode.window.activeTextEditor;
  const uri = editor?.document.uri.toString();
  if (!uri) return undefined;
  const dataset = typeof args[1] === "string" && args[1].length > 0 ? args[1] : undefined;
  const checkName = typeof args[2] === "string" && args[2].length > 0 ? args[2] : undefined;
  return { uri, dataset, checkName };
}

function outcomeToSeverity(outcome: string): vscode.DiagnosticSeverity {
  switch (outcome) {
    case "failed":
    case "errored":
      return vscode.DiagnosticSeverity.Error;
    case "warned":
      return vscode.DiagnosticSeverity.Warning;
    default:
      return vscode.DiagnosticSeverity.Information;
  }
}
let onExecutionComplete: (() => void) | null = null;
interface RunContext {
  client: TurbineClient;
  vsUri: vscode.Uri;
  uriString: string;
  datasource: string;
  dataset?: string;
  checkName?: string;
}

async function runQualityCheck(
  findClient: (uri: vscode.Uri) => LanguageClient | undefined,
  output: vscode.OutputChannel,
  ...args: unknown[]
): Promise<void> {
  const ctx = await prepareRun(findClient, output, args);
  if (!ctx) return;

  const generation = nextGeneration(ctx.uriString);
  checkDiagnostics.delete(ctx.vsUri);

  const workDoneToken = randomUUID();
  const logSubscription = ctx.client.onCheckLog((params) =>
    appendCheckLogForOperation(workDoneToken, params),
  );
  try {
    const result = await ctx.client.runCheck({
      uri: ctx.uriString,
      datasource: ctx.datasource,
      dataset: ctx.dataset,
      checkName: ctx.checkName,
      workDoneToken,
    });
    if (isStale(ctx.uriString, generation)) return;
    renderRunResult(ctx, result);
  } catch (error) {
    if (isStale(ctx.uriString, generation)) return;
    const message = error instanceof Error ? error.message : String(error);
    vscode.window.showErrorMessage(`Quality check failed: ${message}`);
  } finally {
    logSubscription.dispose();
  }
}

async function prepareRun(
  findClient: (uri: vscode.Uri) => LanguageClient | undefined,
  output: vscode.OutputChannel,
  args: unknown[],
): Promise<RunContext | undefined> {
  const resolved = resolveRunQualityArgs(args);
  if (!resolved) {
    vscode.window.showWarningMessage("No active contract file.");
    return undefined;
  }
  const vsUri = vscode.Uri.parse(resolved.uri);
  const lsp = findClient(vsUri);
  if (!lsp) {
    await showLspClientUnavailableMessage(output);
    return undefined;
  }
  const datasource = await pickDatasource(lsp, resolved.uri);
  if (datasource === undefined) return undefined;
  return {
    client: new TurbineClient(lsp),
    vsUri,
    uriString: resolved.uri,
    datasource,
    dataset: resolved.dataset,
    checkName: resolved.checkName,
  };
}

function renderRunResult(ctx: RunContext, result: RunCheckResult): void {
  if (result.error) {
    vscode.window.showErrorMessage(`Quality check failed: ${result.error}`);
    return;
  }
  checkDiagnostics.set(ctx.vsUri, buildDiagnostics(result.outcomes));
  onExecutionComplete?.();
  writeFailedRows(ctx.uriString, result.outcomes);
}

function buildDiagnostics(outcomes: CheckResultItem[]): vscode.Diagnostic[] {
  return outcomes.filter((item) => item.outcome !== "passed").map(toDiagnostic);
}

function toDiagnostic(item: CheckResultItem): vscode.Diagnostic {
  const suffix = item.isRowBased ? ` (${item.rowsFailed}/${item.rowsTested} rows failed)` : "";
  const sourceRange = diagnosticRangeForCheckResult(item);
  const range = new vscode.Range(
    sourceRange.startLine,
    sourceRange.startCharacter,
    sourceRange.endLine,
    sourceRange.endCharacter,
  );
  const diagnostic = new vscode.Diagnostic(
    range,
    `${item.checkName}: ${item.outcome}${suffix}`,
    outcomeToSeverity(item.outcome),
  );
  diagnostic.source = "turbine";
  return diagnostic;
}

function appendCheckLog(params: CheckLogParams): void {
  resultsOutput.appendLine(params.line);
  if (params.excerpt) {
    resultsOutput.appendLine(params.excerpt);
  }
}

function appendCheckLogForOperation(operationToken: string, params: CheckLogParams): void {
  if (params.operationToken !== operationToken) {
    return;
  }
  appendCheckLog(params);
}

function writeFailedRows(uri: string, outcomes: CheckResultItem[]): void {
  const failures = outcomes.filter((item) => item.outcome === "failed" || item.outcome === "errored");
  if (failures.length === 0) return;
  resultsOutput.appendLine(`\n── ${uri} ──`);
  for (const item of failures) {
    const detail = item.isRowBased ? `${item.rowsFailed}/${item.rowsTested} rows failed` : item.outcome;
    resultsOutput.appendLine(`  ${item.checkName}: ${detail}`);
    if (item.diagnostics) {
      for (const diagnosticLine of item.diagnostics) {
        resultsOutput.appendLine(`    ${diagnosticLine}`);
      }
    }
  }
  resultsOutput.show(true);
}

export async function pickDatasource(lsp: LanguageClient, uri: string): Promise<string | undefined> {
  const client = new TurbineClient(lsp);
  const result = await client.listDatasources({ uri });

  if (result.datasources.length === 0) {
    vscode.window.showWarningMessage(
      "No datasources configured. Add a datasource YAML to your datasources directory.",
    );
    return undefined;
  }

  if (result.datasources.length === 1) {
    return result.datasources[0].name;
  }

  const items = result.datasources.map((ds) => ({
    label: ds.name,
    description: ds.dsType,
  }));
  const picked = await vscode.window.showQuickPick(items, {
    placeHolder: "Select a datasource",
  });
  return picked?.label;
}

// ── Validate Contract command ──

async function validateContract(
  findClient: (uri: vscode.Uri) => LanguageClient | undefined,
  output: vscode.OutputChannel,
): Promise<void> {
  const editor = vscode.window.activeTextEditor;
  const uriString = editor?.document.uri.toString();
  if (!uriString) {
    vscode.window.showWarningMessage("No active contract file.");
    return;
  }

  const vsUri = vscode.Uri.parse(uriString);
  const lsp = findClient(vsUri);
  if (!lsp) {
    await showLspClientUnavailableMessage(output);
    return;
  }
  const client = new TurbineClient(lsp);

  // Pick datasource (URI-scoped so each workspace folder sees its own datasources)
  const datasource = await pickDatasource(lsp, uriString);
  if (datasource === undefined) return; // user cancelled

  const generation = nextGeneration(uriString);

  try {
    const result: ValidateSchemaResult = await vscode.window.withProgress(
      {
        location: vscode.ProgressLocation.Notification,
        title: `Validating against ${datasource}...`,
        cancellable: false,
      },
      () => client.validateSchema({ uri: uriString, datasource }),
    );
    if (isStale(uriString, generation)) return;

    onExecutionComplete?.();

    if (result.error) {
      vscode.window.showErrorMessage(result.error);
    } else if (result.hasDrift) {
      const driftCount = result.schemas.reduce((total, schema) => total + schema.columns.length, 0);
      const columnLabel = driftCount === 1 ? "column" : "columns";
      vscode.window.showWarningMessage(
        `Contract schema is out of sync: ${driftCount} ${columnLabel} drifted. See Problems panel for details.`,
      );
    } else {
      vscode.window.showInformationMessage("Contract schema is in sync.");
    }
  } catch (error) {
    if (isStale(uriString, generation)) return;
    const message = error instanceof Error ? error.message : String(error);
    vscode.window.showErrorMessage(`Contract validation failed: ${message}`);
  }
}

// ── Insert Snippet command ──
//
// Registered client-side (not forwarded to workspace/executeCommand) so we can
// use editor.insertSnippet(). That preserves the snippet's tab-stop
// interactivity — server-side workspace/applyEdit would flatten the template
// to plain text and lose every tab stop.

async function insertSnippet(...args: unknown[]): Promise<void> {
  const snippet = typeof args[0] === "string" ? args[0] : undefined;
  if (!snippet) {
    vscode.window.showErrorMessage("turbine.insertSnippet: missing snippet argument");
    return;
  }
  const editor = vscode.window.activeTextEditor;
  if (!editor) {
    vscode.window.showWarningMessage("No active editor.");
    return;
  }
  const fullRange = editor.document.validateRange(
    new vscode.Range(new vscode.Position(0, 0), new vscode.Position(editor.document.lineCount + 1, 0)),
  );
  await editor.edit((builder) => builder.delete(fullRange));
  await editor.insertSnippet(new vscode.SnippetString(snippet), new vscode.Position(0, 0));
}

// ── Insert Snippet At command ──
//
// Used by code-action quick fixes. The LSP code action returns a Command
// (not a WorkspaceEdit) so snippet tab stops survive — apply-edit would
// flatten ${1:placeholder} markers. Arguments come positional from the
// CodeAction.command.arguments wire shape.

async function insertSnippetAtCommand(...args: unknown[]): Promise<void> {
  const [uri, line, character, snippetText] = args;
  if (
    typeof uri !== "string" ||
    typeof line !== "number" ||
    typeof character !== "number" ||
    typeof snippetText !== "string"
  ) {
    vscode.window.showErrorMessage(
      "turbine.insertSnippetAt: expected (uri, line, character, snippetText)",
    );
    return;
  }
  const result = await insertSnippetAtPosition(uri, line, character, snippetText);
  if (!result.applied) {
    vscode.window.showWarningMessage(
      `Insert snippet failed: ${result.failureReason ?? "unknown reason"}`,
    );
  }
}

export function registerExecutionCommands(
  context: vscode.ExtensionContext,
  findClient: (uri: vscode.Uri) => LanguageClient | undefined,
  output: vscode.OutputChannel,
  refreshSidebar?: () => void,
): void {
  onExecutionComplete = refreshSidebar ?? null;
  context.subscriptions.push(
    vscode.commands.registerCommand("turbine.runQualityCheck", (...args: unknown[]) =>
      runQualityCheck(findClient, output, ...args),
    ),
    vscode.commands.registerCommand("turbine.validateContract", () => validateContract(findClient, output)),
    vscode.commands.registerCommand("turbine.runSingleCheck", (...args: unknown[]) =>
      runQualityCheck(findClient, output, ...args),
    ),
    vscode.commands.registerCommand("turbine.insertSnippet", insertSnippet),
    vscode.commands.registerCommand("turbine.insertSnippetAt", insertSnippetAtCommand),
    checkDiagnostics,
  );
}
