/**
 * VSCode Testing API integration for running individual quality checks.
 *
 * Discovers checks via the turbine/listChecks LSP request and provides green
 * play buttons in the gutter for each check definition.
 */

import * as vscode from "vscode";
import type { LanguageClient } from "vscode-languageclient/node";

import { TurbineClient } from "./client";
import { pickDatasource } from "./execution";
import { LSP_CLIENT_UNAVAILABLE_MESSAGE } from "./lsp-client-unavailable";
import type { CheckEntry, ListChecksResult } from "./types";

interface TurbineTestItemData {
  readonly uri: string;
  readonly dataset: string;
  readonly checkName: string;
}

interface TurbineDataCarrier {
  turbineData?: TurbineTestItemData;
}

/** Group check entries by schema name. */
function groupBySchema(checks: CheckEntry[]): Map<string, CheckEntry[]> {
  const groups = new Map<string, CheckEntry[]>();
  for (const check of checks) {
    const group = groups.get(check.schemaName) ?? [];
    group.push(check);
    groups.set(check.schemaName, group);
  }
  return groups;
}

export function registerTestController(
  context: vscode.ExtensionContext,
  findClient: (uri: vscode.Uri) => LanguageClient | undefined,
): void {
  const controller = vscode.tests.createTestController("turbine-checks", "Turbine Checks");
  context.subscriptions.push(controller);

  // ── Resolve handler: discover checks for a file via turbine/listChecks ──

  controller.resolveHandler = async (item) => {
    if (item) return; // only handle root-level resolve

    for (const doc of vscode.workspace.textDocuments) {
      if (doc.languageId === "yaml" || doc.uri.path.endsWith(".yml")) {
        await discoverChecksForFile(controller, doc.uri, findClient);
      }
    }
  };

  // ── Run profile ──

  const runProfile = controller.createRunProfile(
    "Run",
    vscode.TestRunProfileKind.Run,
    async (request, token) => {
      const run = controller.createTestRun(request);

      const items = request.include ?? gatherAllItems(controller);
      for (const item of items) {
        if (token.isCancellationRequested) break;

        for (const leaf of leafItemsFor(item)) {
          if (token.isCancellationRequested) break;
          await runSingleCheckItem(leaf, run, findClient);
        }
      }

      run.end();
    },
  );
  context.subscriptions.push(runProfile);

  // ── Re-discover on document change (debounced) ──

  let debounceTimer: ReturnType<typeof setTimeout> | undefined;
  context.subscriptions.push(
    vscode.workspace.onDidChangeTextDocument((event) => {
      const doc = event.document;
      if (doc.languageId !== "yaml" && !doc.uri.path.endsWith(".yml")) return;

      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(() => {
        discoverChecksForFile(controller, doc.uri, findClient);
      }, 500);
    }),
  );

  // ── Discover on file open ──

  context.subscriptions.push(
    vscode.workspace.onDidOpenTextDocument((doc) => {
      if (doc.languageId === "yaml" || doc.uri.path.endsWith(".yml")) {
        discoverChecksForFile(controller, doc.uri, findClient);
      }
    }),
  );
}

/** Discover checks for a single file via the turbine/listChecks request. */
async function discoverChecksForFile(
  controller: vscode.TestController,
  uri: vscode.Uri,
  findClient: (uri: vscode.Uri) => LanguageClient | undefined,
): Promise<void> {
  const lsp = findClient(uri);
  if (!lsp) return;
  const client = new TurbineClient(lsp);

  try {
    const result: ListChecksResult = await client.listChecks({ uri: uri.toString() });
    const checks = result.checks;

    if (checks.length === 0) {
      controller.items.delete(uri.toString());
      return;
    }

    const fileName = uri.path.split("/").pop() ?? uri.toString();
    const fileItem = controller.createTestItem(uri.toString(), fileName, uri);
    fileItem.canResolveChildren = false;

    for (const [schemaName, schemaChecks] of groupBySchema(checks)) {
      const schemaId = `${uri.toString()}::${schemaName}`;
      const schemaItem = controller.createTestItem(schemaId, schemaName, uri);

      for (const check of schemaChecks) {
        const checkId = `${uri.toString()}::${schemaName}::${check.checkName}`;
        const checkItem = controller.createTestItem(checkId, check.checkName, uri);
        checkItem.range = new vscode.Range(check.line - 1, 0, check.line - 1, 0);
        checkItem.tags = [new vscode.TestTag("turbine-check")];
        (checkItem as unknown as TurbineDataCarrier).turbineData = {
          uri: uri.toString(),
          dataset: schemaName,
          checkName: check.checkName,
        };
        schemaItem.children.add(checkItem);
      }

      fileItem.children.add(schemaItem);
    }

    controller.items.replace(
      [...controller.items].map(([, item]) => {
        return item.id === uri.toString() ? fileItem : item;
      }),
    );

    if (!controller.items.get(uri.toString())) {
      controller.items.add(fileItem);
    }
  } catch {
    // LSP not ready or file not a Turbine file -- silently skip
  }
}

/** Run a single check TestItem via the LSP. */
async function runSingleCheckItem(
  item: vscode.TestItem,
  run: vscode.TestRun,
  findClient: (uri: vscode.Uri) => LanguageClient | undefined,
): Promise<void> {
  const data = (item as unknown as TurbineDataCarrier).turbineData;

  if (!data) {
    run.skipped(item);
    return;
  }

  const vsUri = vscode.Uri.parse(data.uri);
  const lsp = findClient(vsUri);
  if (!lsp) {
    run.errored(
      item,
      new vscode.TestMessage(`${LSP_CLIENT_UNAVAILABLE_MESSAGE} Open the Turbine LSP output for details.`),
    );
    return;
  }
  const client = new TurbineClient(lsp);

  const datasource = await pickDatasource(lsp, data.uri);
  if (datasource === undefined) {
    run.skipped(item);
    return;
  }

  run.started(item);

  try {
    const result = await client.runCheck({
      uri: data.uri,
      datasource,
      dataset: data.dataset,
      checkName: data.checkName,
    });

    if (result.error) {
      run.errored(item, new vscode.TestMessage(result.error));
      return;
    }

    if (result.outcomes.length === 0) {
      run.skipped(item);
      return;
    }

    const outcome = result.outcomes[0];
    if (outcome.outcome === "passed") {
      run.passed(item);
    } else if (outcome.outcome === "failed") {
      const message = outcome.isRowBased
        ? `${outcome.rowsFailed}/${outcome.rowsTested} rows failed`
        : (outcome.diagnostics?.join("\n") ?? "check failed");
      run.failed(item, new vscode.TestMessage(message));
    } else {
      const detail = outcome.diagnostics?.join("\n") ?? `outcome: ${outcome.outcome}`;
      run.errored(item, new vscode.TestMessage(detail));
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    run.errored(item, new vscode.TestMessage(message));
  }
}

/** Gather all leaf TestItems from the controller. */
function gatherAllItems(controller: vscode.TestController): vscode.TestItem[] {
  const items: vscode.TestItem[] = [];
  controller.items.forEach((item) => {
    items.push(...leafItemsFor(item));
  });
  return items;
}

function leafItemsFor(item: vscode.TestItem): vscode.TestItem[] {
  if (item.children.size === 0) {
    return [item];
  }

  const leaves: vscode.TestItem[] = [];
  item.children.forEach((child) => {
    leaves.push(...leafItemsFor(child));
  });
  return leaves;
}
