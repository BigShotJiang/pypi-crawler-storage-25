import type { CheckResultItem } from "./types";

export interface DiagnosticRangeCoordinates {
  startLine: number;
  startCharacter: number;
  endLine: number;
  endCharacter: number;
}

const FALLBACK_RANGE: DiagnosticRangeCoordinates = {
  startLine: 0,
  startCharacter: 0,
  endLine: 0,
  endCharacter: 0,
};

type CheckResultItemWithRange = CheckResultItem & {
  startLine: number;
  startCol: number;
  endLine: number;
  endCol: number;
};

function hasResolvedSourceRange(item: CheckResultItem): item is CheckResultItemWithRange {
  return (
    item.startLine !== null &&
    item.startCol !== null &&
    item.endLine !== null &&
    item.endCol !== null &&
    item.startLine > 0 &&
    item.startCol > 0 &&
    item.endLine > 0 &&
    item.endCol > 0
  );
}

export function diagnosticRangeForCheckResult(item: CheckResultItem): DiagnosticRangeCoordinates {
  if (!hasResolvedSourceRange(item)) {
    return FALLBACK_RANGE;
  }

  return {
    startLine: item.startLine - 1,
    startCharacter: item.startCol - 1,
    endLine: item.endLine - 1,
    endCharacter: item.endCol - 1,
  };
}
