/**
 * TypeScript types mirroring the Turbine LSP extension protocol.
 *
 * Wire format uses camelCase. All types match
 * editors/protocol/turbine-lsp-extension.schema.json.
 */

// ── Enums (string literal unions) ──

export type CheckOutcome = "passed" | "failed" | "warned" | "skipped" | "errored";
export type DriftChangeKind =
  | "added"
  | "removed"
  | "type_changed"
  | "nullable_changed"
  | "pk_changed"
  | "unique_changed";
export type ReferenceKind = "quality_spec" | "field_reference";
export interface CheckResultItem {
  checkName: string;
  /** Server-derived: false for structural checks (schema). Hides row counts in display. */
  isRowBased: boolean;
  outcome: CheckOutcome;
  rowsTested: number;
  rowsFailed: number;
  /** Id of the contract this check belongs to. Empty when unknown. */
  contractId: string;
  /** Schema-qualified dataset this check ran against. Empty when unknown. */
  dataset: string;
  diagnostics?: string[];
  /** 1-indexed source range in the originating YAML. `null` when unresolved. */
  startLine: number | null;
  startCol: number | null;
  endLine: number | null;
  endCol: number | null;
}

export interface DriftColumn {
  name: string;
  change: DriftChangeKind;
  expectedType: string | null;
  actualType: string | null;
  /** 1-indexed source range in the contract YAML. `null` when unresolved. */
  startLine: number | null;
  startCol: number | null;
  endLine: number | null;
  endCol: number | null;
}

export interface SchemaDrift {
  schemaName: string;
  columns: DriftColumn[];
}

export interface ContractHealth {
  contractId: string;
  uri: string;
  errorCount: number;
  warningCount: number;
  checkStatus: CheckOutcome | null;
}

export interface ContractReference {
  sourceContractId: string;
  targetContractId: string;
  referenceType: ReferenceKind;
  sourceUri?: string | null;
  targetUri?: string | null;
}

// ── Request params ──

export interface RunCheckParams {
  uri: string;
  /** Datasource name; server falls back to the contract's default when omitted. */
  datasource?: string;
  /** When both ``dataset`` and ``checkName`` are set, only that check runs. */
  dataset?: string | null;
  checkName?: string | null;
  /** Run every contract in the project. The ``uri`` still anchors the project root. */
  all?: boolean;
  /** Client-supplied progress token. Server emits $/progress for this token. */
  workDoneToken?: string | number;
}

export interface ValidateSchemaParams {
  uri: string;
  datasource?: string;
}

// ── Request results ──

export interface RunCheckResult {
  contractId: string;
  outcomes: CheckResultItem[];
  passed: boolean;
  error?: string | null;
}

export interface ValidateSchemaResult {
  contractId: string;
  schemas: SchemaDrift[];
  hasDrift: boolean;
  error: string | null;
}

export interface OverviewDataResult {
  contracts: ContractHealth[];
}

export interface ReferencesDataResult {
  references: ContractReference[];
}

// ── Datasource discovery + connectivity ──

export interface DatasourceInfo {
  name: string;
  dsType: string;
  uri: string;
}

export interface ListDatasourcesParams {
  uri?: string | null;
}

export interface ListDatasourcesResult {
  datasources: DatasourceInfo[];
}

export interface TestDatasourceParams {
  name: string;
  uri: string;
}

export interface TestDatasourceResult {
  name: string;
  ok: boolean;
  latencyMs: number | null;
  error: string | null;
}

// ── Onboarding tours ──

export type StepSkipKind = "none" | "edit" | "run_check" | "run_introspection";
export type StepKind = "read" | "action";
export type StepContentBlockKind = "paragraph" | "callout" | "image";
export type CalloutTone = "info" | "tip" | "warning" | "error" | "success";
export type StepActionKind =
  | "none"
  | "open_all_contracts"
  | "open_add_check"
  | "run_validate"
  | "run_single_check"
  | "generate_api"
  | "start_api_server"
  | "open_data_swagger"
  | "open_management_swagger"
  | "run_sandbox_checks"
  | "open_dashboard"
  | "final_handoff";
export type HighlightTargetKind =
  | "contract_field"
  | "dataset"
  | "column_field"
  | "quality_spec_field"
  | "check"
  | "sql_text"
  | "source_text"
  | "source_range"
  | "ui_target"
  | "yaml_field";
export type ResolvedHighlightKind = "editor_range" | "ui_target";
export type HighlightRange = [number, number, number, number];
export type RangeKind = "key" | "value" | "block";

export interface BaseHighlightTarget {
  kind: HighlightTargetKind;
}

export interface FileHighlightTarget extends BaseHighlightTarget {
  file: string;
}

export interface HighlightTarget extends BaseHighlightTarget {
  file?: string;
  targetId?: string;
  startLine?: number;
  endLine?: number;
  startCol?: number;
  endCol?: number | null;
}

export interface ResolvedHighlight {
  kind: ResolvedHighlightKind;
  file: string | null;
  range: HighlightRange | null;
  targetId: string | null;
}

export interface StepAction {
  kind: StepActionKind;
  label: string;
  file?: string | null;
  dataset?: string | null;
  checkName?: string | null;
  checkType?: string | null;
  column?: string | null;
  datasource?: string | null;
  url?: string | null;
}

export interface ParagraphBlock {
  readonly kind: "paragraph";
  readonly markdown: string;
}

export interface CalloutBlock {
  readonly kind: "callout";
  readonly tone: CalloutTone;
  readonly markdown: string;
  readonly title: string | null;
}

export interface ImageBlock {
  readonly kind: "image";
  readonly assetPath: string;
  readonly alt: string;
  readonly captionMarkdown: string | null;
}

export type StepContentBlock = ParagraphBlock | CalloutBlock | ImageBlock;

export interface StepDto {
  id: string;
  title: string;
  content: readonly StepContentBlock[];
  target: HighlightTarget;
  resolvedTarget: ResolvedHighlight | null;
  kind: StepKind;
  action: StepAction | null;
  /** Skip discriminator for server-side skip/runStep actions. */
  skipKind: StepSkipKind;
  /** True when the Step has a server-side gating completion. The editor
   * keeps Next disabled until the LSP sends turbine/onboarding/stepCompleted. */
  gated: boolean;
}

export interface TourDto {
  id: string;
  title: string;
  steps: StepDto[];
}

export interface ListToursResult {
  tours: TourDto[];
}

export type ScaffoldVariant = "demo" | "bare";

export interface ScaffoldProjectParams {
  variant: ScaffoldVariant;
  database?: string | null;
}

export interface ScaffoldProjectResult {
  createdFiles: string[];
}

export interface CheckWorkspaceEmptyResult {
  empty: boolean;
  reasons: string[];
}

export interface WatchStepParams {
  tourId: string;
  stepId: string;
}

export interface StepCompletedParams {
  tourId: string;
  stepId: string;
}

export interface ActionInvokedParams {
  tourId: string;
  stepId: string;
  kind: StepActionKind;
}

export interface SurfaceVisibilityChangedParams {
  surfaceId: string;
  visible: boolean;
}

// ── Notification params ──

export interface CheckLogParams {
  uri: string;
  line: string;
  excerpt?: string | null;
  operationToken?: string | number | null;
}

export type TreeId = "workspace" | "datasources";

export type TreeIcon =
  | "pass"
  | "fail"
  | "warning"
  | "info"
  | "unknown"
  | "loading"
  | "diff_added"
  | "diff_removed"
  | "diff_modified"
  | "contract"
  | "reference"
  | "quality_spec"
  | "datasource"
  | "section_validation"
  | "section_references"
  | "section_quality_specs";

export type TreeCollapsibleState = "none" | "collapsed" | "expanded";

export interface OpenFileTreeCommand {
  kind: "openFile";
  uri: string;
  line: number | null;
  column: number | null;
}

export interface ShowReferencesTreeCommand {
  kind: "showReferences";
  anchorUri: string;
  anchorLine: number;
  anchorColumn: number;
  targetUris: string[];
}

export interface ExecuteTreeCommand {
  kind: "executeCommand";
  command: string;
  arguments: unknown[];
}

export type TreeCommand = OpenFileTreeCommand | ShowReferencesTreeCommand | ExecuteTreeCommand;

export interface TreeNode {
  id: string;
  label: string;
  icon: TreeIcon;
  collapsibleState: TreeCollapsibleState;
  description: string | null;
  tooltip: string | null;
  contextValue: string | null;
  resourceUri: string | null;
  command: TreeCommand | null;
  revealed?: boolean;
  dismiss?: DismissTarget | null;
}

export interface DismissTarget {
  uri: string;
  ruleId: string;
  /** Empty string for file-level findings (the wire layer only carries strings). */
  anchor: string;
}

export interface TreeNodesResult {
  nodes: TreeNode[];
}

export interface TreeGetRootParams {
  treeId: TreeId;
  contextUri?: string | null;
}

export interface TreeGetChildrenParams {
  treeId: TreeId;
  nodeId: string;
  contextUri?: string | null;
}

export interface TreeSubscribeParams {
  treeId: TreeId;
  contextUri?: string | null;
}

export interface TreeSubscribeResult {
  subscriptionId: string;
}

export interface TreeUnsubscribeParams {
  subscriptionId: string;
}

export interface TreeDidChangeParams {
  treeId: TreeId;
  invalidatedNodeIds: string[];
}

// ── Pick table (server-to-client request) ──

export interface PickTableParams {
  tables: Array<{ schema: string; table: string }>;
}

export type PickTablesResult = Array<{ schema: string; table: string }> | null;

// ── Input text (server-to-client request) ──

export interface InputTextParams {
  message: string;
  placeholder?: string;
}

export type InputTextResult = string | null;

// ── Server-initiated notifications ──

/** Notification params for turbine/workspaceConfig (server → client). */
export interface WorkspaceConfigParams {
  root: string;
  contractsDir: string;
  qualityDir: string;
  checksDir: string;
  datasourcesDir: string;
}

export type FileKind = "DataContract" | "QualitySpec" | "Datasource";

/** Notification params for turbine/fileContext (server → client). */
export interface FileContextParams {
  uri: string;
  isTurbineFile: boolean;
  fileKind: FileKind | null;
}

/** A single check entry returned by turbine/listChecks. */
export interface CheckEntry {
  checkName: string;
  schemaName: string;
  line: number;
}

/** Result for turbine/listChecks. */
export interface ListChecksResult {
  checks: CheckEntry[];
}
