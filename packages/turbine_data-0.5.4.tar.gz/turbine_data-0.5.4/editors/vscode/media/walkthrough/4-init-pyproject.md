# Initialize a Python project

Turbine installs into a Python project, which means your folder needs
a `pyproject.toml`. If you already have one, this step is already
ticked.

If not, the Turbine sidebar can run `uv init --python 3.13` for you.
Open the sidebar via the button above and click the **Initialize
Python project** action.
