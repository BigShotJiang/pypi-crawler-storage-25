# Install uv

Turbine is a Python package, and **uv** is the tool that runs it. uv
manages Python versions, virtual environments, and packages from a
single command. Turbine relies on uv being on your PATH.

If you already have uv installed, this step is already ticked.

If not, the Turbine sidebar will guide you through installing it. Open
the sidebar via the button above — the **Onboarding** panel shows the
install command for your platform and a link to the uv documentation.
