# Open a folder

Turbine reads contracts and quality results from a project folder. It
needs one open before it can do anything useful.

If you already have the folder open, this step is already ticked. If
not, open the folder you want to work in — Turbine will start picking
up files automatically.
