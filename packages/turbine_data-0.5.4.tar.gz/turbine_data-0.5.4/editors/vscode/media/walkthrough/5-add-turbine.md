# Add Turbine

Turbine ships extras for the database backend you use — Postgres,
Snowflake, DuckDB, or LSP-only (no database). Pick one, and Turbine
installs the matching packages plus the language server.

Open the Turbine sidebar via the button above. The **Onboarding**
panel shows a picker with one card per backend. Pick the one that
matches your project; Turbine runs `uv add` for you and starts the
language server.
