# Find Turbine in the sidebar

Turbine lives in the activity bar on the left, next to the file
explorer. The Turbine icon opens a sidebar with three sections:

- **All Contracts** — every Turbine contract in your workspace.
- **Datasources** — connections Turbine knows about.
- **Onboarding** — the panel that tracks setup and runs the tour.

Open the sidebar once so you know where to come back to. Every other
step in this walkthrough hands off to the **Onboarding** panel, which
shows the next action based on the current state of your project.
