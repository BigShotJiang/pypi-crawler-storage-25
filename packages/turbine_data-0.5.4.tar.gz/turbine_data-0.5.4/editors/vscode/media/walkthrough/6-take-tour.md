# Take the tour

The **Foundations** tour walks through a small example contract and
shows what Turbine does to it: schema validation, quality checks, and
where to look when something fails. The tour scaffolds its demo files
at your workspace root; if you already have Turbine content there, the
panel prompts you to pick an empty folder so your real work stays
untouched.

Open the Turbine sidebar via the button above. The **Onboarding**
panel lists available tours and the steps you've already finished. The
walkthrough ticks this step once you complete a tour.
