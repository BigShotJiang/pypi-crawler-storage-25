package com.turbine.lsp4ij

import com.intellij.openapi.project.Project
import com.intellij.openapi.vfs.VirtualFile
import com.redhat.devtools.lsp4ij.AbstractDocumentMatcher

class TurbineDocumentMatcher : AbstractDocumentMatcher() {

    private val turbineDirectories = listOf(
        "/contracts/",
        "/datacontracts/",
        "/quality/",
        "/checks/",
        "/datasources/",
    )

    override fun match(file: VirtualFile, project: Project): Boolean {
        val path = file.path
        return turbineDirectories.any { path.contains(it) }
    }
}
