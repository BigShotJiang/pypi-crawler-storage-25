package com.turbine.lsp4ij

import com.intellij.execution.configurations.GeneralCommandLine
import com.intellij.openapi.project.Project
import com.redhat.devtools.lsp4ij.server.OSProcessStreamConnectionProvider

class TurbineLanguageServer(project: Project) : OSProcessStreamConnectionProvider() {
    init {
        commandLine = GeneralCommandLine("uv", "run", "turbine-lsp")
            .withWorkDirectory(project.basePath)
    }
}
