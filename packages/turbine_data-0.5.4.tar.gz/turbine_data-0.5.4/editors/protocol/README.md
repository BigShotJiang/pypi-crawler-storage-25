# Turbine LSP Extension Protocol

Custom LSP methods for IDE extensions to communicate with the Turbine language server.

## Capability Negotiation

The server advertises supported custom methods in the `initialize` response:

```json
{
  "capabilities": {
    "experimental": {
      "turbineCapabilities": {
        "runCheck": true,
        "validateSchema": true,
        ...
      }
    }
  }
}
```

Clients check `capabilities.experimental?.turbineCapabilities?.methodName` before
sending custom requests. This follows the standard LSP capability negotiation pattern.

## Methods

### Requests (client to server)

| Method | Purpose |
|--------|---------|
| `turbine/runCheck` | Execute quality checks on a contract |
| `turbine/validateSchema` | Run schema validation against the database |
| `turbine/overviewData` | Fetch contract list with health status |
| `turbine/qualityData` | Fetch check results and scores |
| `turbine/driftData` | Fetch validation status across contracts |
| `turbine/referencesData` | Fetch cross-contract reference graph |
| `turbine/onboardingStatus` | Check project setup state |
| `turbine/scaffoldProject` | Create initial directory structure |

### Notifications

| Method | Direction | Purpose |
|--------|-----------|---------|
| `turbine/checkLog` | server to client | Persistent per-check run output |
| `turbine/telemetryEvent` | client to server | UI interaction metrics |

## Schema

The full type definitions are in `turbine-lsp-extension.schema.json`.
Python types are in `turbine.core.analysis.protocol`.

## Wire Format

All custom methods use JSON-RPC 2.0 over the LSP transport. Property names
use camelCase on the wire (matching LSP convention) and snake_case in the
Python dataclasses.
