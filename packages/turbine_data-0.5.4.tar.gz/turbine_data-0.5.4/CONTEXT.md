# Turbine

Turbine helps teams define dataset expectations and run quality checks against data products.

## Language

**Data Contract**:
A data product owner's enforceable promise about a dataset's schema, ownership, and core quality expectations. Serialised as a conformant ODCS document so it round-trips through the wider ecosystem (see [ADR-0002](docs/adr/0002-turbine-quality-checks-serialise-as-odcs-custom-checks.md)).
_Avoid_: contract file, YAML contract when discussing the domain concept

**Turbine Engine**:
The named quality engine that owns the execution semantics of a Check Definition inside a published contract. Other tools see that a check exists; only the Turbine Engine interprets how it runs.
_Avoid_: turbine runner, custom check engine — `Turbine Engine` is the canonical term

**Quality Spec**:
A team's observability-focused set of checks against a dataset covered by a Data Contract.
_Avoid_: secondary contract, monitoring file

**Check Definition**:
A single configured quality check with its own identity, threshold, dimension, and execution settings.
_Avoid_: check template, SQL file

**Check Name**:
The stable identity of a Check Definition in results, dashboards, flags, and history.
_Avoid_: filename, path

**SQL Check Template**:
A reusable SQL query template that one or more Check Definitions can run with their own parameters.
_Avoid_: SQL check, check name

**SLA Property**:
A producer's promise about *service* the data delivers — when it's fresh, how long it's retained, when the dataset reaches end-of-life. Drawn from the Data QoS periodic table (see [ADR-0001](docs/adr/0001-sla-properties-adhere-to-data-qos.md)). Distinct from a Data Quality Dimension, which is about the *content* of the data.
_Avoid_: SLA, service level, contract promise — `SLA Property` is the canonical term

**Data Quality Dimension**:
The aspect of data *content* that a Check Definition measures. Turbine uses five: **Accuracy**, **Completeness**, **Consistency**, **Timeliness**, **Validity**. Carried by a Check Definition's `dimension:` field. Distinct from an SLA Property, which is about *service*, not content.
_Avoid_: data quality, DQ dimension when the audience won't recognise the term; "uniqueness" and "conformity" are not Turbine dimensions — uniqueness rolls up under Consistency, conformity under Validity

## Relationships

- A **Data Contract** can contain zero or more **Check Definitions**.
- A **Quality Spec** targets exactly one **Data Contract** and contains zero or more **Check Definitions**.
- A **Check Definition** has exactly one **Check Name**.
- A **Check Definition** carries exactly one **Data Quality Dimension**.
- A **Check Definition** is carried in a **Data Contract** as an ODCS custom check executed by the **Turbine Engine**.
- A **Check Definition** can reference at most one **SQL Check Template**.
- A **SQL Check Template** can be reused by many **Check Definitions**.
- A **Data Contract** can carry zero or more **SLA Properties**.
- An **SLA Property** may derive a **Check Definition** (e.g. `freshness`, `latency`, `retention`) or stay metadata-only (e.g. `endOfLife`).

## Example dialogue

> **Dev:** "If two teams use the same SQL rule, do they share the same Check Name?"
> **Domain expert:** "No — they share the SQL Check Template, but each use is a separate Check Definition with its own Check Name, threshold, and parameters."

## Flagged ambiguities

- "SQL check" was used to mean both the YAML check entry and the `.sql` file — resolved: the YAML entry is a **Check Definition**; the reusable `.sql` file is a **SQL Check Template**.
- ODCS offers both a native `sql` check type and a `custom` check type — resolved: Turbine always serialises a **Check Definition** as an ODCS `custom` check run by the **Turbine Engine**, never as native ODCS `sql`/`library` ([ADR-0002](docs/adr/0002-turbine-quality-checks-serialise-as-odcs-custom-checks.md)).
