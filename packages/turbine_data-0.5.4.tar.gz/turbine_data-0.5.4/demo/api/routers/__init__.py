from .customer_router import router as customer_router
from .daily_aggregate_router import router as daily_aggregate_router
from .energy_reading_router import router as energy_reading_router
from .inventory_router import router as inventory_router
from .meter_router import router as meter_router
from .order_router import router as order_router
from .payment_router import router as payment_router
from .product_router import router as product_router
from .reading_router import router as reading_router
from .READINGS_router import router as READINGS_router
from .sensor_router import router as sensor_router

routers = [
    READINGS_router,
    customer_router,
    daily_aggregate_router,
    energy_reading_router,
    inventory_router,
    meter_router,
    order_router,
    payment_router,
    product_router,
    reading_router,
    sensor_router,
]
