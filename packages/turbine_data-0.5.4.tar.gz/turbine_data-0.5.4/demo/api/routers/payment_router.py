from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import add_pagination
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal, UseParamsFields
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy.orm import Session

from turbine.adapters.api.dependencies import get_session

from ..models.payment import Payment, PaymentFilter, PaymentSchema

CursorPageNoTotal = CustomizedPage[
    CursorPage, UseIncludeTotal(False), UseParamsFields(size=Query(50, ge=1, le=50000))
]
router = APIRouter(prefix="/payments")


@router.get("/payments")
def list_payments(session: Annotated[Session, Depends(get_session)]) -> CursorPageNoTotal[PaymentSchema]:
    return paginate(session, Payment.list_query())


@router.get("/payments/{payment_id}", responses={404: {"description": "Payment not found"}})
def get_payment(payment_id: int, session: Annotated[Session, Depends(get_session)]) -> PaymentSchema:
    return Payment.get_or_404(session, payment_id)


add_pagination(router)
