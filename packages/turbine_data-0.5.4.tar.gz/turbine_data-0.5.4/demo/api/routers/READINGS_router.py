from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import add_pagination
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal, UseParamsFields
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy.orm import Session

from turbine.adapters.api.dependencies import get_session

from ..models.READINGS import Readings, ReadingsFilter, ReadingsSchema

CursorPageNoTotal = CustomizedPage[
    CursorPage, UseIncludeTotal(False), UseParamsFields(size=Query(50, ge=1, le=50000))
]
router = APIRouter(prefix="/READINGS")


@router.get("/READINGS")
def list_READINGS(
    session: Annotated[Session, Depends(get_session)],
) -> CursorPageNoTotal[ReadingsSchema]:
    return paginate(session, Readings.list_query())


@router.get("/READINGS/{ID}", responses={404: {"description": "Readings not found"}})
def get_READINGS(ID: int, session: Annotated[Session, Depends(get_session)]) -> ReadingsSchema:
    return Readings.get_or_404(session, ID)


add_pagination(router)
