from datetime import date
from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import add_pagination
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal, UseParamsFields
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy.orm import Session

from turbine.adapters.api.dependencies import get_session

from ..models.daily_aggregate import DailyAggregate, DailyAggregateFilter, DailyAggregateSchema

CursorPageNoTotal = CustomizedPage[
    CursorPage, UseIncludeTotal(False), UseParamsFields(size=Query(50, ge=1, le=50000))
]
router = APIRouter(prefix="/daily_aggregate")


@router.get("/daily_aggregate")
def list_daily_aggregate(
    session: Annotated[Session, Depends(get_session)],
) -> CursorPageNoTotal[DailyAggregateSchema]:
    return paginate(session, DailyAggregate.list_query())


@router.get(
    "/daily_aggregate/{meter_id}/{aggregation_date}",
    responses={404: {"description": "DailyAggregate not found"}},
)
def get_daily_aggregate(
    meter_id: str, aggregation_date: date, session: Annotated[Session, Depends(get_session)]
) -> DailyAggregateSchema:
    return DailyAggregate.get_or_404(session, (meter_id, aggregation_date))


add_pagination(router)
