from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import add_pagination
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal, UseParamsFields
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy.orm import Session

from turbine.adapters.api.dependencies import get_session

from ..models.customer import Customer, CustomerFilter, CustomerSchema

CursorPageNoTotal = CustomizedPage[
    CursorPage, UseIncludeTotal(False), UseParamsFields(size=Query(50, ge=1, le=50000))
]
router = APIRouter(prefix="/customer")


@router.get("/customer")
def list_customer(
    session: Annotated[Session, Depends(get_session)],
) -> CursorPageNoTotal[CustomerSchema]:
    return paginate(session, Customer.list_query())


@router.get("/customer/{customer_id}", responses={404: {"description": "Customer not found"}})
def get_customer(customer_id: str, session: Annotated[Session, Depends(get_session)]) -> CustomerSchema:
    return Customer.get_or_404(session, customer_id)


add_pagination(router)
