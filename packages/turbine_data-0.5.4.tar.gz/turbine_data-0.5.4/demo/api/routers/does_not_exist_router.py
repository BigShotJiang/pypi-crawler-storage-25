from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import add_pagination
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal, UseParamsFields
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlmodel import Session

from turbine.adapters.api.dependencies import get_session

from ..models.does_not_exist import DoesNotExist, DoesNotExistFilter

CursorPageNoTotal = CustomizedPage[
    CursorPage, UseIncludeTotal(False), UseParamsFields(size=Query(50, ge=1, le=50000))
]
router = APIRouter(prefix="/does_not_exist")


@router.get("/does_not_exist")
def list_does_not_exist(
    session: Annotated[Session, Depends(get_session)],
) -> CursorPageNoTotal[DoesNotExist]:
    return paginate(session, DoesNotExist.list_query())


add_pagination(router)
