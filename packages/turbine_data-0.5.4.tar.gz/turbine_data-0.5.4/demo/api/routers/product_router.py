from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import add_pagination
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal, UseParamsFields
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy.orm import Session

from turbine.adapters.api.dependencies import get_session

from ..models.product import Product, ProductFilter, ProductSchema

CursorPageNoTotal = CustomizedPage[
    CursorPage, UseIncludeTotal(False), UseParamsFields(size=Query(50, ge=1, le=50000))
]
router = APIRouter(prefix="/products")


@router.get("/products")
def list_products(session: Annotated[Session, Depends(get_session)]) -> CursorPageNoTotal[ProductSchema]:
    return paginate(session, Product.list_query())


@router.get("/products/{product_id}", responses={404: {"description": "Product not found"}})
def get_product(product_id: int, session: Annotated[Session, Depends(get_session)]) -> ProductSchema:
    return Product.get_or_404(session, product_id)


add_pagination(router)
