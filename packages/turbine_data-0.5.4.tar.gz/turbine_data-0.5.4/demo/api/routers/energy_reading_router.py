from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import add_pagination
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal, UseParamsFields
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy.orm import Session

from turbine.adapters.api.dependencies import get_session

from ..models.energy_reading import EnergyReading, EnergyReadingFilter, EnergyReadingSchema

CursorPageNoTotal = CustomizedPage[
    CursorPage, UseIncludeTotal(False), UseParamsFields(size=Query(50, ge=1, le=50000))
]
router = APIRouter(prefix="/energy_readings")


@router.get("/energy_readings")
def list_energy_readings(
    session: Annotated[Session, Depends(get_session)],
) -> CursorPageNoTotal[EnergyReadingSchema]:
    return paginate(session, EnergyReading.list_query())


@router.get(
    "/energy_readings/{energy_reading_id}", responses={404: {"description": "EnergyReading not found"}}
)
def get_energy_reading(
    energy_reading_id: int, session: Annotated[Session, Depends(get_session)]
) -> EnergyReadingSchema:
    return EnergyReading.get_or_404(session, energy_reading_id)


add_pagination(router)
