from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import add_pagination
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal, UseParamsFields
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy.orm import Session

from turbine.adapters.api.dependencies import get_session

from ..models.order import Order, OrderFilter, OrderSchema

CursorPageNoTotal = CustomizedPage[
    CursorPage, UseIncludeTotal(False), UseParamsFields(size=Query(50, ge=1, le=50000))
]
router = APIRouter(prefix="/orders")


@router.get("/orders")
def list_orders(session: Annotated[Session, Depends(get_session)]) -> CursorPageNoTotal[OrderSchema]:
    return paginate(session, Order.list_query())


@router.get("/orders/{order_id}", responses={404: {"description": "Order not found"}})
def get_order(order_id: int, session: Annotated[Session, Depends(get_session)]) -> OrderSchema:
    return Order.get_or_404(session, order_id)


add_pagination(router)
