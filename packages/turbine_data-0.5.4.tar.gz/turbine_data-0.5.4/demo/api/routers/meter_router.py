from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import add_pagination
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal, UseParamsFields
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy.orm import Session

from turbine.adapters.api.dependencies import get_session

from ..models.meter import Meter, MeterFilter, MeterSchema

CursorPageNoTotal = CustomizedPage[
    CursorPage, UseIncludeTotal(False), UseParamsFields(size=Query(50, ge=1, le=50000))
]
router = APIRouter(prefix="/meters")


@router.get("/meters")
def list_meters(session: Annotated[Session, Depends(get_session)]) -> CursorPageNoTotal[MeterSchema]:
    return paginate(session, Meter.list_query())


@router.get("/meters/{meter_id}", responses={404: {"description": "Meter not found"}})
def get_meter(meter_id: int, session: Annotated[Session, Depends(get_session)]) -> MeterSchema:
    return Meter.get_or_404(session, meter_id)


add_pagination(router)
