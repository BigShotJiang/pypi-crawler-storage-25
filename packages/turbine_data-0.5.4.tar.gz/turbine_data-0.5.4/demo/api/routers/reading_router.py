from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import add_pagination
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal, UseParamsFields
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy.orm import Session

from turbine.adapters.api.dependencies import get_session

from ..models.reading import Reading, ReadingFilter, ReadingSchema

CursorPageNoTotal = CustomizedPage[
    CursorPage, UseIncludeTotal(False), UseParamsFields(size=Query(50, ge=1, le=50000))
]
router = APIRouter(prefix="/reading")


@router.get("/reading")
def list_reading(session: Annotated[Session, Depends(get_session)]) -> CursorPageNoTotal[ReadingSchema]:
    return paginate(session, Reading.list_query())


@router.get("/reading/{reading_id}", responses={404: {"description": "Reading not found"}})
def get_reading(reading_id: str, session: Annotated[Session, Depends(get_session)]) -> ReadingSchema:
    return Reading.get_or_404(session, reading_id)


add_pagination(router)
