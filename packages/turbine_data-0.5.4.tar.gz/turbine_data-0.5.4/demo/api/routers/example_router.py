from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import add_pagination
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal, UseParamsFields
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlmodel import Session

from turbine.adapters.api.dependencies import get_session

from ..models.example import Example, ExampleFilter

CursorPageNoTotal = CustomizedPage[
    CursorPage, UseIncludeTotal(False), UseParamsFields(size=Query(50, ge=1, le=50000))
]
router = APIRouter(prefix="/example")


@router.get("/example")
def list_example(session: Annotated[Session, Depends(get_session)]) -> CursorPageNoTotal[Example]:
    return paginate(session, Example.list_query())


@router.get("/example/{example_id}", responses={404: {"description": "Example not found"}})
def get_example(example_id: int, session: Annotated[Session, Depends(get_session)]) -> Example:
    return Example.get_or_404(session, example_id)


add_pagination(router)
