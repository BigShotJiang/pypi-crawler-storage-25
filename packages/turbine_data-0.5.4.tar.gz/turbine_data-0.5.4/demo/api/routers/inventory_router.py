from typing import Annotated

from fastapi import APIRouter, Depends, Query
from fastapi_pagination import add_pagination
from fastapi_pagination.cursor import CursorPage
from fastapi_pagination.customization import CustomizedPage, UseIncludeTotal, UseParamsFields
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy.orm import Session

from turbine.adapters.api.dependencies import get_session

from ..models.inventory import Inventory, InventoryFilter, InventorySchema

CursorPageNoTotal = CustomizedPage[
    CursorPage, UseIncludeTotal(False), UseParamsFields(size=Query(50, ge=1, le=50000))
]
router = APIRouter(prefix="/inventory")


@router.get("/inventory")
def list_inventory(
    session: Annotated[Session, Depends(get_session)],
) -> CursorPageNoTotal[InventorySchema]:
    return paginate(session, Inventory.list_query())


@router.get("/inventory/{item_id}", responses={404: {"description": "Inventory not found"}})
def get_inventory(item_id: int, session: Annotated[Session, Depends(get_session)]) -> InventorySchema:
    return Inventory.get_or_404(session, item_id)


add_pagination(router)
