from datetime import datetime
from typing import ClassVar

from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Mapped, mapped_column

from turbine.adapters.api.models.abstract_model import AbstractModel


class ReadingsFilter(BaseModel):
    ID: int | None = None
    METER_ID: str | None = None
    RECORDED_AT: datetime | None = None
    ENERGY_KWH: float | None = None
    VOLTAGE_V: float | None = None
    STATUS: str | None = None


class Readings(AbstractModel[ReadingsFilter, int]):
    __tablename__: ClassVar[str] = "READINGS"
    __schema__: ClassVar[str] = "E2E_DSL"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "E2E_DSL"}
    __contract_id__: ClassVar[str] = "e2e-dsl-test-sf"
    __id_field__: ClassVar[str] = "ID"
    ID: Mapped[int] = mapped_column(primary_key=True)
    METER_ID: Mapped[str] = mapped_column()
    RECORDED_AT: Mapped[datetime] = mapped_column()
    ENERGY_KWH: Mapped[float | None] = mapped_column(default=None)
    VOLTAGE_V: Mapped[float | None] = mapped_column(default=None)
    STATUS: Mapped[str] = mapped_column()


class ReadingsSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    ID: int
    METER_ID: str
    RECORDED_AT: datetime
    ENERGY_KWH: float | None = None
    VOLTAGE_V: float | None = None
    STATUS: str
