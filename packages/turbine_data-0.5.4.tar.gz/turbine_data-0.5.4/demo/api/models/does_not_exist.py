from typing import ClassVar

from pydantic import BaseModel
from sqlmodel import SQLModel

from turbine.adapters.api.models.abstract_model import AbstractModel


class DoesNotExistFilter(BaseModel):
    id: int | None = None


class DoesNotExist(AbstractModel[DoesNotExistFilter, int], table=True):
    __tablename__: str = "does_not_exist"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "public"}
    __implicit_pk__ = True
    id: int | None = None
