from datetime import datetime
from typing import ClassVar

from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Mapped, mapped_column

from turbine.adapters.api.models.abstract_model import AbstractModel


class OrderFilter(BaseModel):
    order_id: int | None = None
    customer: str | None = None
    amount: float | None = None
    status: str | None = None
    created_at: datetime | None = None


class Order(AbstractModel[OrderFilter, int]):
    __tablename__: ClassVar[str] = "orders"
    __schema__: ClassVar[str] = "e2e_py"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "e2e_py"}
    __contract_id__: ClassVar[str] = "py-test"
    __id_field__: ClassVar[str] = "order_id"
    order_id: Mapped[int] = mapped_column(primary_key=True)
    customer: Mapped[str] = mapped_column()
    amount: Mapped[float] = mapped_column()
    status: Mapped[str] = mapped_column()
    created_at: Mapped[datetime] = mapped_column()


class OrderSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    order_id: int
    customer: str
    amount: float
    status: str
    created_at: datetime
