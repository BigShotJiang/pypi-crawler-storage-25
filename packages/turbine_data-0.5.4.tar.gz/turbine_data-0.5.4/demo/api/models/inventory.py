from datetime import datetime
from typing import ClassVar

from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Mapped, mapped_column

from turbine.adapters.api.models.abstract_model import AbstractModel


class InventoryFilter(BaseModel):
    item_id: int | None = None
    name: str | None = None
    category: str | None = None
    price: float | None = None
    quantity: int | None = None
    updated_at: datetime | None = None


class Inventory(AbstractModel[InventoryFilter, int]):
    __tablename__: ClassVar[str] = "inventory"
    __schema__: ClassVar[str] = "e2e_allsoda"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "e2e_allsoda"}
    __contract_id__: ClassVar[str] = "allsoda-test"
    __id_field__: ClassVar[str] = "item_id"
    item_id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column()
    category: Mapped[str] = mapped_column()
    price: Mapped[float] = mapped_column()
    quantity: Mapped[int] = mapped_column()
    updated_at: Mapped[datetime] = mapped_column()


class InventorySchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    item_id: int
    name: str
    category: str
    price: float
    quantity: int
    updated_at: datetime
