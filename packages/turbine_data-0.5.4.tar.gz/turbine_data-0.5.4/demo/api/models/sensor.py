from typing import ClassVar

from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Mapped, mapped_column

from turbine.adapters.api.models.abstract_model import AbstractModel


class SensorFilter(BaseModel):
    id: int | None = None
    name: str | None = None
    value: float | None = None
    missing_col: str | None = None


class Sensor(AbstractModel[SensorFilter, int]):
    __tablename__: ClassVar[str] = "sensors"
    __schema__: ClassVar[str] = "public"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "public"}
    __contract_id__: ClassVar[str] = "drift-test"
    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column()
    value: Mapped[float | None] = mapped_column(default=None)
    missing_col: Mapped[str | None] = mapped_column(default=None)


class SensorSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    value: float | None = None
    missing_col: str | None = None
