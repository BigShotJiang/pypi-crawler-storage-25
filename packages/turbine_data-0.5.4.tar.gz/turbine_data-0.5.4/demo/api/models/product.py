from datetime import datetime
from typing import ClassVar

from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Mapped, mapped_column

from turbine.adapters.api.models.abstract_model import AbstractModel


class ProductFilter(BaseModel):
    product_id: int | None = None
    name: str | None = None
    price: float | None = None
    category: str | None = None
    updated_at: datetime | None = None


class Product(AbstractModel[ProductFilter, int]):
    __tablename__: ClassVar[str] = "products"
    __schema__: ClassVar[str] = "e2e_soda"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "e2e_soda"}
    __contract_id__: ClassVar[str] = "soda-test"
    __id_field__: ClassVar[str] = "product_id"
    product_id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column()
    price: Mapped[float] = mapped_column()
    category: Mapped[str] = mapped_column()
    updated_at: Mapped[datetime] = mapped_column()


class ProductSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    product_id: int
    name: str
    price: float
    category: str
    updated_at: datetime
