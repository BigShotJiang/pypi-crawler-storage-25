from datetime import datetime
from typing import ClassVar

from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Mapped, mapped_column

from turbine.adapters.api.models.abstract_model import AbstractModel


class PaymentFilter(BaseModel):
    payment_id: int | None = None
    order_id: int | None = None
    amount: float | None = None
    method: str | None = None
    status: str | None = None
    processed_at: datetime | None = None


class Payment(AbstractModel[PaymentFilter, int]):
    __tablename__: ClassVar[str] = "payments"
    __schema__: ClassVar[str] = "ecommerce"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "ecommerce"}
    __contract_id__: ClassVar[str] = "ecommerce"
    __id_field__: ClassVar[str] = "payment_id"
    payment_id: Mapped[int] = mapped_column(primary_key=True)
    order_id: Mapped[int] = mapped_column()
    amount: Mapped[float] = mapped_column()
    method: Mapped[str] = mapped_column()
    status: Mapped[str] = mapped_column()
    processed_at: Mapped[datetime] = mapped_column()


class PaymentSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    payment_id: int
    order_id: int
    amount: float
    method: str
    status: str
    processed_at: datetime
