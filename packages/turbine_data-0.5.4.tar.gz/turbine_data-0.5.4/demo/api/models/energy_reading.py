from datetime import datetime
from typing import ClassVar

from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Mapped, mapped_column

from turbine.adapters.api.models.abstract_model import AbstractModel


class EnergyReadingFilter(BaseModel):
    id: int | None = None
    meter_id: str | None = None
    recorded_at: datetime | None = None
    energy_kwh: float | None = None
    power_kw: float | None = None
    voltage_v: float | None = None
    quality_flag: int | None = None


class EnergyReading(AbstractModel[EnergyReadingFilter, int]):
    __tablename__: ClassVar[str] = "energy_readings"
    __schema__: ClassVar[str] = "public"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "public"}
    __contract_id__: ClassVar[str] = "energy-clean"
    id: Mapped[int] = mapped_column(primary_key=True)
    meter_id: Mapped[str] = mapped_column()
    recorded_at: Mapped[datetime] = mapped_column()
    energy_kwh: Mapped[float] = mapped_column()
    power_kw: Mapped[float | None] = mapped_column(default=None)
    voltage_v: Mapped[float | None] = mapped_column(default=None)
    quality_flag: Mapped[int] = mapped_column()


class EnergyReadingSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    meter_id: str
    recorded_at: datetime
    energy_kwh: float
    power_kw: float | None = None
    voltage_v: float | None = None
    quality_flag: int
