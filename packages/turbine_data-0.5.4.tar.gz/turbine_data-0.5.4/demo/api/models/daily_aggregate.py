from datetime import date
from typing import ClassVar

from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Mapped, mapped_column

from turbine.adapters.api.models.abstract_model import AbstractModel


class DailyAggregateFilter(BaseModel):
    meter_id: str | None = None
    aggregation_date: date | None = None
    total_energy_kwh: float | None = None
    avg_power_kw: float | None = None
    reading_count: int | None = None


class DailyAggregate(AbstractModel[DailyAggregateFilter, tuple[str, date]]):
    __tablename__: ClassVar[str] = "daily_aggregate"
    __schema__: ClassVar[str] = "meters"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "meters"}
    __contract_id__: ClassVar[str] = "meter-readings"
    __id_field__: ClassVar[tuple[str, ...]] = ("meter_id", "aggregation_date")
    meter_id: Mapped[str] = mapped_column(primary_key=True)
    aggregation_date: Mapped[date] = mapped_column(primary_key=True)
    total_energy_kwh: Mapped[float] = mapped_column()
    avg_power_kw: Mapped[float | None] = mapped_column(default=None)
    reading_count: Mapped[int] = mapped_column()


class DailyAggregateSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    meter_id: str
    aggregation_date: date
    total_energy_kwh: float
    avg_power_kw: float | None = None
    reading_count: int
