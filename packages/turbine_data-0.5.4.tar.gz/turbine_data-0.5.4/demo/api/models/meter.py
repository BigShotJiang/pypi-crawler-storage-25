from datetime import datetime
from typing import ClassVar

from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Mapped, mapped_column

from turbine.adapters.api.models.abstract_model import AbstractModel


class MeterFilter(BaseModel):
    id: int | None = None
    meter_id: str | None = None
    recorded_at: datetime | None = None
    energy_kwh: float | None = None
    voltage_v: float | None = None


class Meter(AbstractModel[MeterFilter, int]):
    __tablename__: ClassVar[str] = "meters"
    __schema__: ClassVar[str] = "e2e_inc"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "e2e_inc"}
    __contract_id__: ClassVar[str] = "inc-test"
    id: Mapped[int] = mapped_column(primary_key=True)
    meter_id: Mapped[str] = mapped_column()
    recorded_at: Mapped[datetime] = mapped_column()
    energy_kwh: Mapped[float | None] = mapped_column(default=None)
    voltage_v: Mapped[float | None] = mapped_column(default=None)


class MeterSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    meter_id: str
    recorded_at: datetime
    energy_kwh: float | None = None
    voltage_v: float | None = None
