from typing import ClassVar

from pydantic import BaseModel
from sqlmodel import Field, SQLModel

from turbine.adapters.api.models.abstract_model import AbstractModel


class ExampleFilter(BaseModel):
    id: int | None = None
    name: str | None = None


class Example(AbstractModel[ExampleFilter, int], table=True):
    __tablename__: str = "example"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "public"}
    id: int = Field(primary_key=True)
    name: str | None = None
