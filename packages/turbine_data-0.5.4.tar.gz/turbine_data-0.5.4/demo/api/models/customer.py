from datetime import datetime
from typing import ClassVar

from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Mapped, mapped_column

from turbine.adapters.api.models.abstract_model import AbstractModel


class CustomerFilter(BaseModel):
    customer_id: str | None = None
    name: str | None = None
    email: str | None = None
    address: str | None = None
    created_at: datetime | None = None


class Customer(AbstractModel[CustomerFilter, str]):
    __tablename__: ClassVar[str] = "customer"
    __schema__: ClassVar[str] = "customers"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "customers"}
    __contract_id__: ClassVar[str] = "customer-base"
    __id_field__: ClassVar[str] = "customer_id"
    customer_id: Mapped[str] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column()
    email: Mapped[str] = mapped_column()
    address: Mapped[str | None] = mapped_column(default=None)
    created_at: Mapped[datetime] = mapped_column()


class CustomerSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    customer_id: str
    name: str
    email: str
    address: str | None = None
    created_at: datetime
