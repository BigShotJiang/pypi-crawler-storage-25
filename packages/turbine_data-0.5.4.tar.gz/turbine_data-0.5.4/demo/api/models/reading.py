from datetime import datetime
from typing import ClassVar

from pydantic import BaseModel, ConfigDict
from sqlalchemy.orm import Mapped, mapped_column

from turbine.adapters.api.models.abstract_model import AbstractModel


class ReadingFilter(BaseModel):
    reading_id: str | None = None
    meter_id: str | None = None
    timestamp: datetime | None = None
    energy_kwh: float | None = None
    power_kw: float | None = None
    voltage_v: float | None = None
    quality_flag: int | None = None


class Reading(AbstractModel[ReadingFilter, str]):
    __tablename__: ClassVar[str] = "reading"
    __schema__: ClassVar[str] = "meters"
    __table_args__: ClassVar[dict[str, str]] = {"schema": "meters"}
    __contract_id__: ClassVar[str] = "meter-readings"
    __id_field__: ClassVar[str] = "reading_id"
    reading_id: Mapped[str] = mapped_column(primary_key=True)
    meter_id: Mapped[str] = mapped_column()
    timestamp: Mapped[datetime] = mapped_column()
    energy_kwh: Mapped[float] = mapped_column()
    power_kw: Mapped[float | None] = mapped_column(default=None)
    voltage_v: Mapped[float | None] = mapped_column(default=None)
    quality_flag: Mapped[int | None] = mapped_column(default=None)


class ReadingSchema(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    reading_id: str
    meter_id: str
    timestamp: datetime
    energy_kwh: float
    power_kw: float | None = None
    voltage_v: float | None = None
    quality_flag: int | None = None
