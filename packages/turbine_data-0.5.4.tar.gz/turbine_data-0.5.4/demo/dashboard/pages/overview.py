"""Overview page.

This is the landing page of the dashboard. It summarises the health of every
contract in a single view: KPIs at the top, per-dimension quality gauges, a
pass-rate trend over time, and a table of recent runs that contained failures.

Customise it by changing the KPIs in ``KpiStrip``, swapping gauges for other
charts, or restructuring the ``Tabs``. Every component used here lives under
``turbine.core.dashboard.components``.

The function below is auto-discovered because it is decorated with ``@page``.
Data is fetched through ``Depends(...)``: each resource runs once and its
result is injected as an argument.
"""

from __future__ import annotations

from turbine.core.dashboard.components.charts import Gauge, TrendChart
from turbine.core.dashboard.components.data import Table
from turbine.core.dashboard.components.layout import KPI, GaugeStrip, KpiStrip, Page, Tabs
from turbine.core.dashboard.injection import Depends
from turbine.core.dashboard.models import page
from turbine.core.dashboard.query import (
    CheckCounters,
    CheckCountersData,
    DimensionScores,
    VerificationRuns,
    VerificationRunSummary,
)
from turbine.core.quality.check_results import DimensionScore


@page("Overview", icon=":material/dashboard:", order=1)
def overview(
    scores: list[DimensionScore] = Depends(DimensionScores()),
    counters: CheckCountersData = Depends(CheckCounters()),
    runs: list[VerificationRunSummary] = Depends(VerificationRuns()),
) -> Page:
    """Overview page with KPIs, dimension gauges, trend chart, and failures table."""
    overall = sum(score.score for score in scores) / len(scores) if scores else None

    failed_runs = tuple(run for run in runs if run.failed_checks > 0)

    return Page(
        KpiStrip(
            KPI(label="Pass Rate", value=overall, fmt=".1f%"),
            KPI(label="Total Checks", value=counters.total, fmt=".0f"),
            KPI(label="Passed", value=counters.passed, fmt=".0f"),
            KPI(label="Failed", value=counters.failed, fmt=".0f"),
            KPI(label="Warned", value=counters.warned, fmt=".0f"),
        ),
        GaugeStrip(*(Gauge(label=score.label().title(), value=score.score) for score in scores)),
        Tabs(
            Trend=TrendChart(
                x=tuple(run.timestamp for run in runs),
                y=tuple(run.pass_rate for run in runs),
                title="Pass Rate Trend",
                x_label="Date",
                y_label="Pass Rate %",
                sla_line=90.0,
            ),
            Failures=Table(data=failed_runs, title="Runs with Failures"),
        ),
        title="Overview",
    )
