"""Quality matrix page.

A two-dimensional view of the check landscape: dimensions on the x axis,
tables on the y axis, and check counts in the cells. Below the heatmap, one
tab per dimension lists the individual checks that contribute to it.

The heatmap y-axis comes from the contract list (tables with a contract). To
change what the cells represent, replace the count in the z_rows comprehension
with any aggregation from ``CheckRegistryEntryData``.
"""

from __future__ import annotations

from turbine.core.dashboard.components.charts import Heatmap
from turbine.core.dashboard.components.data import Table
from turbine.core.dashboard.components.layout import Page, TabItem, Tabs
from turbine.core.dashboard.dataset import Dataset
from turbine.core.dashboard.in_memory_dataset import InMemoryDataset
from turbine.core.dashboard.injection import Depends
from turbine.core.dashboard.models import page
from turbine.core.dashboard.query import (
    CheckRegistryEntryData,
    ContractList,
    ContractSummaryData,
    DimensionScores,
)
from turbine.core.quality.check_results import DimensionScore


@page("Quality Matrix", icon=":material/grid_view:", order=3)
def quality_matrix(
    scores: list[DimensionScore] = Depends(DimensionScores()),
    contract_list: list[ContractSummaryData] = Depends(ContractList()),
) -> Page:
    """Dimension x table heatmap with drill-down per dimension."""
    dimensions = sorted({score.dimension for score in scores})
    x_labels = tuple(dim.value.title() for dim in dimensions)
    y_labels = tuple(contract.table for contract in contract_list)

    if not dimensions or not contract_list:
        heatmap = Heatmap(
            z=(), x_labels=x_labels, y_labels=y_labels, title="Checks per Dimension", z_fmt=".0f"
        )
        return Page(heatmap, Tabs(), title="Quality Matrix")

    z_rows = tuple(
        tuple(float(sum(1 for check in contract.checks if check.dimension == dim)) for dim in dimensions)
        for contract in contract_list
    )

    heatmap = Heatmap(
        z=z_rows, x_labels=x_labels, y_labels=y_labels, title="Checks per Dimension", z_fmt=".0f"
    )

    all_checks: list[CheckRegistryEntryData] = [
        check for contract in contract_list for check in contract.checks
    ]
    checks_dataset: Dataset[CheckRegistryEntryData] = InMemoryDataset(rows=all_checks)
    dim_tabs = tuple(
        TabItem(
            label=dim.value.title(),
            children=(
                Table(
                    dataset=checks_dataset.filter(lambda check, dim=dim: check.dimension == dim),
                    title=f"{dim.value.title()} Checks",
                ),
            ),
        )
        for dim in dimensions
    )

    return Page(heatmap, Tabs(*dim_tabs), title="Quality Matrix")
