"""Contracts page.

Per-contract drill-down. One tab per contract, each with KPIs, a bar chart of
checks grouped by dimension, and a table listing every check embedded on the
contract.

To add a field to the check table, extend the dict comprehension inside
``build_contract_tab``. To change how contracts are ordered, sort the list
returned by ``ContractList()`` before the tab loop. To show something other
than check counts in the bar chart, replace ``dimension_counts`` with your own
aggregation.
"""

from __future__ import annotations

from turbine.core.dashboard.components.charts import BarChart
from turbine.core.dashboard.components.data import Table
from turbine.core.dashboard.components.layout import KPI, KpiStrip, Page, TabItem, Tabs
from turbine.core.dashboard.injection import Depends
from turbine.core.dashboard.models import page
from turbine.core.dashboard.query import CheckRegistryEntryData, ContractList, ContractSummaryData


@page("Contracts", icon=":material/contract:", order=2)
def contracts(contract_list: list[ContractSummaryData] = Depends(ContractList())) -> Page:
    """Per-contract drill-down showing check health and outcome distribution."""
    tabs = tuple(build_contract_tab(contract, contract.checks) for contract in contract_list)
    return Page(Tabs(*tabs), title="Contracts")


def build_contract_tab(contract: ContractSummaryData, checks: list[CheckRegistryEntryData]) -> TabItem:
    """Build a TabItem for a single contract with KPIs, bar chart, and check table."""
    failed_checks = contract.check_count - contract.passed_checks
    last_run_display = contract.last_run_at or "Never"

    dimension_counts: dict[str, int] = {}
    for check in checks:
        dim_label = check.dimension.value.title()
        dimension_counts[dim_label] = dimension_counts.get(dim_label, 0) + 1

    bar_chart = BarChart(
        x=tuple(dimension_counts.keys()),
        y=tuple(float(count) for count in dimension_counts.values()),
        title=f"Checks by Dimension ({contract.passed_checks} passed, {failed_checks} failed)",
        x_label="Dimension",
        y_label="Check Count",
    )

    check_table = Table(
        data=tuple(
            {
                "check_id": check.check_id,
                "name": check.name,
                "dimension": check.dimension.value.title(),
                "type": check.check_type,
            }
            for check in checks
        ),
        title="Check Breakdown",
    )

    tab_label = f"{contract.name} ({contract.table})" if contract.name else contract.table
    return TabItem(
        label=tab_label,
        children=(
            KpiStrip(
                KPI(label="Pass Rate", value=contract.overall_score, fmt=".1f%"),
                KPI(label="Checks", value=contract.check_count, fmt=".0f"),
                KPI(label="Last Run", value=last_run_display),
            ),
            bar_chart,
            check_table,
        ),
    )
