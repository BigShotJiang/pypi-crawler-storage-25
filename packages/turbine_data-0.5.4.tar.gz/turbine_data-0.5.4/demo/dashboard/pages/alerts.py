"""Alerts page.

Surfaces checks that have failed several runs in a row. ``AlertList`` returns
one entry per active alert; each entry carries a severity, a streak length,
and the last failure timestamp. The page renders coloured banners for
``CRITICAL`` and ``WARNING`` alerts, plus a full table of every alert.

To change the banner threshold, filter ``alert_list`` before building the
``banners`` tuple. To escalate an alert to a different severity (for example,
treat a long warning streak as critical), adjust ``SEVERITY_TO_LEVEL`` or
wrap the list with your own mapping function.
"""

from __future__ import annotations

from turbine.core.dashboard.components.data import Table
from turbine.core.dashboard.components.display import Alert, SeverityLevel
from turbine.core.dashboard.components.layout import KPI, KpiStrip, Page
from turbine.core.dashboard.injection import Depends
from turbine.core.dashboard.models import page
from turbine.core.dashboard.query import AlertEntry, AlertList, AlertSeverity

SEVERITY_TO_LEVEL = {
    AlertSeverity.CRITICAL: SeverityLevel.ERROR,
    AlertSeverity.WARNING: SeverityLevel.WARNING,
    AlertSeverity.INFO: SeverityLevel.INFO,
}


@page("Alerts", icon=":material/notifications:", order=5)
def alerts(alert_list: list[AlertEntry] = Depends(AlertList())) -> Page:
    """Active alerts based on consecutive check failures."""
    critical_count = sum(1 for alert in alert_list if alert.severity == AlertSeverity.CRITICAL)
    longest_streak = max((alert.consecutive_failures for alert in alert_list), default=0)

    banners = tuple(
        Alert(
            message=(
                f"{alert.check_name} on {alert.table}: {alert.consecutive_failures} consecutive failures"
            ),
            severity=SEVERITY_TO_LEVEL[alert.severity],
        )
        for alert in alert_list
        if alert.severity in (AlertSeverity.CRITICAL, AlertSeverity.WARNING)
    )

    detail_table = Table(
        data=tuple(
            {
                "check": alert.check_name,
                "table": alert.table,
                "dimension": alert.dimension.value.title(),
                "failures": alert.consecutive_failures,
                "severity": alert.severity.value,
                "last_failure": alert.last_failure_at or "N/A",
            }
            for alert in alert_list
        ),
        title="Alert Details",
    )

    return Page(
        KpiStrip(
            KPI(label="Total Alerts", value=len(alert_list), fmt=".0f"),
            KPI(label="Critical", value=critical_count, fmt=".0f"),
            KPI(label="Longest Streak", value=longest_streak, fmt=".0f"),
        ),
        *banners,
        detail_table,
        title="Alerts",
    )
