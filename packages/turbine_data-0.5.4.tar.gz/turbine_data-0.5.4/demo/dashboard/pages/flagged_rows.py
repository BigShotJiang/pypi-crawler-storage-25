"""Flagged rows page.

A minimal page that lets the user pick a table and then renders every row
that has been flagged by a check. ``Picker`` injects a ``TableView`` bound
to the selection, and ``RowViewer`` expands each row to show which checks
fired against it.

To restrict which tables show up in the picker, swap ``FlaggedTables()`` for
a custom resource that returns a filtered list. To change the row layout,
pass ``RowViewer`` a ``detail=...`` callback that builds custom components
per row.
"""

from __future__ import annotations

from turbine.core.dashboard.components.data import Picker, RowViewer
from turbine.core.dashboard.components.layout import Page
from turbine.core.dashboard.injection import Depends
from turbine.core.dashboard.models import page
from turbine.core.dashboard.query import FlaggedTables
from turbine.core.dashboard.table_view import TableView


@page("Flagged Rows", icon=":material/warning:", order=4)
def flagged_rows(table: TableView = Depends(TableView, picker=Picker(source=FlaggedTables()))) -> Page:
    """Page showing flagged rows for a selected table."""
    return Page(
        RowViewer(dataset=table, expandable=True, title=f"Flagged Rows: {table.table_name}"),
        title="Flagged Rows",
    )
