"""Set up 4 tables for a full dashboard E2E demo.

2 contracts (schema owners):
  - ecommerce: orders + payments
  - crm: customers + products

Each table has intentional quality issues for checks to catch.

Run from the turbine-v2 root:
    uv run python demo/setup_dashboard_demo.py
"""

from __future__ import annotations

from datetime import datetime, timedelta, timezone
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import text
from sqlmodel import Field, Session, SQLModel, create_engine

DEMO_DIR = Path(__file__).parent
ENV_FILE = DEMO_DIR / ".env"


class PgSettings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="PG_", env_file=ENV_FILE, frozen=True)

    host: str
    port: int = 5432
    database: str
    user: str
    password: str

    def url(self) -> str:
        return f"postgresql+psycopg://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"


# ---------------------------------------------------------------------------
# ORM Models
# ---------------------------------------------------------------------------

class Order(SQLModel, table=True):
    __tablename__ = "orders"
    __table_args__ = {"schema": "ecommerce"}

    order_id: int = Field(primary_key=True)
    customer_id: str
    amount: float
    status: str
    region: str
    created_at: datetime


class Payment(SQLModel, table=True):
    __tablename__ = "payments"
    __table_args__ = {"schema": "ecommerce"}

    payment_id: int = Field(primary_key=True)
    order_id: int
    amount: float
    method: str
    status: str
    processed_at: datetime


class Customer(SQLModel, table=True):
    __tablename__ = "customers"
    __table_args__ = {"schema": "crm"}

    customer_id: str = Field(primary_key=True)
    name: str
    email: str | None = None
    tier: str
    signup_date: datetime


class Product(SQLModel, table=True):
    __tablename__ = "products"
    __table_args__ = {"schema": "crm"}

    product_id: int = Field(primary_key=True)
    name: str
    price: float
    category: str
    in_stock: bool
    updated_at: datetime


# ---------------------------------------------------------------------------
# Seed Data
# ---------------------------------------------------------------------------
NOW = datetime(2026, 4, 9, 8, 0, 0, tzinfo=timezone.utc)


def make_orders() -> list[Order]:
    """50 orders, some with quality issues."""
    statuses = ["shipped", "pending", "delivered", "cancelled", "refunded"]
    regions = ["US-East", "US-West", "EU-West", "EU-East", "APAC"]
    rows: list[Order] = []
    for idx in range(50):
        amount = round(10.0 + idx * 7.77, 2)
        status = statuses[idx % len(statuses)]
        region = regions[idx % len(regions)]
        created = NOW - timedelta(hours=idx * 3)

        # Intentional issues
        if idx == 5:
            amount = -25.00  # negative amount
        if idx == 12:
            amount = 0.0  # zero amount
        if idx == 20:
            status = "INVALID_STATUS"  # bad status value
        if idx == 30:
            amount = 99999.99  # suspiciously high

        row = Order(
            order_id=1000 + idx,
            customer_id=f"C{(idx % 15) + 1:03d}",
            amount=amount,
            status=status,
            region=region,
            created_at=created,
        )
        rows.append(row)
    return rows


def make_payments() -> list[Payment]:
    """40 payments, some with issues."""
    methods = ["credit_card", "debit_card", "paypal", "bank_transfer", "crypto"]
    rows: list[Payment] = []
    for idx in range(40):
        amount = round(10.0 + idx * 8.33, 2)
        method = methods[idx % len(methods)]
        status = "completed" if idx % 7 != 0 else "failed"
        processed = NOW - timedelta(hours=idx * 4)

        # Intentional issues
        if idx == 3:
            amount = -10.00  # negative
        if idx == 15:
            method = "UNKNOWN"  # invalid method
        if idx == 25:
            status = "pending_forever"  # invalid status

        row = Payment(
            payment_id=2000 + idx,
            order_id=1000 + (idx % 50),  # references orders
            amount=amount,
            method=method,
            status=status,
            processed_at=processed,
        )
        rows.append(row)
    return rows


def make_customers() -> list[Customer]:
    """20 customers, some with issues."""
    tiers = ["gold", "silver", "bronze"]
    names = [
        "Alice Johnson", "Bob Smith", "Carol White", "Dave Brown", "Eve Davis",
        "Frank Miller", "Grace Lee", "Hank Wilson", "Iris Chen", "Jack Taylor",
        "Karen Moore", "Leo Garcia", "Mia Robinson", "Noah Clark", "Olivia Hall",
        "Pete Young", "Quinn Adams", "Rosa King", "Sam Wright", "Tina Lopez",
    ]
    rows: list[Customer] = []
    for idx, name in enumerate(names):
        tier = tiers[idx % len(tiers)]
        email: str | None = f"{name.split()[0].lower()}@example.com"
        signup = NOW - timedelta(days=365 - idx * 15)

        # Intentional issues
        if idx == 4:
            email = None  # missing email
        if idx == 7:
            email = "not-an-email"  # bad format
        if idx == 11:
            email = ""  # empty string
        if idx == 16:
            tier = "PLATINUM"  # invalid tier

        row = Customer(
            customer_id=f"C{idx + 1:03d}",
            name=name,
            email=email,
            tier=tier,
            signup_date=signup,
        )
        rows.append(row)
    return rows


def make_products() -> list[Product]:
    """25 products, some with issues."""
    categories = ["electronics", "tools", "clothing", "food", "home"]
    rows: list[Product] = []
    for idx in range(25):
        price = round(5.0 + idx * 12.49, 2)
        category = categories[idx % len(categories)]
        updated = NOW - timedelta(days=idx * 2)

        # Intentional issues
        if idx == 2:
            price = -5.00  # negative price
        if idx == 10:
            category = "UNKNOWN_CATEGORY"  # invalid category
        if idx == 18:
            price = 0.0  # zero price

        row = Product(
            product_id=3000 + idx,
            name=f"Product {chr(65 + idx % 26)}{'X' * (idx // 26)}",
            price=price,
            category=category,
            in_stock=idx % 4 != 0,
            updated_at=updated,
        )
        rows.append(row)
    return rows


# ---------------------------------------------------------------------------
# Setup
# ---------------------------------------------------------------------------

def main() -> None:
    settings = PgSettings()  # type: ignore[call-arg]
    engine = create_engine(settings.url())

    # Create schemas
    with engine.connect() as conn:
        conn.execute(text("CREATE SCHEMA IF NOT EXISTS ecommerce"))
        conn.execute(text("CREATE SCHEMA IF NOT EXISTS crm"))
        conn.commit()

    # Drop existing tables
    with engine.connect() as conn:
        for table in ["ecommerce.payments", "ecommerce.orders", "crm.customers", "crm.products"]:
            conn.execute(text(f"DROP TABLE IF EXISTS {table} CASCADE"))
        conn.commit()

    # Create tables
    SQLModel.metadata.create_all(engine)
    print("Created tables: ecommerce.orders, ecommerce.payments, crm.customers, crm.products")

    # Insert data
    with Session(engine) as session:
        orders = make_orders()
        payments = make_payments()
        customers = make_customers()
        products = make_products()

        session.add_all(orders)
        session.add_all(payments)
        session.add_all(customers)
        session.add_all(products)
        session.commit()

    print(f"Seeded: {len(orders)} orders, {len(payments)} payments, "
          f"{len(customers)} customers, {len(products)} products")
    print()
    print("Next steps:")
    print("  uv run turbine check --all --datasource postgres --flag")
    print("  uv run turbine serve --datasource postgres")
    print("  uv run turbine dashboard")


if __name__ == "__main__":
    main()
