"""Seed Snowflake ENERGY_READINGS table with ~500 rows for quality demo.

Creates realistic meter data with intentional quality issues to demonstrate:
  - Quality spec checks (column, SQL, group, window)
  - Row-level flagging (--flag-rows)
  - Audit trail

Run from the turbine-v2 root:
    uv run python demo/seed_snowflake.py
"""

import random
from datetime import datetime, timedelta
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import Engine, text
from sqlmodel import Field, Session, SQLModel, create_engine

ENV_FILE = Path(__file__).parent / ".env"
BASE_TIME = datetime(2026, 2, 20, 0, 0, 0)
RANDOM_SEED = 42


class SnowflakeSettings(BaseSettings):
    """Snowflake connection settings, auto-loaded from SF_* environment variables."""

    model_config = SettingsConfigDict(env_prefix="SF_", env_file=ENV_FILE, frozen=True)

    account: str
    user: str
    password: str
    database: str
    warehouse: str
    schema_name: str = "PUBLIC"
    role: str | None = None

    def engine_url(self) -> str:
        """Build a snowflake:// SQLAlchemy connection URL."""
        return (
            f"snowflake://{self.user}:{self.password}@{self.account}"
            f"/{self.database}/{self.schema_name}?warehouse={self.warehouse}"
        )


class EnergyReading(SQLModel, table=True):
    """ORM model for the ENERGY_READINGS demo table."""

    __tablename__ = "energy_readings"
    __table_args__ = {"schema": "public"}

    id: int = Field(primary_key=True)
    meter_id: str = Field(max_length=10)
    recorded_at: datetime
    energy_kwh: float
    power_kw: float | None = None
    voltage_v: float | None = None
    quality_flag: int = Field(default=0)


def generate_clean_rows(start_id: int) -> tuple[list[EnergyReading], int]:
    """Generate ~460 clean meter readings across 20 meters."""
    rows: list[EnergyReading] = []
    row_id = start_id

    for meter_num in range(1, 21):
        meter_id = f"MTR-{meter_num:03d}"
        for hour in range(24):
            if random.random() < 0.04:
                continue
            timestamp = BASE_TIME + timedelta(hours=hour, minutes=random.randint(0, 30))
            row = EnergyReading(
                id=row_id,
                meter_id=meter_id,
                recorded_at=timestamp,
                energy_kwh=round(random.uniform(0.1, 3.5), 2),
                power_kw=round(random.uniform(0.1, 2.5), 2),
                voltage_v=round(random.uniform(215, 240), 1),
                quality_flag=0,
            )
            rows.append(row)
            row_id += 1

    return rows, row_id


def generate_quality_issues(start_id: int) -> list[EnergyReading]:
    """Generate rows with intentional quality issues for demo purposes."""
    rows: list[EnergyReading] = []
    row_id = start_id

    # 1. NULL power_kw (3 rows) — completeness fail
    for meter_id, hours_offset in [("MTR-001", 30), ("MTR-005", 38), ("MTR-012", 46)]:
        timestamp = BASE_TIME + timedelta(hours=hours_offset)
        rows.append(EnergyReading(
            id=row_id, meter_id=meter_id, recorded_at=timestamp,
            energy_kwh=1.2, power_kw=None, voltage_v=230.5, quality_flag=0
        ))
        row_id += 1

    # 2. Negative energy_kwh (4 rows) — accuracy fail
    for meter_id, hours_offset in [("MTR-003", 31), ("MTR-008", 39), ("MTR-014", 50), ("MTR-019", 55)]:
        timestamp = BASE_TIME + timedelta(hours=hours_offset)
        energy = round(random.uniform(-2.0, -0.1), 2)
        rows.append(EnergyReading(
            id=row_id, meter_id=meter_id, recorded_at=timestamp,
            energy_kwh=energy, power_kw=0.0, voltage_v=228.0, quality_flag=0,
        ))
        row_id += 1

    # 3. Out-of-range voltage (6 rows) — accuracy fail
    bad_voltages = [260.5, 95.0, 255.0, 280.0, 88.0, 270.0]
    for meter_index, bad_voltage in enumerate(bad_voltages):
        meter_id = f"MTR-{(meter_index + 10):03d}"
        timestamp = BASE_TIME + timedelta(hours=26 + meter_index)
        rows.append(EnergyReading(
            id=row_id, meter_id=meter_id, recorded_at=timestamp,
            energy_kwh=1.0, power_kw=0.7, voltage_v=bad_voltage, quality_flag=0,
        ))
        row_id += 1

    # 4. Flatline voltage for MTR-006 (10 identical readings) — window check
    for hour in range(10):
        timestamp = BASE_TIME + timedelta(days=3, hours=hour)
        rows.append(EnergyReading(
            id=row_id, meter_id="MTR-006", recorded_at=timestamp,
            energy_kwh=round(random.uniform(0.5, 2.0), 2),
            power_kw=round(random.uniform(0.3, 1.5), 2),
            voltage_v=245.0, quality_flag=0,
        ))
        row_id += 1

    # 5. Energy spike for MTR-002 (1 anomalous row among normal) — window check
    for hour in range(5):
        timestamp = BASE_TIME + timedelta(days=4, hours=hour)
        energy = 50000.0 if hour == 3 else round(random.uniform(0.5, 2.0), 2)
        rows.append(EnergyReading(
            id=row_id, meter_id="MTR-002", recorded_at=timestamp,
            energy_kwh=energy, power_kw=round(random.uniform(0.3, 1.5), 2),
            voltage_v=230.0, quality_flag=0,
        ))
        row_id += 1

    # 6. Meter with very few readings — MTR-020 only 1 reading
    rows.append(EnergyReading(
        id=row_id, meter_id="MTR-020", recorded_at=BASE_TIME + timedelta(hours=12),
        energy_kwh=1.5, power_kw=1.0, voltage_v=229.0, quality_flag=0,
    ))

    return rows


def recreate_table(engine: Engine) -> None:
    """Drop and recreate the ENERGY_READINGS table via SQLModel metadata."""
    with engine.connect() as conn:
        conn.execute(text("DROP TABLE IF EXISTS PUBLIC.ENERGY_READINGS"))
        conn.commit()
    table = EnergyReading.__table__  # type: ignore[attr]  # set by SQLAlchemy metaclass
    SQLModel.metadata.create_all(engine, tables=[table])
    print("Created PUBLIC.ENERGY_READINGS")


SUMMARY_QUERIES: list[tuple[str, str]] = [
    ("Total rows", "SELECT COUNT(*) FROM PUBLIC.ENERGY_READINGS"),
    ("Negative energy rows", "SELECT COUNT(*) FROM PUBLIC.ENERGY_READINGS WHERE ENERGY_KWH < 0"),
    (
        "Out-of-range voltage rows",
        "SELECT COUNT(*) FROM PUBLIC.ENERGY_READINGS "
        "WHERE VOLTAGE_V IS NOT NULL AND (VOLTAGE_V < 100 OR VOLTAGE_V > 250)",
    ),
    ("Null power_kw rows", "SELECT COUNT(*) FROM PUBLIC.ENERGY_READINGS WHERE POWER_KW IS NULL"),
]


def print_summary(session: Session) -> None:
    """Print row counts and quality issue breakdown."""
    for label, query in SUMMARY_QUERIES:
        result = session.exec(text(query)).one()  # type: ignore[arg-type]
        print(f"  {label}: {result}")


def seed() -> None:
    """Seed the Snowflake ENERGY_READINGS table with demo data."""
    settings = SnowflakeSettings()  # type: ignore[call-arg]
    random.seed(RANDOM_SEED)

    engine = create_engine(settings.engine_url())

    recreate_table(engine)

    clean_rows, next_id = generate_clean_rows(start_id=1)
    issue_rows = generate_quality_issues(start_id=next_id)
    all_rows = clean_rows + issue_rows

    print(f"Inserting {len(all_rows)} rows...")
    with Session(engine) as session:
        session.add_all(all_rows)
        session.commit()
        print_summary(session)

    print("Done!")


if __name__ == "__main__":
    seed()
