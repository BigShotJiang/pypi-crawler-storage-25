import pandas as pd


def e2e_null_check_sf(df: pd.DataFrame) -> pd.Series:
    """Flag rows where ENERGY_KWH is null (Snowflake uppercase columns)."""
    return df["ENERGY_KWH"].isna()
