SELECT order_id, amount
FROM {{ this }}
WHERE amount < {{ var('min_amount') }}
   OR amount > {{ var('max_amount') }}
