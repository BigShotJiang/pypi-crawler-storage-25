"""Typed Python check: validate order amounts against per-status averages.

Demonstrates the typed dataclass input pattern — the check receives
the primary table as `df` and extra data via a typed `CheckInput` dataclass.
"""

from dataclasses import dataclass

import pandas as pd


@dataclass
class CheckInput:
    status_averages: pd.DataFrame
    max_deviation: float = 5.0


def validate_order_consistency(df: pd.DataFrame, inputs: CheckInput) -> pd.Series:
    """Flag orders whose amount deviates more than max_deviation from their status average.

    Returns True for rows that FAIL the check.
    """
    merged = df.merge(inputs.status_averages, on="status", how="left", suffixes=("", "_avg"))
    return (merged["amount"] - merged["avg_amount"]).abs() > inputs.max_deviation
