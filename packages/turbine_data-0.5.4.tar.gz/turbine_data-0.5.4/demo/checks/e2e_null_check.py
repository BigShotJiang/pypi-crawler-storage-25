import pandas as pd


def e2e_null_check(df: pd.DataFrame) -> pd.Series:
    """Flag rows where energy_kwh is null."""
    return df["energy_kwh"].isna()
