-- Custom check: freshness
-- Returns rows that FAIL the check.
SELECT *
FROM {{ table }}
WHERE 1 = 0  -- Replace with your failure condition
