"""Python check that raises at runtime to test error reporting."""

import pandas as pd


def broken_check(df: pd.DataFrame) -> pd.Series:
    """Always raise; used to test runtime-error diagnostics."""
    msg = "intentional failure"
    raise RuntimeError(msg)
