-- Returns readings for meters that have no entry in the meter registry
SELECT *
FROM {{ table }} r
LEFT JOIN {{ reference_table }} m ON r.meter_id = m.meter_id
WHERE m.meter_id IS NULL
