SELECT {{ pk }}
FROM {{ table }}
WHERE ENERGY_KWH < 0
{% if incremental_filter %}AND {{ incremental_filter }}{% endif %}
