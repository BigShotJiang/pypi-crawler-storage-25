-- Returns rows where voltage_v is out of range
SELECT *
FROM {{ table }}
WHERE voltage_v IS NOT NULL
  AND (voltage_v < {{ min_val }} OR voltage_v > {{ max_val }})
