"""Python check: flag rows where amount is zero or negative."""

import pandas as pd


def validate_amounts(df: pd.DataFrame) -> pd.Series:
    """Return True for rows that fail the check (amount <= 0)."""
    return df["amount"] <= 0
