-- Returns rows where amount is outside the allowed range
SELECT *
FROM {{ table }}
WHERE amount < {{ min_amount }} OR amount > {{ max_amount }}
