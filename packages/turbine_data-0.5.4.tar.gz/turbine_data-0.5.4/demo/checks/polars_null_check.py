"""Polars check: flag rows where energy_kwh is null."""

import polars as pl


def polars_null_check(df: pl.DataFrame) -> pl.Series:
    """Return True for rows that FAIL the check."""
    return df["energy_kwh"].is_null()
