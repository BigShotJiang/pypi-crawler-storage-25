-- Returns rows where amount is negative
SELECT *
FROM {{ table }}
WHERE amount < 0
