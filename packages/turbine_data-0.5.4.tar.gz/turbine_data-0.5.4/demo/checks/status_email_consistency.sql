-- Complex: completed orders must have an email, and amounts must be positive
-- Cross-references multiple conditions in a single check
SELECT *
FROM {{ this }}
WHERE (status = 'completed' AND customer_email IS NULL)
   OR (status = 'completed' AND amount <= 0)
