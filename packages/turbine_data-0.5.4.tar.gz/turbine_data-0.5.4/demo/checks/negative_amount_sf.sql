-- Returns rows where AMOUNT is negative (Snowflake uppercase columns).
SELECT *
FROM {{ table }}
WHERE AMOUNT < 0
