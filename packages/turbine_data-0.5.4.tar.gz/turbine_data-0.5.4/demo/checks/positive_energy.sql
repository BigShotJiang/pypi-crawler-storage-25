-- Returns rows where energy_kwh is not positive
SELECT *
FROM {{ table }}
WHERE energy_kwh <= 0
