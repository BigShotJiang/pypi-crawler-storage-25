-- Returns rows where VOLTAGE_V is out of range (Snowflake uppercase columns).
SELECT *
FROM {{ table }}
WHERE VOLTAGE_V IS NOT NULL
  AND (VOLTAGE_V < {{ min_val }} OR VOLTAGE_V > {{ max_val }})
