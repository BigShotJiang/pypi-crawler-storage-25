import pandas as pd


def validate_orders(df: pd.DataFrame) -> pd.Series:
    """Flag orders where amount is negative or status is unknown.

    Valid statuses: shipped, pending, cancelled.
    """
    valid_statuses = {"shipped", "pending", "cancelled"}
    bad_status = ~df["status"].isin(valid_statuses)
    bad_amount = df["amount"] < 0
    return bad_status | bad_amount
