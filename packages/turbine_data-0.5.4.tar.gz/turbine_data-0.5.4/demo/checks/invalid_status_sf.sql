-- Returns rows with STATUS not in the valid set (Snowflake uppercase columns).
SELECT *
FROM {{ table }}
WHERE STATUS NOT IN ('pending', 'shipped', 'completed')
