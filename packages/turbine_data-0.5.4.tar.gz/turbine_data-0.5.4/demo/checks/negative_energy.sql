SELECT {{ pk }}
FROM {{ table }}
WHERE energy_kwh < 0
{% if incremental_filter %}AND {{ incremental_filter }}{% endif %}
