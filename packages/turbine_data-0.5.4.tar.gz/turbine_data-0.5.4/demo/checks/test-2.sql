-- Custom check: test-2
-- Returns rows that FAIL the check.
SELECT *
FROM {{ this }}
WHERE 1 = 0  -- Replace with your failure condition
