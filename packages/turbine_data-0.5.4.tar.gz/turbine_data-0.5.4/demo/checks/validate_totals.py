"""Custom check: validate_totals."""

import polars as pl


def check(df: pl.DataFrame) -> pl.Series:
    """Return a boolean Series where True means the row passed."""
    return df.select(pl.lit(True)).to_series()
