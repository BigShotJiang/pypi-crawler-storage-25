-- Returns readings for meters that have no entry in the meter registry (Snowflake uppercase columns).
SELECT *
FROM {{ table }} r
LEFT JOIN {{ reference_table }} m ON r.METER_ID = m.METER_ID
WHERE m.METER_ID IS NULL
