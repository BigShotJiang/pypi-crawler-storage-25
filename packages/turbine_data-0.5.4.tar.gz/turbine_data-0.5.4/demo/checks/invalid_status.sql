-- Returns rows where status is not in the allowed set
SELECT *
FROM {{ table }}
WHERE status NOT IN ('pending', 'completed', 'shipped', 'cancelled')
