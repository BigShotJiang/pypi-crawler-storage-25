"""Set up demo databases with intentional schema drift.

Creates a sensors table in both DuckDB and PostgreSQL with:
  - id, name, value: match the contract
  - extra_col: present in DB but NOT in contract (drift: extra)
  - missing_col: in contract but NOT in DB (drift: missing)

Run from the turbine-v2 root:
    uv run python demo/setup_demo.py
"""

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict
from sqlalchemy import Engine, text
from sqlmodel import Field, Session, SQLModel, create_engine

DEMO_DIR = Path(__file__).parent
ENV_FILE = DEMO_DIR / ".env"


class PostgresSettings(BaseSettings):
    """PostgreSQL connection settings, auto-loaded from PG_* environment variables."""

    model_config = SettingsConfigDict(env_prefix="PG_", env_file=ENV_FILE, frozen=True)

    host: str
    port: int = 5432
    database: str
    user: str
    password: str

    def engine_url(self) -> str:
        """Build a postgresql+psycopg:// SQLAlchemy connection URL."""
        return f"postgresql+psycopg://{self.user}:{self.password}@{self.host}:{self.port}/{self.database}"


class Sensor(SQLModel, table=True):
    """ORM model for the sensors demo table."""

    __tablename__ = "sensors"
    __table_args__ = {"schema": "public"}

    id: int = Field(primary_key=True)
    name: str
    value: float | None = None
    extra_col: str | None = None


SEED_ROWS: list[Sensor] = [
    Sensor(id=1, name="temperature", value=23.5, extra_col="x"),
    Sensor(id=2, name="humidity", value=45.0, extra_col=None),
    Sensor(id=3, name="pressure", value=1013.25, extra_col="y"),
]


def recreate_table(engine: Engine, label: str) -> None:
    """Drop and recreate the sensors table via SQLModel metadata."""
    with engine.connect() as conn:
        conn.execute(text("DROP TABLE IF EXISTS public.sensors"))
        conn.commit()
    table = Sensor.__table__  # type: ignore[attr]  # set by SQLAlchemy metaclass
    SQLModel.metadata.create_all(engine, tables=[table])
    print(f"{label}: created public.sensors")


def insert_seed_data(engine: Engine) -> None:
    """Insert the seed rows into the sensors table."""
    with Session(engine) as session:
        session.add_all(SEED_ROWS)
        session.commit()


def setup_duckdb() -> None:
    """Create and seed the sensors table in a local DuckDB file."""
    db_path = DEMO_DIR / "demo.duckdb"
    engine = create_engine(f"duckdb:///{db_path}")

    with engine.connect() as conn:
        conn.execute(text("CREATE SCHEMA IF NOT EXISTS public"))
        conn.commit()

    recreate_table(engine, label="DuckDB")
    insert_seed_data(engine)
    print(f"  -> {db_path}")


def setup_postgres() -> None:
    """Create and seed the sensors table in PostgreSQL."""
    settings = PostgresSettings()  # type: ignore[call-arg]
    engine = create_engine(settings.engine_url())

    recreate_table(engine, label="PostgreSQL")
    insert_seed_data(engine)


if __name__ == "__main__":
    setup_duckdb()
    setup_postgres()
    print("Done.")
    print("Run: uv run turbine drift --contract contracts/drift-test.yml --datasource local")
    print("  or: uv run turbine drift --contract contracts/drift-test.yml --datasource postgres")
