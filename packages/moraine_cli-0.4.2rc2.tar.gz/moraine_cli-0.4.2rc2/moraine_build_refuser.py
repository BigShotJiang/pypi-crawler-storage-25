"""In-tree PEP 517 backend that refuses to build moraine from source.

See RFC #219. Moraine ships as prebuilt binary wheels; building from an
sdist would require a Rust toolchain + bun for the monitor frontend,
which is out of scope for `pip install`.
"""

MESSAGE = (
    'moraine ships as prebuilt binary wheels only. Install via a platform with a published wheel, or build from source with: https://github.com/eric-tramel/moraine#install-from-source'
)


def _refuse(*_args, **_kwargs):
    raise SystemExit("ERROR: " + MESSAGE)


build_wheel = _refuse
build_sdist = _refuse
get_requires_for_build_wheel = _refuse
get_requires_for_build_sdist = _refuse
prepare_metadata_for_build_wheel = _refuse
