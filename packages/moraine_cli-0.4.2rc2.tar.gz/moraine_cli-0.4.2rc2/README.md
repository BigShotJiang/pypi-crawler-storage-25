# moraine (source distribution)

This sdist is a stub. Moraine distributes prebuilt binary wheels only
(macOS arm64, Linux x86_64, Linux aarch64). Installing this sdist with
`pip install moraine --no-binary moraine` will fail with a pointer to
the source-install instructions.

To install moraine:

```bash
# Recommended: a published platform wheel
uv tool install moraine

# Fallback on platforms without a wheel: the curl installer
curl -fsSL https://raw.githubusercontent.com/eric-tramel/moraine/main/scripts/install.sh | sh
```

See https://github.com/eric-tramel/moraine for full docs.
