"""Noru — Autonomous orchestrator for Claude Code."""

__version__ = "0.1.2"
