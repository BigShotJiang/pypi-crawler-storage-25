"""Session manager — tracks per-project Claude session-ids in sessions.json."""

from __future__ import annotations

import json
import logging
import uuid
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)

SESSIONS_FILE = "sessions.json"


@dataclass(frozen=True)
class SessionState:
    project_id: str
    session_id: str
    status: str  # new | active | paused
    requests_since_compact: int
    total_requests: int
    tmux_session: str
    created_at: str
    last_active: str

    @classmethod
    def new(cls, project_id: str) -> SessionState:
        now = datetime.now(timezone.utc).isoformat()
        return cls(
            project_id=project_id,
            session_id=str(uuid.uuid4()),
            status="new",
            requests_since_compact=0,
            total_requests=0,
            tmux_session=f"noru-worker-{project_id}",
            created_at=now,
            last_active=now,
        )

    def _replace(self, **kwargs) -> SessionState:
        d = asdict(self)
        d.update(kwargs)
        return SessionState(**d)

    def needs_compact(self, compact_every: int) -> bool:
        return self.requests_since_compact >= compact_every

    def needs_reset(self, reset_after: int) -> bool:
        return self.total_requests >= reset_after

    def increment_requests(self) -> SessionState:
        now = datetime.now(timezone.utc).isoformat()
        return self._replace(
            requests_since_compact=self.requests_since_compact + 1,
            total_requests=self.total_requests + 1,
            last_active=now,
        )

    def mark_compacted(self) -> SessionState:
        return self._replace(requests_since_compact=0)

    def to_dict(self) -> dict:
        return {
            "session_id": self.session_id,
            "tmux_session": self.tmux_session,
            "status": self.status,
            "requests_since_compact": self.requests_since_compact,
            "total_requests": self.total_requests,
            "created_at": self.created_at,
            "last_active": self.last_active,
        }

    @classmethod
    def from_dict(cls, project_id: str, d: dict) -> SessionState:
        return cls(
            project_id=project_id,
            session_id=d["session_id"],
            status=d.get("status", "new"),
            requests_since_compact=d.get("requests_since_compact", 0),
            total_requests=d.get("total_requests", 0),
            tmux_session=d.get("tmux_session", f"noru-worker-{project_id}"),
            created_at=d.get("created_at", ""),
            last_active=d.get("last_active", ""),
        )


class SessionManager:
    """Manages per-project session state in sessions.json."""

    def __init__(self, sessions_dir: Path | None = None):
        self._dir = sessions_dir or (Path.home() / ".noru")
        self._dir.mkdir(parents=True, exist_ok=True)
        self._file = self._dir / SESSIONS_FILE
        self._cache: dict[str, SessionState] = {}
        self._load()

    def _load(self) -> None:
        if not self._file.exists():
            self._cache = {}
            return
        try:
            data = json.loads(self._file.read_text())
            self._cache = {
                pid: SessionState.from_dict(pid, d)
                for pid, d in data.items()
            }
        except (json.JSONDecodeError, OSError):
            self._cache = {}

    def _save(self) -> None:
        data = {pid: s.to_dict() for pid, s in self._cache.items()}
        tmp = self._file.with_suffix(".tmp")
        try:
            tmp.write_text(json.dumps(data, indent=2))
            tmp.rename(self._file)
        except OSError:
            tmp.unlink(missing_ok=True)
            raise

    def get_or_create(self, project_id: str) -> SessionState:
        if project_id not in self._cache:
            state = SessionState.new(project_id)
            self._cache[project_id] = state
            self._save()
        return self._cache[project_id]

    def update(self, state: SessionState) -> None:
        self._cache[state.project_id] = state
        self._save()

    def reset_session(self, project_id: str) -> SessionState:
        new = SessionState.new(project_id)
        self._cache[project_id] = new
        self._save()
        return new

    def pause(self, project_id: str) -> None:
        if project_id in self._cache:
            self._cache[project_id] = self._cache[project_id]._replace(status="paused")
            self._save()

    def resume(self, project_id: str) -> None:
        if project_id in self._cache:
            self._cache[project_id] = self._cache[project_id]._replace(status="active")
            self._save()

    def remove(self, project_id: str) -> None:
        self._cache.pop(project_id, None)
        self._save()

    def all_sessions(self) -> list[SessionState]:
        return list(self._cache.values())
