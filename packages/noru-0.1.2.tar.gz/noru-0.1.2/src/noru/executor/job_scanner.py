"""Periodic scanner for completed jobs — reads JSON files, imports results to DB, creates tasks."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING

from noru.core.database import Database
from noru.core.models import Job

from noru.engine.events import NoruEvent

if TYPE_CHECKING:
    from noru.core.config import NoruConfig
    from noru.engine.events import EventBus
    from noru.executor.action_service import ClaudeAction, ClaudeActionService
    from noru.executor.idle_reviewer import IdleReviewer

logger = logging.getLogger(__name__)

DEFAULT_TIMEOUT = 600  # seconds before a pending job is considered timed out
MAX_RETRIES = 1  # retry timed-out jobs once

RATE_LIMIT_PATTERNS = {"rate limit", "429", "too many requests", "quota exceeded"}


class JobScanner:
    """Scans pending jobs in DB, checks JSON files for completion, imports results."""

    def __init__(
        self, db: Database, config: NoruConfig,
        idle_reviewer: IdleReviewer,
        action_service: ClaudeActionService | None = None,
        event_bus: EventBus | None = None,
    ):
        self.db = db
        self.config = config
        self.idle_reviewer = idle_reviewer
        self.action_service = action_service
        self.event_bus = event_bus
        self.rate_limited = False

    def scan(self) -> int:
        """Check all pending jobs and process completed ones. Returns count of jobs completed."""
        count = 0

        # Phase 1: Check pending jobs — read JSON files, update DB status
        pending = self.db.get_pending_jobs()
        for job in pending:
            if self._check_and_complete(job):
                count += 1

        if pending:
            logger.debug("Scanned %d pending jobs, %d completed", len(pending), count)

        # Phase 2: Process completed-but-unprocessed jobs — create tasks etc.
        unprocessed = self.db.get_completed_unprocessed_jobs()
        for job in unprocessed:
            self._process_completed_job(job)

        return count

    def _check_and_complete(self, job: Job) -> bool:
        """Read the JSON file for a pending job. If done, update DB. Returns True if status changed."""
        filepath = Path(job.file_path)

        if not filepath.exists():
            now = datetime.now(timezone.utc).isoformat()
            self.db.complete_job(job.id, status="error", error="Job file not found", completed_at=now)
            logger.warning("Job #%d: file not found at %s", job.id, filepath)
            return True

        try:
            text = filepath.read_text()
            data = json.loads(text)
        except (json.JSONDecodeError, OSError) as e:
            logger.debug("Job #%d file unreadable: %s", job.id, e)
            return False

        file_status = data.get("status", "pending")

        if file_status == "pending":
            return self._check_timeout(job)

        # Wait for completed_at to ensure Claude finished writing all fields
        if not data.get("completed_at"):
            return False

        # Job completed — update DB
        result = data.get("result")
        result_str = json.dumps(result) if result is not None else None

        self.db.complete_job(
            job.id,
            status=file_status,
            result=result_str,
            error=data.get("error"),
            completed_at=data.get("completed_at", datetime.now(timezone.utc).isoformat()),
        )
        logger.info("Job #%d (%s) completed: status=%s", job.id, job.action_id, file_status)
        return True

    def _check_timeout(self, job: Job) -> bool:
        """Check if a pending job has exceeded the timeout. Retries once, then fails."""
        if not job.created_at:
            return False
        try:
            created = datetime.fromisoformat(job.created_at)
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            elapsed = (datetime.now(timezone.utc) - created).total_seconds()
        except ValueError:
            return False

        if elapsed <= DEFAULT_TIMEOUT:
            return False

        # Retry once for timeouts
        if job.retry_count < MAX_RETRIES and self.action_service:
            if self._retry_job(job):
                logger.info("Job #%d timed out after %ds — retrying (attempt %d)", job.id, int(elapsed), job.retry_count + 1)
                return False  # still pending after retry, don't count as completed
            # Retry failed (tmux busy/dead) — fall through to final timeout

        now = datetime.now(timezone.utc).isoformat()
        self.db.complete_job(job.id, status="timeout", error=f"Timeout after {int(elapsed)}s", completed_at=now)
        logger.warning("Job #%d timed out after %ds (retries exhausted)", job.id, int(elapsed))
        return True

    def _retry_job(self, job: Job) -> bool:
        """Re-dispatch a timed-out job with a new file. Returns True if re-dispatched."""
        from noru.executor.action_service import ClaudeAction

        action = ClaudeAction(
            action_id=job.action_id,
            action_type=job.action_type,
            project_id=job.project_id,
            prompt=job.prompt,
            metadata=json.loads(job.metadata) if job.metadata else {},
        )
        filepath = self.action_service.write_job_file(action)
        tmux_cmd = self.action_service._build_tmux_command(filepath)

        if not self.action_service.tmux_controller or not self.action_service.tmux_controller.is_alive():
            return False
        if not self.action_service.tmux_controller.is_idle():
            return False

        sent = self.action_service.tmux_controller.send_prompt(tmux_cmd)
        if sent:
            self.db.retry_job(job.id, str(filepath))
            return True
        return False

    def _is_rate_limited(self, error: str | None) -> bool:
        """Check if an error message indicates rate limiting."""
        if not error:
            return False
        lower = error.lower()
        return any(p in lower for p in RATE_LIMIT_PATTERNS)

    def _process_completed_job(self, job: Job) -> None:
        """Process a completed job — create tasks from review findings, update task status, etc."""
        if job.action_type == "review" and job.status == "ok" and job.result:
            self._process_review_job(job)
        elif job.action_type == "task":
            self._process_task_job(job)

        self.db.mark_job_processed(job.id)

    # Infrastructure errors — task should retry, not fail
    INFRA_ERRORS = {"Tmux session died", "Worker tmux session died", "Tmux session not alive or not available", "Claude is busy — cannot send action", "Failed to send command to tmux"}

    def _is_infra_error(self, job: Job) -> bool:
        """Check if a job error is infrastructure (not the task's fault)."""
        return job.error in self.INFRA_ERRORS or job.status == "timeout"

    def _process_task_job(self, job: Job) -> None:
        """Process a completed task job — update task_run, task status, add comment."""
        metadata = json.loads(job.metadata) if job.metadata else {}
        task_id = metadata.get("task_id")
        run_id = metadata.get("run_id")

        if not task_id:
            logger.warning("Job #%d (task) has no task_id in metadata", job.id)
            return

        task = self.db.get_task(task_id)
        if not task:
            logger.warning("Job #%d references unknown task #%s", job.id, task_id)
            return

        ended = job.completed_at or datetime.now(timezone.utc).isoformat()

        if job.status == "ok":
            status = "success"
            try:
                raw = json.loads(job.result) if isinstance(job.result, str) else job.result
            except (json.JSONDecodeError, ValueError):
                raw = job.result
            summary = str(raw)[:500] if raw else ""
            error = None
        else:
            status = "failed"
            summary = ""
            error = job.error or "Unknown failure"

        # Update rate limit flag based on job outcome
        if error and self._is_rate_limited(error):
            self.rate_limited = True
        elif job.status == "ok":
            self.rate_limited = False

        # Record the task run (always — it's an accurate execution record)
        if run_id:
            self.db.complete_task_run(
                run_id, status=status, ended_at=ended,
                result_summary=summary, error=error,
            )

        # Infrastructure error → reset task to "ready" for automatic retry
        if status == "failed" and self._is_infra_error(job):
            self.db.create_comment(task_id, f"Retrying: {error} (infra failure, not task failure)"[:500], author="system")
            self.db.update_task(task_id, status="ready", started_at=None, completed_at=None)
            task_num = task.task_number or f"#{task_id}"
            logger.info("Task %s reset to ready after infra error: %s", task_num, error)
            return

        # Genuine task result
        if status == "failed":
            self.db.create_comment(task_id, f"Failed: {error}"[:500], author="system")
        else:
            self.db.create_comment(task_id, f"Completed: {summary or 'No summary'}"[:500], author="system")

        task_status = "done" if status == "success" else "failed"
        update_kwargs = dict(status=task_status, completed_at=ended, completed_by="agent")

        # Extract commit hash if present in result
        if summary:
            import re
            match = re.search(r'COMMIT_HASH:\s*([a-f0-9]{7,40})', summary)
            if match:
                update_kwargs["commit_hash"] = match.group(1)
                logger.info("Task #%d commit: %s", task_id, match.group(1))

        self.db.update_task(task_id, **update_kwargs)
        task_num = task.task_number or f"#{task_id}"
        logger.info("Task %s %s via job #%d", task_num, task_status, job.id)

        # Emit event for completed/failed tasks
        if self.event_bus:
            if task_status == "done":
                self.event_bus.emit(NoruEvent(
                    event_type="task.completed",
                    payload={
                        "task_id": task_id,
                        "task_number": task_num,
                        "title": task.title,
                        "project_id": task.project_id,
                        "commit_hash": update_kwargs.get("commit_hash", ""),
                        "summary": summary,
                    },
                ))
            else:
                self.event_bus.emit(NoruEvent(
                    event_type="task.failed",
                    payload={
                        "task_id": task_id,
                        "task_number": task_num,
                        "title": task.title,
                        "project_id": task.project_id,
                        "error": error,
                    },
                ))

    def _process_review_job(self, job: Job) -> None:
        """Extract findings from a completed review job and create tasks."""
        from noru.executor.idle_reviewer import IdleJob

        metadata = json.loads(job.metadata) if job.metadata else {}
        job_id_str = metadata.get("job_id", "unknown")
        idle_job = IdleJob.from_id(job_id_str)

        project = self.db.get_project(job.project_id)
        if not project:
            logger.warning("Job #%d references unknown project %s", job.id, job.project_id)
            return

        # Parse result — stored as JSON string in DB
        try:
            raw = json.loads(job.result) if isinstance(job.result, str) else job.result
        except (json.JSONDecodeError, ValueError):
            raw = job.result

        findings = self.idle_reviewer._parse_findings(raw, idle_job)
        tasks_created = self.idle_reviewer._create_tasks_from_findings(findings, project, idle_job)

        if tasks_created > 0:
            logger.info("Job #%d: created %d tasks from %s review", job.id, tasks_created, idle_job.name)
        else:
            logger.info("Job #%d: no actionable findings from %s review", job.id, idle_job.name)
