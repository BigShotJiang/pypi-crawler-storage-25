"""tmux-based Claude Code controller.

Manages a persistent Claude Code session in a tmux pane.
Sends commands by typing into the terminal, reads responses
by capturing the pane content.
"""

from __future__ import annotations

import logging
import subprocess
import time

logger = logging.getLogger(__name__)

TMUX_SESSION = "noru-worker"
PROMPT_MARKER = "❯"  # Claude Code's prompt character


class TmuxController:
    """Controls a Claude Code session via tmux."""

    def __init__(
        self,
        session_name: str = TMUX_SESSION,
        cwd: str = "~",
        use_superpowers: bool = False,
        permission_mode: str = "auto",
    ):
        self.session_name = session_name
        self.cwd = cwd
        self.use_superpowers = use_superpowers
        self.permission_mode = permission_mode
        self._started = False

    def is_idle(self) -> bool:
        """Check if Claude is idle (showing prompt marker, not processing)."""
        pane = self._capture_pane()
        if not pane:
            return False
        # Check last 5 lines for prompt marker — it may not be the very last line
        # due to input buffer, separator lines, or shortcuts hint
        lines = pane.strip().split("\n")
        last_lines = lines[-5:] if len(lines) >= 5 else lines
        for line in last_lines:
            stripped = line.strip()
            # Busy indicators — definitely not idle
            if any(c in stripped for c in "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏") or "Thinking" in stripped or "Cogitat" in stripped:
                return False
        # Look for prompt marker in last few lines
        for line in last_lines:
            if PROMPT_MARKER in line:
                return True
        return False

    def send_prompt(self, text: str) -> bool:
        """Send text to tmux session. Returns False if Claude is busy."""
        if not self._started:
            return False
        if not self.is_idle():
            logger.warning("Claude is busy — skipping prompt send")
            return False
        # Clear any queued input first (Escape + Ctrl-C)
        self._run_tmux("send-keys", "-t", self.session_name, "Escape")
        import time
        time.sleep(0.3)
        self._run_tmux("send-keys", "-t", self.session_name, "C-c")
        time.sleep(0.3)
        # Send the prompt
        self._run_tmux("send-keys", "-t", self.session_name, "-l", text)
        self._run_tmux("send-keys", "-t", self.session_name, "Enter")
        return True

    def is_alive(self) -> bool:
        return self._started and self._is_session_alive()

    # --- Internal ---

    def _capture_pane(self) -> str:
        """Capture current tmux pane content."""
        result = self._run_tmux(
            "capture-pane", "-t", self.session_name, "-p", "-S", "-100",
        )
        return result.stdout if result.returncode == 0 else ""

    def _is_session_alive(self) -> bool:
        result = self._run_tmux("has-session", "-t", self.session_name)
        return result.returncode == 0

    def _run_tmux(self, *args: str) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                ["tmux", *args],
                capture_output=True, text=True, timeout=10,
            )
        except (subprocess.TimeoutExpired, OSError) as e:
            return subprocess.CompletedProcess(
                args=["tmux", *args], returncode=1,
                stdout="", stderr=str(e),
            )
