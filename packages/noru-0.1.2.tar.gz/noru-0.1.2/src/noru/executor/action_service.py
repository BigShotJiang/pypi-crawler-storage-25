"""ClaudeActionService — unified file-based dispatch for all Claude interactions.

Flow:
1. Caller creates ClaudeAction(prompt, project_id, action_type, ...)
2. Service writes job file to ~/.noru/jobs/job_{timestamp}.json
3. Service sends SHORT tmux command: "Read the job at {path}, execute, update status/result/error/completed_at"
4. Claude reads the prompt from the file, executes, writes result back to the SAME file
5. Service polls file until status != "pending"
6. Returns ActionResult
"""

from __future__ import annotations

import json
import logging
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import TYPE_CHECKING


if TYPE_CHECKING:
    from noru.core.database import Database
    from noru.executor.tmux_controller import TmuxController

logger = logging.getLogger(__name__)

JOBS_DIR = Path.home() / ".noru" / "jobs"


@dataclass
class ClaudeAction:
    """A single action to be executed by Claude Code."""

    prompt: str
    project_id: str
    action_type: str  # task | review | action
    metadata: dict = field(default_factory=dict)
    action_id: str = ""
    status: str = "pending"
    result: str | None = None
    error: str | None = None
    created_at: str = ""
    completed_at: str | None = None

    def __post_init__(self):
        if not self.action_id:
            self.action_id = self._generate_id()
        if not self.created_at:
            self.created_at = datetime.now(timezone.utc).isoformat()

    def _generate_id(self) -> str:
        ts = int(time.time())
        if self.action_type == "task" and "task_id" in self.metadata:
            return f"task_{self.metadata['task_id']}_{ts}"
        elif self.action_type == "review" and "job_id" in self.metadata:
            return f"review_{self.metadata['job_id']}_{ts}"
        else:
            return f"{self.action_type}_{ts}"

    def to_dict(self) -> dict:
        return {
            "action_id": self.action_id,
            "action_type": self.action_type,
            "status": self.status,
            "project_id": self.project_id,
            "prompt": self.prompt,
            "metadata": self.metadata,
            "created_at": self.created_at,
            "result": self.result,
            "error": self.error,
            "completed_at": self.completed_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> ClaudeAction:
        return cls(
            action_id=data["action_id"],
            action_type=data["action_type"],
            status=data.get("status", "pending"),
            project_id=data["project_id"],
            prompt=data.get("prompt", ""),
            metadata=data.get("metadata", {}),
            created_at=data.get("created_at", ""),
            result=data.get("result"),
            error=data.get("error"),
            completed_at=data.get("completed_at"),
        )


@dataclass(frozen=True)
class ActionResult:
    """Result of a completed ClaudeAction."""

    action_id: str
    success: bool
    result: str | list | dict | None
    error: str | None

    @property
    def is_timeout(self) -> bool:
        return not self.success and self.error is not None and "Timeout" in self.error


class ClaudeActionService:
    """Manages the full lifecycle of Claude actions via file-based job handoff."""

    def __init__(
        self,
        jobs_dir: Path | None = None,
        tmux_controller: TmuxController | None = None,
        db: Database | None = None,
    ):
        self.jobs_dir = jobs_dir or JOBS_DIR
        self.tmux_controller = tmux_controller
        self.db = db

    def write_job_file(self, action: ClaudeAction) -> Path:
        self.jobs_dir.mkdir(parents=True, exist_ok=True)
        ts = time.time_ns()
        filepath = self.jobs_dir / f"job_{ts}.json"
        tmp = filepath.with_suffix(".tmp")
        try:
            tmp.write_text(json.dumps(action.to_dict(), indent=2, ensure_ascii=False))
            tmp.rename(filepath)
        except OSError:
            tmp.unlink(missing_ok=True)
            raise
        return filepath

    def poll_result(self, filepath: Path, action_id: str, timeout: int = 300, interval: float = 3) -> ActionResult:
        elapsed = 0.0
        while elapsed < timeout:
            time.sleep(interval)
            elapsed += interval
            try:
                text = filepath.read_text()
                data = json.loads(text)
                # Wait for BOTH status change AND completed_at to be set.
                # Claude edits fields one at a time — status may change to "ok"
                # before result/completed_at are written.
                if data.get("status") != "pending" and data.get("completed_at"):
                    status = data["status"]
                    return ActionResult(
                        action_id=action_id,
                        success=(status == "ok"),
                        result=data.get("result"),
                        error=data.get("error"),
                    )
            except (json.JSONDecodeError, OSError):
                continue
        return ActionResult(action_id=action_id, success=False, result=None, error=f"Timeout after {timeout}s")

    def execute(self, action: ClaudeAction, timeout: int = 300, poll_interval: float = 3) -> ActionResult:
        if not self.tmux_controller or not self.tmux_controller.is_alive():
            return ActionResult(action_id=action.action_id, success=False, result=None, error="Tmux session not alive or not available")
        if not self.tmux_controller.is_idle():
            return ActionResult(action_id=action.action_id, success=False, result=None, error="Claude is busy — cannot send action")

        filepath = self.write_job_file(action)
        tmux_cmd = self._build_tmux_command(filepath)
        sent = self.tmux_controller.send_prompt(tmux_cmd)
        if not sent:
            return ActionResult(action_id=action.action_id, success=False, result=None, error="Failed to send command to tmux")
        return self.poll_result(filepath, action_id=action.action_id, timeout=timeout, interval=poll_interval)

    def dispatch(self, action: ClaudeAction) -> int | None:
        """Write job file + DB row, send to tmux. Returns DB job ID. Non-blocking."""
        if not self.tmux_controller or not self.tmux_controller.is_alive():
            return None
        if not self.tmux_controller.is_idle():
            return None

        filepath = self.write_job_file(action)

        job_id = None
        if self.db:
            job_id = self.db.create_job(
                action_id=action.action_id,
                action_type=action.action_type,
                project_id=action.project_id,
                file_path=str(filepath),
                prompt=action.prompt,
                metadata=json.dumps(action.metadata),
            )

        tmux_cmd = self._build_tmux_command(filepath)
        sent = self.tmux_controller.send_prompt(tmux_cmd)
        if not sent:
            return None

        return job_id

    def _build_tmux_command(self, filepath: Path) -> str:
        return (
            f"Read the job file at {filepath} and execute the prompt inside it. "
            f"When done, update ONLY the status, result, error, and completed_at fields in that same file. "
            f"Set status to 'ok' on success or 'error' on failure. "
            f"CRITICAL: Update ALL four fields (status, result, error, completed_at) in a SINGLE Edit operation — "
            f"do not edit them one at a time."
        )
