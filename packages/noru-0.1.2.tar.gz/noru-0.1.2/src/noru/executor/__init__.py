"""Executor layer — task dispatch and worker management."""
