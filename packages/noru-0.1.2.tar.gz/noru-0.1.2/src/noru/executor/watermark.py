"""Stateless watermark-based queue refill check."""

from __future__ import annotations

DEFAULT_LOW_WATERMARK = 2


def should_refill(
    ready_count: int,
    has_pending_scan: bool,
    low_watermark: int = DEFAULT_LOW_WATERMARK,
) -> bool:
    """Return True when project needs more tasks generated.

    Triggers a background scan when ready tasks drop below the watermark
    and no scan is already in flight.
    """
    return ready_count < low_watermark and not has_pending_scan
