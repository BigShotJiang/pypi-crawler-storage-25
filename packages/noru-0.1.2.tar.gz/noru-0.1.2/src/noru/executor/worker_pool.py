"""WorkerPool — manages N TmuxWorker slots with priority preemption."""

from __future__ import annotations

import logging

from noru.core.config import WorkerPoolConfig
from noru.executor.session_manager import SessionManager
from noru.executor.tmux_worker import TmuxWorker

logger = logging.getLogger(__name__)

JOB_TYPE_PRIORITY = {
    "task": 1,
    "review": 3,
}


class WorkerPool:
    """Manages a pool of TmuxWorker instances with slot allocation."""

    def __init__(
        self,
        config: WorkerPoolConfig,
        session_manager: SessionManager,
    ):
        self.config = config
        self.session_manager = session_manager
        self._workers: dict[str, TmuxWorker] = {}

    @property
    def slots_available(self) -> int:
        return self.config.max_workers - len(self._workers)

    def get_worker(self, project_id: str) -> TmuxWorker | None:
        return self._workers.get(project_id)

    def assign_worker(self, project_id: str, cwd: str) -> TmuxWorker | None:
        if project_id in self._workers:
            return self._workers[project_id]
        if self.slots_available <= 0:
            return None
        worker = TmuxWorker(
            project_id=project_id,
            cwd=cwd,
            session_manager=self.session_manager,
            compact_every=self.config.compact_every,
            reset_after=self.config.reset_after,
        )
        self._workers[project_id] = worker
        logger.info(
            "Assigned worker slot to %s (%d/%d used)",
            project_id, len(self._workers), self.config.max_workers,
        )
        return worker

    def release_worker(self, project_id: str) -> None:
        worker = self._workers.pop(project_id, None)
        if worker:
            worker.pause()
            logger.info(
                "Released worker slot for %s (%d/%d used)",
                project_id, len(self._workers), self.config.max_workers,
            )

    def find_preemptible(self, incoming_type: str) -> str | None:
        incoming_prio = JOB_TYPE_PRIORITY.get(incoming_type, 2)
        candidates = []
        for pid, worker in self._workers.items():
            worker_prio = JOB_TYPE_PRIORITY.get(
                getattr(worker, "current_job_type", "review"), 3,
            )
            if worker_prio > incoming_prio:
                candidates.append((pid, worker_prio))
        if not candidates:
            return None
        candidates.sort(key=lambda x: -x[1])
        return candidates[0][0]

    def active_workers(self) -> list[TmuxWorker]:
        return list(self._workers.values())

    def stop_all(self) -> None:
        for pid in list(self._workers.keys()):
            worker = self._workers.pop(pid)
            worker.stop()
        logger.info("All workers stopped")

    def health_check(self) -> list[str]:
        """Verify tmux sessions are alive, remove dead workers. Returns dead project IDs."""
        dead = [pid for pid, w in self._workers.items() if not w.is_alive()]
        for pid in dead:
            logger.warning("Worker %s: tmux session died — removing", pid)
            self._workers.pop(pid)
        return dead
