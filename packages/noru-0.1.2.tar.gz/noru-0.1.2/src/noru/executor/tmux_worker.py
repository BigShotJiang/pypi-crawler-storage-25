"""TmuxWorker — one tmux session per project with session-id continuity."""

from __future__ import annotations

import logging
import subprocess
import time

from noru.executor.session_manager import SessionManager

logger = logging.getLogger(__name__)

PROMPT_MARKER = "❯"
TRUST_DIALOG_MARKER = "trust this folder"


class TmuxWorker:
    """Manages a single Claude Code tmux session for one project."""

    def __init__(
        self,
        project_id: str,
        cwd: str,
        session_manager: SessionManager,
        compact_every: int = 10,
        reset_after: int = 50,
    ):
        self.project_id = project_id
        self.cwd = cwd
        self.session_manager = session_manager
        self.compact_every = compact_every
        self.reset_after = reset_after
        self._started = False
        self.current_job_id: int | None = None
        self.current_job_type: str = ""

        # Ensure session state exists
        self.session_manager.get_or_create(project_id)

    @property
    def tmux_session_name(self) -> str:
        state = self.session_manager.get_or_create(self.project_id)
        return state.tmux_session

    def _build_claude_command(self, is_continue: bool = False) -> str:
        state = self.session_manager.get_or_create(self.project_id)
        if is_continue:
            return f"claude --continue {state.session_id} --dangerously-skip-permissions"
        return f"claude --session-id {state.session_id} --dangerously-skip-permissions"

    def start(self) -> bool:
        """Start or resume the tmux session with Claude."""
        state = self.session_manager.get_or_create(self.project_id)
        session_name = state.tmux_session

        if self._is_session_alive():
            self._started = True
            return True

        is_continue = state.status == "paused"
        claude_cmd = self._build_claude_command(is_continue=is_continue)

        self._run_tmux("kill-session", "-t", session_name)
        time.sleep(0.3)

        result = self._run_tmux(
            "new-session", "-d", "-s", session_name,
            "-x", "200", "-y", "50",
            "-c", self.cwd,
            claude_cmd,
        )
        if result.returncode != 0:
            logger.error("Failed to start tmux session %s: %s", session_name, result.stderr)
            return False

        trust_accepted = False
        for i in range(30):
            time.sleep(1)
            pane = self._capture_pane()

            # Handle workspace trust dialog (Claude 2.1+)
            if not trust_accepted and TRUST_DIALOG_MARKER in pane.lower():
                logger.info("Worker %s: accepting workspace trust dialog", self.project_id)
                self._run_tmux("send-keys", "-t", session_name, "Enter")
                trust_accepted = True
                continue

            # Only match the idle prompt when NOT in the trust dialog
            if PROMPT_MARKER in pane and TRUST_DIALOG_MARKER not in pane.lower():
                logger.info("Worker %s ready (took %ds)", self.project_id, i + 1)
                self._started = True
                self.session_manager.update(state._replace(status="active"))
                return True

        logger.error("Worker %s: Claude did not start within 30s", self.project_id)
        self._run_tmux("kill-session", "-t", session_name)
        return False

    def pause(self) -> None:
        """Send /exit to Claude, preserving session-id for later resume."""
        if not self._started:
            return
        session_name = self.tmux_session_name
        self._run_tmux("send-keys", "-t", session_name, "/exit", "Enter")
        time.sleep(1)
        self._run_tmux("kill-session", "-t", session_name)
        self._started = False
        self.session_manager.pause(self.project_id)
        logger.info("Worker %s paused (session-id preserved)", self.project_id)

    def stop(self) -> None:
        """Kill the tmux session entirely."""
        session_name = self.tmux_session_name
        if self._is_session_alive():
            self._run_tmux("send-keys", "-t", session_name, "/exit", "Enter")
            time.sleep(1)
            self._run_tmux("kill-session", "-t", session_name)
        self._started = False
        self.session_manager.remove(self.project_id)
        logger.info("Worker %s stopped", self.project_id)

    def send_task(self, prompt: str) -> bool:
        """Send a task prompt to Claude. Handles compact/reset. Returns True if sent."""
        if not self._started:
            return False

        state = self.session_manager.get_or_create(self.project_id)

        # Check reset threshold BEFORE sending
        if state.needs_reset(self.reset_after):
            self._reset_session()
            return False  # caller should retry after restart

        # Send the prompt
        session_name = self.tmux_session_name
        self._run_tmux("send-keys", "-t", session_name, "-l", prompt)
        self._run_tmux("send-keys", "-t", session_name, "Enter")

        # Increment request counter
        state = state.increment_requests()
        self.session_manager.update(state)

        # Check compact threshold AFTER incrementing
        if state.needs_compact(self.compact_every):
            self._send_compact()

        return True

    def send_prompt(self, text: str) -> bool:
        """Send text to tmux, checking idle first. For ClaudeActionService compatibility."""
        if not self._started or not self.is_idle():
            return False
        session_name = self.tmux_session_name
        self._run_tmux("send-keys", "-t", session_name, "Escape")
        time.sleep(0.3)
        self._run_tmux("send-keys", "-t", session_name, "C-c")
        time.sleep(0.3)
        self._run_tmux("send-keys", "-t", session_name, "-l", text)
        self._run_tmux("send-keys", "-t", session_name, "Enter")

        state = self.session_manager.get_or_create(self.project_id)
        state = state.increment_requests()
        self.session_manager.update(state)

        if state.needs_compact(self.compact_every):
            self._send_compact()

        return True

    def is_idle(self) -> bool:
        """Check if Claude is idle (showing prompt marker)."""
        if not self._started:
            return False
        pane = self._capture_pane()
        if not pane:
            return False
        # Never idle if stuck on trust dialog
        if TRUST_DIALOG_MARKER in pane.lower():
            return False
        lines = pane.strip().split("\n")
        last_lines = lines[-5:] if len(lines) >= 5 else lines
        for line in last_lines:
            stripped = line.strip()
            if any(c in stripped for c in "⠋⠙⠹⠸⠼⠴⠦⠧⠇⠏") or "Thinking" in stripped:
                return False
        for line in last_lines:
            if PROMPT_MARKER in line:
                return True
        return False

    def is_alive(self) -> bool:
        return self._started and self._is_session_alive()

    def _send_compact(self) -> None:
        """Send /compact to compress context."""
        session_name = self.tmux_session_name
        for _ in range(30):
            if self.is_idle():
                break
            time.sleep(1)
        self._run_tmux("send-keys", "-t", session_name, "/compact", "Enter")
        state = self.session_manager.get_or_create(self.project_id)
        self.session_manager.update(state.mark_compacted())
        logger.info("Worker %s: sent /compact", self.project_id)

    def _reset_session(self) -> None:
        """Reset: exit, new UUID, restart."""
        logger.info(
            "Worker %s: resetting session (total_requests >= %d)",
            self.project_id, self.reset_after,
        )
        self.pause()
        self.session_manager.reset_session(self.project_id)
        self.start()

    def _capture_pane(self) -> str:
        result = self._run_tmux(
            "capture-pane", "-t", self.tmux_session_name, "-p", "-S", "-100",
        )
        return result.stdout if result.returncode == 0 else ""

    def _is_session_alive(self) -> bool:
        result = self._run_tmux("has-session", "-t", self.tmux_session_name)
        return result.returncode == 0

    def _run_tmux(self, *args: str) -> subprocess.CompletedProcess:
        try:
            return subprocess.run(
                ["tmux", *args],
                capture_output=True, text=True, timeout=10,
            )
        except (subprocess.TimeoutExpired, OSError) as e:
            return subprocess.CompletedProcess(
                args=["tmux", *args], returncode=1,
                stdout="", stderr=str(e),
            )
