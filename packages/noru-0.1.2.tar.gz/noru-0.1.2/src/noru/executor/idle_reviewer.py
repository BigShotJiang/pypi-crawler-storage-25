# src/noru/executor/idle_reviewer.py
"""Idle reviewer with 16 configurable review jobs."""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass

from noru.core.config import NoruConfig
from noru.core.constants import IDLE_JOB_META, LANGUAGE_MAP
from noru.core.database import Database
from noru.core.models import Project
from noru.executor.action_service import ClaudeAction, ClaudeActionService

logger = logging.getLogger(__name__)

# L1: System Identity — hardcoded, always first
SYSTEM_IDENTITY = (
    "You are a senior software engineer working autonomously on this project. "
    "You have access to the full codebase via the filesystem. "
    "You are already in the project directory."
)

# L7: Output Contract — always last, immutable
OUTPUT_CONTRACT = (
    "Identify up to {max_tasks} issues.\n"
    "Group related small issues into ONE finding when possible.\n\n"
    "Output ONLY a JSON array. Each item MUST have these fields:\n"
    '{{"file": "path/to/file.py", "line": 42, "issue": "Short title", '
    '"description": "Detailed description", "severity": "high|medium|low", '
    '"suggestion": "Specific actionable fix"}}\n\n'
    "If no issues found, output: []\n"
    "Output ONLY the JSON array, nothing else."
)


@dataclass(frozen=True)
class IdleJob:
    id: str
    name: str
    weight: str
    description: str

    @classmethod
    def from_id(cls, job_id: str) -> IdleJob:
        meta = IDLE_JOB_META.get(job_id, {})
        return cls(
            id=job_id,
            name=meta.get("name", job_id),
            weight=meta.get("weight", "light"),
            description=meta.get("description", ""),
        )


class IdleReviewer:
    def __init__(
        self, config: NoruConfig,
        action_service: ClaudeActionService | None = None,
        db: Database | None = None,
    ):
        self.config = config
        self.action_service = action_service
        self.db = db
        self._job_index = 0

    def has_pending_jobs(self) -> bool:
        """Check if there are enabled jobs that haven't been run in current cycle."""
        enabled = self.enabled_jobs()
        return len(enabled) > 0 and self._job_index < len(enabled)

    def enabled_jobs(self) -> list[IdleJob]:
        jobs = []
        for entry in self.config.idle_jobs.jobs:
            if not entry.enabled:
                continue
            meta = IDLE_JOB_META.get(entry.id, {})
            jobs.append(IdleJob(
                id=entry.id,
                name=meta.get("name", entry.id),
                weight=entry.weight or meta.get("weight", "light"),
                description=entry.description or meta.get("description", ""),
            ))
        return jobs

    def next_job(self) -> IdleJob:
        enabled = self.enabled_jobs()
        if not enabled:
            raise StopIteration("No enabled idle jobs")
        job = enabled[self._job_index % len(enabled)]
        self._job_index += 1
        return job

    def run_review(self, project: Project) -> int | None:
        """Dispatch a review job. Returns DB job ID (or None). Non-blocking."""
        enabled = self.enabled_jobs()
        if not enabled:
            return None

        if not self.action_service:
            return None

        job = self.next_job()

        prompt = self._build_prompt(job, project)

        action = ClaudeAction(
            action_type="review",
            prompt=prompt,
            project_id=project.id,
            metadata={"job_id": job.id},
        )

        job_id = self.action_service.dispatch(action)
        if job_id:
            logger.info("Dispatched idle review: %s on project %s (job #%d)", job.name, project.id, job_id)
        else:
            logger.warning("Failed to dispatch idle review: %s on project %s", job.name, project.id)

        return job_id

    def _parse_findings(self, raw, job: IdleJob) -> list[dict]:
        """Parse findings from Claude's response — handles list, dict, or string."""
        findings: list[dict] = []

        # If result is already a list (Claude wrote JSON array to job file)
        if isinstance(raw, list):
            findings = raw
        elif isinstance(raw, dict):
            findings = raw.get("findings", [])
        elif isinstance(raw, str):
            try:
                data = json.loads(raw)
                if isinstance(data, list):
                    findings = data
                elif isinstance(data, dict) and "findings" in data:
                    findings = data["findings"]
            except (json.JSONDecodeError, ValueError):
                match = re.search(r'\[[\s\S]*\]', raw)
                if match:
                    try:
                        findings = json.loads(match.group())
                    except (json.JSONDecodeError, ValueError):
                        pass

        # Fallback: treat entire output as a single finding description
        if not findings and isinstance(raw, str) and len(raw.strip()) > 50:
            findings = [{
                "file": "",
                "line": 0,
                "issue": f"{job.name} findings",
                "description": raw[:2000],
                "severity": "medium",
                "suggestion": "",
            }]

        return findings

    def _create_tasks_from_findings(self, findings: list[dict], project: Project, job: IdleJob) -> int:
        """Create task records from parsed JSON findings. Skips duplicates."""
        if not self.db:
            return 0

        # Build dedup index from existing open tasks
        existing = self.db.list_tasks(project_id=project.id)
        open_tasks = [t for t in existing if t.status not in ("done", "archived")]
        existing_titles = {t.title for t in open_tasks}
        # Extract file+line fingerprints from existing task descriptions
        existing_fingerprints: set[str] = set()
        for t in open_tasks:
            fp = self._extract_fingerprint(t.description, t.source_type)
            if fp:
                existing_fingerprints.add(fp)

        count = 0
        for finding in findings[:self.config.idle_jobs.max_tasks_per_run]:
            title = finding.get("issue", finding.get("title", f"{job.name} finding"))
            desc = finding.get("description", "")
            file_path = finding.get("file", "")
            line = finding.get("line", 0)
            severity = finding.get("severity", "medium")
            suggestion = finding.get("suggestion", finding.get("fix", ""))

            title = f"[{job.name}] {title}"[:200]
            source_type = self._job_source_type(job.id)

            # Dedup: check file+line fingerprint (catches same issue with different wording)
            fingerprint = f"{file_path}:{line}:{source_type}" if file_path else ""
            if fingerprint and fingerprint in existing_fingerprints:
                logger.debug("Skipping duplicate (file+line match): %s", fingerprint)
                continue

            # Dedup: check file+job_type (same file flagged by same review = likely same issue)
            file_fingerprint = f"{file_path}::{source_type}" if file_path else ""
            if file_fingerprint and file_fingerprint in existing_fingerprints:
                logger.debug("Skipping duplicate (file+type match): %s", file_fingerprint)
                continue

            # Dedup: exact title match (fallback for findings without file paths)
            if title in existing_titles:
                logger.debug("Skipping duplicate (title match): %s", title[:80])
                continue

            priority = {"high": 1, "medium": 3, "low": 5}.get(severity, 3)

            full_desc = desc
            if file_path:
                full_desc += f"\n\nFile: {file_path}"
            if line:
                full_desc += f"\nLine: {line}"
            full_desc += f"\nSeverity: {severity}"
            if suggestion:
                full_desc += f"\n\nSuggested fix:\n{suggestion}"

            initial_status = "ready" if self.config.auto_ready else "todo"
            self.db.create_task(
                project_id=project.id,
                title=title,
                description=full_desc.strip(),
                priority=priority,
                token_weight=job.weight,
                auto_generated=True,
                source_type=source_type,
                status=initial_status,
            )
            # Update dedup sets for this batch
            existing_titles.add(title)
            if fingerprint:
                existing_fingerprints.add(fingerprint)
            if file_fingerprint:
                existing_fingerprints.add(file_fingerprint)
            count += 1

        return count

    @staticmethod
    def _extract_fingerprint(description: str, source_type: str) -> str:
        """Extract file+line fingerprint from task description for dedup."""
        if not description:
            return ""
        file_match = re.search(r'File:\s*(.+)', description)
        line_match = re.search(r'Line:\s*(\d+)', description)
        if file_match:
            file_path = file_match.group(1).strip()
            line = line_match.group(1) if line_match else "0"
            return f"{file_path}:{line}:{source_type}"
        return ""

    @staticmethod
    def _job_source_type(job_id: str) -> str:
        """Map job ID to source_type for the task."""
        mapping = {
            "security-deep": "security",
            "env-secrets": "security",
            "bug-detection": "bug",
            "error-handling": "bug",
            "dead-code": "refactor",
            "architecture": "refactor",
            "code-clarity": "refactor",
            "test-gaps": "test",
            "performance": "refactor",
            "devops": "review",
            "deployment-config": "review",
            "frontend": "review",
            # legacy / custom job IDs
            "refactor": "refactor",
            "code-quality": "review",
            "logic-review": "review",
            "ui-bug-scan": "bug",
            "ux-review": "review",
            "perf-audit": "refactor",
            "docs-update": "review",
            "pr-review": "review",
        }
        return mapping.get(job_id, "review")

    def _build_project_context(self, project: Project) -> str:
        """L2: Project context from DB."""
        return (
            f"Project: {project.name}\n"
            f"Description: {project.description}"
        )

    def _build_cycle_context(self, project: Project) -> str:
        """L3: Recent completed tasks — prevents duplicate findings."""
        if not self.db:
            return ""
        tasks = self.db.list_tasks(project_id=project.id, status="done")
        if not tasks:
            return ""
        # Show last 10 completed tasks
        recent = tasks[:10]
        lines = ["Already fixed (do not re-report these):"]
        for t in recent:
            lines.append(f"- {t.task_number or ''}: {t.title}")
        return "\n".join(lines)

    def _build_guardrails_block(self) -> str:
        """L5: Guardrails block from config."""
        rules = self.config.guardrails
        if not rules:
            return ""
        lines = ["STRICT BOUNDARIES — You MUST NOT violate these rules:"]
        for rule in rules:
            lines.append(f"- {rule}")
        lines.append("Do not suggest changes that violate the above.")
        return "\n".join(lines)

    def _build_language_block(self) -> str:
        """L6: Language instruction."""
        if self.config.language == "en":
            return ""
        lang_name = LANGUAGE_MAP.get(self.config.language, self.config.language)
        block = (
            f"IMPORTANT: Respond ENTIRELY in {lang_name}. "
            f"All output — issue titles, descriptions, suggestions — must be in {lang_name}."
        )
        if self.config.english_commits:
            block += "\nException: Git commit messages must always be in English."
        return block

    def _build_prompt(self, job: IdleJob, project: Project) -> str:
        """Build prompt using 7-layer architecture. Output contract is always last."""
        parts = []

        # L1: System Identity (hardcoded)
        parts.append(SYSTEM_IDENTITY)

        # L2: Project Context
        parts.append(self._build_project_context(project))

        # L3: Cycle Context (completed tasks — don't re-report)
        cycle_ctx = self._build_cycle_context(project)
        if cycle_ctx:
            parts.append(cycle_ctx)

        # L4: Focus Directive
        parts.append(job.description)

        # L5: Guardrails (configurable + toggle)
        if self.config.guardrails_enabled:
            guardrails = self._build_guardrails_block()
            if guardrails:
                parts.append(guardrails)

        # L6: Language
        lang = self._build_language_block()
        if lang:
            parts.append(lang)

        # L7: Output Contract (ALWAYS LAST — immutable)
        parts.append(OUTPUT_CONTRACT.format(max_tasks=self.config.idle_jobs.max_tasks_per_run))

        return "\n\n".join(parts)
