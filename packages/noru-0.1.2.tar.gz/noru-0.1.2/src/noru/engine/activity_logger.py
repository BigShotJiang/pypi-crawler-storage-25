"""Activity logger — subscribes to EventBus and persists events to DB."""

from __future__ import annotations

import json
import logging

from noru.core.database import Database
from noru.engine.events import NoruEvent

logger = logging.getLogger(__name__)


class ActivityLogger:
    name = "activity_logger"

    def __init__(self, db: Database):
        self.db = db

    def handle(self, event: NoruEvent) -> None:
        try:
            self.db.log_activity(
                event_type=event.event_type,
                description=self._describe(event),
                entity_type=self._entity_type(event),
                entity_id=event.payload.get("task_number", ""),
                project_id=event.payload.get("project_id", ""),
                metadata=json.dumps(event.payload),
            )
        except Exception:
            logger.exception("Failed to log activity for event %s", event.event_type)

    def _describe(self, event: NoruEvent) -> str:
        d = event.payload
        task = d.get("task_number", d.get("task_id", ""))
        match event.event_type:
            case "task.completed":
                return f"Task {task} completed — {d.get('summary', '')[:100]}"
            case "task.failed":
                return f"Task {task} failed — {d.get('error', '')[:100]}"
            case "agent.started":
                return "Agent started"
            case "agent.stopped":
                return f"Agent stopped by {d.get('stopped_by', 'unknown')}"
            case "review.completed":
                return f"Review completed for {d.get('project_id', '')} — {d.get('tasks_created', 0)} issues found"
            case _:
                return f"{event.event_type}: {json.dumps(d)[:200]}"

    def _entity_type(self, event: NoruEvent) -> str:
        if event.event_type.startswith("task."):
            return "task"
        if event.event_type.startswith("agent."):
            return "agent"
        if event.event_type.startswith("review."):
            return "review"
        return ""
