"""Real usage data from Anthropic.

Primary method: tmux-based — spawns a claude session in a tmux pane,
sends /usage, parses the terminal output. No rate limits.

Fallback: HTTP API at /api/oauth/usage (rate limited to ~5 req then 429).

Cache: file-based at ~/.noru/usage_cache.json, shared across all processes.
"""

from __future__ import annotations

import json
import logging
import re
import subprocess
import threading
import time
from dataclasses import dataclass
from pathlib import Path

import urllib.request
import urllib.error

logger = logging.getLogger(__name__)

USAGE_API_URL = "https://api.anthropic.com/api/oauth/usage"
CACHE_TTL_SECONDS = 300  # 5 minutes
CACHE_FILE = Path.home() / ".noru" / "usage_cache.json"
TMUX_SESSION = "noru-usage"
_fetch_lock = threading.Lock()


@dataclass(frozen=True)
class UsageData:
    session_pct: float
    session_resets_at: str
    weekly_pct: float
    weekly_resets_at: str
    weekly_sonnet_pct: float | None = None
    weekly_sonnet_resets_at: str | None = None
    weekly_opus_pct: float | None = None
    weekly_opus_resets_at: str | None = None
    error: str | None = None
    last_updated: str = ""

    @property
    def session_remaining_pct(self) -> float:
        return max(0.0, 100.0 - self.session_pct)

    @property
    def weekly_remaining_pct(self) -> float:
        return max(0.0, 100.0 - self.weekly_pct)


class UsageAPI:
    def __init__(self):
        self._token_cache: str | None = None
        self._token_cache_time: float = 0

    def get_usage(self) -> UsageData:
        cached = self._read_cache()
        if cached is not None:
            return cached

        acquired = _fetch_lock.acquire(blocking=False)
        if not acquired:
            stale = self._read_stale_cache()
            return stale or UsageData(
                session_pct=0, session_resets_at="",
                weekly_pct=0, weekly_resets_at="",
                error="Waiting for usage fetch...",
            )
        try:
            cached = self._read_cache()
            if cached is not None:
                return cached

            # Primary: tmux-based (no rate limit)
            result = self._fetch_via_tmux()
            if result and result.error is None:
                self._write_cache(result)
                return result

            # Fallback: HTTP API
            logger.info("tmux method failed, trying HTTP API...")
            result = self._fetch_via_api()
            self._write_cache(result) if result.error is None else self._extend_cache_ttl()
            return result
        finally:
            _fetch_lock.release()

    def _fetch_via_tmux(self) -> UsageData | None:
        """Spawn claude in tmux, send /usage, parse output."""
        try:
            # Check tmux is available
            if subprocess.run(["which", "tmux"], capture_output=True).returncode != 0:
                logger.debug("tmux not available")
                return None

            # Kill any existing session
            subprocess.run(["tmux", "kill-session", "-t", TMUX_SESSION],
                           capture_output=True, timeout=5)
            time.sleep(0.5)

            # Start claude in detached tmux
            subprocess.run(
                ["tmux", "new-session", "-d", "-s", TMUX_SESSION, "-x", "200", "-y", "50", "claude"],
                capture_output=True, timeout=10,
            )

            # Wait for claude to start
            time.sleep(8)

            # Send /usage
            subprocess.run(["tmux", "send-keys", "-t", TMUX_SESSION, "/usage", "Enter"],
                           capture_output=True, timeout=5)

            # Wait for response
            time.sleep(4)

            # Capture output
            result = subprocess.run(
                ["tmux", "capture-pane", "-t", TMUX_SESSION, "-p", "-S", "-50"],
                capture_output=True, text=True, timeout=5,
            )
            output = result.stdout

            # Quit claude and kill session
            subprocess.run(["tmux", "send-keys", "-t", TMUX_SESSION, "Escape"],
                           capture_output=True, timeout=3)
            time.sleep(1)
            subprocess.run(["tmux", "send-keys", "-t", TMUX_SESSION, "/quit", "Enter"],
                           capture_output=True, timeout=3)
            time.sleep(2)
            subprocess.run(["tmux", "kill-session", "-t", TMUX_SESSION],
                           capture_output=True, timeout=5)

            # Parse the output
            usage = self._parse_usage_output(output)
            if usage:
                logger.info(
                    "Usage via tmux: session=%.1f%%, weekly=%.1f%%",
                    usage.session_pct, usage.weekly_pct,
                )
                return usage
            logger.warning("Could not parse /usage output from tmux")
            return None

        except Exception as e:
            logger.warning("tmux usage fetch failed: %s", e)
            # Clean up
            subprocess.run(["tmux", "kill-session", "-t", TMUX_SESSION],
                           capture_output=True, timeout=5)
            return None

    def _parse_usage_output(self, output: str) -> UsageData | None:
        """Parse /usage terminal output into UsageData."""
        # Pattern: "N% used" after each label
        session_match = re.search(
            r"Current session.*?(\d+)% used.*?Resets\s+(.+?)(?:\n|$)", output, re.DOTALL
        )
        weekly_match = re.search(
            r"Current week \(all models\).*?(\d+)% used.*?Resets\s+(.+?)(?:\n|$)", output, re.DOTALL
        )
        sonnet_match = re.search(
            r"Current week \(Sonnet only\).*?(\d+)% used.*?Resets\s+(.+?)(?:\n|$)", output, re.DOTALL
        )

        if not session_match or not weekly_match:
            return None

        return UsageData(
            session_pct=float(session_match.group(1)),
            session_resets_at=session_match.group(2).strip(),
            weekly_pct=float(weekly_match.group(1)),
            weekly_resets_at=weekly_match.group(2).strip(),
            weekly_sonnet_pct=float(sonnet_match.group(1)) if sonnet_match else None,
            weekly_sonnet_resets_at=sonnet_match.group(2).strip() if sonnet_match else None,
        )

    def _fetch_via_api(self) -> UsageData:
        """Fallback: HTTP API (may be rate limited)."""
        logger.info("Fetching usage from Anthropic API...")
        token = self._get_oauth_token()
        if not token:
            return UsageData(
                session_pct=0, session_resets_at="",
                weekly_pct=0, weekly_resets_at="",
                error="OAuth token not found. Run 'claude /login'.",
            )

        try:
            req = urllib.request.Request(
                USAGE_API_URL,
                headers={
                    "Authorization": f"Bearer {token}",
                    "anthropic-beta": "oauth-2025-04-20",
                },
            )
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                logger.info("Usage API OK: session=%.1f%%, weekly=%.1f%%",
                            (data.get("five_hour") or {}).get("utilization", 0),
                            (data.get("seven_day") or {}).get("utilization", 0))
        except urllib.error.HTTPError as e:
            logger.warning("Usage API HTTP %d", e.code)
            stale = self._read_stale_cache()
            if stale:
                return stale
            return UsageData(
                session_pct=0, session_resets_at="",
                weekly_pct=0, weekly_resets_at="",
                error=f"API error {e.code}",
            )
        except Exception as e:
            logger.warning("Usage API failed: %s", e)
            stale = self._read_stale_cache()
            if stale:
                return stale
            return UsageData(
                session_pct=0, session_resets_at="",
                weekly_pct=0, weekly_resets_at="",
                error=str(e),
            )

        five_hour = data.get("five_hour") or {}
        seven_day = data.get("seven_day") or {}
        seven_day_sonnet = data.get("seven_day_sonnet") or {}
        seven_day_opus = data.get("seven_day_opus") or {}

        return UsageData(
            session_pct=five_hour.get("utilization", 0) or 0,
            session_resets_at=five_hour.get("resets_at", ""),
            weekly_pct=seven_day.get("utilization", 0) or 0,
            weekly_resets_at=seven_day.get("resets_at", ""),
            weekly_sonnet_pct=seven_day_sonnet.get("utilization") if seven_day_sonnet else None,
            weekly_sonnet_resets_at=seven_day_sonnet.get("resets_at") if seven_day_sonnet else None,
            weekly_opus_pct=seven_day_opus.get("utilization") if seven_day_opus else None,
            weekly_opus_resets_at=seven_day_opus.get("resets_at") if seven_day_opus else None,
        )

    # --- Cache ---

    def _read_cache(self) -> UsageData | None:
        try:
            if not CACHE_FILE.exists():
                return None
            data = json.loads(CACHE_FILE.read_text())
            cached_at = data.get("cached_at", 0)
            if (time.time() - cached_at) > CACHE_TTL_SECONDS:
                return None
            return UsageData(
                session_pct=data.get("session_pct", 0),
                session_resets_at=data.get("session_resets_at", ""),
                weekly_pct=data.get("weekly_pct", 0),
                weekly_resets_at=data.get("weekly_resets_at", ""),
                weekly_sonnet_pct=data.get("weekly_sonnet_pct"),
                weekly_opus_pct=data.get("weekly_opus_pct"),
                error=data.get("error"),
                last_updated=data.get("last_updated", ""),
            )
        except (json.JSONDecodeError, OSError):
            return None

    def _write_cache(self, usage: UsageData) -> None:
        try:
            CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
            now = time.time()
            from datetime import datetime, timezone
            ts = datetime.fromtimestamp(now, tz=timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
            data = {
                "session_pct": usage.session_pct,
                "session_resets_at": usage.session_resets_at,
                "weekly_pct": usage.weekly_pct,
                "weekly_resets_at": usage.weekly_resets_at,
                "weekly_sonnet_pct": usage.weekly_sonnet_pct,
                "weekly_opus_pct": usage.weekly_opus_pct,
                "cached_at": now,
                "last_updated": ts,
            }
            CACHE_FILE.write_text(json.dumps(data, indent=2))
        except OSError as e:
            logger.warning("Could not write usage cache: %s", e)

    def _extend_cache_ttl(self) -> None:
        try:
            if not CACHE_FILE.exists():
                CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
                CACHE_FILE.write_text(json.dumps({"cached_at": time.time(), "error": "no data yet"}))
                return
            data = json.loads(CACHE_FILE.read_text())
            data["cached_at"] = time.time()
            CACHE_FILE.write_text(json.dumps(data, indent=2))
        except (json.JSONDecodeError, OSError):
            pass

    def _read_stale_cache(self) -> UsageData | None:
        try:
            if not CACHE_FILE.exists():
                return None
            data = json.loads(CACHE_FILE.read_text())
            if data.get("error"):
                return None  # Don't return error-only cache
            return UsageData(
                session_pct=data.get("session_pct", 0),
                session_resets_at=data.get("session_resets_at", ""),
                weekly_pct=data.get("weekly_pct", 0),
                weekly_resets_at=data.get("weekly_resets_at", ""),
                weekly_sonnet_pct=data.get("weekly_sonnet_pct"),
                weekly_opus_pct=data.get("weekly_opus_pct"),
                last_updated=data.get("last_updated", ""),
            )
        except (json.JSONDecodeError, OSError):
            return None

    # --- OAuth Token ---

    def _get_oauth_token(self) -> str | None:
        now = time.time()
        if self._token_cache and (now - self._token_cache_time) < 300:
            return self._token_cache
        try:
            result = subprocess.run(
                ["security", "find-generic-password", "-s", "Claude Code-credentials", "-w"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode != 0:
                return None
            creds = json.loads(result.stdout.strip())
            token = creds.get("claudeAiOauth", {}).get("accessToken")
            self._token_cache = token
            self._token_cache_time = now
            return token
        except (subprocess.TimeoutExpired, json.JSONDecodeError, OSError) as e:
            logger.warning("Could not read OAuth token: %s", e)
            return None


# Module-level singleton
_shared_instance: UsageAPI | None = None


def get_shared_usage_api() -> UsageAPI:
    global _shared_instance
    if _shared_instance is None:
        _shared_instance = UsageAPI()
    return _shared_instance
