"""Tunnel manager — spawns cloudflared or ngrok for remote dashboard access."""

from __future__ import annotations

import json
import logging
import re
import subprocess
import threading
import time

logger = logging.getLogger(__name__)


class TunnelManager:
    """Manages a tunnel subprocess for remote dashboard access."""

    def __init__(self):
        self._process: subprocess.Popen | None = None
        self._url: str | None = None
        self._provider: str | None = None

    @property
    def is_running(self) -> bool:
        return self._process is not None and self._process.poll() is None

    def get_url(self) -> str | None:
        return self._url if self.is_running else None

    def start(self, provider: str, local_port: int) -> str | None:
        """Start tunnel. Returns public URL or None on failure."""
        self.stop()
        self._provider = provider
        if provider == "cloudflared":
            return self._start_cloudflared(local_port)
        elif provider == "ngrok":
            return self._start_ngrok(local_port)
        else:
            logger.error("Unknown tunnel provider: %s", provider)
            return None

    def stop(self) -> None:
        if self._process:
            try:
                self._process.terminate()
                self._process.wait(timeout=5)
            except (ProcessLookupError, subprocess.TimeoutExpired):
                if self._process:
                    self._process.kill()
            self._process = None
        self._url = None
        self._provider = None

    def _start_cloudflared(self, port: int) -> str | None:
        try:
            self._process = subprocess.Popen(
                ["cloudflared", "tunnel", "--url", f"http://localhost:{port}"],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            )
        except FileNotFoundError:
            logger.error("cloudflared not found")
            return None

        for _ in range(30):
            line = self._process.stderr.readline()
            url = self._parse_cloudflared_output(line)
            if url:
                self._url = url
                threading.Thread(target=self._drain, args=(self._process.stderr,), daemon=True).start()
                logger.info("Cloudflared tunnel active: %s", url)
                return url
            if self._process.poll() is not None:
                break
        logger.error("Failed to get cloudflared tunnel URL within 30s")
        self.stop()
        return None

    def _start_ngrok(self, port: int) -> str | None:
        try:
            self._process = subprocess.Popen(
                ["ngrok", "http", str(port), "--log=stdout"],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
            )
        except FileNotFoundError:
            logger.error("ngrok not found")
            return None

        time.sleep(2)
        for _ in range(15):
            try:
                import urllib.request
                resp = urllib.request.urlopen("http://localhost:4040/api/tunnels", timeout=2)
                data = json.loads(resp.read())
                for t in data.get("tunnels", []):
                    if t.get("public_url", "").startswith("https://"):
                        self._url = t["public_url"]
                        logger.info("ngrok tunnel active: %s", self._url)
                        return self._url
            except Exception:
                pass
            time.sleep(1)
        logger.error("Failed to get ngrok tunnel URL within 15s")
        self.stop()
        return None

    def _parse_cloudflared_output(self, line: str) -> str | None:
        match = re.search(r'(https://[a-z0-9-]+\.trycloudflare\.com)', line)
        return match.group(1) if match else None

    @staticmethod
    def _drain(stream):
        try:
            for _ in stream:
                pass
        except Exception:
            pass
