"""7-day rolling weekly budget tracker."""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone, timedelta
from pathlib import Path

from noru.core.models import WeeklyBudget

logger = logging.getLogger(__name__)


class WeeklyTracker:
    WEEK_SECONDS = 7 * 24 * 3600

    def __init__(
        self, jsonl_dir: Path, weekly_limit: int = 1_500_000,
        developer_reserve_pct: float = 0.35,
    ):
        self.jsonl_dir = jsonl_dir
        self.weekly_limit = weekly_limit
        self.developer_reserve_pct = developer_reserve_pct

    def tokens_used_this_week(self) -> int:
        cutoff = datetime.now(timezone.utc) - timedelta(seconds=self.WEEK_SECONDS)
        total = 0
        if not self.jsonl_dir.exists():
            return 0
        # Only read direct children of project dirs (not subagent subdirectories).
        for project_dir in self.jsonl_dir.iterdir():
            if not project_dir.is_dir():
                continue
            for jsonl_file in project_dir.iterdir():
                if jsonl_file.is_file() and jsonl_file.suffix == ".jsonl":
                    total += self._sum_tokens_since(jsonl_file, cutoff)
        return total

    def budget(self) -> WeeklyBudget:
        return WeeklyBudget(
            total_used=self.tokens_used_this_week(),
            weekly_limit=self.weekly_limit,
            developer_reserve_pct=self.developer_reserve_pct,
        )

    def _sum_tokens_since(self, jsonl_file: Path, cutoff: datetime) -> int:
        total = 0
        try:
            with open(jsonl_file) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        continue
                    ts_str = entry.get("timestamp", "")
                    if not ts_str:
                        continue
                    try:
                        ts = datetime.fromisoformat(ts_str)
                        if ts.tzinfo is None:
                            ts = ts.replace(tzinfo=timezone.utc)
                    except ValueError:
                        continue
                    if ts < cutoff:
                        continue

                    usage = {}
                    msg = entry.get("message")
                    if isinstance(msg, dict):
                        usage = msg.get("usage", {})
                    if not usage:
                        usage = entry.get("usage", {})
                    if not usage:
                        continue

                    inp = usage.get("input_tokens", 0) or 0
                    out = usage.get("output_tokens", 0) or 0
                    cc = usage.get("cache_creation_input_tokens", 0) or 0
                    # cache_read is excluded from quota (not counted by Anthropic)
                    total += inp + out + cc
        except OSError:
            logger.warning("Cannot read JSONL file: %s", jsonl_file)
        return total
