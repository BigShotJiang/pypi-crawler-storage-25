"""Scheduler decision matrix — dispatch or sleep."""

from __future__ import annotations

from dataclasses import dataclass

from noru.core.models import WeeklyBudget, WindowStatus
from noru.engine.queue_manager import max_weight_for_budget


@dataclass(frozen=True)
class SchedulerDecision:
    action: str  # "dispatch", "sleep", "create_only", "idle"
    max_weight: str | None = None
    reason: str = ""


class Scheduler:
    def decide(
        self,
        window: WindowStatus,
        weekly: WeeklyBudget,
        queue_depth: int,
        *,
        max_session_pct: float = 80.0,
        max_weekly_pct: float = 90.0,
        rate_limited: bool = False,
    ) -> SchedulerDecision:
        if rate_limited:
            return SchedulerDecision(action="sleep", reason="Rate limited — backing off")

        pct = window.pct_remaining

        # Session usage check
        session_used_pct = (1.0 - pct) * 100
        if session_used_pct >= max_session_pct:
            return SchedulerDecision(action="sleep", reason=f"Session usage {session_used_pct:.0f}% >= limit {max_session_pct:.0f}%")

        # Weekly usage check
        if weekly.weekly_limit > 0:
            weekly_used_pct = (weekly.total_used / weekly.weekly_limit) * 100
            if weekly_used_pct >= max_weekly_pct:
                return SchedulerDecision(action="sleep", reason=f"Weekly usage {weekly_used_pct:.0f}% >= limit {max_weekly_pct:.0f}%")

        # Window remaining check
        if pct < 0.10:
            return SchedulerDecision(action="sleep", reason="Window < 10% remaining")

        # Weekly budget critically low
        if weekly.agent_budget_remaining < 50_000:
            return SchedulerDecision(action="sleep", reason=f"Weekly budget critically low ({weekly.agent_budget_remaining} tokens remaining)")

        # Budget weight gate
        weight = max_weight_for_budget(window, weekly)
        if weight is None:
            return SchedulerDecision(action="create_only", reason="Budget too low for dispatch")

        # Has tasks? Dispatch.
        if queue_depth > 0:
            return SchedulerDecision(action="dispatch", max_weight=weight, reason=f"Queue depth {queue_depth}, max weight {weight}")

        # No tasks — idle (orchestrator will trigger watermark refill)
        return SchedulerDecision(action="idle", max_weight=weight, reason="Queue empty")
