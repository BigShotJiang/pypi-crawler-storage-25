"""Budget-aware task priority queue."""

from __future__ import annotations

from noru.core.database import Database
from noru.core.models import Task, WeeklyBudget, WindowStatus


def max_weight_for_budget(window: WindowStatus, weekly: WeeklyBudget) -> str | None:
    pct = window.pct_remaining
    agent_remaining = weekly.agent_budget_remaining

    if agent_remaining < 50_000:
        return None
    if agent_remaining < 100_000:
        return "light"

    if pct < 0.10:
        return None
    if pct < 0.15:
        return None
    if pct < 0.40:
        return "light"
    if pct < 0.60:
        return "medium"

    if agent_remaining < 200_000:
        return "medium"
    return "heavy"


class QueueManager:
    def __init__(self, db: Database):
        self.db = db

    def next_eligible(self, window: WindowStatus, weekly: WeeklyBudget, project_id: str | None = None) -> Task | None:
        weight = max_weight_for_budget(window, weekly)
        if weight is None:
            return None
        return self.db.get_next_eligible_task(weight, project_id)
