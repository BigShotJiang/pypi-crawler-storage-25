"""Webhook event handler — sends HTTP POST on matching events."""

from __future__ import annotations

import json
import logging

from noru.engine.events import NoruEvent

logger = logging.getLogger(__name__)


class WebhookHandler:
    """Sends event payloads to a webhook URL via HTTP POST."""

    def __init__(self, url: str, events: list[str] | None = None, body_template: str | None = None):
        self.name = f"webhook:{url[:50]}"
        self.url = url
        self.events = events or ["*"]
        self.body_template = body_template

    def handle(self, event: NoruEvent) -> None:
        if not self._matches(event.event_type):
            return
        try:
            import httpx
            body = self._build_body(event)
            httpx.post(self.url, content=body, headers={"Content-Type": "application/json"}, timeout=5)
        except Exception:
            logger.exception("Webhook %s failed for %s", self.url[:50], event.event_type)

    def _matches(self, event_type: str) -> bool:
        return "*" in self.events or event_type in self.events

    def _build_body(self, event: NoruEvent) -> str:
        if not self.body_template:
            return json.dumps({
                "event_type": event.event_type,
                "timestamp": event.timestamp,
                **event.payload,
            })
        result = self.body_template
        all_fields = {"event_type": event.event_type, "timestamp": event.timestamp, **event.payload}
        for key, value in all_fields.items():
            result = result.replace(f"{{{{{key}}}}}", str(value))
        return result
