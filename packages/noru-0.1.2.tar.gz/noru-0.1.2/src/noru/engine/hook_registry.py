"""Hook registry — discovers and loads integration hooks from the hooks directory."""

from __future__ import annotations

import importlib
import importlib.util
import logging
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)

HOOKS_DIR = Path(__file__).parent.parent / "integrations" / "hooks"


@dataclass(frozen=True)
class HookMeta:
    name: str
    slug: str
    description: str
    config_schema: list[dict] = field(default_factory=list)
    module_path: str = ""


class HookRegistry:
    """Discovers hook plugins and loads them with config."""

    def __init__(self, hooks_dir: Path | None = None):
        self._hooks_dir = hooks_dir or HOOKS_DIR
        self._meta_cache: list[HookMeta] | None = None
        self._classes: dict[str, type] = {}

    def discover(self) -> list[HookMeta]:
        """Scan hooks directory, import modules, extract metadata."""
        self._meta_cache = []
        self._classes = {}

        if not self._hooks_dir.exists():
            return []

        for py_file in sorted(self._hooks_dir.glob("*.py")):
            if py_file.name.startswith("_"):
                continue
            slug = py_file.stem
            try:
                spec = importlib.util.spec_from_file_location(f"noru.hooks.{slug}", py_file)
                if not spec or not spec.loader:
                    continue
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)

                # Find class with config_schema attribute
                hook_class = None
                for attr_name in dir(module):
                    attr = getattr(module, attr_name)
                    if isinstance(attr, type) and hasattr(attr, 'config_schema') and hasattr(attr, 'handle'):
                        hook_class = attr
                        break

                if not hook_class:
                    continue

                meta = HookMeta(
                    name=getattr(hook_class, 'name', slug),
                    slug=slug,
                    description=getattr(hook_class, 'description', ''),
                    config_schema=getattr(hook_class, 'config_schema', []),
                    module_path=str(py_file),
                )
                self._meta_cache.append(meta)
                self._classes[slug] = hook_class
                logger.info("Discovered hook: %s (%s)", meta.name, slug)

            except Exception:
                logger.warning("Failed to load hook from %s", py_file.name, exc_info=True)

        return self._meta_cache

    def list_available(self) -> list[HookMeta]:
        if self._meta_cache is None:
            self.discover()
        return self._meta_cache or []

    def load(self, slug: str, config: dict) -> Any | None:
        """Instantiate a hook with config. Returns None on error."""
        if slug not in self._classes:
            logger.warning("Hook '%s' not found in registry", slug)
            return None
        try:
            hook_class = self._classes[slug]
            instance = hook_class(config)
            instance.name = getattr(instance, 'name', slug)  # ensure name attribute for EventHandler protocol
            logger.info("Loaded hook: %s", slug)
            return instance
        except Exception:
            logger.warning("Failed to instantiate hook '%s'", slug, exc_info=True)
            return None
