"""5-hour rolling window token monitor with cost-based tracking."""

from __future__ import annotations

import json
import logging
from dataclasses import dataclass
from datetime import datetime, timezone, timedelta
from pathlib import Path

from noru.core.constants import DEFAULT_PRICING
from noru.core.models import WindowStatus

logger = logging.getLogger(__name__)


@dataclass
class UsageAccumulator:
    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_tokens: int = 0
    cache_read_tokens: int = 0

    @property
    def total_tokens(self) -> int:
        """Tokens counted toward quota: input + output + cache_creation (NOT cache_read)."""
        return self.input_tokens + self.output_tokens + self.cache_creation_tokens

    def cost(self, pricing: dict | None = None) -> float:
        p = pricing or DEFAULT_PRICING
        return (
            (self.input_tokens / 1_000_000) * p["input"]
            + (self.output_tokens / 1_000_000) * p["output"]
            + (self.cache_creation_tokens / 1_000_000) * p["cache_creation"]
            + (self.cache_read_tokens / 1_000_000) * p["cache_read"]
        )


class TokenMonitor:
    def __init__(
        self, jsonl_dir: Path, window_tokens: int = 220_000,
        window_hours: int = 5,
    ):
        self.jsonl_dir = jsonl_dir
        self.window_tokens = window_tokens
        self.window_hours = window_hours

    def find_jsonl_files(self) -> list[Path]:
        """Find main session JSONL files only (not subagent files)."""
        if not self.jsonl_dir.exists():
            return []
        files = []
        # Only look at direct children of project dirs, not recursive subfolders.
        # Subagent JSONL files live in subdirs (e.g. subagents/) and their tokens
        # are already counted in the parent session file.
        for project_dir in self.jsonl_dir.iterdir():
            if not project_dir.is_dir():
                continue
            for f in project_dir.iterdir():
                if f.is_file() and f.suffix == ".jsonl":
                    files.append(f)
        return sorted(files)

    def current_window(self) -> WindowStatus:
        now = datetime.now(timezone.utc)
        window_start = now - timedelta(hours=self.window_hours)
        window_reset = now + timedelta(hours=self.window_hours)

        acc = UsageAccumulator()
        for jsonl_file in self.find_jsonl_files():
            self._accumulate_window(jsonl_file, window_start, acc)

        cost = acc.cost()

        return WindowStatus(
            start=window_start.isoformat(),
            reset_at=window_reset.isoformat(),
            used=acc.total_tokens,
            limit=self.window_tokens,
            cost_usd=round(cost, 4),
            input_tokens=acc.input_tokens,
            output_tokens=acc.output_tokens,
            cache_creation_tokens=acc.cache_creation_tokens,
            cache_read_tokens=acc.cache_read_tokens,
        )

    def _accumulate_window(
        self, jsonl_file: Path, window_start: datetime, acc: UsageAccumulator,
    ) -> None:
        try:
            with open(jsonl_file) as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        entry = json.loads(line)
                    except json.JSONDecodeError:
                        continue

                    ts_str = entry.get("timestamp", "")
                    if not ts_str:
                        continue
                    try:
                        ts = datetime.fromisoformat(ts_str)
                        if ts.tzinfo is None:
                            ts = ts.replace(tzinfo=timezone.utc)
                    except ValueError:
                        continue
                    if ts < window_start:
                        continue

                    # Claude Code: usage in message.usage
                    usage = {}
                    msg = entry.get("message")
                    if isinstance(msg, dict):
                        usage = msg.get("usage", {})
                    if not usage:
                        usage = entry.get("usage", {})
                    if not usage:
                        continue

                    inp = usage.get("input_tokens", 0) or 0
                    out = usage.get("output_tokens", 0) or 0
                    cc = usage.get("cache_creation_input_tokens", 0) or 0
                    cr = usage.get("cache_read_input_tokens", 0) or 0

                    if inp == 0 and out == 0 and cc == 0 and cr == 0:
                        continue

                    acc.input_tokens += inp
                    acc.output_tokens += out
                    acc.cache_creation_tokens += cc
                    acc.cache_read_tokens += cr
        except OSError:
            logger.warning("Cannot read JSONL file: %s", jsonl_file)
