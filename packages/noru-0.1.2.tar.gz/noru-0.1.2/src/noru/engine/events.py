"""Event bus — emits NoruEvent to subscribed handlers."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Protocol, runtime_checkable

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class NoruEvent:
    event_type: str
    payload: dict = field(default_factory=dict)
    timestamp: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())


@runtime_checkable
class EventHandler(Protocol):
    name: str
    def handle(self, event: NoruEvent) -> None: ...


class EventBus:
    """Simple synchronous event bus. Handlers must not block."""

    def __init__(self):
        self._handlers: list[EventHandler] = []

    def subscribe(self, handler: EventHandler) -> None:
        self._handlers.append(handler)

    def emit(self, event: NoruEvent) -> None:
        for handler in self._handlers:
            try:
                handler.handle(event)
            except Exception:
                logger.exception("Event handler %s failed for %s", handler.name, event.event_type)
