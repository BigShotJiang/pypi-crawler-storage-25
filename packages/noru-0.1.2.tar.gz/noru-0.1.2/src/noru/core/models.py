"""Frozen dataclasses for all Noru entities."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class Project:
    id: str
    name: str
    repo_path: str
    description: str = ""
    allowed_tools: str = "Read,Edit,Bash,Glob"
    agent_wrapper: str = ""
    use_superpowers: bool = False
    active: bool = True
    short_code: str = ""
    created_at: str = ""

    @classmethod
    def from_row(cls, row: dict) -> Project:
        return cls(
            id=row["id"], name=row["name"], repo_path=row["repo_path"],
            description=row.get("description", ""),
            allowed_tools=row.get("allowed_tools", "Read,Edit,Bash,Glob"),
            agent_wrapper=row.get("agent_wrapper", ""),
            use_superpowers=bool(row.get("use_superpowers", 0)),
            active=bool(row.get("active", 1)),
            short_code=row.get("short_code", ""),
            created_at=row.get("created_at", ""),
        )


@dataclass(frozen=True)
class Feature:
    id: int
    project_id: str
    title: str
    description: str = ""
    priority: int = 3
    status: str = "active"
    created_at: str = ""
    completed_at: str | None = None

    @classmethod
    def from_row(cls, row: dict) -> Feature:
        return cls(
            id=row["id"], project_id=row["project_id"], title=row["title"],
            description=row.get("description", ""),
            priority=row.get("priority", 3),
            status=row.get("status", "active"),
            created_at=row.get("created_at", ""),
            completed_at=row.get("completed_at"),
        )


@dataclass(frozen=True)
class Plan:
    id: int
    feature_id: int
    title: str
    approach: str = ""
    priority: int = 3
    status: str = "active"
    token_budget: int = 0
    created_at: str = ""

    @classmethod
    def from_row(cls, row: dict) -> Plan:
        return cls(
            id=row["id"], feature_id=row["feature_id"], title=row["title"],
            approach=row.get("approach", ""),
            priority=row.get("priority", 3),
            status=row.get("status", "active"),
            token_budget=row.get("token_budget", 0),
            created_at=row.get("created_at", ""),
        )


@dataclass(frozen=True)
class Task:
    id: int
    project_id: str
    title: str
    plan_id: int | None = None
    description: str = ""
    status: str = "todo"
    priority: int = 3
    token_weight: str = "medium"
    token_weight_est: int = 0
    auto_generated: bool = False
    source_type: str = "manual"
    max_turns: int = 20
    permission_mode: str = "auto"
    completed_by: str = ""
    task_number: str = ""
    commit_hash: str = ""
    created_at: str = ""
    started_at: str | None = None
    completed_at: str | None = None

    @classmethod
    def from_row(cls, row: dict) -> Task:
        return cls(
            id=row["id"], project_id=row["project_id"], title=row["title"],
            plan_id=row.get("plan_id"),
            description=row.get("description", ""),
            status=row.get("status", "todo"),
            priority=row.get("priority", 3),
            token_weight=row.get("token_weight", "medium"),
            token_weight_est=row.get("token_weight_est", 0),
            auto_generated=bool(row.get("auto_generated", 0)),
            source_type=row.get("source_type", "manual"),
            max_turns=row.get("max_turns", 20),
            permission_mode=row.get("permission_mode", "auto"),
            completed_by=row.get("completed_by", ""),
            task_number=row.get("task_number", ""),
            commit_hash=row.get("commit_hash", ""),
            created_at=row.get("created_at", ""),
            started_at=row.get("started_at"),
            completed_at=row.get("completed_at"),
        )


@dataclass(frozen=True)
class TaskRun:
    id: int
    task_id: int
    project_id: str
    started_at: str
    ended_at: str | None = None
    status: str = "running"
    tokens_input: int = 0
    tokens_output: int = 0
    tokens_cache_read: int = 0
    cost_usd: float = 0.0
    turns_used: int = 0
    tool_calls: str = "[]"
    result_summary: str = ""
    error: str | None = None
    window_id: str = ""

    @classmethod
    def from_row(cls, row: dict) -> TaskRun:
        return cls(
            id=row["id"], task_id=row["task_id"], project_id=row["project_id"],
            started_at=row["started_at"],
            ended_at=row.get("ended_at"),
            status=row.get("status", "running"),
            tokens_input=row.get("tokens_input", 0),
            tokens_output=row.get("tokens_output", 0),
            tokens_cache_read=row.get("tokens_cache_read", 0),
            cost_usd=row.get("cost_usd", 0.0),
            turns_used=row.get("turns_used", 0),
            tool_calls=row.get("tool_calls", "[]"),
            result_summary=row.get("result_summary", ""),
            error=row.get("error"),
            window_id=row.get("window_id", ""),
        )


@dataclass(frozen=True)
class AgentStateRow:
    state: str = "stopped"
    stopped_by: str = ""
    pause_reason: str = ""
    note: str = ""
    updated_at: str = ""

    @classmethod
    def from_row(cls, row: dict) -> AgentStateRow:
        return cls(
            state=row.get("state", "stopped"),
            stopped_by=row.get("stopped_by", ""),
            pause_reason=row.get("pause_reason", ""),
            note=row.get("note", ""),
            updated_at=row.get("updated_at", ""),
        )


@dataclass(frozen=True)
class WindowStatus:
    start: str
    reset_at: str
    used: int          # total tokens (for display)
    limit: int         # token limit (for display)
    cost_usd: float = 0.0     # actual cost in this window
    cost_limit: float = 140.0  # plan cost limit
    input_tokens: int = 0
    output_tokens: int = 0
    cache_creation_tokens: int = 0
    cache_read_tokens: int = 0

    @property
    def pct_remaining(self) -> float:
        """Percentage remaining based on TOKEN count."""
        if self.limit == 0:
            return 0.0
        return max(0.0, 1.0 - self.used / self.limit)

    @property
    def tokens_remaining(self) -> int:
        return max(0, self.limit - self.used)

    @property
    def cost_pct_used(self) -> float:
        if self.cost_limit <= 0:
            return 0.0
        return min(1.0, self.cost_usd / self.cost_limit)


@dataclass(frozen=True)
class WeeklyBudget:
    total_used: int
    weekly_limit: int
    developer_reserve_pct: float = 0.35

    @property
    def agent_allocation(self) -> int:
        return int(self.weekly_limit * (1 - self.developer_reserve_pct))

    @property
    def agent_budget_remaining(self) -> int:
        return max(0, self.agent_allocation - self.total_used)

    def safe_to_dispatch(self, task_weight_est: int) -> bool:
        return self.agent_budget_remaining - task_weight_est > 50_000


@dataclass(frozen=True)
class Job:
    id: int
    action_id: str
    action_type: str
    project_id: str
    status: str = "pending"
    file_path: str = ""
    prompt: str = ""
    metadata: str = "{}"
    result: str | None = None
    error: str | None = None
    retry_count: int = 0
    created_at: str = ""
    completed_at: str | None = None
    processed_at: str | None = None

    @classmethod
    def from_row(cls, row: dict) -> Job:
        return cls(
            id=row["id"],
            action_id=row["action_id"],
            action_type=row["action_type"],
            project_id=row["project_id"],
            status=row.get("status", "pending"),
            file_path=row.get("file_path", ""),
            prompt=row.get("prompt", ""),
            metadata=row.get("metadata", "{}"),
            result=row.get("result"),
            error=row.get("error"),
            retry_count=row.get("retry_count", 0),
            created_at=row.get("created_at", ""),
            completed_at=row.get("completed_at"),
            processed_at=row.get("processed_at"),
        )


@dataclass(frozen=True)
class TaskComment:
    id: int
    task_id: int
    author: str = "user"
    body: str = ""
    created_at: str = ""

    @classmethod
    def from_row(cls, row: dict) -> TaskComment:
        return cls(
            id=row["id"],
            task_id=row["task_id"],
            author=row.get("author", "user"),
            body=row.get("body", ""),
            created_at=row.get("created_at", ""),
        )
