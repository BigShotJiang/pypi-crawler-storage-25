"""SQLite database management for Noru."""

from __future__ import annotations

import logging
import sqlite3
from datetime import datetime, timezone
from importlib.resources import files
from pathlib import Path

from noru.core.models import (
    AgentStateRow, Feature, Job, Plan, Project, Task, TaskComment, TaskRun,
)

logger = logging.getLogger(__name__)


def _row_to_dict(cursor: sqlite3.Cursor, row: tuple) -> dict:
    """Row factory that returns dicts. Handles column count mismatches."""
    if cursor.description is None:
        return {}
    result = {}
    for idx, col in enumerate(cursor.description):
        if idx < len(row):
            result[col[0]] = row[idx]
        else:
            result[col[0]] = None
    return result


class Database:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self._conn: sqlite3.Connection | None = None

    def initialize(self) -> None:
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self.db_path), check_same_thread=False)
        self._conn.execute("PRAGMA journal_mode = WAL")
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._conn.row_factory = _row_to_dict
        self._run_migrations()

    def _run_migrations(self) -> None:
        """Run pending SQL migrations from noru.core.migrations/."""
        conn = self._conn
        # Create version tracking table (no row_factory needed here, use raw cursor)
        conn.execute(
            "CREATE TABLE IF NOT EXISTS schema_version ("
            "  version INTEGER PRIMARY KEY,"
            "  name TEXT NOT NULL,"
            "  applied_at TEXT DEFAULT (datetime('now'))"
            ")"
        )
        conn.commit()

        # Get current version
        row = conn.execute("SELECT MAX(version) as v FROM schema_version").fetchone()
        current = (row["v"] if row and row["v"] is not None else 0)

        # Discover migration files
        migrations_pkg = files("noru.core.migrations")
        migration_files = sorted(
            f for f in migrations_pkg.iterdir()
            if f.name.endswith(".sql") and f.name[0].isdigit()
        )

        for mf in migration_files:
            # Parse version number from filename: "001_initial_schema.sql" -> 1
            version = int(mf.name.split("_", 1)[0])
            if version <= current:
                continue

            sql = mf.read_text()
            logger.info("Running migration %03d: %s", version, mf.name)
            try:
                conn.executescript(sql)
            except sqlite3.OperationalError as e:
                # Handle "duplicate column" from ALTER TABLE on existing schemas
                if "duplicate column" in str(e).lower():
                    logger.debug("Migration %03d: column already exists, skipping", version)
                else:
                    raise
            conn.execute(
                "INSERT INTO schema_version (version, name) VALUES (?, ?)",
                (version, mf.name),
            )
            conn.commit()

    @property
    def conn(self) -> sqlite3.Connection:
        if self._conn is None:
            raise RuntimeError("Database not initialized. Call initialize() first.")
        return self._conn

    def execute(self, sql: str, params: tuple = ()) -> sqlite3.Cursor:
        return self.conn.execute(sql, params)

    def close(self) -> None:
        if self._conn:
            self._conn.close()
            self._conn = None

    def create_project(self, id: str, name: str, repo_path: str, *, description: str = "", allowed_tools: str = "Read,Edit,Bash,Glob", agent_wrapper: str = "", use_superpowers: bool = False, active: bool = True, short_code: str = "") -> None:
        if not short_code:
            # Auto-derive from name: "mobile-2024" -> "MO", "My App" -> "MY"
            clean = "".join(c for c in name if c.isalpha())
            short_code = clean[:2].upper() if len(clean) >= 2 else name[:2].upper()
        self.conn.execute("INSERT INTO projects (id, name, repo_path, description, allowed_tools, agent_wrapper, use_superpowers, active, short_code) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", (id, name, repo_path, description, allowed_tools, agent_wrapper, int(use_superpowers), int(active), short_code))
        self.conn.commit()

    def get_project(self, project_id: str) -> Project | None:
        row = self.conn.execute("SELECT * FROM projects WHERE id = ?", (project_id,)).fetchone()
        return Project.from_row(dict(row)) if row else None

    def active_projects(self) -> list[Project]:
        rows = self.conn.execute("SELECT * FROM projects WHERE active = 1").fetchall()
        return [Project.from_row(dict(r)) for r in rows]

    def update_project(self, project_id: str, **kwargs) -> None:
        if not kwargs:
            return
        bool_fields = {"use_superpowers", "active"}
        sets, vals = [], []
        for k, v in kwargs.items():
            sets.append(f"{k} = ?")
            vals.append(int(v) if k in bool_fields else v)
        vals.append(project_id)
        self.conn.execute(f"UPDATE projects SET {', '.join(sets)} WHERE id = ?", tuple(vals))
        self.conn.commit()

    def delete_project(self, project_id: str) -> None:
        """Permanently delete a project and all its tasks, runs, comments, features, plans, and jobs."""
        # Delete in dependency order
        self.conn.execute("DELETE FROM task_comments WHERE task_id IN (SELECT id FROM tasks WHERE project_id = ?)", (project_id,))
        self.conn.execute("DELETE FROM task_runs WHERE project_id = ?", (project_id,))
        self.conn.execute("DELETE FROM tasks WHERE project_id = ?", (project_id,))
        self.conn.execute("DELETE FROM jobs WHERE project_id = ?", (project_id,))
        self.conn.execute("DELETE FROM plans WHERE feature_id IN (SELECT id FROM features WHERE project_id = ?)", (project_id,))
        self.conn.execute("DELETE FROM features WHERE project_id = ?", (project_id,))
        self.conn.execute("DELETE FROM trusted_paths WHERE project_id = ?", (project_id,))
        self.conn.execute("DELETE FROM projects WHERE id = ?", (project_id,))
        self.conn.commit()

    def archive_project(self, project_id: str) -> None:
        """Archive a project and cascade to all non-done tasks."""
        self.conn.execute("UPDATE projects SET active = 0 WHERE id = ?", (project_id,))
        self.conn.execute(
            "UPDATE tasks SET status = 'archived' WHERE project_id = ? AND status NOT IN ('done', 'archived')",
            (project_id,),
        )
        self.conn.commit()

    def unarchive_project(self, project_id: str) -> None:
        """Restore an archived project (tasks stay archived — user decides)."""
        self.conn.execute("UPDATE projects SET active = 1 WHERE id = ?", (project_id,))
        self.conn.commit()

    def all_projects(self) -> list[Project]:
        rows = self.conn.execute("SELECT * FROM projects").fetchall()
        return [Project.from_row(dict(r)) for r in rows]

    def create_feature(self, project_id: str, title: str, *, description: str = "", priority: int = 3) -> int:
        cur = self.conn.execute("INSERT INTO features (project_id, title, description, priority) VALUES (?, ?, ?, ?)", (project_id, title, description, priority))
        self.conn.commit()
        return cur.lastrowid

    def get_feature(self, feature_id: int) -> Feature | None:
        row = self.conn.execute("SELECT * FROM features WHERE id = ?", (feature_id,)).fetchone()
        return Feature.from_row(dict(row)) if row else None

    def get_project_features(self, project_id: str) -> list[Feature]:
        rows = self.conn.execute("SELECT * FROM features WHERE project_id = ? ORDER BY priority, id", (project_id,)).fetchall()
        return [Feature.from_row(dict(r)) for r in rows]

    def create_plan(self, feature_id: int, title: str, *, approach: str = "", priority: int = 3, token_budget: int = 0) -> int:
        cur = self.conn.execute("INSERT INTO plans (feature_id, title, approach, priority, token_budget) VALUES (?, ?, ?, ?, ?)", (feature_id, title, approach, priority, token_budget))
        self.conn.commit()
        return cur.lastrowid

    def get_plan(self, plan_id: int) -> Plan | None:
        row = self.conn.execute("SELECT * FROM plans WHERE id = ?", (plan_id,)).fetchone()
        return Plan.from_row(dict(row)) if row else None

    def _next_task_number(self, project_id: str) -> str:
        """Generate next task number for a project, e.g., MT-0001."""
        project = self.get_project(project_id)
        short_code = project.short_code if project and project.short_code else "TK"
        row = self.conn.execute("SELECT COUNT(*) as c FROM tasks WHERE project_id = ?", (project_id,)).fetchone()
        seq = (row["c"] if row else 0) + 1
        return f"{short_code}-{seq:04d}"

    def create_task(self, project_id: str, title: str, *, plan_id: int | None = None, description: str = "", status: str = "todo", priority: int = 3, token_weight: str = "medium", token_weight_est: int = 0, auto_generated: bool = False, source_type: str = "manual", max_turns: int = 20, permission_mode: str = "auto") -> int:
        task_number = self._next_task_number(project_id)
        cur = self.conn.execute("INSERT INTO tasks (plan_id, project_id, title, description, status, priority, token_weight, token_weight_est, auto_generated, source_type, max_turns, permission_mode, task_number) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", (plan_id, project_id, title, description, status, priority, token_weight, token_weight_est, int(auto_generated), source_type, max_turns, permission_mode, task_number))
        self.conn.commit()
        return cur.lastrowid

    def get_task(self, task_id: int) -> Task | None:
        row = self.conn.execute("SELECT * FROM tasks WHERE id = ?", (task_id,)).fetchone()
        return Task.from_row(dict(row)) if row else None

    def update_task(self, task_id: int, **kwargs) -> None:
        if not kwargs:
            return
        bool_fields = {"auto_generated"}
        sets, vals = [], []
        for k, v in kwargs.items():
            sets.append(f"{k} = ?")
            vals.append(int(v) if k in bool_fields else v)
        vals.append(task_id)
        self.conn.execute(f"UPDATE tasks SET {', '.join(sets)} WHERE id = ?", tuple(vals))
        self.conn.commit()

    def get_next_eligible_task(self, max_weight: str, project_id: str | None = None) -> Task | None:
        eligible_weights = []
        for w in ["light", "medium", "heavy"]:
            eligible_weights.append(w)
            if w == max_weight:
                break
        placeholders = ",".join("?" * len(eligible_weights))
        sql = (
            f"SELECT t.* FROM tasks t "
            f"JOIN projects p ON t.project_id = p.id "
            f"WHERE t.status = 'ready' AND p.active = 1 AND t.token_weight IN ({placeholders})"
        )
        params: list = list(eligible_weights)
        if project_id:
            sql += " AND t.project_id = ?"
            params.append(project_id)
        sql += " ORDER BY t.priority ASC, t.id ASC LIMIT 1"
        row = self.conn.execute(sql, tuple(params)).fetchone()
        return Task.from_row(dict(row)) if row else None

    def queue_depth(self, project_id: str | None = None) -> int:
        sql = "SELECT COUNT(*) FROM tasks WHERE status = 'ready'"
        params: tuple = ()
        if project_id:
            sql += " AND project_id = ?"
            params = (project_id,)
        row = self.conn.execute(sql, params).fetchone()
        if row is None:
            return 0
        # Handle both dict and tuple row formats
        try:
            return row["COUNT(*)"]
        except (KeyError, TypeError):
            return 0

    def list_tasks(self, *, project_id: str | None = None, status: str | None = None) -> list[Task]:
        sql = "SELECT * FROM tasks WHERE 1=1"
        params: list = []
        if project_id:
            sql += " AND project_id = ?"
            params.append(project_id)
        if status:
            sql += " AND status = ?"
            params.append(status)
        sql += " ORDER BY priority ASC, id ASC"
        rows = self.conn.execute(sql, tuple(params)).fetchall()
        return [Task.from_row(dict(r)) for r in rows]

    def list_tasks_paginated(self, *, project_id: str | None = None, status: str | None = None,
                              search: str | None = None, priority: int | None = None,
                              source: str | None = None, active_only: bool = False,
                              sort: str = "created_at", order: str = "desc",
                              page: int = 1, limit: int = 10) -> dict:
        """Server-side paginated task list with filtering, search, and sorting."""
        # Whitelist sort columns to prevent SQL injection
        allowed_sorts = {"created_at", "priority", "status", "title", "project_id", "source_type", "id"}
        if sort not in allowed_sorts:
            sort = "created_at"
        if order not in ("asc", "desc"):
            order = "desc"

        where = ["1=1"]
        params: list = []
        if active_only:
            where.append("project_id IN (SELECT id FROM projects WHERE active = 1)")
        if project_id:
            where.append("project_id = ?")
            params.append(project_id)
        if status:
            where.append("status = ?")
            params.append(status)
        if search:
            where.append("(title LIKE ? OR description LIKE ? OR task_number LIKE ?)")
            params.extend([f"%{search}%", f"%{search}%", f"%{search}%"])
        if priority is not None:
            where.append("priority = ?")
            params.append(priority)
        if source:
            where.append("source_type = ?")
            params.append(source)

        where_clause = " AND ".join(where)

        # Count total
        count_row = self.conn.execute(f"SELECT COUNT(*) as c FROM tasks WHERE {where_clause}", tuple(params)).fetchone()
        total = count_row["c"] if count_row else 0

        # Fetch page
        offset = (page - 1) * limit
        sql = f"SELECT * FROM tasks WHERE {where_clause} ORDER BY {sort} {order} LIMIT ? OFFSET ?"
        rows = self.conn.execute(sql, tuple(params) + (limit, offset)).fetchall()
        tasks = [Task.from_row(dict(r)) for r in rows]

        return {
            "tasks": tasks,
            "total": total,
            "page": page,
            "limit": limit,
            "total_pages": max(1, -(-total // limit)),  # ceil division
        }

    def promote_todo_to_ready(self) -> int:
        """Promote all TODO tasks (in active projects) to READY. Returns count promoted."""
        cur = self.conn.execute(
            "UPDATE tasks SET status = 'ready' "
            "WHERE status = 'todo' AND project_id IN (SELECT id FROM projects WHERE active = 1)"
        )
        self.conn.commit()
        return cur.rowcount

    def create_task_run(self, task_id: int, project_id: str, window_id: str) -> int:
        now = datetime.now(timezone.utc).isoformat()
        cur = self.conn.execute("INSERT INTO task_runs (task_id, project_id, started_at, window_id) VALUES (?, ?, ?, ?)", (task_id, project_id, now, window_id))
        self.conn.commit()
        return cur.lastrowid

    def complete_task_run(self, run_id: int, *, status: str, ended_at: str, tokens_input: int = 0, tokens_output: int = 0, tokens_cache_read: int = 0, cost_usd: float = 0.0, turns_used: int = 0, tool_calls: str = "[]", result_summary: str = "", error: str | None = None) -> None:
        self.conn.execute("UPDATE task_runs SET status=?, ended_at=?, tokens_input=?, tokens_output=?, tokens_cache_read=?, cost_usd=?, turns_used=?, tool_calls=?, result_summary=?, error=? WHERE id=?", (status, ended_at, tokens_input, tokens_output, tokens_cache_read, cost_usd, turns_used, tool_calls, result_summary, error, run_id))
        self.conn.commit()

    def get_task_runs(self, task_id: int) -> list[TaskRun]:
        rows = self.conn.execute("SELECT * FROM task_runs WHERE task_id = ? ORDER BY id DESC", (task_id,)).fetchall()
        return [TaskRun.from_row(dict(r)) for r in rows]

    def get_agent_state(self) -> AgentStateRow:
        row = self.conn.execute("SELECT * FROM agent_state WHERE id = 1").fetchone()
        if row is None:
            # Seed row missing — recreate it
            self.conn.execute("INSERT OR IGNORE INTO agent_state (id, state) VALUES (1, 'stopped')")
            self.conn.commit()
            row = self.conn.execute("SELECT * FROM agent_state WHERE id = 1").fetchone()
        return AgentStateRow.from_row(dict(row))

    def update_agent_state(self, state: str, *, stopped_by: str = "", pause_reason: str = "", note: str = "") -> None:
        now = datetime.now(timezone.utc).isoformat()
        self.conn.execute("UPDATE agent_state SET state=?, updated_at=?, stopped_by=?, pause_reason=?, note=? WHERE id=1", (state, now, stopped_by, pause_reason, note))
        self.conn.commit()

    def add_trusted_path(self, path: str, project_id: str | None = None) -> None:
        self.conn.execute("INSERT OR IGNORE INTO trusted_paths (path, project_id) VALUES (?, ?)", (path, project_id))
        self.conn.commit()

    def is_trusted_path(self, path: str) -> bool:
        row = self.conn.execute("SELECT 1 FROM trusted_paths WHERE path = ?", (path,)).fetchone()
        return row is not None

    def create_comment(self, task_id: int, body: str, author: str = "user") -> int:
        cur = self.conn.execute(
            "INSERT INTO task_comments (task_id, body, author) VALUES (?, ?, ?)",
            (task_id, body, author),
        )
        self.conn.commit()
        return cur.lastrowid

    def get_task_comments(self, task_id: int) -> list[TaskComment]:
        rows = self.conn.execute(
            "SELECT * FROM task_comments WHERE task_id = ? ORDER BY created_at ASC",
            (task_id,),
        ).fetchall()
        return [TaskComment.from_row(dict(r)) for r in rows]

    def get_recent_task_comments(self, task_id: int, since: str | None = None) -> list[TaskComment]:
        if since is None:
            return self.get_task_comments(task_id)
        rows = self.conn.execute(
            "SELECT * FROM task_comments WHERE task_id = ? AND created_at > ? ORDER BY created_at ASC",
            (task_id, since),
        ).fetchall()
        return [TaskComment.from_row(dict(r)) for r in rows]

    # --- Jobs ---

    def create_job(self, action_id: str, action_type: str, project_id: str, file_path: str, *, prompt: str = "", metadata: str = "{}") -> int:
        cur = self.conn.execute(
            "INSERT INTO jobs (action_id, action_type, project_id, file_path, prompt, metadata) VALUES (?, ?, ?, ?, ?, ?)",
            (action_id, action_type, project_id, file_path, prompt, metadata),
        )
        self.conn.commit()
        return cur.lastrowid

    def get_job(self, job_id: int) -> Job | None:
        row = self.conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
        return Job.from_row(dict(row)) if row else None

    def get_job_by_action_id(self, action_id: str) -> Job | None:
        row = self.conn.execute("SELECT * FROM jobs WHERE action_id = ?", (action_id,)).fetchone()
        return Job.from_row(dict(row)) if row else None

    def get_pending_jobs(self) -> list[Job]:
        rows = self.conn.execute("SELECT * FROM jobs WHERE status = 'pending' ORDER BY id ASC").fetchall()
        return [Job.from_row(dict(r)) for r in rows]

    def get_pending_jobs_for_project(self, project_id: str) -> list[Job]:
        rows = self.conn.execute(
            "SELECT * FROM jobs WHERE status = 'pending' AND project_id = ? ORDER BY id",
            (project_id,),
        ).fetchall()
        return [Job.from_row(dict(r)) for r in rows]

    def complete_job(self, job_id: int, *, status: str, result: str | None = None, error: str | None = None, completed_at: str) -> None:
        self.conn.execute(
            "UPDATE jobs SET status=?, result=?, error=?, completed_at=? WHERE id=?",
            (status, result, error, completed_at, job_id),
        )
        self.conn.commit()

    def mark_job_processed(self, job_id: int) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self.conn.execute("UPDATE jobs SET processed_at=? WHERE id=?", (now, job_id))
        self.conn.commit()

    def retry_job(self, job_id: int, new_file_path: str) -> None:
        """Reset a job to pending for retry with a new file path."""
        self.conn.execute(
            "UPDATE jobs SET status='pending', file_path=?, result=NULL, error=NULL, completed_at=NULL, retry_count=retry_count+1 WHERE id=?",
            (new_file_path, job_id),
        )
        self.conn.commit()

    # --- Usage History ---

    def log_usage(self, session_pct: float, weekly_pct: float) -> None:
        now = datetime.now(timezone.utc).isoformat()
        self.conn.execute(
            "INSERT INTO usage_history (timestamp, session_pct, weekly_pct) VALUES (?, ?, ?)",
            (now, session_pct, weekly_pct),
        )
        self.conn.commit()

    def get_usage_history(self, hours: int = 24) -> list[dict]:
        from datetime import timedelta
        since = (datetime.now(timezone.utc) - timedelta(hours=hours)).isoformat()
        rows = self.conn.execute(
            "SELECT timestamp, session_pct, weekly_pct FROM usage_history WHERE timestamp > ? ORDER BY timestamp ASC",
            (since,),
        ).fetchall()
        return [dict(r) for r in rows]

    def get_completed_unprocessed_jobs(self) -> list[Job]:
        rows = self.conn.execute(
            "SELECT * FROM jobs WHERE status IN ('ok', 'error') AND processed_at IS NULL ORDER BY id ASC"
        ).fetchall()
        return [Job.from_row(dict(r)) for r in rows]

    # --- Activity Log ---

    def log_activity(self, event_type: str, description: str, *, entity_type: str = "", entity_id: str = "", project_id: str = "", metadata: str = "{}") -> int:
        cur = self.conn.execute(
            "INSERT INTO activity_log (event_type, entity_type, entity_id, project_id, description, metadata) VALUES (?, ?, ?, ?, ?, ?)",
            (event_type, entity_type, entity_id, project_id, description, metadata),
        )
        self.conn.commit()
        return cur.lastrowid

    def get_activity(self, *, limit: int = 20, project_id: str | None = None) -> list[dict]:
        sql = "SELECT * FROM activity_log"
        params: list = []
        if project_id:
            sql += " WHERE project_id = ?"
            params.append(project_id)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        rows = self.conn.execute(sql, tuple(params)).fetchall()
        return [dict(r) for r in rows]
