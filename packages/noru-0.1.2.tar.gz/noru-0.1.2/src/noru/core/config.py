"""Configuration management for Noru."""

from __future__ import annotations

from pathlib import Path

import yaml
from pydantic import BaseModel, Field, field_validator

from noru.core.constants import DEFAULT_IDLE_JOBS


class WeeklyConfig(BaseModel):
    seed_limit: int = 1_500_000
    developer_reserve_pct: float = 0.35
    reset_day: str = "monday"

    @field_validator('developer_reserve_pct')
    @classmethod
    def validate_reserve_pct(cls, v: float) -> float:
        return max(0.0, min(1.0, v))


class IdleJobEntry(BaseModel):
    id: str
    enabled: bool = False
    source: str = "builtin"
    description: str | None = None
    weight: str | None = None


class IdleJobsConfig(BaseModel):
    max_tasks_per_run: int = 3
    mode: str = "dispatch_first"  # dispatch_first = dispatch queue then scan | scan_first = scan all jobs then dispatch | scan_only = only scan, never dispatch
    jobs: list[IdleJobEntry] = Field(
        default_factory=lambda: [
            IdleJobEntry(id=j["id"], enabled=j["enabled"])
            for j in DEFAULT_IDLE_JOBS
        ]
    )


class WorkerPoolConfig(BaseModel):
    max_workers: int = 3
    compact_every: int = 10
    reset_after: int = 50
    idle_timeout_minutes: int = 5


class WatermarkConfig(BaseModel):
    low_watermark: int = 2
    scan_cooldown_seconds: int = 60


class WebhookEntry(BaseModel):
    url: str
    events: list[str] = Field(default_factory=lambda: ["*"])
    body_template: str | None = None


class TunnelConfig(BaseModel):
    provider: str | None = None  # null | "cloudflared" | "ngrok"
    ngrok_authtoken: str = ""


class IntegrationConfig(BaseModel):
    enabled: bool = False
    config: dict = Field(default_factory=dict)


class NoruConfig(BaseModel):
    loop_interval_seconds: int = 30
    max20_window_tokens: int = 220_000
    window_duration_hours: int = 5
    weekly: WeeklyConfig = Field(default_factory=WeeklyConfig)
    idle_jobs: IdleJobsConfig = Field(default_factory=IdleJobsConfig)
    worker_pool: WorkerPoolConfig = Field(default_factory=WorkerPoolConfig)
    watermark: WatermarkConfig = Field(default_factory=WatermarkConfig)
    guardrails: list[str] = Field(default_factory=list)
    max_session_pct: float = 80.0   # pause when session usage reaches this %
    max_weekly_pct: float = 90.0    # pause when weekly usage reaches this %

    @field_validator('max_session_pct', 'max_weekly_pct')
    @classmethod
    def validate_pct(cls, v: float) -> float:
        return max(5.0, min(100.0, v))
    claude_cli: str = "claude"
    port: int = 7777
    auto_ready: bool = False
    auto_commit: bool = False
    webhooks: list[WebhookEntry] = Field(default_factory=list)
    tunnel: TunnelConfig = Field(default_factory=TunnelConfig)
    integrations: dict[str, IntegrationConfig] = Field(default_factory=dict)
    language: str = "en"
    guardrails_enabled: bool = True
    english_commits: bool = True


def load_config(path: Path) -> NoruConfig:
    if not path.exists():
        return NoruConfig()
    text = path.read_text().strip()
    if not text:
        return NoruConfig()
    data = yaml.safe_load(text)
    if not isinstance(data, dict):
        return NoruConfig()
    return NoruConfig(**data)
