-- Add short_code to projects (for task number prefix, e.g., MT)
-- Add task_number to tasks (e.g., MT-0001)

ALTER TABLE projects ADD COLUMN short_code TEXT DEFAULT '';
ALTER TABLE tasks ADD COLUMN task_number TEXT DEFAULT '';
