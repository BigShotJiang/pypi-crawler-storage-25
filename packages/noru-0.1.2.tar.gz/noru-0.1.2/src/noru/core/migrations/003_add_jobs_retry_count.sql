-- Add retry_count column to jobs table for timeout retry tracking
-- Safe: checks if column exists first (SQLite doesn't support IF NOT EXISTS for ALTER TABLE)

-- This will fail silently if the column already exists — the migration runner handles this
ALTER TABLE jobs ADD COLUMN retry_count INTEGER NOT NULL DEFAULT 0;
