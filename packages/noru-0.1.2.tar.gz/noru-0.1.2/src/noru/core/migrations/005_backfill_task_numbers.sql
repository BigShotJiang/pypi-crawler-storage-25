-- Backfill task_number for existing tasks that have empty task_number
-- Uses a correlated subquery to generate sequential numbers per project

UPDATE tasks
SET task_number = (
    SELECT COALESCE(p.short_code, 'TK') || '-' || printf('%04d',
        (SELECT COUNT(*) FROM tasks t2 WHERE t2.project_id = tasks.project_id AND t2.id <= tasks.id)
    )
    FROM projects p WHERE p.id = tasks.project_id
)
WHERE task_number = '' OR task_number IS NULL;

-- Also backfill short_code for projects that don't have one
UPDATE projects
SET short_code = UPPER(SUBSTR(REPLACE(REPLACE(REPLACE(name, '-', ''), '_', ''), ' ', ''), 1, 2))
WHERE short_code = '' OR short_code IS NULL;
