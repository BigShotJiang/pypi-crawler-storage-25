CREATE TABLE IF NOT EXISTS usage_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT NOT NULL DEFAULT (datetime('now')),
    session_pct REAL NOT NULL DEFAULT 0,
    weekly_pct REAL NOT NULL DEFAULT 0
);
