-- Add commit_hash to tasks for tracking auto-committed changes

ALTER TABLE tasks ADD COLUMN commit_hash TEXT DEFAULT '';
