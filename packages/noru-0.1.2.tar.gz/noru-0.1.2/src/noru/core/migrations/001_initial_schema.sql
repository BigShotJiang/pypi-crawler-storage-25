-- Initial schema: projects, features, plans, tasks, task_runs, agent_state, trusted_paths, task_comments

CREATE TABLE IF NOT EXISTS projects (
    id              TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    repo_path       TEXT NOT NULL,
    description     TEXT DEFAULT '',
    allowed_tools   TEXT DEFAULT 'Read,Edit,Bash,Glob',
    agent_wrapper   TEXT DEFAULT '',
    use_superpowers INTEGER DEFAULT 0,
    active          INTEGER DEFAULT 1,
    created_at      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS features (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id      TEXT NOT NULL REFERENCES projects(id),
    title           TEXT NOT NULL,
    description     TEXT DEFAULT '',
    priority        INTEGER DEFAULT 3,
    status          TEXT DEFAULT 'active',
    created_at      TEXT DEFAULT (datetime('now')),
    completed_at    TEXT
);

CREATE TABLE IF NOT EXISTS plans (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    feature_id      INTEGER NOT NULL REFERENCES features(id),
    title           TEXT NOT NULL,
    approach        TEXT DEFAULT '',
    priority        INTEGER DEFAULT 3,
    status          TEXT DEFAULT 'active',
    token_budget    INTEGER DEFAULT 0,
    created_at      TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS tasks (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    plan_id             INTEGER REFERENCES plans(id),
    project_id          TEXT NOT NULL REFERENCES projects(id),
    title               TEXT NOT NULL,
    description         TEXT DEFAULT '',
    status              TEXT DEFAULT 'todo',
    priority            INTEGER DEFAULT 3,
    token_weight        TEXT DEFAULT 'medium',
    token_weight_est    INTEGER DEFAULT 0,
    auto_generated      INTEGER DEFAULT 0,
    source_type         TEXT DEFAULT 'manual',
    max_turns           INTEGER DEFAULT 20,
    permission_mode     TEXT DEFAULT 'auto',
    deferred_reason     TEXT DEFAULT '',
    deferred_until      TEXT,
    completed_by        TEXT DEFAULT '',
    completion_evidence TEXT DEFAULT '',
    created_at          TEXT DEFAULT (datetime('now')),
    started_at          TEXT,
    completed_at        TEXT
);

CREATE TABLE IF NOT EXISTS task_runs (
    id                  INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id             INTEGER NOT NULL REFERENCES tasks(id),
    project_id          TEXT NOT NULL,
    started_at          TEXT NOT NULL,
    ended_at            TEXT,
    status              TEXT DEFAULT 'running',
    tokens_input        INTEGER DEFAULT 0,
    tokens_output       INTEGER DEFAULT 0,
    tokens_cache_read   INTEGER DEFAULT 0,
    cost_usd            REAL DEFAULT 0,
    turns_used          INTEGER DEFAULT 0,
    tool_calls          TEXT DEFAULT '[]',
    result_summary      TEXT DEFAULT '',
    error               TEXT,
    window_id           TEXT
);

CREATE TABLE IF NOT EXISTS agent_state (
    id          INTEGER PRIMARY KEY CHECK (id = 1),
    state       TEXT DEFAULT 'stopped',
    updated_at  TEXT DEFAULT (datetime('now')),
    stopped_by  TEXT DEFAULT '',
    pause_reason TEXT DEFAULT '',
    note        TEXT DEFAULT ''
);

INSERT OR IGNORE INTO agent_state (id, state) VALUES (1, 'stopped');

CREATE TABLE IF NOT EXISTS trusted_paths (
    path        TEXT PRIMARY KEY,
    added_at    TEXT DEFAULT (datetime('now')),
    project_id  TEXT REFERENCES projects(id)
);

CREATE TABLE IF NOT EXISTS task_comments (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    task_id     INTEGER NOT NULL REFERENCES tasks(id),
    author      TEXT NOT NULL DEFAULT 'user',
    body        TEXT NOT NULL DEFAULT '',
    created_at  TEXT DEFAULT (datetime('now'))
);

CREATE INDEX IF NOT EXISTS idx_comments_task ON task_comments(task_id);
CREATE INDEX IF NOT EXISTS idx_tasks_status    ON tasks(status, priority);
CREATE INDEX IF NOT EXISTS idx_tasks_project   ON tasks(project_id, status);
CREATE INDEX IF NOT EXISTS idx_runs_window     ON task_runs(window_id);
CREATE INDEX IF NOT EXISTS idx_runs_task       ON task_runs(task_id);
CREATE INDEX IF NOT EXISTS idx_features_project ON features(project_id);
