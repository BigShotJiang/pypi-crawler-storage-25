"""Enums and constants for Noru."""

from __future__ import annotations

from enum import StrEnum


class TaskStatus(StrEnum):
    TODO = "todo"
    READY = "ready"
    DOING = "doing"
    REVIEW = "review"
    DONE = "done"
    FAILED = "failed"
    REJECTED = "rejected"


class TaskWeight(StrEnum):
    LIGHT = "light"
    MEDIUM = "medium"
    HEAVY = "heavy"


class SourceType(StrEnum):
    MANUAL = "manual"
    BUG = "bug"
    SECURITY = "security"
    REFACTOR = "refactor"
    TEST = "test"
    REVIEW = "review"


DEFAULT_IDLE_JOBS: list[dict[str, str | bool]] = [
    # Security & Compliance (enabled by default)
    {"id": "security-deep", "enabled": True},
    {"id": "env-secrets", "enabled": True},
    # Code Quality & Correctness (enabled by default)
    {"id": "bug-detection", "enabled": True},
    {"id": "error-handling", "enabled": True},
    {"id": "dead-code", "enabled": True},
    # Architecture & Maintainability (disabled by default)
    {"id": "architecture", "enabled": False},
    {"id": "code-clarity", "enabled": False},
    # Testing (disabled by default)
    {"id": "test-gaps", "enabled": False},
    # Performance (disabled by default)
    {"id": "performance", "enabled": False},
    # DevOps & Infrastructure (disabled by default)
    {"id": "devops", "enabled": False},
    {"id": "deployment-config", "enabled": False},
    # Frontend (disabled by default)
    {"id": "frontend", "enabled": False},
]

IDLE_JOB_META: dict[str, dict[str, str]] = {
    "security-deep": {
        "weight": "medium",
        "name": "Security Deep Dive",
        "description": (
            "Perform a security review focused on data flow:\n"
            "1. Find all places where user input enters the system (HTTP params, form data, file uploads, CLI args)\n"
            "2. For each input, trace where it goes — does it reach a database query, HTML output, file path, or shell command?\n"
            "3. Check authentication — are there endpoints accessible without auth that should require it?\n"
            "4. Check authorization — can user A access user B's data by changing an ID?\n"
            "5. Check for hardcoded secrets, API keys, or credentials in code (not .env)\n\n"
            "Only report issues where you can trace the actual attack path."
        ),
    },
    "env-secrets": {
        "weight": "light",
        "name": "Environment & Secrets",
        "description": (
            "Review environment and secrets management:\n"
            "1. Check .env.example vs actual .env — are there missing or exposed secrets?\n"
            "2. Check .gitignore — are .env, credentials, and key files excluded?\n"
            "3. Check for secrets in git history: git log -p --all -S 'password\\|secret\\|api_key\\|token' | head -50\n"
            "4. Check if secrets are passed as command-line arguments (visible in ps)\n"
            "5. Check Docker files for secrets baked into images (ENV, COPY .env, etc.)"
        ),
    },
    "bug-detection": {
        "weight": "medium",
        "name": "Bug Detection",
        "description": (
            "Look for bugs that cause incorrect behavior:\n"
            "1. Null/undefined checks — what happens when data is missing or empty?\n"
            "2. Edge cases — empty arrays, zero values, very large inputs, special characters\n"
            "3. Logic errors — off-by-one, wrong comparison operator, inverted condition\n"
            "4. Async bugs — race conditions, unhandled promise rejections, missing await\n"
            "5. Type mismatches — string where number expected, wrong date format parsing\n\n"
            "Trace the actual execution path for each bug you find."
        ),
    },
    "error-handling": {
        "weight": "medium",
        "name": "Error Handling",
        "description": (
            "Review error handling and resilience:\n"
            "1. Find try/catch blocks that swallow errors silently (empty catch, catch with only console.log)\n"
            "2. Find external calls (HTTP, database, file I/O) without error handling\n"
            "3. Check if errors propagate correctly — does the caller know when something fails?\n"
            "4. Check error responses to users — do they leak stack traces or internal details?\n"
            "5. Check retry logic — is there any? Should there be? Are there infinite retry loops?"
        ),
    },
    "dead-code": {
        "weight": "light",
        "name": "Dead Code Cleanup",
        "description": (
            "Find significant dead code (not single-line lint issues):\n"
            "1. Functions/methods/classes that are never called from anywhere\n"
            "2. Feature flags or config branches that always evaluate the same way\n"
            "3. Commented-out code blocks (>5 lines) that should be deleted or restored\n"
            "4. Unused dependencies in package.json/pyproject.toml/Cargo.toml\n"
            "5. Files that are not imported by anything\n\n"
            "Group related items: '12 unused imports across 5 files' = 1 finding, not 12."
        ),
    },
    "architecture": {
        "weight": "medium",
        "name": "Architecture Review",
        "description": (
            "Assess the codebase architecture:\n"
            "1. Separation of concerns — is business logic mixed with HTTP handling or database queries?\n"
            "2. Dependency direction — do lower-level modules depend on higher-level ones? (circular deps)\n"
            "3. God files — files over 500 lines that do too many things\n"
            "4. Duplicated logic — similar code in multiple places that should be a shared function\n"
            "5. Coupling — would changing one module force changes in many others?\n\n"
            "Suggest specific refactoring steps, not abstract principles."
        ),
    },
    "code-clarity": {
        "weight": "light",
        "name": "Code Clarity",
        "description": (
            "Review code readability and maintainability:\n"
            "1. Functions over 50 lines or with more than 3 levels of nesting\n"
            "2. Unclear naming — variables like x, tmp, data, result in non-trivial code\n"
            "3. Missing or misleading comments on complex business logic\n"
            "4. Inconsistent patterns — the same problem solved differently in different files\n"
            "5. Magic numbers/strings that should be named constants\n\n"
            "Focus on code that's hard to understand, not style preferences."
        ),
    },
    "test-gaps": {
        "weight": "medium",
        "name": "Test Coverage Gaps",
        "description": (
            "Identify critical code paths without test coverage:\n"
            "1. Find the main business logic functions — are they tested?\n"
            "2. Find error paths — are failure scenarios tested?\n"
            "3. Find edge cases in the code — are boundary values tested?\n"
            "4. Check test quality — are tests asserting the right things, or just that code runs without error?\n"
            "5. Find integration points (API calls, DB queries) — are they tested with realistic data?\n\n"
            "For each gap, describe what test should exist and what it should assert."
        ),
    },
    "performance": {
        "weight": "medium",
        "name": "Performance Review",
        "description": (
            "Find performance issues with measurable impact:\n"
            "1. Database: N+1 queries (query inside a loop), missing indexes, SELECT * where few columns needed\n"
            "2. Memory: loading entire datasets into memory, unbounded caches, large object retention\n"
            "3. I/O: synchronous I/O that could be async, missing connection pooling, no request timeouts\n"
            "4. Algorithms: O(n²) where O(n) is possible, repeated computation inside loops\n"
            "5. Network: missing pagination on list endpoints, no compression, oversized responses\n\n"
            "Only report if the impact is real (affects user experience or costs)."
        ),
    },
    "devops": {
        "weight": "light",
        "name": "DevOps Review",
        "description": (
            "Review DevOps and infrastructure configuration:\n"
            "1. Dockerfile: multi-stage build? minimal base image? not running as root? .dockerignore exists?\n"
            "2. CI/CD: do workflows run tests? lint? security scan? are secrets properly managed?\n"
            "3. Environment: are dev/staging/prod configs properly separated? are env vars documented?\n"
            "4. Scripts: are shell scripts (.sh) safe? quoting variables? error handling (set -e)?\n"
            "5. Dependencies: lockfile committed? pinned versions? known vulnerable versions?\n\n"
            "Check: Dockerfile, docker-compose.yml, .github/workflows/, Makefile, scripts/, .env.example"
        ),
    },
    "deployment-config": {
        "weight": "light",
        "name": "Deployment Readiness",
        "description": (
            "Review deployment and production readiness:\n"
            "1. Logging: is there structured logging? are log levels appropriate? are sensitive values redacted?\n"
            "2. Health checks: does the app expose a health endpoint? does it check dependencies (DB, cache)?\n"
            "3. Graceful shutdown: does the app handle SIGTERM? drain connections? finish in-flight requests?\n"
            "4. Configuration: are all hardcoded values that should be configurable extracted to env/config?\n"
            "5. Monitoring: are there metrics/tracing endpoints? error rate tracking? alerting hooks?"
        ),
    },
    "frontend": {
        "weight": "light",
        "name": "Frontend & UX",
        "description": (
            "Review frontend code quality and UX:\n"
            "1. Accessibility: missing alt text, no ARIA labels on interactive elements, poor keyboard navigation\n"
            "2. Responsive: does layout break on mobile? are touch targets at least 44px?\n"
            "3. Performance: large bundle imports, unoptimized images, layout shifts, unnecessary re-renders\n"
            "4. Error states: what does the user see when API calls fail? loading states? empty states?\n"
            "5. Forms: proper validation messages? prevents double-submit? handles paste correctly?\n\n"
            "Only check files in frontend directories (src/components, pages, views, public, etc.)"
        ),
    },
}

LANGUAGE_MAP = {
    "en": "English", "vi": "Tiếng Việt", "zh": "中文", "ja": "日本語",
    "ko": "한국어", "fr": "Français", "de": "Deutsch", "es": "Español",
    "pt": "Português", "ru": "Русский", "th": "ไทย", "id": "Bahasa Indonesia",
    "ar": "العربية",
}

# Model pricing per million tokens (USD)
MODEL_PRICING = {
    "claude-sonnet-4-6": {
        "input": 3.00,
        "output": 15.00,
        "cache_creation": 3.75,
        "cache_read": 0.30,
    },
}

# Default to Sonnet pricing (most commonly used model)
DEFAULT_PRICING = MODEL_PRICING["claude-sonnet-4-6"]
