"""Telegram notification hook — sends messages via Bot API."""

from __future__ import annotations
import json
import logging

logger = logging.getLogger(__name__)


class TelegramHook:
    name = "Telegram"
    description = "Send task notifications to a Telegram chat via Bot API"
    config_schema = [
        {"key": "bot_token", "label": "Bot Token", "type": "password", "required": True, "placeholder": "123456:ABC-DEF..."},
        {"key": "chat_id", "label": "Chat ID", "type": "text", "required": True, "placeholder": "-1001234567890"},
        {"key": "events", "label": "Events", "type": "multiselect", "required": False,
         "options": ["task.completed", "task.failed", "agent.started", "agent.stopped", "review.completed"],
         "default": ["task.completed", "task.failed"]},
    ]

    def __init__(self, config: dict):
        self.bot_token = config.get("bot_token", "")
        self.chat_id = config.get("chat_id", "")
        self.events = config.get("events", ["task.completed", "task.failed"])

    def handle(self, event) -> None:
        if event.event_type not in self.events:
            return
        try:
            import httpx
            text = self._format(event)
            url = f"https://api.telegram.org/bot{self.bot_token}/sendMessage"
            httpx.post(url, json={"chat_id": self.chat_id, "text": text, "parse_mode": "HTML"}, timeout=10)
        except Exception:
            logger.warning("Telegram hook failed for %s", event.event_type, exc_info=True)

    def _format(self, event) -> str:
        p = event.payload
        if event.event_type == "task.completed":
            return f"<b>Task Completed</b>\n{p.get('task_number', '')} {p.get('title', '')}\nProject: {p.get('project_id', '')}"
        if event.event_type == "task.failed":
            return f"<b>Task Failed</b>\n{p.get('task_number', '')} {p.get('title', '')}\nError: {p.get('error', '')}"
        return f"<b>{event.event_type}</b>\n{json.dumps(p, indent=2)}"
