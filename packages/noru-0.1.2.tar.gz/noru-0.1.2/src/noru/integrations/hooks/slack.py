"""Slack notification hook — sends messages via Incoming Webhooks."""

from __future__ import annotations
import json
import logging

logger = logging.getLogger(__name__)


class SlackHook:
    name = "Slack"
    description = "Send task notifications to a Slack channel via Incoming Webhook"
    config_schema = [
        {"key": "webhook_url", "label": "Webhook URL", "type": "text", "required": True, "placeholder": "https://hooks.slack.com/services/T.../B.../xxx"},
        {"key": "channel", "label": "Channel (optional)", "type": "text", "required": False, "placeholder": "#noru-notifications"},
        {"key": "events", "label": "Events", "type": "multiselect", "required": False,
         "options": ["task.completed", "task.failed", "agent.started", "agent.stopped", "review.completed"],
         "default": ["task.completed", "task.failed"]},
    ]

    def __init__(self, config: dict):
        self.webhook_url = config.get("webhook_url", "")
        self.channel = config.get("channel", "")
        self.events = config.get("events", ["task.completed", "task.failed"])

    def handle(self, event) -> None:
        if event.event_type not in self.events:
            return
        try:
            import httpx
            payload = {"text": self._format(event)}
            if self.channel:
                payload["channel"] = self.channel
            httpx.post(self.webhook_url, json=payload, timeout=10)
        except Exception:
            logger.warning("Slack hook failed for %s", event.event_type, exc_info=True)

    def _format(self, event) -> str:
        p = event.payload
        if event.event_type == "task.completed":
            return f":white_check_mark: *Task Completed*\n{p.get('task_number', '')} {p.get('title', '')}\nProject: {p.get('project_id', '')}"
        if event.event_type == "task.failed":
            return f":x: *Task Failed*\n{p.get('task_number', '')} {p.get('title', '')}\nError: {p.get('error', '')}"
        return f"*{event.event_type}*\n```{json.dumps(p, indent=2)}```"
