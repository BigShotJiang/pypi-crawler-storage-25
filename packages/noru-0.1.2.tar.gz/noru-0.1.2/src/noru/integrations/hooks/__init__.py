"""Community hook implementations. Drop a .py file here implementing NoruHook protocol."""
