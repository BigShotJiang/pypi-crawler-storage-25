"""Optional integration loader."""

from __future__ import annotations

from dataclasses import dataclass

from noru.core.models import Project
from noru.integrations.agency_agent import AgencyAgentIntegration
from noru.integrations.superpowers import SuperpowersIntegration


@dataclass
class Integrations:
    superpowers: SuperpowersIntegration | None = None
    agency_agent: AgencyAgentIntegration | None = None

    @classmethod
    def for_project(cls, project: Project) -> Integrations:
        sp = SuperpowersIntegration() if project.use_superpowers else None
        aa = (
            AgencyAgentIntegration(wrapper=project.agent_wrapper)
            if project.agent_wrapper
            else None
        )
        return cls(superpowers=sp, agency_agent=aa)

    def augment_prompt(self, prompt: str) -> str:
        if self.superpowers:
            return self.superpowers.augment_prompt(prompt)
        return prompt
