"""Optional /superpowers prompt injection."""

from __future__ import annotations


class SuperpowersIntegration:
    def augment_prompt(self, prompt: str) -> str:
        return f"/superpowers\n\n{prompt}"
