"""Optional agency-agent CLI wrapper."""

from __future__ import annotations


class AgencyAgentIntegration:
    def __init__(self, wrapper: str = ""):
        self.wrapper = wrapper

    def wrap_command(self, cmd: list[str]) -> list[str]:
        if not self.wrapper:
            return cmd
        parts = self.wrapper.split()
        return parts + cmd
