"""Allow running as `python -m noru`."""

from noru.interface.cli import main

main()
