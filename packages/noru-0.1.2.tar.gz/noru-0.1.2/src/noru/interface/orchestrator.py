"""Main orchestrator loop — integrates engine and executor layers."""

from __future__ import annotations

import logging
import re
import time
from datetime import datetime, timezone
from pathlib import Path

from noru.core.config import NoruConfig
from noru.core.constants import LANGUAGE_MAP
from noru.core.database import Database
from noru.core.models import WeeklyBudget, WindowStatus
from noru.engine.events import EventBus, NoruEvent
from noru.engine.queue_manager import QueueManager
from noru.engine.scheduler import Scheduler
from noru.engine.token_monitor import TokenMonitor
from noru.engine.usage_api import get_shared_usage_api
from noru.engine.webhook import WebhookHandler
from noru.engine.weekly_tracker import WeeklyTracker
from noru.executor.action_service import ClaudeAction, ClaudeActionService
from noru.executor.idle_reviewer import IdleReviewer
from noru.executor.job_scanner import JobScanner
from noru.executor.session_manager import SessionManager
from noru.executor.watermark import should_refill
from noru.executor.worker_pool import WorkerPool

logger = logging.getLogger(__name__)


def _strip_html(text: str) -> str:
    """Strip HTML tags from text for use in prompts."""
    clean = re.sub(r'<[^>]+>', ' ', text)
    clean = re.sub(r'\s+', ' ', clean).strip()
    return clean


def build_comment_context(db: Database, task_id: int) -> str:
    """Build context string from recent relevant comments for a task."""
    runs = db.get_task_runs(task_id)
    last_success = None
    for run in runs:
        if run.status == "success":
            last_success = run.ended_at
            break
    comments = db.get_recent_task_comments(task_id, since=last_success)
    if not comments:
        return ""
    comments = comments[-10:]
    lines = ["Previous attempt context:"]
    for c in comments:
        body = _strip_html(c.body) if '<' in c.body else c.body
        lines.append(f"[{c.author}] {body}")
    return "\n".join(lines)


class OrchestratorLoop:
    def __init__(
        self, db: Database, config: NoruConfig,
        jsonl_dir: Path | None = None,
    ):
        self.db = db
        self.config = config
        self.jsonl_dir = jsonl_dir or Path.home() / ".claude" / "projects"

        self.scheduler = Scheduler()
        self.queue = QueueManager(db)

        # Worker pool with session management
        self.session_manager = SessionManager()
        self.pool = WorkerPool(
            config=config.worker_pool,
            session_manager=self.session_manager,
        )
        self._rate_limited = False
        self._last_scan: dict[str, datetime] = {}

        # Initialize event bus with configured webhooks
        self.event_bus = EventBus()
        for wh in config.webhooks:
            self.event_bus.subscribe(WebhookHandler(url=wh.url, events=wh.events, body_template=wh.body_template))

        from noru.engine.activity_logger import ActivityLogger
        self.activity_logger = ActivityLogger(db)
        self.event_bus.subscribe(self.activity_logger)

        # Load plugin hooks from integrations directory
        from noru.engine.hook_registry import HookRegistry
        self.hook_registry = HookRegistry()
        self.hook_registry.discover()
        for slug, int_config in config.integrations.items():
            if int_config.enabled:
                hook = self.hook_registry.load(slug, int_config.config)
                if hook:
                    self.event_bus.subscribe(hook)

        # IdleReviewer and JobScanner — action_service set per-worker at dispatch time
        self.idle_reviewer = IdleReviewer(config=config, db=db)
        self.job_scanner = JobScanner(
            db=db, config=config, idle_reviewer=self.idle_reviewer,
            event_bus=self.event_bus,
        )

        self.token_monitor = TokenMonitor(
            jsonl_dir=self.jsonl_dir,
            window_tokens=config.max20_window_tokens,
            window_hours=config.window_duration_hours,
        )
        self.weekly_tracker = WeeklyTracker(
            jsonl_dir=self.jsonl_dir,
            weekly_limit=config.weekly.seed_limit,
            developer_reserve_pct=config.weekly.developer_reserve_pct,
        )
        self.usage_api = get_shared_usage_api()

    def run(self) -> None:
        """Main loop — call from a daemon thread."""
        logger.info("Orchestrator loop started")

        try:
            while True:
                try:
                    should_continue = self.tick()
                    if not should_continue:
                        break
                except Exception:
                    logger.exception("Error in orchestrator tick")
                time.sleep(self.config.loop_interval_seconds)
        finally:
            self.pool.stop_all()

        logger.info("Orchestrator loop exited")

    def tick(self) -> bool:
        """Execute one cycle of the orchestrator. Returns False to stop."""
        # Hot-reload config
        from noru.core.config import load_config
        config_path = self.db.db_path.parent / "config.yaml"
        self.config = load_config(config_path)
        self.idle_reviewer.config = self.config

        state = self.db.get_agent_state()

        if state.state == "stopping":
            self.db.update_agent_state("stopped", stopped_by="user")
            self.event_bus.emit(NoruEvent("agent.stopped", {"stopped_by": "user"}))
            logger.info("Agent stopped by user")
            return False

        if state.state == "stopped":
            return True  # keep looping but don't dispatch

        if state.state == "paused":
            return True  # keep looping, server stays up, skip all dispatch/scan

        # Health check: remove dead workers and fail their pending jobs
        dead_projects = self.pool.health_check()
        for pid in dead_projects:
            pending = self.db.get_pending_jobs_for_project(pid)
            for job in pending:
                now = datetime.now(timezone.utc).isoformat()
                self.db.complete_job(job.id, status="error", error="Worker tmux session died", completed_at=now)
                logger.warning("Failed pending job #%d for dead worker %s", job.id, pid)

        # Auto-promote TODO → READY when enabled
        if self.config.auto_ready:
            promoted = self.db.promote_todo_to_ready()
            if promoted:
                logger.info("Auto-promoted %d TODO tasks to READY", promoted)

        # Scan completed jobs (check pending DB jobs against their JSON files)
        self.job_scanner.scan()
        self._rate_limited = getattr(self.job_scanner, 'rate_limited', False)

        # Get current budget status
        window = self._get_window()
        weekly = self._get_weekly()

        # Log usage history
        usage = self.usage_api.get_usage()
        if usage.error is None:
            self.db.log_usage(session_pct=usage.session_pct, weekly_pct=usage.weekly_pct)

        # Make scheduling decision
        decision = self.scheduler.decide(
            window=window,
            weekly=weekly,
            queue_depth=self.db.queue_depth(),
            max_session_pct=self.config.max_session_pct,
            max_weekly_pct=self.config.max_weekly_pct,
            rate_limited=self._rate_limited,
        )

        logger.info("Scheduler decision: %s (%s)", decision.action, decision.reason)

        if decision.action == "sleep":
            logger.info("Sleep — %s", decision.reason)
            return True

        # Iterate over active projects and tick each one
        projects = self.db.active_projects()
        for project in projects:
            self._tick_project(project, decision, window)

        return True

    def _tick_project(self, project, decision, window) -> None:
        """Two concerns: dispatch work + refill queue."""
        pid = project.id

        # --- Concern 1: Dispatch ---
        if decision.action in ("dispatch", "idle"):
            worker = self.pool.get_worker(pid)
            if worker is None:
                worker = self.pool.assign_worker(pid, cwd=project.repo_path)
            if worker is None:
                preempt_pid = self.pool.find_preemptible("task")
                if preempt_pid:
                    self.pool.release_worker(preempt_pid)
                    worker = self.pool.assign_worker(pid, cwd=project.repo_path)
            if worker is None:
                return

            if not worker.is_alive():
                if not worker.start():
                    return

            if worker.is_idle():
                doing_tasks = self.db.list_tasks(project_id=pid, status="doing")
                if doing_tasks:
                    self._dispatch_to_worker(doing_tasks[0], project)
                else:
                    task = self.queue.next_eligible(window, self._get_weekly(), project_id=pid)
                    if task:
                        now = datetime.now(timezone.utc).isoformat()
                        self.db.update_task(task.id, status="doing", started_at=now)
                        self._dispatch_to_worker(task, project)

        # --- Concern 2: Refill (runs even if we just dispatched) ---
        if decision.action != "sleep":
            ready_count = self.db.queue_depth(project_id=pid)
            has_pending = bool(self.db.get_pending_jobs_for_project(pid))
            if should_refill(ready_count, has_pending, self.config.watermark.low_watermark):
                self._run_scan_for_project(project)

    def _dispatch_to_worker(self, task, project) -> None:
        """Dispatch a task to a worker. Replaces _execute_doing_task and _dispatch_task."""
        pid = project.id

        # Get or assign worker
        worker = self.pool.get_worker(pid)
        if worker is None:
            worker = self.pool.assign_worker(pid, cwd=project.repo_path)
        if worker is None:
            # No slot available — try preemption
            preempt_pid = self.pool.find_preemptible("task")
            if preempt_pid:
                self.pool.release_worker(preempt_pid)
                worker = self.pool.assign_worker(pid, cwd=project.repo_path)
        if worker is None:
            logger.warning("No worker slot available for project %s", pid)
            return

        # Start worker if not alive
        if not worker.is_alive():
            if not worker.start():
                logger.error("Failed to start worker for project %s", pid)
                return

        # Check if worker is idle (not busy with another task)
        if not worker.is_idle():
            return

        # Create per-worker action service
        action_service = ClaudeActionService(
            tmux_controller=worker,
            db=self.db,
        )

        plan = self.db.get_plan(task.plan_id) if task.plan_id else None

        # Create TaskRun
        window_id = datetime.now(timezone.utc).strftime("%Y-%m-%d-%H")
        run_id = self.db.create_task_run(task.id, task.project_id, window_id)

        prompt = self._build_task_prompt(task, project, plan)
        context = self._build_comment_context(task.id)
        if context:
            prompt += "\n\n" + context

        action = ClaudeAction(
            action_type="task",
            prompt=prompt,
            project_id=project.id,
            metadata={"task_id": task.id, "run_id": run_id},
        )
        job_id = action_service.dispatch(action)
        if job_id:
            worker.current_job_type = "task"
            logger.info("Dispatched task %s #%d (job #%d) to worker %s",
                        task.task_number or '', task.id, job_id, pid)
        else:
            logger.warning("Failed to dispatch task #%d — worker busy or unavailable", task.id)

    def _run_scan_for_project(self, project) -> None:
        """Run idle review scan for a project using watermark cooldown."""
        pid = project.id

        # Simple timestamp cooldown
        last_scan = self._last_scan.get(pid)
        if last_scan:
            elapsed = (datetime.now(timezone.utc) - last_scan).total_seconds()
            if elapsed < self.config.watermark.scan_cooldown_seconds:
                return

        # Get or assign worker
        worker = self.pool.get_worker(pid)
        if worker is None:
            worker = self.pool.assign_worker(pid, cwd=project.repo_path)
        if worker is None:
            preempt_pid = self.pool.find_preemptible("review")
            if preempt_pid:
                self.pool.release_worker(preempt_pid)
                worker = self.pool.assign_worker(pid, cwd=project.repo_path)
        if worker is None:
            return

        if not worker.is_alive():
            if not worker.start():
                return

        action_service = ClaudeActionService(tmux_controller=worker, db=self.db)
        self.idle_reviewer.action_service = action_service

        if not worker.is_idle():
            return

        worker.current_job_type = "review"
        job_id = self.idle_reviewer.run_review(project)
        if job_id:
            self._last_scan[pid] = datetime.now(timezone.utc)

    def _build_task_prompt(self, task, project, plan) -> str:
        parts = []
        parts.append(
            f"Project: {project.name}\nRepository: {project.repo_path}\nDescription: {project.description}"
        )
        if plan and plan.approach:
            parts.append(f"Approach:\n{plan.approach}")

        # Guardrails — strict boundaries the agent must not violate
        if self.config.guardrails_enabled and self.config.guardrails:
            lines = ["STRICT BOUNDARIES — You MUST NOT violate these rules:"]
            for rule in self.config.guardrails:
                lines.append(f"- {rule}")
            lines.append("Do not make changes that violate the above. If the task requires violating a boundary, skip it and report why.")
            parts.append("\n".join(lines))

        # Language injection
        if self.config.language != "en":
            lang_name = LANGUAGE_MAP.get(self.config.language, self.config.language)
            lang_text = (
                f"IMPORTANT: Respond ENTIRELY in {lang_name}. "
                f"All output, comments, and descriptions must be in {lang_name}."
            )
            if self.config.english_commits:
                lang_text += " Exception: Git commit messages must always be in English."
            parts.append(lang_text)

        # Task description
        task_text = task.description or task.title

        # Superpowers integration
        from noru.integrations import Integrations
        integrations = Integrations.for_project(project)
        task_text = integrations.augment_prompt(task_text)

        parts.append(task_text)

        if self.config.auto_commit:
            commit_instruction = "After completing the task, commit your changes with a descriptive message."
            if task.task_number:
                commit_instruction = (
                    f"After completing the task, commit your changes. "
                    f"Prefix the commit message with [{task.task_number}] "
                    f"(e.g., [{task.task_number}] Fix validation)."
                )
            parts.append(
                commit_instruction + " "
                "Include the commit hash in your output as: COMMIT_HASH: <hash>"
            )

        parts.append("After completing the task, output a one-sentence summary of what was done.")

        return "\n\n".join(parts)

    def _build_comment_context(self, task_id: int) -> str:
        return build_comment_context(self.db, task_id)

    def _get_window(self) -> WindowStatus:
        """Get window status. Prefer real API data, fallback to local estimate."""
        usage = self.usage_api.get_usage()
        if usage.error is None:
            # Real API data: convert percentage to token-equivalent for scheduler
            pct_used = usage.session_pct / 100.0
            limit = self.config.max20_window_tokens
            used = int(limit * pct_used)
            return WindowStatus(
                start="", reset_at=usage.session_resets_at,
                used=used, limit=limit,
            )
        # Fallback to local estimate
        logger.debug("Using local token estimate (API unavailable: %s)", usage.error)
        return self.token_monitor.current_window()

    def _get_weekly(self) -> WeeklyBudget:
        """Get weekly budget. Prefer real API data, fallback to local estimate.

        Note: weekly_pct from API includes ALL usage (developer + agent).
        We don't know how much is Noru's vs developer's. To avoid being
        overly restrictive, we report weekly as healthy when session is OK.
        The session limit is the real bottleneck for dispatch decisions.
        """
        usage = self.usage_api.get_usage()
        if usage.error is None:
            # Use a generous weekly budget since session limit is the real gate
            # Weekly pct includes developer usage which we can't separate
            return WeeklyBudget(
                total_used=0, weekly_limit=self.config.weekly.seed_limit,
                developer_reserve_pct=self.config.weekly.developer_reserve_pct,
            )
        return self.weekly_tracker.budget()

