"""FastAPI server — CRUD, stats, agent control, dashboard mount."""

from __future__ import annotations

import asyncio
import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from noru import __version__
from noru.core.config import NoruConfig
from noru.core.database import Database
from noru.engine.token_monitor import TokenMonitor
from noru.engine.usage_api import get_shared_usage_api
from noru.engine.weekly_tracker import WeeklyTracker


# --- Request/Response models ---

class ProjectCreate(BaseModel):
    id: str
    name: str
    repo_path: str
    description: str = ""
    allowed_tools: str = "Read,Edit,Bash,Glob"
    use_superpowers: bool = False
    short_code: str = ""

class ProjectUpdate(BaseModel):
    name: str | None = None
    description: str | None = None
    allowed_tools: str | None = None
    use_superpowers: bool | None = None
    active: bool | None = None
    short_code: str | None = None

class TaskCreate(BaseModel):
    project_id: str
    title: str
    plan_id: int | None = None
    description: str = ""
    priority: int = 3
    token_weight: str = "medium"
    max_turns: int = 20

class TaskUpdate(BaseModel):
    title: str | None = None
    status: str | None = None
    priority: int | None = None
    token_weight: str | None = None
    description: str | None = None

class CommentCreate(BaseModel):
    body: str


def create_app(
    db: Database, config: NoruConfig, loop: Any = None,
    action_service: Any = None,
) -> FastAPI:
    app = FastAPI(title="Noru", version=__version__)
    usage_api = get_shared_usage_api()

    # --- Projects ---

    @app.get("/projects")
    def list_projects():
        return [_project_dict(p) for p in db.all_projects()]

    @app.post("/projects", status_code=201)
    def create_project(body: ProjectCreate):
        db.create_project(
            body.id, body.name, body.repo_path,
            description=body.description,
            allowed_tools=body.allowed_tools,
            use_superpowers=body.use_superpowers,
            short_code=body.short_code,
        )
        p = db.get_project(body.id)
        db.log_activity("project.created", f"Project '{body.name}' created", entity_type="project", entity_id=body.id, project_id=body.id)
        return _project_dict(p)

    @app.patch("/projects/{project_id}")
    def update_project(project_id: str, body: ProjectUpdate):
        updates = {k: v for k, v in body.model_dump().items() if v is not None}
        if not updates:
            raise HTTPException(400, "No fields to update")
        db.update_project(project_id, **updates)
        p = db.get_project(project_id)
        db.log_activity("project.updated", f"Project '{project_id}' updated", entity_type="project", entity_id=project_id, project_id=project_id)
        return _project_dict(p)

    @app.post("/projects/{project_id}/archive")
    def archive_project(project_id: str):
        db.archive_project(project_id)
        return {"status": "archived"}

    @app.post("/projects/{project_id}/unarchive")
    def unarchive_project(project_id: str):
        db.unarchive_project(project_id)
        return {"status": "unarchived"}

    @app.delete("/projects/{project_id}")
    def delete_project_permanently(project_id: str):
        db.delete_project(project_id)
        return {"status": "deleted"}

    # --- Filesystem browser (for folder picker) ---

    @app.get("/fs/browse")
    def browse_directory(path: str = "~"):
        """List directories at the given path for folder picker."""
        from pathlib import Path as P
        target = P(path).expanduser().resolve()
        if not target.is_dir():
            return {"path": str(target), "dirs": [], "error": "Not a directory"}
        dirs = []
        try:
            for entry in sorted(target.iterdir()):
                if entry.is_dir() and not entry.name.startswith('.'):
                    dirs.append(entry.name)
        except PermissionError:
            return {"path": str(target), "dirs": [], "error": "Permission denied"}
        return {"path": str(target), "parent": str(target.parent), "dirs": dirs}

    @app.get("/fs/resolve")
    def resolve_directory(name: str):
        """Find a directory by name. Searches common workspace dirs first, then broader."""
        import subprocess
        from pathlib import Path as P
        home = P.home()

        # Fast path: check common workspace directories first (depth 2)
        common_dirs = [
            home / "Documents",
            home / "Projects",
            home / "Code",
            home / "Developer",
            home / "repos",
            home / "workspace",
            home / "Desktop",
        ]
        for parent in common_dirs:
            if not parent.exists():
                continue
            try:
                result = subprocess.run(
                    ["find", str(parent), "-maxdepth", "3", "-type", "d", "-name", name, "-not", "-path", "*/.*", "-not", "-path", "*/node_modules/*"],
                    capture_output=True, text=True, timeout=5,
                )
                paths = [p.strip() for p in result.stdout.strip().split("\n") if p.strip()]
                if paths:
                    paths.sort(key=len)
                    return {"path": paths[0]}
            except (subprocess.TimeoutExpired, OSError):
                continue

        # Fallback: broader search from home (depth 5, longer timeout)
        try:
            result = subprocess.run(
                ["find", str(home), "-maxdepth", "5", "-type", "d", "-name", name, "-not", "-path", "*/.*", "-not", "-path", "*/node_modules/*"],
                capture_output=True, text=True, timeout=10,
            )
            paths = [p.strip() for p in result.stdout.strip().split("\n") if p.strip()]
            if paths:
                paths.sort(key=len)
                return {"path": paths[0]}
        except (subprocess.TimeoutExpired, OSError):
            pass
        return {"path": name, "error": "Directory not found"}

    # --- Features ---

    @app.get("/projects/{project_id}/features")
    def list_features(project_id: str):
        return [_feature_dict(f) for f in db.get_project_features(project_id)]

    # --- Tasks ---

    @app.get("/tasks")
    def list_tasks(
        project: str | None = None, status: str | None = None,
        search: str | None = None, priority: int | None = None,
        source: str | None = None,
        sort: str = "created_at", order: str = "desc",
        page: int = 1, limit: int = 10,
    ):
        result = db.list_tasks_paginated(
            project_id=project, status=status, search=search,
            priority=priority, source=source, active_only=True,
            sort=sort, order=order, page=page, limit=limit,
        )
        result["tasks"] = [_task_dict(t) for t in result["tasks"]]
        return result

    @app.get("/tasks/kanban")
    def kanban_tasks(
        project: str | None = None,
        limit: int = 50,
    ):
        """Return tasks grouped by status for the kanban board.

        Each column gets its own query with independent pagination.
        Active columns (ready, doing, review) return ALL tasks.
        Backlog (todo) and archive (done, failed) are capped at `limit`.
        """
        columns = {}
        for status in ["todo", "ready", "doing", "review", "done", "failed"]:
            # Active work columns: return all (no cap)
            col_limit = 9999 if status in ("ready", "doing", "review") else limit
            sort = "priority" if status in ("todo", "ready") else "created_at"
            order = "asc" if status in ("todo", "ready") else "desc"
            result = db.list_tasks_paginated(
                project_id=project, status=status, active_only=True,
                sort=sort, order=order,
                page=1, limit=col_limit,
            )
            columns[status] = {
                "tasks": [_task_dict(t) for t in result["tasks"]],
                "total": result["total"],
            }
        return columns

    @app.post("/tasks", status_code=201)
    def create_task(body: TaskCreate):
        initial_status = "ready" if config.auto_ready else "todo"
        task_id = db.create_task(
            project_id=body.project_id, title=body.title,
            plan_id=body.plan_id, description=body.description,
            priority=body.priority, token_weight=body.token_weight,
            max_turns=body.max_turns, status=initial_status,
        )
        t = db.get_task(task_id)
        task_number = t.task_number or str(task_id)
        db.log_activity("task.created", f"Task {task_number} created: {body.title}", entity_type="task", entity_id=task_number, project_id=body.project_id)
        return _task_dict(t)

    @app.patch("/tasks/{task_id}")
    def update_task(task_id: int, body: TaskUpdate):
        updates = {k: v for k, v in body.model_dump().items() if v is not None}
        if not updates:
            raise HTTPException(400, "No fields to update")
        old_task = db.get_task(task_id)
        old_status = old_task.status if old_task else None
        db.update_task(task_id, **updates)
        t = db.get_task(task_id)
        if t:
            task_number = t.task_number or str(task_id)
            if body.status and old_status and old_status != body.status:
                db.log_activity("task.status_changed", f"Task {task_number}: {old_status.upper()} → {body.status.upper()}", entity_type="task", entity_id=task_number, project_id=t.project_id)
            if body.priority is not None and old_task and old_task.priority != body.priority:
                db.log_activity("task.priority_changed", f"Task {task_number}: priority P{old_task.priority} → P{body.priority}", entity_type="task", entity_id=task_number, project_id=t.project_id)
            if body.token_weight is not None and old_task and old_task.token_weight != body.token_weight:
                db.log_activity("task.weight_changed", f"Task {task_number}: weight {old_task.token_weight} → {body.token_weight}", entity_type="task", entity_id=task_number, project_id=t.project_id)
        return _task_dict(t)

    @app.delete("/tasks/{task_id}")
    def delete_task(task_id: int):
        task = db.get_task(task_id)
        if task and task.status != "todo":
            raise HTTPException(400, "Can only delete tasks with status 'todo'")
        db.update_task(task_id, status="deleted")
        return {"status": "deleted"}

    @app.get("/tasks/{task_id}/runs")
    def list_task_runs(task_id: int):
        return [_run_dict(r) for r in db.get_task_runs(task_id)]

    # --- Comments ---

    @app.get("/tasks/{task_id}/comments")
    def list_comments(task_id: int):
        return [_comment_dict(c) for c in db.get_task_comments(task_id)]

    @app.post("/tasks/{task_id}/comment", status_code=201)
    def create_comment(task_id: int, body: CommentCreate):
        comment_id = db.create_comment(task_id, body.body, author="user")
        comments = db.get_task_comments(task_id)
        t = db.get_task(task_id)
        if t:
            task_number = t.task_number or str(task_id)
            db.log_activity("task.commented", f"Comment on {task_number} by user", entity_type="task", entity_id=task_number, project_id=t.project_id)
        return _comment_dict([c for c in comments if c.id == comment_id][0])

    # --- Fix ---

    @app.post("/tasks/{task_id}/fix")
    def fix_task(task_id: int):
        task = db.get_task(task_id)
        if not task:
            raise HTTPException(404, "Task not found")
        if task.status != "failed":
            raise HTTPException(400, "Can only fix tasks with status 'failed'")

        project = db.get_project(task.project_id)
        if not project:
            raise HTTPException(404, "Project not found")

        if action_service is None:
            raise HTTPException(503, "Action service not available")

        # Build fix prompt
        from noru.interface.orchestrator import build_comment_context
        context = build_comment_context(db, task_id)

        prompt_parts = [
            f"You are fixing a failed task for the {project.name} project at {project.repo_path}.",
            f"Task: {task.title}",
        ]
        if task.description:
            prompt_parts.append(f"Description: {task.description}")
        if context:
            prompt_parts.append(context)
        prompt_parts.append("Analyze the failure, implement the fix, and report what you changed.")
        prompt = "\n\n".join(prompt_parts)

        from noru.executor.action_service import ClaudeAction
        action = ClaudeAction(
            action_type="fix",
            prompt=prompt,
            project_id=project.id,
            metadata={"task_id": task.id},
        )
        result = action_service.execute(action)

        if result.success:
            db.update_task(task_id, status="ready")
            db.create_comment(task_id, f"Fix applied: {result.result or 'No details'}"[:500], author="system")
            return {"status": "ok", "summary": result.result or ""}
        else:
            db.create_comment(task_id, f"Fix failed: {result.error or 'Unknown'}"[:500], author="system")
            return {"status": "error", "error": result.error or "Unknown failure"}

    # --- Stats ---

    @app.get("/stats/overview")
    def stats_overview():
        try:
            total = db.execute(
                "SELECT COUNT(*) as c FROM tasks t JOIN projects p ON t.project_id = p.id WHERE p.active = 1"
            ).fetchone()["c"]
            done = db.execute(
                "SELECT COUNT(*) as c FROM tasks t JOIN projects p ON t.project_id = p.id WHERE t.status = 'done' AND p.active = 1"
            ).fetchone()["c"]
            failed = db.execute(
                "SELECT COUNT(*) as c FROM tasks t JOIN projects p ON t.project_id = p.id WHERE t.status = 'failed' AND p.active = 1"
            ).fetchone()["c"]
            active = db.execute("SELECT COUNT(*) as c FROM projects WHERE active = 1").fetchone()["c"]
            terminal = done + failed
            completion_rate = round(done / terminal * 100, 1) if terminal > 0 else 0
            return {
                "tasks_done": done,
                "completion_rate": completion_rate,
                "active_projects": active,
                "total_tasks": total,
            }
        except Exception as e:
            return {"tasks_done": 0, "completion_rate": 0, "active_projects": 0, "total_tasks": 0, "error": str(e)}

    @app.get("/stats/window")
    def stats_window():
        jsonl_dir = Path.home() / ".claude" / "projects"
        monitor = TokenMonitor(
            jsonl_dir=jsonl_dir,
            window_tokens=config.max20_window_tokens,
        )
        window = monitor.current_window()
        state = db.get_agent_state()
        return {
            "window_start": window.start,
            "window_reset": window.reset_at,
            "tokens_used": window.used,
            "tokens_limit": window.limit,
            "tokens_remaining": window.tokens_remaining,
            "pct_remaining": round(window.pct_remaining, 3),
            "cost_usd": window.cost_usd,
            "cost_limit": window.cost_limit,
            "cost_pct_used": round(window.cost_pct_used, 3),
            "input_tokens": window.input_tokens,
            "output_tokens": window.output_tokens,
            "cache_creation_tokens": window.cache_creation_tokens,
            "cache_read_tokens": window.cache_read_tokens,
            "agent_status": state.state,
        }

    @app.get("/stats/noru-usage")
    def noru_usage():
        """Noru's own token usage from task runs."""
        row = db.conn.execute(
            "SELECT COALESCE(SUM(tokens_input),0) as ti, COALESCE(SUM(tokens_output),0) as to_, "
            "COALESCE(SUM(cost_usd),0) as cost, COUNT(*) as cnt FROM task_runs"
        ).fetchone()

        return {
            "total_input_tokens": row["ti"],
            "total_output_tokens": row["to_"],
            "total_tokens": row["ti"] + row["to_"],
            "total_cost_usd": round(row["cost"], 4),
            "total_runs": row["cnt"],
        }

    @app.get("/stats/usage")
    def stats_usage():
        """Real usage from Anthropic API."""
        usage = usage_api.get_usage()
        return {
            "session_pct": usage.session_pct,
            "session_remaining_pct": usage.session_remaining_pct,
            "session_resets_at": usage.session_resets_at,
            "weekly_pct": usage.weekly_pct,
            "weekly_remaining_pct": usage.weekly_remaining_pct,
            "weekly_resets_at": usage.weekly_resets_at,
            "weekly_sonnet_pct": usage.weekly_sonnet_pct,
            "weekly_opus_pct": usage.weekly_opus_pct,
            "error": usage.error,
        }

    @app.get("/stats/usage-history")
    def usage_history(hours: int = 24):
        return db.get_usage_history(hours=hours)

    @app.get("/stats/weekly")
    def stats_weekly():
        jsonl_dir = Path.home() / ".claude" / "projects"
        tracker = WeeklyTracker(
            jsonl_dir=jsonl_dir,
            weekly_limit=config.weekly.seed_limit,
        )
        budget = tracker.budget()
        return {
            "total_used": budget.total_used,
            "weekly_limit": budget.weekly_limit,
            "agent_allocation": budget.agent_allocation,
            "agent_remaining": budget.agent_budget_remaining,
            "developer_reserve_pct": budget.developer_reserve_pct,
        }

    @app.get("/stats/burndown")
    def stats_burndown():
        """Burndown data: remaining tasks per project over 14 days."""
        from datetime import timedelta

        now = datetime.now(timezone.utc)
        projects_data = {}

        for proj in db.active_projects():
            total = db.execute(
                "SELECT COUNT(*) as c FROM tasks WHERE project_id = ? AND status != 'rejected'",
                (proj.id,)
            ).fetchone()["c"]

            daily = []
            for i in range(13, -1, -1):
                day_end = (now - timedelta(days=i)).replace(hour=23, minute=59, second=59)
                completed_by = db.execute(
                    "SELECT COUNT(*) as c FROM tasks WHERE project_id = ? AND status = 'done' AND completed_at IS NOT NULL AND completed_at <= ?",
                    (proj.id, day_end.isoformat())
                ).fetchone()["c"]
                remaining = total - completed_by
                daily.append({"date": day_end.strftime("%m/%d"), "remaining": remaining, "completed": completed_by})

            projects_data[proj.id] = {"name": proj.name, "total": total, "daily": daily}

        return projects_data

    @app.get("/stats/analytics")
    def stats_analytics():
        """Aggregated analytics for the Stats tab."""
        from datetime import timedelta

        now = datetime.now(timezone.utc)
        seven_days_ago = (now - timedelta(days=7)).isoformat()

        # Completion rate (active projects only)
        done_count = db.execute("SELECT COUNT(*) as c FROM tasks t JOIN projects p ON t.project_id = p.id WHERE t.status = 'done' AND p.active = 1").fetchone()["c"]
        failed_count = db.execute("SELECT COUNT(*) as c FROM tasks t JOIN projects p ON t.project_id = p.id WHERE t.status = 'failed' AND p.active = 1").fetchone()["c"]
        total_terminal = done_count + failed_count
        completion_rate = round(done_count / total_terminal * 100, 1) if total_terminal > 0 else 0

        # Avg session usage (7d) — average session_pct from usage_history where session_pct > 0
        session_rows = db.execute(
            "SELECT AVG(session_pct) as avg_pct FROM usage_history "
            "WHERE session_pct > 0 AND timestamp > ?", (seven_days_ago,)
        ).fetchone()
        avg_session_usage = round(session_rows["avg_pct"], 1) if session_rows["avg_pct"] else 0

        # Cost 7d
        cost_row = db.execute(
            "SELECT COALESCE(SUM(cost_usd), 0) as total FROM task_runs WHERE ended_at > ?",
            (seven_days_ago,)
        ).fetchone()
        cost_7d = round(cost_row["total"], 2)

        # Tasks done (7d) — active projects only
        done_7d = db.execute(
            "SELECT COUNT(*) as c FROM tasks t JOIN projects p ON t.project_id = p.id "
            "WHERE t.status = 'done' AND t.completed_at > ? AND p.active = 1",
            (seven_days_ago,)
        ).fetchone()["c"]

        # Previous 7d for trend comparison
        prev_end = seven_days_ago
        prev_start = (now - timedelta(days=14)).isoformat()
        prev_cost = db.execute(
            "SELECT COALESCE(SUM(cost_usd), 0) as total FROM task_runs WHERE ended_at > ? AND ended_at <= ?",
            (prev_start, prev_end)
        ).fetchone()["total"]
        # Daily throughput (14 days)
        daily_throughput = []
        for i in range(13, -1, -1):
            day_start = (now - timedelta(days=i+1)).replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = (now - timedelta(days=i)).replace(hour=0, minute=0, second=0, microsecond=0)
            ds, de = day_start.isoformat(), day_end.isoformat()
            d = db.execute("SELECT COUNT(DISTINCT r.task_id) as c FROM task_runs r JOIN tasks t ON r.task_id = t.id JOIN projects p ON t.project_id = p.id WHERE r.status='success' AND r.ended_at>=? AND r.ended_at<? AND p.active = 1", (ds, de)).fetchone()["c"]
            f = db.execute("SELECT COUNT(DISTINCT r.task_id) as c FROM task_runs r JOIN tasks t ON r.task_id = t.id JOIN projects p ON t.project_id = p.id WHERE r.status='failed' AND r.ended_at>=? AND r.ended_at<? AND p.active = 1", (ds, de)).fetchone()["c"]
            daily_throughput.append({"date": day_start.strftime("%m/%d"), "done": d, "failed": f})

        # Daily cost (14 days)
        daily_cost = []
        for i in range(13, -1, -1):
            day_start = (now - timedelta(days=i+1)).replace(hour=0, minute=0, second=0, microsecond=0)
            day_end = (now - timedelta(days=i)).replace(hour=0, minute=0, second=0, microsecond=0)
            ds, de = day_start.isoformat(), day_end.isoformat()
            c = db.execute("SELECT COALESCE(SUM(r.cost_usd),0) as total FROM task_runs r JOIN tasks t ON r.task_id = t.id JOIN projects p ON t.project_id = p.id WHERE r.ended_at>=? AND r.ended_at<? AND p.active = 1", (ds, de)).fetchone()["total"]
            daily_cost.append({"date": day_start.strftime("%m/%d"), "cost_usd": round(c, 2)})

        # Cost by project
        project_rows = db.execute(
            "SELECT r.project_id, COALESCE(SUM(r.cost_usd),0) as total_cost, COUNT(*) as run_count "
            "FROM task_runs r JOIN projects p ON r.project_id = p.id "
            "WHERE p.active = 1 GROUP BY r.project_id ORDER BY total_cost DESC"
        ).fetchall()
        cost_by_project = [{"project_id": r["project_id"], "cost_usd": round(r["total_cost"], 2), "run_count": r["run_count"]} for r in project_rows]

        # Per-project efficiency
        efficiency = []
        for proj in db.active_projects():
            p_done = db.execute("SELECT COUNT(*) as c FROM tasks WHERE project_id=? AND status='done'", (proj.id,)).fetchone()["c"]
            p_failed = db.execute("SELECT COUNT(*) as c FROM tasks WHERE project_id=? AND status='failed'", (proj.id,)).fetchone()["c"]
            p_total = p_done + p_failed
            p_rate = round(p_done / p_total * 100, 1) if p_total > 0 else 0
            run_stats = db.execute(
                "SELECT COALESCE(SUM(cost_usd),0) as total_cost, COALESCE(AVG(tokens_input+tokens_output),0) as avg_tokens, COUNT(*) as runs "
                "FROM task_runs WHERE project_id=?", (proj.id,)
            ).fetchone()
            efficiency.append({
                "project_id": proj.id, "project_name": proj.name,
                "done": p_done, "failed": p_failed, "success_rate": p_rate,
                "avg_tokens": int(run_stats["avg_tokens"]), "total_cost": round(run_stats["total_cost"], 2),
            })

        return {
            "completion_rate": completion_rate,
            "avg_session_usage": avg_session_usage,
            "cost_7d": cost_7d,
            "done_7d": done_7d,
            "prev_cost_7d": round(prev_cost, 2),
            "daily_throughput": daily_throughput,
            "daily_cost": daily_cost,
            "cost_by_project": cost_by_project,
            "efficiency": efficiency,
        }

    # --- Activity Log ---

    @app.get("/activity")
    def get_activity(limit: int = 20, page: int = 1, project_id: str | None = None, event_type: str | None = None):
        offset = (page - 1) * limit
        sql = "SELECT * FROM activity_log WHERE 1=1"
        count_sql = "SELECT COUNT(*) as c FROM activity_log WHERE 1=1"
        params = []
        count_params = []

        if project_id:
            sql += " AND project_id = ?"
            count_sql += " AND project_id = ?"
            params.append(project_id)
            count_params.append(project_id)
        if event_type:
            sql += " AND event_type = ?"
            count_sql += " AND event_type = ?"
            params.append(event_type)
            count_params.append(event_type)

        total = db.conn.execute(count_sql, tuple(count_params)).fetchone()["c"]

        sql += " ORDER BY created_at DESC LIMIT ? OFFSET ?"
        params.extend([limit, offset])

        rows = db.conn.execute(sql, tuple(params)).fetchall()
        items = [dict(r) for r in rows]

        return {
            "items": items,
            "total": total,
            "page": page,
            "limit": limit,
            "total_pages": max(1, -(-total // limit)),  # ceil division
        }

    # --- Config ---

    @app.get("/config")
    def get_config():
        # Always reload from file to reflect manual edits + orchestrator hot-reload
        from noru.core.config import load_config as _load_config
        config_path = db.db_path.parent / "config.yaml"
        current = _load_config(config_path)

        data = current.model_dump()

        # Enrich idle jobs with metadata from constants
        from noru.core.constants import IDLE_JOB_META
        enriched_jobs = []
        for entry in data["idle_jobs"]["jobs"]:
            meta = IDLE_JOB_META.get(entry["id"], {})
            enriched_jobs.append({
                **entry,
                "name": meta.get("name", entry["id"]),
                "weight": entry.get("weight") or meta.get("weight", "light"),
                "description": entry.get("description") or meta.get("description", ""),
            })
        data["idle_jobs"]["jobs"] = enriched_jobs

        return data

    @app.post("/config")
    def save_config(body: dict):
        """Validate and save config to ~/.noru/config.yaml. Preserves integrations."""
        import yaml
        from noru.core.config import load_config as _load, NoruConfig as _NoruConfig
        config_path = db.db_path.parent / "config.yaml"
        existing = _load(config_path)
        old_dict = existing.model_dump()
        # Preserve integrations from existing config (managed via /integrations endpoint)
        if "integrations" not in body:
            body["integrations"] = old_dict.get("integrations", {})
        validated = _NoruConfig(**body)
        config_path.write_text(yaml.dump(validated.model_dump(), default_flow_style=False, sort_keys=False))
        new_dict = validated.model_dump()
        _skip = {"webhooks", "integrations", "idle_jobs"}
        changes = [
            f"{key}: {old_dict.get(key)} → {new_dict.get(key)}"
            for key in new_dict
            if key not in _skip and old_dict.get(key) != new_dict.get(key)
        ]
        if changes:
            desc = "Config updated: " + "; ".join(changes[:5])
            if len(changes) > 5:
                desc += f" (+{len(changes) - 5} more)"
        else:
            desc = "Configuration saved (no changes)"
        db.log_activity("config.updated", desc, entity_type="config")
        return {"status": "saved"}

    # --- Integrations ---

    @app.get("/integrations")
    def list_integrations():
        from noru.engine.hook_registry import HookRegistry
        registry = HookRegistry()
        hooks = registry.discover()

        # Load current config
        from noru.core.config import load_config as _load
        current = _load(db.db_path.parent / "config.yaml")

        result = []
        for hook in hooks:
            int_config = current.integrations.get(hook.slug, None)
            result.append({
                "slug": hook.slug,
                "name": hook.name,
                "description": hook.description,
                "config_schema": hook.config_schema,
                "enabled": int_config.enabled if int_config else False,
                "config": int_config.config if int_config else {},
            })
        return result

    @app.post("/integrations/{slug}")
    def save_integration(slug: str, body: dict):
        import yaml
        from noru.core.config import load_config as _load, NoruConfig as _NC
        config_path = db.db_path.parent / "config.yaml"
        current = _load(config_path)
        data = current.model_dump()
        data["integrations"][slug] = {
            "enabled": body.get("enabled", False),
            "config": body.get("config", {}),
        }
        validated = _NC(**data)
        config_path.write_text(yaml.dump(validated.model_dump(), default_flow_style=False, sort_keys=False))
        return {"status": "saved"}

    @app.post("/integrations/{slug}/test")
    def test_integration(slug: str, body: dict | None = None):
        from noru.engine.hook_registry import HookRegistry
        from noru.engine.events import NoruEvent
        from noru.core.config import load_config as _load

        registry = HookRegistry()
        registry.discover()

        # Use config from request body (unsaved UI state) or fall back to saved config
        hook_config = {}
        if body and body.get("config"):
            hook_config = body["config"]
        else:
            current = _load(db.db_path.parent / "config.yaml")
            int_config = current.integrations.get(slug)
            if int_config:
                hook_config = int_config.config

        if not hook_config:
            raise HTTPException(400, f"No config for integration '{slug}'. Fill in the fields and try again.")

        hook = registry.load(slug, hook_config)
        if not hook:
            raise HTTPException(500, f"Failed to load hook '{slug}'")

        # Use task.completed as event type so it passes through the hook's event filter
        test_event = NoruEvent(
            event_type="task.completed",
            payload={"message": f"Test notification from noru", "task_number": "TEST-001", "title": "Test notification from noru", "project_id": "test", "commit_hash": "", "summary": "This is a test event to verify the integration works."},
        )
        try:
            hook.handle(test_event)
            return {"status": "ok", "message": f"Test event sent via {slug}"}
        except Exception as e:
            return {"status": "error", "message": str(e)}

    # --- Tunnel ---

    @app.get("/tunnel")
    def tunnel_status():
        tm = getattr(loop, 'tunnel_manager', None) if loop else None
        if not tm:
            return {"active": False, "url": None, "provider": None}
        return {
            "active": tm.is_running,
            "url": tm.get_url(),
            "provider": tm._provider,
        }

    # --- Agent control ---

    @app.get("/agent/status")
    def agent_status():
        state = db.get_agent_state()
        return {
            "state": state.state,
            "stopped_by": state.stopped_by,
            "pause_reason": state.pause_reason,
            "updated_at": state.updated_at,
        }

    @app.post("/agent/start")
    def agent_start():
        db.update_agent_state("running")
        return {"state": "running"}

    @app.post("/agent/stop")
    def agent_stop(force: bool = False):
        if force:
            db.update_agent_state("stopped", stopped_by="user")
            return {"state": "stopped"}
        db.update_agent_state("stopping", stopped_by="user")
        return {"state": "stopping"}

    @app.post("/agent/pause")
    def agent_pause():
        state = db.get_agent_state()
        if state.state != "running":
            return {"error": f"Agent is {state.state}, can only pause when running"}
        db.update_agent_state("paused")
        return {"status": "paused"}

    # --- SSE endpoint ---

    @app.get("/events")
    async def event_stream():
        """SSE endpoint for real-time dashboard updates."""
        async def generate():
            tick = 0
            while True:
                try:
                    state = db.get_agent_state()
                    done = db.execute(
                        "SELECT COUNT(*) as c FROM tasks t JOIN projects p ON t.project_id = p.id WHERE t.status = 'done' AND p.active = 1"
                    ).fetchone()["c"]
                    failed = db.execute(
                        "SELECT COUNT(*) as c FROM tasks t JOIN projects p ON t.project_id = p.id WHERE t.status = 'failed' AND p.active = 1"
                    ).fetchone()["c"]
                    total = db.execute(
                        "SELECT COUNT(*) as c FROM tasks t JOIN projects p ON t.project_id = p.id WHERE p.active = 1"
                    ).fetchone()["c"]
                    terminal = done + failed
                    completion_rate = round(done / terminal * 100, 1) if terminal > 0 else 0
                    data = {
                        "agent": {
                            "state": state.state,
                            "stopped_by": state.stopped_by,
                        },
                        "overview": {
                            "tasks_done": done,
                            "completion_rate": completion_rate,
                            "active_projects": len(db.active_projects()),
                            "total_tasks": total,
                        },
                    }
                except Exception:
                    data = {"agent": {"state": "unknown"}, "overview": {}}
                # Fetch usage every 15th tick (30s at 2s interval)
                if tick % 15 == 0:
                    usage = usage_api.get_usage()
                    data["usage"] = {
                        "session_pct": usage.session_pct,
                        "session_remaining_pct": usage.session_remaining_pct,
                        "session_resets_at": usage.session_resets_at,
                        "weekly_pct": usage.weekly_pct,
                        "weekly_remaining_pct": usage.weekly_remaining_pct,
                        "weekly_resets_at": usage.weekly_resets_at,
                        "weekly_sonnet_pct": usage.weekly_sonnet_pct,
                        "weekly_opus_pct": usage.weekly_opus_pct,
                        "error": usage.error,
                    }
                tick += 1
                yield f"data: {json.dumps(data)}\n\n"
                await asyncio.sleep(2)

        return StreamingResponse(
            generate(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-cache", "Connection": "keep-alive"},
        )

    # --- Dashboard static mount ---

    try:
        from importlib.resources import files
        ui_path = files("noru").joinpath("interface/ui")
        if Path(str(ui_path)).is_dir():
            app.mount("/", StaticFiles(directory=str(ui_path), html=True), name="dashboard")
    except Exception:
        pass  # Dashboard files not available

    return app


# --- Serializers ---

def _project_dict(p) -> dict:
    if p is None:
        return {}
    return {
        "id": p.id, "name": p.name, "repo_path": p.repo_path,
        "description": p.description, "allowed_tools": p.allowed_tools,
        "use_superpowers": p.use_superpowers, "active": p.active,
        "short_code": p.short_code,
        "created_at": p.created_at,
    }

def _feature_dict(f) -> dict:
    return {
        "id": f.id, "project_id": f.project_id, "title": f.title,
        "description": f.description, "priority": f.priority,
        "status": f.status, "created_at": f.created_at,
    }

def _task_dict(t) -> dict:
    if t is None:
        return {}
    return {
        "id": t.id, "plan_id": t.plan_id, "project_id": t.project_id,
        "title": t.title, "description": t.description,
        "status": t.status, "priority": t.priority,
        "token_weight": t.token_weight, "token_weight_est": t.token_weight_est,
        "auto_generated": t.auto_generated, "source_type": t.source_type,
        "max_turns": t.max_turns, "task_number": t.task_number,
        "commit_hash": t.commit_hash, "created_at": t.created_at,
        "completed_by": t.completed_by, "completed_at": t.completed_at,
    }

def _run_dict(r) -> dict:
    return {
        "id": r.id, "task_id": r.task_id, "project_id": r.project_id,
        "started_at": r.started_at, "ended_at": r.ended_at,
        "status": r.status, "tokens_input": r.tokens_input,
        "tokens_output": r.tokens_output, "cost_usd": r.cost_usd,
        "turns_used": r.turns_used, "result_summary": r.result_summary,
        "error": r.error,
    }

def _comment_dict(c) -> dict:
    return {
        "id": c.id, "task_id": c.task_id, "author": c.author,
        "body": c.body, "created_at": c.created_at,
    }
