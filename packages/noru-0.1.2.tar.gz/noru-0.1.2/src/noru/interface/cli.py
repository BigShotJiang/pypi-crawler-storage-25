"""Click CLI for Noru — all commands."""

from __future__ import annotations

import json
import os
import subprocess
import sys
import threading
from pathlib import Path

import click

from noru import __version__
from noru.core.config import NoruConfig, load_config
from noru.core.constants import DEFAULT_IDLE_JOBS, IDLE_JOB_META
from noru.core.database import Database

DEFAULT_DB = Path.home() / ".noru" / "noru.db"
DEFAULT_CONFIG = Path.home() / ".noru" / "config.yaml"


def _resolve_db(ctx: click.Context, db_path_opt: str | None) -> Database:
    """Resolve db path from subcommand option or group context."""
    path = db_path_opt or ctx.obj.get("db_path", str(DEFAULT_DB))
    db = Database(Path(path))
    db.initialize()
    return db


def _resolve_config(ctx: click.Context, config_path_opt: str | None) -> NoruConfig:
    """Resolve config path from subcommand option or group context."""
    path = config_path_opt or ctx.obj.get("config_path", str(DEFAULT_CONFIG))
    return load_config(Path(path))


def _db_option():
    return click.option("--db", "db_path", default=None, help="Database path")


def _config_option():
    return click.option("--config", "config_path", default=None, help="Config path")


@click.group()
@click.option("--db", "db_path", default=str(DEFAULT_DB), help="Database path")
@click.option("--config", "config_path", default=str(DEFAULT_CONFIG), help="Config path")
@click.option("--json", "use_json", is_flag=True, default=False, help="JSON output")
@click.option("--verbose", is_flag=True, default=False, help="Verbose output")
@click.option("--quiet", is_flag=True, default=False, help="Suppress output")
@click.pass_context
def main(ctx, db_path, config_path, use_json, verbose, quiet):
    """Noru — Autonomous orchestrator for Claude Code."""
    ctx.ensure_object(dict)
    ctx.obj["db_path"] = db_path
    ctx.obj["config_path"] = config_path
    ctx.obj["use_json"] = use_json
    ctx.obj["verbose"] = verbose
    ctx.obj["quiet"] = quiet


# --- Version ---

@main.command()
def version():
    """Print version."""
    click.echo(f"noru {__version__}")


# --- Status ---

@main.command()
@_db_option()
@click.option("--json", "use_json", is_flag=True, default=False, help="JSON output")
@click.pass_context
def status(ctx, db_path, use_json):
    """Show current agent status."""
    db = _resolve_db(ctx, db_path)
    state = db.get_agent_state()
    queue = db.queue_depth()
    use_json = use_json or ctx.obj.get("use_json", False)

    if use_json:
        click.echo(json.dumps({
            "state": state.state,
            "stopped_by": state.stopped_by,
            "pause_reason": state.pause_reason,
            "queue_depth": queue,
        }))
    else:
        click.echo(f"State: {state.state}")
        if state.stopped_by:
            click.echo(f"Stopped by: {state.stopped_by}")
        click.echo(f"Queue: {queue} tasks pending")


# --- Doctor ---

@main.command()
@_db_option()
@_config_option()
@click.pass_context
def doctor(ctx, db_path, config_path):
    """Health check."""
    db = _resolve_db(ctx, db_path)
    config = _resolve_config(ctx, config_path)
    checks = []

    # DB check
    try:
        db.get_agent_state()
        checks.append(("Database", "OK"))
    except Exception as e:
        checks.append(("Database", f"FAIL: {e}"))

    # Claude CLI check
    import shutil
    claude_path = shutil.which(config.claude_cli)
    if claude_path:
        checks.append(("Claude CLI", f"OK ({claude_path})"))
    else:
        checks.append(("Claude CLI", f"NOT FOUND ({config.claude_cli})"))

    # tmux check
    tmux_path = shutil.which("tmux")
    if tmux_path:
        checks.append(("tmux", f"OK ({tmux_path})"))
    else:
        checks.append(("tmux", "NOT FOUND — install with: brew install tmux"))

    # Config check
    resolved_config_path = Path(config_path or ctx.obj.get("config_path", str(DEFAULT_CONFIG)))
    if resolved_config_path.exists():
        checks.append(("Config", f"OK ({resolved_config_path})"))
    else:
        checks.append(("Config", "Using defaults (no config file)"))

    for name, check_status in checks:
        click.echo(f"  {name}: {check_status}")


# --- Start / Stop ---

@main.command()
@click.option("--db", "db_path", default=None, help="Database path")
@click.option("--config", "config_path", default=None, help="Config path")
@click.option("--foreground", is_flag=True, default=False, help="Run in foreground (don't daemonize)")
@click.pass_context
def start(ctx, db_path, config_path, foreground):
    """Start the orchestrator + API server."""
    import shutil
    # Preflight: check required system dependencies
    missing = []
    if not shutil.which("tmux"):
        missing.append("tmux  — install with: brew install tmux")
    if not shutil.which("claude"):
        missing.append("claude — install Claude Code CLI: https://docs.anthropic.com/en/docs/claude-code")
    if missing:
        click.echo("Missing required dependencies:\n")
        for m in missing:
            click.echo(f"  ✗ {m}")
        click.echo("\nInstall them and try again.")
        raise SystemExit(1)

    db = _resolve_db(ctx, db_path)
    config = _resolve_config(ctx, config_path)

    if not foreground:
        state = db.get_agent_state()
        if state.state == "running":
            click.echo("Agent is already running.")
            return
        _start_daemon(db, config)
    else:
        _start_foreground(db, config)


def _start_daemon(db, config) -> None:
    """Start as background daemon process."""
    import signal
    import time
    import webbrowser

    # Kill any existing process on our port
    try:
        result = subprocess.run(
            ["lsof", "-ti", f"tcp:{config.port}"],
            capture_output=True, text=True, timeout=5,
        )
        if result.stdout.strip():
            for pid in result.stdout.strip().split("\n"):
                pid = pid.strip()
                if pid:
                    try:
                        os.kill(int(pid), signal.SIGTERM)
                    except (ProcessLookupError, ValueError):
                        pass
            time.sleep(1)  # Wait for port to be released
    except (subprocess.TimeoutExpired, OSError):
        pass

    db.update_agent_state("running")

    # Launch self in foreground mode as a background subprocess
    cmd = [
        sys.executable, "-m", "noru", "start", "--foreground",
        "--db", str(db.db_path),
    ]

    # Redirect output to log file
    log_dir = db.db_path.parent / "logs"
    log_dir.mkdir(exist_ok=True)
    log_file = log_dir / "noru.log"

    with open(log_file, "a") as lf:
        proc = subprocess.Popen(
            cmd, stdout=lf, stderr=lf,
            start_new_session=True,  # detach from terminal
        )

    click.echo(f"Noru started (PID {proc.pid})")
    click.echo(f"Dashboard: http://localhost:{config.port}")
    click.echo(f"Logs: {log_file}")
    click.echo("Run 'noru dashboard' to open in browser.")


def _start_foreground(db, config) -> None:
    """Run in foreground (used by daemon subprocess)."""
    try:
        from noru.interface.orchestrator import OrchestratorLoop
        from noru.interface.server import create_app
        import uvicorn
        import logging

        # Configure logging to stdout (captured by daemon to log file)
        logging.basicConfig(
            level=logging.INFO,
            format="%(asctime)s [%(name)s] %(levelname)s: %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )

        db.update_agent_state("running")
        loop = OrchestratorLoop(db=db, config=config)

        t = threading.Thread(target=loop.run, daemon=True)
        t.start()

        app = create_app(db, config, loop)
        uvicorn.run(app, host="127.0.0.1", port=config.port, log_level="warning")
    except KeyboardInterrupt:
        db.update_agent_state("stopped", stopped_by="user")


@main.command()
@click.option("--db", "db_path", default=None, help="Database path")
@click.option("--config", "config_path", default=None, help="Config path")
@click.option("--force", is_flag=True, default=False, help="Force immediate stop")
@click.pass_context
def stop(ctx, db_path, config_path, force):
    """Stop the orchestrator."""
    import signal as _signal
    db = _resolve_db(ctx, db_path)
    config = _resolve_config(ctx, config_path)

    # Update state
    if force:
        db.update_agent_state("stopped", stopped_by="user")
    else:
        db.update_agent_state("stopping", stopped_by="user")

    # Kill the daemon process on our port
    try:
        result = subprocess.run(
            ["lsof", "-ti", f"tcp:{config.port}"],
            capture_output=True, text=True, timeout=5,
        )
        if result.stdout.strip():
            for pid in result.stdout.strip().split("\n"):
                pid = pid.strip()
                if pid:
                    try:
                        sig = _signal.SIGKILL if force else _signal.SIGTERM
                        os.kill(int(pid), sig)
                    except (ProcessLookupError, ValueError):
                        pass
    except (subprocess.TimeoutExpired, OSError):
        pass

    # Kill tmux sessions (skip if tmux not installed)
    import shutil as _shutil
    if _shutil.which("tmux"):
        for session in ["noru-usage"]:
            subprocess.run(["tmux", "kill-session", "-t", session],
                           capture_output=True, timeout=5)

    click.echo("Agent stopped." if force else "Agent stopping gracefully...")


@main.command()
@click.option("--db", "db_path", default=None, help="Database path")
@click.pass_context
def pause(ctx, db_path):
    """Pause the orchestrator — server stays running, dispatch stops."""
    db = _resolve_db(ctx, db_path)
    state = db.get_agent_state()
    if state.state != "running":
        click.echo(f"Agent is {state.state}, can only pause when running")
        return
    db.update_agent_state("paused")
    click.echo("Agent paused. Server still running. Use 'noru start' to resume.")


@main.command()
@click.option("-n", "--lines", default=50, help="Number of lines to show")
@click.option("--no-follow", is_flag=True, help="Don't follow (just show last N lines)")
@click.option("--claude", is_flag=True, help="View Claude Code session logs (tmux output)")
def logs(lines, no_follow, claude):
    """View noru logs. Use --claude for Claude Code session output."""
    if claude:
        log_file = Path.home() / ".noru" / "logs" / "claude.log"
        label = "Claude Code session"
    else:
        log_file = Path.home() / ".noru" / "logs" / "noru.log"
        label = "Noru orchestrator"
    if not log_file.exists():
        click.echo(f"No {label} log file found. Is noru running?")
        return
    if no_follow:
        subprocess.run(["tail", f"-{lines}", str(log_file)])
    else:
        click.echo(f"Tailing {label} ({log_file}) — Ctrl+C to stop...")
        try:
            subprocess.run(["tail", f"-{lines}", "-f", str(log_file)])
        except KeyboardInterrupt:
            pass


@main.command()
@_db_option()
@_config_option()
@click.pass_context
def restart(ctx, db_path, config_path):
    """Restart the orchestrator."""
    ctx.invoke(stop, db_path=db_path)
    ctx.invoke(start, db_path=db_path, config_path=config_path)


# --- Dashboard ---

@main.command()
@_config_option()
@click.pass_context
def dashboard(ctx, config_path):
    """Open dashboard in browser."""
    config = _resolve_config(ctx, config_path)
    import webbrowser
    url = f"http://localhost:{config.port}"
    click.echo(f"Opening dashboard at {url}")
    webbrowser.open(url)


# --- Project commands ---

@main.group()
def project():
    """Manage projects."""
    pass


@project.command("list")
@_db_option()
@click.pass_context
def project_list(ctx, db_path):
    """List all projects."""
    db = _resolve_db(ctx, db_path)
    projects = db.all_projects()
    if not projects:
        click.echo("No projects found. Run 'noru init' in a project directory.")
        return
    for p in projects:
        pstatus = "active" if p.active else "paused"
        click.echo(f"  {p.id:20s} {p.name:20s} [{pstatus}] {p.repo_path}")


@project.command("add")
@_db_option()
@click.option("--id", "project_id", required=True, help="Project slug")
@click.option("--name", required=True, help="Display name")
@click.option("--repo-path", required=True, help="Repository path")
@click.option("--description", default="", help="Description")
@click.pass_context
def project_add(ctx, db_path, project_id, name, repo_path, description):
    """Add a new project."""
    db = _resolve_db(ctx, db_path)
    db.create_project(project_id, name, repo_path, description=description)
    click.echo(f"Project '{project_id}' created.")


@project.command("pause")
@_db_option()
@click.argument("project_id")
@click.pass_context
def project_pause(ctx, db_path, project_id):
    """Pause a project."""
    db = _resolve_db(ctx, db_path)
    db.update_project(project_id, active=False)
    click.echo(f"Project '{project_id}' paused.")


@project.command("resume")
@_db_option()
@click.argument("project_id")
@click.pass_context
def project_resume(ctx, db_path, project_id):
    """Resume a paused project."""
    db = _resolve_db(ctx, db_path)
    db.update_project(project_id, active=True)
    click.echo(f"Project '{project_id}' resumed.")


# --- Task commands ---

@main.group()
def task():
    """Manage tasks."""
    pass


@task.command("list")
@_db_option()
@click.option("--status", "task_status", default=None, help="Filter by status")
@click.option("--project", "project_id", default=None, help="Filter by project")
@click.pass_context
def task_list(ctx, db_path, task_status, project_id):
    """List tasks."""
    db = _resolve_db(ctx, db_path)
    tasks = db.list_tasks(project_id=project_id, status=task_status)
    if not tasks:
        click.echo("No tasks found.")
        return
    for t in tasks:
        weight = t.token_weight[0].upper()
        auto = " [auto]" if t.auto_generated else ""
        click.echo(f"  #{t.id:<4d} [{t.status:6s}] P{t.priority} {weight} {t.project_id:12s} {t.title}{auto}")


@task.command("add")
@_db_option()
@click.option("--project", "project_id", required=True, help="Project ID")
@click.option("--title", required=True, help="Task title")
@click.option("--description", default="", help="Task description")
@click.option("--priority", default=3, type=int, help="Priority 1-5")
@click.option("--weight", default="medium", help="Token weight: light|medium|heavy")
@click.pass_context
def task_add(ctx, db_path, project_id, title, description, priority, weight):
    """Add a new task."""
    db = _resolve_db(ctx, db_path)
    task_id = db.create_task(
        project_id=project_id, title=title, description=description,
        priority=priority, token_weight=weight,
    )
    click.echo(f"Task #{task_id} created.")


@task.command("done")
@_db_option()
@click.argument("task_id", type=int)
@click.pass_context
def task_done(ctx, db_path, task_id):
    """Mark a task as done."""
    db = _resolve_db(ctx, db_path)
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc).isoformat()
    db.update_task(task_id, status="done", completed_at=now, completed_by="developer")
    click.echo(f"Task #{task_id} marked as done.")


@task.command("skip")
@_db_option()
@click.argument("task_id", type=int)
@click.pass_context
def task_skip(ctx, db_path, task_id):
    """Move task to back of queue (lower priority)."""
    db = _resolve_db(ctx, db_path)
    task = db.get_task(task_id)
    if task:
        new_priority = min(task.priority + 1, 5)
        db.update_task(task_id, priority=new_priority)
        click.echo(f"Task #{task_id} priority lowered to {new_priority}.")


@task.command("ready")
@_db_option()
@click.argument("task_id", type=int)
@click.pass_context
def task_ready(ctx, db_path, task_id):
    """Promote a task from todo to ready."""
    db = _resolve_db(ctx, db_path)
    t = db.get_task(task_id)
    if not t:
        click.echo(f"Task #{task_id} not found.")
        raise SystemExit(1)
    if t.status != "todo":
        click.echo(f"Task #{task_id} is '{t.status}', not 'todo'.")
        raise SystemExit(1)
    db.update_task(task_id, status="ready")
    click.echo(f"Task #{task_id} promoted to ready.")


# --- Idle job commands ---

@main.group()
def idle():
    """Manage idle review jobs."""
    pass


@idle.command("list")
@_config_option()
@click.pass_context
def idle_list(ctx, config_path):
    """List all idle jobs with status."""
    config = _resolve_config(ctx, config_path)
    for entry in config.idle_jobs.jobs:
        meta = IDLE_JOB_META.get(entry.id, {})
        enabled_str = "ON " if entry.enabled else "OFF"
        name = meta.get("name", entry.id)
        weight = meta.get("weight", "?")
        click.echo(f"  [{enabled_str}] {entry.id:20s} {name:20s} ({weight})")


@idle.command("enable")
@click.argument("job_id")
@click.pass_context
def idle_enable(ctx, job_id):
    """Enable an idle job."""
    click.echo(f"Idle job '{job_id}' enabled. (Update config.yaml to persist)")


@idle.command("disable")
@click.argument("job_id")
@click.pass_context
def idle_disable(ctx, job_id):
    """Disable an idle job."""
    click.echo(f"Idle job '{job_id}' disabled. (Update config.yaml to persist)")


# --- Run helpers ---

def _build_task_prompt(task, project, plan=None, context=None) -> str:
    """Build a task prompt for ClaudeActionService (mirrors Dispatcher._build_prompt)."""
    from noru.integrations import Integrations

    INSTRUCTION_SUFFIX = (
        "\n\nAfter completing the task, output a one-sentence summary of what was done."
    )

    parts: list[str] = []
    parts.append(
        f"Project: {project.name}\n"
        f"Repository: {project.repo_path}\n"
        f"Description: {project.description}"
    )
    if plan and getattr(plan, "approach", None):
        parts.append(f"Approach:\n{plan.approach}")

    integrations = Integrations.for_project(project)
    task_text = task.description or task.title
    task_text = integrations.augment_prompt(task_text)
    parts.append(task_text)

    if getattr(task, 'task_number', None):
        parts.append(
            f"If you commit changes, prefix the commit message with [{task.task_number}]."
        )

    if context:
        parts.append(context)

    parts.append(INSTRUCTION_SUFFIX.strip())
    return "\n\n".join(parts)


# --- Run command ---

@main.command()
@_db_option()
@_config_option()
@click.option("--task", "task_id", type=int, default=None, help="Run specific task")
@click.option("--dry-run", is_flag=True, default=False, help="Build prompt but don't execute")
@click.pass_context
def run(ctx, db_path, config_path, task_id, dry_run):
    """Execute one task immediately."""
    db = _resolve_db(ctx, db_path)
    config = _resolve_config(ctx, config_path)

    if task_id:
        the_task = db.get_task(task_id)
    else:
        the_task = db.get_next_eligible_task("heavy")

    if not the_task:
        click.echo("No eligible task found.")
        return

    project = db.get_project(the_task.project_id)
    if not project:
        click.echo(f"Project '{the_task.project_id}' not found.")
        return

    from noru.executor.action_service import ClaudeActionService, ClaudeAction

    prompt = _build_task_prompt(the_task, project)

    if dry_run:
        click.echo("=== DRY RUN ===")
        click.echo(prompt)
        return

    action_service = ClaudeActionService()
    action = ClaudeAction(
        action_type="task",
        prompt=prompt,
        project_id=project.id,
        metadata={"task_id": the_task.id},
    )
    result = action_service.execute(action)
    if result.success:
        click.echo(f"Task #{the_task.id} completed: {(result.result or '')[:200]}")
    else:
        click.echo(f"Task #{the_task.id} failed: {result.error}")


# --- Init command ---

@main.command()
@_db_option()
@click.pass_context
def init(ctx, db_path):
    """Initialize a project from the current directory."""
    import os
    repo_path = os.getcwd()
    project_id = Path(repo_path).name.lower().replace(" ", "-")

    db = _resolve_db(ctx, db_path)

    # Check if already registered
    existing = db.get_project(project_id)
    if existing:
        click.echo(f"Project '{project_id}' already registered. Run 'noru project rescan' to refresh.")
        return

    # Check trust
    if not db.is_trusted_path(repo_path):
        if not click.confirm(f"Trust {repo_path}?", default=False):
            click.echo("Aborted.")
            return

    # Create project first (trusted_paths FK references projects)
    db.create_project(project_id, project_id, repo_path)
    db.add_trusted_path(repo_path, project_id)
    click.echo(f"Project '{project_id}' created at {repo_path}")
    click.echo("Run 'noru start' to begin, or 'noru dashboard' to manage.")


# --- Tunnel commands ---

@main.group()
@click.pass_context
def tunnel(ctx):
    """Manage tunnel for remote dashboard access."""
    pass


@tunnel.command("start")
@click.option("--provider", type=click.Choice(["cloudflared", "ngrok"]), default=None)
@_config_option()
@click.pass_context
def tunnel_start(ctx, provider, config_path):
    """Start a tunnel and print the public URL with QR code."""
    config = _resolve_config(ctx, config_path)
    prov = provider or config.tunnel.provider or "cloudflared"
    from noru.engine.tunnel import TunnelManager
    tm = TunnelManager()
    url = tm.start(prov, config.port)
    if not url:
        click.echo("Failed to start tunnel.")
        raise SystemExit(1)
    click.echo(f"Tunnel active: {url}")
    _print_qr(url)
    click.echo("\nPress Ctrl+C to stop tunnel.")
    try:
        import time
        while tm.is_running:
            time.sleep(1)
    except KeyboardInterrupt:
        tm.stop()
        click.echo("\nTunnel stopped.")


@tunnel.command("stop")
@click.pass_context
def tunnel_stop(ctx):
    """Stop the running tunnel."""
    click.echo("Tunnel stop requires the running noru process. Use 'noru stop' or Ctrl+C.")


@tunnel.command("status")
@_config_option()
@click.pass_context
def tunnel_status_cmd(ctx, config_path):
    """Check tunnel status."""
    config = _resolve_config(ctx, config_path)
    try:
        import urllib.request
        resp = urllib.request.urlopen(f"http://localhost:{config.port}/tunnel", timeout=3)
        import json as _json
        data = _json.loads(resp.read())
        if data.get("active"):
            click.echo(f"Tunnel active: {data['url']} (provider: {data['provider']})")
        else:
            click.echo("Tunnel not active.")
    except Exception:
        click.echo("Noru server not running or unreachable.")


# --- Config commands ---

@main.group("config")
@click.pass_context
def config_cmd(ctx):
    """View and manage configuration."""
    pass


@config_cmd.command("show")
@_config_option()
@click.pass_context
def config_show(ctx, config_path):
    """Print current config as YAML."""
    import yaml as _yaml
    path = Path(config_path) if config_path else Path(ctx.obj.get("config_path", str(DEFAULT_CONFIG)))
    config = load_config(path)
    click.echo(_yaml.dump(config.model_dump(), default_flow_style=False, sort_keys=False))


@config_cmd.command("set")
@click.argument("key")
@click.argument("value")
@_config_option()
@click.pass_context
def config_set(ctx, key, value, config_path):
    """Set a config value. Supports dot notation (e.g., tunnel.provider)."""
    import yaml as _yaml
    path = Path(config_path) if config_path else Path(ctx.obj.get("config_path", str(DEFAULT_CONFIG)))
    config = load_config(path)
    data = config.model_dump()

    keys = key.split(".")
    target = data
    for k in keys[:-1]:
        if k not in target or not isinstance(target[k], dict):
            click.echo(f"Error: invalid key path '{key}'")
            raise SystemExit(1)
        target = target[k]

    final_key = keys[-1]
    if final_key not in target:
        click.echo(f"Error: unknown key '{key}'")
        raise SystemExit(1)

    old_val = target[final_key]
    if isinstance(old_val, bool):
        target[final_key] = value.lower() in ("true", "1", "yes")
    elif isinstance(old_val, int):
        target[final_key] = int(value)
    elif isinstance(old_val, float):
        target[final_key] = float(value)
    else:
        target[final_key] = value

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_yaml.dump(data, default_flow_style=False, sort_keys=False))
    click.echo(f"Set {key} = {target[final_key]}")


@config_cmd.command("reset")
@_config_option()
@click.confirmation_option(prompt="Reset config to defaults?")
@click.pass_context
def config_reset(ctx, config_path):
    """Reset config to defaults."""
    import yaml as _yaml
    path = Path(config_path) if config_path else Path(ctx.obj.get("config_path", str(DEFAULT_CONFIG)))
    defaults = NoruConfig()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(_yaml.dump(defaults.model_dump(), default_flow_style=False, sort_keys=False))
    click.echo("Config reset to defaults.")


# --- Webhook commands ---

@main.group("webhook")
@click.pass_context
def webhook_cmd(ctx):
    """Manage webhooks."""
    pass


@webhook_cmd.command("test")
@click.argument("url")
@click.pass_context
def webhook_test(ctx, url):
    """Send a test event to a webhook URL."""
    from noru.engine.events import NoruEvent
    from noru.engine.webhook import WebhookHandler

    handler = WebhookHandler(url=url, events=["*"])
    event = NoruEvent(
        event_type="test.ping",
        payload={"message": "Test event from noru CLI"},
    )
    try:
        handler.handle(event)
        click.echo(f"Test event sent to {url}")
    except Exception as e:
        click.echo(f"Failed: {e}")
        raise SystemExit(1)


def _print_qr(url: str) -> None:
    """Print QR code to terminal using qrcode library if available."""
    try:
        import qrcode
        qr = qrcode.QRCode(border=1)
        qr.add_data(url)
        qr.make(fit=True)
        qr.print_ascii(invert=True)
    except ImportError:
        click.echo(f"(Install 'qrcode' for terminal QR: pip install qrcode)")
