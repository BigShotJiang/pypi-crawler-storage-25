"""BotPoker CLI — botpoker init|simulate|submit|watch."""

from __future__ import annotations

import argparse
import importlib.util
import os
import sys


def main() -> None:
    parser = argparse.ArgumentParser(prog="botpoker", description="BotPoker CLI")
    sub = parser.add_subparsers(dest="command")

    # botpoker init
    init_p = sub.add_parser("init", help="Create a new bot project")
    init_p.add_argument("name", help="Bot name")

    # botpoker test (local simulation — no server needed)
    test_p = sub.add_parser("test", help="Test a bot locally (no server needed)")
    test_p.add_argument("bot_file", help="Path to bot Python file")
    test_p.add_argument("--hands", type=int, default=1000, help="Number of hands")
    test_p.add_argument("--opponents", default="random", help="Comma-separated opponents: random,call,tight,aggro")
    test_p.add_argument("--chips", type=int, default=10000, help="Starting chips")
    test_p.add_argument("--bb", type=int, default=100, help="Big blind")
    test_p.add_argument("--seed", type=int, default=None, help="Random seed")
    test_p.add_argument("-v", "--verbose", action="store_true", help="Print each hand")

    # botpoker simulate (legacy — connects to server)
    sim_p = sub.add_parser("simulate", help="Run a bot against a live server")
    sim_p.add_argument("bot_file", help="Path to bot Python file")
    sim_p.add_argument("--hands", type=int, default=100, help="Number of hands")
    sim_p.add_argument("--opponent", default="random", help="Opponent type")
    sim_p.add_argument("--server", default="http://localhost:1339", help="Server URL")

    # botpoker deploy
    deploy_p = sub.add_parser("deploy", help="Deploy bot to bot-poker.com")
    deploy_p.add_argument("bot_file", help="Path to bot Python file")
    deploy_p.add_argument("--api-key", help="API key (or set BOTPOKER_API_KEY env var)")

    # botpoker submit (deprecated alias)
    submit_p = sub.add_parser("submit", help="(Deprecated) Use 'deploy' instead")
    submit_p.add_argument("bot_file", help="Path to bot Python file")
    submit_p.add_argument("--api-key", required=True, help="API key")

    # botpoker watch
    watch_p = sub.add_parser("watch", help="Watch a live table")
    watch_p.add_argument("table_id", help="Table ID")
    watch_p.add_argument("--server", default="http://localhost:1339", help="Server URL")

    args = parser.parse_args()

    if args.command == "init":
        cmd_init(args.name)
    elif args.command == "test":
        cmd_test(args.bot_file, args.hands, args.opponents, args.chips, args.bb, args.seed, args.verbose)
    elif args.command == "simulate":
        cmd_simulate(args.bot_file, args.hands, args.opponent, args.server)
    elif args.command == "deploy":
        cmd_deploy(args.bot_file, args.api_key)
    elif args.command == "submit":
        cmd_deploy(args.bot_file, args.api_key)
    elif args.command == "watch":
        cmd_watch(args.table_id, args.server)
    else:
        parser.print_help()


def cmd_init(name: str) -> None:
    """Create a new bot project from template."""
    dirname = name.lower().replace(" ", "_")
    os.makedirs(dirname, exist_ok=True)

    bot_code = f'''"""{{name}} — A BotPoker bot."""

from botpoker import BotBase, GameState, Action
from botpoker.types import ActionType


class {name}(BotBase):
    name = "{name}"

    def decide(self, state: GameState) -> Action:
        # TODO: implement your strategy here
        for va in state.valid_actions:
            if va.type == ActionType.CHECK:
                return Action.check()
        for va in state.valid_actions:
            if va.type == ActionType.CALL:
                return Action.call()
        return Action.fold()


if __name__ == "__main__":
    import sys
    {name}().run(
        api_key=sys.argv[1] if len(sys.argv) > 1 else "dev-key-1",
        table_id=sys.argv[2] if len(sys.argv) > 2 else "dev-6max",
    )
'''
    filepath = os.path.join(dirname, "bot.py")
    with open(filepath, "w") as f:
        f.write(bot_code)

    print(f"Created bot project: {dirname}/bot.py")
    print(f"Run with: python {filepath}")


def cmd_test(
    bot_file: str, hands: int, opponents: str, chips: int,
    bb: int, seed: int | None, verbose: bool,
) -> None:
    """Test a bot locally using the built-in simulator."""
    bot_class = _load_bot_class(bot_file)
    if bot_class is None:
        print(f"Error: no BotBase subclass found in {bot_file}", file=sys.stderr)
        sys.exit(1)

    bot = bot_class()
    opp_list = [o.strip() for o in opponents.split(",")]

    print(f"Testing {bot.name} vs [{', '.join(opp_list)}] for {hands:,} hands...")
    print(f"Stack: {chips:,} chips | Blinds: {bb // 2}/{bb}")
    if seed is not None:
        print(f"Seed: {seed}")
    print()

    from .simulator import LocalSimulator
    bot.setup()
    sim = LocalSimulator(
        bot=bot,
        opponents=opp_list,
        hands=hands,
        starting_chips=chips,
        big_blind=bb,
        seed=seed,
        verbose=verbose,
    )
    result = sim.run()
    print(result.summary())

    # Exit code: 0 if positive bb/100, 1 if negative.
    sys.exit(0 if result.bot_bb_per_100 >= 0 else 1)


def cmd_simulate(bot_file: str, hands: int, opponent: str, server: str) -> None:
    """Run a bot against a live server."""
    bot_class = _load_bot_class(bot_file)
    if bot_class is None:
        print(f"Error: no BotBase subclass found in {bot_file}", file=sys.stderr)
        sys.exit(1)

    bot = bot_class()
    print(f"Running {bot.name} for {hands} hands against {opponent}...")
    print(f"Server: {server}")
    print("(Requires a running BotPoker server)")

    bot.run(
        api_key="dev-key-1",
        table_id="dev-6max",
        server_url=server,
    )


def cmd_deploy(bot_file: str, api_key: str | None) -> None:
    """Deploy a bot to bot-poker.com."""
    import os
    import json

    try:
        import httpx
    except ImportError:
        print("Error: httpx required. Run: pip install httpx", file=sys.stderr)
        sys.exit(1)

    api_url = os.environ.get("BOTPOKER_API_URL", "https://bot-poker.com")
    api_key = api_key or os.environ.get("BOTPOKER_API_KEY")
    if not api_key:
        print("Error: API key required. Use --api-key or set BOTPOKER_API_KEY env var.", file=sys.stderr)
        sys.exit(1)

    bot_class = _load_bot_class(bot_file)
    if bot_class is None:
        print(f"Error: no BotBase subclass found in {bot_file}", file=sys.stderr)
        sys.exit(1)

    # Validate the bot can instantiate and has decide().
    bot = bot_class()
    bot.setup()
    print(f"Validated: {bot.name}")

    # Read the bot file.
    with open(bot_file, "r") as f:
        source = f.read()

    headers = {"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"}
    client = httpx.Client(base_url=api_url, timeout=30)

    # Check if user has a bot with this name, or create one.
    print(f"Checking for existing bot '{bot.name}'...")
    try:
        resp = client.get("/api/bots", headers=headers)
        resp.raise_for_status()
        bots = resp.json().get("bots", [])
    except Exception as e:
        print(f"Error connecting to {api_url}: {e}", file=sys.stderr)
        print("Is the API server running? Set BOTPOKER_API_URL if using a different host.")
        sys.exit(1)

    bot_id = None
    for b in bots:
        if b["display_name"] == bot.name:
            bot_id = b["id"]
            break

    if bot_id is None:
        print(f"Creating bot '{bot.name}'...")
        resp = client.post("/api/bots", headers=headers, json={"name": bot.name})
        if resp.status_code != 201:
            print(f"Error creating bot: {resp.text}", file=sys.stderr)
            sys.exit(1)
        bot_id = resp.json()["bot_id"]
        print(f"Created bot: {bot_id}")
    else:
        print(f"Found existing bot: {bot_id}")

    # Deploy source code.
    print(f"Deploying {bot.name}...")
    resp = client.post(
        f"/api/bots/{bot_id}/deploy",
        headers=headers,
        json={"source_code": source, "filename": os.path.basename(bot_file)},
    )
    if resp.status_code != 201:
        print(f"Error deploying: {resp.text}", file=sys.stderr)
        sys.exit(1)

    data = resp.json()
    print()
    print(f"Deployed successfully!")
    print(f"  Bot:      {bot.name}")
    print(f"  Version:  {data.get('version', '?')}")
    print(f"  Checksum: {data.get('checksum', '?')[:16]}...")
    print()
    print(f"Your bot is now live on bot-poker.com.")


def cmd_watch(table_id: str, server: str) -> None:
    """Watch a live table."""
    print(f"Watching table {table_id} on {server}...")
    print("Table watching is not yet implemented.")


def _load_bot_class(filepath: str):
    """Dynamically load a BotBase subclass from a Python file."""
    from botpoker.base import BotBase

    spec = importlib.util.spec_from_file_location("user_bot", filepath)
    if spec is None or spec.loader is None:
        return None
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)

    for attr_name in dir(module):
        attr = getattr(module, attr_name)
        if (
            isinstance(attr, type)
            and issubclass(attr, BotBase)
            and attr is not BotBase
        ):
            return attr
    return None


if __name__ == "__main__":
    main()
