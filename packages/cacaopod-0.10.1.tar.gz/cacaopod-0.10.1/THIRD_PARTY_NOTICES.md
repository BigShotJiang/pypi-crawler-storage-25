# Third-Party Notices

Cacaopod bundles a web UI (served from `backend/cacaopod/web/dist`). The compiled
JavaScript bundle may include third-party components listed below.

This project is licensed under Apache-2.0. Third-party components remain under
their respective licenses.

## Plotly.js (`plotly.js-dist-min`)

Copyright (c) 2021 Plotly, Inc

License: MIT

## CodeMirror 6 (`codemirror`)

Copyright (C) 2018-2021 by Marijn Haverbeke <marijn@haverbeke.berlin> and others

License: MIT

## Svelte (`svelte`)

Copyright (c) 2016-23 Svelte contributors

License: MIT

## Vite (`vite`)

Vite is used as a build tool for the web UI. It is not bundled as a Python
runtime dependency, but is used during development/build.

Copyright (c) 2019-present, VoidZero Inc. and Vite contributors

License: MIT

## Python

Cacaopod runs on Python. Python itself is licensed under the Python Software
Foundation License (PSF). This distribution does not bundle a Python runtime.

## MIT License Text

MIT License

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
