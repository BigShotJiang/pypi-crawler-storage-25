# Cacaopod

Cacaopod is a local, browser-based data visualizer for experimental data analysis.
It combines a Python-backed workspace, an interactive plotting board, file loaders,
data tools, and an embedded Python console.

## Features

- Load CSV, TSV, TXT/DAT/ASC, NPY, NPZ, JSON, MAT, image files, and custom file formats.
- View 1D traces and 2D heatmaps in a browser UI.
- Run Python code against the current board and loaded data.
- Save boards, waves, tool definitions, and UI state in the working directory.
- Create custom tools, file loaders, and naming rules in Python.

## Installation

```bash
pip install cacaopod
```

## Usage

Start Cacaopod in the directory you want to use as your workspace:

```bash
cacaopod --open
```

By default, Cacaopod serves the app on `127.0.0.1`. If the browser does not open
automatically, open the URL printed in the terminal.

You can also choose a workspace explicitly:

```bash
cacaopod --workdir /path/to/data --open
```

## Security Note

Cacaopod is designed for trusted local use. The web API can execute Python code
from the embedded console and from user-defined tools. Do not expose the backend
to an untrusted network or run it with a public host unless you have added your
own access controls.

## License

Apache-2.0. See `LICENSE`.

Third-party notices for the bundled web UI are included in
`THIRD_PARTY_NOTICES.md`.
