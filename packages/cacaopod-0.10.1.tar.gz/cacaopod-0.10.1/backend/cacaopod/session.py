from __future__ import annotations

import ast
import importlib
import io
import linecache
import sys
import threading
import time
import traceback
import uuid
from contextlib import redirect_stderr, redirect_stdout
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Literal

import numpy as np
from fastapi import Request, Response

from cacaopod.api_models import (
    BoardPatch,
    BoardSelection,
    CodeHistoryEntry,
    ErrorInfo,
    HeatmapViewSettings,
    PodPatch,
    RunResponse,
    TraceViewSettings,
    ViewState,
)
from cacaopod.board import Board, pod_signature
from cacaopod.config import data_root, in_workdir, workdir
from cacaopod.data_manager import DataManager
from cacaopod.file_loader import FileLoader, FileLoaderRegistry, ensure_wave_list
from cacaopod.file_manager import FileManager
from cacaopod.loaded_files import record_loaded_file
from cacaopod.state.editor import load_editor_state, save_editor_state
from cacaopod.state.ui_state import load_view_state
from cacaopod.state.boards import ensure_active_board_id, load_board_state, load_boards_index, save_board_state
from cacaopod.sort_utils import alphanumeric
from cacaopod.toolbox import Toolbox
from cacaopod.wave import Wave, WaveManager, bind_wave_manager

SESSION_COOKIE = "dv_session"


@dataclass
class SessionState:
    globals: dict[str, Any] = field(default_factory=dict)
    lock: threading.Lock = field(default_factory=threading.Lock)
    board: Board = field(default_factory=Board)
    last_executed_code: str = ""
    code_history: list[CodeHistoryEntry] = field(default_factory=list)
    imported_module_stamps: dict[str, tuple[str, int]] = field(default_factory=dict)
    wave_manager: WaveManager = field(default_factory=lambda: WaveManager(data_root() / "waves"))
    data_manager: DataManager = field(default_factory=lambda: DataManager(data_root() / "data"))
    toolbox: Toolbox = field(default_factory=lambda: Toolbox(workdir=workdir()))
    view_state: ViewState = field(default_factory=load_view_state)
    active_board_id: str = ""
    pod_undo: dict[str, list["PodUndoEntry"]] = field(default_factory=dict)

    def __post_init__(self) -> None:
        if not self.globals:
            self.reset()

    def reset(self) -> None:
        # Keep active_board_id as-is so the reset applies to the current board.
        bid = str(getattr(self, "active_board_id", "") or "")

        self.board = Board()
        self.wave_manager = WaveManager(data_root() / "waves")
        self.data_manager = DataManager(data_root() / "data")
        self.toolbox = Toolbox(workdir=workdir())
        self.view_state = load_view_state()
        self.pod_undo = {}
        self.imported_module_stamps = {}

        file_loader_registry = FileLoaderRegistry(workdir=workdir())
        file_manager = FileManager(workdir=workdir())

        def file_loader(
            file_path: str | Path,
            *,
            name: str | None = None,
            overwrite: bool = False,
            description: str | None = None,
            process: list[Any] | None = None,
            **kwargs: Any,
        ) -> Wave | list[Wave]:
            loader = FileLoader(workdir=workdir(), registry=file_loader_registry)
            loaded = loader(file_path, name=name, overwrite=overwrite, description=description, process=process, **kwargs)
            for w in ensure_wave_list(loaded):
                try:
                    if w.name and w.description:
                        record_loaded_file(self.data_manager, wave_name=w.name, file_path=w.description)
                except Exception:  # noqa: BLE001
                    pass
            return loaded

        self.globals = {
            "__name__": "__cacaopod_session__",
            "board": self.board,
            "np": np,
            "Path": Path,
            "workdir": workdir(),
            "Wave": Wave,
            "wave_manager": self.wave_manager,
            "wm": self.wave_manager,
            "DataManager": DataManager,
            "data_manager": self.data_manager,
            "dm": self.data_manager,
            "FileManager": FileManager,
            "file_manager": file_manager,
            "fm": file_manager,
            "alphanumeric": alphanumeric,
            "Toolbox": Toolbox,
            "toolbox": self.toolbox,
            "file_loader": file_loader,
        }
        try:
            self.toolbox.set_runtime_context(board=self.board, wave_manager=self.wave_manager, data_manager=self.data_manager)
        except Exception:  # noqa: BLE001
            pass
        try:
            import pandas as pd  # type: ignore[import-not-found]

            self.globals["pd"] = pd
        except Exception:  # noqa: BLE001
            pass

        self.active_board_id = bid
        try:
            sync_wave_manager_for_session(self)
        except Exception:  # noqa: BLE001
            pass


_sessions: dict[str, SessionState] = {}
_sessions_lock = threading.Lock()


def active_board_id_for_session(session: SessionState) -> str:
    bid = str(getattr(session, "active_board_id", "") or "").strip()
    if bid:
        return bid
    bid = ensure_active_board_id()
    session.active_board_id = bid
    return bid


def sync_wave_manager_for_session(session: SessionState) -> None:
    items = load_boards_index()
    id_to_name: dict[str, str] = {}
    for item in items:
        bid = item.get("id")
        if not isinstance(bid, str) or not bid.strip():
            continue
        name = item.get("name")
        name_s = name.strip() if isinstance(name, str) and name.strip() else bid.strip()
        id_to_name[bid.strip()] = name_s
    session.wave_manager.set_board_index(id_to_name)
    session.wave_manager.set_active_board(active_board_id_for_session(session))
    session.data_manager.set_board_index(id_to_name)
    session.data_manager.set_active_board(active_board_id_for_session(session))


def save_active_board_state(session: SessionState, *, include_waves: bool) -> None:
    bid = active_board_id_for_session(session)
    save_board_state(bid, board=session.board, wave_manager=session.wave_manager, include_waves=include_waves)


def load_active_board_state(session: SessionState) -> bool:
    bid = active_board_id_for_session(session)
    sync_wave_manager_for_session(session)
    board = load_board_state(bid, wave_manager=session.wave_manager)
    if board is None:
        return False
    session.board = board
    session.globals["board"] = session.board
    try:
        session.toolbox.set_runtime_context(board=session.board, wave_manager=session.wave_manager, data_manager=session.data_manager)
    except Exception:  # noqa: BLE001
        pass
    return True


def remember_executed_code(session_id: str, session: SessionState, code: str) -> None:
    session.last_executed_code = code
    if code.strip():
        now_ms = int(time.time() * 1000)
        if session.code_history and session.code_history[0].code == code:
            session.code_history[0] = session.code_history[0].model_copy(update={"ts": now_ms})
        elif session.code_history and not bool(getattr(session.code_history[0], "favorite", False)):
            # If the new code is extremely similar to the most recent one, replace it
            # to avoid flooding the history with tiny parameter tweaks.
            prev = session.code_history[0].code

            def normalize_text(s: str) -> str:
                t = str(s or "").replace("\r\n", "\n").replace("\r", "\n")
                lines = [ln.rstrip() for ln in t.split("\n")]
                while lines and not lines[0].strip():
                    lines.pop(0)
                while lines and not lines[-1].strip():
                    lines.pop()
                return "\n".join(lines)

            def similarity(aa: str, bb: str) -> float:
                if not aa or not bb:
                    return 0.0
                if aa == bb:
                    return 1.0
                if min(len(aa), len(bb)) < 200:
                    from difflib import SequenceMatcher

                    return float(SequenceMatcher(None, aa, bb).ratio())
                try:
                    from datasketch import MinHash  # type: ignore[import-not-found]
                except Exception:  # noqa: BLE001
                    from difflib import SequenceMatcher

                    return float(SequenceMatcher(None, aa, bb).ratio())

                def mh_from_text(text: str) -> Any:  # noqa: ANN401
                    bs = text.encode("utf-8", errors="ignore")
                    ngram = 8
                    mh = MinHash(num_perm=64)
                    if len(bs) <= ngram:
                        mh.update(bs)
                        return mh
                    if len(bs) <= 2000:
                        step = 1
                    elif len(bs) <= 8000:
                        step = 2
                    elif len(bs) <= 20000:
                        step = 4
                    else:
                        step = 8
                    end = len(bs) - ngram + 1
                    for i in range(0, end, step):
                        mh.update(bs[i : i + ngram])
                    return mh

                try:
                    return float(mh_from_text(aa).jaccard(mh_from_text(bb)))
                except Exception:  # noqa: BLE001
                    return 0.0

            prev_n = normalize_text(prev)
            code_n = normalize_text(code)
            min_len = min(len(prev_n), len(code_n))
            threshold = 0.85 if min_len < 200 else 0.97
            if similarity(prev_n, code_n) >= threshold:
                session.code_history[0] = CodeHistoryEntry(ts=now_ms, code=code)
            else:
                session.code_history.insert(0, CodeHistoryEntry(ts=now_ms, code=code))
        else:
            session.code_history.insert(0, CodeHistoryEntry(ts=now_ms, code=code))
    save_editor_state(session_id, last_code=session.last_executed_code, history=session.code_history)


def get_or_create_session(request: Request, response: Response) -> tuple[str, SessionState]:
    session_id = request.cookies.get(SESSION_COOKIE)
    if not session_id:
        session_id = uuid.uuid4().hex
        response.set_cookie(SESSION_COOKIE, session_id, samesite="lax")

    with _sessions_lock:
        state = _sessions.get(session_id)
        if state is None:
            state = SessionState()
            state.last_executed_code, state.code_history = load_editor_state(session_id)
            state.active_board_id = ensure_active_board_id()
            load_active_board_state(state)
            _sessions[session_id] = state

    # If an existing session was created while the editor history was stored per-session-id,
    # the UI may appear to "lose" history when the cookie changes. Refresh lazily when empty.
    if not state.code_history:
        try:
            state.last_executed_code, state.code_history = load_editor_state(session_id)
        except Exception:  # noqa: BLE001
            pass

    return session_id, state


def collect_imported_module_names(code: str) -> list[str]:
    try:
        tree = ast.parse(code)
    except SyntaxError:
        return []

    names: set[str] = set()

    def add_module_name(name: str) -> None:
        raw = str(name or "").strip()
        if not raw:
            return
        parts = [part for part in raw.split(".") if part]
        for i in range(1, len(parts) + 1):
            names.add(".".join(parts[:i]))

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                add_module_name(alias.name)
            continue
        if not isinstance(node, ast.ImportFrom):
            continue
        if node.level != 0 or not node.module:
            continue
        add_module_name(node.module)
        for alias in node.names:
            if alias.name == "*":
                continue
            add_module_name(f"{node.module}.{alias.name}")

    return sorted(names, key=lambda name: (name.count("."), name))


def _local_module_state(module_name: str, *, base: Path) -> tuple[Any, str, int] | None:  # noqa: ANN401
    module = sys.modules.get(module_name)
    if module is None:
        return None

    module_file = getattr(module, "__file__", None)
    if not isinstance(module_file, str) or not module_file.strip():
        return None

    try:
        path = Path(module_file).resolve()
    except Exception:  # noqa: BLE001
        return None

    if path.suffix in {".pyc", ".pyo"}:
        try:
            path = Path(importlib.util.source_from_cache(str(path))).resolve()
        except Exception:  # noqa: BLE001
            return None

    if path.suffix not in {".py", ".pyw"}:
        return None
    if not path.is_relative_to(base):
        return None

    try:
        mtime_ns = path.stat().st_mtime_ns
    except OSError:
        return None

    return module, str(path), mtime_ns


def _clear_cached_bytecode(module: Any, *, base: Path) -> None:
    cached = getattr(module, "__cached__", None)
    if not isinstance(cached, str) or not cached.strip():
        return

    try:
        cached_path = Path(cached).resolve()
    except Exception:  # noqa: BLE001
        return

    if cached_path.suffix != ".pyc" or not cached_path.is_relative_to(base):
        return

    try:
        cached_path.unlink(missing_ok=True)
    except OSError:
        return


def reload_changed_local_modules(session: SessionState, module_names: list[str]) -> None:
    if not module_names:
        return

    base = workdir()
    importlib.invalidate_caches()

    for module_name in module_names:
        state = _local_module_state(module_name, base=base)
        if state is None:
            continue
        module, path_s, mtime_ns = state
        prev = session.imported_module_stamps.get(module_name)
        if prev is None:
            session.imported_module_stamps[module_name] = (path_s, mtime_ns)
            continue
        if prev == (path_s, mtime_ns):
            continue

        # Clear cached bytecode so same-second edits with unchanged file size still
        # pick up the latest source during reload().
        _clear_cached_bytecode(module, base=base)
        importlib.reload(module)

        refreshed = _local_module_state(module_name, base=base)
        if refreshed is None:
            session.imported_module_stamps.pop(module_name, None)
            continue
        _, next_path_s, next_mtime_ns = refreshed
        session.imported_module_stamps[module_name] = (next_path_s, next_mtime_ns)


def remember_local_module_stamps(session: SessionState, module_names: list[str]) -> None:
    if not module_names:
        return

    base = workdir()
    for module_name in module_names:
        state = _local_module_state(module_name, base=base)
        if state is None:
            continue
        _, path_s, mtime_ns = state
        session.imported_module_stamps[module_name] = (path_s, mtime_ns)


@dataclass
class BoardFingerprint:
    pods: list[Any] = field(default_factory=list)
    ids: list[str] = field(default_factory=list)
    signatures: list[str] = field(default_factory=list)
    selected: int = 0


def _board_selected(board: Board) -> int:
    try:
        return int(getattr(board, "selected", 0))
    except Exception:  # noqa: BLE001
        return int(getattr(board, "_selected_i", 0))


def capture_board_fingerprint(board: Board) -> BoardFingerprint:
    pods = getattr(board, "_pods", None)
    pod_list = list(pods) if isinstance(pods, list) else []
    ids = [str(getattr(p, "id", "")) for p in pod_list]
    signatures = [pod_signature(p) for p in pod_list]
    return BoardFingerprint(pods=pod_list, ids=ids, signatures=signatures, selected=_board_selected(board))


def _board_waves_by_uid(board: Board) -> dict[str, Wave]:
    pods = getattr(board, "_pods", None)
    if not isinstance(pods, list):
        return {}
    waves: dict[str, Wave] = {}
    for pod in pods:
        for w in getattr(pod, "waves", []) or []:
            if not isinstance(w, Wave):
                continue
            uid = str(getattr(w, "uid", "") or "")
            if not uid:
                continue
            waves.setdefault(uid, w)
    return waves


def _board_wave_revs(board: Board) -> dict[str, int]:
    return {uid: int(getattr(w, "_rev", 0)) for uid, w in _board_waves_by_uid(board).items()}


def _touch_shared_waves(before_revs: dict[str, int], board: Board) -> None:
    waves_by_uid = _board_waves_by_uid(board)
    if not waves_by_uid:
        return

    changed_uids: set[str] = set()
    for uid, wave in waves_by_uid.items():
        rev = int(getattr(wave, "_rev", 0))
        prev = before_revs.get(uid)
        if prev is None:
            if rev > 0:
                changed_uids.add(uid)
        elif rev != prev:
            changed_uids.add(uid)

    if not changed_uids:
        return

    for uid in changed_uids:
        wave = waves_by_uid.get(uid)
        if wave is None:
            continue
        try:
            board._update_wave_share_index([wave], [wave])  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            pass

    shared_uids: set[str] = set()
    try:
        share_index = getattr(board, "_wave_share_index", None)
        if not isinstance(share_index, dict):
            share_index = None
    except Exception:  # noqa: BLE001
        share_index = None

    if share_index is None:
        try:
            board._rebuild_wave_share_index()  # type: ignore[attr-defined]
            share_index = getattr(board, "_wave_share_index", None)
        except Exception:  # noqa: BLE001
            share_index = None

    if isinstance(share_index, dict):
        for uid in changed_uids:
            for other_uid in share_index.get(uid, set()):
                if other_uid not in changed_uids:
                    shared_uids.add(other_uid)

    for uid in shared_uids:
        wave = waves_by_uid.get(uid)
        if wave is None:
            continue
        try:
            wave._touch()
        except Exception:  # noqa: BLE001
            pass


@dataclass
class BoardDiff:
    board_snapshot: BoardSnapshot | None = None
    board_patch: BoardPatch | None = None
    changed_idxs: list[int] = field(default_factory=list)
    structural: bool = False
    selected_changed: bool = False


@dataclass
class PodUndoEntry:
    pod_id: str
    signature: str
    name: str
    waves: list[Wave]
    heatmap_settings: HeatmapViewSettings
    trace_settings: TraceViewSettings
    trace_settings_by_wave: list[TraceViewSettings]
    active_wave_index: int


def _clone_model(m: Any, *, fallback: Any) -> Any:  # noqa: ANN401
    if m is None:
        return fallback
    try:
        return m.model_copy(deep=True)
    except Exception:  # noqa: BLE001
        try:
            return type(m).model_validate(m.model_dump())
        except Exception:  # noqa: BLE001
            return fallback


def capture_selected_pod_undo(board: Board) -> PodUndoEntry | None:
    pods = getattr(board, "_pods", None)
    if not isinstance(pods, list) or not pods:
        return None
    idx = _board_selected(board)
    if idx < 0 or idx >= len(pods):
        return None
    pod = pods[idx]
    waves = list(getattr(pod, "waves", []) or [])
    heatmap = _clone_model(getattr(pod, "heatmap_settings", None), fallback=HeatmapViewSettings())
    trace = _clone_model(getattr(pod, "trace_settings", None), fallback=TraceViewSettings())

    ts_by = getattr(pod, "trace_settings_by_wave", None)
    if isinstance(ts_by, list) and len(ts_by) == len(waves):
        trace_by = [_clone_model(ts, fallback=TraceViewSettings()) for ts in ts_by]
    else:
        trace_by = [_clone_model(trace, fallback=TraceViewSettings()) for _ in waves]

    try:
        active_idx = int(getattr(pod, "active_wave_index", 0))
    except Exception:  # noqa: BLE001
        active_idx = 0

    return PodUndoEntry(
        pod_id=str(getattr(pod, "id", "")),
        signature=pod_signature(pod),
        name=str(getattr(pod, "name", "") or ""),
        waves=waves,
        heatmap_settings=heatmap,
        trace_settings=trace,
        trace_settings_by_wave=trace_by,
        active_wave_index=active_idx,
    )


def maybe_push_pod_undo(session: SessionState, entry: PodUndoEntry | None) -> None:
    if entry is None:
        return
    pods = getattr(session.board, "_pods", None)
    if not isinstance(pods, list) or not pods:
        return
    current = next((p for p in pods if str(getattr(p, "id", "")) == entry.pod_id), None)
    if current is None:
        return
    if pod_signature(current) == entry.signature:
        return
    stack = session.pod_undo.get(entry.pod_id, [])
    if stack and stack[-1].signature == entry.signature:
        return
    stack.append(entry)
    if len(stack) > 2:
        stack = stack[-2:]
    session.pod_undo[entry.pod_id] = stack


def apply_pod_undo(session: SessionState, selection: BoardSelection) -> bool:
    session.board.set_selected(selection.i)
    try:
        pod = session.board.get(selection.i)
    except Exception:  # noqa: BLE001
        return False
    stack = session.pod_undo.get(str(getattr(pod, "id", "")), [])
    if not stack:
        return False
    entry = stack.pop()

    try:
        pod.show(list(entry.waves))
    except Exception:  # noqa: BLE001
        try:
            pod.waves = list(entry.waves)  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            return False

    pod.name = entry.name
    pod.heatmap_settings = _clone_model(entry.heatmap_settings, fallback=HeatmapViewSettings())
    pod.trace_settings = _clone_model(entry.trace_settings, fallback=TraceViewSettings())

    n = len(getattr(pod, "waves", []) or [])
    ts_by = [_clone_model(ts, fallback=TraceViewSettings()) for ts in entry.trace_settings_by_wave]
    if n <= 0:
        pod.trace_settings_by_wave = []
    else:
        ts_by = ts_by[:n]
        while len(ts_by) < n:
            ts_by.append(_clone_model(pod.trace_settings, fallback=TraceViewSettings()))
        pod.trace_settings_by_wave = ts_by
        if pod.trace_settings_by_wave:
            pod.trace_settings = pod.trace_settings_by_wave[0]

    try:
        ii = int(entry.active_wave_index)
    except Exception:  # noqa: BLE001
        ii = 0
    pod.active_wave_index = min(max(ii, 0), max(0, n - 1))

    if stack:
        session.pod_undo[entry.pod_id] = stack
    else:
        session.pod_undo.pop(entry.pod_id, None)
    return True


def diff_board(before: BoardFingerprint, board: Board) -> BoardDiff:
    after = capture_board_fingerprint(board)
    structural = len(before.ids) != len(after.ids) or before.ids != after.ids
    selected_changed = before.selected != after.selected

    if structural:
        if len(after.ids) >= len(before.ids) and after.ids[: len(before.ids)] == before.ids:
            idxs = list(range(len(before.ids), len(after.ids)))
            appended = board.snapshot_pods(idxs)
            patch = BoardPatch(selected=BoardSelection(i=after.selected), pods=[], appendPods=appended)
            return BoardDiff(board_patch=patch, changed_idxs=idxs, structural=True, selected_changed=selected_changed)
        return BoardDiff(board_snapshot=board.snapshot(), structural=True, selected_changed=selected_changed)

    changed_idxs = [i for i, (a, b) in enumerate(zip(before.signatures, after.signatures)) if a != b]
    if changed_idxs or selected_changed:
        pods_snaps = board.snapshot_pods(changed_idxs)
        patch = BoardPatch(
            selected=BoardSelection(i=after.selected),
            pods=[PodPatch(i=i, pod=snap) for i, snap in zip(changed_idxs, pods_snaps)],
        )
        return BoardDiff(board_patch=patch, changed_idxs=changed_idxs, selected_changed=selected_changed)

    return BoardDiff(selected_changed=selected_changed)


def exec_in_session(session_id: str, session: SessionState, code: str, selection: BoardSelection) -> RunResponse:
    stdout_io = io.StringIO()
    stderr_io = io.StringIO()
    imported_modules = collect_imported_module_names(code)

    status: Literal["ok", "error"] = "ok"
    error: ErrorInfo | None = None
    board_snapshot = None
    board_patch = None
    exec_ms: float | None = None

    with session.lock:
        t0 = time.perf_counter()
        session.board.set_selected(selection.i)
        undo_entry = capture_selected_pod_undo(session.board)
        before = capture_board_fingerprint(session.board)
        before_wave_revs = _board_wave_revs(session.board)

        try:
            with redirect_stdout(stdout_io), redirect_stderr(stderr_io):
                with bind_wave_manager(session.wave_manager), in_workdir(workdir()):
                    reload_changed_local_modules(session, imported_modules)
                    filename = f"<cacaopod:{session_id}:{int(time.time() * 1000)}>"
                    linecache.cache[filename] = (len(code), None, code.splitlines(True), filename)
                    compiled = compile(code, filename, "exec", dont_inherit=True)
                    exec(compiled, session.globals)  # noqa: S102 - intended for local trusted use
        except Exception as exc:  # noqa: BLE001
            status = "error"
            error = ErrorInfo(message=str(exc), traceback=traceback.format_exc())
        try:
            remember_local_module_stamps(session, imported_modules)
        except Exception:  # noqa: BLE001
            pass
        try:
            _touch_shared_waves(before_wave_revs, session.board)
        except Exception:  # noqa: BLE001
            pass
        try:
            session.wave_manager.flush()
        except Exception:  # noqa: BLE001
            pass
        try:
            session.data_manager.flush()
        except Exception:  # noqa: BLE001
            pass
        if status == "ok":
            remember_executed_code(session_id, session, code)

        diff = diff_board(before, session.board)
        maybe_push_pod_undo(session, undo_entry)
        board_snapshot = diff.board_snapshot
        board_patch = diff.board_patch

        def needs_untracked_wave_save() -> bool:
            pods = getattr(session.board, "_pods", None)
            if not isinstance(pods, list):
                return False
            for pod in pods:
                for w in getattr(pod, "waves", []) or []:
                    wm_path = getattr(w, "_wm_path", None)
                    if isinstance(wm_path, str) and wm_path.strip():
                        continue
                    rev = int(getattr(w, "_rev", 0))
                    saved_rev = int(getattr(w, "_saved_rev", -1))
                    if saved_rev != rev:
                        return True
            return False

        board_changed = diff.structural or bool(diff.changed_idxs) or diff.selected_changed
        if board_changed:
            try:
                save_active_board_state(session, include_waves=needs_untracked_wave_save())
            except Exception:  # noqa: BLE001
                pass
        exec_ms = (time.perf_counter() - t0) * 1000.0

    return RunResponse(
        status=status,
        board=board_snapshot,
        boardPatch=board_patch,
        stdout=stdout_io.getvalue(),
        stderr=stderr_io.getvalue(),
        error=error,
        execMs=exec_ms,
    )
