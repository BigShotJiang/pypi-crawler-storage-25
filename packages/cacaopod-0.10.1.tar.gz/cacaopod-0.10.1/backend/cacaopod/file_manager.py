from __future__ import annotations

import base64
import fnmatch
import hashlib
import json
import os
import time
from pathlib import Path, PurePosixPath
from typing import Iterable
from urllib import request

from cacaopod.api_models import FilesUiState
from cacaopod.config import data_root_for
from cacaopod.sort_utils import alphanumeric


_WEBDAV_PREFIX = "webdav:"
_DEFAULT_MAX_AGE_SEC = 24 * 60 * 60
_DEFAULT_MAX_CACHE_BYTES = 1_000_000_000
_CLEANUP_INTERVAL_SEC = 60


def _auth_header(username: str | None, password: str | None) -> str | None:
    user = (username or "").strip()
    pwd = password or ""
    if not user and not pwd:
        return None
    token = base64.b64encode(f"{user}:{pwd}".encode("utf-8")).decode("ascii")
    return f"Basic {token}"


def _join_url(base_url: str, rel_path: str) -> str:
    base = str(base_url or "").strip()
    if not base:
        raise ValueError("WebDAV url is required")
    rel = str(rel_path or "").strip().lstrip("/")
    if rel:
        return base.rstrip("/") + "/" + rel
    return base.rstrip("/") + "/"


def _has_glob(text: str) -> bool:
    return any(ch in text for ch in ("*", "?", "["))


def _safe_name_with_ext(remote_path: str) -> str:
    p = PurePosixPath(str(remote_path or "").strip())
    name = p.name or "file"
    suffixes = p.suffixes
    ext = "".join(suffixes)
    stem = name[: -len(ext)] if ext else name
    safe_stem = "".join(ch for ch in stem if ch.isalnum() or ch in ("-", "_")) or "file"
    return f"{safe_stem}{ext}"


class FileManager:
    def __init__(
        self,
        *,
        workdir: Path,
        max_age_sec: int = _DEFAULT_MAX_AGE_SEC,
        max_cache_bytes: int = _DEFAULT_MAX_CACHE_BYTES,
    ) -> None:
        self._workdir = Path(workdir).expanduser().resolve()
        self._cache_root = data_root_for(self._workdir) / "tmp" / "file_manager"
        self._max_age_sec = int(max_age_sec)
        self._max_cache_bytes = int(max_cache_bytes)
        self._last_cleanup_ts = 0.0

    @property
    def workdir(self) -> Path:
        return self._workdir

    def localize(
        self,
        file_path: str | Path,
        *,
        allow_outside_workdir: bool = False,
        webdav_url: str | None = None,
        webdav_user: str | None = None,
        webdav_password: str | None = None,
    ) -> str:
        raw = str(file_path or "").strip()
        if not raw:
            raise ValueError("file_path is required")

        if raw.lower().startswith(_WEBDAV_PREFIX):
            rel = raw[len(_WEBDAV_PREFIX) :].lstrip("/")
            if not rel:
                raise ValueError("webdav path is required")
            url, user, pwd = self._webdav_config(webdav_url, webdav_user, webdav_password)
            dest = self._cache_path_for_webdav(url, rel)
            now = time.time()
            if dest.exists() and not self._is_expired(dest, now=now):
                self._write_meta(dest, source=f"{_WEBDAV_PREFIX}{rel}", webdav_url=url)
                self._touch(dest, now=now)
                self._maybe_cleanup(now=now, keep={dest})
                return str(dest)

            self._download_webdav(url, user, pwd, rel, dest)
            self._write_meta(dest, source=f"{_WEBDAV_PREFIX}{rel}", webdav_url=url)
            self._touch(dest, now=now)
            self._maybe_cleanup(now=now, keep={dest})
            return str(dest)

        path = Path(raw).expanduser()
        if not path.is_absolute():
            path = self._resolve_relative(path)
        else:
            path = self._resolve_absolute(path, allow_outside_workdir=allow_outside_workdir)
        if not path.exists():
            raise FileNotFoundError(str(path))
        return str(path)

    def match(self, pattern: str) -> list[str]:
        raw = str(pattern or "").strip()
        if not raw:
            return []
        if raw.lower().startswith(_WEBDAV_PREFIX):
            rel = raw[len(_WEBDAV_PREFIX) :].lstrip("/")
            return self._match_webdav(rel)
        return self._match_local(raw)

    def source(self, file_path: str | Path) -> str:
        raw = str(file_path or "").strip()
        if not raw:
            return raw
        if raw.lower().startswith(_WEBDAV_PREFIX):
            rel = raw[len(_WEBDAV_PREFIX) :].lstrip("/")
            return f"{_WEBDAV_PREFIX}{rel}"

        p = Path(raw).expanduser()
        if not p.is_absolute():
            try:
                p = self._resolve_relative(p)
            except Exception:  # noqa: BLE001
                return raw
        else:
            try:
                p = self._resolve_absolute(p, allow_outside_workdir=True)
            except Exception:  # noqa: BLE001
                return raw

        if not self._is_cache_path(p):
            return raw

        meta = self._read_meta(p)
        source = str(meta.get("source") or "").strip() if isinstance(meta, dict) else ""
        if source:
            return source
        return raw

    def _files_ui_state_path(self) -> Path:
        return data_root_for(self._workdir) / "ui" / "files_ui.json"

    def _load_files_ui_state(self) -> FilesUiState:
        path = self._files_ui_state_path()
        if not path.exists():
            return FilesUiState()
        try:
            raw = path.read_text(encoding="utf-8")
            return FilesUiState.model_validate_json(raw)
        except Exception:  # noqa: BLE001
            return FilesUiState()

    def _webdav_config(self, url: str | None, user: str | None, password: str | None) -> tuple[str, str, str]:
        state = self._load_files_ui_state()
        raw_url = str(url or "").strip() or str(state.webdavUrl or "").strip()
        raw_user = str(user or "").strip() if user is not None else str(state.webdavUser or "").strip()
        raw_pwd = str(password or "") if password is not None else str(state.webdavPass or "")
        url = raw_url
        if not url:
            raise ValueError("WebDAV URL is not configured. Set it in the Files panel.")
        return url, raw_user, raw_pwd

    def _cache_dir_for_webdav(self, base_url: str) -> Path:
        safe = hashlib.sha256(str(base_url).encode("utf-8")).hexdigest()[:12]
        return self._cache_root / "webdav" / safe

    def _cache_path_for_webdav(self, base_url: str, remote_path: str) -> Path:
        name = _safe_name_with_ext(remote_path)
        key = hashlib.sha256(f"{base_url}\n{remote_path}".encode("utf-8")).hexdigest()[:12]
        return self._cache_dir_for_webdav(base_url) / f"{key}_{name}"

    def _meta_path(self, path: Path) -> Path:
        return Path(f"{path}.meta.json")

    def _write_meta(self, path: Path, *, source: str, webdav_url: str) -> None:
        meta = {
            "source": str(source),
            "webdav_url": str(webdav_url or ""),
            "ts": int(time.time()),
        }
        try:
            meta_path = self._meta_path(path)
            meta_path.write_text(json.dumps(meta, ensure_ascii=False), encoding="utf-8")
        except Exception:  # noqa: BLE001
            pass

    def _read_meta(self, path: Path) -> dict[str, str]:
        meta_path = self._meta_path(path)
        if not meta_path.exists():
            return {}
        try:
            raw = meta_path.read_text(encoding="utf-8")
            data = json.loads(raw)
        except Exception:  # noqa: BLE001
            return {}
        if not isinstance(data, dict):
            return {}
        out: dict[str, str] = {}
        for key in ("source", "webdav_url"):
            val = data.get(key)
            if isinstance(val, str) and val.strip():
                out[key] = val.strip()
        return out

    def _download_webdav(self, base_url: str, username: str, password: str, remote_path: str, dest: Path) -> None:
        dest.parent.mkdir(parents=True, exist_ok=True)
        url = _join_url(base_url, remote_path)
        headers: dict[str, str] = {}
        auth = _auth_header(username, password)
        if auth:
            headers["Authorization"] = auth
        req = request.Request(url, method="GET", headers=headers)
        tmp = dest.with_suffix(dest.suffix + ".tmp")
        try:
            with request.urlopen(req, timeout=30) as resp:
                with tmp.open("wb") as f:
                    while True:
                        chunk = resp.read(1024 * 1024)
                        if not chunk:
                            break
                        f.write(chunk)
            tmp.replace(dest)
        finally:
            try:
                if tmp.exists():
                    tmp.unlink()
            except Exception:  # noqa: BLE001
                pass

    def _match_local(self, pattern: str) -> list[str]:
        rel_pattern = self._normalize_local_pattern(pattern)
        if not rel_pattern:
            return []
        out: list[str] = []
        for path in self._workdir.glob(rel_pattern):
            if not path.is_file():
                continue
            try:
                rel = str(path.relative_to(self._workdir))
            except ValueError:
                continue
            out.append(rel)
        out.sort(key=alphanumeric)
        return out

    def _normalize_local_pattern(self, pattern: str) -> str:
        raw = str(pattern or "").strip()
        if not raw:
            return ""
        p = Path(raw).expanduser()
        if p.is_absolute():
            try:
                try:
                    resolved = p.resolve(strict=False)
                except TypeError:
                    resolved = p.resolve()
                rel = resolved.relative_to(self._workdir)
            except Exception as exc:  # noqa: BLE001
                raise ValueError("path must be under workdir") from exc
            return str(rel)
        if ".." in Path(raw).parts:
            raise ValueError("path must be under workdir")
        return raw

    def _resolve_relative(self, path: Path) -> Path:
        try:
            resolved = (self._workdir / path).resolve(strict=False)
        except TypeError:
            resolved = (self._workdir / path).resolve()
        try:
            resolved.relative_to(self._workdir)
        except Exception as exc:  # noqa: BLE001
            raise ValueError("path must be under workdir") from exc
        return resolved

    def _resolve_absolute(self, path: Path, *, allow_outside_workdir: bool) -> Path:
        try:
            resolved = path.resolve(strict=False)
        except TypeError:
            resolved = path.resolve()
        if allow_outside_workdir:
            return resolved
        try:
            resolved.relative_to(self._workdir)
        except Exception as exc:  # noqa: BLE001
            raise ValueError("path must be under workdir") from exc
        return resolved

    def _match_webdav(self, pattern: str) -> list[str]:
        rel = str(pattern or "").strip().lstrip("/")
        if not rel:
            rel = "*"
        url, user, pwd = self._webdav_config(None, None, None)

        posix = PurePosixPath(rel)
        parts = list(posix.parts)
        dir_parts = parts[:-1]
        file_pat = parts[-1] if parts else "*"
        dir_has_glob = any(_has_glob(part) or part == "**" for part in dir_parts)
        needs_recursive = dir_has_glob or "**" in parts

        prefix_parts: list[str] = []
        for part in parts:
            if part == "**" or _has_glob(part):
                break
            prefix_parts.append(part)
        start_dir = "/".join(prefix_parts)

        out: list[str] = []
        if needs_recursive:
            for rel_path in self._webdav_walk_files(url, user, pwd, dir_path=start_dir):
                if fnmatch.fnmatchcase(rel_path, rel):
                    out.append(f"{_WEBDAV_PREFIX}{rel_path}")
        else:
            dir_path = "/".join(dir_parts)
            for entry in self._webdav_list_dir(url, user, pwd, dir_path=dir_path):
                if entry.get("kind") != "file":
                    continue
                name = entry.get("name") or ""
                if not fnmatch.fnmatchcase(name, file_pat):
                    continue
                rel_path = entry.get("path") or name
                out.append(f"{_WEBDAV_PREFIX}{rel_path}")

        out.sort(key=lambda p: alphanumeric(p[len(_WEBDAV_PREFIX) :]))
        return out

    def _webdav_list_dir(self, base_url: str, username: str, password: str, *, dir_path: str) -> list[dict[str, str]]:
        from cacaopod.webdav import list_children

        entries = list_children(base_url, username=username, password=password, dir_path=dir_path)
        out: list[dict[str, str]] = []
        for entry in entries:
            try:
                kind = str(entry.kind)
                name = str(entry.name)
                path = str(entry.path)
            except Exception:  # noqa: BLE001
                continue
            out.append({"kind": kind, "name": name, "path": path})
        return out

    def _webdav_walk_files(self, base_url: str, username: str, password: str, *, dir_path: str) -> Iterable[str]:
        seen: set[str] = set()

        def walk(prefix: str) -> Iterable[str]:
            if prefix in seen:
                return []
            seen.add(prefix)
            entries = self._webdav_list_dir(base_url, username, password, dir_path=prefix)
            out: list[str] = []
            for entry in entries:
                kind = entry.get("kind") or ""
                rel_path = entry.get("path") or ""
                if not rel_path:
                    continue
                if kind == "dir":
                    out.extend(walk(rel_path))
                elif kind == "file":
                    out.append(rel_path)
            return out

        return walk(dir_path)

    def _is_expired(self, path: Path, *, now: float) -> bool:
        try:
            mtime = path.stat().st_mtime
        except Exception:  # noqa: BLE001
            return True
        return now - mtime > self._max_age_sec

    def _touch(self, path: Path, *, now: float) -> None:
        try:
            path.touch()
            os.utime(path, (now, now))
        except Exception:  # noqa: BLE001
            pass
        try:
            meta_path = self._meta_path(path)
            if meta_path.exists():
                meta_path.touch()
                os.utime(meta_path, (now, now))
        except Exception:  # noqa: BLE001
            pass

    def _maybe_cleanup(self, *, now: float, keep: set[Path] | None = None) -> None:
        if now - self._last_cleanup_ts < _CLEANUP_INTERVAL_SEC:
            return
        self._cleanup(now=now, keep=keep)
        self._last_cleanup_ts = now

    def _cleanup(self, *, now: float, keep: set[Path] | None = None) -> None:
        root = self._cache_root
        if not root.exists():
            return
        keep = keep or set()

        files = [p for p in root.rglob("*") if p.is_file()]
        for path in files:
            if path in keep:
                continue
            if self._is_expired(path, now=now):
                try:
                    path.unlink()
                except Exception:  # noqa: BLE001
                    pass
                if not str(path).endswith(".meta.json"):
                    try:
                        meta_path = self._meta_path(path)
                        if meta_path.exists():
                            meta_path.unlink()
                    except Exception:  # noqa: BLE001
                        pass

        files = [p for p in files if p.exists()]
        total = 0
        sized: list[tuple[float, Path, int]] = []
        for path in files:
            try:
                stat = path.stat()
            except Exception:  # noqa: BLE001
                continue
            size = int(stat.st_size)
            total += size
            sized.append((float(stat.st_mtime), path, size))

        if total > self._max_cache_bytes:
            sized.sort(key=lambda item: item[0])
            for _mtime, path, size in sized:
                if path in keep:
                    continue
                if total <= self._max_cache_bytes:
                    break
                try:
                    path.unlink()
                    total -= size
                except Exception:  # noqa: BLE001
                    pass

        try:
            for d in sorted((p for p in root.rglob("*") if p.is_dir()), reverse=True):
                try:
                    next(d.iterdir())
                except StopIteration:
                    d.rmdir()
                except Exception:  # noqa: BLE001
                    pass
        except Exception:  # noqa: BLE001
            pass

    def _is_cache_path(self, path: Path) -> bool:
        try:
            path.resolve().relative_to(self._cache_root)
        except Exception:  # noqa: BLE001
            return False
        return True

    def __repr__(self) -> str:
        return f"FileManager(workdir={self._workdir!s})"
