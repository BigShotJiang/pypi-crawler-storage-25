from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
import time
import webbrowser
from pathlib import Path


def _resolve_workdir(value: str | None) -> str:
    if value is None or not value.strip():
        resolved = Path.cwd().resolve()
    else:
        resolved = Path(value).expanduser().resolve()

    if not resolved.exists():
        raise SystemExit(f"workdir does not exist: {resolved}")
    if not resolved.is_dir():
        raise SystemExit(f"workdir is not a directory: {resolved}")

    return str(resolved)


def _repo_root() -> Path:
    # In a source checkout, this resolves to "<repo>/backend/cacaopod/cli.py".
    return Path(__file__).resolve().parents[2]


def _find_frontend_dir() -> Path | None:
    override = os.environ.get("CACAOPOD_FRONTEND_DIR")
    if override:
        d = Path(override).expanduser().resolve()
        if (d / "package.json").exists():
            return d
        return None

    candidate = _repo_root() / "frontend"
    if (candidate / "package.json").exists():
        return candidate
    return None


def _npm_cmd() -> str:
    return shutil.which("npm") or shutil.which("npm.cmd") or "npm"


def _client_host(host: str) -> str:
    # 0.0.0.0 / :: are valid bind addresses but not valid client targets.
    if host in {"0.0.0.0", "::"}:
        return "127.0.0.1"
    return host


def _port_is_available(host: str, port: int) -> bool:
    try:
        infos = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    except OSError:
        infos = []

    # Fall back to an IPv4 bind attempt if name resolution fails.
    if not infos:
        infos = [(socket.AF_INET, socket.SOCK_STREAM, 0, "", (host, port))]

    for family, socktype, proto, _canon, sockaddr in infos:
        try:
            sock = socket.socket(family, socktype, proto)
        except OSError:
            continue
        try:
            sock.bind(sockaddr)
            return True
        except OSError:
            return False
        finally:
            try:
                sock.close()
            except OSError:
                pass

    return False


def _pick_backend_port(host: str, preferred: int) -> int:
    # Try the preferred port and then a small range above it.
    for p in range(int(preferred), int(preferred) + 50):
        if _port_is_available(host, p):
            return p

    # Last resort: ask OS for an ephemeral port.
    try:
        infos = socket.getaddrinfo(host, 0, type=socket.SOCK_STREAM)
    except OSError:
        infos = []
    if not infos:
        infos = [(socket.AF_INET, socket.SOCK_STREAM, 0, "", (host, 0))]
    family, socktype, proto, _canon, sockaddr = infos[0]
    with socket.socket(family, socktype, proto) as sock:
        sock.bind(sockaddr)
        return int(sock.getsockname()[1])


def _start_backend(*, env: dict[str, str], host: str, port: int, reload: bool) -> subprocess.Popen[bytes]:
    cmd = [
        sys.executable,
        "-m",
        "uvicorn",
        "cacaopod.server:app",
        "--host",
        host,
        "--port",
        str(port),
    ]
    if reload:
        cmd.append("--reload")
        # Ensure reload works even when `cacaopod` is executed from a different workdir.
        # Watch the installed package directory (editable install -> repo path).
        cmd.extend(["--reload-dir", str(Path(__file__).resolve().parent)])
        # Avoid wiping the in-memory session (globals/board) when tools/file_loaders are saved under workdir state.
        cmd.extend(["--reload-exclude", "**/.cacaopod/**/*.py"])
    return subprocess.Popen(cmd, env=env)


def _start_frontend(*, env: dict[str, str], cwd: Path, host: str, port: int) -> subprocess.Popen[bytes]:
    cmd = [
        _npm_cmd(),
        "run",
        "dev",
        "--",
        "--host",
        host,
        "--port",
        str(port),
    ]
    return subprocess.Popen(cmd, cwd=str(cwd), env=env)


def _terminate(proc: subprocess.Popen[bytes], *, timeout_s: float = 5.0) -> None:
    if proc.poll() is not None:
        return
    proc.terminate()
    try:
        proc.wait(timeout=timeout_s)
    except subprocess.TimeoutExpired:
        proc.kill()


def _run_serve(args: argparse.Namespace) -> int:
    workdir = _resolve_workdir(args.workdir)
    env = os.environ.copy()
    env["CACAOPOD_WORKDIR"] = workdir
    bind_host = str(args.backend_host)
    bind_port = _pick_backend_port(bind_host, int(args.backend_port))
    if bind_port != int(args.backend_port):
        print(f"[cacaopod] backend port {args.backend_port} is in use; using {bind_port}", file=sys.stderr)
    env["CACAOPOD_BACKEND_URL"] = f"http://{_client_host(bind_host)}:{bind_port}"

    backend = _start_backend(env=env, host=bind_host, port=bind_port, reload=args.reload)
    try:
        if args.open:
            webbrowser.open(f"http://{_client_host(bind_host)}:{bind_port}", new=2)
        return backend.wait()
    except KeyboardInterrupt:
        return 130
    finally:
        _terminate(backend)


def _run_dev(args: argparse.Namespace) -> int:
    frontend_dir = _find_frontend_dir()
    if frontend_dir is None:
        raise SystemExit(
            "frontend directory not found. Set CACAOPOD_FRONTEND_DIR or run from a source checkout containing ./frontend."
        )

    workdir = _resolve_workdir(args.workdir)
    env = os.environ.copy()
    env["CACAOPOD_WORKDIR"] = workdir
    bind_host = str(args.backend_host)
    bind_port = _pick_backend_port(bind_host, int(args.backend_port))
    if bind_port != int(args.backend_port):
        print(f"[cacaopod] backend port {args.backend_port} is in use; using {bind_port}", file=sys.stderr)
    env["CACAOPOD_BACKEND_URL"] = f"http://{_client_host(bind_host)}:{bind_port}"

    backend = _start_backend(env=env, host=bind_host, port=bind_port, reload=args.reload)
    frontend = _start_frontend(env=env, cwd=frontend_dir, host=args.frontend_host, port=args.frontend_port)

    try:
        if args.open:
            webbrowser.open(f"http://{args.frontend_host}:{args.frontend_port}", new=2)

        while True:
            backend_rc = backend.poll()
            frontend_rc = frontend.poll()
            if backend_rc is not None:
                return int(backend_rc)
            if frontend_rc is not None:
                return int(frontend_rc)
            time.sleep(0.2)
    except KeyboardInterrupt:
        return 130
    finally:
        _terminate(frontend)
        _terminate(backend)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="cacaopod")
    parser.add_argument("--workdir", default=None, help="Tool working directory (default: current directory).")
    parser.add_argument("--mode", choices=["auto", "dev", "serve"], default="auto")
    parser.add_argument("--open", action="store_true", help="Open the UI in the default browser.")

    parser.add_argument("--backend-host", default="127.0.0.1")
    parser.add_argument("--backend-port", type=int, default=8123)
    parser.add_argument("--reload", action="store_true", help="Enable backend auto-reload (dev only).")

    parser.add_argument("--frontend-host", default="127.0.0.1")
    parser.add_argument("--frontend-port", type=int, default=5510)

    args = parser.parse_args(argv)

    mode = args.mode
    if mode == "auto":
        mode = "dev" if _find_frontend_dir() is not None else "serve"

    if mode == "dev":
        return _run_dev(args)
    return _run_serve(args)


if __name__ == "__main__":
    raise SystemExit(main())
