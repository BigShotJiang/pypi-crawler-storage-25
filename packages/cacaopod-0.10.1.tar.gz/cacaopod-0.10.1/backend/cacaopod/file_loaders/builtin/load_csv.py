from __future__ import annotations

import csv
from pathlib import Path

import numpy as np
import pandas as pd


def _is_numeric_token(value: str) -> bool:
    token = value.strip()
    if token == "":
        return True
    try:
        float(token)
    except ValueError:
        return False
    return True


def _looks_like_header(path: Path, *, delimiter: str, skip_header: int) -> bool:
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        for _ in range(max(0, int(skip_header))):
            next(fh, None)
        reader = csv.reader(fh, delimiter=delimiter)
        for row in reader:
            if not row or all(not str(cell).strip() for cell in row):
                continue
            return any(not _is_numeric_token(str(cell)) for cell in row)
    return False


def _header_value(header: str | int | bool | None, path: Path, *, delimiter: str, skip_header: int) -> int | None:
    if isinstance(header, bool):
        return 0 if header else None
    if header is None:
        return None
    if isinstance(header, int):
        return header

    text = str(header).strip().lower()
    if text in {"", "none", "false", "no"}:
        return None
    if text == "auto":
        return 0 if _looks_like_header(path, delimiter=delimiter, skip_header=skip_header) else None
    return int(text)


def _numeric_columns(df: pd.DataFrame, dtype: str | None) -> dict[str, np.ndarray]:
    out: dict[str, np.ndarray] = {}
    for column in df.columns:
        series = pd.to_numeric(df[column], errors="coerce")
        if not series.notna().any():
            continue
        arr = series.to_numpy(dtype=float)
        if dtype:
            arr = arr.astype(np.dtype(dtype))
        out[str(column)] = arr
    if not out:
        raise ValueError("CSV has no numeric columns")
    return out


def load_csv(
    file_path: str | Path,
    delimiter: str = ",",
    skip_header: int = 0,
    dtype: str | None = None,
    header: str | int | bool | None = "auto",
) -> np.ndarray | dict[str, np.ndarray]:
    """Load a CSV-like text file into numpy arrays.

    Headered CSV files are returned as dict[column_name, array], so a requested
    wave name like `sample` materializes as `sample_column`.

    @extensions: .csv
    """

    p = Path(file_path).expanduser()
    header_row = _header_value(header, p, delimiter=delimiter, skip_header=int(skip_header))
    if header_row is None:
        return np.genfromtxt(p, delimiter=delimiter, skip_header=int(skip_header), dtype=dtype)

    df = pd.read_csv(p, delimiter=delimiter, skiprows=int(skip_header), header=header_row)
    return _numeric_columns(df, dtype)
