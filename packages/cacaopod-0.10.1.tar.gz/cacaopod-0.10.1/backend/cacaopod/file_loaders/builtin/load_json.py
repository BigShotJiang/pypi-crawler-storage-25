from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import numpy as np


def _as_numeric_array(value: Any, *, label: str) -> np.ndarray:  # noqa: ANN401
    arr = np.asarray(value)
    if arr.ndim == 0:
        arr = arr.reshape(1)
    if arr.ndim > 3:
        raise ValueError(f"{label} has {arr.ndim} dimensions; only 1D, 2D, and 3D arrays are supported")
    if arr.dtype.kind not in "biufc":
        try:
            arr = arr.astype(float)
        except (TypeError, ValueError) as exc:
            raise ValueError(f"{label} is not numeric") from exc
    return arr


def load_json(file_path: str | Path, key: str | None = None) -> np.ndarray | dict[str, np.ndarray]:
    """Load numeric arrays from a JSON file.

    A top-level list is loaded as one array. A top-level object is loaded as
    dict[key, array], skipping non-numeric values unless `key` is specified.

    @extensions: .json
    """

    p = Path(file_path).expanduser()
    with p.open("r", encoding="utf-8") as fh:
        data = json.load(fh)

    if key is not None:
        if not isinstance(data, dict):
            raise ValueError("JSON key can only be used with a top-level object")
        return _as_numeric_array(data[key], label=key)

    if isinstance(data, dict):
        out: dict[str, np.ndarray] = {}
        for item_key, value in data.items():
            try:
                out[str(item_key)] = _as_numeric_array(value, label=str(item_key))
            except ValueError:
                continue
        if not out:
            raise ValueError("JSON object has no numeric array values")
        return out

    return _as_numeric_array(data, label=p.name)
