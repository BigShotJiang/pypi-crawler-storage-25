from __future__ import annotations

from pathlib import Path

import numpy as np


def load_npz(file_path: str | Path, key: str | None = None) -> np.ndarray:
    """Load a NumPy `.npz` archive into a numpy array.

    If `key` is omitted, the first array in the archive is returned.

    @extensions: .npz
    """

    p = Path(file_path).expanduser()
    with np.load(p, allow_pickle=False) as z:
        if key is not None:
            return z[key]
        names = list(z.files)
        if not names:
            raise ValueError("empty npz archive")
        return z[names[0]]


