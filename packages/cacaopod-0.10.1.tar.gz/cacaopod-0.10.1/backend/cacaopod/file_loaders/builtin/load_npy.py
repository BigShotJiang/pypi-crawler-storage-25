from __future__ import annotations

from pathlib import Path

import numpy as np


def load_npy(file_path: str | Path) -> np.ndarray:
    """Load a NumPy `.npy` file into a numpy array.

    @extensions: .npy
    """

    p = Path(file_path).expanduser()
    return np.load(p, allow_pickle=False)


