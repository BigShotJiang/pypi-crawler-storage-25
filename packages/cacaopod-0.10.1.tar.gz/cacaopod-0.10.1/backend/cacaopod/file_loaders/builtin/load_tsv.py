from __future__ import annotations

from pathlib import Path

import numpy as np

from cacaopod.file_loaders.builtin.load_csv import load_csv


def load_tsv(
    file_path: str | Path,
    skip_header: int = 0,
    dtype: str | None = None,
    header: str | int | bool | None = "auto",
) -> np.ndarray | dict[str, np.ndarray]:
    """Load a tab-separated text file into numpy arrays.

    Headered files are returned as dict[column_name, array].

    @extensions: .tsv .tab
    """

    return load_csv(file_path, delimiter="\t", skip_header=skip_header, dtype=dtype, header=header)
