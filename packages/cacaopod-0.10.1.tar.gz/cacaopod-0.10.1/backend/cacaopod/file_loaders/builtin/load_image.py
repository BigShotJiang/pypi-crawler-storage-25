from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image


def load_image(
    file_path: str | Path,
    mode: str | None = "L",
    dtype: str | None = None,
    normalize: bool = False,
) -> np.ndarray:
    """Load an image file as a numpy array.

    By default images are converted to grayscale (`mode="L"`) so they load as
    2D arrays. Pass `mode="RGB"` or `mode=None` to keep color channels.

    @extensions: .png .jpg .jpeg .tif .tiff .bmp
    """

    p = Path(file_path).expanduser()
    with Image.open(p) as image:
        img = image.convert(mode) if mode is not None else image.copy()
        arr = np.asarray(img)

    if normalize:
        return arr.astype(float) / 255.0
    if dtype:
        return arr.astype(np.dtype(dtype))
    return arr
