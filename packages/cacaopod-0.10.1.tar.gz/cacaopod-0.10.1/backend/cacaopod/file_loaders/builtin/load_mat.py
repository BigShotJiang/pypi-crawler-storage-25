from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
from scipy.io import loadmat


def _as_supported_array(value: Any, *, label: str) -> np.ndarray:  # noqa: ANN401
    arr = np.asarray(value)
    if arr.ndim == 0:
        arr = arr.reshape(1)
    if arr.ndim > 3:
        raise ValueError(f"{label} has {arr.ndim} dimensions; only 1D, 2D, and 3D arrays are supported")
    if arr.dtype.kind not in "biufc":
        raise ValueError(f"{label} is not a numeric array")
    return arr


def load_mat(file_path: str | Path, key: str | None = None, squeeze: bool = True) -> np.ndarray | dict[str, np.ndarray]:
    """Load numeric arrays from a MATLAB `.mat` file.

    If `key` is omitted, all numeric variables are returned as dict[name, array].

    @extensions: .mat
    """

    p = Path(file_path).expanduser()
    data = loadmat(p, squeeze_me=bool(squeeze), struct_as_record=False)
    if key is not None:
        return _as_supported_array(data[key], label=key)

    out: dict[str, np.ndarray] = {}
    for item_key, value in data.items():
        if str(item_key).startswith("__"):
            continue
        try:
            out[str(item_key)] = _as_supported_array(value, label=str(item_key))
        except ValueError:
            continue
    if not out:
        raise ValueError("MAT file has no numeric array variables")
    return out
