from __future__ import annotations

from pathlib import Path

import numpy as np


def load_txt(file_path: str | Path, delimiter: str | None = None, skiprows: int = 0) -> np.ndarray:
    """Load a whitespace/TSV-like text file into a numpy array.

    @extensions: .txt .dat .asc
    """

    p = Path(file_path).expanduser()
    return np.loadtxt(p, delimiter=delimiter, skiprows=int(skiprows))
