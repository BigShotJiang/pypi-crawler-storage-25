from __future__ import annotations

import uuid
from typing import Any, Literal

from pydantic import BaseModel, Field


class BoardSelection(BaseModel):
    i: int = 0


class RunRequest(BaseModel):
    code: str = Field(..., min_length=0, description="Python code to execute")
    selection: BoardSelection = Field(default_factory=BoardSelection)


class BoardPodSettingsRequest(BaseModel):
    selection: BoardSelection = Field(default_factory=BoardSelection)
    heatmapSettings: dict[str, Any] | None = None
    traceSettings: dict[str, Any] | None = None
    traceSettingsByWave: list[dict[str, Any]] | None = None
    activeWaveIndex: int | None = None


class BoardRemoveRequest(BaseModel):
    selection: BoardSelection = Field(default_factory=BoardSelection)


class BoardUndoRequest(BaseModel):
    selection: BoardSelection = Field(default_factory=BoardSelection)


class BoardWaveRemoveRequest(BaseModel):
    selection: BoardSelection = Field(default_factory=BoardSelection)
    waveIndex: int = 0


class ErrorInfo(BaseModel):
    message: str
    traceback: str


class HeatmapViewSettings(BaseModel):
    colorscale: str = "YlGnBu"
    autoscale: bool = True
    zmin: float | None = None
    zmax: float | None = None
    reverseScale: bool = False
    heatmapSmoothing: Literal["none", "fast", "best"] = "none"
    sliceAxis: Literal["x", "y", "z"] = "z"
    sliceIndex: int = Field(default=0, ge=0)
    origin: Literal["upper", "lower"] = "upper"
    aspect: Literal["auto", "equal"] = "auto"
    plotAspectMode: Literal["global", "data", "custom"] = "data"
    plotAspectW: int = Field(default=3, ge=1, le=10000)
    plotAspectH: int = Field(default=2, ge=1, le=10000)
    plotBg: Literal["transparent", "white", "light"] = "transparent"
    showGrid: bool = True
    showAxisLine: bool = True
    fontSize: int = Field(default=12, ge=8, le=32)
    hoverMode: Literal["closest", "x", "x unified", "y", "y unified", "none"] = "closest"
    showLegend: bool = False
    legendPosition: Literal["top-right", "top-left", "bottom-right", "bottom-left"] = "top-right"
    showScale: bool = False
    zLabel: str = ""
    zLabelGapPx: int = Field(default=4, ge=0, le=200)
    xLabel: str = ""
    xLog: bool = False
    xTickCount: int | None = Field(default=None, ge=0, le=100)
    xMin: float | None = None
    xMax: float | None = None
    yLabel: str = ""
    yLog: bool = False
    yTickCount: int | None = Field(default=None, ge=0, le=100)
    yMin: float | None = None
    yMax: float | None = None
    annotationText: str = ""
    annotationX: float = Field(default=0.02, ge=0.0, le=1.0)
    annotationY: float = Field(default=0.98, ge=0.0, le=1.0)
    annotationBg: Literal["transparent", "white", "white-border"] = "transparent"
    scaleBarEnabled: bool = False
    scaleBarLength: float = Field(default=1.0, ge=0.0)
    scaleBarX: float = 0.7
    scaleBarY: float = 0.9


class TraceViewSettings(BaseModel):
    mode: Literal["markers", "lines", "lines+markers", "bar"] = "lines+markers"
    markerSymbol: str = "circle"
    markerSize: float = Field(default=6.0, ge=1.0, le=60.0)
    markerStroke: str = "#0000CC"
    markerFill: str = "#0000CC"
    markerStrokeWidth: float = Field(default=1.0, ge=0.0, le=20.0)
    lineDash: Literal["solid", "dot", "dash", "longdash", "dashdot", "longdashdot"] = "solid"
    lineWidth: float = Field(default=2.0, ge=0.0, le=50.0)
    lineColor: str = "#0000CC"
    opacity: float = Field(default=1.0, ge=0.0, le=1.0)
    errorColor: str = "#333333"
    errorThickness: float = Field(default=1.5, ge=0.0, le=20.0)
    errorWidth: float = Field(default=3.0, ge=0.0, le=40.0)


class ViewState(BaseModel):
    sizeTarget: Literal["plot", "pod"] = "plot"
    widthPx: int = Field(default=420, ge=20, le=10000)
    aspectPreset: Literal["1:1", "3:2", "4:3", "custom"] = "3:2"
    aspectW: int = Field(default=3, ge=1, le=1000)
    aspectH: int = Field(default=2, ge=1, le=1000)
    showWaveInfo: bool = True


class WaveSnapshot(BaseModel):
    kind: Literal["ndarray", "wave"]
    ndim: Literal[1, 2, 3]
    dtype: str
    shape: list[int]
    data: list[Any] | list[list[Any]] | list[list[list[Any]]]
    dataRef: str | None = None
    dataLoaded: bool = True
    uid: str | None = None
    name: str | None = None
    description: str | None = None
    graphLegend: str | None = None
    errorbar: list[float | None] | None = None
    x: list[float | None] | None = None
    y: list[float | None] | None = None
    z: list[float | None] | None = None
    x0: float | None = None
    dx: float | None = None
    y0: float | None = None
    dy: float | None = None
    z0: float | None = None
    dz: float | None = None


class WaveDataRequest(BaseModel):
    pod_id: str = ""
    uid: str
    sliceAxis: Literal["x", "y", "z"] | None = None
    sliceIndex: int = 0


class WaveDataResponse(BaseModel):
    uid: str
    ndim: Literal[1, 2, 3]
    shape: list[int]
    dtype: str
    data: list[Any] | list[list[Any]]
    sliceAxis: Literal["x", "y", "z"] | None = None
    sliceIndex: int | None = None
    xAxis: Literal["x", "y", "z"] | None = None
    yAxis: Literal["x", "y", "z"] | None = None


class BoardSnapshot(BaseModel):
    selected: BoardSelection
    pods: list["PodSnapshot"] = Field(default_factory=list)


class PodSnapshot(BaseModel):
    id: str
    name: str = ""
    signature: str = ""
    waves: list[WaveSnapshot] = Field(default_factory=list)
    heatmapSettings: HeatmapViewSettings = Field(default_factory=HeatmapViewSettings)
    traceSettings: TraceViewSettings = Field(default_factory=TraceViewSettings)
    traceSettingsByWave: list[TraceViewSettings] = Field(default_factory=list)
    activeWaveIndex: int = Field(default=0, ge=0)


class PodPatch(BaseModel):
    i: int = 0
    pod: PodSnapshot


class BoardPatch(BaseModel):
    selected: BoardSelection
    pods: list[PodPatch] = Field(default_factory=list)
    appendPods: list[PodSnapshot] = Field(default_factory=list)


class BoardUpdateResponse(BaseModel):
    board: BoardSnapshot | None = None
    boardPatch: BoardPatch | None = None


class RunResponse(BaseModel):
    status: Literal["ok", "error"]
    board: BoardSnapshot | None = None
    boardPatch: BoardPatch | None = None
    stdout: str = ""
    stderr: str = ""
    error: ErrorInfo | None = None
    execMs: float | None = None


class CodeHistoryEntry(BaseModel):
    id: str = Field(default_factory=lambda: uuid.uuid4().hex)
    ts: int = 0  # ms since epoch
    code: str = ""
    favorite: bool = False


class EditorState(BaseModel):
    code: str = ""
    history: list[CodeHistoryEntry] = Field(default_factory=list)


class EditorHistoryFavoriteRequest(BaseModel):
    id: str
    favorite: bool | None = None  # None -> toggle


class EditorHistoryDeleteRequest(BaseModel):
    id: str


class EditorHistoryLoadRequest(BaseModel):
    start_ts_ms: int = 0
    end_ts_ms: int = 0


class EditorHistoryLoadResponse(BaseModel):
    entries: list[CodeHistoryEntry] = Field(default_factory=list)


class EditorHistoryFavoriteResponse(BaseModel):
    id: str
    favorite: bool


class EditorHistoryDeleteResponse(BaseModel):
    id: str


class ResetResponse(BaseModel):
    status: Literal["ok"]


class RegisteredTool(BaseModel):
    id: str = ""
    name: str = ""
    location: Literal["builtin", "user", "workdir"] = "workdir"
    pinned: bool = False


class ToolsRegistry(BaseModel):
    version: int = 1
    registeredTools: list[RegisteredTool] = Field(default_factory=list)
    workflows: list[dict[str, Any]] = Field(default_factory=list)


class RegisteredFileLoader(BaseModel):
    name: str = ""
    location: Literal["builtin", "user", "workdir"] = "workdir"


class RegisteredNamingRule(BaseModel):
    name: str = ""
    location: Literal["builtin", "user", "workdir"] = "workdir"


class FilesUiState(BaseModel):
    version: int = 1
    selectedDir: str = ""
    extension: str = ""
    loaderByDir: dict[str, dict[str, RegisteredFileLoader]] = Field(default_factory=dict)
    storageMode: Literal["local", "webdav"] = "local"
    webdavUrl: str = ""
    webdavUser: str = ""
    webdavPass: str = ""
    webdavDir: str = ""
    webdavExt: str = ""


class BoardSummary(BaseModel):
    id: str
    name: str
    ts: int = 0  # ms since epoch
    updated: int = 0  # ms since epoch


class BoardsListResponse(BaseModel):
    activeId: str | None = None
    boards: list[BoardSummary] = Field(default_factory=list)


class BoardCreateRequest(BaseModel):
    name: str = ""


class BoardSwitchRequest(BaseModel):
    id: str


class BoardRenameRequest(BaseModel):
    id: str
    name: str = ""


class BoardApplyResponse(BaseModel):
    activeId: str
    boards: list[BoardSummary] = Field(default_factory=list)
    board: BoardSnapshot


class WorkdirInfo(BaseModel):
    path: str
    name: str
    storage_ok: bool = True
    warning: str | None = None


class ToolParamInfo(BaseModel):
    name: str
    annotation: str
    default_repr: str | None = None
    is_wave: bool = False


class ToolSummaryInfo(BaseModel):
    name: str
    ndim: int | None = None
    location: Literal["builtin", "user", "workdir"]
    signature: str = ""
    doc: str = ""
    data_process: bool = False
    params: list[ToolParamInfo] = Field(default_factory=list)


class ToolsListResponse(BaseModel):
    tools: list[ToolSummaryInfo] = Field(default_factory=list)


class ToolSourceResponse(BaseModel):
    name: str
    ndim: int | None = None
    location: Literal["builtin", "user", "workdir"]
    source: str


class ToolSaveRequest(BaseModel):
    location: Literal["builtin", "user", "workdir"]
    source: str


class ToolFormulaFitParam(BaseModel):
    name: str
    init: float | None = None


class ToolFormulaFitRequest(BaseModel):
    name: str
    location: Literal["user", "workdir"]
    ndim: Literal[1, 2]
    formula: str
    params: list[ToolFormulaFitParam] = Field(default_factory=list)


class ToolFunctionFitRequest(BaseModel):
    name: str
    location: Literal["user", "workdir"]
    ndim: Literal[1, 2]
    model_source: str
    function_name: str = "model"
    params: list[ToolFormulaFitParam] = Field(default_factory=list)


class ToolRunRequest(BaseModel):
    name: str
    ndim: int | None = None
    selection: BoardSelection = Field(default_factory=BoardSelection)
    kwargs: dict[str, Any] = Field(default_factory=dict)
    waveIndex: int | None = Field(default=None, ge=0)


class ToolDocstringRequest(BaseModel):
    name: str
    source: str
    language: Literal["ja", "en"] = "ja"
    model: str | None = None


class ToolDocstringResponse(BaseModel):
    docstring: str


class ToolGptCoderWaveContext(BaseModel):
    ndim: int | None = None
    shape: list[int] | None = None
    dtype: str | None = None
    name: str | None = None
    description: str | None = None


class ToolChatMessage(BaseModel):
    role: Literal["user", "assistant"] = "user"
    content: str = ""
    ts: int = 0  # ms since epoch


class ToolGptCoderRequest(BaseModel):
    tool_id: str = ""
    name: str
    request: str = ""
    console_code: str = ""
    error: str | None = None
    fit_tool: bool | None = None
    context_wave: ToolGptCoderWaveContext | None = None
    language: Literal["ja", "en"] = "ja"
    model: str | None = None


class ToolGptCoderResponse(BaseModel):
    code: str
    messages: list[ToolChatMessage] = Field(default_factory=list)


class ToolGptCoderHistoryResponse(BaseModel):
    tool_id: str
    messages: list[ToolChatMessage] = Field(default_factory=list)


class FileLoaderSummaryInfo(BaseModel):
    name: str
    location: Literal["builtin", "user", "workdir"]
    extensions: list[str] = Field(default_factory=list)
    signature: str = ""
    doc: str = ""


class FileLoadersListResponse(BaseModel):
    file_loaders: list[FileLoaderSummaryInfo] = Field(default_factory=list)


class FileLoaderSourceResponse(BaseModel):
    name: str
    location: Literal["builtin", "user", "workdir"]
    source: str


class FileLoaderSaveRequest(BaseModel):
    location: Literal["builtin", "user", "workdir"]
    source: str


class NamingRuleSummaryInfo(BaseModel):
    name: str = ""
    location: Literal["builtin", "user", "workdir"] = "workdir"
    signature: str = ""
    doc: str = ""


class NamingRulesListResponse(BaseModel):
    naming_rules: list[NamingRuleSummaryInfo] = Field(default_factory=list)


class NamingRuleSourceResponse(BaseModel):
    name: str
    location: Literal["builtin", "user", "workdir"]
    source: str


class NamingRuleSaveRequest(BaseModel):
    location: Literal["builtin", "user", "workdir"]
    source: str


class NamingRulePreviewItem(BaseModel):
    file_path: str
    wave_name: str | None = None
    error: str | None = None


class NamingRulePreviewRequest(BaseModel):
    files: list[str] = Field(default_factory=list)
    rule: RegisteredNamingRule


class NamingRulePreviewSourceRequest(BaseModel):
    name: str = ""
    source: str = ""
    files: list[str] = Field(default_factory=list)


class NamingRulePreviewResponse(BaseModel):
    items: list[NamingRulePreviewItem] = Field(default_factory=list)
    duplicates: list[str] = Field(default_factory=list)


class NamingRuleGenerateRequest(BaseModel):
    name: str = ""
    files: list[str] = Field(default_factory=list)
    examples_text: str = ""
    model: str | None = None


class NamingRuleGenerateResponse(BaseModel):
    source: str


class FileTreeEntry(BaseModel):
    kind: Literal["dir", "file"]
    name: str
    path: str


class FileListResponse(BaseModel):
    files: list[FileTreeEntry] = Field(default_factory=list)


class FileChildrenResponse(BaseModel):
    entries: list[FileTreeEntry] = Field(default_factory=list)


class WebDavAuth(BaseModel):
    url: str
    username: str | None = None
    password: str | None = None


class WebDavChildrenRequest(BaseModel):
    auth: WebDavAuth
    dir: str = ""


class WebDavListRequest(BaseModel):
    auth: WebDavAuth
    dir: str = ""
    ext: str = ""


class WebDavLoadRequest(BaseModel):
    auth: WebDavAuth
    file_path: str
    selection: BoardSelection = Field(default_factory=BoardSelection)
    new_pod: bool = False
    append_pod: bool = False
    name: str | None = None
    allow_overwrite: bool = False
    naming_rule: RegisteredNamingRule | None = None
    loader: RegisteredFileLoader | None = None
    kwargs: dict[str, Any] = Field(default_factory=dict)


class WebDavBatchLoadRequest(BaseModel):
    auth: WebDavAuth
    files: list[str] = Field(default_factory=list)
    mode: Literal["pods", "single_pod"] = "pods"
    loader: RegisteredFileLoader | None = None
    kwargs: dict[str, Any] = Field(default_factory=dict)
    as_named_waves: bool = False
    naming_rule: RegisteredNamingRule | None = None
    allow_overwrite: bool = False
    skip_existing: bool = False


class Hdf5NodeInfo(BaseModel):
    kind: Literal["group", "dataset"]
    name: str
    path: str
    shape: list[int] = Field(default_factory=list)
    dtype: str = ""
    ndim: int | None = None
    size: int | None = None
    attrs: dict[str, str] = Field(default_factory=dict)
    loadable: bool = False
    reason: str | None = None
    children: list["Hdf5NodeInfo"] = Field(default_factory=list)


class Hdf5InspectRequest(BaseModel):
    file_path: str
    auth: WebDavAuth | None = None


class Hdf5InspectResponse(BaseModel):
    file_path: str
    root: Hdf5NodeInfo


class Hdf5DatasetLoadSpec(BaseModel):
    path: str
    name: str = ""
    squeeze: bool = True
    transpose: bool = False


class Hdf5LoadRequest(BaseModel):
    file_path: str
    auth: WebDavAuth | None = None
    selection: BoardSelection = Field(default_factory=BoardSelection)
    mode: Literal["pods", "single_pod"] = "pods"
    datasets: list[Hdf5DatasetLoadSpec] = Field(default_factory=list)
    allow_overwrite: bool = False


class FileLoadRequest(BaseModel):
    file_path: str
    selection: BoardSelection = Field(default_factory=BoardSelection)
    new_pod: bool = False
    append_pod: bool = False
    name: str | None = None
    allow_overwrite: bool = False
    naming_rule: RegisteredNamingRule | None = None
    loader: RegisteredFileLoader | None = None
    kwargs: dict[str, Any] = Field(default_factory=dict)


class FileBatchLoadRequest(BaseModel):
    files: list[str] = Field(default_factory=list)
    selection: BoardSelection = Field(default_factory=BoardSelection)
    mode: Literal["pods", "single_pod"] = "pods"
    loader: RegisteredFileLoader | None = None
    kwargs: dict[str, Any] = Field(default_factory=dict)
    as_named_waves: bool = False
    naming_rule: RegisteredNamingRule | None = None
    allow_overwrite: bool = False
    skip_existing: bool = False


class WaveEntry(BaseModel):
    name: str
    uid: str


class WaveListResponse(BaseModel):
    board_id: str = ""
    board_name: str = ""
    waves: list[WaveEntry] = Field(default_factory=list)


class DataEntry(BaseModel):
    name: str
    uid: str
    kind: str = ""


class DataListResponse(BaseModel):
    board_id: str = ""
    board_name: str = ""
    items: list[DataEntry] = Field(default_factory=list)


class DataPrintRequest(BaseModel):
    data_path: str


class DataFramePreviewResponse(BaseModel):
    columns: list[str] = Field(default_factory=list)
    index: list[str] = Field(default_factory=list)
    rows: list[list[Any]] = Field(default_factory=list)


class DataFrameUpdateRequest(BaseModel):
    data_path: str
    columns: list[str] = Field(default_factory=list)
    index: list[str] = Field(default_factory=list)
    rows: list[list[Any]] = Field(default_factory=list)


class StatusResponse(BaseModel):
    status: Literal["ok", "error"]
    message: str = ""


class WaveShowRequest(BaseModel):
    wave_path: str
    selection: BoardSelection = Field(default_factory=BoardSelection)
    new_pod: bool = False
    append_pod: bool = False


class FavoriteSummary(BaseModel):
    id: str
    ts: int = 0
    wave_name: str | None = None
    wave_wm_path: str | None = None
    comment: str = ""
    heatmapSettings: HeatmapViewSettings = Field(default_factory=HeatmapViewSettings)
    traceSettings: TraceViewSettings = Field(default_factory=TraceViewSettings)
    thumb_url: str = ""


class FavoritesListResponse(BaseModel):
    favorites: list[FavoriteSummary] = Field(default_factory=list)


class FavoriteAddRequest(BaseModel):
    selection: BoardSelection = Field(default_factory=BoardSelection)
    heatmapSettings: HeatmapViewSettings = Field(default_factory=HeatmapViewSettings)
    traceSettings: TraceViewSettings = Field(default_factory=TraceViewSettings)
    thumbnail_data_url: str = ""
    comment: str = ""


class FavoriteLoadRequest(BaseModel):
    id: str
    selection: BoardSelection = Field(default_factory=BoardSelection)
    new_pod: bool = False


class GifExportRequest(BaseModel):
    frames: list[str] = Field(default_factory=list, min_length=1, max_length=400)
    delay_ms: int = Field(default=200, ge=10, le=10000)
    filename: str | None = None


class FavoriteLoadResponse(BaseModel):
    board: BoardSnapshot


class FavoriteCommentRequest(BaseModel):
    id: str
    comment: str = ""


BoardSnapshot.model_rebuild()
