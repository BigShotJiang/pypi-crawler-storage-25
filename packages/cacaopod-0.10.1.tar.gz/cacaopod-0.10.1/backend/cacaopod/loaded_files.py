from __future__ import annotations

from typing import Any


def record_loaded_file(dm: Any, *, wave_name: str, file_path: str) -> None:  # noqa: ANN401
    """
    Update (or create) `dm["loaded_files"]` as a pandas DataFrame with:

    - index: wave_name
    - column: file_path

    Persistence is handled by DataManager.
    """

    try:
        import pandas as pd  # type: ignore[import-not-found]
    except Exception:  # noqa: BLE001
        return

    name = str(wave_name or "").strip()
    path = str(file_path or "").strip()
    if not name or not path:
        return

    df = None
    try:
        existing = dm["loaded_files"]
        if isinstance(existing, pd.DataFrame):
            df = existing
    except Exception:  # noqa: BLE001
        df = None

    if df is None:
        df = pd.DataFrame(columns=["file_path"])
        try:
            df.index.name = "wave_name"
        except Exception:  # noqa: BLE001
            pass

    if "file_path" not in df.columns:
        df = df.copy()
        df["file_path"] = None

    df.loc[name, "file_path"] = path

    try:
        dm["loaded_files"] = df
    except Exception:  # noqa: BLE001
        pass

