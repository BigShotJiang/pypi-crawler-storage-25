from __future__ import annotations

import base64
from pathlib import Path
from urllib import parse, request
from xml.etree import ElementTree as ET

from cacaopod.api_models import FileTreeEntry
from cacaopod.state.paths import safe_storage_key


def _auth_header(username: str | None, password: str | None) -> str | None:
    user = (username or "").strip()
    pwd = password or ""
    if not user and not pwd:
        return None
    token = base64.b64encode(f"{user}:{pwd}".encode("utf-8")).decode("ascii")
    return f"Basic {token}"


def _join_url(base_url: str, rel_path: str, *, is_dir: bool) -> str:
    base = str(base_url or "").strip()
    if not base:
        raise ValueError("WebDAV url is required")
    rel = str(rel_path or "").strip().lstrip("/")
    if rel:
        url = base.rstrip("/") + "/" + rel
    else:
        url = base.rstrip("/") + "/"
    if is_dir and not url.endswith("/"):
        url += "/"
    return url


def _base_path_for_url(base_url: str) -> str:
    try:
        p = parse.urlparse(base_url)
        base_path = p.path or ""
    except Exception:  # noqa: BLE001
        base_path = ""
    base_path = base_path.rstrip("/")
    if base_path and not base_path.startswith("/"):
        base_path = "/" + base_path
    return base_path


def _href_to_rel(href: str, base_url: str) -> str:
    href = str(href or "")
    try:
        parsed = parse.urlparse(href)
        path = parsed.path or ""
    except Exception:  # noqa: BLE001
        path = href
    base_path = _base_path_for_url(base_url)
    if base_path and (path == base_path or path.startswith(base_path + "/")):
        path = path[len(base_path) :]
    rel = parse.unquote(path).lstrip("/")
    return rel


def _propfind(url: str, *, username: str | None, password: str | None, depth: str = "1") -> bytes:
    headers = {"Depth": depth}
    auth = _auth_header(username, password)
    if auth:
        headers["Authorization"] = auth
    headers["Content-Type"] = "text/xml"
    body = (
        '<?xml version="1.0" encoding="utf-8"?>'
        '<D:propfind xmlns:D="DAV:">'
        "<D:prop><D:resourcetype/><D:displayname/></D:prop>"
        "</D:propfind>"
    ).encode("utf-8")
    req = request.Request(url, data=body, method="PROPFIND", headers=headers)
    with request.urlopen(req, timeout=15) as resp:
        return resp.read()


def list_children(base_url: str, *, username: str | None, password: str | None, dir_path: str = "") -> list[FileTreeEntry]:
    url = _join_url(base_url, dir_path, is_dir=True)
    xml = _propfind(url, username=username, password=password, depth="1")
    ns = {"d": "DAV:"}
    root = ET.fromstring(xml)
    entries: list[FileTreeEntry] = []
    dir_key = str(dir_path or "").strip().strip("/")
    seen: set[str] = set()
    for resp in root.findall("d:response", ns):
        href = resp.findtext("d:href", default="", namespaces=ns)
        rel = _href_to_rel(href, base_url).rstrip("/")
        if not rel:
            continue
        if rel == dir_key:
            continue
        if rel in seen:
            continue
        seen.add(rel)
        is_dir = resp.find("d:propstat/d:prop/d:resourcetype/d:collection", ns) is not None
        name = rel.split("/")[-1] if rel else rel
        if not name:
            continue
        entries.append(FileTreeEntry(kind="dir" if is_dir else "file", name=name, path=rel))
    return entries


def list_files_by_ext(
    base_url: str,
    *,
    username: str | None,
    password: str | None,
    dir_path: str = "",
    ext: str = "",
) -> list[FileTreeEntry]:
    wanted = str(ext or "").strip().lower()
    if wanted and not wanted.startswith("."):
        wanted = "." + wanted
    if not wanted:
        return []
    entries = list_children(base_url, username=username, password=password, dir_path=dir_path)
    out: list[FileTreeEntry] = []
    for entry in entries:
        if entry.kind != "file":
            continue
        if entry.name.lower().endswith(wanted):
            out.append(entry)
    return out


def download_to_temp(
    base_url: str,
    *,
    username: str | None,
    password: str | None,
    remote_path: str,
    tmp_root: Path,
) -> Path:
    url = _join_url(base_url, remote_path, is_dir=False)
    tmp_root.mkdir(parents=True, exist_ok=True)
    safe = safe_storage_key(remote_path, fallback="webdav")
    dest = tmp_root / safe
    headers: dict[str, str] = {}
    auth = _auth_header(username, password)
    if auth:
        headers["Authorization"] = auth
    req = request.Request(url, method="GET", headers=headers)
    with request.urlopen(req, timeout=30) as resp:
        with dest.open("wb") as f:
            while True:
                chunk = resp.read(1024 * 1024)
                if not chunk:
                    break
                f.write(chunk)
    return dest
