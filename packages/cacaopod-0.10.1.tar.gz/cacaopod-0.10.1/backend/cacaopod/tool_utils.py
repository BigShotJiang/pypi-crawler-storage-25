from __future__ import annotations

import ast
import inspect
import json
import os
import re
import urllib.error
import urllib.request
from time import sleep
from typing import Any, Literal

import numpy as np

from cacaopod.wave import Wave

_TOOL_META_BOOL_RE = re.compile(r"^\s*@(?P<key>[A-Za-z_][A-Za-z0-9_]*)\s*:\s*(?P<value>.+?)\s*$", re.MULTILINE)
_FORMULA_PARAM_RE = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")
_FORMULA_RESERVED = {"x", "y", "np", "numpy", "w", "wave", "mask_noise_level", "Wave"}
_OPENAI_DEFAULT_MODEL = "gpt-5.5"
_OPENAI_REASONING_EFFORT = "medium"


def tool_meta_str(doc: str, key: str) -> str | None:
    wanted = key.strip().lower()
    for m in _TOOL_META_BOOL_RE.finditer(doc or ""):
        if m.group("key").strip().lower() != wanted:
            continue
        raw = m.group("value").strip()
        if raw:
            return raw
    return None


def tool_meta_bool(doc: str, key: str) -> bool | None:
    wanted = key.strip().lower()
    for m in _TOOL_META_BOOL_RE.finditer(doc or ""):
        if m.group("key").strip().lower() != wanted:
            continue
        raw = m.group("value").strip().lower()
        if raw in {"1", "true", "yes", "y", "on"}:
            return True
        if raw in {"0", "false", "no", "n", "off"}:
            return False
    return None


def tool_is_data_process(doc: str) -> bool:
    return bool(tool_meta_bool(doc, "data_process") or tool_meta_bool(doc, "data_process_flag"))


def _tool_tags(doc: str) -> set[str]:
    raw = tool_meta_str(doc, "tags") or ""
    return {t.strip().lower() for t in re.split(r"[,\s]+", raw) if t.strip()}


def tool_is_fitting(doc: str, *, name: str | None = None) -> bool:
    if tool_meta_bool(doc, "fit") or tool_meta_bool(doc, "fitting") or tool_meta_bool(doc, "fit_tool"):
        return True
    tags = _tool_tags(doc)
    if "fit" in tags or "fitting" in tags:
        return True
    if name:
        n = str(name).lower()
        if "fit" in n or "fitting" in n:
            return True
    return False


def _coerce_fit_dict(value: Any, *, prefix: str) -> dict[str, Any]:  # noqa: ANN401
    if value is None:
        return {}
    if isinstance(value, dict):
        return dict(value)
    if isinstance(value, (list, tuple, np.ndarray)):
        arr = np.asarray(value).ravel().tolist()
        return {f"{prefix}{i}": v for i, v in enumerate(arr)}
    try:
        return {"value": value}
    except Exception:  # noqa: BLE001
        return {}


def normalize_fit_result(result: Any) -> tuple[dict[str, Any], dict[str, Any], Any, Any]:  # noqa: ANN401
    coeff: Any = None
    err: Any = None
    fit: Any = None
    metrics: Any = None

    try:
        from cacaopod.tools.fit_utils import FitResult as _FitResult
    except Exception:  # noqa: BLE001
        _FitResult = None

    if _FitResult is not None and isinstance(result, _FitResult):
        coeff = result.coeffs
        err = result.errors
        fit = result.fit
        metrics = result.metrics
    elif all(hasattr(result, attr) for attr in ("coeffs", "errors", "fit", "metrics")):
        coeff = getattr(result, "coeffs", None)
        err = getattr(result, "errors", None)
        fit = getattr(result, "fit", None)
        metrics = getattr(result, "metrics", None)
    elif isinstance(result, dict):
        lower = {str(k).lower(): k for k in result.keys()}
        for key in ["coeff", "coeffs", "coef", "params", "parameters", "popt"]:
            if key in lower:
                coeff = result[lower[key]]
                break
        for key in ["error", "errors", "stderr", "sigma", "uncertainty", "perr"]:
            if key in lower:
                err = result[lower[key]]
                break
        for key in ["fit", "fit_wave", "fitwave", "fitted", "yfit", "wave"]:
            if key in lower:
                fit = result[lower[key]]
                break
        for key in ["metrics", "metric", "stats", "score", "eval", "chi2", "aic", "bic", "rmse"]:
            if key in lower:
                metrics = result[lower[key]]
                break

        if metrics is None:
            # Collect common scalar metrics into a dict if present.
            metric_keys = {"chi2", "aic", "bic", "rmse", "r2", "mse", "mae"}
            found: dict[str, Any] = {}
            for k, v in result.items():
                if str(k).lower() in metric_keys:
                    found[str(k)] = v
            if found:
                metrics = found

    elif isinstance(result, (list, tuple)):
        parts = list(result)
        if len(parts) >= 1:
            coeff = parts[0]
        if len(parts) >= 2:
            err = parts[1]
        if len(parts) >= 3:
            fit = parts[2]
        if len(parts) >= 4:
            metrics = parts[3]
    else:
        fit = result

    coeff_dict = _coerce_fit_dict(coeff, prefix="p")
    err_dict = _coerce_fit_dict(err, prefix="e")
    return coeff_dict, err_dict, fit, metrics


def tool_meta_ndim(doc: str) -> int | None:
    raw = tool_meta_str(doc, "ndim")
    if raw is None:
        return None
    s = raw.strip().lower().replace(" ", "")
    if s in {"*", "any", "all"}:
        return None
    if s.endswith("d"):
        s = s[:-1]
    try:
        n = int(s)
    except Exception:  # noqa: BLE001
        return None
    if n in (1, 2, 3):
        return n
    return None


def validate_formula_fit_inputs(
    formula: str,
    ndim: int,
    params: list[tuple[str, float | None]],
) -> tuple[list[str], list[float]]:
    expr = str(formula or "").strip()
    if not expr:
        raise ValueError("formula is required")
    if ndim not in (1, 2):
        raise ValueError("ndim must be 1 or 2")
    if not params:
        raise ValueError("at least one parameter is required")

    names: list[str] = []
    defaults: list[float] = []
    seen: set[str] = set()
    for raw_name, init in params:
        name = str(raw_name or "").strip()
        if not name:
            raise ValueError("parameter name is required")
        if not _FORMULA_PARAM_RE.match(name):
            raise ValueError(f"invalid parameter name: {name}")
        if name in _FORMULA_RESERVED:
            raise ValueError(f"parameter name reserved: {name}")
        if name in seen:
            raise ValueError(f"duplicate parameter name: {name}")
        seen.add(name)
        names.append(name)
        try:
            val = float(init) if init is not None else 1.0
        except Exception:  # noqa: BLE001
            val = 1.0
        if not np.isfinite(val):
            val = 1.0
        defaults.append(float(val))

    if ndim == 1:
        x = np.linspace(0.1, 1.0, 8)
        env: dict[str, Any] = {"np": np, "x": x}
    else:
        xs = np.linspace(0.1, 1.0, 6)
        ys = np.linspace(0.1, 1.0, 5)
        x, y = np.meshgrid(xs, ys)
        env = {"np": np, "x": x, "y": y}
    for name, val in zip(names, defaults):
        env[name] = val

    try:
        value = eval(expr, {"__builtins__": {}}, env)  # noqa: S307
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"formula evaluation failed: {exc}") from exc

    try:
        arr = np.asarray(value)
        np.broadcast_to(arr, env["x"].shape)
    except Exception as exc:  # noqa: BLE001
        raise ValueError("formula result must be broadcastable to x/y shape") from exc

    return names, defaults


def generate_formula_fit_tool_source(
    name: str,
    ndim: int,
    formula: str,
    params: list[tuple[str, float | None]],
) -> str:
    names, defaults = validate_formula_fit_inputs(formula, ndim, params)
    safe_formula = str(formula).replace('"""', '\\"""')
    params_sig = ", ".join([f"{n}: float = {defaults[i]}" for i, n in enumerate(names)])
    if params_sig:
        params_sig = ", " + params_sig
    params_list = ", ".join([repr(n) for n in names])
    p0_list = ", ".join([f"float({n})" for n in names])
    if len(names) == 1:
        assign_line = f"        {names[0]} = p[0]"
    else:
        assign_line = f"        {', '.join(names)} = p"

    if ndim == 1:
        header = "Formula fit (1D)."
        x_lines = [
            "    x = np.asarray(w.x).ravel()",
            "    y = np.asarray(w.a).ravel()",
            "    mask = _finite_mask(x, y)",
        ]
        fit_target = "y"
    else:
        header = "Formula fit (2D)."
        x_lines = [
            "    x = np.asarray(w.x)",
            "    y = np.asarray(w.y)",
            "    z = np.asarray(w.a)",
            "    mask = _finite_mask(x, y, z)",
        ]
        fit_target = "z"

    doc = [
        f'    """{header}',
        "",
        "    Formula:",
        f"        {safe_formula}",
        "",
        "    Parameters are used as initial guesses.",
        "",
        "    @category: Fit",
        "    @fit: true",
        f"    @ndim: {ndim}",
        "    @tags: fit, formula",
        '    """',
    ]

    body = [
        "from __future__ import annotations",
        "",
        "import numpy as np",
        "",
        "from cacaopod.wave import Wave",
        "from cacaopod.tools.fit_utils import FitResult, _errors_from_cov, _finite_mask, _metrics, fit_with_mask_noise, _gauss_newton",
        "",
        f"def {name}(w: Wave{params_sig}, mask_noise_level: float | None = None) -> FitResult:",
        *doc,
        *x_lines,
        f"    p0 = np.array([{p0_list}], dtype=float)",
        "",
        "    def model(p: np.ndarray) -> np.ndarray:",
        assign_line,
        f"        return {safe_formula}",
        "",
        "    def _fit(m: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:",
        f"        return _gauss_newton(model, {fit_target}, m, p0, max_iter=80)",
        "",
        f"    params, yfit, cov, mask = fit_with_mask_noise(_fit, {fit_target}, mask, mask_noise_level)",
        f"    names = [{params_list}]",
        "    coeffs = {name: float(params[i]) for i, name in enumerate(names)}",
        "    errs = _errors_from_cov(cov, names)",
        f"    fit_wave = w.copy(data=np.asarray(yfit).reshape(w.shape))",
        f"    metrics = _metrics({fit_target}, yfit, mask)",
        "    return FitResult(coeffs=coeffs, errors=errs, fit=fit_wave, metrics=metrics)",
        "",
    ]
    return "\n".join(body)


def _extract_source_context_with_function(source: str, *, function_name: str) -> str:
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        raise ValueError(f"invalid Python source: {exc}") from exc

    lines = source.splitlines(True)
    blocks: list[str] = []
    found = False

    for node in tree.body:
        include = isinstance(node, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef))
        if not include:
            continue
        if isinstance(node, ast.ImportFrom) and node.module == "__future__":
            if any(getattr(alias, "name", "") == "annotations" for alias in node.names):
                continue
        if isinstance(node, ast.FunctionDef) and node.name == function_name:
            found = True

        start = int(getattr(node, "lineno", 1) or 1)
        if getattr(node, "decorator_list", None):
            for dec in node.decorator_list:  # type: ignore[attr-defined]
                dec_line = getattr(dec, "lineno", None)
                if dec_line is not None:
                    start = min(start, int(dec_line))
        end = getattr(node, "end_lineno", None)
        if not end:
            continue
        blocks.append("".join(lines[start - 1 : int(end)]).rstrip() + "\n")

    if not found:
        raise ValueError(f"function {function_name!r} not found")
    return "\n".join(blocks).strip() + "\n"


def _first_function_name(source: str) -> str | None:
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None
    for node in tree.body:
        if isinstance(node, ast.FunctionDef):
            return str(node.name)
    return None


def validate_function_fit_inputs(
    model_source: str,
    function_name: str,
    ndim: int,
    params: list[tuple[str, float | None]],
) -> tuple[str, str, list[str], list[float | None]]:
    source = str(model_source or "").strip()
    if not source:
        raise ValueError("function source is required")
    if ndim not in (1, 2):
        raise ValueError("ndim must be 1 or 2")

    fname = str(function_name or "").strip() or (_first_function_name(source) or "")
    if not fname or not _FORMULA_PARAM_RE.match(fname):
        raise ValueError("function_name must be a valid Python identifier")

    context = _extract_source_context_with_function(source, function_name=fname)
    mod_globals: dict[str, Any] = {"np": np, "numpy": np}
    try:
        exec(compile(context, "<function-fit-validate>", "exec", dont_inherit=True), mod_globals)  # noqa: S102 - local trusted fit code
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"function source failed to load: {exc}") from exc

    fn = mod_globals.get(fname)
    if not callable(fn):
        raise ValueError(f"function {fname!r} is not callable")

    sig = inspect.signature(fn)
    sig_params = list(sig.parameters.values())
    independent_count = 1 if ndim == 1 else 2
    if len(sig_params) <= independent_count:
        raise ValueError("fit function must have at least one fit parameter")
    for p in sig_params:
        if p.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
            raise ValueError("fit function must not use *args or **kwargs")
    expected = ["x"] if ndim == 1 else ["x", "y"]
    for i, want in enumerate(expected):
        got = sig_params[i].name
        if got != want:
            raise ValueError(f"fit function parameter {i + 1} must be {want!r} (got {got!r})")

    names = [p.name for p in sig_params[independent_count:]]
    seen: set[str] = set()
    for name in names:
        if not _FORMULA_PARAM_RE.match(name):
            raise ValueError(f"invalid parameter name: {name}")
        if name in _FORMULA_RESERVED:
            raise ValueError(f"parameter name reserved: {name}")
        if name in seen:
            raise ValueError(f"duplicate parameter name: {name}")
        seen.add(name)

    request_inits: dict[str, float | None] = {}
    for raw_name, init in params:
        pname = str(raw_name or "").strip()
        if not pname:
            continue
        if pname not in names:
            raise ValueError(f"unknown fit parameter: {pname}")
        if init is None:
            request_inits[pname] = None
            continue
        try:
            val = float(init)
        except Exception as exc:  # noqa: BLE001
            raise ValueError(f"invalid initial value for {pname}") from exc
        request_inits[pname] = val if np.isfinite(val) else None

    defaults: list[float | None] = []
    for p in sig_params[independent_count:]:
        if p.name in request_inits:
            defaults.append(request_inits[p.name])
        elif p.default is not inspect._empty:
            try:
                val = float(p.default)
            except Exception:
                val = None
            defaults.append(val if val is not None and np.isfinite(val) else None)
        else:
            defaults.append(None)

    if ndim == 1:
        x = np.linspace(0.1, 1.0, 8)
        call_args: list[Any] = [x]
    else:
        xs = np.linspace(0.1, 1.0, 6)
        ys = np.linspace(0.1, 1.0, 5)
        x, y = np.meshgrid(xs, ys)
        call_args = [x, y]
    call_args.extend(1.0 if v is None else float(v) for v in defaults)

    try:
        value = fn(*call_args)
        arr = np.asarray(value)
        np.broadcast_to(arr, call_args[0].shape)
    except Exception as exc:  # noqa: BLE001
        raise ValueError(f"function evaluation failed or returned incompatible shape: {exc}") from exc

    return fname, context, names, defaults


def generate_function_fit_tool_source(
    name: str,
    ndim: int,
    model_source: str,
    function_name: str,
    params: list[tuple[str, float | None]],
) -> str:
    fname, context, names, defaults = validate_function_fit_inputs(model_source, function_name, ndim, params)
    if fname == name:
        raise ValueError("fit function name must differ from tool name")

    params_sig_parts = [f"{n}: float | None = {defaults[i] if defaults[i] is not None else 'None'}" for i, n in enumerate(names)]
    params_sig = ", " + ", ".join(params_sig_parts) if params_sig_parts else ""
    params_list = ", ".join([repr(n) for n in names])
    user_values = ", ".join([n for n in names])
    if len(names) == 1:
        assign_line = f"        {names[0]} = p[0]"
    else:
        assign_line = f"        {', '.join(names)} = p"

    if ndim == 1:
        header = "Python function fit (1D)."
        x_lines = [
            "    x = np.asarray(w.x).ravel()",
            "    target = np.asarray(w.a).ravel()",
            "    mask = _finite_mask(x, target)",
            f"    auto = estimate_initial_params_1d([{params_list}], x, target, mask)",
        ]
        model_call = f"{fname}(x, {', '.join(names)})"
    else:
        header = "Python function fit (2D)."
        x_lines = [
            "    x = np.asarray(w.x)",
            "    y = np.asarray(w.y)",
            "    target = np.asarray(w.a)",
            "    mask = _finite_mask(x, y, target)",
            f"    auto = estimate_initial_params_2d([{params_list}], x, y, target, mask)",
        ]
        model_call = f"{fname}(x, y, {', '.join(names)})"

    doc = [
        f'    """{header}',
        "",
        f"    Model function: {fname}",
        "    Blank parameter values use automatic initial guesses based on parameter names.",
        "",
        "    @category: Fit",
        "    @fit: true",
        f"    @ndim: {ndim}",
        "    @tags: fit, python_function, auto_initial_guess",
        '    """',
    ]

    body = [
        "from __future__ import annotations",
        "",
        "import numpy as np",
        "",
        "from cacaopod.wave import Wave",
        "from cacaopod.tools.fit_utils import (",
        "    FitResult,",
        "    _errors_from_cov,",
        "    _finite_mask,",
        "    _metrics,",
        "    _gauss_newton,",
        "    estimate_initial_params_1d,",
        "    estimate_initial_params_2d,",
        "    fit_with_mask_noise,",
        ")",
        "",
        context.rstrip(),
        "",
        f"def {name}(w: Wave{params_sig}, mask_noise_level: float | None = None) -> FitResult:",
        *doc,
        *x_lines,
        f"    user_values = [{user_values}]",
        f"    names = [{params_list}]",
        "    p0 = np.array([auto.get(param_name, 1.0) if value is None else float(value) for param_name, value in zip(names, user_values)], dtype=float)",
        "",
        "    def _model_eval(p: np.ndarray) -> np.ndarray:",
        assign_line,
        f"        return np.asarray({model_call}, dtype=float)",
        "",
        "    def _fit(m: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:",
        "        return _gauss_newton(_model_eval, target, m, p0, max_iter=100)",
        "",
        "    params, yfit, cov, mask = fit_with_mask_noise(_fit, target, mask, mask_noise_level)",
        "    coeffs = {param_name: float(params[i]) for i, param_name in enumerate(names)}",
        "    errs = _errors_from_cov(cov, names)",
        "    fit_wave = w.copy(data=np.asarray(yfit).reshape(w.shape))",
        "    metrics = _metrics(target.ravel(), np.asarray(yfit).ravel(), mask.ravel())",
        "    return FitResult(coeffs=coeffs, errors=errs, fit=fit_wave, metrics=metrics)",
        "",
    ]
    return "\n".join(body)


def apply_result_to_wave_inplace(target: Wave, result: Any) -> None:  # noqa: ANN401
    # Ensure we never accidentally overwrite through a view of an "original" Wave.
    if getattr(target, "_parent_wave", None) is not None:
        target._detach_from_parent()
    elif getattr(target, "_original", None) is not None:
        target._detach_from_original()

    if isinstance(result, Wave):
        arr = np.asarray(result)
        if arr.ndim not in (1, 2, 3):
            raise ValueError(f"only 1D/2D/3D arrays are supported (got ndim={arr.ndim})")
        target._a_raw = np.asarray(arr)
        target._offset_dim = result._offset_dim
        target._delta_dim = result._delta_dim
        target._explicit_coords_dim = list(result._explicit_coords_dim)
        target.update()
        return

    arr = np.asarray(result)
    if arr.ndim not in (1, 2, 3):
        raise ValueError(f"only 1D/2D/3D arrays are supported (got ndim={arr.ndim})")

    if target.ndim != int(arr.ndim):
        # If the tool changes dimensionality, require it to return a Wave so axis info
        # (offset/delta/explicit coords) can be adjusted intentionally.
        raise ValueError("data_process tool must return a Wave when changing ndim")

    target._a_raw = np.asarray(arr)
    if any(coords is not None and np.asarray(coords).shape != arr.shape for coords in target._explicit_coords_dim):
        target._explicit_coords_dim = [None] * int(arr.ndim)
    target.update()


def extract_function_block(source: str, *, name: str) -> str:
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        raise ValueError(f"invalid Python source: {exc}") from exc

    lines = source.splitlines(True)
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if node.name != name:
            continue
        start = int(getattr(node, "lineno", 1) or 1)
        if getattr(node, "decorator_list", None):
            for dec in node.decorator_list:
                dec_line = getattr(dec, "lineno", None)
                if dec_line is not None:
                    start = min(start, int(dec_line))
        end = getattr(node, "end_lineno", None)
        if not end:
            break
        return "".join(lines[start - 1 : int(end)]).rstrip() + "\n"

    raise ValueError(f"function {name!r} not found in source")


def extract_tool_docstring_context(source: str, *, name: str) -> str:
    """Extract a minimal, stable snippet for docstring generation.

    Includes top-level imports, class definitions, and the target function. Excludes
    ad-hoc top-level test code and strips `from __future__ import annotations` to
    keep tool files consistent.
    """

    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        raise ValueError(f"invalid Python source: {exc}") from exc

    lines = source.splitlines(True)
    blocks: list[str] = []
    found_func = False

    for node in tree.body:
        include = False
        if isinstance(node, ast.Import):
            include = True
        elif isinstance(node, ast.ImportFrom):
            if node.module == "__future__" and any(getattr(alias, "name", "") == "annotations" for alias in node.names):
                include = False
            else:
                include = True
        elif isinstance(node, ast.ClassDef):
            include = True
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            include = True
            found_func = True

        if not include:
            continue

        start = int(getattr(node, "lineno", 1) or 1)
        if getattr(node, "decorator_list", None):
            for dec in node.decorator_list:  # type: ignore[attr-defined]
                dec_line = getattr(dec, "lineno", None)
                if dec_line is not None:
                    start = min(start, int(dec_line))

        end = getattr(node, "end_lineno", None)
        if not end:
            continue

        block = "".join(lines[start - 1 : int(end)]).rstrip() + "\n"
        blocks.append(block)

    if not found_func:
        raise ValueError(f"function {name!r} not found in source")

    out = "".join(blocks).strip()
    if not out:
        raise ValueError("failed to extract tool context")
    return out + "\n"


def _openai_api_key() -> str | None:
    return os.environ.get("CACAOPOD_OPENAI_API_KEY") or os.environ.get("OPENAI_API_KEY")


def _openai_api_base() -> str:
    return (os.environ.get("CACAOPOD_OPENAI_API_BASE") or os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com").rstrip("/")


def _openai_model_default() -> str:
    return os.environ.get("CACAOPOD_OPENAI_MODEL") or os.environ.get("OPENAI_MODEL") or _OPENAI_DEFAULT_MODEL


def _openai_reasoning() -> dict[str, str]:
    return {"effort": _OPENAI_REASONING_EFFORT}


def _extract_openai_output_text(obj: Any) -> str:  # noqa: ANN401
    if isinstance(obj, dict):
        maybe = obj.get("output_text")
        if isinstance(maybe, str) and maybe.strip():
            return maybe.strip()

        output = obj.get("output")
        if isinstance(output, list):
            chunks: list[str] = []
            for item in output:
                if not isinstance(item, dict):
                    continue
                content = item.get("content")
                if not isinstance(content, list):
                    continue
                for part in content:
                    if not isinstance(part, dict):
                        continue
                    if part.get("type") != "output_text":
                        continue
                    text = part.get("text")
                    if isinstance(text, str) and text.strip():
                        chunks.append(text)
            if chunks:
                return "\n".join(chunks).strip()

        # Fallback for chat-completions style responses (if user uses a proxy)
        choices = obj.get("choices")
        if isinstance(choices, list) and choices:
            first = choices[0]
            if isinstance(first, dict):
                msg = first.get("message")
                if isinstance(msg, dict):
                    content = msg.get("content")
                    if isinstance(content, str) and content.strip():
                        return content.strip()

    raise ValueError("failed to parse OpenAI response text")


def suggest_docstring_via_openai(
    source: str,
    *,
    name: str,
    language: Literal["ja", "en"],
    model: str | None,
) -> str:
    key = _openai_api_key()
    if not key:
        raise ValueError("OpenAI API key is not configured (set CACAOPOD_OPENAI_API_KEY or OPENAI_API_KEY).")

    tool_src = extract_tool_docstring_context(source, name=name)
    sys = "You write clear Python docstrings for tool functions."
    if language == "ja":
        user = (
            "次のPython関数（Cacaopodのツール関数）に対して、読みやすいdocstring本文を日本語で作成してください。\n"
            "- 出力はdocstring本文のみ（クォート類は出さない）\n"
            "- 1行サマリ→空行→詳細（必要なら）→Args/Returns/Raises を含める\n"
            "- @category/@tags/@data_process などのメタ行は含めない\n\n"
            "- 戻り値がこのツール内で定義された独自の `@dataclass` を含む場合、Returns に dataclass の要素（フィールド名と型）を列挙する\n\n"
            "```python\n"
            f"{tool_src}\n"
            "```"
        )
    else:
        user = (
            "Write a clear docstring body for the following Python function (Cacaopod tool function).\n"
            "- Output ONLY the docstring body (no quotes)\n"
            "- Include: 1-line summary, blank line, details (optional), Args/Returns/Raises\n"
            "- Do NOT include @category/@tags/@data_process meta lines\n\n"
            "- If the return value includes custom `@dataclass` types defined in this tool, enumerate their fields (name and type) in Returns\n\n"
            "```python\n"
            f"{tool_src}\n"
            "```"
        )

    payload = {
        "model": model or _openai_model_default(),
        "reasoning": _openai_reasoning(),
        "input": [
            {"role": "system", "content": [{"type": "input_text", "text": sys}]},
            {"role": "user", "content": [{"type": "input_text", "text": user}]},
        ],
    }

    base = _openai_api_base()
    url = f"{base}/v1/responses"
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "authorization": f"Bearer {key}",
            "content-type": "application/json",
        },
        method="POST",
    )

    try:
        with urllib.request.urlopen(req, timeout=45) as resp:  # noqa: S310 - trusted local usage
            raw = resp.read().decode("utf-8", errors="replace")
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", errors="replace")
        raise ValueError(f"OpenAI API error: {exc.code} {exc.reason}: {detail}") from exc
    except urllib.error.URLError as exc:
        raise ValueError(f"OpenAI API connection error: {exc}") from exc

    data = json.loads(raw)
    text = _extract_openai_output_text(data)
    text = text.strip()
    text = re.sub(r"^\\s*(?:r|u|ru|ur|f|fr|rf)?(\"\"\"|''')\\s*", "", text, flags=re.IGNORECASE)
    text = re.sub(r"\\s*(\"\"\"|''')\\s*$", "", text)
    return text.strip()


_VALID_TOOL_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _normalize_openai_code(text: str) -> str:
    s = str(text or "").strip()
    if not s:
        return ""
    # Strip markdown fences if the model ignored instructions.
    s = re.sub(r"^\\s*```(?:python)?\\s*\\n", "", s, flags=re.IGNORECASE)
    s = re.sub(r"\\n```\\s*$", "", s)
    return s.strip() + "\n"


def _tool_gpt_reference_text(language: Literal["ja", "en"]) -> str:
    if language == "en":
        return (
            "Cacaopod quick reference (available in the console / tool runtime):\n"
            "\n"
            "Globals:\n"
            "- board: Board (selected pod is the active target)\n"
            "- wm: WaveManager (persistent named Waves)\n"
            "- dm: DataManager (persistent DataFrame/dict/scalars)\n"
            "- fm: FileManager (path localization for local/WebDAV; fm.source(path) restores original path)\n"
            "- toolbox: Toolbox (tools registry; can call other tools)\n"
            "- np: numpy\n"
            "\n"
            "Board:\n"
            "- board.wave -> Wave  (active Wave in selected pod)\n"
            "- board.waves -> list[Wave]\n"
            "- board.show(value, name=None): show Wave/ndarray (or list) in selected pod; optional pod name\n"
            "- board.add(waves=None, name=None) -> Pod: add a new pod; optional pod name\n"
            "- board.name: selected pod name (get/set)\n"
            "- board.append(value): append Wave(s) to selected pod (same ndim required)\n"
            "\n"
            "Wave:\n"
            "- Wave(a, offset=0, delta=1, name=None, overwrite=False, x=None, y=None, z=None)  (ndim 1..3)\n"
            "- w.a -> numpy-like array view; np.asarray(w) -> ndarray\n"
            "- w.ndim / w.shape / w.dtype\n"
            "- w.offset / w.delta: tuples (x,y,z order)\n"
            "- w.x / w.y / w.z: coordinate grids (shape == w.shape)\n"
            "- w.p / w.q / w.r: index grids\n"
            "- w.copy(data=None, name=None, overwrite=False) -> Wave: copies axis metadata; optional replacement data\n"
            "- w.overwrite(other): overwrite numeric data + axis metadata, keep uid/name\n"
            "- w.name: set to track in WaveManager (no '/', '\\\\', '@')\n"
            "- w.description: free text\n"
            "- w.userdata: dict-like; mutation touches wave\n"
            "\n"
            "WaveManager (wm):\n"
            "- wm['name'] -> Wave in current board\n"
            "- wm['name@board_name'] -> Wave in another board\n"
            "- wm['pattern*'] -> list[Wave] (wildcard; current board)\n"
            "- wm['pattern*@board*'] -> list[Wave] (wildcard with board selection)\n"
            "- wm.match('pattern') -> dict[name, Wave]\n"
            "- wm.list() -> list[(name, uid)]\n"
            "- wm.delete('name')\n"
            "\n"
            "DataManager (dm):\n"
            "- dm['name'] -> stored item\n"
            "- dm['name'] = df/dict/scalar\n"
            "- dm.save('name') if you mutated stored objects in-place (e.g., DataFrame)\n"
            "- dm.match('pattern') / dm.list() / dm.delete('name')\n"
            "\n"
            "Toolbox (toolbox):\n"
            "- toolbox['my_tool'](wave): auto-selects ndim variant by the Wave passed\n"
            "- toolbox.get('my_tool', ndim=2): explicit variant selection\n"
            "\n"
            "Fitting tools:\n"
            "- Mark docstring with `@fit: true`\n"
            "- Return (coeffs: dict, errors: dict, fit: Wave/ndarray, metrics: dict/number)\n"
        )
    return (
        "Cacaopod クイックリファレンス（コンソール / Tool 実行環境で利用可）:\n"
        "\n"
        "グローバル変数:\n"
        "- board: Board（選択中のPodが対象）\n"
        "- wm: WaveManager（名前付きWaveの永続管理）\n"
        "- dm: DataManager（DataFrame/dict/スカラーの永続管理）\n"
        "- fm: FileManager（ローカル/WebDAVのパスをローカル化。fm.source(path)で元のパス復元）\n"
        "- toolbox: Toolbox（他のToolを呼び出せる）\n"
        "- np: numpy\n"
        "\n"
        "Board:\n"
        "- board.wave -> Wave（選択中PodのアクティブWave）\n"
        "- board.waves -> list[Wave]\n"
        "- board.show(value, name=None): 選択中Podに Wave/ndarray（またはリスト）を表示（nameでPod名も指定可）\n"
        "- board.add(waves=None, name=None) -> Pod: 新しいPodを追加（nameでPod名）\n"
        "- board.name: 選択中Podの名前（取得/変更）\n"
        "- board.append(value): 選択中PodへWaveを追加（ndimは揃える必要あり）\n"
        "\n"
        "Wave:\n"
        "- Wave(a, offset=0, delta=1, name=None, overwrite=False, x=None, y=None, z=None)（ndim 1..3）\n"
        "- w.a -> numpy配列ライク; np.asarray(w) -> ndarray\n"
        "- w.ndim / w.shape / w.dtype\n"
        "- w.offset / w.delta: tuple（x,y,z順）\n"
        "- w.x / w.y / w.z: 座標グリッド（shape == w.shape）\n"
        "- w.p / w.q / w.r: インデックスグリッド\n"
        "- w.copy(data=None, name=None, overwrite=False) -> Wave: 軸情報をコピー。data指定で数値配列のみ置換\n"
        "- w.overwrite(other): uid/nameは維持しつつ数値配列と軸情報を上書き\n"
        "- w.name: 代入でWaveManagerへ登録（'/', '\\\\', '@' は不可）\n"
        "- w.description: 任意文字列\n"
        "- w.userdata: dictライク（更新でWaveがtouchされる）\n"
        "\n"
        "WaveManager（wm）:\n"
        "- wm['name'] -> 現在ボードのWave\n"
        "- wm['name@board_name'] -> 他ボードのWave\n"
        "- wm['pattern*'] -> list[Wave]（ワイルドカード; 現在ボード）\n"
        "- wm['pattern*@board*'] -> list[Wave]（ワイルドカード + ボード選択）\n"
        "- wm.match('pattern') -> dict[name, Wave]\n"
        "- wm.list() -> list[(name, uid)]\n"
        "- wm.delete('name')\n"
        "\n"
        "DataManager（dm）:\n"
        "- dm['name'] -> 保存データ\n"
        "- dm['name'] = df/dict/スカラー\n"
        "- DataFrameなどをin-placeで変更したら dm.save('name')\n"
        "- dm.match('pattern') / dm.list() / dm.delete('name')\n"
        "\n"
        "Toolbox（toolbox）:\n"
        "- toolbox['my_tool'](wave): Waveのndimに応じて適切なvariantを自動選択\n"
        "- toolbox.get('my_tool', ndim=2): 明示的にvariant選択\n"
        "\n"
        "フィッティングTool:\n"
        "- docstringに `@fit: true`\n"
        "- 戻り値は (係数dict, エラーdict, フィットWave/ndarray, 評価値dict/数値)\n"
    )


def generate_tool_code_via_openai(
    *,
    name: str,
    request: str,
    console_code: str,
    error: str | None = None,
    fit_tool: bool = False,
    chat_messages: list[dict[str, Any]] | None = None,
    context_wave: dict[str, Any] | None = None,  # noqa: ANN401
    language: Literal["ja", "en"] = "ja",
    model: str | None = None,
) -> str:
    key = _openai_api_key()
    if not key:
        raise ValueError("OpenAI API key is not configured (set CACAOPOD_OPENAI_API_KEY or OPENAI_API_KEY).")

    tool_name = str(name or "").strip()
    if not tool_name or not _VALID_TOOL_NAME.match(tool_name):
        raise ValueError("name must be a valid Python identifier (tool function name).")

    user_req = str(request or "").strip()
    if not user_req and not str(console_code or "").strip():
        raise ValueError("request or console_code must be non-empty.")

    ref_text = _tool_gpt_reference_text(language)

    def _truncate(s: str, *, max_chars: int) -> str:
        t = str(s or "")
        if len(t) <= max_chars:
            return t
        return t[: max(0, max_chars - 40)] + "\n...(truncated)..."

    def _format_chat_history(msgs: list[dict[str, Any]] | None) -> str:
        if not isinstance(msgs, list) or not msgs:
            return ""
        keep = [m for m in msgs if isinstance(m, dict)]
        if not keep:
            return ""
        keep = keep[-12:]
        lines: list[str] = []
        for m in keep:
            role = str(m.get("role") or "").strip().lower()
            if role != "user":
                continue
            content = str(m.get("content") or "").strip()
            if not content:
                continue
            content = _truncate(content, max_chars=2000)
            lines.append(f"USER: {content}")
        return "\n".join(lines).strip()

    wave_ctx_lines: list[str] = []
    if isinstance(context_wave, dict):
        for k in ["name", "description", "ndim", "dtype", "shape"]:
            v = context_wave.get(k)
            if v is None:
                continue
            wave_ctx_lines.append(f"- {k}: {v}")
    wave_ctx = "\n".join(wave_ctx_lines).strip()

    sys = "You write small, correct Python tool code for Cacaopod."
    if language == "ja":
        user = (
            "Cacaopod用のToolコードを作成/修正してください。\n"
            "\n"
            "要件:\n"
            f"- 出力は **有効なPythonソースのみ**（markdown禁止、コードフェンス禁止）\n"
            f"- トップレベルに `{tool_name}` という名前の関数を必ず定義する\n"
            "- インデントはスペース2つ\n"
            "- `from __future__ import annotations` は追加しない\n"
            "- すべての引数に **型注釈** を付ける（必須）。戻り値にも可能なら `-> ...` を付ける\n"
            "- 引数設計: UI入力は数値・テキスト（+必要ならbool）のみ。入力項目は最小限。\n"
            "- Waveを使う場合は `wave: Wave` を受け取り、他は基本 keyword-only（`*`）にする\n"
            "- 解析系: float/dict/軽量な@dataclass等を返して良い（printでも可）\n"
            "- データ処理系: 原則としてin-placeでw.aを書き換えず、`np.ndarray` もしくは `Wave` を return する\n"
            "  - `np.ndarray` を返す場合、ndimは入力Waveと同じにする\n"
            "  - 軸情報も調整するなら `Wave` を返す\n"
            "- Docstringの先頭にメタ行を書いてよい: `@category: ...`, `@ndim: ...`, `@tags: ...`, `@data_process: true`, `@fit: true`\n"
            "- 実行確認用のテストコードを末尾に含める（トップレベルで実行される形）。対象Waveは `board.wave` を使う。\n"
            "\n"
        )
    else:
        user = (
            "Create or edit Cacaopod tool code.\n"
            "\n"
            "Requirements:\n"
            f"- Output ONLY valid Python source (no markdown, no code fences)\n"
            f"- Define a top-level function named `{tool_name}`\n"
            "- Use 2-space indentation\n"
            "- Do NOT add: from __future__ import annotations\n"
            "- Add type annotations for ALL parameters (required). Add a return annotation if possible.\n"
            "- Arg design: UI inputs should be numbers/text (and optionally bool) only, keep them minimal.\n"
            "- If using Wave, accept `wave: Wave` and keep other args keyword-only (`*`).\n"
            "- Analysis tools may return float/dict/light @dataclass (printing is also ok).\n"
            "- Data-processing tools should return `np.ndarray` or `Wave` (avoid in-place edits).\n"
            "  - If returning `np.ndarray`, keep ndim same as input.\n"
            "  - Return `Wave` if axis metadata must change.\n"
            "- You may include meta lines at the top of the docstring: @category/@ndim/@tags/@data_process/@fit\n"
            "- Include runnable test code at the end (top-level). Use `board.wave` as the target.\n"
            "\n"
        )

    if fit_tool:
        if language == "ja":
            user += (
                "フィッティングTool:\n"
                "- 係数dict・誤差dict・フィットWave/ndarray・評価値（dict/数値）を返す\n"
                "- 初期値は可能なら不要にし、引数デフォルトで動作するようにする\n"
                "\n"
            )
        else:
            user += (
                "Fitting tool:\n"
                "- Return (coeffs dict, errors dict, fit Wave/ndarray, metrics dict/number)\n"
                "- Avoid required initial guesses; defaults should work\n"
                "\n"
            )

    if user_req:
        user += f"User request:\n{user_req}\n\n"
    if wave_ctx:
        user += f"Selected wave (board.wave) summary:\n{wave_ctx}\n\n"

    chat_hist = _format_chat_history(chat_messages)
    if chat_hist:
        user += "Chat history (recent):\n" + chat_hist + "\n\n"

    user += "Reference:\n" + ref_text + "\n"

    prev = str(console_code or "").rstrip()
    if prev:
        user += "\nCurrent console code:\n```python\n" + prev + "\n```\n"

    err_text = str(error or "").strip()
    if err_text:
        user += "\nThe last execution failed with this error:\n" + err_text + "\n\nPlease fix the code and output the full updated Python source.\n"

    payload = {
        "model": model or _openai_model_default(),
        "reasoning": _openai_reasoning(),
        "input": [
            {"role": "system", "content": [{"type": "input_text", "text": sys}]},
            {"role": "user", "content": [{"type": "input_text", "text": user}]},
        ],
    }

    base = _openai_api_base()
    url = f"{base}/v1/responses"
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"authorization": f"Bearer {key}", "content-type": "application/json"},
        method="POST",
    )

    last_err: Exception | None = None
    raw = ""
    for attempt in range(2):
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:  # noqa: S310 - trusted local usage
                raw = resp.read().decode("utf-8", errors="replace")
            last_err = None
            break
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            msg = f"OpenAI API error: {exc.code} {exc.reason}: {detail}"
            if attempt == 0 and exc.code in {429, 500, 502, 503, 504}:
                last_err = ValueError(msg)
                sleep(0.8)
                continue
            raise ValueError(msg) from exc
        except TimeoutError as exc:
            last_err = exc
            if attempt == 0:
                sleep(0.8)
                continue
            raise ValueError(f"OpenAI API timeout: {exc}") from exc
        except urllib.error.URLError as exc:
            last_err = exc
            if attempt == 0:
                sleep(0.8)
                continue
            raise ValueError(f"OpenAI API connection error: {exc}") from exc

    if last_err is not None:  # pragma: no cover
        raise ValueError(f"OpenAI API call failed: {last_err}") from last_err

    data = json.loads(raw)
    text = _extract_openai_output_text(data)
    normalized = _normalize_openai_code(text)
    if not normalized.strip():
        raise ValueError("OpenAI returned empty response")
    return normalized
