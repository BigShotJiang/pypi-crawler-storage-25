from __future__ import annotations

import numpy as np

from cacaopod.wave import Wave
from cacaopod.tools.fit_utils import FitResult, _errors_from_cov, _finite_mask, _metrics, fit_polynomial_2d


def poly_fit(w: Wave, degree: int = 2, mask_noise_level: float | None = None) -> FitResult:
    """
    Polynomial surface fit (2D).

    @category: Fit
    @fit: true
    @ndim: 2
    @tags: polynomial, fit
    """

    x = np.asarray(w.x)
    y = np.asarray(w.y)
    z = np.asarray(w.a)
    mask = _finite_mask(x, y, z)

    coeffs, yfit, cov, mask, terms = fit_polynomial_2d(x.ravel(), y.ravel(), z.ravel(), degree=degree, mask=mask.ravel(), mask_noise_level=mask_noise_level)

    coeff_dict = {f"c{i}_{j}": float(coeffs[k]) for k, (i, j) in enumerate(terms)}
    errs = _errors_from_cov(cov, list(coeff_dict.keys()))
    fit_wave = w.copy(data=yfit.reshape(w.shape))
    metrics = _metrics(z.ravel(), yfit, mask.ravel())
    return FitResult(coeffs=coeff_dict, errors=errs, fit=fit_wave, metrics=metrics)
