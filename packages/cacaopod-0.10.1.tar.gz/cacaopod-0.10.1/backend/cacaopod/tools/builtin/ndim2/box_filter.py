from __future__ import annotations

from typing import Literal

import numpy as np

from cacaopod.tools.filter_utils import uniform_filter_ignore_nan, validate_positive_int
from cacaopod.wave import Wave


def box_filter(
    w: Wave,
    size_x: int = 3,
    size_y: int = 3,
    mode: Literal["reflect", "nearest", "mirror", "wrap", "constant"] = "reflect",
    cval: float = 0.0,
    preserve_nan: bool = True,
) -> Wave:
    """
    Box smoothing filter (2D). `size_x`/`size_y` are window lengths in pixels.

    @category: Processing
    @data_process: true
    @ndim: 2
    @tags: box, filter, smooth, smoothing, moving_average
    """

    size = (
        validate_positive_int("size_y", size_y),
        validate_positive_int("size_x", size_x),
    )
    filtered = uniform_filter_ignore_nan(
        np.asarray(w.a),
        size=size,
        mode=mode,
        cval=cval,
        preserve_nan=preserve_nan,
    )
    return w.copy(data=filtered)
