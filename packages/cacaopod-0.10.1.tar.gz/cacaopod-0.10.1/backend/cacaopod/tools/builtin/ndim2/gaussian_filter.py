from __future__ import annotations

from typing import Literal

import numpy as np

from cacaopod.tools.filter_utils import gaussian_filter_ignore_nan, validate_nonnegative_float
from cacaopod.wave import Wave


def gaussian_filter(
    w: Wave,
    sigma_x: float = 1.0,
    sigma_y: float = 1.0,
    mode: Literal["reflect", "nearest", "mirror", "wrap", "constant"] = "reflect",
    cval: float = 0.0,
    truncate: float = 4.0,
    preserve_nan: bool = True,
) -> Wave:
    """
    Gaussian smoothing filter (2D). `sigma_x`/`sigma_y` are in pixels along each axis.

    @category: Processing
    @data_process: true
    @ndim: 2
    @tags: gaussian, filter, smooth, smoothing
    """

    sigma = (
        validate_nonnegative_float("sigma_y", sigma_y),
        validate_nonnegative_float("sigma_x", sigma_x),
    )
    filtered = gaussian_filter_ignore_nan(
        np.asarray(w.a),
        sigma=sigma,
        mode=mode,
        cval=cval,
        truncate=truncate,
        preserve_nan=preserve_nan,
    )
    return w.copy(data=filtered)
