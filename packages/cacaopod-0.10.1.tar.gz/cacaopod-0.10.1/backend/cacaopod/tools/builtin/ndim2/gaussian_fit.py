from __future__ import annotations

import numpy as np

from cacaopod.wave import Wave
from cacaopod.tools.fit_utils import FitResult, _errors_from_cov, _finite_mask, _metrics, fit_gaussian_2d


def gaussian_fit(w: Wave, mask_noise_level: float | None = None) -> FitResult:
    """
    Gaussian fit (2D).

    @category: Fit
    @fit: true
    @ndim: 2
    @tags: gaussian, fit
    """

    x = np.asarray(w.x)
    y = np.asarray(w.y)
    z = np.asarray(w.a)
    mask = _finite_mask(x, y, z)

    params, yfit, cov, mask = fit_gaussian_2d(x, y, z, mask=mask, mask_noise_level=mask_noise_level)
    names = ["amp", "x0", "y0", "sigma_x", "sigma_y", "offset"]
    coeffs = {name: float(params[i]) for i, name in enumerate(names)}
    errs = _errors_from_cov(cov, names)
    fit_wave = w.copy(data=yfit.reshape(w.shape))
    metrics = _metrics(z.ravel(), np.asarray(yfit).ravel(), mask.ravel())
    return FitResult(coeffs=coeffs, errors=errs, fit=fit_wave, metrics=metrics)
