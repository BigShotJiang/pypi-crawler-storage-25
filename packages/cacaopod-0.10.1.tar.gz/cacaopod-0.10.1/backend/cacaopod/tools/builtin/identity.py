from __future__ import annotations

import numpy as np

from cacaopod.wave import Wave


def identity(w: Wave) -> Wave:
    """Return the input Wave unchanged."""

    if isinstance(w, np.ndarray):  # defensive (Tool wrapper normally handles this)
        return Wave(w)
    return w

