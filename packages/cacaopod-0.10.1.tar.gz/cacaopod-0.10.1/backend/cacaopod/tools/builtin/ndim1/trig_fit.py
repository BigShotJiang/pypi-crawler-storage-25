from __future__ import annotations

import numpy as np

from cacaopod.wave import Wave
from cacaopod.tools.fit_utils import FitResult, _errors_from_cov, _finite_mask, _metrics, fit_trig_1d


def trig_fit(w: Wave, mask_noise_level: float | None = None) -> FitResult:
    """
    Trigonometric fit (1D): a*sin(omega*x + phase) + offset.

    @category: Fit
    @fit: true
    @ndim: 1
    @tags: trig, sine, fit
    """

    x = np.asarray(w.x).ravel()
    y = np.asarray(w.a).ravel()
    mask = _finite_mask(x, y)

    params, yfit, cov, mask = fit_trig_1d(x, y, mask=mask, mask_noise_level=mask_noise_level)
    names = ["amp", "omega", "phase", "offset"]
    coeffs = {name: float(params[i]) for i, name in enumerate(names)}
    errs = _errors_from_cov(cov, names)
    fit_wave = w.copy(data=yfit.reshape(w.shape))
    metrics = _metrics(y, yfit, mask)
    return FitResult(coeffs=coeffs, errors=errs, fit=fit_wave, metrics=metrics)
