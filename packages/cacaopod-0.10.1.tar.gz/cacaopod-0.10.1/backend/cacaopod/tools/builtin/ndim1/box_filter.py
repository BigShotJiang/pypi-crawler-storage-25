from __future__ import annotations

from typing import Literal

import numpy as np

from cacaopod.tools.filter_utils import uniform_filter_ignore_nan, validate_positive_int
from cacaopod.wave import Wave


def box_filter(
    w: Wave,
    size: int = 3,
    mode: Literal["reflect", "nearest", "mirror", "wrap", "constant"] = "reflect",
    cval: float = 0.0,
    preserve_nan: bool = True,
) -> Wave:
    """
    Box smoothing filter (1D). `size` is the window length in samples.

    @category: Processing
    @data_process: true
    @ndim: 1
    @tags: box, filter, smooth, smoothing, moving_average
    """

    filtered = uniform_filter_ignore_nan(
        np.asarray(w.a),
        size=validate_positive_int("size", size),
        mode=mode,
        cval=cval,
        preserve_nan=preserve_nan,
    )
    return w.copy(data=filtered)
