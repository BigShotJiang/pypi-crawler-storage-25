from __future__ import annotations

import numpy as np

from cacaopod.wave import Wave


def _histogram_wave(
    values: np.ndarray,
    *,
    bins: int,
    range_min: float | None,
    range_max: float | None,
    density: bool,
    cumulative: bool,
) -> Wave:
    arr = np.asarray(values, dtype=float).ravel()
    arr = arr[np.isfinite(arr)]
    if arr.size == 0:
        raise ValueError("histogram requires at least one finite value")

    if int(bins) < 1:
        raise ValueError("bins must be >= 1")

    lo = float(np.min(arr)) if range_min is None else float(range_min)
    hi = float(np.max(arr)) if range_max is None else float(range_max)
    if not np.isfinite(lo) or not np.isfinite(hi) or lo >= hi:
        raise ValueError("range_min must be smaller than range_max")

    counts, edges = np.histogram(arr, bins=int(bins), range=(lo, hi), density=bool(density))
    y = counts.astype(float)
    if cumulative:
        y = np.cumsum(y)
    centers = 0.5 * (edges[:-1] + edges[1:])
    return Wave(y, x=centers)


def histogram(
    w: Wave,
    bins: int = 50,
    range_min: float | None = None,
    range_max: float | None = None,
    density: bool = False,
    cumulative: bool = False,
) -> Wave:
    """
    Histogram of finite values in a 1D Wave.

    @category: Analysis
    @ndim: 1
    @tags: histogram, distribution, counts
    """

    return _histogram_wave(
        np.asarray(w.a),
        bins=bins,
        range_min=range_min,
        range_max=range_max,
        density=density,
        cumulative=cumulative,
    )
