from __future__ import annotations

import numpy as np

from cacaopod.wave import Wave
from cacaopod.tools.fit_utils import FitResult, _errors_from_cov, _finite_mask, _metrics, fit_polynomial_1d


def poly_fit(w: Wave, degree: int = 2, mask_noise_level: float | None = None) -> FitResult:
    """
    Polynomial fit (1D).

    @category: Fit
    @fit: true
    @ndim: 1
    @tags: polynomial, fit
    """

    x = np.asarray(w.x).ravel()
    y = np.asarray(w.a).ravel()
    mask = _finite_mask(x, y)

    coeffs, yfit, cov, mask = fit_polynomial_1d(x, y, degree=degree, mask=mask, mask_noise_level=mask_noise_level)

    coeffs_rev = coeffs[::-1]
    coeff_dict = {f"c{i}": float(coeffs_rev[i]) for i in range(coeffs_rev.size)}

    if cov is not None:
        errs = _errors_from_cov(cov[::-1, ::-1], [f"c{i}" for i in range(coeffs_rev.size)])
    else:
        errs = {}

    fit_wave = w.copy(data=yfit.reshape(w.shape))
    metrics = _metrics(y, yfit, mask)
    return FitResult(coeffs=coeff_dict, errors=errs, fit=fit_wave, metrics=metrics)
