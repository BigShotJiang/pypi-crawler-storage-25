from __future__ import annotations

from typing import Literal

import numpy as np

from cacaopod.tools.filter_utils import gaussian_filter_ignore_nan, validate_nonnegative_float
from cacaopod.wave import Wave


def gaussian_filter(
    w: Wave,
    sigma: float = 1.0,
    mode: Literal["reflect", "nearest", "mirror", "wrap", "constant"] = "reflect",
    cval: float = 0.0,
    truncate: float = 4.0,
    preserve_nan: bool = True,
) -> Wave:
    """
    Gaussian smoothing filter (1D). `sigma` is in samples.

    @category: Processing
    @data_process: true
    @ndim: 1
    @tags: gaussian, filter, smooth, smoothing
    """

    sigma_value = validate_nonnegative_float("sigma", sigma)
    filtered = gaussian_filter_ignore_nan(
        np.asarray(w.a),
        sigma=sigma_value,
        mode=mode,
        cval=cval,
        truncate=truncate,
        preserve_nan=preserve_nan,
    )
    return w.copy(data=filtered)
