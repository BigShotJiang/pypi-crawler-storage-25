"""Builtin tools shipped with Cacaopod.

User tools override builtin tools if they share the same name.
"""
