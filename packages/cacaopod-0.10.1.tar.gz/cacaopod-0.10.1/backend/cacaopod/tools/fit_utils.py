from __future__ import annotations

from dataclasses import dataclass
from math import erf as _erf
from typing import Any, Callable

import numpy as np

from cacaopod.wave import Wave


@dataclass
class FitResult:
    coeffs: dict[str, Any]
    errors: dict[str, Any]
    fit: Wave | np.ndarray
    metrics: dict[str, Any]


def _erf_array(x: np.ndarray) -> np.ndarray:
    vec = np.vectorize(_erf)
    return vec(x)


def _finite_mask(*arrays: np.ndarray) -> np.ndarray:
    mask = np.ones_like(arrays[0], dtype=bool)
    for arr in arrays:
        mask &= np.isfinite(arr)
    return mask


def _apply_noise_mask(mask: np.ndarray, y: np.ndarray, yfit: np.ndarray, mask_noise_level: float | None) -> np.ndarray:
    if mask_noise_level is None:
        return mask
    residual = yfit - y
    r = residual[mask]
    if r.size < 2:
        return mask
    sigma = float(np.nanstd(r))
    if not np.isfinite(sigma) or sigma <= 0:
        return mask
    return mask & (np.abs(residual) < float(mask_noise_level) * sigma)


def _gauss_newton(
    model: Callable[[np.ndarray], np.ndarray],
    y: np.ndarray,
    mask: np.ndarray,
    p0: np.ndarray,
    *,
    max_iter: int = 50,
    tol: float = 1e-6,
    lam: float = 1e-6,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
    p = np.asarray(p0, dtype=float).copy()
    n_params = p.size
    if n_params == 0:
        raise ValueError("no parameters to fit")

    def jacobian(p_cur: np.ndarray, y_base: np.ndarray) -> np.ndarray:
        eps = 1e-6 * (np.abs(p_cur) + 1.0)
        j = np.zeros((int(mask.sum()), n_params), dtype=float)
        for i in range(n_params):
            p_eps = p_cur.copy()
            p_eps[i] += eps[i]
            y_eps = model(p_eps)
            j[:, i] = (y_eps[mask] - y_base[mask]) / eps[i]
        return j

    for _ in range(max_iter):
        y_pred = model(p)
        r = (y - y_pred)[mask]
        if r.size == 0:
            break
        j = jacobian(p, y_pred)
        jt_j = j.T @ j
        if lam > 0:
            jt_j = jt_j + lam * np.eye(n_params)
        step = np.linalg.lstsq(jt_j, j.T @ r, rcond=None)[0]
        p_next = p + step
        if np.linalg.norm(step) < tol:
            p = p_next
            break
        p = p_next

    y_pred = model(p)
    cov = None
    try:
        r = (y - y_pred)[mask]
        j = jacobian(p, y_pred)
        jt_j = j.T @ j
        dof = max(1, r.size - n_params)
        sigma2 = float((r @ r) / dof)
        cov = np.linalg.pinv(jt_j) * sigma2
    except Exception:  # noqa: BLE001
        cov = None

    return p, y_pred, cov


def _errors_from_cov(cov: np.ndarray | None, names: list[str]) -> dict[str, float]:
    if cov is None:
        return {}
    try:
        diag = np.sqrt(np.diag(cov))
    except Exception:  # noqa: BLE001
        return {}
    return {name: float(diag[i]) for i, name in enumerate(names) if i < diag.size}


def _metrics(y: np.ndarray, yfit: np.ndarray, mask: np.ndarray) -> dict[str, float]:
    r = (yfit - y)[mask]
    if r.size == 0:
        return {}
    chi2 = float(np.sum(r * r))
    rmse = float(np.sqrt(np.mean(r * r)))
    return {"chi2": chi2, "rmse": rmse}


def _span(values: np.ndarray, fallback: float = 1.0) -> float:
    arr = np.asarray(values, dtype=float)
    arr = arr[np.isfinite(arr)]
    if arr.size < 2:
        return fallback
    out = float(np.nanmax(arr) - np.nanmin(arr))
    return out if np.isfinite(out) and out > 0 else fallback


def _center_width_1d(x: np.ndarray, y: np.ndarray, mask: np.ndarray) -> tuple[float, float]:
    xm = np.asarray(x, dtype=float)[mask]
    ym = np.asarray(y, dtype=float)[mask]
    if xm.size == 0:
        return 0.0, 1.0
    baseline = float(np.nanmedian(ym))
    idx = int(np.nanargmax(np.abs(ym - baseline))) if ym.size else 0
    center = float(xm[idx])
    weights = np.abs(ym - baseline)
    if np.nansum(weights) > 0:
        width = float(np.sqrt(np.nansum(weights * (xm - center) ** 2) / np.nansum(weights)))
    else:
        width = _span(xm) / 6.0
    return center, max(width, 1e-12)


def _center_width_2d(x: np.ndarray, y: np.ndarray, z: np.ndarray, mask: np.ndarray) -> tuple[float, float, float, float]:
    xm = np.asarray(x, dtype=float)[mask]
    ym = np.asarray(y, dtype=float)[mask]
    zm = np.asarray(z, dtype=float)[mask]
    if zm.size == 0:
        return 0.0, 0.0, 1.0, 1.0
    baseline = float(np.nanmedian(zm))
    idx = int(np.nanargmax(np.abs(zm - baseline))) if zm.size else 0
    x0 = float(xm[idx])
    y0 = float(ym[idx])
    weights = np.abs(zm - baseline)
    if np.nansum(weights) > 0:
        sx = float(np.sqrt(np.nansum(weights * (xm - x0) ** 2) / np.nansum(weights)))
        sy = float(np.sqrt(np.nansum(weights * (ym - y0) ** 2) / np.nansum(weights)))
    else:
        sx = _span(xm) / 6.0
        sy = _span(ym) / 6.0
    return x0, y0, max(sx, 1e-12), max(sy, 1e-12)


def _frequency_guess_1d(x: np.ndarray, y: np.ndarray, mask: np.ndarray) -> tuple[float, float]:
    xm = np.asarray(x, dtype=float)[mask]
    ym = np.asarray(y, dtype=float)[mask]
    if xm.size < 4:
        omega = 2 * np.pi / _span(xm)
        return float(omega), float(omega / (2 * np.pi))

    order = np.argsort(xm)
    xs = xm[order]
    ys = ym[order] - float(np.nanmean(ym))
    dx = float(np.nanmedian(np.diff(xs)))
    if not np.isfinite(dx) or dx <= 0:
        omega = 2 * np.pi / _span(xs)
        return float(omega), float(omega / (2 * np.pi))

    yf = np.fft.rfft(ys)
    freqs = np.fft.rfftfreq(xs.size, d=dx)
    if freqs.size <= 1:
        omega = 2 * np.pi / _span(xs)
        return float(omega), float(omega / (2 * np.pi))

    idx = int(np.argmax(np.abs(yf[1:])) + 1)
    freq = float(freqs[idx])
    if not np.isfinite(freq) or freq <= 0:
        freq = 1.0 / _span(xs)
    return float(2 * np.pi * freq), float(freq)


def _guess_by_name(name: str, stats: dict[str, float]) -> float:
    n = name.lower()
    if n in {"a", "amp", "amplitude", "height", "scale"} or "amplitude" in n:
        return stats["amplitude"]
    if n in {"b", "c", "bg", "base", "baseline", "offset", "intercept"} or "offset" in n or "baseline" in n:
        return stats["offset"]
    if n in {"x0", "x_c", "xc", "mux", "mu_x", "center_x"} or ("center" in n and "x" in n):
        return stats["x0"]
    if n in {"y0", "y_c", "yc", "muy", "mu_y", "center_y"} or ("center" in n and "y" in n):
        return stats.get("y0", 0.0)
    if n in {"mu", "mean", "center", "loc"}:
        return stats["x0"]
    if n in {"sigma", "sig", "std", "width", "s"}:
        return stats["sigma"]
    if n in {"sx", "sigma_x", "sigmax", "width_x"}:
        return stats.get("sx", stats["sigma"])
    if n in {"sy", "sigma_y", "sigmay", "width_y"}:
        return stats.get("sy", stats["sigma"])
    if n in {"tau", "decay", "lifetime", "time_constant"} or "tau" in n:
        return stats["span_x"] / 5.0
    if n in {"omega", "w", "angular_frequency"}:
        return stats.get("omega", 2 * np.pi / stats["span_x"])
    if n in {"freq", "frequency", "f"}:
        return stats.get("frequency", 1.0 / stats["span_x"])
    if n in {"phase", "phi"}:
        return 0.0
    if n in {"m", "slope"}:
        return stats.get("slope", 0.0)
    return 1.0


def estimate_initial_params_1d(names: list[str], x: np.ndarray, y: np.ndarray, mask: np.ndarray | None = None) -> dict[str, float]:
    """Estimate generic initial fit parameters from common parameter names."""

    x_arr = np.asarray(x, dtype=float).ravel()
    y_arr = np.asarray(y, dtype=float).ravel()
    m = _finite_mask(x_arr, y_arr) if mask is None else np.asarray(mask, dtype=bool).ravel() & _finite_mask(x_arr, y_arr)
    if not np.any(m):
        raise ValueError("no finite data for initial parameter estimation")
    ym = y_arr[m]
    xm = x_arr[m]
    offset = float(np.nanmedian(ym))
    amplitude = float(np.nanmax(ym) - np.nanmin(ym))
    if not np.isfinite(amplitude) or amplitude == 0:
        amplitude = float(np.nanstd(ym)) if np.nanstd(ym) > 0 else 1.0
    x0, sigma = _center_width_1d(x_arr, y_arr, m)
    omega, frequency = _frequency_guess_1d(x_arr, y_arr, m)
    span_x = _span(xm)
    try:
        slope = float((ym[-1] - ym[0]) / (xm[-1] - xm[0])) if xm[-1] != xm[0] else 0.0
    except Exception:  # noqa: BLE001
        slope = 0.0
    stats = {
        "offset": offset,
        "amplitude": amplitude,
        "x0": x0,
        "sigma": sigma,
        "span_x": span_x,
        "omega": omega,
        "frequency": frequency,
        "slope": slope,
    }
    return {name: float(_guess_by_name(name, stats)) for name in names}


def estimate_initial_params_2d(names: list[str], x: np.ndarray, y: np.ndarray, z: np.ndarray, mask: np.ndarray | None = None) -> dict[str, float]:
    """Estimate generic initial fit parameters for 2D surfaces/images."""

    x_arr = np.asarray(x, dtype=float)
    y_arr = np.asarray(y, dtype=float)
    z_arr = np.asarray(z, dtype=float)
    m = _finite_mask(x_arr, y_arr, z_arr) if mask is None else np.asarray(mask, dtype=bool) & _finite_mask(x_arr, y_arr, z_arr)
    if not np.any(m):
        raise ValueError("no finite data for initial parameter estimation")
    zm = z_arr[m]
    offset = float(np.nanmedian(zm))
    amplitude = float(np.nanmax(zm) - np.nanmin(zm))
    if not np.isfinite(amplitude) or amplitude == 0:
        amplitude = float(np.nanstd(zm)) if np.nanstd(zm) > 0 else 1.0
    x0, y0, sx, sy = _center_width_2d(x_arr, y_arr, z_arr, m)
    stats = {
        "offset": offset,
        "amplitude": amplitude,
        "x0": x0,
        "y0": y0,
        "sigma": float(np.sqrt(sx * sy)),
        "sx": sx,
        "sy": sy,
        "span_x": _span(x_arr[m]),
        "span_y": _span(y_arr[m]),
        "slope": 0.0,
    }
    return {name: float(_guess_by_name(name, stats)) for name in names}


def fit_with_mask_noise(
    fit_fn: Callable[[np.ndarray], tuple[np.ndarray, np.ndarray, np.ndarray | None]],
    y: np.ndarray,
    mask: np.ndarray,
    mask_noise_level: float | None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, np.ndarray]:
    params, yfit, cov = fit_fn(mask)
    new_mask = _apply_noise_mask(mask, y, yfit, mask_noise_level)
    if mask_noise_level is not None and not np.array_equal(new_mask, mask):
        params, yfit, cov = fit_fn(new_mask)
        mask = new_mask
    return params, yfit, cov, mask


def fit_polynomial_1d(
    x: np.ndarray,
    y: np.ndarray,
    *,
    degree: int,
    mask: np.ndarray,
    mask_noise_level: float | None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, np.ndarray]:
    def _fit(m: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
        if m.sum() <= degree:
            raise ValueError("not enough points for polynomial fit")
        coeffs, cov = np.polyfit(x[m], y[m], degree, cov=True)
        yfit = np.polyval(coeffs, x)
        return coeffs, yfit, cov

    return fit_with_mask_noise(_fit, y, mask, mask_noise_level)


def fit_polynomial_2d(
    x: np.ndarray,
    y: np.ndarray,
    z: np.ndarray,
    *,
    degree: int,
    mask: np.ndarray,
    mask_noise_level: float | None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, np.ndarray, list[tuple[int, int]]]:
    terms: list[tuple[int, int]] = []
    for i in range(degree + 1):
        for j in range(degree + 1 - i):
            terms.append((i, j))

    def _design(xv: np.ndarray, yv: np.ndarray) -> np.ndarray:
        cols = [np.power(xv, i) * np.power(yv, j) for i, j in terms]
        return np.stack(cols, axis=1)

    def _fit(m: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
        if m.sum() <= len(terms):
            raise ValueError("not enough points for polynomial fit")
        A = _design(x[m], y[m])
        coeffs, *_ = np.linalg.lstsq(A, z[m], rcond=None)
        yfit = (_design(x, y) @ coeffs)
        try:
            r = z[m] - (A @ coeffs)
            dof = max(1, r.size - len(coeffs))
            sigma2 = float((r @ r) / dof)
            cov = np.linalg.pinv(A.T @ A) * sigma2
        except Exception:  # noqa: BLE001
            cov = None
        return coeffs, yfit, cov

    params, yfit, cov, mask_out = fit_with_mask_noise(_fit, z, mask, mask_noise_level)
    return params, yfit, cov, mask_out, terms


def fit_gaussian_1d(
    x: np.ndarray,
    y: np.ndarray,
    *,
    mask: np.ndarray,
    mask_noise_level: float | None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, np.ndarray]:
    y_mask = y[mask]
    x_mask = x[mask]
    if y_mask.size == 0:
        raise ValueError("no valid points for fit")
    offset = float(np.nanmedian(y_mask))
    amp = float(np.nanmax(y_mask) - offset)
    if not np.isfinite(amp) or amp == 0:
        amp = float(np.nanstd(y_mask)) if np.nanstd(y_mask) > 0 else 1.0
    x0 = float(x_mask[np.nanargmax(y_mask)])
    weights = np.clip(y_mask - offset, 0, None)
    if np.sum(weights) > 0:
        sigma = float(np.sqrt(np.sum(weights * (x_mask - x0) ** 2) / np.sum(weights)))
    else:
        sigma = float(np.nanstd(x_mask)) if np.nanstd(x_mask) > 0 else 1.0
    sigma = max(float(sigma), 1e-6)

    def model(p: np.ndarray) -> np.ndarray:
        a, x0v, sv, b = p
        return a * np.exp(-((x - x0v) ** 2) / (2 * (sv**2))) + b

    p0 = np.array([amp, x0, sigma, offset], dtype=float)

    def _fit(m: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
        return _gauss_newton(model, y, m, p0)

    return fit_with_mask_noise(_fit, y, mask, mask_noise_level)


def fit_gaussian_2d(
    x: np.ndarray,
    y: np.ndarray,
    z: np.ndarray,
    *,
    mask: np.ndarray,
    mask_noise_level: float | None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, np.ndarray]:
    z_mask = z[mask]
    x_mask = x[mask]
    y_mask = y[mask]
    if z_mask.size == 0:
        raise ValueError("no valid points for fit")
    offset = float(np.nanmedian(z_mask))
    amp = float(np.nanmax(z_mask) - offset)
    if not np.isfinite(amp) or amp == 0:
        amp = float(np.nanstd(z_mask)) if np.nanstd(z_mask) > 0 else 1.0
    idx = np.nanargmax(z_mask)
    x0 = float(x_mask[idx])
    y0 = float(y_mask[idx])
    weights = np.clip(z_mask - offset, 0, None)
    if np.sum(weights) > 0:
        sx = float(np.sqrt(np.sum(weights * (x_mask - x0) ** 2) / np.sum(weights)))
        sy = float(np.sqrt(np.sum(weights * (y_mask - y0) ** 2) / np.sum(weights)))
    else:
        sx = float(np.nanstd(x_mask)) if np.nanstd(x_mask) > 0 else 1.0
        sy = float(np.nanstd(y_mask)) if np.nanstd(y_mask) > 0 else 1.0
    sx = max(float(sx), 1e-6)
    sy = max(float(sy), 1e-6)

    def model(p: np.ndarray) -> np.ndarray:
        a, x0v, y0v, sxv, syv, b = p
        return a * np.exp(-(((x - x0v) ** 2) / (2 * (sxv**2)) + ((y - y0v) ** 2) / (2 * (syv**2)))) + b

    p0 = np.array([amp, x0, y0, sx, sy, offset], dtype=float)

    def _fit(m: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
        return _gauss_newton(model, z, m, p0)

    return fit_with_mask_noise(_fit, z, mask, mask_noise_level)


def fit_trig_1d(
    x: np.ndarray,
    y: np.ndarray,
    *,
    mask: np.ndarray,
    mask_noise_level: float | None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, np.ndarray]:
    x_mask = x[mask]
    y_mask = y[mask]
    if y_mask.size == 0:
        raise ValueError("no valid points for fit")
    offset = float(np.nanmean(y_mask))
    y0 = y_mask - offset
    if y0.size >= 4:
        dx = float(np.nanmedian(np.diff(np.sort(x_mask))))
        if not np.isfinite(dx) or dx == 0:
            dx = 1.0
        n = y0.size
        fft = np.fft.rfft(y0)
        freq = np.fft.rfftfreq(n, d=dx)
        if freq.size > 1:
            k = int(np.argmax(np.abs(fft[1:])) + 1)
            w = float(2 * np.pi * freq[k])
        else:
            w = 1.0
    else:
        w = 1.0

    A = np.column_stack([np.sin(w * x_mask), np.cos(w * x_mask), np.ones_like(x_mask)])
    coeffs, *_ = np.linalg.lstsq(A, y_mask, rcond=None)
    a_sin, a_cos, b0 = coeffs
    amp = float(np.sqrt(a_sin**2 + a_cos**2))
    phase = float(np.arctan2(a_cos, a_sin))
    offset = float(b0)

    def model(p: np.ndarray) -> np.ndarray:
        a, wv, ph, b = p
        return a * np.sin(wv * x + ph) + b

    p0 = np.array([amp, w, phase, offset], dtype=float)

    def _fit(m: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
        return _gauss_newton(model, y, m, p0, max_iter=60)

    return fit_with_mask_noise(_fit, y, mask, mask_noise_level)


def fit_trig_2d(
    x: np.ndarray,
    y: np.ndarray,
    z: np.ndarray,
    *,
    mask: np.ndarray,
    mask_noise_level: float | None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, np.ndarray]:
    z_mask = z[mask]
    if z_mask.size == 0:
        raise ValueError("no valid points for fit")
    offset = float(np.nanmean(z_mask))
    z0 = z_mask - offset

    # Estimate wx from average over y, wy from average over x.
    x_axis = x[0, :] if x.ndim == 2 else np.unique(x)
    y_axis = y[:, 0] if y.ndim == 2 else np.unique(y)
    mx = np.nanmean(z, axis=0) if z.ndim == 2 else z_mask
    my = np.nanmean(z, axis=1) if z.ndim == 2 else z_mask

    def _estimate_w(axis: np.ndarray, vals: np.ndarray) -> float:
        if axis.size < 4 or vals.size < 4:
            return 1.0
        dx = float(np.nanmedian(np.diff(np.sort(axis))))
        if not np.isfinite(dx) or dx == 0:
            dx = 1.0
        n = vals.size
        fft = np.fft.rfft(vals - np.nanmean(vals))
        freq = np.fft.rfftfreq(n, d=dx)
        if freq.size > 1:
            k = int(np.argmax(np.abs(fft[1:])) + 1)
            return float(2 * np.pi * freq[k])
        return 1.0

    wx = _estimate_w(np.asarray(x_axis), np.asarray(mx))
    wy = _estimate_w(np.asarray(y_axis), np.asarray(my))
    amp = float(np.nanstd(z0)) if np.nanstd(z0) > 0 else 1.0

    def model(p: np.ndarray) -> np.ndarray:
        a, wxv, wyv, ph, b = p
        return a * np.sin(wxv * x + wyv * y + ph) + b

    p0 = np.array([amp, wx, wy, 0.0, offset], dtype=float)

    def _fit(m: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
        return _gauss_newton(model, z, m, p0, max_iter=60)

    return fit_with_mask_noise(_fit, z, mask, mask_noise_level)


def fit_erf_1d(
    x: np.ndarray,
    y: np.ndarray,
    *,
    mask: np.ndarray,
    mask_noise_level: float | None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, np.ndarray]:
    y_mask = y[mask]
    x_mask = x[mask]
    if y_mask.size == 0:
        raise ValueError("no valid points for fit")
    y_min = float(np.nanmin(y_mask))
    y_max = float(np.nanmax(y_mask))
    offset = (y_max + y_min) / 2.0
    amp = (y_max - y_min) / 2.0
    if amp == 0:
        amp = float(np.nanstd(y_mask)) if np.nanstd(y_mask) > 0 else 1.0
    # estimate center from median
    x0 = float(np.nanmedian(x_mask))
    # estimate width from 10-90% rise
    y_norm = (y_mask - offset) / (amp if amp != 0 else 1.0)
    try:
        x10 = float(x_mask[np.nanargmin(np.abs(y_norm - 0.1))])
        x90 = float(x_mask[np.nanargmin(np.abs(y_norm - 0.9))])
        sigma = max(abs(x90 - x10) / 2.0, 1e-6)
    except Exception:  # noqa: BLE001
        sigma = float(np.nanstd(x_mask)) if np.nanstd(x_mask) > 0 else 1.0

    def model(p: np.ndarray) -> np.ndarray:
        a, x0v, sv, b = p
        return a * _erf_array((x - x0v) / (np.sqrt(2) * sv)) + b

    p0 = np.array([amp, x0, sigma, offset], dtype=float)

    def _fit(m: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
        return _gauss_newton(model, y, m, p0, max_iter=60)

    return fit_with_mask_noise(_fit, y, mask, mask_noise_level)


def fit_erf_2d(
    x: np.ndarray,
    y: np.ndarray,
    z: np.ndarray,
    *,
    mask: np.ndarray,
    mask_noise_level: float | None,
) -> tuple[np.ndarray, np.ndarray, np.ndarray | None, np.ndarray]:
    z_mask = z[mask]
    if z_mask.size == 0:
        raise ValueError("no valid points for fit")
    z_min = float(np.nanmin(z_mask))
    z_max = float(np.nanmax(z_mask))
    offset = (z_max + z_min) / 2.0
    amp = (z_max - z_min) / 2.0
    if amp == 0:
        amp = float(np.nanstd(z_mask)) if np.nanstd(z_mask) > 0 else 1.0
    x0 = float(np.nanmedian(x[mask]))
    y0 = float(np.nanmedian(y[mask]))
    sx = float(np.nanstd(x[mask])) if np.nanstd(x[mask]) > 0 else 1.0
    sy = float(np.nanstd(y[mask])) if np.nanstd(y[mask]) > 0 else 1.0

    def model(p: np.ndarray) -> np.ndarray:
        a, x0v, y0v, sxv, syv, b = p
        return a * _erf_array((x - x0v) / (np.sqrt(2) * sxv)) * _erf_array((y - y0v) / (np.sqrt(2) * syv)) + b

    p0 = np.array([amp, x0, y0, sx, sy, offset], dtype=float)

    def _fit(m: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray | None]:
        return _gauss_newton(model, z, m, p0, max_iter=60)

    return fit_with_mask_noise(_fit, z, mask, mask_noise_level)
