from __future__ import annotations

from typing import Callable

import numpy as np
from scipy.ndimage import gaussian_filter as _gaussian_filter
from scipy.ndimage import uniform_filter as _uniform_filter

_ALLOWED_FILTER_MODES = {"reflect", "nearest", "mirror", "wrap", "constant"}


def validate_filter_mode(mode: str) -> str:
    normalized = str(mode or "").strip().lower()
    if normalized not in _ALLOWED_FILTER_MODES:
        allowed = ", ".join(sorted(_ALLOWED_FILTER_MODES))
        raise ValueError(f"mode must be one of: {allowed}")
    return normalized


def validate_finite_float(name: str, value: float) -> float:
    out = float(value)
    if not np.isfinite(out):
        raise ValueError(f"{name} must be finite")
    return out


def validate_nonnegative_float(name: str, value: float) -> float:
    out = validate_finite_float(name, value)
    if out < 0:
        raise ValueError(f"{name} must be >= 0")
    return out


def validate_positive_float(name: str, value: float) -> float:
    out = validate_finite_float(name, value)
    if out <= 0:
        raise ValueError(f"{name} must be > 0")
    return out


def validate_positive_int(name: str, value: int) -> int:
    if isinstance(value, (bool, np.bool_)):
        raise ValueError(f"{name} must be a positive integer")
    if isinstance(value, (int, np.integer)):
        out = int(value)
    else:
        as_float = float(value)
        if not np.isfinite(as_float) or not as_float.is_integer():
            raise ValueError(f"{name} must be a positive integer")
        out = int(as_float)
    if out <= 0:
        raise ValueError(f"{name} must be a positive integer")
    return out


def _nan_weighted_filter_real(
    data: np.ndarray,
    *,
    values_filter: Callable[[np.ndarray], np.ndarray],
    weights_filter: Callable[[np.ndarray], np.ndarray],
    preserve_nan: bool,
) -> np.ndarray:
    finite = np.isfinite(data)
    if finite.all():
        return np.asarray(values_filter(data), dtype=float)

    filled = np.where(finite, data, 0.0)
    weighted_values = np.asarray(values_filter(filled), dtype=float)
    weighted_counts = np.asarray(weights_filter(finite.astype(float)), dtype=float)

    out = np.full(data.shape, np.nan, dtype=float)
    np.divide(weighted_values, weighted_counts, out=out, where=weighted_counts > 0)
    if preserve_nan:
        out[~finite] = np.nan
    return out


def _nan_weighted_filter(
    data: np.ndarray,
    *,
    values_filter: Callable[[np.ndarray], np.ndarray],
    weights_filter: Callable[[np.ndarray], np.ndarray],
    preserve_nan: bool,
) -> np.ndarray:
    arr = np.asarray(data)
    if np.iscomplexobj(arr):
        real = _nan_weighted_filter_real(
            np.asarray(arr.real, dtype=float),
            values_filter=values_filter,
            weights_filter=weights_filter,
            preserve_nan=preserve_nan,
        )
        imag = _nan_weighted_filter_real(
            np.asarray(arr.imag, dtype=float),
            values_filter=values_filter,
            weights_filter=weights_filter,
            preserve_nan=preserve_nan,
        )
        out = real + 1j * imag
        if preserve_nan:
            out[~np.isfinite(arr)] = np.nan + 0j
        return out

    return _nan_weighted_filter_real(
        np.asarray(arr, dtype=float),
        values_filter=values_filter,
        weights_filter=weights_filter,
        preserve_nan=preserve_nan,
    )


def gaussian_filter_ignore_nan(
    data: np.ndarray,
    sigma: float | tuple[float, ...],
    *,
    mode: str = "reflect",
    cval: float = 0.0,
    truncate: float = 4.0,
    preserve_nan: bool = True,
) -> np.ndarray:
    mode_value = validate_filter_mode(mode)
    cval_value = validate_finite_float("cval", cval)
    truncate_value = validate_positive_float("truncate", truncate)
    weights_cval = 1.0 if mode_value == "constant" else 0.0

    return _nan_weighted_filter(
        np.asarray(data),
        values_filter=lambda arr: _gaussian_filter(
            arr,
            sigma=sigma,
            mode=mode_value,
            cval=cval_value,
            truncate=truncate_value,
        ),
        weights_filter=lambda arr: _gaussian_filter(
            arr,
            sigma=sigma,
            mode=mode_value,
            cval=weights_cval,
            truncate=truncate_value,
        ),
        preserve_nan=bool(preserve_nan),
    )


def uniform_filter_ignore_nan(
    data: np.ndarray,
    size: int | tuple[int, ...],
    *,
    mode: str = "reflect",
    cval: float = 0.0,
    preserve_nan: bool = True,
) -> np.ndarray:
    mode_value = validate_filter_mode(mode)
    cval_value = validate_finite_float("cval", cval)
    weights_cval = 1.0 if mode_value == "constant" else 0.0

    return _nan_weighted_filter(
        np.asarray(data),
        values_filter=lambda arr: _uniform_filter(
            arr,
            size=size,
            mode=mode_value,
            cval=cval_value,
        ),
        weights_filter=lambda arr: _uniform_filter(
            arr,
            size=size,
            mode=mode_value,
            cval=weights_cval,
        ),
        preserve_nan=bool(preserve_nan),
    )
