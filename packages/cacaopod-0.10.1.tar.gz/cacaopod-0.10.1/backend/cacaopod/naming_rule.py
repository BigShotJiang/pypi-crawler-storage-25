from __future__ import annotations

import ast
import inspect
import json
import os
import random
import re
import types
import urllib.error
import urllib.request
from time import sleep
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal

from platformdirs import user_data_dir

from cacaopod.config import data_root_for
from cacaopod.tool_utils import _extract_openai_output_text, _openai_model_default, _openai_reasoning

NamingRuleLocation = Literal["builtin", "workdir", "user"]


_VALID_RULE_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _assert_valid_rule_name(name: str) -> str:
    n = str(name).strip()
    if not n:
        raise ValueError("naming_rule name must be non-empty")
    if not _VALID_RULE_NAME.match(n):
        raise ValueError(f"invalid naming_rule name: {n!r} (use a valid Python identifier)")
    return n


def _naming_rules_builtin_dir() -> Path:
    return Path(__file__).resolve().parent / "naming_rules" / "builtin"


def _naming_rules_workdir_dir(workdir: Path) -> Path:
    return data_root_for(workdir) / "naming_rules"


def _naming_rules_user_dir() -> Path:
    return Path(user_data_dir("Cacaopod", "Cacaopod")) / "naming_rules"


def _extract_module_defs_only(source: str) -> str:
    """Keep imports/classes/functions; drop ad-hoc top-level code."""
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:
        raise ValueError(f"invalid Python source: {exc}") from exc

    lines = source.splitlines(True)
    blocks: list[str] = []
    for node in tree.body:
        include = False
        if isinstance(node, ast.Import):
            include = True
        elif isinstance(node, ast.ImportFrom):
            if node.module == "__future__" and any(getattr(a, "name", "") == "annotations" for a in node.names):
                include = False
            else:
                include = True
        elif isinstance(node, ast.ClassDef):
            include = True
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            include = True

        if not include:
            continue

        start = int(getattr(node, "lineno", 1) or 1)
        if getattr(node, "decorator_list", None):
            for dec in node.decorator_list:  # type: ignore[attr-defined]
                dec_line = getattr(dec, "lineno", None)
                if dec_line is not None:
                    start = min(start, int(dec_line))

        end = getattr(node, "end_lineno", None)
        if not end:
            continue

        blocks.append("".join(lines[start - 1 : int(end)]).rstrip() + "\n")

    out = "".join(blocks).strip()
    if not out:
        raise ValueError("no definitions found")
    return out + "\n"


@dataclass(frozen=True)
class NamingRuleSummary:
    name: str
    location: NamingRuleLocation
    signature: str
    doc: str


class NamingRule:
    def __init__(self, name: str, func: Callable[..., Any], *, location: NamingRuleLocation, source_path: Path) -> None:
        self.name = _assert_valid_rule_name(name)
        self._func = func
        self.location = location
        self.source_path = source_path

        sig = inspect.signature(func)
        file_param = sig.parameters.get("file_path")
        if file_param is None:
            raise ValueError("naming_rule must define a required parameter named 'file_path'")
        if file_param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
            raise ValueError("naming_rule parameter 'file_path' must be an explicit argument")
        if file_param.default is not inspect._empty:
            raise ValueError("naming_rule parameter 'file_path' must be required (no default)")
        self._signature = sig

    @property
    def signature(self) -> inspect.Signature:
        return self._signature

    @property
    def doc(self) -> str:
        return (inspect.getdoc(self._func) or "").strip()

    def __call__(self, file_path: str) -> str:
        out = self._func(file_path)
        if out is None:
            raise ValueError("naming_rule returned None")
        name = str(out).strip()
        if not name:
            raise ValueError("naming_rule returned empty name")
        if "/" in name or "\\" in name:
            raise ValueError("wave name must not contain path separators ('/')")
        if "@" in name:
            raise ValueError("wave name must not contain '@' (reserved for board selection: name@board)")
        return name


class NamingRuleRegistry:
    def __init__(self, *, workdir: Path) -> None:
        self._workdir = Path(workdir).expanduser().resolve()

    def _locations_in_precedence(self) -> list[NamingRuleLocation]:
        return ["workdir", "user", "builtin"]

    def _dir_for_location(self, location: NamingRuleLocation) -> Path:
        if location == "builtin":
            return _naming_rules_builtin_dir()
        if location == "user":
            return _naming_rules_user_dir()
        return _naming_rules_workdir_dir(self._workdir)

    def _resolve_rule_path(self, name: str, location: NamingRuleLocation | None = None) -> tuple[NamingRuleLocation, Path]:
        rule_name = _assert_valid_rule_name(name)
        if location is not None:
            loc = location
            path = self._dir_for_location(loc) / f"{rule_name}.py"
            if not path.exists():
                raise KeyError(rule_name)
            return loc, path

        for loc in self._locations_in_precedence():
            path = self._dir_for_location(loc) / f"{rule_name}.py"
            if path.exists():
                return loc, path
        raise KeyError(rule_name)

    def get_source(self, name: str, *, location: NamingRuleLocation | None = None) -> tuple[NamingRuleLocation, str]:
        loc, path = self._resolve_rule_path(name, location)
        return loc, path.read_text(encoding="utf-8")

    def get(self, name: str, *, location: NamingRuleLocation | None = None) -> NamingRule:
        loc, path = self._resolve_rule_path(name, location)
        return self._load_from_path(loc, path)

    def save_source(self, name: str, source: str, *, location: NamingRuleLocation) -> NamingRule:
        if location == "builtin":
            raise ValueError("cannot overwrite builtin naming_rules")
        rule_name = _assert_valid_rule_name(name)

        module_source = _extract_module_defs_only(source)

        tmp_mod = types.ModuleType("_cacaopod_naming_rule_validate")
        exec(compile(module_source, "<naming-rule-validate>", "exec", dont_inherit=True), tmp_mod.__dict__)  # noqa: S102 - local trusted code
        func = tmp_mod.__dict__.get(rule_name)
        if not callable(func):
            raise ValueError(f"source must define a function named {rule_name!r}")

        rule = NamingRule(rule_name, func, location=location, source_path=Path(f"{rule_name}.py"))

        out_dir = self._dir_for_location(location)
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / f"{rule_name}.py"
        tmp = path.with_suffix(".tmp")
        tmp.write_text(module_source, encoding="utf-8")
        tmp.replace(path)

        return NamingRule(rule_name, func, location=location, source_path=path)

    def delete(self, name: str, *, location: NamingRuleLocation) -> None:
        if location == "builtin":
            raise ValueError("cannot delete builtin naming_rules")
        rule_name = _assert_valid_rule_name(name)
        path = self._dir_for_location(location) / f"{rule_name}.py"
        if path.exists():
            path.unlink()

    def list(self) -> list[NamingRuleSummary]:
        found: dict[str, tuple[NamingRuleLocation, Path]] = {}
        for loc in self._locations_in_precedence():
            root = self._dir_for_location(loc)
            if not root.exists():
                continue
            for path in root.glob("*.py"):
                if path.name.startswith("_") or path.name == "__init__.py":
                    continue
                name = path.stem
                if not _VALID_RULE_NAME.match(name):
                    continue
                found.setdefault(name, (loc, path))

        summaries: list[NamingRuleSummary] = []
        for name, (loc, _path) in sorted(found.items(), key=lambda kv: kv[0].lower()):
            try:
                rule = self[name]
                summaries.append(
                    NamingRuleSummary(
                        name=name,
                        location=loc,
                        signature=str(rule.signature),
                        doc=rule.doc,
                    )
                )
            except Exception:  # noqa: BLE001
                summaries.append(NamingRuleSummary(name=name, location=loc, signature="(?)", doc="(failed to load)"))
        return summaries

    def __getitem__(self, name: str) -> NamingRule:
        loc, path = self._resolve_rule_path(name)
        return self._load_from_path(loc, path)

    def _load_from_path(self, loc: NamingRuleLocation, path: Path) -> NamingRule:
        source = path.read_text(encoding="utf-8")

        mod_name = f"_cacaopod_naming_rule_{loc}_{path.stem}_{path.stat().st_mtime_ns}"
        module = types.ModuleType(mod_name)
        module.__file__ = str(path)
        exec(compile(source, str(path), "exec", dont_inherit=True), module.__dict__)  # noqa: S102 - local trusted code

        func = module.__dict__.get(path.stem)
        if not callable(func):
            raise ValueError(f"naming_rule module must define a callable named {path.stem!r}")
        return NamingRule(path.stem, func, location=loc, source_path=path)


def naming_rule_from_source(*, name: str, source: str) -> NamingRule:
    rule_name = _assert_valid_rule_name(name)
    module_source = _extract_module_defs_only(source)

    tmp_mod = types.ModuleType("_cacaopod_naming_rule_preview")
    exec(compile(module_source, "<naming-rule-preview>", "exec", dont_inherit=True), tmp_mod.__dict__)  # noqa: S102 - local trusted code

    func = tmp_mod.__dict__.get(rule_name)
    if not callable(func):
        raise ValueError(f"source must define a function named {rule_name!r}")

    return NamingRule(rule_name, func, location="workdir", source_path=Path(f"{rule_name}.py"))


def _openai_api_key() -> str | None:
    return os.environ.get("CACAOPOD_OPENAI_API_KEY") or os.environ.get("OPENAI_API_KEY")


def _openai_api_base() -> str:
    return (os.environ.get("CACAOPOD_OPENAI_API_BASE") or os.environ.get("OPENAI_BASE_URL") or "https://api.openai.com").rstrip("/")


def generate_naming_rule_via_openai(
    *,
    name: str,
    files: list[str],
    examples_text: str,
    model: str | None,
) -> str:
    key = _openai_api_key()
    if not key:
        raise ValueError("OpenAI API key is not configured (set CACAOPOD_OPENAI_API_KEY or OPENAI_API_KEY).")

    rule_name = _assert_valid_rule_name(name)
    file_list_all_raw = [str(p).strip() for p in files if str(p).strip()]
    if not file_list_all_raw:
        raise ValueError("files must be non-empty")

    def _basename(p: str) -> str:
        return str(p).strip().replace("\\", "/").split("/")[-1].strip()

    file_list_all = [_basename(p) for p in file_list_all_raw if _basename(p)]
    # De-dupe while preserving first occurrence.
    seen_files: set[str] = set()
    file_list_unique: list[str] = []
    for p in file_list_all:
        if p in seen_files:
            continue
        seen_files.add(p)
        file_list_unique.append(p)

    max_files = 20
    if len(file_list_unique) > max_files:
        file_list = random.sample(file_list_unique, k=max_files)
        sampled_note = f"\n(Note: sampled {max_files} files out of {len(file_list_unique)}.)\n"
    else:
        file_list = list(file_list_unique)
        sampled_note = ""

    examples = str(examples_text or "").strip()
    if not examples:
        raise ValueError("examples_text must be non-empty")

    sys = "You write small, correct Python utility functions."
    user = (
        "Create a Python function that converts a file name to a Wave name.\n"
        "\n"
        f"Requirements:\n"
        f"- Output ONLY valid Python source (no markdown, no code fences)\n"
        f"- Define a top-level function named `{rule_name}`\n"
        "- Signature: (file_path: str) -> str  (file_path is typically a file name like 'data_001.csv')\n"
        "- If file_path contains directories, ignore them and use only the basename\n"
        "- Return: a non-empty string name\n"
        "- Name must NOT contain '/' or '\\\\'\n"
        "- Name must NOT contain '@'\n"
        "- Strip whitespace from the result\n"
        "- Do not read files; derive the name only from file_path\n"
        "- Use 2-space indentation\n"
        "- Do NOT add: from __future__ import annotations\n"
        "\n"
        "Examples may include square brackets [] in the *input* example to mark variable segments.\n"
        "- Brackets are NOT part of the real file paths; treat them as annotations.\n"
        "- When matching real file_path values, ignore the brackets and extract the bracketed segments.\n"
        "- Use extracted segments to construct the output name.\n"
        "\n"
        "Use the examples (preferred) to infer the mapping. If a file_path cannot be parsed, raise ValueError.\n"
        "\n"
    )
    if sampled_note:
        user += sampled_note
    user += (
        "Files (filenames):\n"
        + "\n".join(f"- {p}" for p in file_list)
        + "\n\n"
        "User-provided examples (some may be partial):\n"
        + examples
        + "\n"
    )

    payload = {
        "model": model or _openai_model_default(),
        "reasoning": _openai_reasoning(),
        "input": [
            {"role": "system", "content": [{"type": "input_text", "text": sys}]},
            {"role": "user", "content": [{"type": "input_text", "text": user}]},
        ],
    }

    base = _openai_api_base()
    url = f"{base}/v1/responses"
    req = urllib.request.Request(
        url,
        data=json.dumps(payload).encode("utf-8"),
        headers={"authorization": f"Bearer {key}", "content-type": "application/json"},
        method="POST",
    )

    last_err: Exception | None = None
    for attempt in range(2):
        try:
            with urllib.request.urlopen(req, timeout=120) as resp:  # noqa: S310 - trusted local usage
                raw = resp.read().decode("utf-8", errors="replace")
            last_err = None
            break
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            msg = f"OpenAI API error: {exc.code} {exc.reason}: {detail}"
            # Retry a couple of common transient cases.
            if attempt == 0 and exc.code in {429, 500, 502, 503, 504}:
                last_err = ValueError(msg)
                sleep(0.8)
                continue
            raise ValueError(msg) from exc
        except TimeoutError as exc:
            last_err = exc
            if attempt == 0:
                sleep(0.8)
                continue
            raise ValueError(f"OpenAI API timeout: {exc}") from exc
        except urllib.error.URLError as exc:
            last_err = exc
            if attempt == 0:
                sleep(0.8)
                continue
            raise ValueError(f"OpenAI API connection error: {exc}") from exc

    if last_err is not None:  # pragma: no cover
        raise ValueError(f"OpenAI API call failed: {last_err}") from last_err

    data = json.loads(raw)
    text = _extract_openai_output_text(data).strip()
    if not text:
        raise ValueError("OpenAI returned empty response")
    return text
