from __future__ import annotations

import json
import time
from pathlib import Path

from cacaopod.api_models import ToolChatMessage
from cacaopod.config import data_root
from cacaopod.state.paths import safe_storage_key

MAX_TOOL_CHAT_MESSAGES = 60
MAX_TOOL_CHAT_TOTAL_CHARS = 200_000
MAX_TOOL_CHAT_USER_CHARS = 12_000
# Assistant messages are intentionally NOT persisted (user-only history).
MAX_TOOL_CHAT_ASSISTANT_CHARS = 20_000


def _truncate_text(text: str, *, max_chars: int) -> str:
    s = str(text or "")
    if len(s) <= max_chars:
        return s
    head = s[: max(0, max_chars - 40)]
    return head + "\n...(truncated)..."


def _normalize_message(m: ToolChatMessage) -> ToolChatMessage:
    role = "assistant" if str(m.role).strip().lower() == "assistant" else "user"
    max_chars = MAX_TOOL_CHAT_ASSISTANT_CHARS if role == "assistant" else MAX_TOOL_CHAT_USER_CHARS
    content = _truncate_text(str(m.content or "").strip(), max_chars=max_chars)
    return ToolChatMessage(role=role, content=content, ts=int(getattr(m, "ts", 0) or 0))


def tool_chat_root() -> Path:
    root = data_root() / "ui" / "tool_coder_chats"
    root.mkdir(parents=True, exist_ok=True)
    return root


def tool_chat_path(tool_id: str) -> Path:
    safe = safe_storage_key(tool_id, fallback="tool")
    return tool_chat_root() / f"{safe}.json"


def load_tool_chat(tool_id: str) -> list[ToolChatMessage]:
    tool_id_s = str(tool_id or "").strip()
    if not tool_id_s:
        return []
    path = tool_chat_path(tool_id_s)
    if not path.exists():
        return []
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return []

    msgs_raw = raw.get("messages") if isinstance(raw, dict) else raw
    if not isinstance(msgs_raw, list):
        return []

    out: list[ToolChatMessage] = []
    for item in msgs_raw:
        if not isinstance(item, dict):
            continue
        try:
            m = ToolChatMessage.model_validate(item)
        except Exception:  # noqa: BLE001
            continue
        if not str(m.content or "").strip():
            continue
        nm = _normalize_message(m)
        if nm.role != "user":
            continue
        out.append(nm)

    if len(out) > MAX_TOOL_CHAT_MESSAGES:
        out = out[-MAX_TOOL_CHAT_MESSAGES:]
    # Enforce an upper bound to keep UI responsive.
    total = 0
    trimmed: list[ToolChatMessage] = []
    for m in reversed(out):
        total += len(str(m.content or ""))
        if total > MAX_TOOL_CHAT_TOTAL_CHARS:
            break
        trimmed.append(m)
    out = list(reversed(trimmed))
    return out


def save_tool_chat(tool_id: str, messages: list[ToolChatMessage]) -> list[ToolChatMessage]:
    tool_id_s = str(tool_id or "").strip()
    if not tool_id_s:
        return []
    msgs = [
        _normalize_message(m)
        for m in messages
        if str(getattr(m, "content", "") or "").strip() and str(getattr(m, "role", "user") or "").strip().lower() != "assistant"
    ]
    if len(msgs) > MAX_TOOL_CHAT_MESSAGES:
        msgs = msgs[-MAX_TOOL_CHAT_MESSAGES:]
    total = 0
    trimmed: list[ToolChatMessage] = []
    for m in reversed(msgs):
        total += len(str(m.content or ""))
        if total > MAX_TOOL_CHAT_TOTAL_CHARS:
            break
        trimmed.append(m)
    msgs = list(reversed(trimmed))

    path = tool_chat_path(tool_id_s)
    payload = {"version": 1, "tool_id": tool_id_s, "messages": [m.model_dump() for m in msgs]}
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)
    return msgs


def append_tool_chat(tool_id: str, *, role: str, content: str) -> list[ToolChatMessage]:
    tool_id_s = str(tool_id or "").strip()
    if not tool_id_s:
        return []
    if str(role or "").strip().lower() == "assistant":
        return load_tool_chat(tool_id_s)
    text = str(content or "").strip()
    if not text:
        return load_tool_chat(tool_id_s)
    ts = int(time.time() * 1000)
    m = ToolChatMessage(role="assistant" if str(role).strip().lower() == "assistant" else "user", content=text, ts=ts)
    msgs = load_tool_chat(tool_id_s)
    msgs.append(m)
    return save_tool_chat(tool_id_s, msgs)


def clear_tool_chat(tool_id: str) -> None:
    tool_id_s = str(tool_id or "").strip()
    if not tool_id_s:
        return
    path = tool_chat_path(tool_id_s)
    try:
        path.unlink()
    except FileNotFoundError:
        return
    except Exception:  # noqa: BLE001
        return
