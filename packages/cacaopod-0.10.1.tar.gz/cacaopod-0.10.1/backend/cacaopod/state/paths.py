from __future__ import annotations

from pathlib import Path
from typing import Any

from cacaopod.config import data_root


def safe_storage_key(value: Any, *, fallback: str) -> str:  # noqa: ANN401
    safe = "".join(ch for ch in str(value) if ch.isalnum() or ch in ("-", "_"))
    safe = (safe or fallback)[:128]
    return safe


def state_root(kind: str) -> Path:
    root = data_root() / str(kind)
    root.mkdir(parents=True, exist_ok=True)
    return root


def state_dir(kind: str, key: Any, *, create: bool) -> Path:  # noqa: ANN401
    root = state_root(kind)
    safe = safe_storage_key(key, fallback=kind)
    d = root / safe
    if create:
        d.mkdir(parents=True, exist_ok=True)
    return d

