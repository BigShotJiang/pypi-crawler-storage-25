from __future__ import annotations

import json
from pathlib import Path

from cacaopod.api_models import FilesUiState, ToolsRegistry, ViewState
from cacaopod.config import data_root


def ui_root() -> Path:
    root = data_root() / "ui"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _atomic_write_json(path: Path, payload: object) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def view_state_path() -> Path:
    return ui_root() / "view.json"


def load_view_state() -> ViewState:
    path = view_state_path()
    if not path.exists():
        return ViewState()
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return ViewState.model_validate(raw)
    except Exception:  # noqa: BLE001
        return ViewState()


def save_view_state(state: ViewState) -> None:
    _atomic_write_json(view_state_path(), state.model_dump())


def tools_registry_path() -> Path:
    return ui_root() / "tools_registry.json"


def load_tools_registry() -> ToolsRegistry:
    path = tools_registry_path()
    if not path.exists():
        return ToolsRegistry()
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return ToolsRegistry.model_validate(raw)
    except Exception:  # noqa: BLE001
        return ToolsRegistry()


def save_tools_registry(registry: ToolsRegistry) -> None:
    _atomic_write_json(tools_registry_path(), registry.model_dump())


def files_ui_path() -> Path:
    return ui_root() / "files_ui.json"


def load_files_ui_state() -> FilesUiState:
    path = files_ui_path()
    if not path.exists():
        return FilesUiState()
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        return FilesUiState.model_validate(raw)
    except Exception:  # noqa: BLE001
        return FilesUiState()


def save_files_ui_state(state: FilesUiState) -> None:
    _atomic_write_json(files_ui_path(), state.model_dump())


def active_board_path() -> Path:
    # Kept under ui/ because it's UI selection state rather than data.
    return ui_root() / "board.json"
