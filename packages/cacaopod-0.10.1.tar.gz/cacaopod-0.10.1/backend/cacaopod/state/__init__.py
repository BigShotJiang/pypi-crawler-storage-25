"""Persistence helpers for Cacaopod.

Most state is stored under `./.cacaopod/` in the workdir.
"""

from __future__ import annotations
