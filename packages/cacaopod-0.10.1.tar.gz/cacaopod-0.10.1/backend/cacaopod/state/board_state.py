from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from cacaopod.api_models import HeatmapViewSettings, TraceViewSettings
from cacaopod.board import Board, Pod
from cacaopod.wave import Wave, WaveManager
from cacaopod.wave import _load_wave_npz, _save_wave_npz


def save_board_state_to_dir(state_dir: Path, *, board: Board, wave_manager: WaveManager, include_waves: bool) -> None:
    try:
        meta_path = state_dir / "board.json"
        waves_dir = state_dir / "waves"

        untracked_uids: set[str] = set()
        pods_payload: list[dict[str, Any]] = []

        pods = getattr(board, "_pods", None)
        if not isinstance(pods, list):
            return

        for pod in pods:
            wave_refs: list[dict[str, Any]] = []
            for w in getattr(pod, "waves", []) or []:
                wm_path = getattr(w, "_wm_path", None)
                if isinstance(wm_path, str) and wm_path.strip():
                    wave_refs.append({"kind": "wm", "wm_path": f"/{wm_path}", "uid": str(getattr(w, "uid", ""))})
                    continue

                uid = str(getattr(w, "uid", "")).strip()
                if not uid:
                    continue
                wave_refs.append({"kind": "npz", "uid": uid, "file": f"{uid}.npz"})
                untracked_uids.add(uid)

                if include_waves:
                    waves_dir.mkdir(parents=True, exist_ok=True)
                    try:
                        target = waves_dir / f"{uid}.npz"
                        rev = int(getattr(w, "_rev", 0))
                        saved_rev = int(getattr(w, "_saved_rev", -1))
                        if saved_rev == rev and target.exists():
                            pass
                        else:
                            _save_wave_npz(target, w)
                    except Exception:  # noqa: BLE001
                        pass

            ts_by = (
                pod.trace_settings_by_wave
                if isinstance(getattr(pod, "trace_settings_by_wave", None), list) and len(pod.trace_settings_by_wave) == len(pod.waves)
                else [pod.trace_settings for _ in getattr(pod, "waves", []) or []]
            )

            pods_payload.append(
                {
                    "id": str(getattr(pod, "id", "")),
                    "name": str(getattr(pod, "name", "") or ""),
                    "waves": wave_refs,
                    "heatmapSettings": pod.heatmap_settings.model_dump(),
                    "traceSettings": pod.trace_settings.model_dump(),
                    "traceSettingsByWave": [
                        (ts.model_dump() if isinstance(ts, TraceViewSettings) else TraceViewSettings().model_dump()) for ts in ts_by
                    ],
                    "activeWaveIndex": int(getattr(pod, "active_wave_index", 0)),
                }
            )

        selected = int(getattr(board, "_selected_i", getattr(board, "selected", 0)))
        next_pod_number = int(getattr(board, "_next_pod_number", 0) or 0)
        payload = {"version": 3, "selected": selected, "pods": pods_payload, "nextPodNumber": next_pod_number}
        tmp = meta_path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(meta_path)

        if include_waves and waves_dir.exists():
            for p in waves_dir.glob("*.npz"):
                if p.stem not in untracked_uids:
                    try:
                        p.unlink()
                    except Exception:  # noqa: BLE001
                        pass
    except Exception:  # noqa: BLE001
        return


def load_board_state_from_dir(state_dir: Path, *, wave_manager: WaveManager) -> Board | None:
    meta_path = state_dir / "board.json"
    if not meta_path.exists():
        return None
    try:
        raw = json.loads(meta_path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None
    if not isinstance(raw, dict):
        return None

    pods_raw = raw.get("pods")
    if not isinstance(pods_raw, list):
        return None

    waves_dir = state_dir / "waves"

    board = Board()
    board._pods = []  # type: ignore[attr-defined]

    for item in pods_raw:
        if not isinstance(item, dict):
            continue

        pod = Pod()
        cid = item.get("id")
        if isinstance(cid, str) and cid.strip():
            pod.id = cid.strip()

        cname = item.get("name")
        if isinstance(cname, str) and cname.strip():
            pod.name = cname.strip()

        wave_refs = item.get("waves")
        waves: list[Wave] = []
        if isinstance(wave_refs, list):
            for ref in wave_refs:
                if not isinstance(ref, dict):
                    continue
                kind = str(ref.get("kind") or "").strip().lower()
                if kind == "wm":
                    wm_path = ref.get("wm_path")
                    if isinstance(wm_path, str) and wm_path.strip():
                        try:
                            waves.append(wave_manager[wm_path])
                        except KeyError:
                            uid = ref.get("uid")
                            if isinstance(uid, str) and uid.strip():
                                p = waves_dir / f"{uid.strip()}.npz"
                                if p.exists():
                                    try:
                                        waves.append(_load_wave_npz(p, manager=wave_manager, wm_path=None))
                                    except Exception:  # noqa: BLE001
                                        pass
                    continue

                uid = ref.get("uid")
                if not isinstance(uid, str) or not uid.strip():
                    continue
                fname = ref.get("file")
                if isinstance(fname, str) and fname.strip():
                    p = waves_dir / fname.strip()
                else:
                    p = waves_dir / f"{uid.strip()}.npz"
                if not p.exists():
                    continue
                try:
                    waves.append(_load_wave_npz(p, manager=wave_manager, wm_path=None))
                except Exception:  # noqa: BLE001
                    continue

        if waves:
            ndim0 = int(waves[0].ndim)
            waves = [w for w in waves if int(w.ndim) == ndim0]
            try:
                pod.show(waves)
            except Exception:  # noqa: BLE001
                try:
                    pod.show(waves[0])
                except Exception:  # noqa: BLE001
                    pass

        hm_raw = item.get("heatmapSettings") or {}
        if isinstance(hm_raw, dict):
            try:
                pod.heatmap_settings = HeatmapViewSettings.model_validate(hm_raw)
            except Exception:  # noqa: BLE001
                pass

        ts_raw = item.get("traceSettings") or {}
        if isinstance(ts_raw, dict):
            try:
                pod.trace_settings = TraceViewSettings.model_validate(ts_raw)
            except Exception:  # noqa: BLE001
                pass

        ts_by_raw = item.get("traceSettingsByWave")
        parsed_by: list[TraceViewSettings] = []
        if isinstance(ts_by_raw, list):
            for elem in ts_by_raw:
                if not isinstance(elem, dict):
                    continue
                try:
                    parsed_by.append(TraceViewSettings.model_validate(elem))
                except Exception:  # noqa: BLE001
                    parsed_by.append(TraceViewSettings())

        n = len(pod.waves)
        if n > 0:
            if not parsed_by:
                parsed_by = [pod.trace_settings for _ in range(n)]
            parsed_by = parsed_by[:n]
            while len(parsed_by) < n:
                parsed_by.append(TraceViewSettings())
            pod.trace_settings_by_wave = parsed_by
            pod.trace_settings = pod.trace_settings_by_wave[0]

            try:
                ii = int(item.get("activeWaveIndex") or 0)
            except Exception:  # noqa: BLE001
                ii = 0
            pod.active_wave_index = min(max(ii, 0), max(0, n - 1))

        board._pods.append(pod)  # type: ignore[attr-defined]

    try:
        counter = int(raw.get("nextPodNumber") or 0)
    except Exception:  # noqa: BLE001
        counter = 0

    max_auto = -1
    for pod in board._pods:  # type: ignore[attr-defined]
        nm = str(getattr(pod, "name", "") or "").strip()
        if nm.lower().startswith("pod") and nm[3:].isdigit():
            try:
                max_auto = max(max_auto, int(nm[3:]))
            except Exception:  # noqa: BLE001
                pass
    counter = max(counter, max_auto + 1, 0)

    seen: set[str] = set()

    def generate_name() -> str:
        nonlocal counter
        while True:
            candidate = f"pod{counter}"
            counter += 1
            if candidate not in seen:
                return candidate

    for pod in board._pods:  # type: ignore[attr-defined]
        nm = str(getattr(pod, "name", "") or "").strip()
        if not nm or nm in seen:
            nm = generate_name()
        pod.name = nm
        seen.add(nm)
        if nm.lower().startswith("pod") and nm[3:].isdigit():
            try:
                num = int(nm[3:])
            except Exception:  # noqa: BLE001
                continue
            if num + 1 > counter:
                counter = num + 1

    board._next_pod_number = counter  # type: ignore[attr-defined]

    try:
        selected = int(raw.get("selected") or 0)
    except Exception:  # noqa: BLE001
        selected = 0
    if not board._pods:  # type: ignore[attr-defined]
        board._selected_i = 0  # type: ignore[attr-defined]
    else:
        board._selected_i = max(0, min(selected, len(board._pods) - 1))  # type: ignore[attr-defined]

    try:
        board._attach_all_pods()  # type: ignore[attr-defined]
        board._rebuild_wave_share_index()  # type: ignore[attr-defined]
    except Exception:  # noqa: BLE001
        pass

    return board
