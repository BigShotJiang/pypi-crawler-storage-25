from __future__ import annotations

import json
import time
import uuid
from pathlib import Path
from typing import Any

from cacaopod.api_models import BoardSummary
from cacaopod.board import Board
from cacaopod.state.board_state import load_board_state_from_dir, save_board_state_to_dir
from cacaopod.state.paths import state_dir, state_root
from cacaopod.state.ui_state import active_board_path
from cacaopod.wave import WaveManager


def boards_root() -> Path:
    return state_root("boards")


def boards_index_path() -> Path:
    return boards_root() / "index.json"


def _merge_boards_from_dirs(items: list[dict[str, Any]]) -> tuple[list[dict[str, Any]], bool, bool]:
    seen: set[str] = set()
    out: list[dict[str, Any]] = []
    for item in items:
        if not isinstance(item, dict):
            continue
        bid = item.get("id")
        if isinstance(bid, str) and bid.strip():
            out.append(dict(item))
            seen.add(bid.strip())

    changed = False
    ok = True
    try:
        root = boards_root()
    except Exception:  # noqa: BLE001
        return out, changed, False

    try:
        if root.exists():
            for entry in root.iterdir():
                if not entry.is_dir():
                    continue
                board_json = entry / "board.json"
                if not board_json.exists():
                    continue
                bid = entry.name.strip()
                if not bid or bid in seen:
                    continue
                ts = int(board_json.stat().st_mtime * 1000)
                out.append({"id": bid, "name": bid, "ts": ts, "updated": ts})
                seen.add(bid)
                changed = True
    except Exception:  # noqa: BLE001
        ok = False

    return out, changed, ok


def load_boards_index_status() -> tuple[list[dict[str, Any]], bool]:
    path = boards_index_path()
    raw_items: list[dict[str, Any]] = []
    ok = True
    if path.exists():
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                raw = raw.get("boards")
            if isinstance(raw, list):
                for item in raw:
                    if isinstance(item, dict):
                        raw_items.append(dict(item))
        except Exception:  # noqa: BLE001
            raw_items = []
            ok = False

    items, changed, ok_dirs = _merge_boards_from_dirs(raw_items)
    ok = ok and ok_dirs
    if changed and items and ok:
        try:
            save_boards_index(items)
        except Exception:  # noqa: BLE001
            pass
    return items, ok


def load_boards_index() -> list[dict[str, Any]]:
    items, _ok = load_boards_index_status()
    return items


def save_boards_index(items: list[dict[str, Any]]) -> None:
    path = boards_index_path()
    tmp = path.with_suffix(".tmp")
    payload = {"version": 1, "boards": items}
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def load_active_board_id() -> str | None:
    path = active_board_path()
    if not path.exists():
        return None
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return None
    if isinstance(raw, str):
        s = raw.strip()
        return s or None
    if not isinstance(raw, dict):
        return None
    v = raw.get("activeId") or raw.get("id")
    if isinstance(v, str) and v.strip():
        return v.strip()
    return None


def save_active_board_id(board_id: str) -> None:
    path = active_board_path()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps({"activeId": board_id}, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def board_state_dir(board_id: str, *, create: bool) -> Path:
    return state_dir("boards", board_id, create=create)


def boards_summaries(items: list[dict[str, Any]]) -> list[BoardSummary]:
    out: list[BoardSummary] = []
    for item in items:
        bid = item.get("id")
        name = item.get("name")
        if not isinstance(bid, str) or not bid.strip():
            continue
        name_s = name.strip() if isinstance(name, str) and name.strip() else bid.strip()
        try:
            ts = int(item.get("ts") or 0)
        except Exception:  # noqa: BLE001
            ts = 0
        try:
            updated = int(item.get("updated") or ts or 0)
        except Exception:  # noqa: BLE001
            updated = ts
        out.append(BoardSummary(id=bid.strip(), name=name_s, ts=ts, updated=updated))
    out.sort(key=lambda b: (b.updated, b.ts, b.name.lower()), reverse=True)
    return out


def create_board_record(items: list[dict[str, Any]], *, name: str) -> str:
    bid = uuid.uuid4().hex
    now = int(time.time() * 1000)
    items.append({"id": bid, "name": name.strip() if name.strip() else "Board", "ts": now, "updated": now})
    save_boards_index(items)
    board_state_dir(bid, create=True)
    return bid


def ensure_active_board_id() -> str:
    items, ok = load_boards_index_status()
    ids = {str(item.get("id")).strip() for item in items if isinstance(item.get("id"), str) and item.get("id").strip()}

    active = load_active_board_id()
    if active is not None and active not in ids:
        active = None

    if not ids:
        if not ok:
            return active or "volatile"
        active = create_board_record(items, name="Default")
        save_active_board_id(active)
        return active

    if active is None:
        summaries = boards_summaries(items)
        active = summaries[0].id if summaries else next(iter(ids))
        if ok:
            save_active_board_id(active)

    if ok:
        board_state_dir(active, create=True)
    return active


def bump_board_updated(board_id: str, *, now_ms: int | None = None) -> None:
    now = int(time.time() * 1000) if now_ms is None else int(now_ms)
    items = load_boards_index()
    changed = False
    for item in items:
        if str(item.get("id") or "").strip() != board_id:
            continue
        try:
            prev = int(item.get("updated") or item.get("ts") or 0)
        except Exception:  # noqa: BLE001
            prev = 0
        if now - prev < 1000:
            return
        item["updated"] = now
        changed = True
        break
    if changed:
        save_boards_index(items)


def save_board_state(board_id: str, *, board: Board, wave_manager: WaveManager, include_waves: bool) -> None:
    d = board_state_dir(board_id, create=True)
    save_board_state_to_dir(d, board=board, wave_manager=wave_manager, include_waves=include_waves)
    bump_board_updated(board_id)


def load_board_state(board_id: str, *, wave_manager: WaveManager) -> Board | None:
    d = board_state_dir(board_id, create=False)
    return load_board_state_from_dir(d, wave_manager=wave_manager)
