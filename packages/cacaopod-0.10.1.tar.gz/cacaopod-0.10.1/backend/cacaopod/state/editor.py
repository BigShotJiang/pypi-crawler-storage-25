from __future__ import annotations

import json
from pathlib import Path

from cacaopod.api_models import CodeHistoryEntry
from cacaopod.config import data_root


def editor_state_path(session_id: str) -> Path:
    editor_root = data_root() / "editor"
    editor_root.mkdir(parents=True, exist_ok=True)
    # Keep editor history stable across browser sessions / machines.
    # Previously this was stored per-session-id, which made history "disappear"
    # when the cookie changed (e.g., switching between localhost and 127.0.0.1).
    return editor_root / "history.json"


def _load_state_from_path(path: Path) -> tuple[str, list[CodeHistoryEntry]]:
    if not path.exists():
        return "", []
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return "", []

    if not isinstance(data, dict):
        return "", []

    code = data.get("last_code")
    if not isinstance(code, str):
        code = ""

    history_raw = data.get("history")
    if not isinstance(history_raw, list):
        history_raw = []

    history: list[CodeHistoryEntry] = []
    for item in history_raw:
        if not isinstance(item, dict):
            continue
        try:
            entry = CodeHistoryEntry.model_validate(item)
        except Exception:  # noqa: BLE001
            continue
        if not entry.code.strip():
            continue
        history.append(entry)

    return code, history


def load_editor_state(session_id: str) -> tuple[str, list[CodeHistoryEntry]]:
    path = editor_state_path(session_id)
    code, history = _load_state_from_path(path)
    if code.strip() or history:
        return code, history

    # Migration: merge legacy per-session editor files if the new global file is missing/empty.
    editor_root = path.parent
    candidates = [p for p in editor_root.glob("*.json") if p.name != path.name]
    if not candidates:
        return code, history

    merged: dict[str, CodeHistoryEntry] = {}
    last_code_candidates: list[tuple[float, str]] = []
    for p in candidates:
        c, entries = _load_state_from_path(p)
        try:
            mtime = float(p.stat().st_mtime)
        except Exception:  # noqa: BLE001
            mtime = 0.0
        if isinstance(c, str) and c.strip():
            last_code_candidates.append((mtime, c))
        for e in entries:
            prev = merged.get(e.id)
            if prev is None:
                merged[e.id] = e
                continue
            if int(getattr(e, "ts", 0) or 0) > int(getattr(prev, "ts", 0) or 0):
                merged[e.id] = e
                continue
            if int(getattr(e, "ts", 0) or 0) == int(getattr(prev, "ts", 0) or 0) and bool(
                getattr(e, "favorite", False)
            ) and not bool(getattr(prev, "favorite", False)):
                merged[e.id] = e

    history = sorted(merged.values(), key=lambda e: int(getattr(e, "ts", 0) or 0), reverse=True)
    if not code.strip() and history:
        code = history[0].code
    if not code.strip() and last_code_candidates:
        last_code_candidates.sort(key=lambda it: it[0], reverse=True)
        code = last_code_candidates[0][1]

    save_editor_state(session_id, last_code=code, history=history)
    return code, history


def save_editor_state(session_id: str, *, last_code: str, history: list[CodeHistoryEntry]) -> None:
    try:
        path = editor_state_path(session_id)
        payload = {
            "last_code": last_code,
            "history": [e.model_dump() for e in history],
        }
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
        tmp.replace(path)
    except Exception:  # noqa: BLE001
        return
