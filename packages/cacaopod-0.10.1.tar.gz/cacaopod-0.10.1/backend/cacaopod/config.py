from __future__ import annotations

import os
import threading
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

DATA_DIRNAME = ".cacaopod"

SKIP_DIR_NAMES = {
    ".git",
    ".hg",
    ".svn",
    "__pycache__",
    "node_modules",
    DATA_DIRNAME,
}

_CWD_LOCK = threading.Lock()


def workdir() -> Path:
    raw = os.environ.get("CACAOPOD_WORKDIR")
    if raw:
        return Path(raw).expanduser().resolve()
    return Path.cwd().resolve()


def data_root_for(base: Path) -> Path:
    return base / DATA_DIRNAME


def data_root() -> Path:
    return data_root_for(workdir())


def resolve_under_workdir(rel: str | Path) -> Path:
    base = workdir()
    raw = str(rel).strip()
    if raw in {"", "."}:
        return base
    p = (base / raw).expanduser().resolve()
    if not p.is_relative_to(base):
        raise ValueError("path must be under workdir")
    return p


@contextmanager
def in_workdir(path: Path) -> Iterator[None]:
    with _CWD_LOCK:
        prev = Path.cwd()
        os.chdir(path)
        try:
            yield
        finally:
            os.chdir(prev)


def frontend_dist_dir() -> Path | None:
    override = os.environ.get("CACAOPOD_FRONTEND_DIST")
    if override:
        p = Path(override).expanduser().resolve()
        return p if p.exists() else None

    # Source checkout layout: <repo>/frontend/dist
    source_dist = Path(__file__).resolve().parents[2] / "frontend" / "dist"
    if source_dist.exists():
        return source_dist

    # Installed package layout (optional): <site-packages>/cacaopod/web/dist
    packaged_dist = Path(__file__).resolve().parent / "web" / "dist"
    if packaged_dist.exists():
        return packaged_dist

    return None
