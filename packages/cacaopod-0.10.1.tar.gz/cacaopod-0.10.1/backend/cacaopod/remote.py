from __future__ import annotations

import base64
import io
import json
from dataclasses import dataclass
from typing import Any
from urllib import parse, request


def _json_dumps(payload: Any) -> bytes:  # noqa: ANN401
    return json.dumps(payload, ensure_ascii=False).encode("utf-8")


class RemoteError(RuntimeError):
    pass


class _HttpClient:
    def __init__(self, base_url: str, *, timeout: float = 30.0) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout
        self._cookies = request.HTTPCookieProcessor()
        self._opener = request.build_opener(self._cookies)

    def _url(self, path: str, params: dict[str, Any] | None = None) -> str:
        url = f"{self.base_url}{path}"
        if params:
            qs = parse.urlencode(params)
            url = f"{url}?{qs}"
        return url

    def request_json(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        payload: dict[str, Any] | None = None,
    ) -> Any:  # noqa: ANN401
        url = self._url(path, params=params)
        data = _json_dumps(payload) if payload is not None else None
        headers = {"Content-Type": "application/json"} if data is not None else {}
        req = request.Request(url, data=data, headers=headers, method=method)
        try:
            with self._opener.open(req, timeout=self.timeout) as resp:
                body = resp.read()
                if not body:
                    return None
                ctype = resp.headers.get("content-type", "")
                if "application/json" in ctype:
                    return json.loads(body.decode("utf-8"))
                return body
        except Exception as exc:  # noqa: BLE001
            raise RemoteError(str(exc)) from exc


def _encode_array(arr: Any) -> str:  # noqa: ANN401
    import numpy as np

    buf = io.BytesIO()
    np.save(buf, np.asarray(arr), allow_pickle=False)
    return base64.b64encode(buf.getvalue()).decode("ascii")


def _normalize_rel_path(p: str) -> str:
    s = str(p or "").strip().replace("\\", "/")
    while s.startswith("./"):
        s = s[2:]
    s = s.lstrip("/")
    parts = [part for part in s.split("/") if part not in ("", ".")]
    return "/".join(parts)


def _iter_pods_from_run_response(resp: dict[str, Any]) -> list[dict[str, Any]]:
    pods: list[dict[str, Any]] = []
    snap = resp.get("board")
    if isinstance(snap, dict):
        raw_pods = snap.get("pods")
        if isinstance(raw_pods, list):
            for p in raw_pods:
                if isinstance(p, dict):
                    pods.append(p)
    patch = resp.get("boardPatch")
    if isinstance(patch, dict):
        append_pods = patch.get("appendPods")
        if isinstance(append_pods, list):
            for p in append_pods:
                if isinstance(p, dict):
                    pods.append(p)
        pod_patches = patch.get("pods")
        if isinstance(pod_patches, list):
            for pp in pod_patches:
                if not isinstance(pp, dict):
                    continue
                pod = pp.get("pod")
                if isinstance(pod, dict):
                    pods.append(pod)
    return pods


def _extract_wave_uid_from_run_response(resp: dict[str, Any], *, description: str | None, name: str | None) -> str | None:
    wanted_desc = str(description or "").strip()
    wanted_name = str(name or "").strip()
    pods = _iter_pods_from_run_response(resp)

    def waves_in_pod(pod: dict[str, Any]) -> list[dict[str, Any]]:
        raw = pod.get("waves")
        return [w for w in raw if isinstance(w, dict)] if isinstance(raw, list) else []

    if wanted_desc:
        for pod in pods:
            for w in waves_in_pod(pod):
                if str(w.get("description") or "").strip() != wanted_desc:
                    continue
                uid = w.get("uid")
                if isinstance(uid, str) and uid.strip():
                    return uid.strip()

    if wanted_name:
        for pod in pods:
            for w in waves_in_pod(pod):
                if str(w.get("name") or "").strip() != wanted_name:
                    continue
                uid = w.get("uid")
                if isinstance(uid, str) and uid.strip():
                    return uid.strip()

    for pod in pods:
        for w in waves_in_pod(pod):
            uid = w.get("uid")
            if isinstance(uid, str) and uid.strip():
                return uid.strip()
    return None


@dataclass
class LoadResult:
    uid: str | None
    error: str | None = None
    msg: str = ""
    response: dict[str, Any] | None = None

    @property
    def ok(self) -> bool:
        return self.error is None

    def __bool__(self) -> bool:  # pragma: no cover
        return self.ok


@dataclass
class RemoteBoard:
    _client: _HttpClient

    def __getitem__(self, key: int | str) -> "RemotePod":
        return RemotePod(self._client, key)

    def snapshot(self) -> dict[str, Any]:
        return self._client.request_json("GET", "/api/board")

    def add(self) -> dict[str, Any]:
        return self._client.request_json("POST", "/api/board/add")

    def clear(self) -> dict[str, Any]:
        return self._client.request_json("POST", "/api/board/clear")

    def remove(self, index: int) -> dict[str, Any]:
        return self._client.request_json("POST", "/api/board/remove", payload={"selection": {"i": int(index)}})

    def show_array(
        self,
        array: Any,  # noqa: ANN401
        *,
        name: str | None = None,
        selection: int | None = None,
        new_pod: bool = False,
        append: bool = False,
    ) -> dict[str, Any]:
        b64 = _encode_array(array)
        lines = [
            "import base64, io, numpy as np",
            "_data = base64.b64decode(" + repr(b64) + ")",
            "_arr = np.load(io.BytesIO(_data), allow_pickle=False)",
            "_w = Wave(_arr)",
        ]
        if name:
            lines.append(f"_w.name = {name!r}")
        if new_pod:
            lines.append("board.add(_w)")
        else:
            if append:
                lines.append("board.append(_w)")
            else:
                lines.append("board.show(_w)")
        code = "\n".join(lines)
        payload: dict[str, Any] = {"code": code}
        if selection is not None:
            payload["selection"] = {"i": int(selection)}
        return self._client.request_json("POST", "/api/run", payload=payload)

    def show(
        self,
        array: Any,  # noqa: ANN401
        *,
        name: str | None = None,
        selection: int | None = None,
        new_pod: bool = False,
        append: bool = False,
    ) -> dict[str, Any]:
        return self.show_array(array, name=name, selection=selection, new_pod=new_pod, append=append)


@dataclass
class RemotePod:
    _client: _HttpClient
    key: int | str

    def _resolve_index(self) -> int:
        board = self._client.request_json("GET", "/api/board")
        if not isinstance(board, dict):
            raise RemoteError("failed to load board snapshot")
        pods = board.get("pods")
        if not isinstance(pods, list):
            raise RemoteError("invalid board snapshot")

        if isinstance(self.key, int):
            idx = int(self.key)
            if idx < 0 or idx >= len(pods):
                raise RemoteError(f"pod index out of range: {idx} for n={len(pods)}")
            return idx

        name = str(self.key or "").strip()
        if not name:
            raise RemoteError("pod name is empty")
        for i, pod in enumerate(pods):
            if not isinstance(pod, dict):
                continue
            if str(pod.get("name") or "").strip() == name:
                return i
        raise RemoteError(f"pod not found: {name!r}")

    def show(self, value: Any, *, name: str | None = None) -> dict[str, Any]:  # noqa: ANN401
        idx = self._resolve_index()
        if isinstance(value, str):
            return self._client.request_json(
                "POST",
                "/api/waves/show",
                payload={"wave_path": value, "selection": {"i": int(idx)}, "new_pod": False, "append_pod": False},
            )

        b64 = _encode_array(value)
        lines = [
            "import base64, io, numpy as np",
            "_data = base64.b64decode(" + repr(b64) + ")",
            "_arr = np.load(io.BytesIO(_data), allow_pickle=False)",
            "_w = Wave(_arr)",
        ]
        if name:
            lines.append(f"_w.name = {name!r}")
        lines.append(f"board[{idx}].show(_w)")
        code = "\n".join(lines)
        return self._client.request_json("POST", "/api/run", payload={"code": code, "selection": {"i": int(idx)}})

    def append(self, value: Any, *, name: str | None = None) -> dict[str, Any]:  # noqa: ANN401
        idx = self._resolve_index()
        if isinstance(value, str):
            return self._client.request_json(
                "POST",
                "/api/waves/show",
                payload={"wave_path": value, "selection": {"i": int(idx)}, "new_pod": False, "append_pod": True},
            )

        b64 = _encode_array(value)
        lines = [
            "import base64, io, numpy as np",
            "_data = base64.b64decode(" + repr(b64) + ")",
            "_arr = np.load(io.BytesIO(_data), allow_pickle=False)",
            "_w = Wave(_arr)",
        ]
        if name:
            lines.append(f"_w.name = {name!r}")
        lines.append(f"board[{idx}].append(_w)")
        code = "\n".join(lines)
        return self._client.request_json("POST", "/api/run", payload={"code": code, "selection": {"i": int(idx)}})


@dataclass
class RemoteFiles:
    _client: _HttpClient

    def load(
        self,
        file_path: str,
        *,
        selection: int | None = None,
        new_pod: bool = False,
        append: bool = False,
        name: str | None = None,
        allow_overwrite: bool = False,
        loader: dict[str, str] | None = None,
        naming_rule: dict[str, str] | None = None,
        kwargs: dict[str, Any] | None = None,  # noqa: ANN401
    ) -> LoadResult:
        payload: dict[str, Any] = {
            "file_path": file_path,
            "new_pod": bool(new_pod),
            "append_pod": bool(append),
            "name": name,
            "allow_overwrite": bool(allow_overwrite),
            "loader": loader,
            "naming_rule": naming_rule,
            "kwargs": kwargs or {},
        }
        if selection is not None:
            payload["selection"] = {"i": int(selection)}
        try:
            resp = self._client.request_json("POST", "/api/files/load", payload=payload)
        except Exception as exc:  # noqa: BLE001
            return LoadResult(uid=None, error=str(exc), msg=str(exc) or "Error.")
        if not isinstance(resp, dict):
            return LoadResult(uid=None, error="invalid response", msg="invalid response")
        status = str(resp.get("status") or "").strip().lower()
        err = resp.get("error")
        msg = "Loaded." if status == "ok" else "Error."
        error_msg = None
        if status != "ok":
            if isinstance(err, dict):
                error_msg = str(err.get("message") or "").strip() or "error"
            else:
                error_msg = "error"
            msg = error_msg
        uid = None
        if status == "ok":
            uid = _extract_wave_uid_from_run_response(resp, description=_normalize_rel_path(file_path), name=name)
        return LoadResult(uid=uid, error=error_msg, msg=msg, response=resp)


@dataclass
class RemoteTools:
    _client: _HttpClient

    def list(self) -> dict[str, Any]:
        return self._client.request_json("GET", "/api/tools")

    def run(
        self,
        name: str,
        *,
        wave: str | None = None,
        uid: str | None = None,
        kwargs: dict[str, Any] | None = None,  # noqa: ANN401
        **compat: Any,  # noqa: ANN401
    ) -> dict[str, Any]:
        tool_name = str(name or "").strip()
        if not tool_name:
            raise RemoteError("tool name is required")

        if wave is None and "wave_name" in compat:
            wave = compat.get("wave_name")

        wave_name = str(wave or "").strip() if uid is None else ""
        wave_uid = str(uid or "").strip() if uid is not None else ""
        if not wave_name and not wave_uid:
            raise RemoteError("wave name or uid is required")

        board = self._client.request_json("GET", "/api/board")
        if not isinstance(board, dict) or not isinstance(board.get("pods"), list):
            raise RemoteError("failed to load board snapshot")

        def find_in_board() -> tuple[int, int] | None:
            pods = board.get("pods") or []
            selected_i = int((board.get("selected") or {}).get("i") or 0) if isinstance(board.get("selected"), dict) else 0
            idxs = list(range(len(pods)))
            if 0 <= selected_i < len(pods):
                idxs = [selected_i] + [i for i in idxs if i != selected_i]
            for pi in idxs:
                pod = pods[pi]
                if not isinstance(pod, dict):
                    continue
                waves = pod.get("waves")
                if not isinstance(waves, list):
                    continue
                for wi, w in enumerate(waves):
                    if not isinstance(w, dict):
                        continue
                    if wave_uid and str(w.get("uid") or "").strip() == wave_uid:
                        return pi, wi
                    if wave_name and str(w.get("name") or "").strip() == wave_name:
                        return pi, wi
            return None

        found = find_in_board()
        if found is None:
            if wave_uid and not wave_name:
                boards = self._client.request_json("GET", "/api/boards")
                active_id = ""
                if isinstance(boards, dict):
                    active_id = str(boards.get("activeId") or "").strip()
                params = {"board_id": active_id} if active_id else None
                waves = self._client.request_json("GET", "/api/waves", params=params)
                if isinstance(waves, dict):
                    for item in waves.get("waves") or []:
                        if not isinstance(item, dict):
                            continue
                        if str(item.get("uid") or "").strip() == wave_uid:
                            wave_name = str(item.get("name") or "").strip()
                            break
                if not wave_name:
                    raise RemoteError(f"wave uid not found in active board: {wave_uid!r}")

            # Add the wave to a new pod in this session, then re-scan.
            self._client.request_json(
                "POST",
                "/api/waves/show",
                payload={"wave_path": wave_name, "selection": {"i": 0}, "new_pod": True, "append_pod": False},
            )
            board = self._client.request_json("GET", "/api/board")
            if not isinstance(board, dict) or not isinstance(board.get("pods"), list):
                raise RemoteError("failed to load board snapshot after show")
            found = find_in_board()
            if found is None:
                raise RemoteError("wave is not visible on board")

        pod_i, wave_i = found
        payload: dict[str, Any] = {"name": tool_name, "selection": {"i": int(pod_i)}, "kwargs": kwargs or {}, "waveIndex": int(wave_i)}
        return self._client.request_json("POST", "/api/tools/run", payload=payload)


@dataclass
class RemoteBoards:
    _client: _HttpClient

    def list(self) -> dict[str, Any]:
        return self._client.request_json("GET", "/api/boards")

    def create(self, name: str = "") -> dict[str, Any]:
        return self._client.request_json("POST", "/api/boards/new", payload={"name": name})

    def switch(self, board_id: str) -> dict[str, Any]:
        return self._client.request_json("POST", "/api/boards/switch", payload={"id": board_id})

    def rename(self, board_id: str, name: str) -> dict[str, Any]:
        return self._client.request_json("POST", "/api/boards/rename", payload={"id": board_id, "name": name})


@dataclass
class RemoteWaves:
    _client: _HttpClient

    def list(self) -> dict[str, Any]:
        boards = self._client.request_json("GET", "/api/boards")
        active_id = ""
        if isinstance(boards, dict):
            active_id = str(boards.get("activeId") or "").strip()
        params = {"board_id": active_id} if active_id else None
        return self._client.request_json("GET", "/api/waves", params=params)

    def show(self, wave_name: str, *, selection: int | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {"wave_path": wave_name}
        if selection is not None:
            payload["selection"] = {"i": int(selection)}
        return self._client.request_json("POST", "/api/waves/show", payload=payload)


@dataclass
class CacaopodClient:
    base_url: str = "http://127.0.0.1:8123"
    timeout: float = 30.0

    def __post_init__(self) -> None:
        self._http = _HttpClient(self.base_url, timeout=self.timeout)
        self.board = RemoteBoard(self._http)
        self.files = RemoteFiles(self._http)
        self.tools = RemoteTools(self._http)
        self.boards = RemoteBoards(self._http)
        self.waves = RemoteWaves(self._http)

    def run(self, code: str, *, selection: int | None = None) -> dict[str, Any]:
        payload: dict[str, Any] = {"code": code}
        if selection is not None:
            payload["selection"] = {"i": int(selection)}
        return self._http.request_json("POST", "/api/run", payload=payload)

    def ping(self) -> dict[str, Any]:
        return self._http.request_json("GET", "/api/ping")


def connect(base_url: str | None = None, *, timeout: float = 30.0) -> CacaopodClient:
    if base_url is not None and str(base_url).strip():
        return CacaopodClient(base_url=str(base_url).strip(), timeout=timeout)

    host = "127.0.0.1"
    ports = [8123, 8124, 8125, 8126]
    probe_timeout = max(0.2, min(float(timeout), 1.0))

    last_error: str | None = None
    for port in ports:
        url = f"http://{host}:{port}"
        try:
            probe = CacaopodClient(base_url=url, timeout=probe_timeout)
            resp = probe.ping()
            if isinstance(resp, dict):
                status = str(resp.get("status") or "").strip().lower()
                if status == "ok":
                    return CacaopodClient(base_url=url, timeout=timeout)
        except Exception as exc:  # noqa: BLE001
            last_error = str(exc)
            continue

    detail = f" ({last_error})" if last_error else ""
    raise RemoteError(f"Could not connect to cacaopod backend on {host}:{ports[0]}..{ports[-1]}{detail}")
