from __future__ import annotations

import io
import json
import fnmatch
import uuid
from pathlib import Path
from typing import Any, Callable

import numpy as np

from cacaopod.sort_utils import alphanumeric


def _jsonable(value: Any) -> Any:  # noqa: ANN401
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return str(value)


def _is_pandas_dataframe(value: Any) -> bool:  # noqa: ANN401
    cls = getattr(value, "__class__", None)
    if cls is None:
        return False
    return getattr(cls, "__name__", "") == "DataFrame" and str(getattr(cls, "__module__", "")).startswith("pandas")


class _ManagedDict(dict[str, Any]):
    def __init__(self, *args: Any, touch: Callable[[], None], **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._touch = touch

    def __setitem__(self, key: str, value: Any) -> None:  # noqa: ANN401
        super().__setitem__(key, value)
        self._touch()

    def __delitem__(self, key: str) -> None:
        super().__delitem__(key)
        self._touch()

    def clear(self) -> None:
        super().clear()
        self._touch()

    def pop(self, key: str, default: Any = None) -> Any:  # noqa: ANN401
        v = super().pop(key, default)
        self._touch()
        return v

    def popitem(self) -> tuple[str, Any]:  # noqa: ANN401
        kv = super().popitem()
        self._touch()
        return kv

    def setdefault(self, key: str, default: Any = None) -> Any:  # noqa: ANN401
        if key in self:
            return self[key]
        self[key] = default
        return default

    def update(self, *args: Any, **kwargs: Any) -> None:
        super().update(*args, **kwargs)
        self._touch()


class DataManager:
    def __init__(self, root_dir: Path) -> None:
        self._root_dir = root_dir
        self._items: dict[str, Any] = {}
        self._path_to_uid: dict[str, str] = {}
        self._dirty_uids: set[str] = set()
        self._index_dirty = False
        self._active_board_id: str = ""
        self._board_id_to_name: dict[str, str] = {}
        self._board_name_to_id: dict[str, str] = {}
        self._board_name_to_id_lower: dict[str, str] = {}
        self._load_index_json()

    @property
    def root_dir(self) -> Path:
        return self._root_dir

    @property
    def active_board_id(self) -> str:
        return self._active_board_id

    @property
    def active_board_name(self) -> str:
        bid = str(self._active_board_id or "").strip()
        if not bid:
            return ""
        return str(self._board_id_to_name.get(bid) or "").strip() or bid

    def set_active_board(self, board_id: str) -> None:
        self._active_board_id = str(board_id or "").strip()

    def set_board_index(self, board_id_to_name: dict[str, str]) -> None:
        cleaned_id_to_name: dict[str, str] = {}
        name_to_id: dict[str, str] = {}
        name_to_id_lower: dict[str, str] = {}

        for bid_raw, name_raw in (board_id_to_name or {}).items():
            bid = str(bid_raw or "").strip()
            if not bid:
                continue
            name = str(name_raw or "").strip()
            cleaned_id_to_name[bid] = name
            if name:
                name_to_id.setdefault(name, bid)
                name_to_id_lower.setdefault(name.lower(), bid)

        self._board_id_to_name = cleaned_id_to_name
        self._board_name_to_id = name_to_id
        self._board_name_to_id_lower = name_to_id_lower

    def _key_for(self, board_id: str, data_name: str) -> str:
        bid = str(board_id or "").strip()
        if not bid:
            raise RuntimeError("DataManager active board is not set")
        return f"{bid}/{data_name}"

    def _load_index_json(self) -> None:
        path = self._root_dir / "index.json"
        if not path.exists():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return
        if not isinstance(data, dict):
            return
        raw = data.get("by_path")
        if not isinstance(raw, dict):
            return
        loaded: dict[str, str] = {}
        for k, v in raw.items():
            if not isinstance(k, str) or not isinstance(v, str):
                continue
            key = k.strip().strip("/")
            uid = v.strip()
            if not key or not uid:
                continue
            loaded[key] = uid
        self._path_to_uid = loaded

    def _touch(self, uid: str) -> None:
        if uid in self._items:
            self._dirty_uids.add(uid)

    def _load_uid(self, uid: str) -> Any:  # noqa: ANN401
        item = self._items.get(uid)
        if item is not None:
            return item

        json_path = self._root_dir / f"{uid}.json"
        if not json_path.exists():
            raise KeyError(uid)
        try:
            payload = json.loads(json_path.read_text(encoding="utf-8"))
        except Exception as exc:  # noqa: BLE001
            raise KeyError(uid) from exc
        if not isinstance(payload, dict):
            raise KeyError(uid)

        kind = str(payload.get("kind") or "").strip().lower()
        data = payload.get("data")

        if kind == "dataframe":
            try:
                import pandas as pd  # type: ignore[import-not-found]
            except Exception as exc:  # noqa: BLE001
                raise RuntimeError("pandas is required to load stored DataFrame objects") from exc
            if not isinstance(data, str):
                raise KeyError(uid)
            item = pd.read_json(io.StringIO(data), orient="split")
        elif kind == "dict":
            item = _ManagedDict(data or {}, touch=lambda: self._touch(uid)) if isinstance(data, dict) else _ManagedDict(touch=lambda: self._touch(uid))
        elif kind == "scalar":
            item = data
        else:
            raise KeyError(uid)

        self._items[uid] = item
        return item

    def __getitem__(self, name: str) -> Any:  # noqa: ANN401
        raw = str(name).strip()
        if not raw:
            raise KeyError(name)

        # Absolute internal ref: "/<board_id>/<data_name>"
        if raw.startswith("/"):
            ref = raw.lstrip("/").strip()
            if "/" in ref:
                board_id, data_name = ref.split("/", 1)
                board_id = board_id.strip()
                data_name = data_name.strip()
                if not board_id or not data_name:
                    raise KeyError(name)
                path = self._key_for(board_id, data_name)
                uid = self._path_to_uid.get(path)
                if uid is None:
                    raise KeyError(name)
                item = self._load_uid(uid)
                if _is_pandas_dataframe(item):
                    self._dirty_uids.add(uid)
                return item
            raw = ref

        # User ref: "data_name" (active board) or "data_name@board_name"
        data_name = raw
        board_id = str(self._active_board_id or "").strip()
        if "@" in raw:
            left, right = raw.rsplit("@", 1)
            data_name = left.strip()
            board_name = right.strip()
            if not data_name or not board_name:
                raise KeyError(name)
            board_id = self._board_name_to_id.get(board_name) or self._board_name_to_id_lower.get(board_name.lower()) or ""
            if not board_id:
                raise KeyError(name)

        if not board_id:
            raise KeyError(name)

        path = self._key_for(board_id, data_name)
        uid = self._path_to_uid.get(path)
        if uid is None:
            raise KeyError(name)
        item = self._load_uid(uid)
        if _is_pandas_dataframe(item):
            self._dirty_uids.add(uid)
        return item

    def __setitem__(self, name: str, value: Any) -> None:  # noqa: ANN401
        raw = str(name).strip()
        if not raw:
            raise KeyError(name)

        board_id = str(self._active_board_id or "").strip()
        data_name = raw
        if "@" in raw:
            left, right = raw.rsplit("@", 1)
            data_name = left.strip()
            board_name = right.strip()
            if not data_name or not board_name:
                raise KeyError(name)
            board_id = self._board_name_to_id.get(board_name) or self._board_name_to_id_lower.get(board_name.lower()) or ""
            if not board_id:
                raise KeyError(name)

        n = str(data_name).strip()
        if not n:
            raise ValueError("data name must be non-empty")
        if "/" in n or "\\" in n:
            raise ValueError("data name must not contain path separators ('/')")
        if "@" in n:
            raise ValueError("data name must not contain '@' (reserved for board selection: name@board)")

        if not board_id:
            raise RuntimeError("DataManager active board is not set")

        if value is None:
            raise TypeError("DataManager does not support storing None (use a scalar or dict)")

        path = self._key_for(board_id, n)
        uid = self._path_to_uid.get(path)
        if uid is None:
            uid = uuid.uuid4().hex
            self._path_to_uid[path] = uid
            self._index_dirty = True

        if _is_pandas_dataframe(value):
            normalized = value
        elif isinstance(value, dict):
            normalized = _ManagedDict(value, touch=lambda: self._touch(uid))
        elif isinstance(value, (str, int, float, bool, np.integer, np.floating)):
            normalized = _jsonable(value)
        else:
            raise TypeError("DataManager supports pd.DataFrame, dict, and scalar types (str/int/float)")

        self._items[uid] = normalized
        self._dirty_uids.add(uid)

    def __delitem__(self, name: str) -> None:
        self.delete(name)

    def delete(self, name: str, *, board_id: str | None = None) -> None:
        bid = str(board_id or self._active_board_id or "").strip()
        n = str(name or "").strip()
        if not bid:
            raise RuntimeError("DataManager active board is not set")
        if not n:
            raise KeyError(name)

        path = self._key_for(bid, n)
        uid = self._path_to_uid.pop(path, None)
        if uid is None:
            raise KeyError(name)
        self._index_dirty = True

        # If uid isn't referenced anymore, drop cached instance and delete file.
        if uid not in self._path_to_uid.values():
            self._items.pop(uid, None)
            self._dirty_uids.discard(uid)
            try:
                (self._root_dir / f"{uid}.json").unlink()
            except FileNotFoundError:
                pass
            except Exception:  # noqa: BLE001
                pass

    def save(self, name: str) -> None:
        """
        Mark a stored item as dirty so it is persisted on the next `flush()`.

        This is useful when mutating a stored object in-place (e.g., a pandas DataFrame).
        """

        raw = str(name).strip()
        if not raw:
            raise KeyError(name)
        # Resolve and load to ensure uid exists.
        _ = self[raw]
        board_id = str(self._active_board_id or "").strip()
        data_name = raw
        if "@" in raw:
            left, right = raw.rsplit("@", 1)
            data_name = left.strip()
            board_name = right.strip()
            if not data_name or not board_name:
                raise KeyError(name)
            board_id = self._board_name_to_id.get(board_name) or self._board_name_to_id_lower.get(board_name.lower()) or ""
            if not board_id:
                raise KeyError(name)
        if not board_id:
            raise KeyError(name)
        path = self._key_for(board_id, data_name)
        uid = self._path_to_uid.get(path)
        if uid is None:
            raise KeyError(name)
        self._dirty_uids.add(uid)

    def match(self, pattern: str) -> dict[str, Any]:  # noqa: ANN401
        raw = str(pattern).strip()
        if not raw:
            return {}

        pat = raw
        board_id = str(self._active_board_id or "").strip()
        if "@" in raw:
            left, right = raw.rsplit("@", 1)
            pat = left.strip() or "*"
            board_name = right.strip()
            board_id = self._board_name_to_id.get(board_name) or self._board_name_to_id_lower.get(board_name.lower()) or ""

        if not board_id:
            return {}

        base_prefix = f"{board_id}/"
        out: dict[str, Any] = {}
        for path, uid in self._path_to_uid.items():
            if base_prefix and not path.startswith(base_prefix):
                continue
            rel = path[len(base_prefix) :] if base_prefix else path
            if fnmatch.fnmatchcase(rel, pat):
                if uid in self._items:
                    out[rel] = self._items[uid]
                else:
                    out[rel] = self._load_uid(uid)
        return dict(sorted(out.items(), key=lambda kv: alphanumeric(kv[0])))

    def list(self, *, board_id: str | None = None) -> list[tuple[str, str]]:
        bid = str(board_id or self._active_board_id or "").strip()
        if not bid:
            return []
        prefix = f"{bid}/"
        out: list[tuple[str, str]] = []
        for path, uid in self._path_to_uid.items():
            if not path.startswith(prefix):
                continue
            rel = path[len(prefix) :]
            if rel:
                out.append((rel, uid))
        out.sort(key=lambda kv: alphanumeric(kv[0]))
        return out

    def flush(self) -> None:
        if not self._dirty_uids and not self._index_dirty:
            return
        self._root_dir.mkdir(parents=True, exist_ok=True)

        dirty = list(self._dirty_uids)
        still_dirty: set[str] = set()
        for uid in dirty:
            item = self._items.get(uid)
            if item is None:
                continue
            try:
                _save_data_json(self._root_dir / f"{uid}.json", uid, item)
            except Exception:  # noqa: BLE001
                still_dirty.add(uid)

        self._dirty_uids = still_dirty

        if self._index_dirty:
            try:
                _save_data_index_json(self._root_dir / "index.json", self._path_to_uid)
                self._index_dirty = False
            except Exception:  # noqa: BLE001
                pass


def _save_data_json(path: Path, uid: str, value: Any) -> None:  # noqa: ANN401
    kind: str
    data: Any
    if _is_pandas_dataframe(value):
        kind = "dataframe"
        data = value.to_json(orient="split", force_ascii=False)
    elif isinstance(value, dict):
        kind = "dict"
        data = _jsonable(value)
    elif isinstance(value, (str, int, float, bool, np.integer, np.floating)):
        kind = "scalar"
        data = _jsonable(value)
    else:
        raise TypeError("unsupported data type")

    payload = {"version": 1, "uid": uid, "kind": kind, "data": data}
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _save_data_index_json(path: Path, path_to_uid: dict[str, str]) -> None:
    payload = {"by_path": path_to_uid}
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)
