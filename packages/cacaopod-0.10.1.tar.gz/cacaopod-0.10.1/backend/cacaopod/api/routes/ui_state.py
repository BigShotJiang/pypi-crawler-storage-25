from __future__ import annotations

from fastapi import APIRouter, Request, Response

from cacaopod.api_models import FilesUiState, ToolsRegistry, ViewState
from cacaopod.session import get_or_create_session
from cacaopod.state.ui_state import (
    load_files_ui_state,
    load_tools_registry,
    save_files_ui_state,
    save_tools_registry,
    save_view_state,
)

router = APIRouter()


@router.get("/api/view", response_model=ViewState)
async def get_view_state(request: Request, response: Response) -> ViewState:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        return session.view_state


@router.post("/api/view", response_model=ViewState)
async def set_view_state(payload: ViewState, request: Request, response: Response) -> ViewState:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        session.view_state = payload
        save_view_state(payload)
        return session.view_state


@router.get("/api/ui/tools", response_model=ToolsRegistry)
async def get_tools_registry(request: Request, response: Response) -> ToolsRegistry:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        return load_tools_registry()


@router.post("/api/ui/tools", response_model=ToolsRegistry)
async def set_tools_registry(payload: ToolsRegistry, request: Request, response: Response) -> ToolsRegistry:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        save_tools_registry(payload)
        return load_tools_registry()


@router.get("/api/ui/files", response_model=FilesUiState)
async def get_files_ui_state(request: Request, response: Response) -> FilesUiState:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        return load_files_ui_state()


@router.post("/api/ui/files", response_model=FilesUiState)
async def set_files_ui_state(payload: FilesUiState, request: Request, response: Response) -> FilesUiState:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        save_files_ui_state(payload)
        return load_files_ui_state()

