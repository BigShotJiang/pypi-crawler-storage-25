from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, Response
from starlette.concurrency import run_in_threadpool

from cacaopod.api_models import (
    CodeHistoryEntry,
    EditorHistoryDeleteRequest,
    EditorHistoryDeleteResponse,
    EditorHistoryFavoriteRequest,
    EditorHistoryFavoriteResponse,
    EditorHistoryLoadRequest,
    EditorHistoryLoadResponse,
    EditorState,
    ResetResponse,
    RunRequest,
    RunResponse,
)
from cacaopod.session import exec_in_session, get_or_create_session, save_active_board_state
from cacaopod.state.editor import save_editor_state

router = APIRouter()


@router.post("/api/run", response_model=RunResponse)
async def run_code(payload: RunRequest, request: Request, response: Response) -> RunResponse:
    session_id, session = get_or_create_session(request, response)
    return await run_in_threadpool(exec_in_session, session_id, session, payload.code, payload.selection)


@router.post("/api/session/reset", response_model=ResetResponse)
async def reset_session(request: Request, response: Response) -> ResetResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        session.reset()
        save_active_board_state(session, include_waves=True)
    return ResetResponse(status="ok")


@router.get("/api/editor", response_model=EditorState)
async def get_editor_state(request: Request, response: Response) -> EditorState:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        stubs = [e.model_copy(update={"code": ""}) for e in session.code_history]
        return EditorState(code=session.last_executed_code, history=stubs)


@router.post("/api/editor/history/load_range", response_model=EditorHistoryLoadResponse)
async def load_history_range(payload: EditorHistoryLoadRequest, request: Request, response: Response) -> EditorHistoryLoadResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            start = int(payload.start_ts_ms)
            end = int(payload.end_ts_ms)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(status_code=400, detail=f"invalid range: {exc}") from exc
        if end <= start:
            return EditorHistoryLoadResponse(entries=[])
        entries: list[CodeHistoryEntry] = []
        for e in session.code_history:
            ts = int(getattr(e, "ts", 0) or 0)
            if ts < start or ts >= end:
                continue
            entries.append(e)
        return EditorHistoryLoadResponse(entries=entries)


@router.post("/api/editor/history/favorite", response_model=EditorHistoryFavoriteResponse)
async def favorite_history(payload: EditorHistoryFavoriteRequest, request: Request, response: Response) -> EditorHistoryFavoriteResponse:
    session_id, session = get_or_create_session(request, response)
    with session.lock:
        target_id = str(payload.id or "").strip()
        updated_fav: bool | None = None
        if target_id:
            for i, entry in enumerate(session.code_history):
                if str(entry.id) != target_id:
                    continue
                current = bool(getattr(entry, "favorite", False))
                next_fav = payload.favorite if payload.favorite is not None else (not current)
                session.code_history[i] = entry.model_copy(update={"favorite": bool(next_fav)})
                updated_fav = bool(next_fav)
                break
        save_editor_state(session_id, last_code=session.last_executed_code, history=session.code_history)
        if updated_fav is None:
            raise HTTPException(status_code=404, detail="history entry not found")
        return EditorHistoryFavoriteResponse(id=target_id, favorite=updated_fav)


@router.post("/api/editor/history/delete", response_model=EditorHistoryDeleteResponse)
async def delete_history(payload: EditorHistoryDeleteRequest, request: Request, response: Response) -> EditorHistoryDeleteResponse:
    session_id, session = get_or_create_session(request, response)
    with session.lock:
        target_id = str(payload.id or "").strip()
        if target_id:
            session.code_history = [h for h in session.code_history if str(h.id) != target_id]
        save_editor_state(session_id, last_code=session.last_executed_code, history=session.code_history)
        return EditorHistoryDeleteResponse(id=target_id)
