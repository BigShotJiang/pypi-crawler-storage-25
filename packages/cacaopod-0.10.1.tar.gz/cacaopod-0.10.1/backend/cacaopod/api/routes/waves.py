from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, Response

from cacaopod.api_models import BoardUpdateResponse, WaveEntry, WaveListResponse, WaveShowRequest
from cacaopod.session import (
    capture_board_fingerprint,
    capture_selected_pod_undo,
    diff_board,
    get_or_create_session,
    maybe_push_pod_undo,
    save_active_board_state,
)
from cacaopod.wave import WaveManager

router = APIRouter()


def _wave_list_for_manager(wm: WaveManager, *, board_id: str | None = None) -> WaveListResponse:
    bid = str(board_id or wm.active_board_id or "").strip()
    if not bid:
        return WaveListResponse(board_id="", board_name="", waves=[])

    board_name = ""
    try:
        id_to_name = getattr(wm, "_board_id_to_name", {})
        if isinstance(id_to_name, dict):
            board_name = str(id_to_name.get(bid) or "").strip()
    except Exception:  # noqa: BLE001
        board_name = ""
    if not board_name:
        board_name = bid

    waves: list[WaveEntry] = []
    for name, uid in wm.list(board_id=bid):
        waves.append(WaveEntry(name=name, uid=uid))
    return WaveListResponse(board_id=bid, board_name=board_name, waves=waves)


@router.get("/api/waves", response_model=WaveListResponse)
async def list_waves(request: Request, response: Response, board_id: str = "") -> WaveListResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        bid = str(board_id or "").strip() or None
        return _wave_list_for_manager(session.wave_manager, board_id=bid)


@router.delete("/api/waves/{wave_name}", response_model=WaveListResponse)
async def delete_wave(wave_name: str, request: Request, response: Response, board_id: str = "") -> WaveListResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        bid = str(board_id or session.wave_manager.active_board_id or "").strip()
        if not bid:
            raise HTTPException(status_code=400, detail="missing board_id")
        try:
            session.wave_manager.delete(wave_name, board_id=bid)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="wave not found") from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        try:
            session.wave_manager.flush()
        except Exception:  # noqa: BLE001
            pass

        # Board state may still reference the deleted wave, but keep state saving consistent.
        try:
            save_active_board_state(session, include_waves=False)
        except Exception:  # noqa: BLE001
            pass

        return _wave_list_for_manager(session.wave_manager, board_id=bid)


@router.post("/api/waves/show", response_model=BoardUpdateResponse)
async def show_wave(payload: WaveShowRequest, request: Request, response: Response) -> BoardUpdateResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        session.board.set_selected(payload.selection.i)
        undo_entry = capture_selected_pod_undo(session.board)
        before = capture_board_fingerprint(session.board)

        try:
            wave = session.wave_manager[payload.wave_path]
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="wave not found") from exc
        if payload.new_pod:
            session.board.add(wave)
        else:
            if payload.append_pod:
                session.board.append(wave)
            else:
                session.board.show(wave)
        save_active_board_state(session, include_waves=False)
        diff = diff_board(before, session.board)
        maybe_push_pod_undo(session, undo_entry)
        return BoardUpdateResponse(board=diff.board_snapshot, boardPatch=diff.board_patch)
