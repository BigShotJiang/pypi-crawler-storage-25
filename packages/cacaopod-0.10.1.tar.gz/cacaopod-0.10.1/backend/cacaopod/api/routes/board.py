from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, Response

from cacaopod.api_models import (
    BoardPodSettingsRequest,
    BoardRemoveRequest,
    BoardSnapshot,
    BoardUndoRequest,
    BoardUpdateResponse,
    BoardWaveRemoveRequest,
    WaveDataRequest,
    WaveDataResponse,
)
from cacaopod.api_models import HeatmapViewSettings, TraceViewSettings
from cacaopod.session import (
    apply_pod_undo,
    capture_board_fingerprint,
    capture_selected_pod_undo,
    diff_board,
    get_or_create_session,
    maybe_push_pod_undo,
    save_active_board_state,
)
from cacaopod.wave import read_wave_display_data

router = APIRouter()


@router.get("/api/board", response_model=BoardSnapshot)
async def get_board(request: Request, response: Response) -> BoardSnapshot:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        return session.board.snapshot()


@router.post("/api/board/wave_data", response_model=WaveDataResponse)
async def get_wave_data(payload: WaveDataRequest, request: Request, response: Response) -> WaveDataResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        uid = str(payload.uid or "").strip()
        if not uid:
            raise HTTPException(status_code=400, detail="missing wave uid")

        target = None
        pods = getattr(session.board, "_pods", None)
        if isinstance(pods, list):
            for pod in pods:
                if payload.pod_id and str(getattr(pod, "id", "")) != str(payload.pod_id):
                    continue
                for wave in getattr(pod, "waves", []) or []:
                    if str(getattr(wave, "uid", "")) == uid:
                        target = wave
                        break
                if target is not None:
                    break

        if target is None:
            raise HTTPException(status_code=404, detail="wave not found")

        ndim = int(target.ndim)
        axis = payload.sliceAxis if payload.sliceAxis in ("x", "y", "z") else None
        idx = int(payload.sliceIndex or 0)
        data = read_wave_display_data(target, slice_axis=axis, slice_index=idx)
        if data.ndim not in (1, 2):
            raise HTTPException(status_code=400, detail=f"unsupported display data ndim: {data.ndim}")

        x_axis = None
        y_axis = None
        slice_axis = None
        slice_index = None
        if ndim == 3:
            axis = axis or "z"
            shape = tuple(int(x) for x in target.shape)
            axis_to_dim = {"z": 0, "y": 1, "x": 2}
            dim = axis_to_dim.get(axis, 0)
            max_i = max(0, shape[dim] - 1)
            slice_index = max(0, min(idx, max_i))
            slice_axis = axis
            if axis == "z":
                x_axis, y_axis = "x", "y"
            elif axis == "y":
                x_axis, y_axis = "x", "z"
            else:
                x_axis, y_axis = "y", "z"

        return WaveDataResponse(
            uid=uid,
            ndim=ndim,  # type: ignore[arg-type]
            shape=list(target.shape),
            dtype=str(target.dtype),
            data=data.tolist(),
            sliceAxis=slice_axis,  # type: ignore[arg-type]
            sliceIndex=slice_index,
            xAxis=x_axis,  # type: ignore[arg-type]
            yAxis=y_axis,  # type: ignore[arg-type]
        )


@router.post("/api/board/pod_settings")
async def set_pod_settings(payload: BoardPodSettingsRequest, request: Request, response: Response) -> Response:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        session.board.set_selected(payload.selection.i)
        undo_entry = capture_selected_pod_undo(session.board)
        pod = session.board.get(payload.selection.i)

        if payload.activeWaveIndex is not None:
            try:
                ii = int(payload.activeWaveIndex)
            except Exception as exc:  # noqa: BLE001
                raise HTTPException(status_code=400, detail=f"invalid activeWaveIndex: {exc}") from exc
            pod.active_wave_index = min(max(ii, 0), max(0, len(pod.waves) - 1))

        if payload.heatmapSettings is not None:
            try:
                pod.heatmap_settings = HeatmapViewSettings.model_validate(payload.heatmapSettings)
            except Exception as exc:  # noqa: BLE001
                raise HTTPException(status_code=400, detail=f"invalid heatmapSettings: {exc}") from exc

        if payload.traceSettingsByWave is not None:
            try:
                parsed = [TraceViewSettings.model_validate(x) for x in payload.traceSettingsByWave]
            except Exception as exc:  # noqa: BLE001
                raise HTTPException(status_code=400, detail=f"invalid traceSettingsByWave: {exc}") from exc
            n = len(pod.waves)
            if n <= 0:
                pod.trace_settings_by_wave = []
            else:
                parsed = parsed[:n]
                while len(parsed) < n:
                    parsed.append(TraceViewSettings())
                pod.trace_settings_by_wave = parsed
                pod.trace_settings = pod.trace_settings_by_wave[0]

        if payload.traceSettings is not None:
            try:
                pod.trace_settings = TraceViewSettings.model_validate(payload.traceSettings)
            except Exception as exc:  # noqa: BLE001
                raise HTTPException(status_code=400, detail=f"invalid traceSettings: {exc}") from exc
            if isinstance(getattr(pod, "trace_settings_by_wave", None), list) and pod.trace_settings_by_wave:
                pod.trace_settings_by_wave[0] = pod.trace_settings

        maybe_push_pod_undo(session, undo_entry)
        save_active_board_state(session, include_waves=False)
        return Response(status_code=204)


@router.post("/api/board/undo", response_model=BoardUpdateResponse)
async def undo_pod(payload: BoardUndoRequest, request: Request, response: Response) -> BoardUpdateResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        before = capture_board_fingerprint(session.board)
        if not apply_pod_undo(session, payload.selection):
            raise HTTPException(status_code=409, detail="no undo available for selected pod")
        save_active_board_state(session, include_waves=True)
        diff = diff_board(before, session.board)
        return BoardUpdateResponse(board=diff.board_snapshot, boardPatch=diff.board_patch)


@router.post("/api/board/remove", response_model=BoardSnapshot)
async def remove_pod(payload: BoardRemoveRequest, request: Request, response: Response) -> BoardSnapshot:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        before = capture_board_fingerprint(session.board)
        try:
            session.board.remove(payload.selection.i)
        except IndexError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        save_active_board_state(session, include_waves=True)
        diff = diff_board(before, session.board)
        return diff.board_snapshot or session.board.snapshot()


@router.post("/api/board/remove_wave", response_model=BoardUpdateResponse)
async def remove_wave(payload: BoardWaveRemoveRequest, request: Request, response: Response) -> BoardUpdateResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        session.board.set_selected(payload.selection.i)
        undo_entry = capture_selected_pod_undo(session.board)
        before = capture_board_fingerprint(session.board)
        pod = session.board.get(payload.selection.i)
        try:
            ii = int(payload.waveIndex)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(status_code=400, detail=f"invalid waveIndex: {exc}") from exc
        try:
            pod.remove(ii)
        except (IndexError, ValueError) as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        maybe_push_pod_undo(session, undo_entry)
        save_active_board_state(session, include_waves=False)
        diff = diff_board(before, session.board)
        return BoardUpdateResponse(board=diff.board_snapshot, boardPatch=diff.board_patch)


@router.post("/api/board/add", response_model=BoardUpdateResponse)
async def add_pod(request: Request, response: Response) -> BoardUpdateResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        before = capture_board_fingerprint(session.board)
        session.board.add()
        save_active_board_state(session, include_waves=False)
        diff = diff_board(before, session.board)
        return BoardUpdateResponse(board=diff.board_snapshot, boardPatch=diff.board_patch)


@router.post("/api/board/clear", response_model=BoardSnapshot)
async def clear_board(request: Request, response: Response) -> BoardSnapshot:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        session.board.clear()
        snap = session.board.snapshot()
        save_active_board_state(session, include_waves=True)
        return snap
