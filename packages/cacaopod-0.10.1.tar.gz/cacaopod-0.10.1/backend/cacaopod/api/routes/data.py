from __future__ import annotations

import json
from time import perf_counter

from fastapi import APIRouter, HTTPException, Request, Response

from cacaopod.api_models import (
    DataEntry,
    DataFramePreviewResponse,
    DataFrameUpdateRequest,
    DataListResponse,
    DataPrintRequest,
    ErrorInfo,
    RunResponse,
    StatusResponse,
)
from cacaopod.data_manager import DataManager, _is_pandas_dataframe, _jsonable
from cacaopod.session import get_or_create_session

router = APIRouter()


def _data_kind_for_uid(dm: DataManager, uid: str) -> str:
    items = getattr(dm, "_items", {})
    if isinstance(items, dict) and uid in items:
        item = items.get(uid)
        if _is_pandas_dataframe(item):
            return "dataframe"
        if isinstance(item, dict):
            return "dict"
        return "scalar"

    path = dm.root_dir / f"{uid}.json"
    if not path.exists():
        return ""
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return ""
    if not isinstance(payload, dict):
        return ""
    kind = str(payload.get("kind") or "").strip().lower()
    if kind not in {"dataframe", "dict", "scalar"}:
        return ""
    return kind


def _data_list_for_manager(dm: DataManager, *, board_id: str | None = None) -> DataListResponse:
    bid = str(board_id or dm.active_board_id or "").strip()
    if not bid:
        return DataListResponse(board_id="", board_name="", items=[])

    board_name = ""
    try:
        id_to_name = getattr(dm, "_board_id_to_name", {})
        if isinstance(id_to_name, dict):
            board_name = str(id_to_name.get(bid) or "").strip()
    except Exception:  # noqa: BLE001
        board_name = ""
    if not board_name:
        board_name = bid

    items: list[DataEntry] = []
    for name, uid in dm.list(board_id=bid):
        items.append(DataEntry(name=name, uid=uid, kind=_data_kind_for_uid(dm, uid)))
    return DataListResponse(board_id=bid, board_name=board_name, items=items)


@router.get("/api/data", response_model=DataListResponse)
async def list_data(request: Request, response: Response, board_id: str = "") -> DataListResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        bid = str(board_id or "").strip() or None
        return _data_list_for_manager(session.data_manager, board_id=bid)


@router.post("/api/data/print", response_model=RunResponse)
async def print_data(payload: DataPrintRequest, request: Request, response: Response) -> RunResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        t0 = perf_counter()
        status: str = "ok"
        stdout = ""
        stderr = ""
        error: ErrorInfo | None = None

        data_path = str(payload.data_path or "").strip()
        if not data_path:
            status = "error"
            stderr = "data_path is required"
            error = ErrorInfo(message=stderr, traceback="")

        try:
            item = session.data_manager[data_path] if status == "ok" else None
        except KeyError:
            status = "error"
            stderr = "data not found"
            error = ErrorInfo(message=stderr, traceback="")
        except Exception as exc:  # noqa: BLE001
            msg = str(exc)
            status = "error"
            stderr = msg
            error = ErrorInfo(message=msg, traceback="")

        if status == "ok":
            if _is_pandas_dataframe(item):
                stdout = item.to_string()
            elif isinstance(item, dict):
                try:
                    stdout = json.dumps(item, ensure_ascii=False, indent=2)
                except Exception:  # noqa: BLE001
                    stdout = str(item)
            else:
                stdout = str(item)
        exec_ms = (perf_counter() - t0) * 1000.0
        return RunResponse(status=status, stdout=stdout, stderr=stderr, error=error, execMs=exec_ms)


@router.get("/api/data/dataframe", response_model=DataFramePreviewResponse)
async def get_dataframe(data_path: str, request: Request, response: Response) -> DataFramePreviewResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        raw = str(data_path or "").strip()
        if not raw:
            raise HTTPException(status_code=400, detail="data_path is required")
        try:
            item = session.data_manager[raw]
        except KeyError as exc:
            raise HTTPException(status_code=404, detail="data not found") from exc
        if not _is_pandas_dataframe(item):
            raise HTTPException(status_code=400, detail="data is not a DataFrame")

        df = item
        columns = [str(c) for c in df.columns]
        index = [str(i) for i in df.index]
        rows = [[_jsonable(v) for v in row] for row in df.values.tolist()]
        return DataFramePreviewResponse(columns=columns, index=index, rows=rows)


def _is_nullable_dtype(dtype: object) -> bool:
    name = str(dtype)
    return name.startswith("Int") or name.startswith("UInt") or name == "boolean"


def _coerce_bool_series(series: "pd.Series", *, allow_na: bool) -> "pd.Series":
    def _map(v: object) -> object:
        if v is None:
            return None if allow_na else False
        s = str(v).strip().lower()
        if s in {"true", "1", "yes"}:
            return True
        if s in {"false", "0", "no"}:
            return False
        if s == "" and allow_na:
            return None
        raise ValueError(f"invalid bool value: {v}")

    mapped = series.map(_map)
    return mapped


def _coerce_series_to_dtype(series: "pd.Series", dtype: object) -> "pd.Series":
    import pandas as pd  # type: ignore[import-not-found]

    if pd.api.types.is_bool_dtype(dtype):
        allow_na = _is_nullable_dtype(dtype)
        mapped = _coerce_bool_series(series, allow_na=allow_na)
        return mapped.astype(dtype)

    if pd.api.types.is_integer_dtype(dtype):
        numeric = pd.to_numeric(series, errors="coerce")
        if numeric.isna().any() and not _is_nullable_dtype(dtype):
            raise ValueError("integer column contains invalid or empty values")
        return numeric.astype(dtype)

    if pd.api.types.is_float_dtype(dtype):
        numeric = pd.to_numeric(series, errors="coerce")
        return numeric.astype(dtype)

    if pd.api.types.is_string_dtype(dtype):
        def _to_text(v: object) -> str:
            if v is None:
                return ""
            if isinstance(v, float) and pd.isna(v):
                return ""
            if v is pd.NA:
                return ""
            return str(v)

        cleaned = series.map(_to_text)
        try:
            out = cleaned.astype(dtype)
        except Exception:  # noqa: BLE001
            out = cleaned.astype(object)
        try:
            out = out.fillna("")
        except Exception:  # noqa: BLE001
            pass
        return out

    try:
        return series.astype(dtype)
    except Exception:  # noqa: BLE001
        return series


@router.post("/api/data/dataframe/update", response_model=StatusResponse)
async def update_dataframe(payload: DataFrameUpdateRequest, request: Request, response: Response) -> StatusResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        raw = str(payload.data_path or "").strip()
        if not raw:
            return StatusResponse(status="error", message="data_path is required")
        try:
            import pandas as pd  # type: ignore[import-not-found]
        except Exception as exc:  # noqa: BLE001
            return StatusResponse(status="error", message=f"pandas is required: {exc}")

        try:
            existing = session.data_manager[raw]
        except KeyError as exc:
            return StatusResponse(status="error", message="data not found")
        if not _is_pandas_dataframe(existing):
            return StatusResponse(status="error", message="data is not a DataFrame")

        columns = [str(c) for c in (payload.columns or [])]
        rows_in = payload.rows or []
        rows: list[list[object]] = []
        for row in rows_in:
            if not isinstance(row, list):
                continue
            rows.append([None if v is None or str(v) == "" else str(v) for v in row])

        df = pd.DataFrame(rows, columns=columns, dtype="object")
        if payload.index and len(payload.index) == len(df):
            df.index = [str(i) for i in payload.index]
        try:
            old_df = existing
            old_cols = [str(c) for c in old_df.columns]
            for i, col in enumerate(columns):
                target_dtype = None
                if col in old_df.columns:
                    target_dtype = old_df[col].dtype
                elif i < len(old_cols):
                    target_dtype = old_df.iloc[:, i].dtype
                if target_dtype is None:
                    continue
                df[col] = _coerce_series_to_dtype(df[col], target_dtype)
        except Exception as exc:  # noqa: BLE001
            return StatusResponse(status="error", message=f"dtype mismatch: {exc}")

        try:
            session.data_manager[raw] = df
            session.data_manager.flush()
        except Exception as exc:  # noqa: BLE001
            return StatusResponse(status="error", message=str(exc))

        return StatusResponse(status="ok", message="saved")
