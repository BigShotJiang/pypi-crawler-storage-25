from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, Response

from cacaopod.api_models import (
    NamingRuleGenerateRequest,
    NamingRuleGenerateResponse,
    NamingRulePreviewItem,
    NamingRulePreviewRequest,
    NamingRulePreviewSourceRequest,
    NamingRulePreviewResponse,
    NamingRulesListResponse,
    NamingRuleSaveRequest,
    NamingRuleSourceResponse,
    NamingRuleSummaryInfo,
)
from cacaopod.config import workdir
from cacaopod.naming_rule import NamingRuleLocation, NamingRuleRegistry, generate_naming_rule_via_openai, naming_rule_from_source
from cacaopod.session import get_or_create_session

router = APIRouter()


@router.get("/api/naming_rules", response_model=NamingRulesListResponse)
async def list_naming_rules(request: Request, response: Response) -> NamingRulesListResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        registry = NamingRuleRegistry(workdir=workdir())
        out: list[NamingRuleSummaryInfo] = []
        for r in registry.list():
            out.append(NamingRuleSummaryInfo(name=r.name, location=r.location, signature=r.signature, doc=r.doc))
        return NamingRulesListResponse(naming_rules=out)


# NOTE: Static routes must come before "/{name}" routes, otherwise Starlette will
# match "/preview" as name="preview" and validate against the wrong model.
@router.post("/api/naming_rules/preview", response_model=NamingRulePreviewResponse)
async def preview_naming_rule(payload: NamingRulePreviewRequest, request: Request, response: Response) -> NamingRulePreviewResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        registry = NamingRuleRegistry(workdir=workdir())
        try:
            rule = registry.get(payload.rule.name, location=payload.rule.location)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        items: list[NamingRulePreviewItem] = []
        seen: dict[str, int] = {}
        duplicates: set[str] = set()

        for rel in payload.files or []:
            fp_raw = str(rel).strip()
            if not fp_raw:
                continue
            fp = fp_raw.replace("\\", "/").split("/")[-1].strip()
            if not fp:
                fp = fp_raw
            try:
                name = rule(fp)
                items.append(NamingRulePreviewItem(file_path=fp, wave_name=name, error=None))
                prev = seen.get(name)
                if prev is None:
                    seen[name] = 1
                else:
                    seen[name] = prev + 1
                    duplicates.add(name)
            except Exception as exc:  # noqa: BLE001
                items.append(NamingRulePreviewItem(file_path=fp, wave_name=None, error=str(exc)))

        return NamingRulePreviewResponse(items=items, duplicates=sorted(duplicates))


@router.post("/api/naming_rules/preview_source", response_model=NamingRulePreviewResponse)
async def preview_naming_rule_source(
    payload: NamingRulePreviewSourceRequest,
    request: Request,
    response: Response,
) -> NamingRulePreviewResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            rule = naming_rule_from_source(name=payload.name, source=payload.source)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        items: list[NamingRulePreviewItem] = []
        seen: dict[str, int] = {}
        duplicates: set[str] = set()

        for rel in payload.files or []:
            fp_raw = str(rel).strip()
            if not fp_raw:
                continue
            fp = fp_raw.replace("\\", "/").split("/")[-1].strip()
            if not fp:
                fp = fp_raw
            try:
                name = rule(fp)
                items.append(NamingRulePreviewItem(file_path=fp, wave_name=name, error=None))
                prev = seen.get(name)
                if prev is None:
                    seen[name] = 1
                else:
                    seen[name] = prev + 1
                    duplicates.add(name)
            except Exception as exc:  # noqa: BLE001
                items.append(NamingRulePreviewItem(file_path=fp, wave_name=None, error=str(exc)))

        return NamingRulePreviewResponse(items=items, duplicates=sorted(duplicates))


@router.post("/api/naming_rules/generate", response_model=NamingRuleGenerateResponse)
async def generate_naming_rule(payload: NamingRuleGenerateRequest, request: Request, response: Response) -> NamingRuleGenerateResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            source = generate_naming_rule_via_openai(
                name=payload.name,
                files=list(payload.files or []),
                examples_text=payload.examples_text,
                model=payload.model,
            )
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return NamingRuleGenerateResponse(source=source)


@router.get("/api/naming_rules/{name}", response_model=NamingRuleSourceResponse)
async def get_naming_rule_source(
    name: str,
    request: Request,
    response: Response,
    location: NamingRuleLocation | None = None,
) -> NamingRuleSourceResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        registry = NamingRuleRegistry(workdir=workdir())
        try:
            loc, source = registry.get_source(name, location=location)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return NamingRuleSourceResponse(name=name, location=loc, source=source)


@router.post("/api/naming_rules/{name}", response_model=NamingRuleSourceResponse)
async def save_naming_rule_source(
    name: str,
    payload: NamingRuleSaveRequest,
    request: Request,
    response: Response,
) -> NamingRuleSourceResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        registry = NamingRuleRegistry(workdir=workdir())
        try:
            registry.save_source(name, payload.source, location=payload.location)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        loc, source = registry.get_source(name, location=payload.location)
        return NamingRuleSourceResponse(name=name, location=loc, source=source)


@router.delete("/api/naming_rules/{name}")
async def delete_naming_rule(
    name: str,
    location: NamingRuleLocation,
    request: Request,
    response: Response,
) -> dict[str, str]:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        registry = NamingRuleRegistry(workdir=workdir())
        try:
            registry.delete(name, location=location)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"status": "ok"}
