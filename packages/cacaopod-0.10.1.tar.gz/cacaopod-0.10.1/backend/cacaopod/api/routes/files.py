from __future__ import annotations

import io
import sys
import traceback
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path, PurePosixPath
from time import perf_counter
from typing import Literal

from fastapi import APIRouter, HTTPException, Request, Response

from cacaopod.api_models import (
    ErrorInfo,
    FileBatchLoadRequest,
    FileChildrenResponse,
    FileListResponse,
    FileLoadRequest,
    FileTreeEntry,
    Hdf5DatasetLoadSpec,
    Hdf5InspectRequest,
    Hdf5InspectResponse,
    Hdf5LoadRequest,
    Hdf5NodeInfo,
    RunResponse,
)
from cacaopod.config import SKIP_DIR_NAMES, in_workdir, resolve_under_workdir, workdir
from cacaopod.file_loader import (
    FileLoader,
    FileLoaderRegistry,
    collapse_loaded_waves,
    ensure_wave_list,
    finalize_loaded_waves,
    invoke_loader,
    loader_output_name,
    materialize_loader_result,
    normalize_loader_result,
)
from cacaopod.file_manager import FileManager
from cacaopod.loaded_files import record_loaded_file
from cacaopod.naming_rule import NamingRuleRegistry
from cacaopod.session import (
    capture_board_fingerprint,
    capture_selected_pod_undo,
    diff_board,
    get_or_create_session,
    maybe_push_pod_undo,
    save_active_board_state,
)
from cacaopod.sort_utils import alphanumeric
from cacaopod.wave import Wave, bind_wave_manager, create_lazy_hdf5_wave

router = APIRouter()


def _import_h5py():
    try:
        import h5py  # type: ignore[import-not-found]
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError("h5py is required to read HDF5 files. Install cacaopod with h5py support.") from exc
    return h5py


def _json_preview(value: object) -> str:
    try:
        import numpy as np

        if isinstance(value, bytes):
            return value.decode("utf-8", errors="replace")
        if isinstance(value, np.ndarray):
            if value.size > 8:
                return f"{value.shape} {value.dtype}"
            return repr(value.tolist())
        if isinstance(value, np.generic):
            return repr(value.item())
    except Exception:  # noqa: BLE001
        pass
    text = str(value)
    return text if len(text) <= 160 else text[:157] + "..."


def _hdf5_dataset_reason(shape: tuple[int, ...], dtype: object) -> tuple[bool, str | None]:
    import numpy as np

    dt = np.dtype(dtype)
    if dt.kind not in {"b", "i", "u", "f"}:
        return False, f"unsupported dtype {dt}"
    ndim = len(shape)
    squeezed_ndim = int(np.asarray(shape, dtype=int)[np.asarray(shape, dtype=int) > 1].size)
    if squeezed_ndim == 0:
        return False, "scalar dataset"
    if ndim <= 3 or squeezed_ndim <= 3:
        return True, None
    return False, f"dataset has {ndim} dimensions"


def _hdf5_node_info(obj: object, name: str, path: str) -> Hdf5NodeInfo:
    h5py = _import_h5py()
    attrs: dict[str, str] = {}
    try:
        attrs = {str(k): _json_preview(v) for k, v in getattr(obj, "attrs", {}).items()}
    except Exception:  # noqa: BLE001
        attrs = {}

    if isinstance(obj, h5py.Dataset):
        shape = tuple(int(x) for x in obj.shape)
        loadable, reason = _hdf5_dataset_reason(shape, obj.dtype)
        size = 1
        for n in shape:
            size *= max(1, int(n))
        return Hdf5NodeInfo(
            kind="dataset",
            name=name,
            path=path,
            shape=list(shape),
            dtype=str(obj.dtype),
            ndim=len(shape),
            size=size,
            attrs=attrs,
            loadable=loadable,
            reason=reason,
        )

    children: list[Hdf5NodeInfo] = []
    if isinstance(obj, h5py.Group):
        entries = sorted(obj.items(), key=lambda kv: (not isinstance(kv[1], h5py.Group), alphanumeric(str(kv[0]))))
        for child_name, child in entries:
            child_path = f"{path.rstrip('/')}/{child_name}" if path != "/" else f"/{child_name}"
            children.append(_hdf5_node_info(child, str(child_name), child_path))
    return Hdf5NodeInfo(kind="group", name=name, path=path, attrs=attrs, children=children)


def _localize_hdf5_path(raw_path: str, auth: object | None = None) -> tuple[Path, str]:
    file_manager = FileManager(workdir=workdir())
    path_s = str(raw_path or "").strip()
    if not path_s:
        raise ValueError("file_path is required")

    auth_url = str(getattr(auth, "url", "") or "").strip() if auth is not None else ""
    if auth_url:
        remote_path = path_s[len("webdav:") :].lstrip("/") if path_s.lower().startswith("webdav:") else path_s
        localized = Path(
            file_manager.localize(
                f"webdav:{remote_path}",
                webdav_url=auth_url,
                webdav_user=getattr(auth, "username", None),
                webdav_password=getattr(auth, "password", None),
            )
        )
        return localized, f"webdav:{remote_path}"

    localized = Path(file_manager.localize(path_s))
    if path_s.lower().startswith("webdav:"):
        return localized, f"webdav:{path_s[len('webdav:'):].lstrip('/')}"
    try:
        return localized, str(localized.relative_to(workdir()))
    except ValueError:
        return localized, str(localized)


def _safe_hdf5_wave_name(file_path: str, dataset_path: str) -> str:
    stem = Path(str(file_path).replace("\\", "/")).name
    if "." in stem:
        stem = stem.rsplit(".", 1)[0]
    suffix = str(dataset_path).strip("/").replace("/", "_")
    raw = f"{stem}_{suffix}" if suffix else stem
    out = "".join(ch if ch.isalnum() or ch == "_" else "_" for ch in raw)
    out = "_".join(part for part in out.split("_") if part)
    if not out:
        out = "hdf5_data"
    if out[0].isdigit():
        out = f"w_{out}"
    return out


def _existing_wave_names(session: object) -> set[str]:
    try:
        wm = getattr(session, "wave_manager")
        board_id = str(getattr(wm, "active_board_id", "") or "").strip()
        if not board_id:
            return set()
        return {str(name) for name, _uid in wm.list(board_id=board_id)}
    except Exception:  # noqa: BLE001
        return set()


def _unique_wave_name(base: str, used: set[str]) -> str:
    name = base
    i = 1
    while name in used:
        name = f"{base}_{i}"
        i += 1
    used.add(name)
    return name


def _read_hdf5_dataset(file_obj: object, spec: Hdf5DatasetLoadSpec, *, file_path: Path | str | None = None) -> Wave:
    import numpy as np

    path = str(spec.path or "").strip()
    if not path.startswith("/"):
        path = "/" + path
    obj = file_obj[path]  # type: ignore[index]
    h5py = _import_h5py()
    if not isinstance(obj, h5py.Dataset):
        raise ValueError(f"{path} is not a dataset")
    loadable, reason = _hdf5_dataset_reason(tuple(int(x) for x in obj.shape), obj.dtype)
    if not loadable:
        raise ValueError(f"{path}: {reason or 'not loadable'}")

    if file_path is None:
        arr = np.asarray(obj[()])
        if spec.squeeze:
            arr = np.squeeze(arr)
        if spec.transpose and arr.ndim == 2:
            arr = arr.T
        if arr.ndim < 1 or arr.ndim > 3:
            raise ValueError(f"{path}: expected 1D/2D/3D after options, got {arr.ndim}D")
        if arr.dtype.kind not in {"b", "i", "u", "f"}:
            raise ValueError(f"{path}: unsupported dtype {arr.dtype}")
        wave = Wave(arr)
    else:
        wave = create_lazy_hdf5_wave(
            file_path,
            path,
            shape=tuple(int(x) for x in obj.shape),
            dtype=obj.dtype,
            squeeze=bool(spec.squeeze),
            transpose=bool(spec.transpose),
        )
        if wave.ndim < 1 or wave.ndim > 3:
            raise ValueError(f"{path}: expected 1D/2D/3D after options, got {wave.ndim}D")
    try:
        wave.userdata.update({"hdf5_path": path})
    except Exception:  # noqa: BLE001
        pass
    return wave


@router.get("/api/files/children", response_model=FileChildrenResponse)
async def list_file_children(request: Request, response: Response, dir: str = "") -> FileChildrenResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            root = resolve_under_workdir(dir)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        if not root.exists():
            raise HTTPException(status_code=404, detail="directory not found")
        if not root.is_dir():
            raise HTTPException(status_code=400, detail="path is not a directory")

        entries: list[FileTreeEntry] = []
        for child in sorted(root.iterdir(), key=lambda p: (not p.is_dir(), alphanumeric(p.name))):
            name = child.name
            if name.startswith("."):
                continue
            if child.is_dir() and name in SKIP_DIR_NAMES:
                continue
            rel = str(child.relative_to(workdir()))
            entries.append(FileTreeEntry(kind="dir" if child.is_dir() else "file", name=name, path=rel))
        return FileChildrenResponse(entries=entries)


@router.get("/api/files/list", response_model=FileListResponse)
async def list_files_by_extension(
    request: Request,
    response: Response,
    dir: str = "",
    ext: str = "",
) -> FileListResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            root = resolve_under_workdir(dir)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        if not root.exists():
            raise HTTPException(status_code=404, detail="directory not found")
        if not root.is_dir():
            raise HTTPException(status_code=400, detail="path is not a directory")

        wanted = str(ext).strip().lower()
        if wanted and not wanted.startswith("."):
            wanted = "." + wanted
        if not wanted:
            return FileListResponse(files=[])

        files: list[FileTreeEntry] = []
        for child in sorted(root.iterdir(), key=lambda p: alphanumeric(p.name)):
            if not child.is_file():
                continue
            name = child.name
            if name.startswith("."):
                continue
            if child.suffix.lower() != wanted:
                continue
            rel = str(child.relative_to(workdir()))
            files.append(FileTreeEntry(kind="file", name=name, path=rel))
        return FileListResponse(files=files)


@router.post("/api/files/hdf5/inspect", response_model=Hdf5InspectResponse)
async def inspect_hdf5_file(payload: Hdf5InspectRequest, request: Request, response: Response) -> Hdf5InspectResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            h5py = _import_h5py()
            localized, desc = _localize_hdf5_path(payload.file_path, payload.auth)
            if not localized.exists():
                raise FileNotFoundError(str(localized))
            if not localized.is_file():
                raise ValueError("path is not a file")
            with h5py.File(localized, "r") as h5:
                root = _hdf5_node_info(h5, "/", "/")
            return Hdf5InspectResponse(file_path=desc, root=root)
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.post("/api/files/hdf5/load", response_model=RunResponse)
async def load_hdf5_datasets(payload: Hdf5LoadRequest, request: Request, response: Response) -> RunResponse:
    _session_id, session = get_or_create_session(request, response)
    stdout_io = io.StringIO()
    stderr_io = io.StringIO()
    status: Literal["ok", "error"] = "ok"
    error: ErrorInfo | None = None
    board_snapshot = None
    board_patch = None
    exec_ms: float | None = None

    with session.lock:
        t0 = perf_counter()
        session.board.set_selected(payload.selection.i)
        undo_entry = capture_selected_pod_undo(session.board)
        before = capture_board_fingerprint(session.board)
        try:
            specs = [spec for spec in payload.datasets if str(spec.path or "").strip()]
            if not specs:
                raise ValueError("select at least one HDF5 dataset")

            h5py = _import_h5py()
            localized, desc = _localize_hdf5_path(payload.file_path, payload.auth)
            if not localized.exists():
                raise FileNotFoundError(str(localized))
            if not localized.is_file():
                raise ValueError("path is not a file")

            used = _existing_wave_names(session)
            loaded: list[Wave] = []
            allow_overwrite = bool(payload.allow_overwrite)

            with redirect_stdout(stdout_io), redirect_stderr(stderr_io):
                with bind_wave_manager(session.wave_manager), in_workdir(workdir()):
                    with h5py.File(localized, "r") as h5:
                        for spec in specs:
                            wave = _read_hdf5_dataset(h5, spec, file_path=localized)
                            raw_name = str(spec.name or "").strip()
                            desired_name = raw_name or _safe_hdf5_wave_name(desc, spec.path)
                            if allow_overwrite:
                                existing = None
                                try:
                                    existing = session.wave_manager[desired_name]
                                except KeyError:
                                    existing = None
                                if isinstance(existing, Wave):
                                    existing.overwrite(wave)
                                    wave = existing
                                else:
                                    wave.name = desired_name
                            else:
                                wave.name = _unique_wave_name(desired_name, used)

                            wave.description = f"{desc}::{str(spec.path or '').strip()}"
                            wave.userdata.update(
                                {
                                    "file_path": desc,
                                    "loader": "hdf5",
                                    "loader_key": str(spec.path or "").strip(),
                                    "hdf5_path": str(spec.path or "").strip(),
                                }
                            )
                            loaded.append(wave)

                    for wave in loaded:
                        if wave.name and wave.description:
                            record_loaded_file(session.data_manager, wave_name=wave.name, file_path=wave.description)

                    if payload.mode == "single_pod":
                        session.board.add(loaded)
                    else:
                        for wave in loaded:
                            session.board.add(wave)
        except Exception as exc:  # noqa: BLE001
            status = "error"
            error = ErrorInfo(message=str(exc), traceback=traceback.format_exc())

        try:
            session.wave_manager.flush()
        except Exception:  # noqa: BLE001
            pass
        try:
            session.data_manager.flush()
        except Exception:  # noqa: BLE001
            pass
        save_active_board_state(session, include_waves=True)
        diff = diff_board(before, session.board)
        maybe_push_pod_undo(session, undo_entry)
        board_snapshot = diff.board_snapshot
        board_patch = diff.board_patch
        exec_ms = (perf_counter() - t0) * 1000.0

    return RunResponse(
        status=status,
        board=board_snapshot,
        boardPatch=board_patch,
        stdout=stdout_io.getvalue(),
        stderr=stderr_io.getvalue(),
        error=error,
        execMs=exec_ms,
    )


@router.post("/api/files/load", response_model=RunResponse)
async def load_file(payload: FileLoadRequest, request: Request, response: Response) -> RunResponse:
    _session_id, session = get_or_create_session(request, response)
    stdout_io = io.StringIO()
    stderr_io = io.StringIO()
    status: Literal["ok", "error"] = "ok"
    error: ErrorInfo | None = None
    board_snapshot = None
    board_patch = None
    exec_ms: float | None = None

    with session.lock:
        t0 = perf_counter()
        if not payload.new_pod:
            session.board.set_selected(payload.selection.i)
        undo_entry = capture_selected_pod_undo(session.board)
        before = capture_board_fingerprint(session.board)
        try:
            allow_overwrite = bool(getattr(payload, "allow_overwrite", False))
            target_name = str(payload.name).strip() if payload.name is not None else ""
            if not target_name:
                target_name = ""
            raw_path = str(payload.file_path or "").strip()
            if not raw_path:
                raise ValueError("file_path is required")
            file_manager = FileManager(workdir=workdir())
            localized = Path(file_manager.localize(raw_path))
            if not localized.exists():
                raise FileNotFoundError(str(localized))
            if not localized.is_file():
                raise ValueError("path is not a file")
            if raw_path.lower().startswith("webdav:"):
                rel_desc = f"webdav:{raw_path[len('webdav:'):].lstrip('/')}"
            else:
                try:
                    rel_desc = str(localized.relative_to(workdir()))
                except ValueError:
                    rel_desc = str(localized)

            if payload.naming_rule is not None and str(payload.naming_rule.name or "").strip():
                nr = NamingRuleRegistry(workdir=workdir()).get(payload.naming_rule.name, location=payload.naming_rule.location)
                if raw_path.lower().startswith("webdav:"):
                    cleaned = raw_path[len("webdav:") :].lstrip("/")
                    base = PurePosixPath(cleaned).name or localized.name
                else:
                    base = Path(raw_path).name or localized.name
                target_name = str(nr(base)).strip()
                if not target_name:
                    raise ValueError("naming_rule produced an empty wave name")
                allow_overwrite = True

            requested_name = target_name or None

            with redirect_stdout(stdout_io), redirect_stderr(stderr_io):
                with bind_wave_manager(session.wave_manager), in_workdir(workdir()):
                    registry = FileLoaderRegistry(workdir=workdir())
                    if payload.loader is None or not payload.loader.name.strip():
                        loaded_value = FileLoader(workdir=workdir(), registry=registry)(
                            str(localized),
                            name=requested_name,
                            overwrite=allow_overwrite,
                            description=rel_desc,
                            **payload.kwargs,
                        )
                    else:
                        loader = registry.get(payload.loader.name, location=payload.loader.location)
                        result = invoke_loader(loader, localized, **payload.kwargs)
                        loaded_value = collapse_loaded_waves(
                            materialize_loader_result(
                                result,
                                name=requested_name,
                                overwrite=allow_overwrite,
                                description=rel_desc,
                                loader_name=loader.name,
                            )
                        )

                    for w in ensure_wave_list(loaded_value):
                        if w.name and w.description:
                            record_loaded_file(session.data_manager, wave_name=w.name, file_path=w.description)

                    if payload.new_pod:
                        session.board.add(loaded_value)
                    else:
                        if payload.append_pod:
                            session.board.append(loaded_value)
                        else:
                            session.board.show(loaded_value)
        except Exception as exc:  # noqa: BLE001
            status = "error"
            error = ErrorInfo(message=str(exc), traceback=traceback.format_exc())

        try:
            session.wave_manager.flush()
        except Exception:  # noqa: BLE001
            pass
        try:
            session.data_manager.flush()
        except Exception:  # noqa: BLE001
            pass
        save_active_board_state(session, include_waves=True)
        diff = diff_board(before, session.board)
        maybe_push_pod_undo(session, undo_entry)
        board_snapshot = diff.board_snapshot
        board_patch = diff.board_patch
        exec_ms = (perf_counter() - t0) * 1000.0

    return RunResponse(
        status=status,
        board=board_snapshot,
        boardPatch=board_patch,
        stdout=stdout_io.getvalue(),
        stderr=stderr_io.getvalue(),
        error=error,
        execMs=exec_ms,
    )


@router.post("/api/files/load_batch", response_model=RunResponse)
async def load_files_batch(payload: FileBatchLoadRequest, request: Request, response: Response) -> RunResponse:
    _session_id, session = get_or_create_session(request, response)
    stdout_io = io.StringIO()
    stderr_io = io.StringIO()
    status: Literal["ok", "error"] = "ok"
    error: ErrorInfo | None = None
    board_snapshot = None
    board_patch = None
    exec_ms: float | None = None

    with session.lock:
        t0 = perf_counter()
        before = capture_board_fingerprint(session.board)
        try:
            allow_overwrite = bool(getattr(payload, "allow_overwrite", False))
            skip_existing = bool(getattr(payload, "skip_existing", False))
            files = [str(p).strip() for p in (payload.files or [])]
            files = [p for p in files if p]
            if not files:
                raise ValueError("no files to load")

            with redirect_stdout(stdout_io), redirect_stderr(stderr_io):
                with bind_wave_manager(session.wave_manager), in_workdir(workdir()):
                    loaded = 0
                    skipped = 0
                    loaded_groups: list[list[Wave]] = []
                    expected_ndim: int | None = None
                    file_manager = FileManager(workdir=workdir())
                    registry = FileLoaderRegistry(workdir=workdir())

                    as_named = bool(payload.as_named_waves)
                    target_names: list[str | None] = [None for _ in files]
                    if as_named:
                        allow_overwrite = True
                        if payload.naming_rule is None or not str(payload.naming_rule.name or "").strip():
                            raise ValueError("naming_rule is required when as_named_waves is true")
                        nr = NamingRuleRegistry(workdir=workdir()).get(payload.naming_rule.name, location=payload.naming_rule.location)

                        seen: dict[str, int] = {}
                        duplicates: set[str] = set()
                        for i, rel in enumerate(files):
                            raw = str(rel).strip()
                            if raw.lower().startswith("webdav:"):
                                raw = raw[len("webdav:") :].lstrip("/")
                                base = PurePosixPath(raw).name
                            else:
                                base = str(raw).replace("\\", "/").split("/")[-1].strip()
                            name = nr(base or rel)
                            target_names[i] = name
                            prev = seen.get(name)
                            if prev is None:
                                seen[name] = 1
                            else:
                                seen[name] = prev + 1
                                duplicates.add(name)
                        if duplicates:
                            dup_s = ", ".join(sorted(duplicates)[:20])
                            raise ValueError(f"duplicate wave names from naming_rule: {dup_s}")

                        if not allow_overwrite and not skip_existing:
                            # Preflight collision check against existing WaveManager entries in the current directory.
                            wm = session.wave_manager
                            board_id = str(getattr(wm, "active_board_id", "") or "").strip()
                            path_to_uid = getattr(wm, "_path_to_uid", {})
                            if isinstance(path_to_uid, dict) and board_id:
                                colliding: list[str] = []
                                for name in (n for n in target_names if isinstance(n, str) and n):
                                    if f"{board_id}/{name}" in path_to_uid:
                                        colliding.append(name)
                                if colliding:
                                    coll_s = ", ".join(sorted(set(colliding))[:20])
                                    raise ValueError(f"wave name already exists in this board: {coll_s}")

                    existing_names: set[str] = set()
                    if as_named and skip_existing:
                        try:
                            wm = session.wave_manager
                            board_id = str(getattr(wm, "active_board_id", "") or "").strip()
                            if board_id:
                                existing_names = {name for name, _uid in wm.list(board_id=board_id)}
                        except Exception:  # noqa: BLE001
                            existing_names = set()

                    selected_loader = None
                    if payload.loader is not None and payload.loader.name.strip():
                        selected_loader = registry.get(payload.loader.name, location=payload.loader.location)

                    for i, rel in enumerate(files):
                        target_name = target_names[i]
                        try:
                            raw_path = str(rel).strip()
                            if not raw_path:
                                raise ValueError("empty file path")
                            localized = Path(file_manager.localize(raw_path))
                            if not localized.exists():
                                raise FileNotFoundError(str(localized))
                            if not localized.is_file():
                                raise ValueError("path is not a file")
                            if raw_path.lower().startswith("webdav:"):
                                rel_desc = f"webdav:{raw_path[len('webdav:'):].lstrip('/')}"
                            else:
                                try:
                                    rel_desc = str(localized.relative_to(workdir()))
                                except ValueError:
                                    rel_desc = str(localized)

                            loader = selected_loader or registry.resolve_for_extension(localized.suffix)
                            result = invoke_loader(loader, localized, **payload.kwargs)
                            normalized = normalize_loader_result(result, description=rel_desc, loader_name=loader.name)

                            if as_named:
                                if not target_name:
                                    raise ValueError("internal error: missing target wave name")
                                if skip_existing:
                                    intended_names = [loader_output_name(item.key, target_name) for item in normalized]
                                    if any(name in existing_names for name in intended_names if name):
                                        skipped += 1
                                        continue
                                waves = finalize_loaded_waves(normalized, name=target_name, overwrite=allow_overwrite)
                            else:
                                waves = finalize_loaded_waves(normalized)

                            for w in waves:
                                if w.name and w.description:
                                    record_loaded_file(session.data_manager, wave_name=w.name, file_path=w.description)
                                if payload.mode == "single_pod":
                                    ndim = int(w.ndim)
                                    if expected_ndim is None:
                                        expected_ndim = ndim
                                    elif ndim != expected_ndim:
                                        raise ValueError(f"ndim mismatch for batch: expected {expected_ndim}D, got {ndim}D")

                            loaded_groups.append(waves)
                            loaded += 1
                        except Exception as exc:  # noqa: BLE001
                            skipped += 1
                            print(f"[files] skip: {rel} ({exc})", file=sys.stderr)
                            continue

                    if not loaded_groups:
                        raise RuntimeError("no files could be loaded")

                    prev_selected = session.board.selected
                    if payload.mode == "single_pod":
                        merged_waves = [wave for group in loaded_groups for wave in group]
                        session.board.add(merged_waves)
                    else:
                        for waves in loaded_groups:
                            session.board.add(waves)
                    session.board.set_selected(prev_selected)

                    if skipped:
                        print(f"[files] batch load done: loaded={loaded}, skipped={skipped}", file=sys.stderr)
        except Exception as exc:  # noqa: BLE001
            status = "error"
            error = ErrorInfo(message=str(exc), traceback=traceback.format_exc())

        try:
            session.wave_manager.flush()
        except Exception:  # noqa: BLE001
            pass
        try:
            session.data_manager.flush()
        except Exception:  # noqa: BLE001
            pass
        save_active_board_state(session, include_waves=True)
        diff = diff_board(before, session.board)
        board_snapshot = diff.board_snapshot
        board_patch = diff.board_patch
        exec_ms = (perf_counter() - t0) * 1000.0

    return RunResponse(
        status=status,
        board=board_snapshot,
        boardPatch=board_patch,
        stdout=stdout_io.getvalue(),
        stderr=stderr_io.getvalue(),
        error=error,
        execMs=exec_ms,
    )
