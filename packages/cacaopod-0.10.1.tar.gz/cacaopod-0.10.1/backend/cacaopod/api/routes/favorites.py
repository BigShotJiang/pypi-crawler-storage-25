from __future__ import annotations

import base64
import io
import json
import os
import re
import time
import uuid
from pathlib import Path
from typing import Any

import numpy as np
from fastapi import APIRouter, HTTPException, Request, Response
from PIL import Image

from cacaopod.api_models import (
    BoardUpdateResponse,
    FavoriteAddRequest,
    FavoriteCommentRequest,
    FavoriteLoadRequest,
    FavoriteSummary,
    FavoritesListResponse,
    GifExportRequest,
    HeatmapViewSettings,
    TraceViewSettings,
)
from cacaopod.config import data_root
from cacaopod.session import (
    capture_board_fingerprint,
    capture_selected_pod_undo,
    diff_board,
    get_or_create_session,
    maybe_push_pod_undo,
    save_active_board_state,
)
from cacaopod.state.paths import safe_storage_key
from cacaopod.wave import Wave, _load_wave_npz, _save_wave_npz, bind_wave_manager

router = APIRouter()


def _favorites_root() -> Path:
    root = data_root() / "favorites"
    root.mkdir(parents=True, exist_ok=True)
    return root


def _favorites_index_path() -> Path:
    return _favorites_root() / "index.json"


def _load_favorites_index() -> list[dict[str, Any]]:
    path = _favorites_index_path()
    if not path.exists():
        return []
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
    except Exception:  # noqa: BLE001
        return []
    if not isinstance(raw, list):
        return []
    out: list[dict[str, Any]] = []
    for item in raw:
        if not isinstance(item, dict):
            continue
        out.append(dict(item))
    return out


def _save_favorites_index(items: list[dict[str, Any]]) -> None:
    path = _favorites_index_path()
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(items, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _favorite_dir(fid: str) -> Path:
    safe = safe_storage_key(fid, fallback="fav")
    return _favorites_root() / safe


def _favorite_meta_path(fid: str) -> Path:
    return _favorite_dir(fid) / "meta.json"


def _favorite_thumb_path(fid: str) -> Path:
    return _favorite_dir(fid) / "thumb.png"


def _favorite_thumb_url(fid: str) -> str:
    return f"/api/favorites/thumb/{fid}.png"


def _decode_png_data_url(data_url: str) -> bytes:
    raw = str(data_url or "").strip()
    prefix = "data:image/png;base64,"
    if not raw.startswith(prefix):
        raise ValueError("thumbnail_data_url must be a data:image/png;base64,... URL")
    b64 = raw[len(prefix) :]
    try:
        data = base64.b64decode(b64, validate=True)
    except Exception as exc:  # noqa: BLE001
        raise ValueError("invalid base64 in thumbnail_data_url") from exc
    if not data.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("thumbnail_data_url is not a PNG")
    return data


def _favorite_summary_from_meta(meta: dict[str, Any]) -> FavoriteSummary | None:
    fid = str(meta.get("id") or "").strip()
    if not fid:
        return None
    try:
        ts_ms = int(meta.get("ts") or 0)
    except Exception:  # noqa: BLE001
        ts_ms = 0
    wave_name = meta.get("wave_name")
    wave_name_s = wave_name.strip() if isinstance(wave_name, str) and wave_name.strip() else None
    wave_wm_path = meta.get("wave_wm_path")
    wave_wm_path_s = wave_wm_path.strip() if isinstance(wave_wm_path, str) and wave_wm_path.strip() else None
    comment = meta.get("comment")
    comment_s = str(comment) if comment is not None else ""
    hm_raw = meta.get("heatmapSettings") or {}
    try:
        hm = HeatmapViewSettings.model_validate(hm_raw)
    except Exception:  # noqa: BLE001
        hm = HeatmapViewSettings()

    ts_raw = meta.get("traceSettings") or {}
    try:
        trace_settings = TraceViewSettings.model_validate(ts_raw)
    except Exception:  # noqa: BLE001
        trace_settings = TraceViewSettings()
    return FavoriteSummary(
        id=fid,
        ts=ts_ms,
        wave_name=wave_name_s,
        wave_wm_path=wave_wm_path_s,
        comment=comment_s,
        heatmapSettings=hm,
        traceSettings=trace_settings,
        thumb_url=_favorite_thumb_url(fid),
    )


def _load_favorite_meta(fid: str) -> dict[str, Any]:
    path = _favorite_meta_path(fid)
    if not path.exists():
        raise FileNotFoundError(fid)
    raw = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict):
        raise ValueError("invalid favorite meta")
    return dict(raw)


@router.get("/api/favorites", response_model=FavoritesListResponse)
async def list_favorites(request: Request, response: Response) -> FavoritesListResponse:
    _session_id, _session = get_or_create_session(request, response)
    items = _load_favorites_index()
    favorites: list[FavoriteSummary] = []
    for item in items:
        fid = str(item.get("id") or "").strip()
        if not fid:
            continue
        if not _favorite_dir(fid).exists():
            continue
        if not _favorite_thumb_path(fid).exists():
            continue
        summary = _favorite_summary_from_meta(item)
        if summary is not None:
            favorites.append(summary)
    favorites.sort(key=lambda x: x.ts, reverse=True)
    return FavoritesListResponse(favorites=favorites)


@router.get("/api/favorites/thumb/{fid}.png")
async def favorite_thumbnail(fid: str, request: Request, response: Response) -> Response:
    _session_id, _session = get_or_create_session(request, response)
    path = _favorite_thumb_path(fid)
    if not path.exists():
        raise HTTPException(status_code=404, detail="thumbnail not found")
    return Response(content=path.read_bytes(), media_type="image/png")


def _safe_gif_filename(raw: str | None) -> str:
    s = str(raw or "").strip()
    if not s:
        s = f"heatmap-{int(time.time() * 1000)}.gif"
    s = os.path.basename(s)
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", s).strip("._")
    if not s:
        s = f"heatmap-{int(time.time() * 1000)}.gif"
    if not s.lower().endswith(".gif"):
        s += ".gif"
    return s[:200]


@router.post("/api/export/gif")
async def export_gif(payload: GifExportRequest, request: Request, response: Response) -> Response:
    _session_id, _session = get_or_create_session(request, response)
    if not payload.frames:
        raise HTTPException(status_code=400, detail="frames is empty")

    filename = _safe_gif_filename(payload.filename)

    try:
        images_rgb: list[Image.Image] = []
        base_size: tuple[int, int] | None = None
        for url in payload.frames:
            png = _decode_png_data_url(url)
            img = Image.open(io.BytesIO(png)).convert("RGBA")
            if base_size is None:
                base_size = img.size
            elif img.size != base_size:
                img = img.resize(base_size, resample=Image.Resampling.LANCZOS)
            bg = Image.new("RGBA", img.size, (255, 255, 255, 255))
            bg.alpha_composite(img)
            images_rgb.append(bg.convert("RGB"))

        if not images_rgb:
            raise ValueError("no decoded frames")

        palette = images_rgb[0].quantize(colors=256, dither=Image.Dither.NONE)
        frames_p = [palette] + [im.quantize(palette=palette, dither=Image.Dither.NONE) for im in images_rgb[1:]]

        buf = io.BytesIO()
        frames_p[0].save(
            buf,
            format="GIF",
            save_all=True,
            append_images=frames_p[1:],
            duration=int(payload.delay_ms),
            loop=0,
            optimize=False,
        )
        data = buf.getvalue()
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        raise HTTPException(status_code=400, detail=f"failed to build gif: {exc}") from exc

    try:
        out_dir = data_root() / "exports"
        out_dir.mkdir(parents=True, exist_ok=True)
        (out_dir / filename).write_bytes(data)
    except Exception:  # noqa: BLE001
        pass

    headers = {"content-disposition": f'attachment; filename="{filename}"'}
    return Response(content=data, media_type="image/gif", headers=headers)


@router.post("/api/favorites/add", response_model=FavoriteSummary)
async def add_favorite(payload: FavoriteAddRequest, request: Request, response: Response) -> FavoriteSummary:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        pod = session.board.get(payload.selection.i)
        if not pod.waves:
            raise HTTPException(status_code=400, detail="selected pod is empty")

        fig_id = uuid.uuid4().hex
        fig_dir = _favorite_dir(fig_id)
        fig_dir.mkdir(parents=True, exist_ok=True)

        wave_wm_abs: str | None = None
        wave_files: list[str] = []
        waves_meta: list[dict[str, Any]] = []

        with bind_wave_manager(session.wave_manager):
            for idx, src in enumerate(pod.waves):
                arr_copy = np.asarray(src).copy()
                w = Wave(arr_copy)
                w._offset_dim = src._offset_dim  # type: ignore[attr-defined]
                w._delta_dim = src._delta_dim  # type: ignore[attr-defined]
                w._explicit_coords_dim = [
                    (np.asarray(coords).copy() if coords is not None else None) for coords in src._explicit_coords_dim  # type: ignore[attr-defined]
                ]
                w._description = src.description  # type: ignore[attr-defined]
                w._userdata = type(src.userdata)(dict(src.userdata), wave=w)  # type: ignore[call-arg]
                w._name = src.name  # type: ignore[attr-defined]
                w._wm_path = None  # type: ignore[attr-defined]

                if idx == 0:
                    wave_wm_path = getattr(src, "_wm_path", None)
                    wave_wm_abs = f"/{wave_wm_path}" if isinstance(wave_wm_path, str) and wave_wm_path.strip() else None

                wave_file = f"{w.uid}.npz"
                _save_wave_npz(fig_dir / wave_file, w)

                wave_files.append(wave_file)
                waves_meta.append(
                    {
                        "uid": w.uid,
                        "file": wave_file,
                        "name": w.name,
                        "description": w.description,
                        "shape": list(map(int, w.shape)),
                        "dtype": str(w.dtype),
                    }
                )

        try:
            thumb_bytes = _decode_png_data_url(payload.thumbnail_data_url)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        _favorite_thumb_path(fig_id).write_bytes(thumb_bytes)

        primary = waves_meta[0] if waves_meta else {}
        meta: dict[str, Any] = {
            "version": 3,
            "id": fig_id,
            "ts": int(time.time() * 1000),
            "wave_name": primary.get("name"),
            "wave_wm_path": wave_wm_abs,
            # Backward-compatible single-wave fields
            "wave_uid": primary.get("uid"),
            "wave_file": primary.get("file"),
            "shape": primary.get("shape"),
            "dtype": primary.get("dtype"),
            # Multi-wave payload
            "wave_files": list(wave_files),
            "waves": list(waves_meta),
            # Pod settings (source of truth)
            "heatmapSettings": pod.heatmap_settings.model_dump(),
            "traceSettings": pod.trace_settings.model_dump(),
            "traceSettingsByWave": [
                (ts.model_dump() if isinstance(ts, TraceViewSettings) else TraceViewSettings().model_dump())
                for ts in (
                    pod.trace_settings_by_wave
                    if isinstance(getattr(pod, "trace_settings_by_wave", None), list) and len(pod.trace_settings_by_wave) == len(pod.waves)
                    else [pod.trace_settings for _ in pod.waves]
                )
            ],
            "activeWaveIndex": int(getattr(pod, "active_wave_index", 0)),
            "comment": str(payload.comment or ""),
        }
        _favorite_meta_path(fig_id).write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

        items = _load_favorites_index()
        items.append(meta)
        _save_favorites_index(items)

        summary = _favorite_summary_from_meta(meta)
        if summary is None:  # pragma: no cover
            raise HTTPException(status_code=500, detail="failed to build favorite summary")
        return summary


@router.post("/api/favorites/load", response_model=BoardUpdateResponse)
async def load_favorite(payload: FavoriteLoadRequest, request: Request, response: Response) -> BoardUpdateResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        if not payload.new_pod:
            try:
                session.board.set_selected(payload.selection.i)
            except Exception:  # noqa: BLE001
                pass
        undo_entry = capture_selected_pod_undo(session.board)
        before = capture_board_fingerprint(session.board)

        try:
            meta = _load_favorite_meta(payload.id)
        except FileNotFoundError as exc:
            raise HTTPException(status_code=404, detail="favorite not found") from exc
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(status_code=400, detail=str(exc)) from exc

        raw_wave_files = meta.get("wave_files")
        wave_files: list[str] = []
        if isinstance(raw_wave_files, list):
            for item in raw_wave_files:
                if isinstance(item, str) and item.strip():
                    wave_files.append(item.strip())
        if not wave_files:
            wave_file = meta.get("wave_file")
            if isinstance(wave_file, str) and wave_file.strip():
                wave_files = [wave_file.strip()]
        if not wave_files:
            raise HTTPException(status_code=400, detail="favorite meta missing wave_files")

        waves: list[Wave] = []
        for wave_file in wave_files:
            wave_path = _favorite_dir(payload.id) / wave_file
            if not wave_path.exists():
                raise HTTPException(status_code=404, detail="favorite wave file missing")
            try:
                wave = _load_wave_npz(wave_path, manager=session.wave_manager, wm_path=None)
            except Exception as exc:  # noqa: BLE001
                raise HTTPException(status_code=400, detail=f"failed to load favorite wave: {exc}") from exc
            # Always detach by copying so edits in the board don't affect source data.
            try:
                wave = wave.copy()
            except Exception:  # noqa: BLE001
                pass
            waves.append(wave)

        show_value: Wave | list[Wave] = waves if len(waves) != 1 else waves[0]
        if payload.new_pod:
            target = session.board.add(show_value)
        else:
            try:
                session.board.set_selected(payload.selection.i)
                target = session.board.get()
            except IndexError:
                target = session.board.add(show_value)
            else:
                target.show(show_value)

        hm_raw = meta.get("heatmapSettings") or {}
        try:
            hm = HeatmapViewSettings.model_validate(hm_raw)
        except Exception:  # noqa: BLE001
            hm = HeatmapViewSettings()

        ts_raw = meta.get("traceSettings") or {}
        try:
            trace_settings = TraceViewSettings.model_validate(ts_raw)
        except Exception:  # noqa: BLE001
            trace_settings = TraceViewSettings()
        target.heatmap_settings = hm
        target.trace_settings = trace_settings
        if target.waves:
            ts_by_raw = meta.get("traceSettingsByWave")
            parsed_by: list[TraceViewSettings] = []
            if isinstance(ts_by_raw, list):
                for item in ts_by_raw:
                    if not isinstance(item, dict):
                        continue
                    try:
                        parsed_by.append(TraceViewSettings.model_validate(item))
                    except Exception:  # noqa: BLE001
                        parsed_by.append(TraceViewSettings())
            n = len(target.waves)
            if not parsed_by:
                parsed_by = [trace_settings for _ in range(n)]
            parsed_by = parsed_by[:n]
            while len(parsed_by) < n:
                parsed_by.append(TraceViewSettings())
            target.trace_settings_by_wave = parsed_by
            target.trace_settings = target.trace_settings_by_wave[0]

            try:
                ii = int(meta.get("activeWaveIndex") or 0)
            except Exception:  # noqa: BLE001
                ii = 0
            target.active_wave_index = min(max(ii, 0), max(0, n - 1))

        maybe_push_pod_undo(session, undo_entry)
        save_active_board_state(session, include_waves=True)
        diff = diff_board(before, session.board)
        return BoardUpdateResponse(board=diff.board_snapshot, boardPatch=diff.board_patch)


@router.post("/api/favorites/comment", response_model=FavoriteSummary)
async def update_favorite_comment(payload: FavoriteCommentRequest, request: Request, response: Response) -> FavoriteSummary:
    _session_id, _session = get_or_create_session(request, response)
    try:
        meta = _load_favorite_meta(payload.id)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail="favorite not found") from exc

    meta["comment"] = str(payload.comment or "")
    _favorite_meta_path(payload.id).write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")

    items = _load_favorites_index()
    for item in items:
        if str(item.get("id") or "").strip() == payload.id:
            item["comment"] = meta["comment"]
            break
    _save_favorites_index(items)

    summary = _favorite_summary_from_meta(meta)
    if summary is None:  # pragma: no cover
        raise HTTPException(status_code=500, detail="failed to build favorite summary")
    return summary


@router.delete("/api/favorites/{fid}")
async def delete_favorite(fid: str, request: Request, response: Response) -> dict[str, str]:
    _session_id, _session = get_or_create_session(request, response)
    fig_dir = _favorite_dir(fid)
    if fig_dir.exists():
        try:
            for p in fig_dir.iterdir():
                try:
                    p.unlink()
                except Exception:  # noqa: BLE001
                    pass
            fig_dir.rmdir()
        except Exception:  # noqa: BLE001
            pass

    items = _load_favorites_index()
    items = [it for it in items if str(it.get("id") or "").strip() != fid]
    _save_favorites_index(items)
    return {"status": "ok"}
