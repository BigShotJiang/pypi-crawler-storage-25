from __future__ import annotations

import io
import sys
import traceback
from contextlib import redirect_stderr, redirect_stdout
from pathlib import Path
from time import perf_counter
from typing import Literal

from fastapi import APIRouter, HTTPException, Request, Response

from cacaopod.api_models import (
    ErrorInfo,
    FileChildrenResponse,
    FileListResponse,
    RunResponse,
    WebDavBatchLoadRequest,
    WebDavChildrenRequest,
    WebDavListRequest,
    WebDavLoadRequest,
)
from cacaopod.config import in_workdir, workdir
from cacaopod.file_loader import (
    FileLoader,
    FileLoaderRegistry,
    collapse_loaded_waves,
    ensure_wave_list,
    finalize_loaded_waves,
    invoke_loader,
    loader_output_name,
    materialize_loader_result,
    normalize_loader_result,
)
from cacaopod.file_manager import FileManager
from cacaopod.loaded_files import record_loaded_file
from cacaopod.naming_rule import NamingRuleRegistry
from cacaopod.session import (
    capture_board_fingerprint,
    capture_selected_pod_undo,
    diff_board,
    get_or_create_session,
    maybe_push_pod_undo,
    save_active_board_state,
)
from cacaopod.wave import Wave, bind_wave_manager
from cacaopod.sort_utils import alphanumeric
from cacaopod.webdav import list_children, list_files_by_ext

router = APIRouter()


@router.post("/api/webdav/children", response_model=FileChildrenResponse)
async def webdav_children(payload: WebDavChildrenRequest, request: Request, response: Response) -> FileChildrenResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            entries = list_children(
                payload.auth.url,
                username=payload.auth.username,
                password=payload.auth.password,
                dir_path=payload.dir or "",
            )
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        entries.sort(key=lambda e: (e.kind != "dir", alphanumeric(e.name)))
        return FileChildrenResponse(entries=entries)


@router.post("/api/webdav/list", response_model=FileListResponse)
async def webdav_list(payload: WebDavListRequest, request: Request, response: Response) -> FileListResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            files = list_files_by_ext(
                payload.auth.url,
                username=payload.auth.username,
                password=payload.auth.password,
                dir_path=payload.dir or "",
                ext=payload.ext or "",
            )
        except Exception as exc:  # noqa: BLE001
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        files.sort(key=lambda e: alphanumeric(e.name))
        return FileListResponse(files=files)


@router.post("/api/webdav/load", response_model=RunResponse)
async def webdav_load(payload: WebDavLoadRequest, request: Request, response: Response) -> RunResponse:
    _session_id, session = get_or_create_session(request, response)
    stdout_io = io.StringIO()
    stderr_io = io.StringIO()
    status: Literal["ok", "error"] = "ok"
    error: ErrorInfo | None = None
    board_snapshot = None
    board_patch = None
    exec_ms: float | None = None

    with session.lock:
        t0 = perf_counter()
        if not payload.new_pod:
            session.board.set_selected(payload.selection.i)
        undo_entry = capture_selected_pod_undo(session.board)
        before = capture_board_fingerprint(session.board)
        try:
            allow_overwrite = bool(getattr(payload, "allow_overwrite", False))
            target_name = str(payload.name).strip() if payload.name is not None else ""
            if not target_name:
                target_name = ""

            remote_path = str(payload.file_path or "").strip()
            if not remote_path:
                raise ValueError("file_path is required")
            if remote_path.lower().startswith("webdav:"):
                remote_path = remote_path[len("webdav:") :].lstrip("/")

            if payload.naming_rule is not None and str(payload.naming_rule.name or "").strip():
                nr = NamingRuleRegistry(workdir=workdir()).get(payload.naming_rule.name, location=payload.naming_rule.location)
                base = Path(remote_path).name
                target_name = str(nr(base)).strip()
                if not target_name:
                    raise ValueError("naming_rule produced an empty wave name")
                allow_overwrite = True

            requested_name = target_name or None

            file_manager = FileManager(workdir=workdir())
            local_path = Path(
                file_manager.localize(
                    f"webdav:{remote_path}",
                    webdav_url=payload.auth.url,
                    webdav_user=payload.auth.username,
                    webdav_password=payload.auth.password,
                )
            )
            if not local_path.exists():
                raise FileNotFoundError(str(local_path))
            if not local_path.is_file():
                raise ValueError("path is not a file")

            rel_desc = f"webdav:{remote_path}"

            with redirect_stdout(stdout_io), redirect_stderr(stderr_io):
                with bind_wave_manager(session.wave_manager), in_workdir(workdir()):
                    registry = FileLoaderRegistry(workdir=workdir())
                    if payload.loader is None or not payload.loader.name.strip():
                        loaded_value = FileLoader(workdir=workdir(), registry=registry)(
                            str(local_path),
                            name=requested_name,
                            overwrite=allow_overwrite,
                            description=rel_desc,
                            **payload.kwargs,
                        )
                    else:
                        loader = registry.get(payload.loader.name, location=payload.loader.location)
                        result = invoke_loader(loader, local_path, **payload.kwargs)
                        loaded_value = collapse_loaded_waves(
                            materialize_loader_result(
                                result,
                                name=requested_name,
                                overwrite=allow_overwrite,
                                description=rel_desc,
                                loader_name=loader.name,
                            )
                        )

                for w in ensure_wave_list(loaded_value):
                    if w.name and w.description:
                        record_loaded_file(session.data_manager, wave_name=w.name, file_path=w.description)

                if payload.new_pod:
                    session.board.add(loaded_value)
                else:
                    if payload.append_pod:
                        session.board.append(loaded_value)
                    else:
                        session.board.show(loaded_value)
        except Exception as exc:  # noqa: BLE001
            status = "error"
            error = ErrorInfo(message=str(exc), traceback=traceback.format_exc())
        try:
            session.wave_manager.flush()
        except Exception:  # noqa: BLE001
            pass
        try:
            session.data_manager.flush()
        except Exception:  # noqa: BLE001
            pass
        save_active_board_state(session, include_waves=True)
        diff = diff_board(before, session.board)
        maybe_push_pod_undo(session, undo_entry)
        board_snapshot = diff.board_snapshot
        board_patch = diff.board_patch
        exec_ms = (perf_counter() - t0) * 1000.0

    return RunResponse(
        status=status,
        board=board_snapshot,
        boardPatch=board_patch,
        stdout=stdout_io.getvalue(),
        stderr=stderr_io.getvalue(),
        error=error,
        execMs=exec_ms,
    )


@router.post("/api/webdav/load_batch", response_model=RunResponse)
async def webdav_load_batch(payload: WebDavBatchLoadRequest, request: Request, response: Response) -> RunResponse:
    _session_id, session = get_or_create_session(request, response)
    stdout_io = io.StringIO()
    stderr_io = io.StringIO()
    status: Literal["ok", "error"] = "ok"
    error: ErrorInfo | None = None
    board_snapshot = None
    board_patch = None
    exec_ms: float | None = None

    with session.lock:
        t0 = perf_counter()
        before = capture_board_fingerprint(session.board)
        try:
            allow_overwrite = bool(getattr(payload, "allow_overwrite", False))
            skip_existing = bool(getattr(payload, "skip_existing", False))
            files = [str(p).strip() for p in (payload.files or [])]
            files = [p for p in files if p]
            if not files:
                raise ValueError("no files to load")

            with redirect_stdout(stdout_io), redirect_stderr(stderr_io):
                with bind_wave_manager(session.wave_manager), in_workdir(workdir()):
                    loaded = 0
                    skipped = 0
                    loaded_groups: list[list[Wave]] = []
                    expected_ndim: int | None = None
                    file_manager = FileManager(workdir=workdir())
                    registry = FileLoaderRegistry(workdir=workdir())

                    as_named = bool(payload.as_named_waves)
                    target_names: list[str | None] = [None for _ in files]
                    if as_named:
                        allow_overwrite = True
                        if payload.naming_rule is None or not str(payload.naming_rule.name or "").strip():
                            raise ValueError("naming_rule is required when as_named_waves is true")
                        nr = NamingRuleRegistry(workdir=workdir()).get(payload.naming_rule.name, location=payload.naming_rule.location)

                        seen: dict[str, int] = {}
                        duplicates: set[str] = set()
                        for i, rel in enumerate(files):
                            base = str(rel).strip().replace("\\", "/").split("/")[-1].strip()
                            name = nr(base or rel)
                            target_names[i] = name
                            prev = seen.get(name)
                            if prev is None:
                                seen[name] = 1
                            else:
                                seen[name] = prev + 1
                                duplicates.add(name)
                        if duplicates:
                            dup_s = ", ".join(sorted(duplicates)[:20])
                            raise ValueError(f"duplicate wave names from naming_rule: {dup_s}")

                    existing_names: set[str] = set()
                    if as_named and skip_existing:
                        try:
                            wm = session.wave_manager
                            board_id = str(getattr(wm, "active_board_id", "") or "").strip()
                            if board_id:
                                existing_names = {name for name, _uid in wm.list(board_id=board_id)}
                        except Exception:  # noqa: BLE001
                            existing_names = set()

                    selected_loader = None
                    if payload.loader is not None and payload.loader.name.strip():
                        selected_loader = registry.get(payload.loader.name, location=payload.loader.location)

                    for i, rel in enumerate(files):
                        target_name = target_names[i]
                        try:
                            remote_path = str(rel).strip()
                            if not remote_path:
                                raise ValueError("empty file path")
                            if remote_path.lower().startswith("webdav:"):
                                remote_path = remote_path[len("webdav:") :].lstrip("/")

                            local_path = Path(
                                file_manager.localize(
                                    f"webdav:{remote_path}",
                                    webdav_url=payload.auth.url,
                                    webdav_user=payload.auth.username,
                                    webdav_password=payload.auth.password,
                                )
                            )
                            if not local_path.exists():
                                raise FileNotFoundError(str(local_path))
                            if not local_path.is_file():
                                raise ValueError("path is not a file")
                            rel_desc = f"webdav:{remote_path}"

                            loader = selected_loader or registry.resolve_for_extension(local_path.suffix)
                            result = invoke_loader(loader, local_path, **payload.kwargs)
                            normalized = normalize_loader_result(result, description=rel_desc, loader_name=loader.name)

                            if as_named:
                                if not target_name:
                                    raise ValueError("internal error: missing target wave name")
                                if skip_existing:
                                    intended_names = [loader_output_name(item.key, target_name) for item in normalized]
                                    if any(name in existing_names for name in intended_names if name):
                                        skipped += 1
                                        continue
                                waves = finalize_loaded_waves(normalized, name=target_name, overwrite=allow_overwrite)
                            else:
                                waves = finalize_loaded_waves(normalized)

                            for w in waves:
                                if w.name and w.description:
                                    record_loaded_file(session.data_manager, wave_name=w.name, file_path=w.description)
                                if payload.mode == "single_pod":
                                    ndim = int(w.ndim)
                                    if expected_ndim is None:
                                        expected_ndim = ndim
                                    elif ndim != expected_ndim:
                                        raise ValueError(f"ndim mismatch for batch: expected {expected_ndim}D, got {ndim}D")

                            loaded_groups.append(waves)
                            loaded += 1
                        except Exception as exc:  # noqa: BLE001
                            skipped += 1
                            print(f"[webdav] skip: {rel} ({exc})", file=sys.stderr)
                            continue
                    if not loaded_groups:
                        raise RuntimeError("no files could be loaded")

                    prev_selected = session.board.selected
                    if payload.mode == "single_pod":
                        merged_waves = [wave for group in loaded_groups for wave in group]
                        session.board.add(merged_waves)
                    else:
                        for waves in loaded_groups:
                            session.board.add(waves)
                    session.board.set_selected(prev_selected)

                    if skipped:
                        print(f"[webdav] batch load done: loaded={loaded}, skipped={skipped}", file=sys.stderr)
        except Exception as exc:  # noqa: BLE001
            status = "error"
            error = ErrorInfo(message=str(exc), traceback=traceback.format_exc())

        try:
            session.wave_manager.flush()
        except Exception:  # noqa: BLE001
            pass
        try:
            session.data_manager.flush()
        except Exception:  # noqa: BLE001
            pass
        save_active_board_state(session, include_waves=True)
        diff = diff_board(before, session.board)
        board_snapshot = diff.board_snapshot
        board_patch = diff.board_patch
        exec_ms = (perf_counter() - t0) * 1000.0

    return RunResponse(
        status=status,
        board=board_snapshot,
        boardPatch=board_patch,
        stdout=stdout_io.getvalue(),
        stderr=stderr_io.getvalue(),
        error=error,
        execMs=exec_ms,
    )
