from __future__ import annotations

import inspect
import io
import traceback
from contextlib import redirect_stderr, redirect_stdout
from typing import Literal
from time import perf_counter, time

import numpy as np
from fastapi import APIRouter, HTTPException, Request, Response
from starlette.concurrency import run_in_threadpool

from cacaopod.api_models import (
    RunResponse,
    ToolChatMessage,
    ToolDocstringRequest,
    ToolDocstringResponse,
    ToolFunctionFitRequest,
    ToolGptCoderHistoryResponse,
    ToolGptCoderRequest,
    ToolGptCoderResponse,
    ToolFormulaFitRequest,
    StatusResponse,
    ToolRunRequest,
    ToolSaveRequest,
    TraceViewSettings,
)
from cacaopod.api_models import ToolSourceResponse, ToolsListResponse, ToolSummaryInfo, ToolParamInfo
from cacaopod.config import in_workdir, workdir
from cacaopod.session import (
    capture_board_fingerprint,
    capture_selected_pod_undo,
    diff_board,
    get_or_create_session,
    maybe_push_pod_undo,
    save_active_board_state,
)
from cacaopod.tool_utils import (
    apply_result_to_wave_inplace,
    generate_tool_code_via_openai,
    generate_function_fit_tool_source,
    generate_formula_fit_tool_source,
    validate_function_fit_inputs,
    validate_formula_fit_inputs,
    normalize_fit_result,
    suggest_docstring_via_openai,
    tool_is_data_process,
    tool_is_fitting,
)
from cacaopod.state.tool_coder_chat import load_tool_chat, save_tool_chat
from cacaopod.wave import Wave, bind_wave_manager

router = APIRouter()


def _set_selected_pod_trace_mode(session: object, mode: str) -> None:
    try:
        pod = session.board.get()  # type: ignore[attr-defined]
        settings = getattr(pod, "trace_settings_by_wave", None)
        if not isinstance(settings, list):
            return
        next_settings = []
        for ts in settings:
            if isinstance(ts, TraceViewSettings):
                next_settings.append(TraceViewSettings.model_validate({**ts.model_dump(), "mode": mode}))
            else:
                next_settings.append(TraceViewSettings(mode=mode))
        pod.trace_settings_by_wave = next_settings
        if next_settings:
            pod.trace_settings = next_settings[0]
    except Exception:  # noqa: BLE001
        return


@router.get("/api/tools", response_model=ToolsListResponse)
async def list_tools(request: Request, response: Response) -> ToolsListResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        tools = []
        for t in session.toolbox.list():
            tools.append(
                ToolSummaryInfo(
                    name=t.name,
                    ndim=t.ndim,
                    location=t.location,
                    signature=t.signature,
                    doc=t.doc,
                    data_process=tool_is_data_process(t.doc),
                    params=[
                        ToolParamInfo(
                            name=p.name,
                            annotation=p.annotation,
                            default_repr=p.default_repr,
                            is_wave=p.is_wave,
                        )
                        for p in t.params
                    ],
                )
            )
        return ToolsListResponse(tools=tools)


@router.post("/api/tools/run", response_model=RunResponse)
async def run_tool(payload: ToolRunRequest, request: Request, response: Response) -> RunResponse:
    _session_id, session = get_or_create_session(request, response)
    stdout_io = io.StringIO()
    stderr_io = io.StringIO()
    status: Literal["ok", "error"] = "ok"
    error = None
    board_snapshot = None
    board_patch = None
    exec_ms: float | None = None

    with session.lock:
        t0 = perf_counter()
        session.board.set_selected(payload.selection.i)
        undo_entry = capture_selected_pod_undo(session.board)
        before = capture_board_fingerprint(session.board)
        try:
            pod = session.board.get(payload.selection.i)
            context_ndim: int | None = None
            if getattr(pod, "waves", None):
                try:
                    if payload.waveIndex is None:
                        context_ndim = int(pod.wave.ndim)
                    else:
                        ii = int(payload.waveIndex)
                        if ii < 0 or ii >= len(pod.waves):
                            raise ValueError(f"waveIndex out of range: {ii} for n={len(pod.waves)}")
                        context_ndim = int(pod.waves[ii].ndim)
                except Exception:  # noqa: BLE001
                    context_ndim = None
            elif payload.ndim in (1, 2, 3):
                context_ndim = int(payload.ndim)

            tool = session.toolbox.get(payload.name, ndim=context_ndim)
            tool_doc = inspect.getdoc(tool._func) or ""
            data_process = tool_is_data_process(tool_doc)
            is_fitting = tool_is_fitting(tool_doc, name=tool.name)
            wave_params = getattr(tool, "_wave_params", set())
            wave_param_names = [p.name for p in tool.signature.parameters.values() if p.name in wave_params]
            with redirect_stdout(stdout_io), redirect_stderr(stderr_io):
                with bind_wave_manager(session.wave_manager), in_workdir(workdir()):
                    if len(wave_param_names) > 1:
                        raise ValueError("tools with multiple Wave inputs are not supported yet")

                    target_wave: Wave | None = None
                    if len(wave_param_names) == 1:
                        if not pod.waves:
                            raise ValueError("selected pod is empty")
                        if payload.waveIndex is None:
                            target_wave = pod.wave
                        else:
                            ii = int(payload.waveIndex)
                            if ii < 0 or ii >= len(pod.waves):
                                raise ValueError(f"waveIndex out of range: {ii} for n={len(pod.waves)}")
                            target_wave = pod.waves[ii]
                        wave_name = wave_param_names[0]
                        wave_param = tool.signature.parameters[wave_name]
                        if wave_param.kind == inspect.Parameter.POSITIONAL_ONLY:
                            first_name = next(iter(tool.signature.parameters.keys()), "")
                            if first_name != wave_name:
                                raise ValueError("positional-only Wave parameter must be the first parameter")
                            result = tool(target_wave, **payload.kwargs)
                        else:
                            kwargs = dict(payload.kwargs)
                            kwargs.pop(wave_name, None)
                            kwargs[wave_name] = target_wave
                            result = tool(**kwargs)
                    else:
                        result = tool(**payload.kwargs)

                    if result is not None:
                        if is_fitting:
                            coeffs, errors, fit_wave, metrics = normalize_fit_result(result)
                            if coeffs:
                                print(f"fit coeffs: {coeffs}")
                            if errors:
                                print(f"fit errors: {errors}")
                            if metrics is not None:
                                print(f"fit metrics: {metrics}")

                            if fit_wave is not None:
                                if isinstance(fit_wave, Wave):
                                    fw = fit_wave
                                else:
                                    arr = np.asarray(fit_wave)
                                    if target_wave is not None:
                                        fw = target_wave.copy(data=arr)
                                    else:
                                        fw = Wave(arr)

                                if target_wave is not None and int(target_wave.ndim) == int(np.asarray(fw).ndim):
                                    pod.append(fw)
                                else:
                                    session.board.show(fw)
                        elif data_process and len(wave_param_names) == 1 and target_wave is not None:
                            apply_result_to_wave_inplace(target_wave, result)
                        else:
                            arr = np.asarray(result)
                            if arr.ndim in (1, 2):
                                session.board.show(result)
                                if str(tool.name).strip().lower() == "histogram" and arr.ndim == 1:
                                    _set_selected_pod_trace_mode(session, "bar")
                            else:
                                print(repr(result))
        except Exception as exc:  # noqa: BLE001
            status = "error"
            error = {"message": str(exc), "traceback": traceback.format_exc()}
        try:
            session.wave_manager.flush()
        except Exception:  # noqa: BLE001
            pass

        def needs_untracked_wave_save() -> bool:
            pods = getattr(session.board, "_pods", None)
            if not isinstance(pods, list):
                return False
            for p in pods:
                for w in getattr(p, "waves", []) or []:
                    wm_path = getattr(w, "_wm_path", None)
                    if isinstance(wm_path, str) and wm_path.strip():
                        continue
                    try:
                        rev = int(getattr(w, "_rev", 0))
                    except Exception:  # noqa: BLE001
                        rev = 0
                    try:
                        saved_rev = int(getattr(w, "_saved_rev", -1))
                    except Exception:  # noqa: BLE001
                        saved_rev = -1
                    if saved_rev != rev:
                        return True
            return False

        save_active_board_state(session, include_waves=needs_untracked_wave_save())
        diff = diff_board(before, session.board)
        maybe_push_pod_undo(session, undo_entry)
        board_snapshot = diff.board_snapshot
        board_patch = diff.board_patch
        exec_ms = (perf_counter() - t0) * 1000.0

    return RunResponse(
        status=status,
        board=board_snapshot,
        boardPatch=board_patch,
        stdout=stdout_io.getvalue(),
        stderr=stderr_io.getvalue(),
        error=error,
        execMs=exec_ms,
    )


@router.post("/api/tools/docstring", response_model=ToolDocstringResponse)
async def suggest_tool_docstring(payload: ToolDocstringRequest) -> ToolDocstringResponse:
    try:
        doc = await run_in_threadpool(
            suggest_docstring_via_openai,
            payload.source,
            name=payload.name,
            language=payload.language,
            model=payload.model,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return ToolDocstringResponse(docstring=doc)


@router.post("/api/tools/gpt_coder", response_model=ToolGptCoderResponse)
async def gpt_coder(payload: ToolGptCoderRequest) -> ToolGptCoderResponse:
    tool_id = str(getattr(payload, "tool_id", "") or "").strip() or str(payload.name or "").strip()
    messages = load_tool_chat(tool_id)

    req_text = str(payload.request or "").strip()
    if req_text:
        messages.append(ToolChatMessage(role="user", content=req_text, ts=int(time() * 1000)))
        # Persist only user messages (GPT replies are not recorded).
        messages = save_tool_chat(tool_id, messages)
    try:
        code = await run_in_threadpool(
            generate_tool_code_via_openai,
            name=payload.name,
            request=payload.request,
            console_code=payload.console_code,
            error=payload.error,
            fit_tool=bool(payload.fit_tool),
            chat_messages=[m.model_dump() for m in messages],
            context_wave=payload.context_wave.model_dump() if payload.context_wave is not None else None,
            language=payload.language,
            model=payload.model,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return ToolGptCoderResponse(code=code, messages=messages)


@router.get("/api/tools/gpt_coder/history", response_model=ToolGptCoderHistoryResponse)
async def get_gpt_coder_history(tool_id: str) -> ToolGptCoderHistoryResponse:
    tid = str(tool_id or "").strip()
    if not tid:
        raise HTTPException(status_code=400, detail="tool_id is required")
    return ToolGptCoderHistoryResponse(tool_id=tid, messages=load_tool_chat(tid))


@router.post("/api/tools/formula_fit", response_model=ToolSourceResponse)
async def create_formula_fit_tool(
    payload: ToolFormulaFitRequest,
    request: Request,
    response: Response,
) -> ToolSourceResponse:
    name = str(payload.name or "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="name is required")
    if not name.isidentifier():
        raise HTTPException(status_code=400, detail="tool name must be a valid Python identifier")
    if payload.location == "builtin":
        raise HTTPException(status_code=400, detail="cannot create builtin tools")
    params = [(p.name, p.init) for p in (payload.params or [])]
    try:
        source = generate_formula_fit_tool_source(name, int(payload.ndim), payload.formula, params)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            session.toolbox.save_source(name, source, location=payload.location, ndim=int(payload.ndim))
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        loc, stored = session.toolbox.get_source(name, location=payload.location, ndim=int(payload.ndim))
        return ToolSourceResponse(name=name, ndim=int(payload.ndim), location=loc, source=stored)


@router.post("/api/tools/formula_fit/check", response_model=StatusResponse)
async def check_formula_fit_tool(payload: ToolFormulaFitRequest) -> StatusResponse:
    params = [(p.name, p.init) for p in (payload.params or [])]
    try:
        validate_formula_fit_inputs(payload.formula, int(payload.ndim), params)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return StatusResponse(status="ok", message="ok")


@router.post("/api/tools/function_fit", response_model=ToolSourceResponse)
async def create_function_fit_tool(
    payload: ToolFunctionFitRequest,
    request: Request,
    response: Response,
) -> ToolSourceResponse:
    name = str(payload.name or "").strip()
    if not name:
        raise HTTPException(status_code=400, detail="name is required")
    if not name.isidentifier():
        raise HTTPException(status_code=400, detail="tool name must be a valid Python identifier")
    if payload.location == "builtin":
        raise HTTPException(status_code=400, detail="cannot create builtin tools")
    params = [(p.name, p.init) for p in (payload.params or [])]
    try:
        source = generate_function_fit_tool_source(name, int(payload.ndim), payload.model_source, payload.function_name, params)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            session.toolbox.save_source(name, source, location=payload.location, ndim=int(payload.ndim))
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        loc, stored = session.toolbox.get_source(name, location=payload.location, ndim=int(payload.ndim))
        return ToolSourceResponse(name=name, ndim=int(payload.ndim), location=loc, source=stored)


@router.post("/api/tools/function_fit/check", response_model=StatusResponse)
async def check_function_fit_tool(payload: ToolFunctionFitRequest) -> StatusResponse:
    params = [(p.name, p.init) for p in (payload.params or [])]
    try:
        fname, _context, names, defaults = validate_function_fit_inputs(payload.model_source, payload.function_name, int(payload.ndim), params)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    auto = [name for name, init in zip(names, defaults) if init is None]
    msg = f"{fname}({', '.join(names)})"
    if auto:
        msg += f"; auto initial guess: {', '.join(auto)}"
    return StatusResponse(status="ok", message=msg)


@router.get("/api/tools/{name}", response_model=ToolSourceResponse)
async def get_tool_source(name: str, request: Request, response: Response) -> ToolSourceResponse:
    # `ndim` is used to disambiguate tools that share a name across dimensions.
    ndim: int | None = None
    try:
        raw = request.query_params.get("ndim")
        if raw is not None and str(raw).strip():
            ndim = int(str(raw))
    except Exception:  # noqa: BLE001
        ndim = None
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            loc, source = session.toolbox.get_source(name, ndim=ndim)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return ToolSourceResponse(name=name, ndim=ndim, location=loc, source=source)


@router.post("/api/tools/{name}", response_model=ToolSourceResponse)
async def save_tool_source(
    name: str,
    payload: ToolSaveRequest,
    request: Request,
    response: Response,
) -> ToolSourceResponse:
    ndim: int | None = None
    try:
        raw = request.query_params.get("ndim")
        if raw is not None and str(raw).strip():
            ndim = int(str(raw))
    except Exception:  # noqa: BLE001
        ndim = None
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            session.toolbox.save_source(name, payload.source, location=payload.location, ndim=ndim)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        try:
            loc, source = session.toolbox.get_source(name, location=payload.location, ndim=ndim)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return ToolSourceResponse(name=name, ndim=ndim, location=loc, source=source)


@router.delete("/api/tools/{name}")
async def delete_tool(name: str, location: str, request: Request, response: Response, ndim: int | None = None) -> dict[str, str]:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        try:
            session.toolbox.delete(name, location=location, ndim=ndim)  # type: ignore[arg-type]
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"status": "ok"}
