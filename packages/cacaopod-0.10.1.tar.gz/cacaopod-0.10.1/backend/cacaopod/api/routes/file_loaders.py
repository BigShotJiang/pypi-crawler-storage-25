from __future__ import annotations

from fastapi import APIRouter, HTTPException, Request, Response

from cacaopod.api_models import FileLoaderSaveRequest, FileLoaderSourceResponse, FileLoadersListResponse, FileLoaderSummaryInfo
from cacaopod.config import workdir
from cacaopod.file_loader import FileLoaderLocation, FileLoaderRegistry
from cacaopod.session import get_or_create_session

router = APIRouter()


@router.get("/api/file_loaders", response_model=FileLoadersListResponse)
async def list_file_loaders(request: Request, response: Response) -> FileLoadersListResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        registry = FileLoaderRegistry(workdir=workdir())
        loaders: list[FileLoaderSummaryInfo] = []
        for l in registry.list():
            loaders.append(
                FileLoaderSummaryInfo(
                    name=l.name,
                    location=l.location,
                    extensions=list(l.extensions),
                    signature=l.signature,
                    doc=l.doc,
                )
            )
        return FileLoadersListResponse(file_loaders=loaders)


@router.get("/api/file_loaders/{name}", response_model=FileLoaderSourceResponse)
async def get_file_loader_source(
    name: str,
    request: Request,
    response: Response,
    location: FileLoaderLocation | None = None,
) -> FileLoaderSourceResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        registry = FileLoaderRegistry(workdir=workdir())
        try:
            loc, source = registry.get_source(name, location=location)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return FileLoaderSourceResponse(name=name, location=loc, source=source)


@router.post("/api/file_loaders/{name}", response_model=FileLoaderSourceResponse)
async def save_file_loader_source(
    name: str,
    payload: FileLoaderSaveRequest,
    request: Request,
    response: Response,
) -> FileLoaderSourceResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        registry = FileLoaderRegistry(workdir=workdir())
        try:
            registry.save_source(name, payload.source, location=payload.location)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        loc, source = registry.get_source(name, location=payload.location)
        return FileLoaderSourceResponse(name=name, location=loc, source=source)


@router.delete("/api/file_loaders/{name}")
async def delete_file_loader(name: str, location: FileLoaderLocation, request: Request, response: Response) -> dict[str, str]:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        registry = FileLoaderRegistry(workdir=workdir())
        try:
            registry.delete(name, location=location)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        return {"status": "ok"}

