from __future__ import annotations

import shutil
from typing import Any

from fastapi import APIRouter, HTTPException, Request, Response

from cacaopod.board import Board
from cacaopod.api_models import BoardApplyResponse, BoardCreateRequest, BoardRenameRequest, BoardSwitchRequest, BoardsListResponse
from cacaopod.session import get_or_create_session, load_active_board_state, save_active_board_state, sync_wave_manager_for_session
from cacaopod.state.boards import (
    board_state_dir,
    boards_summaries,
    bump_board_updated,
    create_board_record,
    ensure_active_board_id,
    load_active_board_id,
    load_boards_index,
    save_active_board_id,
    save_boards_index,
)

router = APIRouter()

_RESERVED_IN_BOARD_NAME = {"@", "/", "\\"}


def _validate_board_name(name: str, *, items: list[dict[str, Any]], exclude_id: str | None = None) -> str:
    s = str(name or "").strip()
    if not s:
        raise HTTPException(status_code=400, detail="missing board name")
    if any(ch in s for ch in _RESERVED_IN_BOARD_NAME):
        bad = ", ".join(sorted(_RESERVED_IN_BOARD_NAME))
        raise HTTPException(status_code=400, detail=f"board name must not contain reserved characters: {bad}")
    wanted = s.lower()
    for item in items:
        bid = item.get("id")
        if not isinstance(bid, str) or not bid.strip():
            continue
        if exclude_id is not None and bid.strip() == exclude_id:
            continue
        other = item.get("name")
        other_s = other.strip() if isinstance(other, str) and other.strip() else bid.strip()
        if other_s.lower() == wanted:
            raise HTTPException(status_code=400, detail=f"board name already exists: {s!r}")
    return s


@router.get("/api/boards", response_model=BoardsListResponse)
async def list_boards(request: Request, response: Response) -> BoardsListResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        session.active_board_id = ensure_active_board_id()
        sync_wave_manager_for_session(session)
        items = load_boards_index()
        return BoardsListResponse(activeId=session.active_board_id, boards=boards_summaries(items))


@router.post("/api/boards/new", response_model=BoardApplyResponse)
async def create_board(payload: BoardCreateRequest, request: Request, response: Response) -> BoardApplyResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        save_active_board_state(session, include_waves=True)
        items = load_boards_index()
        name = str(payload.name or "").strip()
        if not name:
            name = f"Board {len(items) + 1}"
        name = _validate_board_name(name, items=items)
        bid = create_board_record(items, name=name)
        save_active_board_id(bid)
        session.active_board_id = bid
        sync_wave_manager_for_session(session)
        # A new board starts with an empty Board (no duplication).
        session.board = Board()
        session.globals["board"] = session.board
        try:
            session.toolbox.set_runtime_context(board=session.board, wave_manager=session.wave_manager, data_manager=session.data_manager)
        except Exception:  # noqa: BLE001
            pass
        save_active_board_state(session, include_waves=True)
        return BoardApplyResponse(
            activeId=bid,
            boards=boards_summaries(load_boards_index()),
            board=session.board.snapshot(),
        )


@router.post("/api/boards/switch", response_model=BoardApplyResponse)
async def switch_board(payload: BoardSwitchRequest, request: Request, response: Response) -> BoardApplyResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        items = load_boards_index()
        target = str(payload.id or "").strip()
        if not target:
            raise HTTPException(status_code=400, detail="missing board id")

        ids = {str(item.get("id")).strip() for item in items if isinstance(item.get("id"), str) and item.get("id").strip()}
        if target not in ids:
            raise HTTPException(status_code=404, detail="board not found")

        save_active_board_state(session, include_waves=True)

        save_active_board_id(target)
        session.active_board_id = target

        loaded = load_active_board_state(session)
        if not loaded:
            session.board = Board()
            session.globals["board"] = session.board
            try:
                session.toolbox.set_runtime_context(board=session.board, wave_manager=session.wave_manager, data_manager=session.data_manager)
            except Exception:  # noqa: BLE001
                pass
        bump_board_updated(target)
        sync_wave_manager_for_session(session)

        return BoardApplyResponse(
            activeId=target,
            boards=boards_summaries(load_boards_index()),
            board=session.board.snapshot(),
        )


@router.post("/api/boards/rename", response_model=BoardsListResponse)
async def rename_board(payload: BoardRenameRequest, request: Request, response: Response) -> BoardsListResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        items = load_boards_index()
        bid = str(payload.id or "").strip()
        if not bid:
            raise HTTPException(status_code=400, detail="missing board id")
        name = _validate_board_name(str(payload.name or ""), items=items, exclude_id=bid)
        found = False
        for item in items:
            if str(item.get("id") or "").strip() != bid:
                continue
            item["name"] = name
            found = True
            break
        if not found:
            raise HTTPException(status_code=404, detail="board not found")
        save_boards_index(items)
        bump_board_updated(bid)
        session.active_board_id = ensure_active_board_id()
        sync_wave_manager_for_session(session)
        return BoardsListResponse(activeId=session.active_board_id, boards=boards_summaries(load_boards_index()))


@router.delete("/api/boards/{bid}", response_model=BoardApplyResponse)
async def delete_board(bid: str, request: Request, response: Response) -> BoardApplyResponse:
    _session_id, session = get_or_create_session(request, response)
    with session.lock:
        target = str(bid or "").strip()
        if not target:
            raise HTTPException(status_code=400, detail="missing board id")

        items = load_boards_index()
        kept: list[dict[str, Any]] = []
        found = False
        for item in items:
            if str(item.get("id") or "").strip() == target:
                found = True
                continue
            kept.append(item)
        if not found:
            raise HTTPException(status_code=404, detail="board not found")

        # Delete directory on disk (best-effort).
        try:
            d = board_state_dir(target, create=False)
            if d.exists():
                shutil.rmtree(d, ignore_errors=True)
        except Exception:  # noqa: BLE001
            pass

        save_boards_index(kept)

        active = str(getattr(session, "active_board_id", "") or "").strip() or load_active_board_id() or ""
        if active == target:
            if not kept:
                active = create_board_record(kept, name="Default")
            else:
                summaries = boards_summaries(kept)
                active = summaries[0].id if summaries else str(kept[0].get("id") or "").strip()
            save_active_board_id(active)
            session.active_board_id = active
            loaded = load_active_board_state(session)
            if not loaded:
                session.board = Board()
                session.globals["board"] = session.board
                try:
                    session.toolbox.set_runtime_context(board=session.board, wave_manager=session.wave_manager, data_manager=session.data_manager)
                except Exception:  # noqa: BLE001
                    pass
        else:
            if not kept:
                active = ensure_active_board_id()
                session.active_board_id = active
        sync_wave_manager_for_session(session)

        return BoardApplyResponse(
            activeId=ensure_active_board_id(),
            boards=boards_summaries(load_boards_index()),
            board=session.board.snapshot(),
        )
