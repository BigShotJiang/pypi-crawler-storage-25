from __future__ import annotations

from fastapi import APIRouter

from cacaopod.api_models import WorkdirInfo
from cacaopod.config import workdir
from cacaopod.state.boards import load_boards_index_status

router = APIRouter()


@router.get("/api/ping")
async def ping() -> dict[str, str]:
    return {"status": "ok"}


@router.get("/api/workdir", response_model=WorkdirInfo)
async def get_workdir() -> WorkdirInfo:
    p = workdir()
    name = p.name or str(p)
    _items, ok = load_boards_index_status()
    warning = None
    if not ok:
        warning = "Storage access seems unavailable. Boards will not be overwritten until access recovers."
    return WorkdirInfo(path=str(p), name=name, storage_ok=ok, warning=warning)
