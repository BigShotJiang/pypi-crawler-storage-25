from __future__ import annotations

from fastapi import FastAPI
from starlette.middleware.cors import CORSMiddleware
from starlette.staticfiles import StaticFiles

from cacaopod import __version__
from cacaopod.config import frontend_dist_dir
from cacaopod.api.routes.board import router as board_router
from cacaopod.api.routes.core import router as core_router
from cacaopod.api.routes.favorites import router as favorites_router
from cacaopod.api.routes.file_loaders import router as file_loaders_router
from cacaopod.api.routes.files import router as files_router
from cacaopod.api.routes.webdav import router as webdav_router
from cacaopod.api.routes.naming_rules import router as naming_rules_router
from cacaopod.api.routes.data import router as data_router
from cacaopod.api.routes.run import router as run_router
from cacaopod.api.routes.tools import router as tools_router
from cacaopod.api.routes.ui_state import router as ui_state_router
from cacaopod.api.routes.waves import router as waves_router
from cacaopod.api.routes.boards import router as boards_router


app = FastAPI(title="Cacaopod Backend", version=__version__)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[],
    allow_origin_regex=r"^http://(localhost|127\\.0\\.0\\.1)(:\\d+)?$",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(core_router)
app.include_router(run_router)
app.include_router(board_router)
app.include_router(ui_state_router)
app.include_router(boards_router)
app.include_router(tools_router)
app.include_router(file_loaders_router)
app.include_router(naming_rules_router)
app.include_router(files_router)
app.include_router(webdav_router)
app.include_router(waves_router)
app.include_router(data_router)
app.include_router(favorites_router)

_frontend_dist = frontend_dist_dir()
if _frontend_dist is not None:
    app.mount("/", StaticFiles(directory=_frontend_dist, html=True), name="frontend")
