"""FastAPI application wiring for Cacaopod."""
