from __future__ import annotations

# Keep `uvicorn cacaopod.server:app` stable as an entrypoint.
from cacaopod.api.app import app  # noqa: F401

