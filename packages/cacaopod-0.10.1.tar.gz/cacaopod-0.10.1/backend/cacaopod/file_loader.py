from __future__ import annotations

import ast
import inspect
import re
import types
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal, Sequence

import numpy as np
from platformdirs import user_data_dir

from cacaopod.config import data_root_for
from cacaopod.file_manager import FileManager
from cacaopod.wave import Wave

FileLoaderLocation = Literal["builtin", "workdir", "user"]


_VALID_LOADER_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _assert_valid_loader_name(name: str) -> str:
    n = str(name).strip()
    if not n:
        raise ValueError("loader name must be non-empty")
    if not _VALID_LOADER_NAME.match(n):
        raise ValueError(f"invalid loader name: {n!r} (use a valid Python identifier)")
    return n


_LOADER_META_RE = re.compile(r"^\s*@(?P<key>[A-Za-z_][A-Za-z0-9_]*)\s*:\s*(?P<value>.+?)\s*$", re.MULTILINE)


def _loader_meta_str(doc: str, key: str) -> str | None:
    wanted = key.strip().lower()
    for m in _LOADER_META_RE.finditer(doc or ""):
        if m.group("key").strip().lower() != wanted:
            continue
        return m.group("value").strip()
    return None


def _parse_extensions(doc: str) -> list[str]:
    raw = _loader_meta_str(doc, "extensions") or _loader_meta_str(doc, "ext") or ""
    if not raw.strip():
        return []
    parts = re.split(r"[,\s]+", raw.strip())
    exts: list[str] = []
    for p in parts:
        if not p:
            continue
        v = p.strip().lower()
        if not v:
            continue
        if not v.startswith("."):
            v = "." + v
        exts.append(v)
    # Stable order, de-duped
    seen: set[str] = set()
    out: list[str] = []
    for e in exts:
        if e in seen:
            continue
        seen.add(e)
        out.append(e)
    return out


def _file_loaders_builtin_dir() -> Path:
    return Path(__file__).resolve().parent / "file_loaders" / "builtin"


def _file_loaders_workdir_dir(workdir: Path) -> Path:
    return data_root_for(workdir) / "file_loaders"


def _file_loaders_user_dir() -> Path:
    return Path(user_data_dir("Cacaopod", "Cacaopod")) / "file_loaders"


def _extract_top_level_function_blocks(source: str) -> str:
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:  # pragma: no cover
        raise ValueError(f"invalid Python source: {exc}") from exc

    lines = source.splitlines(True)
    blocks: list[str] = []
    for node in tree.body:
        if not isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            continue

        start = node.lineno
        if getattr(node, "decorator_list", None):
            for dec in node.decorator_list:  # type: ignore[attr-defined]
                if hasattr(dec, "lineno") and dec.lineno is not None:
                    start = min(start, int(dec.lineno))
        end = getattr(node, "end_lineno", None)
        if not end:
            continue
        block = "".join(lines[start - 1 : end]).rstrip() + "\n"
        blocks.append(block)

    return "\n".join(blocks).strip() + "\n"


def _build_loader_module_source(raw_source: str) -> str:
    defs_only = _extract_top_level_function_blocks(raw_source)
    return "from __future__ import annotations\n\n" + defs_only


@dataclass(frozen=True)
class LoaderSummary:
    name: str
    location: FileLoaderLocation
    extensions: tuple[str, ...]
    signature: str
    doc: str


@dataclass(frozen=True)
class LoadedWave:
    wave: Wave
    key: str | None = None


class Loader:
    def __init__(self, name: str, func: Callable[..., Any], *, location: FileLoaderLocation, source_path: Path) -> None:
        self.name = _assert_valid_loader_name(name)
        self._func = func
        self.location = location
        self.source_path = source_path

        sig = inspect.signature(func)
        file_param = sig.parameters.get("file_path")
        if file_param is None:
            raise ValueError("loader must define a required parameter named 'file_path'")
        if file_param.kind in (inspect.Parameter.VAR_POSITIONAL, inspect.Parameter.VAR_KEYWORD):
            raise ValueError("loader parameter 'file_path' must be an explicit argument")
        if file_param.default is not inspect._empty:
            raise ValueError("loader parameter 'file_path' must be required (no default)")
        self._signature = sig

        doc = inspect.getdoc(func) or ""
        self._extensions = tuple(_parse_extensions(doc))

    @property
    def signature(self) -> inspect.Signature:
        return self._signature

    @property
    def extensions(self) -> tuple[str, ...]:
        return self._extensions

    def __call__(self, *args: Any, **kwargs: Any) -> Any:  # noqa: ANN401
        return self._func(*args, **kwargs)


def invoke_loader(loader: Loader, file_path: str | Path, **kwargs: Any) -> Any:  # noqa: ANN401
    file_param = loader.signature.parameters.get("file_path")
    if file_param is None:  # pragma: no cover
        raise RuntimeError("invalid loader signature")

    path_s = str(file_path)
    params = dict(kwargs)
    params.pop("file_path", None)

    if file_param.kind == inspect.Parameter.POSITIONAL_ONLY:
        return loader(path_s, **params)
    return loader(file_path=path_s, **params)


def _coerce_loaded_wave(value: Any) -> Wave:  # noqa: ANN401
    if isinstance(value, Wave):
        return value
    if isinstance(value, np.ndarray):
        return Wave(value)
    return Wave(np.asarray(value))


def _stamp_loaded_wave_metadata(
    wave: Wave,
    *,
    description: str | None = None,
    loader_name: str | None = None,
    key: str | None = None,
) -> None:
    if description is not None:
        wave.description = description

    meta: dict[str, Any] = {}
    if description is not None:
        meta["file_path"] = description
    if loader_name is not None:
        meta["loader"] = loader_name
    if key is not None:
        meta["loader_key"] = key
    if not meta:
        return
    try:
        wave.userdata.update(meta)
    except Exception:  # noqa: BLE001
        pass


def loader_output_name(key: str | None, name: str | None) -> str | None:
    base = str(name).strip() if name is not None else ""
    if not base:
        return None
    if key is None:
        return base
    suffix = str(key).strip()
    if not suffix:
        return base
    suffix = re.sub(r"[/\\@]+", "_", suffix)
    suffix = re.sub(r"\s+", "_", suffix).strip("_")
    if not suffix:
        return base
    return f"{base}_{suffix}"


def normalize_loader_result(
    result: Any,  # noqa: ANN401
    *,
    description: str | None = None,
    loader_name: str | None = None,
    process: list[Callable[[Wave], Any]] | None = None,
) -> list[LoadedWave]:
    raw_items: list[tuple[str | None, Any]]
    if isinstance(result, dict):
        raw_items = [(str(key), value) for key, value in result.items()]
        if not raw_items:
            raise ValueError("file_loader returned an empty dict")
    else:
        raw_items = [(None, result)]

    out: list[LoadedWave] = []
    for key, raw_value in raw_items:
        wave = _coerce_loaded_wave(raw_value)
        _stamp_loaded_wave_metadata(wave, description=description, loader_name=loader_name, key=key)

        if process:
            for fn in process:
                next_value = fn(wave)
                if next_value is None:
                    continue
                if isinstance(next_value, dict):
                    raise TypeError("process must return a Wave-like value, not dict")
                wave = _coerce_loaded_wave(next_value)
                _stamp_loaded_wave_metadata(wave, description=description, loader_name=loader_name, key=key)

        out.append(LoadedWave(wave=wave, key=key))

    return out


def finalize_loaded_waves(items: Sequence[LoadedWave], *, name: str | None = None, overwrite: bool = False) -> list[Wave]:
    out: list[Wave] = []
    for item in items:
        wave = item.wave
        final_name = loader_output_name(item.key, name)
        if final_name is not None:
            if overwrite:
                try:
                    existing = wave._manager[final_name]
                except KeyError:
                    wave.name = final_name
                else:
                    if existing is wave:
                        wave.name = final_name
                    else:
                        existing.overwrite(wave)
                        wave = existing
            else:
                wave.name = final_name
        out.append(wave)
    return out


def materialize_loader_result(
    result: Any,  # noqa: ANN401
    *,
    name: str | None = None,
    overwrite: bool = False,
    description: str | None = None,
    loader_name: str | None = None,
    process: list[Callable[[Wave], Any]] | None = None,
) -> list[Wave]:
    items = normalize_loader_result(result, description=description, loader_name=loader_name, process=process)
    return finalize_loaded_waves(items, name=name, overwrite=overwrite)


def ensure_wave_list(value: Wave | list[Wave]) -> list[Wave]:
    return list(value) if isinstance(value, list) else [value]


def collapse_loaded_waves(waves: Sequence[Wave]) -> Wave | list[Wave]:
    out = list(waves)
    if not out:
        raise ValueError("file_loader produced no waves")
    if len(out) == 1:
        return out[0]
    return out


class FileLoaderRegistry:
    def __init__(self, *, workdir: Path) -> None:
        self._workdir = Path(workdir).expanduser().resolve()
        self._file_manager = FileManager(workdir=self._workdir)

    @property
    def workdir(self) -> Path:
        return self._workdir

    @property
    def file_manager(self) -> FileManager:
        return self._file_manager

    @property
    def builtin_dir(self) -> Path:
        return _file_loaders_builtin_dir()

    @property
    def workdir_dir(self) -> Path:
        return _file_loaders_workdir_dir(self._workdir)

    @property
    def user_dir(self) -> Path:
        return _file_loaders_user_dir()

    def _locations_in_precedence(self) -> list[FileLoaderLocation]:
        return ["workdir", "user", "builtin"]

    def _dir_for_location(self, location: FileLoaderLocation) -> Path:
        if location == "builtin":
            return self.builtin_dir
        if location == "user":
            return self.user_dir
        return self.workdir_dir

    def _resolve_loader_path(self, name: str, location: FileLoaderLocation | None = None) -> tuple[FileLoaderLocation, Path]:
        loader_name = _assert_valid_loader_name(name)
        if location is not None:
            loc = location
            path = self._dir_for_location(loc) / f"{loader_name}.py"
            if not path.exists():
                raise KeyError(loader_name)
            return loc, path

        for loc in self._locations_in_precedence():
            path = self._dir_for_location(loc) / f"{loader_name}.py"
            if path.exists():
                return loc, path
        raise KeyError(loader_name)

    def get_source(self, name: str, *, location: FileLoaderLocation | None = None) -> tuple[FileLoaderLocation, str]:
        loc, path = self._resolve_loader_path(name, location)
        return loc, path.read_text(encoding="utf-8")

    def get(self, name: str, *, location: FileLoaderLocation | None = None) -> Loader:
        loc, path = self._resolve_loader_path(name, location)
        return self._load_from_path(loc, path)

    def save_source(self, name: str, source: str, *, location: FileLoaderLocation) -> Loader:
        if location == "builtin":
            raise ValueError("cannot overwrite builtin file loaders")
        loader_name = _assert_valid_loader_name(name)

        module_source = _build_loader_module_source(source)

        tmp_mod = types.ModuleType("_cacaopod_loader_validate")
        tmp_mod.Wave = Wave  # type: ignore[attr-defined]
        tmp_mod.np = np  # type: ignore[attr-defined]
        tmp_mod.fm = self._file_manager  # type: ignore[attr-defined]
        tmp_mod.FileManager = FileManager  # type: ignore[attr-defined]
        exec(compile(module_source, "<loader-validate>", "exec", dont_inherit=True), tmp_mod.__dict__)  # noqa: S102 - local trusted code

        func = tmp_mod.__dict__.get(loader_name)
        if not callable(func):
            raise ValueError(f"source must define a function named {loader_name!r}")

        loader = Loader(loader_name, func, location=location, source_path=Path(f"{loader_name}.py"))

        out_dir = self._dir_for_location(location)
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / f"{loader_name}.py"
        tmp = path.with_suffix(".tmp")
        tmp.write_text(module_source, encoding="utf-8")
        tmp.replace(path)

        return Loader(loader_name, func, location=location, source_path=path)

    def delete(self, name: str, *, location: FileLoaderLocation) -> None:
        if location == "builtin":
            raise ValueError("cannot delete builtin file loaders")
        loader_name = _assert_valid_loader_name(name)
        path = self._dir_for_location(location) / f"{loader_name}.py"
        if path.exists():
            path.unlink()

    def __getitem__(self, name: str) -> Loader:
        loc, path = self._resolve_loader_path(name)
        return self._load_from_path(loc, path)

    def _load_from_path(self, loc: FileLoaderLocation, path: Path) -> Loader:
        source = path.read_text(encoding="utf-8")

        mod_name = f"_cacaopod_loader_{loc}_{path.stem}_{path.stat().st_mtime_ns}"
        module = types.ModuleType(mod_name)
        module.__file__ = str(path)
        module.Wave = Wave  # type: ignore[attr-defined]
        module.np = np  # type: ignore[attr-defined]
        module.fm = self._file_manager  # type: ignore[attr-defined]
        module.FileManager = FileManager  # type: ignore[attr-defined]
        exec(compile(source, str(path), "exec", dont_inherit=True), module.__dict__)  # noqa: S102 - local trusted code

        func = module.__dict__.get(path.stem)
        if not callable(func):
            raise ValueError(f"loader module must define a callable named {path.stem!r}")

        return Loader(path.stem, func, location=loc, source_path=path)

    def list(self) -> list[LoaderSummary]:
        found: dict[str, tuple[FileLoaderLocation, Path]] = {}
        for loc in self._locations_in_precedence():
            root = self._dir_for_location(loc)
            if not root.exists():
                continue
            for path in root.glob("*.py"):
                if path.name.startswith("_") or path.name == "__init__.py":
                    continue
                name = path.stem
                if not _VALID_LOADER_NAME.match(name):
                    continue
                found.setdefault(name, (loc, path))

        summaries: list[LoaderSummary] = []
        for name, (loc, _path) in sorted(found.items(), key=lambda kv: kv[0].lower()):
            try:
                loader = self[name]
                doc = (inspect.getdoc(loader._func) or "").strip()
                summaries.append(
                    LoaderSummary(
                        name=name,
                        location=loc,
                        extensions=loader.extensions,
                        signature=str(loader.signature),
                        doc=doc,
                    )
                )
            except Exception:  # noqa: BLE001
                summaries.append(LoaderSummary(name=name, location=loc, extensions=(), signature="(?)", doc="(failed to load)"))
        return summaries

    def resolve_for_extension(self, extension: str) -> Loader:
        ext = str(extension).strip().lower()
        if ext and not ext.startswith("."):
            ext = "." + ext
        if not ext:
            raise ValueError("extension must be non-empty")

        # Honor precedence by location, then stable by filename.
        for loc in self._locations_in_precedence():
            root = self._dir_for_location(loc)
            if not root.exists():
                continue
            paths = sorted(
                (p for p in root.glob("*.py") if not (p.name.startswith("_") or p.name == "__init__.py")),
                key=lambda p: p.stem.lower(),
            )
            for path in paths:
                if not _VALID_LOADER_NAME.match(path.stem):
                    continue
                try:
                    loader = self._load_from_path(loc, path)
                except Exception:  # noqa: BLE001
                    continue
                if ext in loader.extensions:
                    return loader

        raise KeyError(ext)


class FileLoader:
    def __init__(self, *, workdir: Path, registry: FileLoaderRegistry | None = None) -> None:
        self._workdir = Path(workdir).expanduser().resolve()
        self._registry = registry or FileLoaderRegistry(workdir=self._workdir)

    @property
    def registry(self) -> FileLoaderRegistry:
        return self._registry

    def __call__(
        self,
        file_path: str | Path,
        *,
        name: str | None = None,
        overwrite: bool = False,
        description: str | None = None,
        process: list[Callable[[Wave], Any]] | None = None,
        **kwargs: Any,
    ) -> Wave | list[Wave]:
        path = Path(file_path).expanduser()
        if not path.is_absolute():
            path = (Path.cwd() / path).resolve()
        if not path.exists():
            raise FileNotFoundError(str(path))

        loader = self._registry.resolve_for_extension(path.suffix)
        result = invoke_loader(loader, path, **kwargs)

        if description is None:
            try:
                desc = str(path.relative_to(self._workdir))
            except ValueError:
                desc = str(path)
        else:
            desc = str(description)

        waves = materialize_loader_result(
            result,
            name=name,
            overwrite=overwrite,
            description=desc,
            loader_name=loader.name,
            process=process,
        )
        return collapse_loaded_waves(waves)
