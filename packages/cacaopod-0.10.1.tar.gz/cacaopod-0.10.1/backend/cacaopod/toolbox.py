from __future__ import annotations

import ast
import inspect
import re
import types
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal, get_args, get_origin, get_type_hints

import numpy as np
from platformdirs import user_data_dir

from cacaopod.config import data_root_for
from cacaopod.wave import Wave

ToolLocation = Literal["builtin", "workdir", "user"]


_VALID_TOOL_NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def _assert_valid_tool_name(name: str) -> str:
    n = str(name).strip()
    if not n:
        raise ValueError("tool name must be non-empty")
    if not _VALID_TOOL_NAME.match(n):
        raise ValueError(f"invalid tool name: {n!r} (use a valid Python identifier)")
    return n


def _iter_wave_types(annotation: Any) -> bool:  # noqa: ANN401
    if annotation is Wave:
        return True
    origin = get_origin(annotation)
    if origin is None:
        return False
    return any(_iter_wave_types(arg) for arg in get_args(annotation))


@dataclass(frozen=True)
class ToolParam:
    name: str
    annotation: str
    default_repr: str | None
    is_wave: bool


@dataclass(frozen=True)
class ToolSummary:
    name: str
    ndim: int | None
    location: ToolLocation
    signature: str
    doc: str
    params: list[ToolParam]


class Tool:
    def __init__(self, name: str, func: Callable[..., Any], *, location: ToolLocation, source_path: Path) -> None:
        self.name = _assert_valid_tool_name(name)
        self._func = func
        self.location = location
        self.source_path = source_path

        sig = inspect.signature(func)
        params = list(sig.parameters.values())

        # Require annotations for every parameter.
        missing = [p.name for p in params if p.annotation is inspect._empty]
        if missing:
            raise ValueError(f"tool parameters must be annotated (missing: {', '.join(missing)})")

        # Resolve type hints if possible (e.g. under future annotations).
        try:
            hints = get_type_hints(func, globalns={"Wave": Wave, "np": np}, localns={})
        except Exception:  # noqa: BLE001
            hints = {}

        wave_params: set[str] = set()
        for p in params:
            hint = hints.get(p.name, p.annotation)
            if _iter_wave_types(hint) or str(p.annotation) in {"Wave", "cacaopod.wave.Wave"}:
                wave_params.add(p.name)
        self._wave_params = wave_params
        self._signature = sig

    @property
    def signature(self) -> inspect.Signature:
        return self._signature

    def help(self) -> None:
        doc = inspect.getdoc(self._func) or ""
        print(f"{self.name}{self._signature}")
        if doc:
            print(doc)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:  # noqa: ANN401
        bound = self._signature.bind(*args, **kwargs)
        # for name in self._wave_params:
        #     if name not in bound.arguments:
        #         continue
        #     v = bound.arguments[name]
        #     if isinstance(v, Wave):
        #         continue
        #     if isinstance(v, np.ndarray):
        #         bound.arguments[name] = Wave(v)
        #         continue
        #     raise TypeError(f"argument {name!r} must be a Wave or numpy.ndarray (got {type(v).__name__})")
        return self._func(*bound.args, **bound.kwargs)


class ToolDispatch:
    """
    A callable tool handle that selects an ndim-specific variant at call time.

    Example:
      `toolbox["fit"](w)` prefers `ndim{w.ndim}/fit.py` when present, falling back
      to `fit.py` (ndim=any).
    """

    def __init__(self, toolbox: "Toolbox", name: str) -> None:
        self._toolbox = toolbox
        self.name = _assert_valid_tool_name(name)

    def __repr__(self) -> str:
        return f"ToolDispatch({self.name!r})"

    def _infer_ndim_from_args(self, args: tuple[Any, ...], kwargs: dict[str, Any]) -> int | None:
        wave_ndims: list[int] = []
        for v in list(args) + list(kwargs.values()):
            if isinstance(v, Wave):
                try:
                    wave_ndims.append(int(v.ndim))
                except Exception:  # noqa: BLE001
                    continue
        if wave_ndims:
            unique = sorted(set(wave_ndims))
            if len(unique) == 1 and unique[0] in (1, 2, 3):
                return unique[0]
            raise ValueError(f"cannot infer ndim: mixed Wave ndims {unique}")

        arr_ndims: list[int] = []
        for v in list(args) + list(kwargs.values()):
            if isinstance(v, np.ndarray):
                try:
                    arr_ndims.append(int(v.ndim))
                except Exception:  # noqa: BLE001
                    continue
        candidates = [n for n in arr_ndims if n in (1, 2, 3)]
        if not candidates:
            return None
        unique = sorted(set(candidates))
        if len(unique) == 1:
            return unique[0]
        raise ValueError(f"cannot infer ndim: mixed numpy array ndims {unique}")

    def resolve(self, *args: Any, **kwargs: Any) -> Tool:  # noqa: ANN401
        ndim = self._infer_ndim_from_args(args, kwargs)
        return self._toolbox.get(self.name, ndim=ndim)

    def __call__(self, *args: Any, **kwargs: Any) -> Any:  # noqa: ANN401
        tool = self.resolve(*args, **kwargs)
        return tool(*args, **kwargs)


def _tools_builtin_dir() -> Path:
    return Path(__file__).resolve().parent / "tools" / "builtin"


def _tools_workdir_dir(workdir: Path) -> Path:
    return data_root_for(workdir) / "tools"


def _tools_user_dir() -> Path:
    return Path(user_data_dir("Cacaopod", "Cacaopod")) / "tools"


def _extract_top_level_function_blocks(source: str) -> str:
    try:
        tree = ast.parse(source)
    except SyntaxError as exc:  # pragma: no cover
        raise ValueError(f"invalid Python source: {exc}") from exc

    lines = source.splitlines(True)
    blocks: list[str] = []
    for node in tree.body:
        if not isinstance(node, (ast.Import, ast.ImportFrom, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            continue
        if isinstance(node, ast.ImportFrom) and node.module == "__future__":
            if any(getattr(alias, "name", "") == "annotations" for alias in node.names):
                continue

        start = node.lineno
        if getattr(node, "decorator_list", None):
            for dec in node.decorator_list:  # type: ignore[attr-defined]
                if hasattr(dec, "lineno") and dec.lineno is not None:
                    start = min(start, int(dec.lineno))
        end = getattr(node, "end_lineno", None)
        if not end:
            continue
        block = "".join(lines[start - 1 : end]).rstrip() + "\n"
        blocks.append(block)

    return "\n".join(blocks).strip() + "\n"


def _build_tool_module_source(raw_source: str) -> str:
    # Save only safe top-level declarations (imports/classes/functions) while
    # stripping any ad-hoc top-level test code from the editor/console.
    return _extract_top_level_function_blocks(raw_source)


class Toolbox:
    def __init__(self, *, workdir: Path) -> None:
        self._workdir = workdir
        self._runtime_context: dict[str, Any] = {}

    @property
    def workdir(self) -> Path:
        return self._workdir

    def set_runtime_context(self, *, board: Any = None, wave_manager: Any = None, data_manager: Any = None) -> None:  # noqa: ANN401
        """
        Set objects injected into tool modules as globals.

        This is intended to make tools behave like the console environment, e.g.:
        - board, wm, dm
        """

        ctx: dict[str, Any] = dict(self._runtime_context)
        if board is not None:
            ctx["board"] = board
        if wave_manager is not None:
            ctx["wave_manager"] = wave_manager
            ctx["wm"] = wave_manager
        if data_manager is not None:
            ctx["data_manager"] = data_manager
            ctx["dm"] = data_manager
        self._runtime_context = ctx

    @property
    def builtin_dir(self) -> Path:
        return _tools_builtin_dir()

    @property
    def workdir_dir(self) -> Path:
        return _tools_workdir_dir(self._workdir)

    @property
    def user_dir(self) -> Path:
        return _tools_user_dir()

    def _locations_in_precedence(self) -> list[ToolLocation]:
        return ["workdir", "user", "builtin"]

    def _dir_for_location(self, location: ToolLocation) -> Path:
        if location == "builtin":
            return self.builtin_dir
        if location == "user":
            return self.user_dir
        return self.workdir_dir

    def _tool_dirs_for_location(self, location: ToolLocation, *, ndim: int | None) -> list[Path]:
        root = self._dir_for_location(location)
        if ndim in (1, 2, 3):
            return [root / f"ndim{ndim}", root]
        return [root]

    def _resolve_tool_path(self, name: str, *, location: ToolLocation | None = None, ndim: int | None = None) -> tuple[ToolLocation, Path]:
        tool_name = _assert_valid_tool_name(name)
        if location is not None:
            loc = location
            if ndim in (1, 2, 3):
                for root in self._tool_dirs_for_location(loc, ndim=ndim):
                    path = root / f"{tool_name}.py"
                    if path.exists():
                        return loc, path
                raise KeyError(tool_name)

            root = self._dir_for_location(loc)
            direct = root / f"{tool_name}.py"
            if direct.exists():
                return loc, direct

            matches: list[Path] = []
            for n in (1, 2, 3):
                p = root / f"ndim{n}" / f"{tool_name}.py"
                if p.exists():
                    matches.append(p)
            if len(matches) == 1:
                return loc, matches[0]
            if len(matches) > 1:
                raise ValueError(
                    f"tool {tool_name!r} is ambiguous (multiple ndim variants found). "
                    f"Use toolbox.get({tool_name!r}, ndim=1/2/3) to select a variant."
                )
            raise KeyError(tool_name)

        for loc in self._locations_in_precedence():
            if ndim in (1, 2, 3):
                for root in self._tool_dirs_for_location(loc, ndim=ndim):
                    path = root / f"{tool_name}.py"
                    if path.exists():
                        return loc, path
            else:
                root = self._dir_for_location(loc)
                direct = root / f"{tool_name}.py"
                if direct.exists():
                    return loc, direct

                matches: list[Path] = []
                for n in (1, 2, 3):
                    p = root / f"ndim{n}" / f"{tool_name}.py"
                    if p.exists():
                        matches.append(p)
                if len(matches) == 1:
                    return loc, matches[0]
                if len(matches) > 1:
                    raise ValueError(
                        f"tool {tool_name!r} is ambiguous (multiple ndim variants found). "
                        f"Use toolbox.get({tool_name!r}, ndim=1/2/3) to select a variant."
                    )
        raise KeyError(tool_name)

    def _infer_ndim_from_path(self, path: Path) -> int | None:
        parent = path.parent.name.lower()
        if parent.startswith("ndim"):
            try:
                n = int(parent[4:])
            except Exception:  # noqa: BLE001
                return None
            if n in (1, 2, 3):
                return n
        return None

    def _ndim_meta_from_source(self, source: str) -> int | None:
        m = re.search(r"^\s*@ndim\s*:\s*(?P<value>.+?)\s*$", source or "", flags=re.MULTILINE | re.IGNORECASE)
        if not m:
            return None
        raw = str(m.group("value") or "").strip().lower().replace(" ", "")
        if raw in {"*", "any", "all"}:
            return None
        if raw.endswith("d"):
            raw = raw[:-1]
        try:
            n = int(raw)
        except Exception:  # noqa: BLE001
            return None
        return n if n in (1, 2, 3) else None

    def _iter_tool_files(self, root: Path) -> list[Path]:
        if not root.exists():
            return []
        paths: list[Path] = []
        for n in (1, 2, 3):
            d = root / f"ndim{n}"
            if d.exists():
                paths.extend(sorted(d.glob("*.py"), key=lambda p: p.name.lower()))
        paths.extend(sorted(root.glob("*.py"), key=lambda p: p.name.lower()))
        return paths

    def get(self, name: str, *, ndim: int | None = None, location: ToolLocation | None = None) -> Tool:
        loc, path = self._resolve_tool_path(name, location=location, ndim=ndim)
        return self._load_tool(loc, path)

    def list(self) -> list[ToolSummary]:
        found: dict[tuple[str, int | None], tuple[ToolLocation, Path]] = {}
        for loc in self._locations_in_precedence():
            root = self._dir_for_location(loc)
            for path in self._iter_tool_files(root):
                if path.name.startswith("_") or path.name == "__init__.py":
                    continue
                name = path.stem
                if not _VALID_TOOL_NAME.match(name):
                    continue
                inferred_ndim = self._infer_ndim_from_path(path)
                try:
                    src = path.read_text(encoding="utf-8")
                except Exception:  # noqa: BLE001
                    src = ""
                meta_ndim = self._ndim_meta_from_source(src)
                key_ndim = meta_ndim if meta_ndim is not None else inferred_ndim
                # honor precedence: first one wins (per name+ndim)
                found.setdefault((name, key_ndim), (loc, path))

        summaries: list[ToolSummary] = []
        for (name, key_ndim), (loc, path) in sorted(found.items(), key=lambda kv: (kv[0][0].lower(), str(kv[0][1] or ""))):
            try:
                tool = self._load_tool(loc, path)
                doc = (inspect.getdoc(tool._func) or "").strip()
                ndim = self._ndim_meta_from_source(doc) if doc else None
                if ndim is None:
                    ndim = key_ndim
                params: list[ToolParam] = []
                for p in tool.signature.parameters.values():
                    ann = p.annotation
                    ann_s = ann if isinstance(ann, str) else getattr(ann, "__name__", str(ann))
                    default_repr = None if p.default is inspect._empty else repr(p.default)
                    params.append(
                        ToolParam(
                            name=p.name,
                            annotation=str(ann_s),
                            default_repr=default_repr,
                            is_wave=p.name in tool._wave_params,
                        )
                    )
                summaries.append(
                    ToolSummary(
                        name=name,
                        ndim=ndim,
                        location=loc,
                        signature=str(tool.signature),
                        doc=doc,
                        params=params,
                    )
                )
            except Exception:  # noqa: BLE001
                summaries.append(
                    ToolSummary(
                        name=name,
                        ndim=key_ndim,
                        location=loc,
                        signature="(?)",
                        doc="(failed to load)",
                        params=[],
                    )
                )
        return summaries

    def __contains__(self, name: object) -> bool:
        if not isinstance(name, str):
            return False
        try:
            self._resolve_tool_path(name)
            return True
        except KeyError:
            return False
        except ValueError:
            return True

    def __getitem__(self, name: str) -> ToolDispatch:
        tool_name = _assert_valid_tool_name(name)
        try:
            self._resolve_tool_path(tool_name)
        except KeyError as exc:
            raise KeyError(tool_name) from exc
        except ValueError:
            # ambiguity is ok here; ToolDispatch resolves by call args.
            pass
        return ToolDispatch(self, tool_name)

    def _load_tool(self, loc: ToolLocation, path: Path) -> Tool:
        source = path.read_text(encoding="utf-8")

        # Load into an isolated module so edits take effect without restart.
        mod_name = f"_cacaopod_tool_{loc}_{path.stem}_{path.stat().st_mtime_ns}"
        module = types.ModuleType(mod_name)
        module.__file__ = str(path)
        module.__dict__.update(dict(self._runtime_context))
        module.Wave = Wave  # type: ignore[attr-defined]
        module.np = np  # type: ignore[attr-defined]
        module.toolbox = self  # type: ignore[attr-defined]
        exec(compile(source, str(path), "exec", dont_inherit=True), module.__dict__)  # noqa: S102 - local trusted code
        module.toolbox = self  # type: ignore[attr-defined]

        func = module.__dict__.get(path.stem)
        if not callable(func):
            raise ValueError(f"tool module must define a callable named {path.stem!r}")

        return Tool(path.stem, func, location=loc, source_path=path)

    def get_source(self, name: str, *, location: ToolLocation | None = None, ndim: int | None = None) -> tuple[ToolLocation, str]:
        loc, path = self._resolve_tool_path(name, location=location, ndim=ndim)
        return loc, path.read_text(encoding="utf-8")

    def save_source(self, name: str, source: str, *, location: ToolLocation, ndim: int | None = None) -> Tool:
        if location == "builtin":
            raise ValueError("cannot overwrite builtin tools")
        tool_name = _assert_valid_tool_name(name)

        module_source = _build_tool_module_source(source)
        meta_ndim = self._ndim_meta_from_source(module_source)
        out_ndim = ndim if ndim in (1, 2, 3) else meta_ndim

        tmp_mod = types.ModuleType("_cacaopod_tool_validate")
        tmp_mod.__dict__.update(dict(self._runtime_context))
        tmp_mod.Wave = Wave  # type: ignore[attr-defined]
        tmp_mod.np = np  # type: ignore[attr-defined]
        tmp_mod.toolbox = self  # type: ignore[attr-defined]
        exec(compile(module_source, "<tool-validate>", "exec", dont_inherit=True), tmp_mod.__dict__)  # noqa: S102 - local trusted code
        func = tmp_mod.__dict__.get(tool_name)
        if not callable(func):
            raise ValueError(f"source must define a function named {tool_name!r}")
        Tool(tool_name, func, location=location, source_path=Path(f"{tool_name}.py"))

        out_dir = self._dir_for_location(location)
        if out_ndim in (1, 2, 3):
            out_dir = out_dir / f"ndim{out_ndim}"
        out_dir.mkdir(parents=True, exist_ok=True)
        path = out_dir / f"{tool_name}.py"
        tmp = path.with_suffix(".tmp")
        tmp.write_text(module_source, encoding="utf-8")
        tmp.replace(path)

        return Tool(tool_name, func, location=location, source_path=path)

    def delete(self, name: str, *, location: ToolLocation, ndim: int | None = None) -> None:
        if location == "builtin":
            raise ValueError("cannot delete builtin tools")
        tool_name = _assert_valid_tool_name(name)
        loc, path = self._resolve_tool_path(tool_name, location=location, ndim=ndim)
        if path.exists():
            path.unlink()

    def register(self, func: Callable[..., Any], *, name: str | None = None, location: ToolLocation = "workdir") -> Tool:
        tool_name = _assert_valid_tool_name(name or getattr(func, "__name__", ""))
        try:
            src = inspect.getsource(func)
        except OSError as exc:
            raise ValueError(
                "failed to locate function source. Tip: run the definition in Cacaopod once so it is available in linecache."
            ) from exc
        return self.save_source(tool_name, src, location=location)
