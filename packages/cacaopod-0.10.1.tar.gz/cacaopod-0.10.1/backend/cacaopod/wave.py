from __future__ import annotations

import json
import fnmatch
import threading
import uuid
from contextlib import contextmanager
from pathlib import Path
from typing import Any, Callable

import numpy as np

from cacaopod.sort_utils import alphanumeric


_STATE = threading.local()


@contextmanager
def bind_wave_manager(manager: "WaveManager") -> Any:
    prev = getattr(_STATE, "manager", None)
    _STATE.manager = manager
    try:
        yield
    finally:
        _STATE.manager = prev


def _current_manager() -> "WaveManager":
    manager = getattr(_STATE, "manager", None)
    if manager is None:
        raise RuntimeError("Wave must be created inside a Cacaopod run (no WaveManager bound).")
    return manager


def _is_scalar(x: Any) -> bool:
    return isinstance(x, (int, float, np.integer, np.floating))


def _normalize_axis_param(value: Any, *, ndim: int, default: float) -> tuple[float, ...]:
    if value is None:
        return tuple([default] * ndim)
    if isinstance(value, (list, tuple, np.ndarray)) and len(value) == 0:
        return tuple([default] * ndim)
    if _is_scalar(value):
        return tuple([float(value)] * ndim)
    if isinstance(value, np.ndarray):
        seq = value.tolist()
    else:
        seq = list(value)  # type: ignore[arg-type]
    if len(seq) != ndim:
        raise ValueError(f"expected length {ndim} but got {len(seq)}")
    return tuple(float(v) for v in seq)


def _xyz_to_dim_order(values_xyz: tuple[float, ...]) -> tuple[float, ...]:
    # (x, y, z) -> numpy axis order (..., z, y, x)
    return tuple(reversed(values_xyz))


def _dim_to_xyz_order(values_dim: tuple[float, ...]) -> tuple[float, ...]:
    # numpy axis order (..., z, y, x) -> (x, y, z)
    return tuple(reversed(values_dim))


def _axis_names_for_ndim(ndim: int) -> list[str]:
    if ndim == 1:
        return ["x"]
    if ndim == 2:
        return ["x", "y"]
    if ndim == 3:
        return ["x", "y", "z"]
    raise ValueError(f"Wave only supports ndim 1..3 (got {ndim})")


def _coerce_wave_input_array(value: Any) -> np.ndarray:  # noqa: ANN401
    arr = np.asarray(value)
    if isinstance(value, np.ndarray):
        # Raw ndarray inputs should be owned by the Wave to avoid aliasing
        # external arrays. Wave inputs keep their own view/copy-on-write path.
        return arr.copy()
    return arr


class WaveArray(np.ndarray):
    __array_priority__ = 1000

    def __new__(cls, input_array: np.ndarray, wave: "Wave") -> "WaveArray":
        obj = np.asarray(input_array).view(cls)
        obj._wave = wave  # type: ignore[attr-defined]
        return obj

    def __array_finalize__(self, obj: Any) -> None:
        if obj is None:
            return
        self._wave = getattr(obj, "_wave", None)  # type: ignore[attr-defined]

    def __setitem__(self, key: Any, value: Any) -> None:  # noqa: ANN401
        wave: Wave | None = getattr(self, "_wave", None)  # type: ignore[attr-defined]
        if wave is None:
            super().__setitem__(key, value)
            return

        if isinstance(getattr(wave, "_parent_wave", None), Wave):
            wave._detach_from_parent()
            if isinstance(value, Wave):
                value = value._a_raw
            wave._a_raw[key] = value
            wave._touch()
            return

        wave._touch()
        super().__setitem__(key, value)

    def __array_ufunc__(self, ufunc: np.ufunc, method: str, *inputs: Any, **kwargs: Any) -> Any:  # noqa: ANN401
        wave: Wave | None = getattr(self, "_wave", None)  # type: ignore[attr-defined]

        # Behave like a normal numpy array for computation, while still marking the
        # owning Wave dirty for in-place operations (out=self).
        out = kwargs.get("out", None)
        out_tuple = tuple(out) if out is not None else ()
        is_inplace = bool(out_tuple) and any(o is self for o in out_tuple)
        detached = False

        if is_inplace and wave is not None and isinstance(getattr(wave, "_parent_wave", None), Wave):
            wave._detach_from_parent()
            detached = True
            new_self = WaveArray(wave._a_raw, wave)
            kwargs["out"] = tuple(new_self if o is self else (np.asarray(o) if isinstance(o, WaveArray) else o) for o in out_tuple)

        def unwrap(x: Any) -> Any:  # noqa: ANN401
            if isinstance(x, WaveArray):
                if detached and wave is not None and getattr(x, "_wave", None) is wave:
                    return np.asarray(wave._a_raw)
                return np.asarray(x)
            return x

        inputs_unwrapped = tuple(unwrap(x) for x in inputs)
        out = kwargs.get("out", None)
        if out is not None:
            out_tuple = tuple(out)
            kwargs["out"] = tuple(unwrap(x) for x in out_tuple)
        else:
            out_tuple = ()

        result = getattr(ufunc, method)(*inputs_unwrapped, **kwargs)

        if is_inplace and wave is not None:
            wave._touch()
            if detached:
                return WaveArray(wave._a_raw, wave)
            return self

        return result


class WaveAxisArray(np.ndarray):
    __array_priority__ = 1000

    def __new__(cls, input_array: np.ndarray, wave: "Wave", axis_name: str) -> "WaveAxisArray":
        obj = np.asarray(input_array).view(cls)
        obj._wave = wave  # type: ignore[attr-defined]
        obj._axis_name = axis_name  # type: ignore[attr-defined]
        return obj

    def __array_finalize__(self, obj: Any) -> None:
        if obj is None:
            return
        self._wave = getattr(obj, "_wave", None)  # type: ignore[attr-defined]
        self._axis_name = getattr(obj, "_axis_name", None)  # type: ignore[attr-defined]

    def _touch_wave(self) -> None:
        wave: Wave | None = getattr(self, "_wave", None)  # type: ignore[attr-defined]
        axis_name = getattr(self, "_axis_name", None)  # type: ignore[attr-defined]
        if wave is None or not axis_name:
            return
        try:
            wave._ensure_explicit_axis(str(axis_name), np.asarray(self))
        except Exception:  # noqa: BLE001
            pass
        wave._touch()

    def __setitem__(self, key: Any, value: Any) -> None:  # noqa: ANN401
        self._touch_wave()
        super().__setitem__(key, value)

    def __array_ufunc__(self, ufunc: np.ufunc, method: str, *inputs: Any, **kwargs: Any) -> Any:  # noqa: ANN401
        # Behave like a normal numpy array for computation, while still marking the
        # owning Wave dirty for in-place operations (out=self).
        def unwrap(x: Any) -> Any:  # noqa: ANN401
            return np.asarray(x) if isinstance(x, WaveAxisArray) else x

        inputs_unwrapped = tuple(unwrap(x) for x in inputs)
        out = kwargs.get("out", None)
        if out is not None:
            out_tuple = tuple(out)
            kwargs["out"] = tuple(unwrap(x) for x in out_tuple)
        else:
            out_tuple = ()

        result = getattr(ufunc, method)(*inputs_unwrapped, **kwargs)

        if out_tuple and any(o is self for o in out_tuple):
            self._touch_wave()

        return result


class WaveUserdata(dict[str, Any]):
    def __init__(self, *args: Any, wave: "Wave", **kwargs: Any) -> None:
        super().__init__(*args, **kwargs)
        self._wave = wave

    def __setitem__(self, key: str, value: Any) -> None:  # noqa: ANN401
        super().__setitem__(key, value)
        self._wave._touch()

    def __delitem__(self, key: str) -> None:
        super().__delitem__(key)
        self._wave._touch()

    def clear(self) -> None:
        super().clear()
        self._wave._touch()

    def pop(self, key: str, default: Any = None) -> Any:  # noqa: ANN401
        v = super().pop(key, default)
        self._wave._touch()
        return v

    def popitem(self) -> tuple[str, Any]:  # noqa: ANN401
        kv = super().popitem()
        self._wave._touch()
        return kv

    def setdefault(self, key: str, default: Any = None) -> Any:  # noqa: ANN401
        if key in self:
            return self[key]
        self[key] = default
        return default

    def update(self, *args: Any, **kwargs: Any) -> None:
        super().update(*args, **kwargs)
        self._wave._touch()


class WaveErrorArray(np.ndarray):
    __array_priority__ = 1000

    def __new__(cls, input_array: np.ndarray, wave: "Wave") -> "WaveErrorArray":
        obj = np.asarray(input_array).view(cls)
        obj._wave = wave  # type: ignore[attr-defined]
        return obj

    def __array_finalize__(self, obj: Any) -> None:
        if obj is None:
            return
        self._wave = getattr(obj, "_wave", None)  # type: ignore[attr-defined]

    def __setitem__(self, key: Any, value: Any) -> None:  # noqa: ANN401
        wave: Wave | None = getattr(self, "_wave", None)  # type: ignore[attr-defined]
        arr = np.asarray(value, dtype=float)
        if np.any(arr < 0):
            raise ValueError("errorbar values must be >= 0")
        super().__setitem__(key, value)
        if wave is not None:
            wave._touch()


def _normalize_errorbar(value: Any, shape: tuple[int, ...]) -> np.ndarray | None:  # noqa: ANN401
    if value is None:
        return None
    arr = np.asarray(value, dtype=float)
    if arr.ndim == 0:
        arr = np.full(shape, float(arr), dtype=float)
    if tuple(int(x) for x in arr.shape) != shape:
        raise ValueError(f"errorbar shape must match Wave.shape (got {arr.shape} vs {shape})")
    if np.any(arr < 0):
        raise ValueError("errorbar values must be >= 0")
    return np.asarray(arr, dtype=float).copy()


class _LazyArrayBase:
    source_kind = ""

    @property
    def ndim(self) -> int:
        return len(self.shape)

    def materialize(self) -> np.ndarray:
        raise NotImplementedError

    def read_display_data(self, *, slice_axis: str | None = None, slice_index: int = 0) -> np.ndarray:
        arr = self.materialize()
        if arr.ndim != 3:
            return arr
        axis_to_dim = {"z": 0, "y": 1, "x": 2}
        dim = axis_to_dim.get(str(slice_axis or "z"), 0)
        ii = max(0, min(int(slice_index), int(arr.shape[dim]) - 1))
        key: list[Any] = [slice(None), slice(None), slice(None)]
        key[dim] = ii
        return np.asarray(arr[tuple(key)])

    def source_meta(self) -> dict[str, Any]:
        raise NotImplementedError

    def __array__(self, dtype: Any | None = None) -> np.ndarray:  # noqa: ANN401
        arr = self.materialize()
        return np.asarray(arr, dtype=dtype)

    def __getitem__(self, key: Any) -> Any:  # noqa: ANN401
        return self.materialize()[key]


class LazyNpzArray(_LazyArrayBase):
    source_kind = "npz"

    def __init__(self, path: Path, *, shape: tuple[int, ...], dtype: Any) -> None:  # noqa: ANN401
        self.path = Path(path)
        self.shape = tuple(int(x) for x in shape)
        self.dtype = np.dtype(dtype)

    def materialize(self) -> np.ndarray:
        with np.load(self.path, allow_pickle=False) as npz:
            if "a" not in npz.files:
                raise ValueError("invalid lazy npz wave: missing 'a'")
            return np.asarray(npz["a"])

    def source_meta(self) -> dict[str, Any]:
        return {"kind": self.source_kind, "path": str(self.path), "shape": list(self.shape), "dtype": str(self.dtype)}


class LazyHdf5Array(_LazyArrayBase):
    source_kind = "hdf5"

    def __init__(
        self,
        file_path: str | Path,
        dataset_path: str,
        *,
        source_shape: tuple[int, ...],
        dtype: Any,  # noqa: ANN401
        squeeze: bool = True,
        transpose: bool = False,
    ) -> None:
        self.file_path = str(file_path)
        self.dataset_path = str(dataset_path or "").strip()
        if not self.dataset_path.startswith("/"):
            self.dataset_path = "/" + self.dataset_path
        self.source_shape = tuple(int(x) for x in source_shape)
        self.dtype = np.dtype(dtype)
        self.squeeze = bool(squeeze)
        self.transpose = bool(transpose)

        kept = [i for i, n in enumerate(self.source_shape) if (not self.squeeze or int(n) != 1)]
        if not kept and self.source_shape:
            kept = [len(self.source_shape) - 1]
        out_shape = [self.source_shape[i] for i in kept]
        out_to_source = list(kept)
        if self.transpose and len(out_shape) == 2:
            out_shape = [out_shape[1], out_shape[0]]
            out_to_source = [out_to_source[1], out_to_source[0]]
        self.shape = tuple(int(x) for x in out_shape)
        self._out_dim_to_source_axis = tuple(out_to_source)

    def _h5py(self) -> Any:  # noqa: ANN401
        try:
            import h5py  # type: ignore[import-not-found]
        except Exception as exc:  # noqa: BLE001
            raise RuntimeError("h5py is required to read lazy HDF5-backed waves.") from exc
        return h5py

    def materialize(self) -> np.ndarray:
        h5py = self._h5py()
        with h5py.File(self.file_path, "r") as h5:
            arr = np.asarray(h5[self.dataset_path][()])
        if self.squeeze:
            arr = np.squeeze(arr)
        if self.transpose and arr.ndim == 2:
            arr = arr.T
        return np.asarray(arr)

    def _source_selection_from_output_key(self, key: tuple[Any, ...]) -> tuple[Any, ...]:
        selection: list[Any] = [slice(None)] * len(self.source_shape)
        if self.squeeze:
            for axis, n in enumerate(self.source_shape):
                if int(n) == 1:
                    selection[axis] = 0
        for out_dim, sel in enumerate(key):
            if out_dim >= len(self._out_dim_to_source_axis):
                break
            selection[self._out_dim_to_source_axis[out_dim]] = sel
        return tuple(selection)

    def read_display_data(self, *, slice_axis: str | None = None, slice_index: int = 0) -> np.ndarray:
        if self.ndim != 3:
            return self.materialize()
        axis_to_dim = {"z": 0, "y": 1, "x": 2}
        dim = axis_to_dim.get(str(slice_axis or "z"), 0)
        ii = max(0, min(int(slice_index), int(self.shape[dim]) - 1))
        key: list[Any] = [slice(None), slice(None), slice(None)]
        key[dim] = ii
        source_key = self._source_selection_from_output_key(tuple(key))
        h5py = self._h5py()
        with h5py.File(self.file_path, "r") as h5:
            return np.asarray(h5[self.dataset_path][source_key])

    def source_meta(self) -> dict[str, Any]:
        return {
            "kind": self.source_kind,
            "file_path": self.file_path,
            "dataset_path": self.dataset_path,
            "source_shape": list(self.source_shape),
            "shape": list(self.shape),
            "dtype": str(self.dtype),
            "squeeze": self.squeeze,
            "transpose": self.transpose,
        }


def _is_lazy_array(value: Any) -> bool:  # noqa: ANN401
    return isinstance(value, _LazyArrayBase)


class Wave:
    def __new__(
        cls,
        a: Any,  # noqa: ANN401
        offset: Any = 0,  # noqa: ANN401
        delta: Any = 1,  # noqa: ANN401
        name: str | None = None,
        *,
        overwrite: bool = False,
        x: Any = None,  # noqa: ANN401
        y: Any = None,  # noqa: ANN401
        z: Any = None,  # noqa: ANN401
        errorbar: Any = None,  # noqa: ANN401
    ) -> "Wave":
        # Allow `Wave(..., name="existing", overwrite=True)` to update the existing tracked Wave
        # in-place, preserving object identity (important for Board/Pod references).
        if cls is not Wave or not overwrite or name is None:
            return super().__new__(cls)

        nm = str(name).strip()
        if not nm:
            return super().__new__(cls)

        try:
            manager = _current_manager()
        except Exception:  # noqa: BLE001
            return super().__new__(cls)

        try:
            return manager[nm]
        except KeyError:
            return super().__new__(cls)

    def __init__(
        self,
        a: Any,  # noqa: ANN401
        offset: Any = 0,  # noqa: ANN401
        delta: Any = 1,  # noqa: ANN401
        name: str | None = None,
        *,
        overwrite: bool = False,
        x: Any = None,  # noqa: ANN401
        y: Any = None,  # noqa: ANN401
        z: Any = None,  # noqa: ANN401
        errorbar: Any = None,  # noqa: ANN401
    ) -> None:
        # If __new__ returned an existing Wave instance, update its numeric data/axis metadata in-place.
        if hasattr(self, "_a_raw"):
            if not overwrite or name is None:
                return

            arr = _coerce_wave_input_array(a)
            if arr.ndim < 1 or arr.ndim > 3:
                raise ValueError(f"Wave only supports ndim 1..3 (got ndim={arr.ndim})")
            if int(arr.ndim) != int(getattr(self, "ndim", int(np.asarray(getattr(self, "_a_raw")).ndim))):
                raise ValueError(f"ndim mismatch for overwrite (self={self.ndim}, new={arr.ndim})")

            axis_names = _axis_names_for_ndim(arr.ndim)
            offset_xyz = _normalize_axis_param(offset, ndim=len(axis_names), default=0.0)
            delta_xyz = _normalize_axis_param(delta, ndim=len(axis_names), default=1.0)

            self._a_raw = arr
            self._offset_dim = _xyz_to_dim_order(offset_xyz)
            self._delta_dim = _xyz_to_dim_order(delta_xyz)
            self._explicit_coords_dim = [None] * arr.ndim
            if errorbar is not None:
                self._errorbar = _normalize_errorbar(errorbar, tuple(int(x) for x in arr.shape))
            elif isinstance(a, Wave) and getattr(a, "_errorbar", None) is not None and tuple(int(x) for x in arr.shape) == a.shape:
                self._errorbar = np.asarray(a._errorbar, dtype=float).copy()
            else:
                self._errorbar = None
            self._cache.clear()
            self._parent_wave = None
            self._original = None
            if x is not None:
                self.x = np.asarray(x)
            if y is not None:
                self.y = np.asarray(y)
            if z is not None:
                self.z = np.asarray(z)
            self._touch()
            return

        source_wave: Wave | None = a if isinstance(a, Wave) else None
        parent_wave: Wave | None = None
        if source_wave is not None:
            parent_wave = getattr(source_wave, "_parent_wave", None) or source_wave

        arr = _coerce_wave_input_array(a)
        if arr.ndim < 1 or arr.ndim > 3:
            raise ValueError(f"Wave only supports ndim 1..3 (got ndim={arr.ndim})")
        if name is not None and source_wave is not None:
            arr = np.asarray(arr).copy()
            parent_wave = None

        self._a_raw: np.ndarray = arr
        self.uid: str = uuid.uuid4().hex
        self._name: str | None = None
        self._wm_path: str | None = None
        self._description: str | None = None
        self._rev: int = 0
        self._saved_rev: int = -1

        axis_names = _axis_names_for_ndim(arr.ndim)
        offset_xyz = _normalize_axis_param(offset, ndim=len(axis_names), default=0.0)
        delta_xyz = _normalize_axis_param(delta, ndim=len(axis_names), default=1.0)

        self._offset_dim: tuple[float, ...] = _xyz_to_dim_order(offset_xyz)
        self._delta_dim: tuple[float, ...] = _xyz_to_dim_order(delta_xyz)

        self._explicit_coords_dim: list[np.ndarray | None] = [None] * arr.ndim
        if errorbar is not None:
            self._errorbar: np.ndarray | None = _normalize_errorbar(errorbar, tuple(int(x) for x in arr.shape))
        elif source_wave is not None and getattr(source_wave, "_errorbar", None) is not None and source_wave.shape == tuple(int(x) for x in arr.shape):
            self._errorbar = np.asarray(source_wave._errorbar, dtype=float).copy()
        else:
            self._errorbar = None
        self._cache: dict[str, np.ndarray] = {}

        # Root waves have no parent. Views keep a pointer to the root wave.
        self._parent_wave: Wave | None = parent_wave
        # Backward-compat alias for older internal code.
        self._original: Wave | None = parent_wave
        self._manager = _current_manager()
        self._userdata = WaveUserdata(wave=self)
        if x is not None:
            self.x = np.asarray(x)
        if y is not None:
            self.y = np.asarray(y)
        if z is not None:
            self.z = np.asarray(z)
        if name is not None:
            self.name = name

    def __repr__(self) -> str:
        return f"Wave(uid={self.uid!r}, name={self._name!r}, shape={self.shape}, dtype={self.dtype})"

    def _is_lazy_data(self) -> bool:
        return _is_lazy_array(getattr(self, "_a_raw", None))

    def _materialize_data(self) -> np.ndarray:
        raw = getattr(self, "_a_raw", None)
        if isinstance(raw, np.ndarray):
            return raw
        if _is_lazy_array(raw):
            arr = np.asarray(raw)
            self._a_raw = arr
            return arr
        arr = np.asarray(raw)
        self._a_raw = arr
        return arr

    @property
    def original(self) -> "Wave | None":
        return self._parent_wave

    @property
    def parent_wave(self) -> "Wave | None":
        return self._parent_wave

    @property
    def name(self) -> str | None:
        return self._name

    @name.setter
    def name(self, value: Any) -> None:  # noqa: ANN401
        if value is None:
            new_name: str | None = None
        else:
            new_name = str(value).strip()
            if not new_name:
                new_name = None

        if new_name == self._name:
            # If the active Board changed, allow re-tracking (move) even if the base name is unchanged.
            current_path = getattr(self, "_wm_path", None)
            if new_name is None or current_path is None:
                return
            expected = self._manager._key_for_active_name(new_name)  # type: ignore[attr-defined]
            if current_path == expected:
                return

        if new_name is None:
            if self._name is not None:
                self._manager.untrack(self)
            self._name = None
            self._touch()
            return

        if self._parent_wave is not None:
            self._detach_from_parent()
        self._manager.track(self, new_name)
        self._name = new_name
        self._touch()

    @property
    def description(self) -> str | None:
        return self._description

    @description.setter
    def description(self, value: Any) -> None:  # noqa: ANN401
        if value is None:
            new_value: str | None = None
        else:
            new_value = str(value).strip()
            if not new_value:
                new_value = None
        if new_value == self._description:
            return
        self._description = new_value
        self._touch()

    @property
    def userdata(self) -> WaveUserdata:
        return self._userdata

    @userdata.setter
    def userdata(self, value: Any) -> None:  # noqa: ANN401
        if value is None:
            self._userdata = WaveUserdata(wave=self)
            self._touch()
            return
        if isinstance(value, WaveUserdata):
            self._userdata = WaveUserdata(value, wave=self)
            self._touch()
            return
        if isinstance(value, dict):
            self._userdata = WaveUserdata(value, wave=self)
            self._touch()
            return
        raise TypeError("userdata must be a dict (or None)")

    @property
    def errorbar(self) -> WaveErrorArray | None:
        if self._errorbar is None:
            return None
        return WaveErrorArray(self._errorbar, self)

    @errorbar.setter
    def errorbar(self, value: Any) -> None:  # noqa: ANN401
        self._errorbar = _normalize_errorbar(value, self.shape)
        self._touch()

    @property
    def a(self) -> WaveArray:
        return WaveArray(self._materialize_data(), self)

    @a.setter
    def a(self, value: Any) -> None:  # noqa: ANN401
        if isinstance(value, Wave):
            value = value._a_raw
        arr = np.asarray(value)
        if arr.ndim < 1 or arr.ndim > 3:
            raise ValueError(f"Wave only supports ndim 1..3 (got ndim={arr.ndim})")
        if int(arr.ndim) != int(self.ndim):
            raise ValueError(f"data.ndim must match Wave.ndim (got {arr.ndim} vs {self.ndim})")

        same_shape = tuple(int(x) for x in arr.shape) == self.shape
        if self._parent_wave is not None:
            if same_shape:
                self._explicit_coords_dim = [
                    (np.asarray(coords).copy() if coords is not None else None) for coords in self._explicit_coords_dim
                ]
            else:
                self._explicit_coords_dim = [None] * int(arr.ndim)
            self._parent_wave = None
            self._original = None
        elif not same_shape:
            self._explicit_coords_dim = [None] * int(arr.ndim)
        if not same_shape:
            self._errorbar = None

        self._a_raw = np.asarray(arr).copy()
        self._touch()

    def __array__(self, dtype: Any | None = None) -> np.ndarray:  # noqa: ANN401
        return np.asarray(self._materialize_data(), dtype=dtype)

    def update(self) -> None:
        self._touch()

    def copy(self, *, data: Any | None = None, name: str | None = None, overwrite: bool = False) -> "Wave":
        """
        Return an untracked Wave copy.

        - `w.copy()` deep-copies numeric data and axis metadata (offset/delta and explicit coords).
        - `w.copy(data=...)` replaces numeric data while copying axis metadata.
        - `w.copy(name=..., overwrite=...)` optionally tracks the copy by name (see `Wave(..., name=...)`).

        The returned Wave has no name and is not tracked by WaveManager unless you set `wave.name`.
        """

        if data is None:
            new_array = np.asarray(self._a_raw).copy()
        else:
            new_array = np.asarray(data)
            if int(new_array.ndim) != int(self.ndim):
                raise ValueError(f"data.ndim must match Wave.ndim (got {new_array.ndim} vs {self.ndim})")
            new_array = np.asarray(new_array).copy()

        w = object.__new__(Wave)
        w._a_raw = new_array
        w.uid = uuid.uuid4().hex
        w._name = None
        w._wm_path = None
        w._description = self._description
        w._rev = 0
        w._saved_rev = -1
        w._offset_dim = self._offset_dim
        w._delta_dim = self._delta_dim
        if new_array.shape == self.shape:
            w._explicit_coords_dim = [
                (np.asarray(coords).copy() if coords is not None else None) for coords in self._explicit_coords_dim
            ]
            w._errorbar = np.asarray(self._errorbar, dtype=float).copy() if self._errorbar is not None else None
        else:
            w._explicit_coords_dim = [None] * int(new_array.ndim)
            w._errorbar = None
        w._cache = {}
        w._parent_wave = None
        w._original = None
        w._manager = self._manager
        w._userdata = WaveUserdata(dict(self._userdata), wave=w)

        nm = str(name).strip() if name is not None else ""
        if not nm:
            return w

        if overwrite:
            try:
                existing = self._manager[nm]
            except KeyError:
                existing = None
            if isinstance(existing, Wave):
                existing.overwrite(w)
                return existing

        w.name = nm
        return w

    def overwrite(self, other: "Wave") -> None:
        """
        Overwrite this Wave's numeric data and axis metadata from another Wave.

        This keeps the current Wave's uid/name/tracking while updating:
        - numeric array
        - description/userdata
        - offset/delta and explicit coords
        """

        if not isinstance(other, Wave):
            raise TypeError("other must be a Wave")
        if int(other.ndim) != int(self.ndim):
            raise ValueError(f"ndim mismatch (self={self.ndim}, other={other.ndim})")

        self._a_raw = np.asarray(other._a_raw).copy()
        self._description = other._description
        self._userdata = WaveUserdata(dict(other._userdata), wave=self)
        self._errorbar = np.asarray(other._errorbar, dtype=float).copy() if other._errorbar is not None else None
        self._offset_dim = other._offset_dim
        self._delta_dim = other._delta_dim
        self._explicit_coords_dim = [
            (np.asarray(coords).copy() if coords is not None else None) for coords in other._explicit_coords_dim
        ]
        self._parent_wave = None
        self._original = None
        self._touch()

    @property
    def ndim(self) -> int:
        return int(getattr(self._a_raw, "ndim"))

    @property
    def shape(self) -> tuple[int, ...]:
        return tuple(int(x) for x in getattr(self._a_raw, "shape"))

    @property
    def dtype(self) -> np.dtype:
        return np.dtype(getattr(self._a_raw, "dtype"))

    def _touch(self) -> None:
        self._cache.clear()
        self._rev = int(getattr(self, "_rev", 0)) + 1
        if self._name is not None:
            self._manager.mark_dirty(self.uid)

    def _detach_from_parent(self) -> None:
        # A slice is a view; when it is modified or named we want to materialize it
        # as an independent Wave to avoid unintentionally coupling it to the parent.
        if self._parent_wave is None:
            return
        self._a_raw = np.asarray(self._a_raw).copy()
        self._explicit_coords_dim = [
            (np.asarray(coords).copy() if coords is not None else None) for coords in self._explicit_coords_dim
        ]
        if self._errorbar is not None:
            self._errorbar = np.asarray(self._errorbar, dtype=float).copy()
        self._parent_wave = None
        self._original = None
        self._cache.clear()

    def _detach_from_original(self) -> None:
        # Backward-compat alias.
        self._detach_from_parent()

    def _ensure_own_array(self) -> None:
        if self._is_lazy_data():
            self._materialize_data()
        if self._parent_wave is not None:
            self._detach_from_parent()

    def _clone(self, new_array: np.ndarray) -> "Wave":
        w = object.__new__(Wave)
        w._a_raw = new_array
        w.uid = uuid.uuid4().hex
        w._name = None
        w._wm_path = None
        w._description = self._description
        w._rev = 0
        w._saved_rev = -1
        w._offset_dim = self._offset_dim
        w._delta_dim = self._delta_dim
        w._explicit_coords_dim = list(self._explicit_coords_dim)
        w._errorbar = np.asarray(self._errorbar, dtype=float).copy() if self._errorbar is not None and new_array.shape == self.shape else None
        w._cache = {}
        w._parent_wave = None
        w._original = None
        w._manager = self._manager
        w._userdata = WaveUserdata(dict(self._userdata), wave=w)
        return w

    # ---- axis params (x,y,z order outward) ----
    @property
    def offset(self) -> tuple[float, ...]:
        return _dim_to_xyz_order(self._offset_dim)

    @offset.setter
    def offset(self, value: Any) -> None:
        axis_names = _axis_names_for_ndim(self.ndim)
        offset_xyz = _normalize_axis_param(value, ndim=len(axis_names), default=0.0)
        self._offset_dim = _xyz_to_dim_order(offset_xyz)
        self._touch()

    @property
    def delta(self) -> tuple[float, ...]:
        return _dim_to_xyz_order(self._delta_dim)

    @delta.setter
    def delta(self, value: Any) -> None:
        axis_names = _axis_names_for_ndim(self.ndim)
        delta_xyz = _normalize_axis_param(value, ndim=len(axis_names), default=1.0)
        self._delta_dim = _xyz_to_dim_order(delta_xyz)
        self._touch()

    def _dim_index(self, axis_name: str) -> int:
        if self.ndim == 1:
            mapping = {"x": 0}
        elif self.ndim == 2:
            mapping = {"y": 0, "x": 1}
        elif self.ndim == 3:
            mapping = {"z": 0, "y": 1, "x": 2}
        else:  # pragma: no cover
            raise ValueError("unsupported ndim")
        if axis_name not in mapping:
            raise AttributeError(axis_name)
        return mapping[axis_name]

    def _coord_vector(self, dim: int) -> np.ndarray:
        n = self.shape[dim]
        o = float(self._offset_dim[dim])
        d = float(self._delta_dim[dim])
        if n <= 1:
            return np.array([o], dtype=float)
        end = o + d * (n - 1)
        return np.linspace(o, end, n, dtype=float)

    def _coord_grid_dim(self, dim: int) -> np.ndarray:
        explicit = self._explicit_coords_dim[dim]
        if explicit is not None:
            return explicit

        if self.ndim == 1:
            return self._coord_vector(0)

        if self.ndim == 2:
            x1 = self._coord_vector(1)
            y0 = self._coord_vector(0)
            xx, yy = np.meshgrid(x1, y0)
            return xx if dim == 1 else yy

        idx = np.indices(self.shape)
        return float(self._offset_dim[dim]) + float(self._delta_dim[dim]) * idx[dim]

    def _index_grid_dim(self, dim: int) -> np.ndarray:
        if self.ndim == 1:
            return np.arange(self.shape[0], dtype=int)
        idx = np.indices(self.shape)
        return idx[dim]

    def _get_axis_grid(self, axis_name: str) -> np.ndarray:
        key = f"coord:{axis_name}"
        if key in self._cache:
            return self._cache[key]
        dim = self._dim_index(axis_name)
        arr = self._coord_grid_dim(dim)
        wrapped = WaveAxisArray(arr, self, axis_name)
        self._cache[key] = wrapped
        return wrapped

    def _get_index_grid(self, axis_name: str) -> np.ndarray:
        key = f"index:{axis_name}"
        if key in self._cache:
            return self._cache[key]
        dim = self._dim_index(axis_name)
        arr = self._index_grid_dim(dim)
        self._cache[key] = arr
        return arr

    @property
    def x(self) -> np.ndarray:
        return self._get_axis_grid("x")

    @x.setter
    def x(self, value: Any) -> None:
        arr = np.asarray(value)
        if arr.shape != self.shape:
            raise ValueError(f"x must have shape {self.shape} (got {arr.shape})")
        self._explicit_coords_dim[self._dim_index("x")] = arr
        self._touch()

    @property
    def y(self) -> np.ndarray:
        return self._get_axis_grid("y")

    @y.setter
    def y(self, value: Any) -> None:
        if self.ndim < 2:
            raise AttributeError("y")
        arr = np.asarray(value)
        if arr.shape != self.shape:
            raise ValueError(f"y must have shape {self.shape} (got {arr.shape})")
        self._explicit_coords_dim[self._dim_index("y")] = arr
        self._touch()

    @property
    def z(self) -> np.ndarray:
        return self._get_axis_grid("z")

    def _ensure_explicit_axis(self, axis_name: str, arr: np.ndarray) -> None:
        dim = self._dim_index(axis_name)
        if self._explicit_coords_dim[dim] is None:
            a = np.asarray(arr)
            if a.shape != self.shape:
                return
            self._explicit_coords_dim[dim] = a

    @z.setter
    def z(self, value: Any) -> None:
        if self.ndim < 3:
            raise AttributeError("z")
        arr = np.asarray(value)
        if arr.shape != self.shape:
            raise ValueError(f"z must have shape {self.shape} (got {arr.shape})")
        self._explicit_coords_dim[self._dim_index("z")] = arr
        self._touch()

    @property
    def p(self) -> np.ndarray:
        return self._get_index_grid("x")

    @property
    def q(self) -> np.ndarray:
        return self._get_index_grid("y")

    @property
    def r(self) -> np.ndarray:
        return self._get_index_grid("z")

    # ---- slicing ----
    def __getitem__(self, key: Any) -> Any:  # noqa: ANN401
        view = self._a_raw[key]
        if not isinstance(view, np.ndarray):
            view = np.asarray(view)
        if view.ndim == 0:
            return view.item()

        w = object.__new__(Wave)
        w._a_raw = view
        w.uid = uuid.uuid4().hex
        w._name = None
        w._wm_path = None
        w._description = self._description
        w._rev = 0
        w._saved_rev = -1
        w._userdata = WaveUserdata(dict(self._userdata), wave=w)

        # update axis params in numpy dim order
        w._offset_dim, w._delta_dim = _slice_offset_delta(self._offset_dim, self._delta_dim, self.shape, key)

        # slice explicit coords (if any)
        selectors = _normalize_key(key, ndim=self.ndim)
        kept_dims = [dim for dim, sel in enumerate(selectors) if not isinstance(sel, (int, np.integer))]
        dim_map = {old: new for new, old in enumerate(kept_dims)}
        w._explicit_coords_dim = [None] * w._a_raw.ndim
        for old_dim, coords in enumerate(self._explicit_coords_dim):
            if coords is None:
                continue
            if old_dim not in dim_map:
                continue
            w._explicit_coords_dim[dim_map[old_dim]] = np.asarray(coords)[key]
        if self._errorbar is not None:
            sliced_errorbar = np.asarray(self._errorbar)[key]
            w._errorbar = np.asarray(sliced_errorbar, dtype=float).copy() if np.asarray(sliced_errorbar).shape == w._a_raw.shape else None
        else:
            w._errorbar = None

        w._cache = {}
        root = self._parent_wave if self._parent_wave is not None else self
        w._parent_wave = root
        w._original = root
        w._manager = self._manager
        # Slices are views; saving is handled at the root Wave level.
        return w

    def __setitem__(self, key: Any, value: Any) -> None:  # noqa: ANN401
        self._ensure_own_array()
        if isinstance(value, Wave):
            value = value._a_raw
        self._a_raw[key] = value
        self._touch()

    # ---- arithmetic ----
    def _binary(self, other: Any, op: Callable[[Any, Any], Any]) -> "Wave":  # noqa: ANN401
        if isinstance(other, Wave):
            if other.shape != self.shape:
                raise ValueError(f"Wave shapes must match (got {self.shape} vs {other.shape})")
            result = op(self._a_raw, other._a_raw)
        else:
            result = op(self._a_raw, other)
        return self._clone(np.asarray(result))

    def __add__(self, other: Any) -> "Wave":  # noqa: ANN401
        return self._binary(other, lambda a, b: a + b)

    def __radd__(self, other: Any) -> "Wave":  # noqa: ANN401
        return self.__add__(other)

    def __sub__(self, other: Any) -> "Wave":  # noqa: ANN401
        return self._binary(other, lambda a, b: a - b)

    def __rsub__(self, other: Any) -> "Wave":  # noqa: ANN401
        return self._binary(other, lambda a, b: b - a)

    def __mul__(self, other: Any) -> "Wave":  # noqa: ANN401
        return self._binary(other, lambda a, b: a * b)

    def __rmul__(self, other: Any) -> "Wave":  # noqa: ANN401
        return self.__mul__(other)

    def __truediv__(self, other: Any) -> "Wave":  # noqa: ANN401
        return self._binary(other, lambda a, b: a / b)

    def __rtruediv__(self, other: Any) -> "Wave":  # noqa: ANN401
        return self._binary(other, lambda a, b: b / a)

    def __pow__(self, other: Any) -> "Wave":  # noqa: ANN401
        return self._binary(other, lambda a, b: a**b)

    def __neg__(self) -> "Wave":
        return self._clone(-self._a_raw)

    def __iadd__(self, other: Any) -> "Wave":  # noqa: ANN401
        self._ensure_own_array()
        if isinstance(other, Wave):
            if other.shape != self.shape:
                raise ValueError(f"Wave shapes must match (got {self.shape} vs {other.shape})")
            self._a_raw += other._a_raw
        else:
            self._a_raw += other
        self._touch()
        return self

    def __isub__(self, other: Any) -> "Wave":  # noqa: ANN401
        self._ensure_own_array()
        if isinstance(other, Wave):
            if other.shape != self.shape:
                raise ValueError(f"Wave shapes must match (got {self.shape} vs {other.shape})")
            self._a_raw -= other._a_raw
        else:
            self._a_raw -= other
        self._touch()
        return self

    def __imul__(self, other: Any) -> "Wave":  # noqa: ANN401
        self._ensure_own_array()
        if isinstance(other, Wave):
            if other.shape != self.shape:
                raise ValueError(f"Wave shapes must match (got {self.shape} vs {other.shape})")
            self._a_raw *= other._a_raw
        else:
            self._a_raw *= other
        self._touch()
        return self

    def __itruediv__(self, other: Any) -> "Wave":  # noqa: ANN401
        self._ensure_own_array()
        if isinstance(other, Wave):
            if other.shape != self.shape:
                raise ValueError(f"Wave shapes must match (got {self.shape} vs {other.shape})")
            self._a_raw /= other._a_raw
        else:
            self._a_raw /= other
        self._touch()
        return self


def _normalize_key(key: Any, *, ndim: int) -> tuple[Any, ...]:  # noqa: ANN401
    if not isinstance(key, tuple):
        key = (key,)
    key = list(key)
    if Ellipsis in key:
        i = key.index(Ellipsis)
        num_missing = ndim - (len(key) - 1)
        key = key[:i] + [slice(None)] * num_missing + key[i + 1 :]
    while len(key) < ndim:
        key.append(slice(None))
    return tuple(key[:ndim])


def _slice_offset_delta(
    offset_dim: tuple[float, ...],
    delta_dim: tuple[float, ...],
    shape: tuple[int, ...],
    key: Any,  # noqa: ANN401
) -> tuple[tuple[float, ...], tuple[float, ...]]:
    if len(shape) == 0:
        return (), ()

    selectors = _normalize_key(key, ndim=len(shape))
    new_offset: list[float] = []
    new_delta: list[float] = []

    for dim, sel in enumerate(selectors):
        if isinstance(sel, slice):
            start, _stop, step = sel.indices(shape[dim])
            d = float(delta_dim[dim])
            o = float(offset_dim[dim])
            new_offset.append(o + d * start)
            new_delta.append(d * step)
            continue

        if isinstance(sel, (int, np.integer)):
            continue

        raise ValueError(f"unsupported slice key element: {sel!r} (only slice/int are supported)")

    return tuple(new_offset), tuple(new_delta)


def _new_wave_with_storage(
    storage: Any,  # noqa: ANN401
    *,
    manager: "WaveManager",
    uid: str | None = None,
    name: str | None = None,
    wm_path: str | None = None,
    description: str | None = None,
    userdata: dict[str, Any] | None = None,
    offset: Any = 0,  # noqa: ANN401
    delta: Any = 1,  # noqa: ANN401
) -> Wave:
    ndim = int(getattr(storage, "ndim"))
    if ndim < 1 or ndim > 3:
        raise ValueError(f"Wave only supports ndim 1..3 (got ndim={ndim})")
    axis_names = _axis_names_for_ndim(ndim)
    offset_xyz = _normalize_axis_param(offset, ndim=len(axis_names), default=0.0)
    delta_xyz = _normalize_axis_param(delta, ndim=len(axis_names), default=1.0)

    wave = object.__new__(Wave)
    wave._a_raw = storage
    wave.uid = uid or uuid.uuid4().hex
    wave._name = str(name).strip() if isinstance(name, str) and name.strip() else None
    wave._wm_path = wm_path
    wave._description = str(description).strip() if isinstance(description, str) and description.strip() else None
    wave._rev = 0
    wave._saved_rev = 0 if uid else -1
    wave._offset_dim = _xyz_to_dim_order(offset_xyz)
    wave._delta_dim = _xyz_to_dim_order(delta_xyz)
    wave._explicit_coords_dim = [None] * ndim
    wave._errorbar = None
    wave._cache = {}
    wave._parent_wave = None
    wave._original = None
    wave._manager = manager
    wave._userdata = WaveUserdata(userdata or {}, wave=wave)
    return wave


def create_lazy_hdf5_wave(
    file_path: str | Path,
    dataset_path: str,
    *,
    shape: tuple[int, ...],
    dtype: Any,  # noqa: ANN401
    squeeze: bool = True,
    transpose: bool = False,
    manager: "WaveManager | None" = None,
) -> Wave:
    storage = LazyHdf5Array(file_path, dataset_path, source_shape=shape, dtype=dtype, squeeze=squeeze, transpose=transpose)
    return _new_wave_with_storage(storage, manager=manager or _current_manager())


def wave_is_lazy(wave: Wave) -> bool:
    return bool(isinstance(wave, Wave) and wave._is_lazy_data())


def read_wave_display_data(wave: Wave, *, slice_axis: str | None = None, slice_index: int = 0) -> np.ndarray:
    raw = getattr(wave, "_a_raw", None)
    if _is_lazy_array(raw):
        return np.asarray(raw.read_display_data(slice_axis=slice_axis, slice_index=slice_index))
    arr = np.asarray(wave)
    if arr.ndim != 3:
        return arr
    axis_to_dim = {"z": 0, "y": 1, "x": 2}
    dim = axis_to_dim.get(str(slice_axis or "z"), 0)
    ii = max(0, min(int(slice_index), int(arr.shape[dim]) - 1))
    key: list[Any] = [slice(None), slice(None), slice(None)]
    key[dim] = ii
    return np.asarray(arr[tuple(key)])


class WaveManager:
    def __init__(self, root_dir: Path) -> None:
        self._root_dir = root_dir
        self._waves: dict[str, Wave] = {}
        self._path_to_uid: dict[str, str] = {}
        self._dirty_uids: set[str] = set()
        self._index_dirty = False
        self._active_board_id: str = ""
        self._board_id_to_name: dict[str, str] = {}
        self._board_name_to_id: dict[str, str] = {}
        self._board_name_to_id_lower: dict[str, str] = {}
        self._load_index_json()

    @property
    def root_dir(self) -> Path:
        return self._root_dir

    @property
    def active_board_id(self) -> str:
        return self._active_board_id

    @property
    def active_board_name(self) -> str:
        bid = str(self._active_board_id or "").strip()
        if not bid:
            return ""
        return str(self._board_id_to_name.get(bid) or "").strip() or bid

    def set_active_board(self, board_id: str) -> None:
        self._active_board_id = str(board_id or "").strip()

    def set_board_index(self, board_id_to_name: dict[str, str]) -> None:
        cleaned_id_to_name: dict[str, str] = {}
        name_to_id: dict[str, str] = {}
        name_to_id_lower: dict[str, str] = {}

        for bid_raw, name_raw in (board_id_to_name or {}).items():
            bid = str(bid_raw or "").strip()
            if not bid:
                continue
            name = str(name_raw or "").strip()
            cleaned_id_to_name[bid] = name
            if name:
                name_to_id.setdefault(name, bid)
                name_to_id_lower.setdefault(name.lower(), bid)

        self._board_id_to_name = cleaned_id_to_name
        self._board_name_to_id = name_to_id
        self._board_name_to_id_lower = name_to_id_lower

    def _key_for_active_name(self, wave_name: str) -> str:
        bid = str(self._active_board_id or "").strip()
        return f"{bid}/{wave_name}" if bid else str(wave_name)

    def _key_for(self, board_id: str, wave_name: str) -> str:
        bid = str(board_id or "").strip()
        if not bid:
            raise RuntimeError("WaveManager active board is not set")
        return f"{bid}/{wave_name}"

    def _load_index_json(self) -> None:
        path = self._root_dir / "index.json"
        if not path.exists():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except Exception:  # noqa: BLE001
            return
        if not isinstance(data, dict):
            return
        raw = data.get("by_path")
        if not isinstance(raw, dict):
            return
        loaded: dict[str, str] = {}
        for k, v in raw.items():
            if not isinstance(k, str) or not isinstance(v, str):
                continue
            key = k.strip().strip("/")
            uid = v.strip()
            if not key or not uid:
                continue
            loaded[key] = uid
        self._path_to_uid = loaded

    def _load_uid(self, uid: str, *, wm_path: str | None = None) -> Wave | None:
        wave = self._waves.get(uid)
        if wave is not None:
            if wm_path is not None:
                wave._wm_path = wm_path
                if wave._name is None:
                    base = wm_path.split("/")[-1].strip()
                    wave._name = base or None
            return wave

        npz_path = self._root_dir / f"{uid}.npz"
        if not npz_path.exists():
            return None
        try:
            wave = _load_wave_npz(npz_path, manager=self, wm_path=wm_path)
        except Exception:  # noqa: BLE001
            return None
        self._waves[uid] = wave
        return wave

    def __getitem__(self, name: str) -> "Wave | list[Wave]":
        raw = str(name).strip()
        if not raw:
            raise KeyError(name)

        # Wildcard access: `wm["abc*"]` -> list[Wave] sorted by wave name.
        # Cross-board wildcard requires explicit `@board_name` (board_name can also contain wildcards).
        if "*" in raw:
            if raw.startswith("/"):
                raise KeyError(name)
            matched = self.match(raw)
            waves = list(matched.values())
            waves.sort(
                key=lambda w: (
                    alphanumeric(str(getattr(w, "name", "") or "")),
                    alphanumeric(str(getattr(w, "_wm_path", "") or "")),
                )
            )
            return waves

        # Absolute internal ref: "/<board_id>/<wave_name>"
        if raw.startswith("/"):
            ref = raw.lstrip("/").strip()
            if "/" in ref:
                board_id, wave_name = ref.split("/", 1)
                board_id = board_id.strip()
                wave_name = wave_name.strip()
                if not board_id or not wave_name:
                    raise KeyError(name)
                path = self._key_for(board_id, wave_name)
                uid = self._path_to_uid.get(path)
                if uid is None:
                    raise KeyError(name)
                wave = self._waves.get(uid) or self._load_uid(uid, wm_path=path)
                if wave is None:
                    raise KeyError(name)
                return wave
            raw = ref

        # User ref: "wave_name" (active board) or "wave_name@board_name"
        wave_name = raw
        board_id = str(self._active_board_id or "").strip()
        if "@" in raw:
            left, right = raw.rsplit("@", 1)
            wave_name = left.strip()
            board_name = right.strip()
            if not wave_name or not board_name:
                raise KeyError(name)
            board_id = self._board_name_to_id.get(board_name) or self._board_name_to_id_lower.get(board_name.lower()) or ""
            if not board_id:
                raise KeyError(name)

        if not board_id:
            raise KeyError(name)

        path = self._key_for(board_id, wave_name)
        uid = self._path_to_uid.get(path)
        if uid is None:
            raise KeyError(name)
        wave = self._waves.get(uid) or self._load_uid(uid, wm_path=path)
        if wave is None:
            raise KeyError(name)
        return wave

    def track(self, wave: Wave, name: str) -> None:
        n = str(name).strip()
        if not n:
            raise ValueError("wave name must be non-empty")
        if "/" in n or "\\" in n:
            raise ValueError("wave name must not contain path separators ('/')")
        if "@" in n:
            raise ValueError("wave name must not contain '@' (reserved for board selection: name@board)")

        path = self._key_for(self._active_board_id, n)

        existing_uid = self._path_to_uid.get(path)
        if existing_uid is not None and existing_uid != wave.uid:
            raise ValueError(f"wave name already exists in this board: {n!r}")

        old_path = getattr(wave, "_wm_path", None)
        if old_path is not None and old_path != path:
            self._path_to_uid.pop(old_path, None)

        self._waves[wave.uid] = wave
        self._path_to_uid[path] = wave.uid
        wave._wm_path = path
        self._dirty_uids.add(wave.uid)
        self._index_dirty = True

    def untrack(self, wave: Wave) -> None:
        old_path = getattr(wave, "_wm_path", None)
        if old_path is not None:
            self._path_to_uid.pop(old_path, None)
            wave._wm_path = None
        self._waves.pop(wave.uid, None)
        self._dirty_uids.discard(wave.uid)
        self._index_dirty = True

    def delete(self, name: str, *, board_id: str | None = None) -> None:
        """
        Delete a tracked Wave entry from the index and remove its persisted data file (best-effort).

        This removes the name -> uid mapping for the given board. If the uid is no longer referenced
        by any other path, the associated `<uid>.npz` file is deleted as well.
        """

        bid = str(board_id or self._active_board_id or "").strip()
        n = str(name or "").strip()
        if not bid:
            raise RuntimeError("WaveManager active board is not set")
        if not n:
            raise KeyError(name)

        path = self._key_for(bid, n)
        uid = self._path_to_uid.pop(path, None)
        if uid is None:
            raise KeyError(name)

        self._index_dirty = True

        wave = self._waves.get(uid)
        if wave is not None and getattr(wave, "_wm_path", None) == path:
            wave._wm_path = None

        # If uid isn't referenced anymore, drop cached instance and delete file.
        if uid not in self._path_to_uid.values():
            self._waves.pop(uid, None)
            self._dirty_uids.discard(uid)
            try:
                (self._root_dir / f"{uid}.npz").unlink()
            except FileNotFoundError:
                pass
            except Exception:  # noqa: BLE001
                pass

    def match(self, pattern: str) -> dict[str, Wave]:
        raw = str(pattern).strip()
        if not raw:
            return {}

        explicit_board = False
        include_board_in_key = False
        pat = raw
        board_pat: str | None = None
        board_ids: list[str] = []
        board_id = str(self._active_board_id or "").strip()
        if "@" in raw:
            explicit_board = True
            left, right = raw.rsplit("@", 1)
            pat = left.strip() or "*"
            board_pat = right.strip()
            if not board_pat:
                return {}

            is_wild_board = any(ch in board_pat for ch in ("*", "?", "["))
            if not is_wild_board:
                board_id = self._board_name_to_id.get(board_pat) or self._board_name_to_id_lower.get(board_pat.lower()) or ""
                if not board_id:
                    return {}
                board_ids = [board_id]
            else:
                include_board_in_key = True
                bp = board_pat.lower()
                for bid, bname in self._board_id_to_name.items():
                    name_s = str(bname or bid or "").strip()
                    if not name_s:
                        continue
                    if fnmatch.fnmatchcase(name_s.lower(), bp) or fnmatch.fnmatchcase(str(bid).lower(), bp):
                        board_ids.append(str(bid).strip())
                board_ids = [bid for bid in board_ids if bid]
                board_ids.sort(key=lambda bid: alphanumeric(str(self._board_id_to_name.get(bid) or bid)))
        else:
            if not board_id:
                return {}
            board_ids = [board_id]

        if not board_ids:
            return {}

        out: dict[str, Wave] = {}
        for bid in board_ids:
            base_prefix = f"{bid}/"
            for path, uid in self._path_to_uid.items():
                if base_prefix and not path.startswith(base_prefix):
                    continue
                rel = path[len(base_prefix) :] if base_prefix else path
                if not fnmatch.fnmatchcase(rel, pat):
                    continue
                wave = self._waves.get(uid) or self._load_uid(uid, wm_path=path)
                if wave is None:
                    continue
                if explicit_board and include_board_in_key:
                    out[f"/{path}"] = wave
                else:
                    out[rel] = wave

        return dict(sorted(out.items(), key=lambda kv: alphanumeric(kv[0])))

    def mark_dirty(self, uid: str) -> None:
        if uid in self._waves:
            self._dirty_uids.add(uid)

    def list(self, *, board_id: str | None = None) -> list[tuple[str, str]]:
        bid = str(board_id or self._active_board_id or "").strip()
        if not bid:
            return []
        prefix = f"{bid}/"
        out: list[tuple[str, str]] = []
        for path, uid in self._path_to_uid.items():
            if not path.startswith(prefix):
                continue
            rel = path[len(prefix) :]
            if rel:
                out.append((rel, uid))
        out.sort(key=lambda kv: alphanumeric(kv[0]))
        return out

    def flush(self) -> None:
        if not self._dirty_uids and not self._index_dirty:
            return
        self._root_dir.mkdir(parents=True, exist_ok=True)

        dirty = list(self._dirty_uids)
        still_dirty: set[str] = set()
        for uid in dirty:
            wave = self._waves.get(uid)
            if wave is None:
                continue
            try:
                _save_wave_npz(self._root_dir / f"{uid}.npz", wave)
            except Exception:  # noqa: BLE001
                still_dirty.add(uid)

        self._dirty_uids = still_dirty

        if self._index_dirty:
            try:
                _save_wave_index_json(self._root_dir / "index.json", self._path_to_uid)
                self._index_dirty = False
            except Exception:  # noqa: BLE001
                pass


def _save_wave_npz(path: Path, wave: Wave) -> None:
    meta = {
        "uid": wave.uid,
        "name": wave.name,
        "description": wave.description,
        "userdata": _jsonable(dict(wave.userdata)),
        "shape": list(wave.shape),
        "dtype": str(wave.dtype),
        "offset": list(wave.offset),
        "delta": list(wave.delta),
    }

    raw = getattr(wave, "_a_raw", None)
    payload: dict[str, Any] = {"_meta": np.array(json.dumps(meta), dtype=str)}
    if isinstance(raw, LazyHdf5Array):
        payload["_lazy_meta"] = np.array(json.dumps(raw.source_meta()), dtype=str)
    else:
        payload["a"] = np.asarray(raw)

    if not isinstance(raw, LazyHdf5Array) and getattr(wave, "_errorbar", None) is not None:
        payload["errorbar"] = np.asarray(wave._errorbar, dtype=float)

    axis_names = _axis_names_for_ndim(wave.ndim)
    for axis_name in axis_names:
        dim = wave._dim_index(axis_name)
        coords = wave._explicit_coords_dim[dim]
        if coords is not None and not isinstance(raw, LazyHdf5Array):
            payload[axis_name] = coords

    tmp = path.with_name(f"{path.stem}.tmp{path.suffix}")
    np.savez(tmp, **payload)
    tmp.replace(path)
    try:
        wave._saved_rev = int(getattr(wave, "_rev", 0))
    except Exception:  # noqa: BLE001
        pass


def _save_wave_index_json(path: Path, path_to_uid: dict[str, str]) -> None:
    payload = {"by_path": path_to_uid}
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(path)


def _jsonable(value: Any) -> Any:  # noqa: ANN401
    if value is None:
        return None
    if isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (np.integer, np.floating)):
        return value.item()
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple)):
        return [_jsonable(v) for v in value]
    return str(value)


def _load_wave_npz(path: Path, *, manager: WaveManager, wm_path: str | None = None, lazy: bool = True) -> Wave:
    with np.load(path, allow_pickle=False) as npz:
        meta: dict[str, Any] = {}
        if "_meta" in npz.files:
            meta_raw = npz["_meta"]
            if isinstance(meta_raw, np.ndarray) and meta_raw.shape == ():
                try:
                    meta = json.loads(meta_raw.item())
                except Exception:  # noqa: BLE001
                    meta = {}

        lazy_meta: dict[str, Any] = {}
        if "_lazy_meta" in npz.files:
            raw_lazy_meta = npz["_lazy_meta"]
            if isinstance(raw_lazy_meta, np.ndarray) and raw_lazy_meta.shape == ():
                try:
                    loaded = json.loads(raw_lazy_meta.item())
                    if isinstance(loaded, dict):
                        lazy_meta = loaded
                except Exception:  # noqa: BLE001
                    lazy_meta = {}

        if "a" in npz.files:
            if lazy:
                shape_raw = meta.get("shape")
                dtype_raw = meta.get("dtype")
                if isinstance(shape_raw, list) and dtype_raw:
                    try:
                        arr: Any = LazyNpzArray(path, shape=tuple(int(x) for x in shape_raw), dtype=dtype_raw)
                    except Exception:  # noqa: BLE001
                        arr = np.asarray(npz["a"])
                else:
                    arr = np.asarray(npz["a"])
            else:
                arr = np.asarray(npz["a"])
        elif lazy_meta:
            kind = str(lazy_meta.get("kind") or "").strip().lower()
            if kind == "hdf5":
                arr = LazyHdf5Array(
                    str(lazy_meta.get("file_path") or ""),
                    str(lazy_meta.get("dataset_path") or ""),
                    source_shape=tuple(int(x) for x in (lazy_meta.get("source_shape") or lazy_meta.get("shape") or [])),
                    dtype=str(lazy_meta.get("dtype") or "float64"),
                    squeeze=bool(lazy_meta.get("squeeze", True)),
                    transpose=bool(lazy_meta.get("transpose", False)),
                )
            elif kind == "npz":
                arr = LazyNpzArray(
                    Path(str(lazy_meta.get("path") or path)),
                    shape=tuple(int(x) for x in (lazy_meta.get("shape") or meta.get("shape") or [])),
                    dtype=str(lazy_meta.get("dtype") or meta.get("dtype") or "float64"),
                )
            else:
                raise ValueError("invalid lazy wave file: unsupported source kind")
        else:
            raise ValueError("invalid wave file: missing 'a'")

        wave = object.__new__(Wave)
        wave._a_raw = arr
        wave.uid = path.stem

        name_raw = meta.get("name")
        if isinstance(name_raw, str) and name_raw.strip():
            wave._name = name_raw.strip()
        else:
            wave._name = None

        wave._rev = 0
        wave._saved_rev = 0

        wave._wm_path = wm_path
        if wave._name is None and wm_path is not None:
            base = wm_path.split("/")[-1].strip()
            wave._name = base or None

        desc_raw = meta.get("description")
        if isinstance(desc_raw, str) and desc_raw.strip():
            wave._description = desc_raw.strip()
        else:
            wave._description = None

        axis_names = _axis_names_for_ndim(arr.ndim)
        offset_xyz = _normalize_axis_param(meta.get("offset"), ndim=len(axis_names), default=0.0)
        delta_xyz = _normalize_axis_param(meta.get("delta"), ndim=len(axis_names), default=1.0)
        wave._offset_dim = _xyz_to_dim_order(offset_xyz)
        wave._delta_dim = _xyz_to_dim_order(delta_xyz)

        wave._explicit_coords_dim = [None] * arr.ndim
        for axis_name in axis_names:
            if axis_name in npz.files:
                dim = wave._dim_index(axis_name)
                wave._explicit_coords_dim[dim] = np.asarray(npz[axis_name])
        if "errorbar" in npz.files:
            try:
                wave._errorbar = _normalize_errorbar(np.asarray(npz["errorbar"]), tuple(int(x) for x in arr.shape))
            except Exception:  # noqa: BLE001
                wave._errorbar = None
        else:
            wave._errorbar = None

        wave._cache = {}
        wave._parent_wave = None
        wave._original = None
        wave._manager = manager

        userdata_raw = meta.get("userdata")
        if isinstance(userdata_raw, dict):
            wave._userdata = WaveUserdata(userdata_raw, wave=wave)
        else:
            wave._userdata = WaveUserdata(wave=wave)

        return wave
