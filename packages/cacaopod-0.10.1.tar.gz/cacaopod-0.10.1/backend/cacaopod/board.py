from __future__ import annotations

import hashlib
import json
import math
import re
import uuid
import warnings
from typing import Any

import numpy as np

from cacaopod.api_models import (
    WaveSnapshot,
    PodSnapshot,
    BoardSelection,
    BoardSnapshot,
    HeatmapViewSettings,
    TraceViewSettings,
)
from cacaopod.wave import Wave, wave_is_lazy


_GRAPH_KEY_ALIASES: dict[str, str] = {
    "colorscale/name": "colormap/name",
    "colorscale/autoscale": "colormap/autoscale",
    "colorscale/zmin": "colormap/min",
    "colorscale/zmax": "colormap/max",
    "colorscale/reverse": "colormap/reverse",
    "colorscale/reversescale": "colormap/reverse",
    "colorscale/smoothing": "colormap/smoothing",
    "colorscale/showscale": "colormap/showscale",
    "colorscale/label": "colormap/label",
    "colorscale/label_gap_px": "colormap/label_gap_px",
    "colorscale/labelgappx": "colormap/label_gap_px",
    "axis/x/title": "axis/x/label",
    "axis/y/title": "axis/y/label",
    "axis/x/range/min": "axis/x/min",
    "axis/x/range/max": "axis/x/max",
    "axis/y/range/min": "axis/y/min",
    "axis/y/range/max": "axis/y/max",
    "display/flip_y": "display/origin",
    "display/flip_yaxis": "display/origin",
    "display/yflip": "display/origin",
    "display/slice": "display/slice_index",
    "display/sliceaxis": "display/slice_axis",
    "display/sliceindex": "display/slice_index",
    "display/slice_axis_name": "display/slice_axis",
    "display/aspectratio": "display/aspect",
    "display/plotaspect": "display/plot_aspect",
    "display/plot_aspect_ratio": "display/plot_aspect",
    "display/plotaspectratio": "display/plot_aspect",
    "display/plot_aspect_width": "display/plot_aspect_w",
    "display/plotaspectwidth": "display/plot_aspect_w",
    "display/plot_aspect_height": "display/plot_aspect_h",
    "display/plotaspectheight": "display/plot_aspect_h",
    "display/background": "display/plot_bg",
    "display/bg": "display/plot_bg",
    "display/grid": "display/show_grid",
    "display/axis_line": "display/show_axis_line",
    "display/axisline": "display/show_axis_line",
    "display/font_size": "display/font_size",
    "display/fontsize": "display/font_size",
    "display/hover": "display/hover_mode",
    "display/hovermode": "display/hover_mode",
    "legend/show": "legend/enabled",
    "legend/position": "legend/position",
    "colormap/zmin": "colormap/min",
    "colormap/zmax": "colormap/max",
    "colormap/reversescale": "colormap/reverse",
    "colormap/heatmap_smoothing": "colormap/smoothing",
    "colormap/heatmapsmoothing": "colormap/smoothing",
    "colormap/show_scale": "colormap/showscale",
    "colormap/label_gap": "colormap/label_gap_px",
    "colormap/labelgappx": "colormap/label_gap_px",
    "trace/marker/strokewidth": "trace/marker/stroke_width",
    "trace/marker/strokewidthpx": "trace/marker/stroke_width",
    "trace/marker/size_px": "trace/marker/size",
    "trace/markersize": "trace/marker/size",
    "trace/line/dashstyle": "trace/line/dash",
    "trace/error/thick": "trace/error/thickness",
    "trace/error/cap": "trace/error/width",
    "trace/error/cap_width": "trace/error/width",
    "annotation/bg": "annotation/background",
}

_HEATMAP_KEY_TO_FIELD: dict[str, str] = {
    "axis/x/label": "xLabel",
    "axis/x/log": "xLog",
    "axis/x/min": "xMin",
    "axis/x/max": "xMax",
    "axis/y/label": "yLabel",
    "axis/y/log": "yLog",
    "axis/y/min": "yMin",
    "axis/y/max": "yMax",
    "colormap/name": "colorscale",
    "colormap/autoscale": "autoscale",
    "colormap/min": "zmin",
    "colormap/max": "zmax",
    "colormap/reverse": "reverseScale",
    "colormap/smoothing": "heatmapSmoothing",
    "colormap/showscale": "showScale",
    "colormap/label": "zLabel",
    "colormap/label_gap_px": "zLabelGapPx",
    "display/slice_axis": "sliceAxis",
    "display/slice_index": "sliceIndex",
    "display/origin": "origin",
    "display/aspect": "aspect",
    "display/plot_aspect": "plotAspectMode",
    "display/plot_aspect_w": "plotAspectW",
    "display/plot_aspect_h": "plotAspectH",
    "display/plot_bg": "plotBg",
    "display/show_grid": "showGrid",
    "display/show_axis_line": "showAxisLine",
    "display/font_size": "fontSize",
    "display/hover_mode": "hoverMode",
    "legend/enabled": "showLegend",
    "legend/position": "legendPosition",
    "annotation/text": "annotationText",
    "annotation/x": "annotationX",
    "annotation/y": "annotationY",
    "annotation/background": "annotationBg",
    "scalebar/enabled": "scaleBarEnabled",
    "scalebar/length": "scaleBarLength",
    "scalebar/x": "scaleBarX",
    "scalebar/y": "scaleBarY",
}

_TRACE_KEY_TO_FIELD: dict[str, str] = {
    "trace/mode": "mode",
    "trace/marker/symbol": "markerSymbol",
    "trace/marker/size": "markerSize",
    "trace/marker/stroke": "markerStroke",
    "trace/marker/fill": "markerFill",
    "trace/marker/stroke_width": "markerStrokeWidth",
    "trace/line/dash": "lineDash",
    "trace/line/width": "lineWidth",
    "trace/line/color": "lineColor",
    "trace/opacity": "opacity",
    "trace/error/color": "errorColor",
    "trace/error/thickness": "errorThickness",
    "trace/error/width": "errorWidth",
}


def pod_signature_payload(pod: "Pod") -> dict[str, Any]:
    waves = getattr(pod, "waves", []) or []
    wave_sigs = [(str(getattr(w, "uid", "")), int(getattr(w, "_rev", 0))) for w in waves]

    try:
        heatmap = pod.heatmap_settings.model_dump()
    except Exception:  # noqa: BLE001
        heatmap = {}

    trace_by = getattr(pod, "trace_settings_by_wave", None)
    if isinstance(trace_by, list) and len(trace_by) == len(waves):
        try:
            trace_by_dump = [t.model_dump() for t in trace_by]
        except Exception:  # noqa: BLE001
            trace_by_dump = []
    else:
        try:
            base = pod.trace_settings.model_dump()
        except Exception:  # noqa: BLE001
            base = {}
        trace_by_dump = [base for _ in waves]

    try:
        active = int(getattr(pod, "active_wave_index", 0))
    except Exception:  # noqa: BLE001
        active = 0

    name = str(getattr(pod, "name", "") or "")

    return {
        "id": str(getattr(pod, "id", "")),
        "name": name,
        "active": active,
        "waves": wave_sigs,
        "heatmap": heatmap,
        "trace": trace_by_dump,
    }


def pod_signature(pod: "Pod") -> str:
    payload = pod_signature_payload(pod)
    try:
        text = json.dumps(payload, sort_keys=True, separators=(",", ":"))
    except Exception:  # noqa: BLE001
        text = repr(payload)
    return hashlib.sha1(text.encode("utf-8")).hexdigest()


def _normalize_graph_key(key: Any, *, trace_scope: bool = False) -> str:
    raw = str(key)
    k = raw.strip().replace(":", "/")
    k = re.sub(r"/+", "/", k).strip("/")
    if trace_scope and not k.lower().startswith("trace/"):
        k = f"trace/{k}"
    k = k.lower()
    return _GRAPH_KEY_ALIASES.get(k, k)


def _normalize_color(value: Any) -> Any:  # noqa: ANN401
    if not isinstance(value, str):
        return value
    s = value.strip()
    if not s:
        return s
    if re.fullmatch(r"[0-9a-fA-F]{6}", s):
        return f"#{s}"
    if re.fullmatch(r"#[0-9a-fA-F]{6}", s):
        return s
    if re.fullmatch(r"[0-9a-fA-F]{3}", s):
        return f"#{s}"
    if re.fullmatch(r"#[0-9a-fA-F]{3}", s):
        return s
    return value


def _normalize_trace_mode(value: Any) -> Any:  # noqa: ANN401
    if not isinstance(value, str):
        return value
    v = value.strip().lower().replace(" ", "")
    if v in {"marker", "markers"}:
        return "markers"
    if v in {"line", "lines"}:
        return "lines"
    if v in {"lines+markers", "markers+lines", "line+markers", "markers+line", "line+marker"}:
        return "lines+markers"
    if v in {"bar", "bars", "column", "columns"}:
        return "bar"
    return value


def _root_base(arr: np.ndarray) -> Any:  # noqa: ANN401
    base: Any = arr
    seen: set[int] = set()
    while True:
        ident = id(base)
        if ident in seen:
            break
        seen.add(ident)
        nxt = getattr(base, "base", None)
        if nxt is None:
            break
        base = nxt
    return base


def _wave_base_id(wave: Wave) -> int | None:
    arr = getattr(wave, "_a_raw", None)
    if not isinstance(arr, np.ndarray):
        return None
    try:
        return id(_root_base(arr))
    except Exception:  # noqa: BLE001
        return None


def _waves_share_memory(a: np.ndarray, b: np.ndarray) -> bool:
    if a is b:
        return True
    try:
        if _root_base(a) is _root_base(b):
            return True
    except Exception:  # noqa: BLE001
        pass
    try:
        return bool(np.shares_memory(a, b))
    except Exception:  # noqa: BLE001
        try:
            return bool(np.may_share_memory(a, b))
        except Exception:  # noqa: BLE001
            return False


def _wave_uid(wave: Wave) -> str:
    return str(getattr(wave, "uid", "") or "")


class _PodGraphProxy:
    def __init__(self, pods: list["Pod"], *, trace_index: int | None = None) -> None:
        self._pods = pods
        self._trace_index = trace_index

    def __repr__(self) -> str:
        suffix = f", trace_index={self._trace_index}" if self._trace_index is not None else ""
        return f"_PodGraphProxy(n={len(self._pods)}{suffix})"

    @property
    def trace(self) -> "_PodGraphTraceCollectionProxy":
        return _PodGraphTraceCollectionProxy(self._pods)

    def apply(self, mapping: Any) -> None:  # noqa: ANN401
        if not isinstance(mapping, dict):
            raise TypeError("graph expects a dict of key -> value")
        for k, v in mapping.items():
            self[k] = v

    def __getitem__(self, key: Any) -> Any:  # noqa: ANN401
        k = _normalize_graph_key(key, trace_scope=self._trace_index is not None)
        if not self._pods:
            raise IndexError("no pods selected")
        pod = self._pods[0]
        if k.startswith("trace/"):
            return self._get_trace_value(pod, k)
        return self._get_heatmap_value(pod, k)

    def __setitem__(self, key: Any, value: Any) -> None:  # noqa: ANN401
        k = _normalize_graph_key(key, trace_scope=self._trace_index is not None)
        if isinstance(value, dict):
            for subk, subv in value.items():
                self[f"{k}/{subk}"] = subv
            return

        if k.startswith("trace/"):
            for pod in self._pods:
                self._set_trace_value(pod, k, value)
            return

        for pod in self._pods:
            self._set_heatmap_value(pod, k, value)

    def _get_heatmap_value(self, pod: "Pod", key: str) -> Any:  # noqa: ANN401
        field = _HEATMAP_KEY_TO_FIELD.get(key)
        if field is None:
            raise KeyError(key)
        return getattr(pod.heatmap_settings, field)

    def _set_heatmap_value(self, pod: "Pod", key: str, value: Any) -> None:  # noqa: ANN401
        field = _HEATMAP_KEY_TO_FIELD.get(key)
        if field is None:
            raise KeyError(key)
        patch = {field: value}
        if field in {"zmin", "zmax"} and value is not None:
            patch["autoscale"] = False
        pod.heatmap_settings = HeatmapViewSettings.model_validate({**pod.heatmap_settings.model_dump(), **patch})

    def _trace_index_for_pod(self, pod: "Pod") -> int:
        if self._trace_index is not None:
            return int(self._trace_index)
        return min(max(int(getattr(pod, "active_wave_index", 0)), 0), max(0, len(pod.waves) - 1))

    def _get_trace_value(self, pod: "Pod", key: str) -> Any:  # noqa: ANN401
        field = _TRACE_KEY_TO_FIELD.get(key)
        if field is None:
            raise KeyError(key)
        ii = self._trace_index_for_pod(pod)
        if ii < 0 or ii >= len(pod.trace_settings_by_wave):
            raise IndexError(f"trace index out of range: {ii} for n={len(pod.trace_settings_by_wave)}")
        return getattr(pod.trace_settings_by_wave[ii], field)

    def _set_trace_value(self, pod: "Pod", key: str, value: Any) -> None:  # noqa: ANN401
        field = _TRACE_KEY_TO_FIELD.get(key)
        if field is None:
            raise KeyError(key)
        ii = self._trace_index_for_pod(pod)
        if ii < 0 or ii >= len(pod.trace_settings_by_wave):
            raise IndexError(f"trace index out of range: {ii} for n={len(pod.trace_settings_by_wave)}")

        v = value
        if field in {"markerStroke", "markerFill", "lineColor", "errorColor"}:
            v = _normalize_color(value)
        if field == "mode":
            v = _normalize_trace_mode(value)

        pod.trace_settings_by_wave[ii] = TraceViewSettings.model_validate({**pod.trace_settings_by_wave[ii].model_dump(), field: v})
        if ii == 0:
            pod.trace_settings = pod.trace_settings_by_wave[0]


class _PodGraphTraceCollectionProxy:
    def __init__(self, pods: list["Pod"]) -> None:
        self._pods = pods

    def __getitem__(self, idx: int) -> _PodGraphProxy:
        return _PodGraphProxy(self._pods, trace_index=int(idx))

    def __setitem__(self, idx: int, mapping: Any) -> None:  # noqa: ANN401
        proxy = _PodGraphProxy(self._pods, trace_index=int(idx))
        if isinstance(mapping, dict):
            proxy.apply(mapping)
            return
        raise TypeError("trace[...] expects a dict of key -> value")


class BoardPodsView:
    def __init__(self, pods: list["Pod"]) -> None:
        self._pods = pods

    @property
    def graph(self) -> _PodGraphProxy:
        return _PodGraphProxy(self._pods)

    @graph.setter
    def graph(self, value: Any) -> None:  # noqa: ANN401
        self.graph.apply(value)


_PLOTLY_DEFAULT_COLORS = [
    "#0000CC",
    "#CC0000",
    "#008800",
    "#d62728",
    "#9467bd",
    "#8c564b",
    "#e377c2",
    "#7f7f7f",
    "#bcbd22",
    "#17becf",
]

_POD_AUTO_NAME_RE = re.compile(r"^pod(\d+)$", re.IGNORECASE)


class Pod:
    def __init__(self, waves: Any = None, *, name: str | None = None) -> None:  # noqa: ANN401
        self.id = uuid.uuid4().hex
        self.name = str(name or "").strip()
        self._board = None
        self.waves: list[Wave] = []
        self.heatmap_settings = HeatmapViewSettings()
        self.trace_settings = TraceViewSettings()
        self.trace_settings_by_wave: list[TraceViewSettings] = []
        self.active_wave_index = 0
        if waves is not None:
            self.show(waves)

    def __repr__(self) -> str:
        name = str(getattr(self, "name", "") or "")
        extra = f", name={name!r}" if name else ""
        return f"Pod(id={self.id!r}{extra}, waves={len(self.waves)})"

    def show(self, waves: Any) -> None:  # noqa: ANN401
        old_waves = list(self.waves)
        old_trace_settings_by_wave = list(self.trace_settings_by_wave)

        def coerce_wave(v: Any) -> Wave:  # noqa: ANN401
            if isinstance(v, Wave):
                return v
            if isinstance(v, np.ndarray):
                return Wave(v)
            arr = np.asarray(v)
            if arr.ndim not in (1, 2, 3):
                raise ValueError(f"only 1D/2D/3D arrays are supported (got ndim={arr.ndim})")
            return Wave(arr)

        items: list[Any]
        multi_wave_list = False
        if isinstance(waves, (list, tuple)):
            items = list(waves)
            multi_wave_list = bool(items) and any(isinstance(x, (Wave, np.ndarray)) for x in items)
            # Ambiguity resolution:
            # - list[Wave/ndarray/...]: treat as multiple waves
            # - plain list of numbers / list-of-lists: treat as a single array-like and wrap once
            if items and not multi_wave_list:
                items = [waves]
        else:
            items = [waves]

        out: list[Wave] = []
        ndims: set[int] = set()
        for idx, w in enumerate(items):
            try:
                ww = coerce_wave(w)
            except Exception as exc:  # noqa: BLE001
                if multi_wave_list:
                    warnings.warn(f"Skipped invalid wave item at index {idx}: {exc}", stacklevel=2)
                    continue
                raise
            ndims.add(int(ww.ndim))
            out.append(ww)
        if items and multi_wave_list and not out:
            raise ValueError("no valid waves in list")
        if len(ndims) > 1:
            raise ValueError(f"all waves in a pod must have the same ndim (got {sorted(ndims)})")
        self.waves = out
        self.active_wave_index = min(max(int(self.active_wave_index), 0), max(0, len(self.waves) - 1))

        prev_settings_by_uid: dict[str, TraceViewSettings] = {}
        for w0, s0 in zip(old_waves, old_trace_settings_by_wave):
            prev_settings_by_uid[str(w0.uid)] = s0

        next_settings: list[TraceViewSettings] = []
        for idx, w1 in enumerate(self.waves):
            uid = str(w1.uid)
            prev = prev_settings_by_uid.get(uid)
            if prev is not None:
                next_settings.append(prev)
            elif idx == 0 and isinstance(self.trace_settings, TraceViewSettings):
                next_settings.append(self.trace_settings)
            else:
                color = _PLOTLY_DEFAULT_COLORS[idx % len(_PLOTLY_DEFAULT_COLORS)]
                next_settings.append(TraceViewSettings(markerStroke=color, markerFill=color, lineColor=color))
        self.trace_settings_by_wave = next_settings
        if self.trace_settings_by_wave:
            self.trace_settings = self.trace_settings_by_wave[0]
        board = getattr(self, "_board", None)
        if isinstance(board, Board):
            board._update_wave_share_index(old_waves, self.waves)

    def append(self, waves: Wave | list[Wave]) -> None:
        if waves is None:
            return
        if not self.waves:
            self.show(waves)
            return
        if isinstance(waves, (list, tuple)):
            items = list(waves)
            if items and not any(isinstance(x, (Wave, np.ndarray)) for x in items):
                self.show(list(self.waves) + [waves])  # type: ignore[list-item]
                return
            self.show(list(self.waves) + items)  # type: ignore[list-item]
            return
        self.show(list(self.waves) + [waves])

    def remove(self, index: int) -> Wave:
        if not self.waves:
            raise IndexError("pod is empty")
        old_waves = list(self.waves)
        ii = int(index)
        if ii < 0 or ii >= len(self.waves):
            raise IndexError(f"wave index out of range: {ii} for n={len(self.waves)}")
        removed = self.waves.pop(ii)

        if self.trace_settings_by_wave:
            if ii < len(self.trace_settings_by_wave):
                self.trace_settings_by_wave.pop(ii)
            if len(self.trace_settings_by_wave) != len(self.waves):
                next_settings: list[TraceViewSettings] = []
                for idx in range(len(self.waves)):
                    if idx < len(self.trace_settings_by_wave):
                        next_settings.append(self.trace_settings_by_wave[idx])
                    else:
                        color = _PLOTLY_DEFAULT_COLORS[idx % len(_PLOTLY_DEFAULT_COLORS)]
                        next_settings.append(TraceViewSettings(markerStroke=color, markerFill=color, lineColor=color))
                self.trace_settings_by_wave = next_settings
            if self.trace_settings_by_wave:
                self.trace_settings = self.trace_settings_by_wave[0]

        if not self.waves:
            self.active_wave_index = 0
            self.trace_settings_by_wave = []
            return removed

        if self.active_wave_index > ii:
            self.active_wave_index -= 1
        elif self.active_wave_index == ii:
            self.active_wave_index = min(ii, len(self.waves) - 1)

        board = getattr(self, "_board", None)
        if isinstance(board, Board):
            board._update_wave_share_index(old_waves, self.waves)

        return removed

    def clear(self) -> None:
        old_waves = list(self.waves)
        self.waves = []
        self.active_wave_index = 0
        self.trace_settings_by_wave = []
        board = getattr(self, "_board", None)
        if isinstance(board, Board):
            board._update_wave_share_index(old_waves, self.waves)

    @property
    def graph(self) -> _PodGraphProxy:
        return _PodGraphProxy([self])

    @graph.setter
    def graph(self, value: Any) -> None:  # noqa: ANN401
        self.graph.apply(value)

    @property
    def wave(self) -> Wave:
        if not self.waves:
            raise ValueError("pod is empty")
        ii = min(max(int(self.active_wave_index), 0), len(self.waves) - 1)
        return self.waves[ii]


def _trace_settings_by_wave_for_pod(pod: Pod) -> list[TraceViewSettings]:
    ts_by = getattr(pod, "trace_settings_by_wave", None)
    waves = getattr(pod, "waves", []) or []
    if isinstance(ts_by, list) and len(ts_by) == len(waves):
        return ts_by
    base = pod.trace_settings if isinstance(getattr(pod, "trace_settings", None), TraceViewSettings) else TraceViewSettings()
    return [base for _ in waves]


def _safe_float(value: Any) -> float | None:  # noqa: ANN401
    try:
        v = float(value)
    except Exception:  # noqa: BLE001
        return None
    return v if math.isfinite(v) else None


def _safe_float_list(values: Any) -> list[float | None]:  # noqa: ANN401
    try:
        items = np.asarray(values).ravel().tolist()
    except Exception:  # noqa: BLE001
        try:
            items = list(values)
        except Exception:  # noqa: BLE001
            items = []
    return [_safe_float(v) for v in items]


def _serialize_wave_snapshot(wave: Wave) -> WaveSnapshot:
    lazy_data = wave_is_lazy(wave)
    ndim = int(wave.ndim)
    shape = tuple(int(x) for x in wave.shape)
    dtype = str(wave.dtype)
    if lazy_data:
        data: list[Any] | list[list[Any]] | list[list[list[Any]]] = []
    else:
        arr = np.asarray(wave)
        if arr.ndim == 1:
            data = arr.tolist()
        elif arr.ndim in (2, 3):
            data = arr.tolist()
        else:  # pragma: no cover
            raise ValueError(f"unsupported ndim={arr.ndim}")

    x: list[float] | None = None
    y: list[float] | None = None
    z: list[float] | None = None
    x0: float | None = None
    dx: float | None = None
    y0: float | None = None
    dy: float | None = None
    z0: float | None = None
    dz: float | None = None

    if ndim == 1:
        explicit_x = wave._explicit_coords_dim[wave._dim_index("x")]
        if explicit_x is not None:
            x = _safe_float_list(explicit_x)
        else:
            off = wave.offset
            delt = wave.delta
            x0 = _safe_float(off[0])
            dx = _safe_float(delt[0])
    elif ndim == 2:
        rows, cols = shape
        explicit_x2 = wave._explicit_coords_dim[wave._dim_index("x")]
        explicit_y2 = wave._explicit_coords_dim[wave._dim_index("y")]
        if explicit_x2 is not None:
            grid = np.asarray(explicit_x2)
            if grid.shape == (rows, cols):
                x = _safe_float_list(grid[0, :])
        else:
            off = wave.offset
            delt = wave.delta
            x0 = _safe_float(off[0])
            dx = _safe_float(delt[0])

        if explicit_y2 is not None:
            grid = np.asarray(explicit_y2)
            if grid.shape == (rows, cols):
                y = _safe_float_list(grid[:, 0])
        else:
            off = wave.offset
            delt = wave.delta
            y0 = _safe_float(off[1])
            dy = _safe_float(delt[1])
    elif ndim == 3:
        planes, rows, cols = shape
        explicit_x3 = wave._explicit_coords_dim[wave._dim_index("x")]
        explicit_y3 = wave._explicit_coords_dim[wave._dim_index("y")]
        explicit_z3 = wave._explicit_coords_dim[wave._dim_index("z")]
        if explicit_x3 is not None:
            grid = np.asarray(explicit_x3)
            if grid.shape == (planes, rows, cols):
                x = _safe_float_list(grid[0, 0, :])
        else:
            off = wave.offset
            delt = wave.delta
            x0 = _safe_float(off[0])
            dx = _safe_float(delt[0])

        if explicit_y3 is not None:
            grid = np.asarray(explicit_y3)
            if grid.shape == (planes, rows, cols):
                y = _safe_float_list(grid[0, :, 0])
        else:
            off = wave.offset
            delt = wave.delta
            y0 = _safe_float(off[1])
            dy = _safe_float(delt[1])

        if explicit_z3 is not None:
            grid = np.asarray(explicit_z3)
            if grid.shape == (planes, rows, cols):
                z = _safe_float_list(grid[:, 0, 0])
        else:
            off = wave.offset
            delt = wave.delta
            z0 = _safe_float(off[2])
            dz = _safe_float(delt[2])

    graph_legend: str | None = None
    try:
        raw = wave.userdata.get("graph_legend")
        if raw is not None:
            s = str(raw).strip()
            if s:
                graph_legend = s
    except Exception:  # noqa: BLE001
        graph_legend = None

    errorbar: list[float | None] | None = None
    if ndim == 1 and not lazy_data:
        try:
            raw_errorbar = getattr(wave, "errorbar", None)
            if raw_errorbar is not None:
                err = np.asarray(raw_errorbar, dtype=float)
                if err.shape == shape:
                    errorbar = _safe_float_list(err)
        except Exception:  # noqa: BLE001
            errorbar = None

    return WaveSnapshot(
        kind="wave",
        uid=wave.uid,
        name=wave.name,
        description=wave.description,
        graphLegend=graph_legend,
        errorbar=errorbar,
        ndim=ndim,  # type: ignore[arg-type]
        dtype=dtype,
        shape=list(shape),
        data=data,
        dataRef=wave.uid if lazy_data else None,
        dataLoaded=not lazy_data,
        x=x,
        y=y,
        z=z,
        x0=x0,
        dx=dx,
        y0=y0,
        dy=dy,
        z0=z0,
        dz=dz,
    )


def _serialize_pod_snapshot(pod: Pod) -> PodSnapshot:
    waves = getattr(pod, "waves", []) or []
    return PodSnapshot(
        id=pod.id,
        name=str(getattr(pod, "name", "") or ""),
        signature=pod_signature(pod),
        waves=[_serialize_wave_snapshot(w) for w in waves],
        heatmapSettings=pod.heatmap_settings,
        traceSettings=pod.trace_settings,
        traceSettingsByWave=_trace_settings_by_wave_for_pod(pod),
        activeWaveIndex=min(max(int(getattr(pod, "active_wave_index", 0)), 0), max(0, len(waves) - 1)),
    )


class Board:
    def __init__(self) -> None:
        self._selected_i = 0
        self._pods: list[Pod] = []
        self._next_pod_number = 0
        self._wave_share_index: dict[str, set[str]] = {}
        self._wave_share_bases: dict[str, int] = {}

    def __repr__(self) -> str:
        return f"Board(n={len(self._pods)}, selected={self._selected_i})"

    def __len__(self) -> int:
        return len(self._pods)

    @property
    def selected(self) -> int:
        return self._selected_i

    def set_selected(self, i: int) -> None:
        if not self._pods:
            self._selected_i = 0
            return
        ii = max(0, min(int(i), len(self._pods) - 1))
        self._selected_i = ii

    def _ensure_wave_share_index(self) -> None:
        if not isinstance(getattr(self, "_wave_share_index", None), dict):
            self._wave_share_index = {}
        if not isinstance(getattr(self, "_wave_share_bases", None), dict):
            self._wave_share_bases = {}

    def _attach_pod(self, pod: Pod) -> None:
        try:
            pod._board = self  # type: ignore[attr-defined]
        except Exception:  # noqa: BLE001
            pass

    def _attach_all_pods(self) -> None:
        for pod in self._pods:
            self._attach_pod(pod)

    def _all_waves(self) -> list[Wave]:
        waves: list[Wave] = []
        for pod in self._pods:
            for w in getattr(pod, "waves", []) or []:
                if isinstance(w, Wave):
                    waves.append(w)
        return waves

    def _remove_wave_uid(self, uid: str) -> None:
        if not uid:
            return
        others = self._wave_share_index.pop(uid, set())
        for other in list(others):
            shared = self._wave_share_index.get(other)
            if not shared:
                continue
            shared.discard(uid)
            if not shared:
                self._wave_share_index.pop(other, None)
        self._wave_share_bases.pop(uid, None)

    def _register_share(self, uid: str, other_uid: str) -> None:
        if not uid or not other_uid or uid == other_uid:
            return
        self._wave_share_index.setdefault(uid, set()).add(other_uid)
        self._wave_share_index.setdefault(other_uid, set()).add(uid)

    def _update_wave_share_index(self, old_waves: list[Wave], new_waves: list[Wave]) -> None:
        self._ensure_wave_share_index()
        old_uids = {_wave_uid(w) for w in old_waves if _wave_uid(w)}
        new_uids = {_wave_uid(w) for w in new_waves if _wave_uid(w)}

        new_bases: dict[str, int] = {}
        for w in new_waves:
            uid = _wave_uid(w)
            if not uid:
                continue
            base_id = _wave_base_id(w)
            if base_id is not None:
                new_bases[uid] = base_id

        base_changed = {uid for uid, base_id in new_bases.items() if self._wave_share_bases.get(uid) != base_id}
        removed = (old_uids - new_uids) | base_changed
        added = (new_uids - old_uids) | base_changed

        for uid in removed:
            self._remove_wave_uid(uid)

        for uid in new_uids:
            base_id = new_bases.get(uid)
            if base_id is not None:
                self._wave_share_bases[uid] = base_id

        if not added:
            return

        waves_by_uid: dict[str, Wave] = {}
        for w in self._all_waves():
            uid = _wave_uid(w)
            if uid:
                waves_by_uid[uid] = w

        for uid in added:
            wave = waves_by_uid.get(uid)
            if wave is None:
                continue
            arr = getattr(wave, "_a_raw", None)
            if not isinstance(arr, np.ndarray):
                continue
            base_id = self._wave_share_bases.get(uid)
            for other_uid, other_wave in waves_by_uid.items():
                if other_uid == uid:
                    continue
                other_arr = getattr(other_wave, "_a_raw", None)
                if not isinstance(other_arr, np.ndarray):
                    continue
                other_base = self._wave_share_bases.get(other_uid)
                if base_id is not None and other_base is not None and base_id == other_base:
                    self._register_share(uid, other_uid)
                    continue
                if _waves_share_memory(arr, other_arr):
                    self._register_share(uid, other_uid)

    def _rebuild_wave_share_index(self) -> None:
        self._ensure_wave_share_index()
        self._wave_share_index = {}
        self._wave_share_bases = {}

        waves = self._all_waves()
        if not waves:
            return

        for w in waves:
            uid = _wave_uid(w)
            if not uid:
                continue
            base_id = _wave_base_id(w)
            if base_id is not None:
                self._wave_share_bases[uid] = base_id

        n = len(waves)
        for i in range(n):
            w_i = waves[i]
            uid_i = _wave_uid(w_i)
            if not uid_i:
                continue
            arr_i = getattr(w_i, "_a_raw", None)
            if not isinstance(arr_i, np.ndarray):
                continue
            base_i = self._wave_share_bases.get(uid_i)
            for j in range(i + 1, n):
                w_j = waves[j]
                uid_j = _wave_uid(w_j)
                if not uid_j:
                    continue
                arr_j = getattr(w_j, "_a_raw", None)
                if not isinstance(arr_j, np.ndarray):
                    continue
                base_j = self._wave_share_bases.get(uid_j)
                if base_i is not None and base_j is not None and base_i == base_j:
                    self._register_share(uid_i, uid_j)
                    continue
                if _waves_share_memory(arr_i, arr_j):
                    self._register_share(uid_i, uid_j)

    def _shared_wave_uids(self, uid: str) -> set[str]:
        self._ensure_wave_share_index()
        shared = self._wave_share_index.get(uid)
        return set(shared) if shared else set()

    def _normalize_pod_name(self, name: str | None) -> str | None:
        if name is None:
            return None
        s = str(name).strip()
        return s if s else None

    def _pod_name_taken(self, name: str, *, exclude: Pod | None = None) -> bool:
        for p in self._pods:
            if exclude is not None and p is exclude:
                continue
            if str(getattr(p, "name", "") or "") == name:
                return True
        return False

    def _bump_next_pod_number_from_name(self, name: str) -> None:
        m = _POD_AUTO_NAME_RE.fullmatch(str(name).strip())
        if not m:
            return
        try:
            n = int(m.group(1))
        except Exception:  # noqa: BLE001
            return
        if n + 1 > int(getattr(self, "_next_pod_number", 0) or 0):
            self._next_pod_number = n + 1

    def _generate_default_pod_name(self) -> str:
        while True:
            n = int(getattr(self, "_next_pod_number", 0) or 0)
            candidate = f"pod{n}"
            self._next_pod_number = n + 1
            if not self._pod_name_taken(candidate):
                return candidate

    def _assign_pod_name(self, pod: Pod, name: str | None) -> None:
        nm = self._normalize_pod_name(name)
        if nm is None:
            nm = self._generate_default_pod_name()
        else:
            if self._pod_name_taken(nm, exclude=pod):
                raise ValueError(f"pod name already exists: {nm!r}")
            self._bump_next_pod_number_from_name(nm)
        pod.name = nm

    def add(self, waves: Any = None, *, name: str | None = None) -> Pod:  # noqa: ANN401
        pod = Pod()
        self._assign_pod_name(pod, name)
        self._pods.append(pod)
        self._attach_pod(pod)
        if waves is not None:
            pod.show(waves)
        self._selected_i = len(self._pods) - 1
        return pod

    def append(self, value: Any, *, name: str | None = None) -> Pod:  # noqa: ANN401
        nm = self._normalize_pod_name(name)
        if nm is not None:
            for i, pod in enumerate(self._pods):
                if str(getattr(pod, "name", "") or "") == nm:
                    self._selected_i = i
                    self._attach_pod(pod)
                    if value is None or (isinstance(value, (list, tuple)) and len(value) == 0):
                        return pod
                    pod.append(value)
                    return pod

            if value is None or (isinstance(value, (list, tuple)) and len(value) == 0):
                return self.add(name=nm)
            return self.add(value, name=nm)

        if value is None or (isinstance(value, (list, tuple)) and len(value) == 0):
            if not self._pods:
                return self.add()
            return self.get()

        if not self._pods:
            return self.add(value)
        pod = self.get()
        self._attach_pod(pod)
        pod.append(value)
        return pod

    def remove(self, i: int | None = None) -> Pod:
        if not self._pods:
            raise IndexError("board is empty")
        ii = self._selected_i if i is None else int(i)
        if ii < 0 or ii >= len(self._pods):
            raise IndexError(f"board index out of range: {ii} for n={len(self._pods)}")
        pod = self._pods.pop(ii)
        try:
            self._update_wave_share_index(list(getattr(pod, "waves", []) or []), [])
        except Exception:  # noqa: BLE001
            pass
        if not self._pods:
            self._selected_i = 0
        else:
            self._selected_i = max(0, min(self._selected_i, len(self._pods) - 1))
        return pod

    def clear(self) -> None:
        self._pods = []
        self._selected_i = 0
        self._wave_share_index = {}
        self._wave_share_bases = {}

    def get(self, i: int | None = None) -> Pod:
        if not self._pods:
            raise IndexError("board is empty")
        ii = self._selected_i if i is None else int(i)
        if ii < 0 or ii >= len(self._pods):
            raise IndexError(f"board index out of range: {ii} for n={len(self._pods)}")
        pod = self._pods[ii]
        self._attach_pod(pod)
        return pod

    def __getitem__(self, key: int | slice | str) -> Pod | BoardPodsView:
        if isinstance(key, slice):
            idxs = range(*key.indices(len(self._pods)))
            return BoardPodsView([self._pods[i] for i in idxs])
        if isinstance(key, str):
            name = str(key).strip()
            if not name:
                raise KeyError("pod name is empty")
            for pod in self._pods:
                if str(getattr(pod, "name", "") or "") == name:
                    return pod
            raise KeyError(f"pod not found: {name!r}")
        return self.get(int(key))

    def __setitem__(self, key: int, value: Any) -> None:  # noqa: ANN401
        pod = self.get(int(key))
        if isinstance(value, list):
            pod.show(value)  # type: ignore[arg-type]
        else:
            pod.show(value)

    @property
    def pod(self) -> Pod:
        return self.get()

    @property
    def name(self) -> str:
        if not self._pods:
            return ""
        return str(getattr(self.get(), "name", "") or "")

    @name.setter
    def name(self, value: str) -> None:
        if not self._pods:
            raise IndexError("board is empty")
        nm = self._normalize_pod_name(value)
        if nm is None:
            raise ValueError("pod name must be non-empty")
        pod = self.get()
        if self._pod_name_taken(nm, exclude=pod):
            raise ValueError(f"pod name already exists: {nm!r}")
        pod.name = nm
        self._bump_next_pod_number_from_name(nm)

    @property
    def wave(self) -> Wave:
        return self.get().wave

    @wave.setter
    def wave(self, value: Any) -> None:  # noqa: ANN401
        # Allow `board.wave += ...` (augmented assignment assigns back to the property).
        if not self._pods:
            self.show(value)
            return

        pod = self.get()
        if not pod.waves:
            pod.show(value)
            return

        current = pod.wave
        if isinstance(value, Wave) and value is current:
            return

        def coerce_wave(v: Any) -> Wave:  # noqa: ANN401
            if isinstance(v, Wave):
                return v
            if isinstance(v, np.ndarray):
                return Wave(v)
            arr = np.asarray(v)
            if arr.ndim not in (1, 2, 3):
                raise ValueError(f"only 1D/2D/3D arrays are supported (got ndim={arr.ndim})")
            return Wave(arr)

        w = coerce_wave(value)
        ii = min(max(int(getattr(pod, "active_wave_index", 0)), 0), max(0, len(pod.waves) - 1))
        waves = list(pod.waves)
        waves[ii] = w
        pod.show(waves)

    @property
    def waves(self) -> list[Wave]:
        return self.get().waves

    @waves.setter
    def waves(self, value: Any) -> None:  # noqa: ANN401
        if not self._pods:
            self.show(value)
            return
        self.get().show(value)

    @property
    def graph(self) -> _PodGraphProxy:
        return _PodGraphProxy([self.get()])

    @graph.setter
    def graph(self, value: Any) -> None:  # noqa: ANN401
        self.graph.apply(value)

    def show(self, value: Any, *, name: str | None = None) -> None:  # noqa: ANN401
        nm = self._normalize_pod_name(name)
        if nm is not None:
            for i, pod in enumerate(self._pods):
                if str(getattr(pod, "name", "") or "") == nm:
                    self._selected_i = i
                    pod.show(value)
                    return
            if isinstance(value, (list, tuple)) and len(value) == 0:
                self.add(name=nm)
                return
            self.add(value, name=nm)
            return

        if not self._pods:
            if isinstance(value, (list, tuple)) and len(value) == 0:
                self.add()
                return
            self.add(value)
            return

        self.get().show(value)

    def snapshot_pods(self, idxs: list[int]) -> list[PodSnapshot]:
        out: list[PodSnapshot] = []
        for ii in idxs:
            i = int(ii)
            if i < 0 or i >= len(self._pods):
                continue
            out.append(_serialize_pod_snapshot(self._pods[i]))
        return out

    def snapshot_pod(self, i: int) -> PodSnapshot:
        return _serialize_pod_snapshot(self.get(i))

    def snapshot(self) -> BoardSnapshot:
        return BoardSnapshot(
            selected=BoardSelection(i=self._selected_i),
            pods=[_serialize_pod_snapshot(pod) for pod in self._pods],
        )
