from __future__ import annotations

import re
from typing import Any

_ALPHANUM_RE = re.compile(r"(\d+)")


def alphanumeric(value: Any) -> tuple[Any, ...]:
    """
    Return a "natural" sort key for strings containing numbers.

    Example:
        sorted(["a2", "a10", "a1"], key=alphanumeric) -> ["a1", "a2", "a10"]
    """

    s = "" if value is None else str(value)
    parts = _ALPHANUM_RE.split(s)
    out: list[tuple[Any, ...]] = []
    for part in parts:
        if not part:
            continue
        if part.isdigit():
            out.append((0, int(part), len(part)))
        else:
            out.append((1, part.casefold()))
    out.append((2, s))
    return tuple(out)

