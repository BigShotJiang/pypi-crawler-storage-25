def stem(file_path: str) -> str:
  """Wave name = file stem (basename without extension)."""

  name = (file_path or "").split("/")[-1]
  if not name:
    raise ValueError("empty file_path")
  if "." in name:
    name = name.rsplit(".", 1)[0]
  name = name.strip()
  if not name:
    raise ValueError("empty name")
  if "/" in name or "\\" in name:
    raise ValueError("invalid name")
  return name

