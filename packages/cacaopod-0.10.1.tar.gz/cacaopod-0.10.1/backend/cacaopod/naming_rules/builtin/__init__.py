# Builtin naming rules.

