# Package for builtin naming rules.

