"""Job Manager logic."""
