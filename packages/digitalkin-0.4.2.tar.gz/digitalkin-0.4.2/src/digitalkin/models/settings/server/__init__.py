"""Package for server settings."""
