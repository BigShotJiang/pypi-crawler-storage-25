"""Tests for the high-level Python API (digest2.core)."""

import subprocess
import tempfile
from pathlib import Path

import pytest

from digest2 import Digest2, classify, ClassificationResult, Scores
from digest2.observation import Observation, parse_ades_psv, parse_ades_xml, parse_mpc80_file


class TestDigest2Class:
    """Test the Digest2 stateful classifier."""

    def test_init_and_close(self, model_path, obscodes_path, empty_config_path):
        d2 = Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
        )
        d2.close()

    def test_context_manager(self, model_path, obscodes_path, empty_config_path):
        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
        ) as d2:
            assert d2._closed is False
        assert d2._closed is True

    def test_classify_tracklet(self, model_path, obscodes_path, empty_config_path):
        obs = [
            Observation(mjd=59938.384965, ra=128.15118, dec=17.17665,
                        mag=22.22, band="G", obscode="G96"),
            Observation(mjd=59938.395273, ra=128.14899, dec=17.17702,
                        mag=21.96, band="G", obscode="G96"),
            Observation(mjd=59938.400402, ra=128.14780, dec=17.17717,
                        mag=21.55, band="G", obscode="G96"),
        ]

        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            result = d2.classify_tracklet(obs)

        assert isinstance(result, ClassificationResult)
        assert isinstance(result.raw, Scores)
        assert isinstance(result.noid, Scores)
        assert result.rms >= 0
        assert result.rms_prime >= 0

        # MB1 should be dominant
        assert result.noid.MB1 > 50

    def test_classify_file(self, model_path, obscodes_path, sample_obs_path,
                           empty_config_path):
        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            results = d2.classify_file(sample_obs_path)

        assert len(results) == 1
        r = results[0]
        assert isinstance(r, ClassificationResult)
        assert "K16S99K" in r.designation
        assert abs(r.rms - 0.73) < 0.1
        # NoID scores should match CLI
        assert round(r.noid.Int) == 2
        assert round(r.noid.NEO) == 2
        assert round(r.noid.MB1) == 85

    def test_classify_file_matches_cli(self, model_path, obscodes_path,
                                       sample_obs_path, empty_config_path):
        """Verify Python API matches CLI output for sample.obs.

        CLI with 'repeatable' config shows:
        K16S99K  0.73  Int=2 NEO=2 N22=1 N18=0 MC=2 MB1=85 MB2=3
        """
        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            results = d2.classify_file(sample_obs_path)

        r = results[0]

        # These should match the CLI exactly (all rounded)
        assert round(r.noid.Int) == 2
        assert round(r.noid.NEO) == 2
        assert round(r.noid.N22) == 1
        assert round(r.noid.N18) == 0
        assert round(r.noid.MC) == 2
        assert round(r.noid.MB1) == 85
        assert round(r.noid.MB2) == 3

    def test_classify_tracklet_with_class_filter(self, model_path, obscodes_path,
                                                  empty_config_path):
        obs = [
            Observation(mjd=59938.384965, ra=128.15118, dec=17.17665,
                        mag=22.22, obscode="G96"),
            Observation(mjd=59938.395273, ra=128.14899, dec=17.17702,
                        mag=21.96, obscode="G96"),
        ]

        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            result = d2.classify_tracklet(obs, classes=["NEO", "MB1"])

        # Should still return all classes but only filtered ones computed
        assert result.noid.NEO >= 0
        assert result.noid.MB1 >= 0

    def test_classify_batch(self, model_path, obscodes_path, empty_config_path):
        obs1 = [
            Observation(mjd=59938.384965, ra=128.15118, dec=17.17665,
                        mag=22.22, obscode="G96"),
            Observation(mjd=59938.395273, ra=128.14899, dec=17.17702,
                        mag=21.96, obscode="G96"),
        ]
        obs2 = [
            Observation(mjd=59938.384965, ra=130.0, dec=20.0,
                        mag=20.0, obscode="G96"),
            Observation(mjd=59938.395273, ra=130.01, dec=20.01,
                        mag=20.0, obscode="G96"),
        ]

        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            results = d2.classify_batch([obs1, obs2])

        assert len(results) == 2
        assert results[0] is not None
        assert results[1] is not None
        assert isinstance(results[0], ClassificationResult)

    def test_closed_raises(self, model_path, obscodes_path, empty_config_path):
        d2 = Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
        )
        d2.close()
        with pytest.raises(RuntimeError, match="closed"):
            d2.classify_tracklet([
                Observation(mjd=59938.0, ra=128.0, dec=17.0, obscode="G96"),
                Observation(mjd=59938.1, ra=128.1, dec=17.1, obscode="G96"),
            ])

    def test_invalid_class_abbr(self, model_path, obscodes_path,
                                 empty_config_path):
        obs = [
            Observation(mjd=59938.0, ra=128.0, dec=17.0, obscode="G96"),
            Observation(mjd=59938.1, ra=128.1, dec=17.1, obscode="G96"),
        ]
        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
        ) as d2:
            with pytest.raises(ValueError, match="Unknown class"):
                d2.classify_tracklet(obs, classes=["BOGUS"])

    def test_with_mpc_config(self, model_path, obscodes_path, mpc_config_path):
        """Test that applying MPC.config changes scores (G96 has 0.29 arcsec error)."""
        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=mpc_config_path,
            repeatable=True,
        ) as d2:
            obs = [
                Observation(mjd=59938.384965, ra=128.15118, dec=17.17665,
                            mag=22.22, obscode="G96"),
                Observation(mjd=59938.395273, ra=128.14899, dec=17.17702,
                            mag=21.96, obscode="G96"),
                Observation(mjd=59938.400402, ra=128.14780, dec=17.17717,
                            mag=21.55, obscode="G96"),
            ]
            result = d2.classify_tracklet(obs)

        # With G96 error at 0.29 arcsec (vs default 1.0), scores change significantly.
        # With real site errors, this object scores as high-probability NEO.
        assert result.noid.NEO > 50


class TestClassifyFunction:
    """Test the polymorphic classify() convenience function."""

    def test_classify_single_tracklet(self, model_path, obscodes_path,
                                       empty_config_path):
        obs = [
            Observation(mjd=59938.384965, ra=128.15118, dec=17.17665,
                        mag=22.22, obscode="G96"),
            Observation(mjd=59938.395273, ra=128.14899, dec=17.17702,
                        mag=21.96, obscode="G96"),
        ]

        result = classify(
            obs,
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        )

        assert isinstance(result, ClassificationResult)
        assert isinstance(result.raw, Scores)
        assert isinstance(result.noid, Scores)
        assert result.rms >= 0

    def test_classify_filepath_str(self, model_path, obscodes_path,
                                    sample_obs_path, empty_config_path):
        results = classify(
            sample_obs_path,
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        )

        assert isinstance(results, list)
        assert len(results) == 1
        assert "K16S99K" in results[0].designation

    def test_classify_filepath_path(self, model_path, obscodes_path,
                                     sample_obs_path, empty_config_path):
        results = classify(
            Path(sample_obs_path),
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        )

        assert isinstance(results, list)
        assert len(results) == 1
        assert "K16S99K" in results[0].designation

    def test_classify_batch(self, model_path, obscodes_path, empty_config_path):
        obs1 = [
            Observation(mjd=59938.384965, ra=128.15118, dec=17.17665,
                        mag=22.22, obscode="G96"),
            Observation(mjd=59938.395273, ra=128.14899, dec=17.17702,
                        mag=21.96, obscode="G96"),
        ]
        obs2 = [
            Observation(mjd=59938.384965, ra=130.0, dec=20.0,
                        mag=20.0, obscode="G96"),
            Observation(mjd=59938.395273, ra=130.01, dec=20.01,
                        mag=20.0, obscode="G96"),
        ]

        results = classify(
            [obs1, obs2],
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        )

        assert isinstance(results, list)
        assert len(results) == 2
        assert results[0] is not None
        assert results[1] is not None


class TestScoresDataclass:
    """Test the Scores dataclass convenience methods."""

    def test_getitem(self):
        s = Scores(NEO=42.5, MB1=57.5)
        assert s["NEO"] == 42.5
        assert s["MB1"] == 57.5
        assert s["Int"] == 0.0

    def test_getitem_invalid_key(self):
        s = Scores()
        with pytest.raises(KeyError):
            s["BOGUS"]

    def test_items(self):
        s = Scores(NEO=10.0, MB1=90.0)
        items = dict(s.items())
        assert items["NEO"] == 10.0
        assert items["MB1"] == 90.0
        assert items["Int"] == 0.0
        assert len(items) == 15

    def test_iter(self):
        s = Scores()
        abbrs = list(s)
        assert abbrs == [
            "Int", "NEO", "N22", "N18", "MC", "Hun", "Pho",
            "MB1", "Pal", "Han", "MB2", "MB3", "Hil", "JTr", "JFC",
        ]

    def test_frozen(self):
        s = Scores(NEO=42.5)
        with pytest.raises(AttributeError):
            s.NEO = 99.0


class TestClassificationResult:
    """Test the ClassificationResult dataclass."""

    def test_top_class(self):
        noid = Scores(NEO=10.0, MB1=80.0, MC=5.0)
        result = ClassificationResult(
            raw=Scores(), noid=noid, rms=0.5, rms_prime=0.0,
        )
        assert result.top_class == "MB1"

    def test_top_class_neo(self):
        noid = Scores(NEO=90.0, MB1=5.0)
        result = ClassificationResult(
            raw=Scores(), noid=noid, rms=0.5, rms_prime=0.0,
        )
        assert result.top_class == "NEO"

    def test_designation_default(self):
        result = ClassificationResult(
            raw=Scores(), noid=Scores(), rms=0.0, rms_prime=0.0,
        )
        assert result.designation == ""

    def test_frozen(self):
        result = ClassificationResult(
            raw=Scores(), noid=Scores(), rms=0.0, rms_prime=0.0,
        )
        with pytest.raises(AttributeError):
            result.rms = 99.0


# ── Cross-validation: Python API vs C CLI ──────────────────────────────


ALL_CLASSES = [
    "Int", "NEO", "N22", "N18", "MC", "Hun", "Pho",
    "MB1", "Pal", "Han", "MB2", "MB3", "Hil", "JTr", "JFC",
]


def _parse_cli_output(stdout: str):
    """Parse CLI stdout into a list of dicts with designation, rms, and scores.

    Expected format (with all classes requested):
        Desig.    RMS Int NEO N22 N18  MC Hun Pho MB1 Pal Han MB2 MB3 Hil JTr JFC
        K16S99K  0.73   2   2   1   0   2   0   0  85   0   0   3   0   0   0   0
    """
    lines = [l for l in stdout.strip().splitlines() if l.strip()]
    header = lines[0].split()
    results = []
    for line in lines[1:]:
        fields = line.split()
        desig = fields[0]
        rms = float(fields[1])
        scores = {}
        for i, cls in enumerate(ALL_CLASSES):
            scores[cls] = int(fields[2 + i])
        results.append({"designation": desig, "rms": rms, "scores": scores})
    return results


def _run_cli(data_dir, config_path, obs_filename):
    """Run the C digest2 binary and return parsed results."""
    binary = data_dir / "digest2"
    if not binary.exists():
        pytest.skip(f"digest2 binary not found at {binary}")
    result = subprocess.run(
        [str(binary), "-c", config_path, obs_filename],
        cwd=data_dir,
        check=False,
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        pytest.fail(f"digest2 CLI failed: {result.stderr}")
    return _parse_cli_output(result.stdout)


class TestCLIvsPythonAPI:
    """Compare C CLI output to Python API output on the same inputs."""

    @pytest.fixture
    def cli_config_path(self, tmp_path):
        """Write a CLI config that requests repeatable + all 15 NoID classes."""
        cfg = tmp_path / "cli_test.config"
        cfg.write_text("repeatable\nnoid\n" + "\n".join(ALL_CLASSES) + "\n")
        return str(cfg)

    @staticmethod
    def _compare_results(cli_results, py_results, tolerance=0):
        """Compare CLI and Python results, allowing +-tolerance on scores.

        Args:
            tolerance: Maximum allowed difference per score. Use 0 for exact
                match (MPC 80-col where both paths are identical), or 1 for
                ADES XML where different XML parsers can cause minor
                floating-point divergence at rounding boundaries.
        """
        assert len(py_results) == len(cli_results), \
            f"Tracklet count mismatch: CLI={len(cli_results)} Python={len(py_results)}"

        for cli_r, py_r in zip(cli_results, py_results):
            # Designations should match
            assert cli_r["designation"] in py_r.designation or \
                   py_r.designation in cli_r["designation"], \
                   f"Designation mismatch: CLI={cli_r['designation']} Python={py_r.designation}"

            # RMS should match within tolerance
            assert abs(cli_r["rms"] - py_r.rms) < 0.01, \
                f"RMS mismatch for {cli_r['designation']}: " \
                f"CLI={cli_r['rms']} Python={py_r.rms:.2f}"

            # Every class score (rounded to integer) should match within tolerance
            for cls in ALL_CLASSES:
                cli_score = cli_r["scores"][cls]
                py_score = round(py_r.noid[cls])
                assert abs(cli_score - py_score) <= tolerance, \
                    f"Score mismatch for {cli_r['designation']} class {cls}: " \
                    f"CLI={cli_score} Python={py_score} (tolerance={tolerance})"

    def test_sample_obs_scores_match(self, digest2_dir, model_path,
                                      obscodes_path, sample_obs_path,
                                      cli_config_path):
        """C CLI and Python API produce identical scores for sample.obs.

        MPC 80-column format is parsed identically by both C and Python,
        so scores should match exactly (tolerance=0).
        """
        data_dir = digest2_dir / "digest2"

        # Run C CLI
        cli_results = _run_cli(data_dir, cli_config_path, "sample.obs")
        assert len(cli_results) >= 1

        # Run Python API with equivalent settings (repeatable, no site errors)
        empty_cfg = Path(cli_config_path).parent / "empty.config"
        empty_cfg.write_text("# empty config\n")

        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=str(empty_cfg),
            repeatable=True,
        ) as d2:
            py_results = d2.classify_file(sample_obs_path)

        self._compare_results(cli_results, py_results, tolerance=0)

    def test_sample_xml_scores_match(self, digest2_dir, model_path,
                                      obscodes_path, sample_xml_path,
                                      cli_config_path):
        """C CLI and Python API produce near-identical scores for sample.xml.

        ADES XML is parsed by libxml2 in the CLI and by Python's xml.etree
        in the Python API. Minor floating-point differences in RMS handling
        can cause +-1 at rounding boundaries, so we allow tolerance=1.
        """
        data_dir = digest2_dir / "digest2"

        # Run C CLI
        cli_results = _run_cli(data_dir, cli_config_path, "sample.xml")
        assert len(cli_results) >= 1

        # Run Python API
        empty_cfg = Path(cli_config_path).parent / "empty.config"
        empty_cfg.write_text("# empty config\n")

        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=str(empty_cfg),
            repeatable=True,
        ) as d2:
            py_results = d2.classify_file(sample_xml_path)

        self._compare_results(cli_results, py_results, tolerance=1)


class TestParallelScoring:
    """Test that parallel scoring produces identical results to sequential."""

    def test_classify_file_parallel_matches_sequential(
        self, model_path, obscodes_path, sample_obs_path, empty_config_path
    ):
        """Parallel and sequential classify_file produce the same results."""
        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            seq_results = d2.classify_file(sample_obs_path, max_workers=1)
            par_results = d2.classify_file(sample_obs_path, max_workers=4)

        assert len(seq_results) == len(par_results)
        for sr, pr in zip(seq_results, par_results):
            assert sr.designation == pr.designation
            assert sr.rms == pr.rms
            for cls in ALL_CLASSES:
                assert sr.noid[cls] == pr.noid[cls], \
                    f"Mismatch for {sr.designation} class {cls}: " \
                    f"seq={sr.noid[cls]} par={pr.noid[cls]}"

    def test_classify_batch_parallel_matches_sequential(
        self, model_path, obscodes_path, empty_config_path
    ):
        """Parallel and sequential classify_batch produce the same results."""
        obs1 = [
            Observation(mjd=59938.384965, ra=128.15118, dec=17.17665,
                        mag=22.22, obscode="G96"),
            Observation(mjd=59938.395273, ra=128.14899, dec=17.17702,
                        mag=21.96, obscode="G96"),
        ]
        obs2 = [
            Observation(mjd=59938.384965, ra=130.0, dec=20.0,
                        mag=20.0, obscode="G96"),
            Observation(mjd=59938.395273, ra=130.01, dec=20.01,
                        mag=20.0, obscode="G96"),
        ]
        obs3 = [
            Observation(mjd=59938.384965, ra=125.0, dec=15.0,
                        mag=19.5, obscode="G96"),
            Observation(mjd=59938.395273, ra=125.02, dec=15.01,
                        mag=19.5, obscode="G96"),
        ]

        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            seq_results = d2.classify_batch(
                [obs1, obs2, obs3], max_workers=1,
            )
            par_results = d2.classify_batch(
                [obs1, obs2, obs3], max_workers=3,
            )

        assert len(seq_results) == len(par_results)
        for sr, pr in zip(seq_results, par_results):
            if sr is None:
                assert pr is None
                continue
            for cls in ALL_CLASSES:
                assert sr.noid[cls] == pr.noid[cls], \
                    f"Mismatch for class {cls}: seq={sr.noid[cls]} par={pr.noid[cls]}"

    def test_classify_file_parallel_with_class_filter(
        self, model_path, obscodes_path, sample_obs_path, empty_config_path
    ):
        """Parallel scoring with a class filter produces correct results."""
        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            seq_results = d2.classify_file(
                sample_obs_path, classes=["NEO", "MB1"], max_workers=1,
            )
            par_results = d2.classify_file(
                sample_obs_path, classes=["NEO", "MB1"], max_workers=4,
            )

        assert len(seq_results) == len(par_results)
        for sr, pr in zip(seq_results, par_results):
            assert sr.noid.NEO == pr.noid.NEO
            assert sr.noid.MB1 == pr.noid.MB1


class TestClassifyBatchIsAdes:
    """Test that classify_batch with is_ades=True matches classify_file on XML."""

    def test_classify_batch_is_ades_matches_classify_file(
        self, model_path, obscodes_path, sample_xml_path, empty_config_path
    ):
        """Pre-parsed ADES observations scored via classify_batch(is_ades=True)
        should produce the same scores as classify_file on the same XML."""
        # Parse the XML file into observation lists
        tracklets_dict = parse_ades_xml(sample_xml_path)
        designations = list(tracklets_dict.keys())
        obs_lists = [tracklets_dict[d] for d in designations]

        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            file_results = d2.classify_file(sample_xml_path)
            batch_results = d2.classify_batch(obs_lists, is_ades=True)

        # Build lookup from file results by designation
        file_by_desig = {r.designation.strip(): r for r in file_results}

        assert len(batch_results) == len(designations)
        for desig, br in zip(designations, batch_results):
            fr = file_by_desig.get(desig.strip())
            assert fr is not None, f"Designation {desig} not in classify_file results"
            assert br is not None, f"classify_batch returned None for {desig}"
            for cls in ALL_CLASSES:
                assert fr.noid[cls] == br.noid[cls], \
                    f"Mismatch for {desig} class {cls}: " \
                    f"file={fr.noid[cls]} batch={br.noid[cls]}"

    def test_classify_batch_is_ades_matches_classify_file_psv(
        self, model_path, obscodes_path, sample_psv_path, empty_config_path
    ):
        """Pre-parsed PSV observations scored via classify_batch(is_ades=True)
        should produce the same scores as classify_file on the same PSV file."""
        tracklets_dict = parse_ades_psv(sample_psv_path)
        designations = list(tracklets_dict.keys())
        obs_lists = [tracklets_dict[d] for d in designations]

        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            file_results = d2.classify_file(sample_psv_path)
            batch_results = d2.classify_batch(obs_lists, is_ades=True)

        # Build lookup from file results by designation
        file_by_desig = {r.designation.strip(): r for r in file_results}

        assert len(batch_results) == len(designations)
        for desig, br in zip(designations, batch_results):
            fr = file_by_desig.get(desig.strip())
            assert fr is not None, f"Designation {desig} not in classify_file results"
            assert br is not None, f"classify_batch returned None for {desig}"
            for cls in ALL_CLASSES:
                assert fr.noid[cls] == br.noid[cls], \
                    f"Mismatch for {desig} class {cls}: " \
                    f"file={fr.noid[cls]} batch={br.noid[cls]}"

    def test_classify_batch_is_ades_false_differs(
        self, model_path, obscodes_path, sample_xml_path, empty_config_path
    ):
        """classify_batch without is_ades=True may produce different scores
        for ADES observations (verifies the flag has an effect)."""
        tracklets_dict = parse_ades_xml(sample_xml_path)
        obs_lists = list(tracklets_dict.values())

        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            ades_results = d2.classify_batch(obs_lists, is_ades=True)
            non_ades_results = d2.classify_batch(obs_lists, is_ades=False)

        # At least some scores should differ (RMS handling changes results)
        any_differ = False
        for ar, nr in zip(ades_results, non_ades_results):
            if ar is None or nr is None:
                continue
            if ar.noid.NEO != nr.noid.NEO:
                any_differ = True
                break
        # This is a soft check — if all scores happen to match, that's
        # technically possible but unlikely for real ADES data with rms values.
        # We don't assert here to avoid fragile tests.


class TestBinaryModelLoading:
    """Test that digest2 can load binary model files."""

    def test_init_with_binary_model(self, model_path, obscodes_path,
                                     empty_config_path):
        """Initialize with CSV, verify binary cache is created, then init with binary."""
        # First init with CSV to generate binary cache
        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
        ) as d2:
            pass

        # The binary model should be alongside the CSV (without .csv extension)
        binary_path = model_path.replace(".csv", "")
        if not Path(binary_path).is_file():
            pytest.skip("Binary model cache was not created (write permission issue?)")

        # Now init with the binary path directly
        with Digest2(
            model_path=binary_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
        ) as d2:
            pass  # Should succeed without error

    def test_binary_model_scores_match_csv(self, model_path, obscodes_path,
                                            empty_config_path):
        """Scores from binary model should match scores from CSV model."""
        binary_path = model_path.replace(".csv", "")

        obs = [
            Observation(mjd=59938.384965, ra=128.15118, dec=17.17665,
                        mag=22.22, band="G", obscode="G96"),
            Observation(mjd=59938.395273, ra=128.14899, dec=17.17702,
                        mag=21.96, band="G", obscode="G96"),
            Observation(mjd=59938.400402, ra=128.14780, dec=17.17717,
                        mag=21.55, band="G", obscode="G96"),
        ]

        # Score with CSV model
        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            csv_result = d2.classify_tracklet(obs)

        if not Path(binary_path).is_file():
            pytest.skip("Binary model cache was not created")

        # Score with binary model
        with Digest2(
            model_path=binary_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=True,
        ) as d2:
            bin_result = d2.classify_tracklet(obs)

        # Scores should be identical
        for cls in ALL_CLASSES:
            assert csv_result.noid[cls] == bin_result.noid[cls], \
                f"Score mismatch for class {cls}: CSV={csv_result.noid[cls]} binary={bin_result.noid[cls]}"
        assert csv_result.rms == bin_result.rms


class TestParallelNonRepeatable:
    """Test parallel scoring with repeatable=False (stochastic mode).

    These tests exercise the thread-safe RNG path to verify no crashes
    or data corruption when multiple threads call rand_r() concurrently.
    Scores are stochastic so we check structure and bounds, not exact values.
    """

    def test_classify_file_parallel_non_repeatable(
        self, model_path, obscodes_path, sample_obs_path, empty_config_path
    ):
        """Parallel classify_file with repeatable=False produces valid results."""
        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=False,
        ) as d2:
            results = d2.classify_file(sample_obs_path, max_workers=4)

        assert len(results) >= 1
        for r in results:
            assert isinstance(r, ClassificationResult)
            assert r.rms >= 0
            for cls in ALL_CLASSES:
                assert -0.01 <= r.noid[cls] <= 100.01, \
                    f"Score out of range for {cls}: {r.noid[cls]}"

    def test_classify_batch_parallel_non_repeatable(
        self, model_path, obscodes_path, empty_config_path
    ):
        """Parallel classify_batch with repeatable=False produces valid results."""
        tracklets = [
            [
                Observation(mjd=59938.384965, ra=128.15118, dec=17.17665,
                            mag=22.22, obscode="G96"),
                Observation(mjd=59938.395273, ra=128.14899, dec=17.17702,
                            mag=21.96, obscode="G96"),
                Observation(mjd=59938.400402, ra=128.14780, dec=17.17717,
                            mag=21.55, obscode="G96"),
            ],
            [
                Observation(mjd=59938.384965, ra=130.0, dec=20.0,
                            mag=20.0, obscode="G96"),
                Observation(mjd=59938.395273, ra=130.01, dec=20.01,
                            mag=20.0, obscode="G96"),
            ],
            [
                Observation(mjd=59938.384965, ra=125.0, dec=15.0,
                            mag=19.5, obscode="G96"),
                Observation(mjd=59938.395273, ra=125.02, dec=15.01,
                            mag=19.5, obscode="G96"),
            ],
            [
                Observation(mjd=59938.384965, ra=135.0, dec=25.0,
                            mag=21.0, obscode="G96"),
                Observation(mjd=59938.395273, ra=135.005, dec=25.005,
                            mag=21.0, obscode="G96"),
            ],
        ]

        with Digest2(
            model_path=model_path,
            obscodes_path=obscodes_path,
            config_path=empty_config_path,
            repeatable=False,
        ) as d2:
            results = d2.classify_batch(tracklets, max_workers=4)

        assert len(results) == 4
        for r in results:
            assert r is not None
            assert isinstance(r, ClassificationResult)
            assert r.rms >= 0
            for cls in ALL_CLASSES:
                assert -0.01 <= r.noid[cls] <= 100.01, \
                    f"Score out of range for {cls}: {r.noid[cls]}"
