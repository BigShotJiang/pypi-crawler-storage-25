"""Core evaluation engine package."""
