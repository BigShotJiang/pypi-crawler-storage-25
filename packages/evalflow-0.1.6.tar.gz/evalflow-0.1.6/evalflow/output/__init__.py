"""Terminal output helpers."""
