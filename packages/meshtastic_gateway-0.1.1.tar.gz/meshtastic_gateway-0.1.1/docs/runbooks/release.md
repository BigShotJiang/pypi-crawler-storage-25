# Cutting a release

Releases are driven manually from a local clone using the
`codeberg.org/b4mad/semantic-release` container. Codeberg Actions CI
runs tests and lints, but does **not** cut releases — see § Why local,
below.

## Prerequisites

One-time setup on your workstation:

- Podman installed.
- GPG keys for commit signing, mounted at
  `/home/goern/Source/github.com/operate-first/op1st-emea-b4mad/tmp.d/codeberg.org`
  (adjust path to your own).
- SSH keys authorized to push to `codeberg.org/goern/meshtastic-gateway`,
  mounted at
  `/home/goern/Source/github.com/operate-first/op1st-emea-b4mad/manifests/applications/b4mad-renovate/dot-ssh/`.
- A PyPI API token with scope `Project: meshtastic-gateway`, available
  in your shell as `$PYPI_TOKEN` (do not commit it).

## The one command

From a clean clone with the commits you want to release on `main`:

```bash
cd ~/work/meshtastic-gateway
git pull --rebase
podman run --rm -ti \
  --userns=keep-id:uid=1001,gid=0 \
  -e PYPI_TOKEN="$PYPI_TOKEN" \
  -v "$(pwd)":/workspace:Z \
  -v /home/goern/Source/github.com/operate-first/op1st-emea-b4mad/tmp.d/codeberg.org:/opt/app-root/src/.gnupg:Z \
  -v /home/goern/Source/github.com/operate-first/op1st-emea-b4mad/manifests/applications/b4mad-renovate/dot-ssh/:/opt/app-root/src/.ssh:Z \
  codeberg.org/b4mad/semantic-release:v1.5.3 \
  --debug --no-ci
```

Key flags:

- `-e PYPI_TOKEN=…` — forwarded into the container so the
  `@semantic-release/exec` step can run `uv publish --token $PYPI_TOKEN`.
- `--no-ci` — semantic-release would otherwise refuse to run outside a
  CI environment.
- `--debug` — prints the plugin pipeline, useful if the run aborts.

## What semantic-release does

Driven by `.releaserc`:

1. Reads commits since the last git tag on `main`.
2. Decides next version from conventional-commit types (feat → minor,
   fix/chore/refactor/ci/etc → patch, `!` or `BREAKING CHANGE` → major).
3. Updates `pyproject.toml` (`version = "X.Y.Z"`) via
   `semantic-release-replace-plugin`.
4. Writes/updates `CHANGELOG.md`.
5. Runs `uv build && uv publish --token $PYPI_TOKEN` via
   `@semantic-release/exec`.
6. Commits `CHANGELOG.md`, `pyproject.toml`, `uv.lock` as
   `chore(release): X.Y.Z`.
7. Pushes the commit and the new `vX.Y.Z` tag to `origin/main`.
8. Creates a Forgejo release on Codeberg.

If any step fails, semantic-release rolls back and exits non-zero. Nothing
partial is committed or published.

## Verifying the release

After the podman run exits cleanly:

```bash
git pull                                   # fetch the chore(release) commit + tag
curl -sf https://pypi.org/pypi/meshtastic-gateway/json | jq .info.version
```

The version field should equal the just-released version. The Forgejo
release should show up at
`https://codeberg.org/goern/meshtastic-gateway/releases`.

Smoke-test the published wheel on a throwaway venv:

```bash
python -m venv /tmp/mg-verify
/tmp/mg-verify/bin/pip install meshtastic-gateway
/tmp/mg-verify/bin/meshtastic-gateway --help
/tmp/mg-verify/bin/mesh-send --help
```

Both CLIs should print help at the new version.

## Why local, not Codeberg Actions

Earlier, we attempted a `.forgejo/workflows/release.yml` that ran the
same semantic-release pipeline on a Codeberg runner. It failed at
`actions/checkout@v4` (0 s) because the `RELEASE_TOKEN` we configured
didn't satisfy the action's `token:` parameter format on Codeberg's
Forgejo runner, and log access from outside the web UI is limited.

Rather than debug remote runner idiosyncrasies, we ship from a
container where the GPG + SSH auth is already configured and
reproducible. Codeberg CI still gates correctness (tests, lints,
coverage ≥ 60%) — release automation is just decoupled from it.

If you want to revisit Codeberg-side releases later, the `.releaserc`
config is already correct — only the workflow file needs to come back,
and the token handshake fixed.
