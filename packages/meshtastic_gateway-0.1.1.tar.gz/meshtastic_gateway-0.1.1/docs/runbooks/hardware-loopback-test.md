# Hardware loopback smoke test

Manual checklist to exercise a real Meshtastic device + the gateway end
to end. Not run by CI; run it before cutting a release when changes
touch `gateway.py`, `mqtt_bridge.py`, or the serial-IO path.

## Prerequisites

- A Meshtastic device with firmware ≥ 2.3 tethered over USB.
- `meshtastic-gateway` installed in a venv.
- `udev` rule so the device appears at a stable path (e.g. `/dev/meshtastic0`).
- `mqtt.meshtastic.org` or another broker reachable from the test host.

## Steps

1. Plug in the device; wait for the firmware boot beep/LED.
2. Configure the device's MQTT module via `meshtastic --configure
   config.yaml` so `proxy_to_client_enabled=true` and broker details
   are set.
3. Start the gateway:

   ```bash
   meshtastic-gateway /dev/meshtastic0 --port 9464 --allow-net 127.0.0.1/32
   ```

   Wait until the log prints `Gateway running on :9464`.
4. Check metrics:

   ```bash
   curl -sf http://127.0.0.1:9464/metrics | grep meshtastic_device_uptime_seconds
   ```

   **Expected:** non-zero value within 15 s of the first telemetry
   packet from the device (may take up to 60 s on a fresh boot).
5. Send a test message:

   ```bash
   mesh-send --gateway http://127.0.0.1:9464 "loopback smoke test $(date -Iseconds)"
   ```

   **Expected:** CLI prints `Sent to ^all: loopback smoke test ...`;
   the device's TX LED blinks.
6. Verify the broker received the publish:

   ```bash
   mosquitto_sub -h mqtt.meshtastic.org -u meshdev -P large4cats -t 'msh/#' -v | head -5
   ```

   **Expected:** messages appear (may take a few seconds after the
   `mesh-send` call).
7. Confirm the TX counter incremented:

   ```bash
   curl -sf http://127.0.0.1:9464/metrics | grep 'meshtastic_lora_tx_packets_total{portnum="TEXT_MESSAGE_APP"}'
   ```

   **Expected:** value has incremented by 1 relative to the pre-send
   reading.
8. Confirm `mqtt_connected`:

   ```bash
   curl -sf http://127.0.0.1:9464/metrics | grep '^meshtastic_mqtt_connected '
   ```

   **Expected:** value is `1.0`.

## Rollback / cleanup

`Ctrl-C` the gateway. No persistent state — nothing to clean up.
