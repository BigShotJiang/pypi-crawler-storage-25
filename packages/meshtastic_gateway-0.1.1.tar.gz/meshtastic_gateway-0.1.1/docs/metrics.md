# Prometheus metrics

The gateway exposes metrics at `GET /metrics` in the standard Prometheus
text format. All metrics are prefixed with `meshtastic_`.

## MQTT bridge

| Metric | Type | Description |
|---|---|---|
| `meshtastic_mqtt_connected` | gauge | 1 when broker connection is active, 0 otherwise |
| `meshtastic_mqtt_uplink_packets_total` | counter | Packets published device → broker |
| `meshtastic_mqtt_uplink_bytes_total` | counter | Bytes published device → broker |
| `meshtastic_mqtt_downlink_packets_total` | counter | Packets received broker → device |
| `meshtastic_mqtt_downlink_bytes_total` | counter | Bytes received broker → device |

## LoRa radio

| Metric | Type | Labels | Description |
|---|---|---|---|
| `meshtastic_lora_rx_packets_total` | counter | `portnum` | Packets received over LoRa from other nodes |
| `meshtastic_lora_tx_packets_total` | counter | `portnum` | Packets transmitted over LoRa by this node |
| `meshtastic_lora_nodes_in_mesh` | gauge | — | Number of nodes known to the device |

`portnum` values are the Meshtastic app identifiers — common ones include
`TEXT_MESSAGE_APP`, `POSITION_APP`, `TELEMETRY_APP`, `NODEINFO_APP`.

## Device telemetry

These reflect the most recent `TELEMETRY_APP` packet from the local node.

| Metric | Unit |
|---|---|
| `meshtastic_device_battery_level_percent` | 0–100 |
| `meshtastic_device_voltage_volts` | volts |
| `meshtastic_device_air_util_tx_percent` | 0–100, EU 868 duty-cycle budget used |
| `meshtastic_device_channel_utilization_percent` | 0–100, local RF channel utilization |
| `meshtastic_device_uptime_seconds` | seconds since last reboot |

## Device position

Updated from the most recent `POSITION_APP` packet from the local node or
from the initial `nodes` snapshot at startup.

| Metric | Unit |
|---|---|
| `meshtastic_device_latitude_degrees` | decimal degrees |
| `meshtastic_device_longitude_degrees` | decimal degrees |
| `meshtastic_device_altitude_meters` | meters above sea level |

## HTTP API

| Metric | Type | Labels | Description |
|---|---|---|---|
| `meshtastic_gateway_send_requests_total` | counter | `status` | Messages sent via `POST /send`, labeled `ok` or `error` |

## Static metadata

`meshtastic_gateway_info` exposes a constant-1 metric with labels
`node_id`, `broker`, `root`, `firmware` — useful for joining against
identity in dashboards.
