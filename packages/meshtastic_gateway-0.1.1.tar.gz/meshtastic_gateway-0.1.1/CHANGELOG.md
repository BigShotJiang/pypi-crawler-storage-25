## [0.1.1](https://codeberg.org/goern/meshtastic-gateway/compare/v0.1.0...v0.1.1) (2026-04-19)

### :bug: Fixes

* 🔧 correct python version strings in tool config ([f079961](https://codeberg.org/goern/meshtastic-gateway/commit/f079961c8b6331524c1821c5827a6b0b4e797b63))

### :repeat: Chore

* 🧹 slim CLAUDE.md to pointer at AGENTS.md ([f8ccd56](https://codeberg.org/goern/meshtastic-gateway/commit/f8ccd563dfaa43a3ec3ae2ea4c91068af2fa2ad9))

## [0.1.0](https://codeberg.org/goern/meshtastic-gateway/compare/v0.0.1...v0.1.0) (2026-04-19)

### :sparkles: Features

* ⚙️  Gateway orchestrator wiring iface + MqttBridge + HTTP ([a400f08](https://codeberg.org/goern/meshtastic-gateway/commit/a400f086709454de9356a75c09a71ef9aff3f753))
* 🌉 MqttBridge class wrapping paho client ([e5078c2](https://codeberg.org/goern/meshtastic-gateway/commit/e5078c299ed68778e97c9ad7a92852d6adb5ad13))
* 🌐 http_api module with /metrics, /send, IP allow-list ([8cf193b](https://codeberg.org/goern/meshtastic-gateway/commit/8cf193b43c4ceae628b55762be6919d828c5c57d))
* 📊 metrics module with prometheus_client definitions ([ef15243](https://codeberg.org/goern/meshtastic-gateway/commit/ef15243cd826e087446c6160179ac736b9f9b0f4))
* 📡 telemetry module for packet→metric updates ([ba64165](https://codeberg.org/goern/meshtastic-gateway/commit/ba641654528ce9c3610d0c65fbf85a787578f6d4))
* 🖥️  CLI entry points for daemon and mesh-send client ([35df3e5](https://codeberg.org/goern/meshtastic-gateway/commit/35df3e5ab86e6af2be2a4f829d696cd70a6d52bc))

### :memo: Documentation

* 📊 metrics reference and hardware loopback runbook ([988785b](https://codeberg.org/goern/meshtastic-gateway/commit/988785b6b2b894f47a08b8c7a9254dab4e87afbe))

### :repeat: CI

* ✅ bump coverage threshold to 60% now that modules are tested ([4cfb94f](https://codeberg.org/goern/meshtastic-gateway/commit/4cfb94faa866685ef9aac5b8b2e133395d8ee681))
* 🐍 add setup-python before uv for pre-commit hook bootstrapping ([847a847](https://codeberg.org/goern/meshtastic-gateway/commit/847a847ff27b0e0f0437fe6371f9554757901f25))
* 🔧 switch releases to local podman, delete release.yml ([9cfb397](https://codeberg.org/goern/meshtastic-gateway/commit/9cfb397f8defc074ecf2661fc43fcfc0e5a62def)), closes [#8](https://codeberg.org/goern/meshtastic-gateway/issues/8)
* 🚀 release workflow — semantic-release + uv publish ([8051ae7](https://codeberg.org/goern/meshtastic-gateway/commit/8051ae797ad2292a8a00591c379ab4a2fbdf7b73))
* 🚀 semantic-release config (.releaserc) ([09664c4](https://codeberg.org/goern/meshtastic-gateway/commit/09664c4e92054396d84c56c99acab9b3b383f390))
