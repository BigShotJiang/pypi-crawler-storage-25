"""MQTT bridge between the Meshtastic device (via pubsub) and a real broker."""

from __future__ import annotations

import logging
from typing import Any

from . import metrics

log = logging.getLogger(__name__)


class MqttBridge:
    """Wraps a paho.mqtt.Client and forwards packets in both directions."""

    def __init__(self, client: Any, iface: Any, node_hex: str):
        self._client = client
        self._iface = iface
        self._node_hex = node_hex

    def connect(self, address: str, port: int, username: str, password: str, tls: bool) -> None:
        self._client.username_pw_set(username, password)
        if tls:
            self._client.tls_set()
        self._client.connect(address, port)

    def subscribe_topics(self, channels: Any, root: str) -> list[str]:
        """Derive the MQTT topic list from the device's channel config.

        Returns one `/+` wildcard topic per (encrypted, clear) x (downlink-enabled channel),
        plus the PKC topic for this node.
        """
        topics: list[str] = []
        for ch in channels or []:
            if ch.settings and ch.settings.downlink_enabled:
                ch_name = ch.settings.name or "LongFast"
                for enc in ("e", "c"):
                    topics.append(f"{root}/2/{enc}/{ch_name}/+")
        topics.append(f"{root}/2/e/PKC/{self._node_hex}")
        return topics

    def on_message(self, client: Any, userdata: Any, msg: Any) -> None:
        """MQTT downlink: broker → device. Filters self-echoes."""
        if msg.topic.endswith(f"/{self._node_hex}"):
            return
        log.info("MQTT rx: %s (%d bytes)", msg.topic, len(msg.payload))
        metrics.downlink_packets.inc()
        metrics.downlink_bytes.inc(len(msg.payload))
        self._iface.sendMqttClientProxyMessage(msg.topic, msg.payload)

    def publish_proxy(self, proxy_message: Any) -> None:
        """MQTT uplink: device → broker. Called via pubsub callback."""
        log.info("Device tx: %s (%d bytes)", proxy_message.topic, len(proxy_message.data))
        metrics.uplink_packets.inc()
        metrics.uplink_bytes.inc(len(proxy_message.data))
        self._client.publish(
            proxy_message.topic,
            proxy_message.data,
            retain=proxy_message.retained,
        )
