"""HTTP API: Prometheus /metrics, /send LoRa message, IP allow-list ACL."""

from __future__ import annotations

import ipaddress
import json
import logging
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler
from typing import Any
from urllib.parse import parse_qs

from prometheus_client import generate_latest

from . import metrics

log = logging.getLogger(__name__)

SEND_FORM = """\
<!DOCTYPE html>
<html><head><title>Meshtastic Gateway</title></head><body>
<h2>Send LoRa Message</h2>
<form method="POST" action="/send">
<p><label>Message: <input name="text" size="40" autofocus></label></p>
<p><label>To (blank=broadcast): <input name="to" size="12" placeholder="!abcdef12"></label></p>
<p><label>Channel: <input name="channel" type="number" value="0" size="3"></label></p>
<p><button type="submit">Send</button></p>
</form></body></html>
"""


def make_handler(iface: Any, allowed_nets: list) -> type[BaseHTTPRequestHandler]:
    """Build a handler class closing over iface + allow-list. No module globals."""

    class GatewayHandler(BaseHTTPRequestHandler):
        @classmethod
        def _acl_ok(cls, client_ip: ipaddress.IPv4Address | ipaddress.IPv6Address) -> bool:
            """Pure predicate — reusable in unit tests without a live request."""
            if not allowed_nets:
                return True
            return any(client_ip in net for net in allowed_nets)

        def _check_acl(self) -> bool:
            try:
                client_ip = ipaddress.ip_address(self.client_address[0])
            except ValueError:
                self.send_error(HTTPStatus.FORBIDDEN)
                return False
            if self._acl_ok(client_ip):
                return True
            self.send_error(HTTPStatus.FORBIDDEN)
            return False

        def do_GET(self) -> None:
            if not self._check_acl():
                return
            if self.path == "/metrics":
                data = generate_latest()
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
                self.end_headers()
                self.wfile.write(data)
            elif self.path == "/send":
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", "text/html")
                self.end_headers()
                self.wfile.write(SEND_FORM.encode())
            else:
                self.send_error(HTTPStatus.NOT_FOUND)

        def do_POST(self) -> None:
            if not self._check_acl():
                return
            if self.path != "/send":
                self.send_error(HTTPStatus.NOT_FOUND)
                return

            content_len = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(content_len)
            content_type = self.headers.get("Content-Type", "")

            if "application/json" in content_type:
                try:
                    params = json.loads(body)
                except json.JSONDecodeError as e:
                    self._json_response(HTTPStatus.BAD_REQUEST, {"error": f"invalid JSON: {e}"})
                    return
            elif "application/x-www-form-urlencoded" in content_type:
                parsed = parse_qs(body.decode())
                params = {k: v[0] for k, v in parsed.items()}
            else:
                self._json_response(
                    HTTPStatus.BAD_REQUEST,
                    {
                        "error": "Content-Type must be application/json "
                        "or application/x-www-form-urlencoded"
                    },
                )
                return

            text = (params.get("text") or "").strip()
            if not text:
                self._json_response(HTTPStatus.BAD_REQUEST, {"error": "missing 'text' field"})
                return

            dest = (params.get("to") or "^all").strip() or "^all"
            channel = int(params.get("channel", 0))

            try:
                log.info("API send: %r to=%s ch=%d", text, dest, channel)
                iface.sendText(text, destinationId=dest, channelIndex=channel)
                metrics.send_requests.labels(status="ok").inc()
                self._json_response(
                    HTTPStatus.OK,
                    {"status": "sent", "text": text, "to": dest, "channel": channel},
                )
            except Exception as e:
                log.error("Send failed: %s", e)
                metrics.send_requests.labels(status="error").inc()
                self._json_response(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(e)})

        def _json_response(self, code: int, obj: dict) -> None:
            data = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.end_headers()
            self.wfile.write(data)

        def log_message(self, format: str, *args: Any) -> None:
            # Silence the default stderr request log; we use our own logger.
            pass

    return GatewayHandler
