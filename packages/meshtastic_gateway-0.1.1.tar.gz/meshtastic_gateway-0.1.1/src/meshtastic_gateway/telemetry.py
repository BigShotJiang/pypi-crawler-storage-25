"""Pure functions that translate mesh packets into metric updates."""

from __future__ import annotations

from . import metrics


def update_from_mesh_packet(packet: dict, node_hex: str) -> None:
    """Update counters and gauges based on a received mesh packet."""
    decoded = packet.get("decoded", {})
    portnum = decoded.get("portnum", "UNKNOWN")
    from_id = packet.get("fromId", "")

    if from_id == node_hex:
        metrics.lora_tx_packets.labels(portnum=portnum).inc()
    else:
        metrics.lora_rx_packets.labels(portnum=portnum).inc()

    if portnum == "POSITION_APP" and from_id == node_hex:
        pos = decoded.get("position", {})
        if "latitude" in pos:
            metrics.device_latitude.set(pos["latitude"])
        if "longitude" in pos:
            metrics.device_longitude.set(pos["longitude"])
        if "altitude" in pos:
            metrics.device_altitude.set(pos["altitude"])

    if portnum == "TELEMETRY_APP" and from_id == node_hex:
        dm = decoded.get("telemetry", {}).get("deviceMetrics", {})
        if "batteryLevel" in dm:
            metrics.device_battery_level.set(dm["batteryLevel"])
        if "voltage" in dm:
            metrics.device_voltage.set(dm["voltage"])
        if "airUtilTx" in dm:
            metrics.device_air_util_tx.set(dm["airUtilTx"])
        if "channelUtilization" in dm:
            metrics.device_channel_utilization.set(dm["channelUtilization"])
        if "uptimeSeconds" in dm:
            metrics.device_uptime.set(dm["uptimeSeconds"])


def update_from_node_position(node: dict) -> None:
    """Update position gauges from a `nodes[node_hex]` entry."""
    pos = node.get("position", {})
    if "latitude" in pos:
        metrics.device_latitude.set(pos["latitude"])
    if "longitude" in pos:
        metrics.device_longitude.set(pos["longitude"])
    if "altitude" in pos:
        metrics.device_altitude.set(pos["altitude"])


def update_nodes_in_mesh(count: int) -> None:
    """Set the nodes-in-mesh gauge."""
    metrics.lora_nodes_in_mesh.set(count)
