"""CLI entry points for the meshtastic-gateway package."""

from __future__ import annotations

import argparse
import json
import os
import sys
import urllib.request

DEFAULT_DEV_PATH = "/dev/meshtastic0"
DEFAULT_PORT = 9464
DEFAULT_GATEWAY_ENV = "MESHTASTIC_GATEWAY"
DEFAULT_GATEWAY = "http://rpi5:9464"


def _parse_main_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="meshtastic-gateway",
        description="Meshtastic Gateway: MQTT bridge + Prometheus metrics + HTTP send API",
    )
    parser.add_argument("dev_path", nargs="?", default=DEFAULT_DEV_PATH)
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    parser.add_argument(
        "--allow-net",
        action="append",
        default=[],
        help="CIDR network allowed to access the HTTP API (repeatable)",
    )
    return parser.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    # Lazy import: gateway.py arrives in T13; keep this import out of module-load
    # time so tests that only exercise arg parsing don't require Gateway.
    from .gateway import Gateway

    args = _parse_main_args(argv if argv is not None else sys.argv[1:])
    gateway = Gateway(
        dev_path=args.dev_path,
        port=args.port,
        allow_nets=args.allow_net,
    )
    return gateway.run()


def _parse_mesh_send_args(argv: list[str]) -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        prog="mesh-send",
        description="Send a LoRa message via the Meshtastic Gateway HTTP API",
    )
    parser.add_argument(
        "--to", default="", help="destination node (e.g. !abcdef12); blank=broadcast"
    )
    parser.add_argument("--ch", type=int, default=0, help="channel index (default 0)")
    parser.add_argument(
        "--gateway",
        default=os.environ.get(DEFAULT_GATEWAY_ENV, DEFAULT_GATEWAY),
        help=f"gateway base URL (default ${DEFAULT_GATEWAY_ENV} or {DEFAULT_GATEWAY})",
    )
    parser.add_argument("message", nargs="+", help="message text")
    return parser.parse_args(argv)


def mesh_send_main(argv: list[str] | None = None) -> int:
    args = _parse_mesh_send_args(argv if argv is not None else sys.argv[1:])
    payload: dict = {"text": " ".join(args.message), "channel": args.ch}
    if args.to:
        payload["to"] = args.to

    req = urllib.request.Request(
        f"{args.gateway}/send",
        data=json.dumps(payload).encode(),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req) as resp:
            result = json.loads(resp.read())
            print(f"Sent to {result.get('to')}: {result.get('text')}")
            return 0
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
