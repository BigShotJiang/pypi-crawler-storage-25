"""Gateway orchestrator: opens SerialInterface, wires MqttBridge + HTTP server."""

from __future__ import annotations

import ipaddress
import logging
import threading
import time
from http.server import ThreadingHTTPServer

import paho.mqtt.client as mqtt_client

from . import metrics, telemetry
from .http_api import make_handler
from .mqtt_bridge import MqttBridge

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("meshtastic_gateway")


class Gateway:
    def __init__(self, dev_path: str, port: int, allow_nets: list[str]):
        self._dev_path = dev_path
        self._port = port
        self._allow_nets = [ipaddress.ip_network(n) for n in allow_nets] if allow_nets else []
        if not self._allow_nets:
            log.warning("No --allow-net specified, accepting connections from any IP")
        else:
            log.info("IP allow-list: %s", [str(n) for n in self._allow_nets])

    def run(self) -> int:
        import meshtastic.serial_interface
        from pubsub import pub

        log.info("Connecting to device on %s", self._dev_path)
        iface = meshtastic.serial_interface.SerialInterface(devPath=self._dev_path)
        node_hex = f"!{iface.myInfo.my_node_num:08x}"

        cfg = iface.localNode.moduleConfig.mqtt
        address = cfg.address or "mqtt.meshtastic.org"
        username = cfg.username or "meshdev"
        password = cfg.password or "large4cats"
        root = cfg.root or "msh"
        mqtt_port = 8883 if cfg.tls_enabled else 1883

        metrics.set_gateway_info(
            iface=iface,
            node_hex=node_hex,
            broker=f"{address}:{mqtt_port}",
            root=root,
        )
        log.info("MQTT broker: %s:%d root=%s", address, mqtt_port, root)

        paho = mqtt_client.Client(
            callback_api_version=mqtt_client.CallbackAPIVersion.VERSION2,
            client_id=f"meshtastic-gw-{node_hex}",
        )
        bridge = MqttBridge(paho, iface, node_hex)

        subscribe_topics = bridge.subscribe_topics(iface.localNode.channels, root)
        log.info("Subscribing to: %s", subscribe_topics)

        def on_connect(client, userdata, flags, reason_code, properties):
            log.info("MQTT connected: %s", reason_code)
            metrics.mqtt_connected.set(1)
            for t in subscribe_topics:
                client.subscribe(t)
                log.info("Subscribed: %s", t)

        def on_disconnect(client, userdata, flags, reason_code, properties):
            log.warning("MQTT disconnected: %s", reason_code)
            metrics.mqtt_connected.set(0)

        paho.on_connect = on_connect
        paho.on_disconnect = on_disconnect
        paho.on_message = bridge.on_message

        pub.subscribe(
            lambda proxymessage, interface: bridge.publish_proxy(proxymessage),
            "meshtastic.mqttclientproxymessage",
        )

        if iface.nodes:
            telemetry.update_nodes_in_mesh(len(iface.nodes))
            my_node = iface.nodes.get(node_hex, {})
            telemetry.update_from_node_position(my_node)

        def on_mesh_packet(packet, interface):
            telemetry.update_from_mesh_packet(packet, node_hex)
            if interface.nodes:
                telemetry.update_nodes_in_mesh(len(interface.nodes))

        pub.subscribe(on_mesh_packet, "meshtastic.receive")

        bridge.connect(address, mqtt_port, username, password, cfg.tls_enabled)
        paho.loop_start()

        handler_cls = make_handler(iface, self._allow_nets)
        httpd = ThreadingHTTPServer(("0.0.0.0", self._port), handler_cls)
        http_thread = threading.Thread(target=httpd.serve_forever, daemon=True)
        http_thread.start()
        log.info("Gateway running on :%d — /metrics, /send", self._port)

        try:
            while True:
                time.sleep(60)
        except KeyboardInterrupt:
            log.info("Shutting down")
        finally:
            httpd.shutdown()
            paho.loop_stop()
            paho.disconnect()
            iface.close()

        return 0
