"""Prometheus metric definitions for the meshtastic-gateway."""

from __future__ import annotations

from typing import Any

from prometheus_client import Counter, Gauge, Info

# --- MQTT uplink/downlink counters ---

uplink_packets = Counter(
    "meshtastic_mqtt_uplink_packets",
    "Packets published from device to MQTT broker",
)
uplink_bytes = Counter(
    "meshtastic_mqtt_uplink_bytes",
    "Bytes published from device to MQTT broker",
)
downlink_packets = Counter(
    "meshtastic_mqtt_downlink_packets",
    "Packets received from MQTT broker and forwarded to device",
)
downlink_bytes = Counter(
    "meshtastic_mqtt_downlink_bytes",
    "Bytes received from MQTT broker and forwarded to device",
)
mqtt_connected = Gauge(
    "meshtastic_mqtt_connected",
    "Whether the MQTT broker connection is active (1=yes, 0=no)",
)

# --- Gateway identity ---

gateway_info = Info(
    "meshtastic_gateway",
    "Static metadata about this gateway instance",
)

# --- LoRa packet counters ---

lora_rx_packets = Counter(
    "meshtastic_lora_rx_packets",
    "Packets received over LoRa from other nodes",
    ["portnum"],
)
lora_tx_packets = Counter(
    "meshtastic_lora_tx_packets",
    "Packets transmitted over LoRa by this node",
    ["portnum"],
)
lora_nodes_in_mesh = Gauge(
    "meshtastic_lora_nodes_in_mesh",
    "Number of nodes known to the device",
)

# --- Device telemetry ---

device_battery_level = Gauge(
    "meshtastic_device_battery_level_percent",
    "Device battery level (0-100)",
)
device_voltage = Gauge(
    "meshtastic_device_voltage_volts",
    "Device battery voltage",
)
device_air_util_tx = Gauge(
    "meshtastic_device_air_util_tx_percent",
    "Percentage of EU 868 duty-cycle budget used by transmissions",
)
device_channel_utilization = Gauge(
    "meshtastic_device_channel_utilization_percent",
    "Local RF channel utilization",
)
device_uptime = Gauge(
    "meshtastic_device_uptime_seconds",
    "Device uptime since last reboot (drops to 0 on firmware crash)",
)

# --- Device position ---

device_latitude = Gauge(
    "meshtastic_device_latitude_degrees",
    "Device latitude in decimal degrees",
)
device_longitude = Gauge(
    "meshtastic_device_longitude_degrees",
    "Device longitude in decimal degrees",
)
device_altitude = Gauge(
    "meshtastic_device_altitude_meters",
    "Device altitude in meters above sea level",
)

# --- HTTP API ---

send_requests = Counter(
    "meshtastic_gateway_send_requests",
    "Messages sent via the HTTP API",
    ["status"],
)


def set_gateway_info(iface: Any, node_hex: str, broker: str, root: str) -> None:
    """Populate the gateway_info Info metric with static metadata."""
    firmware = "unknown"
    if iface.metadata is not None:
        firmware = iface.metadata.firmware_version
    gateway_info.info(
        {
            "node_id": node_hex,
            "broker": broker,
            "root": root,
            "firmware": firmware,
        }
    )
