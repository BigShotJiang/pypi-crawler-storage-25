# meshtastic-gateway

MQTT bridge, Prometheus metrics, and HTTP send API for USB-tethered
Meshtastic devices.

## Install

```bash
pip install meshtastic-gateway
```

## Usage

```bash
meshtastic-gateway /dev/meshtastic0 --port 9464 --allow-net 100.64.0.0/10
```

See [docs/metrics.md](docs/metrics.md) for the Prometheus metric reference
and [docs/runbooks/hardware-loopback-test.md](docs/runbooks/hardware-loopback-test.md)
for smoke testing on a real device.

## License

GPL-3.0-or-later. See [LICENSE](LICENSE).
