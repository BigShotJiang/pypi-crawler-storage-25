"""Tests for prometheus_client metric definitions."""

from unittest.mock import MagicMock

from meshtastic_gateway import metrics


def test_core_counters_exist():
    assert metrics.uplink_packets._name == "meshtastic_mqtt_uplink_packets"
    assert metrics.uplink_bytes._name == "meshtastic_mqtt_uplink_bytes"
    assert metrics.downlink_packets._name == "meshtastic_mqtt_downlink_packets"
    assert metrics.downlink_bytes._name == "meshtastic_mqtt_downlink_bytes"


def test_lora_counters_have_portnum_label():
    assert metrics.lora_rx_packets._labelnames == ("portnum",)
    assert metrics.lora_tx_packets._labelnames == ("portnum",)


def test_device_gauges_exist():
    for attr in (
        "device_battery_level",
        "device_voltage",
        "device_air_util_tx",
        "device_channel_utilization",
        "device_uptime",
        "device_latitude",
        "device_longitude",
        "device_altitude",
    ):
        assert hasattr(metrics, attr), f"missing gauge: {attr}"


def test_mqtt_connected_gauge_exists():
    assert metrics.mqtt_connected._name == "meshtastic_mqtt_connected"


def test_send_requests_counter_has_status_label():
    assert metrics.send_requests._labelnames == ("status",)


def test_set_gateway_info_populates_info_metric():
    iface = MagicMock()
    iface.metadata.firmware_version = "2.5.0"
    metrics.set_gateway_info(
        iface=iface,
        node_hex="!abcdef12",
        broker="mqtt.example.org:8883",
        root="msh",
    )
    labels = metrics.gateway_info._value
    assert labels["node_id"] == "!abcdef12"
    assert labels["broker"] == "mqtt.example.org:8883"
    assert labels["root"] == "msh"
    assert labels["firmware"] == "2.5.0"
