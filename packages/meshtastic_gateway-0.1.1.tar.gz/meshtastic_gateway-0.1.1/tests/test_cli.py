"""Tests for CLI argument parsing and mesh-send HTTP client."""

import json
from unittest.mock import MagicMock, patch

from meshtastic_gateway import cli


def test_parse_args_defaults():
    args = cli._parse_main_args([])
    assert args.dev_path == "/dev/meshtastic0"
    assert args.port == 9464
    assert args.allow_net == []


def test_parse_args_all_options():
    args = cli._parse_main_args(
        ["/dev/ttyACM0", "--port", "9999", "--allow-net", "10.0.0.0/8", "--allow-net", "fe80::/10"]
    )
    assert args.dev_path == "/dev/ttyACM0"
    assert args.port == 9999
    assert args.allow_net == ["10.0.0.0/8", "fe80::/10"]


def test_mesh_send_parses_message_and_to():
    args = cli._parse_mesh_send_args(["--to", "!abcdef12", "--ch", "1", "hello", "world"])
    assert args.message == ["hello", "world"]
    assert args.to == "!abcdef12"
    assert args.ch == 1


def test_mesh_send_uses_env_gateway_default(monkeypatch):
    monkeypatch.setenv("MESHTASTIC_GATEWAY", "http://myhost:9464")
    args = cli._parse_mesh_send_args(["hi"])
    assert args.gateway == "http://myhost:9464"


def test_mesh_send_main_posts_json_and_prints_result(capsys):
    fake_response = MagicMock()
    fake_response.__enter__.return_value.read.return_value = json.dumps(
        {"status": "sent", "text": "hi", "to": "^all", "channel": 0}
    ).encode()
    fake_response.__exit__.return_value = False

    with patch("urllib.request.urlopen", return_value=fake_response) as mock_urlopen:
        rc = cli.mesh_send_main(["--gateway", "http://x:9464", "hi"])

    assert rc == 0
    req = mock_urlopen.call_args[0][0]
    assert req.full_url == "http://x:9464/send"
    assert req.method == "POST"
    assert req.headers["Content-type"] == "application/json"
    body = json.loads(req.data)
    assert body == {"text": "hi", "channel": 0}
    captured = capsys.readouterr()
    assert "Sent to ^all: hi" in captured.out


def test_mesh_send_main_with_to_adds_to_field():
    fake_response = MagicMock()
    fake_response.__enter__.return_value.read.return_value = json.dumps(
        {"status": "sent", "text": "hi", "to": "!abcdef12", "channel": 0}
    ).encode()
    fake_response.__exit__.return_value = False

    with patch("urllib.request.urlopen", return_value=fake_response) as mock_urlopen:
        cli.mesh_send_main(["--to", "!abcdef12", "--gateway", "http://x:9464", "hi"])

    req = mock_urlopen.call_args[0][0]
    body = json.loads(req.data)
    assert body["to"] == "!abcdef12"
