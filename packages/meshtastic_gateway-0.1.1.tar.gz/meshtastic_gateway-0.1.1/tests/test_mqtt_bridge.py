"""Tests for the MqttBridge class."""

from unittest.mock import MagicMock

from meshtastic_gateway.mqtt_bridge import MqttBridge


def test_subscribe_topics_includes_downlink_enabled_channels(
    fake_iface, fake_mqtt_client, node_hex
):
    bridge = MqttBridge(fake_mqtt_client, fake_iface, node_hex)
    topics = bridge.subscribe_topics(fake_iface.localNode.channels, root="msh")
    assert "msh/2/e/LongFast/+" in topics
    assert "msh/2/c/LongFast/+" in topics
    assert "msh/2/e/secondary/+" not in topics
    assert "msh/2/c/secondary/+" not in topics


def test_subscribe_topics_includes_pki_topic(fake_iface, fake_mqtt_client, node_hex):
    bridge = MqttBridge(fake_mqtt_client, fake_iface, node_hex)
    topics = bridge.subscribe_topics(fake_iface.localNode.channels, root="msh")
    assert f"msh/2/e/PKC/{node_hex}" in topics


def test_on_message_filters_self_echo(fake_iface, fake_mqtt_client, node_hex):
    bridge = MqttBridge(fake_mqtt_client, fake_iface, node_hex)
    msg = MagicMock()
    msg.topic = f"msh/2/e/LongFast/{node_hex}"
    msg.payload = b"some bytes"
    bridge.on_message(fake_mqtt_client, None, msg)
    fake_iface.sendMqttClientProxyMessage.assert_not_called()


def test_on_message_forwards_to_iface(fake_iface, fake_mqtt_client, node_hex):
    bridge = MqttBridge(fake_mqtt_client, fake_iface, node_hex)
    msg = MagicMock()
    msg.topic = "msh/2/e/LongFast/!deadbeef"
    msg.payload = b"some bytes"
    bridge.on_message(fake_mqtt_client, None, msg)
    fake_iface.sendMqttClientProxyMessage.assert_called_once_with(msg.topic, msg.payload)


def test_publish_proxy_sends_with_retain(fake_iface, fake_mqtt_client, node_hex):
    bridge = MqttBridge(fake_mqtt_client, fake_iface, node_hex)
    pm = MagicMock()
    pm.topic = "msh/2/e/LongFast/publish"
    pm.data = b"payload"
    pm.retained = True
    bridge.publish_proxy(pm)
    fake_mqtt_client.publish.assert_called_once_with(
        "msh/2/e/LongFast/publish", b"payload", retain=True
    )


def test_connect_applies_credentials_and_tls(fake_iface, fake_mqtt_client, node_hex):
    bridge = MqttBridge(fake_mqtt_client, fake_iface, node_hex)
    bridge.connect("mqtt.example.org", 8883, "user", "pass", tls=True)
    fake_mqtt_client.username_pw_set.assert_called_once_with("user", "pass")
    fake_mqtt_client.tls_set.assert_called_once()
    fake_mqtt_client.connect.assert_called_once_with("mqtt.example.org", 8883)


def test_connect_without_tls_skips_tls_set(fake_iface, fake_mqtt_client, node_hex):
    bridge = MqttBridge(fake_mqtt_client, fake_iface, node_hex)
    bridge.connect("mqtt.example.org", 1883, "user", "pass", tls=False)
    fake_mqtt_client.tls_set.assert_not_called()
