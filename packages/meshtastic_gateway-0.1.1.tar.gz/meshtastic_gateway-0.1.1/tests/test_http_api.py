"""Tests for GatewayHandler HTTP endpoints and ACL."""

import ipaddress
import json
import threading
from contextlib import contextmanager
from http.server import ThreadingHTTPServer
from unittest.mock import MagicMock
from urllib.error import HTTPError
from urllib.request import Request, urlopen

import pytest
from meshtastic_gateway.http_api import make_handler


@contextmanager
def running_server(iface, allowed_nets):
    handler_cls = make_handler(iface, allowed_nets=allowed_nets)
    server = ThreadingHTTPServer(("127.0.0.1", 0), handler_cls)
    host, port = server.server_address
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://{host}:{port}"
    finally:
        server.shutdown()
        server.server_close()


def _get(url: str):
    try:
        with urlopen(url, timeout=2) as resp:
            return resp.status, resp.read()
    except HTTPError as e:
        return e.code, e.read()


def _post(url: str, body: bytes, content_type: str = "application/json"):
    req = Request(url, data=body, headers={"Content-Type": content_type}, method="POST")
    try:
        with urlopen(req, timeout=2) as resp:
            return resp.status, resp.read()
    except HTTPError as e:
        return e.code, e.read()


@pytest.fixture
def iface():
    return MagicMock()


def test_metrics_returns_200(iface):
    with running_server(iface, allowed_nets=[]) as base:
        status, body = _get(f"{base}/metrics")
    assert status == 200
    assert b"# HELP" in body


def test_send_get_returns_form(iface):
    with running_server(iface, allowed_nets=[]) as base:
        status, body = _get(f"{base}/send")
    assert status == 200
    assert b"<form" in body


def test_send_post_json_calls_sendtext(iface):
    body = json.dumps({"text": "hi", "channel": 0}).encode()
    with running_server(iface, allowed_nets=[]) as base:
        status, _ = _post(f"{base}/send", body)
    assert status == 200
    iface.sendText.assert_called_once_with("hi", destinationId="^all", channelIndex=0)


def test_send_post_invalid_json_returns_400(iface):
    with running_server(iface, allowed_nets=[]) as base:
        status, _ = _post(f"{base}/send", b"not json")
    assert status == 400


def test_send_post_missing_text_returns_400(iface):
    body = json.dumps({"channel": 0}).encode()
    with running_server(iface, allowed_nets=[]) as base:
        status, _ = _post(f"{base}/send", body)
    assert status == 400


def test_send_post_sendtext_raises_returns_500(iface):
    iface.sendText.side_effect = RuntimeError("serial broken")
    body = json.dumps({"text": "hi"}).encode()
    with running_server(iface, allowed_nets=[]) as base:
        status, _ = _post(f"{base}/send", body)
    assert status == 500


def test_unknown_path_returns_404(iface):
    with running_server(iface, allowed_nets=[]) as base:
        status, _ = _get(f"{base}/nope")
    assert status == 404


def test_acl_allows_in_range_ip(iface):
    nets = [ipaddress.ip_network("10.0.0.0/8")]
    handler_cls = make_handler(iface, allowed_nets=nets)
    assert handler_cls._acl_ok(ipaddress.ip_address("10.1.2.3"))


def test_acl_rejects_out_of_range_ip(iface):
    nets = [ipaddress.ip_network("10.0.0.0/8")]
    handler_cls = make_handler(iface, allowed_nets=nets)
    assert not handler_cls._acl_ok(ipaddress.ip_address("192.168.1.5"))


def test_acl_empty_allows_all(iface):
    handler_cls = make_handler(iface, allowed_nets=[])
    assert handler_cls._acl_ok(ipaddress.ip_address("192.168.1.5"))


def test_acl_blocks_loopback_when_not_allowed(iface):
    nets = [ipaddress.ip_network("10.0.0.0/8")]
    with running_server(iface, allowed_nets=nets) as base:
        status, _ = _get(f"{base}/metrics")
    assert status == 403


def test_acl_allows_loopback_when_in_list(iface):
    nets = [ipaddress.ip_network("127.0.0.0/8")]
    with running_server(iface, allowed_nets=nets) as base:
        status, _ = _get(f"{base}/metrics")
    assert status == 200
