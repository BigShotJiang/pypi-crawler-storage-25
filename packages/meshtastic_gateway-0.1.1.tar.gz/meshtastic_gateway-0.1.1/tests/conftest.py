"""Shared pytest fixtures."""

from unittest.mock import MagicMock

import pytest

NODE_HEX = "!abcdef12"


@pytest.fixture
def node_hex():
    return NODE_HEX


@pytest.fixture
def sample_telemetry_packet():
    return {
        "fromId": NODE_HEX,
        "decoded": {
            "portnum": "TELEMETRY_APP",
            "telemetry": {
                "deviceMetrics": {
                    "batteryLevel": 87,
                    "voltage": 4.01,
                    "airUtilTx": 1.2,
                    "channelUtilization": 3.4,
                    "uptimeSeconds": 12345,
                }
            },
        },
    }


@pytest.fixture
def sample_position_packet():
    return {
        "fromId": NODE_HEX,
        "decoded": {
            "portnum": "POSITION_APP",
            "position": {
                "latitude": 50.7374,
                "longitude": 7.0982,
                "altitude": 60,
            },
        },
    }


@pytest.fixture
def sample_text_packet():
    return {
        "fromId": NODE_HEX,
        "decoded": {"portnum": "TEXT_MESSAGE_APP", "text": "hello"},
    }


@pytest.fixture
def sample_remote_packet():
    return {
        "fromId": "!deadbeef",
        "decoded": {"portnum": "TELEMETRY_APP", "telemetry": {}},
    }


@pytest.fixture
def fake_iface():
    iface = MagicMock()
    iface.myInfo.my_node_num = 0xABCDEF12
    iface.metadata.firmware_version = "2.5.0"

    iface.localNode.moduleConfig.mqtt.address = "mqtt.example.org"
    iface.localNode.moduleConfig.mqtt.username = "meshdev"
    iface.localNode.moduleConfig.mqtt.password = "large4cats"
    iface.localNode.moduleConfig.mqtt.root = "msh"
    iface.localNode.moduleConfig.mqtt.tls_enabled = True

    ch0 = MagicMock()
    ch0.settings.name = "LongFast"
    ch0.settings.downlink_enabled = True
    ch1 = MagicMock()
    ch1.settings.name = "secondary"
    ch1.settings.downlink_enabled = False
    iface.localNode.channels = [ch0, ch1]

    iface.nodes = {NODE_HEX: {"position": {"latitude": 50.0, "longitude": 7.0, "altitude": 50}}}

    return iface


@pytest.fixture
def fake_mqtt_client():
    return MagicMock()
