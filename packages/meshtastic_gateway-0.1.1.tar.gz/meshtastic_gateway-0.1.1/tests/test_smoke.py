"""Baseline smoke tests that run before full module tests exist."""

import meshtastic_gateway


def test_package_has_version():
    assert meshtastic_gateway.__version__
    assert meshtastic_gateway.__version__ != "0.0.0+unknown"


def test_cli_module_invocable():
    """Daemon main() lazy-imports Gateway (lands in T13). Until then,
    exercise the parser directly."""
    from meshtastic_gateway.cli import _parse_main_args

    args = _parse_main_args([])
    assert args.port == 9464
    assert args.dev_path == "/dev/meshtastic0"
