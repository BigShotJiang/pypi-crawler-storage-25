"""Tests for the telemetry.packet → metric update logic."""

from meshtastic_gateway import metrics, telemetry


def _counter_value(counter, **labels):
    return counter.labels(**labels)._value.get()


def _gauge_value(gauge):
    return gauge._value.get()


def test_tx_packet_from_self_increments_tx_counter(sample_text_packet, node_hex):
    before = _counter_value(metrics.lora_tx_packets, portnum="TEXT_MESSAGE_APP")
    telemetry.update_from_mesh_packet(sample_text_packet, node_hex)
    after = _counter_value(metrics.lora_tx_packets, portnum="TEXT_MESSAGE_APP")
    assert after == before + 1


def test_packet_from_remote_increments_rx_counter(sample_remote_packet, node_hex):
    before = _counter_value(metrics.lora_rx_packets, portnum="TELEMETRY_APP")
    telemetry.update_from_mesh_packet(sample_remote_packet, node_hex)
    after = _counter_value(metrics.lora_rx_packets, portnum="TELEMETRY_APP")
    assert after == before + 1


def test_telemetry_packet_from_self_updates_device_gauges(sample_telemetry_packet, node_hex):
    telemetry.update_from_mesh_packet(sample_telemetry_packet, node_hex)
    assert _gauge_value(metrics.device_battery_level) == 87
    assert _gauge_value(metrics.device_voltage) == 4.01
    assert _gauge_value(metrics.device_air_util_tx) == 1.2
    assert _gauge_value(metrics.device_channel_utilization) == 3.4
    assert _gauge_value(metrics.device_uptime) == 12345


def test_telemetry_packet_from_remote_does_not_update_device_gauges(sample_remote_packet, node_hex):
    metrics.device_battery_level.set(42)
    telemetry.update_from_mesh_packet(sample_remote_packet, node_hex)
    assert _gauge_value(metrics.device_battery_level) == 42


def test_position_packet_from_self_updates_position_gauges(sample_position_packet, node_hex):
    telemetry.update_from_mesh_packet(sample_position_packet, node_hex)
    assert _gauge_value(metrics.device_latitude) == 50.7374
    assert _gauge_value(metrics.device_longitude) == 7.0982
    assert _gauge_value(metrics.device_altitude) == 60


def test_update_nodes_in_mesh_sets_gauge():
    telemetry.update_nodes_in_mesh(7)
    assert _gauge_value(metrics.lora_nodes_in_mesh) == 7


def test_update_from_node_position_sets_gauges():
    node = {"position": {"latitude": 49.0, "longitude": 8.0, "altitude": 100}}
    telemetry.update_from_node_position(node)
    assert _gauge_value(metrics.device_latitude) == 49.0
    assert _gauge_value(metrics.device_longitude) == 8.0
    assert _gauge_value(metrics.device_altitude) == 100
