"""Async HTTP client for ComfyUI API."""

from __future__ import annotations

import asyncio
import json
import re
import time
import uuid
from urllib.parse import urlencode

import httpx

_ALLOWED_HTTP_METHODS = frozenset({"GET", "POST", "PUT", "DELETE", "PATCH"})
_IDEMPOTENT_HTTP_METHODS = frozenset({"GET", "HEAD", "PUT", "DELETE"})
_RETRYABLE_STATUS_CODES = frozenset({502, 503, 504})
_UUID_RE = re.compile(r"^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$")
_SAFE_SEGMENT_RE = re.compile(r"^[A-Za-z0-9_.\-]+$")
_VALID_JOB_STATUSES = frozenset({"pending", "in_progress", "completed", "failed", "cancelled"})
_VALID_JOB_SORT_BY = frozenset({"created_at", "execution_duration"})
_VALID_JOB_SORT_ORDER = frozenset({"asc", "desc"})


def _validate_prompt_id(prompt_id: str) -> str:
    """Validate that a prompt_id is a well-formed UUID."""
    if not _UUID_RE.match(prompt_id):
        raise ValueError(f"Invalid prompt_id format: {prompt_id!r}")
    return prompt_id


def _validate_path_segment(value: str, *, label: str = "value") -> str:
    """Validate that a value is safe for interpolation into a URL path segment."""
    if not value:
        raise ValueError(f"{label} must not be empty")
    if not _SAFE_SEGMENT_RE.match(value):
        raise ValueError(f"{label} contains invalid characters: {value!r}")
    return value


class ComfyUIClient:
    _OBJECT_INFO_TTL = 300.0

    def __init__(
        self,
        base_url: str = "http://127.0.0.1:8188",
        timeout_connect: int = 30,
        timeout_read: int = 300,
        tls_verify: bool = True,
        max_retries: int = 3,
    ) -> None:
        self._base_url = base_url.rstrip("/")
        self._timeout = httpx.Timeout(connect=timeout_connect, read=timeout_read, write=30, pool=30)
        self._tls_verify = tls_verify
        self._client: httpx.AsyncClient | None = None
        self._max_retries = max_retries
        self._init_lock = asyncio.Lock()
        self._object_info_cache: dict | None = None
        self._object_info_ts: float = 0.0

    @property
    def base_url(self) -> str:
        """Return the base URL for the ComfyUI server."""
        return self._base_url

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is not None:
            return self._client
        async with self._init_lock:
            if self._client is None:
                self._client = httpx.AsyncClient(
                    base_url=self._base_url,
                    timeout=self._timeout,
                    verify=self._tls_verify,
                )
        return self._client

    async def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        """Make an HTTP request with retry logic for transient failures."""
        normalized = method.upper()
        if normalized not in _ALLOWED_HTTP_METHODS:
            raise ValueError(f"HTTP method not allowed: {method!r}")
        last_exception: Exception | None = None
        for attempt in range(self._max_retries):
            try:
                c = await self._get_client()
                r = await c.request(normalized, path, **kwargs)
                if (
                    r.status_code in _RETRYABLE_STATUS_CODES
                    and normalized in _IDEMPOTENT_HTTP_METHODS
                    and attempt < self._max_retries - 1
                ):
                    last_exception = httpx.HTTPStatusError(
                        f"Server returned {r.status_code}",
                        request=r.request,
                        response=r,
                    )
                    await r.aclose()
                    await asyncio.sleep(0.5 * (attempt + 1))
                    continue
                r.raise_for_status()
                return r
            except httpx.RequestError as e:
                last_exception = e
                if attempt < self._max_retries - 1:
                    await asyncio.sleep(0.5 * (attempt + 1))
                continue
        raise last_exception or RuntimeError("Request failed")

    async def close(self) -> None:
        if self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> ComfyUIClient:
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb) -> None:
        await self.close()

    @staticmethod
    def _unwrap_model_manager_response(payload: object) -> object:
        """Normalize ComfyUI-Model-Manager success envelopes to their data payload."""
        if isinstance(payload, dict) and payload.get("success") is True and "data" in payload:
            return payload["data"]
        return payload

    async def get_queue(self) -> dict:
        r = await self._request("get", "/queue")
        return r.json()

    async def post_prompt(self, workflow: dict, *, client_id: str | None = None) -> dict:
        payload: dict = {"prompt": workflow}
        if client_id is not None:
            payload["client_id"] = client_id
        r = await self._request("post", "/prompt", json=payload)
        return r.json()

    async def get_models(self, folder: str) -> list:
        _validate_path_segment(folder, label="folder")
        r = await self._request("get", f"/models/{folder}")
        return r.json()

    async def get_object_info(self, node_class: str | None = None) -> dict:
        if node_class is not None:
            _validate_path_segment(node_class, label="node_class")
            r = await self._request("get", f"/object_info/{node_class}")
            return r.json()
        now = time.monotonic()
        cache_age = now - self._object_info_ts
        if self._object_info_cache is not None and cache_age < self._OBJECT_INFO_TTL:
            return self._object_info_cache
        r = await self._request("get", "/object_info")
        data: dict = r.json()
        self._object_info_cache = data
        self._object_info_ts = now
        return data

    async def get_history(
        self,
        max_items: int | None = None,
        *,
        offset: int | None = None,
    ) -> dict:
        """GET /history — fetch execution history with optional pagination.

        Args:
            max_items: Maximum number of history entries to return. Capped at 1000
                server-side regardless of the value passed.
            offset: Zero-based starting index. None (default) sends no offset, which
                ComfyUI treats as "no offset" (newest entries first).
        """
        params: dict[str, int] = {}
        if max_items is not None:
            if max_items <= 0:
                raise ValueError("max_items must be a positive integer")
            params["max_items"] = min(max_items, 1000)
        if offset is not None:
            if offset < 0:
                raise ValueError("offset must be >= 0")
            params["offset"] = offset
        r = await self._request("get", "/history", params=params or None)
        return r.json()

    async def get_job(self, job_id: str) -> dict:
        """GET /api/jobs/{job_id} — unified job lookup across queue + history."""
        _validate_prompt_id(job_id)
        r = await self._request("get", f"/api/jobs/{job_id}")
        return r.json()

    async def get_jobs(
        self,
        *,
        status: list[str] | None = None,
        workflow_id: str | None = None,
        sort_by: str = "created_at",
        sort_order: str = "desc",
        limit: int | None = None,
        offset: int = 0,
    ) -> dict:
        """GET /api/jobs — unified, paginated, filterable job list."""
        if status is not None:
            invalid = [s for s in status if s not in _VALID_JOB_STATUSES]
            if invalid:
                raise ValueError(
                    f"Invalid status value(s): {invalid}. Valid: {sorted(_VALID_JOB_STATUSES)}"
                )
        if sort_by not in _VALID_JOB_SORT_BY:
            raise ValueError(
                f"sort_by must be one of {sorted(_VALID_JOB_SORT_BY)}, got {sort_by!r}"
            )
        if sort_order not in _VALID_JOB_SORT_ORDER:
            raise ValueError(
                f"sort_order must be one of {sorted(_VALID_JOB_SORT_ORDER)}, got {sort_order!r}"
            )
        if limit is not None and limit <= 0:
            raise ValueError("limit must be a positive integer")
        if offset < 0:
            raise ValueError("offset must be >= 0")

        params: dict[str, str] = {
            "sort_by": sort_by,
            "sort_order": sort_order,
            "offset": str(offset),
        }
        if status:
            params["status"] = ",".join(status)
        if workflow_id:
            params["workflow_id"] = workflow_id
        if limit is not None:
            params["limit"] = str(limit)

        r = await self._request("get", "/api/jobs", params=params)
        return r.json()

    async def interrupt(self, prompt_id: str | None = None) -> None:
        """POST /interrupt — global interrupt, or targeted if prompt_id is given.

        Without prompt_id, interrupts whatever is currently executing.
        With prompt_id, ComfyUI only interrupts if that prompt is the running one;
        otherwise the call is a no-op (server returns 200 either way).
        """
        if prompt_id is not None:
            _validate_prompt_id(prompt_id)
            await self._request("post", "/interrupt", json={"prompt_id": prompt_id})
        else:
            await self._request("post", "/interrupt")

    async def delete_queue_item(self, prompt_id: str) -> None:
        _validate_prompt_id(prompt_id)
        await self._request("post", "/queue", json={"delete": [prompt_id]})

    async def upload_image(
        self,
        data: bytes,
        filename: str,
        subfolder: str = "",
        *,
        destination: str = "input",
        overwrite: bool = False,
    ) -> dict:
        """POST /upload/image — upload an image to ComfyUI.

        Args:
            data: Raw image bytes.
            filename: Target filename in ComfyUI's storage.
            subfolder: Optional subfolder within the destination.
            destination: Destination type. One of "input" (default), "output", "temp".
                The wire field name is ``type`` — renamed here to avoid shadowing the
                Python builtin.
            overwrite: If True, replace an existing file with the same name. If False
                (default), ComfyUI auto-renames by suffixing ``(N)`` when a duplicate
                exists.
        """
        if destination not in {"input", "output", "temp"}:
            raise ValueError(
                f"destination must be one of 'input', 'output', 'temp'; got {destination!r}"
            )
        files = {"image": (filename, data, "image/png")}
        form_data: dict[str, str] = {}
        if subfolder:
            form_data["subfolder"] = subfolder
        # Only include 'type'/'overwrite' when the caller deviates from defaults —
        # keeps the request body identical to historical behavior in the common case.
        if destination != "input":
            form_data["type"] = destination
        if overwrite:
            form_data["overwrite"] = "true"
        r = await self._request("post", "/upload/image", files=files, data=form_data)
        return r.json()

    async def get_image(
        self,
        filename: str,
        subfolder: str = "",
        *,
        preview: str | None = None,
    ) -> tuple[bytes, str]:
        """GET /view — download an output image by filename and subfolder.

        Args:
            filename: Image filename in ComfyUI's output dir.
            subfolder: Subfolder within ComfyUI's output dir.
            preview: Optional thumbnail spec passed to ComfyUI as ``preview=<spec>``.
                Format ``<format>;<quality>`` where format is ``webp`` or ``jpeg``
                and quality is 1-100. ComfyUI re-encodes the image server-side.
        """
        params: dict[str, str] = {
            "filename": filename,
            "subfolder": subfolder,
            "type": "output",
        }
        if preview is not None:
            params["preview"] = preview
        r = await self._request("get", "/view", params=params)
        content_type = r.headers.get("content-type", "image/png")
        return r.content, content_type

    def build_image_url(
        self,
        filename: str,
        subfolder: str = "",
        *,
        base_url: str | None = None,
    ) -> str:
        """Build a direct ComfyUI /view URL for an image."""
        target_base_url = (base_url or self._base_url).rstrip("/")
        parsed = httpx.URL(target_base_url)
        if parsed.scheme not in ("http", "https") or not parsed.host:
            raise ValueError("base_url must use http or https and include a host")
        query = urlencode({"filename": filename, "subfolder": subfolder, "type": "output"})
        return f"{target_base_url}/view?{query}"

    async def get_embeddings(self) -> list:
        r = await self._request("get", "/embeddings")
        return r.json()

    async def get_workflow_templates(self) -> dict:
        """GET /workflow_templates — list installed workflow templates by package."""
        r = await self._request("get", "/workflow_templates")
        return r.json()

    async def get_extensions(self) -> list:
        r = await self._request("get", "/extensions")
        return r.json()

    async def get_features(self) -> dict:
        r = await self._request("get", "/features")
        return r.json()

    async def get_model_types(self) -> list:
        r = await self._request("get", "/models")
        return r.json()

    async def get_view_metadata(self, folder: str, filename: str) -> dict:
        _validate_path_segment(folder, label="folder")
        if not filename or "\x00" in filename or ".." in filename:
            raise ValueError(f"filename is invalid: {filename!r}")
        r = await self._request("get", f"/view_metadata/{folder}", params={"filename": filename})
        return r.json()

    async def get_prompt_status(self) -> dict:
        r = await self._request("get", "/prompt")
        return r.json()

    async def get_system_stats(self) -> dict:
        """GET /system_stats — raw ComfyUI system statistics.

        NOTE: /system_stats is on the blocked-endpoint list for direct exposure.
        This method is called exclusively by the get_system_info tool, which
        applies a strict whitelist before returning any data. No raw response
        is ever forwarded to callers. Do not add any other callers.
        """
        r = await self._request("get", "/system_stats")
        return r.json()

    async def clear_queue(self, clear_running: bool = False, clear_pending: bool = False) -> None:
        data: dict[str, list[str]] = {"clear": []}
        if clear_running:
            data["clear"].append("running")
        if clear_pending:
            data["clear"].append("pending")
        await self._request("post", "/queue", json=data)

    async def upload_mask(
        self,
        data: bytes,
        filename: str,
        original_ref: dict[str, str],
        subfolder: str = "",
        *,
        destination: str = "input",
        overwrite: bool = False,
    ) -> dict:
        """POST /upload/mask — upload a mask image to ComfyUI.

        Args:
            data: Raw mask image bytes.
            filename: Target filename in ComfyUI's storage.
            original_ref: Dict identifying the original image whose alpha channel
                this mask updates. Must include ``filename`` and ``type`` keys;
                may include ``subfolder``.
            subfolder: Optional subfolder within the destination.
            destination: Destination type. One of "input" (default), "output", "temp".
                The wire field name is ``type`` — renamed here to avoid shadowing
                the Python builtin.
            overwrite: If True, replace an existing file with the same name. If False
                (default), ComfyUI auto-renames by suffixing ``(N)``.
        """
        if destination not in {"input", "output", "temp"}:
            raise ValueError(
                f"destination must be one of 'input', 'output', 'temp'; got {destination!r}"
            )
        files = {"image": (filename, data, "image/png")}
        form_data: dict[str, str] = {"original_ref": json.dumps(original_ref)}
        if subfolder:
            form_data["subfolder"] = subfolder
        # Only include 'type'/'overwrite' when the caller deviates from defaults —
        # keeps the request body identical to historical behavior in the common case.
        if destination != "input":
            form_data["type"] = destination
        if overwrite:
            form_data["overwrite"] = "true"
        r = await self._request("post", "/upload/mask", files=files, data=form_data)
        return r.json()

    # --- ComfyUI Manager endpoints (V4+, /v2/ prefix) ---

    async def get_manager_version(self) -> str:
        """GET /v2/manager/version — check ComfyUI Manager availability."""
        r = await self._request("get", "/v2/manager/version")
        return r.text

    async def get_installed_custom_nodes(self) -> dict:
        """GET /v2/customnode/installed — list installed custom node packs."""
        r = await self._request("get", "/v2/customnode/installed")
        return r.json()

    async def queue_manager_task(
        self,
        *,
        kind: str,
        params: dict,
        client_id: str = "comfyui-mcp",
    ) -> None:
        """POST /v2/manager/queue/task — submit an install/uninstall/update task."""
        payload = {
            "ui_id": uuid.uuid4().hex,
            "client_id": client_id,
            "kind": kind,
            "params": params,
        }
        await self._request("post", "/v2/manager/queue/task", json=payload)

    async def start_custom_node_queue(self) -> None:
        """GET /v2/manager/queue/start — start processing queued tasks."""
        await self._request("get", "/v2/manager/queue/start")

    async def get_custom_node_queue_status(self) -> dict:
        """GET /v2/manager/queue/status — poll queue progress."""
        r = await self._request("get", "/v2/manager/queue/status")
        return r.json()

    async def reset_custom_node_queue(self) -> None:
        """GET /v2/manager/queue/reset — clear the task queue."""
        await self._request("get", "/v2/manager/queue/reset")

    async def reboot_comfyui(self) -> None:
        """GET /v2/manager/reboot — restart ComfyUI.

        NOTE: This endpoint uses GET (unusual for a destructive action) —
        this is upstream ComfyUI Manager behavior. Only called when the user
        explicitly passes restart=True and the job queue is verified empty.
        """
        await self._request("get", "/v2/manager/reboot")

    # --- Model Manager endpoints ---

    async def get_model_manager_folders(self) -> list[str]:
        """GET /model-manager/models — list available model folder types."""
        r = await self._request("get", "/model-manager/models")
        payload = self._unwrap_model_manager_response(r.json())
        if isinstance(payload, dict):
            return sorted(payload.keys())
        if isinstance(payload, list):
            return payload
        raise TypeError("Unexpected response payload for /model-manager/models")

    async def create_download_task(
        self,
        *,
        model_type: str,
        path_index: int,
        fullname: str,
        download_platform: str,
        download_url: str,
        size_bytes: int,
        preview_url: str = "",
        description: str = "",
    ) -> dict:
        """POST /model-manager/model — create a model download task."""
        form_data = {
            "type": model_type,
            "pathIndex": str(path_index),
            "fullname": fullname,
            "downloadPlatform": download_platform,
            "downloadUrl": download_url,
            "sizeBytes": str(size_bytes),
            "previewFile": preview_url,
        }
        if description:
            form_data["description"] = description
        r = await self._request("post", "/model-manager/model", data=form_data)
        payload = self._unwrap_model_manager_response(r.json())
        if isinstance(payload, dict):
            return payload
        raise TypeError("Unexpected response payload for /model-manager/model")

    async def get_download_tasks(self) -> list[dict]:
        """GET /model-manager/download/task — list download tasks with progress."""
        r = await self._request("get", "/model-manager/download/task")
        payload = self._unwrap_model_manager_response(r.json())
        if isinstance(payload, list):
            return payload
        raise TypeError("Unexpected response payload for /model-manager/download/task")

    async def delete_download_task(self, task_id: str) -> dict:
        """DELETE /model-manager/download/{task_id} — cancel and remove a download."""
        _validate_path_segment(task_id, label="task_id")
        r = await self._request("delete", f"/model-manager/download/{task_id}")
        payload = self._unwrap_model_manager_response(r.json())
        if isinstance(payload, dict):
            return payload
        raise TypeError("Unexpected response payload for /model-manager/download/{task_id}")
