'''
Function:
    Implementation of TedVideoClient
Author:
    Zhenchao Jin
WeChat Official Account (微信公众号):
    Charles的皮卡丘
'''
import os
import json_repair
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from .base import BaseVideoClient
from ..utils import legalizestring, useparseheaderscookies, yieldtimerelatedtitle, safeextractfromdict, FileTypeSniffer, VideoInfo


'''TedVideoClient'''
class TedVideoClient(BaseVideoClient):
    source = 'TedVideoClient'
    def __init__(self, **kwargs):
        super(TedVideoClient, self).__init__(**kwargs)
        self.default_parse_headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/142.0.0.0 Safari/537.36',
        }
        self.default_download_headers = {
            "accept-encoding": "identity;q=1, *;q=0", "referer": "https://www.ted.com/", "sec-ch-ua": '"Google Chrome";v="143", "Chromium";v="143", "Not A(Brand";v="24"', "sec-ch-ua-mobile": "?0",
            "sec-ch-ua-platform": '"Windows"', "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36",
        }
        self.default_headers = self.default_parse_headers
        self._initsession()
    '''parsefromurl'''
    @useparseheaderscookies
    def parsefromurl(self, url: str, request_overrides: dict = None):
        # prepare
        if not self.belongto(url=url): return []
        request_overrides, video_info, null_backup_title = request_overrides or {}, VideoInfo(source=self.source, nm3u8dlre_settings={"--auto-select": False, "-sv": "best", "-sa": "best", "-M": "format=mp4:skip_sub=true"}), yieldtimerelatedtitle(self.source)
        # try parse
        try:
            vid = urlparse(url).path.strip('/').split('/')[-1]
            (resp := self.get(url, **request_overrides)).raise_for_status(); resp.encoding = 'utf-8'
            script_tag = BeautifulSoup(resp.text, "lxml").find("script", id="__NEXT_DATA__", type="application/json")
            video_info.update(dict(raw_data=(raw_data := json_repair.loads(script_tag.string))))
            player_data = json_repair.loads(raw_data["props"]["pageProps"]["videoData"]["playerData"])
            download_url = safeextractfromdict(player_data, ['resources', 'hls', 'stream'], '') or safeextractfromdict(sorted(safeextractfromdict(player_data, ['resources', 'h264'], []), key=lambda x: x.get('bitrate', 0), reverse=True), [0, 'file'], '') or safeextractfromdict(sorted(safeextractfromdict(player_data, ['resources', 'rtmp'], []), key=lambda x: x.get('width', 0) * x.get('height', 0), reverse=True), [0, 'file'], '')
            video_info.update(dict(download_url=download_url))
            guess_video_ext_result = FileTypeSniffer.getfileextensionfromurl(url=download_url, headers=self.default_download_headers, request_overrides=request_overrides, cookies=self.default_download_cookies)
            ext = guess_video_ext_result['ext'] if guess_video_ext_result['ext'] and guess_video_ext_result['ext'] != 'NULL' else video_info.ext
            video_title = safeextractfromdict(raw_data["props"]["pageProps"]["videoData"], ['title'], None) or null_backup_title
            video_title = legalizestring(video_title, replace_null_string=null_backup_title).removesuffix('.')
            cover_url = safeextractfromdict(raw_data, ['props', 'pageProps', 'videoData', 'primaryImageSet', 0, 'url'], None)
            video_info.update(dict(title=video_title, save_path=os.path.join(self.work_dir, self.source, f'{video_title}.{ext}'), ext=ext, guess_video_ext_result=guess_video_ext_result, identifier=vid, cover_url=cover_url))
        except Exception as err:
            video_info.update(dict(err_msg=(err_msg := f'{self.source}.parsefromurl >>> {url} (Error: {err})')))
            self.logger_handle.error(err_msg, disable_print=self.disable_print)
        # return
        return [video_info]
    '''belongto'''
    @staticmethod
    def belongto(url: str, valid_domains: list[str] | set[str] = None):
        valid_domains = set(valid_domains or []) | {"ted.com"}
        return BaseVideoClient.belongto(url, valid_domains)