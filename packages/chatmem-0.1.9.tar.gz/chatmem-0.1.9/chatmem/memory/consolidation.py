"""
Consolidation task (sleep-consolidation analogue).
Runs asynchronously every N sessions.
Extracts stable patterns from recent memory → writes to core memory.
"""

import json
from typing import TYPE_CHECKING

from openai import OpenAI

from ..compressor import _is_chinese

if TYPE_CHECKING:
    from .recent_memory import RecentMemory
    from .core_memory import CoreMemory


_CONSOLIDATION_PROMPT = """You are a memory consolidation assistant. Analyze the following recent conversation summaries and extract stable patterns that can be internalized as long-term memory.

Stable patterns include: recurring preferences, habits, decision tendencies, user traits.
Exclude: one-time events, temporary states.

Recent memory summaries:
{text}

Output the stable patterns found as a JSON array (each item contains key and value):
[{{"key": "...", "value": "..."}}]
If no stable patterns found, return: []

Output JSON only:"""

_CONSOLIDATION_PROMPT_ZH = """你是一个记忆巩固助手。分析以下近期对话摘要，提取可以内化为长期记忆的稳定模式。

稳定模式包括：反复出现的偏好、习惯、决策倾向、用户特征。
不包括：一次性事件、临时状态。

近期记忆摘要：
{text}

以JSON数组格式输出发现的稳定模式（每项包含key和value）：
[{{"key": "...", "value": "..."}}]
如果没有发现稳定模式，返回：[]

只输出JSON："""


class ConsolidationTask:
    """
    Periodic consolidation: recent memory patterns → core memory.
    Run via run() after every N sessions (recommended: every 5-10 sessions).
    """

    def __init__(
        self,
        recent_memory: "RecentMemory",
        core_memory: "CoreMemory",
        api_key: str,
        model: str = "gpt-4o-mini",
        base_url: str | None = None,
        extra_body: dict | None = None,
    ):
        self.recent = recent_memory
        self.core = core_memory
        self.api_key = api_key
        self.model = model
        self.base_url = base_url
        self.extra_body = extra_body

    def run(self) -> list[dict]:
        """
        Extract stable patterns from recent memory and write to core memory.
        Returns list of consolidated entries.
        """
        recent_text = self.recent.get_for_context()
        if not recent_text.strip():
            return []

        prompt = _CONSOLIDATION_PROMPT_ZH if _is_chinese(recent_text) else _CONSOLIDATION_PROMPT
        client = OpenAI(api_key=self.api_key, base_url=self.base_url)
        kwargs: dict = dict(
            model=self.model,
            messages=[
                {
                    "role": "user",
                    "content": prompt.format(text=recent_text),
                }
            ],
            max_tokens=400,
        )
        if self.extra_body:
            kwargs["extra_body"] = self.extra_body
        response = client.chat.completions.create(**kwargs)
        raw = response.choices[0].message.content.strip()
        try:
            entries = json.loads(raw)
        except json.JSONDecodeError:
            return []

        consolidated = []
        for entry in entries:
            if "key" in entry and "value" in entry:
                self.core.set(entry["key"], entry["value"], stability=40.0)
                consolidated.append(entry)

        return consolidated
