"""
Proxy server tests — no real LLM calls.

Run:
    pytest tests/test_proxy.py -v
"""

import json
import threading
import time
from unittest.mock import MagicMock
import pytest


# ---------------------------------------------------------------------------
# Fake response helpers
# ---------------------------------------------------------------------------

def _fake_response(content: str = "Hello from chatmem!") -> MagicMock:
    r = MagicMock()
    r.choices[0].message.content = content
    r.choices[0].finish_reason = "stop"
    r.model_dump.return_value = {
        "id": "chatcmpl-test",
        "object": "chat.completion",
        "created": 1234567890,
        "model": "mock-model",
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": content},
            "finish_reason": "stop",
        }],
        "usage": {"prompt_tokens": 10, "completion_tokens": 5, "total_tokens": 15},
    }
    return r


def _fake_stream_chunk(content: str | None, finish: bool = False) -> MagicMock:
    chunk = MagicMock()
    chunk.choices[0].delta.content = content
    chunk.choices[0].finish_reason = "stop" if finish else None
    chunk.model_dump.return_value = {
        "id": "chatcmpl-stream",
        "object": "chat.completion.chunk",
        "choices": [{
            "delta": {"content": content},
            "finish_reason": "stop" if finish else None,
        }],
    }
    return chunk


def _fake_tool_response() -> MagicMock:
    r = MagicMock()
    r.choices[0].message.content = None
    r.choices[0].finish_reason = "tool_calls"
    r.model_dump.return_value = {
        "id": "chatcmpl-tool",
        "object": "chat.completion",
        "created": 1234567890,
        "model": "mock-model",
        "choices": [{
            "index": 0,
            "message": {"role": "assistant", "content": None,
                        "tool_calls": [{"id": "call_1", "type": "function",
                                        "function": {"name": "bash", "arguments": "{}"}}]},
            "finish_reason": "tool_calls",
        }],
    }
    return r


# ---------------------------------------------------------------------------
# Fixture: start proxy server with fake ContextManager
# ---------------------------------------------------------------------------

PORT = 12499  # separate from chatmem serve default (12434)

@pytest.fixture(scope="module")
def client():
    fastapi = pytest.importorskip("fastapi")
    uvicorn = pytest.importorskip("uvicorn")
    requests = pytest.importorskip("requests")

    import chatmem.server as srv

    # Build a fake ContextManager
    fake_cm = MagicMock()
    fake_cm.model = "mock-model"
    fake_cm._history = []
    fake_cm._turn_count = 0
    fake_cm._persisted_seq = 0
    fake_cm.chat.return_value = _fake_response()

    # Inject directly into module globals — survives across thread boundary
    srv._cm = fake_cm
    original_init = srv._init_cm
    srv._init_cm = lambda *a, **kw: None   # no-op: don't touch config/DB

    app = srv.create_app(config_path=None, db_path=":memory:")

    cfg = uvicorn.Config(app, host="127.0.0.1", port=PORT, log_level="error")
    server = uvicorn.Server(cfg)
    t = threading.Thread(target=server.run, daemon=True)
    t.start()

    # Wait until server is ready
    deadline = time.time() + 5
    while time.time() < deadline:
        try:
            requests.get(f"http://127.0.0.1:{PORT}/v1/models", timeout=0.3)
            break
        except Exception:
            time.sleep(0.1)

    session = requests.Session()
    session.headers["Authorization"] = "Bearer test-key"
    session._cm = fake_cm        # expose for per-test manipulation
    session._base = f"http://127.0.0.1:{PORT}/v1"

    yield session

    server.should_exit = True
    srv._init_cm = original_init


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

def test_models(client):
    r = client.get(f"{client._base}/models")
    assert r.status_code == 200
    assert r.json()["object"] == "list"


def test_non_streaming(client):
    client._cm.chat.return_value = _fake_response("pong")
    r = client.post(f"{client._base}/chat/completions", json={
        "model": "mock-model",
        "messages": [{"role": "user", "content": "ping"}],
    })
    assert r.status_code == 200
    assert r.json()["choices"][0]["message"]["content"] == "pong"


def test_kwargs_forwarded(client):
    client._cm.chat.return_value = _fake_response("ok")
    client.post(f"{client._base}/chat/completions", json={
        "model": "mock-model",
        "messages": [{"role": "user", "content": "test"}],
        "temperature": 1.0,
        "max_tokens": 50,
    })
    _, kwargs = client._cm.chat.call_args
    assert kwargs.get("temperature") == 1.0
    assert kwargs.get("max_tokens") == 50


def test_streaming(client):
    client._cm.chat.return_value = iter([
        _fake_stream_chunk("Hello"),
        _fake_stream_chunk(" world"),
        _fake_stream_chunk(None, finish=True),
    ])
    r = client.post(f"{client._base}/chat/completions", json={
        "model": "mock-model",
        "messages": [{"role": "user", "content": "hi"}],
        "stream": True,
    }, stream=True)
    assert r.status_code == 200
    assert "text/event-stream" in r.headers.get("content-type", "")

    lines = [
        (l.decode() if isinstance(l, bytes) else l)
        for l in r.iter_lines() if l
    ]
    data_lines = [l for l in lines if l.startswith("data:") and "[DONE]" not in l]
    assert len(data_lines) >= 1
    payload = json.loads(data_lines[0].removeprefix("data:").strip())
    assert "choices" in payload


def test_tool_call_rolled_back(client):
    client._cm._history.clear()
    client._cm._turn_count = 0
    client._cm._persisted_seq = 0
    client._cm.chat.return_value = _fake_tool_response()

    client.post(f"{client._base}/chat/completions", json={
        "model": "mock-model",
        "messages": [{"role": "user", "content": "run ls"}],
    })
    # tool_call turn should be rolled back — history stays empty
    assert len(client._cm._history) == 0
