"""
Integration test against a real running chatmem serve.

Prerequisites:
    chatmem serve   # running on 127.0.0.1:12434

Run:
    pytest tests/test_proxy_integration.py -v -s
"""

import json
import pytest
import requests

BASE = "http://127.0.0.1:12434/v1"
SYSTEM = "You are a concise assistant. Reply in one sentence."


@pytest.fixture(scope="module", autouse=True)
def require_server():
    """Skip all tests if chatmem serve is not running."""
    try:
        requests.get(f"{BASE}/models", timeout=2)
    except Exception:
        pytest.skip("chatmem serve not running on 127.0.0.1:12434")


def test_models():
    r = requests.get(f"{BASE}/models")
    assert r.status_code == 200
    data = r.json()
    assert data["object"] == "list"
    assert len(data["data"]) >= 1
    print(f"\n  model: {data['data'][0]['id']}")


def test_non_streaming():
    r = requests.post(f"{BASE}/chat/completions", json={
        "model": "ignored",   # chatmem uses config model
        "messages": [
            {"role": "system", "content": SYSTEM},
            {"role": "user",   "content": "Say 'hello'"},
        ],
    })
    assert r.status_code == 200
    data = r.json()
    assert data["choices"][0]["message"]["role"] == "assistant"
    content = data["choices"][0]["message"]["content"]
    assert content and len(content) > 0
    print(f"\n  reply: {content}")


def test_streaming():
    r = requests.post(f"{BASE}/chat/completions", json={
        "model": "ignored",
        "messages": [
            {"role": "system", "content": SYSTEM},
            {"role": "user",   "content": "Count to 3"},
        ],
        "stream": True,
    }, stream=True)

    assert r.status_code == 200
    assert "text/event-stream" in r.headers.get("content-type", "")

    collected = []
    for line in r.iter_lines():
        decoded = line.decode() if isinstance(line, bytes) else line
        if not decoded or not decoded.startswith("data:"):
            continue
        if "[DONE]" in decoded:
            break
        chunk = json.loads(decoded.removeprefix("data:").strip())
        delta = chunk["choices"][0]["delta"].get("content") or ""
        collected.append(delta)
        print(delta, end="", flush=True)

    print()
    full = "".join(collected)
    assert len(full) > 0


def test_multi_turn_memory():
    """Two consecutive turns — second should reference the first."""
    turn1 = requests.post(f"{BASE}/chat/completions", json={
        "model": "ignored",
        "messages": [
            {"role": "system", "content": SYSTEM},
            {"role": "user",   "content": "My name is TestUser."},
        ],
    })
    assert turn1.status_code == 200
    print(f"\n  turn1: {turn1.json()['choices'][0]['message']['content']}")

    turn2 = requests.post(f"{BASE}/chat/completions", json={
        "model": "ignored",
        "messages": [
            {"role": "system", "content": SYSTEM},
            {"role": "user",   "content": "What is my name?"},
        ],
    })
    assert turn2.status_code == 200
    reply = turn2.json()["choices"][0]["message"]["content"]
    print(f"  turn2: {reply}")
    assert "TestUser" in reply


def test_extra_kwargs():
    """Extra kwargs (max_tokens) are forwarded — verified by successful response."""
    r = requests.post(f"{BASE}/chat/completions", json={
        "model": "ignored",
        "messages": [{"role": "user", "content": "Hi"}],
        "max_tokens": 50,
    })
    assert r.status_code == 200
    data = r.json()
    assert "choices" in data
    print(f"\n  reply (max_tokens=50): {data['choices'][0]['message']['content']!r}")
