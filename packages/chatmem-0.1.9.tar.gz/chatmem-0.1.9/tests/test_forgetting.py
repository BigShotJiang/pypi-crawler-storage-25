"""Tests for ForgettingManager and compute_score."""
import time
import tempfile
import pytest
from chatmem.memory.forgetting import ForgettingManager, compute_score
from chatmem.memory.core_memory import CoreMemory


def test_compute_score_fresh():
    score = compute_score(access_count=0, created_at=time.time(), stability=30.0)
    assert 0.9 < score <= 1.0


def test_compute_score_old_entry():
    old_time = time.time() - 30 * 86400  # 30 days ago
    score = compute_score(access_count=0, created_at=old_time, stability=10.0)
    assert score < 0.1


def test_compute_score_high_access_count():
    old_time = time.time() - 5 * 86400  # 5 days ago
    score_low = compute_score(access_count=0, created_at=old_time, stability=10.0)
    score_high = compute_score(access_count=5, created_at=old_time, stability=10.0)
    assert score_high > score_low


def test_compute_score_capped_at_1():
    score = compute_score(access_count=100, created_at=time.time(), stability=50.0)
    assert score == 1.0


@pytest.fixture
def db():
    with tempfile.NamedTemporaryFile(suffix=".db") as f:
        yield f.name


def test_run_decay_reduces_old_scores(db):
    core = CoreMemory(db, api_key="test")
    core.set("old_key", "value")
    # Manually set old timestamp
    import sqlite3
    old_time = time.time() - 60 * 86400  # 60 days ago
    with sqlite3.connect(db) as conn:
        conn.execute("UPDATE core_memory SET created_at=?, updated_at=? WHERE key=?",
                     (old_time, old_time, "old_key"))

    fm = ForgettingManager(core)
    fm.run_decay()

    # Score should have dropped significantly
    rows = core.get_all_with_scores()
    old_entry = next(r for r in rows if r["key"] == "old_key")
    assert old_entry["score"] < 0.5


def test_run_decay_keeps_recent_scores_high(db):
    core = CoreMemory(db, api_key="test")
    core.set("new_key", "value", stability=50.0)

    fm = ForgettingManager(core)
    fm.run_decay()

    rows = core.get_all_with_scores()
    new_entry = next(r for r in rows if r["key"] == "new_key")
    assert new_entry["score"] > 0.9
