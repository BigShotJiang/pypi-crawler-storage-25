"""Tests for ContextConfig and DimensionConfig."""
import json
import tempfile
import pytest
from chatmem.config import ContextConfig, DimensionConfig, DEFAULT_DIMENSIONS


def test_default_dimensions_exist():
    assert len(DEFAULT_DIMENSIONS) == 7
    assert "identity" in DEFAULT_DIMENSIONS
    assert "preferences" in DEFAULT_DIMENSIONS


def test_dimension_config_fields():
    d = DimensionConfig(label="test", stability=30.0)
    assert d.label == "test"
    assert d.stability == 30.0


def test_context_config_defaults():
    cfg = ContextConfig()
    assert set(cfg.dimensions.keys()) == set(DEFAULT_DIMENSIONS.keys())


def test_context_config_custom_dimensions():
    cfg = ContextConfig(dimensions={
        "domain": DimensionConfig(label="专业领域", stability=40.0),
        "style":  DimensionConfig(label="风格偏好", stability=25.0),
    })
    assert "domain" in cfg.dimensions
    assert "style" in cfg.dimensions
    assert "identity" not in cfg.dimensions


def test_from_dict():
    data = {
        "dimensions": {
            "role":  {"label": "角色", "stability": 50.0},
            "prefs": {"label": "偏好", "stability": 20.0},
        }
    }
    cfg = ContextConfig.from_dict(data)
    assert cfg.dimensions["role"].label == "角色"
    assert cfg.dimensions["prefs"].stability == 20.0


def test_to_dict_round_trip():
    cfg = ContextConfig(dimensions={
        "test": DimensionConfig(label="测试", stability=15.0)
    })
    d = cfg.to_dict()
    cfg2 = ContextConfig.from_dict(d)
    assert cfg2.dimensions["test"].label == "测试"
    assert cfg2.dimensions["test"].stability == 15.0


def test_from_json_to_json_round_trip():
    cfg = ContextConfig(dimensions={
        "foo": DimensionConfig(label="Foo", stability=33.0)
    })
    with tempfile.NamedTemporaryFile(suffix=".json", mode="w", delete=False) as f:
        path = f.name
    cfg.to_json(path)
    cfg2 = ContextConfig.from_json(path)
    assert cfg2.dimensions["foo"].label == "Foo"
    assert cfg2.dimensions["foo"].stability == 33.0
