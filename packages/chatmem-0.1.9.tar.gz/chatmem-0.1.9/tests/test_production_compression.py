"""
Production compression simulation test.

Simulates exactly what happens in production when _compress_old_turns fires:
  - All turns except the last VERBATIM_TAIL are compressed into ONE structured summary
  - Verbatim tail stays intact
  - Checks fact survival in the summary
  - Then runs a recall test: LLM answers questions using only [summary + verbatim tail]

Output saved to: tests/production_compression_result.txt
"""

import os
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from chatmem.compressor import compress_session_context
from chatmem.token_counter import count_tokens, count_messages_tokens
from openai import OpenAI

API_KEY      = os.environ["MOONSHOT_API_KEY"]
INPUT_FILE   = Path(__file__).parent.parent / "conxxxxx.txt"
OUTPUT_FILE  = Path(__file__).parent / "production_compression_result.txt"
VERBATIM_TAIL = 20   # production default

# Key facts that should survive (grouped by importance)
KEY_FACTS = {
    "核心架构": [
        ("session持久化 active_session表",  ["active_session", "持久化", "进程重启"]),
        ("verbatim tail 20轮",              ["verbatim", "20轮", "verbatim_tail"]),
        ("压缩阈值 50%",                    ["50%", "COMPRESS_THRESHOLD", "0.50"]),
        ("结构化摘要 compress_for_session", ["compress_for_session_context", "结构化摘要"]),
        ("judge 在压缩时后台运行",          ["judge", "_compress_old_turns", "后台"]),
    ],
    "关键决策": [
        ("删除 history_memory 层",          ["history_memory", "删除", "dormant"]),
        ("recent 层统一 跨session",         ["recent", "跨session", "end_session"]),
        ("core_memory 可配置维度",          ["DimensionConfig", "ContextConfig", "dimensions"]),
        ("不实现 forget() API",             ["forget", "decay", "遗忘"]),
        ("temperature=0.6 修复",            ["temperature", "0.6", "kimi"]),
    ],
    "测试结论": [
        ("75 个单元测试全通过",             ["75", "passed", "单元测试"]),
        ("集成测试 6次压缩触发",            ["6次", "6 compression", "压缩"]),
        ("生产模拟无需100轮",               ["100轮", "生产", "成本"]),
    ],
}


# ── parser (same as chain test) ───────────────────────────────────────────────

def parse_conversation(path: Path) -> list[dict]:
    text = path.read_text(encoding="utf-8")
    turns = []
    segments = re.split(r'\n(?=❯ |⏺ )', text)
    for seg in segments:
        seg = seg.strip()
        if not seg:
            continue
        if seg.startswith("❯ "):
            content = seg[2:].strip()
            if content.startswith("/") or len(content) < 10:
                continue
            content = re.sub(r'\s*⎿.*', '', content, flags=re.DOTALL).strip()
            if content:
                turns.append({"role": "user", "content": content})
        elif seg.startswith("⏺ "):
            content = seg[2:].strip()
            if re.match(r'^(Update|Read|Write|Edit|Bash|Glob|Grep)\(', content):
                continue
            content = re.sub(r'\n⏺ (Update|Read|Write|Edit|Bash|Glob|Grep)\(.*',
                             '', content, flags=re.DOTALL).strip()
            content = re.sub(r'\s*⎿.*', '', content, flags=re.DOTALL).strip()
            if content and len(content) > 20:
                turns.append({"role": "assistant", "content": content})
    return turns


def check_facts(text: str, groups: dict) -> dict:
    text_lower = text.lower()
    results = {}
    for group, facts in groups.items():
        results[group] = {}
        for label, keywords in facts:
            results[group][label] = any(kw.lower() in text_lower for kw in keywords)
    return results


def group_survival(results: dict) -> dict:
    return {
        group: sum(v.values()) / len(v)
        for group, v in results.items()
    }


class Logger:
    def __init__(self):
        self.lines = []

    def log(self, text: str = ""):
        print(text)
        self.lines.append(text)

    def save(self, path: Path):
        path.write_text("\n".join(self.lines), encoding="utf-8")


# ── main ─────────────────────────────────────────────────────────────────────

def run():
    log = Logger()
    client = OpenAI(api_key=API_KEY, base_url="https://api.moonshot.cn/v1")

    log.log("=" * 70)
    log.log("PRODUCTION COMPRESSION SIMULATION")
    log.log(f"verbatim_tail={VERBATIM_TAIL} turns  |  ONE compression event")
    log.log("=" * 70)

    # ── Parse & split ──────────────────────────────────────────────────────
    turns = parse_conversation(INPUT_FILE)
    log.log(f"\nParsed {len(turns)} turns total")

    tail_msgs  = VERBATIM_TAIL * 2   # user+assistant pairs
    old_turns  = turns[:-tail_msgs] if len(turns) > tail_msgs else turns
    tail_turns = turns[-tail_msgs:]  if len(turns) > tail_msgs else []

    old_text  = "\n".join(f"{t['role']}: {t['content']}" for t in old_turns)
    tail_text = "\n".join(f"{t['role']}: {t['content']}" for t in tail_turns)

    old_tokens  = count_tokens(old_text)
    tail_tokens = count_tokens(tail_text)

    log.log(f"Old content (to compress): {len(old_turns)} turns = {old_tokens:,} tokens")
    log.log(f"Verbatim tail (kept):      {len(tail_turns)} turns = {tail_tokens:,} tokens")

    # ── Baseline fact check on old content ────────────────────────────────
    baseline = check_facts(old_text, KEY_FACTS)
    log.log("\n── Baseline: facts present in old content ──")
    for group, facts in baseline.items():
        rate = sum(facts.values()) / len(facts)
        log.log(f"  {group}: {rate:.0%}")
        for label, found in facts.items():
            log.log(f"    {'✅' if found else '⚠️ '} {label}")

    # ── ONE production compression ─────────────────────────────────────────
    log.log(f"\n── Compressing {old_tokens:,} tokens → structured summary ──")
    summary = compress_session_context(old_text, api_key=API_KEY)
    summary_tokens = count_tokens(summary)
    ratio = summary_tokens / old_tokens

    log.log(f"Summary: {summary_tokens} tokens  (ratio={ratio:.1%})")
    log.log(f"\n── Full summary output ──")
    log.log(summary)

    # ── Fact survival check ────────────────────────────────────────────────
    summary_facts = check_facts(summary, KEY_FACTS)
    log.log("\n── Fact survival in summary ──")
    total_found = total_checked = 0
    for group, facts in summary_facts.items():
        # Only check facts that were present in original old content
        original = baseline[group]
        relevant = {label: found for label, found in facts.items()
                    if original.get(label)}
        if not relevant:
            continue
        rate = sum(relevant.values()) / len(relevant)
        total_found += sum(relevant.values())
        total_checked += len(relevant)
        log.log(f"  {group}: {rate:.0%} ({sum(relevant.values())}/{len(relevant)})")
        for label, found in relevant.items():
            log.log(f"    {'✅' if found else '❌'} {label}")

    overall_survival = total_found / total_checked if total_checked else 0

    # ── Recall test: LLM answers using [summary + verbatim tail] ──────────
    log.log("\n── Recall test: LLM with [summary + verbatim tail] only ──")

    context_msgs = [
        {"role": "system",
         "content": f"以下是之前对话的结构化摘要和最近的对话记录，请基于这些内容回答问题。\n\n[对话摘要]\n{summary}"},
    ]
    # Add verbatim tail
    for t in tail_turns:
        context_msgs.append({"role": t["role"], "content": t["content"]})

    context_tokens = count_messages_tokens(context_msgs)
    log.log(f"Context for recall test: {context_tokens:,} tokens "
            f"(summary + {len(tail_turns)} verbatim msgs)")

    RECALL_QUESTIONS = [
        ("session持久化方案是什么？为什么要做这个改动？",
         ["active_session", "持久化", "进程重启", "sqlite"]),
        ("history_memory层为什么被删除？",
         ["dormant", "删除", "复杂", "history"]),
        ("judge在哪个位置运行？为什么选这个位置？",
         ["_compress_old_turns", "压缩", "后台", "judge"]),
        ("core memory的维度如何配置？",
         ["DimensionConfig", "ContextConfig", "config", "维度"]),
    ]

    recall_pass = 0
    for q, keywords in RECALL_QUESTIONS:
        msgs = context_msgs + [{"role": "user", "content": q}]
        resp = client.chat.completions.create(
            model="kimi-k2.5",
            messages=msgs,
            max_tokens=300,
            temperature=0.6,
            extra_body={"thinking": {"type": "disabled"}},
        )
        answer = resp.choices[0].message.content
        hits = [kw for kw in keywords if kw.lower() in answer.lower()]
        passed = len(hits) >= len(keywords) * 0.5
        if passed:
            recall_pass += 1
        log.log(f"\n  Q: {q}")
        log.log(f"  A: {answer[:250].replace(chr(10), ' ')}...")
        log.log(f"  {'✅ PASS' if passed else '❌ FAIL'}  keywords hit: {hits}")

    recall_rate = recall_pass / len(RECALL_QUESTIONS)

    # ── Final verdict ──────────────────────────────────────────────────────
    log.log("\n" + "=" * 70)
    log.log("RESULTS")
    log.log("=" * 70)
    log.log(f"  Old content compressed:  {old_tokens:,} tokens → {summary_tokens} tokens ({ratio:.1%})")
    log.log(f"  Keyword survival:        {overall_survival:.0%} ({total_found}/{total_checked})")
    log.log(f"  Recall test:             {recall_pass}/{len(RECALL_QUESTIONS)} passed ({recall_rate:.0%})")

    if overall_survival >= 0.7 and recall_rate >= 0.75:
        verdict = "✅ PASS — production compression is stable"
    elif overall_survival >= 0.5 and recall_rate >= 0.5:
        verdict = "⚠️  ACCEPTABLE — some detail loss but core decisions preserved"
    else:
        verdict = "❌ FAIL — compression loses too much critical information"

    log.log(f"\n  Verdict: {verdict}")
    log.log(f"  Results saved to: {OUTPUT_FILE}")
    log.log("=" * 70)

    log.save(OUTPUT_FILE)
    return overall_survival >= 0.5 and recall_rate >= 0.5


if __name__ == "__main__":
    success = run()
    sys.exit(0 if success else 1)
