"""Tests for ContextManager — the core session continuity logic."""
import sqlite3
import tempfile
import time
import pytest
from unittest.mock import MagicMock, patch
from openai import OpenAI

from chatmem.context_manager import ContextManager, COMPRESS_THRESHOLD
from chatmem.config import ContextConfig, LLMConfig, DimensionConfig


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_fake_response(content: str = "assistant reply"):
    resp = MagicMock()
    resp.choices[0].message.content = content
    return resp


def _make_cm(db_path: str, context_window: int = 128_000, verbatim_tail: int = 4) -> ContextManager:
    """Create a ContextManager with mocked OpenAI client."""
    client = MagicMock(spec=OpenAI)
    client.chat.completions.create.return_value = _make_fake_response()
    config = ContextConfig(llm=LLMConfig(model="gpt-4o-mini", context_window=context_window))
    cm = ContextManager(
        client=client,
        api_key="test",
        db_path=db_path,
        verbatim_tail=verbatim_tail,
        config=config,
    )
    # Patch compressor to avoid real API calls
    cm.compressor.compress_for_session_context = MagicMock(
        return_value="【话题】测试\n【决策】完成\n【进展】进行中"
    )
    cm.compressor.compress_for_recent_memory = MagicMock(return_value="摘要")
    # Patch judge to avoid real API calls
    cm.core_memory.judge_and_update = MagicMock(return_value=[])
    return cm


@pytest.fixture
def db():
    with tempfile.NamedTemporaryFile(suffix=".db") as f:
        yield f.name


@pytest.fixture
def cm(db):
    return _make_cm(db)


# ---------------------------------------------------------------------------
# _build_context
# ---------------------------------------------------------------------------

def test_build_context_includes_current_message(cm):
    msgs = [{"role": "user", "content": "hello"}]
    result = cm._build_context(msgs)
    contents = [m["content"] for m in result]
    assert any("hello" in c for c in contents)


def test_build_context_includes_history(cm, db):
    cm._history = [
        {"role": "user",      "content": "previous question"},
        {"role": "assistant", "content": "previous answer"},
    ]
    result = cm._build_context([{"role": "user", "content": "new question"}])
    contents = [m["content"] for m in result]
    assert any("previous question" in c for c in contents)
    assert any("previous answer" in c for c in contents)


def test_build_context_strips_internal_keys(cm):
    cm._history = [{"role": "system", "content": "summary", "_is_summary": True}]
    result = cm._build_context([{"role": "user", "content": "hi"}])
    for msg in result:
        assert "_is_summary" not in msg


def test_build_context_with_system_prompt(cm):
    msgs = [
        {"role": "system",  "content": "You are helpful."},
        {"role": "user",    "content": "hi"},
    ]
    result = cm._build_context(msgs)
    assert result[0]["role"] == "system"
    assert "You are helpful." in result[0]["content"]


def test_build_context_with_core_memory(cm):
    cm.core_memory.set("lang", "Python", dimension="capabilities")
    result = cm._build_context([{"role": "user", "content": "hi"}])
    system_content = result[0]["content"]
    assert "Python" in system_content


def test_build_context_with_recent_memory(cm, db):
    cm.recent_memory.add(turn_id=1, compressed_content="上次会话：讨论了API设计")
    result = cm._build_context([{"role": "user", "content": "继续"}])
    system_content = result[0]["content"]
    assert "API设计" in system_content


# ---------------------------------------------------------------------------
# _post_turn / history growth
# ---------------------------------------------------------------------------

def test_post_turn_appends_to_history(cm):
    cm._post_turn("user msg", "assistant reply", [])
    assert len(cm._history) == 2
    assert cm._history[0]["role"] == "user"
    assert cm._history[1]["role"] == "assistant"


def test_post_turn_increments_turn_count(cm):
    assert cm._turn_count == 0
    cm._post_turn("u", "a", [])
    assert cm._turn_count == 1


def test_post_turn_persists_to_db(cm, db):
    cm._post_turn("user says hi", "assistant replies", [])
    with sqlite3.connect(db) as conn:
        rows = conn.execute("SELECT * FROM active_session").fetchall()
    assert len(rows) == 2


# ---------------------------------------------------------------------------
# Session persistence
# ---------------------------------------------------------------------------

def test_restore_history_on_init(db):
    cm1 = _make_cm(db)
    cm1._post_turn("persisted user msg", "persisted assistant reply", [])

    # New instance on same DB should restore history
    cm2 = _make_cm(db)
    assert len(cm2._history) == 2
    assert cm2._history[0]["content"] == "persisted user msg"


def test_restore_history_includes_summaries(db):
    cm1 = _make_cm(db)
    # Manually insert a summary message
    cm1._history = [
        {"role": "system", "content": "[对话摘要]\n摘要内容", "_is_summary": True},
        {"role": "user",   "content": "recent user"},
    ]
    cm1._persist_history()

    cm2 = _make_cm(db)
    assert cm2._history[0].get("_is_summary") is True
    assert cm2._history[1]["content"] == "recent user"


def test_restore_turn_count(db):
    cm1 = _make_cm(db)
    cm1._post_turn("q1", "a1", [])
    cm1._post_turn("q2", "a2", [])

    cm2 = _make_cm(db)
    assert cm2._turn_count == 2


def test_empty_db_gives_empty_history(db):
    cm = _make_cm(db)
    assert cm._history == []
    assert cm._turn_count == 0


# ---------------------------------------------------------------------------
# Compression
# ---------------------------------------------------------------------------

def test_compress_old_turns_reduces_history(db):
    cm = _make_cm(db, context_window=1000, verbatim_tail=2)
    # Add enough history to exceed threshold
    for i in range(10):
        cm._history.append({"role": "user",      "content": f"question {i} " * 20})
        cm._history.append({"role": "assistant", "content": f"answer {i} "   * 20})
    before = len(cm._history)
    cm._compress_old_turns(turn_id=10)
    after = len(cm._history)
    assert after < before


def test_compress_replaces_old_with_summary(db):
    cm = _make_cm(db, context_window=1000, verbatim_tail=2)
    for i in range(6):
        cm._history.append({"role": "user",      "content": f"q{i}"})
        cm._history.append({"role": "assistant", "content": f"a{i}"})
    cm._compress_old_turns(turn_id=6)
    # First message should be summary
    assert cm._history[0].get("_is_summary") is True
    assert "[对话摘要]" in cm._history[0]["content"]


def test_compress_keeps_verbatim_tail(db):
    cm = _make_cm(db, context_window=1000, verbatim_tail=2)
    tail_msgs = [
        {"role": "user",      "content": "tail user"},
        {"role": "assistant", "content": "tail assistant"},
    ]
    for i in range(4):
        cm._history.append({"role": "user",      "content": f"old {i}"})
        cm._history.append({"role": "assistant", "content": f"old reply {i}"})
    cm._history += tail_msgs
    cm._compress_old_turns(turn_id=5)
    tail_contents = [m["content"] for m in cm._history[-2:]]
    assert "tail user" in tail_contents
    assert "tail assistant" in tail_contents


def test_compress_triggers_judge_in_background(db):
    cm = _make_cm(db, context_window=1000, verbatim_tail=2)
    for i in range(6):
        cm._history.append({"role": "user",      "content": f"q{i}"})
        cm._history.append({"role": "assistant", "content": f"a{i}"})

    with patch("chatmem.context_manager.threading.Thread") as mock_thread:
        mock_thread.return_value.start = MagicMock()
        cm._compress_old_turns(turn_id=6)
        mock_thread.assert_called()


def test_maybe_compress_triggers_at_threshold(db):
    cm = _make_cm(db, context_window=1000, verbatim_tail=2)
    cm._last_context_tokens = 600  # > 50% of 1000
    for i in range(6):
        cm._history.append({"role": "user",      "content": f"q{i}"})
        cm._history.append({"role": "assistant", "content": f"a{i}"})
    with patch.object(cm, "_compress_old_turns") as mock_compress:
        cm._maybe_compress(turn_id=1)
        mock_compress.assert_called_once()


def test_maybe_compress_skips_below_threshold(db):
    cm = _make_cm(db, context_window=1000, verbatim_tail=2)
    cm._last_context_tokens = 400  # < 50%
    with patch.object(cm, "_compress_old_turns") as mock_compress:
        cm._maybe_compress(turn_id=1)
        mock_compress.assert_not_called()


# ---------------------------------------------------------------------------
# end_session
# ---------------------------------------------------------------------------

def test_end_session_resets_history(cm):
    cm._history = [
        {"role": "user",      "content": "something"},
        {"role": "assistant", "content": "reply"},
    ]
    cm.end_session()
    assert cm._history == []


def test_end_session_resets_turn_count(cm):
    cm._turn_count = 5
    cm.end_session()
    assert cm._turn_count == 0


def test_end_session_clears_active_session_db(cm, db):
    cm._post_turn("u", "a", [])
    cm.end_session()
    with sqlite3.connect(db) as conn:
        rows = conn.execute("SELECT * FROM active_session").fetchall()
    assert len(rows) == 0


def test_end_session_saves_summary_blocks_to_recent(cm):
    cm._history = [
        {"role": "system",    "content": "[对话摘要]\n摘要块1", "_is_summary": True},
        {"role": "user",      "content": "recent user"},
        {"role": "assistant", "content": "recent reply"},
    ]
    cm.end_session()
    recent = cm.recent_memory.get_for_context()
    assert "摘要块1" in recent


def test_end_session_compresses_verbatim_tail(cm):
    cm._history = [
        {"role": "user",      "content": "only verbatim"},
        {"role": "assistant", "content": "verbatim reply"},
    ]
    cm.end_session()
    cm.compressor.compress_for_session_context.assert_called_once()


def test_end_session_calls_judge_on_verbatim(cm):
    cm._history = [
        {"role": "user",      "content": "I love Python"},
        {"role": "assistant", "content": "Great choice!"},
    ]
    cm.end_session()
    cm.core_memory.judge_and_update.assert_called_once()


def test_end_session_skips_judge_when_only_summaries(cm):
    cm._history = [
        {"role": "system", "content": "[对话摘要]\n摘要", "_is_summary": True},
    ]
    cm.end_session()
    cm.core_memory.judge_and_update.assert_not_called()


# ---------------------------------------------------------------------------
# Idle timeout — must NOT call end_session
# ---------------------------------------------------------------------------

def test_idle_timeout_preserves_history(db):
    cm = _make_cm(db, context_window=128_000)
    cm.idle_session_timeout = 1  # 1 second timeout

    # Add history
    cm._history = [
        {"role": "user",      "content": "question"},
        {"role": "assistant", "content": "answer"},
    ]
    cm._last_chat_time = time.time() - 5  # 5 seconds ago → exceeds timeout

    # Patch tracker to avoid real API call
    cm.client.chat.completions.create = MagicMock(return_value=_make_fake_response("new reply"))

    with patch.object(cm, "end_session") as mock_end:
        cm.chat([{"role": "user", "content": "resumed"}])
        mock_end.assert_not_called()

    # History should still contain old messages
    history_contents = [m["content"] for m in cm._history]
    assert "question" in history_contents


# ---------------------------------------------------------------------------
# chat() integration
# ---------------------------------------------------------------------------

def test_chat_returns_response(cm):
    cm.client.chat.completions.create = MagicMock(return_value=_make_fake_response("hello back"))
    resp = cm.chat([{"role": "user", "content": "hello"}])
    assert resp.choices[0].message.content == "hello back"


def test_chat_updates_history(cm):
    cm.client.chat.completions.create = MagicMock(return_value=_make_fake_response("response"))
    cm.chat([{"role": "user", "content": "input"}])
    assert any(m["content"] == "input"    for m in cm._history)
    assert any(m["content"] == "response" for m in cm._history)


def test_chat_persists_after_each_turn(db):
    cm = _make_cm(db)
    cm.client.chat.completions.create = MagicMock(return_value=_make_fake_response("reply"))
    cm.chat([{"role": "user", "content": "persisted?"}])
    with sqlite3.connect(db) as conn:
        rows = conn.execute("SELECT content FROM active_session").fetchall()
    contents = [r[0] for r in rows]
    assert "persisted?" in contents


# ---------------------------------------------------------------------------
# remember() convenience method
# ---------------------------------------------------------------------------

def test_remember_writes_to_core_memory(cm):
    cm.remember("project", "chatmem", dimension="goals")
    assert cm.core_memory.get("project") == "chatmem"
