"""
Compression chain stability test.
Uses the exported real conversation to test how well structured summaries
preserve key facts through multiple chained compression rounds.

Usage:
    python3 tests/test_compression_chain.py

Output saved to: tests/compression_chain_result.txt
"""

import os
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from chatmem.compressor import compress_session_context
from chatmem.token_counter import count_tokens

# ── config ───────────────────────────────────────────────────────────────────
API_KEY       = os.environ["MOONSHOT_API_KEY"]
INPUT_FILE    = Path(__file__).parent.parent / "conxxxxx.txt"
OUTPUT_FILE   = Path(__file__).parent / "compression_chain_result.txt"
CHUNK_TURNS   = 8   # compress every 8 user+assistant turn pairs

# Key facts that should survive compression — drawn from the real conversation
KEY_FACTS = [
    # Architecture decisions
    ("session持久化",        ["active_session", "active_session表", "持久化"]),
    ("verbatim_tail",        ["verbatim_tail", "verbatim tail", "20轮"]),
    ("压缩阈值50%",          ["COMPRESS_THRESHOLD", "50%", "0.50"]),
    ("结构化摘要",           ["compress_for_session_context", "结构化摘要", "SESSION_CONTEXT"]),
    ("judge位置",            ["_compress_old_turns", "压缩时", "后台"]),
    # Removed modules
    ("删除history_memory",   ["history_memory", "HistoryMemory", "删除"]),
    ("删除rank_bm25",        ["rank-bm25", "rank_bm25", "numpy"]),
    # Design decisions
    ("recent层统一",         ["recent_memory", "recent层", "跨session"]),
    ("core_memory维度",      ["DIMENSIONS", "dimensions", "DimensionConfig"]),
    ("可配置维度",           ["ContextConfig", "from_json", "config"]),
    # Test results
    ("集成测试压缩次数",     ["6次", "6 compression", "compression events"]),
    ("temperature修复",      ["temperature=0.6", "temperature", "0.3"]),
]


# ── parser ───────────────────────────────────────────────────────────────────

def parse_conversation(path: Path) -> list[dict]:
    """
    Parse Claude Code export format into list of {role, content} dicts.
    Skips tool use outputs, keeps user messages and assistant text responses.
    """
    text = path.read_text(encoding="utf-8")
    turns = []

    # Split on turn boundaries
    # User turns start with ❯, assistant turns start with ⏺
    segments = re.split(r'\n(?=❯ |⏺ )', text)

    for seg in segments:
        seg = seg.strip()
        if not seg:
            continue

        if seg.startswith("❯ "):
            content = seg[2:].strip()
            # Skip slash commands and very short messages
            if content.startswith("/") or len(content) < 10:
                continue
            # Remove tool output annotations
            content = re.sub(r'\s*⎿.*', '', content, flags=re.DOTALL).strip()
            if content:
                turns.append({"role": "user", "content": content})

        elif seg.startswith("⏺ "):
            content = seg[2:].strip()
            # Skip pure tool-use lines (Update/Read/Write/Edit/Bash etc.)
            if re.match(r'^(Update|Read|Write|Edit|Bash|Glob|Grep)\(', content):
                continue
            # Remove tool output annotations
            content = re.sub(r'\n⏺ (Update|Read|Write|Edit|Bash|Glob|Grep)\(.*', '',
                             content, flags=re.DOTALL).strip()
            content = re.sub(r'\s*⎿.*', '', content, flags=re.DOTALL).strip()
            if content and len(content) > 20:
                turns.append({"role": "assistant", "content": content})

    return turns


def chunk_turns(turns: list[dict], chunk_size: int) -> list[list[dict]]:
    """Split turns into chunks of chunk_size pairs."""
    chunks = []
    i = 0
    while i < len(turns):
        chunks.append(turns[i:i + chunk_size * 2])
        i += chunk_size * 2
    return [c for c in chunks if c]


# ── fact checker ─────────────────────────────────────────────────────────────

def check_facts(text: str, facts: list[tuple]) -> dict:
    text_lower = text.lower()
    results = {}
    for label, keywords in facts:
        found = any(kw.lower() in text_lower for kw in keywords)
        results[label] = found
    return results


def survival_rate(fact_results: dict) -> float:
    if not fact_results:
        return 0.0
    return sum(fact_results.values()) / len(fact_results)


# ── main ─────────────────────────────────────────────────────────────────────

class Logger:
    def __init__(self):
        self.lines = []

    def log(self, text: str = ""):
        print(text)
        self.lines.append(text)

    def save(self, path: Path):
        path.write_text("\n".join(self.lines), encoding="utf-8")


def run():
    log = Logger()

    log.log("=" * 70)
    log.log("COMPRESSION CHAIN STABILITY TEST")
    log.log(f"Input: {INPUT_FILE.name}")
    log.log("=" * 70)

    # ── Parse ──────────────────────────────────────────────────────────────
    turns = parse_conversation(INPUT_FILE)
    log.log(f"\nParsed {len(turns)} turns from conversation")

    if len(turns) < 4:
        log.log("ERROR: not enough turns parsed")
        log.save(OUTPUT_FILE)
        return False

    chunks = chunk_turns(turns, CHUNK_TURNS)
    log.log(f"Chunked into {len(chunks)} groups of ~{CHUNK_TURNS} pairs")

    # ── Build full text for baseline fact check ─────────────────────────────
    full_text = "\n".join(f"{t['role']}: {t['content']}" for t in turns)
    baseline = check_facts(full_text, KEY_FACTS)
    baseline_rate = survival_rate(baseline)
    log.log(f"\nBaseline (full conversation) — {baseline_rate:.0%} facts present:")
    for label, found in baseline.items():
        log.log(f"  {'✅' if found else '⚠️ '} {label}")

    facts_in_original = {label for label, found in baseline.items() if found}

    # ── Compression chain ───────────────────────────────────────────────────
    log.log(f"\n── Compression chain ({len(chunks)} rounds) ──")

    running_summary = ""
    round_results = []

    for i, chunk in enumerate(chunks):
        round_num = i + 1
        chunk_text = "\n".join(f"{t['role']}: {t['content']}" for t in chunk)
        chunk_tokens = count_tokens(chunk_text)

        # Combine previous summary with new chunk
        if running_summary:
            combined = f"[前轮摘要]\n{running_summary}\n\n[新内容]\n{chunk_text}"
        else:
            combined = chunk_text

        combined_tokens = count_tokens(combined)
        log.log(f"\n[Round {round_num}] input={combined_tokens} tokens "
                f"(summary={count_tokens(running_summary)} + chunk={chunk_tokens})")

        # Compress
        running_summary = compress_session_context(combined, api_key=API_KEY)
        summary_tokens = count_tokens(running_summary)

        log.log(f"  → summary={summary_tokens} tokens  "
                f"(ratio={summary_tokens/combined_tokens:.1%})")
        log.log(f"  Summary preview: {running_summary[:200].replace(chr(10), ' ')}...")

        # Check fact survival (only facts present in original)
        facts = check_facts(running_summary, KEY_FACTS)
        surviving = {label: found for label, found in facts.items()
                     if label in facts_in_original}
        rate = survival_rate(surviving)
        round_results.append((round_num, rate, surviving, summary_tokens))

        log.log(f"  Fact survival: {rate:.0%} "
                f"({sum(surviving.values())}/{len(surviving)})")
        for label, found in surviving.items():
            if not found:
                log.log(f"    ❌ lost: {label}")

    # ── Final summary ───────────────────────────────────────────────────────
    log.log("\n" + "=" * 70)
    log.log("COMPRESSION CHAIN RESULTS")
    log.log("=" * 70)
    log.log(f"\n{'Round':<8} {'Survival':<12} {'Summary tokens':<18} {'Lost facts'}")
    log.log("-" * 60)
    for round_num, rate, surviving, summary_tokens in round_results:
        lost = [label for label, found in surviving.items() if not found]
        log.log(f"  {round_num:<6} {rate:<12.0%} {summary_tokens:<18} "
                f"{', '.join(lost) if lost else '—'}")

    final_rate = round_results[-1][1] if round_results else 0.0
    degradation = baseline_rate - final_rate

    log.log(f"\nBaseline:          {baseline_rate:.0%}")
    log.log(f"After {len(chunks)} rounds:   {final_rate:.0%}")
    log.log(f"Degradation:       {degradation:.0%}")

    if degradation <= 0.15:
        verdict = "✅ STABLE — compression chain preserves information well"
    elif degradation <= 0.30:
        verdict = "⚠️  MODERATE LOSS — acceptable for long sessions"
    else:
        verdict = "❌ UNSTABLE — summary prompt needs improvement"

    log.log(f"\nVerdict: {verdict}")
    log.log(f"\nFull results saved to: {OUTPUT_FILE}")
    log.log("=" * 70)

    log.save(OUTPUT_FILE)
    return degradation <= 0.30


if __name__ == "__main__":
    success = run()
    sys.exit(0 if success else 1)
