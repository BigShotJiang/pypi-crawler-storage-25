"""Tests for CoreMemory."""
import tempfile
import pytest
from unittest.mock import patch, MagicMock
from chatmem.memory.core_memory import CoreMemory, _build_judge_prompt
from chatmem.config import ContextConfig, DimensionConfig


@pytest.fixture
def db():
    with tempfile.NamedTemporaryFile(suffix=".db") as f:
        yield f.name


@pytest.fixture
def mem(db):
    return CoreMemory(db, api_key="test")


def test_set_and_get(mem):
    mem.set("lang", "Python", dimension="capabilities")
    assert mem.get("lang") == "Python"


def test_overwrite_same_key(mem):
    mem.set("lang", "Python")
    mem.set("lang", "Go")
    assert mem.get("lang") == "Go"


def test_get_nonexistent(mem):
    assert mem.get("nonexistent") is None


def test_get_all(mem):
    mem.set("k1", "v1", dimension="identity")
    mem.set("k2", "v2", dimension="preferences")
    entries = mem.get_all()
    keys = [e["key"] for e in entries]
    assert "k1" in keys and "k2" in keys


def test_to_context_string_empty(mem):
    assert mem.to_context_string() == ""


def test_to_context_string_grouped(mem):
    mem.set("job", "engineer", dimension="identity")
    mem.set("likes", "coffee", dimension="preferences")
    s = mem.to_context_string()
    assert "[核心记忆]" in s
    assert "engineer" in s
    assert "coffee" in s


def test_custom_dimensions_in_context_string(db):
    cfg = ContextConfig(dimensions={
        "domain": DimensionConfig(label="专业领域", stability=40.0),
        "style":  DimensionConfig(label="风格偏好", stability=25.0),
    })
    mem = CoreMemory(db, api_key="test", dimensions=cfg.dimensions)
    mem.set("field", "AI", dimension="domain")
    s = mem.to_context_string()
    assert "专业领域" in s
    assert "AI" in s


def test_unknown_dimension_falls_back(db):
    cfg = ContextConfig(dimensions={
        "domain": DimensionConfig(label="专业领域", stability=40.0),
    })
    mem = CoreMemory(db, api_key="test", dimensions=cfg.dimensions)
    # Writing with unknown dimension falls back to first dimension
    mem.set("key", "val", dimension="nonexistent_dim")
    entries = mem.get_all()
    assert len(entries) == 1


def test_judge_prompt_contains_custom_dimensions(db):
    cfg = ContextConfig(dimensions={
        "hobby": DimensionConfig(label="兴趣爱好", stability=20.0),
        "work":  DimensionConfig(label="工作领域", stability=35.0),
    })
    mem = CoreMemory(db, api_key="test", dimensions=cfg.dimensions)
    assert "hobby" in mem._judge_prompt
    assert "work" in mem._judge_prompt
    assert "兴趣爱好" in mem._judge_prompt


def test_judge_prompt_does_not_contain_removed_dimensions(db):
    cfg = ContextConfig(dimensions={
        "custom": DimensionConfig(label="自定义", stability=25.0),
    })
    mem = CoreMemory(db, api_key="test", dimensions=cfg.dimensions)
    # Default dimensions like "identity" should not appear
    assert "identity" not in mem._judge_prompt
    assert "autobiography" not in mem._judge_prompt


def test_judge_and_update_writes_entries(db):
    mem = CoreMemory(db, api_key="test")
    mock_resp = MagicMock()
    mock_resp.choices[0].message.content = (
        '[{"key": "language", "value": "Python", "dimension": "capabilities"}]'
    )
    with patch("chatmem.memory.core_memory.OpenAI") as MockOpenAI:
        MockOpenAI.return_value.chat.completions.create.return_value = mock_resp
        written = mem.judge_and_update("user: I mostly code in Python")
    assert len(written) == 1
    assert mem.get("language") == "Python"


def test_judge_and_update_returns_empty_on_no_facts(db):
    mem = CoreMemory(db, api_key="test")
    mock_resp = MagicMock()
    mock_resp.choices[0].message.content = "[]"
    with patch("chatmem.memory.core_memory.OpenAI") as MockOpenAI:
        MockOpenAI.return_value.chat.completions.create.return_value = mock_resp
        written = mem.judge_and_update("user: what's the weather like?")
    assert written == []


def test_update_score(mem):
    mem.set("k", "v")
    mem.update_score("k", 0.05)
    # score < 0.1 → not returned by get_all
    assert mem.get("k") is None


def test_get_all_with_scores(mem):
    mem.set("k", "v")
    rows = mem.get_all_with_scores()
    assert any(r["key"] == "k" for r in rows)
