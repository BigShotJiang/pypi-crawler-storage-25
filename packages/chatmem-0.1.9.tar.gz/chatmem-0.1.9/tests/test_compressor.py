"""Tests for Compressor paths."""
import pytest
from unittest.mock import patch, MagicMock
from chatmem.compressor import (
    Compressor, _is_chinese_narrative,
    compress_llm_summary, compress_session_context,
)


def test_is_chinese_narrative_pure_chinese():
    text = "今天天气很好，我们去公园散步，看到了很多花朵，心情愉快。"
    assert _is_chinese_narrative(text) is True


def test_is_chinese_narrative_with_code():
    text = "```python\ndef hello(): pass\n``` 这是代码示例"
    assert _is_chinese_narrative(text) is False


def test_is_chinese_narrative_english():
    text = "The quick brown fox jumps over the lazy dog."
    assert _is_chinese_narrative(text) is False


def test_is_chinese_narrative_mixed_technical():
    text = "用户使用 API 调用了 http://example.com 接口，返回了 JSON 数据。"
    assert _is_chinese_narrative(text) is False


def _make_mock_response(content: str):
    resp = MagicMock()
    resp.choices[0].message.content = content
    return resp


def test_compress_llm_summary_calls_api():
    mock_resp = _make_mock_response("用户决定使用Python。")
    with patch("chatmem.compressor._make_client") as mock_client:
        mock_client.return_value.chat.completions.create.return_value = mock_resp
        result = compress_llm_summary("很长的对话内容...", api_key="test")
    assert result == "用户决定使用Python。"


def test_compress_session_context_calls_api():
    summary = "【话题】架构设计\n【决策】使用微服务\n【进展】完成了接口定义"
    mock_resp = _make_mock_response(summary)
    with patch("chatmem.compressor._make_client") as mock_client:
        mock_client.return_value.chat.completions.create.return_value = mock_resp
        result = compress_session_context("很长的对话...", api_key="test")
    assert "架构设计" in result


def test_compress_empty_text_returns_empty():
    c = Compressor(api_key="test")
    with patch("chatmem.compressor.compress_llm_summary", return_value=""):
        result = c.compress_for_recent_memory("   ")
    # Empty text short-circuits before API call
    assert result == "   " or result == ""


def test_compressor_compress_for_session_context():
    c = Compressor(api_key="test")
    mock_resp = _make_mock_response("【话题】测试\n【决策】通过")
    with patch("chatmem.compressor._make_client") as mock_client:
        mock_client.return_value.chat.completions.create.return_value = mock_resp
        result = c.compress_for_session_context("对话内容")
    assert "测试" in result


def test_compressor_compress_for_recent_memory():
    c = Compressor(api_key="test")
    mock_resp = _make_mock_response("用户偏好Go语言。")
    with patch("chatmem.compressor._make_client") as mock_client:
        mock_client.return_value.chat.completions.create.return_value = mock_resp
        result = c.compress_for_recent_memory("很长内容")
    assert result == "用户偏好Go语言。"
