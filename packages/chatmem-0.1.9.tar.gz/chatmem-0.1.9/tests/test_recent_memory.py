"""Tests for RecentMemory."""
import tempfile
import pytest
from unittest.mock import MagicMock, patch
from chatmem.memory.recent_memory import RecentMemory
from chatmem.compressor import Compressor


@pytest.fixture
def db():
    with tempfile.NamedTemporaryFile(suffix=".db") as f:
        yield f.name


@pytest.fixture
def compressor():
    c = MagicMock(spec=Compressor)
    c.compress_for_session_context.return_value = "压缩摘要"
    c.compress_for_recent_memory.return_value = "极简摘要"
    return c


@pytest.fixture
def mem(db, compressor):
    return RecentMemory(db, compressor)


def test_add_and_get_for_context(mem):
    mem.add(turn_id=1, compressed_content="话题：Python。决策：使用fastapi。")
    result = mem.get_for_context()
    assert "fastapi" in result


def test_get_for_context_empty(mem):
    assert mem.get_for_context() == ""


def test_inject_token_cap(db, compressor):
    mem = RecentMemory(db, compressor, inject_token_cap=10)
    # Add content that far exceeds the cap
    mem.add(turn_id=1, compressed_content="A " * 200)
    mem.add(turn_id=2, compressed_content="B " * 200)
    result = mem.get_for_context()
    # Should only get one or zero entries within cap
    assert len(result) < len("A " * 200 + "B " * 200)


def test_newest_first_within_budget(db, compressor):
    mem = RecentMemory(db, compressor, inject_token_cap=500)
    mem.add(turn_id=1, compressed_content="旧的内容")
    mem.add(turn_id=2, compressed_content="新的内容")
    result = mem.get_for_context()
    # Both fit within budget, chronological order restored
    assert result.index("旧的内容") < result.index("新的内容")


def test_total_tokens(mem):
    mem.add(turn_id=1, compressed_content="some content here")
    assert mem.total_tokens() > 0


def test_remove(mem):
    mem.add(turn_id=1, compressed_content="要删除的内容")
    import sqlite3
    with sqlite3.connect(mem.db_path) as conn:
        row = conn.execute("SELECT id FROM recent_memory LIMIT 1").fetchone()
    mem.remove(row[0])
    assert mem.get_for_context() == ""


def test_compress_oldest_segment_on_budget_overflow(db, compressor):
    mem = RecentMemory(db, compressor)
    mem.TOKEN_BUDGET = 50  # very low budget for testing
    # Add entries that exceed budget
    for i in range(5):
        mem.add(turn_id=i, compressed_content=f"内容{i} " * 20)
    # compress_for_session_context should have been called
    compressor.compress_for_session_context.assert_called()


def test_multiple_sessions_accumulated(mem):
    mem.add(turn_id=10, compressed_content="第一次会话摘要")
    mem.add(turn_id=20, compressed_content="第二次会话摘要")
    result = mem.get_for_context()
    assert "第一次" in result
    assert "第二次" in result
