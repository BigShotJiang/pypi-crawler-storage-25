"""

OSM Route Screen library (OsmRouteScreenLib) v.0.0.6

The MIT License Copyright © 2026 Aleksandr Krasnov

"""

from .startup import *