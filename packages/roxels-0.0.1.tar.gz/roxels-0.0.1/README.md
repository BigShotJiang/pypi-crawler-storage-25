# Roxels

> **Under construction.** Roxels is in early access.

Roxels lets you create configurable AI voice agents that interact with your users via meeting rooms and return structured data. Define what you want to learn, embed the interview widget, and get structured JSON back via webhooks or API.

- **Website:** [roxels.ai](https://roxels.ai)
- **MCP Server:** `pip install roxels-mcp` — let AI agents manage Roxels programmatically
- **MCP Registry:** `ai.roxels/roxels-mcp`

This package is a namespace reservation. The SDK is coming soon.
