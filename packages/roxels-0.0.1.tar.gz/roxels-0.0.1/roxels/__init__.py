"""Roxels — configurable AI voice agents that return structured data. SDK coming soon."""

__version__ = "0.0.1"
