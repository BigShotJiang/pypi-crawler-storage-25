from collections.abc import Iterable
from itertools import chain
from uuid import uuid4

from cognite.client.data_classes import Row, RowWrite

from cognite_toolkit._cdf_tk.client.http_client import HTTPClient
from cognite_toolkit._cdf_tk.client.http_client._item_classes import ItemsRequest, ItemsResultList
from cognite_toolkit._cdf_tk.exceptions import ToolkitValueError
from cognite_toolkit._cdf_tk.resource_ios import RawDatabaseCRUD, RawTableCRUD
from cognite_toolkit._cdf_tk.utils import sanitize_filename
from cognite_toolkit._cdf_tk.utils.collection import chunker
from cognite_toolkit._cdf_tk.utils.fileio import MultiFileReader
from cognite_toolkit._cdf_tk.utils.useful_types import JsonVal

from ._base import (
    Bookmark,
    ConfigurableDataIO,
    DataItem,
    Page,
    StorageIOConfig,
    TableUploadableDataIO,
)
from .selectors import RawTableSelector


class RawIO(
    ConfigurableDataIO[RawTableSelector, Row],
    TableUploadableDataIO[RawTableSelector, Row, RowWrite],
):
    KIND = "RawRows"
    DISPLAY_NAME = "Raw Rows"
    CHUNK_SIZE = 10_000
    UPLOAD_ENDPOINT = "/raw/dbs/{dbName}/tables/{tableName}/rows"
    BASE_SELECTOR = RawTableSelector

    def count(self, selector: RawTableSelector) -> int | None:
        # Raw tables do not support aggregation queries, so we do not know the count
        # up front.
        return None

    def stream_data(
        self,
        selector: RawTableSelector,
        limit: int | None = None,
        bookmark: Bookmark | None = None,
    ) -> Iterable[Page]:
        for chunk in self.client.raw.rows(
            db_name=selector.table.db_name,
            table_name=selector.table.table_name,
            limit=limit,
            # We cannot use partitions here as it is not thread safe. This spawn multiple threads
            # that are not shut down until all data is downloaded. We need to be able to abort.
            partitions=None,
            chunk_size=self.CHUNK_SIZE,
        ):
            yield self.emit_registered_page(
                Page(
                    worker_id="main",
                    items=[DataItem(tracking_id=str(item.key), item=item) for item in chunk],
                )
            )

    def upload_items(
        self,
        data_chunk: Page[RowWrite],
        http_client: HTTPClient,
        selector: RawTableSelector | None = None,
    ) -> ItemsResultList:
        if selector is None:
            raise ToolkitValueError("Selector must be provided for RawIO upload_items")
        url = self.UPLOAD_ENDPOINT.format(dbName=selector.table.db_name, tableName=selector.table.table_name)
        config = http_client.config
        return http_client.request_items_retries(
            message=ItemsRequest(
                endpoint_url=config.create_api_url(url),
                method="POST",
                items=data_chunk.items,
            )
        )

    def data_to_json_chunk(
        self, data_chunk: Page[Row], selector: RawTableSelector | None = None
    ) -> Page[dict[str, JsonVal]]:
        result = [DataItem(tracking_id=item.tracking_id, item=item.item.as_write().dump()) for item in data_chunk.items]
        return data_chunk.create_from(result)

    def json_to_resource(self, item_json: dict[str, JsonVal]) -> RowWrite:
        return RowWrite._load(item_json)

    def configurations(self, selector: RawTableSelector) -> Iterable[StorageIOConfig]:
        yield StorageIOConfig(
            kind=RawDatabaseCRUD.kind,
            folder_name=RawDatabaseCRUD.folder_name,
            value={"dbName": selector.table.db_name},
            filename=sanitize_filename(selector.table.db_name),
        )
        yield StorageIOConfig(
            kind=RawTableCRUD.kind, folder_name=RawTableCRUD.folder_name, value=selector.table.model_dump(by_alias=True)
        )

    def row_to_resource(
        self, source_id: str, row: dict[str, JsonVal], selector: RawTableSelector | None = None
    ) -> RowWrite:
        key = str(uuid4())
        if selector is not None and selector.key is not None and selector.key in row:
            key = str(row.pop(selector.key))
        return RowWrite(key=key, columns=row)

    @classmethod
    def read_chunks(cls, reader: MultiFileReader, selector: RawTableSelector) -> Iterable[Page[dict[str, JsonVal]]]:
        if not reader.is_table or selector.key is None:
            yield from super().read_chunks(reader, selector)
            return
        data_name = "row" if reader.is_table else "line"
        # Validate that the key exists in all files
        for input_file in sorted(reader.input_files, key=reader._part_no):
            iterable = reader.reader_class(input_file).read_chunks()
            try:
                first = next(iterable)
            except StopIteration:
                continue
            if selector.key not in first:
                raise ToolkitValueError(
                    f"Column '{selector.key}' not found in file {input_file.as_posix()!r}. Please ensure the specified column exists."
                )
            full_iterator = chain([first], iterable)
            line_numbered_iterator = ((f"{data_name} {i}", row) for i, row in enumerate(full_iterator, start=1))
            for chunk in chunker(line_numbered_iterator, cls.CHUNK_SIZE):
                yield Page(
                    worker_id="main",
                    items=[DataItem(tracking_id=tracking_id, item=row) for tracking_id, row in chunk],
                )
