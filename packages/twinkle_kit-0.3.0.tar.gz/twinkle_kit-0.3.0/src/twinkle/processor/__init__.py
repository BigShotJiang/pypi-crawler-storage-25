# Copyright (c) ModelScope Contributors. All rights reserved.
from .base import InputProcessor
