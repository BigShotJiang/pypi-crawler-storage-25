try:
    from typing import Self  # Python 3.11+
except ImportError:
    from typing_extensions import Self  # Python <3.11

import logging

import numpy as np
from numpy import imag, pi, real, sqrt

from solrat.atom_model.base_atom_model.radiative_transfer_equations import BaseRTE
from solrat.atom_model.multi_term_atom_model.object.atmosphere_parameters import AtmosphereParameters
from solrat.atom_model.multi_term_atom_model.object.level_registry import Term
from solrat.atom_model.multi_term_atom_model.object.multi_term_atom_config import MultiTermAtomConfig
from solrat.atom_model.multi_term_atom_model.object.rho_matrix_builder import Rho
from solrat.atom_model.multi_term_atom_model.object.transition_registry import TransitionRegistry
from solrat.atom_model.multi_term_atom_model.utility.paschen_back import calculate_paschen_back
from solrat.atom_model.shared.object.angles import Angles
from solrat.atom_model.shared.object.radiative_transfer_coefficients import RadiativeTransferCoefficients
from solrat.atom_model.shared.object.rotations import T_K_Q_double_rotation, WignerD
from solrat.atom_model.shared.utility.constants import c_cm_sm1, h_erg_s, sqrt_pi
from solrat.atom_model.shared.utility.functions import energy_cmm1_to_frequency_hz
from solrat.atom_model.shared.utility.voigt_profile import voigt
from solrat.atom_model.shared.utility.wigner_3j_6j_9j import wigner_3j, wigner_6j
from solrat.engine.functions.decorators import log_method
from solrat.engine.functions.general import m1p, n_proj
from solrat.engine.functions.looping import FROMTO, INTERSECTION, PROJECTION, TRIANGULAR, VALUE
from solrat.engine.generators.multiply import multiply
from solrat.engine.generators.summate import summate


class MultiTermAtomRTELegacy(BaseRTE):
    r"""
    This is a legacy RTE implementation.
    It is not vectorized and therefore the new RTE implementation should be preferred for synthesis/inversion.
    This one is kept for reference and testing purposes.
    It also contains analytical expressions under further assumptions, which are used for testing.

    Note that there are some minor differences from the new vectorized implementation,
    such as cut-off condition. And the vectorized implementation has many features not available in this
    legacy implementation.
    """

    def __init__(
        self,
        transition_registry: TransitionRegistry,
        nu: np.ndarray,
        maximum_delta_v_thermal_units_cutoff=5,
        N=1,
    ):
        self.transition_registry: TransitionRegistry = transition_registry
        self.nu = nu
        self.maximum_delta_v_thermal_units_cutoff = maximum_delta_v_thermal_units_cutoff
        self.N = N  # Atom concentration

    @classmethod
    def from_model_config(
        cls,
        config: MultiTermAtomConfig,
        nu: np.ndarray,
    ) -> Self:
        r"""
        Constructor from the model config.
        """

        return cls(
            transition_registry=config.transition_registry,
            nu=nu,
        )

    def phi(self, nui, nu, atmosphere_parameters: AtmosphereParameters):
        """
        Reference: (5.43 - 5.45)
        """
        delta_nu_D = nui * atmosphere_parameters.delta_v_thermal_cm_sm1 / c_cm_sm1  # Doppler width

        nu_round = (nui - nu) / delta_nu_D  # nui already accounts for magnetic shifts
        nu_round_A = atmosphere_parameters.macroscopic_velocity_cm_sm1 / atmosphere_parameters.delta_v_thermal_cm_sm1

        complex_voigt = voigt(nu=nu_round - nu_round_A, a=atmosphere_parameters.voigt_a) / sqrt_pi / delta_nu_D
        return complex_voigt

    def cutoff_condition(self, term_upper: Term, term_lower: Term, nu: np.ndarray, atmosphere_parameters):
        """
        If the transition is far away from the requested frequency range, it does not contribute to RTE.
        """
        nui = energy_cmm1_to_frequency_hz(term_upper.get_mean_energy_cmm1() - term_lower.get_mean_energy_cmm1())
        cutoff = (
            self.maximum_delta_v_thermal_units_cutoff * nui * atmosphere_parameters.delta_v_thermal_cm_sm1 / c_cm_sm1
        )
        if min(nu) > nui + cutoff or max(nu) < nui - cutoff:  # pragma: no cover
            return True
        return False

    def eta_a(
        self,
        rho: Rho,
        stokes_component_index: int,
        atmosphere_parameters: AtmosphereParameters,
        angles: Angles,
    ):
        """
        Reference:
        (7.47a)
        """
        D_inverse_omega = WignerD(alpha=-angles.gamma, beta=-angles.theta, gamma=-angles.chi, K_max=2)
        D_magnetic = WignerD(alpha=angles.chi_B, beta=angles.theta_B, gamma=0, K_max=2)

        result = 0
        for transition in self.transition_registry.transitions.values():
            term_upper = transition.term_upper
            term_lower = transition.term_lower

            if self.cutoff_condition(
                term_upper=term_upper,
                term_lower=term_lower,
                nu=self.nu,
                atmosphere_parameters=atmosphere_parameters,
            ):  # pragma: no cover
                logging.info(
                    f"Cutting off the transition {term_upper.term_id} -> {term_lower.term_id} "
                    f"because it does not contribute to the specified frequency range"
                )
                continue

            Ll = term_lower.L
            Lu = term_upper.L
            S = term_lower.S
            lower_pb_eigenvalues, lower_pb_eigenvectors = calculate_paschen_back(
                term=term_lower, magnetic_field_gauss=atmosphere_parameters.magnetic_field_gauss
            )
            upper_pb_eigenvalues, upper_pb_eigenvectors = calculate_paschen_back(
                term=term_upper, magnetic_field_gauss=atmosphere_parameters.magnetic_field_gauss
            )

            result = result + summate(
                lambda K, Q, Kl, Ql, jl, Jl, Jʹl, Jʹʹl, ju, Ju, Jʹu, Ml, Mʹl, Mu, q, qʹ: multiply(
                    lambda: h_erg_s * self.nu / 4 / pi * self.N * n_proj(Ll),
                    lambda: transition.einstein_b_lu * sqrt(n_proj(1, K, Kl)),
                    lambda: m1p(1 + Jʹʹl - Ml + qʹ),
                    lambda: lower_pb_eigenvectors(j=jl, J=Jl, M=Ml),
                    lambda: lower_pb_eigenvectors(j=jl, J=Jʹʹl, M=Ml),
                    lambda: upper_pb_eigenvectors(j=ju, J=Ju, M=Mu),
                    lambda: upper_pb_eigenvectors(j=ju, J=Jʹu, M=Mu),
                    lambda: sqrt(n_proj(Jl, Jʹl, Ju, Jʹu)),
                    lambda: wigner_3j(Ju, Jl, 1, -Mu, Ml, -q),
                    lambda: wigner_3j(Jʹu, Jʹl, 1, -Mu, Mʹl, -qʹ),
                    lambda: wigner_3j(1, 1, K, q, -qʹ, -Q),
                    lambda: wigner_3j(Jʹʹl, Jʹl, Kl, Ml, -Mʹl, -Ql),
                    lambda: wigner_6j(Lu, Ll, 1, Jl, Ju, S),
                    lambda: wigner_6j(Lu, Ll, 1, Jʹl, Jʹu, S),
                    lambda: real(
                        multiply(
                            lambda: T_K_Q_double_rotation(K, Q, stokes_component_index, D_inverse_omega, D_magnetic),
                            lambda: rho(term_id=term_lower.term_id, K=Kl, Q=Ql, J=Jʹʹl, Jʹ=Jʹl),
                            lambda: self.phi(
                                nui=energy_cmm1_to_frequency_hz(
                                    upper_pb_eigenvalues(j=ju, M=Mu) - lower_pb_eigenvalues(j=jl, M=Ml),
                                ),
                                nu=self.nu,
                                atmosphere_parameters=atmosphere_parameters,
                            ),
                            is_complex=True,
                        )
                    ),
                ),
                jl=TRIANGULAR(Ll, S),
                Jl=TRIANGULAR(Ll, S),
                Jʹl=TRIANGULAR(Ll, S),
                Jʹʹl=TRIANGULAR(Ll, S),
                ju=TRIANGULAR(Lu, S),
                Ju=INTERSECTION(TRIANGULAR(Lu, S), TRIANGULAR("Jl", 1)),
                Jʹu=INTERSECTION(TRIANGULAR(Lu, S), TRIANGULAR("Jʹl", 1)),
                Ml=INTERSECTION(PROJECTION("Jl"), PROJECTION("Jʹʹl"), PROJECTION("jl")),
                Mʹl=PROJECTION("Jʹl"),
                Mu=INTERSECTION(PROJECTION("Ju"), PROJECTION("Jʹu"), PROJECTION("ju")),
                K=FROMTO(0, 2),
                Kl=TRIANGULAR("Jʹl", "Jʹʹl"),
                Ql=INTERSECTION(PROJECTION("Kl"), VALUE("Ml - Mʹl")),
                q=VALUE("Ml - Mu"),
                qʹ=VALUE("Mʹl - Mu"),
                Q=INTERSECTION(PROJECTION("K"), VALUE("q - qʹ")),
                tqdm_level=1,
            )
        return result

    def eta_s(
        self,
        rho: Rho,
        stokes_component_index: int,
        atmosphere_parameters: AtmosphereParameters,
        angles: Angles,
    ):
        """
        Reference:
        (7.47b)
        """
        D_inverse_omega = WignerD(alpha=-angles.gamma, beta=-angles.theta, gamma=-angles.chi, K_max=2)
        D_magnetic = WignerD(alpha=angles.chi_B, beta=angles.theta_B, gamma=0, K_max=2)

        result = 0
        for transition in self.transition_registry.transitions.values():
            term_upper = transition.term_upper
            term_lower = transition.term_lower

            if self.cutoff_condition(
                term_upper=term_upper,
                term_lower=term_lower,
                nu=self.nu,
                atmosphere_parameters=atmosphere_parameters,
            ):  # pragma: no cover
                logging.info(
                    f"Cutting off the transition {term_upper.term_id} -> {term_lower.term_id} "
                    f"because it does not contribute to the specified frequency range"
                )
                continue

            logging.info(f"Processing {term_upper.term_id} -> {term_lower.term_id}")

            Ll = term_lower.L
            Lu = term_upper.L

            S = term_lower.S
            lower_pb_eigenvalues, lower_pb_eigenvectors = calculate_paschen_back(
                term=term_lower, magnetic_field_gauss=atmosphere_parameters.magnetic_field_gauss
            )
            upper_pb_eigenvalues, upper_pb_eigenvectors = calculate_paschen_back(
                term=term_upper, magnetic_field_gauss=atmosphere_parameters.magnetic_field_gauss
            )

            result = result + summate(
                lambda ju, Ju, Jʹu, Jʹʹu, jl, Jl, Jʹl, Mu, Mʹu, Ml, K, Q, Ku, Qu, q, qʹ: multiply(
                    lambda: h_erg_s * self.nu / 4 / pi * self.N,
                    lambda: n_proj(Lu) * transition.einstein_b_ul * sqrt(n_proj(1, K, Ku)),
                    lambda: m1p(1 + Jʹu - Mu + qʹ),
                    lambda: lower_pb_eigenvectors(j=jl, J=Jl, M=Ml),
                    lambda: lower_pb_eigenvectors(j=jl, J=Jʹl, M=Ml),
                    lambda: upper_pb_eigenvectors(j=ju, J=Ju, M=Mu),
                    lambda: upper_pb_eigenvectors(j=ju, J=Jʹʹu, M=Mu),
                    lambda: sqrt(n_proj(Jl, Jʹl, Ju, Jʹu)),
                    lambda: wigner_3j(Ju, Jl, 1, -Mu, Ml, -q),
                    lambda: wigner_3j(Jʹu, Jʹl, 1, -Mʹu, Ml, -qʹ),
                    lambda: wigner_3j(1, 1, K, q, -qʹ, -Q),
                    lambda: wigner_3j(Jʹu, Jʹʹu, Ku, Mʹu, -Mu, -Qu),
                    lambda: wigner_6j(Lu, Ll, 1, Jl, Ju, S),
                    lambda: wigner_6j(Lu, Ll, 1, Jʹl, Jʹu, S),
                    lambda: real(
                        multiply(
                            lambda: T_K_Q_double_rotation(
                                K=K,
                                Q=Q,
                                stokes_component_index=stokes_component_index,
                                D_inverse_omega=D_inverse_omega,
                                D_magnetic=D_magnetic,
                            ),
                            lambda: rho(term_id=term_upper.term_id, K=Ku, Q=Qu, J=Jʹu, Jʹ=Jʹʹu),
                            lambda: self.phi(
                                nui=energy_cmm1_to_frequency_hz(
                                    upper_pb_eigenvalues(j=ju, M=Mu) - lower_pb_eigenvalues(j=jl, M=Ml),
                                ),
                                nu=self.nu,
                                atmosphere_parameters=atmosphere_parameters,
                            ),
                        )
                    ),
                ),
                ju=TRIANGULAR(Lu, S),
                Ju=TRIANGULAR(Lu, S),
                Jʹu=TRIANGULAR(Lu, S),
                Jʹʹu=TRIANGULAR(Lu, S),
                jl=TRIANGULAR(Ll, S),
                Jl=INTERSECTION(TRIANGULAR(Ll, S), TRIANGULAR("Ju", 1)),
                Jʹl=INTERSECTION(TRIANGULAR(Ll, S), TRIANGULAR("Jʹu", 1)),
                Mu=INTERSECTION(PROJECTION("Ju"), PROJECTION("Jʹʹu"), PROJECTION("ju")),
                Mʹu=PROJECTION("Jʹu"),
                Ml=INTERSECTION(PROJECTION("Jl"), PROJECTION("Jʹl"), PROJECTION("jl")),
                K=FROMTO(0, 2),
                Ku=TRIANGULAR("Jʹu", "Jʹʹu"),
                Qu=INTERSECTION(PROJECTION("Ku"), VALUE("Mʹu - Mu")),
                q=VALUE("Ml - Mu"),
                qʹ=VALUE("Ml - Mʹu"),
                Q=INTERSECTION(PROJECTION("K"), VALUE("q - qʹ")),
                tqdm_level=1,
            )
        return result

    def rho_a(
        self,
        rho: Rho,
        stokes_component_index: int,
        atmosphere_parameters: AtmosphereParameters,
        angles: Angles,
    ):
        """
        Reference:
        (7.47a)
        """
        D_inverse_omega = WignerD(alpha=-angles.gamma, beta=-angles.theta, gamma=-angles.chi, K_max=2)
        D_magnetic = WignerD(alpha=angles.chi_B, beta=angles.theta_B, gamma=0, K_max=2)

        result = 0
        for transition in self.transition_registry.transitions.values():
            term_upper = transition.term_upper
            term_lower = transition.term_lower

            if self.cutoff_condition(
                term_upper=term_upper,
                term_lower=term_lower,
                nu=self.nu,
                atmosphere_parameters=atmosphere_parameters,
            ):  # pragma: no cover
                logging.info(
                    f"Cutting off the transition {term_upper.term_id} -> {term_lower.term_id} "
                    f"because it does not contribute to the specified frequency range"
                )
                continue

            Ll = term_lower.L
            Lu = term_upper.L
            S = term_lower.S
            lower_pb_eigenvalues, lower_pb_eigenvectors = calculate_paschen_back(
                term=term_lower, magnetic_field_gauss=atmosphere_parameters.magnetic_field_gauss
            )
            upper_pb_eigenvalues, upper_pb_eigenvectors = calculate_paschen_back(
                term=term_upper, magnetic_field_gauss=atmosphere_parameters.magnetic_field_gauss
            )

            result = result + summate(
                lambda K, Q, Kl, Ql, jl, Jl, Jʹl, Jʹʹl, ju, Ju, Jʹu, Ml, Mʹl, Mu, q, qʹ: multiply(
                    lambda: h_erg_s * self.nu / 4 / pi * self.N * n_proj(Ll),
                    lambda: transition.einstein_b_lu * sqrt(n_proj(1, K, Kl)),
                    lambda: m1p(1 + Jʹʹl - Ml + qʹ),
                    lambda: lower_pb_eigenvectors(j=jl, J=Jl, M=Ml),
                    lambda: lower_pb_eigenvectors(j=jl, J=Jʹʹl, M=Ml),
                    lambda: upper_pb_eigenvectors(j=ju, J=Ju, M=Mu),
                    lambda: upper_pb_eigenvectors(j=ju, J=Jʹu, M=Mu),
                    lambda: sqrt(n_proj(Jl, Jʹl, Ju, Jʹu)),
                    lambda: wigner_3j(Ju, Jl, 1, -Mu, Ml, -q),
                    lambda: wigner_3j(Jʹu, Jʹl, 1, -Mu, Mʹl, -qʹ),
                    lambda: wigner_3j(1, 1, K, q, -qʹ, -Q),
                    lambda: wigner_3j(Jʹʹl, Jʹl, Kl, Ml, -Mʹl, -Ql),
                    lambda: wigner_6j(Lu, Ll, 1, Jl, Ju, S),
                    lambda: wigner_6j(Lu, Ll, 1, Jʹl, Jʹu, S),
                    lambda: imag(
                        multiply(
                            lambda: T_K_Q_double_rotation(
                                K=K,
                                Q=Q,
                                stokes_component_index=stokes_component_index,
                                D_inverse_omega=D_inverse_omega,
                                D_magnetic=D_magnetic,
                            ),
                            lambda: rho(term_id=term_lower.term_id, K=Kl, Q=Ql, J=Jʹʹl, Jʹ=Jʹl),
                            lambda: self.phi(
                                nui=energy_cmm1_to_frequency_hz(
                                    upper_pb_eigenvalues(j=ju, M=Mu) - lower_pb_eigenvalues(j=jl, M=Ml),
                                ),
                                nu=self.nu,
                                atmosphere_parameters=atmosphere_parameters,
                            ),
                            is_complex=True,
                        )
                    ),
                ),
                jl=TRIANGULAR(Ll, S),
                Jl=TRIANGULAR(Ll, S),
                Jʹl=TRIANGULAR(Ll, S),
                Jʹʹl=TRIANGULAR(Ll, S),
                ju=TRIANGULAR(Lu, S),
                Ju=INTERSECTION(TRIANGULAR(Lu, S), TRIANGULAR("Jl", 1)),
                Jʹu=INTERSECTION(TRIANGULAR(Lu, S), TRIANGULAR("Jʹl", 1)),
                Ml=INTERSECTION(PROJECTION("Jl"), PROJECTION("Jʹʹl"), PROJECTION("jl")),
                Mʹl=PROJECTION("Jʹl"),
                Mu=INTERSECTION(PROJECTION("Ju"), PROJECTION("Jʹu"), PROJECTION("ju")),
                K=FROMTO(0, 2),
                Kl=TRIANGULAR("Jʹl", "Jʹʹl"),
                Ql=INTERSECTION(PROJECTION("Kl"), VALUE("Ml - Mʹl")),
                q=VALUE("Ml - Mu"),
                qʹ=VALUE("Mʹl - Mu"),
                Q=INTERSECTION(PROJECTION("K"), VALUE("q - qʹ")),
                tqdm_level=1,
            )
        return result

    def rho_s(
        self,
        rho: Rho,
        stokes_component_index: int,
        atmosphere_parameters: AtmosphereParameters,
        angles: Angles,
    ):
        """
        Reference:
        (7.47b)
        """
        D_inverse_omega = WignerD(alpha=-angles.gamma, beta=-angles.theta, gamma=-angles.chi, K_max=2)
        D_magnetic = WignerD(alpha=angles.chi_B, beta=angles.theta_B, gamma=0, K_max=2)

        result = 0
        for transition in self.transition_registry.transitions.values():
            term_upper = transition.term_upper
            term_lower = transition.term_lower

            if self.cutoff_condition(
                term_upper=term_upper,
                term_lower=term_lower,
                nu=self.nu,
                atmosphere_parameters=atmosphere_parameters,
            ):  # pragma: no cover
                logging.info(
                    f"Cutting off the transition {term_upper.term_id} -> {term_lower.term_id} "
                    f"because it does not contribute to the specified frequency range"
                )
                continue

            logging.info(f"Processing {term_upper.term_id} -> {term_lower.term_id}")

            Ll = term_lower.L
            Lu = term_upper.L

            S = term_lower.S
            lower_pb_eigenvalues, lower_pb_eigenvectors = calculate_paschen_back(
                term=term_lower, magnetic_field_gauss=atmosphere_parameters.magnetic_field_gauss
            )
            upper_pb_eigenvalues, upper_pb_eigenvectors = calculate_paschen_back(
                term=term_upper, magnetic_field_gauss=atmosphere_parameters.magnetic_field_gauss
            )

            result = result + summate(
                lambda ju, Ju, Jʹu, Jʹʹu, jl, Jl, Jʹl, Mu, Mʹu, Ml, K, Q, Ku, Qu, q, qʹ: multiply(
                    lambda: h_erg_s * self.nu / 4 / pi * self.N,
                    lambda: n_proj(Lu) * transition.einstein_b_ul * sqrt(n_proj(1, K, Ku)),
                    lambda: m1p(1 + Jʹu - Mu + qʹ),
                    lambda: lower_pb_eigenvectors(j=jl, J=Jl, M=Ml),
                    lambda: lower_pb_eigenvectors(j=jl, J=Jʹl, M=Ml),
                    lambda: upper_pb_eigenvectors(j=ju, J=Ju, M=Mu),
                    lambda: upper_pb_eigenvectors(j=ju, J=Jʹʹu, M=Mu),
                    lambda: sqrt(n_proj(Jl, Jʹl, Ju, Jʹu)),
                    lambda: wigner_3j(Ju, Jl, 1, -Mu, Ml, -q),
                    lambda: wigner_3j(Jʹu, Jʹl, 1, -Mʹu, Ml, -qʹ),
                    lambda: wigner_3j(1, 1, K, q, -qʹ, -Q),
                    lambda: wigner_3j(Jʹu, Jʹʹu, Ku, Mʹu, -Mu, -Qu),
                    lambda: wigner_6j(Lu, Ll, 1, Jl, Ju, S),
                    lambda: wigner_6j(Lu, Ll, 1, Jʹl, Jʹu, S),
                    lambda: imag(
                        multiply(
                            lambda: T_K_Q_double_rotation(K, Q, stokes_component_index, D_inverse_omega, D_magnetic),
                            lambda: rho(term_id=term_upper.term_id, K=Ku, Q=Qu, J=Jʹu, Jʹ=Jʹʹu),
                            lambda: self.phi(
                                nui=energy_cmm1_to_frequency_hz(
                                    upper_pb_eigenvalues(j=ju, M=Mu) - lower_pb_eigenvalues(j=jl, M=Ml),
                                ),
                                nu=self.nu,
                                atmosphere_parameters=atmosphere_parameters,
                            ),
                        )
                    ),
                ),
                ju=TRIANGULAR(Lu, S),
                Ju=TRIANGULAR(Lu, S),
                Jʹu=TRIANGULAR(Lu, S),
                Jʹʹu=TRIANGULAR(Lu, S),
                jl=TRIANGULAR(Ll, S),
                Jl=INTERSECTION(TRIANGULAR(Ll, S), TRIANGULAR("Ju", 1)),
                Jʹl=INTERSECTION(TRIANGULAR(Ll, S), TRIANGULAR("Jʹu", 1)),
                Mu=INTERSECTION(PROJECTION("Ju"), PROJECTION("Jʹʹu"), PROJECTION("ju")),
                Mʹu=PROJECTION("Jʹu"),
                Ml=INTERSECTION(PROJECTION("Jl"), PROJECTION("Jʹl"), PROJECTION("jl")),
                K=FROMTO(0, 2),
                Ku=TRIANGULAR("Jʹu", "Jʹʹu"),
                Qu=INTERSECTION(PROJECTION("Ku"), VALUE("Mʹu - Mu")),
                q=VALUE("Ml - Mu"),
                qʹ=VALUE("Ml - Mʹu"),
                Q=INTERSECTION(PROJECTION("K"), VALUE("q - qʹ")),
                tqdm_level=1,
            )
        return result

    @staticmethod
    def epsilon(eta_s: np.ndarray, nu: np.ndarray):
        """
        Reference:
        (7.47e)
        """
        return 2 * h_erg_s * nu**3 / c_cm_sm1**2 * eta_s

    """
    Combined
    Returning complex values for eta_rho gives 2x performance benefit.
    """

    def eta_rho_a(
        self,
        rho: Rho,
        stokes_component_index: int,
        atmosphere_parameters: AtmosphereParameters,
        angles: Angles,
    ):
        """
        eta_a = real(eta_rho_a)
        rho_a = imag(eta_rho_a)
        """
        D_inverse_omega = WignerD(alpha=-angles.gamma, beta=-angles.theta, gamma=-angles.chi, K_max=2)
        D_magnetic = WignerD(alpha=angles.chi_B, beta=angles.theta_B, gamma=0, K_max=2)

        result = 0
        for transition in self.transition_registry.transitions.values():
            term_upper = transition.term_upper
            term_lower = transition.term_lower

            if self.cutoff_condition(
                term_upper=term_upper,
                term_lower=term_lower,
                nu=self.nu,
                atmosphere_parameters=atmosphere_parameters,
            ):  # pragma: no cover
                logging.info(
                    f"Cutting off the transition {term_upper.term_id} -> {term_lower.term_id} "
                    f"because it does not contribute to the specified frequency range"
                )
                continue

            Ll = term_lower.L
            Lu = term_upper.L
            S = term_lower.S
            lower_pb_eigenvalues, lower_pb_eigenvectors = calculate_paschen_back(
                term=term_lower, magnetic_field_gauss=atmosphere_parameters.magnetic_field_gauss
            )
            upper_pb_eigenvalues, upper_pb_eigenvectors = calculate_paschen_back(
                term=term_upper, magnetic_field_gauss=atmosphere_parameters.magnetic_field_gauss
            )

            result = result + summate(
                lambda K, Q, Kl, Ql, jl, Jl, Jʹl, Jʹʹl, ju, Ju, Jʹu, Ml, Mʹl, Mu, q, qʹ: multiply(
                    lambda: h_erg_s * self.nu / 4 / pi * self.N * n_proj(Ll),
                    lambda: transition.einstein_b_lu * sqrt(n_proj(1, K, Kl)),
                    lambda: m1p(1 + Jʹʹl - Ml + qʹ),
                    lambda: lower_pb_eigenvectors(j=jl, J=Jl, M=Ml),
                    lambda: lower_pb_eigenvectors(j=jl, J=Jʹʹl, M=Ml),
                    lambda: upper_pb_eigenvectors(j=ju, J=Ju, M=Mu),
                    lambda: upper_pb_eigenvectors(j=ju, J=Jʹu, M=Mu),
                    lambda: sqrt(n_proj(Jl, Jʹl, Ju, Jʹu)),
                    lambda: wigner_3j(Ju, Jl, 1, -Mu, Ml, -q),
                    lambda: wigner_3j(Jʹu, Jʹl, 1, -Mu, Mʹl, -qʹ),
                    lambda: wigner_3j(1, 1, K, q, -qʹ, -Q),
                    lambda: wigner_3j(Jʹʹl, Jʹl, Kl, Ml, -Mʹl, -Ql),
                    lambda: wigner_6j(Lu, Ll, 1, Jl, Ju, S),
                    lambda: wigner_6j(Lu, Ll, 1, Jʹl, Jʹu, S),
                    lambda: multiply(
                        lambda: T_K_Q_double_rotation(K, Q, stokes_component_index, D_inverse_omega, D_magnetic),
                        lambda: rho(term_id=term_lower.term_id, K=Kl, Q=Ql, J=Jʹʹl, Jʹ=Jʹl),
                        lambda: self.phi(
                            nui=energy_cmm1_to_frequency_hz(
                                upper_pb_eigenvalues(j=ju, M=Mu) - lower_pb_eigenvalues(j=jl, M=Ml),
                            ),
                            nu=self.nu,
                            atmosphere_parameters=atmosphere_parameters,
                        ),
                        is_complex=True,
                    ),
                ),
                jl=TRIANGULAR(Ll, S),
                Jl=TRIANGULAR(Ll, S),
                Jʹl=TRIANGULAR(Ll, S),
                Jʹʹl=TRIANGULAR(Ll, S),
                ju=TRIANGULAR(Lu, S),
                Ju=INTERSECTION(TRIANGULAR(Lu, S), TRIANGULAR("Jl", 1)),
                Jʹu=INTERSECTION(TRIANGULAR(Lu, S), TRIANGULAR("Jʹl", 1)),
                Ml=INTERSECTION(PROJECTION("Jl"), PROJECTION("Jʹʹl"), PROJECTION("jl")),
                Mʹl=PROJECTION("Jʹl"),
                Mu=INTERSECTION(PROJECTION("Ju"), PROJECTION("Jʹu"), PROJECTION("ju")),
                K=FROMTO(0, 2),
                Kl=TRIANGULAR("Jʹl", "Jʹʹl"),
                Ql=INTERSECTION(PROJECTION("Kl"), VALUE("Ml - Mʹl")),
                q=VALUE("Ml - Mu"),
                qʹ=VALUE("Mʹl - Mu"),
                Q=INTERSECTION(PROJECTION("K"), VALUE("q - qʹ")),
                tqdm_level=1,
            )
        return result

    def eta_rho_s(
        self,
        rho: Rho,
        stokes_component_index: int,
        atmosphere_parameters: AtmosphereParameters,
        angles: Angles,
    ) -> np.ndarray:
        """
        eta_s = real(eta_rho_s)
        rho_s = imag(eta_rho_s)
        """
        D_inverse_omega = WignerD(alpha=-angles.gamma, beta=-angles.theta, gamma=-angles.chi, K_max=2)
        D_magnetic = WignerD(alpha=angles.chi_B, beta=angles.theta_B, gamma=0, K_max=2)

        result = 0
        for transition in self.transition_registry.transitions.values():
            term_upper = transition.term_upper
            term_lower = transition.term_lower

            if self.cutoff_condition(
                term_upper=term_upper,
                term_lower=term_lower,
                nu=self.nu,
                atmosphere_parameters=atmosphere_parameters,
            ):  # pragma: no cover
                logging.info(
                    f"Cutting off the transition {term_upper.term_id} -> {term_lower.term_id} "
                    f"because it does not contribute to the specified frequency range"
                )
                continue

            logging.info(f"Processing {term_upper.term_id} -> {term_lower.term_id}")

            Ll = term_lower.L
            Lu = term_upper.L

            S = term_lower.S
            lower_pb_eigenvalues, lower_pb_eigenvectors = calculate_paschen_back(
                term=term_lower, magnetic_field_gauss=atmosphere_parameters.magnetic_field_gauss
            )
            upper_pb_eigenvalues, upper_pb_eigenvectors = calculate_paschen_back(
                term=term_upper, magnetic_field_gauss=atmosphere_parameters.magnetic_field_gauss
            )

            result = result + summate(
                lambda ju, Ju, Jʹu, Jʹʹu, jl, Jl, Jʹl, Mu, Mʹu, Ml, K, Q, Ku, Qu, q, qʹ: multiply(
                    lambda: h_erg_s * self.nu / 4 / pi * self.N,
                    lambda: n_proj(Lu) * transition.einstein_b_ul * sqrt(n_proj(1, K, Ku)),
                    lambda: m1p(1 + Jʹu - Mu + qʹ),
                    lambda: lower_pb_eigenvectors(j=jl, J=Jl, M=Ml),
                    lambda: lower_pb_eigenvectors(j=jl, J=Jʹl, M=Ml),
                    lambda: upper_pb_eigenvectors(j=ju, J=Ju, M=Mu),
                    lambda: upper_pb_eigenvectors(j=ju, J=Jʹʹu, M=Mu),
                    lambda: sqrt(n_proj(Jl, Jʹl, Ju, Jʹu)),
                    lambda: wigner_3j(Ju, Jl, 1, -Mu, Ml, -q),
                    lambda: wigner_3j(Jʹu, Jʹl, 1, -Mʹu, Ml, -qʹ),
                    lambda: wigner_3j(1, 1, K, q, -qʹ, -Q),
                    lambda: wigner_3j(Jʹu, Jʹʹu, Ku, Mʹu, -Mu, -Qu),
                    lambda: wigner_6j(Lu, Ll, 1, Jl, Ju, S),
                    lambda: wigner_6j(Lu, Ll, 1, Jʹl, Jʹu, S),
                    lambda: multiply(
                        lambda: T_K_Q_double_rotation(K, Q, stokes_component_index, D_inverse_omega, D_magnetic),
                        lambda: rho(term_id=term_upper.term_id, K=Ku, Q=Qu, J=Jʹu, Jʹ=Jʹʹu),
                        lambda: self.phi(
                            nui=energy_cmm1_to_frequency_hz(
                                upper_pb_eigenvalues(j=ju, M=Mu) - lower_pb_eigenvalues(j=jl, M=Ml),
                            ),
                            nu=self.nu,
                            atmosphere_parameters=atmosphere_parameters,
                        ),
                    ),
                ),
                ju=TRIANGULAR(Lu, S),
                Ju=TRIANGULAR(Lu, S),
                Jʹu=TRIANGULAR(Lu, S),
                Jʹʹu=TRIANGULAR(Lu, S),
                jl=TRIANGULAR(Ll, S),
                Jl=INTERSECTION(TRIANGULAR(Ll, S), TRIANGULAR("Ju", 1)),
                Jʹl=INTERSECTION(TRIANGULAR(Ll, S), TRIANGULAR("Jʹu", 1)),
                Mu=INTERSECTION(PROJECTION("Ju"), PROJECTION("Jʹʹu"), PROJECTION("ju")),
                Mʹu=PROJECTION("Jʹu"),
                Ml=INTERSECTION(PROJECTION("Jl"), PROJECTION("Jʹl"), PROJECTION("jl")),
                K=FROMTO(0, 2),
                Ku=TRIANGULAR("Jʹu", "Jʹʹu"),
                Qu=INTERSECTION(PROJECTION("Ku"), VALUE("Mʹu - Mu")),
                q=VALUE("Ml - Mu"),
                qʹ=VALUE("Ml - Mʹu"),
                Q=INTERSECTION(PROJECTION("K"), VALUE("q - qʹ")),
                tqdm_level=1,
            )
        return result

    """
    The following are some analytical expressions under further assumptions for validation.
    """

    def eta_a_no_field_no_fine_structure(
        self,
        rho: Rho,
        stokes_component_index: int,
        atmosphere_parameters: AtmosphereParameters,
        angles: Angles,
    ):
        """
        Reference:
        (7.48a)
        """
        assert atmosphere_parameters.magnetic_field_gauss == 0
        D_inverse_omega = WignerD(alpha=-angles.gamma, beta=-angles.theta, gamma=-angles.chi, K_max=2)
        D_magnetic = WignerD(alpha=angles.chi_B, beta=angles.theta_B, gamma=0, K_max=2)

        result = 0
        for transition in self.transition_registry.transitions.values():
            term_upper = transition.term_upper
            term_lower = transition.term_lower

            if self.cutoff_condition(
                term_upper=term_upper,
                term_lower=term_lower,
                nu=self.nu,
                atmosphere_parameters=atmosphere_parameters,
            ):  # pragma: no cover
                logging.info(
                    f"Cutting off the transition {term_upper.term_id} -> {term_lower.term_id} "
                    f"because it does not contribute to the specified frequency range"
                )
                continue

            Ll = term_lower.L
            Lu = term_upper.L
            S = term_lower.S

            result = result + summate(
                lambda K, Q, Jl, Jʹl: multiply(
                    lambda: h_erg_s * self.nu / 4 / pi * self.N * n_proj(Ll),
                    lambda: transition.einstein_b_lu,
                    lambda: m1p(1 - Lu + S + Jʹl),
                    lambda: sqrt(n_proj(1, Jl, Jʹl)),
                    lambda: wigner_6j(Ll, Ll, K, Jl, Jʹl, S),
                    lambda: wigner_6j(1, 1, K, Ll, Ll, Lu),
                    lambda: real(
                        multiply(
                            lambda: T_K_Q_double_rotation(K, Q, stokes_component_index, D_inverse_omega, D_magnetic),
                            lambda: rho(term_id=term_lower.term_id, K=K, Q=Q, J=Jl, Jʹ=Jʹl),
                            lambda: self.phi(
                                nui=energy_cmm1_to_frequency_hz(
                                    term_upper.get_mean_energy_cmm1() - term_lower.get_mean_energy_cmm1()
                                ),
                                nu=self.nu,
                                atmosphere_parameters=atmosphere_parameters,
                            ),
                            is_complex=True,
                        )
                    ),
                ),
                Jl=TRIANGULAR(Ll, S),
                Jʹl=TRIANGULAR(Ll, S),
                K=INTERSECTION(FROMTO(0, 2), TRIANGULAR("Jʹl", "Jl")),
                Q=PROJECTION("K"),
                tqdm_level=1,
            )
        return result

    def eta_s_no_field_no_fine_structure(
        self,
        rho: Rho,
        stokes_component_index: int,
        atmosphere_parameters: AtmosphereParameters,
        angles: Angles,
    ):
        """
        No magnetic field, no fine structure splitting.
        Reference:
        (7.48d)
        """
        assert atmosphere_parameters.magnetic_field_gauss == 0
        D_inverse_omega = WignerD(alpha=-angles.gamma, beta=-angles.theta, gamma=-angles.chi, K_max=2)
        D_magnetic = WignerD(alpha=angles.chi_B, beta=angles.theta_B, gamma=0, K_max=2)

        result = 0
        for transition in self.transition_registry.transitions.values():
            term_upper = transition.term_upper
            term_lower = transition.term_lower

            if self.cutoff_condition(
                term_upper=term_upper,
                term_lower=term_lower,
                nu=self.nu,
                atmosphere_parameters=atmosphere_parameters,
            ):  # pragma: no cover
                logging.info(
                    f"Cutting off the transition {term_upper.term_id} -> {term_lower.term_id} "
                    f"because it does not contribute to the specified frequency range"
                )
                continue

            logging.info(f"Processing {term_upper.term_id} -> {term_lower.term_id}")

            Ll = term_lower.L
            Lu = term_upper.L

            S = term_lower.S

            result = result + summate(
                lambda Ju, Jʹu, K, Q: multiply(
                    lambda: h_erg_s * self.nu / 4 / pi * self.N,
                    lambda: n_proj(Lu) * transition.einstein_b_ul,
                    lambda: m1p(1 - Ll + S + Ju + K),
                    lambda: sqrt(n_proj(1, Ju, Jʹu)),
                    lambda: wigner_6j(Lu, Lu, K, Ju, Jʹu, S),
                    lambda: wigner_6j(1, 1, K, Lu, Lu, Ll),
                    lambda: real(
                        multiply(
                            lambda: T_K_Q_double_rotation(K, Q, stokes_component_index, D_inverse_omega, D_magnetic),
                            lambda: rho(term_id=term_upper.term_id, K=K, Q=Q, J=Jʹu, Jʹ=Ju),
                            lambda: self.phi(
                                nui=energy_cmm1_to_frequency_hz(
                                    term_upper.get_mean_energy_cmm1() - term_lower.get_mean_energy_cmm1()
                                ),
                                nu=self.nu,
                                atmosphere_parameters=atmosphere_parameters,
                            ),
                        )
                    ),
                ),
                Ju=TRIANGULAR(Lu, S),
                Jʹu=TRIANGULAR(Lu, S),
                K=INTERSECTION(FROMTO(0, 2), TRIANGULAR("Jʹu", "Ju")),
                Q=INTERSECTION(PROJECTION("K")),
                tqdm_level=1,
            )
        return result

    def rho_a_no_field_no_fine_structure(
        self,
        rho: Rho,
        stokes_component_index: int,
        atmosphere_parameters: AtmosphereParameters,
        angles: Angles,
    ):
        """
        Reference:
        (7.48a)
        """
        assert atmosphere_parameters.magnetic_field_gauss == 0
        D_inverse_omega = WignerD(alpha=-angles.gamma, beta=-angles.theta, gamma=-angles.chi, K_max=2)
        D_magnetic = WignerD(alpha=angles.chi_B, beta=angles.theta_B, gamma=0, K_max=2)

        result = 0
        for transition in self.transition_registry.transitions.values():
            term_upper = transition.term_upper
            term_lower = transition.term_lower

            if self.cutoff_condition(
                term_upper=term_upper,
                term_lower=term_lower,
                nu=self.nu,
                atmosphere_parameters=atmosphere_parameters,
            ):  # pragma: no cover
                logging.info(
                    f"Cutting off the transition {term_upper.term_id} -> {term_lower.term_id} "
                    f"because it does not contribute to the specified frequency range"
                )
                continue

            Ll = term_lower.L
            Lu = term_upper.L
            S = term_lower.S

            result = result + summate(
                lambda K, Q, Jl, Jʹl: multiply(
                    lambda: h_erg_s * self.nu / 4 / pi * self.N * n_proj(Ll),
                    lambda: transition.einstein_b_lu,
                    lambda: m1p(1 - Lu + S + Jʹl),
                    lambda: sqrt(n_proj(1, Jl, Jʹl)),
                    lambda: wigner_6j(Ll, Ll, K, Jl, Jʹl, S),
                    lambda: wigner_6j(1, 1, K, Ll, Ll, Lu),
                    lambda: imag(
                        multiply(
                            lambda: T_K_Q_double_rotation(K, Q, stokes_component_index, D_inverse_omega, D_magnetic),
                            lambda: rho(term_id=term_lower.term_id, K=K, Q=Q, J=Jl, Jʹ=Jʹl),
                            lambda: self.phi(
                                nui=energy_cmm1_to_frequency_hz(
                                    term_upper.get_mean_energy_cmm1() - term_lower.get_mean_energy_cmm1()
                                ),
                                nu=self.nu,
                                atmosphere_parameters=atmosphere_parameters,
                            ),
                            is_complex=True,
                        )
                    ),
                ),
                Jl=TRIANGULAR(Ll, S),
                Jʹl=TRIANGULAR(Ll, S),
                K=INTERSECTION(FROMTO(0, 2), TRIANGULAR("Jʹl", "Jl")),
                Q=PROJECTION("K"),
                tqdm_level=1,
            )
        return result

    def rho_s_no_field_no_fine_structure(
        self,
        rho: Rho,
        stokes_component_index: int,
        atmosphere_parameters: AtmosphereParameters,
        angles: Angles,
    ):
        """
        No magnetic field, no fine structure splitting.
        Reference:
        (7.48d)
        """
        assert atmosphere_parameters.magnetic_field_gauss == 0
        D_inverse_omega = WignerD(alpha=-angles.gamma, beta=-angles.theta, gamma=-angles.chi, K_max=2)
        D_magnetic = WignerD(alpha=angles.chi_B, beta=angles.theta_B, gamma=0, K_max=2)

        result = 0
        for transition in self.transition_registry.transitions.values():
            term_upper = transition.term_upper
            term_lower = transition.term_lower

            if self.cutoff_condition(
                term_upper=term_upper,
                term_lower=term_lower,
                nu=self.nu,
                atmosphere_parameters=atmosphere_parameters,
            ):  # pragma: no cover
                logging.info(
                    f"Cutting off the transition {term_upper.term_id} -> {term_lower.term_id} "
                    f"because it does not contribute to the specified frequency range"
                )
                continue

            logging.info(f"Processing {term_upper.term_id} -> {term_lower.term_id}")

            Ll = term_lower.L
            Lu = term_upper.L

            S = term_lower.S

            result = result + summate(
                lambda Ju, Jʹu, K, Q: multiply(
                    lambda: h_erg_s * self.nu / 4 / pi * self.N,
                    lambda: n_proj(Lu) * transition.einstein_b_ul,
                    lambda: m1p(1 - Ll + S + Ju + K),
                    lambda: sqrt(n_proj(1, Ju, Jʹu)),
                    lambda: wigner_6j(Lu, Lu, K, Ju, Jʹu, S),
                    lambda: wigner_6j(1, 1, K, Lu, Lu, Ll),
                    lambda: imag(
                        multiply(
                            lambda: T_K_Q_double_rotation(K, Q, stokes_component_index, D_inverse_omega, D_magnetic),
                            lambda: rho(term_id=term_upper.term_id, K=K, Q=Q, J=Jʹu, Jʹ=Ju),
                            lambda: self.phi(
                                nui=energy_cmm1_to_frequency_hz(
                                    term_upper.get_mean_energy_cmm1() - term_lower.get_mean_energy_cmm1()
                                ),
                                nu=self.nu,
                                atmosphere_parameters=atmosphere_parameters,
                            ),
                        )
                    ),
                ),
                Ju=TRIANGULAR(Lu, S),
                Jʹu=TRIANGULAR(Lu, S),
                K=INTERSECTION(FROMTO(0, 2), TRIANGULAR("Jʹu", "Ju")),
                Q=INTERSECTION(PROJECTION("K")),
                tqdm_level=1,
            )
        return result

    def eta_s_no_field(
        self,
        rho: Rho,
        stokes_component_index: int,
        atmosphere_parameters: AtmosphereParameters,
        angles: Angles,
    ):
        """
        No magnetic field.
        Reference:
        (10.127)
        """
        assert atmosphere_parameters.magnetic_field_gauss == 0
        D_inverse_omega = WignerD(alpha=-angles.gamma, beta=-angles.theta, gamma=-angles.chi, K_max=2)
        D_magnetic = WignerD(alpha=angles.chi_B, beta=angles.theta_B, gamma=0, K_max=2)

        result = 0
        for transition in self.transition_registry.transitions.values():
            term_upper = transition.term_upper
            term_lower = transition.term_lower

            logging.info(f"{term_upper.term_id} -> {term_lower.term_id}")
            if self.cutoff_condition(
                term_upper=term_upper,
                term_lower=term_lower,
                nu=self.nu,
                atmosphere_parameters=atmosphere_parameters,
            ):  # pragma: no cover
                logging.info("Cutting off the transition because it is out of frequency range")
                continue

            Ll = term_lower.L
            Lu = term_upper.L
            S = term_lower.S

            result = result + summate(
                lambda Ju, Jʹu, Jl, K, Q: multiply(
                    lambda: h_erg_s * self.nu / 4 / pi * self.N * n_proj(Lu) * transition.einstein_b_ul,
                    lambda: m1p(1 + Jl + Jʹu),
                    lambda: sqrt(n_proj(Jl, Jl, 1, Ju, Jʹu)),
                    lambda: wigner_6j(Lu, Ll, 1, Jl, Ju, S),
                    lambda: wigner_6j(Lu, Ll, 1, Jl, Jʹu, S),
                    lambda: wigner_6j(1, 1, K, Ju, Jʹu, Jl),
                    lambda: real(
                        multiply(
                            lambda: T_K_Q_double_rotation(K, Q, stokes_component_index, D_inverse_omega, D_magnetic),
                            lambda: rho(term_id=term_upper.term_id, K=K, Q=Q, J=Jʹu, Jʹ=Ju),
                            lambda: 0.5
                            * (
                                self.phi(
                                    nui=energy_cmm1_to_frequency_hz(
                                        term_upper.get_level(J=Ju).energy_cmm1 - term_lower.get_level(J=Jl).energy_cmm1,
                                    ),
                                    nu=self.nu,
                                    atmosphere_parameters=atmosphere_parameters,
                                )
                                + np.conjugate(
                                    self.phi(
                                        nui=energy_cmm1_to_frequency_hz(
                                            term_upper.get_level(J=Jʹu).energy_cmm1
                                            - term_lower.get_level(J=Jl).energy_cmm1,
                                        ),
                                        nu=self.nu,
                                        atmosphere_parameters=atmosphere_parameters,
                                    )
                                )
                            ),
                        )
                    ),
                ),
                Ju=TRIANGULAR(Lu, S),
                Jʹu=TRIANGULAR(Lu, S),
                Jl=TRIANGULAR(Ll, S),
                K=INTERSECTION(FROMTO(0, 2), TRIANGULAR("Jʹu", "Ju")),
                Q=PROJECTION("K"),
            )
        return result

    @log_method
    def calculate_all_coefficients(
        self, atmosphere_parameters: AtmosphereParameters, angles: Angles, rho: Rho
    ) -> RadiativeTransferCoefficients:
        r"""
        Compute all radiative transfer coefficients.

        :param angles:  Angles instance with LOS and magnetic field angles
        :param rho:  density tensor Rho
        :param atmosphere_parameters:  AtmosphereParameters instance
        :return: RadiativeTransferCoefficients instance

        Reference: (LL04 7.47)
        """

        eta_rho_aI = self.eta_rho_a(
            stokes_component_index=0,
            angles=angles,
            rho=rho,
            atmosphere_parameters=atmosphere_parameters,
        )
        eta_rho_aQ = self.eta_rho_a(
            stokes_component_index=1,
            angles=angles,
            rho=rho,
            atmosphere_parameters=atmosphere_parameters,
        )
        eta_rho_aU = self.eta_rho_a(
            stokes_component_index=2,
            angles=angles,
            rho=rho,
            atmosphere_parameters=atmosphere_parameters,
        )
        eta_rho_aV = self.eta_rho_a(
            stokes_component_index=3,
            angles=angles,
            rho=rho,
            atmosphere_parameters=atmosphere_parameters,
        )

        eta_rho_sI = self.eta_rho_s(
            stokes_component_index=0,
            angles=angles,
            rho=rho,
            atmosphere_parameters=atmosphere_parameters,
        )
        eta_rho_sQ = self.eta_rho_s(
            stokes_component_index=1,
            angles=angles,
            rho=rho,
            atmosphere_parameters=atmosphere_parameters,
        )
        eta_rho_sU = self.eta_rho_s(
            stokes_component_index=2,
            angles=angles,
            rho=rho,
            atmosphere_parameters=atmosphere_parameters,
        )
        eta_rho_sV = self.eta_rho_s(
            stokes_component_index=3,
            angles=angles,
            rho=rho,
            atmosphere_parameters=atmosphere_parameters,
        )

        epsilonI = self.epsilon(eta_s=eta_rho_sI, nu=self.nu)
        epsilonQ = self.epsilon(eta_s=eta_rho_sQ, nu=self.nu)
        epsilonU = self.epsilon(eta_s=eta_rho_sU, nu=self.nu)
        epsilonV = self.epsilon(eta_s=eta_rho_sV, nu=self.nu)

        return RadiativeTransferCoefficients(
            eta_rho_aI=eta_rho_aI,
            eta_rho_aQ=eta_rho_aQ,
            eta_rho_aU=eta_rho_aU,
            eta_rho_aV=eta_rho_aV,
            eta_rho_sI=eta_rho_sI,
            eta_rho_sQ=eta_rho_sQ,
            eta_rho_sU=eta_rho_sU,
            eta_rho_sV=eta_rho_sV,
            epsilonI=epsilonI,
            epsilonQ=epsilonQ,
            epsilonU=epsilonU,
            epsilonV=epsilonV,
        )
