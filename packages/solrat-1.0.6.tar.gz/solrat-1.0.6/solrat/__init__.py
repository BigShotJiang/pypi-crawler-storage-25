r"""
SolRaT main package.
"""
