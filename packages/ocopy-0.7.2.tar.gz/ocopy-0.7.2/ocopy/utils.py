import os
import platform
from pathlib import Path
from threading import Thread

from ocopy.ignored import ignored_paths


def threaded(fn):
    def wrapper(*args, **kwargs):
        t = Thread(target=fn, args=args, kwargs=kwargs)
        t.daemon = True
        t.start()

    return wrapper


def folder_size(path):
    total = 0
    all_files = [f for f in Path(path).glob("**/*") if not any(dir_ in f.parts for dir_ in ignored_paths)]
    for entry in all_files:
        if entry.is_file():
            total += entry.stat().st_size
    return total


def get_user_display_name() -> str:
    if platform.system() != "Windows":
        import pwd

        return pwd.getpwuid(os.getuid()).pw_gecos
    else:
        import ctypes

        get_user_name_ex = ctypes.windll.secur32.GetUserNameExW
        name_display = 3

        size = ctypes.pointer(ctypes.c_ulong(0))
        get_user_name_ex(name_display, None, size)

        name_buffer = ctypes.create_unicode_buffer(size.contents.value)
        get_user_name_ex(name_display, name_buffer, size)
        return name_buffer.value


def get_mount(path: Path) -> Path:
    # pathlib.Path.is_mount is not implemented on Windows
    while not os.path.ismount(path) and path.parents:
        path = path.parent

    return path
