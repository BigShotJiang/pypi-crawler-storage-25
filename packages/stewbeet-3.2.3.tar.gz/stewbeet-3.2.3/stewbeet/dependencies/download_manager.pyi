import stouputils as stp
from ..core.constants import LATEST_MC_VERSION as LATEST_MC_VERSION
from .official_libs import OFFICIAL_LIBS as OFFICIAL_LIBS
from beet import Context as Context
from dataclasses import dataclass
from pathlib import Path
from stouputils.typing import JsonDict as JsonDict
from typing import Any

SMITHED_API_BASE: str
MODRINTH_API_BASE: str
HEADERS: dict[str, str]
BUILD_CACHE: dict[str, list[DownloadedLib]]

@dataclass
class DownloadedLib:
    lib_ns: str
    name: str
    version: tuple[int, ...]
    datapack_path: str | None
    resource_pack_path: str | None

def mc_tuple(ctx: Context) -> tuple[int, ...]: ...
def mc_str(ctx: Context) -> str: ...
def lookup_static(lib_data: JsonDict, mc_tup: tuple[int, ...]) -> tuple[tuple[int, ...], str] | None:
    """Return ``(dep_ver, url)`` for the highest MC key ``<= mc_tup``, or ``None``."""
def cached_json(ctx: Context, url: str) -> Any | None: ...
def cached_zip(ctx: Context, url: str) -> Path | None:
    """Download *url* via beet cache, ensuring the file has a ``.zip`` suffix."""
def version_str(ver: list[int] | tuple[int, ...]) -> str: ...
def parse_version(s: str) -> tuple[int, ...]: ...
def mc_compatible(versions: list[JsonDict], mc_tup: tuple[int, ...]) -> list[JsonDict]:
    """Return versions whose supports list includes mc_tup (exact), falling back to max(supports) <= mc_tup."""
def resolve_smithed_lib(ctx: Context, lib_ns: str, lib_data: JsonDict, mc_tup: tuple[int, ...]) -> DownloadedLib | None: ...
def resolve_modrinth_lib(ctx: Context, lib_ns: str, lib_data: JsonDict, mc_ver: str) -> DownloadedLib | None: ...
def resolve_static_lib(ctx: Context, lib_ns: str, lib_data: JsonDict, mc_tup: tuple[int, ...], mc_ver: str) -> DownloadedLib | None: ...
@stp.handle_error
def get_lib_paths(ctx: Context) -> list[DownloadedLib]:
    """Download all ``is_used`` official libs and return their cached paths.

\tResults are memoised per build so weld.py and copy_to_destination can
\tboth call this without redundant work.
\t"""
