"""Detection probability prediction kernels."""
