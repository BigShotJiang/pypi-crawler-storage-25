from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class AcknowledgementCompleted(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.AcknowledgementCompleted",
):
    '''(experimental) EventBridge event pattern for aws.b2bi@AcknowledgementCompleted.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
        
        acknowledgement_completed = b2bi_events.AcknowledgementCompleted()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        ack_error_code_detected: typing.Optional[typing.Sequence[builtins.str]] = None,
        ack_file_s3_attributes: typing.Optional[typing.Union["AcknowledgementCompleted.AckFileS3Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
        ack_x12_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ack_x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        input_file_s3_attributes: typing.Optional[typing.Union["AcknowledgementCompleted.InputFileS3Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
        input_x12_transaction_set: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
        trading_partner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        transformer_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Acknowledgement Completed.

        :param ack_error_code_detected: (experimental) ack-error-code-detected property. Specify an array of string values to match this event if the actual value of ack-error-code-detected is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ack_file_s3_attributes: (experimental) ack-file-s3-attributes property. Specify an array of string values to match this event if the actual value of ack-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ack_x12_type: (experimental) ack-x12-type property. Specify an array of string values to match this event if the actual value of ack-x12-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ack_x12_version: (experimental) ack-x12-version property. Specify an array of string values to match this event if the actual value of ack-x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_timestamp: (experimental) end-timestamp property. Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param input_file_s3_attributes: (experimental) input-file-s3-attributes property. Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_x12_transaction_set: (experimental) input-x12-transaction-set property. Specify an array of string values to match this event if the actual value of input-x12-transaction-set is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_x12_version: (experimental) input-x12-version property. Specify an array of string values to match this event if the actual value of input-x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_timestamp: (experimental) start-timestamp property. Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param trading_partner_id: (experimental) trading-partner-id property. Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transformer_job_id: (experimental) transformer-job-id property. Specify an array of string values to match this event if the actual value of transformer-job-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AcknowledgementCompleted.AcknowledgementCompletedProps(
            ack_error_code_detected=ack_error_code_detected,
            ack_file_s3_attributes=ack_file_s3_attributes,
            ack_x12_type=ack_x12_type,
            ack_x12_version=ack_x12_version,
            end_timestamp=end_timestamp,
            event_metadata=event_metadata,
            input_file_s3_attributes=input_file_s3_attributes,
            input_x12_transaction_set=input_x12_transaction_set,
            input_x12_version=input_x12_version,
            start_timestamp=start_timestamp,
            trading_partner_id=trading_partner_id,
            transformer_job_id=transformer_job_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.AcknowledgementCompleted.AckFileS3Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "bucket": "bucket",
            "object_key": "objectKey",
            "object_size_bytes": "objectSizeBytes",
        },
    )
    class AckFileS3Attributes:
        def __init__(
            self,
            *,
            bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
            object_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            object_size_bytes: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Ack-file-s3-attributes.

            :param bucket: (experimental) bucket property. Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param object_key: (experimental) object-key property. Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param object_size_bytes: (experimental) object-size-bytes property. Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
                
                ack_file_s3_attributes = b2bi_events.AcknowledgementCompleted.AckFileS3Attributes(
                    bucket=["bucket"],
                    object_key=["objectKey"],
                    object_size_bytes=["objectSizeBytes"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0b0675ae997aad959e1613d3a1832e1a8d1636a81af534fe91552b6798c1e7f8)
                check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
                check_type(argname="argument object_key", value=object_key, expected_type=type_hints["object_key"])
                check_type(argname="argument object_size_bytes", value=object_size_bytes, expected_type=type_hints["object_size_bytes"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if bucket is not None:
                self._values["bucket"] = bucket
            if object_key is not None:
                self._values["object_key"] = object_key
            if object_size_bytes is not None:
                self._values["object_size_bytes"] = object_size_bytes

        @builtins.property
        def bucket(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bucket property.

            Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("bucket")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def object_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) object-key property.

            Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("object_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def object_size_bytes(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) object-size-bytes property.

            Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("object_size_bytes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AckFileS3Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.AcknowledgementCompleted.AcknowledgementCompletedProps",
        jsii_struct_bases=[],
        name_mapping={
            "ack_error_code_detected": "ackErrorCodeDetected",
            "ack_file_s3_attributes": "ackFileS3Attributes",
            "ack_x12_type": "ackX12Type",
            "ack_x12_version": "ackX12Version",
            "end_timestamp": "endTimestamp",
            "event_metadata": "eventMetadata",
            "input_file_s3_attributes": "inputFileS3Attributes",
            "input_x12_transaction_set": "inputX12TransactionSet",
            "input_x12_version": "inputX12Version",
            "start_timestamp": "startTimestamp",
            "trading_partner_id": "tradingPartnerId",
            "transformer_job_id": "transformerJobId",
        },
    )
    class AcknowledgementCompletedProps:
        def __init__(
            self,
            *,
            ack_error_code_detected: typing.Optional[typing.Sequence[builtins.str]] = None,
            ack_file_s3_attributes: typing.Optional[typing.Union["AcknowledgementCompleted.AckFileS3Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            ack_x12_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            ack_x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            input_file_s3_attributes: typing.Optional[typing.Union["AcknowledgementCompleted.InputFileS3Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            input_x12_transaction_set: typing.Optional[typing.Sequence[builtins.str]] = None,
            input_x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
            trading_partner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            transformer_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.b2bi@AcknowledgementCompleted event.

            :param ack_error_code_detected: (experimental) ack-error-code-detected property. Specify an array of string values to match this event if the actual value of ack-error-code-detected is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ack_file_s3_attributes: (experimental) ack-file-s3-attributes property. Specify an array of string values to match this event if the actual value of ack-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ack_x12_type: (experimental) ack-x12-type property. Specify an array of string values to match this event if the actual value of ack-x12-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ack_x12_version: (experimental) ack-x12-version property. Specify an array of string values to match this event if the actual value of ack-x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_timestamp: (experimental) end-timestamp property. Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param input_file_s3_attributes: (experimental) input-file-s3-attributes property. Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_x12_transaction_set: (experimental) input-x12-transaction-set property. Specify an array of string values to match this event if the actual value of input-x12-transaction-set is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_x12_version: (experimental) input-x12-version property. Specify an array of string values to match this event if the actual value of input-x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_timestamp: (experimental) start-timestamp property. Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param trading_partner_id: (experimental) trading-partner-id property. Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transformer_job_id: (experimental) transformer-job-id property. Specify an array of string values to match this event if the actual value of transformer-job-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
                
                acknowledgement_completed_props = b2bi_events.AcknowledgementCompleted.AcknowledgementCompletedProps(
                    ack_error_code_detected=["ackErrorCodeDetected"],
                    ack_file_s3_attributes=b2bi_events.AcknowledgementCompleted.AckFileS3Attributes(
                        bucket=["bucket"],
                        object_key=["objectKey"],
                        object_size_bytes=["objectSizeBytes"]
                    ),
                    ack_x12_type=["ackX12Type"],
                    ack_x12_version=["ackX12Version"],
                    end_timestamp=["endTimestamp"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    input_file_s3_attributes=b2bi_events.AcknowledgementCompleted.InputFileS3Attributes(
                        bucket=["bucket"],
                        object_key=["objectKey"],
                        object_size_bytes=["objectSizeBytes"]
                    ),
                    input_x12_transaction_set=["inputX12TransactionSet"],
                    input_x12_version=["inputX12Version"],
                    start_timestamp=["startTimestamp"],
                    trading_partner_id=["tradingPartnerId"],
                    transformer_job_id=["transformerJobId"]
                )
            '''
            if isinstance(ack_file_s3_attributes, dict):
                ack_file_s3_attributes = AcknowledgementCompleted.AckFileS3Attributes(**ack_file_s3_attributes)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(input_file_s3_attributes, dict):
                input_file_s3_attributes = AcknowledgementCompleted.InputFileS3Attributes(**input_file_s3_attributes)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0cf013bf53fddf9196bf5ab63e98f3d69a8556bcc224357521e5df1031793c2d)
                check_type(argname="argument ack_error_code_detected", value=ack_error_code_detected, expected_type=type_hints["ack_error_code_detected"])
                check_type(argname="argument ack_file_s3_attributes", value=ack_file_s3_attributes, expected_type=type_hints["ack_file_s3_attributes"])
                check_type(argname="argument ack_x12_type", value=ack_x12_type, expected_type=type_hints["ack_x12_type"])
                check_type(argname="argument ack_x12_version", value=ack_x12_version, expected_type=type_hints["ack_x12_version"])
                check_type(argname="argument end_timestamp", value=end_timestamp, expected_type=type_hints["end_timestamp"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument input_file_s3_attributes", value=input_file_s3_attributes, expected_type=type_hints["input_file_s3_attributes"])
                check_type(argname="argument input_x12_transaction_set", value=input_x12_transaction_set, expected_type=type_hints["input_x12_transaction_set"])
                check_type(argname="argument input_x12_version", value=input_x12_version, expected_type=type_hints["input_x12_version"])
                check_type(argname="argument start_timestamp", value=start_timestamp, expected_type=type_hints["start_timestamp"])
                check_type(argname="argument trading_partner_id", value=trading_partner_id, expected_type=type_hints["trading_partner_id"])
                check_type(argname="argument transformer_job_id", value=transformer_job_id, expected_type=type_hints["transformer_job_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if ack_error_code_detected is not None:
                self._values["ack_error_code_detected"] = ack_error_code_detected
            if ack_file_s3_attributes is not None:
                self._values["ack_file_s3_attributes"] = ack_file_s3_attributes
            if ack_x12_type is not None:
                self._values["ack_x12_type"] = ack_x12_type
            if ack_x12_version is not None:
                self._values["ack_x12_version"] = ack_x12_version
            if end_timestamp is not None:
                self._values["end_timestamp"] = end_timestamp
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if input_file_s3_attributes is not None:
                self._values["input_file_s3_attributes"] = input_file_s3_attributes
            if input_x12_transaction_set is not None:
                self._values["input_x12_transaction_set"] = input_x12_transaction_set
            if input_x12_version is not None:
                self._values["input_x12_version"] = input_x12_version
            if start_timestamp is not None:
                self._values["start_timestamp"] = start_timestamp
            if trading_partner_id is not None:
                self._values["trading_partner_id"] = trading_partner_id
            if transformer_job_id is not None:
                self._values["transformer_job_id"] = transformer_job_id

        @builtins.property
        def ack_error_code_detected(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ack-error-code-detected property.

            Specify an array of string values to match this event if the actual value of ack-error-code-detected is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ack_error_code_detected")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ack_file_s3_attributes(
            self,
        ) -> typing.Optional["AcknowledgementCompleted.AckFileS3Attributes"]:
            '''(experimental) ack-file-s3-attributes property.

            Specify an array of string values to match this event if the actual value of ack-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ack_file_s3_attributes")
            return typing.cast(typing.Optional["AcknowledgementCompleted.AckFileS3Attributes"], result)

        @builtins.property
        def ack_x12_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ack-x12-type property.

            Specify an array of string values to match this event if the actual value of ack-x12-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ack_x12_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ack_x12_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ack-x12-version property.

            Specify an array of string values to match this event if the actual value of ack-x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ack_x12_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_timestamp(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) end-timestamp property.

            Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_timestamp")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def input_file_s3_attributes(
            self,
        ) -> typing.Optional["AcknowledgementCompleted.InputFileS3Attributes"]:
            '''(experimental) input-file-s3-attributes property.

            Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_file_s3_attributes")
            return typing.cast(typing.Optional["AcknowledgementCompleted.InputFileS3Attributes"], result)

        @builtins.property
        def input_x12_transaction_set(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) input-x12-transaction-set property.

            Specify an array of string values to match this event if the actual value of input-x12-transaction-set is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_x12_transaction_set")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def input_x12_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) input-x12-version property.

            Specify an array of string values to match this event if the actual value of input-x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_x12_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_timestamp(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) start-timestamp property.

            Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_timestamp")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def trading_partner_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) trading-partner-id property.

            Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("trading_partner_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def transformer_job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) transformer-job-id property.

            Specify an array of string values to match this event if the actual value of transformer-job-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transformer_job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AcknowledgementCompletedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.AcknowledgementCompleted.InputFileS3Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "bucket": "bucket",
            "object_key": "objectKey",
            "object_size_bytes": "objectSizeBytes",
        },
    )
    class InputFileS3Attributes:
        def __init__(
            self,
            *,
            bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
            object_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            object_size_bytes: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Input-file-s3-attributes.

            :param bucket: (experimental) bucket property. Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param object_key: (experimental) object-key property. Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param object_size_bytes: (experimental) object-size-bytes property. Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
                
                input_file_s3_attributes = b2bi_events.AcknowledgementCompleted.InputFileS3Attributes(
                    bucket=["bucket"],
                    object_key=["objectKey"],
                    object_size_bytes=["objectSizeBytes"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__aac94137edbd094e5a35f1a5018f1740090c8ee6ba3e6bf30fe602a183767007)
                check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
                check_type(argname="argument object_key", value=object_key, expected_type=type_hints["object_key"])
                check_type(argname="argument object_size_bytes", value=object_size_bytes, expected_type=type_hints["object_size_bytes"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if bucket is not None:
                self._values["bucket"] = bucket
            if object_key is not None:
                self._values["object_key"] = object_key
            if object_size_bytes is not None:
                self._values["object_size_bytes"] = object_size_bytes

        @builtins.property
        def bucket(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bucket property.

            Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("bucket")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def object_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) object-key property.

            Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("object_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def object_size_bytes(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) object-size-bytes property.

            Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("object_size_bytes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InputFileS3Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class AcknowledgementFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.AcknowledgementFailed",
):
    '''(experimental) EventBridge event pattern for aws.b2bi@AcknowledgementFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
        
        acknowledgement_failed = b2bi_events.AcknowledgementFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        ack_x12_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ack_x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        failure_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        failure_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_file_s3_attributes: typing.Optional[typing.Union["AcknowledgementFailed.InputFileS3Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
        input_x12_transaction_set: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
        trading_partner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        transformer_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Acknowledgement Failed.

        :param ack_x12_type: (experimental) ack-x12-type property. Specify an array of string values to match this event if the actual value of ack-x12-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ack_x12_version: (experimental) ack-x12-version property. Specify an array of string values to match this event if the actual value of ack-x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_timestamp: (experimental) end-timestamp property. Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param failure_code: (experimental) failure-code property. Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param failure_message: (experimental) failure-message property. Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_file_s3_attributes: (experimental) input-file-s3-attributes property. Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_x12_transaction_set: (experimental) input-x12-transaction-set property. Specify an array of string values to match this event if the actual value of input-x12-transaction-set is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_x12_version: (experimental) input-x12-version property. Specify an array of string values to match this event if the actual value of input-x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_timestamp: (experimental) start-timestamp property. Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param trading_partner_id: (experimental) trading-partner-id property. Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transformer_job_id: (experimental) transformer-job-id property. Specify an array of string values to match this event if the actual value of transformer-job-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AcknowledgementFailed.AcknowledgementFailedProps(
            ack_x12_type=ack_x12_type,
            ack_x12_version=ack_x12_version,
            end_timestamp=end_timestamp,
            event_metadata=event_metadata,
            failure_code=failure_code,
            failure_message=failure_message,
            input_file_s3_attributes=input_file_s3_attributes,
            input_x12_transaction_set=input_x12_transaction_set,
            input_x12_version=input_x12_version,
            start_timestamp=start_timestamp,
            trading_partner_id=trading_partner_id,
            transformer_job_id=transformer_job_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.AcknowledgementFailed.AcknowledgementFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "ack_x12_type": "ackX12Type",
            "ack_x12_version": "ackX12Version",
            "end_timestamp": "endTimestamp",
            "event_metadata": "eventMetadata",
            "failure_code": "failureCode",
            "failure_message": "failureMessage",
            "input_file_s3_attributes": "inputFileS3Attributes",
            "input_x12_transaction_set": "inputX12TransactionSet",
            "input_x12_version": "inputX12Version",
            "start_timestamp": "startTimestamp",
            "trading_partner_id": "tradingPartnerId",
            "transformer_job_id": "transformerJobId",
        },
    )
    class AcknowledgementFailedProps:
        def __init__(
            self,
            *,
            ack_x12_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            ack_x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            failure_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            failure_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            input_file_s3_attributes: typing.Optional[typing.Union["AcknowledgementFailed.InputFileS3Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            input_x12_transaction_set: typing.Optional[typing.Sequence[builtins.str]] = None,
            input_x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
            trading_partner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            transformer_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.b2bi@AcknowledgementFailed event.

            :param ack_x12_type: (experimental) ack-x12-type property. Specify an array of string values to match this event if the actual value of ack-x12-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ack_x12_version: (experimental) ack-x12-version property. Specify an array of string values to match this event if the actual value of ack-x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_timestamp: (experimental) end-timestamp property. Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param failure_code: (experimental) failure-code property. Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param failure_message: (experimental) failure-message property. Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_file_s3_attributes: (experimental) input-file-s3-attributes property. Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_x12_transaction_set: (experimental) input-x12-transaction-set property. Specify an array of string values to match this event if the actual value of input-x12-transaction-set is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_x12_version: (experimental) input-x12-version property. Specify an array of string values to match this event if the actual value of input-x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_timestamp: (experimental) start-timestamp property. Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param trading_partner_id: (experimental) trading-partner-id property. Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transformer_job_id: (experimental) transformer-job-id property. Specify an array of string values to match this event if the actual value of transformer-job-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
                
                acknowledgement_failed_props = b2bi_events.AcknowledgementFailed.AcknowledgementFailedProps(
                    ack_x12_type=["ackX12Type"],
                    ack_x12_version=["ackX12Version"],
                    end_timestamp=["endTimestamp"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    failure_code=["failureCode"],
                    failure_message=["failureMessage"],
                    input_file_s3_attributes=b2bi_events.AcknowledgementFailed.InputFileS3Attributes(
                        bucket=["bucket"],
                        object_key=["objectKey"],
                        object_size_bytes=["objectSizeBytes"]
                    ),
                    input_x12_transaction_set=["inputX12TransactionSet"],
                    input_x12_version=["inputX12Version"],
                    start_timestamp=["startTimestamp"],
                    trading_partner_id=["tradingPartnerId"],
                    transformer_job_id=["transformerJobId"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(input_file_s3_attributes, dict):
                input_file_s3_attributes = AcknowledgementFailed.InputFileS3Attributes(**input_file_s3_attributes)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d8af6edee6d84b1122e02f09773d7155ba5b13e2522ea466451dcbc399116326)
                check_type(argname="argument ack_x12_type", value=ack_x12_type, expected_type=type_hints["ack_x12_type"])
                check_type(argname="argument ack_x12_version", value=ack_x12_version, expected_type=type_hints["ack_x12_version"])
                check_type(argname="argument end_timestamp", value=end_timestamp, expected_type=type_hints["end_timestamp"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument failure_code", value=failure_code, expected_type=type_hints["failure_code"])
                check_type(argname="argument failure_message", value=failure_message, expected_type=type_hints["failure_message"])
                check_type(argname="argument input_file_s3_attributes", value=input_file_s3_attributes, expected_type=type_hints["input_file_s3_attributes"])
                check_type(argname="argument input_x12_transaction_set", value=input_x12_transaction_set, expected_type=type_hints["input_x12_transaction_set"])
                check_type(argname="argument input_x12_version", value=input_x12_version, expected_type=type_hints["input_x12_version"])
                check_type(argname="argument start_timestamp", value=start_timestamp, expected_type=type_hints["start_timestamp"])
                check_type(argname="argument trading_partner_id", value=trading_partner_id, expected_type=type_hints["trading_partner_id"])
                check_type(argname="argument transformer_job_id", value=transformer_job_id, expected_type=type_hints["transformer_job_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if ack_x12_type is not None:
                self._values["ack_x12_type"] = ack_x12_type
            if ack_x12_version is not None:
                self._values["ack_x12_version"] = ack_x12_version
            if end_timestamp is not None:
                self._values["end_timestamp"] = end_timestamp
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if failure_code is not None:
                self._values["failure_code"] = failure_code
            if failure_message is not None:
                self._values["failure_message"] = failure_message
            if input_file_s3_attributes is not None:
                self._values["input_file_s3_attributes"] = input_file_s3_attributes
            if input_x12_transaction_set is not None:
                self._values["input_x12_transaction_set"] = input_x12_transaction_set
            if input_x12_version is not None:
                self._values["input_x12_version"] = input_x12_version
            if start_timestamp is not None:
                self._values["start_timestamp"] = start_timestamp
            if trading_partner_id is not None:
                self._values["trading_partner_id"] = trading_partner_id
            if transformer_job_id is not None:
                self._values["transformer_job_id"] = transformer_job_id

        @builtins.property
        def ack_x12_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ack-x12-type property.

            Specify an array of string values to match this event if the actual value of ack-x12-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ack_x12_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ack_x12_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ack-x12-version property.

            Specify an array of string values to match this event if the actual value of ack-x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ack_x12_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_timestamp(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) end-timestamp property.

            Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_timestamp")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def failure_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) failure-code property.

            Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("failure_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def failure_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) failure-message property.

            Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("failure_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def input_file_s3_attributes(
            self,
        ) -> typing.Optional["AcknowledgementFailed.InputFileS3Attributes"]:
            '''(experimental) input-file-s3-attributes property.

            Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_file_s3_attributes")
            return typing.cast(typing.Optional["AcknowledgementFailed.InputFileS3Attributes"], result)

        @builtins.property
        def input_x12_transaction_set(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) input-x12-transaction-set property.

            Specify an array of string values to match this event if the actual value of input-x12-transaction-set is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_x12_transaction_set")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def input_x12_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) input-x12-version property.

            Specify an array of string values to match this event if the actual value of input-x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_x12_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_timestamp(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) start-timestamp property.

            Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_timestamp")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def trading_partner_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) trading-partner-id property.

            Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("trading_partner_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def transformer_job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) transformer-job-id property.

            Specify an array of string values to match this event if the actual value of transformer-job-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transformer_job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AcknowledgementFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.AcknowledgementFailed.InputFileS3Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "bucket": "bucket",
            "object_key": "objectKey",
            "object_size_bytes": "objectSizeBytes",
        },
    )
    class InputFileS3Attributes:
        def __init__(
            self,
            *,
            bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
            object_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            object_size_bytes: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Input-file-s3-attributes.

            :param bucket: (experimental) bucket property. Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param object_key: (experimental) object-key property. Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param object_size_bytes: (experimental) object-size-bytes property. Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
                
                input_file_s3_attributes = b2bi_events.AcknowledgementFailed.InputFileS3Attributes(
                    bucket=["bucket"],
                    object_key=["objectKey"],
                    object_size_bytes=["objectSizeBytes"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__828e6736dc00aa7f8ad439c279c403dda48d04d9bee818e58bb5c50543798c22)
                check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
                check_type(argname="argument object_key", value=object_key, expected_type=type_hints["object_key"])
                check_type(argname="argument object_size_bytes", value=object_size_bytes, expected_type=type_hints["object_size_bytes"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if bucket is not None:
                self._values["bucket"] = bucket
            if object_key is not None:
                self._values["object_key"] = object_key
            if object_size_bytes is not None:
                self._values["object_size_bytes"] = object_size_bytes

        @builtins.property
        def bucket(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bucket property.

            Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("bucket")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def object_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) object-key property.

            Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("object_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def object_size_bytes(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) object-size-bytes property.

            Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("object_size_bytes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InputFileS3Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class TransformationCompleted(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.TransformationCompleted",
):
    '''(experimental) EventBridge event pattern for aws.b2bi@TransformationCompleted.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
        
        transformation_completed = b2bi_events.TransformationCompleted()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        ack_error_code_detected: typing.Optional[typing.Sequence[builtins.str]] = None,
        ack_generation_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        input_file_s3_attributes: typing.Optional[typing.Union["TransformationCompleted.InputFileS3Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
        output_file_s3_attributes: typing.Optional[typing.Union["TransformationCompleted.OutputFileS3Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
        start_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
        trading_partner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        x12_transaction_set: typing.Optional[typing.Sequence[builtins.str]] = None,
        x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Transformation Completed.

        :param ack_error_code_detected: (experimental) ack-error-code-detected property. Specify an array of string values to match this event if the actual value of ack-error-code-detected is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ack_generation_status: (experimental) ack-generation-status property. Specify an array of string values to match this event if the actual value of ack-generation-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_timestamp: (experimental) end-timestamp property. Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param input_file_s3_attributes: (experimental) input-file-s3-attributes property. Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_file_s3_attributes: (experimental) output-file-s3-attributes property. Specify an array of string values to match this event if the actual value of output-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_timestamp: (experimental) start-timestamp property. Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param trading_partner_id: (experimental) trading-partner-id property. Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param x12_transaction_set: (experimental) x12-transaction-set property. Specify an array of string values to match this event if the actual value of x12-transaction-set is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param x12_version: (experimental) x12-version property. Specify an array of string values to match this event if the actual value of x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = TransformationCompleted.TransformationCompletedProps(
            ack_error_code_detected=ack_error_code_detected,
            ack_generation_status=ack_generation_status,
            end_timestamp=end_timestamp,
            event_metadata=event_metadata,
            input_file_s3_attributes=input_file_s3_attributes,
            output_file_s3_attributes=output_file_s3_attributes,
            start_timestamp=start_timestamp,
            trading_partner_id=trading_partner_id,
            x12_transaction_set=x12_transaction_set,
            x12_version=x12_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.TransformationCompleted.InputFileS3Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "bucket": "bucket",
            "object_key": "objectKey",
            "object_size_bytes": "objectSizeBytes",
        },
    )
    class InputFileS3Attributes:
        def __init__(
            self,
            *,
            bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
            object_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            object_size_bytes: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Input-file-s3-attributes.

            :param bucket: (experimental) bucket property. Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param object_key: (experimental) object-key property. Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param object_size_bytes: (experimental) object-size-bytes property. Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
                
                input_file_s3_attributes = b2bi_events.TransformationCompleted.InputFileS3Attributes(
                    bucket=["bucket"],
                    object_key=["objectKey"],
                    object_size_bytes=["objectSizeBytes"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a27490032701acae855c16ae281d3fc550b19d33a93afe14b02c333854422328)
                check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
                check_type(argname="argument object_key", value=object_key, expected_type=type_hints["object_key"])
                check_type(argname="argument object_size_bytes", value=object_size_bytes, expected_type=type_hints["object_size_bytes"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if bucket is not None:
                self._values["bucket"] = bucket
            if object_key is not None:
                self._values["object_key"] = object_key
            if object_size_bytes is not None:
                self._values["object_size_bytes"] = object_size_bytes

        @builtins.property
        def bucket(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bucket property.

            Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("bucket")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def object_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) object-key property.

            Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("object_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def object_size_bytes(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) object-size-bytes property.

            Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("object_size_bytes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InputFileS3Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.TransformationCompleted.OutputFileS3Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "bucket": "bucket",
            "object_key": "objectKey",
            "object_size_bytes": "objectSizeBytes",
        },
    )
    class OutputFileS3Attributes:
        def __init__(
            self,
            *,
            bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
            object_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            object_size_bytes: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Output-file-s3-attributes.

            :param bucket: (experimental) bucket property. Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param object_key: (experimental) object-key property. Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param object_size_bytes: (experimental) object-size-bytes property. Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
                
                output_file_s3_attributes = b2bi_events.TransformationCompleted.OutputFileS3Attributes(
                    bucket=["bucket"],
                    object_key=["objectKey"],
                    object_size_bytes=["objectSizeBytes"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1073811acda23551534b7a17a199526ab9c03ef809cd8d40339fc762e0a0b956)
                check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
                check_type(argname="argument object_key", value=object_key, expected_type=type_hints["object_key"])
                check_type(argname="argument object_size_bytes", value=object_size_bytes, expected_type=type_hints["object_size_bytes"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if bucket is not None:
                self._values["bucket"] = bucket
            if object_key is not None:
                self._values["object_key"] = object_key
            if object_size_bytes is not None:
                self._values["object_size_bytes"] = object_size_bytes

        @builtins.property
        def bucket(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bucket property.

            Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("bucket")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def object_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) object-key property.

            Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("object_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def object_size_bytes(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) object-size-bytes property.

            Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("object_size_bytes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OutputFileS3Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.TransformationCompleted.TransformationCompletedProps",
        jsii_struct_bases=[],
        name_mapping={
            "ack_error_code_detected": "ackErrorCodeDetected",
            "ack_generation_status": "ackGenerationStatus",
            "end_timestamp": "endTimestamp",
            "event_metadata": "eventMetadata",
            "input_file_s3_attributes": "inputFileS3Attributes",
            "output_file_s3_attributes": "outputFileS3Attributes",
            "start_timestamp": "startTimestamp",
            "trading_partner_id": "tradingPartnerId",
            "x12_transaction_set": "x12TransactionSet",
            "x12_version": "x12Version",
        },
    )
    class TransformationCompletedProps:
        def __init__(
            self,
            *,
            ack_error_code_detected: typing.Optional[typing.Sequence[builtins.str]] = None,
            ack_generation_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            input_file_s3_attributes: typing.Optional[typing.Union["TransformationCompleted.InputFileS3Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            output_file_s3_attributes: typing.Optional[typing.Union["TransformationCompleted.OutputFileS3Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            start_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
            trading_partner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            x12_transaction_set: typing.Optional[typing.Sequence[builtins.str]] = None,
            x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.b2bi@TransformationCompleted event.

            :param ack_error_code_detected: (experimental) ack-error-code-detected property. Specify an array of string values to match this event if the actual value of ack-error-code-detected is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ack_generation_status: (experimental) ack-generation-status property. Specify an array of string values to match this event if the actual value of ack-generation-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_timestamp: (experimental) end-timestamp property. Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param input_file_s3_attributes: (experimental) input-file-s3-attributes property. Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_file_s3_attributes: (experimental) output-file-s3-attributes property. Specify an array of string values to match this event if the actual value of output-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_timestamp: (experimental) start-timestamp property. Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param trading_partner_id: (experimental) trading-partner-id property. Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param x12_transaction_set: (experimental) x12-transaction-set property. Specify an array of string values to match this event if the actual value of x12-transaction-set is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param x12_version: (experimental) x12-version property. Specify an array of string values to match this event if the actual value of x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
                
                transformation_completed_props = b2bi_events.TransformationCompleted.TransformationCompletedProps(
                    ack_error_code_detected=["ackErrorCodeDetected"],
                    ack_generation_status=["ackGenerationStatus"],
                    end_timestamp=["endTimestamp"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    input_file_s3_attributes=b2bi_events.TransformationCompleted.InputFileS3Attributes(
                        bucket=["bucket"],
                        object_key=["objectKey"],
                        object_size_bytes=["objectSizeBytes"]
                    ),
                    output_file_s3_attributes=b2bi_events.TransformationCompleted.OutputFileS3Attributes(
                        bucket=["bucket"],
                        object_key=["objectKey"],
                        object_size_bytes=["objectSizeBytes"]
                    ),
                    start_timestamp=["startTimestamp"],
                    trading_partner_id=["tradingPartnerId"],
                    x12_transaction_set=["x12TransactionSet"],
                    x12_version=["x12Version"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(input_file_s3_attributes, dict):
                input_file_s3_attributes = TransformationCompleted.InputFileS3Attributes(**input_file_s3_attributes)
            if isinstance(output_file_s3_attributes, dict):
                output_file_s3_attributes = TransformationCompleted.OutputFileS3Attributes(**output_file_s3_attributes)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__43acda91640ec5e1e171ed4bc8fc6a6b0a875b2a7bf7312a7520b1e42b01ab61)
                check_type(argname="argument ack_error_code_detected", value=ack_error_code_detected, expected_type=type_hints["ack_error_code_detected"])
                check_type(argname="argument ack_generation_status", value=ack_generation_status, expected_type=type_hints["ack_generation_status"])
                check_type(argname="argument end_timestamp", value=end_timestamp, expected_type=type_hints["end_timestamp"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument input_file_s3_attributes", value=input_file_s3_attributes, expected_type=type_hints["input_file_s3_attributes"])
                check_type(argname="argument output_file_s3_attributes", value=output_file_s3_attributes, expected_type=type_hints["output_file_s3_attributes"])
                check_type(argname="argument start_timestamp", value=start_timestamp, expected_type=type_hints["start_timestamp"])
                check_type(argname="argument trading_partner_id", value=trading_partner_id, expected_type=type_hints["trading_partner_id"])
                check_type(argname="argument x12_transaction_set", value=x12_transaction_set, expected_type=type_hints["x12_transaction_set"])
                check_type(argname="argument x12_version", value=x12_version, expected_type=type_hints["x12_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if ack_error_code_detected is not None:
                self._values["ack_error_code_detected"] = ack_error_code_detected
            if ack_generation_status is not None:
                self._values["ack_generation_status"] = ack_generation_status
            if end_timestamp is not None:
                self._values["end_timestamp"] = end_timestamp
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if input_file_s3_attributes is not None:
                self._values["input_file_s3_attributes"] = input_file_s3_attributes
            if output_file_s3_attributes is not None:
                self._values["output_file_s3_attributes"] = output_file_s3_attributes
            if start_timestamp is not None:
                self._values["start_timestamp"] = start_timestamp
            if trading_partner_id is not None:
                self._values["trading_partner_id"] = trading_partner_id
            if x12_transaction_set is not None:
                self._values["x12_transaction_set"] = x12_transaction_set
            if x12_version is not None:
                self._values["x12_version"] = x12_version

        @builtins.property
        def ack_error_code_detected(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ack-error-code-detected property.

            Specify an array of string values to match this event if the actual value of ack-error-code-detected is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ack_error_code_detected")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ack_generation_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ack-generation-status property.

            Specify an array of string values to match this event if the actual value of ack-generation-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ack_generation_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_timestamp(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) end-timestamp property.

            Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_timestamp")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def input_file_s3_attributes(
            self,
        ) -> typing.Optional["TransformationCompleted.InputFileS3Attributes"]:
            '''(experimental) input-file-s3-attributes property.

            Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_file_s3_attributes")
            return typing.cast(typing.Optional["TransformationCompleted.InputFileS3Attributes"], result)

        @builtins.property
        def output_file_s3_attributes(
            self,
        ) -> typing.Optional["TransformationCompleted.OutputFileS3Attributes"]:
            '''(experimental) output-file-s3-attributes property.

            Specify an array of string values to match this event if the actual value of output-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_file_s3_attributes")
            return typing.cast(typing.Optional["TransformationCompleted.OutputFileS3Attributes"], result)

        @builtins.property
        def start_timestamp(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) start-timestamp property.

            Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_timestamp")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def trading_partner_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) trading-partner-id property.

            Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("trading_partner_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def x12_transaction_set(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) x12-transaction-set property.

            Specify an array of string values to match this event if the actual value of x12-transaction-set is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("x12_transaction_set")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def x12_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) x12-version property.

            Specify an array of string values to match this event if the actual value of x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("x12_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TransformationCompletedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class TransformationFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.TransformationFailed",
):
    '''(experimental) EventBridge event pattern for aws.b2bi@TransformationFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
        
        transformation_failed = b2bi_events.TransformationFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        ack_error_code_detected: typing.Optional[typing.Sequence[builtins.str]] = None,
        ack_generation_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        failure_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        failure_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_file_s3_attributes: typing.Optional[typing.Union["TransformationFailed.InputFileS3Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
        start_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
        trading_partner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        x12_transaction_set: typing.Optional[typing.Sequence[builtins.str]] = None,
        x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Transformation Failed.

        :param ack_error_code_detected: (experimental) ack-error-code-detected property. Specify an array of string values to match this event if the actual value of ack-error-code-detected is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ack_generation_status: (experimental) ack-generation-status property. Specify an array of string values to match this event if the actual value of ack-generation-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_timestamp: (experimental) end-timestamp property. Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param failure_code: (experimental) failure-code property. Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param failure_message: (experimental) failure-message property. Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_file_s3_attributes: (experimental) input-file-s3-attributes property. Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_timestamp: (experimental) start-timestamp property. Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param trading_partner_id: (experimental) trading-partner-id property. Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param x12_transaction_set: (experimental) x12-transaction-set property. Specify an array of string values to match this event if the actual value of x12-transaction-set is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param x12_version: (experimental) x12-version property. Specify an array of string values to match this event if the actual value of x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = TransformationFailed.TransformationFailedProps(
            ack_error_code_detected=ack_error_code_detected,
            ack_generation_status=ack_generation_status,
            end_timestamp=end_timestamp,
            event_metadata=event_metadata,
            failure_code=failure_code,
            failure_message=failure_message,
            input_file_s3_attributes=input_file_s3_attributes,
            start_timestamp=start_timestamp,
            trading_partner_id=trading_partner_id,
            x12_transaction_set=x12_transaction_set,
            x12_version=x12_version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.TransformationFailed.InputFileS3Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "bucket": "bucket",
            "object_key": "objectKey",
            "object_size_bytes": "objectSizeBytes",
        },
    )
    class InputFileS3Attributes:
        def __init__(
            self,
            *,
            bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
            object_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            object_size_bytes: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Input-file-s3-attributes.

            :param bucket: (experimental) bucket property. Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param object_key: (experimental) object-key property. Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param object_size_bytes: (experimental) object-size-bytes property. Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
                
                input_file_s3_attributes = b2bi_events.TransformationFailed.InputFileS3Attributes(
                    bucket=["bucket"],
                    object_key=["objectKey"],
                    object_size_bytes=["objectSizeBytes"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__46c8fd27fcbb16bfb50f9c21a11b485d7be7694601b64b238dc9e54ff8a660b8)
                check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
                check_type(argname="argument object_key", value=object_key, expected_type=type_hints["object_key"])
                check_type(argname="argument object_size_bytes", value=object_size_bytes, expected_type=type_hints["object_size_bytes"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if bucket is not None:
                self._values["bucket"] = bucket
            if object_key is not None:
                self._values["object_key"] = object_key
            if object_size_bytes is not None:
                self._values["object_size_bytes"] = object_size_bytes

        @builtins.property
        def bucket(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bucket property.

            Specify an array of string values to match this event if the actual value of bucket is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("bucket")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def object_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) object-key property.

            Specify an array of string values to match this event if the actual value of object-key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("object_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def object_size_bytes(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) object-size-bytes property.

            Specify an array of string values to match this event if the actual value of object-size-bytes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("object_size_bytes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InputFileS3Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_b2bi.events.TransformationFailed.TransformationFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "ack_error_code_detected": "ackErrorCodeDetected",
            "ack_generation_status": "ackGenerationStatus",
            "end_timestamp": "endTimestamp",
            "event_metadata": "eventMetadata",
            "failure_code": "failureCode",
            "failure_message": "failureMessage",
            "input_file_s3_attributes": "inputFileS3Attributes",
            "start_timestamp": "startTimestamp",
            "trading_partner_id": "tradingPartnerId",
            "x12_transaction_set": "x12TransactionSet",
            "x12_version": "x12Version",
        },
    )
    class TransformationFailedProps:
        def __init__(
            self,
            *,
            ack_error_code_detected: typing.Optional[typing.Sequence[builtins.str]] = None,
            ack_generation_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            failure_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            failure_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            input_file_s3_attributes: typing.Optional[typing.Union["TransformationFailed.InputFileS3Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            start_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
            trading_partner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            x12_transaction_set: typing.Optional[typing.Sequence[builtins.str]] = None,
            x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.b2bi@TransformationFailed event.

            :param ack_error_code_detected: (experimental) ack-error-code-detected property. Specify an array of string values to match this event if the actual value of ack-error-code-detected is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ack_generation_status: (experimental) ack-generation-status property. Specify an array of string values to match this event if the actual value of ack-generation-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_timestamp: (experimental) end-timestamp property. Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param failure_code: (experimental) failure-code property. Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param failure_message: (experimental) failure-message property. Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_file_s3_attributes: (experimental) input-file-s3-attributes property. Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_timestamp: (experimental) start-timestamp property. Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param trading_partner_id: (experimental) trading-partner-id property. Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param x12_transaction_set: (experimental) x12-transaction-set property. Specify an array of string values to match this event if the actual value of x12-transaction-set is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param x12_version: (experimental) x12-version property. Specify an array of string values to match this event if the actual value of x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_b2bi import events as b2bi_events
                
                transformation_failed_props = b2bi_events.TransformationFailed.TransformationFailedProps(
                    ack_error_code_detected=["ackErrorCodeDetected"],
                    ack_generation_status=["ackGenerationStatus"],
                    end_timestamp=["endTimestamp"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    failure_code=["failureCode"],
                    failure_message=["failureMessage"],
                    input_file_s3_attributes=b2bi_events.TransformationFailed.InputFileS3Attributes(
                        bucket=["bucket"],
                        object_key=["objectKey"],
                        object_size_bytes=["objectSizeBytes"]
                    ),
                    start_timestamp=["startTimestamp"],
                    trading_partner_id=["tradingPartnerId"],
                    x12_transaction_set=["x12TransactionSet"],
                    x12_version=["x12Version"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(input_file_s3_attributes, dict):
                input_file_s3_attributes = TransformationFailed.InputFileS3Attributes(**input_file_s3_attributes)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9bdf4173c23e1ffc4cff7fb6e00922ecf38ae1da62e823c2b8c96727c809aeb5)
                check_type(argname="argument ack_error_code_detected", value=ack_error_code_detected, expected_type=type_hints["ack_error_code_detected"])
                check_type(argname="argument ack_generation_status", value=ack_generation_status, expected_type=type_hints["ack_generation_status"])
                check_type(argname="argument end_timestamp", value=end_timestamp, expected_type=type_hints["end_timestamp"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument failure_code", value=failure_code, expected_type=type_hints["failure_code"])
                check_type(argname="argument failure_message", value=failure_message, expected_type=type_hints["failure_message"])
                check_type(argname="argument input_file_s3_attributes", value=input_file_s3_attributes, expected_type=type_hints["input_file_s3_attributes"])
                check_type(argname="argument start_timestamp", value=start_timestamp, expected_type=type_hints["start_timestamp"])
                check_type(argname="argument trading_partner_id", value=trading_partner_id, expected_type=type_hints["trading_partner_id"])
                check_type(argname="argument x12_transaction_set", value=x12_transaction_set, expected_type=type_hints["x12_transaction_set"])
                check_type(argname="argument x12_version", value=x12_version, expected_type=type_hints["x12_version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if ack_error_code_detected is not None:
                self._values["ack_error_code_detected"] = ack_error_code_detected
            if ack_generation_status is not None:
                self._values["ack_generation_status"] = ack_generation_status
            if end_timestamp is not None:
                self._values["end_timestamp"] = end_timestamp
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if failure_code is not None:
                self._values["failure_code"] = failure_code
            if failure_message is not None:
                self._values["failure_message"] = failure_message
            if input_file_s3_attributes is not None:
                self._values["input_file_s3_attributes"] = input_file_s3_attributes
            if start_timestamp is not None:
                self._values["start_timestamp"] = start_timestamp
            if trading_partner_id is not None:
                self._values["trading_partner_id"] = trading_partner_id
            if x12_transaction_set is not None:
                self._values["x12_transaction_set"] = x12_transaction_set
            if x12_version is not None:
                self._values["x12_version"] = x12_version

        @builtins.property
        def ack_error_code_detected(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ack-error-code-detected property.

            Specify an array of string values to match this event if the actual value of ack-error-code-detected is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ack_error_code_detected")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ack_generation_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ack-generation-status property.

            Specify an array of string values to match this event if the actual value of ack-generation-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ack_generation_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_timestamp(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) end-timestamp property.

            Specify an array of string values to match this event if the actual value of end-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_timestamp")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def failure_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) failure-code property.

            Specify an array of string values to match this event if the actual value of failure-code is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("failure_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def failure_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) failure-message property.

            Specify an array of string values to match this event if the actual value of failure-message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("failure_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def input_file_s3_attributes(
            self,
        ) -> typing.Optional["TransformationFailed.InputFileS3Attributes"]:
            '''(experimental) input-file-s3-attributes property.

            Specify an array of string values to match this event if the actual value of input-file-s3-attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_file_s3_attributes")
            return typing.cast(typing.Optional["TransformationFailed.InputFileS3Attributes"], result)

        @builtins.property
        def start_timestamp(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) start-timestamp property.

            Specify an array of string values to match this event if the actual value of start-timestamp is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_timestamp")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def trading_partner_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) trading-partner-id property.

            Specify an array of string values to match this event if the actual value of trading-partner-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("trading_partner_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def x12_transaction_set(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) x12-transaction-set property.

            Specify an array of string values to match this event if the actual value of x12-transaction-set is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("x12_transaction_set")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def x12_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) x12-version property.

            Specify an array of string values to match this event if the actual value of x12-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("x12_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TransformationFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "AcknowledgementCompleted",
    "AcknowledgementFailed",
    "TransformationCompleted",
    "TransformationFailed",
]

publication.publish()

def _typecheckingstub__0b0675ae997aad959e1613d3a1832e1a8d1636a81af534fe91552b6798c1e7f8(
    *,
    bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
    object_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    object_size_bytes: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0cf013bf53fddf9196bf5ab63e98f3d69a8556bcc224357521e5df1031793c2d(
    *,
    ack_error_code_detected: typing.Optional[typing.Sequence[builtins.str]] = None,
    ack_file_s3_attributes: typing.Optional[typing.Union[AcknowledgementCompleted.AckFileS3Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    ack_x12_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ack_x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    input_file_s3_attributes: typing.Optional[typing.Union[AcknowledgementCompleted.InputFileS3Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    input_x12_transaction_set: typing.Optional[typing.Sequence[builtins.str]] = None,
    input_x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
    trading_partner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    transformer_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aac94137edbd094e5a35f1a5018f1740090c8ee6ba3e6bf30fe602a183767007(
    *,
    bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
    object_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    object_size_bytes: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d8af6edee6d84b1122e02f09773d7155ba5b13e2522ea466451dcbc399116326(
    *,
    ack_x12_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ack_x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    failure_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    failure_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    input_file_s3_attributes: typing.Optional[typing.Union[AcknowledgementFailed.InputFileS3Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    input_x12_transaction_set: typing.Optional[typing.Sequence[builtins.str]] = None,
    input_x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
    trading_partner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    transformer_job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__828e6736dc00aa7f8ad439c279c403dda48d04d9bee818e58bb5c50543798c22(
    *,
    bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
    object_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    object_size_bytes: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a27490032701acae855c16ae281d3fc550b19d33a93afe14b02c333854422328(
    *,
    bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
    object_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    object_size_bytes: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1073811acda23551534b7a17a199526ab9c03ef809cd8d40339fc762e0a0b956(
    *,
    bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
    object_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    object_size_bytes: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__43acda91640ec5e1e171ed4bc8fc6a6b0a875b2a7bf7312a7520b1e42b01ab61(
    *,
    ack_error_code_detected: typing.Optional[typing.Sequence[builtins.str]] = None,
    ack_generation_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    input_file_s3_attributes: typing.Optional[typing.Union[TransformationCompleted.InputFileS3Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    output_file_s3_attributes: typing.Optional[typing.Union[TransformationCompleted.OutputFileS3Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    start_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
    trading_partner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    x12_transaction_set: typing.Optional[typing.Sequence[builtins.str]] = None,
    x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__46c8fd27fcbb16bfb50f9c21a11b485d7be7694601b64b238dc9e54ff8a660b8(
    *,
    bucket: typing.Optional[typing.Sequence[builtins.str]] = None,
    object_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    object_size_bytes: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9bdf4173c23e1ffc4cff7fb6e00922ecf38ae1da62e823c2b8c96727c809aeb5(
    *,
    ack_error_code_detected: typing.Optional[typing.Sequence[builtins.str]] = None,
    ack_generation_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    failure_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    failure_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    input_file_s3_attributes: typing.Optional[typing.Union[TransformationFailed.InputFileS3Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    start_timestamp: typing.Optional[typing.Sequence[builtins.str]] = None,
    trading_partner_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    x12_transaction_set: typing.Optional[typing.Sequence[builtins.str]] = None,
    x12_version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
