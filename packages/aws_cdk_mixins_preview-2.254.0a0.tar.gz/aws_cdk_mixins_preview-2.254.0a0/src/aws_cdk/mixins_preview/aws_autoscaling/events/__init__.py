from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d
import aws_cdk.interfaces.aws_autoscaling as _aws_cdk_interfaces_aws_autoscaling_ceddda9d


class AWSAPICallViaCloudTrail(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail",
):
    '''(experimental) EventBridge event pattern for aws.autoscaling@AWSAPICallViaCloudTrail.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
        
        a_wSAPICall_via_cloud_trail = autoscaling_events.AWSAPICallViaCloudTrail()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
        source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AWS API Call via CloudTrail.

        :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
            aws_region=aws_region,
            error_code=error_code,
            error_message=error_message,
            event_id=event_id,
            event_metadata=event_metadata,
            event_name=event_name,
            event_source=event_source,
            event_time=event_time,
            event_type=event_type,
            event_version=event_version,
            request_id=request_id,
            request_parameters=request_parameters,
            response_elements=response_elements,
            source_ip_address=source_ip_address,
            user_agent=user_agent,
            user_identity=user_identity,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps",
        jsii_struct_bases=[],
        name_mapping={
            "aws_region": "awsRegion",
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "event_name": "eventName",
            "event_source": "eventSource",
            "event_time": "eventTime",
            "event_type": "eventType",
            "event_version": "eventVersion",
            "request_id": "requestId",
            "request_parameters": "requestParameters",
            "response_elements": "responseElements",
            "source_ip_address": "sourceIpAddress",
            "user_agent": "userAgent",
            "user_identity": "userIdentity",
        },
    )
    class AWSAPICallViaCloudTrailProps:
        def __init__(
            self,
            *,
            aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
            response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
            source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.autoscaling@AWSAPICallViaCloudTrail event.

            :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                # alarms: Any
                # failed_scheduled_actions: Any
                # failed_scheduled_update_group_actions: Any
                # lifecycle_hook_specification_list: Any
                # overrides: Any
                # scheduled_update_group_actions: Any
                
                a_wSAPICall_via_cloud_trail_props = autoscaling_events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
                    aws_region=["awsRegion"],
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    event_name=["eventName"],
                    event_source=["eventSource"],
                    event_time=["eventTime"],
                    event_type=["eventType"],
                    event_version=["eventVersion"],
                    request_id=["requestId"],
                    request_parameters=autoscaling_events.AWSAPICallViaCloudTrail.RequestParameters(
                        adjustment_type=["adjustmentType"],
                        auto_scaling_group_name=["autoScalingGroupName"],
                        availability_zones=["availabilityZones"],
                        breach_threshold=["breachThreshold"],
                        default_cooldown=["defaultCooldown"],
                        desired_capacity=["desiredCapacity"],
                        force_delete=["forceDelete"],
                        granularity=["granularity"],
                        health_check_grace_period=["healthCheckGracePeriod"],
                        health_check_type=["healthCheckType"],
                        honor_cooldown=["honorCooldown"],
                        image_id=["imageId"],
                        instance_ids=["instanceIds"],
                        instance_type=["instanceType"],
                        launch_configuration_name=["launchConfigurationName"],
                        launch_template=autoscaling_events.AWSAPICallViaCloudTrail.LaunchTemplate(
                            launch_template_name=["launchTemplateName"]
                        ),
                        lifecycle_hook_specification_list=[lifecycle_hook_specification_list],
                        load_balancer_names=["loadBalancerNames"],
                        max_size=["maxSize"],
                        metrics=["metrics"],
                        metric_value=["metricValue"],
                        min_size=["minSize"],
                        mixed_instances_policy=autoscaling_events.AWSAPICallViaCloudTrail.MixedInstancesPolicy(
                            instances_distribution=autoscaling_events.AWSAPICallViaCloudTrail.InstancesDistribution(
                                on_demand_allocation_strategy=["onDemandAllocationStrategy"],
                                on_demand_base_capacity=["onDemandBaseCapacity"],
                                on_demand_percentage_above_base_capacity=["onDemandPercentageAboveBaseCapacity"],
                                spot_allocation_strategy=["spotAllocationStrategy"],
                                spot_instance_pools=["spotInstancePools"]
                            ),
                            launch_template=autoscaling_events.AWSAPICallViaCloudTrail.LaunchTemplate1(
                                launch_template_specification=autoscaling_events.AWSAPICallViaCloudTrail.LaunchTemplateSpecification(
                                    launch_template_name=["launchTemplateName"],
                                    version=["version"]
                                ),
                                overrides=[overrides]
                            )
                        ),
                        new_instances_protected_from_scale_in=["newInstancesProtectedFromScaleIn"],
                        notification_types=["notificationTypes"],
                        policy_name=["policyName"],
                        policy_type=["policyType"],
                        protected_from_scale_in=["protectedFromScaleIn"],
                        scaling_adjustment=["scalingAdjustment"],
                        scheduled_action_name=["scheduledActionName"],
                        scheduled_action_names=["scheduledActionNames"],
                        scheduled_update_group_actions=[scheduled_update_group_actions],
                        security_groups=["securityGroups"],
                        service_linked_role_arn=["serviceLinkedRoleArn"],
                        spot_price=["spotPrice"],
                        start_time=["startTime"],
                        step_adjustments=[autoscaling_events.AWSAPICallViaCloudTrail.RequestParametersItem1(
                            metric_interval_lower_bound=["metricIntervalLowerBound"],
                            scaling_adjustment=["scalingAdjustment"]
                        )],
                        tags=[autoscaling_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                            key=["key"],
                            propagate_at_launch=["propagateAtLaunch"],
                            resource_id=["resourceId"],
                            resource_type=["resourceType"],
                            value=["value"]
                        )],
                        target_group_arns=["targetGroupArns"],
                        target_tracking_configuration=autoscaling_events.AWSAPICallViaCloudTrail.TargetTrackingConfiguration(
                            customized_metric_specification=autoscaling_events.AWSAPICallViaCloudTrail.CustomizedMetricSpecification(
                                dimensions=[autoscaling_events.AWSAPICallViaCloudTrail.CustomizedMetricSpecificationItem(
                                    name=["name"],
                                    value=["value"]
                                )],
                                metric_name=["metricName"],
                                namespace=["namespace"],
                                statistic=["statistic"],
                                unit=["unit"]
                            ),
                            predefined_metric_specification=autoscaling_events.AWSAPICallViaCloudTrail.PredefinedMetricSpecification(
                                predefined_metric_type=["predefinedMetricType"]
                            ),
                            target_value=["targetValue"]
                        ),
                        time=["time"],
                        topic_arn=["topicArn"],
                        user_data=["userData"],
                        v_pc_zone_identifier=["vPcZoneIdentifier"]
                    ),
                    response_elements=autoscaling_events.AWSAPICallViaCloudTrail.ResponseElements(
                        alarms=[alarms],
                        failed_scheduled_actions=[failed_scheduled_actions],
                        failed_scheduled_update_group_actions=[failed_scheduled_update_group_actions],
                        policy_arn=["policyArn"]
                    ),
                    source_ip_address=["sourceIpAddress"],
                    user_agent=["userAgent"],
                    user_identity=autoscaling_events.AWSAPICallViaCloudTrail.UserIdentity(
                        access_key_id=["accessKeyId"],
                        account_id=["accountId"],
                        arn=["arn"],
                        principal_id=["principalId"],
                        type=["type"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(request_parameters, dict):
                request_parameters = AWSAPICallViaCloudTrail.RequestParameters(**request_parameters)
            if isinstance(response_elements, dict):
                response_elements = AWSAPICallViaCloudTrail.ResponseElements(**response_elements)
            if isinstance(user_identity, dict):
                user_identity = AWSAPICallViaCloudTrail.UserIdentity(**user_identity)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e1e4acf2fb9f06e51b818e7b09430b6eb5a12ab06e5b3273538cad73e1a3c7d8)
                check_type(argname="argument aws_region", value=aws_region, expected_type=type_hints["aws_region"])
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument event_name", value=event_name, expected_type=type_hints["event_name"])
                check_type(argname="argument event_source", value=event_source, expected_type=type_hints["event_source"])
                check_type(argname="argument event_time", value=event_time, expected_type=type_hints["event_time"])
                check_type(argname="argument event_type", value=event_type, expected_type=type_hints["event_type"])
                check_type(argname="argument event_version", value=event_version, expected_type=type_hints["event_version"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument request_parameters", value=request_parameters, expected_type=type_hints["request_parameters"])
                check_type(argname="argument response_elements", value=response_elements, expected_type=type_hints["response_elements"])
                check_type(argname="argument source_ip_address", value=source_ip_address, expected_type=type_hints["source_ip_address"])
                check_type(argname="argument user_agent", value=user_agent, expected_type=type_hints["user_agent"])
                check_type(argname="argument user_identity", value=user_identity, expected_type=type_hints["user_identity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if aws_region is not None:
                self._values["aws_region"] = aws_region
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if event_name is not None:
                self._values["event_name"] = event_name
            if event_source is not None:
                self._values["event_source"] = event_source
            if event_time is not None:
                self._values["event_time"] = event_time
            if event_type is not None:
                self._values["event_type"] = event_type
            if event_version is not None:
                self._values["event_version"] = event_version
            if request_id is not None:
                self._values["request_id"] = request_id
            if request_parameters is not None:
                self._values["request_parameters"] = request_parameters
            if response_elements is not None:
                self._values["response_elements"] = response_elements
            if source_ip_address is not None:
                self._values["source_ip_address"] = source_ip_address
            if user_agent is not None:
                self._values["user_agent"] = user_agent
            if user_identity is not None:
                self._values["user_identity"] = user_identity

        @builtins.property
        def aws_region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) awsRegion property.

            Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventID property.

            Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def event_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventName property.

            Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventSource property.

            Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventTime property.

            Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventType property.

            Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventVersion property.

            Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestID property.

            Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_parameters(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"]:
            '''(experimental) requestParameters property.

            Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_parameters")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"], result)

        @builtins.property
        def response_elements(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"]:
            '''(experimental) responseElements property.

            Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("response_elements")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"], result)

        @builtins.property
        def source_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceIPAddress property.

            Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_agent(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userAgent property.

            Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_agent")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_identity(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"]:
            '''(experimental) userIdentity property.

            Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_identity")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AWSAPICallViaCloudTrailProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.CustomizedMetricSpecification",
        jsii_struct_bases=[],
        name_mapping={
            "dimensions": "dimensions",
            "metric_name": "metricName",
            "namespace": "namespace",
            "statistic": "statistic",
            "unit": "unit",
        },
    )
    class CustomizedMetricSpecification:
        def __init__(
            self,
            *,
            dimensions: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.CustomizedMetricSpecificationItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            metric_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            namespace: typing.Optional[typing.Sequence[builtins.str]] = None,
            statistic: typing.Optional[typing.Sequence[builtins.str]] = None,
            unit: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CustomizedMetricSpecification.

            :param dimensions: (experimental) dimensions property. Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric_name: (experimental) metricName property. Specify an array of string values to match this event if the actual value of metricName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param namespace: (experimental) namespace property. Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param statistic: (experimental) statistic property. Specify an array of string values to match this event if the actual value of statistic is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param unit: (experimental) unit property. Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                customized_metric_specification = autoscaling_events.AWSAPICallViaCloudTrail.CustomizedMetricSpecification(
                    dimensions=[autoscaling_events.AWSAPICallViaCloudTrail.CustomizedMetricSpecificationItem(
                        name=["name"],
                        value=["value"]
                    )],
                    metric_name=["metricName"],
                    namespace=["namespace"],
                    statistic=["statistic"],
                    unit=["unit"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fd309829311f49cca94ab1b534901d6a637bc7e86eecd8d08e20fdcb4856b0c6)
                check_type(argname="argument dimensions", value=dimensions, expected_type=type_hints["dimensions"])
                check_type(argname="argument metric_name", value=metric_name, expected_type=type_hints["metric_name"])
                check_type(argname="argument namespace", value=namespace, expected_type=type_hints["namespace"])
                check_type(argname="argument statistic", value=statistic, expected_type=type_hints["statistic"])
                check_type(argname="argument unit", value=unit, expected_type=type_hints["unit"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if dimensions is not None:
                self._values["dimensions"] = dimensions
            if metric_name is not None:
                self._values["metric_name"] = metric_name
            if namespace is not None:
                self._values["namespace"] = namespace
            if statistic is not None:
                self._values["statistic"] = statistic
            if unit is not None:
                self._values["unit"] = unit

        @builtins.property
        def dimensions(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.CustomizedMetricSpecificationItem"]]:
            '''(experimental) dimensions property.

            Specify an array of string values to match this event if the actual value of dimensions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dimensions")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.CustomizedMetricSpecificationItem"]], result)

        @builtins.property
        def metric_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metricName property.

            Specify an array of string values to match this event if the actual value of metricName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def namespace(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) namespace property.

            Specify an array of string values to match this event if the actual value of namespace is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("namespace")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def statistic(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) statistic property.

            Specify an array of string values to match this event if the actual value of statistic is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("statistic")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def unit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) unit property.

            Specify an array of string values to match this event if the actual value of unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("unit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CustomizedMetricSpecification(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.CustomizedMetricSpecificationItem",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "value": "value"},
    )
    class CustomizedMetricSpecificationItem:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CustomizedMetricSpecificationItem.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                customized_metric_specification_item = autoscaling_events.AWSAPICallViaCloudTrail.CustomizedMetricSpecificationItem(
                    name=["name"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__dd82298f1d560cfca0c0ea744007867d598b0c144e10280282140eb132843bb6)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CustomizedMetricSpecificationItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.InstancesDistribution",
        jsii_struct_bases=[],
        name_mapping={
            "on_demand_allocation_strategy": "onDemandAllocationStrategy",
            "on_demand_base_capacity": "onDemandBaseCapacity",
            "on_demand_percentage_above_base_capacity": "onDemandPercentageAboveBaseCapacity",
            "spot_allocation_strategy": "spotAllocationStrategy",
            "spot_instance_pools": "spotInstancePools",
        },
    )
    class InstancesDistribution:
        def __init__(
            self,
            *,
            on_demand_allocation_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
            on_demand_base_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
            on_demand_percentage_above_base_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
            spot_allocation_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
            spot_instance_pools: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for InstancesDistribution.

            :param on_demand_allocation_strategy: (experimental) onDemandAllocationStrategy property. Specify an array of string values to match this event if the actual value of onDemandAllocationStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param on_demand_base_capacity: (experimental) onDemandBaseCapacity property. Specify an array of string values to match this event if the actual value of onDemandBaseCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param on_demand_percentage_above_base_capacity: (experimental) onDemandPercentageAboveBaseCapacity property. Specify an array of string values to match this event if the actual value of onDemandPercentageAboveBaseCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param spot_allocation_strategy: (experimental) spotAllocationStrategy property. Specify an array of string values to match this event if the actual value of spotAllocationStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param spot_instance_pools: (experimental) spotInstancePools property. Specify an array of string values to match this event if the actual value of spotInstancePools is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                instances_distribution = autoscaling_events.AWSAPICallViaCloudTrail.InstancesDistribution(
                    on_demand_allocation_strategy=["onDemandAllocationStrategy"],
                    on_demand_base_capacity=["onDemandBaseCapacity"],
                    on_demand_percentage_above_base_capacity=["onDemandPercentageAboveBaseCapacity"],
                    spot_allocation_strategy=["spotAllocationStrategy"],
                    spot_instance_pools=["spotInstancePools"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__37a5915d91cc83f2a80af317545968eff9750b702b8f1fd63bacdf2f0485c1b1)
                check_type(argname="argument on_demand_allocation_strategy", value=on_demand_allocation_strategy, expected_type=type_hints["on_demand_allocation_strategy"])
                check_type(argname="argument on_demand_base_capacity", value=on_demand_base_capacity, expected_type=type_hints["on_demand_base_capacity"])
                check_type(argname="argument on_demand_percentage_above_base_capacity", value=on_demand_percentage_above_base_capacity, expected_type=type_hints["on_demand_percentage_above_base_capacity"])
                check_type(argname="argument spot_allocation_strategy", value=spot_allocation_strategy, expected_type=type_hints["spot_allocation_strategy"])
                check_type(argname="argument spot_instance_pools", value=spot_instance_pools, expected_type=type_hints["spot_instance_pools"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if on_demand_allocation_strategy is not None:
                self._values["on_demand_allocation_strategy"] = on_demand_allocation_strategy
            if on_demand_base_capacity is not None:
                self._values["on_demand_base_capacity"] = on_demand_base_capacity
            if on_demand_percentage_above_base_capacity is not None:
                self._values["on_demand_percentage_above_base_capacity"] = on_demand_percentage_above_base_capacity
            if spot_allocation_strategy is not None:
                self._values["spot_allocation_strategy"] = spot_allocation_strategy
            if spot_instance_pools is not None:
                self._values["spot_instance_pools"] = spot_instance_pools

        @builtins.property
        def on_demand_allocation_strategy(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) onDemandAllocationStrategy property.

            Specify an array of string values to match this event if the actual value of onDemandAllocationStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("on_demand_allocation_strategy")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def on_demand_base_capacity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) onDemandBaseCapacity property.

            Specify an array of string values to match this event if the actual value of onDemandBaseCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("on_demand_base_capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def on_demand_percentage_above_base_capacity(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) onDemandPercentageAboveBaseCapacity property.

            Specify an array of string values to match this event if the actual value of onDemandPercentageAboveBaseCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("on_demand_percentage_above_base_capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def spot_allocation_strategy(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) spotAllocationStrategy property.

            Specify an array of string values to match this event if the actual value of spotAllocationStrategy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("spot_allocation_strategy")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def spot_instance_pools(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) spotInstancePools property.

            Specify an array of string values to match this event if the actual value of spotInstancePools is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("spot_instance_pools")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InstancesDistribution(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.LaunchTemplate",
        jsii_struct_bases=[],
        name_mapping={"launch_template_name": "launchTemplateName"},
    )
    class LaunchTemplate:
        def __init__(
            self,
            *,
            launch_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for LaunchTemplate.

            :param launch_template_name: (experimental) launchTemplateName property. Specify an array of string values to match this event if the actual value of launchTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                launch_template = autoscaling_events.AWSAPICallViaCloudTrail.LaunchTemplate(
                    launch_template_name=["launchTemplateName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c0ebddccd4c6a6bfe237a6ef13906182cab76023a70975044d3bc8f6df9adee0)
                check_type(argname="argument launch_template_name", value=launch_template_name, expected_type=type_hints["launch_template_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if launch_template_name is not None:
                self._values["launch_template_name"] = launch_template_name

        @builtins.property
        def launch_template_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) launchTemplateName property.

            Specify an array of string values to match this event if the actual value of launchTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "LaunchTemplate(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.LaunchTemplate1",
        jsii_struct_bases=[],
        name_mapping={
            "launch_template_specification": "launchTemplateSpecification",
            "overrides": "overrides",
        },
    )
    class LaunchTemplate1:
        def __init__(
            self,
            *,
            launch_template_specification: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.LaunchTemplateSpecification", typing.Dict[builtins.str, typing.Any]]] = None,
            overrides: typing.Optional[typing.Sequence[typing.Any]] = None,
        ) -> None:
            '''(experimental) Type definition for LaunchTemplate_1.

            :param launch_template_specification: (experimental) launchTemplateSpecification property. Specify an array of string values to match this event if the actual value of launchTemplateSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param overrides: (experimental) overrides property. Specify an array of string values to match this event if the actual value of overrides is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                # overrides: Any
                
                launch_template1 = autoscaling_events.AWSAPICallViaCloudTrail.LaunchTemplate1(
                    launch_template_specification=autoscaling_events.AWSAPICallViaCloudTrail.LaunchTemplateSpecification(
                        launch_template_name=["launchTemplateName"],
                        version=["version"]
                    ),
                    overrides=[overrides]
                )
            '''
            if isinstance(launch_template_specification, dict):
                launch_template_specification = AWSAPICallViaCloudTrail.LaunchTemplateSpecification(**launch_template_specification)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e3094cebf12d5f9730af6d95c0992d7a5a33010014c1f02ec4a789b8bb2762f0)
                check_type(argname="argument launch_template_specification", value=launch_template_specification, expected_type=type_hints["launch_template_specification"])
                check_type(argname="argument overrides", value=overrides, expected_type=type_hints["overrides"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if launch_template_specification is not None:
                self._values["launch_template_specification"] = launch_template_specification
            if overrides is not None:
                self._values["overrides"] = overrides

        @builtins.property
        def launch_template_specification(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplateSpecification"]:
            '''(experimental) launchTemplateSpecification property.

            Specify an array of string values to match this event if the actual value of launchTemplateSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template_specification")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplateSpecification"], result)

        @builtins.property
        def overrides(self) -> typing.Optional[typing.List[typing.Any]]:
            '''(experimental) overrides property.

            Specify an array of string values to match this event if the actual value of overrides is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("overrides")
            return typing.cast(typing.Optional[typing.List[typing.Any]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "LaunchTemplate1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.LaunchTemplateSpecification",
        jsii_struct_bases=[],
        name_mapping={
            "launch_template_name": "launchTemplateName",
            "version": "version",
        },
    )
    class LaunchTemplateSpecification:
        def __init__(
            self,
            *,
            launch_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for LaunchTemplateSpecification.

            :param launch_template_name: (experimental) launchTemplateName property. Specify an array of string values to match this event if the actual value of launchTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                launch_template_specification = autoscaling_events.AWSAPICallViaCloudTrail.LaunchTemplateSpecification(
                    launch_template_name=["launchTemplateName"],
                    version=["version"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1a15a2b992d22ee710fa7753fa477c1a046811a8354cc6d4f9da55c16e5072da)
                check_type(argname="argument launch_template_name", value=launch_template_name, expected_type=type_hints["launch_template_name"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if launch_template_name is not None:
                self._values["launch_template_name"] = launch_template_name
            if version is not None:
                self._values["version"] = version

        @builtins.property
        def launch_template_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) launchTemplateName property.

            Specify an array of string values to match this event if the actual value of launchTemplateName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version property.

            Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "LaunchTemplateSpecification(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.MixedInstancesPolicy",
        jsii_struct_bases=[],
        name_mapping={
            "instances_distribution": "instancesDistribution",
            "launch_template": "launchTemplate",
        },
    )
    class MixedInstancesPolicy:
        def __init__(
            self,
            *,
            instances_distribution: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.InstancesDistribution", typing.Dict[builtins.str, typing.Any]]] = None,
            launch_template: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.LaunchTemplate1", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for MixedInstancesPolicy.

            :param instances_distribution: (experimental) instancesDistribution property. Specify an array of string values to match this event if the actual value of instancesDistribution is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param launch_template: (experimental) launchTemplate property. Specify an array of string values to match this event if the actual value of launchTemplate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                # overrides: Any
                
                mixed_instances_policy = autoscaling_events.AWSAPICallViaCloudTrail.MixedInstancesPolicy(
                    instances_distribution=autoscaling_events.AWSAPICallViaCloudTrail.InstancesDistribution(
                        on_demand_allocation_strategy=["onDemandAllocationStrategy"],
                        on_demand_base_capacity=["onDemandBaseCapacity"],
                        on_demand_percentage_above_base_capacity=["onDemandPercentageAboveBaseCapacity"],
                        spot_allocation_strategy=["spotAllocationStrategy"],
                        spot_instance_pools=["spotInstancePools"]
                    ),
                    launch_template=autoscaling_events.AWSAPICallViaCloudTrail.LaunchTemplate1(
                        launch_template_specification=autoscaling_events.AWSAPICallViaCloudTrail.LaunchTemplateSpecification(
                            launch_template_name=["launchTemplateName"],
                            version=["version"]
                        ),
                        overrides=[overrides]
                    )
                )
            '''
            if isinstance(instances_distribution, dict):
                instances_distribution = AWSAPICallViaCloudTrail.InstancesDistribution(**instances_distribution)
            if isinstance(launch_template, dict):
                launch_template = AWSAPICallViaCloudTrail.LaunchTemplate1(**launch_template)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d530143bc0a7f57bc3041daff3da2293883fc10aabed80716d3301203a0c133d)
                check_type(argname="argument instances_distribution", value=instances_distribution, expected_type=type_hints["instances_distribution"])
                check_type(argname="argument launch_template", value=launch_template, expected_type=type_hints["launch_template"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if instances_distribution is not None:
                self._values["instances_distribution"] = instances_distribution
            if launch_template is not None:
                self._values["launch_template"] = launch_template

        @builtins.property
        def instances_distribution(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.InstancesDistribution"]:
            '''(experimental) instancesDistribution property.

            Specify an array of string values to match this event if the actual value of instancesDistribution is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instances_distribution")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.InstancesDistribution"], result)

        @builtins.property
        def launch_template(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplate1"]:
            '''(experimental) launchTemplate property.

            Specify an array of string values to match this event if the actual value of launchTemplate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplate1"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "MixedInstancesPolicy(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.PredefinedMetricSpecification",
        jsii_struct_bases=[],
        name_mapping={"predefined_metric_type": "predefinedMetricType"},
    )
    class PredefinedMetricSpecification:
        def __init__(
            self,
            *,
            predefined_metric_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for PredefinedMetricSpecification.

            :param predefined_metric_type: (experimental) predefinedMetricType property. Specify an array of string values to match this event if the actual value of predefinedMetricType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                predefined_metric_specification = autoscaling_events.AWSAPICallViaCloudTrail.PredefinedMetricSpecification(
                    predefined_metric_type=["predefinedMetricType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__faf90cf89506dc675dbc819390efa2df119fe011cb6b9b267dca8b03a808834b)
                check_type(argname="argument predefined_metric_type", value=predefined_metric_type, expected_type=type_hints["predefined_metric_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if predefined_metric_type is not None:
                self._values["predefined_metric_type"] = predefined_metric_type

        @builtins.property
        def predefined_metric_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) predefinedMetricType property.

            Specify an array of string values to match this event if the actual value of predefinedMetricType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("predefined_metric_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "PredefinedMetricSpecification(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.RequestParameters",
        jsii_struct_bases=[],
        name_mapping={
            "adjustment_type": "adjustmentType",
            "auto_scaling_group_name": "autoScalingGroupName",
            "availability_zones": "availabilityZones",
            "breach_threshold": "breachThreshold",
            "default_cooldown": "defaultCooldown",
            "desired_capacity": "desiredCapacity",
            "force_delete": "forceDelete",
            "granularity": "granularity",
            "health_check_grace_period": "healthCheckGracePeriod",
            "health_check_type": "healthCheckType",
            "honor_cooldown": "honorCooldown",
            "image_id": "imageId",
            "instance_ids": "instanceIds",
            "instance_type": "instanceType",
            "launch_configuration_name": "launchConfigurationName",
            "launch_template": "launchTemplate",
            "lifecycle_hook_specification_list": "lifecycleHookSpecificationList",
            "load_balancer_names": "loadBalancerNames",
            "max_size": "maxSize",
            "metrics": "metrics",
            "metric_value": "metricValue",
            "min_size": "minSize",
            "mixed_instances_policy": "mixedInstancesPolicy",
            "new_instances_protected_from_scale_in": "newInstancesProtectedFromScaleIn",
            "notification_types": "notificationTypes",
            "policy_name": "policyName",
            "policy_type": "policyType",
            "protected_from_scale_in": "protectedFromScaleIn",
            "scaling_adjustment": "scalingAdjustment",
            "scheduled_action_name": "scheduledActionName",
            "scheduled_action_names": "scheduledActionNames",
            "scheduled_update_group_actions": "scheduledUpdateGroupActions",
            "security_groups": "securityGroups",
            "service_linked_role_arn": "serviceLinkedRoleArn",
            "spot_price": "spotPrice",
            "start_time": "startTime",
            "step_adjustments": "stepAdjustments",
            "tags": "tags",
            "target_group_arns": "targetGroupArns",
            "target_tracking_configuration": "targetTrackingConfiguration",
            "time": "time",
            "topic_arn": "topicArn",
            "user_data": "userData",
            "v_pc_zone_identifier": "vPcZoneIdentifier",
        },
    )
    class RequestParameters:
        def __init__(
            self,
            *,
            adjustment_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            availability_zones: typing.Optional[typing.Sequence[builtins.str]] = None,
            breach_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
            default_cooldown: typing.Optional[typing.Sequence[builtins.str]] = None,
            desired_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
            force_delete: typing.Optional[typing.Sequence[builtins.str]] = None,
            granularity: typing.Optional[typing.Sequence[builtins.str]] = None,
            health_check_grace_period: typing.Optional[typing.Sequence[builtins.str]] = None,
            health_check_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            honor_cooldown: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            launch_configuration_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            launch_template: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.LaunchTemplate", typing.Dict[builtins.str, typing.Any]]] = None,
            lifecycle_hook_specification_list: typing.Optional[typing.Sequence[typing.Any]] = None,
            load_balancer_names: typing.Optional[typing.Sequence[builtins.str]] = None,
            max_size: typing.Optional[typing.Sequence[builtins.str]] = None,
            metrics: typing.Optional[typing.Sequence[builtins.str]] = None,
            metric_value: typing.Optional[typing.Sequence[builtins.str]] = None,
            min_size: typing.Optional[typing.Sequence[builtins.str]] = None,
            mixed_instances_policy: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.MixedInstancesPolicy", typing.Dict[builtins.str, typing.Any]]] = None,
            new_instances_protected_from_scale_in: typing.Optional[typing.Sequence[builtins.str]] = None,
            notification_types: typing.Optional[typing.Sequence[builtins.str]] = None,
            policy_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            policy_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            protected_from_scale_in: typing.Optional[typing.Sequence[builtins.str]] = None,
            scaling_adjustment: typing.Optional[typing.Sequence[builtins.str]] = None,
            scheduled_action_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            scheduled_action_names: typing.Optional[typing.Sequence[builtins.str]] = None,
            scheduled_update_group_actions: typing.Optional[typing.Sequence[typing.Any]] = None,
            security_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
            service_linked_role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            spot_price: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            step_adjustments: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.RequestParametersItem1", typing.Dict[builtins.str, typing.Any]]]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.RequestParametersItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            target_group_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
            target_tracking_configuration: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.TargetTrackingConfiguration", typing.Dict[builtins.str, typing.Any]]] = None,
            time: typing.Optional[typing.Sequence[builtins.str]] = None,
            topic_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_data: typing.Optional[typing.Sequence[builtins.str]] = None,
            v_pc_zone_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParameters.

            :param adjustment_type: (experimental) adjustmentType property. Specify an array of string values to match this event if the actual value of adjustmentType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param auto_scaling_group_name: (experimental) autoScalingGroupName property. Specify an array of string values to match this event if the actual value of autoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param availability_zones: (experimental) availabilityZones property. Specify an array of string values to match this event if the actual value of availabilityZones is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param breach_threshold: (experimental) breachThreshold property. Specify an array of string values to match this event if the actual value of breachThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param default_cooldown: (experimental) defaultCooldown property. Specify an array of string values to match this event if the actual value of defaultCooldown is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param desired_capacity: (experimental) desiredCapacity property. Specify an array of string values to match this event if the actual value of desiredCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param force_delete: (experimental) forceDelete property. Specify an array of string values to match this event if the actual value of forceDelete is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param granularity: (experimental) granularity property. Specify an array of string values to match this event if the actual value of granularity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param health_check_grace_period: (experimental) healthCheckGracePeriod property. Specify an array of string values to match this event if the actual value of healthCheckGracePeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param health_check_type: (experimental) healthCheckType property. Specify an array of string values to match this event if the actual value of healthCheckType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param honor_cooldown: (experimental) honorCooldown property. Specify an array of string values to match this event if the actual value of honorCooldown is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_id: (experimental) imageId property. Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_ids: (experimental) instanceIds property. Specify an array of string values to match this event if the actual value of instanceIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) instanceType property. Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param launch_configuration_name: (experimental) launchConfigurationName property. Specify an array of string values to match this event if the actual value of launchConfigurationName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param launch_template: (experimental) launchTemplate property. Specify an array of string values to match this event if the actual value of launchTemplate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param lifecycle_hook_specification_list: (experimental) lifecycleHookSpecificationList property. Specify an array of string values to match this event if the actual value of lifecycleHookSpecificationList is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param load_balancer_names: (experimental) loadBalancerNames property. Specify an array of string values to match this event if the actual value of loadBalancerNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param max_size: (experimental) maxSize property. Specify an array of string values to match this event if the actual value of maxSize is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metrics: (experimental) metrics property. Specify an array of string values to match this event if the actual value of metrics is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metric_value: (experimental) metricValue property. Specify an array of string values to match this event if the actual value of metricValue is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param min_size: (experimental) minSize property. Specify an array of string values to match this event if the actual value of minSize is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param mixed_instances_policy: (experimental) mixedInstancesPolicy property. Specify an array of string values to match this event if the actual value of mixedInstancesPolicy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param new_instances_protected_from_scale_in: (experimental) newInstancesProtectedFromScaleIn property. Specify an array of string values to match this event if the actual value of newInstancesProtectedFromScaleIn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notification_types: (experimental) notificationTypes property. Specify an array of string values to match this event if the actual value of notificationTypes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param policy_name: (experimental) policyName property. Specify an array of string values to match this event if the actual value of policyName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param policy_type: (experimental) policyType property. Specify an array of string values to match this event if the actual value of policyType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param protected_from_scale_in: (experimental) protectedFromScaleIn property. Specify an array of string values to match this event if the actual value of protectedFromScaleIn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param scaling_adjustment: (experimental) scalingAdjustment property. Specify an array of string values to match this event if the actual value of scalingAdjustment is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param scheduled_action_name: (experimental) scheduledActionName property. Specify an array of string values to match this event if the actual value of scheduledActionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param scheduled_action_names: (experimental) scheduledActionNames property. Specify an array of string values to match this event if the actual value of scheduledActionNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param scheduled_update_group_actions: (experimental) scheduledUpdateGroupActions property. Specify an array of string values to match this event if the actual value of scheduledUpdateGroupActions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param security_groups: (experimental) securityGroups property. Specify an array of string values to match this event if the actual value of securityGroups is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param service_linked_role_arn: (experimental) serviceLinkedRoleARN property. Specify an array of string values to match this event if the actual value of serviceLinkedRoleARN is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param spot_price: (experimental) spotPrice property. Specify an array of string values to match this event if the actual value of spotPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param step_adjustments: (experimental) stepAdjustments property. Specify an array of string values to match this event if the actual value of stepAdjustments is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) tags property. Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_group_arns: (experimental) targetGroupARNs property. Specify an array of string values to match this event if the actual value of targetGroupARNs is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_tracking_configuration: (experimental) targetTrackingConfiguration property. Specify an array of string values to match this event if the actual value of targetTrackingConfiguration is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param time: (experimental) time property. Specify an array of string values to match this event if the actual value of time is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param topic_arn: (experimental) topicARN property. Specify an array of string values to match this event if the actual value of topicARN is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_data: (experimental) userData property. Specify an array of string values to match this event if the actual value of userData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param v_pc_zone_identifier: (experimental) vPCZoneIdentifier property. Specify an array of string values to match this event if the actual value of vPCZoneIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                # lifecycle_hook_specification_list: Any
                # overrides: Any
                # scheduled_update_group_actions: Any
                
                request_parameters = autoscaling_events.AWSAPICallViaCloudTrail.RequestParameters(
                    adjustment_type=["adjustmentType"],
                    auto_scaling_group_name=["autoScalingGroupName"],
                    availability_zones=["availabilityZones"],
                    breach_threshold=["breachThreshold"],
                    default_cooldown=["defaultCooldown"],
                    desired_capacity=["desiredCapacity"],
                    force_delete=["forceDelete"],
                    granularity=["granularity"],
                    health_check_grace_period=["healthCheckGracePeriod"],
                    health_check_type=["healthCheckType"],
                    honor_cooldown=["honorCooldown"],
                    image_id=["imageId"],
                    instance_ids=["instanceIds"],
                    instance_type=["instanceType"],
                    launch_configuration_name=["launchConfigurationName"],
                    launch_template=autoscaling_events.AWSAPICallViaCloudTrail.LaunchTemplate(
                        launch_template_name=["launchTemplateName"]
                    ),
                    lifecycle_hook_specification_list=[lifecycle_hook_specification_list],
                    load_balancer_names=["loadBalancerNames"],
                    max_size=["maxSize"],
                    metrics=["metrics"],
                    metric_value=["metricValue"],
                    min_size=["minSize"],
                    mixed_instances_policy=autoscaling_events.AWSAPICallViaCloudTrail.MixedInstancesPolicy(
                        instances_distribution=autoscaling_events.AWSAPICallViaCloudTrail.InstancesDistribution(
                            on_demand_allocation_strategy=["onDemandAllocationStrategy"],
                            on_demand_base_capacity=["onDemandBaseCapacity"],
                            on_demand_percentage_above_base_capacity=["onDemandPercentageAboveBaseCapacity"],
                            spot_allocation_strategy=["spotAllocationStrategy"],
                            spot_instance_pools=["spotInstancePools"]
                        ),
                        launch_template=autoscaling_events.AWSAPICallViaCloudTrail.LaunchTemplate1(
                            launch_template_specification=autoscaling_events.AWSAPICallViaCloudTrail.LaunchTemplateSpecification(
                                launch_template_name=["launchTemplateName"],
                                version=["version"]
                            ),
                            overrides=[overrides]
                        )
                    ),
                    new_instances_protected_from_scale_in=["newInstancesProtectedFromScaleIn"],
                    notification_types=["notificationTypes"],
                    policy_name=["policyName"],
                    policy_type=["policyType"],
                    protected_from_scale_in=["protectedFromScaleIn"],
                    scaling_adjustment=["scalingAdjustment"],
                    scheduled_action_name=["scheduledActionName"],
                    scheduled_action_names=["scheduledActionNames"],
                    scheduled_update_group_actions=[scheduled_update_group_actions],
                    security_groups=["securityGroups"],
                    service_linked_role_arn=["serviceLinkedRoleArn"],
                    spot_price=["spotPrice"],
                    start_time=["startTime"],
                    step_adjustments=[autoscaling_events.AWSAPICallViaCloudTrail.RequestParametersItem1(
                        metric_interval_lower_bound=["metricIntervalLowerBound"],
                        scaling_adjustment=["scalingAdjustment"]
                    )],
                    tags=[autoscaling_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                        key=["key"],
                        propagate_at_launch=["propagateAtLaunch"],
                        resource_id=["resourceId"],
                        resource_type=["resourceType"],
                        value=["value"]
                    )],
                    target_group_arns=["targetGroupArns"],
                    target_tracking_configuration=autoscaling_events.AWSAPICallViaCloudTrail.TargetTrackingConfiguration(
                        customized_metric_specification=autoscaling_events.AWSAPICallViaCloudTrail.CustomizedMetricSpecification(
                            dimensions=[autoscaling_events.AWSAPICallViaCloudTrail.CustomizedMetricSpecificationItem(
                                name=["name"],
                                value=["value"]
                            )],
                            metric_name=["metricName"],
                            namespace=["namespace"],
                            statistic=["statistic"],
                            unit=["unit"]
                        ),
                        predefined_metric_specification=autoscaling_events.AWSAPICallViaCloudTrail.PredefinedMetricSpecification(
                            predefined_metric_type=["predefinedMetricType"]
                        ),
                        target_value=["targetValue"]
                    ),
                    time=["time"],
                    topic_arn=["topicArn"],
                    user_data=["userData"],
                    v_pc_zone_identifier=["vPcZoneIdentifier"]
                )
            '''
            if isinstance(launch_template, dict):
                launch_template = AWSAPICallViaCloudTrail.LaunchTemplate(**launch_template)
            if isinstance(mixed_instances_policy, dict):
                mixed_instances_policy = AWSAPICallViaCloudTrail.MixedInstancesPolicy(**mixed_instances_policy)
            if isinstance(target_tracking_configuration, dict):
                target_tracking_configuration = AWSAPICallViaCloudTrail.TargetTrackingConfiguration(**target_tracking_configuration)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1dd976ae6e76a746546f6ae57347a1349866b12a684a8bd641bbd739a5e282f0)
                check_type(argname="argument adjustment_type", value=adjustment_type, expected_type=type_hints["adjustment_type"])
                check_type(argname="argument auto_scaling_group_name", value=auto_scaling_group_name, expected_type=type_hints["auto_scaling_group_name"])
                check_type(argname="argument availability_zones", value=availability_zones, expected_type=type_hints["availability_zones"])
                check_type(argname="argument breach_threshold", value=breach_threshold, expected_type=type_hints["breach_threshold"])
                check_type(argname="argument default_cooldown", value=default_cooldown, expected_type=type_hints["default_cooldown"])
                check_type(argname="argument desired_capacity", value=desired_capacity, expected_type=type_hints["desired_capacity"])
                check_type(argname="argument force_delete", value=force_delete, expected_type=type_hints["force_delete"])
                check_type(argname="argument granularity", value=granularity, expected_type=type_hints["granularity"])
                check_type(argname="argument health_check_grace_period", value=health_check_grace_period, expected_type=type_hints["health_check_grace_period"])
                check_type(argname="argument health_check_type", value=health_check_type, expected_type=type_hints["health_check_type"])
                check_type(argname="argument honor_cooldown", value=honor_cooldown, expected_type=type_hints["honor_cooldown"])
                check_type(argname="argument image_id", value=image_id, expected_type=type_hints["image_id"])
                check_type(argname="argument instance_ids", value=instance_ids, expected_type=type_hints["instance_ids"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument launch_configuration_name", value=launch_configuration_name, expected_type=type_hints["launch_configuration_name"])
                check_type(argname="argument launch_template", value=launch_template, expected_type=type_hints["launch_template"])
                check_type(argname="argument lifecycle_hook_specification_list", value=lifecycle_hook_specification_list, expected_type=type_hints["lifecycle_hook_specification_list"])
                check_type(argname="argument load_balancer_names", value=load_balancer_names, expected_type=type_hints["load_balancer_names"])
                check_type(argname="argument max_size", value=max_size, expected_type=type_hints["max_size"])
                check_type(argname="argument metrics", value=metrics, expected_type=type_hints["metrics"])
                check_type(argname="argument metric_value", value=metric_value, expected_type=type_hints["metric_value"])
                check_type(argname="argument min_size", value=min_size, expected_type=type_hints["min_size"])
                check_type(argname="argument mixed_instances_policy", value=mixed_instances_policy, expected_type=type_hints["mixed_instances_policy"])
                check_type(argname="argument new_instances_protected_from_scale_in", value=new_instances_protected_from_scale_in, expected_type=type_hints["new_instances_protected_from_scale_in"])
                check_type(argname="argument notification_types", value=notification_types, expected_type=type_hints["notification_types"])
                check_type(argname="argument policy_name", value=policy_name, expected_type=type_hints["policy_name"])
                check_type(argname="argument policy_type", value=policy_type, expected_type=type_hints["policy_type"])
                check_type(argname="argument protected_from_scale_in", value=protected_from_scale_in, expected_type=type_hints["protected_from_scale_in"])
                check_type(argname="argument scaling_adjustment", value=scaling_adjustment, expected_type=type_hints["scaling_adjustment"])
                check_type(argname="argument scheduled_action_name", value=scheduled_action_name, expected_type=type_hints["scheduled_action_name"])
                check_type(argname="argument scheduled_action_names", value=scheduled_action_names, expected_type=type_hints["scheduled_action_names"])
                check_type(argname="argument scheduled_update_group_actions", value=scheduled_update_group_actions, expected_type=type_hints["scheduled_update_group_actions"])
                check_type(argname="argument security_groups", value=security_groups, expected_type=type_hints["security_groups"])
                check_type(argname="argument service_linked_role_arn", value=service_linked_role_arn, expected_type=type_hints["service_linked_role_arn"])
                check_type(argname="argument spot_price", value=spot_price, expected_type=type_hints["spot_price"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument step_adjustments", value=step_adjustments, expected_type=type_hints["step_adjustments"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
                check_type(argname="argument target_group_arns", value=target_group_arns, expected_type=type_hints["target_group_arns"])
                check_type(argname="argument target_tracking_configuration", value=target_tracking_configuration, expected_type=type_hints["target_tracking_configuration"])
                check_type(argname="argument time", value=time, expected_type=type_hints["time"])
                check_type(argname="argument topic_arn", value=topic_arn, expected_type=type_hints["topic_arn"])
                check_type(argname="argument user_data", value=user_data, expected_type=type_hints["user_data"])
                check_type(argname="argument v_pc_zone_identifier", value=v_pc_zone_identifier, expected_type=type_hints["v_pc_zone_identifier"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if adjustment_type is not None:
                self._values["adjustment_type"] = adjustment_type
            if auto_scaling_group_name is not None:
                self._values["auto_scaling_group_name"] = auto_scaling_group_name
            if availability_zones is not None:
                self._values["availability_zones"] = availability_zones
            if breach_threshold is not None:
                self._values["breach_threshold"] = breach_threshold
            if default_cooldown is not None:
                self._values["default_cooldown"] = default_cooldown
            if desired_capacity is not None:
                self._values["desired_capacity"] = desired_capacity
            if force_delete is not None:
                self._values["force_delete"] = force_delete
            if granularity is not None:
                self._values["granularity"] = granularity
            if health_check_grace_period is not None:
                self._values["health_check_grace_period"] = health_check_grace_period
            if health_check_type is not None:
                self._values["health_check_type"] = health_check_type
            if honor_cooldown is not None:
                self._values["honor_cooldown"] = honor_cooldown
            if image_id is not None:
                self._values["image_id"] = image_id
            if instance_ids is not None:
                self._values["instance_ids"] = instance_ids
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if launch_configuration_name is not None:
                self._values["launch_configuration_name"] = launch_configuration_name
            if launch_template is not None:
                self._values["launch_template"] = launch_template
            if lifecycle_hook_specification_list is not None:
                self._values["lifecycle_hook_specification_list"] = lifecycle_hook_specification_list
            if load_balancer_names is not None:
                self._values["load_balancer_names"] = load_balancer_names
            if max_size is not None:
                self._values["max_size"] = max_size
            if metrics is not None:
                self._values["metrics"] = metrics
            if metric_value is not None:
                self._values["metric_value"] = metric_value
            if min_size is not None:
                self._values["min_size"] = min_size
            if mixed_instances_policy is not None:
                self._values["mixed_instances_policy"] = mixed_instances_policy
            if new_instances_protected_from_scale_in is not None:
                self._values["new_instances_protected_from_scale_in"] = new_instances_protected_from_scale_in
            if notification_types is not None:
                self._values["notification_types"] = notification_types
            if policy_name is not None:
                self._values["policy_name"] = policy_name
            if policy_type is not None:
                self._values["policy_type"] = policy_type
            if protected_from_scale_in is not None:
                self._values["protected_from_scale_in"] = protected_from_scale_in
            if scaling_adjustment is not None:
                self._values["scaling_adjustment"] = scaling_adjustment
            if scheduled_action_name is not None:
                self._values["scheduled_action_name"] = scheduled_action_name
            if scheduled_action_names is not None:
                self._values["scheduled_action_names"] = scheduled_action_names
            if scheduled_update_group_actions is not None:
                self._values["scheduled_update_group_actions"] = scheduled_update_group_actions
            if security_groups is not None:
                self._values["security_groups"] = security_groups
            if service_linked_role_arn is not None:
                self._values["service_linked_role_arn"] = service_linked_role_arn
            if spot_price is not None:
                self._values["spot_price"] = spot_price
            if start_time is not None:
                self._values["start_time"] = start_time
            if step_adjustments is not None:
                self._values["step_adjustments"] = step_adjustments
            if tags is not None:
                self._values["tags"] = tags
            if target_group_arns is not None:
                self._values["target_group_arns"] = target_group_arns
            if target_tracking_configuration is not None:
                self._values["target_tracking_configuration"] = target_tracking_configuration
            if time is not None:
                self._values["time"] = time
            if topic_arn is not None:
                self._values["topic_arn"] = topic_arn
            if user_data is not None:
                self._values["user_data"] = user_data
            if v_pc_zone_identifier is not None:
                self._values["v_pc_zone_identifier"] = v_pc_zone_identifier

        @builtins.property
        def adjustment_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) adjustmentType property.

            Specify an array of string values to match this event if the actual value of adjustmentType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("adjustment_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def auto_scaling_group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) autoScalingGroupName property.

            Specify an array of string values to match this event if the actual value of autoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("auto_scaling_group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def availability_zones(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) availabilityZones property.

            Specify an array of string values to match this event if the actual value of availabilityZones is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("availability_zones")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def breach_threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) breachThreshold property.

            Specify an array of string values to match this event if the actual value of breachThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("breach_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def default_cooldown(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) defaultCooldown property.

            Specify an array of string values to match this event if the actual value of defaultCooldown is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("default_cooldown")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def desired_capacity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) desiredCapacity property.

            Specify an array of string values to match this event if the actual value of desiredCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("desired_capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def force_delete(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) forceDelete property.

            Specify an array of string values to match this event if the actual value of forceDelete is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("force_delete")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def granularity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) granularity property.

            Specify an array of string values to match this event if the actual value of granularity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("granularity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def health_check_grace_period(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) healthCheckGracePeriod property.

            Specify an array of string values to match this event if the actual value of healthCheckGracePeriod is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("health_check_grace_period")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def health_check_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) healthCheckType property.

            Specify an array of string values to match this event if the actual value of healthCheckType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("health_check_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def honor_cooldown(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) honorCooldown property.

            Specify an array of string values to match this event if the actual value of honorCooldown is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("honor_cooldown")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imageId property.

            Specify an array of string values to match this event if the actual value of imageId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_ids(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceIds property.

            Specify an array of string values to match this event if the actual value of instanceIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_ids")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceType property.

            Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def launch_configuration_name(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) launchConfigurationName property.

            Specify an array of string values to match this event if the actual value of launchConfigurationName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_configuration_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def launch_template(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplate"]:
            '''(experimental) launchTemplate property.

            Specify an array of string values to match this event if the actual value of launchTemplate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("launch_template")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.LaunchTemplate"], result)

        @builtins.property
        def lifecycle_hook_specification_list(
            self,
        ) -> typing.Optional[typing.List[typing.Any]]:
            '''(experimental) lifecycleHookSpecificationList property.

            Specify an array of string values to match this event if the actual value of lifecycleHookSpecificationList is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("lifecycle_hook_specification_list")
            return typing.cast(typing.Optional[typing.List[typing.Any]], result)

        @builtins.property
        def load_balancer_names(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) loadBalancerNames property.

            Specify an array of string values to match this event if the actual value of loadBalancerNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("load_balancer_names")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def max_size(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) maxSize property.

            Specify an array of string values to match this event if the actual value of maxSize is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_size")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def metrics(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metrics property.

            Specify an array of string values to match this event if the actual value of metrics is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metrics")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def metric_value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metricValue property.

            Specify an array of string values to match this event if the actual value of metricValue is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def min_size(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) minSize property.

            Specify an array of string values to match this event if the actual value of minSize is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("min_size")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def mixed_instances_policy(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.MixedInstancesPolicy"]:
            '''(experimental) mixedInstancesPolicy property.

            Specify an array of string values to match this event if the actual value of mixedInstancesPolicy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("mixed_instances_policy")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.MixedInstancesPolicy"], result)

        @builtins.property
        def new_instances_protected_from_scale_in(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) newInstancesProtectedFromScaleIn property.

            Specify an array of string values to match this event if the actual value of newInstancesProtectedFromScaleIn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("new_instances_protected_from_scale_in")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notification_types(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) notificationTypes property.

            Specify an array of string values to match this event if the actual value of notificationTypes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notification_types")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def policy_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) policyName property.

            Specify an array of string values to match this event if the actual value of policyName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("policy_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def policy_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) policyType property.

            Specify an array of string values to match this event if the actual value of policyType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("policy_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def protected_from_scale_in(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) protectedFromScaleIn property.

            Specify an array of string values to match this event if the actual value of protectedFromScaleIn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("protected_from_scale_in")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def scaling_adjustment(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) scalingAdjustment property.

            Specify an array of string values to match this event if the actual value of scalingAdjustment is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("scaling_adjustment")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def scheduled_action_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) scheduledActionName property.

            Specify an array of string values to match this event if the actual value of scheduledActionName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("scheduled_action_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def scheduled_action_names(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) scheduledActionNames property.

            Specify an array of string values to match this event if the actual value of scheduledActionNames is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("scheduled_action_names")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def scheduled_update_group_actions(
            self,
        ) -> typing.Optional[typing.List[typing.Any]]:
            '''(experimental) scheduledUpdateGroupActions property.

            Specify an array of string values to match this event if the actual value of scheduledUpdateGroupActions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("scheduled_update_group_actions")
            return typing.cast(typing.Optional[typing.List[typing.Any]], result)

        @builtins.property
        def security_groups(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) securityGroups property.

            Specify an array of string values to match this event if the actual value of securityGroups is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("security_groups")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def service_linked_role_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) serviceLinkedRoleARN property.

            Specify an array of string values to match this event if the actual value of serviceLinkedRoleARN is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("service_linked_role_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def spot_price(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) spotPrice property.

            Specify an array of string values to match this event if the actual value of spotPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("spot_price")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def step_adjustments(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem1"]]:
            '''(experimental) stepAdjustments property.

            Specify an array of string values to match this event if the actual value of stepAdjustments is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("step_adjustments")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem1"]], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem"]]:
            '''(experimental) tags property.

            Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem"]], result)

        @builtins.property
        def target_group_arns(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) targetGroupARNs property.

            Specify an array of string values to match this event if the actual value of targetGroupARNs is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_group_arns")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def target_tracking_configuration(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.TargetTrackingConfiguration"]:
            '''(experimental) targetTrackingConfiguration property.

            Specify an array of string values to match this event if the actual value of targetTrackingConfiguration is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_tracking_configuration")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.TargetTrackingConfiguration"], result)

        @builtins.property
        def time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) time property.

            Specify an array of string values to match this event if the actual value of time is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def topic_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) topicARN property.

            Specify an array of string values to match this event if the actual value of topicARN is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("topic_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_data(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userData property.

            Specify an array of string values to match this event if the actual value of userData is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_data")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def v_pc_zone_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) vPCZoneIdentifier property.

            Specify an array of string values to match this event if the actual value of vPCZoneIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("v_pc_zone_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParameters(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.RequestParametersItem",
        jsii_struct_bases=[],
        name_mapping={
            "key": "key",
            "propagate_at_launch": "propagateAtLaunch",
            "resource_id": "resourceId",
            "resource_type": "resourceType",
            "value": "value",
        },
    )
    class RequestParametersItem:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            propagate_at_launch: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParametersItem.

            :param key: (experimental) key property. Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param propagate_at_launch: (experimental) propagateAtLaunch property. Specify an array of string values to match this event if the actual value of propagateAtLaunch is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_id: (experimental) resourceId property. Specify an array of string values to match this event if the actual value of resourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_type: (experimental) resourceType property. Specify an array of string values to match this event if the actual value of resourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                request_parameters_item = autoscaling_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                    key=["key"],
                    propagate_at_launch=["propagateAtLaunch"],
                    resource_id=["resourceId"],
                    resource_type=["resourceType"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__804db7e5bcfee52ac7067a6954381efbb4452ffb5bdb7538204ab024b0d09c29)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument propagate_at_launch", value=propagate_at_launch, expected_type=type_hints["propagate_at_launch"])
                check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
                check_type(argname="argument resource_type", value=resource_type, expected_type=type_hints["resource_type"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if propagate_at_launch is not None:
                self._values["propagate_at_launch"] = propagate_at_launch
            if resource_id is not None:
                self._values["resource_id"] = resource_id
            if resource_type is not None:
                self._values["resource_type"] = resource_type
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) key property.

            Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def propagate_at_launch(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) propagateAtLaunch property.

            Specify an array of string values to match this event if the actual value of propagateAtLaunch is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("propagate_at_launch")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resourceId property.

            Specify an array of string values to match this event if the actual value of resourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resourceType property.

            Specify an array of string values to match this event if the actual value of resourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParametersItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.RequestParametersItem1",
        jsii_struct_bases=[],
        name_mapping={
            "metric_interval_lower_bound": "metricIntervalLowerBound",
            "scaling_adjustment": "scalingAdjustment",
        },
    )
    class RequestParametersItem1:
        def __init__(
            self,
            *,
            metric_interval_lower_bound: typing.Optional[typing.Sequence[builtins.str]] = None,
            scaling_adjustment: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParametersItem_1.

            :param metric_interval_lower_bound: (experimental) metricIntervalLowerBound property. Specify an array of string values to match this event if the actual value of metricIntervalLowerBound is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param scaling_adjustment: (experimental) scalingAdjustment property. Specify an array of string values to match this event if the actual value of scalingAdjustment is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                request_parameters_item1 = autoscaling_events.AWSAPICallViaCloudTrail.RequestParametersItem1(
                    metric_interval_lower_bound=["metricIntervalLowerBound"],
                    scaling_adjustment=["scalingAdjustment"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9238ca643ff32d78ef354f424c39d7156e06443af7ae1cb70224b8e798920d6b)
                check_type(argname="argument metric_interval_lower_bound", value=metric_interval_lower_bound, expected_type=type_hints["metric_interval_lower_bound"])
                check_type(argname="argument scaling_adjustment", value=scaling_adjustment, expected_type=type_hints["scaling_adjustment"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if metric_interval_lower_bound is not None:
                self._values["metric_interval_lower_bound"] = metric_interval_lower_bound
            if scaling_adjustment is not None:
                self._values["scaling_adjustment"] = scaling_adjustment

        @builtins.property
        def metric_interval_lower_bound(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) metricIntervalLowerBound property.

            Specify an array of string values to match this event if the actual value of metricIntervalLowerBound is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_interval_lower_bound")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def scaling_adjustment(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) scalingAdjustment property.

            Specify an array of string values to match this event if the actual value of scalingAdjustment is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("scaling_adjustment")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParametersItem1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.ResponseElements",
        jsii_struct_bases=[],
        name_mapping={
            "alarms": "alarms",
            "failed_scheduled_actions": "failedScheduledActions",
            "failed_scheduled_update_group_actions": "failedScheduledUpdateGroupActions",
            "policy_arn": "policyArn",
        },
    )
    class ResponseElements:
        def __init__(
            self,
            *,
            alarms: typing.Optional[typing.Sequence[typing.Any]] = None,
            failed_scheduled_actions: typing.Optional[typing.Sequence[typing.Any]] = None,
            failed_scheduled_update_group_actions: typing.Optional[typing.Sequence[typing.Any]] = None,
            policy_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResponseElements.

            :param alarms: (experimental) alarms property. Specify an array of string values to match this event if the actual value of alarms is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param failed_scheduled_actions: (experimental) failedScheduledActions property. Specify an array of string values to match this event if the actual value of failedScheduledActions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param failed_scheduled_update_group_actions: (experimental) failedScheduledUpdateGroupActions property. Specify an array of string values to match this event if the actual value of failedScheduledUpdateGroupActions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param policy_arn: (experimental) policyARN property. Specify an array of string values to match this event if the actual value of policyARN is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                # alarms: Any
                # failed_scheduled_actions: Any
                # failed_scheduled_update_group_actions: Any
                
                response_elements = autoscaling_events.AWSAPICallViaCloudTrail.ResponseElements(
                    alarms=[alarms],
                    failed_scheduled_actions=[failed_scheduled_actions],
                    failed_scheduled_update_group_actions=[failed_scheduled_update_group_actions],
                    policy_arn=["policyArn"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0a85d7e5d5f1ff1b3108d5b0e4b0f91529e641d2af9f79a7426d8155e2c70af4)
                check_type(argname="argument alarms", value=alarms, expected_type=type_hints["alarms"])
                check_type(argname="argument failed_scheduled_actions", value=failed_scheduled_actions, expected_type=type_hints["failed_scheduled_actions"])
                check_type(argname="argument failed_scheduled_update_group_actions", value=failed_scheduled_update_group_actions, expected_type=type_hints["failed_scheduled_update_group_actions"])
                check_type(argname="argument policy_arn", value=policy_arn, expected_type=type_hints["policy_arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if alarms is not None:
                self._values["alarms"] = alarms
            if failed_scheduled_actions is not None:
                self._values["failed_scheduled_actions"] = failed_scheduled_actions
            if failed_scheduled_update_group_actions is not None:
                self._values["failed_scheduled_update_group_actions"] = failed_scheduled_update_group_actions
            if policy_arn is not None:
                self._values["policy_arn"] = policy_arn

        @builtins.property
        def alarms(self) -> typing.Optional[typing.List[typing.Any]]:
            '''(experimental) alarms property.

            Specify an array of string values to match this event if the actual value of alarms is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("alarms")
            return typing.cast(typing.Optional[typing.List[typing.Any]], result)

        @builtins.property
        def failed_scheduled_actions(self) -> typing.Optional[typing.List[typing.Any]]:
            '''(experimental) failedScheduledActions property.

            Specify an array of string values to match this event if the actual value of failedScheduledActions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("failed_scheduled_actions")
            return typing.cast(typing.Optional[typing.List[typing.Any]], result)

        @builtins.property
        def failed_scheduled_update_group_actions(
            self,
        ) -> typing.Optional[typing.List[typing.Any]]:
            '''(experimental) failedScheduledUpdateGroupActions property.

            Specify an array of string values to match this event if the actual value of failedScheduledUpdateGroupActions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("failed_scheduled_update_group_actions")
            return typing.cast(typing.Optional[typing.List[typing.Any]], result)

        @builtins.property
        def policy_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) policyARN property.

            Specify an array of string values to match this event if the actual value of policyARN is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("policy_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResponseElements(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.TargetTrackingConfiguration",
        jsii_struct_bases=[],
        name_mapping={
            "customized_metric_specification": "customizedMetricSpecification",
            "predefined_metric_specification": "predefinedMetricSpecification",
            "target_value": "targetValue",
        },
    )
    class TargetTrackingConfiguration:
        def __init__(
            self,
            *,
            customized_metric_specification: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.CustomizedMetricSpecification", typing.Dict[builtins.str, typing.Any]]] = None,
            predefined_metric_specification: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.PredefinedMetricSpecification", typing.Dict[builtins.str, typing.Any]]] = None,
            target_value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for TargetTrackingConfiguration.

            :param customized_metric_specification: (experimental) customizedMetricSpecification property. Specify an array of string values to match this event if the actual value of customizedMetricSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param predefined_metric_specification: (experimental) predefinedMetricSpecification property. Specify an array of string values to match this event if the actual value of predefinedMetricSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_value: (experimental) targetValue property. Specify an array of string values to match this event if the actual value of targetValue is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                target_tracking_configuration = autoscaling_events.AWSAPICallViaCloudTrail.TargetTrackingConfiguration(
                    customized_metric_specification=autoscaling_events.AWSAPICallViaCloudTrail.CustomizedMetricSpecification(
                        dimensions=[autoscaling_events.AWSAPICallViaCloudTrail.CustomizedMetricSpecificationItem(
                            name=["name"],
                            value=["value"]
                        )],
                        metric_name=["metricName"],
                        namespace=["namespace"],
                        statistic=["statistic"],
                        unit=["unit"]
                    ),
                    predefined_metric_specification=autoscaling_events.AWSAPICallViaCloudTrail.PredefinedMetricSpecification(
                        predefined_metric_type=["predefinedMetricType"]
                    ),
                    target_value=["targetValue"]
                )
            '''
            if isinstance(customized_metric_specification, dict):
                customized_metric_specification = AWSAPICallViaCloudTrail.CustomizedMetricSpecification(**customized_metric_specification)
            if isinstance(predefined_metric_specification, dict):
                predefined_metric_specification = AWSAPICallViaCloudTrail.PredefinedMetricSpecification(**predefined_metric_specification)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__31eea2e11c4e8dffe7821b13a7bd5b21f64fb23296dcc4c567ceefa167069c83)
                check_type(argname="argument customized_metric_specification", value=customized_metric_specification, expected_type=type_hints["customized_metric_specification"])
                check_type(argname="argument predefined_metric_specification", value=predefined_metric_specification, expected_type=type_hints["predefined_metric_specification"])
                check_type(argname="argument target_value", value=target_value, expected_type=type_hints["target_value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if customized_metric_specification is not None:
                self._values["customized_metric_specification"] = customized_metric_specification
            if predefined_metric_specification is not None:
                self._values["predefined_metric_specification"] = predefined_metric_specification
            if target_value is not None:
                self._values["target_value"] = target_value

        @builtins.property
        def customized_metric_specification(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.CustomizedMetricSpecification"]:
            '''(experimental) customizedMetricSpecification property.

            Specify an array of string values to match this event if the actual value of customizedMetricSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("customized_metric_specification")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.CustomizedMetricSpecification"], result)

        @builtins.property
        def predefined_metric_specification(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.PredefinedMetricSpecification"]:
            '''(experimental) predefinedMetricSpecification property.

            Specify an array of string values to match this event if the actual value of predefinedMetricSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("predefined_metric_specification")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.PredefinedMetricSpecification"], result)

        @builtins.property
        def target_value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) targetValue property.

            Specify an array of string values to match this event if the actual value of targetValue is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TargetTrackingConfiguration(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AWSAPICallViaCloudTrail.UserIdentity",
        jsii_struct_bases=[],
        name_mapping={
            "access_key_id": "accessKeyId",
            "account_id": "accountId",
            "arn": "arn",
            "principal_id": "principalId",
            "type": "type",
        },
    )
    class UserIdentity:
        def __init__(
            self,
            *,
            access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for UserIdentity.

            :param access_key_id: (experimental) accessKeyId property. Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                user_identity = autoscaling_events.AWSAPICallViaCloudTrail.UserIdentity(
                    access_key_id=["accessKeyId"],
                    account_id=["accountId"],
                    arn=["arn"],
                    principal_id=["principalId"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d04ca64ce7aa12ee6e141de6298305dc67511fdedc42dce653dee57fc851c02a)
                check_type(argname="argument access_key_id", value=access_key_id, expected_type=type_hints["access_key_id"])
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if access_key_id is not None:
                self._values["access_key_id"] = access_key_id
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def access_key_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accessKeyId property.

            Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("access_key_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "UserIdentity(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class AutoScalingGroupEvents(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.AutoScalingGroupEvents",
):
    '''(experimental) EventBridge event patterns for AutoScalingGroup.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
        from aws_cdk.interfaces import aws_autoscaling as interfaces_autoscaling
        
        # auto_scaling_group_ref: interfaces_autoscaling.IAutoScalingGroupRef
        
        auto_scaling_group_events = autoscaling_events.AutoScalingGroupEvents.from_auto_scaling_group(auto_scaling_group_ref)
    '''

    @jsii.member(jsii_name="fromAutoScalingGroup")
    @builtins.classmethod
    def from_auto_scaling_group(
        cls,
        auto_scaling_group_ref: "_aws_cdk_interfaces_aws_autoscaling_ceddda9d.IAutoScalingGroupRef",
    ) -> "AutoScalingGroupEvents":
        '''(experimental) Create AutoScalingGroupEvents from a AutoScalingGroup reference.

        :param auto_scaling_group_ref: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__969e9a9ab78cc8e0d927bb6cc75bd3f471f7b0b3439b6bebcb043eab1ff95288)
            check_type(argname="argument auto_scaling_group_ref", value=auto_scaling_group_ref, expected_type=type_hints["auto_scaling_group_ref"])
        return typing.cast("AutoScalingGroupEvents", jsii.sinvoke(cls, "fromAutoScalingGroup", [auto_scaling_group_ref]))

    @jsii.member(jsii_name="ec2InstanceLaunchLifecycleActionPattern")
    def ec2_instance_launch_lifecycle_action_pattern(
        self,
        *,
        auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination: typing.Optional[typing.Sequence[builtins.str]] = None,
        ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        lifecycle_action_token: typing.Optional[typing.Sequence[builtins.str]] = None,
        lifecycle_hook_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        lifecycle_transition: typing.Optional[typing.Sequence[builtins.str]] = None,
        notification_metadata: typing.Optional[typing.Sequence[builtins.str]] = None,
        origin: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AutoScalingGroup EC2 Instance-launch Lifecycle Action.

        :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
        :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param lifecycle_action_token: (experimental) LifecycleActionToken property. Specify an array of string values to match this event if the actual value of LifecycleActionToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param lifecycle_hook_name: (experimental) LifecycleHookName property. Specify an array of string values to match this event if the actual value of LifecycleHookName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param lifecycle_transition: (experimental) LifecycleTransition property. Specify an array of string values to match this event if the actual value of LifecycleTransition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notification_metadata: (experimental) NotificationMetadata property. Specify an array of string values to match this event if the actual value of NotificationMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceLaunchLifecycleAction.EC2InstanceLaunchLifecycleActionProps(
            auto_scaling_group_name=auto_scaling_group_name,
            destination=destination,
            ec2_instance_id=ec2_instance_id,
            event_metadata=event_metadata,
            lifecycle_action_token=lifecycle_action_token,
            lifecycle_hook_name=lifecycle_hook_name,
            lifecycle_transition=lifecycle_transition,
            notification_metadata=notification_metadata,
            origin=origin,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "ec2InstanceLaunchLifecycleActionPattern", [options]))

    @jsii.member(jsii_name="ec2InstanceLaunchSuccessfulPattern")
    def ec2_instance_launch_successful_pattern(
        self,
        *,
        activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        cause: typing.Optional[typing.Sequence[builtins.str]] = None,
        description: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination: typing.Optional[typing.Sequence[builtins.str]] = None,
        details: typing.Optional[typing.Union["EC2InstanceLaunchSuccessful.Details", typing.Dict[builtins.str, typing.Any]]] = None,
        ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        origin: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AutoScalingGroup EC2 Instance Launch Successful.

        :param activity_id: (experimental) ActivityId property. Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
        :param cause: (experimental) Cause property. Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param description: (experimental) Description property. Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param details: (experimental) Details property. Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) RequestId property. Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_code: (experimental) StatusCode property. Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceLaunchSuccessful.EC2InstanceLaunchSuccessfulProps(
            activity_id=activity_id,
            auto_scaling_group_name=auto_scaling_group_name,
            cause=cause,
            description=description,
            destination=destination,
            details=details,
            ec2_instance_id=ec2_instance_id,
            end_time=end_time,
            event_metadata=event_metadata,
            origin=origin,
            request_id=request_id,
            start_time=start_time,
            status_code=status_code,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "ec2InstanceLaunchSuccessfulPattern", [options]))

    @jsii.member(jsii_name="ec2InstanceLaunchUnsuccessfulPattern")
    def ec2_instance_launch_unsuccessful_pattern(
        self,
        *,
        activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        cause: typing.Optional[typing.Sequence[builtins.str]] = None,
        description: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination: typing.Optional[typing.Sequence[builtins.str]] = None,
        details: typing.Optional[typing.Union["EC2InstanceLaunchUnsuccessful.Details", typing.Dict[builtins.str, typing.Any]]] = None,
        ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        origin: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AutoScalingGroup EC2 Instance Launch Unsuccessful.

        :param activity_id: (experimental) ActivityId property. Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
        :param cause: (experimental) Cause property. Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param description: (experimental) Description property. Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param details: (experimental) Details property. Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) RequestId property. Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_code: (experimental) StatusCode property. Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceLaunchUnsuccessful.EC2InstanceLaunchUnsuccessfulProps(
            activity_id=activity_id,
            auto_scaling_group_name=auto_scaling_group_name,
            cause=cause,
            description=description,
            destination=destination,
            details=details,
            ec2_instance_id=ec2_instance_id,
            end_time=end_time,
            event_metadata=event_metadata,
            origin=origin,
            request_id=request_id,
            start_time=start_time,
            status_code=status_code,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "ec2InstanceLaunchUnsuccessfulPattern", [options]))

    @jsii.member(jsii_name="ec2InstanceTerminateLifecycleActionPattern")
    def ec2_instance_terminate_lifecycle_action_pattern(
        self,
        *,
        auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination: typing.Optional[typing.Sequence[builtins.str]] = None,
        ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        lifecycle_action_token: typing.Optional[typing.Sequence[builtins.str]] = None,
        lifecycle_hook_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        lifecycle_transition: typing.Optional[typing.Sequence[builtins.str]] = None,
        notification_metadata: typing.Optional[typing.Sequence[builtins.str]] = None,
        origin: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AutoScalingGroup EC2 Instance-terminate Lifecycle Action.

        :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
        :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param lifecycle_action_token: (experimental) LifecycleActionToken property. Specify an array of string values to match this event if the actual value of LifecycleActionToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param lifecycle_hook_name: (experimental) LifecycleHookName property. Specify an array of string values to match this event if the actual value of LifecycleHookName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param lifecycle_transition: (experimental) LifecycleTransition property. Specify an array of string values to match this event if the actual value of LifecycleTransition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notification_metadata: (experimental) NotificationMetadata property. Specify an array of string values to match this event if the actual value of NotificationMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceTerminateLifecycleAction.EC2InstanceTerminateLifecycleActionProps(
            auto_scaling_group_name=auto_scaling_group_name,
            destination=destination,
            ec2_instance_id=ec2_instance_id,
            event_metadata=event_metadata,
            lifecycle_action_token=lifecycle_action_token,
            lifecycle_hook_name=lifecycle_hook_name,
            lifecycle_transition=lifecycle_transition,
            notification_metadata=notification_metadata,
            origin=origin,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "ec2InstanceTerminateLifecycleActionPattern", [options]))

    @jsii.member(jsii_name="ec2InstanceTerminateSuccessfulPattern")
    def ec2_instance_terminate_successful_pattern(
        self,
        *,
        activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        cause: typing.Optional[typing.Sequence[builtins.str]] = None,
        description: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination: typing.Optional[typing.Sequence[builtins.str]] = None,
        details: typing.Optional[typing.Union["EC2InstanceTerminateSuccessful.Details", typing.Dict[builtins.str, typing.Any]]] = None,
        ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        origin: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AutoScalingGroup EC2 Instance Terminate Successful.

        :param activity_id: (experimental) ActivityId property. Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
        :param cause: (experimental) Cause property. Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param description: (experimental) Description property. Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param details: (experimental) Details property. Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) RequestId property. Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_code: (experimental) StatusCode property. Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceTerminateSuccessful.EC2InstanceTerminateSuccessfulProps(
            activity_id=activity_id,
            auto_scaling_group_name=auto_scaling_group_name,
            cause=cause,
            description=description,
            destination=destination,
            details=details,
            ec2_instance_id=ec2_instance_id,
            end_time=end_time,
            event_metadata=event_metadata,
            origin=origin,
            request_id=request_id,
            start_time=start_time,
            status_code=status_code,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "ec2InstanceTerminateSuccessfulPattern", [options]))

    @jsii.member(jsii_name="ec2InstanceTerminateUnsuccessfulPattern")
    def ec2_instance_terminate_unsuccessful_pattern(
        self,
        *,
        activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        cause: typing.Optional[typing.Sequence[builtins.str]] = None,
        description: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination: typing.Optional[typing.Sequence[builtins.str]] = None,
        details: typing.Optional[typing.Union["EC2InstanceTerminateUnsuccessful.Details", typing.Dict[builtins.str, typing.Any]]] = None,
        ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        origin: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AutoScalingGroup EC2 Instance Terminate Unsuccessful.

        :param activity_id: (experimental) ActivityId property. Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
        :param cause: (experimental) Cause property. Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param description: (experimental) Description property. Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param details: (experimental) Details property. Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) RequestId property. Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_code: (experimental) StatusCode property. Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceTerminateUnsuccessful.EC2InstanceTerminateUnsuccessfulProps(
            activity_id=activity_id,
            auto_scaling_group_name=auto_scaling_group_name,
            cause=cause,
            description=description,
            destination=destination,
            details=details,
            ec2_instance_id=ec2_instance_id,
            end_time=end_time,
            event_metadata=event_metadata,
            origin=origin,
            request_id=request_id,
            start_time=start_time,
            status_code=status_code,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "ec2InstanceTerminateUnsuccessfulPattern", [options]))


class EC2InstanceLaunchLifecycleAction(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceLaunchLifecycleAction",
):
    '''(experimental) EventBridge event pattern for aws.autoscaling@EC2InstanceLaunchLifecycleAction.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
        
        e_c2_instance_launch_lifecycle_action = autoscaling_events.EC2InstanceLaunchLifecycleAction()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination: typing.Optional[typing.Sequence[builtins.str]] = None,
        ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        lifecycle_action_token: typing.Optional[typing.Sequence[builtins.str]] = None,
        lifecycle_hook_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        lifecycle_transition: typing.Optional[typing.Sequence[builtins.str]] = None,
        notification_metadata: typing.Optional[typing.Sequence[builtins.str]] = None,
        origin: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EC2 Instance-launch Lifecycle Action.

        :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
        :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param lifecycle_action_token: (experimental) LifecycleActionToken property. Specify an array of string values to match this event if the actual value of LifecycleActionToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param lifecycle_hook_name: (experimental) LifecycleHookName property. Specify an array of string values to match this event if the actual value of LifecycleHookName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param lifecycle_transition: (experimental) LifecycleTransition property. Specify an array of string values to match this event if the actual value of LifecycleTransition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notification_metadata: (experimental) NotificationMetadata property. Specify an array of string values to match this event if the actual value of NotificationMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceLaunchLifecycleAction.EC2InstanceLaunchLifecycleActionProps(
            auto_scaling_group_name=auto_scaling_group_name,
            destination=destination,
            ec2_instance_id=ec2_instance_id,
            event_metadata=event_metadata,
            lifecycle_action_token=lifecycle_action_token,
            lifecycle_hook_name=lifecycle_hook_name,
            lifecycle_transition=lifecycle_transition,
            notification_metadata=notification_metadata,
            origin=origin,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceLaunchLifecycleAction.EC2InstanceLaunchLifecycleActionProps",
        jsii_struct_bases=[],
        name_mapping={
            "auto_scaling_group_name": "autoScalingGroupName",
            "destination": "destination",
            "ec2_instance_id": "ec2InstanceId",
            "event_metadata": "eventMetadata",
            "lifecycle_action_token": "lifecycleActionToken",
            "lifecycle_hook_name": "lifecycleHookName",
            "lifecycle_transition": "lifecycleTransition",
            "notification_metadata": "notificationMetadata",
            "origin": "origin",
        },
    )
    class EC2InstanceLaunchLifecycleActionProps:
        def __init__(
            self,
            *,
            auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            destination: typing.Optional[typing.Sequence[builtins.str]] = None,
            ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            lifecycle_action_token: typing.Optional[typing.Sequence[builtins.str]] = None,
            lifecycle_hook_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            lifecycle_transition: typing.Optional[typing.Sequence[builtins.str]] = None,
            notification_metadata: typing.Optional[typing.Sequence[builtins.str]] = None,
            origin: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.autoscaling@EC2InstanceLaunchLifecycleAction event.

            :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
            :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param lifecycle_action_token: (experimental) LifecycleActionToken property. Specify an array of string values to match this event if the actual value of LifecycleActionToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param lifecycle_hook_name: (experimental) LifecycleHookName property. Specify an array of string values to match this event if the actual value of LifecycleHookName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param lifecycle_transition: (experimental) LifecycleTransition property. Specify an array of string values to match this event if the actual value of LifecycleTransition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notification_metadata: (experimental) NotificationMetadata property. Specify an array of string values to match this event if the actual value of NotificationMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                e_c2_instance_launch_lifecycle_action_props = autoscaling_events.EC2InstanceLaunchLifecycleAction.EC2InstanceLaunchLifecycleActionProps(
                    auto_scaling_group_name=["autoScalingGroupName"],
                    destination=["destination"],
                    ec2_instance_id=["ec2InstanceId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    lifecycle_action_token=["lifecycleActionToken"],
                    lifecycle_hook_name=["lifecycleHookName"],
                    lifecycle_transition=["lifecycleTransition"],
                    notification_metadata=["notificationMetadata"],
                    origin=["origin"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__318699159b862ad8220b30e01b7a8ee5c0162c93f976c2514c01e055aee2c087)
                check_type(argname="argument auto_scaling_group_name", value=auto_scaling_group_name, expected_type=type_hints["auto_scaling_group_name"])
                check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
                check_type(argname="argument ec2_instance_id", value=ec2_instance_id, expected_type=type_hints["ec2_instance_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument lifecycle_action_token", value=lifecycle_action_token, expected_type=type_hints["lifecycle_action_token"])
                check_type(argname="argument lifecycle_hook_name", value=lifecycle_hook_name, expected_type=type_hints["lifecycle_hook_name"])
                check_type(argname="argument lifecycle_transition", value=lifecycle_transition, expected_type=type_hints["lifecycle_transition"])
                check_type(argname="argument notification_metadata", value=notification_metadata, expected_type=type_hints["notification_metadata"])
                check_type(argname="argument origin", value=origin, expected_type=type_hints["origin"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if auto_scaling_group_name is not None:
                self._values["auto_scaling_group_name"] = auto_scaling_group_name
            if destination is not None:
                self._values["destination"] = destination
            if ec2_instance_id is not None:
                self._values["ec2_instance_id"] = ec2_instance_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if lifecycle_action_token is not None:
                self._values["lifecycle_action_token"] = lifecycle_action_token
            if lifecycle_hook_name is not None:
                self._values["lifecycle_hook_name"] = lifecycle_hook_name
            if lifecycle_transition is not None:
                self._values["lifecycle_transition"] = lifecycle_transition
            if notification_metadata is not None:
                self._values["notification_metadata"] = notification_metadata
            if origin is not None:
                self._values["origin"] = origin

        @builtins.property
        def auto_scaling_group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AutoScalingGroupName property.

            Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the AutoScalingGroup reference

            :stability: experimental
            '''
            result = self._values.get("auto_scaling_group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def destination(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Destination property.

            Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ec2_instance_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EC2InstanceId property.

            Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ec2_instance_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def lifecycle_action_token(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LifecycleActionToken property.

            Specify an array of string values to match this event if the actual value of LifecycleActionToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("lifecycle_action_token")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def lifecycle_hook_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LifecycleHookName property.

            Specify an array of string values to match this event if the actual value of LifecycleHookName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("lifecycle_hook_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def lifecycle_transition(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LifecycleTransition property.

            Specify an array of string values to match this event if the actual value of LifecycleTransition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("lifecycle_transition")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notification_metadata(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) NotificationMetadata property.

            Specify an array of string values to match this event if the actual value of NotificationMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notification_metadata")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def origin(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Origin property.

            Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("origin")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EC2InstanceLaunchLifecycleActionProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EC2InstanceLaunchSuccessful(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceLaunchSuccessful",
):
    '''(experimental) EventBridge event pattern for aws.autoscaling@EC2InstanceLaunchSuccessful.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
        
        e_c2_instance_launch_successful = autoscaling_events.EC2InstanceLaunchSuccessful()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        cause: typing.Optional[typing.Sequence[builtins.str]] = None,
        description: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination: typing.Optional[typing.Sequence[builtins.str]] = None,
        details: typing.Optional[typing.Union["EC2InstanceLaunchSuccessful.Details", typing.Dict[builtins.str, typing.Any]]] = None,
        ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        origin: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EC2 Instance Launch Successful.

        :param activity_id: (experimental) ActivityId property. Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
        :param cause: (experimental) Cause property. Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param description: (experimental) Description property. Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param details: (experimental) Details property. Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) RequestId property. Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_code: (experimental) StatusCode property. Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceLaunchSuccessful.EC2InstanceLaunchSuccessfulProps(
            activity_id=activity_id,
            auto_scaling_group_name=auto_scaling_group_name,
            cause=cause,
            description=description,
            destination=destination,
            details=details,
            ec2_instance_id=ec2_instance_id,
            end_time=end_time,
            event_metadata=event_metadata,
            origin=origin,
            request_id=request_id,
            start_time=start_time,
            status_code=status_code,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceLaunchSuccessful.Details",
        jsii_struct_bases=[],
        name_mapping={
            "availability_zone": "availabilityZone",
            "subnet_id": "subnetId",
        },
    )
    class Details:
        def __init__(
            self,
            *,
            availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Details.

            :param availability_zone: (experimental) Availability Zone property. Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) Subnet ID property. Specify an array of string values to match this event if the actual value of Subnet ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                details = autoscaling_events.EC2InstanceLaunchSuccessful.Details(
                    availability_zone=["availabilityZone"],
                    subnet_id=["subnetId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e438f3e62067f6d575a156a1549f79bf5bb9dc26feb42ffaa9a9596655fd008b)
                check_type(argname="argument availability_zone", value=availability_zone, expected_type=type_hints["availability_zone"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if availability_zone is not None:
                self._values["availability_zone"] = availability_zone
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id

        @builtins.property
        def availability_zone(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Availability Zone property.

            Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("availability_zone")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Subnet ID property.

            Specify an array of string values to match this event if the actual value of Subnet ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Details(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceLaunchSuccessful.EC2InstanceLaunchSuccessfulProps",
        jsii_struct_bases=[],
        name_mapping={
            "activity_id": "activityId",
            "auto_scaling_group_name": "autoScalingGroupName",
            "cause": "cause",
            "description": "description",
            "destination": "destination",
            "details": "details",
            "ec2_instance_id": "ec2InstanceId",
            "end_time": "endTime",
            "event_metadata": "eventMetadata",
            "origin": "origin",
            "request_id": "requestId",
            "start_time": "startTime",
            "status_code": "statusCode",
            "status_message": "statusMessage",
        },
    )
    class EC2InstanceLaunchSuccessfulProps:
        def __init__(
            self,
            *,
            activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            cause: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            destination: typing.Optional[typing.Sequence[builtins.str]] = None,
            details: typing.Optional[typing.Union["EC2InstanceLaunchSuccessful.Details", typing.Dict[builtins.str, typing.Any]]] = None,
            ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            origin: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.autoscaling@EC2InstanceLaunchSuccessful event.

            :param activity_id: (experimental) ActivityId property. Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
            :param cause: (experimental) Cause property. Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) Description property. Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param details: (experimental) Details property. Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) RequestId property. Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_code: (experimental) StatusCode property. Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                e_c2_instance_launch_successful_props = autoscaling_events.EC2InstanceLaunchSuccessful.EC2InstanceLaunchSuccessfulProps(
                    activity_id=["activityId"],
                    auto_scaling_group_name=["autoScalingGroupName"],
                    cause=["cause"],
                    description=["description"],
                    destination=["destination"],
                    details=autoscaling_events.EC2InstanceLaunchSuccessful.Details(
                        availability_zone=["availabilityZone"],
                        subnet_id=["subnetId"]
                    ),
                    ec2_instance_id=["ec2InstanceId"],
                    end_time=["endTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    origin=["origin"],
                    request_id=["requestId"],
                    start_time=["startTime"],
                    status_code=["statusCode"],
                    status_message=["statusMessage"]
                )
            '''
            if isinstance(details, dict):
                details = EC2InstanceLaunchSuccessful.Details(**details)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__15fe53a12c2a4754a8cda203a742454a29324d6cd5bf578626de6f9bbbc9f1cf)
                check_type(argname="argument activity_id", value=activity_id, expected_type=type_hints["activity_id"])
                check_type(argname="argument auto_scaling_group_name", value=auto_scaling_group_name, expected_type=type_hints["auto_scaling_group_name"])
                check_type(argname="argument cause", value=cause, expected_type=type_hints["cause"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
                check_type(argname="argument details", value=details, expected_type=type_hints["details"])
                check_type(argname="argument ec2_instance_id", value=ec2_instance_id, expected_type=type_hints["ec2_instance_id"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument origin", value=origin, expected_type=type_hints["origin"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument status_code", value=status_code, expected_type=type_hints["status_code"])
                check_type(argname="argument status_message", value=status_message, expected_type=type_hints["status_message"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if activity_id is not None:
                self._values["activity_id"] = activity_id
            if auto_scaling_group_name is not None:
                self._values["auto_scaling_group_name"] = auto_scaling_group_name
            if cause is not None:
                self._values["cause"] = cause
            if description is not None:
                self._values["description"] = description
            if destination is not None:
                self._values["destination"] = destination
            if details is not None:
                self._values["details"] = details
            if ec2_instance_id is not None:
                self._values["ec2_instance_id"] = ec2_instance_id
            if end_time is not None:
                self._values["end_time"] = end_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if origin is not None:
                self._values["origin"] = origin
            if request_id is not None:
                self._values["request_id"] = request_id
            if start_time is not None:
                self._values["start_time"] = start_time
            if status_code is not None:
                self._values["status_code"] = status_code
            if status_message is not None:
                self._values["status_message"] = status_message

        @builtins.property
        def activity_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ActivityId property.

            Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("activity_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def auto_scaling_group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AutoScalingGroupName property.

            Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the AutoScalingGroup reference

            :stability: experimental
            '''
            result = self._values.get("auto_scaling_group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def cause(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Cause property.

            Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cause")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Description property.

            Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def destination(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Destination property.

            Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def details(self) -> typing.Optional["EC2InstanceLaunchSuccessful.Details"]:
            '''(experimental) Details property.

            Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("details")
            return typing.cast(typing.Optional["EC2InstanceLaunchSuccessful.Details"], result)

        @builtins.property
        def ec2_instance_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EC2InstanceId property.

            Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ec2_instance_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EndTime property.

            Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def origin(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Origin property.

            Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("origin")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) RequestId property.

            Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StartTime property.

            Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StatusCode property.

            Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StatusMessage property.

            Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EC2InstanceLaunchSuccessfulProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EC2InstanceLaunchUnsuccessful(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceLaunchUnsuccessful",
):
    '''(experimental) EventBridge event pattern for aws.autoscaling@EC2InstanceLaunchUnsuccessful.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
        
        e_c2_instance_launch_unsuccessful = autoscaling_events.EC2InstanceLaunchUnsuccessful()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        cause: typing.Optional[typing.Sequence[builtins.str]] = None,
        description: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination: typing.Optional[typing.Sequence[builtins.str]] = None,
        details: typing.Optional[typing.Union["EC2InstanceLaunchUnsuccessful.Details", typing.Dict[builtins.str, typing.Any]]] = None,
        ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        origin: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EC2 Instance Launch Unsuccessful.

        :param activity_id: (experimental) ActivityId property. Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
        :param cause: (experimental) Cause property. Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param description: (experimental) Description property. Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param details: (experimental) Details property. Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) RequestId property. Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_code: (experimental) StatusCode property. Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceLaunchUnsuccessful.EC2InstanceLaunchUnsuccessfulProps(
            activity_id=activity_id,
            auto_scaling_group_name=auto_scaling_group_name,
            cause=cause,
            description=description,
            destination=destination,
            details=details,
            ec2_instance_id=ec2_instance_id,
            end_time=end_time,
            event_metadata=event_metadata,
            origin=origin,
            request_id=request_id,
            start_time=start_time,
            status_code=status_code,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceLaunchUnsuccessful.Details",
        jsii_struct_bases=[],
        name_mapping={
            "availability_zone": "availabilityZone",
            "subnet_id": "subnetId",
        },
    )
    class Details:
        def __init__(
            self,
            *,
            availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Details.

            :param availability_zone: (experimental) Availability Zone property. Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) Subnet ID property. Specify an array of string values to match this event if the actual value of Subnet ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                details = autoscaling_events.EC2InstanceLaunchUnsuccessful.Details(
                    availability_zone=["availabilityZone"],
                    subnet_id=["subnetId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9e5933ea1bc828b45df064e8b7c23152959c3952ba276353f78633d95869f4b1)
                check_type(argname="argument availability_zone", value=availability_zone, expected_type=type_hints["availability_zone"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if availability_zone is not None:
                self._values["availability_zone"] = availability_zone
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id

        @builtins.property
        def availability_zone(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Availability Zone property.

            Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("availability_zone")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Subnet ID property.

            Specify an array of string values to match this event if the actual value of Subnet ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Details(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceLaunchUnsuccessful.EC2InstanceLaunchUnsuccessfulProps",
        jsii_struct_bases=[],
        name_mapping={
            "activity_id": "activityId",
            "auto_scaling_group_name": "autoScalingGroupName",
            "cause": "cause",
            "description": "description",
            "destination": "destination",
            "details": "details",
            "ec2_instance_id": "ec2InstanceId",
            "end_time": "endTime",
            "event_metadata": "eventMetadata",
            "origin": "origin",
            "request_id": "requestId",
            "start_time": "startTime",
            "status_code": "statusCode",
            "status_message": "statusMessage",
        },
    )
    class EC2InstanceLaunchUnsuccessfulProps:
        def __init__(
            self,
            *,
            activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            cause: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            destination: typing.Optional[typing.Sequence[builtins.str]] = None,
            details: typing.Optional[typing.Union["EC2InstanceLaunchUnsuccessful.Details", typing.Dict[builtins.str, typing.Any]]] = None,
            ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            origin: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.autoscaling@EC2InstanceLaunchUnsuccessful event.

            :param activity_id: (experimental) ActivityId property. Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
            :param cause: (experimental) Cause property. Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) Description property. Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param details: (experimental) Details property. Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) RequestId property. Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_code: (experimental) StatusCode property. Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                e_c2_instance_launch_unsuccessful_props = autoscaling_events.EC2InstanceLaunchUnsuccessful.EC2InstanceLaunchUnsuccessfulProps(
                    activity_id=["activityId"],
                    auto_scaling_group_name=["autoScalingGroupName"],
                    cause=["cause"],
                    description=["description"],
                    destination=["destination"],
                    details=autoscaling_events.EC2InstanceLaunchUnsuccessful.Details(
                        availability_zone=["availabilityZone"],
                        subnet_id=["subnetId"]
                    ),
                    ec2_instance_id=["ec2InstanceId"],
                    end_time=["endTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    origin=["origin"],
                    request_id=["requestId"],
                    start_time=["startTime"],
                    status_code=["statusCode"],
                    status_message=["statusMessage"]
                )
            '''
            if isinstance(details, dict):
                details = EC2InstanceLaunchUnsuccessful.Details(**details)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8a3b61c2bf9160767b15d24c25658df273bb86257bebdccf957715fa66c2462d)
                check_type(argname="argument activity_id", value=activity_id, expected_type=type_hints["activity_id"])
                check_type(argname="argument auto_scaling_group_name", value=auto_scaling_group_name, expected_type=type_hints["auto_scaling_group_name"])
                check_type(argname="argument cause", value=cause, expected_type=type_hints["cause"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
                check_type(argname="argument details", value=details, expected_type=type_hints["details"])
                check_type(argname="argument ec2_instance_id", value=ec2_instance_id, expected_type=type_hints["ec2_instance_id"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument origin", value=origin, expected_type=type_hints["origin"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument status_code", value=status_code, expected_type=type_hints["status_code"])
                check_type(argname="argument status_message", value=status_message, expected_type=type_hints["status_message"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if activity_id is not None:
                self._values["activity_id"] = activity_id
            if auto_scaling_group_name is not None:
                self._values["auto_scaling_group_name"] = auto_scaling_group_name
            if cause is not None:
                self._values["cause"] = cause
            if description is not None:
                self._values["description"] = description
            if destination is not None:
                self._values["destination"] = destination
            if details is not None:
                self._values["details"] = details
            if ec2_instance_id is not None:
                self._values["ec2_instance_id"] = ec2_instance_id
            if end_time is not None:
                self._values["end_time"] = end_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if origin is not None:
                self._values["origin"] = origin
            if request_id is not None:
                self._values["request_id"] = request_id
            if start_time is not None:
                self._values["start_time"] = start_time
            if status_code is not None:
                self._values["status_code"] = status_code
            if status_message is not None:
                self._values["status_message"] = status_message

        @builtins.property
        def activity_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ActivityId property.

            Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("activity_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def auto_scaling_group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AutoScalingGroupName property.

            Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the AutoScalingGroup reference

            :stability: experimental
            '''
            result = self._values.get("auto_scaling_group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def cause(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Cause property.

            Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cause")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Description property.

            Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def destination(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Destination property.

            Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def details(self) -> typing.Optional["EC2InstanceLaunchUnsuccessful.Details"]:
            '''(experimental) Details property.

            Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("details")
            return typing.cast(typing.Optional["EC2InstanceLaunchUnsuccessful.Details"], result)

        @builtins.property
        def ec2_instance_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EC2InstanceId property.

            Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ec2_instance_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EndTime property.

            Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def origin(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Origin property.

            Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("origin")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) RequestId property.

            Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StartTime property.

            Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StatusCode property.

            Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StatusMessage property.

            Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EC2InstanceLaunchUnsuccessfulProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EC2InstanceTerminateLifecycleAction(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceTerminateLifecycleAction",
):
    '''(experimental) EventBridge event pattern for aws.autoscaling@EC2InstanceTerminateLifecycleAction.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
        
        e_c2_instance_terminate_lifecycle_action = autoscaling_events.EC2InstanceTerminateLifecycleAction()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination: typing.Optional[typing.Sequence[builtins.str]] = None,
        ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        lifecycle_action_token: typing.Optional[typing.Sequence[builtins.str]] = None,
        lifecycle_hook_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        lifecycle_transition: typing.Optional[typing.Sequence[builtins.str]] = None,
        notification_metadata: typing.Optional[typing.Sequence[builtins.str]] = None,
        origin: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EC2 Instance-terminate Lifecycle Action.

        :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
        :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param lifecycle_action_token: (experimental) LifecycleActionToken property. Specify an array of string values to match this event if the actual value of LifecycleActionToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param lifecycle_hook_name: (experimental) LifecycleHookName property. Specify an array of string values to match this event if the actual value of LifecycleHookName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param lifecycle_transition: (experimental) LifecycleTransition property. Specify an array of string values to match this event if the actual value of LifecycleTransition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notification_metadata: (experimental) NotificationMetadata property. Specify an array of string values to match this event if the actual value of NotificationMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceTerminateLifecycleAction.EC2InstanceTerminateLifecycleActionProps(
            auto_scaling_group_name=auto_scaling_group_name,
            destination=destination,
            ec2_instance_id=ec2_instance_id,
            event_metadata=event_metadata,
            lifecycle_action_token=lifecycle_action_token,
            lifecycle_hook_name=lifecycle_hook_name,
            lifecycle_transition=lifecycle_transition,
            notification_metadata=notification_metadata,
            origin=origin,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceTerminateLifecycleAction.EC2InstanceTerminateLifecycleActionProps",
        jsii_struct_bases=[],
        name_mapping={
            "auto_scaling_group_name": "autoScalingGroupName",
            "destination": "destination",
            "ec2_instance_id": "ec2InstanceId",
            "event_metadata": "eventMetadata",
            "lifecycle_action_token": "lifecycleActionToken",
            "lifecycle_hook_name": "lifecycleHookName",
            "lifecycle_transition": "lifecycleTransition",
            "notification_metadata": "notificationMetadata",
            "origin": "origin",
        },
    )
    class EC2InstanceTerminateLifecycleActionProps:
        def __init__(
            self,
            *,
            auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            destination: typing.Optional[typing.Sequence[builtins.str]] = None,
            ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            lifecycle_action_token: typing.Optional[typing.Sequence[builtins.str]] = None,
            lifecycle_hook_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            lifecycle_transition: typing.Optional[typing.Sequence[builtins.str]] = None,
            notification_metadata: typing.Optional[typing.Sequence[builtins.str]] = None,
            origin: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.autoscaling@EC2InstanceTerminateLifecycleAction event.

            :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
            :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param lifecycle_action_token: (experimental) LifecycleActionToken property. Specify an array of string values to match this event if the actual value of LifecycleActionToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param lifecycle_hook_name: (experimental) LifecycleHookName property. Specify an array of string values to match this event if the actual value of LifecycleHookName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param lifecycle_transition: (experimental) LifecycleTransition property. Specify an array of string values to match this event if the actual value of LifecycleTransition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notification_metadata: (experimental) NotificationMetadata property. Specify an array of string values to match this event if the actual value of NotificationMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                e_c2_instance_terminate_lifecycle_action_props = autoscaling_events.EC2InstanceTerminateLifecycleAction.EC2InstanceTerminateLifecycleActionProps(
                    auto_scaling_group_name=["autoScalingGroupName"],
                    destination=["destination"],
                    ec2_instance_id=["ec2InstanceId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    lifecycle_action_token=["lifecycleActionToken"],
                    lifecycle_hook_name=["lifecycleHookName"],
                    lifecycle_transition=["lifecycleTransition"],
                    notification_metadata=["notificationMetadata"],
                    origin=["origin"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9bd840d62bd9192729afdeb2803dba3a4db1d27064e470a890c0e08025d70bad)
                check_type(argname="argument auto_scaling_group_name", value=auto_scaling_group_name, expected_type=type_hints["auto_scaling_group_name"])
                check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
                check_type(argname="argument ec2_instance_id", value=ec2_instance_id, expected_type=type_hints["ec2_instance_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument lifecycle_action_token", value=lifecycle_action_token, expected_type=type_hints["lifecycle_action_token"])
                check_type(argname="argument lifecycle_hook_name", value=lifecycle_hook_name, expected_type=type_hints["lifecycle_hook_name"])
                check_type(argname="argument lifecycle_transition", value=lifecycle_transition, expected_type=type_hints["lifecycle_transition"])
                check_type(argname="argument notification_metadata", value=notification_metadata, expected_type=type_hints["notification_metadata"])
                check_type(argname="argument origin", value=origin, expected_type=type_hints["origin"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if auto_scaling_group_name is not None:
                self._values["auto_scaling_group_name"] = auto_scaling_group_name
            if destination is not None:
                self._values["destination"] = destination
            if ec2_instance_id is not None:
                self._values["ec2_instance_id"] = ec2_instance_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if lifecycle_action_token is not None:
                self._values["lifecycle_action_token"] = lifecycle_action_token
            if lifecycle_hook_name is not None:
                self._values["lifecycle_hook_name"] = lifecycle_hook_name
            if lifecycle_transition is not None:
                self._values["lifecycle_transition"] = lifecycle_transition
            if notification_metadata is not None:
                self._values["notification_metadata"] = notification_metadata
            if origin is not None:
                self._values["origin"] = origin

        @builtins.property
        def auto_scaling_group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AutoScalingGroupName property.

            Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the AutoScalingGroup reference

            :stability: experimental
            '''
            result = self._values.get("auto_scaling_group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def destination(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Destination property.

            Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ec2_instance_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EC2InstanceId property.

            Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ec2_instance_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def lifecycle_action_token(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LifecycleActionToken property.

            Specify an array of string values to match this event if the actual value of LifecycleActionToken is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("lifecycle_action_token")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def lifecycle_hook_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LifecycleHookName property.

            Specify an array of string values to match this event if the actual value of LifecycleHookName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("lifecycle_hook_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def lifecycle_transition(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LifecycleTransition property.

            Specify an array of string values to match this event if the actual value of LifecycleTransition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("lifecycle_transition")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notification_metadata(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) NotificationMetadata property.

            Specify an array of string values to match this event if the actual value of NotificationMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notification_metadata")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def origin(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Origin property.

            Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("origin")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EC2InstanceTerminateLifecycleActionProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EC2InstanceTerminateSuccessful(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceTerminateSuccessful",
):
    '''(experimental) EventBridge event pattern for aws.autoscaling@EC2InstanceTerminateSuccessful.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
        
        e_c2_instance_terminate_successful = autoscaling_events.EC2InstanceTerminateSuccessful()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        cause: typing.Optional[typing.Sequence[builtins.str]] = None,
        description: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination: typing.Optional[typing.Sequence[builtins.str]] = None,
        details: typing.Optional[typing.Union["EC2InstanceTerminateSuccessful.Details", typing.Dict[builtins.str, typing.Any]]] = None,
        ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        origin: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EC2 Instance Terminate Successful.

        :param activity_id: (experimental) ActivityId property. Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
        :param cause: (experimental) Cause property. Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param description: (experimental) Description property. Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param details: (experimental) Details property. Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) RequestId property. Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_code: (experimental) StatusCode property. Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceTerminateSuccessful.EC2InstanceTerminateSuccessfulProps(
            activity_id=activity_id,
            auto_scaling_group_name=auto_scaling_group_name,
            cause=cause,
            description=description,
            destination=destination,
            details=details,
            ec2_instance_id=ec2_instance_id,
            end_time=end_time,
            event_metadata=event_metadata,
            origin=origin,
            request_id=request_id,
            start_time=start_time,
            status_code=status_code,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceTerminateSuccessful.Details",
        jsii_struct_bases=[],
        name_mapping={
            "availability_zone": "availabilityZone",
            "subnet_id": "subnetId",
        },
    )
    class Details:
        def __init__(
            self,
            *,
            availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Details.

            :param availability_zone: (experimental) Availability Zone property. Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) Subnet ID property. Specify an array of string values to match this event if the actual value of Subnet ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                details = autoscaling_events.EC2InstanceTerminateSuccessful.Details(
                    availability_zone=["availabilityZone"],
                    subnet_id=["subnetId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__59d186e8e33d58835c317ff8495dc077747ce0219eb08bd9f222cf968b9ea7fd)
                check_type(argname="argument availability_zone", value=availability_zone, expected_type=type_hints["availability_zone"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if availability_zone is not None:
                self._values["availability_zone"] = availability_zone
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id

        @builtins.property
        def availability_zone(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Availability Zone property.

            Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("availability_zone")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Subnet ID property.

            Specify an array of string values to match this event if the actual value of Subnet ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Details(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceTerminateSuccessful.EC2InstanceTerminateSuccessfulProps",
        jsii_struct_bases=[],
        name_mapping={
            "activity_id": "activityId",
            "auto_scaling_group_name": "autoScalingGroupName",
            "cause": "cause",
            "description": "description",
            "destination": "destination",
            "details": "details",
            "ec2_instance_id": "ec2InstanceId",
            "end_time": "endTime",
            "event_metadata": "eventMetadata",
            "origin": "origin",
            "request_id": "requestId",
            "start_time": "startTime",
            "status_code": "statusCode",
            "status_message": "statusMessage",
        },
    )
    class EC2InstanceTerminateSuccessfulProps:
        def __init__(
            self,
            *,
            activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            cause: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            destination: typing.Optional[typing.Sequence[builtins.str]] = None,
            details: typing.Optional[typing.Union["EC2InstanceTerminateSuccessful.Details", typing.Dict[builtins.str, typing.Any]]] = None,
            ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            origin: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.autoscaling@EC2InstanceTerminateSuccessful event.

            :param activity_id: (experimental) ActivityId property. Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
            :param cause: (experimental) Cause property. Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) Description property. Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param details: (experimental) Details property. Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) RequestId property. Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_code: (experimental) StatusCode property. Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                e_c2_instance_terminate_successful_props = autoscaling_events.EC2InstanceTerminateSuccessful.EC2InstanceTerminateSuccessfulProps(
                    activity_id=["activityId"],
                    auto_scaling_group_name=["autoScalingGroupName"],
                    cause=["cause"],
                    description=["description"],
                    destination=["destination"],
                    details=autoscaling_events.EC2InstanceTerminateSuccessful.Details(
                        availability_zone=["availabilityZone"],
                        subnet_id=["subnetId"]
                    ),
                    ec2_instance_id=["ec2InstanceId"],
                    end_time=["endTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    origin=["origin"],
                    request_id=["requestId"],
                    start_time=["startTime"],
                    status_code=["statusCode"],
                    status_message=["statusMessage"]
                )
            '''
            if isinstance(details, dict):
                details = EC2InstanceTerminateSuccessful.Details(**details)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1c8ab8a33a48e99a5101edc4fe429dc694080a9b0e4d0c8414ef449822cdfce2)
                check_type(argname="argument activity_id", value=activity_id, expected_type=type_hints["activity_id"])
                check_type(argname="argument auto_scaling_group_name", value=auto_scaling_group_name, expected_type=type_hints["auto_scaling_group_name"])
                check_type(argname="argument cause", value=cause, expected_type=type_hints["cause"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
                check_type(argname="argument details", value=details, expected_type=type_hints["details"])
                check_type(argname="argument ec2_instance_id", value=ec2_instance_id, expected_type=type_hints["ec2_instance_id"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument origin", value=origin, expected_type=type_hints["origin"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument status_code", value=status_code, expected_type=type_hints["status_code"])
                check_type(argname="argument status_message", value=status_message, expected_type=type_hints["status_message"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if activity_id is not None:
                self._values["activity_id"] = activity_id
            if auto_scaling_group_name is not None:
                self._values["auto_scaling_group_name"] = auto_scaling_group_name
            if cause is not None:
                self._values["cause"] = cause
            if description is not None:
                self._values["description"] = description
            if destination is not None:
                self._values["destination"] = destination
            if details is not None:
                self._values["details"] = details
            if ec2_instance_id is not None:
                self._values["ec2_instance_id"] = ec2_instance_id
            if end_time is not None:
                self._values["end_time"] = end_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if origin is not None:
                self._values["origin"] = origin
            if request_id is not None:
                self._values["request_id"] = request_id
            if start_time is not None:
                self._values["start_time"] = start_time
            if status_code is not None:
                self._values["status_code"] = status_code
            if status_message is not None:
                self._values["status_message"] = status_message

        @builtins.property
        def activity_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ActivityId property.

            Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("activity_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def auto_scaling_group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AutoScalingGroupName property.

            Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the AutoScalingGroup reference

            :stability: experimental
            '''
            result = self._values.get("auto_scaling_group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def cause(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Cause property.

            Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cause")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Description property.

            Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def destination(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Destination property.

            Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def details(self) -> typing.Optional["EC2InstanceTerminateSuccessful.Details"]:
            '''(experimental) Details property.

            Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("details")
            return typing.cast(typing.Optional["EC2InstanceTerminateSuccessful.Details"], result)

        @builtins.property
        def ec2_instance_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EC2InstanceId property.

            Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ec2_instance_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EndTime property.

            Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def origin(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Origin property.

            Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("origin")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) RequestId property.

            Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StartTime property.

            Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StatusCode property.

            Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StatusMessage property.

            Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EC2InstanceTerminateSuccessfulProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EC2InstanceTerminateUnsuccessful(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceTerminateUnsuccessful",
):
    '''(experimental) EventBridge event pattern for aws.autoscaling@EC2InstanceTerminateUnsuccessful.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
        
        e_c2_instance_terminate_unsuccessful = autoscaling_events.EC2InstanceTerminateUnsuccessful()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        cause: typing.Optional[typing.Sequence[builtins.str]] = None,
        description: typing.Optional[typing.Sequence[builtins.str]] = None,
        destination: typing.Optional[typing.Sequence[builtins.str]] = None,
        details: typing.Optional[typing.Union["EC2InstanceTerminateUnsuccessful.Details", typing.Dict[builtins.str, typing.Any]]] = None,
        ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        origin: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EC2 Instance Terminate Unsuccessful.

        :param activity_id: (experimental) ActivityId property. Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
        :param cause: (experimental) Cause property. Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param description: (experimental) Description property. Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param details: (experimental) Details property. Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) RequestId property. Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_code: (experimental) StatusCode property. Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2InstanceTerminateUnsuccessful.EC2InstanceTerminateUnsuccessfulProps(
            activity_id=activity_id,
            auto_scaling_group_name=auto_scaling_group_name,
            cause=cause,
            description=description,
            destination=destination,
            details=details,
            ec2_instance_id=ec2_instance_id,
            end_time=end_time,
            event_metadata=event_metadata,
            origin=origin,
            request_id=request_id,
            start_time=start_time,
            status_code=status_code,
            status_message=status_message,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceTerminateUnsuccessful.Details",
        jsii_struct_bases=[],
        name_mapping={
            "availability_zone": "availabilityZone",
            "subnet_id": "subnetId",
        },
    )
    class Details:
        def __init__(
            self,
            *,
            availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Details.

            :param availability_zone: (experimental) Availability Zone property. Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) Subnet ID property. Specify an array of string values to match this event if the actual value of Subnet ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                details = autoscaling_events.EC2InstanceTerminateUnsuccessful.Details(
                    availability_zone=["availabilityZone"],
                    subnet_id=["subnetId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0fbe9490358f3f6f2eb03d75c19d661c8bc9721f2fabf16ce70df3901e790cc8)
                check_type(argname="argument availability_zone", value=availability_zone, expected_type=type_hints["availability_zone"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if availability_zone is not None:
                self._values["availability_zone"] = availability_zone
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id

        @builtins.property
        def availability_zone(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Availability Zone property.

            Specify an array of string values to match this event if the actual value of Availability Zone is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("availability_zone")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Subnet ID property.

            Specify an array of string values to match this event if the actual value of Subnet ID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Details(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_autoscaling.events.EC2InstanceTerminateUnsuccessful.EC2InstanceTerminateUnsuccessfulProps",
        jsii_struct_bases=[],
        name_mapping={
            "activity_id": "activityId",
            "auto_scaling_group_name": "autoScalingGroupName",
            "cause": "cause",
            "description": "description",
            "destination": "destination",
            "details": "details",
            "ec2_instance_id": "ec2InstanceId",
            "end_time": "endTime",
            "event_metadata": "eventMetadata",
            "origin": "origin",
            "request_id": "requestId",
            "start_time": "startTime",
            "status_code": "statusCode",
            "status_message": "statusMessage",
        },
    )
    class EC2InstanceTerminateUnsuccessfulProps:
        def __init__(
            self,
            *,
            activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            cause: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            destination: typing.Optional[typing.Sequence[builtins.str]] = None,
            details: typing.Optional[typing.Union["EC2InstanceTerminateUnsuccessful.Details", typing.Dict[builtins.str, typing.Any]]] = None,
            ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            origin: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.autoscaling@EC2InstanceTerminateUnsuccessful event.

            :param activity_id: (experimental) ActivityId property. Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param auto_scaling_group_name: (experimental) AutoScalingGroupName property. Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the AutoScalingGroup reference
            :param cause: (experimental) Cause property. Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) Description property. Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param destination: (experimental) Destination property. Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param details: (experimental) Details property. Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ec2_instance_id: (experimental) EC2InstanceId property. Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) EndTime property. Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param origin: (experimental) Origin property. Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) RequestId property. Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_code: (experimental) StatusCode property. Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_autoscaling import events as autoscaling_events
                
                e_c2_instance_terminate_unsuccessful_props = autoscaling_events.EC2InstanceTerminateUnsuccessful.EC2InstanceTerminateUnsuccessfulProps(
                    activity_id=["activityId"],
                    auto_scaling_group_name=["autoScalingGroupName"],
                    cause=["cause"],
                    description=["description"],
                    destination=["destination"],
                    details=autoscaling_events.EC2InstanceTerminateUnsuccessful.Details(
                        availability_zone=["availabilityZone"],
                        subnet_id=["subnetId"]
                    ),
                    ec2_instance_id=["ec2InstanceId"],
                    end_time=["endTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    origin=["origin"],
                    request_id=["requestId"],
                    start_time=["startTime"],
                    status_code=["statusCode"],
                    status_message=["statusMessage"]
                )
            '''
            if isinstance(details, dict):
                details = EC2InstanceTerminateUnsuccessful.Details(**details)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1f89ca7b8d413c8a498ab04585f624f552938f5d43d1f8595dad0996acb25211)
                check_type(argname="argument activity_id", value=activity_id, expected_type=type_hints["activity_id"])
                check_type(argname="argument auto_scaling_group_name", value=auto_scaling_group_name, expected_type=type_hints["auto_scaling_group_name"])
                check_type(argname="argument cause", value=cause, expected_type=type_hints["cause"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
                check_type(argname="argument details", value=details, expected_type=type_hints["details"])
                check_type(argname="argument ec2_instance_id", value=ec2_instance_id, expected_type=type_hints["ec2_instance_id"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument origin", value=origin, expected_type=type_hints["origin"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument status_code", value=status_code, expected_type=type_hints["status_code"])
                check_type(argname="argument status_message", value=status_message, expected_type=type_hints["status_message"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if activity_id is not None:
                self._values["activity_id"] = activity_id
            if auto_scaling_group_name is not None:
                self._values["auto_scaling_group_name"] = auto_scaling_group_name
            if cause is not None:
                self._values["cause"] = cause
            if description is not None:
                self._values["description"] = description
            if destination is not None:
                self._values["destination"] = destination
            if details is not None:
                self._values["details"] = details
            if ec2_instance_id is not None:
                self._values["ec2_instance_id"] = ec2_instance_id
            if end_time is not None:
                self._values["end_time"] = end_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if origin is not None:
                self._values["origin"] = origin
            if request_id is not None:
                self._values["request_id"] = request_id
            if start_time is not None:
                self._values["start_time"] = start_time
            if status_code is not None:
                self._values["status_code"] = status_code
            if status_message is not None:
                self._values["status_message"] = status_message

        @builtins.property
        def activity_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ActivityId property.

            Specify an array of string values to match this event if the actual value of ActivityId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("activity_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def auto_scaling_group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AutoScalingGroupName property.

            Specify an array of string values to match this event if the actual value of AutoScalingGroupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the AutoScalingGroup reference

            :stability: experimental
            '''
            result = self._values.get("auto_scaling_group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def cause(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Cause property.

            Specify an array of string values to match this event if the actual value of Cause is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cause")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Description property.

            Specify an array of string values to match this event if the actual value of Description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def destination(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Destination property.

            Specify an array of string values to match this event if the actual value of Destination is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("destination")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def details(
            self,
        ) -> typing.Optional["EC2InstanceTerminateUnsuccessful.Details"]:
            '''(experimental) Details property.

            Specify an array of string values to match this event if the actual value of Details is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("details")
            return typing.cast(typing.Optional["EC2InstanceTerminateUnsuccessful.Details"], result)

        @builtins.property
        def ec2_instance_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EC2InstanceId property.

            Specify an array of string values to match this event if the actual value of EC2InstanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ec2_instance_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EndTime property.

            Specify an array of string values to match this event if the actual value of EndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def origin(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Origin property.

            Specify an array of string values to match this event if the actual value of Origin is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("origin")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) RequestId property.

            Specify an array of string values to match this event if the actual value of RequestId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StartTime property.

            Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StatusCode property.

            Specify an array of string values to match this event if the actual value of StatusCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StatusMessage property.

            Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EC2InstanceTerminateUnsuccessfulProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "AWSAPICallViaCloudTrail",
    "AutoScalingGroupEvents",
    "EC2InstanceLaunchLifecycleAction",
    "EC2InstanceLaunchSuccessful",
    "EC2InstanceLaunchUnsuccessful",
    "EC2InstanceTerminateLifecycleAction",
    "EC2InstanceTerminateSuccessful",
    "EC2InstanceTerminateUnsuccessful",
]

publication.publish()

def _typecheckingstub__e1e4acf2fb9f06e51b818e7b09430b6eb5a12ab06e5b3273538cad73e1a3c7d8(
    *,
    aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_parameters: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.RequestParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    response_elements: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ResponseElements, typing.Dict[builtins.str, typing.Any]]] = None,
    source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_identity: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.UserIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd309829311f49cca94ab1b534901d6a637bc7e86eecd8d08e20fdcb4856b0c6(
    *,
    dimensions: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.CustomizedMetricSpecificationItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    metric_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    namespace: typing.Optional[typing.Sequence[builtins.str]] = None,
    statistic: typing.Optional[typing.Sequence[builtins.str]] = None,
    unit: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dd82298f1d560cfca0c0ea744007867d598b0c144e10280282140eb132843bb6(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__37a5915d91cc83f2a80af317545968eff9750b702b8f1fd63bacdf2f0485c1b1(
    *,
    on_demand_allocation_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
    on_demand_base_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
    on_demand_percentage_above_base_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
    spot_allocation_strategy: typing.Optional[typing.Sequence[builtins.str]] = None,
    spot_instance_pools: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c0ebddccd4c6a6bfe237a6ef13906182cab76023a70975044d3bc8f6df9adee0(
    *,
    launch_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e3094cebf12d5f9730af6d95c0992d7a5a33010014c1f02ec4a789b8bb2762f0(
    *,
    launch_template_specification: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.LaunchTemplateSpecification, typing.Dict[builtins.str, typing.Any]]] = None,
    overrides: typing.Optional[typing.Sequence[typing.Any]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a15a2b992d22ee710fa7753fa477c1a046811a8354cc6d4f9da55c16e5072da(
    *,
    launch_template_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d530143bc0a7f57bc3041daff3da2293883fc10aabed80716d3301203a0c133d(
    *,
    instances_distribution: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.InstancesDistribution, typing.Dict[builtins.str, typing.Any]]] = None,
    launch_template: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.LaunchTemplate1, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__faf90cf89506dc675dbc819390efa2df119fe011cb6b9b267dca8b03a808834b(
    *,
    predefined_metric_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1dd976ae6e76a746546f6ae57347a1349866b12a684a8bd641bbd739a5e282f0(
    *,
    adjustment_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    availability_zones: typing.Optional[typing.Sequence[builtins.str]] = None,
    breach_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
    default_cooldown: typing.Optional[typing.Sequence[builtins.str]] = None,
    desired_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
    force_delete: typing.Optional[typing.Sequence[builtins.str]] = None,
    granularity: typing.Optional[typing.Sequence[builtins.str]] = None,
    health_check_grace_period: typing.Optional[typing.Sequence[builtins.str]] = None,
    health_check_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    honor_cooldown: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    launch_configuration_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    launch_template: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.LaunchTemplate, typing.Dict[builtins.str, typing.Any]]] = None,
    lifecycle_hook_specification_list: typing.Optional[typing.Sequence[typing.Any]] = None,
    load_balancer_names: typing.Optional[typing.Sequence[builtins.str]] = None,
    max_size: typing.Optional[typing.Sequence[builtins.str]] = None,
    metrics: typing.Optional[typing.Sequence[builtins.str]] = None,
    metric_value: typing.Optional[typing.Sequence[builtins.str]] = None,
    min_size: typing.Optional[typing.Sequence[builtins.str]] = None,
    mixed_instances_policy: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.MixedInstancesPolicy, typing.Dict[builtins.str, typing.Any]]] = None,
    new_instances_protected_from_scale_in: typing.Optional[typing.Sequence[builtins.str]] = None,
    notification_types: typing.Optional[typing.Sequence[builtins.str]] = None,
    policy_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    policy_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    protected_from_scale_in: typing.Optional[typing.Sequence[builtins.str]] = None,
    scaling_adjustment: typing.Optional[typing.Sequence[builtins.str]] = None,
    scheduled_action_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    scheduled_action_names: typing.Optional[typing.Sequence[builtins.str]] = None,
    scheduled_update_group_actions: typing.Optional[typing.Sequence[typing.Any]] = None,
    security_groups: typing.Optional[typing.Sequence[builtins.str]] = None,
    service_linked_role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    spot_price: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    step_adjustments: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.RequestParametersItem1, typing.Dict[builtins.str, typing.Any]]]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.RequestParametersItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    target_group_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
    target_tracking_configuration: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.TargetTrackingConfiguration, typing.Dict[builtins.str, typing.Any]]] = None,
    time: typing.Optional[typing.Sequence[builtins.str]] = None,
    topic_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_data: typing.Optional[typing.Sequence[builtins.str]] = None,
    v_pc_zone_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__804db7e5bcfee52ac7067a6954381efbb4452ffb5bdb7538204ab024b0d09c29(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    propagate_at_launch: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9238ca643ff32d78ef354f424c39d7156e06443af7ae1cb70224b8e798920d6b(
    *,
    metric_interval_lower_bound: typing.Optional[typing.Sequence[builtins.str]] = None,
    scaling_adjustment: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a85d7e5d5f1ff1b3108d5b0e4b0f91529e641d2af9f79a7426d8155e2c70af4(
    *,
    alarms: typing.Optional[typing.Sequence[typing.Any]] = None,
    failed_scheduled_actions: typing.Optional[typing.Sequence[typing.Any]] = None,
    failed_scheduled_update_group_actions: typing.Optional[typing.Sequence[typing.Any]] = None,
    policy_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__31eea2e11c4e8dffe7821b13a7bd5b21f64fb23296dcc4c567ceefa167069c83(
    *,
    customized_metric_specification: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.CustomizedMetricSpecification, typing.Dict[builtins.str, typing.Any]]] = None,
    predefined_metric_specification: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.PredefinedMetricSpecification, typing.Dict[builtins.str, typing.Any]]] = None,
    target_value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d04ca64ce7aa12ee6e141de6298305dc67511fdedc42dce653dee57fc851c02a(
    *,
    access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__969e9a9ab78cc8e0d927bb6cc75bd3f471f7b0b3439b6bebcb043eab1ff95288(
    auto_scaling_group_ref: _aws_cdk_interfaces_aws_autoscaling_ceddda9d.IAutoScalingGroupRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__318699159b862ad8220b30e01b7a8ee5c0162c93f976c2514c01e055aee2c087(
    *,
    auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    destination: typing.Optional[typing.Sequence[builtins.str]] = None,
    ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    lifecycle_action_token: typing.Optional[typing.Sequence[builtins.str]] = None,
    lifecycle_hook_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    lifecycle_transition: typing.Optional[typing.Sequence[builtins.str]] = None,
    notification_metadata: typing.Optional[typing.Sequence[builtins.str]] = None,
    origin: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e438f3e62067f6d575a156a1549f79bf5bb9dc26feb42ffaa9a9596655fd008b(
    *,
    availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__15fe53a12c2a4754a8cda203a742454a29324d6cd5bf578626de6f9bbbc9f1cf(
    *,
    activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    cause: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    destination: typing.Optional[typing.Sequence[builtins.str]] = None,
    details: typing.Optional[typing.Union[EC2InstanceLaunchSuccessful.Details, typing.Dict[builtins.str, typing.Any]]] = None,
    ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    origin: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9e5933ea1bc828b45df064e8b7c23152959c3952ba276353f78633d95869f4b1(
    *,
    availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a3b61c2bf9160767b15d24c25658df273bb86257bebdccf957715fa66c2462d(
    *,
    activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    cause: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    destination: typing.Optional[typing.Sequence[builtins.str]] = None,
    details: typing.Optional[typing.Union[EC2InstanceLaunchUnsuccessful.Details, typing.Dict[builtins.str, typing.Any]]] = None,
    ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    origin: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9bd840d62bd9192729afdeb2803dba3a4db1d27064e470a890c0e08025d70bad(
    *,
    auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    destination: typing.Optional[typing.Sequence[builtins.str]] = None,
    ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    lifecycle_action_token: typing.Optional[typing.Sequence[builtins.str]] = None,
    lifecycle_hook_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    lifecycle_transition: typing.Optional[typing.Sequence[builtins.str]] = None,
    notification_metadata: typing.Optional[typing.Sequence[builtins.str]] = None,
    origin: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__59d186e8e33d58835c317ff8495dc077747ce0219eb08bd9f222cf968b9ea7fd(
    *,
    availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c8ab8a33a48e99a5101edc4fe429dc694080a9b0e4d0c8414ef449822cdfce2(
    *,
    activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    cause: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    destination: typing.Optional[typing.Sequence[builtins.str]] = None,
    details: typing.Optional[typing.Union[EC2InstanceTerminateSuccessful.Details, typing.Dict[builtins.str, typing.Any]]] = None,
    ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    origin: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0fbe9490358f3f6f2eb03d75c19d661c8bc9721f2fabf16ce70df3901e790cc8(
    *,
    availability_zone: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1f89ca7b8d413c8a498ab04585f624f552938f5d43d1f8595dad0996acb25211(
    *,
    activity_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    auto_scaling_group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    cause: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    destination: typing.Optional[typing.Sequence[builtins.str]] = None,
    details: typing.Optional[typing.Union[EC2InstanceTerminateUnsuccessful.Details, typing.Dict[builtins.str, typing.Any]]] = None,
    ec2_instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    origin: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
