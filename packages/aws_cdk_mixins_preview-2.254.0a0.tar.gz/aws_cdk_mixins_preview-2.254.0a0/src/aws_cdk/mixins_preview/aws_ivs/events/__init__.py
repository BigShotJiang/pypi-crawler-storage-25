from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class LimitBreach(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ivs.events.LimitBreach",
):
    '''(experimental) EventBridge event pattern for aws.ivs@LimitBreach.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ivs import events as ivs_events
        
        limit_breach = ivs_events.LimitBreach()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        exceeded_by: typing.Optional[typing.Sequence[builtins.str]] = None,
        limit: typing.Optional[typing.Sequence[builtins.str]] = None,
        limit_unit: typing.Optional[typing.Sequence[builtins.str]] = None,
        limit_value: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for IVS Limit Breach.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param exceeded_by: (experimental) exceeded_by property. Specify an array of string values to match this event if the actual value of exceeded_by is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param limit: (experimental) limit property. Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param limit_unit: (experimental) limit_unit property. Specify an array of string values to match this event if the actual value of limit_unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param limit_value: (experimental) limit_value property. Specify an array of string values to match this event if the actual value of limit_value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = LimitBreach.LimitBreachProps(
            event_metadata=event_metadata,
            exceeded_by=exceeded_by,
            limit=limit,
            limit_unit=limit_unit,
            limit_value=limit_value,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ivs.events.LimitBreach.LimitBreachProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "exceeded_by": "exceededBy",
            "limit": "limit",
            "limit_unit": "limitUnit",
            "limit_value": "limitValue",
        },
    )
    class LimitBreachProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            exceeded_by: typing.Optional[typing.Sequence[builtins.str]] = None,
            limit: typing.Optional[typing.Sequence[builtins.str]] = None,
            limit_unit: typing.Optional[typing.Sequence[builtins.str]] = None,
            limit_value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.ivs@LimitBreach event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param exceeded_by: (experimental) exceeded_by property. Specify an array of string values to match this event if the actual value of exceeded_by is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param limit: (experimental) limit property. Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param limit_unit: (experimental) limit_unit property. Specify an array of string values to match this event if the actual value of limit_unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param limit_value: (experimental) limit_value property. Specify an array of string values to match this event if the actual value of limit_value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ivs import events as ivs_events
                
                limit_breach_props = ivs_events.LimitBreach.LimitBreachProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    exceeded_by=["exceededBy"],
                    limit=["limit"],
                    limit_unit=["limitUnit"],
                    limit_value=["limitValue"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7b2f3c5a6a7e0e1333e4f2d5e33c9087c7da0bb9703ef31bbc2e348033c8ea39)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument exceeded_by", value=exceeded_by, expected_type=type_hints["exceeded_by"])
                check_type(argname="argument limit", value=limit, expected_type=type_hints["limit"])
                check_type(argname="argument limit_unit", value=limit_unit, expected_type=type_hints["limit_unit"])
                check_type(argname="argument limit_value", value=limit_value, expected_type=type_hints["limit_value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if exceeded_by is not None:
                self._values["exceeded_by"] = exceeded_by
            if limit is not None:
                self._values["limit"] = limit
            if limit_unit is not None:
                self._values["limit_unit"] = limit_unit
            if limit_value is not None:
                self._values["limit_value"] = limit_value

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def exceeded_by(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) exceeded_by property.

            Specify an array of string values to match this event if the actual value of exceeded_by is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("exceeded_by")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def limit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) limit property.

            Specify an array of string values to match this event if the actual value of limit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("limit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def limit_unit(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) limit_unit property.

            Specify an array of string values to match this event if the actual value of limit_unit is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("limit_unit")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def limit_value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) limit_value property.

            Specify an array of string values to match this event if the actual value of limit_value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("limit_value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "LimitBreachProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class RecordingStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ivs.events.RecordingStateChange",
):
    '''(experimental) EventBridge event pattern for aws.ivs@RecordingStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ivs import events as ivs_events
        
        recording_state_change = ivs_events.RecordingStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        recording_s3_bucket_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        recording_s3_key_prefix: typing.Optional[typing.Sequence[builtins.str]] = None,
        recording_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        recording_status_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
        stream_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for IVS Recording State Change.

        :param channel_name: (experimental) channel_name property. Specify an array of string values to match this event if the actual value of channel_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param recording_s3_bucket_name: (experimental) recording_s3_bucket_name property. Specify an array of string values to match this event if the actual value of recording_s3_bucket_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param recording_s3_key_prefix: (experimental) recording_s3_key_prefix property. Specify an array of string values to match this event if the actual value of recording_s3_key_prefix is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param recording_status: (experimental) recording_status property. Specify an array of string values to match this event if the actual value of recording_status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param recording_status_reason: (experimental) recording_status_reason property. Specify an array of string values to match this event if the actual value of recording_status_reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param stream_id: (experimental) stream_id property. Specify an array of string values to match this event if the actual value of stream_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = RecordingStateChange.RecordingStateChangeProps(
            channel_name=channel_name,
            event_metadata=event_metadata,
            recording_s3_bucket_name=recording_s3_bucket_name,
            recording_s3_key_prefix=recording_s3_key_prefix,
            recording_status=recording_status,
            recording_status_reason=recording_status_reason,
            stream_id=stream_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ivs.events.RecordingStateChange.RecordingStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "channel_name": "channelName",
            "event_metadata": "eventMetadata",
            "recording_s3_bucket_name": "recordingS3BucketName",
            "recording_s3_key_prefix": "recordingS3KeyPrefix",
            "recording_status": "recordingStatus",
            "recording_status_reason": "recordingStatusReason",
            "stream_id": "streamId",
        },
    )
    class RecordingStateChangeProps:
        def __init__(
            self,
            *,
            channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            recording_s3_bucket_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            recording_s3_key_prefix: typing.Optional[typing.Sequence[builtins.str]] = None,
            recording_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            recording_status_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
            stream_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.ivs@RecordingStateChange event.

            :param channel_name: (experimental) channel_name property. Specify an array of string values to match this event if the actual value of channel_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param recording_s3_bucket_name: (experimental) recording_s3_bucket_name property. Specify an array of string values to match this event if the actual value of recording_s3_bucket_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param recording_s3_key_prefix: (experimental) recording_s3_key_prefix property. Specify an array of string values to match this event if the actual value of recording_s3_key_prefix is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param recording_status: (experimental) recording_status property. Specify an array of string values to match this event if the actual value of recording_status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param recording_status_reason: (experimental) recording_status_reason property. Specify an array of string values to match this event if the actual value of recording_status_reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stream_id: (experimental) stream_id property. Specify an array of string values to match this event if the actual value of stream_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ivs import events as ivs_events
                
                recording_state_change_props = ivs_events.RecordingStateChange.RecordingStateChangeProps(
                    channel_name=["channelName"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    recording_s3_bucket_name=["recordingS3BucketName"],
                    recording_s3_key_prefix=["recordingS3KeyPrefix"],
                    recording_status=["recordingStatus"],
                    recording_status_reason=["recordingStatusReason"],
                    stream_id=["streamId"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__97f445ceaa4eaed90e78aacc6e2476de02ee8ac59f245ca1d715d9cec290560e)
                check_type(argname="argument channel_name", value=channel_name, expected_type=type_hints["channel_name"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument recording_s3_bucket_name", value=recording_s3_bucket_name, expected_type=type_hints["recording_s3_bucket_name"])
                check_type(argname="argument recording_s3_key_prefix", value=recording_s3_key_prefix, expected_type=type_hints["recording_s3_key_prefix"])
                check_type(argname="argument recording_status", value=recording_status, expected_type=type_hints["recording_status"])
                check_type(argname="argument recording_status_reason", value=recording_status_reason, expected_type=type_hints["recording_status_reason"])
                check_type(argname="argument stream_id", value=stream_id, expected_type=type_hints["stream_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if channel_name is not None:
                self._values["channel_name"] = channel_name
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if recording_s3_bucket_name is not None:
                self._values["recording_s3_bucket_name"] = recording_s3_bucket_name
            if recording_s3_key_prefix is not None:
                self._values["recording_s3_key_prefix"] = recording_s3_key_prefix
            if recording_status is not None:
                self._values["recording_status"] = recording_status
            if recording_status_reason is not None:
                self._values["recording_status_reason"] = recording_status_reason
            if stream_id is not None:
                self._values["stream_id"] = stream_id

        @builtins.property
        def channel_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) channel_name property.

            Specify an array of string values to match this event if the actual value of channel_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("channel_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def recording_s3_bucket_name(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) recording_s3_bucket_name property.

            Specify an array of string values to match this event if the actual value of recording_s3_bucket_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("recording_s3_bucket_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def recording_s3_key_prefix(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) recording_s3_key_prefix property.

            Specify an array of string values to match this event if the actual value of recording_s3_key_prefix is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("recording_s3_key_prefix")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def recording_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) recording_status property.

            Specify an array of string values to match this event if the actual value of recording_status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("recording_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def recording_status_reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) recording_status_reason property.

            Specify an array of string values to match this event if the actual value of recording_status_reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("recording_status_reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stream_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stream_id property.

            Specify an array of string values to match this event if the actual value of stream_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stream_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RecordingStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class StreamHealthChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ivs.events.StreamHealthChange",
):
    '''(experimental) EventBridge event pattern for aws.ivs@StreamHealthChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ivs import events as ivs_events
        
        stream_health_change = ivs_events.StreamHealthChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        stream_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for IVS Stream Health Change.

        :param channel_name: (experimental) channel_name property. Specify an array of string values to match this event if the actual value of channel_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_name: (experimental) event_name property. Specify an array of string values to match this event if the actual value of event_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param stream_id: (experimental) stream_id property. Specify an array of string values to match this event if the actual value of stream_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = StreamHealthChange.StreamHealthChangeProps(
            channel_name=channel_name,
            event_metadata=event_metadata,
            event_name=event_name,
            stream_id=stream_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ivs.events.StreamHealthChange.StreamHealthChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "channel_name": "channelName",
            "event_metadata": "eventMetadata",
            "event_name": "eventName",
            "stream_id": "streamId",
        },
    )
    class StreamHealthChangeProps:
        def __init__(
            self,
            *,
            channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            stream_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.ivs@StreamHealthChange event.

            :param channel_name: (experimental) channel_name property. Specify an array of string values to match this event if the actual value of channel_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param event_name: (experimental) event_name property. Specify an array of string values to match this event if the actual value of event_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stream_id: (experimental) stream_id property. Specify an array of string values to match this event if the actual value of stream_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ivs import events as ivs_events
                
                stream_health_change_props = ivs_events.StreamHealthChange.StreamHealthChangeProps(
                    channel_name=["channelName"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    event_name=["eventName"],
                    stream_id=["streamId"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__967a2cc0764986475318dd843a2eb7ff995aadd82b25a2cef6fa9784b56ebe08)
                check_type(argname="argument channel_name", value=channel_name, expected_type=type_hints["channel_name"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument event_name", value=event_name, expected_type=type_hints["event_name"])
                check_type(argname="argument stream_id", value=stream_id, expected_type=type_hints["stream_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if channel_name is not None:
                self._values["channel_name"] = channel_name
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if event_name is not None:
                self._values["event_name"] = event_name
            if stream_id is not None:
                self._values["stream_id"] = stream_id

        @builtins.property
        def channel_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) channel_name property.

            Specify an array of string values to match this event if the actual value of channel_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("channel_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def event_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) event_name property.

            Specify an array of string values to match this event if the actual value of event_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stream_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stream_id property.

            Specify an array of string values to match this event if the actual value of stream_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stream_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "StreamHealthChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class StreamStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ivs.events.StreamStateChange",
):
    '''(experimental) EventBridge event pattern for aws.ivs@StreamStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ivs import events as ivs_events
        
        stream_state_change = ivs_events.StreamStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        stream_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for IVS Stream State Change.

        :param channel_name: (experimental) channel_name property. Specify an array of string values to match this event if the actual value of channel_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_name: (experimental) event_name property. Specify an array of string values to match this event if the actual value of event_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param stream_id: (experimental) stream_id property. Specify an array of string values to match this event if the actual value of stream_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = StreamStateChange.StreamStateChangeProps(
            channel_name=channel_name,
            event_metadata=event_metadata,
            event_name=event_name,
            stream_id=stream_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_ivs.events.StreamStateChange.StreamStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "channel_name": "channelName",
            "event_metadata": "eventMetadata",
            "event_name": "eventName",
            "stream_id": "streamId",
        },
    )
    class StreamStateChangeProps:
        def __init__(
            self,
            *,
            channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            stream_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.ivs@StreamStateChange event.

            :param channel_name: (experimental) channel_name property. Specify an array of string values to match this event if the actual value of channel_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param event_name: (experimental) event_name property. Specify an array of string values to match this event if the actual value of event_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stream_id: (experimental) stream_id property. Specify an array of string values to match this event if the actual value of stream_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_ivs import events as ivs_events
                
                stream_state_change_props = ivs_events.StreamStateChange.StreamStateChangeProps(
                    channel_name=["channelName"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    event_name=["eventName"],
                    stream_id=["streamId"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b45cbac734b3b35987968d6b6811dfd4f4958de6deca2392da639b32d9d349eb)
                check_type(argname="argument channel_name", value=channel_name, expected_type=type_hints["channel_name"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument event_name", value=event_name, expected_type=type_hints["event_name"])
                check_type(argname="argument stream_id", value=stream_id, expected_type=type_hints["stream_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if channel_name is not None:
                self._values["channel_name"] = channel_name
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if event_name is not None:
                self._values["event_name"] = event_name
            if stream_id is not None:
                self._values["stream_id"] = stream_id

        @builtins.property
        def channel_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) channel_name property.

            Specify an array of string values to match this event if the actual value of channel_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("channel_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def event_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) event_name property.

            Specify an array of string values to match this event if the actual value of event_name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stream_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stream_id property.

            Specify an array of string values to match this event if the actual value of stream_id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stream_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "StreamStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "LimitBreach",
    "RecordingStateChange",
    "StreamHealthChange",
    "StreamStateChange",
]

publication.publish()

def _typecheckingstub__7b2f3c5a6a7e0e1333e4f2d5e33c9087c7da0bb9703ef31bbc2e348033c8ea39(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    exceeded_by: typing.Optional[typing.Sequence[builtins.str]] = None,
    limit: typing.Optional[typing.Sequence[builtins.str]] = None,
    limit_unit: typing.Optional[typing.Sequence[builtins.str]] = None,
    limit_value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97f445ceaa4eaed90e78aacc6e2476de02ee8ac59f245ca1d715d9cec290560e(
    *,
    channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    recording_s3_bucket_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    recording_s3_key_prefix: typing.Optional[typing.Sequence[builtins.str]] = None,
    recording_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    recording_status_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    stream_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__967a2cc0764986475318dd843a2eb7ff995aadd82b25a2cef6fa9784b56ebe08(
    *,
    channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    stream_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b45cbac734b3b35987968d6b6811dfd4f4958de6deca2392da639b32d9d349eb(
    *,
    channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    stream_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
