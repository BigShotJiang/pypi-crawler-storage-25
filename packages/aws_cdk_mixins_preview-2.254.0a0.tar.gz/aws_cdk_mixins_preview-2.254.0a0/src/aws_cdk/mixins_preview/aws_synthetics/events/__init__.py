from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class SyntheticsCanaryStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_synthetics.events.SyntheticsCanaryStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.synthetics@SyntheticsCanaryStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_synthetics import events as synthetics_events
        
        synthetics_canary_status_change = synthetics_events.SyntheticsCanaryStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        canary_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        canary_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        changed_config: typing.Optional[typing.Union["SyntheticsCanaryStatusChange.ChangedConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        current_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        previous_state: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_location: typing.Optional[typing.Sequence[builtins.str]] = None,
        updated_on: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Synthetics Canary Status Change.

        :param account_id: (experimental) account-id property. Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param canary_id: (experimental) canary-id property. Specify an array of string values to match this event if the actual value of canary-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param canary_name: (experimental) canary-name property. Specify an array of string values to match this event if the actual value of canary-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param changed_config: (experimental) changed-config property. Specify an array of string values to match this event if the actual value of changed-config is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param current_state: (experimental) current-state property. Specify an array of string values to match this event if the actual value of current-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param previous_state: (experimental) previous-state property. Specify an array of string values to match this event if the actual value of previous-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_location: (experimental) source-location property. Specify an array of string values to match this event if the actual value of source-location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param updated_on: (experimental) updated-on property. Specify an array of string values to match this event if the actual value of updated-on is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SyntheticsCanaryStatusChange.SyntheticsCanaryStatusChangeProps(
            account_id=account_id,
            canary_id=canary_id,
            canary_name=canary_name,
            changed_config=changed_config,
            current_state=current_state,
            event_metadata=event_metadata,
            message=message,
            previous_state=previous_state,
            source_location=source_location,
            updated_on=updated_on,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_synthetics.events.SyntheticsCanaryStatusChange.ChangedConfig",
        jsii_struct_bases=[],
        name_mapping={
            "execution_arn": "executionArn",
            "test_code_layer_version_arn": "testCodeLayerVersionArn",
        },
    )
    class ChangedConfig:
        def __init__(
            self,
            *,
            execution_arn: typing.Optional[typing.Union["SyntheticsCanaryStatusChange.ExecutionArn", typing.Dict[builtins.str, typing.Any]]] = None,
            test_code_layer_version_arn: typing.Optional[typing.Union["SyntheticsCanaryStatusChange.TestCodeLayerVersionArn", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for Changed-config.

            :param execution_arn: (experimental) executionArn property. Specify an array of string values to match this event if the actual value of executionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param test_code_layer_version_arn: (experimental) testCodeLayerVersionArn property. Specify an array of string values to match this event if the actual value of testCodeLayerVersionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_synthetics import events as synthetics_events
                
                changed_config = synthetics_events.SyntheticsCanaryStatusChange.ChangedConfig(
                    execution_arn=synthetics_events.SyntheticsCanaryStatusChange.ExecutionArn(
                        current_value=["currentValue"],
                        previous_value=["previousValue"]
                    ),
                    test_code_layer_version_arn=synthetics_events.SyntheticsCanaryStatusChange.TestCodeLayerVersionArn(
                        current_value=["currentValue"],
                        previous_value=["previousValue"]
                    )
                )
            '''
            if isinstance(execution_arn, dict):
                execution_arn = SyntheticsCanaryStatusChange.ExecutionArn(**execution_arn)
            if isinstance(test_code_layer_version_arn, dict):
                test_code_layer_version_arn = SyntheticsCanaryStatusChange.TestCodeLayerVersionArn(**test_code_layer_version_arn)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__12382bc266587d8fa49e87c1aad673895d02c816ab93877c6d2f5a3cac31334c)
                check_type(argname="argument execution_arn", value=execution_arn, expected_type=type_hints["execution_arn"])
                check_type(argname="argument test_code_layer_version_arn", value=test_code_layer_version_arn, expected_type=type_hints["test_code_layer_version_arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if execution_arn is not None:
                self._values["execution_arn"] = execution_arn
            if test_code_layer_version_arn is not None:
                self._values["test_code_layer_version_arn"] = test_code_layer_version_arn

        @builtins.property
        def execution_arn(
            self,
        ) -> typing.Optional["SyntheticsCanaryStatusChange.ExecutionArn"]:
            '''(experimental) executionArn property.

            Specify an array of string values to match this event if the actual value of executionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("execution_arn")
            return typing.cast(typing.Optional["SyntheticsCanaryStatusChange.ExecutionArn"], result)

        @builtins.property
        def test_code_layer_version_arn(
            self,
        ) -> typing.Optional["SyntheticsCanaryStatusChange.TestCodeLayerVersionArn"]:
            '''(experimental) testCodeLayerVersionArn property.

            Specify an array of string values to match this event if the actual value of testCodeLayerVersionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("test_code_layer_version_arn")
            return typing.cast(typing.Optional["SyntheticsCanaryStatusChange.TestCodeLayerVersionArn"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ChangedConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_synthetics.events.SyntheticsCanaryStatusChange.ExecutionArn",
        jsii_struct_bases=[],
        name_mapping={
            "current_value": "currentValue",
            "previous_value": "previousValue",
        },
    )
    class ExecutionArn:
        def __init__(
            self,
            *,
            current_value: typing.Optional[typing.Sequence[builtins.str]] = None,
            previous_value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ExecutionArn.

            :param current_value: (experimental) current-value property. Specify an array of string values to match this event if the actual value of current-value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param previous_value: (experimental) previous-value property. Specify an array of string values to match this event if the actual value of previous-value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_synthetics import events as synthetics_events
                
                execution_arn = synthetics_events.SyntheticsCanaryStatusChange.ExecutionArn(
                    current_value=["currentValue"],
                    previous_value=["previousValue"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__054c564fbbd91100b39dae2388bbc8d7393a1396912a733c06095384d6ac8748)
                check_type(argname="argument current_value", value=current_value, expected_type=type_hints["current_value"])
                check_type(argname="argument previous_value", value=previous_value, expected_type=type_hints["previous_value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if current_value is not None:
                self._values["current_value"] = current_value
            if previous_value is not None:
                self._values["previous_value"] = previous_value

        @builtins.property
        def current_value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) current-value property.

            Specify an array of string values to match this event if the actual value of current-value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def previous_value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) previous-value property.

            Specify an array of string values to match this event if the actual value of previous-value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("previous_value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ExecutionArn(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_synthetics.events.SyntheticsCanaryStatusChange.SyntheticsCanaryStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "canary_id": "canaryId",
            "canary_name": "canaryName",
            "changed_config": "changedConfig",
            "current_state": "currentState",
            "event_metadata": "eventMetadata",
            "message": "message",
            "previous_state": "previousState",
            "source_location": "sourceLocation",
            "updated_on": "updatedOn",
        },
    )
    class SyntheticsCanaryStatusChangeProps:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            canary_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            canary_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            changed_config: typing.Optional[typing.Union["SyntheticsCanaryStatusChange.ChangedConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            current_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            previous_state: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_location: typing.Optional[typing.Sequence[builtins.str]] = None,
            updated_on: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.synthetics@SyntheticsCanaryStatusChange event.

            :param account_id: (experimental) account-id property. Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param canary_id: (experimental) canary-id property. Specify an array of string values to match this event if the actual value of canary-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param canary_name: (experimental) canary-name property. Specify an array of string values to match this event if the actual value of canary-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param changed_config: (experimental) changed-config property. Specify an array of string values to match this event if the actual value of changed-config is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param current_state: (experimental) current-state property. Specify an array of string values to match this event if the actual value of current-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param previous_state: (experimental) previous-state property. Specify an array of string values to match this event if the actual value of previous-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_location: (experimental) source-location property. Specify an array of string values to match this event if the actual value of source-location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param updated_on: (experimental) updated-on property. Specify an array of string values to match this event if the actual value of updated-on is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_synthetics import events as synthetics_events
                
                synthetics_canary_status_change_props = synthetics_events.SyntheticsCanaryStatusChange.SyntheticsCanaryStatusChangeProps(
                    account_id=["accountId"],
                    canary_id=["canaryId"],
                    canary_name=["canaryName"],
                    changed_config=synthetics_events.SyntheticsCanaryStatusChange.ChangedConfig(
                        execution_arn=synthetics_events.SyntheticsCanaryStatusChange.ExecutionArn(
                            current_value=["currentValue"],
                            previous_value=["previousValue"]
                        ),
                        test_code_layer_version_arn=synthetics_events.SyntheticsCanaryStatusChange.TestCodeLayerVersionArn(
                            current_value=["currentValue"],
                            previous_value=["previousValue"]
                        )
                    ),
                    current_state=["currentState"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    previous_state=["previousState"],
                    source_location=["sourceLocation"],
                    updated_on=["updatedOn"]
                )
            '''
            if isinstance(changed_config, dict):
                changed_config = SyntheticsCanaryStatusChange.ChangedConfig(**changed_config)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__3c69177154a127666c9dd1b47933eb4815e45957f1743a082eb866c0d3bdd13b)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument canary_id", value=canary_id, expected_type=type_hints["canary_id"])
                check_type(argname="argument canary_name", value=canary_name, expected_type=type_hints["canary_name"])
                check_type(argname="argument changed_config", value=changed_config, expected_type=type_hints["changed_config"])
                check_type(argname="argument current_state", value=current_state, expected_type=type_hints["current_state"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument previous_state", value=previous_state, expected_type=type_hints["previous_state"])
                check_type(argname="argument source_location", value=source_location, expected_type=type_hints["source_location"])
                check_type(argname="argument updated_on", value=updated_on, expected_type=type_hints["updated_on"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if canary_id is not None:
                self._values["canary_id"] = canary_id
            if canary_name is not None:
                self._values["canary_name"] = canary_name
            if changed_config is not None:
                self._values["changed_config"] = changed_config
            if current_state is not None:
                self._values["current_state"] = current_state
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if previous_state is not None:
                self._values["previous_state"] = previous_state
            if source_location is not None:
                self._values["source_location"] = source_location
            if updated_on is not None:
                self._values["updated_on"] = updated_on

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) account-id property.

            Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def canary_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) canary-id property.

            Specify an array of string values to match this event if the actual value of canary-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("canary_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def canary_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) canary-name property.

            Specify an array of string values to match this event if the actual value of canary-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("canary_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def changed_config(
            self,
        ) -> typing.Optional["SyntheticsCanaryStatusChange.ChangedConfig"]:
            '''(experimental) changed-config property.

            Specify an array of string values to match this event if the actual value of changed-config is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("changed_config")
            return typing.cast(typing.Optional["SyntheticsCanaryStatusChange.ChangedConfig"], result)

        @builtins.property
        def current_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) current-state property.

            Specify an array of string values to match this event if the actual value of current-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def previous_state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) previous-state property.

            Specify an array of string values to match this event if the actual value of previous-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("previous_state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) source-location property.

            Specify an array of string values to match this event if the actual value of source-location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def updated_on(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) updated-on property.

            Specify an array of string values to match this event if the actual value of updated-on is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("updated_on")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SyntheticsCanaryStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_synthetics.events.SyntheticsCanaryStatusChange.TestCodeLayerVersionArn",
        jsii_struct_bases=[],
        name_mapping={
            "current_value": "currentValue",
            "previous_value": "previousValue",
        },
    )
    class TestCodeLayerVersionArn:
        def __init__(
            self,
            *,
            current_value: typing.Optional[typing.Sequence[builtins.str]] = None,
            previous_value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for TestCodeLayerVersionArn.

            :param current_value: (experimental) current-value property. Specify an array of string values to match this event if the actual value of current-value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param previous_value: (experimental) previous-value property. Specify an array of string values to match this event if the actual value of previous-value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_synthetics import events as synthetics_events
                
                test_code_layer_version_arn = synthetics_events.SyntheticsCanaryStatusChange.TestCodeLayerVersionArn(
                    current_value=["currentValue"],
                    previous_value=["previousValue"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__03848c5249706eb12353da17c6c9a04a1aa128ae7064e7631d29cbd37401b6b9)
                check_type(argname="argument current_value", value=current_value, expected_type=type_hints["current_value"])
                check_type(argname="argument previous_value", value=previous_value, expected_type=type_hints["previous_value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if current_value is not None:
                self._values["current_value"] = current_value
            if previous_value is not None:
                self._values["previous_value"] = previous_value

        @builtins.property
        def current_value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) current-value property.

            Specify an array of string values to match this event if the actual value of current-value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def previous_value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) previous-value property.

            Specify an array of string values to match this event if the actual value of previous-value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("previous_value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TestCodeLayerVersionArn(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SyntheticsCanaryTestRunFailure(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_synthetics.events.SyntheticsCanaryTestRunFailure",
):
    '''(experimental) EventBridge event pattern for aws.synthetics@SyntheticsCanaryTestRunFailure.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_synthetics import events as synthetics_events
        
        synthetics_canary_test_run_failure = synthetics_events.SyntheticsCanaryTestRunFailure()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        artifact_location: typing.Optional[typing.Sequence[builtins.str]] = None,
        canary_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        canary_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        canary_run_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        canary_run_timeline: typing.Optional[typing.Union["SyntheticsCanaryTestRunFailure.CanaryRunTimeline", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        state_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
        test_run_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Synthetics Canary TestRun Failure.

        :param account_id: (experimental) account-id property. Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param artifact_location: (experimental) artifact-location property. Specify an array of string values to match this event if the actual value of artifact-location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param canary_id: (experimental) canary-id property. Specify an array of string values to match this event if the actual value of canary-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param canary_name: (experimental) canary-name property. Specify an array of string values to match this event if the actual value of canary-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param canary_run_id: (experimental) canary-run-id property. Specify an array of string values to match this event if the actual value of canary-run-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param canary_run_timeline: (experimental) canary-run-timeline property. Specify an array of string values to match this event if the actual value of canary-run-timeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state_reason: (experimental) state-reason property. Specify an array of string values to match this event if the actual value of state-reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param test_run_status: (experimental) test-run-status property. Specify an array of string values to match this event if the actual value of test-run-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SyntheticsCanaryTestRunFailure.SyntheticsCanaryTestRunFailureProps(
            account_id=account_id,
            artifact_location=artifact_location,
            canary_id=canary_id,
            canary_name=canary_name,
            canary_run_id=canary_run_id,
            canary_run_timeline=canary_run_timeline,
            event_metadata=event_metadata,
            message=message,
            state_reason=state_reason,
            test_run_status=test_run_status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_synthetics.events.SyntheticsCanaryTestRunFailure.CanaryRunTimeline",
        jsii_struct_bases=[],
        name_mapping={"completed": "completed", "started": "started"},
    )
    class CanaryRunTimeline:
        def __init__(
            self,
            *,
            completed: typing.Optional[typing.Sequence[builtins.str]] = None,
            started: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Canary-run-timeline.

            :param completed: (experimental) completed property. Specify an array of string values to match this event if the actual value of completed is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param started: (experimental) started property. Specify an array of string values to match this event if the actual value of started is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_synthetics import events as synthetics_events
                
                canary_run_timeline = synthetics_events.SyntheticsCanaryTestRunFailure.CanaryRunTimeline(
                    completed=["completed"],
                    started=["started"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__36faa1f4ef40bc8f128624b451d8bf725e6d7684f0a20baee26e145ff9be3d80)
                check_type(argname="argument completed", value=completed, expected_type=type_hints["completed"])
                check_type(argname="argument started", value=started, expected_type=type_hints["started"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if completed is not None:
                self._values["completed"] = completed
            if started is not None:
                self._values["started"] = started

        @builtins.property
        def completed(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) completed property.

            Specify an array of string values to match this event if the actual value of completed is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("completed")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def started(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) started property.

            Specify an array of string values to match this event if the actual value of started is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("started")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CanaryRunTimeline(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_synthetics.events.SyntheticsCanaryTestRunFailure.SyntheticsCanaryTestRunFailureProps",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "artifact_location": "artifactLocation",
            "canary_id": "canaryId",
            "canary_name": "canaryName",
            "canary_run_id": "canaryRunId",
            "canary_run_timeline": "canaryRunTimeline",
            "event_metadata": "eventMetadata",
            "message": "message",
            "state_reason": "stateReason",
            "test_run_status": "testRunStatus",
        },
    )
    class SyntheticsCanaryTestRunFailureProps:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            artifact_location: typing.Optional[typing.Sequence[builtins.str]] = None,
            canary_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            canary_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            canary_run_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            canary_run_timeline: typing.Optional[typing.Union["SyntheticsCanaryTestRunFailure.CanaryRunTimeline", typing.Dict[builtins.str, typing.Any]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            state_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
            test_run_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.synthetics@SyntheticsCanaryTestRunFailure event.

            :param account_id: (experimental) account-id property. Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param artifact_location: (experimental) artifact-location property. Specify an array of string values to match this event if the actual value of artifact-location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param canary_id: (experimental) canary-id property. Specify an array of string values to match this event if the actual value of canary-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param canary_name: (experimental) canary-name property. Specify an array of string values to match this event if the actual value of canary-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param canary_run_id: (experimental) canary-run-id property. Specify an array of string values to match this event if the actual value of canary-run-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param canary_run_timeline: (experimental) canary-run-timeline property. Specify an array of string values to match this event if the actual value of canary-run-timeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state_reason: (experimental) state-reason property. Specify an array of string values to match this event if the actual value of state-reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param test_run_status: (experimental) test-run-status property. Specify an array of string values to match this event if the actual value of test-run-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_synthetics import events as synthetics_events
                
                synthetics_canary_test_run_failure_props = synthetics_events.SyntheticsCanaryTestRunFailure.SyntheticsCanaryTestRunFailureProps(
                    account_id=["accountId"],
                    artifact_location=["artifactLocation"],
                    canary_id=["canaryId"],
                    canary_name=["canaryName"],
                    canary_run_id=["canaryRunId"],
                    canary_run_timeline=synthetics_events.SyntheticsCanaryTestRunFailure.CanaryRunTimeline(
                        completed=["completed"],
                        started=["started"]
                    ),
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    state_reason=["stateReason"],
                    test_run_status=["testRunStatus"]
                )
            '''
            if isinstance(canary_run_timeline, dict):
                canary_run_timeline = SyntheticsCanaryTestRunFailure.CanaryRunTimeline(**canary_run_timeline)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0027197ce6ef71e159b8a8d33fdde75441514fdeeda934b6af3e4cfebbab29cd)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument artifact_location", value=artifact_location, expected_type=type_hints["artifact_location"])
                check_type(argname="argument canary_id", value=canary_id, expected_type=type_hints["canary_id"])
                check_type(argname="argument canary_name", value=canary_name, expected_type=type_hints["canary_name"])
                check_type(argname="argument canary_run_id", value=canary_run_id, expected_type=type_hints["canary_run_id"])
                check_type(argname="argument canary_run_timeline", value=canary_run_timeline, expected_type=type_hints["canary_run_timeline"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument state_reason", value=state_reason, expected_type=type_hints["state_reason"])
                check_type(argname="argument test_run_status", value=test_run_status, expected_type=type_hints["test_run_status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if artifact_location is not None:
                self._values["artifact_location"] = artifact_location
            if canary_id is not None:
                self._values["canary_id"] = canary_id
            if canary_name is not None:
                self._values["canary_name"] = canary_name
            if canary_run_id is not None:
                self._values["canary_run_id"] = canary_run_id
            if canary_run_timeline is not None:
                self._values["canary_run_timeline"] = canary_run_timeline
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if state_reason is not None:
                self._values["state_reason"] = state_reason
            if test_run_status is not None:
                self._values["test_run_status"] = test_run_status

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) account-id property.

            Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def artifact_location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) artifact-location property.

            Specify an array of string values to match this event if the actual value of artifact-location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("artifact_location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def canary_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) canary-id property.

            Specify an array of string values to match this event if the actual value of canary-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("canary_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def canary_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) canary-name property.

            Specify an array of string values to match this event if the actual value of canary-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("canary_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def canary_run_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) canary-run-id property.

            Specify an array of string values to match this event if the actual value of canary-run-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("canary_run_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def canary_run_timeline(
            self,
        ) -> typing.Optional["SyntheticsCanaryTestRunFailure.CanaryRunTimeline"]:
            '''(experimental) canary-run-timeline property.

            Specify an array of string values to match this event if the actual value of canary-run-timeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("canary_run_timeline")
            return typing.cast(typing.Optional["SyntheticsCanaryTestRunFailure.CanaryRunTimeline"], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state_reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state-reason property.

            Specify an array of string values to match this event if the actual value of state-reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state_reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def test_run_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) test-run-status property.

            Specify an array of string values to match this event if the actual value of test-run-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("test_run_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SyntheticsCanaryTestRunFailureProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SyntheticsCanaryTestRunSuccessful(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_synthetics.events.SyntheticsCanaryTestRunSuccessful",
):
    '''(experimental) EventBridge event pattern for aws.synthetics@SyntheticsCanaryTestRunSuccessful.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_synthetics import events as synthetics_events
        
        synthetics_canary_test_run_successful = synthetics_events.SyntheticsCanaryTestRunSuccessful()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        artifact_location: typing.Optional[typing.Sequence[builtins.str]] = None,
        canary_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        canary_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        canary_run_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        canary_run_timeline: typing.Optional[typing.Union["SyntheticsCanaryTestRunSuccessful.CanaryRunTimeline", typing.Dict[builtins.str, typing.Any]]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        state_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
        test_run_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Synthetics Canary TestRun Successful.

        :param account_id: (experimental) account-id property. Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param artifact_location: (experimental) artifact-location property. Specify an array of string values to match this event if the actual value of artifact-location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param canary_id: (experimental) canary-id property. Specify an array of string values to match this event if the actual value of canary-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param canary_name: (experimental) canary-name property. Specify an array of string values to match this event if the actual value of canary-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param canary_run_id: (experimental) canary-run-id property. Specify an array of string values to match this event if the actual value of canary-run-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param canary_run_timeline: (experimental) canary-run-timeline property. Specify an array of string values to match this event if the actual value of canary-run-timeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state_reason: (experimental) state-reason property. Specify an array of string values to match this event if the actual value of state-reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param test_run_status: (experimental) test-run-status property. Specify an array of string values to match this event if the actual value of test-run-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SyntheticsCanaryTestRunSuccessful.SyntheticsCanaryTestRunSuccessfulProps(
            account_id=account_id,
            artifact_location=artifact_location,
            canary_id=canary_id,
            canary_name=canary_name,
            canary_run_id=canary_run_id,
            canary_run_timeline=canary_run_timeline,
            event_metadata=event_metadata,
            message=message,
            state_reason=state_reason,
            test_run_status=test_run_status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_synthetics.events.SyntheticsCanaryTestRunSuccessful.CanaryRunTimeline",
        jsii_struct_bases=[],
        name_mapping={"completed": "completed", "started": "started"},
    )
    class CanaryRunTimeline:
        def __init__(
            self,
            *,
            completed: typing.Optional[typing.Sequence[builtins.str]] = None,
            started: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Canary-run-timeline.

            :param completed: (experimental) completed property. Specify an array of string values to match this event if the actual value of completed is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param started: (experimental) started property. Specify an array of string values to match this event if the actual value of started is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_synthetics import events as synthetics_events
                
                canary_run_timeline = synthetics_events.SyntheticsCanaryTestRunSuccessful.CanaryRunTimeline(
                    completed=["completed"],
                    started=["started"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1d882b823719739cf8961367c9f6b649b8606228f97fa58fd3807a52d79fda39)
                check_type(argname="argument completed", value=completed, expected_type=type_hints["completed"])
                check_type(argname="argument started", value=started, expected_type=type_hints["started"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if completed is not None:
                self._values["completed"] = completed
            if started is not None:
                self._values["started"] = started

        @builtins.property
        def completed(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) completed property.

            Specify an array of string values to match this event if the actual value of completed is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("completed")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def started(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) started property.

            Specify an array of string values to match this event if the actual value of started is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("started")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CanaryRunTimeline(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_synthetics.events.SyntheticsCanaryTestRunSuccessful.SyntheticsCanaryTestRunSuccessfulProps",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "artifact_location": "artifactLocation",
            "canary_id": "canaryId",
            "canary_name": "canaryName",
            "canary_run_id": "canaryRunId",
            "canary_run_timeline": "canaryRunTimeline",
            "event_metadata": "eventMetadata",
            "message": "message",
            "state_reason": "stateReason",
            "test_run_status": "testRunStatus",
        },
    )
    class SyntheticsCanaryTestRunSuccessfulProps:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            artifact_location: typing.Optional[typing.Sequence[builtins.str]] = None,
            canary_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            canary_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            canary_run_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            canary_run_timeline: typing.Optional[typing.Union["SyntheticsCanaryTestRunSuccessful.CanaryRunTimeline", typing.Dict[builtins.str, typing.Any]]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            state_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
            test_run_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.synthetics@SyntheticsCanaryTestRunSuccessful event.

            :param account_id: (experimental) account-id property. Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param artifact_location: (experimental) artifact-location property. Specify an array of string values to match this event if the actual value of artifact-location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param canary_id: (experimental) canary-id property. Specify an array of string values to match this event if the actual value of canary-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param canary_name: (experimental) canary-name property. Specify an array of string values to match this event if the actual value of canary-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param canary_run_id: (experimental) canary-run-id property. Specify an array of string values to match this event if the actual value of canary-run-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param canary_run_timeline: (experimental) canary-run-timeline property. Specify an array of string values to match this event if the actual value of canary-run-timeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state_reason: (experimental) state-reason property. Specify an array of string values to match this event if the actual value of state-reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param test_run_status: (experimental) test-run-status property. Specify an array of string values to match this event if the actual value of test-run-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_synthetics import events as synthetics_events
                
                synthetics_canary_test_run_successful_props = synthetics_events.SyntheticsCanaryTestRunSuccessful.SyntheticsCanaryTestRunSuccessfulProps(
                    account_id=["accountId"],
                    artifact_location=["artifactLocation"],
                    canary_id=["canaryId"],
                    canary_name=["canaryName"],
                    canary_run_id=["canaryRunId"],
                    canary_run_timeline=synthetics_events.SyntheticsCanaryTestRunSuccessful.CanaryRunTimeline(
                        completed=["completed"],
                        started=["started"]
                    ),
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    state_reason=["stateReason"],
                    test_run_status=["testRunStatus"]
                )
            '''
            if isinstance(canary_run_timeline, dict):
                canary_run_timeline = SyntheticsCanaryTestRunSuccessful.CanaryRunTimeline(**canary_run_timeline)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4dbb1ec8bea8c1ba59db6e15ceaae2345acebd12feed3d8ec46f7b2a3894df70)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument artifact_location", value=artifact_location, expected_type=type_hints["artifact_location"])
                check_type(argname="argument canary_id", value=canary_id, expected_type=type_hints["canary_id"])
                check_type(argname="argument canary_name", value=canary_name, expected_type=type_hints["canary_name"])
                check_type(argname="argument canary_run_id", value=canary_run_id, expected_type=type_hints["canary_run_id"])
                check_type(argname="argument canary_run_timeline", value=canary_run_timeline, expected_type=type_hints["canary_run_timeline"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument state_reason", value=state_reason, expected_type=type_hints["state_reason"])
                check_type(argname="argument test_run_status", value=test_run_status, expected_type=type_hints["test_run_status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if artifact_location is not None:
                self._values["artifact_location"] = artifact_location
            if canary_id is not None:
                self._values["canary_id"] = canary_id
            if canary_name is not None:
                self._values["canary_name"] = canary_name
            if canary_run_id is not None:
                self._values["canary_run_id"] = canary_run_id
            if canary_run_timeline is not None:
                self._values["canary_run_timeline"] = canary_run_timeline
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if state_reason is not None:
                self._values["state_reason"] = state_reason
            if test_run_status is not None:
                self._values["test_run_status"] = test_run_status

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) account-id property.

            Specify an array of string values to match this event if the actual value of account-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def artifact_location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) artifact-location property.

            Specify an array of string values to match this event if the actual value of artifact-location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("artifact_location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def canary_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) canary-id property.

            Specify an array of string values to match this event if the actual value of canary-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("canary_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def canary_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) canary-name property.

            Specify an array of string values to match this event if the actual value of canary-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("canary_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def canary_run_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) canary-run-id property.

            Specify an array of string values to match this event if the actual value of canary-run-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("canary_run_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def canary_run_timeline(
            self,
        ) -> typing.Optional["SyntheticsCanaryTestRunSuccessful.CanaryRunTimeline"]:
            '''(experimental) canary-run-timeline property.

            Specify an array of string values to match this event if the actual value of canary-run-timeline is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("canary_run_timeline")
            return typing.cast(typing.Optional["SyntheticsCanaryTestRunSuccessful.CanaryRunTimeline"], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state_reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state-reason property.

            Specify an array of string values to match this event if the actual value of state-reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state_reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def test_run_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) test-run-status property.

            Specify an array of string values to match this event if the actual value of test-run-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("test_run_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SyntheticsCanaryTestRunSuccessfulProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "SyntheticsCanaryStatusChange",
    "SyntheticsCanaryTestRunFailure",
    "SyntheticsCanaryTestRunSuccessful",
]

publication.publish()

def _typecheckingstub__12382bc266587d8fa49e87c1aad673895d02c816ab93877c6d2f5a3cac31334c(
    *,
    execution_arn: typing.Optional[typing.Union[SyntheticsCanaryStatusChange.ExecutionArn, typing.Dict[builtins.str, typing.Any]]] = None,
    test_code_layer_version_arn: typing.Optional[typing.Union[SyntheticsCanaryStatusChange.TestCodeLayerVersionArn, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__054c564fbbd91100b39dae2388bbc8d7393a1396912a733c06095384d6ac8748(
    *,
    current_value: typing.Optional[typing.Sequence[builtins.str]] = None,
    previous_value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3c69177154a127666c9dd1b47933eb4815e45957f1743a082eb866c0d3bdd13b(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    canary_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    canary_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    changed_config: typing.Optional[typing.Union[SyntheticsCanaryStatusChange.ChangedConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    current_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    previous_state: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_location: typing.Optional[typing.Sequence[builtins.str]] = None,
    updated_on: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__03848c5249706eb12353da17c6c9a04a1aa128ae7064e7631d29cbd37401b6b9(
    *,
    current_value: typing.Optional[typing.Sequence[builtins.str]] = None,
    previous_value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__36faa1f4ef40bc8f128624b451d8bf725e6d7684f0a20baee26e145ff9be3d80(
    *,
    completed: typing.Optional[typing.Sequence[builtins.str]] = None,
    started: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0027197ce6ef71e159b8a8d33fdde75441514fdeeda934b6af3e4cfebbab29cd(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    artifact_location: typing.Optional[typing.Sequence[builtins.str]] = None,
    canary_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    canary_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    canary_run_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    canary_run_timeline: typing.Optional[typing.Union[SyntheticsCanaryTestRunFailure.CanaryRunTimeline, typing.Dict[builtins.str, typing.Any]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    state_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    test_run_status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1d882b823719739cf8961367c9f6b649b8606228f97fa58fd3807a52d79fda39(
    *,
    completed: typing.Optional[typing.Sequence[builtins.str]] = None,
    started: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4dbb1ec8bea8c1ba59db6e15ceaae2345acebd12feed3d8ec46f7b2a3894df70(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    artifact_location: typing.Optional[typing.Sequence[builtins.str]] = None,
    canary_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    canary_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    canary_run_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    canary_run_timeline: typing.Optional[typing.Union[SyntheticsCanaryTestRunSuccessful.CanaryRunTimeline, typing.Dict[builtins.str, typing.Any]]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    state_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    test_run_status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
