from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class CodeGuruProfilerRecommendationStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codeguruprofiler.events.CodeGuruProfilerRecommendationStateChange",
):
    '''(experimental) EventBridge event pattern for aws.codeguruprofiler@CodeGuruProfilerRecommendationStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codeguruprofiler import events as codeguruprofiler_events
        
        code_guru_profiler_recommendation_state_change = codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        compute_instance_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
        deduplication_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        expires_on: typing.Optional[typing.Sequence[builtins.str]] = None,
        recommendation: typing.Optional[typing.Union["CodeGuruProfilerRecommendationStateChange.Recommendation", typing.Dict[builtins.str, typing.Any]]] = None,
        schema: typing.Optional[typing.Sequence[builtins.str]] = None,
        severity: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_url: typing.Optional[typing.Sequence[builtins.str]] = None,
        status: typing.Optional[typing.Sequence[builtins.str]] = None,
        title: typing.Optional[typing.Union["CodeGuruProfilerRecommendationStateChange.Title", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodeGuru Profiler Recommendations State Change.

        :param compute_instance_arns: (experimental) computeInstanceArns property. Specify an array of string values to match this event if the actual value of computeInstanceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param deduplication_id: (experimental) deduplicationId property. Specify an array of string values to match this event if the actual value of deduplicationId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_end_time: (experimental) eventEndTime property. Specify an array of string values to match this event if the actual value of eventEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_start_time: (experimental) eventStartTime property. Specify an array of string values to match this event if the actual value of eventStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param expires_on: (experimental) expiresOn property. Specify an array of string values to match this event if the actual value of expiresOn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param recommendation: (experimental) recommendation property. Specify an array of string values to match this event if the actual value of recommendation is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param schema: (experimental) schema property. Specify an array of string values to match this event if the actual value of schema is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_url: (experimental) sourceUrl property. Specify an array of string values to match this event if the actual value of sourceUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param title: (experimental) title property. Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeGuruProfilerRecommendationStateChange.CodeGuruProfilerRecommendationStateChangeProps(
            compute_instance_arns=compute_instance_arns,
            deduplication_id=deduplication_id,
            event_end_time=event_end_time,
            event_metadata=event_metadata,
            event_start_time=event_start_time,
            expires_on=expires_on,
            recommendation=recommendation,
            schema=schema,
            severity=severity,
            source_url=source_url,
            status=status,
            title=title,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codeguruprofiler.events.CodeGuruProfilerRecommendationStateChange.CodeGuruProfilerRecommendationStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "compute_instance_arns": "computeInstanceArns",
            "deduplication_id": "deduplicationId",
            "event_end_time": "eventEndTime",
            "event_metadata": "eventMetadata",
            "event_start_time": "eventStartTime",
            "expires_on": "expiresOn",
            "recommendation": "recommendation",
            "schema": "schema",
            "severity": "severity",
            "source_url": "sourceUrl",
            "status": "status",
            "title": "title",
        },
    )
    class CodeGuruProfilerRecommendationStateChangeProps:
        def __init__(
            self,
            *,
            compute_instance_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
            deduplication_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            event_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            expires_on: typing.Optional[typing.Sequence[builtins.str]] = None,
            recommendation: typing.Optional[typing.Union["CodeGuruProfilerRecommendationStateChange.Recommendation", typing.Dict[builtins.str, typing.Any]]] = None,
            schema: typing.Optional[typing.Sequence[builtins.str]] = None,
            severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_url: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            title: typing.Optional[typing.Union["CodeGuruProfilerRecommendationStateChange.Title", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codeguruprofiler@CodeGuruProfilerRecommendationStateChange event.

            :param compute_instance_arns: (experimental) computeInstanceArns property. Specify an array of string values to match this event if the actual value of computeInstanceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param deduplication_id: (experimental) deduplicationId property. Specify an array of string values to match this event if the actual value of deduplicationId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_end_time: (experimental) eventEndTime property. Specify an array of string values to match this event if the actual value of eventEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param event_start_time: (experimental) eventStartTime property. Specify an array of string values to match this event if the actual value of eventStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param expires_on: (experimental) expiresOn property. Specify an array of string values to match this event if the actual value of expiresOn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param recommendation: (experimental) recommendation property. Specify an array of string values to match this event if the actual value of recommendation is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param schema: (experimental) schema property. Specify an array of string values to match this event if the actual value of schema is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_url: (experimental) sourceUrl property. Specify an array of string values to match this event if the actual value of sourceUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param title: (experimental) title property. Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codeguruprofiler import events as codeguruprofiler_events
                
                code_guru_profiler_recommendation_state_change_props = codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.CodeGuruProfilerRecommendationStateChangeProps(
                    compute_instance_arns=["computeInstanceArns"],
                    deduplication_id=["deduplicationId"],
                    event_end_time=["eventEndTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    event_start_time=["eventStartTime"],
                    expires_on=["expiresOn"],
                    recommendation=codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Recommendation(
                        description=codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Description(
                            value=["value"]
                        ),
                        name=codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Name(
                            value=["value"]
                        ),
                        reason=codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Reason(
                            value=["value"]
                        ),
                        resolution_steps=codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.ResolutionSteps(
                            value=["value"]
                        )
                    ),
                    schema=["schema"],
                    severity=["severity"],
                    source_url=["sourceUrl"],
                    status=["status"],
                    title=codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Title(
                        value=["value"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(recommendation, dict):
                recommendation = CodeGuruProfilerRecommendationStateChange.Recommendation(**recommendation)
            if isinstance(title, dict):
                title = CodeGuruProfilerRecommendationStateChange.Title(**title)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__96fbf7642d7e87febd90e77e679a3c60a67e7dcb2894b4fe43f75c2602a44de7)
                check_type(argname="argument compute_instance_arns", value=compute_instance_arns, expected_type=type_hints["compute_instance_arns"])
                check_type(argname="argument deduplication_id", value=deduplication_id, expected_type=type_hints["deduplication_id"])
                check_type(argname="argument event_end_time", value=event_end_time, expected_type=type_hints["event_end_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument event_start_time", value=event_start_time, expected_type=type_hints["event_start_time"])
                check_type(argname="argument expires_on", value=expires_on, expected_type=type_hints["expires_on"])
                check_type(argname="argument recommendation", value=recommendation, expected_type=type_hints["recommendation"])
                check_type(argname="argument schema", value=schema, expected_type=type_hints["schema"])
                check_type(argname="argument severity", value=severity, expected_type=type_hints["severity"])
                check_type(argname="argument source_url", value=source_url, expected_type=type_hints["source_url"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument title", value=title, expected_type=type_hints["title"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if compute_instance_arns is not None:
                self._values["compute_instance_arns"] = compute_instance_arns
            if deduplication_id is not None:
                self._values["deduplication_id"] = deduplication_id
            if event_end_time is not None:
                self._values["event_end_time"] = event_end_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if event_start_time is not None:
                self._values["event_start_time"] = event_start_time
            if expires_on is not None:
                self._values["expires_on"] = expires_on
            if recommendation is not None:
                self._values["recommendation"] = recommendation
            if schema is not None:
                self._values["schema"] = schema
            if severity is not None:
                self._values["severity"] = severity
            if source_url is not None:
                self._values["source_url"] = source_url
            if status is not None:
                self._values["status"] = status
            if title is not None:
                self._values["title"] = title

        @builtins.property
        def compute_instance_arns(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) computeInstanceArns property.

            Specify an array of string values to match this event if the actual value of computeInstanceArns is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("compute_instance_arns")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def deduplication_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) deduplicationId property.

            Specify an array of string values to match this event if the actual value of deduplicationId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("deduplication_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventEndTime property.

            Specify an array of string values to match this event if the actual value of eventEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def event_start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventStartTime property.

            Specify an array of string values to match this event if the actual value of eventStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def expires_on(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) expiresOn property.

            Specify an array of string values to match this event if the actual value of expiresOn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("expires_on")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def recommendation(
            self,
        ) -> typing.Optional["CodeGuruProfilerRecommendationStateChange.Recommendation"]:
            '''(experimental) recommendation property.

            Specify an array of string values to match this event if the actual value of recommendation is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("recommendation")
            return typing.cast(typing.Optional["CodeGuruProfilerRecommendationStateChange.Recommendation"], result)

        @builtins.property
        def schema(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) schema property.

            Specify an array of string values to match this event if the actual value of schema is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("schema")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) severity property.

            Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceUrl property.

            Specify an array of string values to match this event if the actual value of sourceUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def title(
            self,
        ) -> typing.Optional["CodeGuruProfilerRecommendationStateChange.Title"]:
            '''(experimental) title property.

            Specify an array of string values to match this event if the actual value of title is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("title")
            return typing.cast(typing.Optional["CodeGuruProfilerRecommendationStateChange.Title"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodeGuruProfilerRecommendationStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codeguruprofiler.events.CodeGuruProfilerRecommendationStateChange.Description",
        jsii_struct_bases=[],
        name_mapping={"value": "value"},
    )
    class Description:
        def __init__(
            self,
            *,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Description.

            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codeguruprofiler import events as codeguruprofiler_events
                
                description = codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Description(
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d1299e640b905dd3d461e479a22d3b6111f25ea01e86b3f28229c492697c8d3c)
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Description(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codeguruprofiler.events.CodeGuruProfilerRecommendationStateChange.Name",
        jsii_struct_bases=[],
        name_mapping={"value": "value"},
    )
    class Name:
        def __init__(
            self,
            *,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Name.

            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codeguruprofiler import events as codeguruprofiler_events
                
                name = codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Name(
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c885e9ae95e2439a7eaad4e4936572879868b6058f0ee6b2c025357c920d91f9)
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Name(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codeguruprofiler.events.CodeGuruProfilerRecommendationStateChange.Reason",
        jsii_struct_bases=[],
        name_mapping={"value": "value"},
    )
    class Reason:
        def __init__(
            self,
            *,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Reason.

            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codeguruprofiler import events as codeguruprofiler_events
                
                reason = codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Reason(
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__50b40a6faab26c832ce67669f2e5e4a29b6a71132b0ad4122d6a2328a809445e)
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Reason(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codeguruprofiler.events.CodeGuruProfilerRecommendationStateChange.Recommendation",
        jsii_struct_bases=[],
        name_mapping={
            "description": "description",
            "name": "name",
            "reason": "reason",
            "resolution_steps": "resolutionSteps",
        },
    )
    class Recommendation:
        def __init__(
            self,
            *,
            description: typing.Optional[typing.Union["CodeGuruProfilerRecommendationStateChange.Description", typing.Dict[builtins.str, typing.Any]]] = None,
            name: typing.Optional[typing.Union["CodeGuruProfilerRecommendationStateChange.Name", typing.Dict[builtins.str, typing.Any]]] = None,
            reason: typing.Optional[typing.Union["CodeGuruProfilerRecommendationStateChange.Reason", typing.Dict[builtins.str, typing.Any]]] = None,
            resolution_steps: typing.Optional[typing.Union["CodeGuruProfilerRecommendationStateChange.ResolutionSteps", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for Recommendation.

            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reason: (experimental) reason property. Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resolution_steps: (experimental) resolutionSteps property. Specify an array of string values to match this event if the actual value of resolutionSteps is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codeguruprofiler import events as codeguruprofiler_events
                
                recommendation = codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Recommendation(
                    description=codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Description(
                        value=["value"]
                    ),
                    name=codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Name(
                        value=["value"]
                    ),
                    reason=codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Reason(
                        value=["value"]
                    ),
                    resolution_steps=codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.ResolutionSteps(
                        value=["value"]
                    )
                )
            '''
            if isinstance(description, dict):
                description = CodeGuruProfilerRecommendationStateChange.Description(**description)
            if isinstance(name, dict):
                name = CodeGuruProfilerRecommendationStateChange.Name(**name)
            if isinstance(reason, dict):
                reason = CodeGuruProfilerRecommendationStateChange.Reason(**reason)
            if isinstance(resolution_steps, dict):
                resolution_steps = CodeGuruProfilerRecommendationStateChange.ResolutionSteps(**resolution_steps)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2585002b01398f9055e352969ff5b6c8536c61c434ae87c13cbfa5c2a19ed263)
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument reason", value=reason, expected_type=type_hints["reason"])
                check_type(argname="argument resolution_steps", value=resolution_steps, expected_type=type_hints["resolution_steps"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if description is not None:
                self._values["description"] = description
            if name is not None:
                self._values["name"] = name
            if reason is not None:
                self._values["reason"] = reason
            if resolution_steps is not None:
                self._values["resolution_steps"] = resolution_steps

        @builtins.property
        def description(
            self,
        ) -> typing.Optional["CodeGuruProfilerRecommendationStateChange.Description"]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional["CodeGuruProfilerRecommendationStateChange.Description"], result)

        @builtins.property
        def name(
            self,
        ) -> typing.Optional["CodeGuruProfilerRecommendationStateChange.Name"]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional["CodeGuruProfilerRecommendationStateChange.Name"], result)

        @builtins.property
        def reason(
            self,
        ) -> typing.Optional["CodeGuruProfilerRecommendationStateChange.Reason"]:
            '''(experimental) reason property.

            Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reason")
            return typing.cast(typing.Optional["CodeGuruProfilerRecommendationStateChange.Reason"], result)

        @builtins.property
        def resolution_steps(
            self,
        ) -> typing.Optional["CodeGuruProfilerRecommendationStateChange.ResolutionSteps"]:
            '''(experimental) resolutionSteps property.

            Specify an array of string values to match this event if the actual value of resolutionSteps is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resolution_steps")
            return typing.cast(typing.Optional["CodeGuruProfilerRecommendationStateChange.ResolutionSteps"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Recommendation(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codeguruprofiler.events.CodeGuruProfilerRecommendationStateChange.ResolutionSteps",
        jsii_struct_bases=[],
        name_mapping={"value": "value"},
    )
    class ResolutionSteps:
        def __init__(
            self,
            *,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResolutionSteps.

            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codeguruprofiler import events as codeguruprofiler_events
                
                resolution_steps = codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.ResolutionSteps(
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__17d0488b6d1d613575a25ff612111855a544ac2fe46a18e673c17d74961e21d9)
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResolutionSteps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codeguruprofiler.events.CodeGuruProfilerRecommendationStateChange.Title",
        jsii_struct_bases=[],
        name_mapping={"value": "value"},
    )
    class Title:
        def __init__(
            self,
            *,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Title.

            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codeguruprofiler import events as codeguruprofiler_events
                
                title = codeguruprofiler_events.CodeGuruProfilerRecommendationStateChange.Title(
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__65f0ec4091d3b0d9aba1172736213656e05050f6be4594cd38984559bf00fc1e)
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Title(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "CodeGuruProfilerRecommendationStateChange",
]

publication.publish()

def _typecheckingstub__96fbf7642d7e87febd90e77e679a3c60a67e7dcb2894b4fe43f75c2602a44de7(
    *,
    compute_instance_arns: typing.Optional[typing.Sequence[builtins.str]] = None,
    deduplication_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    event_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    expires_on: typing.Optional[typing.Sequence[builtins.str]] = None,
    recommendation: typing.Optional[typing.Union[CodeGuruProfilerRecommendationStateChange.Recommendation, typing.Dict[builtins.str, typing.Any]]] = None,
    schema: typing.Optional[typing.Sequence[builtins.str]] = None,
    severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_url: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    title: typing.Optional[typing.Union[CodeGuruProfilerRecommendationStateChange.Title, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d1299e640b905dd3d461e479a22d3b6111f25ea01e86b3f28229c492697c8d3c(
    *,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c885e9ae95e2439a7eaad4e4936572879868b6058f0ee6b2c025357c920d91f9(
    *,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__50b40a6faab26c832ce67669f2e5e4a29b6a71132b0ad4122d6a2328a809445e(
    *,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2585002b01398f9055e352969ff5b6c8536c61c434ae87c13cbfa5c2a19ed263(
    *,
    description: typing.Optional[typing.Union[CodeGuruProfilerRecommendationStateChange.Description, typing.Dict[builtins.str, typing.Any]]] = None,
    name: typing.Optional[typing.Union[CodeGuruProfilerRecommendationStateChange.Name, typing.Dict[builtins.str, typing.Any]]] = None,
    reason: typing.Optional[typing.Union[CodeGuruProfilerRecommendationStateChange.Reason, typing.Dict[builtins.str, typing.Any]]] = None,
    resolution_steps: typing.Optional[typing.Union[CodeGuruProfilerRecommendationStateChange.ResolutionSteps, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__17d0488b6d1d613575a25ff612111855a544ac2fe46a18e673c17d74961e21d9(
    *,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__65f0ec4091d3b0d9aba1172736213656e05050f6be4594cd38984559bf00fc1e(
    *,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
