from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class CacheCreated(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.CacheCreated",
):
    '''(experimental) EventBridge event pattern for aws.elasticache@CacheCreated.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
        
        cache_created = elasticache_events.CacheCreated()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Cache Created.

        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CacheCreated.CacheCreatedProps(
            event_categories=event_categories,
            event_id=event_id,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.CacheCreated.CacheCreatedProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_categories": "eventCategories",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
        },
    )
    class CacheCreatedProps:
        def __init__(
            self,
            *,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.elasticache@CacheCreated event.

            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
                
                cache_created_props = elasticache_events.CacheCreated.CacheCreatedProps(
                    event_categories=["eventCategories"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0575c84973f5cdcf1ba630adcd71a6f2f7ace8f3690d865f36824a3aad9bd770)
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventID property.

            Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CacheCreatedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CacheCreationFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.CacheCreationFailed",
):
    '''(experimental) EventBridge event pattern for aws.elasticache@CacheCreationFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
        
        cache_creation_failed = elasticache_events.CacheCreationFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Cache Creation Failed.

        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CacheCreationFailed.CacheCreationFailedProps(
            event_categories=event_categories,
            event_id=event_id,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.CacheCreationFailed.CacheCreationFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_categories": "eventCategories",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
        },
    )
    class CacheCreationFailedProps:
        def __init__(
            self,
            *,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.elasticache@CacheCreationFailed event.

            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
                
                cache_creation_failed_props = elasticache_events.CacheCreationFailed.CacheCreationFailedProps(
                    event_categories=["eventCategories"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f9dc52c98206748a73a728d3a4bc138b3ac966b0cc9bbb7fbe8c435a9943ae0b)
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventID property.

            Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CacheCreationFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CacheDeleted(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.CacheDeleted",
):
    '''(experimental) EventBridge event pattern for aws.elasticache@CacheDeleted.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
        
        cache_deleted = elasticache_events.CacheDeleted()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Cache Deleted.

        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CacheDeleted.CacheDeletedProps(
            event_categories=event_categories,
            event_id=event_id,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.CacheDeleted.CacheDeletedProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_categories": "eventCategories",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
        },
    )
    class CacheDeletedProps:
        def __init__(
            self,
            *,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.elasticache@CacheDeleted event.

            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
                
                cache_deleted_props = elasticache_events.CacheDeleted.CacheDeletedProps(
                    event_categories=["eventCategories"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7424e789dce8d627f11c273faaa7ed417b0d0aa11f7f323525e30b6f41416b1b)
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventID property.

            Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CacheDeletedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CacheLimitApproaching(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.CacheLimitApproaching",
):
    '''(experimental) EventBridge event pattern for aws.elasticache@CacheLimitApproaching.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
        
        cache_limit_approaching = elasticache_events.CacheLimitApproaching()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Cache Limit Approaching.

        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CacheLimitApproaching.CacheLimitApproachingProps(
            event_categories=event_categories,
            event_id=event_id,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.CacheLimitApproaching.CacheLimitApproachingProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_categories": "eventCategories",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
        },
    )
    class CacheLimitApproachingProps:
        def __init__(
            self,
            *,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.elasticache@CacheLimitApproaching event.

            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
                
                cache_limit_approaching_props = elasticache_events.CacheLimitApproaching.CacheLimitApproachingProps(
                    event_categories=["eventCategories"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__888ac29894762d0a833439e86630a333387d7c590f8bfb00b49ccacd1693d26c)
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventID property.

            Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CacheLimitApproachingProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CacheUpdateFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.CacheUpdateFailed",
):
    '''(experimental) EventBridge event pattern for aws.elasticache@CacheUpdateFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
        
        cache_update_failed = elasticache_events.CacheUpdateFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Cache Update Failed.

        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CacheUpdateFailed.CacheUpdateFailedProps(
            event_categories=event_categories,
            event_id=event_id,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.CacheUpdateFailed.CacheUpdateFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_categories": "eventCategories",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
        },
    )
    class CacheUpdateFailedProps:
        def __init__(
            self,
            *,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.elasticache@CacheUpdateFailed event.

            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
                
                cache_update_failed_props = elasticache_events.CacheUpdateFailed.CacheUpdateFailedProps(
                    event_categories=["eventCategories"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f7175e4896c3b99f63c51340b40751293e64c04c7769ed6a14ad58dfb20ea3f1)
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventID property.

            Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CacheUpdateFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CacheUpdated(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.CacheUpdated",
):
    '''(experimental) EventBridge event pattern for aws.elasticache@CacheUpdated.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
        
        cache_updated = elasticache_events.CacheUpdated()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Cache Updated.

        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CacheUpdated.CacheUpdatedProps(
            event_categories=event_categories,
            event_id=event_id,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.CacheUpdated.CacheUpdatedProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_categories": "eventCategories",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
        },
    )
    class CacheUpdatedProps:
        def __init__(
            self,
            *,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.elasticache@CacheUpdated event.

            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
                
                cache_updated_props = elasticache_events.CacheUpdated.CacheUpdatedProps(
                    event_categories=["eventCategories"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__769866aa2aae97f1185d34e2c1367f35a2c269a664a671336056287556dee458)
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventID property.

            Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CacheUpdatedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SnapshotCopyFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.SnapshotCopyFailed",
):
    '''(experimental) EventBridge event pattern for aws.elasticache@SnapshotCopyFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
        
        snapshot_copy_failed = elasticache_events.SnapshotCopyFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Snapshot Copy Failed.

        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SnapshotCopyFailed.SnapshotCopyFailedProps(
            event_categories=event_categories,
            event_id=event_id,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.SnapshotCopyFailed.SnapshotCopyFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_categories": "eventCategories",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
        },
    )
    class SnapshotCopyFailedProps:
        def __init__(
            self,
            *,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.elasticache@SnapshotCopyFailed event.

            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
                
                snapshot_copy_failed_props = elasticache_events.SnapshotCopyFailed.SnapshotCopyFailedProps(
                    event_categories=["eventCategories"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7a384e7bef564f67c75fbec9269ffed8f2c4fe40c117a5ff164a6b9ab7dadf67)
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventID property.

            Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SnapshotCopyFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SnapshotCreated(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.SnapshotCreated",
):
    '''(experimental) EventBridge event pattern for aws.elasticache@SnapshotCreated.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
        
        snapshot_created = elasticache_events.SnapshotCreated()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Snapshot Created.

        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SnapshotCreated.SnapshotCreatedProps(
            event_categories=event_categories,
            event_id=event_id,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.SnapshotCreated.SnapshotCreatedProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_categories": "eventCategories",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
        },
    )
    class SnapshotCreatedProps:
        def __init__(
            self,
            *,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.elasticache@SnapshotCreated event.

            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
                
                snapshot_created_props = elasticache_events.SnapshotCreated.SnapshotCreatedProps(
                    event_categories=["eventCategories"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0a4faf00bf239c8b68a07753ccbfedccef1959c147cc918fc019b2e75125691b)
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventID property.

            Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SnapshotCreatedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SnapshotCreationFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.SnapshotCreationFailed",
):
    '''(experimental) EventBridge event pattern for aws.elasticache@SnapshotCreationFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
        
        snapshot_creation_failed = elasticache_events.SnapshotCreationFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Snapshot Creation Failed.

        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SnapshotCreationFailed.SnapshotCreationFailedProps(
            event_categories=event_categories,
            event_id=event_id,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.SnapshotCreationFailed.SnapshotCreationFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_categories": "eventCategories",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
        },
    )
    class SnapshotCreationFailedProps:
        def __init__(
            self,
            *,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.elasticache@SnapshotCreationFailed event.

            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
                
                snapshot_creation_failed_props = elasticache_events.SnapshotCreationFailed.SnapshotCreationFailedProps(
                    event_categories=["eventCategories"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__377922ad03fd4525bc3abd3f00a61b851cf82accf8fe706057503e4bc9c03861)
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventID property.

            Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SnapshotCreationFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SnapshotExportFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.SnapshotExportFailed",
):
    '''(experimental) EventBridge event pattern for aws.elasticache@SnapshotExportFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
        
        snapshot_export_failed = elasticache_events.SnapshotExportFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
        source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Snapshot Export Failed.

        :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SnapshotExportFailed.SnapshotExportFailedProps(
            event_categories=event_categories,
            event_id=event_id,
            event_metadata=event_metadata,
            message=message,
            source_arn=source_arn,
            source_identifier=source_identifier,
            source_type=source_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticache.events.SnapshotExportFailed.SnapshotExportFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_categories": "eventCategories",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "source_arn": "sourceArn",
            "source_identifier": "sourceIdentifier",
            "source_type": "sourceType",
        },
    )
    class SnapshotExportFailedProps:
        def __init__(
            self,
            *,
            event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
            source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.elasticache@SnapshotExportFailed event.

            :param event_categories: (experimental) EventCategories property. Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) EventID property. Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) Message property. Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_arn: (experimental) SourceArn property. Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_identifier: (experimental) SourceIdentifier property. Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_type: (experimental) SourceType property. Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticache import events as elasticache_events
                
                snapshot_export_failed_props = elasticache_events.SnapshotExportFailed.SnapshotExportFailedProps(
                    event_categories=["eventCategories"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    source_arn=["sourceArn"],
                    source_identifier=["sourceIdentifier"],
                    source_type=["sourceType"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d68a4bd4f4506c690836a7c25a7cb8340d9daddd03347c18b888e373e9223a5e)
                check_type(argname="argument event_categories", value=event_categories, expected_type=type_hints["event_categories"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument source_arn", value=source_arn, expected_type=type_hints["source_arn"])
                check_type(argname="argument source_identifier", value=source_identifier, expected_type=type_hints["source_identifier"])
                check_type(argname="argument source_type", value=source_type, expected_type=type_hints["source_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_categories is not None:
                self._values["event_categories"] = event_categories
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if source_arn is not None:
                self._values["source_arn"] = source_arn
            if source_identifier is not None:
                self._values["source_identifier"] = source_identifier
            if source_type is not None:
                self._values["source_type"] = source_type

        @builtins.property
        def event_categories(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventCategories property.

            Specify an array of string values to match this event if the actual value of EventCategories is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_categories")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EventID property.

            Specify an array of string values to match this event if the actual value of EventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Message property.

            Specify an array of string values to match this event if the actual value of Message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceArn property.

            Specify an array of string values to match this event if the actual value of SourceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_identifier(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceIdentifier property.

            Specify an array of string values to match this event if the actual value of SourceIdentifier is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_identifier")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SourceType property.

            Specify an array of string values to match this event if the actual value of SourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SnapshotExportFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "CacheCreated",
    "CacheCreationFailed",
    "CacheDeleted",
    "CacheLimitApproaching",
    "CacheUpdateFailed",
    "CacheUpdated",
    "SnapshotCopyFailed",
    "SnapshotCreated",
    "SnapshotCreationFailed",
    "SnapshotExportFailed",
]

publication.publish()

def _typecheckingstub__0575c84973f5cdcf1ba630adcd71a6f2f7ace8f3690d865f36824a3aad9bd770(
    *,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f9dc52c98206748a73a728d3a4bc138b3ac966b0cc9bbb7fbe8c435a9943ae0b(
    *,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7424e789dce8d627f11c273faaa7ed417b0d0aa11f7f323525e30b6f41416b1b(
    *,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__888ac29894762d0a833439e86630a333387d7c590f8bfb00b49ccacd1693d26c(
    *,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f7175e4896c3b99f63c51340b40751293e64c04c7769ed6a14ad58dfb20ea3f1(
    *,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__769866aa2aae97f1185d34e2c1367f35a2c269a664a671336056287556dee458(
    *,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7a384e7bef564f67c75fbec9269ffed8f2c4fe40c117a5ff164a6b9ab7dadf67(
    *,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a4faf00bf239c8b68a07753ccbfedccef1959c147cc918fc019b2e75125691b(
    *,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__377922ad03fd4525bc3abd3f00a61b851cf82accf8fe706057503e4bc9c03861(
    *,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d68a4bd4f4506c690836a7c25a7cb8340d9daddd03347c18b888e373e9223a5e(
    *,
    event_categories: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_identifier: typing.Optional[typing.Sequence[builtins.str]] = None,
    source_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
