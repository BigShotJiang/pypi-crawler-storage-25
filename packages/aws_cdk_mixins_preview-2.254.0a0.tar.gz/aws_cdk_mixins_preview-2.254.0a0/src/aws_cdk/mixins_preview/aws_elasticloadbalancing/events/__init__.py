from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class AWSAPICallViaCloudTrail(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail",
):
    '''(experimental) EventBridge event pattern for aws.elasticloadbalancing@AWSAPICallViaCloudTrail.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
        
        a_wSAPICall_via_cloud_trail = elasticloadbalancing_events.AWSAPICallViaCloudTrail()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        api_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
        source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AWS API Call via CloudTrail.

        :param api_version: (experimental) apiVersion property. Specify an array of string values to match this event if the actual value of apiVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
            api_version=api_version,
            aws_region=aws_region,
            error_code=error_code,
            error_message=error_message,
            event_id=event_id,
            event_metadata=event_metadata,
            event_name=event_name,
            event_source=event_source,
            event_time=event_time,
            event_type=event_type,
            event_version=event_version,
            request_id=request_id,
            request_parameters=request_parameters,
            response_elements=response_elements,
            source_ip_address=source_ip_address,
            user_agent=user_agent,
            user_identity=user_identity,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps",
        jsii_struct_bases=[],
        name_mapping={
            "api_version": "apiVersion",
            "aws_region": "awsRegion",
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "event_name": "eventName",
            "event_source": "eventSource",
            "event_time": "eventTime",
            "event_type": "eventType",
            "event_version": "eventVersion",
            "request_id": "requestId",
            "request_parameters": "requestParameters",
            "response_elements": "responseElements",
            "source_ip_address": "sourceIpAddress",
            "user_agent": "userAgent",
            "user_identity": "userIdentity",
        },
    )
    class AWSAPICallViaCloudTrailProps:
        def __init__(
            self,
            *,
            api_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
            response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
            source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.elasticloadbalancing@AWSAPICallViaCloudTrail event.

            :param api_version: (experimental) apiVersion property. Specify an array of string values to match this event if the actual value of apiVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
                
                a_wSAPICall_via_cloud_trail_props = elasticloadbalancing_events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
                    api_version=["apiVersion"],
                    aws_region=["awsRegion"],
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    event_name=["eventName"],
                    event_source=["eventSource"],
                    event_time=["eventTime"],
                    event_type=["eventType"],
                    event_version=["eventVersion"],
                    request_id=["requestId"],
                    request_parameters=elasticloadbalancing_events.AWSAPICallViaCloudTrail.RequestParameters(
                        health_check=elasticloadbalancing_events.AWSAPICallViaCloudTrail.HealthCheck1(
                            healthy_threshold=["healthyThreshold"],
                            interval=["interval"],
                            target=["target"],
                            timeout=["timeout"],
                            unhealthy_threshold=["unhealthyThreshold"]
                        ),
                        instances=[elasticloadbalancing_events.AWSAPICallViaCloudTrail.ResponseElementsItem(
                            instance_id=["instanceId"]
                        )],
                        listeners=[elasticloadbalancing_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                            instance_port=["instancePort"],
                            load_balancer_port=["loadBalancerPort"],
                            protocol=["protocol"]
                        )],
                        load_balancer_name=["loadBalancerName"],
                        subnets=["subnets"],
                        target_group_arn=["targetGroupArn"],
                        targets=[elasticloadbalancing_events.AWSAPICallViaCloudTrail.RequestParametersItem1(
                            id=["id"]
                        )]
                    ),
                    response_elements=elasticloadbalancing_events.AWSAPICallViaCloudTrail.ResponseElements(
                        d_ns_name=["dNsName"],
                        health_check=elasticloadbalancing_events.AWSAPICallViaCloudTrail.HealthCheck(
                            healthy_threshold=["healthyThreshold"],
                            interval=["interval"],
                            target=["target"],
                            timeout=["timeout"],
                            unhealthy_threshold=["unhealthyThreshold"]
                        ),
                        instances=[elasticloadbalancing_events.AWSAPICallViaCloudTrail.ResponseElementsItem(
                            instance_id=["instanceId"]
                        )]
                    ),
                    source_ip_address=["sourceIpAddress"],
                    user_agent=["userAgent"],
                    user_identity=elasticloadbalancing_events.AWSAPICallViaCloudTrail.UserIdentity(
                        access_key_id=["accessKeyId"],
                        account_id=["accountId"],
                        arn=["arn"],
                        invoked_by=["invokedBy"],
                        principal_id=["principalId"],
                        session_context=elasticloadbalancing_events.AWSAPICallViaCloudTrail.SessionContext(
                            attributes=elasticloadbalancing_events.AWSAPICallViaCloudTrail.Attributes(
                                creation_date=["creationDate"],
                                mfa_authenticated=["mfaAuthenticated"]
                            ),
                            session_issuer=elasticloadbalancing_events.AWSAPICallViaCloudTrail.SessionIssuer(
                                account_id=["accountId"],
                                arn=["arn"],
                                principal_id=["principalId"],
                                type=["type"],
                                user_name=["userName"]
                            ),
                            web_id_federation_data=["webIdFederationData"]
                        ),
                        type=["type"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(request_parameters, dict):
                request_parameters = AWSAPICallViaCloudTrail.RequestParameters(**request_parameters)
            if isinstance(response_elements, dict):
                response_elements = AWSAPICallViaCloudTrail.ResponseElements(**response_elements)
            if isinstance(user_identity, dict):
                user_identity = AWSAPICallViaCloudTrail.UserIdentity(**user_identity)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__62c05d5189b83aa2fc9d6d7554e569abf901571691a47d4a20d907f010774d9f)
                check_type(argname="argument api_version", value=api_version, expected_type=type_hints["api_version"])
                check_type(argname="argument aws_region", value=aws_region, expected_type=type_hints["aws_region"])
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument event_name", value=event_name, expected_type=type_hints["event_name"])
                check_type(argname="argument event_source", value=event_source, expected_type=type_hints["event_source"])
                check_type(argname="argument event_time", value=event_time, expected_type=type_hints["event_time"])
                check_type(argname="argument event_type", value=event_type, expected_type=type_hints["event_type"])
                check_type(argname="argument event_version", value=event_version, expected_type=type_hints["event_version"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument request_parameters", value=request_parameters, expected_type=type_hints["request_parameters"])
                check_type(argname="argument response_elements", value=response_elements, expected_type=type_hints["response_elements"])
                check_type(argname="argument source_ip_address", value=source_ip_address, expected_type=type_hints["source_ip_address"])
                check_type(argname="argument user_agent", value=user_agent, expected_type=type_hints["user_agent"])
                check_type(argname="argument user_identity", value=user_identity, expected_type=type_hints["user_identity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if api_version is not None:
                self._values["api_version"] = api_version
            if aws_region is not None:
                self._values["aws_region"] = aws_region
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if event_name is not None:
                self._values["event_name"] = event_name
            if event_source is not None:
                self._values["event_source"] = event_source
            if event_time is not None:
                self._values["event_time"] = event_time
            if event_type is not None:
                self._values["event_type"] = event_type
            if event_version is not None:
                self._values["event_version"] = event_version
            if request_id is not None:
                self._values["request_id"] = request_id
            if request_parameters is not None:
                self._values["request_parameters"] = request_parameters
            if response_elements is not None:
                self._values["response_elements"] = response_elements
            if source_ip_address is not None:
                self._values["source_ip_address"] = source_ip_address
            if user_agent is not None:
                self._values["user_agent"] = user_agent
            if user_identity is not None:
                self._values["user_identity"] = user_identity

        @builtins.property
        def api_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) apiVersion property.

            Specify an array of string values to match this event if the actual value of apiVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("api_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def aws_region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) awsRegion property.

            Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventID property.

            Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def event_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventName property.

            Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventSource property.

            Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventTime property.

            Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventType property.

            Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventVersion property.

            Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestID property.

            Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_parameters(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"]:
            '''(experimental) requestParameters property.

            Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_parameters")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"], result)

        @builtins.property
        def response_elements(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"]:
            '''(experimental) responseElements property.

            Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("response_elements")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"], result)

        @builtins.property
        def source_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceIPAddress property.

            Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_agent(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userAgent property.

            Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_agent")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_identity(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"]:
            '''(experimental) userIdentity property.

            Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_identity")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AWSAPICallViaCloudTrailProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail.Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "creation_date": "creationDate",
            "mfa_authenticated": "mfaAuthenticated",
        },
    )
    class Attributes:
        def __init__(
            self,
            *,
            creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Attributes.

            :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param mfa_authenticated: (experimental) mfaAuthenticated property. Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
                
                attributes = elasticloadbalancing_events.AWSAPICallViaCloudTrail.Attributes(
                    creation_date=["creationDate"],
                    mfa_authenticated=["mfaAuthenticated"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__41c1e6ab2e1fb16d017398fdd8154d591672bf42d782330bae516e50be356551)
                check_type(argname="argument creation_date", value=creation_date, expected_type=type_hints["creation_date"])
                check_type(argname="argument mfa_authenticated", value=mfa_authenticated, expected_type=type_hints["mfa_authenticated"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_date is not None:
                self._values["creation_date"] = creation_date
            if mfa_authenticated is not None:
                self._values["mfa_authenticated"] = mfa_authenticated

        @builtins.property
        def creation_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationDate property.

            Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def mfa_authenticated(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mfaAuthenticated property.

            Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("mfa_authenticated")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail.HealthCheck",
        jsii_struct_bases=[],
        name_mapping={
            "healthy_threshold": "healthyThreshold",
            "interval": "interval",
            "target": "target",
            "timeout": "timeout",
            "unhealthy_threshold": "unhealthyThreshold",
        },
    )
    class HealthCheck:
        def __init__(
            self,
            *,
            healthy_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
            interval: typing.Optional[typing.Sequence[builtins.str]] = None,
            target: typing.Optional[typing.Sequence[builtins.str]] = None,
            timeout: typing.Optional[typing.Sequence[builtins.str]] = None,
            unhealthy_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for HealthCheck.

            :param healthy_threshold: (experimental) healthyThreshold property. Specify an array of string values to match this event if the actual value of healthyThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param interval: (experimental) interval property. Specify an array of string values to match this event if the actual value of interval is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target: (experimental) target property. Specify an array of string values to match this event if the actual value of target is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param timeout: (experimental) timeout property. Specify an array of string values to match this event if the actual value of timeout is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param unhealthy_threshold: (experimental) unhealthyThreshold property. Specify an array of string values to match this event if the actual value of unhealthyThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
                
                health_check = elasticloadbalancing_events.AWSAPICallViaCloudTrail.HealthCheck(
                    healthy_threshold=["healthyThreshold"],
                    interval=["interval"],
                    target=["target"],
                    timeout=["timeout"],
                    unhealthy_threshold=["unhealthyThreshold"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8fd0744b5b7cf5761916fa196d5c61df3b82cc7987fa13a0561a120f0caac46b)
                check_type(argname="argument healthy_threshold", value=healthy_threshold, expected_type=type_hints["healthy_threshold"])
                check_type(argname="argument interval", value=interval, expected_type=type_hints["interval"])
                check_type(argname="argument target", value=target, expected_type=type_hints["target"])
                check_type(argname="argument timeout", value=timeout, expected_type=type_hints["timeout"])
                check_type(argname="argument unhealthy_threshold", value=unhealthy_threshold, expected_type=type_hints["unhealthy_threshold"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if healthy_threshold is not None:
                self._values["healthy_threshold"] = healthy_threshold
            if interval is not None:
                self._values["interval"] = interval
            if target is not None:
                self._values["target"] = target
            if timeout is not None:
                self._values["timeout"] = timeout
            if unhealthy_threshold is not None:
                self._values["unhealthy_threshold"] = unhealthy_threshold

        @builtins.property
        def healthy_threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) healthyThreshold property.

            Specify an array of string values to match this event if the actual value of healthyThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("healthy_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def interval(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) interval property.

            Specify an array of string values to match this event if the actual value of interval is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("interval")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def target(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) target property.

            Specify an array of string values to match this event if the actual value of target is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def timeout(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) timeout property.

            Specify an array of string values to match this event if the actual value of timeout is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("timeout")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def unhealthy_threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) unhealthyThreshold property.

            Specify an array of string values to match this event if the actual value of unhealthyThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("unhealthy_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "HealthCheck(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail.HealthCheck1",
        jsii_struct_bases=[],
        name_mapping={
            "healthy_threshold": "healthyThreshold",
            "interval": "interval",
            "target": "target",
            "timeout": "timeout",
            "unhealthy_threshold": "unhealthyThreshold",
        },
    )
    class HealthCheck1:
        def __init__(
            self,
            *,
            healthy_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
            interval: typing.Optional[typing.Sequence[builtins.str]] = None,
            target: typing.Optional[typing.Sequence[builtins.str]] = None,
            timeout: typing.Optional[typing.Sequence[builtins.str]] = None,
            unhealthy_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for HealthCheck_1.

            :param healthy_threshold: (experimental) healthyThreshold property. Specify an array of string values to match this event if the actual value of healthyThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param interval: (experimental) interval property. Specify an array of string values to match this event if the actual value of interval is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target: (experimental) target property. Specify an array of string values to match this event if the actual value of target is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param timeout: (experimental) timeout property. Specify an array of string values to match this event if the actual value of timeout is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param unhealthy_threshold: (experimental) unhealthyThreshold property. Specify an array of string values to match this event if the actual value of unhealthyThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
                
                health_check1 = elasticloadbalancing_events.AWSAPICallViaCloudTrail.HealthCheck1(
                    healthy_threshold=["healthyThreshold"],
                    interval=["interval"],
                    target=["target"],
                    timeout=["timeout"],
                    unhealthy_threshold=["unhealthyThreshold"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__300b099434c24cc434b6f2e82282a1feaa188c29211bc795fae63e08e209c7f6)
                check_type(argname="argument healthy_threshold", value=healthy_threshold, expected_type=type_hints["healthy_threshold"])
                check_type(argname="argument interval", value=interval, expected_type=type_hints["interval"])
                check_type(argname="argument target", value=target, expected_type=type_hints["target"])
                check_type(argname="argument timeout", value=timeout, expected_type=type_hints["timeout"])
                check_type(argname="argument unhealthy_threshold", value=unhealthy_threshold, expected_type=type_hints["unhealthy_threshold"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if healthy_threshold is not None:
                self._values["healthy_threshold"] = healthy_threshold
            if interval is not None:
                self._values["interval"] = interval
            if target is not None:
                self._values["target"] = target
            if timeout is not None:
                self._values["timeout"] = timeout
            if unhealthy_threshold is not None:
                self._values["unhealthy_threshold"] = unhealthy_threshold

        @builtins.property
        def healthy_threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) healthyThreshold property.

            Specify an array of string values to match this event if the actual value of healthyThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("healthy_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def interval(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) interval property.

            Specify an array of string values to match this event if the actual value of interval is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("interval")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def target(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) target property.

            Specify an array of string values to match this event if the actual value of target is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def timeout(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) timeout property.

            Specify an array of string values to match this event if the actual value of timeout is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("timeout")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def unhealthy_threshold(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) unhealthyThreshold property.

            Specify an array of string values to match this event if the actual value of unhealthyThreshold is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("unhealthy_threshold")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "HealthCheck1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail.RequestParameters",
        jsii_struct_bases=[],
        name_mapping={
            "health_check": "healthCheck",
            "instances": "instances",
            "listeners": "listeners",
            "load_balancer_name": "loadBalancerName",
            "subnets": "subnets",
            "target_group_arn": "targetGroupArn",
            "targets": "targets",
        },
    )
    class RequestParameters:
        def __init__(
            self,
            *,
            health_check: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.HealthCheck1", typing.Dict[builtins.str, typing.Any]]] = None,
            instances: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.ResponseElementsItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            listeners: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.RequestParametersItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            load_balancer_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnets: typing.Optional[typing.Sequence[builtins.str]] = None,
            target_group_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            targets: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.RequestParametersItem1", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParameters.

            :param health_check: (experimental) healthCheck property. Specify an array of string values to match this event if the actual value of healthCheck is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instances: (experimental) instances property. Specify an array of string values to match this event if the actual value of instances is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param listeners: (experimental) listeners property. Specify an array of string values to match this event if the actual value of listeners is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param load_balancer_name: (experimental) loadBalancerName property. Specify an array of string values to match this event if the actual value of loadBalancerName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnets: (experimental) subnets property. Specify an array of string values to match this event if the actual value of subnets is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_group_arn: (experimental) targetGroupArn property. Specify an array of string values to match this event if the actual value of targetGroupArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param targets: (experimental) targets property. Specify an array of string values to match this event if the actual value of targets is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
                
                request_parameters = elasticloadbalancing_events.AWSAPICallViaCloudTrail.RequestParameters(
                    health_check=elasticloadbalancing_events.AWSAPICallViaCloudTrail.HealthCheck1(
                        healthy_threshold=["healthyThreshold"],
                        interval=["interval"],
                        target=["target"],
                        timeout=["timeout"],
                        unhealthy_threshold=["unhealthyThreshold"]
                    ),
                    instances=[elasticloadbalancing_events.AWSAPICallViaCloudTrail.ResponseElementsItem(
                        instance_id=["instanceId"]
                    )],
                    listeners=[elasticloadbalancing_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                        instance_port=["instancePort"],
                        load_balancer_port=["loadBalancerPort"],
                        protocol=["protocol"]
                    )],
                    load_balancer_name=["loadBalancerName"],
                    subnets=["subnets"],
                    target_group_arn=["targetGroupArn"],
                    targets=[elasticloadbalancing_events.AWSAPICallViaCloudTrail.RequestParametersItem1(
                        id=["id"]
                    )]
                )
            '''
            if isinstance(health_check, dict):
                health_check = AWSAPICallViaCloudTrail.HealthCheck1(**health_check)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__431104780a5d9afdfc50008fad364ecc74cee077c6ef38236571e74477eaf158)
                check_type(argname="argument health_check", value=health_check, expected_type=type_hints["health_check"])
                check_type(argname="argument instances", value=instances, expected_type=type_hints["instances"])
                check_type(argname="argument listeners", value=listeners, expected_type=type_hints["listeners"])
                check_type(argname="argument load_balancer_name", value=load_balancer_name, expected_type=type_hints["load_balancer_name"])
                check_type(argname="argument subnets", value=subnets, expected_type=type_hints["subnets"])
                check_type(argname="argument target_group_arn", value=target_group_arn, expected_type=type_hints["target_group_arn"])
                check_type(argname="argument targets", value=targets, expected_type=type_hints["targets"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if health_check is not None:
                self._values["health_check"] = health_check
            if instances is not None:
                self._values["instances"] = instances
            if listeners is not None:
                self._values["listeners"] = listeners
            if load_balancer_name is not None:
                self._values["load_balancer_name"] = load_balancer_name
            if subnets is not None:
                self._values["subnets"] = subnets
            if target_group_arn is not None:
                self._values["target_group_arn"] = target_group_arn
            if targets is not None:
                self._values["targets"] = targets

        @builtins.property
        def health_check(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.HealthCheck1"]:
            '''(experimental) healthCheck property.

            Specify an array of string values to match this event if the actual value of healthCheck is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("health_check")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.HealthCheck1"], result)

        @builtins.property
        def instances(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.ResponseElementsItem"]]:
            '''(experimental) instances property.

            Specify an array of string values to match this event if the actual value of instances is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instances")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.ResponseElementsItem"]], result)

        @builtins.property
        def listeners(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem"]]:
            '''(experimental) listeners property.

            Specify an array of string values to match this event if the actual value of listeners is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("listeners")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem"]], result)

        @builtins.property
        def load_balancer_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) loadBalancerName property.

            Specify an array of string values to match this event if the actual value of loadBalancerName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("load_balancer_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnets(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) subnets property.

            Specify an array of string values to match this event if the actual value of subnets is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnets")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def target_group_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) targetGroupArn property.

            Specify an array of string values to match this event if the actual value of targetGroupArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_group_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def targets(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem1"]]:
            '''(experimental) targets property.

            Specify an array of string values to match this event if the actual value of targets is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("targets")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem1"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParameters(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail.RequestParametersItem",
        jsii_struct_bases=[],
        name_mapping={
            "instance_port": "instancePort",
            "load_balancer_port": "loadBalancerPort",
            "protocol": "protocol",
        },
    )
    class RequestParametersItem:
        def __init__(
            self,
            *,
            instance_port: typing.Optional[typing.Sequence[builtins.str]] = None,
            load_balancer_port: typing.Optional[typing.Sequence[builtins.str]] = None,
            protocol: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParametersItem.

            :param instance_port: (experimental) instancePort property. Specify an array of string values to match this event if the actual value of instancePort is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param load_balancer_port: (experimental) loadBalancerPort property. Specify an array of string values to match this event if the actual value of loadBalancerPort is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param protocol: (experimental) protocol property. Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
                
                request_parameters_item = elasticloadbalancing_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                    instance_port=["instancePort"],
                    load_balancer_port=["loadBalancerPort"],
                    protocol=["protocol"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__71d5766f77a96a36d5ab28d526952d896f083c15ec1c3c024e72955fa4ad66bc)
                check_type(argname="argument instance_port", value=instance_port, expected_type=type_hints["instance_port"])
                check_type(argname="argument load_balancer_port", value=load_balancer_port, expected_type=type_hints["load_balancer_port"])
                check_type(argname="argument protocol", value=protocol, expected_type=type_hints["protocol"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if instance_port is not None:
                self._values["instance_port"] = instance_port
            if load_balancer_port is not None:
                self._values["load_balancer_port"] = load_balancer_port
            if protocol is not None:
                self._values["protocol"] = protocol

        @builtins.property
        def instance_port(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instancePort property.

            Specify an array of string values to match this event if the actual value of instancePort is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_port")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def load_balancer_port(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) loadBalancerPort property.

            Specify an array of string values to match this event if the actual value of loadBalancerPort is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("load_balancer_port")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def protocol(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) protocol property.

            Specify an array of string values to match this event if the actual value of protocol is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("protocol")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParametersItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail.RequestParametersItem1",
        jsii_struct_bases=[],
        name_mapping={"id": "id"},
    )
    class RequestParametersItem1:
        def __init__(
            self,
            *,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParametersItem_1.

            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
                
                request_parameters_item1 = elasticloadbalancing_events.AWSAPICallViaCloudTrail.RequestParametersItem1(
                    id=["id"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__51f5a81219be36c8859a50f7554c457729e4e476a7cb7bf4dcce6aa5787f06f5)
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if id is not None:
                self._values["id"] = id

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParametersItem1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail.ResponseElements",
        jsii_struct_bases=[],
        name_mapping={
            "d_ns_name": "dNsName",
            "health_check": "healthCheck",
            "instances": "instances",
        },
    )
    class ResponseElements:
        def __init__(
            self,
            *,
            d_ns_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            health_check: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.HealthCheck", typing.Dict[builtins.str, typing.Any]]] = None,
            instances: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.ResponseElementsItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Type definition for ResponseElements.

            :param d_ns_name: (experimental) dNSName property. Specify an array of string values to match this event if the actual value of dNSName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param health_check: (experimental) healthCheck property. Specify an array of string values to match this event if the actual value of healthCheck is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instances: (experimental) instances property. Specify an array of string values to match this event if the actual value of instances is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
                
                response_elements = elasticloadbalancing_events.AWSAPICallViaCloudTrail.ResponseElements(
                    d_ns_name=["dNsName"],
                    health_check=elasticloadbalancing_events.AWSAPICallViaCloudTrail.HealthCheck(
                        healthy_threshold=["healthyThreshold"],
                        interval=["interval"],
                        target=["target"],
                        timeout=["timeout"],
                        unhealthy_threshold=["unhealthyThreshold"]
                    ),
                    instances=[elasticloadbalancing_events.AWSAPICallViaCloudTrail.ResponseElementsItem(
                        instance_id=["instanceId"]
                    )]
                )
            '''
            if isinstance(health_check, dict):
                health_check = AWSAPICallViaCloudTrail.HealthCheck(**health_check)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__57ac4b4a272071b335d22ea2eb7081ac6ae13bf9c11bfaa4160d9985f82f4bb5)
                check_type(argname="argument d_ns_name", value=d_ns_name, expected_type=type_hints["d_ns_name"])
                check_type(argname="argument health_check", value=health_check, expected_type=type_hints["health_check"])
                check_type(argname="argument instances", value=instances, expected_type=type_hints["instances"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if d_ns_name is not None:
                self._values["d_ns_name"] = d_ns_name
            if health_check is not None:
                self._values["health_check"] = health_check
            if instances is not None:
                self._values["instances"] = instances

        @builtins.property
        def d_ns_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dNSName property.

            Specify an array of string values to match this event if the actual value of dNSName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("d_ns_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def health_check(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.HealthCheck"]:
            '''(experimental) healthCheck property.

            Specify an array of string values to match this event if the actual value of healthCheck is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("health_check")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.HealthCheck"], result)

        @builtins.property
        def instances(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.ResponseElementsItem"]]:
            '''(experimental) instances property.

            Specify an array of string values to match this event if the actual value of instances is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instances")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.ResponseElementsItem"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResponseElements(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail.ResponseElementsItem",
        jsii_struct_bases=[],
        name_mapping={"instance_id": "instanceId"},
    )
    class ResponseElementsItem:
        def __init__(
            self,
            *,
            instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResponseElementsItem.

            :param instance_id: (experimental) instanceId property. Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
                
                response_elements_item = elasticloadbalancing_events.AWSAPICallViaCloudTrail.ResponseElementsItem(
                    instance_id=["instanceId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__424b977a70427c191710d08daa53ea8c499e0fd431c09b5ab6009a2545eb262a)
                check_type(argname="argument instance_id", value=instance_id, expected_type=type_hints["instance_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if instance_id is not None:
                self._values["instance_id"] = instance_id

        @builtins.property
        def instance_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceId property.

            Specify an array of string values to match this event if the actual value of instanceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResponseElementsItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail.SessionContext",
        jsii_struct_bases=[],
        name_mapping={
            "attributes": "attributes",
            "session_issuer": "sessionIssuer",
            "web_id_federation_data": "webIdFederationData",
        },
    )
    class SessionContext:
        def __init__(
            self,
            *,
            attributes: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            session_issuer: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionIssuer", typing.Dict[builtins.str, typing.Any]]] = None,
            web_id_federation_data: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionContext.

            :param attributes: (experimental) attributes property. Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_issuer: (experimental) sessionIssuer property. Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param web_id_federation_data: (experimental) webIdFederationData property. Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
                
                session_context = elasticloadbalancing_events.AWSAPICallViaCloudTrail.SessionContext(
                    attributes=elasticloadbalancing_events.AWSAPICallViaCloudTrail.Attributes(
                        creation_date=["creationDate"],
                        mfa_authenticated=["mfaAuthenticated"]
                    ),
                    session_issuer=elasticloadbalancing_events.AWSAPICallViaCloudTrail.SessionIssuer(
                        account_id=["accountId"],
                        arn=["arn"],
                        principal_id=["principalId"],
                        type=["type"],
                        user_name=["userName"]
                    ),
                    web_id_federation_data=["webIdFederationData"]
                )
            '''
            if isinstance(attributes, dict):
                attributes = AWSAPICallViaCloudTrail.Attributes(**attributes)
            if isinstance(session_issuer, dict):
                session_issuer = AWSAPICallViaCloudTrail.SessionIssuer(**session_issuer)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2b9f141a172ad242487a149d07c19e226c1b330fb553352a883459190e10cac4)
                check_type(argname="argument attributes", value=attributes, expected_type=type_hints["attributes"])
                check_type(argname="argument session_issuer", value=session_issuer, expected_type=type_hints["session_issuer"])
                check_type(argname="argument web_id_federation_data", value=web_id_federation_data, expected_type=type_hints["web_id_federation_data"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attributes is not None:
                self._values["attributes"] = attributes
            if session_issuer is not None:
                self._values["session_issuer"] = session_issuer
            if web_id_federation_data is not None:
                self._values["web_id_federation_data"] = web_id_federation_data

        @builtins.property
        def attributes(self) -> typing.Optional["AWSAPICallViaCloudTrail.Attributes"]:
            '''(experimental) attributes property.

            Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attributes")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Attributes"], result)

        @builtins.property
        def session_issuer(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"]:
            '''(experimental) sessionIssuer property.

            Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_issuer")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"], result)

        @builtins.property
        def web_id_federation_data(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) webIdFederationData property.

            Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("web_id_federation_data")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionContext(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail.SessionIssuer",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "arn": "arn",
            "principal_id": "principalId",
            "type": "type",
            "user_name": "userName",
        },
    )
    class SessionIssuer:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionIssuer.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_name: (experimental) userName property. Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
                
                session_issuer = elasticloadbalancing_events.AWSAPICallViaCloudTrail.SessionIssuer(
                    account_id=["accountId"],
                    arn=["arn"],
                    principal_id=["principalId"],
                    type=["type"],
                    user_name=["userName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5155cd877da623fa8fb66b5729da0bcb5c52701e010efbb4e12b1bbf36d0b1af)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument user_name", value=user_name, expected_type=type_hints["user_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if type is not None:
                self._values["type"] = type
            if user_name is not None:
                self._values["user_name"] = user_name

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userName property.

            Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionIssuer(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_elasticloadbalancing.events.AWSAPICallViaCloudTrail.UserIdentity",
        jsii_struct_bases=[],
        name_mapping={
            "access_key_id": "accessKeyId",
            "account_id": "accountId",
            "arn": "arn",
            "invoked_by": "invokedBy",
            "principal_id": "principalId",
            "session_context": "sessionContext",
            "type": "type",
        },
    )
    class UserIdentity:
        def __init__(
            self,
            *,
            access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_context: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionContext", typing.Dict[builtins.str, typing.Any]]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for UserIdentity.

            :param access_key_id: (experimental) accessKeyId property. Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param invoked_by: (experimental) invokedBy property. Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_context: (experimental) sessionContext property. Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_elasticloadbalancing import events as elasticloadbalancing_events
                
                user_identity = elasticloadbalancing_events.AWSAPICallViaCloudTrail.UserIdentity(
                    access_key_id=["accessKeyId"],
                    account_id=["accountId"],
                    arn=["arn"],
                    invoked_by=["invokedBy"],
                    principal_id=["principalId"],
                    session_context=elasticloadbalancing_events.AWSAPICallViaCloudTrail.SessionContext(
                        attributes=elasticloadbalancing_events.AWSAPICallViaCloudTrail.Attributes(
                            creation_date=["creationDate"],
                            mfa_authenticated=["mfaAuthenticated"]
                        ),
                        session_issuer=elasticloadbalancing_events.AWSAPICallViaCloudTrail.SessionIssuer(
                            account_id=["accountId"],
                            arn=["arn"],
                            principal_id=["principalId"],
                            type=["type"],
                            user_name=["userName"]
                        ),
                        web_id_federation_data=["webIdFederationData"]
                    ),
                    type=["type"]
                )
            '''
            if isinstance(session_context, dict):
                session_context = AWSAPICallViaCloudTrail.SessionContext(**session_context)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1a06c20e223e6473ba25efe0a88fcb747bc95adb6b4cb09c6819d82f650cea2b)
                check_type(argname="argument access_key_id", value=access_key_id, expected_type=type_hints["access_key_id"])
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument invoked_by", value=invoked_by, expected_type=type_hints["invoked_by"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument session_context", value=session_context, expected_type=type_hints["session_context"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if access_key_id is not None:
                self._values["access_key_id"] = access_key_id
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if invoked_by is not None:
                self._values["invoked_by"] = invoked_by
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if session_context is not None:
                self._values["session_context"] = session_context
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def access_key_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accessKeyId property.

            Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("access_key_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def invoked_by(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) invokedBy property.

            Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("invoked_by")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_context(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionContext"]:
            '''(experimental) sessionContext property.

            Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_context")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionContext"], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "UserIdentity(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "AWSAPICallViaCloudTrail",
]

publication.publish()

def _typecheckingstub__62c05d5189b83aa2fc9d6d7554e569abf901571691a47d4a20d907f010774d9f(
    *,
    api_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_parameters: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.RequestParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    response_elements: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ResponseElements, typing.Dict[builtins.str, typing.Any]]] = None,
    source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_identity: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.UserIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__41c1e6ab2e1fb16d017398fdd8154d591672bf42d782330bae516e50be356551(
    *,
    creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8fd0744b5b7cf5761916fa196d5c61df3b82cc7987fa13a0561a120f0caac46b(
    *,
    healthy_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
    interval: typing.Optional[typing.Sequence[builtins.str]] = None,
    target: typing.Optional[typing.Sequence[builtins.str]] = None,
    timeout: typing.Optional[typing.Sequence[builtins.str]] = None,
    unhealthy_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__300b099434c24cc434b6f2e82282a1feaa188c29211bc795fae63e08e209c7f6(
    *,
    healthy_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
    interval: typing.Optional[typing.Sequence[builtins.str]] = None,
    target: typing.Optional[typing.Sequence[builtins.str]] = None,
    timeout: typing.Optional[typing.Sequence[builtins.str]] = None,
    unhealthy_threshold: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__431104780a5d9afdfc50008fad364ecc74cee077c6ef38236571e74477eaf158(
    *,
    health_check: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.HealthCheck1, typing.Dict[builtins.str, typing.Any]]] = None,
    instances: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.ResponseElementsItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    listeners: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.RequestParametersItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    load_balancer_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnets: typing.Optional[typing.Sequence[builtins.str]] = None,
    target_group_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    targets: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.RequestParametersItem1, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__71d5766f77a96a36d5ab28d526952d896f083c15ec1c3c024e72955fa4ad66bc(
    *,
    instance_port: typing.Optional[typing.Sequence[builtins.str]] = None,
    load_balancer_port: typing.Optional[typing.Sequence[builtins.str]] = None,
    protocol: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__51f5a81219be36c8859a50f7554c457729e4e476a7cb7bf4dcce6aa5787f06f5(
    *,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57ac4b4a272071b335d22ea2eb7081ac6ae13bf9c11bfaa4160d9985f82f4bb5(
    *,
    d_ns_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    health_check: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.HealthCheck, typing.Dict[builtins.str, typing.Any]]] = None,
    instances: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.ResponseElementsItem, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__424b977a70427c191710d08daa53ea8c499e0fd431c09b5ab6009a2545eb262a(
    *,
    instance_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2b9f141a172ad242487a149d07c19e226c1b330fb553352a883459190e10cac4(
    *,
    attributes: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    session_issuer: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionIssuer, typing.Dict[builtins.str, typing.Any]]] = None,
    web_id_federation_data: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5155cd877da623fa8fb66b5729da0bcb5c52701e010efbb4e12b1bbf36d0b1af(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1a06c20e223e6473ba25efe0a88fcb747bc95adb6b4cb09c6819d82f650cea2b(
    *,
    access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_context: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionContext, typing.Dict[builtins.str, typing.Any]]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
