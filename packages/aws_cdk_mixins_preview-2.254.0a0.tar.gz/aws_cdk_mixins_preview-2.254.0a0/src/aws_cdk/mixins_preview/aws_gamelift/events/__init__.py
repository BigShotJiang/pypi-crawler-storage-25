from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class GameLiftMatchmakingEvent(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_gamelift.events.GameLiftMatchmakingEvent",
):
    '''(experimental) EventBridge event pattern for aws.gamelift@GameLiftMatchmakingEvent.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_gamelift import events as gamelift_events
        
        game_lift_matchmaking_event = gamelift_events.GameLiftMatchmakingEvent()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        acceptance_required: typing.Optional[typing.Sequence[builtins.str]] = None,
        acceptance_timeout: typing.Optional[typing.Sequence[builtins.str]] = None,
        custom_event_data: typing.Optional[typing.Sequence[builtins.str]] = None,
        estimated_wait_millis: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        game_session_info: typing.Optional[typing.Union["GameLiftMatchmakingEvent.GameSessionInfo", typing.Dict[builtins.str, typing.Any]]] = None,
        match_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        reason: typing.Optional[typing.Sequence[builtins.str]] = None,
        rule_evaluation_metrics: typing.Optional[typing.Sequence[typing.Union["GameLiftMatchmakingEvent.RuleEvaluationMetrics", typing.Dict[builtins.str, typing.Any]]]] = None,
        tickets: typing.Optional[typing.Sequence[typing.Union["GameLiftMatchmakingEvent.Ticket", typing.Dict[builtins.str, typing.Any]]]] = None,
        type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for GameLift Matchmaking Event.

        :param acceptance_required: (experimental) acceptanceRequired property. Specify an array of string values to match this event if the actual value of acceptanceRequired is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param acceptance_timeout: (experimental) acceptanceTimeout property. Specify an array of string values to match this event if the actual value of acceptanceTimeout is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param custom_event_data: (experimental) customEventData property. Specify an array of string values to match this event if the actual value of customEventData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param estimated_wait_millis: (experimental) estimatedWaitMillis property. Specify an array of string values to match this event if the actual value of estimatedWaitMillis is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param game_session_info: (experimental) gameSessionInfo property. Specify an array of string values to match this event if the actual value of gameSessionInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param match_id: (experimental) matchId property. Specify an array of string values to match this event if the actual value of matchId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param reason: (experimental) reason property. Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param rule_evaluation_metrics: (experimental) ruleEvaluationMetrics property. Specify an array of string values to match this event if the actual value of ruleEvaluationMetrics is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tickets: (experimental) tickets property. Specify an array of string values to match this event if the actual value of tickets is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = GameLiftMatchmakingEvent.GameLiftMatchmakingEventProps(
            acceptance_required=acceptance_required,
            acceptance_timeout=acceptance_timeout,
            custom_event_data=custom_event_data,
            estimated_wait_millis=estimated_wait_millis,
            event_metadata=event_metadata,
            game_session_info=game_session_info,
            match_id=match_id,
            message=message,
            reason=reason,
            rule_evaluation_metrics=rule_evaluation_metrics,
            tickets=tickets,
            type=type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_gamelift.events.GameLiftMatchmakingEvent.GameLiftMatchmakingEventProps",
        jsii_struct_bases=[],
        name_mapping={
            "acceptance_required": "acceptanceRequired",
            "acceptance_timeout": "acceptanceTimeout",
            "custom_event_data": "customEventData",
            "estimated_wait_millis": "estimatedWaitMillis",
            "event_metadata": "eventMetadata",
            "game_session_info": "gameSessionInfo",
            "match_id": "matchId",
            "message": "message",
            "reason": "reason",
            "rule_evaluation_metrics": "ruleEvaluationMetrics",
            "tickets": "tickets",
            "type": "type",
        },
    )
    class GameLiftMatchmakingEventProps:
        def __init__(
            self,
            *,
            acceptance_required: typing.Optional[typing.Sequence[builtins.str]] = None,
            acceptance_timeout: typing.Optional[typing.Sequence[builtins.str]] = None,
            custom_event_data: typing.Optional[typing.Sequence[builtins.str]] = None,
            estimated_wait_millis: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            game_session_info: typing.Optional[typing.Union["GameLiftMatchmakingEvent.GameSessionInfo", typing.Dict[builtins.str, typing.Any]]] = None,
            match_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            reason: typing.Optional[typing.Sequence[builtins.str]] = None,
            rule_evaluation_metrics: typing.Optional[typing.Sequence[typing.Union["GameLiftMatchmakingEvent.RuleEvaluationMetrics", typing.Dict[builtins.str, typing.Any]]]] = None,
            tickets: typing.Optional[typing.Sequence[typing.Union["GameLiftMatchmakingEvent.Ticket", typing.Dict[builtins.str, typing.Any]]]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.gamelift@GameLiftMatchmakingEvent event.

            :param acceptance_required: (experimental) acceptanceRequired property. Specify an array of string values to match this event if the actual value of acceptanceRequired is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param acceptance_timeout: (experimental) acceptanceTimeout property. Specify an array of string values to match this event if the actual value of acceptanceTimeout is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param custom_event_data: (experimental) customEventData property. Specify an array of string values to match this event if the actual value of customEventData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param estimated_wait_millis: (experimental) estimatedWaitMillis property. Specify an array of string values to match this event if the actual value of estimatedWaitMillis is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param game_session_info: (experimental) gameSessionInfo property. Specify an array of string values to match this event if the actual value of gameSessionInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param match_id: (experimental) matchId property. Specify an array of string values to match this event if the actual value of matchId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param reason: (experimental) reason property. Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param rule_evaluation_metrics: (experimental) ruleEvaluationMetrics property. Specify an array of string values to match this event if the actual value of ruleEvaluationMetrics is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tickets: (experimental) tickets property. Specify an array of string values to match this event if the actual value of tickets is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_gamelift import events as gamelift_events
                
                game_lift_matchmaking_event_props = gamelift_events.GameLiftMatchmakingEvent.GameLiftMatchmakingEventProps(
                    acceptance_required=["acceptanceRequired"],
                    acceptance_timeout=["acceptanceTimeout"],
                    custom_event_data=["customEventData"],
                    estimated_wait_millis=["estimatedWaitMillis"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    game_session_info=gamelift_events.GameLiftMatchmakingEvent.GameSessionInfo(
                        game_session_arn=["gameSessionArn"],
                        ip_address=["ipAddress"],
                        players=[gamelift_events.GameLiftMatchmakingEvent.GameSessionInfoItem(
                            player_id=["playerId"],
                            team=["team"]
                        )],
                        port=["port"]
                    ),
                    match_id=["matchId"],
                    message=["message"],
                    reason=["reason"],
                    rule_evaluation_metrics=[gamelift_events.GameLiftMatchmakingEvent.RuleEvaluationMetrics(
                        failed_count=["failedCount"],
                        passed_count=["passedCount"],
                        rule_name=["ruleName"]
                    )],
                    tickets=[gamelift_events.GameLiftMatchmakingEvent.Ticket(
                        players=[gamelift_events.GameLiftMatchmakingEvent.GameSessionInfoItem(
                            player_id=["playerId"],
                            team=["team"]
                        )],
                        start_time=["startTime"],
                        ticket_id=["ticketId"]
                    )],
                    type=["type"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(game_session_info, dict):
                game_session_info = GameLiftMatchmakingEvent.GameSessionInfo(**game_session_info)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f7b85c27979580cef11acea9409294c2c59a840b31409d151054c34bc7b9aaa8)
                check_type(argname="argument acceptance_required", value=acceptance_required, expected_type=type_hints["acceptance_required"])
                check_type(argname="argument acceptance_timeout", value=acceptance_timeout, expected_type=type_hints["acceptance_timeout"])
                check_type(argname="argument custom_event_data", value=custom_event_data, expected_type=type_hints["custom_event_data"])
                check_type(argname="argument estimated_wait_millis", value=estimated_wait_millis, expected_type=type_hints["estimated_wait_millis"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument game_session_info", value=game_session_info, expected_type=type_hints["game_session_info"])
                check_type(argname="argument match_id", value=match_id, expected_type=type_hints["match_id"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument reason", value=reason, expected_type=type_hints["reason"])
                check_type(argname="argument rule_evaluation_metrics", value=rule_evaluation_metrics, expected_type=type_hints["rule_evaluation_metrics"])
                check_type(argname="argument tickets", value=tickets, expected_type=type_hints["tickets"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if acceptance_required is not None:
                self._values["acceptance_required"] = acceptance_required
            if acceptance_timeout is not None:
                self._values["acceptance_timeout"] = acceptance_timeout
            if custom_event_data is not None:
                self._values["custom_event_data"] = custom_event_data
            if estimated_wait_millis is not None:
                self._values["estimated_wait_millis"] = estimated_wait_millis
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if game_session_info is not None:
                self._values["game_session_info"] = game_session_info
            if match_id is not None:
                self._values["match_id"] = match_id
            if message is not None:
                self._values["message"] = message
            if reason is not None:
                self._values["reason"] = reason
            if rule_evaluation_metrics is not None:
                self._values["rule_evaluation_metrics"] = rule_evaluation_metrics
            if tickets is not None:
                self._values["tickets"] = tickets
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def acceptance_required(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) acceptanceRequired property.

            Specify an array of string values to match this event if the actual value of acceptanceRequired is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("acceptance_required")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def acceptance_timeout(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) acceptanceTimeout property.

            Specify an array of string values to match this event if the actual value of acceptanceTimeout is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("acceptance_timeout")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def custom_event_data(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) customEventData property.

            Specify an array of string values to match this event if the actual value of customEventData is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("custom_event_data")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def estimated_wait_millis(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) estimatedWaitMillis property.

            Specify an array of string values to match this event if the actual value of estimatedWaitMillis is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("estimated_wait_millis")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def game_session_info(
            self,
        ) -> typing.Optional["GameLiftMatchmakingEvent.GameSessionInfo"]:
            '''(experimental) gameSessionInfo property.

            Specify an array of string values to match this event if the actual value of gameSessionInfo is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("game_session_info")
            return typing.cast(typing.Optional["GameLiftMatchmakingEvent.GameSessionInfo"], result)

        @builtins.property
        def match_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) matchId property.

            Specify an array of string values to match this event if the actual value of matchId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("match_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) reason property.

            Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def rule_evaluation_metrics(
            self,
        ) -> typing.Optional[typing.List["GameLiftMatchmakingEvent.RuleEvaluationMetrics"]]:
            '''(experimental) ruleEvaluationMetrics property.

            Specify an array of string values to match this event if the actual value of ruleEvaluationMetrics is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("rule_evaluation_metrics")
            return typing.cast(typing.Optional[typing.List["GameLiftMatchmakingEvent.RuleEvaluationMetrics"]], result)

        @builtins.property
        def tickets(
            self,
        ) -> typing.Optional[typing.List["GameLiftMatchmakingEvent.Ticket"]]:
            '''(experimental) tickets property.

            Specify an array of string values to match this event if the actual value of tickets is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tickets")
            return typing.cast(typing.Optional[typing.List["GameLiftMatchmakingEvent.Ticket"]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GameLiftMatchmakingEventProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_gamelift.events.GameLiftMatchmakingEvent.GameSessionInfo",
        jsii_struct_bases=[],
        name_mapping={
            "game_session_arn": "gameSessionArn",
            "ip_address": "ipAddress",
            "players": "players",
            "port": "port",
        },
    )
    class GameSessionInfo:
        def __init__(
            self,
            *,
            game_session_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            players: typing.Optional[typing.Sequence[typing.Union["GameLiftMatchmakingEvent.GameSessionInfoItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            port: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for GameSessionInfo.

            :param game_session_arn: (experimental) gameSessionArn property. Specify an array of string values to match this event if the actual value of gameSessionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ip_address: (experimental) ipAddress property. Specify an array of string values to match this event if the actual value of ipAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param players: (experimental) players property. Specify an array of string values to match this event if the actual value of players is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param port: (experimental) port property. Specify an array of string values to match this event if the actual value of port is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_gamelift import events as gamelift_events
                
                game_session_info = gamelift_events.GameLiftMatchmakingEvent.GameSessionInfo(
                    game_session_arn=["gameSessionArn"],
                    ip_address=["ipAddress"],
                    players=[gamelift_events.GameLiftMatchmakingEvent.GameSessionInfoItem(
                        player_id=["playerId"],
                        team=["team"]
                    )],
                    port=["port"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__50e91df6a158fcfcb36c2daec6e4df6fe7fc57e1f2eb2384aa2237cd991a9490)
                check_type(argname="argument game_session_arn", value=game_session_arn, expected_type=type_hints["game_session_arn"])
                check_type(argname="argument ip_address", value=ip_address, expected_type=type_hints["ip_address"])
                check_type(argname="argument players", value=players, expected_type=type_hints["players"])
                check_type(argname="argument port", value=port, expected_type=type_hints["port"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if game_session_arn is not None:
                self._values["game_session_arn"] = game_session_arn
            if ip_address is not None:
                self._values["ip_address"] = ip_address
            if players is not None:
                self._values["players"] = players
            if port is not None:
                self._values["port"] = port

        @builtins.property
        def game_session_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) gameSessionArn property.

            Specify an array of string values to match this event if the actual value of gameSessionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("game_session_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ipAddress property.

            Specify an array of string values to match this event if the actual value of ipAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def players(
            self,
        ) -> typing.Optional[typing.List["GameLiftMatchmakingEvent.GameSessionInfoItem"]]:
            '''(experimental) players property.

            Specify an array of string values to match this event if the actual value of players is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("players")
            return typing.cast(typing.Optional[typing.List["GameLiftMatchmakingEvent.GameSessionInfoItem"]], result)

        @builtins.property
        def port(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) port property.

            Specify an array of string values to match this event if the actual value of port is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("port")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GameSessionInfo(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_gamelift.events.GameLiftMatchmakingEvent.GameSessionInfoItem",
        jsii_struct_bases=[],
        name_mapping={"player_id": "playerId", "team": "team"},
    )
    class GameSessionInfoItem:
        def __init__(
            self,
            *,
            player_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            team: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for GameSessionInfoItem.

            :param player_id: (experimental) playerId property. Specify an array of string values to match this event if the actual value of playerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param team: (experimental) team property. Specify an array of string values to match this event if the actual value of team is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_gamelift import events as gamelift_events
                
                game_session_info_item = gamelift_events.GameLiftMatchmakingEvent.GameSessionInfoItem(
                    player_id=["playerId"],
                    team=["team"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__741cbee963b7b0d5a967ae532af95ff935c32de3a74e08846a00e778c3f681a4)
                check_type(argname="argument player_id", value=player_id, expected_type=type_hints["player_id"])
                check_type(argname="argument team", value=team, expected_type=type_hints["team"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if player_id is not None:
                self._values["player_id"] = player_id
            if team is not None:
                self._values["team"] = team

        @builtins.property
        def player_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) playerId property.

            Specify an array of string values to match this event if the actual value of playerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("player_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def team(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) team property.

            Specify an array of string values to match this event if the actual value of team is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("team")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GameSessionInfoItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_gamelift.events.GameLiftMatchmakingEvent.RuleEvaluationMetrics",
        jsii_struct_bases=[],
        name_mapping={
            "failed_count": "failedCount",
            "passed_count": "passedCount",
            "rule_name": "ruleName",
        },
    )
    class RuleEvaluationMetrics:
        def __init__(
            self,
            *,
            failed_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            passed_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            rule_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RuleEvaluationMetrics.

            :param failed_count: (experimental) failedCount property. Specify an array of string values to match this event if the actual value of failedCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param passed_count: (experimental) passedCount property. Specify an array of string values to match this event if the actual value of passedCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param rule_name: (experimental) ruleName property. Specify an array of string values to match this event if the actual value of ruleName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_gamelift import events as gamelift_events
                
                rule_evaluation_metrics = gamelift_events.GameLiftMatchmakingEvent.RuleEvaluationMetrics(
                    failed_count=["failedCount"],
                    passed_count=["passedCount"],
                    rule_name=["ruleName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d553343539da0e4cf956ee75df3ed72df70fa8dc7d09a62bf73bc0a34075e256)
                check_type(argname="argument failed_count", value=failed_count, expected_type=type_hints["failed_count"])
                check_type(argname="argument passed_count", value=passed_count, expected_type=type_hints["passed_count"])
                check_type(argname="argument rule_name", value=rule_name, expected_type=type_hints["rule_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if failed_count is not None:
                self._values["failed_count"] = failed_count
            if passed_count is not None:
                self._values["passed_count"] = passed_count
            if rule_name is not None:
                self._values["rule_name"] = rule_name

        @builtins.property
        def failed_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) failedCount property.

            Specify an array of string values to match this event if the actual value of failedCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("failed_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def passed_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) passedCount property.

            Specify an array of string values to match this event if the actual value of passedCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("passed_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def rule_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ruleName property.

            Specify an array of string values to match this event if the actual value of ruleName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("rule_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RuleEvaluationMetrics(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_gamelift.events.GameLiftMatchmakingEvent.Ticket",
        jsii_struct_bases=[],
        name_mapping={
            "players": "players",
            "start_time": "startTime",
            "ticket_id": "ticketId",
        },
    )
    class Ticket:
        def __init__(
            self,
            *,
            players: typing.Optional[typing.Sequence[typing.Union["GameLiftMatchmakingEvent.GameSessionInfoItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            ticket_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Ticket.

            :param players: (experimental) players property. Specify an array of string values to match this event if the actual value of players is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ticket_id: (experimental) ticketId property. Specify an array of string values to match this event if the actual value of ticketId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_gamelift import events as gamelift_events
                
                ticket = gamelift_events.GameLiftMatchmakingEvent.Ticket(
                    players=[gamelift_events.GameLiftMatchmakingEvent.GameSessionInfoItem(
                        player_id=["playerId"],
                        team=["team"]
                    )],
                    start_time=["startTime"],
                    ticket_id=["ticketId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a4280d1a7a268b889a3baebe329db3a048e7201aba8606e81923aa737768262d)
                check_type(argname="argument players", value=players, expected_type=type_hints["players"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument ticket_id", value=ticket_id, expected_type=type_hints["ticket_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if players is not None:
                self._values["players"] = players
            if start_time is not None:
                self._values["start_time"] = start_time
            if ticket_id is not None:
                self._values["ticket_id"] = ticket_id

        @builtins.property
        def players(
            self,
        ) -> typing.Optional[typing.List["GameLiftMatchmakingEvent.GameSessionInfoItem"]]:
            '''(experimental) players property.

            Specify an array of string values to match this event if the actual value of players is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("players")
            return typing.cast(typing.Optional[typing.List["GameLiftMatchmakingEvent.GameSessionInfoItem"]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ticket_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ticketId property.

            Specify an array of string values to match this event if the actual value of ticketId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ticket_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Ticket(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class GameLiftQueuePlacementEvent(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_gamelift.events.GameLiftQueuePlacementEvent",
):
    '''(experimental) EventBridge event pattern for aws.gamelift@GameLiftQueuePlacementEvent.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_gamelift import events as gamelift_events
        
        game_lift_queue_placement_event = gamelift_events.GameLiftQueuePlacementEvent()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        dns_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        game_session_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        game_session_region: typing.Optional[typing.Sequence[builtins.str]] = None,
        ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        placed_player_sessions: typing.Optional[typing.Sequence[typing.Union["GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        placement_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        port: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for GameLift Queue Placement Event.

        :param dns_name: (experimental) dnsName property. Specify an array of string values to match this event if the actual value of dnsName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param game_session_arn: (experimental) gameSessionArn property. Specify an array of string values to match this event if the actual value of gameSessionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param game_session_region: (experimental) gameSessionRegion property. Specify an array of string values to match this event if the actual value of gameSessionRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param ip_address: (experimental) ipAddress property. Specify an array of string values to match this event if the actual value of ipAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param placed_player_sessions: (experimental) placedPlayerSessions property. Specify an array of string values to match this event if the actual value of placedPlayerSessions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param placement_id: (experimental) placementId property. Specify an array of string values to match this event if the actual value of placementId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param port: (experimental) port property. Specify an array of string values to match this event if the actual value of port is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventProps(
            dns_name=dns_name,
            end_time=end_time,
            event_metadata=event_metadata,
            game_session_arn=game_session_arn,
            game_session_region=game_session_region,
            ip_address=ip_address,
            placed_player_sessions=placed_player_sessions,
            placement_id=placement_id,
            port=port,
            start_time=start_time,
            type=type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_gamelift.events.GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventItem",
        jsii_struct_bases=[],
        name_mapping={"player_id": "playerId", "player_session_id": "playerSessionId"},
    )
    class GameLiftQueuePlacementEventItem:
        def __init__(
            self,
            *,
            player_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            player_session_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for GameLiftQueuePlacementEventItem.

            :param player_id: (experimental) playerId property. Specify an array of string values to match this event if the actual value of playerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param player_session_id: (experimental) playerSessionId property. Specify an array of string values to match this event if the actual value of playerSessionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_gamelift import events as gamelift_events
                
                game_lift_queue_placement_event_item = gamelift_events.GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventItem(
                    player_id=["playerId"],
                    player_session_id=["playerSessionId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1ef15356d2fba4523938d5a7143a3a9bef2784c67cab668faea52c538576a414)
                check_type(argname="argument player_id", value=player_id, expected_type=type_hints["player_id"])
                check_type(argname="argument player_session_id", value=player_session_id, expected_type=type_hints["player_session_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if player_id is not None:
                self._values["player_id"] = player_id
            if player_session_id is not None:
                self._values["player_session_id"] = player_session_id

        @builtins.property
        def player_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) playerId property.

            Specify an array of string values to match this event if the actual value of playerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("player_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def player_session_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) playerSessionId property.

            Specify an array of string values to match this event if the actual value of playerSessionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("player_session_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GameLiftQueuePlacementEventItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_gamelift.events.GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventProps",
        jsii_struct_bases=[],
        name_mapping={
            "dns_name": "dnsName",
            "end_time": "endTime",
            "event_metadata": "eventMetadata",
            "game_session_arn": "gameSessionArn",
            "game_session_region": "gameSessionRegion",
            "ip_address": "ipAddress",
            "placed_player_sessions": "placedPlayerSessions",
            "placement_id": "placementId",
            "port": "port",
            "start_time": "startTime",
            "type": "type",
        },
    )
    class GameLiftQueuePlacementEventProps:
        def __init__(
            self,
            *,
            dns_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            game_session_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            game_session_region: typing.Optional[typing.Sequence[builtins.str]] = None,
            ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            placed_player_sessions: typing.Optional[typing.Sequence[typing.Union["GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            placement_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            port: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.gamelift@GameLiftQueuePlacementEvent event.

            :param dns_name: (experimental) dnsName property. Specify an array of string values to match this event if the actual value of dnsName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param game_session_arn: (experimental) gameSessionArn property. Specify an array of string values to match this event if the actual value of gameSessionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param game_session_region: (experimental) gameSessionRegion property. Specify an array of string values to match this event if the actual value of gameSessionRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param ip_address: (experimental) ipAddress property. Specify an array of string values to match this event if the actual value of ipAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param placed_player_sessions: (experimental) placedPlayerSessions property. Specify an array of string values to match this event if the actual value of placedPlayerSessions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param placement_id: (experimental) placementId property. Specify an array of string values to match this event if the actual value of placementId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param port: (experimental) port property. Specify an array of string values to match this event if the actual value of port is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_gamelift import events as gamelift_events
                
                game_lift_queue_placement_event_props = gamelift_events.GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventProps(
                    dns_name=["dnsName"],
                    end_time=["endTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    game_session_arn=["gameSessionArn"],
                    game_session_region=["gameSessionRegion"],
                    ip_address=["ipAddress"],
                    placed_player_sessions=[gamelift_events.GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventItem(
                        player_id=["playerId"],
                        player_session_id=["playerSessionId"]
                    )],
                    placement_id=["placementId"],
                    port=["port"],
                    start_time=["startTime"],
                    type=["type"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ad809f2b823ff56c7a3e101e7dd07ccd093d059a39c5a67cd7cd34f0c6ccf71b)
                check_type(argname="argument dns_name", value=dns_name, expected_type=type_hints["dns_name"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument game_session_arn", value=game_session_arn, expected_type=type_hints["game_session_arn"])
                check_type(argname="argument game_session_region", value=game_session_region, expected_type=type_hints["game_session_region"])
                check_type(argname="argument ip_address", value=ip_address, expected_type=type_hints["ip_address"])
                check_type(argname="argument placed_player_sessions", value=placed_player_sessions, expected_type=type_hints["placed_player_sessions"])
                check_type(argname="argument placement_id", value=placement_id, expected_type=type_hints["placement_id"])
                check_type(argname="argument port", value=port, expected_type=type_hints["port"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if dns_name is not None:
                self._values["dns_name"] = dns_name
            if end_time is not None:
                self._values["end_time"] = end_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if game_session_arn is not None:
                self._values["game_session_arn"] = game_session_arn
            if game_session_region is not None:
                self._values["game_session_region"] = game_session_region
            if ip_address is not None:
                self._values["ip_address"] = ip_address
            if placed_player_sessions is not None:
                self._values["placed_player_sessions"] = placed_player_sessions
            if placement_id is not None:
                self._values["placement_id"] = placement_id
            if port is not None:
                self._values["port"] = port
            if start_time is not None:
                self._values["start_time"] = start_time
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def dns_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) dnsName property.

            Specify an array of string values to match this event if the actual value of dnsName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("dns_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTime property.

            Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def game_session_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) gameSessionArn property.

            Specify an array of string values to match this event if the actual value of gameSessionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("game_session_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def game_session_region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) gameSessionRegion property.

            Specify an array of string values to match this event if the actual value of gameSessionRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("game_session_region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ipAddress property.

            Specify an array of string values to match this event if the actual value of ipAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def placed_player_sessions(
            self,
        ) -> typing.Optional[typing.List["GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventItem"]]:
            '''(experimental) placedPlayerSessions property.

            Specify an array of string values to match this event if the actual value of placedPlayerSessions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("placed_player_sessions")
            return typing.cast(typing.Optional[typing.List["GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventItem"]], result)

        @builtins.property
        def placement_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) placementId property.

            Specify an array of string values to match this event if the actual value of placementId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("placement_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def port(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) port property.

            Specify an array of string values to match this event if the actual value of port is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("port")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GameLiftQueuePlacementEventProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "GameLiftMatchmakingEvent",
    "GameLiftQueuePlacementEvent",
]

publication.publish()

def _typecheckingstub__f7b85c27979580cef11acea9409294c2c59a840b31409d151054c34bc7b9aaa8(
    *,
    acceptance_required: typing.Optional[typing.Sequence[builtins.str]] = None,
    acceptance_timeout: typing.Optional[typing.Sequence[builtins.str]] = None,
    custom_event_data: typing.Optional[typing.Sequence[builtins.str]] = None,
    estimated_wait_millis: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    game_session_info: typing.Optional[typing.Union[GameLiftMatchmakingEvent.GameSessionInfo, typing.Dict[builtins.str, typing.Any]]] = None,
    match_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    rule_evaluation_metrics: typing.Optional[typing.Sequence[typing.Union[GameLiftMatchmakingEvent.RuleEvaluationMetrics, typing.Dict[builtins.str, typing.Any]]]] = None,
    tickets: typing.Optional[typing.Sequence[typing.Union[GameLiftMatchmakingEvent.Ticket, typing.Dict[builtins.str, typing.Any]]]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__50e91df6a158fcfcb36c2daec6e4df6fe7fc57e1f2eb2384aa2237cd991a9490(
    *,
    game_session_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    players: typing.Optional[typing.Sequence[typing.Union[GameLiftMatchmakingEvent.GameSessionInfoItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    port: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__741cbee963b7b0d5a967ae532af95ff935c32de3a74e08846a00e778c3f681a4(
    *,
    player_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    team: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d553343539da0e4cf956ee75df3ed72df70fa8dc7d09a62bf73bc0a34075e256(
    *,
    failed_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    passed_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    rule_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a4280d1a7a268b889a3baebe329db3a048e7201aba8606e81923aa737768262d(
    *,
    players: typing.Optional[typing.Sequence[typing.Union[GameLiftMatchmakingEvent.GameSessionInfoItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ticket_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1ef15356d2fba4523938d5a7143a3a9bef2784c67cab668faea52c538576a414(
    *,
    player_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    player_session_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ad809f2b823ff56c7a3e101e7dd07ccd093d059a39c5a67cd7cd34f0c6ccf71b(
    *,
    dns_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    game_session_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    game_session_region: typing.Optional[typing.Sequence[builtins.str]] = None,
    ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    placed_player_sessions: typing.Optional[typing.Sequence[typing.Union[GameLiftQueuePlacementEvent.GameLiftQueuePlacementEventItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    placement_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    port: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
