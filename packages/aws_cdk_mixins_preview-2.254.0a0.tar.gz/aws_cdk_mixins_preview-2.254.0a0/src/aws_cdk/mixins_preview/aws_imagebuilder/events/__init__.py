from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class EC2ImageBuilderCVEDetected(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_imagebuilder.events.EC2ImageBuilderCVEDetected",
):
    '''(experimental) EventBridge event pattern for aws.imagebuilder@EC2ImageBuilderCVEDetected.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_imagebuilder import events as imagebuilder_events
        
        e_c2_image_builder_cVEDetected = imagebuilder_events.EC2ImageBuilderCVEDetected()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        finding_severity_counts: typing.Optional[typing.Union["EC2ImageBuilderCVEDetected.FindingSeverityCounts", typing.Dict[builtins.str, typing.Any]]] = None,
        resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EC2 Image Builder CVE Detected.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param finding_severity_counts: (experimental) finding-severity-counts property. Specify an array of string values to match this event if the actual value of finding-severity-counts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resource_id: (experimental) resource-id property. Specify an array of string values to match this event if the actual value of resource-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2ImageBuilderCVEDetected.EC2ImageBuilderCVEDetectedProps(
            event_metadata=event_metadata,
            finding_severity_counts=finding_severity_counts,
            resource_id=resource_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_imagebuilder.events.EC2ImageBuilderCVEDetected.EC2ImageBuilderCVEDetectedProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "finding_severity_counts": "findingSeverityCounts",
            "resource_id": "resourceId",
        },
    )
    class EC2ImageBuilderCVEDetectedProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            finding_severity_counts: typing.Optional[typing.Union["EC2ImageBuilderCVEDetected.FindingSeverityCounts", typing.Dict[builtins.str, typing.Any]]] = None,
            resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.imagebuilder@EC2ImageBuilderCVEDetected event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param finding_severity_counts: (experimental) finding-severity-counts property. Specify an array of string values to match this event if the actual value of finding-severity-counts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_id: (experimental) resource-id property. Specify an array of string values to match this event if the actual value of resource-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_imagebuilder import events as imagebuilder_events
                
                e_c2_image_builder_cVEDetected_props = imagebuilder_events.EC2ImageBuilderCVEDetected.EC2ImageBuilderCVEDetectedProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    finding_severity_counts=imagebuilder_events.EC2ImageBuilderCVEDetected.FindingSeverityCounts(
                        all=["all"],
                        critical=["critical"],
                        high=["high"],
                        medium=["medium"]
                    ),
                    resource_id=["resourceId"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(finding_severity_counts, dict):
                finding_severity_counts = EC2ImageBuilderCVEDetected.FindingSeverityCounts(**finding_severity_counts)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__471f689739de4bc394feeadd30dd178e7fc21d52ad84019c804a90dae1bc2c82)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument finding_severity_counts", value=finding_severity_counts, expected_type=type_hints["finding_severity_counts"])
                check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if finding_severity_counts is not None:
                self._values["finding_severity_counts"] = finding_severity_counts
            if resource_id is not None:
                self._values["resource_id"] = resource_id

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def finding_severity_counts(
            self,
        ) -> typing.Optional["EC2ImageBuilderCVEDetected.FindingSeverityCounts"]:
            '''(experimental) finding-severity-counts property.

            Specify an array of string values to match this event if the actual value of finding-severity-counts is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("finding_severity_counts")
            return typing.cast(typing.Optional["EC2ImageBuilderCVEDetected.FindingSeverityCounts"], result)

        @builtins.property
        def resource_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resource-id property.

            Specify an array of string values to match this event if the actual value of resource-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EC2ImageBuilderCVEDetectedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_imagebuilder.events.EC2ImageBuilderCVEDetected.FindingSeverityCounts",
        jsii_struct_bases=[],
        name_mapping={
            "all": "all",
            "critical": "critical",
            "high": "high",
            "medium": "medium",
        },
    )
    class FindingSeverityCounts:
        def __init__(
            self,
            *,
            all: typing.Optional[typing.Sequence[builtins.str]] = None,
            critical: typing.Optional[typing.Sequence[builtins.str]] = None,
            high: typing.Optional[typing.Sequence[builtins.str]] = None,
            medium: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Finding-severity-counts.

            :param all: (experimental) all property. Specify an array of string values to match this event if the actual value of all is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param critical: (experimental) critical property. Specify an array of string values to match this event if the actual value of critical is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param high: (experimental) high property. Specify an array of string values to match this event if the actual value of high is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param medium: (experimental) medium property. Specify an array of string values to match this event if the actual value of medium is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_imagebuilder import events as imagebuilder_events
                
                finding_severity_counts = imagebuilder_events.EC2ImageBuilderCVEDetected.FindingSeverityCounts(
                    all=["all"],
                    critical=["critical"],
                    high=["high"],
                    medium=["medium"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4d3cc4c707b08e95f56a7e3f3d8d1639084c9456b6d56d0e577971d728900ff7)
                check_type(argname="argument all", value=all, expected_type=type_hints["all"])
                check_type(argname="argument critical", value=critical, expected_type=type_hints["critical"])
                check_type(argname="argument high", value=high, expected_type=type_hints["high"])
                check_type(argname="argument medium", value=medium, expected_type=type_hints["medium"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if all is not None:
                self._values["all"] = all
            if critical is not None:
                self._values["critical"] = critical
            if high is not None:
                self._values["high"] = high
            if medium is not None:
                self._values["medium"] = medium

        @builtins.property
        def all(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) all property.

            Specify an array of string values to match this event if the actual value of all is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("all")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def critical(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) critical property.

            Specify an array of string values to match this event if the actual value of critical is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("critical")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def high(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) high property.

            Specify an array of string values to match this event if the actual value of high is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("high")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def medium(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) medium property.

            Specify an array of string values to match this event if the actual value of medium is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("medium")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "FindingSeverityCounts(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EC2ImageBuilderImageStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_imagebuilder.events.EC2ImageBuilderImageStateChange",
):
    '''(experimental) EventBridge event pattern for aws.imagebuilder@EC2ImageBuilderImageStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_imagebuilder import events as imagebuilder_events
        
        e_c2_image_builder_image_state_change = imagebuilder_events.EC2ImageBuilderImageStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        previous_state: typing.Optional[typing.Union["EC2ImageBuilderImageStateChange.ImageState", typing.Dict[builtins.str, typing.Any]]] = None,
        state: typing.Optional[typing.Union["EC2ImageBuilderImageStateChange.ImageState", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EC2 Image Builder Image State Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param previous_state: (experimental) previous-state property. Specify an array of string values to match this event if the actual value of previous-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2ImageBuilderImageStateChange.EC2ImageBuilderImageStateChangeProps(
            event_metadata=event_metadata, previous_state=previous_state, state=state
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_imagebuilder.events.EC2ImageBuilderImageStateChange.EC2ImageBuilderImageStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "previous_state": "previousState",
            "state": "state",
        },
    )
    class EC2ImageBuilderImageStateChangeProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            previous_state: typing.Optional[typing.Union["EC2ImageBuilderImageStateChange.ImageState", typing.Dict[builtins.str, typing.Any]]] = None,
            state: typing.Optional[typing.Union["EC2ImageBuilderImageStateChange.ImageState", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.imagebuilder@EC2ImageBuilderImageStateChange event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param previous_state: (experimental) previous-state property. Specify an array of string values to match this event if the actual value of previous-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_imagebuilder import events as imagebuilder_events
                
                e_c2_image_builder_image_state_change_props = imagebuilder_events.EC2ImageBuilderImageStateChange.EC2ImageBuilderImageStateChangeProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    previous_state=imagebuilder_events.EC2ImageBuilderImageStateChange.ImageState(
                        reason=["reason"],
                        status=["status"]
                    ),
                    state=imagebuilder_events.EC2ImageBuilderImageStateChange.ImageState(
                        reason=["reason"],
                        status=["status"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(previous_state, dict):
                previous_state = EC2ImageBuilderImageStateChange.ImageState(**previous_state)
            if isinstance(state, dict):
                state = EC2ImageBuilderImageStateChange.ImageState(**state)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b26d2bf515bcb3e87804ed95e6e69865adf4ef3fda81facff235471df75ef365)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument previous_state", value=previous_state, expected_type=type_hints["previous_state"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if previous_state is not None:
                self._values["previous_state"] = previous_state
            if state is not None:
                self._values["state"] = state

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def previous_state(
            self,
        ) -> typing.Optional["EC2ImageBuilderImageStateChange.ImageState"]:
            '''(experimental) previous-state property.

            Specify an array of string values to match this event if the actual value of previous-state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("previous_state")
            return typing.cast(typing.Optional["EC2ImageBuilderImageStateChange.ImageState"], result)

        @builtins.property
        def state(
            self,
        ) -> typing.Optional["EC2ImageBuilderImageStateChange.ImageState"]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional["EC2ImageBuilderImageStateChange.ImageState"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EC2ImageBuilderImageStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_imagebuilder.events.EC2ImageBuilderImageStateChange.ImageState",
        jsii_struct_bases=[],
        name_mapping={"reason": "reason", "status": "status"},
    )
    class ImageState:
        def __init__(
            self,
            *,
            reason: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ImageState.

            :param reason: (experimental) reason property. Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) status property. Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_imagebuilder import events as imagebuilder_events
                
                image_state = imagebuilder_events.EC2ImageBuilderImageStateChange.ImageState(
                    reason=["reason"],
                    status=["status"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__12fcd6194eb55e078a6b1520690c394e6f104c8a59757ebb6e49291e289ee983)
                check_type(argname="argument reason", value=reason, expected_type=type_hints["reason"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if reason is not None:
                self._values["reason"] = reason
            if status is not None:
                self._values["status"] = status

        @builtins.property
        def reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) reason property.

            Specify an array of string values to match this event if the actual value of reason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) status property.

            Specify an array of string values to match this event if the actual value of status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImageState(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EC2ImageBuilderWorkflowStepWaiting(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_imagebuilder.events.EC2ImageBuilderWorkflowStepWaiting",
):
    '''(experimental) EventBridge event pattern for aws.imagebuilder@EC2ImageBuilderWorkflowStepWaiting.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_imagebuilder import events as imagebuilder_events
        
        e_c2_image_builder_workflow_step_waiting = imagebuilder_events.EC2ImageBuilderWorkflowStepWaiting()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        workflow_execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        workflow_step_execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        workflow_step_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EC2 Image Builder Workflow Step Waiting.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param workflow_execution_id: (experimental) workflow-execution-id property. Specify an array of string values to match this event if the actual value of workflow-execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param workflow_step_execution_id: (experimental) workflow-step-execution-id property. Specify an array of string values to match this event if the actual value of workflow-step-execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param workflow_step_name: (experimental) workflow-step-name property. Specify an array of string values to match this event if the actual value of workflow-step-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EC2ImageBuilderWorkflowStepWaiting.EC2ImageBuilderWorkflowStepWaitingProps(
            event_metadata=event_metadata,
            workflow_execution_id=workflow_execution_id,
            workflow_step_execution_id=workflow_step_execution_id,
            workflow_step_name=workflow_step_name,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_imagebuilder.events.EC2ImageBuilderWorkflowStepWaiting.EC2ImageBuilderWorkflowStepWaitingProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "workflow_execution_id": "workflowExecutionId",
            "workflow_step_execution_id": "workflowStepExecutionId",
            "workflow_step_name": "workflowStepName",
        },
    )
    class EC2ImageBuilderWorkflowStepWaitingProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            workflow_execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            workflow_step_execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            workflow_step_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.imagebuilder@EC2ImageBuilderWorkflowStepWaiting event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param workflow_execution_id: (experimental) workflow-execution-id property. Specify an array of string values to match this event if the actual value of workflow-execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param workflow_step_execution_id: (experimental) workflow-step-execution-id property. Specify an array of string values to match this event if the actual value of workflow-step-execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param workflow_step_name: (experimental) workflow-step-name property. Specify an array of string values to match this event if the actual value of workflow-step-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_imagebuilder import events as imagebuilder_events
                
                e_c2_image_builder_workflow_step_waiting_props = imagebuilder_events.EC2ImageBuilderWorkflowStepWaiting.EC2ImageBuilderWorkflowStepWaitingProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    workflow_execution_id=["workflowExecutionId"],
                    workflow_step_execution_id=["workflowStepExecutionId"],
                    workflow_step_name=["workflowStepName"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7d52219868178bfe14db371dcd230c35bd81be7c7041896d667097802ea418ce)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument workflow_execution_id", value=workflow_execution_id, expected_type=type_hints["workflow_execution_id"])
                check_type(argname="argument workflow_step_execution_id", value=workflow_step_execution_id, expected_type=type_hints["workflow_step_execution_id"])
                check_type(argname="argument workflow_step_name", value=workflow_step_name, expected_type=type_hints["workflow_step_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if workflow_execution_id is not None:
                self._values["workflow_execution_id"] = workflow_execution_id
            if workflow_step_execution_id is not None:
                self._values["workflow_step_execution_id"] = workflow_step_execution_id
            if workflow_step_name is not None:
                self._values["workflow_step_name"] = workflow_step_name

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def workflow_execution_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) workflow-execution-id property.

            Specify an array of string values to match this event if the actual value of workflow-execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("workflow_execution_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def workflow_step_execution_id(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) workflow-step-execution-id property.

            Specify an array of string values to match this event if the actual value of workflow-step-execution-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("workflow_step_execution_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def workflow_step_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) workflow-step-name property.

            Specify an array of string values to match this event if the actual value of workflow-step-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("workflow_step_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EC2ImageBuilderWorkflowStepWaitingProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "EC2ImageBuilderCVEDetected",
    "EC2ImageBuilderImageStateChange",
    "EC2ImageBuilderWorkflowStepWaiting",
]

publication.publish()

def _typecheckingstub__471f689739de4bc394feeadd30dd178e7fc21d52ad84019c804a90dae1bc2c82(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    finding_severity_counts: typing.Optional[typing.Union[EC2ImageBuilderCVEDetected.FindingSeverityCounts, typing.Dict[builtins.str, typing.Any]]] = None,
    resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4d3cc4c707b08e95f56a7e3f3d8d1639084c9456b6d56d0e577971d728900ff7(
    *,
    all: typing.Optional[typing.Sequence[builtins.str]] = None,
    critical: typing.Optional[typing.Sequence[builtins.str]] = None,
    high: typing.Optional[typing.Sequence[builtins.str]] = None,
    medium: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b26d2bf515bcb3e87804ed95e6e69865adf4ef3fda81facff235471df75ef365(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    previous_state: typing.Optional[typing.Union[EC2ImageBuilderImageStateChange.ImageState, typing.Dict[builtins.str, typing.Any]]] = None,
    state: typing.Optional[typing.Union[EC2ImageBuilderImageStateChange.ImageState, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__12fcd6194eb55e078a6b1520690c394e6f104c8a59757ebb6e49291e289ee983(
    *,
    reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7d52219868178bfe14db371dcd230c35bd81be7c7041896d667097802ea418ce(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    workflow_execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    workflow_step_execution_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    workflow_step_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
