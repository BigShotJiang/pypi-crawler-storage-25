from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class DataStoreActive(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.DataStoreActive",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@DataStoreActive.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        data_store_active = healthlake_events.DataStoreActive()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_endpoint: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_type_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Data Store Active.

        :param datastore_endpoint: (experimental) datastoreEndpoint property. Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_type_version: (experimental) datastoreTypeVersion property. Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -

        :stability: experimental
        '''
        options = DataStoreActive.DataStoreActiveProps(
            datastore_endpoint=datastore_endpoint,
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_type_version=datastore_type_version,
            event_metadata=event_metadata,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.DataStoreActive.DataStoreActiveProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_endpoint": "datastoreEndpoint",
            "datastore_id": "datastoreId",
            "datastore_name": "datastoreName",
            "datastore_type_version": "datastoreTypeVersion",
            "event_metadata": "eventMetadata",
        },
    )
    class DataStoreActiveProps:
        def __init__(
            self,
            *,
            datastore_endpoint: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_type_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@DataStoreActive event.

            :param datastore_endpoint: (experimental) datastoreEndpoint property. Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_type_version: (experimental) datastoreTypeVersion property. Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                data_store_active_props = healthlake_events.DataStoreActive.DataStoreActiveProps(
                    datastore_endpoint=["datastoreEndpoint"],
                    datastore_id=["datastoreId"],
                    datastore_name=["datastoreName"],
                    datastore_type_version=["datastoreTypeVersion"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__645b68c5512cfab7e9392a911be938c32d36dc9ce4fee454da9e7a7822eea032)
                check_type(argname="argument datastore_endpoint", value=datastore_endpoint, expected_type=type_hints["datastore_endpoint"])
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument datastore_name", value=datastore_name, expected_type=type_hints["datastore_name"])
                check_type(argname="argument datastore_type_version", value=datastore_type_version, expected_type=type_hints["datastore_type_version"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_endpoint is not None:
                self._values["datastore_endpoint"] = datastore_endpoint
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if datastore_name is not None:
                self._values["datastore_name"] = datastore_name
            if datastore_type_version is not None:
                self._values["datastore_type_version"] = datastore_type_version
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata

        @builtins.property
        def datastore_endpoint(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreEndpoint property.

            Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_endpoint")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreName property.

            Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_type_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreTypeVersion property.

            Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_type_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataStoreActiveProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DataStoreCreating(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.DataStoreCreating",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@DataStoreCreating.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        data_store_creating = healthlake_events.DataStoreCreating()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_endpoint: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_type_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Data Store Creating.

        :param datastore_endpoint: (experimental) datastoreEndpoint property. Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_type_version: (experimental) datastoreTypeVersion property. Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -

        :stability: experimental
        '''
        options = DataStoreCreating.DataStoreCreatingProps(
            datastore_endpoint=datastore_endpoint,
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_type_version=datastore_type_version,
            event_metadata=event_metadata,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.DataStoreCreating.DataStoreCreatingProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_endpoint": "datastoreEndpoint",
            "datastore_id": "datastoreId",
            "datastore_name": "datastoreName",
            "datastore_type_version": "datastoreTypeVersion",
            "event_metadata": "eventMetadata",
        },
    )
    class DataStoreCreatingProps:
        def __init__(
            self,
            *,
            datastore_endpoint: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_type_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@DataStoreCreating event.

            :param datastore_endpoint: (experimental) datastoreEndpoint property. Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_type_version: (experimental) datastoreTypeVersion property. Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                data_store_creating_props = healthlake_events.DataStoreCreating.DataStoreCreatingProps(
                    datastore_endpoint=["datastoreEndpoint"],
                    datastore_id=["datastoreId"],
                    datastore_name=["datastoreName"],
                    datastore_type_version=["datastoreTypeVersion"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__165949bea802ba4da0b084d6a473ce30e980aa30699c29bd3022efe0298f1d74)
                check_type(argname="argument datastore_endpoint", value=datastore_endpoint, expected_type=type_hints["datastore_endpoint"])
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument datastore_name", value=datastore_name, expected_type=type_hints["datastore_name"])
                check_type(argname="argument datastore_type_version", value=datastore_type_version, expected_type=type_hints["datastore_type_version"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_endpoint is not None:
                self._values["datastore_endpoint"] = datastore_endpoint
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if datastore_name is not None:
                self._values["datastore_name"] = datastore_name
            if datastore_type_version is not None:
                self._values["datastore_type_version"] = datastore_type_version
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata

        @builtins.property
        def datastore_endpoint(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreEndpoint property.

            Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_endpoint")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreName property.

            Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_type_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreTypeVersion property.

            Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_type_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataStoreCreatingProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DataStoreDeleted(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.DataStoreDeleted",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@DataStoreDeleted.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        data_store_deleted = healthlake_events.DataStoreDeleted()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_endpoint: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_type_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Data Store Deleted.

        :param datastore_endpoint: (experimental) datastoreEndpoint property. Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_type_version: (experimental) datastoreTypeVersion property. Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -

        :stability: experimental
        '''
        options = DataStoreDeleted.DataStoreDeletedProps(
            datastore_endpoint=datastore_endpoint,
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_type_version=datastore_type_version,
            event_metadata=event_metadata,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.DataStoreDeleted.DataStoreDeletedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_endpoint": "datastoreEndpoint",
            "datastore_id": "datastoreId",
            "datastore_name": "datastoreName",
            "datastore_type_version": "datastoreTypeVersion",
            "event_metadata": "eventMetadata",
        },
    )
    class DataStoreDeletedProps:
        def __init__(
            self,
            *,
            datastore_endpoint: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_type_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@DataStoreDeleted event.

            :param datastore_endpoint: (experimental) datastoreEndpoint property. Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_type_version: (experimental) datastoreTypeVersion property. Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                data_store_deleted_props = healthlake_events.DataStoreDeleted.DataStoreDeletedProps(
                    datastore_endpoint=["datastoreEndpoint"],
                    datastore_id=["datastoreId"],
                    datastore_name=["datastoreName"],
                    datastore_type_version=["datastoreTypeVersion"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7997aa9cfc7ba95c9bdfcac6984c5c13da8b33048485338ebf360a3bbdba2fbf)
                check_type(argname="argument datastore_endpoint", value=datastore_endpoint, expected_type=type_hints["datastore_endpoint"])
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument datastore_name", value=datastore_name, expected_type=type_hints["datastore_name"])
                check_type(argname="argument datastore_type_version", value=datastore_type_version, expected_type=type_hints["datastore_type_version"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_endpoint is not None:
                self._values["datastore_endpoint"] = datastore_endpoint
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if datastore_name is not None:
                self._values["datastore_name"] = datastore_name
            if datastore_type_version is not None:
                self._values["datastore_type_version"] = datastore_type_version
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata

        @builtins.property
        def datastore_endpoint(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreEndpoint property.

            Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_endpoint")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreName property.

            Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_type_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreTypeVersion property.

            Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_type_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataStoreDeletedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class DataStoreDeleting(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.DataStoreDeleting",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@DataStoreDeleting.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        data_store_deleting = healthlake_events.DataStoreDeleting()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_endpoint: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        datastore_type_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Data Store Deleting.

        :param datastore_endpoint: (experimental) datastoreEndpoint property. Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param datastore_type_version: (experimental) datastoreTypeVersion property. Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -

        :stability: experimental
        '''
        options = DataStoreDeleting.DataStoreDeletingProps(
            datastore_endpoint=datastore_endpoint,
            datastore_id=datastore_id,
            datastore_name=datastore_name,
            datastore_type_version=datastore_type_version,
            event_metadata=event_metadata,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.DataStoreDeleting.DataStoreDeletingProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_endpoint": "datastoreEndpoint",
            "datastore_id": "datastoreId",
            "datastore_name": "datastoreName",
            "datastore_type_version": "datastoreTypeVersion",
            "event_metadata": "eventMetadata",
        },
    )
    class DataStoreDeletingProps:
        def __init__(
            self,
            *,
            datastore_endpoint: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            datastore_type_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@DataStoreDeleting event.

            :param datastore_endpoint: (experimental) datastoreEndpoint property. Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_name: (experimental) datastoreName property. Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param datastore_type_version: (experimental) datastoreTypeVersion property. Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                data_store_deleting_props = healthlake_events.DataStoreDeleting.DataStoreDeletingProps(
                    datastore_endpoint=["datastoreEndpoint"],
                    datastore_id=["datastoreId"],
                    datastore_name=["datastoreName"],
                    datastore_type_version=["datastoreTypeVersion"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__35f791404546842c4f6d905b49f59a5385f599632f9b0ec05c938250a57987de)
                check_type(argname="argument datastore_endpoint", value=datastore_endpoint, expected_type=type_hints["datastore_endpoint"])
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument datastore_name", value=datastore_name, expected_type=type_hints["datastore_name"])
                check_type(argname="argument datastore_type_version", value=datastore_type_version, expected_type=type_hints["datastore_type_version"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_endpoint is not None:
                self._values["datastore_endpoint"] = datastore_endpoint
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if datastore_name is not None:
                self._values["datastore_name"] = datastore_name
            if datastore_type_version is not None:
                self._values["datastore_type_version"] = datastore_type_version
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata

        @builtins.property
        def datastore_endpoint(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreEndpoint property.

            Specify an array of string values to match this event if the actual value of datastoreEndpoint is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_endpoint")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreName property.

            Specify an array of string values to match this event if the actual value of datastoreName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def datastore_type_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreTypeVersion property.

            Specify an array of string values to match this event if the actual value of datastoreTypeVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_type_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataStoreDeletingProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ExportJobCompleted(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobCompleted",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@ExportJobCompleted.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        export_job_completed = healthlake_events.ExportJobCompleted()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_data_config: typing.Optional[typing.Union["ExportJobCompleted.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Export Job Completed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ExportJobCompleted.ExportJobCompletedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            job_id=job_id,
            output_data_config=output_data_config,
            submit_time=submit_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobCompleted.ExportJobCompletedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "job_id": "jobId",
            "output_data_config": "outputDataConfig",
            "submit_time": "submitTime",
        },
    )
    class ExportJobCompletedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            output_data_config: typing.Optional[typing.Union["ExportJobCompleted.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@ExportJobCompleted event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                export_job_completed_props = healthlake_events.ExportJobCompleted.ExportJobCompletedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    job_id=["jobId"],
                    output_data_config=healthlake_events.ExportJobCompleted.OutputDataConfig(
                        s3_uri=["s3Uri"]
                    ),
                    submit_time=["submitTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(output_data_config, dict):
                output_data_config = ExportJobCompleted.OutputDataConfig(**output_data_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2731db7e91a61a916dda9d1c8916592c9c2ac6e1391d2aec9dec6e004dd0c585)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument output_data_config", value=output_data_config, expected_type=type_hints["output_data_config"])
                check_type(argname="argument submit_time", value=submit_time, expected_type=type_hints["submit_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if job_id is not None:
                self._values["job_id"] = job_id
            if output_data_config is not None:
                self._values["output_data_config"] = output_data_config
            if submit_time is not None:
                self._values["submit_time"] = submit_time

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def output_data_config(
            self,
        ) -> typing.Optional["ExportJobCompleted.OutputDataConfig"]:
            '''(experimental) outputDataConfig property.

            Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_data_config")
            return typing.cast(typing.Optional["ExportJobCompleted.OutputDataConfig"], result)

        @builtins.property
        def submit_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) submitTime property.

            Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("submit_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ExportJobCompletedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobCompleted.OutputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_uri": "s3Uri"},
    )
    class OutputDataConfig:
        def __init__(
            self,
            *,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for OutputDataConfig.

            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                output_data_config = healthlake_events.ExportJobCompleted.OutputDataConfig(
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__efb6df39fd1dd3a89b5fbc06a4b70cebe6ac9e2de1a354af0be7d7fb1f8f7fd7)
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OutputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ExportJobCompletedWithErrors(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobCompletedWithErrors",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@ExportJobCompletedWithErrors.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        export_job_completed_with_errors = healthlake_events.ExportJobCompletedWithErrors()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_data_config: typing.Optional[typing.Union["ExportJobCompletedWithErrors.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Export Job Completed With Errors.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ExportJobCompletedWithErrors.ExportJobCompletedWithErrorsProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            job_id=job_id,
            output_data_config=output_data_config,
            submit_time=submit_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobCompletedWithErrors.ExportJobCompletedWithErrorsProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "job_id": "jobId",
            "output_data_config": "outputDataConfig",
            "submit_time": "submitTime",
        },
    )
    class ExportJobCompletedWithErrorsProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            output_data_config: typing.Optional[typing.Union["ExportJobCompletedWithErrors.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@ExportJobCompletedWithErrors event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                export_job_completed_with_errors_props = healthlake_events.ExportJobCompletedWithErrors.ExportJobCompletedWithErrorsProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    job_id=["jobId"],
                    output_data_config=healthlake_events.ExportJobCompletedWithErrors.OutputDataConfig(
                        s3_uri=["s3Uri"]
                    ),
                    submit_time=["submitTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(output_data_config, dict):
                output_data_config = ExportJobCompletedWithErrors.OutputDataConfig(**output_data_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0d9219aac4fbf3f9fa97817eb7428f4320a76f5b4a1acf8220ceccb8a65a1679)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument output_data_config", value=output_data_config, expected_type=type_hints["output_data_config"])
                check_type(argname="argument submit_time", value=submit_time, expected_type=type_hints["submit_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if job_id is not None:
                self._values["job_id"] = job_id
            if output_data_config is not None:
                self._values["output_data_config"] = output_data_config
            if submit_time is not None:
                self._values["submit_time"] = submit_time

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def output_data_config(
            self,
        ) -> typing.Optional["ExportJobCompletedWithErrors.OutputDataConfig"]:
            '''(experimental) outputDataConfig property.

            Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_data_config")
            return typing.cast(typing.Optional["ExportJobCompletedWithErrors.OutputDataConfig"], result)

        @builtins.property
        def submit_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) submitTime property.

            Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("submit_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ExportJobCompletedWithErrorsProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobCompletedWithErrors.OutputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_uri": "s3Uri"},
    )
    class OutputDataConfig:
        def __init__(
            self,
            *,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for OutputDataConfig.

            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                output_data_config = healthlake_events.ExportJobCompletedWithErrors.OutputDataConfig(
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8e0fdeebbff25e2f913c9b6b8edc92c3ebdd716e7ec8345f9a9b00228e5cdb20)
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OutputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ExportJobFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobFailed",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@ExportJobFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        export_job_failed = healthlake_events.ExportJobFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_data_config: typing.Optional[typing.Union["ExportJobFailed.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Export Job Failed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ExportJobFailed.ExportJobFailedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            job_id=job_id,
            output_data_config=output_data_config,
            submit_time=submit_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobFailed.ExportJobFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "job_id": "jobId",
            "output_data_config": "outputDataConfig",
            "submit_time": "submitTime",
        },
    )
    class ExportJobFailedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            output_data_config: typing.Optional[typing.Union["ExportJobFailed.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@ExportJobFailed event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                export_job_failed_props = healthlake_events.ExportJobFailed.ExportJobFailedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    job_id=["jobId"],
                    output_data_config=healthlake_events.ExportJobFailed.OutputDataConfig(
                        s3_uri=["s3Uri"]
                    ),
                    submit_time=["submitTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(output_data_config, dict):
                output_data_config = ExportJobFailed.OutputDataConfig(**output_data_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4f3a639c28f55abfc4c5bc5bf81de6484f856f595b0c19690d3dc80c5d4f0744)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument output_data_config", value=output_data_config, expected_type=type_hints["output_data_config"])
                check_type(argname="argument submit_time", value=submit_time, expected_type=type_hints["submit_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if job_id is not None:
                self._values["job_id"] = job_id
            if output_data_config is not None:
                self._values["output_data_config"] = output_data_config
            if submit_time is not None:
                self._values["submit_time"] = submit_time

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def output_data_config(
            self,
        ) -> typing.Optional["ExportJobFailed.OutputDataConfig"]:
            '''(experimental) outputDataConfig property.

            Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_data_config")
            return typing.cast(typing.Optional["ExportJobFailed.OutputDataConfig"], result)

        @builtins.property
        def submit_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) submitTime property.

            Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("submit_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ExportJobFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobFailed.OutputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_uri": "s3Uri"},
    )
    class OutputDataConfig:
        def __init__(
            self,
            *,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for OutputDataConfig.

            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                output_data_config = healthlake_events.ExportJobFailed.OutputDataConfig(
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d7b40cb3aa5f3cdae3e5879ab33b6ca358ce17b321b73124ff1714fa5c37924e)
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OutputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ExportJobInProgress(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobInProgress",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@ExportJobInProgress.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        export_job_in_progress = healthlake_events.ExportJobInProgress()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_data_config: typing.Optional[typing.Union["ExportJobInProgress.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Export Job In Progress.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ExportJobInProgress.ExportJobInProgressProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            job_id=job_id,
            output_data_config=output_data_config,
            submit_time=submit_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobInProgress.ExportJobInProgressProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "job_id": "jobId",
            "output_data_config": "outputDataConfig",
            "submit_time": "submitTime",
        },
    )
    class ExportJobInProgressProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            output_data_config: typing.Optional[typing.Union["ExportJobInProgress.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@ExportJobInProgress event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                export_job_in_progress_props = healthlake_events.ExportJobInProgress.ExportJobInProgressProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    job_id=["jobId"],
                    output_data_config=healthlake_events.ExportJobInProgress.OutputDataConfig(
                        s3_uri=["s3Uri"]
                    ),
                    submit_time=["submitTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(output_data_config, dict):
                output_data_config = ExportJobInProgress.OutputDataConfig(**output_data_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9c58c817934a575a9d6cfefdd25bf496e1d0cfb9a90c8637d4e767ad8a506bc2)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument output_data_config", value=output_data_config, expected_type=type_hints["output_data_config"])
                check_type(argname="argument submit_time", value=submit_time, expected_type=type_hints["submit_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if job_id is not None:
                self._values["job_id"] = job_id
            if output_data_config is not None:
                self._values["output_data_config"] = output_data_config
            if submit_time is not None:
                self._values["submit_time"] = submit_time

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def output_data_config(
            self,
        ) -> typing.Optional["ExportJobInProgress.OutputDataConfig"]:
            '''(experimental) outputDataConfig property.

            Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_data_config")
            return typing.cast(typing.Optional["ExportJobInProgress.OutputDataConfig"], result)

        @builtins.property
        def submit_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) submitTime property.

            Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("submit_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ExportJobInProgressProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobInProgress.OutputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_uri": "s3Uri"},
    )
    class OutputDataConfig:
        def __init__(
            self,
            *,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for OutputDataConfig.

            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                output_data_config = healthlake_events.ExportJobInProgress.OutputDataConfig(
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ba0404e90904249eb7e2a771aa668fc366aa291a5bda6fc10b8df36057801af8)
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OutputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ExportJobSubmitted(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobSubmitted",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@ExportJobSubmitted.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        export_job_submitted = healthlake_events.ExportJobSubmitted()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        output_data_config: typing.Optional[typing.Union["ExportJobSubmitted.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Export Job Submitted.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ExportJobSubmitted.ExportJobSubmittedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            job_id=job_id,
            output_data_config=output_data_config,
            submit_time=submit_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobSubmitted.ExportJobSubmittedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "job_id": "jobId",
            "output_data_config": "outputDataConfig",
            "submit_time": "submitTime",
        },
    )
    class ExportJobSubmittedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            output_data_config: typing.Optional[typing.Union["ExportJobSubmitted.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@ExportJobSubmitted event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                export_job_submitted_props = healthlake_events.ExportJobSubmitted.ExportJobSubmittedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    job_id=["jobId"],
                    output_data_config=healthlake_events.ExportJobSubmitted.OutputDataConfig(
                        s3_uri=["s3Uri"]
                    ),
                    submit_time=["submitTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(output_data_config, dict):
                output_data_config = ExportJobSubmitted.OutputDataConfig(**output_data_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8347a4f06e94ec195fc8bc23cdfcc64bee8c62f2f640ea05cb2eaa3e34a55141)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument output_data_config", value=output_data_config, expected_type=type_hints["output_data_config"])
                check_type(argname="argument submit_time", value=submit_time, expected_type=type_hints["submit_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if job_id is not None:
                self._values["job_id"] = job_id
            if output_data_config is not None:
                self._values["output_data_config"] = output_data_config
            if submit_time is not None:
                self._values["submit_time"] = submit_time

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def output_data_config(
            self,
        ) -> typing.Optional["ExportJobSubmitted.OutputDataConfig"]:
            '''(experimental) outputDataConfig property.

            Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_data_config")
            return typing.cast(typing.Optional["ExportJobSubmitted.OutputDataConfig"], result)

        @builtins.property
        def submit_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) submitTime property.

            Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("submit_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ExportJobSubmittedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ExportJobSubmitted.OutputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_uri": "s3Uri"},
    )
    class OutputDataConfig:
        def __init__(
            self,
            *,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for OutputDataConfig.

            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                output_data_config = healthlake_events.ExportJobSubmitted.OutputDataConfig(
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__de3c456cb53b88d3da55579a5d3ce36889d1e0d88ffe57ce17855be52ab2b745)
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OutputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImportJobCompleted(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobCompleted",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@ImportJobCompleted.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        import_job_completed = healthlake_events.ImportJobCompleted()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        input_data_config: typing.Optional[typing.Union["ImportJobCompleted.InputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Import Job Completed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobCompleted.ImportJobCompletedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            input_data_config=input_data_config,
            job_id=job_id,
            submit_time=submit_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobCompleted.ImportJobCompletedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "input_data_config": "inputDataConfig",
            "job_id": "jobId",
            "submit_time": "submitTime",
        },
    )
    class ImportJobCompletedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            input_data_config: typing.Optional[typing.Union["ImportJobCompleted.InputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@ImportJobCompleted event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                import_job_completed_props = healthlake_events.ImportJobCompleted.ImportJobCompletedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    input_data_config=healthlake_events.ImportJobCompleted.InputDataConfig(
                        s3_uri=["s3Uri"]
                    ),
                    job_id=["jobId"],
                    submit_time=["submitTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(input_data_config, dict):
                input_data_config = ImportJobCompleted.InputDataConfig(**input_data_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2f2f160955041eb10ff88a4fbd49c2452095dacb8f5423015eb63bebbe643432)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument input_data_config", value=input_data_config, expected_type=type_hints["input_data_config"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument submit_time", value=submit_time, expected_type=type_hints["submit_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if input_data_config is not None:
                self._values["input_data_config"] = input_data_config
            if job_id is not None:
                self._values["job_id"] = job_id
            if submit_time is not None:
                self._values["submit_time"] = submit_time

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def input_data_config(
            self,
        ) -> typing.Optional["ImportJobCompleted.InputDataConfig"]:
            '''(experimental) inputDataConfig property.

            Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_data_config")
            return typing.cast(typing.Optional["ImportJobCompleted.InputDataConfig"], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def submit_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) submitTime property.

            Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("submit_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImportJobCompletedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobCompleted.InputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_uri": "s3Uri"},
    )
    class InputDataConfig:
        def __init__(
            self,
            *,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for InputDataConfig.

            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                input_data_config = healthlake_events.ImportJobCompleted.InputDataConfig(
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b33c7a610461f5fdea1a3ab4cb8e3ba368a5688016b35e40841bca6b95c3dfe1)
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImportJobCompletedWithErrors(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobCompletedWithErrors",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@ImportJobCompletedWithErrors.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        import_job_completed_with_errors = healthlake_events.ImportJobCompletedWithErrors()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        input_data_config: typing.Optional[typing.Union["ImportJobCompletedWithErrors.InputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Import Job Completed With Errors.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobCompletedWithErrors.ImportJobCompletedWithErrorsProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            input_data_config=input_data_config,
            job_id=job_id,
            submit_time=submit_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobCompletedWithErrors.ImportJobCompletedWithErrorsProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "input_data_config": "inputDataConfig",
            "job_id": "jobId",
            "submit_time": "submitTime",
        },
    )
    class ImportJobCompletedWithErrorsProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            input_data_config: typing.Optional[typing.Union["ImportJobCompletedWithErrors.InputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@ImportJobCompletedWithErrors event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                import_job_completed_with_errors_props = healthlake_events.ImportJobCompletedWithErrors.ImportJobCompletedWithErrorsProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    input_data_config=healthlake_events.ImportJobCompletedWithErrors.InputDataConfig(
                        s3_uri=["s3Uri"]
                    ),
                    job_id=["jobId"],
                    submit_time=["submitTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(input_data_config, dict):
                input_data_config = ImportJobCompletedWithErrors.InputDataConfig(**input_data_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2dd793b04cfa9c918f0e44c5f3615f8ffc9d9239304df620b1126f36df9b9bba)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument input_data_config", value=input_data_config, expected_type=type_hints["input_data_config"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument submit_time", value=submit_time, expected_type=type_hints["submit_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if input_data_config is not None:
                self._values["input_data_config"] = input_data_config
            if job_id is not None:
                self._values["job_id"] = job_id
            if submit_time is not None:
                self._values["submit_time"] = submit_time

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def input_data_config(
            self,
        ) -> typing.Optional["ImportJobCompletedWithErrors.InputDataConfig"]:
            '''(experimental) inputDataConfig property.

            Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_data_config")
            return typing.cast(typing.Optional["ImportJobCompletedWithErrors.InputDataConfig"], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def submit_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) submitTime property.

            Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("submit_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImportJobCompletedWithErrorsProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobCompletedWithErrors.InputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_uri": "s3Uri"},
    )
    class InputDataConfig:
        def __init__(
            self,
            *,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for InputDataConfig.

            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                input_data_config = healthlake_events.ImportJobCompletedWithErrors.InputDataConfig(
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__809fa6d13aad79489ca71241f45cfce0eae668f608ce9ac8ee01aa9363921721)
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImportJobFailed(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobFailed",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@ImportJobFailed.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        import_job_failed = healthlake_events.ImportJobFailed()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        input_data_config: typing.Optional[typing.Union["ImportJobFailed.InputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Import Job Failed.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobFailed.ImportJobFailedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            input_data_config=input_data_config,
            job_id=job_id,
            submit_time=submit_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobFailed.ImportJobFailedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "input_data_config": "inputDataConfig",
            "job_id": "jobId",
            "submit_time": "submitTime",
        },
    )
    class ImportJobFailedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            input_data_config: typing.Optional[typing.Union["ImportJobFailed.InputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@ImportJobFailed event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                import_job_failed_props = healthlake_events.ImportJobFailed.ImportJobFailedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    input_data_config=healthlake_events.ImportJobFailed.InputDataConfig(
                        s3_uri=["s3Uri"]
                    ),
                    job_id=["jobId"],
                    submit_time=["submitTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(input_data_config, dict):
                input_data_config = ImportJobFailed.InputDataConfig(**input_data_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e4be539d2c6e96c4ce5c247ef6071a7961dbd3e90027f2b7672cd4b99e126543)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument input_data_config", value=input_data_config, expected_type=type_hints["input_data_config"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument submit_time", value=submit_time, expected_type=type_hints["submit_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if input_data_config is not None:
                self._values["input_data_config"] = input_data_config
            if job_id is not None:
                self._values["job_id"] = job_id
            if submit_time is not None:
                self._values["submit_time"] = submit_time

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def input_data_config(
            self,
        ) -> typing.Optional["ImportJobFailed.InputDataConfig"]:
            '''(experimental) inputDataConfig property.

            Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_data_config")
            return typing.cast(typing.Optional["ImportJobFailed.InputDataConfig"], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def submit_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) submitTime property.

            Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("submit_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImportJobFailedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobFailed.InputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_uri": "s3Uri"},
    )
    class InputDataConfig:
        def __init__(
            self,
            *,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for InputDataConfig.

            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                input_data_config = healthlake_events.ImportJobFailed.InputDataConfig(
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__91157813e559fbe92b37406b359acfcedd58c205cfde725c7291fa3fc2f46b38)
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImportJobInProgress(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobInProgress",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@ImportJobInProgress.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        import_job_in_progress = healthlake_events.ImportJobInProgress()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        input_data_config: typing.Optional[typing.Union["ImportJobInProgress.InputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Import Job In Progress.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobInProgress.ImportJobInProgressProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            input_data_config=input_data_config,
            job_id=job_id,
            submit_time=submit_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobInProgress.ImportJobInProgressProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "input_data_config": "inputDataConfig",
            "job_id": "jobId",
            "submit_time": "submitTime",
        },
    )
    class ImportJobInProgressProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            input_data_config: typing.Optional[typing.Union["ImportJobInProgress.InputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@ImportJobInProgress event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                import_job_in_progress_props = healthlake_events.ImportJobInProgress.ImportJobInProgressProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    input_data_config=healthlake_events.ImportJobInProgress.InputDataConfig(
                        s3_uri=["s3Uri"]
                    ),
                    job_id=["jobId"],
                    submit_time=["submitTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(input_data_config, dict):
                input_data_config = ImportJobInProgress.InputDataConfig(**input_data_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__bfd966c3be1b00d86cbc295f10767df4a8c54fb1a190ddf0485047fe6422885a)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument input_data_config", value=input_data_config, expected_type=type_hints["input_data_config"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument submit_time", value=submit_time, expected_type=type_hints["submit_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if input_data_config is not None:
                self._values["input_data_config"] = input_data_config
            if job_id is not None:
                self._values["job_id"] = job_id
            if submit_time is not None:
                self._values["submit_time"] = submit_time

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def input_data_config(
            self,
        ) -> typing.Optional["ImportJobInProgress.InputDataConfig"]:
            '''(experimental) inputDataConfig property.

            Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_data_config")
            return typing.cast(typing.Optional["ImportJobInProgress.InputDataConfig"], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def submit_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) submitTime property.

            Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("submit_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImportJobInProgressProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobInProgress.InputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_uri": "s3Uri"},
    )
    class InputDataConfig:
        def __init__(
            self,
            *,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for InputDataConfig.

            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                input_data_config = healthlake_events.ImportJobInProgress.InputDataConfig(
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4072b188b7053ab3c303eb9e5507b70ffbf59df6ab917816e36c21e8c456cfd7)
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ImportJobSubmitted(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobSubmitted",
):
    '''(experimental) EventBridge event pattern for aws.healthlake@ImportJobSubmitted.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
        
        import_job_submitted = healthlake_events.ImportJobSubmitted()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        input_data_config: typing.Optional[typing.Union["ImportJobSubmitted.InputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Import Job Submitted.

        :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ImportJobSubmitted.ImportJobSubmittedProps(
            datastore_id=datastore_id,
            event_metadata=event_metadata,
            input_data_config=input_data_config,
            job_id=job_id,
            submit_time=submit_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobSubmitted.ImportJobSubmittedProps",
        jsii_struct_bases=[],
        name_mapping={
            "datastore_id": "datastoreId",
            "event_metadata": "eventMetadata",
            "input_data_config": "inputDataConfig",
            "job_id": "jobId",
            "submit_time": "submitTime",
        },
    )
    class ImportJobSubmittedProps:
        def __init__(
            self,
            *,
            datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            input_data_config: typing.Optional[typing.Union["ImportJobSubmitted.InputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.healthlake@ImportJobSubmitted event.

            :param datastore_id: (experimental) datastoreId property. Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param job_id: (experimental) jobId property. Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param submit_time: (experimental) submitTime property. Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                import_job_submitted_props = healthlake_events.ImportJobSubmitted.ImportJobSubmittedProps(
                    datastore_id=["datastoreId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    input_data_config=healthlake_events.ImportJobSubmitted.InputDataConfig(
                        s3_uri=["s3Uri"]
                    ),
                    job_id=["jobId"],
                    submit_time=["submitTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(input_data_config, dict):
                input_data_config = ImportJobSubmitted.InputDataConfig(**input_data_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__617d9464e5d15d338f84c03f1f4f8e407942281d4a95d0b18bc82f79007c40fa)
                check_type(argname="argument datastore_id", value=datastore_id, expected_type=type_hints["datastore_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument input_data_config", value=input_data_config, expected_type=type_hints["input_data_config"])
                check_type(argname="argument job_id", value=job_id, expected_type=type_hints["job_id"])
                check_type(argname="argument submit_time", value=submit_time, expected_type=type_hints["submit_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if datastore_id is not None:
                self._values["datastore_id"] = datastore_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if input_data_config is not None:
                self._values["input_data_config"] = input_data_config
            if job_id is not None:
                self._values["job_id"] = job_id
            if submit_time is not None:
                self._values["submit_time"] = submit_time

        @builtins.property
        def datastore_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) datastoreId property.

            Specify an array of string values to match this event if the actual value of datastoreId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("datastore_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def input_data_config(
            self,
        ) -> typing.Optional["ImportJobSubmitted.InputDataConfig"]:
            '''(experimental) inputDataConfig property.

            Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_data_config")
            return typing.cast(typing.Optional["ImportJobSubmitted.InputDataConfig"], result)

        @builtins.property
        def job_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) jobId property.

            Specify an array of string values to match this event if the actual value of jobId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("job_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def submit_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) submitTime property.

            Specify an array of string values to match this event if the actual value of submitTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("submit_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ImportJobSubmittedProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_healthlake.events.ImportJobSubmitted.InputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_uri": "s3Uri"},
    )
    class InputDataConfig:
        def __init__(
            self,
            *,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for InputDataConfig.

            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_healthlake import events as healthlake_events
                
                input_data_config = healthlake_events.ImportJobSubmitted.InputDataConfig(
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__3278f2b42493fbba1ffade5a1cc85df4e034c5e9184979d8267e87035c516ecd)
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "InputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "DataStoreActive",
    "DataStoreCreating",
    "DataStoreDeleted",
    "DataStoreDeleting",
    "ExportJobCompleted",
    "ExportJobCompletedWithErrors",
    "ExportJobFailed",
    "ExportJobInProgress",
    "ExportJobSubmitted",
    "ImportJobCompleted",
    "ImportJobCompletedWithErrors",
    "ImportJobFailed",
    "ImportJobInProgress",
    "ImportJobSubmitted",
]

publication.publish()

def _typecheckingstub__645b68c5512cfab7e9392a911be938c32d36dc9ce4fee454da9e7a7822eea032(
    *,
    datastore_endpoint: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_type_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__165949bea802ba4da0b084d6a473ce30e980aa30699c29bd3022efe0298f1d74(
    *,
    datastore_endpoint: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_type_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7997aa9cfc7ba95c9bdfcac6984c5c13da8b33048485338ebf360a3bbdba2fbf(
    *,
    datastore_endpoint: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_type_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__35f791404546842c4f6d905b49f59a5385f599632f9b0ec05c938250a57987de(
    *,
    datastore_endpoint: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    datastore_type_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2731db7e91a61a916dda9d1c8916592c9c2ac6e1391d2aec9dec6e004dd0c585(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    output_data_config: typing.Optional[typing.Union[ExportJobCompleted.OutputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__efb6df39fd1dd3a89b5fbc06a4b70cebe6ac9e2de1a354af0be7d7fb1f8f7fd7(
    *,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0d9219aac4fbf3f9fa97817eb7428f4320a76f5b4a1acf8220ceccb8a65a1679(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    output_data_config: typing.Optional[typing.Union[ExportJobCompletedWithErrors.OutputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e0fdeebbff25e2f913c9b6b8edc92c3ebdd716e7ec8345f9a9b00228e5cdb20(
    *,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4f3a639c28f55abfc4c5bc5bf81de6484f856f595b0c19690d3dc80c5d4f0744(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    output_data_config: typing.Optional[typing.Union[ExportJobFailed.OutputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d7b40cb3aa5f3cdae3e5879ab33b6ca358ce17b321b73124ff1714fa5c37924e(
    *,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9c58c817934a575a9d6cfefdd25bf496e1d0cfb9a90c8637d4e767ad8a506bc2(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    output_data_config: typing.Optional[typing.Union[ExportJobInProgress.OutputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ba0404e90904249eb7e2a771aa668fc366aa291a5bda6fc10b8df36057801af8(
    *,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8347a4f06e94ec195fc8bc23cdfcc64bee8c62f2f640ea05cb2eaa3e34a55141(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    output_data_config: typing.Optional[typing.Union[ExportJobSubmitted.OutputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__de3c456cb53b88d3da55579a5d3ce36889d1e0d88ffe57ce17855be52ab2b745(
    *,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f2f160955041eb10ff88a4fbd49c2452095dacb8f5423015eb63bebbe643432(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    input_data_config: typing.Optional[typing.Union[ImportJobCompleted.InputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b33c7a610461f5fdea1a3ab4cb8e3ba368a5688016b35e40841bca6b95c3dfe1(
    *,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2dd793b04cfa9c918f0e44c5f3615f8ffc9d9239304df620b1126f36df9b9bba(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    input_data_config: typing.Optional[typing.Union[ImportJobCompletedWithErrors.InputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__809fa6d13aad79489ca71241f45cfce0eae668f608ce9ac8ee01aa9363921721(
    *,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e4be539d2c6e96c4ce5c247ef6071a7961dbd3e90027f2b7672cd4b99e126543(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    input_data_config: typing.Optional[typing.Union[ImportJobFailed.InputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__91157813e559fbe92b37406b359acfcedd58c205cfde725c7291fa3fc2f46b38(
    *,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bfd966c3be1b00d86cbc295f10767df4a8c54fb1a190ddf0485047fe6422885a(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    input_data_config: typing.Optional[typing.Union[ImportJobInProgress.InputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4072b188b7053ab3c303eb9e5507b70ffbf59df6ab917816e36c21e8c456cfd7(
    *,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__617d9464e5d15d338f84c03f1f4f8e407942281d4a95d0b18bc82f79007c40fa(
    *,
    datastore_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    input_data_config: typing.Optional[typing.Union[ImportJobSubmitted.InputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    job_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    submit_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3278f2b42493fbba1ffade5a1cc85df4e034c5e9184979d8267e87035c516ecd(
    *,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
