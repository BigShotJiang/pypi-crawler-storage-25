from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class FleetSizeRecommendationChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_deadline.events.FleetSizeRecommendationChange",
):
    '''(experimental) EventBridge event pattern for aws.deadline@FleetSizeRecommendationChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_deadline import events as deadline_events
        
        fleet_size_recommendation_change = deadline_events.FleetSizeRecommendationChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        farm_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        fleet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        new_fleet_size: typing.Optional[typing.Sequence[builtins.str]] = None,
        old_fleet_size: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Fleet Size Recommendation Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param farm_id: (experimental) farmId property. Specify an array of string values to match this event if the actual value of farmId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param fleet_id: (experimental) fleetId property. Specify an array of string values to match this event if the actual value of fleetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param new_fleet_size: (experimental) newFleetSize property. Specify an array of string values to match this event if the actual value of newFleetSize is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param old_fleet_size: (experimental) oldFleetSize property. Specify an array of string values to match this event if the actual value of oldFleetSize is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = FleetSizeRecommendationChange.FleetSizeRecommendationChangeProps(
            event_metadata=event_metadata,
            farm_id=farm_id,
            fleet_id=fleet_id,
            new_fleet_size=new_fleet_size,
            old_fleet_size=old_fleet_size,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_deadline.events.FleetSizeRecommendationChange.FleetSizeRecommendationChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "farm_id": "farmId",
            "fleet_id": "fleetId",
            "new_fleet_size": "newFleetSize",
            "old_fleet_size": "oldFleetSize",
        },
    )
    class FleetSizeRecommendationChangeProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            farm_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            fleet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            new_fleet_size: typing.Optional[typing.Sequence[builtins.str]] = None,
            old_fleet_size: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.deadline@FleetSizeRecommendationChange event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param farm_id: (experimental) farmId property. Specify an array of string values to match this event if the actual value of farmId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param fleet_id: (experimental) fleetId property. Specify an array of string values to match this event if the actual value of fleetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param new_fleet_size: (experimental) newFleetSize property. Specify an array of string values to match this event if the actual value of newFleetSize is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param old_fleet_size: (experimental) oldFleetSize property. Specify an array of string values to match this event if the actual value of oldFleetSize is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_deadline import events as deadline_events
                
                fleet_size_recommendation_change_props = deadline_events.FleetSizeRecommendationChange.FleetSizeRecommendationChangeProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    farm_id=["farmId"],
                    fleet_id=["fleetId"],
                    new_fleet_size=["newFleetSize"],
                    old_fleet_size=["oldFleetSize"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b3abdbdec8619d2b8d89d13d2f0bdaa79cf2fde3a77d0a4b2c8e0edfa860000e)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument farm_id", value=farm_id, expected_type=type_hints["farm_id"])
                check_type(argname="argument fleet_id", value=fleet_id, expected_type=type_hints["fleet_id"])
                check_type(argname="argument new_fleet_size", value=new_fleet_size, expected_type=type_hints["new_fleet_size"])
                check_type(argname="argument old_fleet_size", value=old_fleet_size, expected_type=type_hints["old_fleet_size"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if farm_id is not None:
                self._values["farm_id"] = farm_id
            if fleet_id is not None:
                self._values["fleet_id"] = fleet_id
            if new_fleet_size is not None:
                self._values["new_fleet_size"] = new_fleet_size
            if old_fleet_size is not None:
                self._values["old_fleet_size"] = old_fleet_size

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def farm_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) farmId property.

            Specify an array of string values to match this event if the actual value of farmId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("farm_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def fleet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) fleetId property.

            Specify an array of string values to match this event if the actual value of fleetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fleet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def new_fleet_size(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) newFleetSize property.

            Specify an array of string values to match this event if the actual value of newFleetSize is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("new_fleet_size")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def old_fleet_size(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) oldFleetSize property.

            Specify an array of string values to match this event if the actual value of oldFleetSize is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("old_fleet_size")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "FleetSizeRecommendationChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "FleetSizeRecommendationChange",
]

publication.publish()

def _typecheckingstub__b3abdbdec8619d2b8d89d13d2f0bdaa79cf2fde3a77d0a4b2c8e0edfa860000e(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    farm_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    fleet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    new_fleet_size: typing.Optional[typing.Sequence[builtins.str]] = None,
    old_fleet_size: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
