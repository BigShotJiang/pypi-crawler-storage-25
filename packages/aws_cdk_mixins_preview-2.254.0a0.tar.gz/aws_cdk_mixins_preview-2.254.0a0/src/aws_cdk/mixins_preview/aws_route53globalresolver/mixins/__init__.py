from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnGlobalResolverGlobalResolverLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_route53globalresolver.mixins.CfnGlobalResolverGlobalResolverLogs",
):
    '''Builder for CfnGlobalResolverLogsMixin to generate GLOBAL_RESOLVER_LOGS for CfnGlobalResolver.

    :cloudformationResource: AWS::Route53GlobalResolver::GlobalResolver
    :logType: GLOBAL_RESOLVER_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_route53globalresolver import mixins as route53globalresolver_mixins
        
        cfn_global_resolver_global_resolver_logs = route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnGlobalResolverGlobalResolverLogsRecordFields"]] = None,
    ) -> "CfnGlobalResolverLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2c7e7258bbb1bfc659258c330a865e6b0d99656043b58c9a03b571da23775916)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnGlobalResolverGlobalResolverLogsDestProps(
            record_fields=record_fields
        )

        return typing.cast("CfnGlobalResolverLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnGlobalResolverGlobalResolverLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnGlobalResolverGlobalResolverLogsRecordFields"]] = None,
    ) -> "CfnGlobalResolverLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__500b176079042d6905587d2881da1d63ab2ca353b10527b27445675b84f50ce6)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnGlobalResolverGlobalResolverLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnGlobalResolverLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnGlobalResolverGlobalResolverLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnGlobalResolverGlobalResolverLogsRecordFields"]] = None,
    ) -> "CfnGlobalResolverLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__430bd857f3eb27a241819b4fdb8832fcbbd1043e4fa39d601a87fbff5241c95d)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnGlobalResolverGlobalResolverLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnGlobalResolverLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnGlobalResolverGlobalResolverLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnGlobalResolverGlobalResolverLogsRecordFields"]] = None,
    ) -> "CfnGlobalResolverLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__4204dcaeba2b0f9ccbb6200f0891d3e6c5736e65cdb605ce56bdcb080e7a33bb)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnGlobalResolverGlobalResolverLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnGlobalResolverLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_route53globalresolver.mixins.CfnGlobalResolverGlobalResolverLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnGlobalResolverGlobalResolverLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnGlobalResolverGlobalResolverLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_route53globalresolver import mixins as route53globalresolver_mixins
            
            cfn_global_resolver_global_resolver_logs_dest_props = route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogsDestProps(
                record_fields=[route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogsRecordFields.ACTION_NAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a2ab5b2813e856462874710a36a45bbc97799178def1a27e1343562761cd6025)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnGlobalResolverGlobalResolverLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnGlobalResolverGlobalResolverLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnGlobalResolverGlobalResolverLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_route53globalresolver.mixins.CfnGlobalResolverGlobalResolverLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnGlobalResolverGlobalResolverLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnGlobalResolverGlobalResolverLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnGlobalResolverGlobalResolverLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_route53globalresolver import mixins as route53globalresolver_mixins
            
            cfn_global_resolver_global_resolver_logs_firehose_props = route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogsFirehoseProps(
                output_format=route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogsOutputFormat.Firehose.JSON,
                record_fields=[route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogsRecordFields.ACTION_NAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7dbd62687a922086df93bd2c2650a3c41bcb509ee8197aa465c5b635174c250f)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnGlobalResolverGlobalResolverLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnGlobalResolverGlobalResolverLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnGlobalResolverGlobalResolverLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnGlobalResolverGlobalResolverLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnGlobalResolverGlobalResolverLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_route53globalresolver.mixins.CfnGlobalResolverGlobalResolverLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnGlobalResolverGlobalResolverLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnGlobalResolverGlobalResolverLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnGlobalResolverGlobalResolverLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_route53globalresolver import mixins as route53globalresolver_mixins
            
            cfn_global_resolver_global_resolver_logs_log_group_props = route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogsLogGroupProps(
                output_format=route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogsRecordFields.ACTION_NAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6535350bf5881dc95afde454dabe439b1776bcb9235305c1adbefb839de9fb17)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnGlobalResolverGlobalResolverLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnGlobalResolverGlobalResolverLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnGlobalResolverGlobalResolverLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnGlobalResolverGlobalResolverLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnGlobalResolverGlobalResolverLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnGlobalResolverGlobalResolverLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_route53globalresolver.mixins.CfnGlobalResolverGlobalResolverLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnGlobalResolverGlobalResolverLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_route53globalresolver import mixins as route53globalresolver_mixins
        
        cfn_global_resolver_global_resolver_logs_output_format = route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_route53globalresolver.mixins.CfnGlobalResolverGlobalResolverLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_route53globalresolver.mixins.CfnGlobalResolverGlobalResolverLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_route53globalresolver.mixins.CfnGlobalResolverGlobalResolverLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_route53globalresolver.mixins.CfnGlobalResolverGlobalResolverLogsRecordFields"
)
class CfnGlobalResolverGlobalResolverLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    ACTION_NAME = "ACTION_NAME"
    '''
    :stability: experimental
    '''
    ACTIVITY_NAME = "ACTIVITY_NAME"
    '''
    :stability: experimental
    '''
    ANSWERS = "ANSWERS"
    '''
    :stability: experimental
    '''
    CATEGORY_NAME = "CATEGORY_NAME"
    '''
    :stability: experimental
    '''
    CLASS_NAME = "CLASS_NAME"
    '''
    :stability: experimental
    '''
    CONNECTION_INFO = "CONNECTION_INFO"
    '''
    :stability: experimental
    '''
    DISPOSITION = "DISPOSITION"
    '''
    :stability: experimental
    '''
    DISPOSITION_ID = "DISPOSITION_ID"
    '''
    :stability: experimental
    '''
    DURATION = "DURATION"
    '''
    :stability: experimental
    '''
    END_TIME = "END_TIME"
    '''
    :stability: experimental
    '''
    ENRICHMENTS = "ENRICHMENTS"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    QUERY = "QUERY"
    '''
    :stability: experimental
    '''
    QUERY_TIME = "QUERY_TIME"
    '''
    :stability: experimental
    '''
    RCODE = "RCODE"
    '''
    :stability: experimental
    '''
    RCODE_ID = "RCODE_ID"
    '''
    :stability: experimental
    '''
    RESPONSE_TIME = "RESPONSE_TIME"
    '''
    :stability: experimental
    '''
    SEVERITY = "SEVERITY"
    '''
    :stability: experimental
    '''
    START_TIME = "START_TIME"
    '''
    :stability: experimental
    '''
    STATUS = "STATUS"
    '''
    :stability: experimental
    '''
    STATUS_ID = "STATUS_ID"
    '''
    :stability: experimental
    '''
    TYPE_NAME = "TYPE_NAME"
    '''
    :stability: experimental
    '''
    ACTION_ID = "ACTION_ID"
    '''
    :stability: experimental
    '''
    ACTIVITY_ID = "ACTIVITY_ID"
    '''
    :stability: experimental
    '''
    CATEGORY_UID = "CATEGORY_UID"
    '''
    :stability: experimental
    '''
    CLASS_UID = "CLASS_UID"
    '''
    :stability: experimental
    '''
    CLOUD = "CLOUD"
    '''
    :stability: experimental
    '''
    METADATA = "METADATA"
    '''
    :stability: experimental
    '''
    SEVERITY_ID = "SEVERITY_ID"
    '''
    :stability: experimental
    '''
    SRC_ENDPOINT = "SRC_ENDPOINT"
    '''
    :stability: experimental
    '''
    TIME = "TIME"
    '''
    :stability: experimental
    '''
    TYPE_UID = "TYPE_UID"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_route53globalresolver.mixins.CfnGlobalResolverGlobalResolverLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnGlobalResolverGlobalResolverLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnGlobalResolverGlobalResolverLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnGlobalResolverGlobalResolverLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_route53globalresolver import mixins as route53globalresolver_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_global_resolver_global_resolver_logs_s3_props = route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogsS3Props(
                encryption_key=key_ref,
                output_format=route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogsOutputFormat.S3.JSON,
                record_fields=[route53globalresolver_mixins.CfnGlobalResolverGlobalResolverLogsRecordFields.ACTION_NAME]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2612d67c72a850ffa0ff06fc5c2a7d76b507c8422196a44d9aced5a6953d9d86)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnGlobalResolverGlobalResolverLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnGlobalResolverGlobalResolverLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnGlobalResolverGlobalResolverLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnGlobalResolverGlobalResolverLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnGlobalResolverGlobalResolverLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnGlobalResolverLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_route53globalresolver.mixins.CfnGlobalResolverLogsMixin",
):
    '''Resource schema for AWS::Route53GlobalResolver::GlobalResolver.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-route53globalresolver-globalresolver.html
    :cloudformationResource: AWS::Route53GlobalResolver::GlobalResolver
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_route53globalresolver import mixins as route53globalresolver_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_global_resolver_logs_mixin = route53globalresolver_mixins.CfnGlobalResolverLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::Route53GlobalResolver::GlobalResolver``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__66964f6f2611490e55130314d8673ff39298ac44dead17f24a26a798447992f8)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b12326d99da39ed055bce7f566c87e7ed423cf9b5c21f0026c49114107415b3c)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__3461c026b333030ea5ec376f9c6b0968fe37913ea992e2435588a7185fd76a36)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="GLOBAL_RESOLVER_LOGS")
    def GLOBAL_RESOLVER_LOGS(cls) -> "CfnGlobalResolverGlobalResolverLogs":
        return typing.cast("CfnGlobalResolverGlobalResolverLogs", jsii.sget(cls, "GLOBAL_RESOLVER_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


__all__ = [
    "CfnGlobalResolverGlobalResolverLogs",
    "CfnGlobalResolverGlobalResolverLogsDestProps",
    "CfnGlobalResolverGlobalResolverLogsFirehoseProps",
    "CfnGlobalResolverGlobalResolverLogsLogGroupProps",
    "CfnGlobalResolverGlobalResolverLogsOutputFormat",
    "CfnGlobalResolverGlobalResolverLogsRecordFields",
    "CfnGlobalResolverGlobalResolverLogsS3Props",
    "CfnGlobalResolverLogsMixin",
]

publication.publish()

def _typecheckingstub__2c7e7258bbb1bfc659258c330a865e6b0d99656043b58c9a03b571da23775916(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnGlobalResolverGlobalResolverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__500b176079042d6905587d2881da1d63ab2ca353b10527b27445675b84f50ce6(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnGlobalResolverGlobalResolverLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnGlobalResolverGlobalResolverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__430bd857f3eb27a241819b4fdb8832fcbbd1043e4fa39d601a87fbff5241c95d(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnGlobalResolverGlobalResolverLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnGlobalResolverGlobalResolverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4204dcaeba2b0f9ccbb6200f0891d3e6c5736e65cdb605ce56bdcb080e7a33bb(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnGlobalResolverGlobalResolverLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnGlobalResolverGlobalResolverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a2ab5b2813e856462874710a36a45bbc97799178def1a27e1343562761cd6025(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnGlobalResolverGlobalResolverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7dbd62687a922086df93bd2c2650a3c41bcb509ee8197aa465c5b635174c250f(
    *,
    output_format: typing.Optional[CfnGlobalResolverGlobalResolverLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnGlobalResolverGlobalResolverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6535350bf5881dc95afde454dabe439b1776bcb9235305c1adbefb839de9fb17(
    *,
    output_format: typing.Optional[CfnGlobalResolverGlobalResolverLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnGlobalResolverGlobalResolverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2612d67c72a850ffa0ff06fc5c2a7d76b507c8422196a44d9aced5a6953d9d86(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnGlobalResolverGlobalResolverLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnGlobalResolverGlobalResolverLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__66964f6f2611490e55130314d8673ff39298ac44dead17f24a26a798447992f8(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b12326d99da39ed055bce7f566c87e7ed423cf9b5c21f0026c49114107415b3c(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3461c026b333030ea5ec376f9c6b0968fe37913ea992e2435588a7185fd76a36(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass
