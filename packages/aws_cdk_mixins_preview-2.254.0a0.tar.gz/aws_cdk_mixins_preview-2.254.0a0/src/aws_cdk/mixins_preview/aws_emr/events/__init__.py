from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class EMRAutoScalingPolicyStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRAutoScalingPolicyStateChange",
):
    '''(experimental) EventBridge event pattern for aws.emr@EMRAutoScalingPolicyStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_emr import events as emr_events
        
        e_mRAuto_scaling_policy_state_change = emr_events.EMRAutoScalingPolicyStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        scaling_resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        severity: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EMR Auto Scaling Policy State Change.

        :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resource_id: (experimental) resourceId property. Specify an array of string values to match this event if the actual value of resourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param scaling_resource_type: (experimental) scalingResourceType property. Specify an array of string values to match this event if the actual value of scalingResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EMRAutoScalingPolicyStateChange.EMRAutoScalingPolicyStateChangeProps(
            cluster_id=cluster_id,
            event_metadata=event_metadata,
            message=message,
            resource_id=resource_id,
            scaling_resource_type=scaling_resource_type,
            severity=severity,
            state=state,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRAutoScalingPolicyStateChange.EMRAutoScalingPolicyStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "cluster_id": "clusterId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "resource_id": "resourceId",
            "scaling_resource_type": "scalingResourceType",
            "severity": "severity",
            "state": "state",
        },
    )
    class EMRAutoScalingPolicyStateChangeProps:
        def __init__(
            self,
            *,
            cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            scaling_resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.emr@EMRAutoScalingPolicyStateChange event.

            :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_id: (experimental) resourceId property. Specify an array of string values to match this event if the actual value of resourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param scaling_resource_type: (experimental) scalingResourceType property. Specify an array of string values to match this event if the actual value of scalingResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_emr import events as emr_events
                
                e_mRAuto_scaling_policy_state_change_props = emr_events.EMRAutoScalingPolicyStateChange.EMRAutoScalingPolicyStateChangeProps(
                    cluster_id=["clusterId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    resource_id=["resourceId"],
                    scaling_resource_type=["scalingResourceType"],
                    severity=["severity"],
                    state=["state"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__890394203611da678143b31ca2014dab3fcc3e8ec6f5a22c371c16c6669065a2)
                check_type(argname="argument cluster_id", value=cluster_id, expected_type=type_hints["cluster_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument resource_id", value=resource_id, expected_type=type_hints["resource_id"])
                check_type(argname="argument scaling_resource_type", value=scaling_resource_type, expected_type=type_hints["scaling_resource_type"])
                check_type(argname="argument severity", value=severity, expected_type=type_hints["severity"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cluster_id is not None:
                self._values["cluster_id"] = cluster_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if resource_id is not None:
                self._values["resource_id"] = resource_id
            if scaling_resource_type is not None:
                self._values["scaling_resource_type"] = scaling_resource_type
            if severity is not None:
                self._values["severity"] = severity
            if state is not None:
                self._values["state"] = state

        @builtins.property
        def cluster_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clusterId property.

            Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cluster_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resource_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resourceId property.

            Specify an array of string values to match this event if the actual value of resourceId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def scaling_resource_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) scalingResourceType property.

            Specify an array of string values to match this event if the actual value of scalingResourceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("scaling_resource_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) severity property.

            Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EMRAutoScalingPolicyStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EMRClusterStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRClusterStateChange",
):
    '''(experimental) EventBridge event pattern for aws.emr@EMRClusterStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_emr import events as emr_events
        
        e_mRCluster_state_change = emr_events.EMRClusterStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        name: typing.Optional[typing.Sequence[builtins.str]] = None,
        severity: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
        state_change_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EMR Cluster State Change.

        :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state_change_reason: (experimental) stateChangeReason property. Specify an array of string values to match this event if the actual value of stateChangeReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EMRClusterStateChange.EMRClusterStateChangeProps(
            cluster_id=cluster_id,
            event_metadata=event_metadata,
            message=message,
            name=name,
            severity=severity,
            state=state,
            state_change_reason=state_change_reason,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRClusterStateChange.EMRClusterStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "cluster_id": "clusterId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "name": "name",
            "severity": "severity",
            "state": "state",
            "state_change_reason": "stateChangeReason",
        },
    )
    class EMRClusterStateChangeProps:
        def __init__(
            self,
            *,
            cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
            state_change_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.emr@EMRClusterStateChange event.

            :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state_change_reason: (experimental) stateChangeReason property. Specify an array of string values to match this event if the actual value of stateChangeReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_emr import events as emr_events
                
                e_mRCluster_state_change_props = emr_events.EMRClusterStateChange.EMRClusterStateChangeProps(
                    cluster_id=["clusterId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    name=["name"],
                    severity=["severity"],
                    state=["state"],
                    state_change_reason=["stateChangeReason"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__684c62041eae01697840ff7c6a87c9a0761e64637579d0ad53cfe27f67422f47)
                check_type(argname="argument cluster_id", value=cluster_id, expected_type=type_hints["cluster_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument severity", value=severity, expected_type=type_hints["severity"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
                check_type(argname="argument state_change_reason", value=state_change_reason, expected_type=type_hints["state_change_reason"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cluster_id is not None:
                self._values["cluster_id"] = cluster_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if name is not None:
                self._values["name"] = name
            if severity is not None:
                self._values["severity"] = severity
            if state is not None:
                self._values["state"] = state
            if state_change_reason is not None:
                self._values["state_change_reason"] = state_change_reason

        @builtins.property
        def cluster_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clusterId property.

            Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cluster_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) severity property.

            Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state_change_reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stateChangeReason property.

            Specify an array of string values to match this event if the actual value of stateChangeReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state_change_reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EMRClusterStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EMRConfigurationError(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRConfigurationError",
):
    '''(experimental) EventBridge event pattern for aws.emr@EMRConfigurationError.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_emr import events as emr_events
        
        e_mRConfiguration_error = emr_events.EMRConfigurationError()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        description: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EMR Configuration Error.

        :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EMRConfigurationError.EMRConfigurationErrorProps(
            cluster_id=cluster_id,
            description=description,
            event_metadata=event_metadata,
            severity=severity,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRConfigurationError.EMRConfigurationErrorProps",
        jsii_struct_bases=[],
        name_mapping={
            "cluster_id": "clusterId",
            "description": "description",
            "event_metadata": "eventMetadata",
            "severity": "severity",
        },
    )
    class EMRConfigurationErrorProps:
        def __init__(
            self,
            *,
            cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            severity: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.emr@EMRConfigurationError event.

            :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_emr import events as emr_events
                
                e_mRConfiguration_error_props = emr_events.EMRConfigurationError.EMRConfigurationErrorProps(
                    cluster_id=["clusterId"],
                    description=["description"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    severity=["severity"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9b557a2aade7712e44b61e6388e64efad2cbcb11d8ba7358c461fdd6afe3d3b9)
                check_type(argname="argument cluster_id", value=cluster_id, expected_type=type_hints["cluster_id"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument severity", value=severity, expected_type=type_hints["severity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cluster_id is not None:
                self._values["cluster_id"] = cluster_id
            if description is not None:
                self._values["description"] = description
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if severity is not None:
                self._values["severity"] = severity

        @builtins.property
        def cluster_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clusterId property.

            Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cluster_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) severity property.

            Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EMRConfigurationErrorProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EMRInstanceFleetStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRInstanceFleetStateChange",
):
    '''(experimental) EventBridge event pattern for aws.emr@EMRInstanceFleetStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_emr import events as emr_events
        
        e_mRInstance_fleet_state_change = emr_events.EMRInstanceFleetStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        instance_fleet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        instance_fleet_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        provisioned_on_demand_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
        provisioned_spot_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
        severity: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
        target_on_demand_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
        target_spot_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EMR Instance Fleet State Change.

        :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param instance_fleet_id: (experimental) instanceFleetId property. Specify an array of string values to match this event if the actual value of instanceFleetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param instance_fleet_type: (experimental) instanceFleetType property. Specify an array of string values to match this event if the actual value of instanceFleetType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param provisioned_on_demand_capacity: (experimental) provisionedOnDemandCapacity property. Specify an array of string values to match this event if the actual value of provisionedOnDemandCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param provisioned_spot_capacity: (experimental) provisionedSpotCapacity property. Specify an array of string values to match this event if the actual value of provisionedSpotCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param target_on_demand_capacity: (experimental) targetOnDemandCapacity property. Specify an array of string values to match this event if the actual value of targetOnDemandCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param target_spot_capacity: (experimental) targetSpotCapacity property. Specify an array of string values to match this event if the actual value of targetSpotCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EMRInstanceFleetStateChange.EMRInstanceFleetStateChangeProps(
            cluster_id=cluster_id,
            event_metadata=event_metadata,
            instance_fleet_id=instance_fleet_id,
            instance_fleet_type=instance_fleet_type,
            message=message,
            provisioned_on_demand_capacity=provisioned_on_demand_capacity,
            provisioned_spot_capacity=provisioned_spot_capacity,
            severity=severity,
            state=state,
            target_on_demand_capacity=target_on_demand_capacity,
            target_spot_capacity=target_spot_capacity,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRInstanceFleetStateChange.EMRInstanceFleetStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "cluster_id": "clusterId",
            "event_metadata": "eventMetadata",
            "instance_fleet_id": "instanceFleetId",
            "instance_fleet_type": "instanceFleetType",
            "message": "message",
            "provisioned_on_demand_capacity": "provisionedOnDemandCapacity",
            "provisioned_spot_capacity": "provisionedSpotCapacity",
            "severity": "severity",
            "state": "state",
            "target_on_demand_capacity": "targetOnDemandCapacity",
            "target_spot_capacity": "targetSpotCapacity",
        },
    )
    class EMRInstanceFleetStateChangeProps:
        def __init__(
            self,
            *,
            cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            instance_fleet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_fleet_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            provisioned_on_demand_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
            provisioned_spot_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
            severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
            target_on_demand_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
            target_spot_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.emr@EMRInstanceFleetStateChange event.

            :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param instance_fleet_id: (experimental) instanceFleetId property. Specify an array of string values to match this event if the actual value of instanceFleetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_fleet_type: (experimental) instanceFleetType property. Specify an array of string values to match this event if the actual value of instanceFleetType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param provisioned_on_demand_capacity: (experimental) provisionedOnDemandCapacity property. Specify an array of string values to match this event if the actual value of provisionedOnDemandCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param provisioned_spot_capacity: (experimental) provisionedSpotCapacity property. Specify an array of string values to match this event if the actual value of provisionedSpotCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_on_demand_capacity: (experimental) targetOnDemandCapacity property. Specify an array of string values to match this event if the actual value of targetOnDemandCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param target_spot_capacity: (experimental) targetSpotCapacity property. Specify an array of string values to match this event if the actual value of targetSpotCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_emr import events as emr_events
                
                e_mRInstance_fleet_state_change_props = emr_events.EMRInstanceFleetStateChange.EMRInstanceFleetStateChangeProps(
                    cluster_id=["clusterId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    instance_fleet_id=["instanceFleetId"],
                    instance_fleet_type=["instanceFleetType"],
                    message=["message"],
                    provisioned_on_demand_capacity=["provisionedOnDemandCapacity"],
                    provisioned_spot_capacity=["provisionedSpotCapacity"],
                    severity=["severity"],
                    state=["state"],
                    target_on_demand_capacity=["targetOnDemandCapacity"],
                    target_spot_capacity=["targetSpotCapacity"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2986b51703211a6cdda1a868ab04953fc0a7d9e448dbcedece87e5a9dd346647)
                check_type(argname="argument cluster_id", value=cluster_id, expected_type=type_hints["cluster_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument instance_fleet_id", value=instance_fleet_id, expected_type=type_hints["instance_fleet_id"])
                check_type(argname="argument instance_fleet_type", value=instance_fleet_type, expected_type=type_hints["instance_fleet_type"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument provisioned_on_demand_capacity", value=provisioned_on_demand_capacity, expected_type=type_hints["provisioned_on_demand_capacity"])
                check_type(argname="argument provisioned_spot_capacity", value=provisioned_spot_capacity, expected_type=type_hints["provisioned_spot_capacity"])
                check_type(argname="argument severity", value=severity, expected_type=type_hints["severity"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
                check_type(argname="argument target_on_demand_capacity", value=target_on_demand_capacity, expected_type=type_hints["target_on_demand_capacity"])
                check_type(argname="argument target_spot_capacity", value=target_spot_capacity, expected_type=type_hints["target_spot_capacity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cluster_id is not None:
                self._values["cluster_id"] = cluster_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if instance_fleet_id is not None:
                self._values["instance_fleet_id"] = instance_fleet_id
            if instance_fleet_type is not None:
                self._values["instance_fleet_type"] = instance_fleet_type
            if message is not None:
                self._values["message"] = message
            if provisioned_on_demand_capacity is not None:
                self._values["provisioned_on_demand_capacity"] = provisioned_on_demand_capacity
            if provisioned_spot_capacity is not None:
                self._values["provisioned_spot_capacity"] = provisioned_spot_capacity
            if severity is not None:
                self._values["severity"] = severity
            if state is not None:
                self._values["state"] = state
            if target_on_demand_capacity is not None:
                self._values["target_on_demand_capacity"] = target_on_demand_capacity
            if target_spot_capacity is not None:
                self._values["target_spot_capacity"] = target_spot_capacity

        @builtins.property
        def cluster_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clusterId property.

            Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cluster_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def instance_fleet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceFleetId property.

            Specify an array of string values to match this event if the actual value of instanceFleetId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_fleet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_fleet_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceFleetType property.

            Specify an array of string values to match this event if the actual value of instanceFleetType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_fleet_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def provisioned_on_demand_capacity(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) provisionedOnDemandCapacity property.

            Specify an array of string values to match this event if the actual value of provisionedOnDemandCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("provisioned_on_demand_capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def provisioned_spot_capacity(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) provisionedSpotCapacity property.

            Specify an array of string values to match this event if the actual value of provisionedSpotCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("provisioned_spot_capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) severity property.

            Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def target_on_demand_capacity(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) targetOnDemandCapacity property.

            Specify an array of string values to match this event if the actual value of targetOnDemandCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_on_demand_capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def target_spot_capacity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) targetSpotCapacity property.

            Specify an array of string values to match this event if the actual value of targetSpotCapacity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("target_spot_capacity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EMRInstanceFleetStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EMRInstanceGroupStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRInstanceGroupStateChange",
):
    '''(experimental) EventBridge event pattern for aws.emr@EMRInstanceGroupStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_emr import events as emr_events
        
        e_mRInstance_group_state_change = emr_events.EMRInstanceGroupStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        bid_price: typing.Optional[typing.Sequence[builtins.str]] = None,
        bid_price_as_percentage_of_on_demand_price: typing.Optional[typing.Sequence[builtins.str]] = None,
        cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        instance_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        instance_group_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        market: typing.Optional[typing.Sequence[builtins.str]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        requested_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
        running_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
        severity: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EMR Instance Group State Change.

        :param bid_price: (experimental) bidPrice property. Specify an array of string values to match this event if the actual value of bidPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param bid_price_as_percentage_of_on_demand_price: (experimental) bidPriceAsPercentageOfOnDemandPrice property. Specify an array of string values to match this event if the actual value of bidPriceAsPercentageOfOnDemandPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param instance_group_id: (experimental) instanceGroupId property. Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param instance_group_type: (experimental) instanceGroupType property. Specify an array of string values to match this event if the actual value of instanceGroupType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param instance_type: (experimental) instanceType property. Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param market: (experimental) market property. Specify an array of string values to match this event if the actual value of market is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param requested_instance_count: (experimental) requestedInstanceCount property. Specify an array of string values to match this event if the actual value of requestedInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param running_instance_count: (experimental) runningInstanceCount property. Specify an array of string values to match this event if the actual value of runningInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EMRInstanceGroupStateChange.EMRInstanceGroupStateChangeProps(
            bid_price=bid_price,
            bid_price_as_percentage_of_on_demand_price=bid_price_as_percentage_of_on_demand_price,
            cluster_id=cluster_id,
            event_metadata=event_metadata,
            instance_group_id=instance_group_id,
            instance_group_type=instance_group_type,
            instance_type=instance_type,
            market=market,
            message=message,
            requested_instance_count=requested_instance_count,
            running_instance_count=running_instance_count,
            severity=severity,
            state=state,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRInstanceGroupStateChange.EMRInstanceGroupStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "bid_price": "bidPrice",
            "bid_price_as_percentage_of_on_demand_price": "bidPriceAsPercentageOfOnDemandPrice",
            "cluster_id": "clusterId",
            "event_metadata": "eventMetadata",
            "instance_group_id": "instanceGroupId",
            "instance_group_type": "instanceGroupType",
            "instance_type": "instanceType",
            "market": "market",
            "message": "message",
            "requested_instance_count": "requestedInstanceCount",
            "running_instance_count": "runningInstanceCount",
            "severity": "severity",
            "state": "state",
        },
    )
    class EMRInstanceGroupStateChangeProps:
        def __init__(
            self,
            *,
            bid_price: typing.Optional[typing.Sequence[builtins.str]] = None,
            bid_price_as_percentage_of_on_demand_price: typing.Optional[typing.Sequence[builtins.str]] = None,
            cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            instance_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_group_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            market: typing.Optional[typing.Sequence[builtins.str]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            requested_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            running_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.emr@EMRInstanceGroupStateChange event.

            :param bid_price: (experimental) bidPrice property. Specify an array of string values to match this event if the actual value of bidPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param bid_price_as_percentage_of_on_demand_price: (experimental) bidPriceAsPercentageOfOnDemandPrice property. Specify an array of string values to match this event if the actual value of bidPriceAsPercentageOfOnDemandPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param instance_group_id: (experimental) instanceGroupId property. Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_group_type: (experimental) instanceGroupType property. Specify an array of string values to match this event if the actual value of instanceGroupType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) instanceType property. Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param market: (experimental) market property. Specify an array of string values to match this event if the actual value of market is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param requested_instance_count: (experimental) requestedInstanceCount property. Specify an array of string values to match this event if the actual value of requestedInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param running_instance_count: (experimental) runningInstanceCount property. Specify an array of string values to match this event if the actual value of runningInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_emr import events as emr_events
                
                e_mRInstance_group_state_change_props = emr_events.EMRInstanceGroupStateChange.EMRInstanceGroupStateChangeProps(
                    bid_price=["bidPrice"],
                    bid_price_as_percentage_of_on_demand_price=["bidPriceAsPercentageOfOnDemandPrice"],
                    cluster_id=["clusterId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    instance_group_id=["instanceGroupId"],
                    instance_group_type=["instanceGroupType"],
                    instance_type=["instanceType"],
                    market=["market"],
                    message=["message"],
                    requested_instance_count=["requestedInstanceCount"],
                    running_instance_count=["runningInstanceCount"],
                    severity=["severity"],
                    state=["state"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__57c574b946d741891b34a4df72a69648d184e841b7e64ac1133aec3721ca6dac)
                check_type(argname="argument bid_price", value=bid_price, expected_type=type_hints["bid_price"])
                check_type(argname="argument bid_price_as_percentage_of_on_demand_price", value=bid_price_as_percentage_of_on_demand_price, expected_type=type_hints["bid_price_as_percentage_of_on_demand_price"])
                check_type(argname="argument cluster_id", value=cluster_id, expected_type=type_hints["cluster_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument instance_group_id", value=instance_group_id, expected_type=type_hints["instance_group_id"])
                check_type(argname="argument instance_group_type", value=instance_group_type, expected_type=type_hints["instance_group_type"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument market", value=market, expected_type=type_hints["market"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument requested_instance_count", value=requested_instance_count, expected_type=type_hints["requested_instance_count"])
                check_type(argname="argument running_instance_count", value=running_instance_count, expected_type=type_hints["running_instance_count"])
                check_type(argname="argument severity", value=severity, expected_type=type_hints["severity"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if bid_price is not None:
                self._values["bid_price"] = bid_price
            if bid_price_as_percentage_of_on_demand_price is not None:
                self._values["bid_price_as_percentage_of_on_demand_price"] = bid_price_as_percentage_of_on_demand_price
            if cluster_id is not None:
                self._values["cluster_id"] = cluster_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if instance_group_id is not None:
                self._values["instance_group_id"] = instance_group_id
            if instance_group_type is not None:
                self._values["instance_group_type"] = instance_group_type
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if market is not None:
                self._values["market"] = market
            if message is not None:
                self._values["message"] = message
            if requested_instance_count is not None:
                self._values["requested_instance_count"] = requested_instance_count
            if running_instance_count is not None:
                self._values["running_instance_count"] = running_instance_count
            if severity is not None:
                self._values["severity"] = severity
            if state is not None:
                self._values["state"] = state

        @builtins.property
        def bid_price(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bidPrice property.

            Specify an array of string values to match this event if the actual value of bidPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("bid_price")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def bid_price_as_percentage_of_on_demand_price(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bidPriceAsPercentageOfOnDemandPrice property.

            Specify an array of string values to match this event if the actual value of bidPriceAsPercentageOfOnDemandPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("bid_price_as_percentage_of_on_demand_price")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def cluster_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clusterId property.

            Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cluster_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def instance_group_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceGroupId property.

            Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_group_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_group_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceGroupType property.

            Specify an array of string values to match this event if the actual value of instanceGroupType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_group_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceType property.

            Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def market(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) market property.

            Specify an array of string values to match this event if the actual value of market is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("market")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def requested_instance_count(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestedInstanceCount property.

            Specify an array of string values to match this event if the actual value of requestedInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("requested_instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def running_instance_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) runningInstanceCount property.

            Specify an array of string values to match this event if the actual value of runningInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("running_instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) severity property.

            Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EMRInstanceGroupStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EMRInstanceGroupStatusNotification(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRInstanceGroupStatusNotification",
):
    '''(experimental) EventBridge event pattern for aws.emr@EMRInstanceGroupStatusNotification.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_emr import events as emr_events
        
        e_mRInstance_group_status_notification = emr_events.EMRInstanceGroupStatusNotification()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        bid_price: typing.Optional[typing.Sequence[builtins.str]] = None,
        bid_price_as_percentage_of_on_demand_price: typing.Optional[typing.Sequence[builtins.str]] = None,
        cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        instance_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        instance_group_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        market: typing.Optional[typing.Sequence[builtins.str]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        requested_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
        running_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
        severity: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EMR Instance Group Status Notification.

        :param bid_price: (experimental) bidPrice property. Specify an array of string values to match this event if the actual value of bidPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param bid_price_as_percentage_of_on_demand_price: (experimental) bidPriceAsPercentageOfOnDemandPrice property. Specify an array of string values to match this event if the actual value of bidPriceAsPercentageOfOnDemandPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param instance_group_id: (experimental) instanceGroupId property. Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param instance_group_type: (experimental) instanceGroupType property. Specify an array of string values to match this event if the actual value of instanceGroupType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param instance_type: (experimental) instanceType property. Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param market: (experimental) market property. Specify an array of string values to match this event if the actual value of market is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param requested_instance_count: (experimental) requestedInstanceCount property. Specify an array of string values to match this event if the actual value of requestedInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param running_instance_count: (experimental) runningInstanceCount property. Specify an array of string values to match this event if the actual value of runningInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EMRInstanceGroupStatusNotification.EMRInstanceGroupStatusNotificationProps(
            bid_price=bid_price,
            bid_price_as_percentage_of_on_demand_price=bid_price_as_percentage_of_on_demand_price,
            cluster_id=cluster_id,
            event_metadata=event_metadata,
            instance_group_id=instance_group_id,
            instance_group_type=instance_group_type,
            instance_type=instance_type,
            market=market,
            message=message,
            requested_instance_count=requested_instance_count,
            running_instance_count=running_instance_count,
            severity=severity,
            state=state,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRInstanceGroupStatusNotification.EMRInstanceGroupStatusNotificationProps",
        jsii_struct_bases=[],
        name_mapping={
            "bid_price": "bidPrice",
            "bid_price_as_percentage_of_on_demand_price": "bidPriceAsPercentageOfOnDemandPrice",
            "cluster_id": "clusterId",
            "event_metadata": "eventMetadata",
            "instance_group_id": "instanceGroupId",
            "instance_group_type": "instanceGroupType",
            "instance_type": "instanceType",
            "market": "market",
            "message": "message",
            "requested_instance_count": "requestedInstanceCount",
            "running_instance_count": "runningInstanceCount",
            "severity": "severity",
            "state": "state",
        },
    )
    class EMRInstanceGroupStatusNotificationProps:
        def __init__(
            self,
            *,
            bid_price: typing.Optional[typing.Sequence[builtins.str]] = None,
            bid_price_as_percentage_of_on_demand_price: typing.Optional[typing.Sequence[builtins.str]] = None,
            cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            instance_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_group_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            market: typing.Optional[typing.Sequence[builtins.str]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            requested_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            running_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.emr@EMRInstanceGroupStatusNotification event.

            :param bid_price: (experimental) bidPrice property. Specify an array of string values to match this event if the actual value of bidPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param bid_price_as_percentage_of_on_demand_price: (experimental) bidPriceAsPercentageOfOnDemandPrice property. Specify an array of string values to match this event if the actual value of bidPriceAsPercentageOfOnDemandPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param instance_group_id: (experimental) instanceGroupId property. Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_group_type: (experimental) instanceGroupType property. Specify an array of string values to match this event if the actual value of instanceGroupType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) instanceType property. Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param market: (experimental) market property. Specify an array of string values to match this event if the actual value of market is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param requested_instance_count: (experimental) requestedInstanceCount property. Specify an array of string values to match this event if the actual value of requestedInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param running_instance_count: (experimental) runningInstanceCount property. Specify an array of string values to match this event if the actual value of runningInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_emr import events as emr_events
                
                e_mRInstance_group_status_notification_props = emr_events.EMRInstanceGroupStatusNotification.EMRInstanceGroupStatusNotificationProps(
                    bid_price=["bidPrice"],
                    bid_price_as_percentage_of_on_demand_price=["bidPriceAsPercentageOfOnDemandPrice"],
                    cluster_id=["clusterId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    instance_group_id=["instanceGroupId"],
                    instance_group_type=["instanceGroupType"],
                    instance_type=["instanceType"],
                    market=["market"],
                    message=["message"],
                    requested_instance_count=["requestedInstanceCount"],
                    running_instance_count=["runningInstanceCount"],
                    severity=["severity"],
                    state=["state"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__25ca2bbce174aa6c3c2c1e88b5f40919aae583e157bfc69499474ae0fb17100f)
                check_type(argname="argument bid_price", value=bid_price, expected_type=type_hints["bid_price"])
                check_type(argname="argument bid_price_as_percentage_of_on_demand_price", value=bid_price_as_percentage_of_on_demand_price, expected_type=type_hints["bid_price_as_percentage_of_on_demand_price"])
                check_type(argname="argument cluster_id", value=cluster_id, expected_type=type_hints["cluster_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument instance_group_id", value=instance_group_id, expected_type=type_hints["instance_group_id"])
                check_type(argname="argument instance_group_type", value=instance_group_type, expected_type=type_hints["instance_group_type"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument market", value=market, expected_type=type_hints["market"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument requested_instance_count", value=requested_instance_count, expected_type=type_hints["requested_instance_count"])
                check_type(argname="argument running_instance_count", value=running_instance_count, expected_type=type_hints["running_instance_count"])
                check_type(argname="argument severity", value=severity, expected_type=type_hints["severity"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if bid_price is not None:
                self._values["bid_price"] = bid_price
            if bid_price_as_percentage_of_on_demand_price is not None:
                self._values["bid_price_as_percentage_of_on_demand_price"] = bid_price_as_percentage_of_on_demand_price
            if cluster_id is not None:
                self._values["cluster_id"] = cluster_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if instance_group_id is not None:
                self._values["instance_group_id"] = instance_group_id
            if instance_group_type is not None:
                self._values["instance_group_type"] = instance_group_type
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if market is not None:
                self._values["market"] = market
            if message is not None:
                self._values["message"] = message
            if requested_instance_count is not None:
                self._values["requested_instance_count"] = requested_instance_count
            if running_instance_count is not None:
                self._values["running_instance_count"] = running_instance_count
            if severity is not None:
                self._values["severity"] = severity
            if state is not None:
                self._values["state"] = state

        @builtins.property
        def bid_price(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bidPrice property.

            Specify an array of string values to match this event if the actual value of bidPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("bid_price")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def bid_price_as_percentage_of_on_demand_price(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) bidPriceAsPercentageOfOnDemandPrice property.

            Specify an array of string values to match this event if the actual value of bidPriceAsPercentageOfOnDemandPrice is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("bid_price_as_percentage_of_on_demand_price")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def cluster_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clusterId property.

            Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cluster_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def instance_group_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceGroupId property.

            Specify an array of string values to match this event if the actual value of instanceGroupId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_group_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_group_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceGroupType property.

            Specify an array of string values to match this event if the actual value of instanceGroupType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_group_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceType property.

            Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def market(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) market property.

            Specify an array of string values to match this event if the actual value of market is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("market")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def requested_instance_count(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestedInstanceCount property.

            Specify an array of string values to match this event if the actual value of requestedInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("requested_instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def running_instance_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) runningInstanceCount property.

            Specify an array of string values to match this event if the actual value of runningInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("running_instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) severity property.

            Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EMRInstanceGroupStatusNotificationProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EMRStepStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRStepStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.emr@EMRStepStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_emr import events as emr_events
        
        e_mRStep_status_change = emr_events.EMRStepStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        action_on_failure: typing.Optional[typing.Sequence[builtins.str]] = None,
        cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        message: typing.Optional[typing.Sequence[builtins.str]] = None,
        name: typing.Optional[typing.Sequence[builtins.str]] = None,
        severity: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
        step_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EMR Step Status Change.

        :param action_on_failure: (experimental) actionOnFailure property. Specify an array of string values to match this event if the actual value of actionOnFailure is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param step_id: (experimental) stepId property. Specify an array of string values to match this event if the actual value of stepId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = EMRStepStatusChange.EMRStepStatusChangeProps(
            action_on_failure=action_on_failure,
            cluster_id=cluster_id,
            event_metadata=event_metadata,
            message=message,
            name=name,
            severity=severity,
            state=state,
            step_id=step_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_emr.events.EMRStepStatusChange.EMRStepStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "action_on_failure": "actionOnFailure",
            "cluster_id": "clusterId",
            "event_metadata": "eventMetadata",
            "message": "message",
            "name": "name",
            "severity": "severity",
            "state": "state",
            "step_id": "stepId",
        },
    )
    class EMRStepStatusChangeProps:
        def __init__(
            self,
            *,
            action_on_failure: typing.Optional[typing.Sequence[builtins.str]] = None,
            cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            severity: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
            step_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.emr@EMRStepStatusChange event.

            :param action_on_failure: (experimental) actionOnFailure property. Specify an array of string values to match this event if the actual value of actionOnFailure is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param cluster_id: (experimental) clusterId property. Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param severity: (experimental) severity property. Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) state property. Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param step_id: (experimental) stepId property. Specify an array of string values to match this event if the actual value of stepId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_emr import events as emr_events
                
                e_mRStep_status_change_props = emr_events.EMRStepStatusChange.EMRStepStatusChangeProps(
                    action_on_failure=["actionOnFailure"],
                    cluster_id=["clusterId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    message=["message"],
                    name=["name"],
                    severity=["severity"],
                    state=["state"],
                    step_id=["stepId"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0479c079af1426c5d1f96a1876e35925a46a37cd7c53d234cfedef8192cd41c4)
                check_type(argname="argument action_on_failure", value=action_on_failure, expected_type=type_hints["action_on_failure"])
                check_type(argname="argument cluster_id", value=cluster_id, expected_type=type_hints["cluster_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument severity", value=severity, expected_type=type_hints["severity"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
                check_type(argname="argument step_id", value=step_id, expected_type=type_hints["step_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if action_on_failure is not None:
                self._values["action_on_failure"] = action_on_failure
            if cluster_id is not None:
                self._values["cluster_id"] = cluster_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if message is not None:
                self._values["message"] = message
            if name is not None:
                self._values["name"] = name
            if severity is not None:
                self._values["severity"] = severity
            if state is not None:
                self._values["state"] = state
            if step_id is not None:
                self._values["step_id"] = step_id

        @builtins.property
        def action_on_failure(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) actionOnFailure property.

            Specify an array of string values to match this event if the actual value of actionOnFailure is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("action_on_failure")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def cluster_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) clusterId property.

            Specify an array of string values to match this event if the actual value of clusterId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cluster_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def severity(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) severity property.

            Specify an array of string values to match this event if the actual value of severity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("severity")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) state property.

            Specify an array of string values to match this event if the actual value of state is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def step_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stepId property.

            Specify an array of string values to match this event if the actual value of stepId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("step_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EMRStepStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "EMRAutoScalingPolicyStateChange",
    "EMRClusterStateChange",
    "EMRConfigurationError",
    "EMRInstanceFleetStateChange",
    "EMRInstanceGroupStateChange",
    "EMRInstanceGroupStatusNotification",
    "EMRStepStatusChange",
]

publication.publish()

def _typecheckingstub__890394203611da678143b31ca2014dab3fcc3e8ec6f5a22c371c16c6669065a2(
    *,
    cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    resource_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    scaling_resource_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__684c62041eae01697840ff7c6a87c9a0761e64637579d0ad53cfe27f67422f47(
    *,
    cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
    state_change_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9b557a2aade7712e44b61e6388e64efad2cbcb11d8ba7358c461fdd6afe3d3b9(
    *,
    cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    severity: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2986b51703211a6cdda1a868ab04953fc0a7d9e448dbcedece87e5a9dd346647(
    *,
    cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    instance_fleet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_fleet_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    provisioned_on_demand_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
    provisioned_spot_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
    severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
    target_on_demand_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
    target_spot_capacity: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57c574b946d741891b34a4df72a69648d184e841b7e64ac1133aec3721ca6dac(
    *,
    bid_price: typing.Optional[typing.Sequence[builtins.str]] = None,
    bid_price_as_percentage_of_on_demand_price: typing.Optional[typing.Sequence[builtins.str]] = None,
    cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    instance_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_group_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    market: typing.Optional[typing.Sequence[builtins.str]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    requested_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    running_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__25ca2bbce174aa6c3c2c1e88b5f40919aae583e157bfc69499474ae0fb17100f(
    *,
    bid_price: typing.Optional[typing.Sequence[builtins.str]] = None,
    bid_price_as_percentage_of_on_demand_price: typing.Optional[typing.Sequence[builtins.str]] = None,
    cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    instance_group_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_group_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    market: typing.Optional[typing.Sequence[builtins.str]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    requested_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    running_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0479c079af1426c5d1f96a1876e35925a46a37cd7c53d234cfedef8192cd41c4(
    *,
    action_on_failure: typing.Optional[typing.Sequence[builtins.str]] = None,
    cluster_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    severity: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
    step_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
