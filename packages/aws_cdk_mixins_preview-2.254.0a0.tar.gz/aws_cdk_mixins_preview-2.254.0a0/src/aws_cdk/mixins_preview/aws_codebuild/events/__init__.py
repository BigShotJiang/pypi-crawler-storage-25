from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d
import aws_cdk.interfaces.aws_codebuild as _aws_cdk_interfaces_aws_codebuild_ceddda9d


class AWSAPICallViaCloudTrail(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail",
):
    '''(experimental) EventBridge event pattern for aws.codebuild@AWSAPICallViaCloudTrail.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
        
        a_wSAPICall_via_cloud_trail = codebuild_events.AWSAPICallViaCloudTrail()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
        source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AWS API Call via CloudTrail.

        :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
            aws_region=aws_region,
            error_code=error_code,
            error_message=error_message,
            event_id=event_id,
            event_metadata=event_metadata,
            event_name=event_name,
            event_source=event_source,
            event_time=event_time,
            event_type=event_type,
            event_version=event_version,
            request_id=request_id,
            request_parameters=request_parameters,
            response_elements=response_elements,
            source_ip_address=source_ip_address,
            user_agent=user_agent,
            user_identity=user_identity,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps",
        jsii_struct_bases=[],
        name_mapping={
            "aws_region": "awsRegion",
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "event_name": "eventName",
            "event_source": "eventSource",
            "event_time": "eventTime",
            "event_type": "eventType",
            "event_version": "eventVersion",
            "request_id": "requestId",
            "request_parameters": "requestParameters",
            "response_elements": "responseElements",
            "source_ip_address": "sourceIpAddress",
            "user_agent": "userAgent",
            "user_identity": "userIdentity",
        },
    )
    class AWSAPICallViaCloudTrailProps:
        def __init__(
            self,
            *,
            aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
            response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
            source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codebuild@AWSAPICallViaCloudTrail event.

            :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                a_wSAPICall_via_cloud_trail_props = codebuild_events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
                    aws_region=["awsRegion"],
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    event_name=["eventName"],
                    event_source=["eventSource"],
                    event_time=["eventTime"],
                    event_type=["eventType"],
                    event_version=["eventVersion"],
                    request_id=["requestId"],
                    request_parameters=codebuild_events.AWSAPICallViaCloudTrail.RequestParameters(
                        aws_act_id=["awsActId"],
                        invoked_by=["invokedBy"],
                        payer_id=["payerId"],
                        user_arn=["userArn"]
                    ),
                    response_elements=codebuild_events.AWSAPICallViaCloudTrail.ResponseElements(
                        build_property=codebuild_events.AWSAPICallViaCloudTrail.Build(
                            arn=["arn"],
                            artifacts=codebuild_events.AWSAPICallViaCloudTrail.Artifacts(
                                encryption_disabled=["encryptionDisabled"],
                                location=["location"]
                            ),
                            build_complete=["buildComplete"],
                            build_status=["buildStatus"],
                            cache=codebuild_events.AWSAPICallViaCloudTrail.Cache(
                                location=["location"],
                                type=["type"]
                            ),
                            current_phase=["currentPhase"],
                            encryption_key=["encryptionKey"],
                            end_time=["endTime"],
                            environment=codebuild_events.AWSAPICallViaCloudTrail.Environment(
                                certificate=["certificate"],
                                compute_type=["computeType"],
                                environment_variables=[codebuild_events.AWSAPICallViaCloudTrail.EnvironmentItem(
                                    name=["name"],
                                    type=["type"],
                                    value=["value"]
                                )],
                                image=["image"],
                                image_pull_credentials_type=["imagePullCredentialsType"],
                                privileged_mode=["privilegedMode"],
                                type=["type"]
                            ),
                            id=["id"],
                            initiator=["initiator"],
                            logs=codebuild_events.AWSAPICallViaCloudTrail.Logs(
                                deep_link=["deepLink"],
                                group_name=["groupName"],
                                stream_name=["streamName"]
                            ),
                            phases=[codebuild_events.AWSAPICallViaCloudTrail.BuildPhase(
                                duration_in_seconds=["durationInSeconds"],
                                end_time=["endTime"],
                                phase_context=["phaseContext"],
                                phase_status=["phaseStatus"],
                                phase_type=["phaseType"],
                                start_time=["startTime"]
                            )],
                            project_name=["projectName"],
                            queued_timeout_in_minutes=["queuedTimeoutInMinutes"],
                            resolved_source_version=["resolvedSourceVersion"],
                            service_role=["serviceRole"],
                            source=codebuild_events.AWSAPICallViaCloudTrail.Source(
                                auth=codebuild_events.AWSAPICallViaCloudTrail.Auth(
                                    type=["type"]
                                ),
                                buildspec=["buildspec"],
                                insecure_ssl=["insecureSsl"],
                                location=["location"],
                                report_build_status=["reportBuildStatus"],
                                type=["type"]
                            ),
                            source_version=["sourceVersion"],
                            start_time=["startTime"],
                            timeout_in_minutes=["timeoutInMinutes"],
                            vpc_config=codebuild_events.AWSAPICallViaCloudTrail.VpcConfig(
                                security_group_ids=["securityGroupIds"],
                                subnets=["subnets"],
                                vpc_id=["vpcId"]
                            )
                        ),
                        message=["message"],
                        project=codebuild_events.AWSAPICallViaCloudTrail.Project(
                            arn=["arn"],
                            artifacts=codebuild_events.AWSAPICallViaCloudTrail.Artifacts1(
                                encryption_disabled=["encryptionDisabled"],
                                location=["location"],
                                name=["name"],
                                namespace_type=["namespaceType"],
                                packaging=["packaging"],
                                type=["type"]
                            ),
                            badge=codebuild_events.AWSAPICallViaCloudTrail.Badge(
                                badge_enabled=["badgeEnabled"],
                                badge_request_url=["badgeRequestUrl"]
                            ),
                            cache=codebuild_events.AWSAPICallViaCloudTrail.Cache(
                                location=["location"],
                                type=["type"]
                            ),
                            created=["created"],
                            description=["description"],
                            encryption_key=["encryptionKey"],
                            environment=codebuild_events.AWSAPICallViaCloudTrail.Environment1(
                                compute_type=["computeType"],
                                environment_variables=[codebuild_events.AWSAPICallViaCloudTrail.EnvironmentItem(
                                    name=["name"],
                                    type=["type"],
                                    value=["value"]
                                )],
                                image=["image"],
                                image_pull_credentials_type=["imagePullCredentialsType"],
                                privileged_mode=["privilegedMode"],
                                type=["type"]
                            ),
                            last_modified=["lastModified"],
                            name=["name"],
                            queued_timeout_in_minutes=["queuedTimeoutInMinutes"],
                            service_role=["serviceRole"],
                            source=codebuild_events.AWSAPICallViaCloudTrail.Source1(
                                auth=codebuild_events.AWSAPICallViaCloudTrail.Auth(
                                    type=["type"]
                                ),
                                buildspec=["buildspec"],
                                git_clone_depth=["gitCloneDepth"],
                                git_submodules_config=codebuild_events.AWSAPICallViaCloudTrail.GitSubmodulesConfig(
                                    fetch_submodules=["fetchSubmodules"]
                                ),
                                insecure_ssl=["insecureSsl"],
                                location=["location"],
                                report_build_status=["reportBuildStatus"],
                                type=["type"]
                            ),
                            source_version=["sourceVersion"],
                            tags=[codebuild_events.AWSAPICallViaCloudTrail.ProjectItem(
                                key=["key"],
                                value=["value"]
                            )],
                            timeout_in_minutes=["timeoutInMinutes"]
                        ),
                        webhook=codebuild_events.AWSAPICallViaCloudTrail.Webhook(
                            branch_filter=["branchFilter"],
                            last_modified_secret=["lastModifiedSecret"],
                            payload_url=["payloadUrl"],
                            url=["url"]
                        ),
                        webhook_deleted_status=["webhookDeletedStatus"]
                    ),
                    source_ip_address=["sourceIpAddress"],
                    user_agent=["userAgent"],
                    user_identity=codebuild_events.AWSAPICallViaCloudTrail.UserIdentity(
                        access_key_id=["accessKeyId"],
                        account_id=["accountId"],
                        arn=["arn"],
                        invoked_by=["invokedBy"],
                        principal_id=["principalId"],
                        session_context=codebuild_events.AWSAPICallViaCloudTrail.SessionContext(
                            attributes=codebuild_events.AWSAPICallViaCloudTrail.Attributes(
                                creation_date=["creationDate"],
                                mfa_authenticated=["mfaAuthenticated"]
                            ),
                            session_issuer=codebuild_events.AWSAPICallViaCloudTrail.SessionIssuer(
                                account_id=["accountId"],
                                arn=["arn"],
                                principal_id=["principalId"],
                                type=["type"],
                                user_name=["userName"]
                            )
                        ),
                        type=["type"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(request_parameters, dict):
                request_parameters = AWSAPICallViaCloudTrail.RequestParameters(**request_parameters)
            if isinstance(response_elements, dict):
                response_elements = AWSAPICallViaCloudTrail.ResponseElements(**response_elements)
            if isinstance(user_identity, dict):
                user_identity = AWSAPICallViaCloudTrail.UserIdentity(**user_identity)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fa552bdf4a36229f5517550b44d72498cd203aa0ad6be6bd1b83a88613991b92)
                check_type(argname="argument aws_region", value=aws_region, expected_type=type_hints["aws_region"])
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument event_name", value=event_name, expected_type=type_hints["event_name"])
                check_type(argname="argument event_source", value=event_source, expected_type=type_hints["event_source"])
                check_type(argname="argument event_time", value=event_time, expected_type=type_hints["event_time"])
                check_type(argname="argument event_type", value=event_type, expected_type=type_hints["event_type"])
                check_type(argname="argument event_version", value=event_version, expected_type=type_hints["event_version"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument request_parameters", value=request_parameters, expected_type=type_hints["request_parameters"])
                check_type(argname="argument response_elements", value=response_elements, expected_type=type_hints["response_elements"])
                check_type(argname="argument source_ip_address", value=source_ip_address, expected_type=type_hints["source_ip_address"])
                check_type(argname="argument user_agent", value=user_agent, expected_type=type_hints["user_agent"])
                check_type(argname="argument user_identity", value=user_identity, expected_type=type_hints["user_identity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if aws_region is not None:
                self._values["aws_region"] = aws_region
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if event_name is not None:
                self._values["event_name"] = event_name
            if event_source is not None:
                self._values["event_source"] = event_source
            if event_time is not None:
                self._values["event_time"] = event_time
            if event_type is not None:
                self._values["event_type"] = event_type
            if event_version is not None:
                self._values["event_version"] = event_version
            if request_id is not None:
                self._values["request_id"] = request_id
            if request_parameters is not None:
                self._values["request_parameters"] = request_parameters
            if response_elements is not None:
                self._values["response_elements"] = response_elements
            if source_ip_address is not None:
                self._values["source_ip_address"] = source_ip_address
            if user_agent is not None:
                self._values["user_agent"] = user_agent
            if user_identity is not None:
                self._values["user_identity"] = user_identity

        @builtins.property
        def aws_region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) awsRegion property.

            Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventID property.

            Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def event_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventName property.

            Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventSource property.

            Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventTime property.

            Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventType property.

            Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventVersion property.

            Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestID property.

            Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_parameters(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"]:
            '''(experimental) requestParameters property.

            Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_parameters")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"], result)

        @builtins.property
        def response_elements(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"]:
            '''(experimental) responseElements property.

            Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("response_elements")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"], result)

        @builtins.property
        def source_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceIPAddress property.

            Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_agent(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userAgent property.

            Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_agent")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_identity(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"]:
            '''(experimental) userIdentity property.

            Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_identity")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AWSAPICallViaCloudTrailProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Artifacts",
        jsii_struct_bases=[],
        name_mapping={
            "encryption_disabled": "encryptionDisabled",
            "location": "location",
        },
    )
    class Artifacts:
        def __init__(
            self,
            *,
            encryption_disabled: typing.Optional[typing.Sequence[builtins.str]] = None,
            location: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Artifacts.

            :param encryption_disabled: (experimental) encryptionDisabled property. Specify an array of string values to match this event if the actual value of encryptionDisabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                artifacts = codebuild_events.AWSAPICallViaCloudTrail.Artifacts(
                    encryption_disabled=["encryptionDisabled"],
                    location=["location"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__809250864e736be36bc032a9f237864ef531bd9dbb88c9551337b4e507759862)
                check_type(argname="argument encryption_disabled", value=encryption_disabled, expected_type=type_hints["encryption_disabled"])
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if encryption_disabled is not None:
                self._values["encryption_disabled"] = encryption_disabled
            if location is not None:
                self._values["location"] = location

        @builtins.property
        def encryption_disabled(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) encryptionDisabled property.

            Specify an array of string values to match this event if the actual value of encryptionDisabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("encryption_disabled")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Artifacts(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Artifacts1",
        jsii_struct_bases=[],
        name_mapping={
            "encryption_disabled": "encryptionDisabled",
            "location": "location",
            "name": "name",
            "namespace_type": "namespaceType",
            "packaging": "packaging",
            "type": "type",
        },
    )
    class Artifacts1:
        def __init__(
            self,
            *,
            encryption_disabled: typing.Optional[typing.Sequence[builtins.str]] = None,
            location: typing.Optional[typing.Sequence[builtins.str]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            namespace_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            packaging: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Artifacts_1.

            :param encryption_disabled: (experimental) encryptionDisabled property. Specify an array of string values to match this event if the actual value of encryptionDisabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param namespace_type: (experimental) namespaceType property. Specify an array of string values to match this event if the actual value of namespaceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param packaging: (experimental) packaging property. Specify an array of string values to match this event if the actual value of packaging is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                artifacts1 = codebuild_events.AWSAPICallViaCloudTrail.Artifacts1(
                    encryption_disabled=["encryptionDisabled"],
                    location=["location"],
                    name=["name"],
                    namespace_type=["namespaceType"],
                    packaging=["packaging"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__eeee42334e0f209fa9132b9ebeff56ef6f845a565bc511b572f12777cdba76cd)
                check_type(argname="argument encryption_disabled", value=encryption_disabled, expected_type=type_hints["encryption_disabled"])
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument namespace_type", value=namespace_type, expected_type=type_hints["namespace_type"])
                check_type(argname="argument packaging", value=packaging, expected_type=type_hints["packaging"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if encryption_disabled is not None:
                self._values["encryption_disabled"] = encryption_disabled
            if location is not None:
                self._values["location"] = location
            if name is not None:
                self._values["name"] = name
            if namespace_type is not None:
                self._values["namespace_type"] = namespace_type
            if packaging is not None:
                self._values["packaging"] = packaging
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def encryption_disabled(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) encryptionDisabled property.

            Specify an array of string values to match this event if the actual value of encryptionDisabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("encryption_disabled")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def namespace_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) namespaceType property.

            Specify an array of string values to match this event if the actual value of namespaceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("namespace_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def packaging(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) packaging property.

            Specify an array of string values to match this event if the actual value of packaging is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("packaging")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Artifacts1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "creation_date": "creationDate",
            "mfa_authenticated": "mfaAuthenticated",
        },
    )
    class Attributes:
        def __init__(
            self,
            *,
            creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Attributes.

            :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param mfa_authenticated: (experimental) mfaAuthenticated property. Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                attributes = codebuild_events.AWSAPICallViaCloudTrail.Attributes(
                    creation_date=["creationDate"],
                    mfa_authenticated=["mfaAuthenticated"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f007912bddd55b8d4f1eb42780f74513b0ac9b09c2bd982beb035adc29823934)
                check_type(argname="argument creation_date", value=creation_date, expected_type=type_hints["creation_date"])
                check_type(argname="argument mfa_authenticated", value=mfa_authenticated, expected_type=type_hints["mfa_authenticated"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_date is not None:
                self._values["creation_date"] = creation_date
            if mfa_authenticated is not None:
                self._values["mfa_authenticated"] = mfa_authenticated

        @builtins.property
        def creation_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationDate property.

            Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def mfa_authenticated(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mfaAuthenticated property.

            Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("mfa_authenticated")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Auth",
        jsii_struct_bases=[],
        name_mapping={"type": "type"},
    )
    class Auth:
        def __init__(
            self,
            *,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Auth.

            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                auth = codebuild_events.AWSAPICallViaCloudTrail.Auth(
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__dd3d68d027f06f272acbca3ded2d62027f5d222d778ec2ee5c7cafdee1ef6b67)
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Auth(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Badge",
        jsii_struct_bases=[],
        name_mapping={
            "badge_enabled": "badgeEnabled",
            "badge_request_url": "badgeRequestUrl",
        },
    )
    class Badge:
        def __init__(
            self,
            *,
            badge_enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
            badge_request_url: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Badge.

            :param badge_enabled: (experimental) badgeEnabled property. Specify an array of string values to match this event if the actual value of badgeEnabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param badge_request_url: (experimental) badgeRequestUrl property. Specify an array of string values to match this event if the actual value of badgeRequestUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                badge = codebuild_events.AWSAPICallViaCloudTrail.Badge(
                    badge_enabled=["badgeEnabled"],
                    badge_request_url=["badgeRequestUrl"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__48addcf0053c18cc44093d2eef8a71fd3ec206b5d149210d769ed6eaf5d2b7fc)
                check_type(argname="argument badge_enabled", value=badge_enabled, expected_type=type_hints["badge_enabled"])
                check_type(argname="argument badge_request_url", value=badge_request_url, expected_type=type_hints["badge_request_url"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if badge_enabled is not None:
                self._values["badge_enabled"] = badge_enabled
            if badge_request_url is not None:
                self._values["badge_request_url"] = badge_request_url

        @builtins.property
        def badge_enabled(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) badgeEnabled property.

            Specify an array of string values to match this event if the actual value of badgeEnabled is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("badge_enabled")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def badge_request_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) badgeRequestUrl property.

            Specify an array of string values to match this event if the actual value of badgeRequestUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("badge_request_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Badge(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Build",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "artifacts": "artifacts",
            "build_complete": "buildComplete",
            "build_status": "buildStatus",
            "cache": "cache",
            "current_phase": "currentPhase",
            "encryption_key": "encryptionKey",
            "end_time": "endTime",
            "environment": "environment",
            "id": "id",
            "initiator": "initiator",
            "logs": "logs",
            "phases": "phases",
            "project_name": "projectName",
            "queued_timeout_in_minutes": "queuedTimeoutInMinutes",
            "resolved_source_version": "resolvedSourceVersion",
            "service_role": "serviceRole",
            "source": "source",
            "source_version": "sourceVersion",
            "start_time": "startTime",
            "timeout_in_minutes": "timeoutInMinutes",
            "vpc_config": "vpcConfig",
        },
    )
    class Build:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            artifacts: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Artifacts", typing.Dict[builtins.str, typing.Any]]] = None,
            build_complete: typing.Optional[typing.Sequence[builtins.str]] = None,
            build_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            cache: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Cache", typing.Dict[builtins.str, typing.Any]]] = None,
            current_phase: typing.Optional[typing.Sequence[builtins.str]] = None,
            encryption_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            environment: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Environment", typing.Dict[builtins.str, typing.Any]]] = None,
            id: typing.Optional[typing.Sequence[builtins.str]] = None,
            initiator: typing.Optional[typing.Sequence[builtins.str]] = None,
            logs: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Logs", typing.Dict[builtins.str, typing.Any]]] = None,
            phases: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.BuildPhase", typing.Dict[builtins.str, typing.Any]]]] = None,
            project_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            queued_timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
            resolved_source_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            service_role: typing.Optional[typing.Sequence[builtins.str]] = None,
            source: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Source", typing.Dict[builtins.str, typing.Any]]] = None,
            source_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
            vpc_config: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.VpcConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for Build.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param artifacts: (experimental) artifacts property. Specify an array of string values to match this event if the actual value of artifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param build_complete: (experimental) buildComplete property. Specify an array of string values to match this event if the actual value of buildComplete is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param build_status: (experimental) buildStatus property. Specify an array of string values to match this event if the actual value of buildStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param cache: (experimental) cache property. Specify an array of string values to match this event if the actual value of cache is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param current_phase: (experimental) currentPhase property. Specify an array of string values to match this event if the actual value of currentPhase is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param encryption_key: (experimental) encryptionKey property. Specify an array of string values to match this event if the actual value of encryptionKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param environment: (experimental) environment property. Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param id: (experimental) id property. Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param initiator: (experimental) initiator property. Specify an array of string values to match this event if the actual value of initiator is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param logs: (experimental) logs property. Specify an array of string values to match this event if the actual value of logs is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param phases: (experimental) phases property. Specify an array of string values to match this event if the actual value of phases is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param project_name: (experimental) projectName property. Specify an array of string values to match this event if the actual value of projectName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param queued_timeout_in_minutes: (experimental) queuedTimeoutInMinutes property. Specify an array of string values to match this event if the actual value of queuedTimeoutInMinutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resolved_source_version: (experimental) resolvedSourceVersion property. Specify an array of string values to match this event if the actual value of resolvedSourceVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param service_role: (experimental) serviceRole property. Specify an array of string values to match this event if the actual value of serviceRole is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source: (experimental) source property. Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_version: (experimental) sourceVersion property. Specify an array of string values to match this event if the actual value of sourceVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param timeout_in_minutes: (experimental) timeoutInMinutes property. Specify an array of string values to match this event if the actual value of timeoutInMinutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_config: (experimental) vpcConfig property. Specify an array of string values to match this event if the actual value of vpcConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                build = codebuild_events.AWSAPICallViaCloudTrail.Build(
                    arn=["arn"],
                    artifacts=codebuild_events.AWSAPICallViaCloudTrail.Artifacts(
                        encryption_disabled=["encryptionDisabled"],
                        location=["location"]
                    ),
                    build_complete=["buildComplete"],
                    build_status=["buildStatus"],
                    cache=codebuild_events.AWSAPICallViaCloudTrail.Cache(
                        location=["location"],
                        type=["type"]
                    ),
                    current_phase=["currentPhase"],
                    encryption_key=["encryptionKey"],
                    end_time=["endTime"],
                    environment=codebuild_events.AWSAPICallViaCloudTrail.Environment(
                        certificate=["certificate"],
                        compute_type=["computeType"],
                        environment_variables=[codebuild_events.AWSAPICallViaCloudTrail.EnvironmentItem(
                            name=["name"],
                            type=["type"],
                            value=["value"]
                        )],
                        image=["image"],
                        image_pull_credentials_type=["imagePullCredentialsType"],
                        privileged_mode=["privilegedMode"],
                        type=["type"]
                    ),
                    id=["id"],
                    initiator=["initiator"],
                    logs=codebuild_events.AWSAPICallViaCloudTrail.Logs(
                        deep_link=["deepLink"],
                        group_name=["groupName"],
                        stream_name=["streamName"]
                    ),
                    phases=[codebuild_events.AWSAPICallViaCloudTrail.BuildPhase(
                        duration_in_seconds=["durationInSeconds"],
                        end_time=["endTime"],
                        phase_context=["phaseContext"],
                        phase_status=["phaseStatus"],
                        phase_type=["phaseType"],
                        start_time=["startTime"]
                    )],
                    project_name=["projectName"],
                    queued_timeout_in_minutes=["queuedTimeoutInMinutes"],
                    resolved_source_version=["resolvedSourceVersion"],
                    service_role=["serviceRole"],
                    source=codebuild_events.AWSAPICallViaCloudTrail.Source(
                        auth=codebuild_events.AWSAPICallViaCloudTrail.Auth(
                            type=["type"]
                        ),
                        buildspec=["buildspec"],
                        insecure_ssl=["insecureSsl"],
                        location=["location"],
                        report_build_status=["reportBuildStatus"],
                        type=["type"]
                    ),
                    source_version=["sourceVersion"],
                    start_time=["startTime"],
                    timeout_in_minutes=["timeoutInMinutes"],
                    vpc_config=codebuild_events.AWSAPICallViaCloudTrail.VpcConfig(
                        security_group_ids=["securityGroupIds"],
                        subnets=["subnets"],
                        vpc_id=["vpcId"]
                    )
                )
            '''
            if isinstance(artifacts, dict):
                artifacts = AWSAPICallViaCloudTrail.Artifacts(**artifacts)
            if isinstance(cache, dict):
                cache = AWSAPICallViaCloudTrail.Cache(**cache)
            if isinstance(environment, dict):
                environment = AWSAPICallViaCloudTrail.Environment(**environment)
            if isinstance(logs, dict):
                logs = AWSAPICallViaCloudTrail.Logs(**logs)
            if isinstance(source, dict):
                source = AWSAPICallViaCloudTrail.Source(**source)
            if isinstance(vpc_config, dict):
                vpc_config = AWSAPICallViaCloudTrail.VpcConfig(**vpc_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5906d999b3c1d1f6ff4241f12e5cc946cb7f852c2242393d128b2bb5850f8535)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument artifacts", value=artifacts, expected_type=type_hints["artifacts"])
                check_type(argname="argument build_complete", value=build_complete, expected_type=type_hints["build_complete"])
                check_type(argname="argument build_status", value=build_status, expected_type=type_hints["build_status"])
                check_type(argname="argument cache", value=cache, expected_type=type_hints["cache"])
                check_type(argname="argument current_phase", value=current_phase, expected_type=type_hints["current_phase"])
                check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument environment", value=environment, expected_type=type_hints["environment"])
                check_type(argname="argument id", value=id, expected_type=type_hints["id"])
                check_type(argname="argument initiator", value=initiator, expected_type=type_hints["initiator"])
                check_type(argname="argument logs", value=logs, expected_type=type_hints["logs"])
                check_type(argname="argument phases", value=phases, expected_type=type_hints["phases"])
                check_type(argname="argument project_name", value=project_name, expected_type=type_hints["project_name"])
                check_type(argname="argument queued_timeout_in_minutes", value=queued_timeout_in_minutes, expected_type=type_hints["queued_timeout_in_minutes"])
                check_type(argname="argument resolved_source_version", value=resolved_source_version, expected_type=type_hints["resolved_source_version"])
                check_type(argname="argument service_role", value=service_role, expected_type=type_hints["service_role"])
                check_type(argname="argument source", value=source, expected_type=type_hints["source"])
                check_type(argname="argument source_version", value=source_version, expected_type=type_hints["source_version"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument timeout_in_minutes", value=timeout_in_minutes, expected_type=type_hints["timeout_in_minutes"])
                check_type(argname="argument vpc_config", value=vpc_config, expected_type=type_hints["vpc_config"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if artifacts is not None:
                self._values["artifacts"] = artifacts
            if build_complete is not None:
                self._values["build_complete"] = build_complete
            if build_status is not None:
                self._values["build_status"] = build_status
            if cache is not None:
                self._values["cache"] = cache
            if current_phase is not None:
                self._values["current_phase"] = current_phase
            if encryption_key is not None:
                self._values["encryption_key"] = encryption_key
            if end_time is not None:
                self._values["end_time"] = end_time
            if environment is not None:
                self._values["environment"] = environment
            if id is not None:
                self._values["id"] = id
            if initiator is not None:
                self._values["initiator"] = initiator
            if logs is not None:
                self._values["logs"] = logs
            if phases is not None:
                self._values["phases"] = phases
            if project_name is not None:
                self._values["project_name"] = project_name
            if queued_timeout_in_minutes is not None:
                self._values["queued_timeout_in_minutes"] = queued_timeout_in_minutes
            if resolved_source_version is not None:
                self._values["resolved_source_version"] = resolved_source_version
            if service_role is not None:
                self._values["service_role"] = service_role
            if source is not None:
                self._values["source"] = source
            if source_version is not None:
                self._values["source_version"] = source_version
            if start_time is not None:
                self._values["start_time"] = start_time
            if timeout_in_minutes is not None:
                self._values["timeout_in_minutes"] = timeout_in_minutes
            if vpc_config is not None:
                self._values["vpc_config"] = vpc_config

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def artifacts(self) -> typing.Optional["AWSAPICallViaCloudTrail.Artifacts"]:
            '''(experimental) artifacts property.

            Specify an array of string values to match this event if the actual value of artifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("artifacts")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Artifacts"], result)

        @builtins.property
        def build_complete(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) buildComplete property.

            Specify an array of string values to match this event if the actual value of buildComplete is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("build_complete")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def build_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) buildStatus property.

            Specify an array of string values to match this event if the actual value of buildStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("build_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def cache(self) -> typing.Optional["AWSAPICallViaCloudTrail.Cache"]:
            '''(experimental) cache property.

            Specify an array of string values to match this event if the actual value of cache is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cache")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Cache"], result)

        @builtins.property
        def current_phase(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) currentPhase property.

            Specify an array of string values to match this event if the actual value of currentPhase is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_phase")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def encryption_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) encryptionKey property.

            Specify an array of string values to match this event if the actual value of encryptionKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("encryption_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTime property.

            Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def environment(self) -> typing.Optional["AWSAPICallViaCloudTrail.Environment"]:
            '''(experimental) environment property.

            Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("environment")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Environment"], result)

        @builtins.property
        def id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) id property.

            Specify an array of string values to match this event if the actual value of id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def initiator(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) initiator property.

            Specify an array of string values to match this event if the actual value of initiator is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("initiator")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def logs(self) -> typing.Optional["AWSAPICallViaCloudTrail.Logs"]:
            '''(experimental) logs property.

            Specify an array of string values to match this event if the actual value of logs is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("logs")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Logs"], result)

        @builtins.property
        def phases(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.BuildPhase"]]:
            '''(experimental) phases property.

            Specify an array of string values to match this event if the actual value of phases is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("phases")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.BuildPhase"]], result)

        @builtins.property
        def project_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) projectName property.

            Specify an array of string values to match this event if the actual value of projectName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("project_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def queued_timeout_in_minutes(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) queuedTimeoutInMinutes property.

            Specify an array of string values to match this event if the actual value of queuedTimeoutInMinutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("queued_timeout_in_minutes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def resolved_source_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resolvedSourceVersion property.

            Specify an array of string values to match this event if the actual value of resolvedSourceVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resolved_source_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def service_role(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) serviceRole property.

            Specify an array of string values to match this event if the actual value of serviceRole is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("service_role")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source(self) -> typing.Optional["AWSAPICallViaCloudTrail.Source"]:
            '''(experimental) source property.

            Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Source"], result)

        @builtins.property
        def source_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceVersion property.

            Specify an array of string values to match this event if the actual value of sourceVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def timeout_in_minutes(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) timeoutInMinutes property.

            Specify an array of string values to match this event if the actual value of timeoutInMinutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("timeout_in_minutes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def vpc_config(self) -> typing.Optional["AWSAPICallViaCloudTrail.VpcConfig"]:
            '''(experimental) vpcConfig property.

            Specify an array of string values to match this event if the actual value of vpcConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_config")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.VpcConfig"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Build(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.BuildPhase",
        jsii_struct_bases=[],
        name_mapping={
            "duration_in_seconds": "durationInSeconds",
            "end_time": "endTime",
            "phase_context": "phaseContext",
            "phase_status": "phaseStatus",
            "phase_type": "phaseType",
            "start_time": "startTime",
        },
    )
    class BuildPhase:
        def __init__(
            self,
            *,
            duration_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
            phase_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            phase_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for BuildPhase.

            :param duration_in_seconds: (experimental) durationInSeconds property. Specify an array of string values to match this event if the actual value of durationInSeconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) endTime property. Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param phase_context: (experimental) phaseContext property. Specify an array of string values to match this event if the actual value of phaseContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param phase_status: (experimental) phaseStatus property. Specify an array of string values to match this event if the actual value of phaseStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param phase_type: (experimental) phaseType property. Specify an array of string values to match this event if the actual value of phaseType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                build_phase = codebuild_events.AWSAPICallViaCloudTrail.BuildPhase(
                    duration_in_seconds=["durationInSeconds"],
                    end_time=["endTime"],
                    phase_context=["phaseContext"],
                    phase_status=["phaseStatus"],
                    phase_type=["phaseType"],
                    start_time=["startTime"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__25e36d0fb822e106e44351a88353df9b168ba8727f5fb0cbc3010ff35c7adf82)
                check_type(argname="argument duration_in_seconds", value=duration_in_seconds, expected_type=type_hints["duration_in_seconds"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument phase_context", value=phase_context, expected_type=type_hints["phase_context"])
                check_type(argname="argument phase_status", value=phase_status, expected_type=type_hints["phase_status"])
                check_type(argname="argument phase_type", value=phase_type, expected_type=type_hints["phase_type"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if duration_in_seconds is not None:
                self._values["duration_in_seconds"] = duration_in_seconds
            if end_time is not None:
                self._values["end_time"] = end_time
            if phase_context is not None:
                self._values["phase_context"] = phase_context
            if phase_status is not None:
                self._values["phase_status"] = phase_status
            if phase_type is not None:
                self._values["phase_type"] = phase_type
            if start_time is not None:
                self._values["start_time"] = start_time

        @builtins.property
        def duration_in_seconds(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) durationInSeconds property.

            Specify an array of string values to match this event if the actual value of durationInSeconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("duration_in_seconds")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endTime property.

            Specify an array of string values to match this event if the actual value of endTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def phase_context(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) phaseContext property.

            Specify an array of string values to match this event if the actual value of phaseContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("phase_context")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def phase_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) phaseStatus property.

            Specify an array of string values to match this event if the actual value of phaseStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("phase_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def phase_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) phaseType property.

            Specify an array of string values to match this event if the actual value of phaseType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("phase_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "BuildPhase(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Cache",
        jsii_struct_bases=[],
        name_mapping={"location": "location", "type": "type"},
    )
    class Cache:
        def __init__(
            self,
            *,
            location: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Cache.

            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                cache = codebuild_events.AWSAPICallViaCloudTrail.Cache(
                    location=["location"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2262676acd7d373259a29888bfbdcd6fc7ee627164d6c539319281ed9ec2ea3b)
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if location is not None:
                self._values["location"] = location
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Cache(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Environment",
        jsii_struct_bases=[],
        name_mapping={
            "certificate": "certificate",
            "compute_type": "computeType",
            "environment_variables": "environmentVariables",
            "image": "image",
            "image_pull_credentials_type": "imagePullCredentialsType",
            "privileged_mode": "privilegedMode",
            "type": "type",
        },
    )
    class Environment:
        def __init__(
            self,
            *,
            certificate: typing.Optional[typing.Sequence[builtins.str]] = None,
            compute_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            environment_variables: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.EnvironmentItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            image: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_pull_credentials_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            privileged_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Environment.

            :param certificate: (experimental) certificate property. Specify an array of string values to match this event if the actual value of certificate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param compute_type: (experimental) computeType property. Specify an array of string values to match this event if the actual value of computeType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param environment_variables: (experimental) environmentVariables property. Specify an array of string values to match this event if the actual value of environmentVariables is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image: (experimental) image property. Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_pull_credentials_type: (experimental) imagePullCredentialsType property. Specify an array of string values to match this event if the actual value of imagePullCredentialsType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param privileged_mode: (experimental) privilegedMode property. Specify an array of string values to match this event if the actual value of privilegedMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                environment = codebuild_events.AWSAPICallViaCloudTrail.Environment(
                    certificate=["certificate"],
                    compute_type=["computeType"],
                    environment_variables=[codebuild_events.AWSAPICallViaCloudTrail.EnvironmentItem(
                        name=["name"],
                        type=["type"],
                        value=["value"]
                    )],
                    image=["image"],
                    image_pull_credentials_type=["imagePullCredentialsType"],
                    privileged_mode=["privilegedMode"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__498076640bdb8b46a9685ecf59eb6fad17e7ef74dedd3c3c68f9fb6cf9aa1e32)
                check_type(argname="argument certificate", value=certificate, expected_type=type_hints["certificate"])
                check_type(argname="argument compute_type", value=compute_type, expected_type=type_hints["compute_type"])
                check_type(argname="argument environment_variables", value=environment_variables, expected_type=type_hints["environment_variables"])
                check_type(argname="argument image", value=image, expected_type=type_hints["image"])
                check_type(argname="argument image_pull_credentials_type", value=image_pull_credentials_type, expected_type=type_hints["image_pull_credentials_type"])
                check_type(argname="argument privileged_mode", value=privileged_mode, expected_type=type_hints["privileged_mode"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if certificate is not None:
                self._values["certificate"] = certificate
            if compute_type is not None:
                self._values["compute_type"] = compute_type
            if environment_variables is not None:
                self._values["environment_variables"] = environment_variables
            if image is not None:
                self._values["image"] = image
            if image_pull_credentials_type is not None:
                self._values["image_pull_credentials_type"] = image_pull_credentials_type
            if privileged_mode is not None:
                self._values["privileged_mode"] = privileged_mode
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def certificate(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) certificate property.

            Specify an array of string values to match this event if the actual value of certificate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("certificate")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def compute_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) computeType property.

            Specify an array of string values to match this event if the actual value of computeType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("compute_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def environment_variables(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.EnvironmentItem"]]:
            '''(experimental) environmentVariables property.

            Specify an array of string values to match this event if the actual value of environmentVariables is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("environment_variables")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.EnvironmentItem"]], result)

        @builtins.property
        def image(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) image property.

            Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_pull_credentials_type(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagePullCredentialsType property.

            Specify an array of string values to match this event if the actual value of imagePullCredentialsType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_pull_credentials_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def privileged_mode(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) privilegedMode property.

            Specify an array of string values to match this event if the actual value of privilegedMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("privileged_mode")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Environment(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Environment1",
        jsii_struct_bases=[],
        name_mapping={
            "compute_type": "computeType",
            "environment_variables": "environmentVariables",
            "image": "image",
            "image_pull_credentials_type": "imagePullCredentialsType",
            "privileged_mode": "privilegedMode",
            "type": "type",
        },
    )
    class Environment1:
        def __init__(
            self,
            *,
            compute_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            environment_variables: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.EnvironmentItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            image: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_pull_credentials_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            privileged_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Environment_1.

            :param compute_type: (experimental) computeType property. Specify an array of string values to match this event if the actual value of computeType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param environment_variables: (experimental) environmentVariables property. Specify an array of string values to match this event if the actual value of environmentVariables is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image: (experimental) image property. Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_pull_credentials_type: (experimental) imagePullCredentialsType property. Specify an array of string values to match this event if the actual value of imagePullCredentialsType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param privileged_mode: (experimental) privilegedMode property. Specify an array of string values to match this event if the actual value of privilegedMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                environment1 = codebuild_events.AWSAPICallViaCloudTrail.Environment1(
                    compute_type=["computeType"],
                    environment_variables=[codebuild_events.AWSAPICallViaCloudTrail.EnvironmentItem(
                        name=["name"],
                        type=["type"],
                        value=["value"]
                    )],
                    image=["image"],
                    image_pull_credentials_type=["imagePullCredentialsType"],
                    privileged_mode=["privilegedMode"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__33f36e010253466c2f2ab9e638daf345203d86f240c8513a5f04a8e51b405d3c)
                check_type(argname="argument compute_type", value=compute_type, expected_type=type_hints["compute_type"])
                check_type(argname="argument environment_variables", value=environment_variables, expected_type=type_hints["environment_variables"])
                check_type(argname="argument image", value=image, expected_type=type_hints["image"])
                check_type(argname="argument image_pull_credentials_type", value=image_pull_credentials_type, expected_type=type_hints["image_pull_credentials_type"])
                check_type(argname="argument privileged_mode", value=privileged_mode, expected_type=type_hints["privileged_mode"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if compute_type is not None:
                self._values["compute_type"] = compute_type
            if environment_variables is not None:
                self._values["environment_variables"] = environment_variables
            if image is not None:
                self._values["image"] = image
            if image_pull_credentials_type is not None:
                self._values["image_pull_credentials_type"] = image_pull_credentials_type
            if privileged_mode is not None:
                self._values["privileged_mode"] = privileged_mode
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def compute_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) computeType property.

            Specify an array of string values to match this event if the actual value of computeType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("compute_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def environment_variables(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.EnvironmentItem"]]:
            '''(experimental) environmentVariables property.

            Specify an array of string values to match this event if the actual value of environmentVariables is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("environment_variables")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.EnvironmentItem"]], result)

        @builtins.property
        def image(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) image property.

            Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_pull_credentials_type(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) imagePullCredentialsType property.

            Specify an array of string values to match this event if the actual value of imagePullCredentialsType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_pull_credentials_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def privileged_mode(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) privilegedMode property.

            Specify an array of string values to match this event if the actual value of privilegedMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("privileged_mode")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Environment1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.EnvironmentItem",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "type": "type", "value": "value"},
    )
    class EnvironmentItem:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for EnvironmentItem.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                environment_item = codebuild_events.AWSAPICallViaCloudTrail.EnvironmentItem(
                    name=["name"],
                    type=["type"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6f1bcc86793afdd06ce8df175071a34de20ea98a1082e05b9031188a89688c71)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if type is not None:
                self._values["type"] = type
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EnvironmentItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.GitSubmodulesConfig",
        jsii_struct_bases=[],
        name_mapping={"fetch_submodules": "fetchSubmodules"},
    )
    class GitSubmodulesConfig:
        def __init__(
            self,
            *,
            fetch_submodules: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for GitSubmodulesConfig.

            :param fetch_submodules: (experimental) fetchSubmodules property. Specify an array of string values to match this event if the actual value of fetchSubmodules is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                git_submodules_config = codebuild_events.AWSAPICallViaCloudTrail.GitSubmodulesConfig(
                    fetch_submodules=["fetchSubmodules"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ef72df77053484e3666f1952181072bc344ae8cd288a9944b251de73235edf43)
                check_type(argname="argument fetch_submodules", value=fetch_submodules, expected_type=type_hints["fetch_submodules"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if fetch_submodules is not None:
                self._values["fetch_submodules"] = fetch_submodules

        @builtins.property
        def fetch_submodules(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) fetchSubmodules property.

            Specify an array of string values to match this event if the actual value of fetchSubmodules is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("fetch_submodules")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "GitSubmodulesConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Logs",
        jsii_struct_bases=[],
        name_mapping={
            "deep_link": "deepLink",
            "group_name": "groupName",
            "stream_name": "streamName",
        },
    )
    class Logs:
        def __init__(
            self,
            *,
            deep_link: typing.Optional[typing.Sequence[builtins.str]] = None,
            group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            stream_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Logs.

            :param deep_link: (experimental) deepLink property. Specify an array of string values to match this event if the actual value of deepLink is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_name: (experimental) groupName property. Specify an array of string values to match this event if the actual value of groupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stream_name: (experimental) streamName property. Specify an array of string values to match this event if the actual value of streamName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                logs = codebuild_events.AWSAPICallViaCloudTrail.Logs(
                    deep_link=["deepLink"],
                    group_name=["groupName"],
                    stream_name=["streamName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7fac08a13ab69759baceb5afb86f210107add618a188ee0853dfe914def84f6f)
                check_type(argname="argument deep_link", value=deep_link, expected_type=type_hints["deep_link"])
                check_type(argname="argument group_name", value=group_name, expected_type=type_hints["group_name"])
                check_type(argname="argument stream_name", value=stream_name, expected_type=type_hints["stream_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if deep_link is not None:
                self._values["deep_link"] = deep_link
            if group_name is not None:
                self._values["group_name"] = group_name
            if stream_name is not None:
                self._values["stream_name"] = stream_name

        @builtins.property
        def deep_link(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) deepLink property.

            Specify an array of string values to match this event if the actual value of deepLink is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("deep_link")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) groupName property.

            Specify an array of string values to match this event if the actual value of groupName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stream_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) streamName property.

            Specify an array of string values to match this event if the actual value of streamName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stream_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Logs(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Project",
        jsii_struct_bases=[],
        name_mapping={
            "arn": "arn",
            "artifacts": "artifacts",
            "badge": "badge",
            "cache": "cache",
            "created": "created",
            "description": "description",
            "encryption_key": "encryptionKey",
            "environment": "environment",
            "last_modified": "lastModified",
            "name": "name",
            "queued_timeout_in_minutes": "queuedTimeoutInMinutes",
            "service_role": "serviceRole",
            "source": "source",
            "source_version": "sourceVersion",
            "tags": "tags",
            "timeout_in_minutes": "timeoutInMinutes",
        },
    )
    class Project:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            artifacts: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Artifacts1", typing.Dict[builtins.str, typing.Any]]] = None,
            badge: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Badge", typing.Dict[builtins.str, typing.Any]]] = None,
            cache: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Cache", typing.Dict[builtins.str, typing.Any]]] = None,
            created: typing.Optional[typing.Sequence[builtins.str]] = None,
            description: typing.Optional[typing.Sequence[builtins.str]] = None,
            encryption_key: typing.Optional[typing.Sequence[builtins.str]] = None,
            environment: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Environment1", typing.Dict[builtins.str, typing.Any]]] = None,
            last_modified: typing.Optional[typing.Sequence[builtins.str]] = None,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            queued_timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
            service_role: typing.Optional[typing.Sequence[builtins.str]] = None,
            source: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Source1", typing.Dict[builtins.str, typing.Any]]] = None,
            source_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.ProjectItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Project.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param artifacts: (experimental) artifacts property. Specify an array of string values to match this event if the actual value of artifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param badge: (experimental) badge property. Specify an array of string values to match this event if the actual value of badge is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param cache: (experimental) cache property. Specify an array of string values to match this event if the actual value of cache is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param created: (experimental) created property. Specify an array of string values to match this event if the actual value of created is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param description: (experimental) description property. Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param encryption_key: (experimental) encryptionKey property. Specify an array of string values to match this event if the actual value of encryptionKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param environment: (experimental) environment property. Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param last_modified: (experimental) lastModified property. Specify an array of string values to match this event if the actual value of lastModified is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param queued_timeout_in_minutes: (experimental) queuedTimeoutInMinutes property. Specify an array of string values to match this event if the actual value of queuedTimeoutInMinutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param service_role: (experimental) serviceRole property. Specify an array of string values to match this event if the actual value of serviceRole is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source: (experimental) source property. Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_version: (experimental) sourceVersion property. Specify an array of string values to match this event if the actual value of sourceVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) tags property. Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param timeout_in_minutes: (experimental) timeoutInMinutes property. Specify an array of string values to match this event if the actual value of timeoutInMinutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                project = codebuild_events.AWSAPICallViaCloudTrail.Project(
                    arn=["arn"],
                    artifacts=codebuild_events.AWSAPICallViaCloudTrail.Artifacts1(
                        encryption_disabled=["encryptionDisabled"],
                        location=["location"],
                        name=["name"],
                        namespace_type=["namespaceType"],
                        packaging=["packaging"],
                        type=["type"]
                    ),
                    badge=codebuild_events.AWSAPICallViaCloudTrail.Badge(
                        badge_enabled=["badgeEnabled"],
                        badge_request_url=["badgeRequestUrl"]
                    ),
                    cache=codebuild_events.AWSAPICallViaCloudTrail.Cache(
                        location=["location"],
                        type=["type"]
                    ),
                    created=["created"],
                    description=["description"],
                    encryption_key=["encryptionKey"],
                    environment=codebuild_events.AWSAPICallViaCloudTrail.Environment1(
                        compute_type=["computeType"],
                        environment_variables=[codebuild_events.AWSAPICallViaCloudTrail.EnvironmentItem(
                            name=["name"],
                            type=["type"],
                            value=["value"]
                        )],
                        image=["image"],
                        image_pull_credentials_type=["imagePullCredentialsType"],
                        privileged_mode=["privilegedMode"],
                        type=["type"]
                    ),
                    last_modified=["lastModified"],
                    name=["name"],
                    queued_timeout_in_minutes=["queuedTimeoutInMinutes"],
                    service_role=["serviceRole"],
                    source=codebuild_events.AWSAPICallViaCloudTrail.Source1(
                        auth=codebuild_events.AWSAPICallViaCloudTrail.Auth(
                            type=["type"]
                        ),
                        buildspec=["buildspec"],
                        git_clone_depth=["gitCloneDepth"],
                        git_submodules_config=codebuild_events.AWSAPICallViaCloudTrail.GitSubmodulesConfig(
                            fetch_submodules=["fetchSubmodules"]
                        ),
                        insecure_ssl=["insecureSsl"],
                        location=["location"],
                        report_build_status=["reportBuildStatus"],
                        type=["type"]
                    ),
                    source_version=["sourceVersion"],
                    tags=[codebuild_events.AWSAPICallViaCloudTrail.ProjectItem(
                        key=["key"],
                        value=["value"]
                    )],
                    timeout_in_minutes=["timeoutInMinutes"]
                )
            '''
            if isinstance(artifacts, dict):
                artifacts = AWSAPICallViaCloudTrail.Artifacts1(**artifacts)
            if isinstance(badge, dict):
                badge = AWSAPICallViaCloudTrail.Badge(**badge)
            if isinstance(cache, dict):
                cache = AWSAPICallViaCloudTrail.Cache(**cache)
            if isinstance(environment, dict):
                environment = AWSAPICallViaCloudTrail.Environment1(**environment)
            if isinstance(source, dict):
                source = AWSAPICallViaCloudTrail.Source1(**source)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f19fa55f09f47a96e42d63345c80ba94c66150a26d65fb5ea54bfd9b1bbfb2a0)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument artifacts", value=artifacts, expected_type=type_hints["artifacts"])
                check_type(argname="argument badge", value=badge, expected_type=type_hints["badge"])
                check_type(argname="argument cache", value=cache, expected_type=type_hints["cache"])
                check_type(argname="argument created", value=created, expected_type=type_hints["created"])
                check_type(argname="argument description", value=description, expected_type=type_hints["description"])
                check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
                check_type(argname="argument environment", value=environment, expected_type=type_hints["environment"])
                check_type(argname="argument last_modified", value=last_modified, expected_type=type_hints["last_modified"])
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument queued_timeout_in_minutes", value=queued_timeout_in_minutes, expected_type=type_hints["queued_timeout_in_minutes"])
                check_type(argname="argument service_role", value=service_role, expected_type=type_hints["service_role"])
                check_type(argname="argument source", value=source, expected_type=type_hints["source"])
                check_type(argname="argument source_version", value=source_version, expected_type=type_hints["source_version"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
                check_type(argname="argument timeout_in_minutes", value=timeout_in_minutes, expected_type=type_hints["timeout_in_minutes"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn
            if artifacts is not None:
                self._values["artifacts"] = artifacts
            if badge is not None:
                self._values["badge"] = badge
            if cache is not None:
                self._values["cache"] = cache
            if created is not None:
                self._values["created"] = created
            if description is not None:
                self._values["description"] = description
            if encryption_key is not None:
                self._values["encryption_key"] = encryption_key
            if environment is not None:
                self._values["environment"] = environment
            if last_modified is not None:
                self._values["last_modified"] = last_modified
            if name is not None:
                self._values["name"] = name
            if queued_timeout_in_minutes is not None:
                self._values["queued_timeout_in_minutes"] = queued_timeout_in_minutes
            if service_role is not None:
                self._values["service_role"] = service_role
            if source is not None:
                self._values["source"] = source
            if source_version is not None:
                self._values["source_version"] = source_version
            if tags is not None:
                self._values["tags"] = tags
            if timeout_in_minutes is not None:
                self._values["timeout_in_minutes"] = timeout_in_minutes

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def artifacts(self) -> typing.Optional["AWSAPICallViaCloudTrail.Artifacts1"]:
            '''(experimental) artifacts property.

            Specify an array of string values to match this event if the actual value of artifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("artifacts")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Artifacts1"], result)

        @builtins.property
        def badge(self) -> typing.Optional["AWSAPICallViaCloudTrail.Badge"]:
            '''(experimental) badge property.

            Specify an array of string values to match this event if the actual value of badge is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("badge")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Badge"], result)

        @builtins.property
        def cache(self) -> typing.Optional["AWSAPICallViaCloudTrail.Cache"]:
            '''(experimental) cache property.

            Specify an array of string values to match this event if the actual value of cache is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cache")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Cache"], result)

        @builtins.property
        def created(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) created property.

            Specify an array of string values to match this event if the actual value of created is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("created")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) description property.

            Specify an array of string values to match this event if the actual value of description is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def encryption_key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) encryptionKey property.

            Specify an array of string values to match this event if the actual value of encryptionKey is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("encryption_key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def environment(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.Environment1"]:
            '''(experimental) environment property.

            Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("environment")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Environment1"], result)

        @builtins.property
        def last_modified(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) lastModified property.

            Specify an array of string values to match this event if the actual value of lastModified is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_modified")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def queued_timeout_in_minutes(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) queuedTimeoutInMinutes property.

            Specify an array of string values to match this event if the actual value of queuedTimeoutInMinutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("queued_timeout_in_minutes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def service_role(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) serviceRole property.

            Specify an array of string values to match this event if the actual value of serviceRole is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("service_role")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source(self) -> typing.Optional["AWSAPICallViaCloudTrail.Source1"]:
            '''(experimental) source property.

            Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Source1"], result)

        @builtins.property
        def source_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceVersion property.

            Specify an array of string values to match this event if the actual value of sourceVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.ProjectItem"]]:
            '''(experimental) tags property.

            Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.ProjectItem"]], result)

        @builtins.property
        def timeout_in_minutes(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) timeoutInMinutes property.

            Specify an array of string values to match this event if the actual value of timeoutInMinutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("timeout_in_minutes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Project(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.ProjectItem",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class ProjectItem:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ProjectItem.

            :param key: (experimental) key property. Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                project_item = codebuild_events.AWSAPICallViaCloudTrail.ProjectItem(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e9bf24df1bd3ee125c77ea4e0616682b24425fa7d74822297d4a7c2a9f951492)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) key property.

            Specify an array of string values to match this event if the actual value of key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ProjectItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.RequestParameters",
        jsii_struct_bases=[],
        name_mapping={
            "aws_act_id": "awsActId",
            "invoked_by": "invokedBy",
            "payer_id": "payerId",
            "user_arn": "userArn",
        },
    )
    class RequestParameters:
        def __init__(
            self,
            *,
            aws_act_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
            payer_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParameters.

            :param aws_act_id: (experimental) awsActId property. Specify an array of string values to match this event if the actual value of awsActId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param invoked_by: (experimental) invokedBy property. Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param payer_id: (experimental) payerId property. Specify an array of string values to match this event if the actual value of payerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_arn: (experimental) userArn property. Specify an array of string values to match this event if the actual value of userArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                request_parameters = codebuild_events.AWSAPICallViaCloudTrail.RequestParameters(
                    aws_act_id=["awsActId"],
                    invoked_by=["invokedBy"],
                    payer_id=["payerId"],
                    user_arn=["userArn"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0cb89d4e023ad9c7af3f9ab7838a7f436fab1845c04f1b2cc958c3362f72295a)
                check_type(argname="argument aws_act_id", value=aws_act_id, expected_type=type_hints["aws_act_id"])
                check_type(argname="argument invoked_by", value=invoked_by, expected_type=type_hints["invoked_by"])
                check_type(argname="argument payer_id", value=payer_id, expected_type=type_hints["payer_id"])
                check_type(argname="argument user_arn", value=user_arn, expected_type=type_hints["user_arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if aws_act_id is not None:
                self._values["aws_act_id"] = aws_act_id
            if invoked_by is not None:
                self._values["invoked_by"] = invoked_by
            if payer_id is not None:
                self._values["payer_id"] = payer_id
            if user_arn is not None:
                self._values["user_arn"] = user_arn

        @builtins.property
        def aws_act_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) awsActId property.

            Specify an array of string values to match this event if the actual value of awsActId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_act_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def invoked_by(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) invokedBy property.

            Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("invoked_by")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def payer_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) payerId property.

            Specify an array of string values to match this event if the actual value of payerId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("payer_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userArn property.

            Specify an array of string values to match this event if the actual value of userArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParameters(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.ResponseElements",
        jsii_struct_bases=[],
        name_mapping={
            "build_property": "buildProperty",
            "message": "message",
            "project": "project",
            "webhook": "webhook",
            "webhook_deleted_status": "webhookDeletedStatus",
        },
    )
    class ResponseElements:
        def __init__(
            self,
            *,
            build_property: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Build", typing.Dict[builtins.str, typing.Any]]] = None,
            message: typing.Optional[typing.Sequence[builtins.str]] = None,
            project: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Project", typing.Dict[builtins.str, typing.Any]]] = None,
            webhook: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Webhook", typing.Dict[builtins.str, typing.Any]]] = None,
            webhook_deleted_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResponseElements.

            :param build_property: (experimental) build property. Specify an array of string values to match this event if the actual value of build is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param message: (experimental) message property. Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param project: (experimental) project property. Specify an array of string values to match this event if the actual value of project is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param webhook: (experimental) webhook property. Specify an array of string values to match this event if the actual value of webhook is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param webhook_deleted_status: (experimental) webhookDeletedStatus property. Specify an array of string values to match this event if the actual value of webhookDeletedStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                response_elements = codebuild_events.AWSAPICallViaCloudTrail.ResponseElements(
                    build_property=codebuild_events.AWSAPICallViaCloudTrail.Build(
                        arn=["arn"],
                        artifacts=codebuild_events.AWSAPICallViaCloudTrail.Artifacts(
                            encryption_disabled=["encryptionDisabled"],
                            location=["location"]
                        ),
                        build_complete=["buildComplete"],
                        build_status=["buildStatus"],
                        cache=codebuild_events.AWSAPICallViaCloudTrail.Cache(
                            location=["location"],
                            type=["type"]
                        ),
                        current_phase=["currentPhase"],
                        encryption_key=["encryptionKey"],
                        end_time=["endTime"],
                        environment=codebuild_events.AWSAPICallViaCloudTrail.Environment(
                            certificate=["certificate"],
                            compute_type=["computeType"],
                            environment_variables=[codebuild_events.AWSAPICallViaCloudTrail.EnvironmentItem(
                                name=["name"],
                                type=["type"],
                                value=["value"]
                            )],
                            image=["image"],
                            image_pull_credentials_type=["imagePullCredentialsType"],
                            privileged_mode=["privilegedMode"],
                            type=["type"]
                        ),
                        id=["id"],
                        initiator=["initiator"],
                        logs=codebuild_events.AWSAPICallViaCloudTrail.Logs(
                            deep_link=["deepLink"],
                            group_name=["groupName"],
                            stream_name=["streamName"]
                        ),
                        phases=[codebuild_events.AWSAPICallViaCloudTrail.BuildPhase(
                            duration_in_seconds=["durationInSeconds"],
                            end_time=["endTime"],
                            phase_context=["phaseContext"],
                            phase_status=["phaseStatus"],
                            phase_type=["phaseType"],
                            start_time=["startTime"]
                        )],
                        project_name=["projectName"],
                        queued_timeout_in_minutes=["queuedTimeoutInMinutes"],
                        resolved_source_version=["resolvedSourceVersion"],
                        service_role=["serviceRole"],
                        source=codebuild_events.AWSAPICallViaCloudTrail.Source(
                            auth=codebuild_events.AWSAPICallViaCloudTrail.Auth(
                                type=["type"]
                            ),
                            buildspec=["buildspec"],
                            insecure_ssl=["insecureSsl"],
                            location=["location"],
                            report_build_status=["reportBuildStatus"],
                            type=["type"]
                        ),
                        source_version=["sourceVersion"],
                        start_time=["startTime"],
                        timeout_in_minutes=["timeoutInMinutes"],
                        vpc_config=codebuild_events.AWSAPICallViaCloudTrail.VpcConfig(
                            security_group_ids=["securityGroupIds"],
                            subnets=["subnets"],
                            vpc_id=["vpcId"]
                        )
                    ),
                    message=["message"],
                    project=codebuild_events.AWSAPICallViaCloudTrail.Project(
                        arn=["arn"],
                        artifacts=codebuild_events.AWSAPICallViaCloudTrail.Artifacts1(
                            encryption_disabled=["encryptionDisabled"],
                            location=["location"],
                            name=["name"],
                            namespace_type=["namespaceType"],
                            packaging=["packaging"],
                            type=["type"]
                        ),
                        badge=codebuild_events.AWSAPICallViaCloudTrail.Badge(
                            badge_enabled=["badgeEnabled"],
                            badge_request_url=["badgeRequestUrl"]
                        ),
                        cache=codebuild_events.AWSAPICallViaCloudTrail.Cache(
                            location=["location"],
                            type=["type"]
                        ),
                        created=["created"],
                        description=["description"],
                        encryption_key=["encryptionKey"],
                        environment=codebuild_events.AWSAPICallViaCloudTrail.Environment1(
                            compute_type=["computeType"],
                            environment_variables=[codebuild_events.AWSAPICallViaCloudTrail.EnvironmentItem(
                                name=["name"],
                                type=["type"],
                                value=["value"]
                            )],
                            image=["image"],
                            image_pull_credentials_type=["imagePullCredentialsType"],
                            privileged_mode=["privilegedMode"],
                            type=["type"]
                        ),
                        last_modified=["lastModified"],
                        name=["name"],
                        queued_timeout_in_minutes=["queuedTimeoutInMinutes"],
                        service_role=["serviceRole"],
                        source=codebuild_events.AWSAPICallViaCloudTrail.Source1(
                            auth=codebuild_events.AWSAPICallViaCloudTrail.Auth(
                                type=["type"]
                            ),
                            buildspec=["buildspec"],
                            git_clone_depth=["gitCloneDepth"],
                            git_submodules_config=codebuild_events.AWSAPICallViaCloudTrail.GitSubmodulesConfig(
                                fetch_submodules=["fetchSubmodules"]
                            ),
                            insecure_ssl=["insecureSsl"],
                            location=["location"],
                            report_build_status=["reportBuildStatus"],
                            type=["type"]
                        ),
                        source_version=["sourceVersion"],
                        tags=[codebuild_events.AWSAPICallViaCloudTrail.ProjectItem(
                            key=["key"],
                            value=["value"]
                        )],
                        timeout_in_minutes=["timeoutInMinutes"]
                    ),
                    webhook=codebuild_events.AWSAPICallViaCloudTrail.Webhook(
                        branch_filter=["branchFilter"],
                        last_modified_secret=["lastModifiedSecret"],
                        payload_url=["payloadUrl"],
                        url=["url"]
                    ),
                    webhook_deleted_status=["webhookDeletedStatus"]
                )
            '''
            if isinstance(build_property, dict):
                build_property = AWSAPICallViaCloudTrail.Build(**build_property)
            if isinstance(project, dict):
                project = AWSAPICallViaCloudTrail.Project(**project)
            if isinstance(webhook, dict):
                webhook = AWSAPICallViaCloudTrail.Webhook(**webhook)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1474fe577386c0c7ddf70c96ea4fda8c8609132d95111fc80e6a04ebe632a44f)
                check_type(argname="argument build_property", value=build_property, expected_type=type_hints["build_property"])
                check_type(argname="argument message", value=message, expected_type=type_hints["message"])
                check_type(argname="argument project", value=project, expected_type=type_hints["project"])
                check_type(argname="argument webhook", value=webhook, expected_type=type_hints["webhook"])
                check_type(argname="argument webhook_deleted_status", value=webhook_deleted_status, expected_type=type_hints["webhook_deleted_status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if build_property is not None:
                self._values["build_property"] = build_property
            if message is not None:
                self._values["message"] = message
            if project is not None:
                self._values["project"] = project
            if webhook is not None:
                self._values["webhook"] = webhook
            if webhook_deleted_status is not None:
                self._values["webhook_deleted_status"] = webhook_deleted_status

        @builtins.property
        def build_property(self) -> typing.Optional["AWSAPICallViaCloudTrail.Build"]:
            '''(experimental) build property.

            Specify an array of string values to match this event if the actual value of build is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("build_property")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Build"], result)

        @builtins.property
        def message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) message property.

            Specify an array of string values to match this event if the actual value of message is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def project(self) -> typing.Optional["AWSAPICallViaCloudTrail.Project"]:
            '''(experimental) project property.

            Specify an array of string values to match this event if the actual value of project is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("project")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Project"], result)

        @builtins.property
        def webhook(self) -> typing.Optional["AWSAPICallViaCloudTrail.Webhook"]:
            '''(experimental) webhook property.

            Specify an array of string values to match this event if the actual value of webhook is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("webhook")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Webhook"], result)

        @builtins.property
        def webhook_deleted_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) webhookDeletedStatus property.

            Specify an array of string values to match this event if the actual value of webhookDeletedStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("webhook_deleted_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResponseElements(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.SessionContext",
        jsii_struct_bases=[],
        name_mapping={"attributes": "attributes", "session_issuer": "sessionIssuer"},
    )
    class SessionContext:
        def __init__(
            self,
            *,
            attributes: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            session_issuer: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionIssuer", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionContext.

            :param attributes: (experimental) attributes property. Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_issuer: (experimental) sessionIssuer property. Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                session_context = codebuild_events.AWSAPICallViaCloudTrail.SessionContext(
                    attributes=codebuild_events.AWSAPICallViaCloudTrail.Attributes(
                        creation_date=["creationDate"],
                        mfa_authenticated=["mfaAuthenticated"]
                    ),
                    session_issuer=codebuild_events.AWSAPICallViaCloudTrail.SessionIssuer(
                        account_id=["accountId"],
                        arn=["arn"],
                        principal_id=["principalId"],
                        type=["type"],
                        user_name=["userName"]
                    )
                )
            '''
            if isinstance(attributes, dict):
                attributes = AWSAPICallViaCloudTrail.Attributes(**attributes)
            if isinstance(session_issuer, dict):
                session_issuer = AWSAPICallViaCloudTrail.SessionIssuer(**session_issuer)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__95f4144ad226879ea814952e59f0c055041b0c64974c09d7a4f5998b9e6e370c)
                check_type(argname="argument attributes", value=attributes, expected_type=type_hints["attributes"])
                check_type(argname="argument session_issuer", value=session_issuer, expected_type=type_hints["session_issuer"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attributes is not None:
                self._values["attributes"] = attributes
            if session_issuer is not None:
                self._values["session_issuer"] = session_issuer

        @builtins.property
        def attributes(self) -> typing.Optional["AWSAPICallViaCloudTrail.Attributes"]:
            '''(experimental) attributes property.

            Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attributes")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Attributes"], result)

        @builtins.property
        def session_issuer(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"]:
            '''(experimental) sessionIssuer property.

            Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_issuer")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionContext(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.SessionIssuer",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "arn": "arn",
            "principal_id": "principalId",
            "type": "type",
            "user_name": "userName",
        },
    )
    class SessionIssuer:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionIssuer.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_name: (experimental) userName property. Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                session_issuer = codebuild_events.AWSAPICallViaCloudTrail.SessionIssuer(
                    account_id=["accountId"],
                    arn=["arn"],
                    principal_id=["principalId"],
                    type=["type"],
                    user_name=["userName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f16f9a763459b6ce0aa68580e9e7fe4fa0f867ec2c9238a9cf3a736d49a884ed)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument user_name", value=user_name, expected_type=type_hints["user_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if type is not None:
                self._values["type"] = type
            if user_name is not None:
                self._values["user_name"] = user_name

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userName property.

            Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionIssuer(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Source",
        jsii_struct_bases=[],
        name_mapping={
            "auth": "auth",
            "buildspec": "buildspec",
            "insecure_ssl": "insecureSsl",
            "location": "location",
            "report_build_status": "reportBuildStatus",
            "type": "type",
        },
    )
    class Source:
        def __init__(
            self,
            *,
            auth: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Auth", typing.Dict[builtins.str, typing.Any]]] = None,
            buildspec: typing.Optional[typing.Sequence[builtins.str]] = None,
            insecure_ssl: typing.Optional[typing.Sequence[builtins.str]] = None,
            location: typing.Optional[typing.Sequence[builtins.str]] = None,
            report_build_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Source.

            :param auth: (experimental) auth property. Specify an array of string values to match this event if the actual value of auth is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param buildspec: (experimental) buildspec property. Specify an array of string values to match this event if the actual value of buildspec is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insecure_ssl: (experimental) insecureSsl property. Specify an array of string values to match this event if the actual value of insecureSsl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param report_build_status: (experimental) reportBuildStatus property. Specify an array of string values to match this event if the actual value of reportBuildStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                source = codebuild_events.AWSAPICallViaCloudTrail.Source(
                    auth=codebuild_events.AWSAPICallViaCloudTrail.Auth(
                        type=["type"]
                    ),
                    buildspec=["buildspec"],
                    insecure_ssl=["insecureSsl"],
                    location=["location"],
                    report_build_status=["reportBuildStatus"],
                    type=["type"]
                )
            '''
            if isinstance(auth, dict):
                auth = AWSAPICallViaCloudTrail.Auth(**auth)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__819726a70a22f2684d1aaf1ebea2138a1ce88866e19fb21c843096bab701f12c)
                check_type(argname="argument auth", value=auth, expected_type=type_hints["auth"])
                check_type(argname="argument buildspec", value=buildspec, expected_type=type_hints["buildspec"])
                check_type(argname="argument insecure_ssl", value=insecure_ssl, expected_type=type_hints["insecure_ssl"])
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
                check_type(argname="argument report_build_status", value=report_build_status, expected_type=type_hints["report_build_status"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if auth is not None:
                self._values["auth"] = auth
            if buildspec is not None:
                self._values["buildspec"] = buildspec
            if insecure_ssl is not None:
                self._values["insecure_ssl"] = insecure_ssl
            if location is not None:
                self._values["location"] = location
            if report_build_status is not None:
                self._values["report_build_status"] = report_build_status
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def auth(self) -> typing.Optional["AWSAPICallViaCloudTrail.Auth"]:
            '''(experimental) auth property.

            Specify an array of string values to match this event if the actual value of auth is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("auth")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Auth"], result)

        @builtins.property
        def buildspec(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) buildspec property.

            Specify an array of string values to match this event if the actual value of buildspec is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("buildspec")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def insecure_ssl(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insecureSsl property.

            Specify an array of string values to match this event if the actual value of insecureSsl is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insecure_ssl")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def report_build_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) reportBuildStatus property.

            Specify an array of string values to match this event if the actual value of reportBuildStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("report_build_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Source(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Source1",
        jsii_struct_bases=[],
        name_mapping={
            "auth": "auth",
            "buildspec": "buildspec",
            "git_clone_depth": "gitCloneDepth",
            "git_submodules_config": "gitSubmodulesConfig",
            "insecure_ssl": "insecureSsl",
            "location": "location",
            "report_build_status": "reportBuildStatus",
            "type": "type",
        },
    )
    class Source1:
        def __init__(
            self,
            *,
            auth: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Auth", typing.Dict[builtins.str, typing.Any]]] = None,
            buildspec: typing.Optional[typing.Sequence[builtins.str]] = None,
            git_clone_depth: typing.Optional[typing.Sequence[builtins.str]] = None,
            git_submodules_config: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.GitSubmodulesConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            insecure_ssl: typing.Optional[typing.Sequence[builtins.str]] = None,
            location: typing.Optional[typing.Sequence[builtins.str]] = None,
            report_build_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Source_1.

            :param auth: (experimental) auth property. Specify an array of string values to match this event if the actual value of auth is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param buildspec: (experimental) buildspec property. Specify an array of string values to match this event if the actual value of buildspec is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param git_clone_depth: (experimental) gitCloneDepth property. Specify an array of string values to match this event if the actual value of gitCloneDepth is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param git_submodules_config: (experimental) gitSubmodulesConfig property. Specify an array of string values to match this event if the actual value of gitSubmodulesConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param insecure_ssl: (experimental) insecureSsl property. Specify an array of string values to match this event if the actual value of insecureSsl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param report_build_status: (experimental) reportBuildStatus property. Specify an array of string values to match this event if the actual value of reportBuildStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                source1 = codebuild_events.AWSAPICallViaCloudTrail.Source1(
                    auth=codebuild_events.AWSAPICallViaCloudTrail.Auth(
                        type=["type"]
                    ),
                    buildspec=["buildspec"],
                    git_clone_depth=["gitCloneDepth"],
                    git_submodules_config=codebuild_events.AWSAPICallViaCloudTrail.GitSubmodulesConfig(
                        fetch_submodules=["fetchSubmodules"]
                    ),
                    insecure_ssl=["insecureSsl"],
                    location=["location"],
                    report_build_status=["reportBuildStatus"],
                    type=["type"]
                )
            '''
            if isinstance(auth, dict):
                auth = AWSAPICallViaCloudTrail.Auth(**auth)
            if isinstance(git_submodules_config, dict):
                git_submodules_config = AWSAPICallViaCloudTrail.GitSubmodulesConfig(**git_submodules_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4c7bca3b44409d55d88429819e8855294e7fc8ead97891566dac74dc9d577903)
                check_type(argname="argument auth", value=auth, expected_type=type_hints["auth"])
                check_type(argname="argument buildspec", value=buildspec, expected_type=type_hints["buildspec"])
                check_type(argname="argument git_clone_depth", value=git_clone_depth, expected_type=type_hints["git_clone_depth"])
                check_type(argname="argument git_submodules_config", value=git_submodules_config, expected_type=type_hints["git_submodules_config"])
                check_type(argname="argument insecure_ssl", value=insecure_ssl, expected_type=type_hints["insecure_ssl"])
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
                check_type(argname="argument report_build_status", value=report_build_status, expected_type=type_hints["report_build_status"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if auth is not None:
                self._values["auth"] = auth
            if buildspec is not None:
                self._values["buildspec"] = buildspec
            if git_clone_depth is not None:
                self._values["git_clone_depth"] = git_clone_depth
            if git_submodules_config is not None:
                self._values["git_submodules_config"] = git_submodules_config
            if insecure_ssl is not None:
                self._values["insecure_ssl"] = insecure_ssl
            if location is not None:
                self._values["location"] = location
            if report_build_status is not None:
                self._values["report_build_status"] = report_build_status
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def auth(self) -> typing.Optional["AWSAPICallViaCloudTrail.Auth"]:
            '''(experimental) auth property.

            Specify an array of string values to match this event if the actual value of auth is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("auth")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Auth"], result)

        @builtins.property
        def buildspec(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) buildspec property.

            Specify an array of string values to match this event if the actual value of buildspec is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("buildspec")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def git_clone_depth(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) gitCloneDepth property.

            Specify an array of string values to match this event if the actual value of gitCloneDepth is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("git_clone_depth")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def git_submodules_config(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.GitSubmodulesConfig"]:
            '''(experimental) gitSubmodulesConfig property.

            Specify an array of string values to match this event if the actual value of gitSubmodulesConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("git_submodules_config")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.GitSubmodulesConfig"], result)

        @builtins.property
        def insecure_ssl(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) insecureSsl property.

            Specify an array of string values to match this event if the actual value of insecureSsl is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("insecure_ssl")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def report_build_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) reportBuildStatus property.

            Specify an array of string values to match this event if the actual value of reportBuildStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("report_build_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Source1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.UserIdentity",
        jsii_struct_bases=[],
        name_mapping={
            "access_key_id": "accessKeyId",
            "account_id": "accountId",
            "arn": "arn",
            "invoked_by": "invokedBy",
            "principal_id": "principalId",
            "session_context": "sessionContext",
            "type": "type",
        },
    )
    class UserIdentity:
        def __init__(
            self,
            *,
            access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_context: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionContext", typing.Dict[builtins.str, typing.Any]]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for UserIdentity.

            :param access_key_id: (experimental) accessKeyId property. Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param invoked_by: (experimental) invokedBy property. Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_context: (experimental) sessionContext property. Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                user_identity = codebuild_events.AWSAPICallViaCloudTrail.UserIdentity(
                    access_key_id=["accessKeyId"],
                    account_id=["accountId"],
                    arn=["arn"],
                    invoked_by=["invokedBy"],
                    principal_id=["principalId"],
                    session_context=codebuild_events.AWSAPICallViaCloudTrail.SessionContext(
                        attributes=codebuild_events.AWSAPICallViaCloudTrail.Attributes(
                            creation_date=["creationDate"],
                            mfa_authenticated=["mfaAuthenticated"]
                        ),
                        session_issuer=codebuild_events.AWSAPICallViaCloudTrail.SessionIssuer(
                            account_id=["accountId"],
                            arn=["arn"],
                            principal_id=["principalId"],
                            type=["type"],
                            user_name=["userName"]
                        )
                    ),
                    type=["type"]
                )
            '''
            if isinstance(session_context, dict):
                session_context = AWSAPICallViaCloudTrail.SessionContext(**session_context)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2a07981bb802ac53a07f60a9e2d7805266cf6fe2304a78680ee7d43a893740dd)
                check_type(argname="argument access_key_id", value=access_key_id, expected_type=type_hints["access_key_id"])
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument invoked_by", value=invoked_by, expected_type=type_hints["invoked_by"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument session_context", value=session_context, expected_type=type_hints["session_context"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if access_key_id is not None:
                self._values["access_key_id"] = access_key_id
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if invoked_by is not None:
                self._values["invoked_by"] = invoked_by
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if session_context is not None:
                self._values["session_context"] = session_context
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def access_key_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accessKeyId property.

            Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("access_key_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def invoked_by(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) invokedBy property.

            Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("invoked_by")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_context(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionContext"]:
            '''(experimental) sessionContext property.

            Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_context")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionContext"], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "UserIdentity(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.VpcConfig",
        jsii_struct_bases=[],
        name_mapping={
            "security_group_ids": "securityGroupIds",
            "subnets": "subnets",
            "vpc_id": "vpcId",
        },
    )
    class VpcConfig:
        def __init__(
            self,
            *,
            security_group_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnets: typing.Optional[typing.Sequence[builtins.str]] = None,
            vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for VpcConfig.

            :param security_group_ids: (experimental) securityGroupIds property. Specify an array of string values to match this event if the actual value of securityGroupIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnets: (experimental) subnets property. Specify an array of string values to match this event if the actual value of subnets is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_id: (experimental) vpcId property. Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                vpc_config = codebuild_events.AWSAPICallViaCloudTrail.VpcConfig(
                    security_group_ids=["securityGroupIds"],
                    subnets=["subnets"],
                    vpc_id=["vpcId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__028fe7c10241e269cb21a425e0933df7c012e5227fa0d9be2ce6bb325fdff9d3)
                check_type(argname="argument security_group_ids", value=security_group_ids, expected_type=type_hints["security_group_ids"])
                check_type(argname="argument subnets", value=subnets, expected_type=type_hints["subnets"])
                check_type(argname="argument vpc_id", value=vpc_id, expected_type=type_hints["vpc_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if security_group_ids is not None:
                self._values["security_group_ids"] = security_group_ids
            if subnets is not None:
                self._values["subnets"] = subnets
            if vpc_id is not None:
                self._values["vpc_id"] = vpc_id

        @builtins.property
        def security_group_ids(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) securityGroupIds property.

            Specify an array of string values to match this event if the actual value of securityGroupIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("security_group_ids")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnets(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) subnets property.

            Specify an array of string values to match this event if the actual value of subnets is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnets")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def vpc_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) vpcId property.

            Specify an array of string values to match this event if the actual value of vpcId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VpcConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSAPICallViaCloudTrail.Webhook",
        jsii_struct_bases=[],
        name_mapping={
            "branch_filter": "branchFilter",
            "last_modified_secret": "lastModifiedSecret",
            "payload_url": "payloadUrl",
            "url": "url",
        },
    )
    class Webhook:
        def __init__(
            self,
            *,
            branch_filter: typing.Optional[typing.Sequence[builtins.str]] = None,
            last_modified_secret: typing.Optional[typing.Sequence[builtins.str]] = None,
            payload_url: typing.Optional[typing.Sequence[builtins.str]] = None,
            url: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Webhook.

            :param branch_filter: (experimental) branchFilter property. Specify an array of string values to match this event if the actual value of branchFilter is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param last_modified_secret: (experimental) lastModifiedSecret property. Specify an array of string values to match this event if the actual value of lastModifiedSecret is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param payload_url: (experimental) payloadUrl property. Specify an array of string values to match this event if the actual value of payloadUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param url: (experimental) url property. Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                webhook = codebuild_events.AWSAPICallViaCloudTrail.Webhook(
                    branch_filter=["branchFilter"],
                    last_modified_secret=["lastModifiedSecret"],
                    payload_url=["payloadUrl"],
                    url=["url"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__74f1b615326c7391c7ce1c45d52ed6cea9478e732ee32bc28ebe589b678fd71a)
                check_type(argname="argument branch_filter", value=branch_filter, expected_type=type_hints["branch_filter"])
                check_type(argname="argument last_modified_secret", value=last_modified_secret, expected_type=type_hints["last_modified_secret"])
                check_type(argname="argument payload_url", value=payload_url, expected_type=type_hints["payload_url"])
                check_type(argname="argument url", value=url, expected_type=type_hints["url"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if branch_filter is not None:
                self._values["branch_filter"] = branch_filter
            if last_modified_secret is not None:
                self._values["last_modified_secret"] = last_modified_secret
            if payload_url is not None:
                self._values["payload_url"] = payload_url
            if url is not None:
                self._values["url"] = url

        @builtins.property
        def branch_filter(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) branchFilter property.

            Specify an array of string values to match this event if the actual value of branchFilter is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("branch_filter")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def last_modified_secret(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) lastModifiedSecret property.

            Specify an array of string values to match this event if the actual value of lastModifiedSecret is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_modified_secret")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def payload_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) payloadUrl property.

            Specify an array of string values to match this event if the actual value of payloadUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("payload_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) url property.

            Specify an array of string values to match this event if the actual value of url is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Webhook(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class AWSServiceEventViaCloudTrail(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSServiceEventViaCloudTrail",
):
    '''(experimental) EventBridge event pattern for aws.codebuild@AWSServiceEventViaCloudTrail.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
        
        a_wSService_event_via_cloud_trail = codebuild_events.AWSServiceEventViaCloudTrail()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
        service_event_details: typing.Optional[typing.Union["AWSServiceEventViaCloudTrail.ServiceEventDetails", typing.Dict[builtins.str, typing.Any]]] = None,
        source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_identity: typing.Optional[typing.Union["AWSServiceEventViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AWS Service Event via CloudTrail.

        :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param read_only: (experimental) readOnly property. Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param service_event_details: (experimental) serviceEventDetails property. Specify an array of string values to match this event if the actual value of serviceEventDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AWSServiceEventViaCloudTrail.AWSServiceEventViaCloudTrailProps(
            aws_region=aws_region,
            event_id=event_id,
            event_metadata=event_metadata,
            event_name=event_name,
            event_source=event_source,
            event_time=event_time,
            event_type=event_type,
            event_version=event_version,
            read_only=read_only,
            service_event_details=service_event_details,
            source_ip_address=source_ip_address,
            user_agent=user_agent,
            user_identity=user_identity,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSServiceEventViaCloudTrail.AWSServiceEventViaCloudTrailProps",
        jsii_struct_bases=[],
        name_mapping={
            "aws_region": "awsRegion",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "event_name": "eventName",
            "event_source": "eventSource",
            "event_time": "eventTime",
            "event_type": "eventType",
            "event_version": "eventVersion",
            "read_only": "readOnly",
            "service_event_details": "serviceEventDetails",
            "source_ip_address": "sourceIpAddress",
            "user_agent": "userAgent",
            "user_identity": "userIdentity",
        },
    )
    class AWSServiceEventViaCloudTrailProps:
        def __init__(
            self,
            *,
            aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
            service_event_details: typing.Optional[typing.Union["AWSServiceEventViaCloudTrail.ServiceEventDetails", typing.Dict[builtins.str, typing.Any]]] = None,
            source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_identity: typing.Optional[typing.Union["AWSServiceEventViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codebuild@AWSServiceEventViaCloudTrail event.

            :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param read_only: (experimental) readOnly property. Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param service_event_details: (experimental) serviceEventDetails property. Specify an array of string values to match this event if the actual value of serviceEventDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                a_wSService_event_via_cloud_trail_props = codebuild_events.AWSServiceEventViaCloudTrail.AWSServiceEventViaCloudTrailProps(
                    aws_region=["awsRegion"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    event_name=["eventName"],
                    event_source=["eventSource"],
                    event_time=["eventTime"],
                    event_type=["eventType"],
                    event_version=["eventVersion"],
                    read_only=["readOnly"],
                    service_event_details=codebuild_events.AWSServiceEventViaCloudTrail.ServiceEventDetails(
                        response=["response"]
                    ),
                    source_ip_address=["sourceIpAddress"],
                    user_agent=["userAgent"],
                    user_identity=codebuild_events.AWSServiceEventViaCloudTrail.UserIdentity(
                        account_id=["accountId"],
                        invoked_by=["invokedBy"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(service_event_details, dict):
                service_event_details = AWSServiceEventViaCloudTrail.ServiceEventDetails(**service_event_details)
            if isinstance(user_identity, dict):
                user_identity = AWSServiceEventViaCloudTrail.UserIdentity(**user_identity)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__13b857d2471f6acc838e3c503edd5f3aba3e9f0c1b4177b5dc766a2616670628)
                check_type(argname="argument aws_region", value=aws_region, expected_type=type_hints["aws_region"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument event_name", value=event_name, expected_type=type_hints["event_name"])
                check_type(argname="argument event_source", value=event_source, expected_type=type_hints["event_source"])
                check_type(argname="argument event_time", value=event_time, expected_type=type_hints["event_time"])
                check_type(argname="argument event_type", value=event_type, expected_type=type_hints["event_type"])
                check_type(argname="argument event_version", value=event_version, expected_type=type_hints["event_version"])
                check_type(argname="argument read_only", value=read_only, expected_type=type_hints["read_only"])
                check_type(argname="argument service_event_details", value=service_event_details, expected_type=type_hints["service_event_details"])
                check_type(argname="argument source_ip_address", value=source_ip_address, expected_type=type_hints["source_ip_address"])
                check_type(argname="argument user_agent", value=user_agent, expected_type=type_hints["user_agent"])
                check_type(argname="argument user_identity", value=user_identity, expected_type=type_hints["user_identity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if aws_region is not None:
                self._values["aws_region"] = aws_region
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if event_name is not None:
                self._values["event_name"] = event_name
            if event_source is not None:
                self._values["event_source"] = event_source
            if event_time is not None:
                self._values["event_time"] = event_time
            if event_type is not None:
                self._values["event_type"] = event_type
            if event_version is not None:
                self._values["event_version"] = event_version
            if read_only is not None:
                self._values["read_only"] = read_only
            if service_event_details is not None:
                self._values["service_event_details"] = service_event_details
            if source_ip_address is not None:
                self._values["source_ip_address"] = source_ip_address
            if user_agent is not None:
                self._values["user_agent"] = user_agent
            if user_identity is not None:
                self._values["user_identity"] = user_identity

        @builtins.property
        def aws_region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) awsRegion property.

            Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventID property.

            Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def event_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventName property.

            Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventSource property.

            Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventTime property.

            Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventType property.

            Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventVersion property.

            Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def read_only(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) readOnly property.

            Specify an array of string values to match this event if the actual value of readOnly is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("read_only")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def service_event_details(
            self,
        ) -> typing.Optional["AWSServiceEventViaCloudTrail.ServiceEventDetails"]:
            '''(experimental) serviceEventDetails property.

            Specify an array of string values to match this event if the actual value of serviceEventDetails is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("service_event_details")
            return typing.cast(typing.Optional["AWSServiceEventViaCloudTrail.ServiceEventDetails"], result)

        @builtins.property
        def source_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceIPAddress property.

            Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_agent(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userAgent property.

            Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_agent")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_identity(
            self,
        ) -> typing.Optional["AWSServiceEventViaCloudTrail.UserIdentity"]:
            '''(experimental) userIdentity property.

            Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_identity")
            return typing.cast(typing.Optional["AWSServiceEventViaCloudTrail.UserIdentity"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AWSServiceEventViaCloudTrailProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSServiceEventViaCloudTrail.ServiceEventDetails",
        jsii_struct_bases=[],
        name_mapping={"response": "response"},
    )
    class ServiceEventDetails:
        def __init__(
            self,
            *,
            response: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ServiceEventDetails.

            :param response: (experimental) response property. Specify an array of string values to match this event if the actual value of response is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                service_event_details = codebuild_events.AWSServiceEventViaCloudTrail.ServiceEventDetails(
                    response=["response"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__da1ea30d66ed2c33304a1a018f92cc98070d1308a63349dc2454b5a9dda259d0)
                check_type(argname="argument response", value=response, expected_type=type_hints["response"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if response is not None:
                self._values["response"] = response

        @builtins.property
        def response(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) response property.

            Specify an array of string values to match this event if the actual value of response is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("response")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ServiceEventDetails(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.AWSServiceEventViaCloudTrail.UserIdentity",
        jsii_struct_bases=[],
        name_mapping={"account_id": "accountId", "invoked_by": "invokedBy"},
    )
    class UserIdentity:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for UserIdentity.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param invoked_by: (experimental) invokedBy property. Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                user_identity = codebuild_events.AWSServiceEventViaCloudTrail.UserIdentity(
                    account_id=["accountId"],
                    invoked_by=["invokedBy"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d11ff3abd42f8c1461d1d7b9ddceea3eee13bd7799952d8efa2b62bf2c88c9da)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument invoked_by", value=invoked_by, expected_type=type_hints["invoked_by"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if invoked_by is not None:
                self._values["invoked_by"] = invoked_by

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def invoked_by(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) invokedBy property.

            Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("invoked_by")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "UserIdentity(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CodeBuildBuildPhaseChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange",
):
    '''(experimental) EventBridge event pattern for aws.codebuild@CodeBuildBuildPhaseChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
        
        code_build_build_phase_change = codebuild_events.CodeBuildBuildPhaseChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        additional_information: typing.Optional[typing.Union["CodeBuildBuildPhaseChange.AdditionalInformation", typing.Dict[builtins.str, typing.Any]]] = None,
        build_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        completed_phase: typing.Optional[typing.Sequence[builtins.str]] = None,
        completed_phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
        completed_phase_duration_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
        completed_phase_end: typing.Optional[typing.Sequence[builtins.str]] = None,
        completed_phase_start: typing.Optional[typing.Sequence[builtins.str]] = None,
        completed_phase_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        project_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodeBuild Build Phase Change.

        :param additional_information: (experimental) additional-information property. Specify an array of string values to match this event if the actual value of additional-information is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param build_id: (experimental) build-id property. Specify an array of string values to match this event if the actual value of build-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param completed_phase: (experimental) completed-phase property. Specify an array of string values to match this event if the actual value of completed-phase is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param completed_phase_context: (experimental) completed-phase-context property. Specify an array of string values to match this event if the actual value of completed-phase-context is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param completed_phase_duration_seconds: (experimental) completed-phase-duration-seconds property. Specify an array of string values to match this event if the actual value of completed-phase-duration-seconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param completed_phase_end: (experimental) completed-phase-end property. Specify an array of string values to match this event if the actual value of completed-phase-end is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param completed_phase_start: (experimental) completed-phase-start property. Specify an array of string values to match this event if the actual value of completed-phase-start is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param completed_phase_status: (experimental) completed-phase-status property. Specify an array of string values to match this event if the actual value of completed-phase-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param project_name: (experimental) project-name property. Specify an array of string values to match this event if the actual value of project-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Project reference
        :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeBuildBuildPhaseChange.CodeBuildBuildPhaseChangeProps(
            additional_information=additional_information,
            build_id=build_id,
            completed_phase=completed_phase,
            completed_phase_context=completed_phase_context,
            completed_phase_duration_seconds=completed_phase_duration_seconds,
            completed_phase_end=completed_phase_end,
            completed_phase_start=completed_phase_start,
            completed_phase_status=completed_phase_status,
            event_metadata=event_metadata,
            project_name=project_name,
            version=version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.AdditionalInformation",
        jsii_struct_bases=[],
        name_mapping={
            "artifact": "artifact",
            "build_complete": "buildComplete",
            "build_start_time": "buildStartTime",
            "cache": "cache",
            "environment": "environment",
            "initiator": "initiator",
            "logs": "logs",
            "network_interface": "networkInterface",
            "phases": "phases",
            "queued_timeout_in_minutes": "queuedTimeoutInMinutes",
            "source": "source",
            "source_version": "sourceVersion",
            "timeout_in_minutes": "timeoutInMinutes",
            "vpc_config": "vpcConfig",
        },
    )
    class AdditionalInformation:
        def __init__(
            self,
            *,
            artifact: typing.Optional[typing.Union["CodeBuildBuildPhaseChange.Artifact", typing.Dict[builtins.str, typing.Any]]] = None,
            build_complete: typing.Optional[typing.Sequence[builtins.str]] = None,
            build_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            cache: typing.Optional[typing.Union["CodeBuildBuildPhaseChange.Cache", typing.Dict[builtins.str, typing.Any]]] = None,
            environment: typing.Optional[typing.Union["CodeBuildBuildPhaseChange.Environment", typing.Dict[builtins.str, typing.Any]]] = None,
            initiator: typing.Optional[typing.Sequence[builtins.str]] = None,
            logs: typing.Optional[typing.Union["CodeBuildBuildPhaseChange.Logs", typing.Dict[builtins.str, typing.Any]]] = None,
            network_interface: typing.Optional[typing.Union["CodeBuildBuildPhaseChange.NetworkInterface", typing.Dict[builtins.str, typing.Any]]] = None,
            phases: typing.Optional[typing.Sequence[typing.Union["CodeBuildBuildPhaseChange.AdditionalInformationItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            queued_timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
            source: typing.Optional[typing.Union["CodeBuildBuildPhaseChange.Source", typing.Dict[builtins.str, typing.Any]]] = None,
            source_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
            vpc_config: typing.Optional[typing.Union["CodeBuildBuildPhaseChange.VpcConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for Additional-information.

            :param artifact: (experimental) artifact property. Specify an array of string values to match this event if the actual value of artifact is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param build_complete: (experimental) build-complete property. Specify an array of string values to match this event if the actual value of build-complete is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param build_start_time: (experimental) build-start-time property. Specify an array of string values to match this event if the actual value of build-start-time is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param cache: (experimental) cache property. Specify an array of string values to match this event if the actual value of cache is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param environment: (experimental) environment property. Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param initiator: (experimental) initiator property. Specify an array of string values to match this event if the actual value of initiator is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param logs: (experimental) logs property. Specify an array of string values to match this event if the actual value of logs is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_interface: (experimental) network-interface property. Specify an array of string values to match this event if the actual value of network-interface is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param phases: (experimental) phases property. Specify an array of string values to match this event if the actual value of phases is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param queued_timeout_in_minutes: (experimental) queued-timeout-in-minutes property. Specify an array of string values to match this event if the actual value of queued-timeout-in-minutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source: (experimental) source property. Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_version: (experimental) source-version property. Specify an array of string values to match this event if the actual value of source-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param timeout_in_minutes: (experimental) timeout-in-minutes property. Specify an array of string values to match this event if the actual value of timeout-in-minutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_config: (experimental) vpc-config property. Specify an array of string values to match this event if the actual value of vpc-config is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                additional_information = codebuild_events.CodeBuildBuildPhaseChange.AdditionalInformation(
                    artifact=codebuild_events.CodeBuildBuildPhaseChange.Artifact(
                        location=["location"],
                        md5_sum=["md5Sum"],
                        sha256_sum=["sha256Sum"]
                    ),
                    build_complete=["buildComplete"],
                    build_start_time=["buildStartTime"],
                    cache=codebuild_events.CodeBuildBuildPhaseChange.Cache(
                        location=["location"],
                        type=["type"]
                    ),
                    environment=codebuild_events.CodeBuildBuildPhaseChange.Environment(
                        compute_type=["computeType"],
                        environment_variables=[codebuild_events.CodeBuildBuildPhaseChange.EnvironmentItem(
                            name=["name"],
                            type=["type"],
                            value=["value"]
                        )],
                        image=["image"],
                        image_pull_credentials_type=["imagePullCredentialsType"],
                        privileged_mode=["privilegedMode"],
                        type=["type"]
                    ),
                    initiator=["initiator"],
                    logs=codebuild_events.CodeBuildBuildPhaseChange.Logs(
                        deep_link=["deepLink"],
                        group_name=["groupName"],
                        stream_name=["streamName"]
                    ),
                    network_interface=codebuild_events.CodeBuildBuildPhaseChange.NetworkInterface(
                        eni_id=["eniId"],
                        subnet_id=["subnetId"]
                    ),
                    phases=[codebuild_events.CodeBuildBuildPhaseChange.AdditionalInformationItem(
                        duration_in_seconds=["durationInSeconds"],
                        end_time=["endTime"],
                        phase_context=["phaseContext"],
                        phase_status=["phaseStatus"],
                        phase_type=["phaseType"],
                        start_time=["startTime"]
                    )],
                    queued_timeout_in_minutes=["queuedTimeoutInMinutes"],
                    source=codebuild_events.CodeBuildBuildPhaseChange.Source(
                        auth=codebuild_events.CodeBuildBuildPhaseChange.Auth(
                            type=["type"]
                        ),
                        buildspec=["buildspec"],
                        location=["location"],
                        type=["type"]
                    ),
                    source_version=["sourceVersion"],
                    timeout_in_minutes=["timeoutInMinutes"],
                    vpc_config=codebuild_events.CodeBuildBuildPhaseChange.VpcConfig(
                        security_group_ids=["securityGroupIds"],
                        subnets=[codebuild_events.CodeBuildBuildPhaseChange.VpcConfigItem(
                            build_fleet_az=["buildFleetAz"],
                            customer_az=["customerAz"],
                            subnet_id=["subnetId"]
                        )],
                        vpc_id=["vpcId"]
                    )
                )
            '''
            if isinstance(artifact, dict):
                artifact = CodeBuildBuildPhaseChange.Artifact(**artifact)
            if isinstance(cache, dict):
                cache = CodeBuildBuildPhaseChange.Cache(**cache)
            if isinstance(environment, dict):
                environment = CodeBuildBuildPhaseChange.Environment(**environment)
            if isinstance(logs, dict):
                logs = CodeBuildBuildPhaseChange.Logs(**logs)
            if isinstance(network_interface, dict):
                network_interface = CodeBuildBuildPhaseChange.NetworkInterface(**network_interface)
            if isinstance(source, dict):
                source = CodeBuildBuildPhaseChange.Source(**source)
            if isinstance(vpc_config, dict):
                vpc_config = CodeBuildBuildPhaseChange.VpcConfig(**vpc_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9b7efde68fd58ae12013758ec71552ddcc88e89fd5c16e5f9b19d594ce311362)
                check_type(argname="argument artifact", value=artifact, expected_type=type_hints["artifact"])
                check_type(argname="argument build_complete", value=build_complete, expected_type=type_hints["build_complete"])
                check_type(argname="argument build_start_time", value=build_start_time, expected_type=type_hints["build_start_time"])
                check_type(argname="argument cache", value=cache, expected_type=type_hints["cache"])
                check_type(argname="argument environment", value=environment, expected_type=type_hints["environment"])
                check_type(argname="argument initiator", value=initiator, expected_type=type_hints["initiator"])
                check_type(argname="argument logs", value=logs, expected_type=type_hints["logs"])
                check_type(argname="argument network_interface", value=network_interface, expected_type=type_hints["network_interface"])
                check_type(argname="argument phases", value=phases, expected_type=type_hints["phases"])
                check_type(argname="argument queued_timeout_in_minutes", value=queued_timeout_in_minutes, expected_type=type_hints["queued_timeout_in_minutes"])
                check_type(argname="argument source", value=source, expected_type=type_hints["source"])
                check_type(argname="argument source_version", value=source_version, expected_type=type_hints["source_version"])
                check_type(argname="argument timeout_in_minutes", value=timeout_in_minutes, expected_type=type_hints["timeout_in_minutes"])
                check_type(argname="argument vpc_config", value=vpc_config, expected_type=type_hints["vpc_config"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if artifact is not None:
                self._values["artifact"] = artifact
            if build_complete is not None:
                self._values["build_complete"] = build_complete
            if build_start_time is not None:
                self._values["build_start_time"] = build_start_time
            if cache is not None:
                self._values["cache"] = cache
            if environment is not None:
                self._values["environment"] = environment
            if initiator is not None:
                self._values["initiator"] = initiator
            if logs is not None:
                self._values["logs"] = logs
            if network_interface is not None:
                self._values["network_interface"] = network_interface
            if phases is not None:
                self._values["phases"] = phases
            if queued_timeout_in_minutes is not None:
                self._values["queued_timeout_in_minutes"] = queued_timeout_in_minutes
            if source is not None:
                self._values["source"] = source
            if source_version is not None:
                self._values["source_version"] = source_version
            if timeout_in_minutes is not None:
                self._values["timeout_in_minutes"] = timeout_in_minutes
            if vpc_config is not None:
                self._values["vpc_config"] = vpc_config

        @builtins.property
        def artifact(self) -> typing.Optional["CodeBuildBuildPhaseChange.Artifact"]:
            '''(experimental) artifact property.

            Specify an array of string values to match this event if the actual value of artifact is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("artifact")
            return typing.cast(typing.Optional["CodeBuildBuildPhaseChange.Artifact"], result)

        @builtins.property
        def build_complete(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) build-complete property.

            Specify an array of string values to match this event if the actual value of build-complete is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("build_complete")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def build_start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) build-start-time property.

            Specify an array of string values to match this event if the actual value of build-start-time is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("build_start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def cache(self) -> typing.Optional["CodeBuildBuildPhaseChange.Cache"]:
            '''(experimental) cache property.

            Specify an array of string values to match this event if the actual value of cache is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cache")
            return typing.cast(typing.Optional["CodeBuildBuildPhaseChange.Cache"], result)

        @builtins.property
        def environment(
            self,
        ) -> typing.Optional["CodeBuildBuildPhaseChange.Environment"]:
            '''(experimental) environment property.

            Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("environment")
            return typing.cast(typing.Optional["CodeBuildBuildPhaseChange.Environment"], result)

        @builtins.property
        def initiator(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) initiator property.

            Specify an array of string values to match this event if the actual value of initiator is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("initiator")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def logs(self) -> typing.Optional["CodeBuildBuildPhaseChange.Logs"]:
            '''(experimental) logs property.

            Specify an array of string values to match this event if the actual value of logs is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("logs")
            return typing.cast(typing.Optional["CodeBuildBuildPhaseChange.Logs"], result)

        @builtins.property
        def network_interface(
            self,
        ) -> typing.Optional["CodeBuildBuildPhaseChange.NetworkInterface"]:
            '''(experimental) network-interface property.

            Specify an array of string values to match this event if the actual value of network-interface is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_interface")
            return typing.cast(typing.Optional["CodeBuildBuildPhaseChange.NetworkInterface"], result)

        @builtins.property
        def phases(
            self,
        ) -> typing.Optional[typing.List["CodeBuildBuildPhaseChange.AdditionalInformationItem"]]:
            '''(experimental) phases property.

            Specify an array of string values to match this event if the actual value of phases is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("phases")
            return typing.cast(typing.Optional[typing.List["CodeBuildBuildPhaseChange.AdditionalInformationItem"]], result)

        @builtins.property
        def queued_timeout_in_minutes(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) queued-timeout-in-minutes property.

            Specify an array of string values to match this event if the actual value of queued-timeout-in-minutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("queued_timeout_in_minutes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source(self) -> typing.Optional["CodeBuildBuildPhaseChange.Source"]:
            '''(experimental) source property.

            Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source")
            return typing.cast(typing.Optional["CodeBuildBuildPhaseChange.Source"], result)

        @builtins.property
        def source_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) source-version property.

            Specify an array of string values to match this event if the actual value of source-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def timeout_in_minutes(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) timeout-in-minutes property.

            Specify an array of string values to match this event if the actual value of timeout-in-minutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("timeout_in_minutes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def vpc_config(self) -> typing.Optional["CodeBuildBuildPhaseChange.VpcConfig"]:
            '''(experimental) vpc-config property.

            Specify an array of string values to match this event if the actual value of vpc-config is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_config")
            return typing.cast(typing.Optional["CodeBuildBuildPhaseChange.VpcConfig"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AdditionalInformation(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.AdditionalInformationItem",
        jsii_struct_bases=[],
        name_mapping={
            "duration_in_seconds": "durationInSeconds",
            "end_time": "endTime",
            "phase_context": "phaseContext",
            "phase_status": "phaseStatus",
            "phase_type": "phaseType",
            "start_time": "startTime",
        },
    )
    class AdditionalInformationItem:
        def __init__(
            self,
            *,
            duration_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
            phase_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            phase_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Additional-informationItem.

            :param duration_in_seconds: (experimental) duration-in-seconds property. Specify an array of string values to match this event if the actual value of duration-in-seconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) end-time property. Specify an array of string values to match this event if the actual value of end-time is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param phase_context: (experimental) phase-context property. Specify an array of string values to match this event if the actual value of phase-context is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param phase_status: (experimental) phase-status property. Specify an array of string values to match this event if the actual value of phase-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param phase_type: (experimental) phase-type property. Specify an array of string values to match this event if the actual value of phase-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) start-time property. Specify an array of string values to match this event if the actual value of start-time is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                additional_information_item = codebuild_events.CodeBuildBuildPhaseChange.AdditionalInformationItem(
                    duration_in_seconds=["durationInSeconds"],
                    end_time=["endTime"],
                    phase_context=["phaseContext"],
                    phase_status=["phaseStatus"],
                    phase_type=["phaseType"],
                    start_time=["startTime"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4febbe4795c393f35ed64635987d8dbb9a00df11f2cbd72e522a4423b0661fcf)
                check_type(argname="argument duration_in_seconds", value=duration_in_seconds, expected_type=type_hints["duration_in_seconds"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument phase_context", value=phase_context, expected_type=type_hints["phase_context"])
                check_type(argname="argument phase_status", value=phase_status, expected_type=type_hints["phase_status"])
                check_type(argname="argument phase_type", value=phase_type, expected_type=type_hints["phase_type"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if duration_in_seconds is not None:
                self._values["duration_in_seconds"] = duration_in_seconds
            if end_time is not None:
                self._values["end_time"] = end_time
            if phase_context is not None:
                self._values["phase_context"] = phase_context
            if phase_status is not None:
                self._values["phase_status"] = phase_status
            if phase_type is not None:
                self._values["phase_type"] = phase_type
            if start_time is not None:
                self._values["start_time"] = start_time

        @builtins.property
        def duration_in_seconds(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) duration-in-seconds property.

            Specify an array of string values to match this event if the actual value of duration-in-seconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("duration_in_seconds")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) end-time property.

            Specify an array of string values to match this event if the actual value of end-time is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def phase_context(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) phase-context property.

            Specify an array of string values to match this event if the actual value of phase-context is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("phase_context")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def phase_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) phase-status property.

            Specify an array of string values to match this event if the actual value of phase-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("phase_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def phase_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) phase-type property.

            Specify an array of string values to match this event if the actual value of phase-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("phase_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) start-time property.

            Specify an array of string values to match this event if the actual value of start-time is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AdditionalInformationItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.Artifact",
        jsii_struct_bases=[],
        name_mapping={
            "location": "location",
            "md5_sum": "md5Sum",
            "sha256_sum": "sha256Sum",
        },
    )
    class Artifact:
        def __init__(
            self,
            *,
            location: typing.Optional[typing.Sequence[builtins.str]] = None,
            md5_sum: typing.Optional[typing.Sequence[builtins.str]] = None,
            sha256_sum: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Artifact.

            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param md5_sum: (experimental) md5sum property. Specify an array of string values to match this event if the actual value of md5sum is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param sha256_sum: (experimental) sha256sum property. Specify an array of string values to match this event if the actual value of sha256sum is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                artifact = codebuild_events.CodeBuildBuildPhaseChange.Artifact(
                    location=["location"],
                    md5_sum=["md5Sum"],
                    sha256_sum=["sha256Sum"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e3af66b4ebaa434a62f73b6251553a79242e39363bb84210c25a2a7e7022167e)
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
                check_type(argname="argument md5_sum", value=md5_sum, expected_type=type_hints["md5_sum"])
                check_type(argname="argument sha256_sum", value=sha256_sum, expected_type=type_hints["sha256_sum"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if location is not None:
                self._values["location"] = location
            if md5_sum is not None:
                self._values["md5_sum"] = md5_sum
            if sha256_sum is not None:
                self._values["sha256_sum"] = sha256_sum

        @builtins.property
        def location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def md5_sum(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) md5sum property.

            Specify an array of string values to match this event if the actual value of md5sum is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("md5_sum")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def sha256_sum(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sha256sum property.

            Specify an array of string values to match this event if the actual value of sha256sum is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("sha256_sum")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Artifact(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.Auth",
        jsii_struct_bases=[],
        name_mapping={"type": "type"},
    )
    class Auth:
        def __init__(
            self,
            *,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Auth.

            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                auth = codebuild_events.CodeBuildBuildPhaseChange.Auth(
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__27d9d008470c867d21fd5d4973a24bcd4b458d0a29e6f2aea6d15632f00bacf1)
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Auth(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.Cache",
        jsii_struct_bases=[],
        name_mapping={"location": "location", "type": "type"},
    )
    class Cache:
        def __init__(
            self,
            *,
            location: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Cache.

            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                cache = codebuild_events.CodeBuildBuildPhaseChange.Cache(
                    location=["location"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7ec787685bd2f35d093ba374b660ac8003afa2b5b1e604543160666659567aa4)
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if location is not None:
                self._values["location"] = location
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Cache(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.CodeBuildBuildPhaseChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "additional_information": "additionalInformation",
            "build_id": "buildId",
            "completed_phase": "completedPhase",
            "completed_phase_context": "completedPhaseContext",
            "completed_phase_duration_seconds": "completedPhaseDurationSeconds",
            "completed_phase_end": "completedPhaseEnd",
            "completed_phase_start": "completedPhaseStart",
            "completed_phase_status": "completedPhaseStatus",
            "event_metadata": "eventMetadata",
            "project_name": "projectName",
            "version": "version",
        },
    )
    class CodeBuildBuildPhaseChangeProps:
        def __init__(
            self,
            *,
            additional_information: typing.Optional[typing.Union["CodeBuildBuildPhaseChange.AdditionalInformation", typing.Dict[builtins.str, typing.Any]]] = None,
            build_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            completed_phase: typing.Optional[typing.Sequence[builtins.str]] = None,
            completed_phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
            completed_phase_duration_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
            completed_phase_end: typing.Optional[typing.Sequence[builtins.str]] = None,
            completed_phase_start: typing.Optional[typing.Sequence[builtins.str]] = None,
            completed_phase_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            project_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codebuild@CodeBuildBuildPhaseChange event.

            :param additional_information: (experimental) additional-information property. Specify an array of string values to match this event if the actual value of additional-information is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param build_id: (experimental) build-id property. Specify an array of string values to match this event if the actual value of build-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param completed_phase: (experimental) completed-phase property. Specify an array of string values to match this event if the actual value of completed-phase is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param completed_phase_context: (experimental) completed-phase-context property. Specify an array of string values to match this event if the actual value of completed-phase-context is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param completed_phase_duration_seconds: (experimental) completed-phase-duration-seconds property. Specify an array of string values to match this event if the actual value of completed-phase-duration-seconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param completed_phase_end: (experimental) completed-phase-end property. Specify an array of string values to match this event if the actual value of completed-phase-end is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param completed_phase_start: (experimental) completed-phase-start property. Specify an array of string values to match this event if the actual value of completed-phase-start is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param completed_phase_status: (experimental) completed-phase-status property. Specify an array of string values to match this event if the actual value of completed-phase-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param project_name: (experimental) project-name property. Specify an array of string values to match this event if the actual value of project-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Project reference
            :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                code_build_build_phase_change_props = codebuild_events.CodeBuildBuildPhaseChange.CodeBuildBuildPhaseChangeProps(
                    additional_information=codebuild_events.CodeBuildBuildPhaseChange.AdditionalInformation(
                        artifact=codebuild_events.CodeBuildBuildPhaseChange.Artifact(
                            location=["location"],
                            md5_sum=["md5Sum"],
                            sha256_sum=["sha256Sum"]
                        ),
                        build_complete=["buildComplete"],
                        build_start_time=["buildStartTime"],
                        cache=codebuild_events.CodeBuildBuildPhaseChange.Cache(
                            location=["location"],
                            type=["type"]
                        ),
                        environment=codebuild_events.CodeBuildBuildPhaseChange.Environment(
                            compute_type=["computeType"],
                            environment_variables=[codebuild_events.CodeBuildBuildPhaseChange.EnvironmentItem(
                                name=["name"],
                                type=["type"],
                                value=["value"]
                            )],
                            image=["image"],
                            image_pull_credentials_type=["imagePullCredentialsType"],
                            privileged_mode=["privilegedMode"],
                            type=["type"]
                        ),
                        initiator=["initiator"],
                        logs=codebuild_events.CodeBuildBuildPhaseChange.Logs(
                            deep_link=["deepLink"],
                            group_name=["groupName"],
                            stream_name=["streamName"]
                        ),
                        network_interface=codebuild_events.CodeBuildBuildPhaseChange.NetworkInterface(
                            eni_id=["eniId"],
                            subnet_id=["subnetId"]
                        ),
                        phases=[codebuild_events.CodeBuildBuildPhaseChange.AdditionalInformationItem(
                            duration_in_seconds=["durationInSeconds"],
                            end_time=["endTime"],
                            phase_context=["phaseContext"],
                            phase_status=["phaseStatus"],
                            phase_type=["phaseType"],
                            start_time=["startTime"]
                        )],
                        queued_timeout_in_minutes=["queuedTimeoutInMinutes"],
                        source=codebuild_events.CodeBuildBuildPhaseChange.Source(
                            auth=codebuild_events.CodeBuildBuildPhaseChange.Auth(
                                type=["type"]
                            ),
                            buildspec=["buildspec"],
                            location=["location"],
                            type=["type"]
                        ),
                        source_version=["sourceVersion"],
                        timeout_in_minutes=["timeoutInMinutes"],
                        vpc_config=codebuild_events.CodeBuildBuildPhaseChange.VpcConfig(
                            security_group_ids=["securityGroupIds"],
                            subnets=[codebuild_events.CodeBuildBuildPhaseChange.VpcConfigItem(
                                build_fleet_az=["buildFleetAz"],
                                customer_az=["customerAz"],
                                subnet_id=["subnetId"]
                            )],
                            vpc_id=["vpcId"]
                        )
                    ),
                    build_id=["buildId"],
                    completed_phase=["completedPhase"],
                    completed_phase_context=["completedPhaseContext"],
                    completed_phase_duration_seconds=["completedPhaseDurationSeconds"],
                    completed_phase_end=["completedPhaseEnd"],
                    completed_phase_start=["completedPhaseStart"],
                    completed_phase_status=["completedPhaseStatus"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    project_name=["projectName"],
                    version=["version"]
                )
            '''
            if isinstance(additional_information, dict):
                additional_information = CodeBuildBuildPhaseChange.AdditionalInformation(**additional_information)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7be86d1ee12ed9c46427f0835dfa49f749b21fa1402cb4087c8773bc118f6d94)
                check_type(argname="argument additional_information", value=additional_information, expected_type=type_hints["additional_information"])
                check_type(argname="argument build_id", value=build_id, expected_type=type_hints["build_id"])
                check_type(argname="argument completed_phase", value=completed_phase, expected_type=type_hints["completed_phase"])
                check_type(argname="argument completed_phase_context", value=completed_phase_context, expected_type=type_hints["completed_phase_context"])
                check_type(argname="argument completed_phase_duration_seconds", value=completed_phase_duration_seconds, expected_type=type_hints["completed_phase_duration_seconds"])
                check_type(argname="argument completed_phase_end", value=completed_phase_end, expected_type=type_hints["completed_phase_end"])
                check_type(argname="argument completed_phase_start", value=completed_phase_start, expected_type=type_hints["completed_phase_start"])
                check_type(argname="argument completed_phase_status", value=completed_phase_status, expected_type=type_hints["completed_phase_status"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument project_name", value=project_name, expected_type=type_hints["project_name"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if additional_information is not None:
                self._values["additional_information"] = additional_information
            if build_id is not None:
                self._values["build_id"] = build_id
            if completed_phase is not None:
                self._values["completed_phase"] = completed_phase
            if completed_phase_context is not None:
                self._values["completed_phase_context"] = completed_phase_context
            if completed_phase_duration_seconds is not None:
                self._values["completed_phase_duration_seconds"] = completed_phase_duration_seconds
            if completed_phase_end is not None:
                self._values["completed_phase_end"] = completed_phase_end
            if completed_phase_start is not None:
                self._values["completed_phase_start"] = completed_phase_start
            if completed_phase_status is not None:
                self._values["completed_phase_status"] = completed_phase_status
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if project_name is not None:
                self._values["project_name"] = project_name
            if version is not None:
                self._values["version"] = version

        @builtins.property
        def additional_information(
            self,
        ) -> typing.Optional["CodeBuildBuildPhaseChange.AdditionalInformation"]:
            '''(experimental) additional-information property.

            Specify an array of string values to match this event if the actual value of additional-information is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("additional_information")
            return typing.cast(typing.Optional["CodeBuildBuildPhaseChange.AdditionalInformation"], result)

        @builtins.property
        def build_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) build-id property.

            Specify an array of string values to match this event if the actual value of build-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("build_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def completed_phase(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) completed-phase property.

            Specify an array of string values to match this event if the actual value of completed-phase is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("completed_phase")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def completed_phase_context(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) completed-phase-context property.

            Specify an array of string values to match this event if the actual value of completed-phase-context is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("completed_phase_context")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def completed_phase_duration_seconds(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) completed-phase-duration-seconds property.

            Specify an array of string values to match this event if the actual value of completed-phase-duration-seconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("completed_phase_duration_seconds")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def completed_phase_end(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) completed-phase-end property.

            Specify an array of string values to match this event if the actual value of completed-phase-end is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("completed_phase_end")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def completed_phase_start(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) completed-phase-start property.

            Specify an array of string values to match this event if the actual value of completed-phase-start is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("completed_phase_start")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def completed_phase_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) completed-phase-status property.

            Specify an array of string values to match this event if the actual value of completed-phase-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("completed_phase_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def project_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) project-name property.

            Specify an array of string values to match this event if the actual value of project-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Project reference

            :stability: experimental
            '''
            result = self._values.get("project_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version property.

            Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodeBuildBuildPhaseChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.Environment",
        jsii_struct_bases=[],
        name_mapping={
            "compute_type": "computeType",
            "environment_variables": "environmentVariables",
            "image": "image",
            "image_pull_credentials_type": "imagePullCredentialsType",
            "privileged_mode": "privilegedMode",
            "type": "type",
        },
    )
    class Environment:
        def __init__(
            self,
            *,
            compute_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            environment_variables: typing.Optional[typing.Sequence[typing.Union["CodeBuildBuildPhaseChange.EnvironmentItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            image: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_pull_credentials_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            privileged_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Environment.

            :param compute_type: (experimental) compute-type property. Specify an array of string values to match this event if the actual value of compute-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param environment_variables: (experimental) environment-variables property. Specify an array of string values to match this event if the actual value of environment-variables is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image: (experimental) image property. Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_pull_credentials_type: (experimental) image-pull-credentials-type property. Specify an array of string values to match this event if the actual value of image-pull-credentials-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param privileged_mode: (experimental) privileged-mode property. Specify an array of string values to match this event if the actual value of privileged-mode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                environment = codebuild_events.CodeBuildBuildPhaseChange.Environment(
                    compute_type=["computeType"],
                    environment_variables=[codebuild_events.CodeBuildBuildPhaseChange.EnvironmentItem(
                        name=["name"],
                        type=["type"],
                        value=["value"]
                    )],
                    image=["image"],
                    image_pull_credentials_type=["imagePullCredentialsType"],
                    privileged_mode=["privilegedMode"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__14dc0ad0ff266847dfeaa34e3b64882a4a07fab90079ce828bc3b9833f79e22f)
                check_type(argname="argument compute_type", value=compute_type, expected_type=type_hints["compute_type"])
                check_type(argname="argument environment_variables", value=environment_variables, expected_type=type_hints["environment_variables"])
                check_type(argname="argument image", value=image, expected_type=type_hints["image"])
                check_type(argname="argument image_pull_credentials_type", value=image_pull_credentials_type, expected_type=type_hints["image_pull_credentials_type"])
                check_type(argname="argument privileged_mode", value=privileged_mode, expected_type=type_hints["privileged_mode"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if compute_type is not None:
                self._values["compute_type"] = compute_type
            if environment_variables is not None:
                self._values["environment_variables"] = environment_variables
            if image is not None:
                self._values["image"] = image
            if image_pull_credentials_type is not None:
                self._values["image_pull_credentials_type"] = image_pull_credentials_type
            if privileged_mode is not None:
                self._values["privileged_mode"] = privileged_mode
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def compute_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) compute-type property.

            Specify an array of string values to match this event if the actual value of compute-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("compute_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def environment_variables(
            self,
        ) -> typing.Optional[typing.List["CodeBuildBuildPhaseChange.EnvironmentItem"]]:
            '''(experimental) environment-variables property.

            Specify an array of string values to match this event if the actual value of environment-variables is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("environment_variables")
            return typing.cast(typing.Optional[typing.List["CodeBuildBuildPhaseChange.EnvironmentItem"]], result)

        @builtins.property
        def image(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) image property.

            Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_pull_credentials_type(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) image-pull-credentials-type property.

            Specify an array of string values to match this event if the actual value of image-pull-credentials-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_pull_credentials_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def privileged_mode(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) privileged-mode property.

            Specify an array of string values to match this event if the actual value of privileged-mode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("privileged_mode")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Environment(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.EnvironmentItem",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "type": "type", "value": "value"},
    )
    class EnvironmentItem:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for EnvironmentItem.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                environment_item = codebuild_events.CodeBuildBuildPhaseChange.EnvironmentItem(
                    name=["name"],
                    type=["type"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__bd817946916681c446c5b521c48653a0c0d7773a2e6fc146dd470165c5ff69db)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if type is not None:
                self._values["type"] = type
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EnvironmentItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.Logs",
        jsii_struct_bases=[],
        name_mapping={
            "deep_link": "deepLink",
            "group_name": "groupName",
            "stream_name": "streamName",
        },
    )
    class Logs:
        def __init__(
            self,
            *,
            deep_link: typing.Optional[typing.Sequence[builtins.str]] = None,
            group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            stream_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Logs.

            :param deep_link: (experimental) deep-link property. Specify an array of string values to match this event if the actual value of deep-link is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_name: (experimental) group-name property. Specify an array of string values to match this event if the actual value of group-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stream_name: (experimental) stream-name property. Specify an array of string values to match this event if the actual value of stream-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                logs = codebuild_events.CodeBuildBuildPhaseChange.Logs(
                    deep_link=["deepLink"],
                    group_name=["groupName"],
                    stream_name=["streamName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a3db0c960b51a1c3d1a7fad4f14ac38e0c1bc1ffc8a7af50ef675920289ba31c)
                check_type(argname="argument deep_link", value=deep_link, expected_type=type_hints["deep_link"])
                check_type(argname="argument group_name", value=group_name, expected_type=type_hints["group_name"])
                check_type(argname="argument stream_name", value=stream_name, expected_type=type_hints["stream_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if deep_link is not None:
                self._values["deep_link"] = deep_link
            if group_name is not None:
                self._values["group_name"] = group_name
            if stream_name is not None:
                self._values["stream_name"] = stream_name

        @builtins.property
        def deep_link(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) deep-link property.

            Specify an array of string values to match this event if the actual value of deep-link is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("deep_link")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) group-name property.

            Specify an array of string values to match this event if the actual value of group-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stream_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stream-name property.

            Specify an array of string values to match this event if the actual value of stream-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stream_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Logs(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.NetworkInterface",
        jsii_struct_bases=[],
        name_mapping={"eni_id": "eniId", "subnet_id": "subnetId"},
    )
    class NetworkInterface:
        def __init__(
            self,
            *,
            eni_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Network-interface.

            :param eni_id: (experimental) eni-id property. Specify an array of string values to match this event if the actual value of eni-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) subnet-id property. Specify an array of string values to match this event if the actual value of subnet-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                network_interface = codebuild_events.CodeBuildBuildPhaseChange.NetworkInterface(
                    eni_id=["eniId"],
                    subnet_id=["subnetId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__27610d6749bc24aa82d8e0e70c32084d167a697f4eb05687c338cfd99e28eea1)
                check_type(argname="argument eni_id", value=eni_id, expected_type=type_hints["eni_id"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if eni_id is not None:
                self._values["eni_id"] = eni_id
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id

        @builtins.property
        def eni_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eni-id property.

            Specify an array of string values to match this event if the actual value of eni-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("eni_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) subnet-id property.

            Specify an array of string values to match this event if the actual value of subnet-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "NetworkInterface(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.Source",
        jsii_struct_bases=[],
        name_mapping={
            "auth": "auth",
            "buildspec": "buildspec",
            "location": "location",
            "type": "type",
        },
    )
    class Source:
        def __init__(
            self,
            *,
            auth: typing.Optional[typing.Union["CodeBuildBuildPhaseChange.Auth", typing.Dict[builtins.str, typing.Any]]] = None,
            buildspec: typing.Optional[typing.Sequence[builtins.str]] = None,
            location: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Source.

            :param auth: (experimental) auth property. Specify an array of string values to match this event if the actual value of auth is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param buildspec: (experimental) buildspec property. Specify an array of string values to match this event if the actual value of buildspec is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                source = codebuild_events.CodeBuildBuildPhaseChange.Source(
                    auth=codebuild_events.CodeBuildBuildPhaseChange.Auth(
                        type=["type"]
                    ),
                    buildspec=["buildspec"],
                    location=["location"],
                    type=["type"]
                )
            '''
            if isinstance(auth, dict):
                auth = CodeBuildBuildPhaseChange.Auth(**auth)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__36b7014a7e6e48528ab7e07197c49b57a7381e3e8b1af70f7325f21c64f5505d)
                check_type(argname="argument auth", value=auth, expected_type=type_hints["auth"])
                check_type(argname="argument buildspec", value=buildspec, expected_type=type_hints["buildspec"])
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if auth is not None:
                self._values["auth"] = auth
            if buildspec is not None:
                self._values["buildspec"] = buildspec
            if location is not None:
                self._values["location"] = location
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def auth(self) -> typing.Optional["CodeBuildBuildPhaseChange.Auth"]:
            '''(experimental) auth property.

            Specify an array of string values to match this event if the actual value of auth is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("auth")
            return typing.cast(typing.Optional["CodeBuildBuildPhaseChange.Auth"], result)

        @builtins.property
        def buildspec(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) buildspec property.

            Specify an array of string values to match this event if the actual value of buildspec is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("buildspec")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Source(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.VpcConfig",
        jsii_struct_bases=[],
        name_mapping={
            "security_group_ids": "securityGroupIds",
            "subnets": "subnets",
            "vpc_id": "vpcId",
        },
    )
    class VpcConfig:
        def __init__(
            self,
            *,
            security_group_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnets: typing.Optional[typing.Sequence[typing.Union["CodeBuildBuildPhaseChange.VpcConfigItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Vpc-config.

            :param security_group_ids: (experimental) security-group-ids property. Specify an array of string values to match this event if the actual value of security-group-ids is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnets: (experimental) subnets property. Specify an array of string values to match this event if the actual value of subnets is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_id: (experimental) vpc-id property. Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                vpc_config = codebuild_events.CodeBuildBuildPhaseChange.VpcConfig(
                    security_group_ids=["securityGroupIds"],
                    subnets=[codebuild_events.CodeBuildBuildPhaseChange.VpcConfigItem(
                        build_fleet_az=["buildFleetAz"],
                        customer_az=["customerAz"],
                        subnet_id=["subnetId"]
                    )],
                    vpc_id=["vpcId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9a108810434402a5cc7e1bf359ffd869a3ef01b096211032e62c4050c9e557b5)
                check_type(argname="argument security_group_ids", value=security_group_ids, expected_type=type_hints["security_group_ids"])
                check_type(argname="argument subnets", value=subnets, expected_type=type_hints["subnets"])
                check_type(argname="argument vpc_id", value=vpc_id, expected_type=type_hints["vpc_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if security_group_ids is not None:
                self._values["security_group_ids"] = security_group_ids
            if subnets is not None:
                self._values["subnets"] = subnets
            if vpc_id is not None:
                self._values["vpc_id"] = vpc_id

        @builtins.property
        def security_group_ids(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) security-group-ids property.

            Specify an array of string values to match this event if the actual value of security-group-ids is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("security_group_ids")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnets(
            self,
        ) -> typing.Optional[typing.List["CodeBuildBuildPhaseChange.VpcConfigItem"]]:
            '''(experimental) subnets property.

            Specify an array of string values to match this event if the actual value of subnets is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnets")
            return typing.cast(typing.Optional[typing.List["CodeBuildBuildPhaseChange.VpcConfigItem"]], result)

        @builtins.property
        def vpc_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) vpc-id property.

            Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VpcConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildPhaseChange.VpcConfigItem",
        jsii_struct_bases=[],
        name_mapping={
            "build_fleet_az": "buildFleetAz",
            "customer_az": "customerAz",
            "subnet_id": "subnetId",
        },
    )
    class VpcConfigItem:
        def __init__(
            self,
            *,
            build_fleet_az: typing.Optional[typing.Sequence[builtins.str]] = None,
            customer_az: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Vpc-configItem.

            :param build_fleet_az: (experimental) build-fleet-az property. Specify an array of string values to match this event if the actual value of build-fleet-az is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param customer_az: (experimental) customer-az property. Specify an array of string values to match this event if the actual value of customer-az is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) subnet-id property. Specify an array of string values to match this event if the actual value of subnet-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                vpc_config_item = codebuild_events.CodeBuildBuildPhaseChange.VpcConfigItem(
                    build_fleet_az=["buildFleetAz"],
                    customer_az=["customerAz"],
                    subnet_id=["subnetId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e089c6bf92a8e4d72a2a6660ed48803cf5cff1478aeeffb9e64ce20666a13b25)
                check_type(argname="argument build_fleet_az", value=build_fleet_az, expected_type=type_hints["build_fleet_az"])
                check_type(argname="argument customer_az", value=customer_az, expected_type=type_hints["customer_az"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if build_fleet_az is not None:
                self._values["build_fleet_az"] = build_fleet_az
            if customer_az is not None:
                self._values["customer_az"] = customer_az
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id

        @builtins.property
        def build_fleet_az(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) build-fleet-az property.

            Specify an array of string values to match this event if the actual value of build-fleet-az is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("build_fleet_az")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def customer_az(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) customer-az property.

            Specify an array of string values to match this event if the actual value of customer-az is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("customer_az")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) subnet-id property.

            Specify an array of string values to match this event if the actual value of subnet-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VpcConfigItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class CodeBuildBuildStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange",
):
    '''(experimental) EventBridge event pattern for aws.codebuild@CodeBuildBuildStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
        
        code_build_build_state_change = codebuild_events.CodeBuildBuildStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        additional_information: typing.Optional[typing.Union["CodeBuildBuildStateChange.AdditionalInformation", typing.Dict[builtins.str, typing.Any]]] = None,
        build_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        build_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        current_phase: typing.Optional[typing.Sequence[builtins.str]] = None,
        current_phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        project_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for CodeBuild Build State Change.

        :param additional_information: (experimental) additional-information property. Specify an array of string values to match this event if the actual value of additional-information is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param build_id: (experimental) build-id property. Specify an array of string values to match this event if the actual value of build-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param build_status: (experimental) build-status property. Specify an array of string values to match this event if the actual value of build-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param current_phase: (experimental) current-phase property. Specify an array of string values to match this event if the actual value of current-phase is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param current_phase_context: (experimental) current-phase-context property. Specify an array of string values to match this event if the actual value of current-phase-context is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param project_name: (experimental) project-name property. Specify an array of string values to match this event if the actual value of project-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Project reference
        :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeBuildBuildStateChange.CodeBuildBuildStateChangeProps(
            additional_information=additional_information,
            build_id=build_id,
            build_status=build_status,
            current_phase=current_phase,
            current_phase_context=current_phase_context,
            event_metadata=event_metadata,
            project_name=project_name,
            version=version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.AdditionalInformation",
        jsii_struct_bases=[],
        name_mapping={
            "artifact": "artifact",
            "build_complete": "buildComplete",
            "build_start_time": "buildStartTime",
            "cache": "cache",
            "environment": "environment",
            "initiator": "initiator",
            "logs": "logs",
            "network_interface": "networkInterface",
            "phases": "phases",
            "queued_timeout_in_minutes": "queuedTimeoutInMinutes",
            "source": "source",
            "source_version": "sourceVersion",
            "timeout_in_minutes": "timeoutInMinutes",
            "vpc_config": "vpcConfig",
        },
    )
    class AdditionalInformation:
        def __init__(
            self,
            *,
            artifact: typing.Optional[typing.Union["CodeBuildBuildStateChange.Artifact", typing.Dict[builtins.str, typing.Any]]] = None,
            build_complete: typing.Optional[typing.Sequence[builtins.str]] = None,
            build_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            cache: typing.Optional[typing.Union["CodeBuildBuildStateChange.Cache", typing.Dict[builtins.str, typing.Any]]] = None,
            environment: typing.Optional[typing.Union["CodeBuildBuildStateChange.Environment", typing.Dict[builtins.str, typing.Any]]] = None,
            initiator: typing.Optional[typing.Sequence[builtins.str]] = None,
            logs: typing.Optional[typing.Union["CodeBuildBuildStateChange.Logs", typing.Dict[builtins.str, typing.Any]]] = None,
            network_interface: typing.Optional[typing.Union["CodeBuildBuildStateChange.NetworkInterface", typing.Dict[builtins.str, typing.Any]]] = None,
            phases: typing.Optional[typing.Sequence[typing.Union["CodeBuildBuildStateChange.AdditionalInformationItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            queued_timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
            source: typing.Optional[typing.Union["CodeBuildBuildStateChange.Source", typing.Dict[builtins.str, typing.Any]]] = None,
            source_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
            vpc_config: typing.Optional[typing.Union["CodeBuildBuildStateChange.VpcConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for Additional-information.

            :param artifact: (experimental) artifact property. Specify an array of string values to match this event if the actual value of artifact is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param build_complete: (experimental) build-complete property. Specify an array of string values to match this event if the actual value of build-complete is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param build_start_time: (experimental) build-start-time property. Specify an array of string values to match this event if the actual value of build-start-time is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param cache: (experimental) cache property. Specify an array of string values to match this event if the actual value of cache is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param environment: (experimental) environment property. Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param initiator: (experimental) initiator property. Specify an array of string values to match this event if the actual value of initiator is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param logs: (experimental) logs property. Specify an array of string values to match this event if the actual value of logs is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param network_interface: (experimental) network-interface property. Specify an array of string values to match this event if the actual value of network-interface is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param phases: (experimental) phases property. Specify an array of string values to match this event if the actual value of phases is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param queued_timeout_in_minutes: (experimental) queued-timeout-in-minutes property. Specify an array of string values to match this event if the actual value of queued-timeout-in-minutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source: (experimental) source property. Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_version: (experimental) source-version property. Specify an array of string values to match this event if the actual value of source-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param timeout_in_minutes: (experimental) timeout-in-minutes property. Specify an array of string values to match this event if the actual value of timeout-in-minutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_config: (experimental) vpc-config property. Specify an array of string values to match this event if the actual value of vpc-config is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                additional_information = codebuild_events.CodeBuildBuildStateChange.AdditionalInformation(
                    artifact=codebuild_events.CodeBuildBuildStateChange.Artifact(
                        location=["location"],
                        md5_sum=["md5Sum"],
                        sha256_sum=["sha256Sum"]
                    ),
                    build_complete=["buildComplete"],
                    build_start_time=["buildStartTime"],
                    cache=codebuild_events.CodeBuildBuildStateChange.Cache(
                        location=["location"],
                        type=["type"]
                    ),
                    environment=codebuild_events.CodeBuildBuildStateChange.Environment(
                        compute_type=["computeType"],
                        environment_variables=[codebuild_events.CodeBuildBuildStateChange.EnvironmentItem(
                            name=["name"],
                            type=["type"],
                            value=["value"]
                        )],
                        image=["image"],
                        image_pull_credentials_type=["imagePullCredentialsType"],
                        privileged_mode=["privilegedMode"],
                        type=["type"]
                    ),
                    initiator=["initiator"],
                    logs=codebuild_events.CodeBuildBuildStateChange.Logs(
                        deep_link=["deepLink"],
                        group_name=["groupName"],
                        stream_name=["streamName"]
                    ),
                    network_interface=codebuild_events.CodeBuildBuildStateChange.NetworkInterface(
                        eni_id=["eniId"],
                        subnet_id=["subnetId"]
                    ),
                    phases=[codebuild_events.CodeBuildBuildStateChange.AdditionalInformationItem(
                        duration_in_seconds=["durationInSeconds"],
                        end_time=["endTime"],
                        phase_context=["phaseContext"],
                        phase_status=["phaseStatus"],
                        phase_type=["phaseType"],
                        start_time=["startTime"]
                    )],
                    queued_timeout_in_minutes=["queuedTimeoutInMinutes"],
                    source=codebuild_events.CodeBuildBuildStateChange.Source(
                        auth=codebuild_events.CodeBuildBuildStateChange.Auth(
                            resource=["resource"],
                            type=["type"]
                        ),
                        buildspec=["buildspec"],
                        location=["location"],
                        type=["type"]
                    ),
                    source_version=["sourceVersion"],
                    timeout_in_minutes=["timeoutInMinutes"],
                    vpc_config=codebuild_events.CodeBuildBuildStateChange.VpcConfig(
                        security_group_ids=["securityGroupIds"],
                        subnets=[codebuild_events.CodeBuildBuildStateChange.VpcConfigItem(
                            build_fleet_az=["buildFleetAz"],
                            customer_az=["customerAz"],
                            subnet_id=["subnetId"]
                        )],
                        vpc_id=["vpcId"]
                    )
                )
            '''
            if isinstance(artifact, dict):
                artifact = CodeBuildBuildStateChange.Artifact(**artifact)
            if isinstance(cache, dict):
                cache = CodeBuildBuildStateChange.Cache(**cache)
            if isinstance(environment, dict):
                environment = CodeBuildBuildStateChange.Environment(**environment)
            if isinstance(logs, dict):
                logs = CodeBuildBuildStateChange.Logs(**logs)
            if isinstance(network_interface, dict):
                network_interface = CodeBuildBuildStateChange.NetworkInterface(**network_interface)
            if isinstance(source, dict):
                source = CodeBuildBuildStateChange.Source(**source)
            if isinstance(vpc_config, dict):
                vpc_config = CodeBuildBuildStateChange.VpcConfig(**vpc_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__67459f809720eed0d66aeaf29a617043d7d9c9dbc7af4ac77bf43892957acfd3)
                check_type(argname="argument artifact", value=artifact, expected_type=type_hints["artifact"])
                check_type(argname="argument build_complete", value=build_complete, expected_type=type_hints["build_complete"])
                check_type(argname="argument build_start_time", value=build_start_time, expected_type=type_hints["build_start_time"])
                check_type(argname="argument cache", value=cache, expected_type=type_hints["cache"])
                check_type(argname="argument environment", value=environment, expected_type=type_hints["environment"])
                check_type(argname="argument initiator", value=initiator, expected_type=type_hints["initiator"])
                check_type(argname="argument logs", value=logs, expected_type=type_hints["logs"])
                check_type(argname="argument network_interface", value=network_interface, expected_type=type_hints["network_interface"])
                check_type(argname="argument phases", value=phases, expected_type=type_hints["phases"])
                check_type(argname="argument queued_timeout_in_minutes", value=queued_timeout_in_minutes, expected_type=type_hints["queued_timeout_in_minutes"])
                check_type(argname="argument source", value=source, expected_type=type_hints["source"])
                check_type(argname="argument source_version", value=source_version, expected_type=type_hints["source_version"])
                check_type(argname="argument timeout_in_minutes", value=timeout_in_minutes, expected_type=type_hints["timeout_in_minutes"])
                check_type(argname="argument vpc_config", value=vpc_config, expected_type=type_hints["vpc_config"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if artifact is not None:
                self._values["artifact"] = artifact
            if build_complete is not None:
                self._values["build_complete"] = build_complete
            if build_start_time is not None:
                self._values["build_start_time"] = build_start_time
            if cache is not None:
                self._values["cache"] = cache
            if environment is not None:
                self._values["environment"] = environment
            if initiator is not None:
                self._values["initiator"] = initiator
            if logs is not None:
                self._values["logs"] = logs
            if network_interface is not None:
                self._values["network_interface"] = network_interface
            if phases is not None:
                self._values["phases"] = phases
            if queued_timeout_in_minutes is not None:
                self._values["queued_timeout_in_minutes"] = queued_timeout_in_minutes
            if source is not None:
                self._values["source"] = source
            if source_version is not None:
                self._values["source_version"] = source_version
            if timeout_in_minutes is not None:
                self._values["timeout_in_minutes"] = timeout_in_minutes
            if vpc_config is not None:
                self._values["vpc_config"] = vpc_config

        @builtins.property
        def artifact(self) -> typing.Optional["CodeBuildBuildStateChange.Artifact"]:
            '''(experimental) artifact property.

            Specify an array of string values to match this event if the actual value of artifact is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("artifact")
            return typing.cast(typing.Optional["CodeBuildBuildStateChange.Artifact"], result)

        @builtins.property
        def build_complete(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) build-complete property.

            Specify an array of string values to match this event if the actual value of build-complete is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("build_complete")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def build_start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) build-start-time property.

            Specify an array of string values to match this event if the actual value of build-start-time is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("build_start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def cache(self) -> typing.Optional["CodeBuildBuildStateChange.Cache"]:
            '''(experimental) cache property.

            Specify an array of string values to match this event if the actual value of cache is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cache")
            return typing.cast(typing.Optional["CodeBuildBuildStateChange.Cache"], result)

        @builtins.property
        def environment(
            self,
        ) -> typing.Optional["CodeBuildBuildStateChange.Environment"]:
            '''(experimental) environment property.

            Specify an array of string values to match this event if the actual value of environment is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("environment")
            return typing.cast(typing.Optional["CodeBuildBuildStateChange.Environment"], result)

        @builtins.property
        def initiator(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) initiator property.

            Specify an array of string values to match this event if the actual value of initiator is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("initiator")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def logs(self) -> typing.Optional["CodeBuildBuildStateChange.Logs"]:
            '''(experimental) logs property.

            Specify an array of string values to match this event if the actual value of logs is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("logs")
            return typing.cast(typing.Optional["CodeBuildBuildStateChange.Logs"], result)

        @builtins.property
        def network_interface(
            self,
        ) -> typing.Optional["CodeBuildBuildStateChange.NetworkInterface"]:
            '''(experimental) network-interface property.

            Specify an array of string values to match this event if the actual value of network-interface is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("network_interface")
            return typing.cast(typing.Optional["CodeBuildBuildStateChange.NetworkInterface"], result)

        @builtins.property
        def phases(
            self,
        ) -> typing.Optional[typing.List["CodeBuildBuildStateChange.AdditionalInformationItem"]]:
            '''(experimental) phases property.

            Specify an array of string values to match this event if the actual value of phases is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("phases")
            return typing.cast(typing.Optional[typing.List["CodeBuildBuildStateChange.AdditionalInformationItem"]], result)

        @builtins.property
        def queued_timeout_in_minutes(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) queued-timeout-in-minutes property.

            Specify an array of string values to match this event if the actual value of queued-timeout-in-minutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("queued_timeout_in_minutes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def source(self) -> typing.Optional["CodeBuildBuildStateChange.Source"]:
            '''(experimental) source property.

            Specify an array of string values to match this event if the actual value of source is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source")
            return typing.cast(typing.Optional["CodeBuildBuildStateChange.Source"], result)

        @builtins.property
        def source_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) source-version property.

            Specify an array of string values to match this event if the actual value of source-version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def timeout_in_minutes(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) timeout-in-minutes property.

            Specify an array of string values to match this event if the actual value of timeout-in-minutes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("timeout_in_minutes")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def vpc_config(self) -> typing.Optional["CodeBuildBuildStateChange.VpcConfig"]:
            '''(experimental) vpc-config property.

            Specify an array of string values to match this event if the actual value of vpc-config is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_config")
            return typing.cast(typing.Optional["CodeBuildBuildStateChange.VpcConfig"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AdditionalInformation(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.AdditionalInformationItem",
        jsii_struct_bases=[],
        name_mapping={
            "duration_in_seconds": "durationInSeconds",
            "end_time": "endTime",
            "phase_context": "phaseContext",
            "phase_status": "phaseStatus",
            "phase_type": "phaseType",
            "start_time": "startTime",
        },
    )
    class AdditionalInformationItem:
        def __init__(
            self,
            *,
            duration_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
            end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
            phase_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            phase_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Additional-informationItem.

            :param duration_in_seconds: (experimental) duration-in-seconds property. Specify an array of string values to match this event if the actual value of duration-in-seconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param end_time: (experimental) end-time property. Specify an array of string values to match this event if the actual value of end-time is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param phase_context: (experimental) phase-context property. Specify an array of string values to match this event if the actual value of phase-context is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param phase_status: (experimental) phase-status property. Specify an array of string values to match this event if the actual value of phase-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param phase_type: (experimental) phase-type property. Specify an array of string values to match this event if the actual value of phase-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) start-time property. Specify an array of string values to match this event if the actual value of start-time is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                additional_information_item = codebuild_events.CodeBuildBuildStateChange.AdditionalInformationItem(
                    duration_in_seconds=["durationInSeconds"],
                    end_time=["endTime"],
                    phase_context=["phaseContext"],
                    phase_status=["phaseStatus"],
                    phase_type=["phaseType"],
                    start_time=["startTime"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c2ba014748bc99c31d90defc40563c2830865d000cbb6d95f9e588ca09e38406)
                check_type(argname="argument duration_in_seconds", value=duration_in_seconds, expected_type=type_hints["duration_in_seconds"])
                check_type(argname="argument end_time", value=end_time, expected_type=type_hints["end_time"])
                check_type(argname="argument phase_context", value=phase_context, expected_type=type_hints["phase_context"])
                check_type(argname="argument phase_status", value=phase_status, expected_type=type_hints["phase_status"])
                check_type(argname="argument phase_type", value=phase_type, expected_type=type_hints["phase_type"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if duration_in_seconds is not None:
                self._values["duration_in_seconds"] = duration_in_seconds
            if end_time is not None:
                self._values["end_time"] = end_time
            if phase_context is not None:
                self._values["phase_context"] = phase_context
            if phase_status is not None:
                self._values["phase_status"] = phase_status
            if phase_type is not None:
                self._values["phase_type"] = phase_type
            if start_time is not None:
                self._values["start_time"] = start_time

        @builtins.property
        def duration_in_seconds(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) duration-in-seconds property.

            Specify an array of string values to match this event if the actual value of duration-in-seconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("duration_in_seconds")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) end-time property.

            Specify an array of string values to match this event if the actual value of end-time is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def phase_context(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) phase-context property.

            Specify an array of string values to match this event if the actual value of phase-context is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("phase_context")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def phase_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) phase-status property.

            Specify an array of string values to match this event if the actual value of phase-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("phase_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def phase_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) phase-type property.

            Specify an array of string values to match this event if the actual value of phase-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("phase_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) start-time property.

            Specify an array of string values to match this event if the actual value of start-time is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AdditionalInformationItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.Artifact",
        jsii_struct_bases=[],
        name_mapping={
            "location": "location",
            "md5_sum": "md5Sum",
            "sha256_sum": "sha256Sum",
        },
    )
    class Artifact:
        def __init__(
            self,
            *,
            location: typing.Optional[typing.Sequence[builtins.str]] = None,
            md5_sum: typing.Optional[typing.Sequence[builtins.str]] = None,
            sha256_sum: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Artifact.

            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param md5_sum: (experimental) md5sum property. Specify an array of string values to match this event if the actual value of md5sum is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param sha256_sum: (experimental) sha256sum property. Specify an array of string values to match this event if the actual value of sha256sum is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                artifact = codebuild_events.CodeBuildBuildStateChange.Artifact(
                    location=["location"],
                    md5_sum=["md5Sum"],
                    sha256_sum=["sha256Sum"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e749067f706e3cb6e2d38dc29cab64e0c06e9c5c247dcf57c7051e4b11644c54)
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
                check_type(argname="argument md5_sum", value=md5_sum, expected_type=type_hints["md5_sum"])
                check_type(argname="argument sha256_sum", value=sha256_sum, expected_type=type_hints["sha256_sum"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if location is not None:
                self._values["location"] = location
            if md5_sum is not None:
                self._values["md5_sum"] = md5_sum
            if sha256_sum is not None:
                self._values["sha256_sum"] = sha256_sum

        @builtins.property
        def location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def md5_sum(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) md5sum property.

            Specify an array of string values to match this event if the actual value of md5sum is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("md5_sum")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def sha256_sum(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sha256sum property.

            Specify an array of string values to match this event if the actual value of sha256sum is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("sha256_sum")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Artifact(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.Auth",
        jsii_struct_bases=[],
        name_mapping={"resource": "resource", "type": "type"},
    )
    class Auth:
        def __init__(
            self,
            *,
            resource: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Auth.

            :param resource: (experimental) resource property. Specify an array of string values to match this event if the actual value of resource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                auth = codebuild_events.CodeBuildBuildStateChange.Auth(
                    resource=["resource"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6a5649a553313456b3b9c2af56376b59ce0dffc15a8c06bef13434ac10a8d01c)
                check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if resource is not None:
                self._values["resource"] = resource
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def resource(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) resource property.

            Specify an array of string values to match this event if the actual value of resource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Auth(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.Cache",
        jsii_struct_bases=[],
        name_mapping={"location": "location", "type": "type"},
    )
    class Cache:
        def __init__(
            self,
            *,
            location: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Cache.

            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                cache = codebuild_events.CodeBuildBuildStateChange.Cache(
                    location=["location"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__50827c94b1d2017f7e8873748d79e7f52471f5ac65ffbab4aa6874921f90a2f3)
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if location is not None:
                self._values["location"] = location
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Cache(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.CodeBuildBuildStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "additional_information": "additionalInformation",
            "build_id": "buildId",
            "build_status": "buildStatus",
            "current_phase": "currentPhase",
            "current_phase_context": "currentPhaseContext",
            "event_metadata": "eventMetadata",
            "project_name": "projectName",
            "version": "version",
        },
    )
    class CodeBuildBuildStateChangeProps:
        def __init__(
            self,
            *,
            additional_information: typing.Optional[typing.Union["CodeBuildBuildStateChange.AdditionalInformation", typing.Dict[builtins.str, typing.Any]]] = None,
            build_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            build_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            current_phase: typing.Optional[typing.Sequence[builtins.str]] = None,
            current_phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            project_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.codebuild@CodeBuildBuildStateChange event.

            :param additional_information: (experimental) additional-information property. Specify an array of string values to match this event if the actual value of additional-information is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param build_id: (experimental) build-id property. Specify an array of string values to match this event if the actual value of build-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param build_status: (experimental) build-status property. Specify an array of string values to match this event if the actual value of build-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param current_phase: (experimental) current-phase property. Specify an array of string values to match this event if the actual value of current-phase is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param current_phase_context: (experimental) current-phase-context property. Specify an array of string values to match this event if the actual value of current-phase-context is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param project_name: (experimental) project-name property. Specify an array of string values to match this event if the actual value of project-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Project reference
            :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                code_build_build_state_change_props = codebuild_events.CodeBuildBuildStateChange.CodeBuildBuildStateChangeProps(
                    additional_information=codebuild_events.CodeBuildBuildStateChange.AdditionalInformation(
                        artifact=codebuild_events.CodeBuildBuildStateChange.Artifact(
                            location=["location"],
                            md5_sum=["md5Sum"],
                            sha256_sum=["sha256Sum"]
                        ),
                        build_complete=["buildComplete"],
                        build_start_time=["buildStartTime"],
                        cache=codebuild_events.CodeBuildBuildStateChange.Cache(
                            location=["location"],
                            type=["type"]
                        ),
                        environment=codebuild_events.CodeBuildBuildStateChange.Environment(
                            compute_type=["computeType"],
                            environment_variables=[codebuild_events.CodeBuildBuildStateChange.EnvironmentItem(
                                name=["name"],
                                type=["type"],
                                value=["value"]
                            )],
                            image=["image"],
                            image_pull_credentials_type=["imagePullCredentialsType"],
                            privileged_mode=["privilegedMode"],
                            type=["type"]
                        ),
                        initiator=["initiator"],
                        logs=codebuild_events.CodeBuildBuildStateChange.Logs(
                            deep_link=["deepLink"],
                            group_name=["groupName"],
                            stream_name=["streamName"]
                        ),
                        network_interface=codebuild_events.CodeBuildBuildStateChange.NetworkInterface(
                            eni_id=["eniId"],
                            subnet_id=["subnetId"]
                        ),
                        phases=[codebuild_events.CodeBuildBuildStateChange.AdditionalInformationItem(
                            duration_in_seconds=["durationInSeconds"],
                            end_time=["endTime"],
                            phase_context=["phaseContext"],
                            phase_status=["phaseStatus"],
                            phase_type=["phaseType"],
                            start_time=["startTime"]
                        )],
                        queued_timeout_in_minutes=["queuedTimeoutInMinutes"],
                        source=codebuild_events.CodeBuildBuildStateChange.Source(
                            auth=codebuild_events.CodeBuildBuildStateChange.Auth(
                                resource=["resource"],
                                type=["type"]
                            ),
                            buildspec=["buildspec"],
                            location=["location"],
                            type=["type"]
                        ),
                        source_version=["sourceVersion"],
                        timeout_in_minutes=["timeoutInMinutes"],
                        vpc_config=codebuild_events.CodeBuildBuildStateChange.VpcConfig(
                            security_group_ids=["securityGroupIds"],
                            subnets=[codebuild_events.CodeBuildBuildStateChange.VpcConfigItem(
                                build_fleet_az=["buildFleetAz"],
                                customer_az=["customerAz"],
                                subnet_id=["subnetId"]
                            )],
                            vpc_id=["vpcId"]
                        )
                    ),
                    build_id=["buildId"],
                    build_status=["buildStatus"],
                    current_phase=["currentPhase"],
                    current_phase_context=["currentPhaseContext"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    project_name=["projectName"],
                    version=["version"]
                )
            '''
            if isinstance(additional_information, dict):
                additional_information = CodeBuildBuildStateChange.AdditionalInformation(**additional_information)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__86192eb57ed69210100a89c273e97a706168aeedb7a2cc1d88f874427fe0ac2f)
                check_type(argname="argument additional_information", value=additional_information, expected_type=type_hints["additional_information"])
                check_type(argname="argument build_id", value=build_id, expected_type=type_hints["build_id"])
                check_type(argname="argument build_status", value=build_status, expected_type=type_hints["build_status"])
                check_type(argname="argument current_phase", value=current_phase, expected_type=type_hints["current_phase"])
                check_type(argname="argument current_phase_context", value=current_phase_context, expected_type=type_hints["current_phase_context"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument project_name", value=project_name, expected_type=type_hints["project_name"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if additional_information is not None:
                self._values["additional_information"] = additional_information
            if build_id is not None:
                self._values["build_id"] = build_id
            if build_status is not None:
                self._values["build_status"] = build_status
            if current_phase is not None:
                self._values["current_phase"] = current_phase
            if current_phase_context is not None:
                self._values["current_phase_context"] = current_phase_context
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if project_name is not None:
                self._values["project_name"] = project_name
            if version is not None:
                self._values["version"] = version

        @builtins.property
        def additional_information(
            self,
        ) -> typing.Optional["CodeBuildBuildStateChange.AdditionalInformation"]:
            '''(experimental) additional-information property.

            Specify an array of string values to match this event if the actual value of additional-information is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("additional_information")
            return typing.cast(typing.Optional["CodeBuildBuildStateChange.AdditionalInformation"], result)

        @builtins.property
        def build_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) build-id property.

            Specify an array of string values to match this event if the actual value of build-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("build_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def build_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) build-status property.

            Specify an array of string values to match this event if the actual value of build-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("build_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def current_phase(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) current-phase property.

            Specify an array of string values to match this event if the actual value of current-phase is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_phase")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def current_phase_context(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) current-phase-context property.

            Specify an array of string values to match this event if the actual value of current-phase-context is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_phase_context")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def project_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) project-name property.

            Specify an array of string values to match this event if the actual value of project-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the Project reference

            :stability: experimental
            '''
            result = self._values.get("project_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version property.

            Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CodeBuildBuildStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.Environment",
        jsii_struct_bases=[],
        name_mapping={
            "compute_type": "computeType",
            "environment_variables": "environmentVariables",
            "image": "image",
            "image_pull_credentials_type": "imagePullCredentialsType",
            "privileged_mode": "privilegedMode",
            "type": "type",
        },
    )
    class Environment:
        def __init__(
            self,
            *,
            compute_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            environment_variables: typing.Optional[typing.Sequence[typing.Union["CodeBuildBuildStateChange.EnvironmentItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            image: typing.Optional[typing.Sequence[builtins.str]] = None,
            image_pull_credentials_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            privileged_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Environment.

            :param compute_type: (experimental) compute-type property. Specify an array of string values to match this event if the actual value of compute-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param environment_variables: (experimental) environment-variables property. Specify an array of string values to match this event if the actual value of environment-variables is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image: (experimental) image property. Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image_pull_credentials_type: (experimental) image-pull-credentials-type property. Specify an array of string values to match this event if the actual value of image-pull-credentials-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param privileged_mode: (experimental) privileged-mode property. Specify an array of string values to match this event if the actual value of privileged-mode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                environment = codebuild_events.CodeBuildBuildStateChange.Environment(
                    compute_type=["computeType"],
                    environment_variables=[codebuild_events.CodeBuildBuildStateChange.EnvironmentItem(
                        name=["name"],
                        type=["type"],
                        value=["value"]
                    )],
                    image=["image"],
                    image_pull_credentials_type=["imagePullCredentialsType"],
                    privileged_mode=["privilegedMode"],
                    type=["type"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6fb3583bd3718d0daca33c914b963fdd8a5561bf9461a8d465f16a02044b03de)
                check_type(argname="argument compute_type", value=compute_type, expected_type=type_hints["compute_type"])
                check_type(argname="argument environment_variables", value=environment_variables, expected_type=type_hints["environment_variables"])
                check_type(argname="argument image", value=image, expected_type=type_hints["image"])
                check_type(argname="argument image_pull_credentials_type", value=image_pull_credentials_type, expected_type=type_hints["image_pull_credentials_type"])
                check_type(argname="argument privileged_mode", value=privileged_mode, expected_type=type_hints["privileged_mode"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if compute_type is not None:
                self._values["compute_type"] = compute_type
            if environment_variables is not None:
                self._values["environment_variables"] = environment_variables
            if image is not None:
                self._values["image"] = image
            if image_pull_credentials_type is not None:
                self._values["image_pull_credentials_type"] = image_pull_credentials_type
            if privileged_mode is not None:
                self._values["privileged_mode"] = privileged_mode
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def compute_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) compute-type property.

            Specify an array of string values to match this event if the actual value of compute-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("compute_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def environment_variables(
            self,
        ) -> typing.Optional[typing.List["CodeBuildBuildStateChange.EnvironmentItem"]]:
            '''(experimental) environment-variables property.

            Specify an array of string values to match this event if the actual value of environment-variables is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("environment_variables")
            return typing.cast(typing.Optional[typing.List["CodeBuildBuildStateChange.EnvironmentItem"]], result)

        @builtins.property
        def image(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) image property.

            Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image_pull_credentials_type(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) image-pull-credentials-type property.

            Specify an array of string values to match this event if the actual value of image-pull-credentials-type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image_pull_credentials_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def privileged_mode(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) privileged-mode property.

            Specify an array of string values to match this event if the actual value of privileged-mode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("privileged_mode")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Environment(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.EnvironmentItem",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "type": "type", "value": "value"},
    )
    class EnvironmentItem:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for EnvironmentItem.

            :param name: (experimental) name property. Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) value property. Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                environment_item = codebuild_events.CodeBuildBuildStateChange.EnvironmentItem(
                    name=["name"],
                    type=["type"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f6462e8a65278a564fe0823191bd28fd034ebcb80ab9c6b95353ef724a89dbcf)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if type is not None:
                self._values["type"] = type
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) name property.

            Specify an array of string values to match this event if the actual value of name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) value property.

            Specify an array of string values to match this event if the actual value of value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "EnvironmentItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.Logs",
        jsii_struct_bases=[],
        name_mapping={
            "deep_link": "deepLink",
            "group_name": "groupName",
            "stream_name": "streamName",
        },
    )
    class Logs:
        def __init__(
            self,
            *,
            deep_link: typing.Optional[typing.Sequence[builtins.str]] = None,
            group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            stream_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Logs.

            :param deep_link: (experimental) deep-link property. Specify an array of string values to match this event if the actual value of deep-link is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param group_name: (experimental) group-name property. Specify an array of string values to match this event if the actual value of group-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stream_name: (experimental) stream-name property. Specify an array of string values to match this event if the actual value of stream-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                logs = codebuild_events.CodeBuildBuildStateChange.Logs(
                    deep_link=["deepLink"],
                    group_name=["groupName"],
                    stream_name=["streamName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4a3e32a53a6a3453beaf8514408029c6eccd15ed4031d8512402198d5f6e1019)
                check_type(argname="argument deep_link", value=deep_link, expected_type=type_hints["deep_link"])
                check_type(argname="argument group_name", value=group_name, expected_type=type_hints["group_name"])
                check_type(argname="argument stream_name", value=stream_name, expected_type=type_hints["stream_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if deep_link is not None:
                self._values["deep_link"] = deep_link
            if group_name is not None:
                self._values["group_name"] = group_name
            if stream_name is not None:
                self._values["stream_name"] = stream_name

        @builtins.property
        def deep_link(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) deep-link property.

            Specify an array of string values to match this event if the actual value of deep-link is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("deep_link")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def group_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) group-name property.

            Specify an array of string values to match this event if the actual value of group-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("group_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stream_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stream-name property.

            Specify an array of string values to match this event if the actual value of stream-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stream_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Logs(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.NetworkInterface",
        jsii_struct_bases=[],
        name_mapping={"eni_id": "eniId", "subnet_id": "subnetId"},
    )
    class NetworkInterface:
        def __init__(
            self,
            *,
            eni_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Network-interface.

            :param eni_id: (experimental) eni-id property. Specify an array of string values to match this event if the actual value of eni-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) subnet-id property. Specify an array of string values to match this event if the actual value of subnet-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                network_interface = codebuild_events.CodeBuildBuildStateChange.NetworkInterface(
                    eni_id=["eniId"],
                    subnet_id=["subnetId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d5c05e75715545294cacb2b5bae05faa12c54ee113907e3b33b0c7332d8c1467)
                check_type(argname="argument eni_id", value=eni_id, expected_type=type_hints["eni_id"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if eni_id is not None:
                self._values["eni_id"] = eni_id
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id

        @builtins.property
        def eni_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eni-id property.

            Specify an array of string values to match this event if the actual value of eni-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("eni_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) subnet-id property.

            Specify an array of string values to match this event if the actual value of subnet-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "NetworkInterface(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.Source",
        jsii_struct_bases=[],
        name_mapping={
            "auth": "auth",
            "buildspec": "buildspec",
            "location": "location",
            "type": "type",
        },
    )
    class Source:
        def __init__(
            self,
            *,
            auth: typing.Optional[typing.Union["CodeBuildBuildStateChange.Auth", typing.Dict[builtins.str, typing.Any]]] = None,
            buildspec: typing.Optional[typing.Sequence[builtins.str]] = None,
            location: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Source.

            :param auth: (experimental) auth property. Specify an array of string values to match this event if the actual value of auth is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param buildspec: (experimental) buildspec property. Specify an array of string values to match this event if the actual value of buildspec is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param location: (experimental) location property. Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                source = codebuild_events.CodeBuildBuildStateChange.Source(
                    auth=codebuild_events.CodeBuildBuildStateChange.Auth(
                        resource=["resource"],
                        type=["type"]
                    ),
                    buildspec=["buildspec"],
                    location=["location"],
                    type=["type"]
                )
            '''
            if isinstance(auth, dict):
                auth = CodeBuildBuildStateChange.Auth(**auth)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__271fe5b1288398df4ad413ba4ea8f3c5ad4808d40f000d518816c589ca5b57ca)
                check_type(argname="argument auth", value=auth, expected_type=type_hints["auth"])
                check_type(argname="argument buildspec", value=buildspec, expected_type=type_hints["buildspec"])
                check_type(argname="argument location", value=location, expected_type=type_hints["location"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if auth is not None:
                self._values["auth"] = auth
            if buildspec is not None:
                self._values["buildspec"] = buildspec
            if location is not None:
                self._values["location"] = location
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def auth(self) -> typing.Optional["CodeBuildBuildStateChange.Auth"]:
            '''(experimental) auth property.

            Specify an array of string values to match this event if the actual value of auth is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("auth")
            return typing.cast(typing.Optional["CodeBuildBuildStateChange.Auth"], result)

        @builtins.property
        def buildspec(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) buildspec property.

            Specify an array of string values to match this event if the actual value of buildspec is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("buildspec")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def location(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) location property.

            Specify an array of string values to match this event if the actual value of location is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("location")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Source(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.VpcConfig",
        jsii_struct_bases=[],
        name_mapping={
            "security_group_ids": "securityGroupIds",
            "subnets": "subnets",
            "vpc_id": "vpcId",
        },
    )
    class VpcConfig:
        def __init__(
            self,
            *,
            security_group_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnets: typing.Optional[typing.Sequence[typing.Union["CodeBuildBuildStateChange.VpcConfigItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Vpc-config.

            :param security_group_ids: (experimental) security-group-ids property. Specify an array of string values to match this event if the actual value of security-group-ids is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnets: (experimental) subnets property. Specify an array of string values to match this event if the actual value of subnets is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_id: (experimental) vpc-id property. Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                vpc_config = codebuild_events.CodeBuildBuildStateChange.VpcConfig(
                    security_group_ids=["securityGroupIds"],
                    subnets=[codebuild_events.CodeBuildBuildStateChange.VpcConfigItem(
                        build_fleet_az=["buildFleetAz"],
                        customer_az=["customerAz"],
                        subnet_id=["subnetId"]
                    )],
                    vpc_id=["vpcId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fd255fdab961049952435cbfaa637f5676b4c85d0acb86db59365cf73a10152b)
                check_type(argname="argument security_group_ids", value=security_group_ids, expected_type=type_hints["security_group_ids"])
                check_type(argname="argument subnets", value=subnets, expected_type=type_hints["subnets"])
                check_type(argname="argument vpc_id", value=vpc_id, expected_type=type_hints["vpc_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if security_group_ids is not None:
                self._values["security_group_ids"] = security_group_ids
            if subnets is not None:
                self._values["subnets"] = subnets
            if vpc_id is not None:
                self._values["vpc_id"] = vpc_id

        @builtins.property
        def security_group_ids(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) security-group-ids property.

            Specify an array of string values to match this event if the actual value of security-group-ids is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("security_group_ids")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnets(
            self,
        ) -> typing.Optional[typing.List["CodeBuildBuildStateChange.VpcConfigItem"]]:
            '''(experimental) subnets property.

            Specify an array of string values to match this event if the actual value of subnets is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnets")
            return typing.cast(typing.Optional[typing.List["CodeBuildBuildStateChange.VpcConfigItem"]], result)

        @builtins.property
        def vpc_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) vpc-id property.

            Specify an array of string values to match this event if the actual value of vpc-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VpcConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.CodeBuildBuildStateChange.VpcConfigItem",
        jsii_struct_bases=[],
        name_mapping={
            "build_fleet_az": "buildFleetAz",
            "customer_az": "customerAz",
            "subnet_id": "subnetId",
        },
    )
    class VpcConfigItem:
        def __init__(
            self,
            *,
            build_fleet_az: typing.Optional[typing.Sequence[builtins.str]] = None,
            customer_az: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Vpc-configItem.

            :param build_fleet_az: (experimental) build-fleet-az property. Specify an array of string values to match this event if the actual value of build-fleet-az is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param customer_az: (experimental) customer-az property. Specify an array of string values to match this event if the actual value of customer-az is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnet_id: (experimental) subnet-id property. Specify an array of string values to match this event if the actual value of subnet-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
                
                vpc_config_item = codebuild_events.CodeBuildBuildStateChange.VpcConfigItem(
                    build_fleet_az=["buildFleetAz"],
                    customer_az=["customerAz"],
                    subnet_id=["subnetId"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__40ac92130303c440608218b1abb03a961fbd8c89b3c50f068b930bcf3c002c19)
                check_type(argname="argument build_fleet_az", value=build_fleet_az, expected_type=type_hints["build_fleet_az"])
                check_type(argname="argument customer_az", value=customer_az, expected_type=type_hints["customer_az"])
                check_type(argname="argument subnet_id", value=subnet_id, expected_type=type_hints["subnet_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if build_fleet_az is not None:
                self._values["build_fleet_az"] = build_fleet_az
            if customer_az is not None:
                self._values["customer_az"] = customer_az
            if subnet_id is not None:
                self._values["subnet_id"] = subnet_id

        @builtins.property
        def build_fleet_az(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) build-fleet-az property.

            Specify an array of string values to match this event if the actual value of build-fleet-az is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("build_fleet_az")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def customer_az(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) customer-az property.

            Specify an array of string values to match this event if the actual value of customer-az is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("customer_az")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnet_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) subnet-id property.

            Specify an array of string values to match this event if the actual value of subnet-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnet_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VpcConfigItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class ProjectEvents(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_codebuild.events.ProjectEvents",
):
    '''(experimental) EventBridge event patterns for Project.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_codebuild import events as codebuild_events
        from aws_cdk.interfaces import aws_codebuild as interfaces_codebuild
        
        # project_ref: interfaces_codebuild.IProjectRef
        
        project_events = codebuild_events.ProjectEvents.from_project(project_ref)
    '''

    @jsii.member(jsii_name="fromProject")
    @builtins.classmethod
    def from_project(
        cls,
        project_ref: "_aws_cdk_interfaces_aws_codebuild_ceddda9d.IProjectRef",
    ) -> "ProjectEvents":
        '''(experimental) Create ProjectEvents from a Project reference.

        :param project_ref: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__db4d32fb7791ee1d99407b942179cc160a485c3efe1a1bf3d6c836e1b2638ff0)
            check_type(argname="argument project_ref", value=project_ref, expected_type=type_hints["project_ref"])
        return typing.cast("ProjectEvents", jsii.sinvoke(cls, "fromProject", [project_ref]))

    @jsii.member(jsii_name="codeBuildBuildPhaseChangePattern")
    def code_build_build_phase_change_pattern(
        self,
        *,
        additional_information: typing.Optional[typing.Union["CodeBuildBuildPhaseChange.AdditionalInformation", typing.Dict[builtins.str, typing.Any]]] = None,
        build_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        completed_phase: typing.Optional[typing.Sequence[builtins.str]] = None,
        completed_phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
        completed_phase_duration_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
        completed_phase_end: typing.Optional[typing.Sequence[builtins.str]] = None,
        completed_phase_start: typing.Optional[typing.Sequence[builtins.str]] = None,
        completed_phase_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        project_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Project CodeBuild Build Phase Change.

        :param additional_information: (experimental) additional-information property. Specify an array of string values to match this event if the actual value of additional-information is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param build_id: (experimental) build-id property. Specify an array of string values to match this event if the actual value of build-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param completed_phase: (experimental) completed-phase property. Specify an array of string values to match this event if the actual value of completed-phase is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param completed_phase_context: (experimental) completed-phase-context property. Specify an array of string values to match this event if the actual value of completed-phase-context is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param completed_phase_duration_seconds: (experimental) completed-phase-duration-seconds property. Specify an array of string values to match this event if the actual value of completed-phase-duration-seconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param completed_phase_end: (experimental) completed-phase-end property. Specify an array of string values to match this event if the actual value of completed-phase-end is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param completed_phase_start: (experimental) completed-phase-start property. Specify an array of string values to match this event if the actual value of completed-phase-start is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param completed_phase_status: (experimental) completed-phase-status property. Specify an array of string values to match this event if the actual value of completed-phase-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param project_name: (experimental) project-name property. Specify an array of string values to match this event if the actual value of project-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Project reference
        :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeBuildBuildPhaseChange.CodeBuildBuildPhaseChangeProps(
            additional_information=additional_information,
            build_id=build_id,
            completed_phase=completed_phase,
            completed_phase_context=completed_phase_context,
            completed_phase_duration_seconds=completed_phase_duration_seconds,
            completed_phase_end=completed_phase_end,
            completed_phase_start=completed_phase_start,
            completed_phase_status=completed_phase_status,
            event_metadata=event_metadata,
            project_name=project_name,
            version=version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "codeBuildBuildPhaseChangePattern", [options]))

    @jsii.member(jsii_name="codeBuildBuildStateChangePattern")
    def code_build_build_state_change_pattern(
        self,
        *,
        additional_information: typing.Optional[typing.Union["CodeBuildBuildStateChange.AdditionalInformation", typing.Dict[builtins.str, typing.Any]]] = None,
        build_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        build_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        current_phase: typing.Optional[typing.Sequence[builtins.str]] = None,
        current_phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        project_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        version: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Project CodeBuild Build State Change.

        :param additional_information: (experimental) additional-information property. Specify an array of string values to match this event if the actual value of additional-information is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param build_id: (experimental) build-id property. Specify an array of string values to match this event if the actual value of build-id is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param build_status: (experimental) build-status property. Specify an array of string values to match this event if the actual value of build-status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param current_phase: (experimental) current-phase property. Specify an array of string values to match this event if the actual value of current-phase is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param current_phase_context: (experimental) current-phase-context property. Specify an array of string values to match this event if the actual value of current-phase-context is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param project_name: (experimental) project-name property. Specify an array of string values to match this event if the actual value of project-name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the Project reference
        :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = CodeBuildBuildStateChange.CodeBuildBuildStateChangeProps(
            additional_information=additional_information,
            build_id=build_id,
            build_status=build_status,
            current_phase=current_phase,
            current_phase_context=current_phase_context,
            event_metadata=event_metadata,
            project_name=project_name,
            version=version,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "codeBuildBuildStateChangePattern", [options]))


__all__ = [
    "AWSAPICallViaCloudTrail",
    "AWSServiceEventViaCloudTrail",
    "CodeBuildBuildPhaseChange",
    "CodeBuildBuildStateChange",
    "ProjectEvents",
]

publication.publish()

def _typecheckingstub__fa552bdf4a36229f5517550b44d72498cd203aa0ad6be6bd1b83a88613991b92(
    *,
    aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_parameters: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.RequestParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    response_elements: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ResponseElements, typing.Dict[builtins.str, typing.Any]]] = None,
    source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_identity: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.UserIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__809250864e736be36bc032a9f237864ef531bd9dbb88c9551337b4e507759862(
    *,
    encryption_disabled: typing.Optional[typing.Sequence[builtins.str]] = None,
    location: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eeee42334e0f209fa9132b9ebeff56ef6f845a565bc511b572f12777cdba76cd(
    *,
    encryption_disabled: typing.Optional[typing.Sequence[builtins.str]] = None,
    location: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    namespace_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    packaging: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f007912bddd55b8d4f1eb42780f74513b0ac9b09c2bd982beb035adc29823934(
    *,
    creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dd3d68d027f06f272acbca3ded2d62027f5d222d778ec2ee5c7cafdee1ef6b67(
    *,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__48addcf0053c18cc44093d2eef8a71fd3ec206b5d149210d769ed6eaf5d2b7fc(
    *,
    badge_enabled: typing.Optional[typing.Sequence[builtins.str]] = None,
    badge_request_url: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5906d999b3c1d1f6ff4241f12e5cc946cb7f852c2242393d128b2bb5850f8535(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    artifacts: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Artifacts, typing.Dict[builtins.str, typing.Any]]] = None,
    build_complete: typing.Optional[typing.Sequence[builtins.str]] = None,
    build_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    cache: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Cache, typing.Dict[builtins.str, typing.Any]]] = None,
    current_phase: typing.Optional[typing.Sequence[builtins.str]] = None,
    encryption_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    environment: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Environment, typing.Dict[builtins.str, typing.Any]]] = None,
    id: typing.Optional[typing.Sequence[builtins.str]] = None,
    initiator: typing.Optional[typing.Sequence[builtins.str]] = None,
    logs: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Logs, typing.Dict[builtins.str, typing.Any]]] = None,
    phases: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.BuildPhase, typing.Dict[builtins.str, typing.Any]]]] = None,
    project_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    queued_timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
    resolved_source_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    service_role: typing.Optional[typing.Sequence[builtins.str]] = None,
    source: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Source, typing.Dict[builtins.str, typing.Any]]] = None,
    source_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
    vpc_config: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.VpcConfig, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__25e36d0fb822e106e44351a88353df9b168ba8727f5fb0cbc3010ff35c7adf82(
    *,
    duration_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
    phase_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    phase_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2262676acd7d373259a29888bfbdcd6fc7ee627164d6c539319281ed9ec2ea3b(
    *,
    location: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__498076640bdb8b46a9685ecf59eb6fad17e7ef74dedd3c3c68f9fb6cf9aa1e32(
    *,
    certificate: typing.Optional[typing.Sequence[builtins.str]] = None,
    compute_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    environment_variables: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.EnvironmentItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    image: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_pull_credentials_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    privileged_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__33f36e010253466c2f2ab9e638daf345203d86f240c8513a5f04a8e51b405d3c(
    *,
    compute_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    environment_variables: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.EnvironmentItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    image: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_pull_credentials_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    privileged_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6f1bcc86793afdd06ce8df175071a34de20ea98a1082e05b9031188a89688c71(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ef72df77053484e3666f1952181072bc344ae8cd288a9944b251de73235edf43(
    *,
    fetch_submodules: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7fac08a13ab69759baceb5afb86f210107add618a188ee0853dfe914def84f6f(
    *,
    deep_link: typing.Optional[typing.Sequence[builtins.str]] = None,
    group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    stream_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f19fa55f09f47a96e42d63345c80ba94c66150a26d65fb5ea54bfd9b1bbfb2a0(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    artifacts: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Artifacts1, typing.Dict[builtins.str, typing.Any]]] = None,
    badge: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Badge, typing.Dict[builtins.str, typing.Any]]] = None,
    cache: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Cache, typing.Dict[builtins.str, typing.Any]]] = None,
    created: typing.Optional[typing.Sequence[builtins.str]] = None,
    description: typing.Optional[typing.Sequence[builtins.str]] = None,
    encryption_key: typing.Optional[typing.Sequence[builtins.str]] = None,
    environment: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Environment1, typing.Dict[builtins.str, typing.Any]]] = None,
    last_modified: typing.Optional[typing.Sequence[builtins.str]] = None,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    queued_timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
    service_role: typing.Optional[typing.Sequence[builtins.str]] = None,
    source: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Source1, typing.Dict[builtins.str, typing.Any]]] = None,
    source_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.ProjectItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e9bf24df1bd3ee125c77ea4e0616682b24425fa7d74822297d4a7c2a9f951492(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0cb89d4e023ad9c7af3f9ab7838a7f436fab1845c04f1b2cc958c3362f72295a(
    *,
    aws_act_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
    payer_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1474fe577386c0c7ddf70c96ea4fda8c8609132d95111fc80e6a04ebe632a44f(
    *,
    build_property: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Build, typing.Dict[builtins.str, typing.Any]]] = None,
    message: typing.Optional[typing.Sequence[builtins.str]] = None,
    project: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Project, typing.Dict[builtins.str, typing.Any]]] = None,
    webhook: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Webhook, typing.Dict[builtins.str, typing.Any]]] = None,
    webhook_deleted_status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__95f4144ad226879ea814952e59f0c055041b0c64974c09d7a4f5998b9e6e370c(
    *,
    attributes: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    session_issuer: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionIssuer, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f16f9a763459b6ce0aa68580e9e7fe4fa0f867ec2c9238a9cf3a736d49a884ed(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__819726a70a22f2684d1aaf1ebea2138a1ce88866e19fb21c843096bab701f12c(
    *,
    auth: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Auth, typing.Dict[builtins.str, typing.Any]]] = None,
    buildspec: typing.Optional[typing.Sequence[builtins.str]] = None,
    insecure_ssl: typing.Optional[typing.Sequence[builtins.str]] = None,
    location: typing.Optional[typing.Sequence[builtins.str]] = None,
    report_build_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4c7bca3b44409d55d88429819e8855294e7fc8ead97891566dac74dc9d577903(
    *,
    auth: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Auth, typing.Dict[builtins.str, typing.Any]]] = None,
    buildspec: typing.Optional[typing.Sequence[builtins.str]] = None,
    git_clone_depth: typing.Optional[typing.Sequence[builtins.str]] = None,
    git_submodules_config: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.GitSubmodulesConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    insecure_ssl: typing.Optional[typing.Sequence[builtins.str]] = None,
    location: typing.Optional[typing.Sequence[builtins.str]] = None,
    report_build_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a07981bb802ac53a07f60a9e2d7805266cf6fe2304a78680ee7d43a893740dd(
    *,
    access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_context: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionContext, typing.Dict[builtins.str, typing.Any]]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__028fe7c10241e269cb21a425e0933df7c012e5227fa0d9be2ce6bb325fdff9d3(
    *,
    security_group_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnets: typing.Optional[typing.Sequence[builtins.str]] = None,
    vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__74f1b615326c7391c7ce1c45d52ed6cea9478e732ee32bc28ebe589b678fd71a(
    *,
    branch_filter: typing.Optional[typing.Sequence[builtins.str]] = None,
    last_modified_secret: typing.Optional[typing.Sequence[builtins.str]] = None,
    payload_url: typing.Optional[typing.Sequence[builtins.str]] = None,
    url: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__13b857d2471f6acc838e3c503edd5f3aba3e9f0c1b4177b5dc766a2616670628(
    *,
    aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    read_only: typing.Optional[typing.Sequence[builtins.str]] = None,
    service_event_details: typing.Optional[typing.Union[AWSServiceEventViaCloudTrail.ServiceEventDetails, typing.Dict[builtins.str, typing.Any]]] = None,
    source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_identity: typing.Optional[typing.Union[AWSServiceEventViaCloudTrail.UserIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__da1ea30d66ed2c33304a1a018f92cc98070d1308a63349dc2454b5a9dda259d0(
    *,
    response: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d11ff3abd42f8c1461d1d7b9ddceea3eee13bd7799952d8efa2b62bf2c88c9da(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9b7efde68fd58ae12013758ec71552ddcc88e89fd5c16e5f9b19d594ce311362(
    *,
    artifact: typing.Optional[typing.Union[CodeBuildBuildPhaseChange.Artifact, typing.Dict[builtins.str, typing.Any]]] = None,
    build_complete: typing.Optional[typing.Sequence[builtins.str]] = None,
    build_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    cache: typing.Optional[typing.Union[CodeBuildBuildPhaseChange.Cache, typing.Dict[builtins.str, typing.Any]]] = None,
    environment: typing.Optional[typing.Union[CodeBuildBuildPhaseChange.Environment, typing.Dict[builtins.str, typing.Any]]] = None,
    initiator: typing.Optional[typing.Sequence[builtins.str]] = None,
    logs: typing.Optional[typing.Union[CodeBuildBuildPhaseChange.Logs, typing.Dict[builtins.str, typing.Any]]] = None,
    network_interface: typing.Optional[typing.Union[CodeBuildBuildPhaseChange.NetworkInterface, typing.Dict[builtins.str, typing.Any]]] = None,
    phases: typing.Optional[typing.Sequence[typing.Union[CodeBuildBuildPhaseChange.AdditionalInformationItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    queued_timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
    source: typing.Optional[typing.Union[CodeBuildBuildPhaseChange.Source, typing.Dict[builtins.str, typing.Any]]] = None,
    source_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
    vpc_config: typing.Optional[typing.Union[CodeBuildBuildPhaseChange.VpcConfig, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4febbe4795c393f35ed64635987d8dbb9a00df11f2cbd72e522a4423b0661fcf(
    *,
    duration_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
    phase_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    phase_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e3af66b4ebaa434a62f73b6251553a79242e39363bb84210c25a2a7e7022167e(
    *,
    location: typing.Optional[typing.Sequence[builtins.str]] = None,
    md5_sum: typing.Optional[typing.Sequence[builtins.str]] = None,
    sha256_sum: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__27d9d008470c867d21fd5d4973a24bcd4b458d0a29e6f2aea6d15632f00bacf1(
    *,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7ec787685bd2f35d093ba374b660ac8003afa2b5b1e604543160666659567aa4(
    *,
    location: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7be86d1ee12ed9c46427f0835dfa49f749b21fa1402cb4087c8773bc118f6d94(
    *,
    additional_information: typing.Optional[typing.Union[CodeBuildBuildPhaseChange.AdditionalInformation, typing.Dict[builtins.str, typing.Any]]] = None,
    build_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    completed_phase: typing.Optional[typing.Sequence[builtins.str]] = None,
    completed_phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
    completed_phase_duration_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
    completed_phase_end: typing.Optional[typing.Sequence[builtins.str]] = None,
    completed_phase_start: typing.Optional[typing.Sequence[builtins.str]] = None,
    completed_phase_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    project_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__14dc0ad0ff266847dfeaa34e3b64882a4a07fab90079ce828bc3b9833f79e22f(
    *,
    compute_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    environment_variables: typing.Optional[typing.Sequence[typing.Union[CodeBuildBuildPhaseChange.EnvironmentItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    image: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_pull_credentials_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    privileged_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__bd817946916681c446c5b521c48653a0c0d7773a2e6fc146dd470165c5ff69db(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a3db0c960b51a1c3d1a7fad4f14ac38e0c1bc1ffc8a7af50ef675920289ba31c(
    *,
    deep_link: typing.Optional[typing.Sequence[builtins.str]] = None,
    group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    stream_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__27610d6749bc24aa82d8e0e70c32084d167a697f4eb05687c338cfd99e28eea1(
    *,
    eni_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__36b7014a7e6e48528ab7e07197c49b57a7381e3e8b1af70f7325f21c64f5505d(
    *,
    auth: typing.Optional[typing.Union[CodeBuildBuildPhaseChange.Auth, typing.Dict[builtins.str, typing.Any]]] = None,
    buildspec: typing.Optional[typing.Sequence[builtins.str]] = None,
    location: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9a108810434402a5cc7e1bf359ffd869a3ef01b096211032e62c4050c9e557b5(
    *,
    security_group_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnets: typing.Optional[typing.Sequence[typing.Union[CodeBuildBuildPhaseChange.VpcConfigItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e089c6bf92a8e4d72a2a6660ed48803cf5cff1478aeeffb9e64ce20666a13b25(
    *,
    build_fleet_az: typing.Optional[typing.Sequence[builtins.str]] = None,
    customer_az: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__67459f809720eed0d66aeaf29a617043d7d9c9dbc7af4ac77bf43892957acfd3(
    *,
    artifact: typing.Optional[typing.Union[CodeBuildBuildStateChange.Artifact, typing.Dict[builtins.str, typing.Any]]] = None,
    build_complete: typing.Optional[typing.Sequence[builtins.str]] = None,
    build_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    cache: typing.Optional[typing.Union[CodeBuildBuildStateChange.Cache, typing.Dict[builtins.str, typing.Any]]] = None,
    environment: typing.Optional[typing.Union[CodeBuildBuildStateChange.Environment, typing.Dict[builtins.str, typing.Any]]] = None,
    initiator: typing.Optional[typing.Sequence[builtins.str]] = None,
    logs: typing.Optional[typing.Union[CodeBuildBuildStateChange.Logs, typing.Dict[builtins.str, typing.Any]]] = None,
    network_interface: typing.Optional[typing.Union[CodeBuildBuildStateChange.NetworkInterface, typing.Dict[builtins.str, typing.Any]]] = None,
    phases: typing.Optional[typing.Sequence[typing.Union[CodeBuildBuildStateChange.AdditionalInformationItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    queued_timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
    source: typing.Optional[typing.Union[CodeBuildBuildStateChange.Source, typing.Dict[builtins.str, typing.Any]]] = None,
    source_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    timeout_in_minutes: typing.Optional[typing.Sequence[builtins.str]] = None,
    vpc_config: typing.Optional[typing.Union[CodeBuildBuildStateChange.VpcConfig, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c2ba014748bc99c31d90defc40563c2830865d000cbb6d95f9e588ca09e38406(
    *,
    duration_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
    end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
    phase_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    phase_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e749067f706e3cb6e2d38dc29cab64e0c06e9c5c247dcf57c7051e4b11644c54(
    *,
    location: typing.Optional[typing.Sequence[builtins.str]] = None,
    md5_sum: typing.Optional[typing.Sequence[builtins.str]] = None,
    sha256_sum: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a5649a553313456b3b9c2af56376b59ce0dffc15a8c06bef13434ac10a8d01c(
    *,
    resource: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__50827c94b1d2017f7e8873748d79e7f52471f5ac65ffbab4aa6874921f90a2f3(
    *,
    location: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__86192eb57ed69210100a89c273e97a706168aeedb7a2cc1d88f874427fe0ac2f(
    *,
    additional_information: typing.Optional[typing.Union[CodeBuildBuildStateChange.AdditionalInformation, typing.Dict[builtins.str, typing.Any]]] = None,
    build_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    build_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    current_phase: typing.Optional[typing.Sequence[builtins.str]] = None,
    current_phase_context: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    project_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6fb3583bd3718d0daca33c914b963fdd8a5561bf9461a8d465f16a02044b03de(
    *,
    compute_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    environment_variables: typing.Optional[typing.Sequence[typing.Union[CodeBuildBuildStateChange.EnvironmentItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    image: typing.Optional[typing.Sequence[builtins.str]] = None,
    image_pull_credentials_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    privileged_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f6462e8a65278a564fe0823191bd28fd034ebcb80ab9c6b95353ef724a89dbcf(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4a3e32a53a6a3453beaf8514408029c6eccd15ed4031d8512402198d5f6e1019(
    *,
    deep_link: typing.Optional[typing.Sequence[builtins.str]] = None,
    group_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    stream_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d5c05e75715545294cacb2b5bae05faa12c54ee113907e3b33b0c7332d8c1467(
    *,
    eni_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__271fe5b1288398df4ad413ba4ea8f3c5ad4808d40f000d518816c589ca5b57ca(
    *,
    auth: typing.Optional[typing.Union[CodeBuildBuildStateChange.Auth, typing.Dict[builtins.str, typing.Any]]] = None,
    buildspec: typing.Optional[typing.Sequence[builtins.str]] = None,
    location: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd255fdab961049952435cbfaa637f5676b4c85d0acb86db59365cf73a10152b(
    *,
    security_group_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnets: typing.Optional[typing.Sequence[typing.Union[CodeBuildBuildStateChange.VpcConfigItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    vpc_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__40ac92130303c440608218b1abb03a961fbd8c89b3c50f068b930bcf3c002c19(
    *,
    build_fleet_az: typing.Optional[typing.Sequence[builtins.str]] = None,
    customer_az: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnet_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__db4d32fb7791ee1d99407b942179cc160a485c3efe1a1bf3d6c836e1b2638ff0(
    project_ref: _aws_cdk_interfaces_aws_codebuild_ceddda9d.IProjectRef,
) -> None:
    """Type checking stubs"""
    pass
