from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d
import aws_cdk.interfaces.aws_sagemaker as _aws_cdk_interfaces_aws_sagemaker_ceddda9d


class AWSAPICallViaCloudTrail(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@AWSAPICallViaCloudTrail.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        a_wSAPICall_via_cloud_trail = sagemaker_events.AWSAPICallViaCloudTrail()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
        error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
        response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
        source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
        user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for AWS API Call via CloudTrail.

        :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
            aws_region=aws_region,
            error_code=error_code,
            error_message=error_message,
            event_id=event_id,
            event_metadata=event_metadata,
            event_name=event_name,
            event_source=event_source,
            event_time=event_time,
            event_type=event_type,
            event_version=event_version,
            request_id=request_id,
            request_parameters=request_parameters,
            response_elements=response_elements,
            source_ip_address=source_ip_address,
            user_agent=user_agent,
            user_identity=user_identity,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps",
        jsii_struct_bases=[],
        name_mapping={
            "aws_region": "awsRegion",
            "error_code": "errorCode",
            "error_message": "errorMessage",
            "event_id": "eventId",
            "event_metadata": "eventMetadata",
            "event_name": "eventName",
            "event_source": "eventSource",
            "event_time": "eventTime",
            "event_type": "eventType",
            "event_version": "eventVersion",
            "request_id": "requestId",
            "request_parameters": "requestParameters",
            "response_elements": "responseElements",
            "source_ip_address": "sourceIpAddress",
            "user_agent": "userAgent",
            "user_identity": "userIdentity",
        },
    )
    class AWSAPICallViaCloudTrailProps:
        def __init__(
            self,
            *,
            aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
            error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            request_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.RequestParameters", typing.Dict[builtins.str, typing.Any]]] = None,
            response_elements: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResponseElements", typing.Dict[builtins.str, typing.Any]]] = None,
            source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_identity: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.UserIdentity", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@AWSAPICallViaCloudTrail event.

            :param aws_region: (experimental) awsRegion property. Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_code: (experimental) errorCode property. Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param error_message: (experimental) errorMessage property. Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_id: (experimental) eventID property. Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param event_name: (experimental) eventName property. Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_source: (experimental) eventSource property. Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_time: (experimental) eventTime property. Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_type: (experimental) eventType property. Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_version: (experimental) eventVersion property. Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_id: (experimental) requestID property. Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param request_parameters: (experimental) requestParameters property. Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param response_elements: (experimental) responseElements property. Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param source_ip_address: (experimental) sourceIPAddress property. Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_agent: (experimental) userAgent property. Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_identity: (experimental) userIdentity property. Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                # tags: Any
                
                a_wSAPICall_via_cloud_trail_props = sagemaker_events.AWSAPICallViaCloudTrail.AWSAPICallViaCloudTrailProps(
                    aws_region=["awsRegion"],
                    error_code=["errorCode"],
                    error_message=["errorMessage"],
                    event_id=["eventId"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    event_name=["eventName"],
                    event_source=["eventSource"],
                    event_time=["eventTime"],
                    event_type=["eventType"],
                    event_version=["eventVersion"],
                    request_id=["requestId"],
                    request_parameters=sagemaker_events.AWSAPICallViaCloudTrail.RequestParameters(
                        algorithm_specification=sagemaker_events.AWSAPICallViaCloudTrail.AlgorithmSpecification(
                            training_image=["trainingImage"],
                            training_input_mode=["trainingInputMode"]
                        ),
                        enable_inter_container_traffic_encryption=["enableInterContainerTrafficEncryption"],
                        enable_managed_spot_training=["enableManagedSpotTraining"],
                        enable_network_isolation=["enableNetworkIsolation"],
                        endpoint_config_name=["endpointConfigName"],
                        endpoint_name=["endpointName"],
                        execution_role_arn=["executionRoleArn"],
                        hyper_parameters=sagemaker_events.AWSAPICallViaCloudTrail.HyperParameters(
                            eval_metric=["evalMetric"],
                            num_round=["numRound"],
                            objective=["objective"]
                        ),
                        input_data_config=[sagemaker_events.AWSAPICallViaCloudTrail.RequestParametersItem2(
                            channel_name=["channelName"],
                            content_type=["contentType"],
                            data_source=sagemaker_events.AWSAPICallViaCloudTrail.DataSource1(
                                s3_data_source=sagemaker_events.AWSAPICallViaCloudTrail.S3DataSource1(
                                    s3_data_distribution_type=["s3DataDistributionType"],
                                    s3_data_type=["s3DataType"],
                                    s3_uri=["s3Uri"]
                                )
                            )
                        )],
                        model_name=["modelName"],
                        output_data_config=sagemaker_events.AWSAPICallViaCloudTrail.OutputDataConfig(
                            remove_job_name_from_s3_output_path=["removeJobNameFromS3OutputPath"],
                            s3_output_path=["s3OutputPath"]
                        ),
                        primary_container=sagemaker_events.AWSAPICallViaCloudTrail.PrimaryContainer(
                            container_hostname=["containerHostname"],
                            image=["image"],
                            model_data_url=["modelDataUrl"]
                        ),
                        production_variants=[sagemaker_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                            initial_instance_count=["initialInstanceCount"],
                            initial_variant_weight=["initialVariantWeight"],
                            instance_type=["instanceType"],
                            model_name=["modelName"],
                            variant_name=["variantName"]
                        )],
                        resource_config=sagemaker_events.AWSAPICallViaCloudTrail.ResourceConfig(
                            instance_count=["instanceCount"],
                            instance_type=["instanceType"],
                            volume_size_in_gb=["volumeSizeInGb"]
                        ),
                        role_arn=["roleArn"],
                        stopping_condition=sagemaker_events.AWSAPICallViaCloudTrail.StoppingCondition(
                            max_runtime_in_seconds=["maxRuntimeInSeconds"]
                        ),
                        tags=[tags],
                        training_job_name=["trainingJobName"],
                        transform_input=sagemaker_events.AWSAPICallViaCloudTrail.TransformInput(
                            compression_type=["compressionType"],
                            content_type=["contentType"],
                            data_source=sagemaker_events.AWSAPICallViaCloudTrail.DataSource(
                                s3_data_source=sagemaker_events.AWSAPICallViaCloudTrail.S3DataSource(
                                    s3_data_type=["s3DataType"],
                                    s3_uri=["s3Uri"]
                                )
                            )
                        ),
                        transform_job_name=["transformJobName"],
                        transform_output=sagemaker_events.AWSAPICallViaCloudTrail.TransformOutput(
                            s3_output_path=["s3OutputPath"]
                        ),
                        transform_resources=sagemaker_events.AWSAPICallViaCloudTrail.TransformResources(
                            instance_count=["instanceCount"],
                            instance_type=["instanceType"]
                        )
                    ),
                    response_elements=sagemaker_events.AWSAPICallViaCloudTrail.ResponseElements(
                        endpoint_config_arn=["endpointConfigArn"],
                        model_arn=["modelArn"],
                        training_job_arn=["trainingJobArn"],
                        transform_job_arn=["transformJobArn"]
                    ),
                    source_ip_address=["sourceIpAddress"],
                    user_agent=["userAgent"],
                    user_identity=sagemaker_events.AWSAPICallViaCloudTrail.UserIdentity(
                        access_key_id=["accessKeyId"],
                        account_id=["accountId"],
                        arn=["arn"],
                        invoked_by=["invokedBy"],
                        principal_id=["principalId"],
                        session_context=sagemaker_events.AWSAPICallViaCloudTrail.SessionContext(
                            attributes=sagemaker_events.AWSAPICallViaCloudTrail.Attributes(
                                creation_date=["creationDate"],
                                mfa_authenticated=["mfaAuthenticated"]
                            ),
                            session_issuer=sagemaker_events.AWSAPICallViaCloudTrail.SessionIssuer(
                                account_id=["accountId"],
                                arn=["arn"],
                                principal_id=["principalId"],
                                type=["type"],
                                user_name=["userName"]
                            ),
                            web_id_federation_data=["webIdFederationData"]
                        ),
                        type=["type"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(request_parameters, dict):
                request_parameters = AWSAPICallViaCloudTrail.RequestParameters(**request_parameters)
            if isinstance(response_elements, dict):
                response_elements = AWSAPICallViaCloudTrail.ResponseElements(**response_elements)
            if isinstance(user_identity, dict):
                user_identity = AWSAPICallViaCloudTrail.UserIdentity(**user_identity)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f61f8ef12ad0e858807b399b29395eab359e24077e842ff4d7224c64e2f3d867)
                check_type(argname="argument aws_region", value=aws_region, expected_type=type_hints["aws_region"])
                check_type(argname="argument error_code", value=error_code, expected_type=type_hints["error_code"])
                check_type(argname="argument error_message", value=error_message, expected_type=type_hints["error_message"])
                check_type(argname="argument event_id", value=event_id, expected_type=type_hints["event_id"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument event_name", value=event_name, expected_type=type_hints["event_name"])
                check_type(argname="argument event_source", value=event_source, expected_type=type_hints["event_source"])
                check_type(argname="argument event_time", value=event_time, expected_type=type_hints["event_time"])
                check_type(argname="argument event_type", value=event_type, expected_type=type_hints["event_type"])
                check_type(argname="argument event_version", value=event_version, expected_type=type_hints["event_version"])
                check_type(argname="argument request_id", value=request_id, expected_type=type_hints["request_id"])
                check_type(argname="argument request_parameters", value=request_parameters, expected_type=type_hints["request_parameters"])
                check_type(argname="argument response_elements", value=response_elements, expected_type=type_hints["response_elements"])
                check_type(argname="argument source_ip_address", value=source_ip_address, expected_type=type_hints["source_ip_address"])
                check_type(argname="argument user_agent", value=user_agent, expected_type=type_hints["user_agent"])
                check_type(argname="argument user_identity", value=user_identity, expected_type=type_hints["user_identity"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if aws_region is not None:
                self._values["aws_region"] = aws_region
            if error_code is not None:
                self._values["error_code"] = error_code
            if error_message is not None:
                self._values["error_message"] = error_message
            if event_id is not None:
                self._values["event_id"] = event_id
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if event_name is not None:
                self._values["event_name"] = event_name
            if event_source is not None:
                self._values["event_source"] = event_source
            if event_time is not None:
                self._values["event_time"] = event_time
            if event_type is not None:
                self._values["event_type"] = event_type
            if event_version is not None:
                self._values["event_version"] = event_version
            if request_id is not None:
                self._values["request_id"] = request_id
            if request_parameters is not None:
                self._values["request_parameters"] = request_parameters
            if response_elements is not None:
                self._values["response_elements"] = response_elements
            if source_ip_address is not None:
                self._values["source_ip_address"] = source_ip_address
            if user_agent is not None:
                self._values["user_agent"] = user_agent
            if user_identity is not None:
                self._values["user_identity"] = user_identity

        @builtins.property
        def aws_region(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) awsRegion property.

            Specify an array of string values to match this event if the actual value of awsRegion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("aws_region")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_code(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorCode property.

            Specify an array of string values to match this event if the actual value of errorCode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_code")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def error_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) errorMessage property.

            Specify an array of string values to match this event if the actual value of errorMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("error_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventID property.

            Specify an array of string values to match this event if the actual value of eventID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def event_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventName property.

            Specify an array of string values to match this event if the actual value of eventName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_source(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventSource property.

            Specify an array of string values to match this event if the actual value of eventSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_source")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventTime property.

            Specify an array of string values to match this event if the actual value of eventTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventType property.

            Specify an array of string values to match this event if the actual value of eventType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eventVersion property.

            Specify an array of string values to match this event if the actual value of eventVersion is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("event_version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) requestID property.

            Specify an array of string values to match this event if the actual value of requestID is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def request_parameters(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"]:
            '''(experimental) requestParameters property.

            Specify an array of string values to match this event if the actual value of requestParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("request_parameters")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.RequestParameters"], result)

        @builtins.property
        def response_elements(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"]:
            '''(experimental) responseElements property.

            Specify an array of string values to match this event if the actual value of responseElements is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("response_elements")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ResponseElements"], result)

        @builtins.property
        def source_ip_address(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourceIPAddress property.

            Specify an array of string values to match this event if the actual value of sourceIPAddress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_ip_address")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_agent(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userAgent property.

            Specify an array of string values to match this event if the actual value of userAgent is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_agent")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_identity(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"]:
            '''(experimental) userIdentity property.

            Specify an array of string values to match this event if the actual value of userIdentity is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_identity")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.UserIdentity"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AWSAPICallViaCloudTrailProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.AlgorithmSpecification",
        jsii_struct_bases=[],
        name_mapping={
            "training_image": "trainingImage",
            "training_input_mode": "trainingInputMode",
        },
    )
    class AlgorithmSpecification:
        def __init__(
            self,
            *,
            training_image: typing.Optional[typing.Sequence[builtins.str]] = None,
            training_input_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AlgorithmSpecification.

            :param training_image: (experimental) trainingImage property. Specify an array of string values to match this event if the actual value of trainingImage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_input_mode: (experimental) trainingInputMode property. Specify an array of string values to match this event if the actual value of trainingInputMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                algorithm_specification = sagemaker_events.AWSAPICallViaCloudTrail.AlgorithmSpecification(
                    training_image=["trainingImage"],
                    training_input_mode=["trainingInputMode"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6a0ed15c03c82ac3b129bec9eb933a1ba90cf97d9aba465489f060a3fe544891)
                check_type(argname="argument training_image", value=training_image, expected_type=type_hints["training_image"])
                check_type(argname="argument training_input_mode", value=training_input_mode, expected_type=type_hints["training_input_mode"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if training_image is not None:
                self._values["training_image"] = training_image
            if training_input_mode is not None:
                self._values["training_input_mode"] = training_input_mode

        @builtins.property
        def training_image(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) trainingImage property.

            Specify an array of string values to match this event if the actual value of trainingImage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_image")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def training_input_mode(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) trainingInputMode property.

            Specify an array of string values to match this event if the actual value of trainingInputMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_input_mode")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AlgorithmSpecification(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.Attributes",
        jsii_struct_bases=[],
        name_mapping={
            "creation_date": "creationDate",
            "mfa_authenticated": "mfaAuthenticated",
        },
    )
    class Attributes:
        def __init__(
            self,
            *,
            creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
            mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Attributes.

            :param creation_date: (experimental) creationDate property. Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param mfa_authenticated: (experimental) mfaAuthenticated property. Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                attributes = sagemaker_events.AWSAPICallViaCloudTrail.Attributes(
                    creation_date=["creationDate"],
                    mfa_authenticated=["mfaAuthenticated"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__dc355425535b6bf79145caf578aa349a753f26a84a92e0abb9596d411425ea6d)
                check_type(argname="argument creation_date", value=creation_date, expected_type=type_hints["creation_date"])
                check_type(argname="argument mfa_authenticated", value=mfa_authenticated, expected_type=type_hints["mfa_authenticated"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_date is not None:
                self._values["creation_date"] = creation_date
            if mfa_authenticated is not None:
                self._values["mfa_authenticated"] = mfa_authenticated

        @builtins.property
        def creation_date(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) creationDate property.

            Specify an array of string values to match this event if the actual value of creationDate is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_date")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def mfa_authenticated(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mfaAuthenticated property.

            Specify an array of string values to match this event if the actual value of mfaAuthenticated is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("mfa_authenticated")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Attributes(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.DataSource",
        jsii_struct_bases=[],
        name_mapping={"s3_data_source": "s3DataSource"},
    )
    class DataSource:
        def __init__(
            self,
            *,
            s3_data_source: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.S3DataSource", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for DataSource.

            :param s3_data_source: (experimental) s3DataSource property. Specify an array of string values to match this event if the actual value of s3DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                data_source = sagemaker_events.AWSAPICallViaCloudTrail.DataSource(
                    s3_data_source=sagemaker_events.AWSAPICallViaCloudTrail.S3DataSource(
                        s3_data_type=["s3DataType"],
                        s3_uri=["s3Uri"]
                    )
                )
            '''
            if isinstance(s3_data_source, dict):
                s3_data_source = AWSAPICallViaCloudTrail.S3DataSource(**s3_data_source)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e4106b023f8c8771ef1916912b1de1ece1b77c70da771aa81cb355680904c6e5)
                check_type(argname="argument s3_data_source", value=s3_data_source, expected_type=type_hints["s3_data_source"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_data_source is not None:
                self._values["s3_data_source"] = s3_data_source

        @builtins.property
        def s3_data_source(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.S3DataSource"]:
            '''(experimental) s3DataSource property.

            Specify an array of string values to match this event if the actual value of s3DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_source")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.S3DataSource"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataSource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.DataSource1",
        jsii_struct_bases=[],
        name_mapping={"s3_data_source": "s3DataSource"},
    )
    class DataSource1:
        def __init__(
            self,
            *,
            s3_data_source: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.S3DataSource1", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for DataSource_1.

            :param s3_data_source: (experimental) s3DataSource property. Specify an array of string values to match this event if the actual value of s3DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                data_source1 = sagemaker_events.AWSAPICallViaCloudTrail.DataSource1(
                    s3_data_source=sagemaker_events.AWSAPICallViaCloudTrail.S3DataSource1(
                        s3_data_distribution_type=["s3DataDistributionType"],
                        s3_data_type=["s3DataType"],
                        s3_uri=["s3Uri"]
                    )
                )
            '''
            if isinstance(s3_data_source, dict):
                s3_data_source = AWSAPICallViaCloudTrail.S3DataSource1(**s3_data_source)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__57702cd4b21da5aae7b63fa403fc1ac3d183a48a1378941623f7fd70de348899)
                check_type(argname="argument s3_data_source", value=s3_data_source, expected_type=type_hints["s3_data_source"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_data_source is not None:
                self._values["s3_data_source"] = s3_data_source

        @builtins.property
        def s3_data_source(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.S3DataSource1"]:
            '''(experimental) s3DataSource property.

            Specify an array of string values to match this event if the actual value of s3DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_source")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.S3DataSource1"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataSource1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.HyperParameters",
        jsii_struct_bases=[],
        name_mapping={
            "eval_metric": "evalMetric",
            "num_round": "numRound",
            "objective": "objective",
        },
    )
    class HyperParameters:
        def __init__(
            self,
            *,
            eval_metric: typing.Optional[typing.Sequence[builtins.str]] = None,
            num_round: typing.Optional[typing.Sequence[builtins.str]] = None,
            objective: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for HyperParameters.

            :param eval_metric: (experimental) eval_metric property. Specify an array of string values to match this event if the actual value of eval_metric is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param num_round: (experimental) num_round property. Specify an array of string values to match this event if the actual value of num_round is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param objective: (experimental) objective property. Specify an array of string values to match this event if the actual value of objective is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                hyper_parameters = sagemaker_events.AWSAPICallViaCloudTrail.HyperParameters(
                    eval_metric=["evalMetric"],
                    num_round=["numRound"],
                    objective=["objective"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fa303df54be486b2916ddb9d6a199252dba0bcb912fc2eedc07746a4a7168b77)
                check_type(argname="argument eval_metric", value=eval_metric, expected_type=type_hints["eval_metric"])
                check_type(argname="argument num_round", value=num_round, expected_type=type_hints["num_round"])
                check_type(argname="argument objective", value=objective, expected_type=type_hints["objective"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if eval_metric is not None:
                self._values["eval_metric"] = eval_metric
            if num_round is not None:
                self._values["num_round"] = num_round
            if objective is not None:
                self._values["objective"] = objective

        @builtins.property
        def eval_metric(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) eval_metric property.

            Specify an array of string values to match this event if the actual value of eval_metric is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("eval_metric")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def num_round(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) num_round property.

            Specify an array of string values to match this event if the actual value of num_round is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("num_round")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def objective(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) objective property.

            Specify an array of string values to match this event if the actual value of objective is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("objective")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "HyperParameters(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.OutputDataConfig",
        jsii_struct_bases=[],
        name_mapping={
            "remove_job_name_from_s3_output_path": "removeJobNameFromS3OutputPath",
            "s3_output_path": "s3OutputPath",
        },
    )
    class OutputDataConfig:
        def __init__(
            self,
            *,
            remove_job_name_from_s3_output_path: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_output_path: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for OutputDataConfig.

            :param remove_job_name_from_s3_output_path: (experimental) removeJobNameFromS3OutputPath property. Specify an array of string values to match this event if the actual value of removeJobNameFromS3OutputPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_output_path: (experimental) s3OutputPath property. Specify an array of string values to match this event if the actual value of s3OutputPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                output_data_config = sagemaker_events.AWSAPICallViaCloudTrail.OutputDataConfig(
                    remove_job_name_from_s3_output_path=["removeJobNameFromS3OutputPath"],
                    s3_output_path=["s3OutputPath"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2a2a0488d827cb3fac133659309cfd1a54eb9c45b9a3cc121b01a1f33b681c9c)
                check_type(argname="argument remove_job_name_from_s3_output_path", value=remove_job_name_from_s3_output_path, expected_type=type_hints["remove_job_name_from_s3_output_path"])
                check_type(argname="argument s3_output_path", value=s3_output_path, expected_type=type_hints["s3_output_path"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if remove_job_name_from_s3_output_path is not None:
                self._values["remove_job_name_from_s3_output_path"] = remove_job_name_from_s3_output_path
            if s3_output_path is not None:
                self._values["s3_output_path"] = s3_output_path

        @builtins.property
        def remove_job_name_from_s3_output_path(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) removeJobNameFromS3OutputPath property.

            Specify an array of string values to match this event if the actual value of removeJobNameFromS3OutputPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("remove_job_name_from_s3_output_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_output_path(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3OutputPath property.

            Specify an array of string values to match this event if the actual value of s3OutputPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_output_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OutputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.PrimaryContainer",
        jsii_struct_bases=[],
        name_mapping={
            "container_hostname": "containerHostname",
            "image": "image",
            "model_data_url": "modelDataUrl",
        },
    )
    class PrimaryContainer:
        def __init__(
            self,
            *,
            container_hostname: typing.Optional[typing.Sequence[builtins.str]] = None,
            image: typing.Optional[typing.Sequence[builtins.str]] = None,
            model_data_url: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for PrimaryContainer.

            :param container_hostname: (experimental) containerHostname property. Specify an array of string values to match this event if the actual value of containerHostname is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image: (experimental) image property. Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param model_data_url: (experimental) modelDataUrl property. Specify an array of string values to match this event if the actual value of modelDataUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                primary_container = sagemaker_events.AWSAPICallViaCloudTrail.PrimaryContainer(
                    container_hostname=["containerHostname"],
                    image=["image"],
                    model_data_url=["modelDataUrl"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4363e84b18d7bdefad04ab001ac5db54a88b0bf9a4f6521c384c5ccef724f548)
                check_type(argname="argument container_hostname", value=container_hostname, expected_type=type_hints["container_hostname"])
                check_type(argname="argument image", value=image, expected_type=type_hints["image"])
                check_type(argname="argument model_data_url", value=model_data_url, expected_type=type_hints["model_data_url"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if container_hostname is not None:
                self._values["container_hostname"] = container_hostname
            if image is not None:
                self._values["image"] = image
            if model_data_url is not None:
                self._values["model_data_url"] = model_data_url

        @builtins.property
        def container_hostname(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) containerHostname property.

            Specify an array of string values to match this event if the actual value of containerHostname is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("container_hostname")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) image property.

            Specify an array of string values to match this event if the actual value of image is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def model_data_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) modelDataUrl property.

            Specify an array of string values to match this event if the actual value of modelDataUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_data_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "PrimaryContainer(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.RequestParameters",
        jsii_struct_bases=[],
        name_mapping={
            "algorithm_specification": "algorithmSpecification",
            "enable_inter_container_traffic_encryption": "enableInterContainerTrafficEncryption",
            "enable_managed_spot_training": "enableManagedSpotTraining",
            "enable_network_isolation": "enableNetworkIsolation",
            "endpoint_config_name": "endpointConfigName",
            "endpoint_name": "endpointName",
            "execution_role_arn": "executionRoleArn",
            "hyper_parameters": "hyperParameters",
            "input_data_config": "inputDataConfig",
            "model_name": "modelName",
            "output_data_config": "outputDataConfig",
            "primary_container": "primaryContainer",
            "production_variants": "productionVariants",
            "resource_config": "resourceConfig",
            "role_arn": "roleArn",
            "stopping_condition": "stoppingCondition",
            "tags": "tags",
            "training_job_name": "trainingJobName",
            "transform_input": "transformInput",
            "transform_job_name": "transformJobName",
            "transform_output": "transformOutput",
            "transform_resources": "transformResources",
        },
    )
    class RequestParameters:
        def __init__(
            self,
            *,
            algorithm_specification: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.AlgorithmSpecification", typing.Dict[builtins.str, typing.Any]]] = None,
            enable_inter_container_traffic_encryption: typing.Optional[typing.Sequence[builtins.str]] = None,
            enable_managed_spot_training: typing.Optional[typing.Sequence[builtins.str]] = None,
            enable_network_isolation: typing.Optional[typing.Sequence[builtins.str]] = None,
            endpoint_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            endpoint_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            execution_role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            hyper_parameters: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.HyperParameters", typing.Dict[builtins.str, typing.Any]]] = None,
            input_data_config: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.RequestParametersItem2", typing.Dict[builtins.str, typing.Any]]]] = None,
            model_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            output_data_config: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            primary_container: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.PrimaryContainer", typing.Dict[builtins.str, typing.Any]]] = None,
            production_variants: typing.Optional[typing.Sequence[typing.Union["AWSAPICallViaCloudTrail.RequestParametersItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            resource_config: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.ResourceConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            stopping_condition: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.StoppingCondition", typing.Dict[builtins.str, typing.Any]]] = None,
            tags: typing.Optional[typing.Sequence[typing.Any]] = None,
            training_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            transform_input: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.TransformInput", typing.Dict[builtins.str, typing.Any]]] = None,
            transform_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            transform_output: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.TransformOutput", typing.Dict[builtins.str, typing.Any]]] = None,
            transform_resources: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.TransformResources", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParameters.

            :param algorithm_specification: (experimental) algorithmSpecification property. Specify an array of string values to match this event if the actual value of algorithmSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param enable_inter_container_traffic_encryption: (experimental) enableInterContainerTrafficEncryption property. Specify an array of string values to match this event if the actual value of enableInterContainerTrafficEncryption is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param enable_managed_spot_training: (experimental) enableManagedSpotTraining property. Specify an array of string values to match this event if the actual value of enableManagedSpotTraining is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param enable_network_isolation: (experimental) enableNetworkIsolation property. Specify an array of string values to match this event if the actual value of enableNetworkIsolation is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param endpoint_config_name: (experimental) endpointConfigName property. Specify an array of string values to match this event if the actual value of endpointConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param endpoint_name: (experimental) endpointName property. Specify an array of string values to match this event if the actual value of endpointName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param execution_role_arn: (experimental) executionRoleArn property. Specify an array of string values to match this event if the actual value of executionRoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param hyper_parameters: (experimental) hyperParameters property. Specify an array of string values to match this event if the actual value of hyperParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_data_config: (experimental) inputDataConfig property. Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param model_name: (experimental) modelName property. Specify an array of string values to match this event if the actual value of modelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_data_config: (experimental) outputDataConfig property. Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param primary_container: (experimental) primaryContainer property. Specify an array of string values to match this event if the actual value of primaryContainer is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param production_variants: (experimental) productionVariants property. Specify an array of string values to match this event if the actual value of productionVariants is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_config: (experimental) resourceConfig property. Specify an array of string values to match this event if the actual value of resourceConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param role_arn: (experimental) roleArn property. Specify an array of string values to match this event if the actual value of roleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stopping_condition: (experimental) stoppingCondition property. Specify an array of string values to match this event if the actual value of stoppingCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) tags property. Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_job_name: (experimental) trainingJobName property. Specify an array of string values to match this event if the actual value of trainingJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_input: (experimental) transformInput property. Specify an array of string values to match this event if the actual value of transformInput is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_job_name: (experimental) transformJobName property. Specify an array of string values to match this event if the actual value of transformJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_output: (experimental) transformOutput property. Specify an array of string values to match this event if the actual value of transformOutput is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_resources: (experimental) transformResources property. Specify an array of string values to match this event if the actual value of transformResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                # tags: Any
                
                request_parameters = sagemaker_events.AWSAPICallViaCloudTrail.RequestParameters(
                    algorithm_specification=sagemaker_events.AWSAPICallViaCloudTrail.AlgorithmSpecification(
                        training_image=["trainingImage"],
                        training_input_mode=["trainingInputMode"]
                    ),
                    enable_inter_container_traffic_encryption=["enableInterContainerTrafficEncryption"],
                    enable_managed_spot_training=["enableManagedSpotTraining"],
                    enable_network_isolation=["enableNetworkIsolation"],
                    endpoint_config_name=["endpointConfigName"],
                    endpoint_name=["endpointName"],
                    execution_role_arn=["executionRoleArn"],
                    hyper_parameters=sagemaker_events.AWSAPICallViaCloudTrail.HyperParameters(
                        eval_metric=["evalMetric"],
                        num_round=["numRound"],
                        objective=["objective"]
                    ),
                    input_data_config=[sagemaker_events.AWSAPICallViaCloudTrail.RequestParametersItem2(
                        channel_name=["channelName"],
                        content_type=["contentType"],
                        data_source=sagemaker_events.AWSAPICallViaCloudTrail.DataSource1(
                            s3_data_source=sagemaker_events.AWSAPICallViaCloudTrail.S3DataSource1(
                                s3_data_distribution_type=["s3DataDistributionType"],
                                s3_data_type=["s3DataType"],
                                s3_uri=["s3Uri"]
                            )
                        )
                    )],
                    model_name=["modelName"],
                    output_data_config=sagemaker_events.AWSAPICallViaCloudTrail.OutputDataConfig(
                        remove_job_name_from_s3_output_path=["removeJobNameFromS3OutputPath"],
                        s3_output_path=["s3OutputPath"]
                    ),
                    primary_container=sagemaker_events.AWSAPICallViaCloudTrail.PrimaryContainer(
                        container_hostname=["containerHostname"],
                        image=["image"],
                        model_data_url=["modelDataUrl"]
                    ),
                    production_variants=[sagemaker_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                        initial_instance_count=["initialInstanceCount"],
                        initial_variant_weight=["initialVariantWeight"],
                        instance_type=["instanceType"],
                        model_name=["modelName"],
                        variant_name=["variantName"]
                    )],
                    resource_config=sagemaker_events.AWSAPICallViaCloudTrail.ResourceConfig(
                        instance_count=["instanceCount"],
                        instance_type=["instanceType"],
                        volume_size_in_gb=["volumeSizeInGb"]
                    ),
                    role_arn=["roleArn"],
                    stopping_condition=sagemaker_events.AWSAPICallViaCloudTrail.StoppingCondition(
                        max_runtime_in_seconds=["maxRuntimeInSeconds"]
                    ),
                    tags=[tags],
                    training_job_name=["trainingJobName"],
                    transform_input=sagemaker_events.AWSAPICallViaCloudTrail.TransformInput(
                        compression_type=["compressionType"],
                        content_type=["contentType"],
                        data_source=sagemaker_events.AWSAPICallViaCloudTrail.DataSource(
                            s3_data_source=sagemaker_events.AWSAPICallViaCloudTrail.S3DataSource(
                                s3_data_type=["s3DataType"],
                                s3_uri=["s3Uri"]
                            )
                        )
                    ),
                    transform_job_name=["transformJobName"],
                    transform_output=sagemaker_events.AWSAPICallViaCloudTrail.TransformOutput(
                        s3_output_path=["s3OutputPath"]
                    ),
                    transform_resources=sagemaker_events.AWSAPICallViaCloudTrail.TransformResources(
                        instance_count=["instanceCount"],
                        instance_type=["instanceType"]
                    )
                )
            '''
            if isinstance(algorithm_specification, dict):
                algorithm_specification = AWSAPICallViaCloudTrail.AlgorithmSpecification(**algorithm_specification)
            if isinstance(hyper_parameters, dict):
                hyper_parameters = AWSAPICallViaCloudTrail.HyperParameters(**hyper_parameters)
            if isinstance(output_data_config, dict):
                output_data_config = AWSAPICallViaCloudTrail.OutputDataConfig(**output_data_config)
            if isinstance(primary_container, dict):
                primary_container = AWSAPICallViaCloudTrail.PrimaryContainer(**primary_container)
            if isinstance(resource_config, dict):
                resource_config = AWSAPICallViaCloudTrail.ResourceConfig(**resource_config)
            if isinstance(stopping_condition, dict):
                stopping_condition = AWSAPICallViaCloudTrail.StoppingCondition(**stopping_condition)
            if isinstance(transform_input, dict):
                transform_input = AWSAPICallViaCloudTrail.TransformInput(**transform_input)
            if isinstance(transform_output, dict):
                transform_output = AWSAPICallViaCloudTrail.TransformOutput(**transform_output)
            if isinstance(transform_resources, dict):
                transform_resources = AWSAPICallViaCloudTrail.TransformResources(**transform_resources)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0b8c55112733735b34e1d8081f24442fc153f03c3f77946a0317c20e48156f6c)
                check_type(argname="argument algorithm_specification", value=algorithm_specification, expected_type=type_hints["algorithm_specification"])
                check_type(argname="argument enable_inter_container_traffic_encryption", value=enable_inter_container_traffic_encryption, expected_type=type_hints["enable_inter_container_traffic_encryption"])
                check_type(argname="argument enable_managed_spot_training", value=enable_managed_spot_training, expected_type=type_hints["enable_managed_spot_training"])
                check_type(argname="argument enable_network_isolation", value=enable_network_isolation, expected_type=type_hints["enable_network_isolation"])
                check_type(argname="argument endpoint_config_name", value=endpoint_config_name, expected_type=type_hints["endpoint_config_name"])
                check_type(argname="argument endpoint_name", value=endpoint_name, expected_type=type_hints["endpoint_name"])
                check_type(argname="argument execution_role_arn", value=execution_role_arn, expected_type=type_hints["execution_role_arn"])
                check_type(argname="argument hyper_parameters", value=hyper_parameters, expected_type=type_hints["hyper_parameters"])
                check_type(argname="argument input_data_config", value=input_data_config, expected_type=type_hints["input_data_config"])
                check_type(argname="argument model_name", value=model_name, expected_type=type_hints["model_name"])
                check_type(argname="argument output_data_config", value=output_data_config, expected_type=type_hints["output_data_config"])
                check_type(argname="argument primary_container", value=primary_container, expected_type=type_hints["primary_container"])
                check_type(argname="argument production_variants", value=production_variants, expected_type=type_hints["production_variants"])
                check_type(argname="argument resource_config", value=resource_config, expected_type=type_hints["resource_config"])
                check_type(argname="argument role_arn", value=role_arn, expected_type=type_hints["role_arn"])
                check_type(argname="argument stopping_condition", value=stopping_condition, expected_type=type_hints["stopping_condition"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
                check_type(argname="argument training_job_name", value=training_job_name, expected_type=type_hints["training_job_name"])
                check_type(argname="argument transform_input", value=transform_input, expected_type=type_hints["transform_input"])
                check_type(argname="argument transform_job_name", value=transform_job_name, expected_type=type_hints["transform_job_name"])
                check_type(argname="argument transform_output", value=transform_output, expected_type=type_hints["transform_output"])
                check_type(argname="argument transform_resources", value=transform_resources, expected_type=type_hints["transform_resources"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if algorithm_specification is not None:
                self._values["algorithm_specification"] = algorithm_specification
            if enable_inter_container_traffic_encryption is not None:
                self._values["enable_inter_container_traffic_encryption"] = enable_inter_container_traffic_encryption
            if enable_managed_spot_training is not None:
                self._values["enable_managed_spot_training"] = enable_managed_spot_training
            if enable_network_isolation is not None:
                self._values["enable_network_isolation"] = enable_network_isolation
            if endpoint_config_name is not None:
                self._values["endpoint_config_name"] = endpoint_config_name
            if endpoint_name is not None:
                self._values["endpoint_name"] = endpoint_name
            if execution_role_arn is not None:
                self._values["execution_role_arn"] = execution_role_arn
            if hyper_parameters is not None:
                self._values["hyper_parameters"] = hyper_parameters
            if input_data_config is not None:
                self._values["input_data_config"] = input_data_config
            if model_name is not None:
                self._values["model_name"] = model_name
            if output_data_config is not None:
                self._values["output_data_config"] = output_data_config
            if primary_container is not None:
                self._values["primary_container"] = primary_container
            if production_variants is not None:
                self._values["production_variants"] = production_variants
            if resource_config is not None:
                self._values["resource_config"] = resource_config
            if role_arn is not None:
                self._values["role_arn"] = role_arn
            if stopping_condition is not None:
                self._values["stopping_condition"] = stopping_condition
            if tags is not None:
                self._values["tags"] = tags
            if training_job_name is not None:
                self._values["training_job_name"] = training_job_name
            if transform_input is not None:
                self._values["transform_input"] = transform_input
            if transform_job_name is not None:
                self._values["transform_job_name"] = transform_job_name
            if transform_output is not None:
                self._values["transform_output"] = transform_output
            if transform_resources is not None:
                self._values["transform_resources"] = transform_resources

        @builtins.property
        def algorithm_specification(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.AlgorithmSpecification"]:
            '''(experimental) algorithmSpecification property.

            Specify an array of string values to match this event if the actual value of algorithmSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("algorithm_specification")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.AlgorithmSpecification"], result)

        @builtins.property
        def enable_inter_container_traffic_encryption(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) enableInterContainerTrafficEncryption property.

            Specify an array of string values to match this event if the actual value of enableInterContainerTrafficEncryption is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("enable_inter_container_traffic_encryption")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def enable_managed_spot_training(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) enableManagedSpotTraining property.

            Specify an array of string values to match this event if the actual value of enableManagedSpotTraining is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("enable_managed_spot_training")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def enable_network_isolation(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) enableNetworkIsolation property.

            Specify an array of string values to match this event if the actual value of enableNetworkIsolation is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("enable_network_isolation")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def endpoint_config_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endpointConfigName property.

            Specify an array of string values to match this event if the actual value of endpointConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("endpoint_config_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def endpoint_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endpointName property.

            Specify an array of string values to match this event if the actual value of endpointName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("endpoint_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def execution_role_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) executionRoleArn property.

            Specify an array of string values to match this event if the actual value of executionRoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("execution_role_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def hyper_parameters(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.HyperParameters"]:
            '''(experimental) hyperParameters property.

            Specify an array of string values to match this event if the actual value of hyperParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("hyper_parameters")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.HyperParameters"], result)

        @builtins.property
        def input_data_config(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem2"]]:
            '''(experimental) inputDataConfig property.

            Specify an array of string values to match this event if the actual value of inputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_data_config")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem2"]], result)

        @builtins.property
        def model_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) modelName property.

            Specify an array of string values to match this event if the actual value of modelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def output_data_config(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.OutputDataConfig"]:
            '''(experimental) outputDataConfig property.

            Specify an array of string values to match this event if the actual value of outputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_data_config")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.OutputDataConfig"], result)

        @builtins.property
        def primary_container(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.PrimaryContainer"]:
            '''(experimental) primaryContainer property.

            Specify an array of string values to match this event if the actual value of primaryContainer is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("primary_container")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.PrimaryContainer"], result)

        @builtins.property
        def production_variants(
            self,
        ) -> typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem"]]:
            '''(experimental) productionVariants property.

            Specify an array of string values to match this event if the actual value of productionVariants is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("production_variants")
            return typing.cast(typing.Optional[typing.List["AWSAPICallViaCloudTrail.RequestParametersItem"]], result)

        @builtins.property
        def resource_config(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.ResourceConfig"]:
            '''(experimental) resourceConfig property.

            Specify an array of string values to match this event if the actual value of resourceConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_config")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.ResourceConfig"], result)

        @builtins.property
        def role_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) roleArn property.

            Specify an array of string values to match this event if the actual value of roleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("role_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stopping_condition(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.StoppingCondition"]:
            '''(experimental) stoppingCondition property.

            Specify an array of string values to match this event if the actual value of stoppingCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stopping_condition")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.StoppingCondition"], result)

        @builtins.property
        def tags(self) -> typing.Optional[typing.List[typing.Any]]:
            '''(experimental) tags property.

            Specify an array of string values to match this event if the actual value of tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List[typing.Any]], result)

        @builtins.property
        def training_job_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) trainingJobName property.

            Specify an array of string values to match this event if the actual value of trainingJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_job_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def transform_input(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.TransformInput"]:
            '''(experimental) transformInput property.

            Specify an array of string values to match this event if the actual value of transformInput is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_input")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.TransformInput"], result)

        @builtins.property
        def transform_job_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) transformJobName property.

            Specify an array of string values to match this event if the actual value of transformJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_job_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def transform_output(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.TransformOutput"]:
            '''(experimental) transformOutput property.

            Specify an array of string values to match this event if the actual value of transformOutput is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_output")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.TransformOutput"], result)

        @builtins.property
        def transform_resources(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.TransformResources"]:
            '''(experimental) transformResources property.

            Specify an array of string values to match this event if the actual value of transformResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_resources")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.TransformResources"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParameters(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.RequestParametersItem",
        jsii_struct_bases=[],
        name_mapping={
            "initial_instance_count": "initialInstanceCount",
            "initial_variant_weight": "initialVariantWeight",
            "instance_type": "instanceType",
            "model_name": "modelName",
            "variant_name": "variantName",
        },
    )
    class RequestParametersItem:
        def __init__(
            self,
            *,
            initial_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            initial_variant_weight: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            model_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            variant_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParametersItem.

            :param initial_instance_count: (experimental) initialInstanceCount property. Specify an array of string values to match this event if the actual value of initialInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param initial_variant_weight: (experimental) initialVariantWeight property. Specify an array of string values to match this event if the actual value of initialVariantWeight is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) instanceType property. Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param model_name: (experimental) modelName property. Specify an array of string values to match this event if the actual value of modelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param variant_name: (experimental) variantName property. Specify an array of string values to match this event if the actual value of variantName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                request_parameters_item = sagemaker_events.AWSAPICallViaCloudTrail.RequestParametersItem(
                    initial_instance_count=["initialInstanceCount"],
                    initial_variant_weight=["initialVariantWeight"],
                    instance_type=["instanceType"],
                    model_name=["modelName"],
                    variant_name=["variantName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8ba537fa22959b96074d142ce9fa2c2f2e351775d4e66279829d016c40b6ac47)
                check_type(argname="argument initial_instance_count", value=initial_instance_count, expected_type=type_hints["initial_instance_count"])
                check_type(argname="argument initial_variant_weight", value=initial_variant_weight, expected_type=type_hints["initial_variant_weight"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument model_name", value=model_name, expected_type=type_hints["model_name"])
                check_type(argname="argument variant_name", value=variant_name, expected_type=type_hints["variant_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if initial_instance_count is not None:
                self._values["initial_instance_count"] = initial_instance_count
            if initial_variant_weight is not None:
                self._values["initial_variant_weight"] = initial_variant_weight
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if model_name is not None:
                self._values["model_name"] = model_name
            if variant_name is not None:
                self._values["variant_name"] = variant_name

        @builtins.property
        def initial_instance_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) initialInstanceCount property.

            Specify an array of string values to match this event if the actual value of initialInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("initial_instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def initial_variant_weight(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) initialVariantWeight property.

            Specify an array of string values to match this event if the actual value of initialVariantWeight is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("initial_variant_weight")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceType property.

            Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def model_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) modelName property.

            Specify an array of string values to match this event if the actual value of modelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def variant_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) variantName property.

            Specify an array of string values to match this event if the actual value of variantName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("variant_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParametersItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.RequestParametersItem2",
        jsii_struct_bases=[],
        name_mapping={
            "channel_name": "channelName",
            "content_type": "contentType",
            "data_source": "dataSource",
        },
    )
    class RequestParametersItem2:
        def __init__(
            self,
            *,
            channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            content_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            data_source: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.DataSource1", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for RequestParametersItem_2.

            :param channel_name: (experimental) channelName property. Specify an array of string values to match this event if the actual value of channelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param content_type: (experimental) contentType property. Specify an array of string values to match this event if the actual value of contentType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source: (experimental) dataSource property. Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                request_parameters_item2 = sagemaker_events.AWSAPICallViaCloudTrail.RequestParametersItem2(
                    channel_name=["channelName"],
                    content_type=["contentType"],
                    data_source=sagemaker_events.AWSAPICallViaCloudTrail.DataSource1(
                        s3_data_source=sagemaker_events.AWSAPICallViaCloudTrail.S3DataSource1(
                            s3_data_distribution_type=["s3DataDistributionType"],
                            s3_data_type=["s3DataType"],
                            s3_uri=["s3Uri"]
                        )
                    )
                )
            '''
            if isinstance(data_source, dict):
                data_source = AWSAPICallViaCloudTrail.DataSource1(**data_source)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d47cdc0a60321eea6c845332ccfff5bb96ccccf84b1c5efabd46aedacb7d00c9)
                check_type(argname="argument channel_name", value=channel_name, expected_type=type_hints["channel_name"])
                check_type(argname="argument content_type", value=content_type, expected_type=type_hints["content_type"])
                check_type(argname="argument data_source", value=data_source, expected_type=type_hints["data_source"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if channel_name is not None:
                self._values["channel_name"] = channel_name
            if content_type is not None:
                self._values["content_type"] = content_type
            if data_source is not None:
                self._values["data_source"] = data_source

        @builtins.property
        def channel_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) channelName property.

            Specify an array of string values to match this event if the actual value of channelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("channel_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def content_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) contentType property.

            Specify an array of string values to match this event if the actual value of contentType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("content_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data_source(self) -> typing.Optional["AWSAPICallViaCloudTrail.DataSource1"]:
            '''(experimental) dataSource property.

            Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.DataSource1"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "RequestParametersItem2(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.ResourceConfig",
        jsii_struct_bases=[],
        name_mapping={
            "instance_count": "instanceCount",
            "instance_type": "instanceType",
            "volume_size_in_gb": "volumeSizeInGb",
        },
    )
    class ResourceConfig:
        def __init__(
            self,
            *,
            instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            volume_size_in_gb: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResourceConfig.

            :param instance_count: (experimental) instanceCount property. Specify an array of string values to match this event if the actual value of instanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) instanceType property. Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param volume_size_in_gb: (experimental) volumeSizeInGB property. Specify an array of string values to match this event if the actual value of volumeSizeInGB is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                resource_config = sagemaker_events.AWSAPICallViaCloudTrail.ResourceConfig(
                    instance_count=["instanceCount"],
                    instance_type=["instanceType"],
                    volume_size_in_gb=["volumeSizeInGb"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e61df796362f3dd45bbd8cf3569bee7f8c119bf5c998ccea5176b01e31bea9be)
                check_type(argname="argument instance_count", value=instance_count, expected_type=type_hints["instance_count"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument volume_size_in_gb", value=volume_size_in_gb, expected_type=type_hints["volume_size_in_gb"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if instance_count is not None:
                self._values["instance_count"] = instance_count
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if volume_size_in_gb is not None:
                self._values["volume_size_in_gb"] = volume_size_in_gb

        @builtins.property
        def instance_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceCount property.

            Specify an array of string values to match this event if the actual value of instanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceType property.

            Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def volume_size_in_gb(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) volumeSizeInGB property.

            Specify an array of string values to match this event if the actual value of volumeSizeInGB is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("volume_size_in_gb")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResourceConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.ResponseElements",
        jsii_struct_bases=[],
        name_mapping={
            "endpoint_config_arn": "endpointConfigArn",
            "model_arn": "modelArn",
            "training_job_arn": "trainingJobArn",
            "transform_job_arn": "transformJobArn",
        },
    )
    class ResponseElements:
        def __init__(
            self,
            *,
            endpoint_config_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            model_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            training_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            transform_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResponseElements.

            :param endpoint_config_arn: (experimental) endpointConfigArn property. Specify an array of string values to match this event if the actual value of endpointConfigArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param model_arn: (experimental) modelArn property. Specify an array of string values to match this event if the actual value of modelArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_job_arn: (experimental) trainingJobArn property. Specify an array of string values to match this event if the actual value of trainingJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_job_arn: (experimental) transformJobArn property. Specify an array of string values to match this event if the actual value of transformJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                response_elements = sagemaker_events.AWSAPICallViaCloudTrail.ResponseElements(
                    endpoint_config_arn=["endpointConfigArn"],
                    model_arn=["modelArn"],
                    training_job_arn=["trainingJobArn"],
                    transform_job_arn=["transformJobArn"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__97fb69455d578f254d20e16c8a234be0ee4f7c1a027596eb2e93e35389b87066)
                check_type(argname="argument endpoint_config_arn", value=endpoint_config_arn, expected_type=type_hints["endpoint_config_arn"])
                check_type(argname="argument model_arn", value=model_arn, expected_type=type_hints["model_arn"])
                check_type(argname="argument training_job_arn", value=training_job_arn, expected_type=type_hints["training_job_arn"])
                check_type(argname="argument transform_job_arn", value=transform_job_arn, expected_type=type_hints["transform_job_arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if endpoint_config_arn is not None:
                self._values["endpoint_config_arn"] = endpoint_config_arn
            if model_arn is not None:
                self._values["model_arn"] = model_arn
            if training_job_arn is not None:
                self._values["training_job_arn"] = training_job_arn
            if transform_job_arn is not None:
                self._values["transform_job_arn"] = transform_job_arn

        @builtins.property
        def endpoint_config_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) endpointConfigArn property.

            Specify an array of string values to match this event if the actual value of endpointConfigArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("endpoint_config_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def model_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) modelArn property.

            Specify an array of string values to match this event if the actual value of modelArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def training_job_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) trainingJobArn property.

            Specify an array of string values to match this event if the actual value of trainingJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_job_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def transform_job_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) transformJobArn property.

            Specify an array of string values to match this event if the actual value of transformJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_job_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResponseElements(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.S3DataSource",
        jsii_struct_bases=[],
        name_mapping={"s3_data_type": "s3DataType", "s3_uri": "s3Uri"},
    )
    class S3DataSource:
        def __init__(
            self,
            *,
            s3_data_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for S3DataSource.

            :param s3_data_type: (experimental) s3DataType property. Specify an array of string values to match this event if the actual value of s3DataType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                s3_data_source = sagemaker_events.AWSAPICallViaCloudTrail.S3DataSource(
                    s3_data_type=["s3DataType"],
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ee998a8aedcf329dc09553ec020a7d66da065124c2c3ef9feadb21c57f170dd7)
                check_type(argname="argument s3_data_type", value=s3_data_type, expected_type=type_hints["s3_data_type"])
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_data_type is not None:
                self._values["s3_data_type"] = s3_data_type
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_data_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3DataType property.

            Specify an array of string values to match this event if the actual value of s3DataType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "S3DataSource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.S3DataSource1",
        jsii_struct_bases=[],
        name_mapping={
            "s3_data_distribution_type": "s3DataDistributionType",
            "s3_data_type": "s3DataType",
            "s3_uri": "s3Uri",
        },
    )
    class S3DataSource1:
        def __init__(
            self,
            *,
            s3_data_distribution_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_data_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for S3DataSource_1.

            :param s3_data_distribution_type: (experimental) s3DataDistributionType property. Specify an array of string values to match this event if the actual value of s3DataDistributionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_data_type: (experimental) s3DataType property. Specify an array of string values to match this event if the actual value of s3DataType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_uri: (experimental) s3Uri property. Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                s3_data_source1 = sagemaker_events.AWSAPICallViaCloudTrail.S3DataSource1(
                    s3_data_distribution_type=["s3DataDistributionType"],
                    s3_data_type=["s3DataType"],
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fcf1e1ef05960173b2653295de48416bd448338cac85fb21c9f63cb67cb8e41b)
                check_type(argname="argument s3_data_distribution_type", value=s3_data_distribution_type, expected_type=type_hints["s3_data_distribution_type"])
                check_type(argname="argument s3_data_type", value=s3_data_type, expected_type=type_hints["s3_data_type"])
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_data_distribution_type is not None:
                self._values["s3_data_distribution_type"] = s3_data_distribution_type
            if s3_data_type is not None:
                self._values["s3_data_type"] = s3_data_type
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_data_distribution_type(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3DataDistributionType property.

            Specify an array of string values to match this event if the actual value of s3DataDistributionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_distribution_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_data_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3DataType property.

            Specify an array of string values to match this event if the actual value of s3DataType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3Uri property.

            Specify an array of string values to match this event if the actual value of s3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "S3DataSource1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.SessionContext",
        jsii_struct_bases=[],
        name_mapping={
            "attributes": "attributes",
            "session_issuer": "sessionIssuer",
            "web_id_federation_data": "webIdFederationData",
        },
    )
    class SessionContext:
        def __init__(
            self,
            *,
            attributes: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.Attributes", typing.Dict[builtins.str, typing.Any]]] = None,
            session_issuer: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionIssuer", typing.Dict[builtins.str, typing.Any]]] = None,
            web_id_federation_data: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionContext.

            :param attributes: (experimental) attributes property. Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_issuer: (experimental) sessionIssuer property. Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param web_id_federation_data: (experimental) webIdFederationData property. Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                session_context = sagemaker_events.AWSAPICallViaCloudTrail.SessionContext(
                    attributes=sagemaker_events.AWSAPICallViaCloudTrail.Attributes(
                        creation_date=["creationDate"],
                        mfa_authenticated=["mfaAuthenticated"]
                    ),
                    session_issuer=sagemaker_events.AWSAPICallViaCloudTrail.SessionIssuer(
                        account_id=["accountId"],
                        arn=["arn"],
                        principal_id=["principalId"],
                        type=["type"],
                        user_name=["userName"]
                    ),
                    web_id_federation_data=["webIdFederationData"]
                )
            '''
            if isinstance(attributes, dict):
                attributes = AWSAPICallViaCloudTrail.Attributes(**attributes)
            if isinstance(session_issuer, dict):
                session_issuer = AWSAPICallViaCloudTrail.SessionIssuer(**session_issuer)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__eaf46a11d4a66b62828debf1c9cac86f0483694198ac056f2640a5b05d9c976e)
                check_type(argname="argument attributes", value=attributes, expected_type=type_hints["attributes"])
                check_type(argname="argument session_issuer", value=session_issuer, expected_type=type_hints["session_issuer"])
                check_type(argname="argument web_id_federation_data", value=web_id_federation_data, expected_type=type_hints["web_id_federation_data"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if attributes is not None:
                self._values["attributes"] = attributes
            if session_issuer is not None:
                self._values["session_issuer"] = session_issuer
            if web_id_federation_data is not None:
                self._values["web_id_federation_data"] = web_id_federation_data

        @builtins.property
        def attributes(self) -> typing.Optional["AWSAPICallViaCloudTrail.Attributes"]:
            '''(experimental) attributes property.

            Specify an array of string values to match this event if the actual value of attributes is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("attributes")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.Attributes"], result)

        @builtins.property
        def session_issuer(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"]:
            '''(experimental) sessionIssuer property.

            Specify an array of string values to match this event if the actual value of sessionIssuer is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_issuer")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionIssuer"], result)

        @builtins.property
        def web_id_federation_data(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) webIdFederationData property.

            Specify an array of string values to match this event if the actual value of webIdFederationData is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("web_id_federation_data")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionContext(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.SessionIssuer",
        jsii_struct_bases=[],
        name_mapping={
            "account_id": "accountId",
            "arn": "arn",
            "principal_id": "principalId",
            "type": "type",
            "user_name": "userName",
        },
    )
    class SessionIssuer:
        def __init__(
            self,
            *,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
            user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SessionIssuer.

            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param user_name: (experimental) userName property. Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                session_issuer = sagemaker_events.AWSAPICallViaCloudTrail.SessionIssuer(
                    account_id=["accountId"],
                    arn=["arn"],
                    principal_id=["principalId"],
                    type=["type"],
                    user_name=["userName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fdc402c46ff2d8d75852be3ba14f88f1329e07ae1e606677021d2cc91344ea51)
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
                check_type(argname="argument user_name", value=user_name, expected_type=type_hints["user_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if type is not None:
                self._values["type"] = type
            if user_name is not None:
                self._values["user_name"] = user_name

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def user_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) userName property.

            Specify an array of string values to match this event if the actual value of userName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("user_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SessionIssuer(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.StoppingCondition",
        jsii_struct_bases=[],
        name_mapping={"max_runtime_in_seconds": "maxRuntimeInSeconds"},
    )
    class StoppingCondition:
        def __init__(
            self,
            *,
            max_runtime_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for StoppingCondition.

            :param max_runtime_in_seconds: (experimental) maxRuntimeInSeconds property. Specify an array of string values to match this event if the actual value of maxRuntimeInSeconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                stopping_condition = sagemaker_events.AWSAPICallViaCloudTrail.StoppingCondition(
                    max_runtime_in_seconds=["maxRuntimeInSeconds"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__351b2afe247a7e475a43130ff9b0bee99973d231731d29a9e35d4c6d1feb7bf8)
                check_type(argname="argument max_runtime_in_seconds", value=max_runtime_in_seconds, expected_type=type_hints["max_runtime_in_seconds"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if max_runtime_in_seconds is not None:
                self._values["max_runtime_in_seconds"] = max_runtime_in_seconds

        @builtins.property
        def max_runtime_in_seconds(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) maxRuntimeInSeconds property.

            Specify an array of string values to match this event if the actual value of maxRuntimeInSeconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_runtime_in_seconds")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "StoppingCondition(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.TransformInput",
        jsii_struct_bases=[],
        name_mapping={
            "compression_type": "compressionType",
            "content_type": "contentType",
            "data_source": "dataSource",
        },
    )
    class TransformInput:
        def __init__(
            self,
            *,
            compression_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            content_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            data_source: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.DataSource", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for TransformInput.

            :param compression_type: (experimental) compressionType property. Specify an array of string values to match this event if the actual value of compressionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param content_type: (experimental) contentType property. Specify an array of string values to match this event if the actual value of contentType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source: (experimental) dataSource property. Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                transform_input = sagemaker_events.AWSAPICallViaCloudTrail.TransformInput(
                    compression_type=["compressionType"],
                    content_type=["contentType"],
                    data_source=sagemaker_events.AWSAPICallViaCloudTrail.DataSource(
                        s3_data_source=sagemaker_events.AWSAPICallViaCloudTrail.S3DataSource(
                            s3_data_type=["s3DataType"],
                            s3_uri=["s3Uri"]
                        )
                    )
                )
            '''
            if isinstance(data_source, dict):
                data_source = AWSAPICallViaCloudTrail.DataSource(**data_source)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b4b3c3cdb4dcf85d438d1bd5a652f0fb8310e6f0c0ccae87bb838997f6eda56e)
                check_type(argname="argument compression_type", value=compression_type, expected_type=type_hints["compression_type"])
                check_type(argname="argument content_type", value=content_type, expected_type=type_hints["content_type"])
                check_type(argname="argument data_source", value=data_source, expected_type=type_hints["data_source"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if compression_type is not None:
                self._values["compression_type"] = compression_type
            if content_type is not None:
                self._values["content_type"] = content_type
            if data_source is not None:
                self._values["data_source"] = data_source

        @builtins.property
        def compression_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) compressionType property.

            Specify an array of string values to match this event if the actual value of compressionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("compression_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def content_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) contentType property.

            Specify an array of string values to match this event if the actual value of contentType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("content_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data_source(self) -> typing.Optional["AWSAPICallViaCloudTrail.DataSource"]:
            '''(experimental) dataSource property.

            Specify an array of string values to match this event if the actual value of dataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.DataSource"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TransformInput(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.TransformOutput",
        jsii_struct_bases=[],
        name_mapping={"s3_output_path": "s3OutputPath"},
    )
    class TransformOutput:
        def __init__(
            self,
            *,
            s3_output_path: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for TransformOutput.

            :param s3_output_path: (experimental) s3OutputPath property. Specify an array of string values to match this event if the actual value of s3OutputPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                transform_output = sagemaker_events.AWSAPICallViaCloudTrail.TransformOutput(
                    s3_output_path=["s3OutputPath"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2e95013c4114b3d52f34b82cb0b6569658ca1ace4e3f981645d4846d73cb7117)
                check_type(argname="argument s3_output_path", value=s3_output_path, expected_type=type_hints["s3_output_path"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_output_path is not None:
                self._values["s3_output_path"] = s3_output_path

        @builtins.property
        def s3_output_path(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) s3OutputPath property.

            Specify an array of string values to match this event if the actual value of s3OutputPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_output_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TransformOutput(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.TransformResources",
        jsii_struct_bases=[],
        name_mapping={
            "instance_count": "instanceCount",
            "instance_type": "instanceType",
        },
    )
    class TransformResources:
        def __init__(
            self,
            *,
            instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for TransformResources.

            :param instance_count: (experimental) instanceCount property. Specify an array of string values to match this event if the actual value of instanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) instanceType property. Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                transform_resources = sagemaker_events.AWSAPICallViaCloudTrail.TransformResources(
                    instance_count=["instanceCount"],
                    instance_type=["instanceType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8a09cf73f140a3bdbb78b4406d3ba56eb269e8b0da8e0b2e64a6b70d7e058be8)
                check_type(argname="argument instance_count", value=instance_count, expected_type=type_hints["instance_count"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if instance_count is not None:
                self._values["instance_count"] = instance_count
            if instance_type is not None:
                self._values["instance_type"] = instance_type

        @builtins.property
        def instance_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceCount property.

            Specify an array of string values to match this event if the actual value of instanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) instanceType property.

            Specify an array of string values to match this event if the actual value of instanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TransformResources(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.AWSAPICallViaCloudTrail.UserIdentity",
        jsii_struct_bases=[],
        name_mapping={
            "access_key_id": "accessKeyId",
            "account_id": "accountId",
            "arn": "arn",
            "invoked_by": "invokedBy",
            "principal_id": "principalId",
            "session_context": "sessionContext",
            "type": "type",
        },
    )
    class UserIdentity:
        def __init__(
            self,
            *,
            access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
            principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            session_context: typing.Optional[typing.Union["AWSAPICallViaCloudTrail.SessionContext", typing.Dict[builtins.str, typing.Any]]] = None,
            type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for UserIdentity.

            :param access_key_id: (experimental) accessKeyId property. Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param account_id: (experimental) accountId property. Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param invoked_by: (experimental) invokedBy property. Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param principal_id: (experimental) principalId property. Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param session_context: (experimental) sessionContext property. Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param type: (experimental) type property. Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                user_identity = sagemaker_events.AWSAPICallViaCloudTrail.UserIdentity(
                    access_key_id=["accessKeyId"],
                    account_id=["accountId"],
                    arn=["arn"],
                    invoked_by=["invokedBy"],
                    principal_id=["principalId"],
                    session_context=sagemaker_events.AWSAPICallViaCloudTrail.SessionContext(
                        attributes=sagemaker_events.AWSAPICallViaCloudTrail.Attributes(
                            creation_date=["creationDate"],
                            mfa_authenticated=["mfaAuthenticated"]
                        ),
                        session_issuer=sagemaker_events.AWSAPICallViaCloudTrail.SessionIssuer(
                            account_id=["accountId"],
                            arn=["arn"],
                            principal_id=["principalId"],
                            type=["type"],
                            user_name=["userName"]
                        ),
                        web_id_federation_data=["webIdFederationData"]
                    ),
                    type=["type"]
                )
            '''
            if isinstance(session_context, dict):
                session_context = AWSAPICallViaCloudTrail.SessionContext(**session_context)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__24dc7f523f5804a8c36c95d281c42b6019fddcd7fa2024e08e774ceddc6eaa42)
                check_type(argname="argument access_key_id", value=access_key_id, expected_type=type_hints["access_key_id"])
                check_type(argname="argument account_id", value=account_id, expected_type=type_hints["account_id"])
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
                check_type(argname="argument invoked_by", value=invoked_by, expected_type=type_hints["invoked_by"])
                check_type(argname="argument principal_id", value=principal_id, expected_type=type_hints["principal_id"])
                check_type(argname="argument session_context", value=session_context, expected_type=type_hints["session_context"])
                check_type(argname="argument type", value=type, expected_type=type_hints["type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if access_key_id is not None:
                self._values["access_key_id"] = access_key_id
            if account_id is not None:
                self._values["account_id"] = account_id
            if arn is not None:
                self._values["arn"] = arn
            if invoked_by is not None:
                self._values["invoked_by"] = invoked_by
            if principal_id is not None:
                self._values["principal_id"] = principal_id
            if session_context is not None:
                self._values["session_context"] = session_context
            if type is not None:
                self._values["type"] = type

        @builtins.property
        def access_key_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accessKeyId property.

            Specify an array of string values to match this event if the actual value of accessKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("access_key_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def account_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) accountId property.

            Specify an array of string values to match this event if the actual value of accountId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("account_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def invoked_by(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) invokedBy property.

            Specify an array of string values to match this event if the actual value of invokedBy is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("invoked_by")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def principal_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) principalId property.

            Specify an array of string values to match this event if the actual value of principalId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("principal_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def session_context(
            self,
        ) -> typing.Optional["AWSAPICallViaCloudTrail.SessionContext"]:
            '''(experimental) sessionContext property.

            Specify an array of string values to match this event if the actual value of sessionContext is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("session_context")
            return typing.cast(typing.Optional["AWSAPICallViaCloudTrail.SessionContext"], result)

        @builtins.property
        def type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) type property.

            Specify an array of string values to match this event if the actual value of type is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "UserIdentity(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class EndpointConfigEvents(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.EndpointConfigEvents",
):
    '''(experimental) EventBridge event patterns for EndpointConfig.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        from aws_cdk.interfaces import aws_sagemaker as interfaces_sagemaker
        
        # endpoint_config_ref: interfaces_sagemaker.IEndpointConfigRef
        
        endpoint_config_events = sagemaker_events.EndpointConfigEvents.from_endpoint_config(endpoint_config_ref)
    '''

    @jsii.member(jsii_name="fromEndpointConfig")
    @builtins.classmethod
    def from_endpoint_config(
        cls,
        endpoint_config_ref: "_aws_cdk_interfaces_aws_sagemaker_ceddda9d.IEndpointConfigRef",
    ) -> "EndpointConfigEvents":
        '''(experimental) Create EndpointConfigEvents from a EndpointConfig reference.

        :param endpoint_config_ref: -

        :stability: experimental
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__89bc78d1a42c6f2ff82f20a6a7795085c79302c38cfa5dd975930ba03b128982)
            check_type(argname="argument endpoint_config_ref", value=endpoint_config_ref, expected_type=type_hints["endpoint_config_ref"])
        return typing.cast("EndpointConfigEvents", jsii.sinvoke(cls, "fromEndpointConfig", [endpoint_config_ref]))

    @jsii.member(jsii_name="sageMakerEndpointConfigStateChangePattern")
    def sage_maker_endpoint_config_state_change_pattern(
        self,
        *,
        creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        endpoint_config_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        endpoint_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        production_variants: typing.Optional[typing.Sequence[typing.Union["SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        tags: typing.Optional[typing.Sequence[typing.Union["SageMakerEndpointConfigStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for EndpointConfig SageMaker Endpoint Config State Change.

        :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param endpoint_config_arn: (experimental) EndpointConfigArn property. Specify an array of string values to match this event if the actual value of EndpointConfigArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param endpoint_config_name: (experimental) EndpointConfigName property. Specify an array of string values to match this event if the actual value of EndpointConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the EndpointConfig reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param production_variants: (experimental) ProductionVariants property. Specify an array of string values to match this event if the actual value of ProductionVariants is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeProps(
            creation_time=creation_time,
            endpoint_config_arn=endpoint_config_arn,
            endpoint_config_name=endpoint_config_name,
            event_metadata=event_metadata,
            production_variants=production_variants,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.invoke(self, "sageMakerEndpointConfigStateChangePattern", [options]))


class SageMakerAlgorithmStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerAlgorithmStateChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerAlgorithmStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_algorithm_state_change = sagemaker_events.SageMakerAlgorithmStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        algorithm_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        algorithm_description: typing.Optional[typing.Sequence[builtins.str]] = None,
        algorithm_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        certify_for_marketplace: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        tags: typing.Optional[typing.Sequence[typing.Union["SageMakerAlgorithmStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker Algorithm State Change.

        :param algorithm_arn: (experimental) AlgorithmArn property. Specify an array of string values to match this event if the actual value of AlgorithmArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param algorithm_description: (experimental) AlgorithmDescription property. Specify an array of string values to match this event if the actual value of AlgorithmDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param algorithm_name: (experimental) AlgorithmName property. Specify an array of string values to match this event if the actual value of AlgorithmName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param certify_for_marketplace: (experimental) CertifyForMarketplace property. Specify an array of string values to match this event if the actual value of CertifyForMarketplace is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerAlgorithmStateChange.SageMakerAlgorithmStateChangeProps(
            algorithm_arn=algorithm_arn,
            algorithm_description=algorithm_description,
            algorithm_name=algorithm_name,
            certify_for_marketplace=certify_for_marketplace,
            event_metadata=event_metadata,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerAlgorithmStateChange.SageMakerAlgorithmStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "algorithm_arn": "algorithmArn",
            "algorithm_description": "algorithmDescription",
            "algorithm_name": "algorithmName",
            "certify_for_marketplace": "certifyForMarketplace",
            "event_metadata": "eventMetadata",
            "tags": "tags",
        },
    )
    class SageMakerAlgorithmStateChangeProps:
        def __init__(
            self,
            *,
            algorithm_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            algorithm_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            algorithm_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            certify_for_marketplace: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["SageMakerAlgorithmStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerAlgorithmStateChange event.

            :param algorithm_arn: (experimental) AlgorithmArn property. Specify an array of string values to match this event if the actual value of AlgorithmArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param algorithm_description: (experimental) AlgorithmDescription property. Specify an array of string values to match this event if the actual value of AlgorithmDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param algorithm_name: (experimental) AlgorithmName property. Specify an array of string values to match this event if the actual value of AlgorithmName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param certify_for_marketplace: (experimental) CertifyForMarketplace property. Specify an array of string values to match this event if the actual value of CertifyForMarketplace is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_algorithm_state_change_props = sagemaker_events.SageMakerAlgorithmStateChange.SageMakerAlgorithmStateChangeProps(
                    algorithm_arn=["algorithmArn"],
                    algorithm_description=["algorithmDescription"],
                    algorithm_name=["algorithmName"],
                    certify_for_marketplace=["certifyForMarketplace"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    tags=[sagemaker_events.SageMakerAlgorithmStateChange.Tags(
                        key=["key"],
                        value=["value"]
                    )]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e18690949b97ed59f68bcfd18dd8b27df0891d270b8f1430e9e16b1d219be7d4)
                check_type(argname="argument algorithm_arn", value=algorithm_arn, expected_type=type_hints["algorithm_arn"])
                check_type(argname="argument algorithm_description", value=algorithm_description, expected_type=type_hints["algorithm_description"])
                check_type(argname="argument algorithm_name", value=algorithm_name, expected_type=type_hints["algorithm_name"])
                check_type(argname="argument certify_for_marketplace", value=certify_for_marketplace, expected_type=type_hints["certify_for_marketplace"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if algorithm_arn is not None:
                self._values["algorithm_arn"] = algorithm_arn
            if algorithm_description is not None:
                self._values["algorithm_description"] = algorithm_description
            if algorithm_name is not None:
                self._values["algorithm_name"] = algorithm_name
            if certify_for_marketplace is not None:
                self._values["certify_for_marketplace"] = certify_for_marketplace
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def algorithm_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AlgorithmArn property.

            Specify an array of string values to match this event if the actual value of AlgorithmArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("algorithm_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def algorithm_description(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AlgorithmDescription property.

            Specify an array of string values to match this event if the actual value of AlgorithmDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("algorithm_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def algorithm_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AlgorithmName property.

            Specify an array of string values to match this event if the actual value of AlgorithmName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("algorithm_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def certify_for_marketplace(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CertifyForMarketplace property.

            Specify an array of string values to match this event if the actual value of CertifyForMarketplace is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("certify_for_marketplace")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["SageMakerAlgorithmStateChange.Tags"]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["SageMakerAlgorithmStateChange.Tags"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerAlgorithmStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerAlgorithmStateChange.Tags",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class Tags:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tags.

            :param key: (experimental) Key property. Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) Value property. Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                tags = sagemaker_events.SageMakerAlgorithmStateChange.Tags(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__2f1ef0e3299265996888fa7238d33feba339cfe0d221250992d481a1bdb438f9)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Key property.

            Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Value property.

            Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Tags(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SageMakerEndpointConfigStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerEndpointConfigStateChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerEndpointConfigStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_endpoint_config_state_change = sagemaker_events.SageMakerEndpointConfigStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        endpoint_config_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        endpoint_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        production_variants: typing.Optional[typing.Sequence[typing.Union["SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        tags: typing.Optional[typing.Sequence[typing.Union["SageMakerEndpointConfigStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker Endpoint Config State Change.

        :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param endpoint_config_arn: (experimental) EndpointConfigArn property. Specify an array of string values to match this event if the actual value of EndpointConfigArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param endpoint_config_name: (experimental) EndpointConfigName property. Specify an array of string values to match this event if the actual value of EndpointConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the EndpointConfig reference
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param production_variants: (experimental) ProductionVariants property. Specify an array of string values to match this event if the actual value of ProductionVariants is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeProps(
            creation_time=creation_time,
            endpoint_config_arn=endpoint_config_arn,
            endpoint_config_name=endpoint_config_name,
            event_metadata=event_metadata,
            production_variants=production_variants,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeItem",
        jsii_struct_bases=[],
        name_mapping={
            "initial_instance_count": "initialInstanceCount",
            "initial_variant_weight": "initialVariantWeight",
            "instance_type": "instanceType",
            "model_name": "modelName",
            "variant_name": "variantName",
        },
    )
    class SageMakerEndpointConfigStateChangeItem:
        def __init__(
            self,
            *,
            initial_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            initial_variant_weight: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            model_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            variant_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SageMakerEndpointConfigStateChangeItem.

            :param initial_instance_count: (experimental) InitialInstanceCount property. Specify an array of string values to match this event if the actual value of InitialInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param initial_variant_weight: (experimental) InitialVariantWeight property. Specify an array of string values to match this event if the actual value of InitialVariantWeight is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) InstanceType property. Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param model_name: (experimental) ModelName property. Specify an array of string values to match this event if the actual value of ModelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param variant_name: (experimental) VariantName property. Specify an array of string values to match this event if the actual value of VariantName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_endpoint_config_state_change_item = sagemaker_events.SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeItem(
                    initial_instance_count=["initialInstanceCount"],
                    initial_variant_weight=["initialVariantWeight"],
                    instance_type=["instanceType"],
                    model_name=["modelName"],
                    variant_name=["variantName"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ec6a44dafc80f6ec02d3881f92f1baebaf27bb49a168abec7898390a992962aa)
                check_type(argname="argument initial_instance_count", value=initial_instance_count, expected_type=type_hints["initial_instance_count"])
                check_type(argname="argument initial_variant_weight", value=initial_variant_weight, expected_type=type_hints["initial_variant_weight"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument model_name", value=model_name, expected_type=type_hints["model_name"])
                check_type(argname="argument variant_name", value=variant_name, expected_type=type_hints["variant_name"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if initial_instance_count is not None:
                self._values["initial_instance_count"] = initial_instance_count
            if initial_variant_weight is not None:
                self._values["initial_variant_weight"] = initial_variant_weight
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if model_name is not None:
                self._values["model_name"] = model_name
            if variant_name is not None:
                self._values["variant_name"] = variant_name

        @builtins.property
        def initial_instance_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InitialInstanceCount property.

            Specify an array of string values to match this event if the actual value of InitialInstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("initial_instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def initial_variant_weight(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InitialVariantWeight property.

            Specify an array of string values to match this event if the actual value of InitialVariantWeight is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("initial_variant_weight")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstanceType property.

            Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def model_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ModelName property.

            Specify an array of string values to match this event if the actual value of ModelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def variant_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) VariantName property.

            Specify an array of string values to match this event if the actual value of VariantName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("variant_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerEndpointConfigStateChangeItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "creation_time": "creationTime",
            "endpoint_config_arn": "endpointConfigArn",
            "endpoint_config_name": "endpointConfigName",
            "event_metadata": "eventMetadata",
            "production_variants": "productionVariants",
            "tags": "tags",
        },
    )
    class SageMakerEndpointConfigStateChangeProps:
        def __init__(
            self,
            *,
            creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            endpoint_config_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            endpoint_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            production_variants: typing.Optional[typing.Sequence[typing.Union["SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["SageMakerEndpointConfigStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerEndpointConfigStateChange event.

            :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param endpoint_config_arn: (experimental) EndpointConfigArn property. Specify an array of string values to match this event if the actual value of EndpointConfigArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param endpoint_config_name: (experimental) EndpointConfigName property. Specify an array of string values to match this event if the actual value of EndpointConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Filter with the EndpointConfig reference
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param production_variants: (experimental) ProductionVariants property. Specify an array of string values to match this event if the actual value of ProductionVariants is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_endpoint_config_state_change_props = sagemaker_events.SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeProps(
                    creation_time=["creationTime"],
                    endpoint_config_arn=["endpointConfigArn"],
                    endpoint_config_name=["endpointConfigName"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    production_variants=[sagemaker_events.SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeItem(
                        initial_instance_count=["initialInstanceCount"],
                        initial_variant_weight=["initialVariantWeight"],
                        instance_type=["instanceType"],
                        model_name=["modelName"],
                        variant_name=["variantName"]
                    )],
                    tags=[sagemaker_events.SageMakerEndpointConfigStateChange.Tags(
                        key=["key"],
                        value=["value"]
                    )]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f0ee228586d3c2c5114b8b787db51f818c9764bf6e113ae001eb44278cda69da)
                check_type(argname="argument creation_time", value=creation_time, expected_type=type_hints["creation_time"])
                check_type(argname="argument endpoint_config_arn", value=endpoint_config_arn, expected_type=type_hints["endpoint_config_arn"])
                check_type(argname="argument endpoint_config_name", value=endpoint_config_name, expected_type=type_hints["endpoint_config_name"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument production_variants", value=production_variants, expected_type=type_hints["production_variants"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_time is not None:
                self._values["creation_time"] = creation_time
            if endpoint_config_arn is not None:
                self._values["endpoint_config_arn"] = endpoint_config_arn
            if endpoint_config_name is not None:
                self._values["endpoint_config_name"] = endpoint_config_name
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if production_variants is not None:
                self._values["production_variants"] = production_variants
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def creation_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CreationTime property.

            Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def endpoint_config_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EndpointConfigArn property.

            Specify an array of string values to match this event if the actual value of EndpointConfigArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("endpoint_config_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def endpoint_config_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EndpointConfigName property.

            Specify an array of string values to match this event if the actual value of EndpointConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Filter with the EndpointConfig reference

            :stability: experimental
            '''
            result = self._values.get("endpoint_config_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def production_variants(
            self,
        ) -> typing.Optional[typing.List["SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeItem"]]:
            '''(experimental) ProductionVariants property.

            Specify an array of string values to match this event if the actual value of ProductionVariants is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("production_variants")
            return typing.cast(typing.Optional[typing.List["SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeItem"]], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["SageMakerEndpointConfigStateChange.Tags"]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["SageMakerEndpointConfigStateChange.Tags"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerEndpointConfigStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerEndpointConfigStateChange.Tags",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class Tags:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tags.

            :param key: (experimental) Key property. Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) Value property. Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                tags = sagemaker_events.SageMakerEndpointConfigStateChange.Tags(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4083165630fcd44580fd87a930e9ad34cff2d57a3fbebe71dc8a86297c4aeda8)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Key property.

            Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Value property.

            Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Tags(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SageMakerEndpointStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerEndpointStateChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerEndpointStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_endpoint_state_change = sagemaker_events.SageMakerEndpointStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        endpoint_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        endpoint_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        endpoint_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        endpoint_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        tags: typing.Optional[typing.Sequence[typing.Union["SageMakerEndpointStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker Endpoint State Change.

        :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param endpoint_arn: (experimental) EndpointArn property. Specify an array of string values to match this event if the actual value of EndpointArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param endpoint_config_name: (experimental) EndpointConfigName property. Specify an array of string values to match this event if the actual value of EndpointConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param endpoint_name: (experimental) EndpointName property. Specify an array of string values to match this event if the actual value of EndpointName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param endpoint_status: (experimental) EndpointStatus property. Specify an array of string values to match this event if the actual value of EndpointStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param last_modified_time: (experimental) LastModifiedTime property. Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerEndpointStateChange.SageMakerEndpointStateChangeProps(
            creation_time=creation_time,
            endpoint_arn=endpoint_arn,
            endpoint_config_name=endpoint_config_name,
            endpoint_name=endpoint_name,
            endpoint_status=endpoint_status,
            event_metadata=event_metadata,
            last_modified_time=last_modified_time,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerEndpointStateChange.SageMakerEndpointStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "creation_time": "creationTime",
            "endpoint_arn": "endpointArn",
            "endpoint_config_name": "endpointConfigName",
            "endpoint_name": "endpointName",
            "endpoint_status": "endpointStatus",
            "event_metadata": "eventMetadata",
            "last_modified_time": "lastModifiedTime",
            "tags": "tags",
        },
    )
    class SageMakerEndpointStateChangeProps:
        def __init__(
            self,
            *,
            creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            endpoint_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            endpoint_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            endpoint_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            endpoint_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["SageMakerEndpointStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerEndpointStateChange event.

            :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param endpoint_arn: (experimental) EndpointArn property. Specify an array of string values to match this event if the actual value of EndpointArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param endpoint_config_name: (experimental) EndpointConfigName property. Specify an array of string values to match this event if the actual value of EndpointConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param endpoint_name: (experimental) EndpointName property. Specify an array of string values to match this event if the actual value of EndpointName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param endpoint_status: (experimental) EndpointStatus property. Specify an array of string values to match this event if the actual value of EndpointStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param last_modified_time: (experimental) LastModifiedTime property. Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_endpoint_state_change_props = sagemaker_events.SageMakerEndpointStateChange.SageMakerEndpointStateChangeProps(
                    creation_time=["creationTime"],
                    endpoint_arn=["endpointArn"],
                    endpoint_config_name=["endpointConfigName"],
                    endpoint_name=["endpointName"],
                    endpoint_status=["endpointStatus"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    last_modified_time=["lastModifiedTime"],
                    tags=[sagemaker_events.SageMakerEndpointStateChange.Tags(
                        key=["key"],
                        value=["value"]
                    )]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ae0398ffa625c97ca91ee51c348b1fa40709707fa0f041d22e8da85aeebabf91)
                check_type(argname="argument creation_time", value=creation_time, expected_type=type_hints["creation_time"])
                check_type(argname="argument endpoint_arn", value=endpoint_arn, expected_type=type_hints["endpoint_arn"])
                check_type(argname="argument endpoint_config_name", value=endpoint_config_name, expected_type=type_hints["endpoint_config_name"])
                check_type(argname="argument endpoint_name", value=endpoint_name, expected_type=type_hints["endpoint_name"])
                check_type(argname="argument endpoint_status", value=endpoint_status, expected_type=type_hints["endpoint_status"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument last_modified_time", value=last_modified_time, expected_type=type_hints["last_modified_time"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_time is not None:
                self._values["creation_time"] = creation_time
            if endpoint_arn is not None:
                self._values["endpoint_arn"] = endpoint_arn
            if endpoint_config_name is not None:
                self._values["endpoint_config_name"] = endpoint_config_name
            if endpoint_name is not None:
                self._values["endpoint_name"] = endpoint_name
            if endpoint_status is not None:
                self._values["endpoint_status"] = endpoint_status
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if last_modified_time is not None:
                self._values["last_modified_time"] = last_modified_time
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def creation_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CreationTime property.

            Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def endpoint_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EndpointArn property.

            Specify an array of string values to match this event if the actual value of EndpointArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("endpoint_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def endpoint_config_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EndpointConfigName property.

            Specify an array of string values to match this event if the actual value of EndpointConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("endpoint_config_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def endpoint_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EndpointName property.

            Specify an array of string values to match this event if the actual value of EndpointName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("endpoint_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def endpoint_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) EndpointStatus property.

            Specify an array of string values to match this event if the actual value of EndpointStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("endpoint_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def last_modified_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LastModifiedTime property.

            Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_modified_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["SageMakerEndpointStateChange.Tags"]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["SageMakerEndpointStateChange.Tags"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerEndpointStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerEndpointStateChange.Tags",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class Tags:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tags.

            :param key: (experimental) Key property. Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) Value property. Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                tags = sagemaker_events.SageMakerEndpointStateChange.Tags(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1766d224b589f890d657321901c78a8e61db549aaf96bcd478a04bbcd0af0745)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Key property.

            Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Value property.

            Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Tags(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SageMakerGroundTruthLabelingJobTaskStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerGroundTruthLabelingJobTaskStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerGroundTruthLabelingJobTaskStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_ground_truth_labeling_job_task_status_change = sagemaker_events.SageMakerGroundTruthLabelingJobTaskStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        labeling_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        state: typing.Optional[typing.Sequence[builtins.str]] = None,
        workteam_team_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker Ground Truth Labeling Job Task Status Change.

        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param labeling_job_arn: (experimental) labeling-job-arn property. Specify an array of string values to match this event if the actual value of labeling-job-arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param state: (experimental) State property. Specify an array of string values to match this event if the actual value of State is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param workteam_team_arn: (experimental) workteam-team-arn property. Specify an array of string values to match this event if the actual value of workteam-team-arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerGroundTruthLabelingJobTaskStatusChange.SageMakerGroundTruthLabelingJobTaskStatusChangeProps(
            event_metadata=event_metadata,
            labeling_job_arn=labeling_job_arn,
            state=state,
            workteam_team_arn=workteam_team_arn,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerGroundTruthLabelingJobTaskStatusChange.SageMakerGroundTruthLabelingJobTaskStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "event_metadata": "eventMetadata",
            "labeling_job_arn": "labelingJobArn",
            "state": "state",
            "workteam_team_arn": "workteamTeamArn",
        },
    )
    class SageMakerGroundTruthLabelingJobTaskStatusChangeProps:
        def __init__(
            self,
            *,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            labeling_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            state: typing.Optional[typing.Sequence[builtins.str]] = None,
            workteam_team_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerGroundTruthLabelingJobTaskStatusChange event.

            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param labeling_job_arn: (experimental) labeling-job-arn property. Specify an array of string values to match this event if the actual value of labeling-job-arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param state: (experimental) State property. Specify an array of string values to match this event if the actual value of State is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param workteam_team_arn: (experimental) workteam-team-arn property. Specify an array of string values to match this event if the actual value of workteam-team-arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_ground_truth_labeling_job_task_status_change_props = sagemaker_events.SageMakerGroundTruthLabelingJobTaskStatusChange.SageMakerGroundTruthLabelingJobTaskStatusChangeProps(
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    labeling_job_arn=["labelingJobArn"],
                    state=["state"],
                    workteam_team_arn=["workteamTeamArn"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8bd2457ad1aef32425fb7763b97bbb115ce3a6321b17abcd77c1a9bbbb3f9692)
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument labeling_job_arn", value=labeling_job_arn, expected_type=type_hints["labeling_job_arn"])
                check_type(argname="argument state", value=state, expected_type=type_hints["state"])
                check_type(argname="argument workteam_team_arn", value=workteam_team_arn, expected_type=type_hints["workteam_team_arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if labeling_job_arn is not None:
                self._values["labeling_job_arn"] = labeling_job_arn
            if state is not None:
                self._values["state"] = state
            if workteam_team_arn is not None:
                self._values["workteam_team_arn"] = workteam_team_arn

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def labeling_job_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) labeling-job-arn property.

            Specify an array of string values to match this event if the actual value of labeling-job-arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("labeling_job_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def state(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) State property.

            Specify an array of string values to match this event if the actual value of State is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("state")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def workteam_team_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) workteam-team-arn property.

            Specify an array of string values to match this event if the actual value of workteam-team-arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("workteam_team_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerGroundTruthLabelingJobTaskStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SageMakerHyperParameterTuningJobStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerHyperParameterTuningJobStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_hyper_parameter_tuning_job_state_change = sagemaker_events.SageMakerHyperParameterTuningJobStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        hyper_parameter_tuning_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        hyper_parameter_tuning_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        hyper_parameter_tuning_job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        objective_status_counters: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.ObjectiveStatusCounters", typing.Dict[builtins.str, typing.Any]]] = None,
        tags: typing.Optional[typing.Sequence[typing.Union["SageMakerHyperParameterTuningJobStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
        training_job_definition: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinition", typing.Dict[builtins.str, typing.Any]]] = None,
        training_job_status_counters: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.TrainingJobStatusCounters", typing.Dict[builtins.str, typing.Any]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker HyperParameter Tuning Job State Change.

        :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param hyper_parameter_tuning_job_arn: (experimental) HyperParameterTuningJobArn property. Specify an array of string values to match this event if the actual value of HyperParameterTuningJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param hyper_parameter_tuning_job_name: (experimental) HyperParameterTuningJobName property. Specify an array of string values to match this event if the actual value of HyperParameterTuningJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param hyper_parameter_tuning_job_status: (experimental) HyperParameterTuningJobStatus property. Specify an array of string values to match this event if the actual value of HyperParameterTuningJobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param last_modified_time: (experimental) LastModifiedTime property. Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param objective_status_counters: (experimental) ObjectiveStatusCounters property. Specify an array of string values to match this event if the actual value of ObjectiveStatusCounters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param training_job_definition: (experimental) TrainingJobDefinition property. Specify an array of string values to match this event if the actual value of TrainingJobDefinition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param training_job_status_counters: (experimental) TrainingJobStatusCounters property. Specify an array of string values to match this event if the actual value of TrainingJobStatusCounters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerHyperParameterTuningJobStateChange.SageMakerHyperParameterTuningJobStateChangeProps(
            creation_time=creation_time,
            event_metadata=event_metadata,
            hyper_parameter_tuning_job_arn=hyper_parameter_tuning_job_arn,
            hyper_parameter_tuning_job_name=hyper_parameter_tuning_job_name,
            hyper_parameter_tuning_job_status=hyper_parameter_tuning_job_status,
            last_modified_time=last_modified_time,
            objective_status_counters=objective_status_counters,
            tags=tags,
            training_job_definition=training_job_definition,
            training_job_status_counters=training_job_status_counters,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecification",
        jsii_struct_bases=[],
        name_mapping={
            "metric_definitions": "metricDefinitions",
            "training_image": "trainingImage",
            "training_input_mode": "trainingInputMode",
        },
    )
    class AlgorithmSpecification:
        def __init__(
            self,
            *,
            metric_definitions: typing.Optional[typing.Sequence[typing.Union["SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecificationItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            training_image: typing.Optional[typing.Sequence[builtins.str]] = None,
            training_input_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AlgorithmSpecification.

            :param metric_definitions: (experimental) MetricDefinitions property. Specify an array of string values to match this event if the actual value of MetricDefinitions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_image: (experimental) TrainingImage property. Specify an array of string values to match this event if the actual value of TrainingImage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_input_mode: (experimental) TrainingInputMode property. Specify an array of string values to match this event if the actual value of TrainingInputMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                algorithm_specification = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecification(
                    metric_definitions=[sagemaker_events.SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecificationItem(
                        name=["name"],
                        regex=["regex"]
                    )],
                    training_image=["trainingImage"],
                    training_input_mode=["trainingInputMode"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__d90257762f2e3f325a976e6052e6403bef9eafa5307d4c5f8caab4c5e32e876f)
                check_type(argname="argument metric_definitions", value=metric_definitions, expected_type=type_hints["metric_definitions"])
                check_type(argname="argument training_image", value=training_image, expected_type=type_hints["training_image"])
                check_type(argname="argument training_input_mode", value=training_input_mode, expected_type=type_hints["training_input_mode"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if metric_definitions is not None:
                self._values["metric_definitions"] = metric_definitions
            if training_image is not None:
                self._values["training_image"] = training_image
            if training_input_mode is not None:
                self._values["training_input_mode"] = training_input_mode

        @builtins.property
        def metric_definitions(
            self,
        ) -> typing.Optional[typing.List["SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecificationItem"]]:
            '''(experimental) MetricDefinitions property.

            Specify an array of string values to match this event if the actual value of MetricDefinitions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metric_definitions")
            return typing.cast(typing.Optional[typing.List["SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecificationItem"]], result)

        @builtins.property
        def training_image(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TrainingImage property.

            Specify an array of string values to match this event if the actual value of TrainingImage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_image")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def training_input_mode(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TrainingInputMode property.

            Specify an array of string values to match this event if the actual value of TrainingInputMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_input_mode")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AlgorithmSpecification(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecificationItem",
        jsii_struct_bases=[],
        name_mapping={"name": "name", "regex": "regex"},
    )
    class AlgorithmSpecificationItem:
        def __init__(
            self,
            *,
            name: typing.Optional[typing.Sequence[builtins.str]] = None,
            regex: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AlgorithmSpecificationItem.

            :param name: (experimental) Name property. Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param regex: (experimental) Regex property. Specify an array of string values to match this event if the actual value of Regex is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                algorithm_specification_item = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecificationItem(
                    name=["name"],
                    regex=["regex"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__441c33e42a23b726860151dcf9b8e92cde2042dad691d796dac9ed2982bc981b)
                check_type(argname="argument name", value=name, expected_type=type_hints["name"])
                check_type(argname="argument regex", value=regex, expected_type=type_hints["regex"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if name is not None:
                self._values["name"] = name
            if regex is not None:
                self._values["regex"] = regex

        @builtins.property
        def name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Name property.

            Specify an array of string values to match this event if the actual value of Name is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def regex(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Regex property.

            Specify an array of string values to match this event if the actual value of Regex is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("regex")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AlgorithmSpecificationItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.DataSource",
        jsii_struct_bases=[],
        name_mapping={"s3_data_source": "s3DataSource"},
    )
    class DataSource:
        def __init__(
            self,
            *,
            s3_data_source: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.S3DataSource", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for DataSource.

            :param s3_data_source: (experimental) S3DataSource property. Specify an array of string values to match this event if the actual value of S3DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                data_source = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.DataSource(
                    s3_data_source=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.S3DataSource(
                        s3_data_distribution_type=["s3DataDistributionType"],
                        s3_data_type=["s3DataType"],
                        s3_uri=["s3Uri"]
                    )
                )
            '''
            if isinstance(s3_data_source, dict):
                s3_data_source = SageMakerHyperParameterTuningJobStateChange.S3DataSource(**s3_data_source)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f27f5e3ff903e36e338c42f0f84365985ac94c44019fc31c1568e4653c631124)
                check_type(argname="argument s3_data_source", value=s3_data_source, expected_type=type_hints["s3_data_source"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_data_source is not None:
                self._values["s3_data_source"] = s3_data_source

        @builtins.property
        def s3_data_source(
            self,
        ) -> typing.Optional["SageMakerHyperParameterTuningJobStateChange.S3DataSource"]:
            '''(experimental) S3DataSource property.

            Specify an array of string values to match this event if the actual value of S3DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_source")
            return typing.cast(typing.Optional["SageMakerHyperParameterTuningJobStateChange.S3DataSource"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataSource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.ObjectiveStatusCounters",
        jsii_struct_bases=[],
        name_mapping={
            "failed": "failed",
            "pending": "pending",
            "succeeded": "succeeded",
        },
    )
    class ObjectiveStatusCounters:
        def __init__(
            self,
            *,
            failed: typing.Optional[typing.Sequence[builtins.str]] = None,
            pending: typing.Optional[typing.Sequence[builtins.str]] = None,
            succeeded: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ObjectiveStatusCounters.

            :param failed: (experimental) Failed property. Specify an array of string values to match this event if the actual value of Failed is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pending: (experimental) Pending property. Specify an array of string values to match this event if the actual value of Pending is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param succeeded: (experimental) Succeeded property. Specify an array of string values to match this event if the actual value of Succeeded is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                objective_status_counters = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.ObjectiveStatusCounters(
                    failed=["failed"],
                    pending=["pending"],
                    succeeded=["succeeded"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__dabbd9a55dc39c7dc7286eda156f6e88d913685f7e111c242207a538346820b9)
                check_type(argname="argument failed", value=failed, expected_type=type_hints["failed"])
                check_type(argname="argument pending", value=pending, expected_type=type_hints["pending"])
                check_type(argname="argument succeeded", value=succeeded, expected_type=type_hints["succeeded"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if failed is not None:
                self._values["failed"] = failed
            if pending is not None:
                self._values["pending"] = pending
            if succeeded is not None:
                self._values["succeeded"] = succeeded

        @builtins.property
        def failed(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Failed property.

            Specify an array of string values to match this event if the actual value of Failed is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("failed")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pending(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Pending property.

            Specify an array of string values to match this event if the actual value of Pending is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pending")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def succeeded(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Succeeded property.

            Specify an array of string values to match this event if the actual value of Succeeded is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("succeeded")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ObjectiveStatusCounters(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.OutputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"kms_key_id": "kmsKeyId", "s3_output_path": "s3OutputPath"},
    )
    class OutputDataConfig:
        def __init__(
            self,
            *,
            kms_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_output_path: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for OutputDataConfig.

            :param kms_key_id: (experimental) KmsKeyId property. Specify an array of string values to match this event if the actual value of KmsKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_output_path: (experimental) S3OutputPath property. Specify an array of string values to match this event if the actual value of S3OutputPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                output_data_config = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.OutputDataConfig(
                    kms_key_id=["kmsKeyId"],
                    s3_output_path=["s3OutputPath"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__26c46152736bba524349a7f3afe155a619a44ed686a3c288dec10ff1e0edf778)
                check_type(argname="argument kms_key_id", value=kms_key_id, expected_type=type_hints["kms_key_id"])
                check_type(argname="argument s3_output_path", value=s3_output_path, expected_type=type_hints["s3_output_path"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if kms_key_id is not None:
                self._values["kms_key_id"] = kms_key_id
            if s3_output_path is not None:
                self._values["s3_output_path"] = s3_output_path

        @builtins.property
        def kms_key_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) KmsKeyId property.

            Specify an array of string values to match this event if the actual value of KmsKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("kms_key_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_output_path(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) S3OutputPath property.

            Specify an array of string values to match this event if the actual value of S3OutputPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_output_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OutputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.ResourceConfig",
        jsii_struct_bases=[],
        name_mapping={
            "instance_count": "instanceCount",
            "instance_type": "instanceType",
            "volume_kms_key_id": "volumeKmsKeyId",
            "volume_size_in_gb": "volumeSizeInGb",
        },
    )
    class ResourceConfig:
        def __init__(
            self,
            *,
            instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            volume_kms_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            volume_size_in_gb: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResourceConfig.

            :param instance_count: (experimental) InstanceCount property. Specify an array of string values to match this event if the actual value of InstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) InstanceType property. Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param volume_kms_key_id: (experimental) VolumeKmsKeyId property. Specify an array of string values to match this event if the actual value of VolumeKmsKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param volume_size_in_gb: (experimental) VolumeSizeInGB property. Specify an array of string values to match this event if the actual value of VolumeSizeInGB is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                resource_config = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.ResourceConfig(
                    instance_count=["instanceCount"],
                    instance_type=["instanceType"],
                    volume_kms_key_id=["volumeKmsKeyId"],
                    volume_size_in_gb=["volumeSizeInGb"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ff46feb2c32f0fbe1a99dea95a7c111b4fd86d01c23f335037618fc8a950d7cb)
                check_type(argname="argument instance_count", value=instance_count, expected_type=type_hints["instance_count"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument volume_kms_key_id", value=volume_kms_key_id, expected_type=type_hints["volume_kms_key_id"])
                check_type(argname="argument volume_size_in_gb", value=volume_size_in_gb, expected_type=type_hints["volume_size_in_gb"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if instance_count is not None:
                self._values["instance_count"] = instance_count
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if volume_kms_key_id is not None:
                self._values["volume_kms_key_id"] = volume_kms_key_id
            if volume_size_in_gb is not None:
                self._values["volume_size_in_gb"] = volume_size_in_gb

        @builtins.property
        def instance_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstanceCount property.

            Specify an array of string values to match this event if the actual value of InstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstanceType property.

            Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def volume_kms_key_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) VolumeKmsKeyId property.

            Specify an array of string values to match this event if the actual value of VolumeKmsKeyId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("volume_kms_key_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def volume_size_in_gb(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) VolumeSizeInGB property.

            Specify an array of string values to match this event if the actual value of VolumeSizeInGB is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("volume_size_in_gb")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResourceConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.S3DataSource",
        jsii_struct_bases=[],
        name_mapping={
            "s3_data_distribution_type": "s3DataDistributionType",
            "s3_data_type": "s3DataType",
            "s3_uri": "s3Uri",
        },
    )
    class S3DataSource:
        def __init__(
            self,
            *,
            s3_data_distribution_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_data_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for S3DataSource.

            :param s3_data_distribution_type: (experimental) S3DataDistributionType property. Specify an array of string values to match this event if the actual value of S3DataDistributionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_data_type: (experimental) S3DataType property. Specify an array of string values to match this event if the actual value of S3DataType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_uri: (experimental) S3Uri property. Specify an array of string values to match this event if the actual value of S3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                s3_data_source = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.S3DataSource(
                    s3_data_distribution_type=["s3DataDistributionType"],
                    s3_data_type=["s3DataType"],
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f25172725ebecd413dc8e7daa0c5de4f0f2cc4c51f5b1c16f07b1d4b2e450132)
                check_type(argname="argument s3_data_distribution_type", value=s3_data_distribution_type, expected_type=type_hints["s3_data_distribution_type"])
                check_type(argname="argument s3_data_type", value=s3_data_type, expected_type=type_hints["s3_data_type"])
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_data_distribution_type is not None:
                self._values["s3_data_distribution_type"] = s3_data_distribution_type
            if s3_data_type is not None:
                self._values["s3_data_type"] = s3_data_type
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_data_distribution_type(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) S3DataDistributionType property.

            Specify an array of string values to match this event if the actual value of S3DataDistributionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_distribution_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_data_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) S3DataType property.

            Specify an array of string values to match this event if the actual value of S3DataType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) S3Uri property.

            Specify an array of string values to match this event if the actual value of S3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "S3DataSource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.SageMakerHyperParameterTuningJobStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "creation_time": "creationTime",
            "event_metadata": "eventMetadata",
            "hyper_parameter_tuning_job_arn": "hyperParameterTuningJobArn",
            "hyper_parameter_tuning_job_name": "hyperParameterTuningJobName",
            "hyper_parameter_tuning_job_status": "hyperParameterTuningJobStatus",
            "last_modified_time": "lastModifiedTime",
            "objective_status_counters": "objectiveStatusCounters",
            "tags": "tags",
            "training_job_definition": "trainingJobDefinition",
            "training_job_status_counters": "trainingJobStatusCounters",
        },
    )
    class SageMakerHyperParameterTuningJobStateChangeProps:
        def __init__(
            self,
            *,
            creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            hyper_parameter_tuning_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            hyper_parameter_tuning_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            hyper_parameter_tuning_job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            objective_status_counters: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.ObjectiveStatusCounters", typing.Dict[builtins.str, typing.Any]]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["SageMakerHyperParameterTuningJobStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
            training_job_definition: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinition", typing.Dict[builtins.str, typing.Any]]] = None,
            training_job_status_counters: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.TrainingJobStatusCounters", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerHyperParameterTuningJobStateChange event.

            :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param hyper_parameter_tuning_job_arn: (experimental) HyperParameterTuningJobArn property. Specify an array of string values to match this event if the actual value of HyperParameterTuningJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param hyper_parameter_tuning_job_name: (experimental) HyperParameterTuningJobName property. Specify an array of string values to match this event if the actual value of HyperParameterTuningJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param hyper_parameter_tuning_job_status: (experimental) HyperParameterTuningJobStatus property. Specify an array of string values to match this event if the actual value of HyperParameterTuningJobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param last_modified_time: (experimental) LastModifiedTime property. Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param objective_status_counters: (experimental) ObjectiveStatusCounters property. Specify an array of string values to match this event if the actual value of ObjectiveStatusCounters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_job_definition: (experimental) TrainingJobDefinition property. Specify an array of string values to match this event if the actual value of TrainingJobDefinition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_job_status_counters: (experimental) TrainingJobStatusCounters property. Specify an array of string values to match this event if the actual value of TrainingJobStatusCounters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_hyper_parameter_tuning_job_state_change_props = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.SageMakerHyperParameterTuningJobStateChangeProps(
                    creation_time=["creationTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    hyper_parameter_tuning_job_arn=["hyperParameterTuningJobArn"],
                    hyper_parameter_tuning_job_name=["hyperParameterTuningJobName"],
                    hyper_parameter_tuning_job_status=["hyperParameterTuningJobStatus"],
                    last_modified_time=["lastModifiedTime"],
                    objective_status_counters=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.ObjectiveStatusCounters(
                        failed=["failed"],
                        pending=["pending"],
                        succeeded=["succeeded"]
                    ),
                    tags=[sagemaker_events.SageMakerHyperParameterTuningJobStateChange.Tags(
                        key=["key"],
                        value=["value"]
                    )],
                    training_job_definition=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinition(
                        algorithm_specification=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecification(
                            metric_definitions=[sagemaker_events.SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecificationItem(
                                name=["name"],
                                regex=["regex"]
                            )],
                            training_image=["trainingImage"],
                            training_input_mode=["trainingInputMode"]
                        ),
                        input_data_config=[sagemaker_events.SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinitionItem(
                            channel_name=["channelName"],
                            compression_type=["compressionType"],
                            content_type=["contentType"],
                            data_source=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.DataSource(
                                s3_data_source=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.S3DataSource(
                                    s3_data_distribution_type=["s3DataDistributionType"],
                                    s3_data_type=["s3DataType"],
                                    s3_uri=["s3Uri"]
                                )
                            ),
                            record_wrapper_type=["recordWrapperType"]
                        )],
                        output_data_config=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.OutputDataConfig(
                            kms_key_id=["kmsKeyId"],
                            s3_output_path=["s3OutputPath"]
                        ),
                        resource_config=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.ResourceConfig(
                            instance_count=["instanceCount"],
                            instance_type=["instanceType"],
                            volume_kms_key_id=["volumeKmsKeyId"],
                            volume_size_in_gb=["volumeSizeInGb"]
                        ),
                        role_arn=["roleArn"],
                        static_hyper_parameters=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.Tags(
                            key=["key"],
                            value=["value"]
                        ),
                        stopping_condition=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.StoppingCondition(
                            max_runtime_in_seconds=["maxRuntimeInSeconds"]
                        ),
                        vpc_config=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.VpcConfig(
                            security_group_ids=["securityGroupIds"],
                            subnets=["subnets"]
                        )
                    ),
                    training_job_status_counters=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.TrainingJobStatusCounters(
                        completed=["completed"],
                        in_progress=["inProgress"],
                        non_retryable_error=["nonRetryableError"],
                        retryable_error=["retryableError"],
                        stopped=["stopped"]
                    )
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(objective_status_counters, dict):
                objective_status_counters = SageMakerHyperParameterTuningJobStateChange.ObjectiveStatusCounters(**objective_status_counters)
            if isinstance(training_job_definition, dict):
                training_job_definition = SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinition(**training_job_definition)
            if isinstance(training_job_status_counters, dict):
                training_job_status_counters = SageMakerHyperParameterTuningJobStateChange.TrainingJobStatusCounters(**training_job_status_counters)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__47c0e9849b02d493cdbfc592852be40c95ee3a11dfea127af4884d27644c6ec4)
                check_type(argname="argument creation_time", value=creation_time, expected_type=type_hints["creation_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument hyper_parameter_tuning_job_arn", value=hyper_parameter_tuning_job_arn, expected_type=type_hints["hyper_parameter_tuning_job_arn"])
                check_type(argname="argument hyper_parameter_tuning_job_name", value=hyper_parameter_tuning_job_name, expected_type=type_hints["hyper_parameter_tuning_job_name"])
                check_type(argname="argument hyper_parameter_tuning_job_status", value=hyper_parameter_tuning_job_status, expected_type=type_hints["hyper_parameter_tuning_job_status"])
                check_type(argname="argument last_modified_time", value=last_modified_time, expected_type=type_hints["last_modified_time"])
                check_type(argname="argument objective_status_counters", value=objective_status_counters, expected_type=type_hints["objective_status_counters"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
                check_type(argname="argument training_job_definition", value=training_job_definition, expected_type=type_hints["training_job_definition"])
                check_type(argname="argument training_job_status_counters", value=training_job_status_counters, expected_type=type_hints["training_job_status_counters"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_time is not None:
                self._values["creation_time"] = creation_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if hyper_parameter_tuning_job_arn is not None:
                self._values["hyper_parameter_tuning_job_arn"] = hyper_parameter_tuning_job_arn
            if hyper_parameter_tuning_job_name is not None:
                self._values["hyper_parameter_tuning_job_name"] = hyper_parameter_tuning_job_name
            if hyper_parameter_tuning_job_status is not None:
                self._values["hyper_parameter_tuning_job_status"] = hyper_parameter_tuning_job_status
            if last_modified_time is not None:
                self._values["last_modified_time"] = last_modified_time
            if objective_status_counters is not None:
                self._values["objective_status_counters"] = objective_status_counters
            if tags is not None:
                self._values["tags"] = tags
            if training_job_definition is not None:
                self._values["training_job_definition"] = training_job_definition
            if training_job_status_counters is not None:
                self._values["training_job_status_counters"] = training_job_status_counters

        @builtins.property
        def creation_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CreationTime property.

            Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def hyper_parameter_tuning_job_arn(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) HyperParameterTuningJobArn property.

            Specify an array of string values to match this event if the actual value of HyperParameterTuningJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("hyper_parameter_tuning_job_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def hyper_parameter_tuning_job_name(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) HyperParameterTuningJobName property.

            Specify an array of string values to match this event if the actual value of HyperParameterTuningJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("hyper_parameter_tuning_job_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def hyper_parameter_tuning_job_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) HyperParameterTuningJobStatus property.

            Specify an array of string values to match this event if the actual value of HyperParameterTuningJobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("hyper_parameter_tuning_job_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def last_modified_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LastModifiedTime property.

            Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_modified_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def objective_status_counters(
            self,
        ) -> typing.Optional["SageMakerHyperParameterTuningJobStateChange.ObjectiveStatusCounters"]:
            '''(experimental) ObjectiveStatusCounters property.

            Specify an array of string values to match this event if the actual value of ObjectiveStatusCounters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("objective_status_counters")
            return typing.cast(typing.Optional["SageMakerHyperParameterTuningJobStateChange.ObjectiveStatusCounters"], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["SageMakerHyperParameterTuningJobStateChange.Tags"]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["SageMakerHyperParameterTuningJobStateChange.Tags"]], result)

        @builtins.property
        def training_job_definition(
            self,
        ) -> typing.Optional["SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinition"]:
            '''(experimental) TrainingJobDefinition property.

            Specify an array of string values to match this event if the actual value of TrainingJobDefinition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_job_definition")
            return typing.cast(typing.Optional["SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinition"], result)

        @builtins.property
        def training_job_status_counters(
            self,
        ) -> typing.Optional["SageMakerHyperParameterTuningJobStateChange.TrainingJobStatusCounters"]:
            '''(experimental) TrainingJobStatusCounters property.

            Specify an array of string values to match this event if the actual value of TrainingJobStatusCounters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_job_status_counters")
            return typing.cast(typing.Optional["SageMakerHyperParameterTuningJobStateChange.TrainingJobStatusCounters"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerHyperParameterTuningJobStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.StoppingCondition",
        jsii_struct_bases=[],
        name_mapping={"max_runtime_in_seconds": "maxRuntimeInSeconds"},
    )
    class StoppingCondition:
        def __init__(
            self,
            *,
            max_runtime_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for StoppingCondition.

            :param max_runtime_in_seconds: (experimental) MaxRuntimeInSeconds property. Specify an array of string values to match this event if the actual value of MaxRuntimeInSeconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                stopping_condition = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.StoppingCondition(
                    max_runtime_in_seconds=["maxRuntimeInSeconds"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8327c6042f63f32fad2be7f2b6546f32eef04700ac86d1703d510b98a4793538)
                check_type(argname="argument max_runtime_in_seconds", value=max_runtime_in_seconds, expected_type=type_hints["max_runtime_in_seconds"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if max_runtime_in_seconds is not None:
                self._values["max_runtime_in_seconds"] = max_runtime_in_seconds

        @builtins.property
        def max_runtime_in_seconds(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) MaxRuntimeInSeconds property.

            Specify an array of string values to match this event if the actual value of MaxRuntimeInSeconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_runtime_in_seconds")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "StoppingCondition(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.Tags",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class Tags:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tags.

            :param key: (experimental) Key property. Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) Value property. Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                tags = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.Tags(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__6a87badf3373bfd2eca44f85a6e8eecca83bf54e1c7f41d53f79be889bf88a47)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Key property.

            Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Value property.

            Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Tags(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinition",
        jsii_struct_bases=[],
        name_mapping={
            "algorithm_specification": "algorithmSpecification",
            "input_data_config": "inputDataConfig",
            "output_data_config": "outputDataConfig",
            "resource_config": "resourceConfig",
            "role_arn": "roleArn",
            "static_hyper_parameters": "staticHyperParameters",
            "stopping_condition": "stoppingCondition",
            "vpc_config": "vpcConfig",
        },
    )
    class TrainingJobDefinition:
        def __init__(
            self,
            *,
            algorithm_specification: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecification", typing.Dict[builtins.str, typing.Any]]] = None,
            input_data_config: typing.Optional[typing.Sequence[typing.Union["SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinitionItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            output_data_config: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            resource_config: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.ResourceConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            static_hyper_parameters: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.Tags", typing.Dict[builtins.str, typing.Any]]] = None,
            stopping_condition: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.StoppingCondition", typing.Dict[builtins.str, typing.Any]]] = None,
            vpc_config: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.VpcConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for TrainingJobDefinition.

            :param algorithm_specification: (experimental) AlgorithmSpecification property. Specify an array of string values to match this event if the actual value of AlgorithmSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_data_config: (experimental) InputDataConfig property. Specify an array of string values to match this event if the actual value of InputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_data_config: (experimental) OutputDataConfig property. Specify an array of string values to match this event if the actual value of OutputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_config: (experimental) ResourceConfig property. Specify an array of string values to match this event if the actual value of ResourceConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param role_arn: (experimental) RoleArn property. Specify an array of string values to match this event if the actual value of RoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param static_hyper_parameters: (experimental) StaticHyperParameters property. Specify an array of string values to match this event if the actual value of StaticHyperParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stopping_condition: (experimental) StoppingCondition property. Specify an array of string values to match this event if the actual value of StoppingCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param vpc_config: (experimental) VpcConfig property. Specify an array of string values to match this event if the actual value of VpcConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                training_job_definition = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinition(
                    algorithm_specification=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecification(
                        metric_definitions=[sagemaker_events.SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecificationItem(
                            name=["name"],
                            regex=["regex"]
                        )],
                        training_image=["trainingImage"],
                        training_input_mode=["trainingInputMode"]
                    ),
                    input_data_config=[sagemaker_events.SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinitionItem(
                        channel_name=["channelName"],
                        compression_type=["compressionType"],
                        content_type=["contentType"],
                        data_source=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.DataSource(
                            s3_data_source=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.S3DataSource(
                                s3_data_distribution_type=["s3DataDistributionType"],
                                s3_data_type=["s3DataType"],
                                s3_uri=["s3Uri"]
                            )
                        ),
                        record_wrapper_type=["recordWrapperType"]
                    )],
                    output_data_config=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.OutputDataConfig(
                        kms_key_id=["kmsKeyId"],
                        s3_output_path=["s3OutputPath"]
                    ),
                    resource_config=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.ResourceConfig(
                        instance_count=["instanceCount"],
                        instance_type=["instanceType"],
                        volume_kms_key_id=["volumeKmsKeyId"],
                        volume_size_in_gb=["volumeSizeInGb"]
                    ),
                    role_arn=["roleArn"],
                    static_hyper_parameters=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.Tags(
                        key=["key"],
                        value=["value"]
                    ),
                    stopping_condition=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.StoppingCondition(
                        max_runtime_in_seconds=["maxRuntimeInSeconds"]
                    ),
                    vpc_config=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.VpcConfig(
                        security_group_ids=["securityGroupIds"],
                        subnets=["subnets"]
                    )
                )
            '''
            if isinstance(algorithm_specification, dict):
                algorithm_specification = SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecification(**algorithm_specification)
            if isinstance(output_data_config, dict):
                output_data_config = SageMakerHyperParameterTuningJobStateChange.OutputDataConfig(**output_data_config)
            if isinstance(resource_config, dict):
                resource_config = SageMakerHyperParameterTuningJobStateChange.ResourceConfig(**resource_config)
            if isinstance(static_hyper_parameters, dict):
                static_hyper_parameters = SageMakerHyperParameterTuningJobStateChange.Tags(**static_hyper_parameters)
            if isinstance(stopping_condition, dict):
                stopping_condition = SageMakerHyperParameterTuningJobStateChange.StoppingCondition(**stopping_condition)
            if isinstance(vpc_config, dict):
                vpc_config = SageMakerHyperParameterTuningJobStateChange.VpcConfig(**vpc_config)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__3fc13451368a1d2705b54288fa12a295c9fb58b10fd25a044cd375318049ce89)
                check_type(argname="argument algorithm_specification", value=algorithm_specification, expected_type=type_hints["algorithm_specification"])
                check_type(argname="argument input_data_config", value=input_data_config, expected_type=type_hints["input_data_config"])
                check_type(argname="argument output_data_config", value=output_data_config, expected_type=type_hints["output_data_config"])
                check_type(argname="argument resource_config", value=resource_config, expected_type=type_hints["resource_config"])
                check_type(argname="argument role_arn", value=role_arn, expected_type=type_hints["role_arn"])
                check_type(argname="argument static_hyper_parameters", value=static_hyper_parameters, expected_type=type_hints["static_hyper_parameters"])
                check_type(argname="argument stopping_condition", value=stopping_condition, expected_type=type_hints["stopping_condition"])
                check_type(argname="argument vpc_config", value=vpc_config, expected_type=type_hints["vpc_config"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if algorithm_specification is not None:
                self._values["algorithm_specification"] = algorithm_specification
            if input_data_config is not None:
                self._values["input_data_config"] = input_data_config
            if output_data_config is not None:
                self._values["output_data_config"] = output_data_config
            if resource_config is not None:
                self._values["resource_config"] = resource_config
            if role_arn is not None:
                self._values["role_arn"] = role_arn
            if static_hyper_parameters is not None:
                self._values["static_hyper_parameters"] = static_hyper_parameters
            if stopping_condition is not None:
                self._values["stopping_condition"] = stopping_condition
            if vpc_config is not None:
                self._values["vpc_config"] = vpc_config

        @builtins.property
        def algorithm_specification(
            self,
        ) -> typing.Optional["SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecification"]:
            '''(experimental) AlgorithmSpecification property.

            Specify an array of string values to match this event if the actual value of AlgorithmSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("algorithm_specification")
            return typing.cast(typing.Optional["SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecification"], result)

        @builtins.property
        def input_data_config(
            self,
        ) -> typing.Optional[typing.List["SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinitionItem"]]:
            '''(experimental) InputDataConfig property.

            Specify an array of string values to match this event if the actual value of InputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_data_config")
            return typing.cast(typing.Optional[typing.List["SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinitionItem"]], result)

        @builtins.property
        def output_data_config(
            self,
        ) -> typing.Optional["SageMakerHyperParameterTuningJobStateChange.OutputDataConfig"]:
            '''(experimental) OutputDataConfig property.

            Specify an array of string values to match this event if the actual value of OutputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_data_config")
            return typing.cast(typing.Optional["SageMakerHyperParameterTuningJobStateChange.OutputDataConfig"], result)

        @builtins.property
        def resource_config(
            self,
        ) -> typing.Optional["SageMakerHyperParameterTuningJobStateChange.ResourceConfig"]:
            '''(experimental) ResourceConfig property.

            Specify an array of string values to match this event if the actual value of ResourceConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_config")
            return typing.cast(typing.Optional["SageMakerHyperParameterTuningJobStateChange.ResourceConfig"], result)

        @builtins.property
        def role_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) RoleArn property.

            Specify an array of string values to match this event if the actual value of RoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("role_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def static_hyper_parameters(
            self,
        ) -> typing.Optional["SageMakerHyperParameterTuningJobStateChange.Tags"]:
            '''(experimental) StaticHyperParameters property.

            Specify an array of string values to match this event if the actual value of StaticHyperParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("static_hyper_parameters")
            return typing.cast(typing.Optional["SageMakerHyperParameterTuningJobStateChange.Tags"], result)

        @builtins.property
        def stopping_condition(
            self,
        ) -> typing.Optional["SageMakerHyperParameterTuningJobStateChange.StoppingCondition"]:
            '''(experimental) StoppingCondition property.

            Specify an array of string values to match this event if the actual value of StoppingCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stopping_condition")
            return typing.cast(typing.Optional["SageMakerHyperParameterTuningJobStateChange.StoppingCondition"], result)

        @builtins.property
        def vpc_config(
            self,
        ) -> typing.Optional["SageMakerHyperParameterTuningJobStateChange.VpcConfig"]:
            '''(experimental) VpcConfig property.

            Specify an array of string values to match this event if the actual value of VpcConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("vpc_config")
            return typing.cast(typing.Optional["SageMakerHyperParameterTuningJobStateChange.VpcConfig"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TrainingJobDefinition(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinitionItem",
        jsii_struct_bases=[],
        name_mapping={
            "channel_name": "channelName",
            "compression_type": "compressionType",
            "content_type": "contentType",
            "data_source": "dataSource",
            "record_wrapper_type": "recordWrapperType",
        },
    )
    class TrainingJobDefinitionItem:
        def __init__(
            self,
            *,
            channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            compression_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            content_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            data_source: typing.Optional[typing.Union["SageMakerHyperParameterTuningJobStateChange.DataSource", typing.Dict[builtins.str, typing.Any]]] = None,
            record_wrapper_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for TrainingJobDefinitionItem.

            :param channel_name: (experimental) ChannelName property. Specify an array of string values to match this event if the actual value of ChannelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param compression_type: (experimental) CompressionType property. Specify an array of string values to match this event if the actual value of CompressionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param content_type: (experimental) ContentType property. Specify an array of string values to match this event if the actual value of ContentType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source: (experimental) DataSource property. Specify an array of string values to match this event if the actual value of DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param record_wrapper_type: (experimental) RecordWrapperType property. Specify an array of string values to match this event if the actual value of RecordWrapperType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                training_job_definition_item = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinitionItem(
                    channel_name=["channelName"],
                    compression_type=["compressionType"],
                    content_type=["contentType"],
                    data_source=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.DataSource(
                        s3_data_source=sagemaker_events.SageMakerHyperParameterTuningJobStateChange.S3DataSource(
                            s3_data_distribution_type=["s3DataDistributionType"],
                            s3_data_type=["s3DataType"],
                            s3_uri=["s3Uri"]
                        )
                    ),
                    record_wrapper_type=["recordWrapperType"]
                )
            '''
            if isinstance(data_source, dict):
                data_source = SageMakerHyperParameterTuningJobStateChange.DataSource(**data_source)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__a1ea70fe870402ea5e3d7c053056a088be44374ebc5e0aa5fda73faf0259f6b6)
                check_type(argname="argument channel_name", value=channel_name, expected_type=type_hints["channel_name"])
                check_type(argname="argument compression_type", value=compression_type, expected_type=type_hints["compression_type"])
                check_type(argname="argument content_type", value=content_type, expected_type=type_hints["content_type"])
                check_type(argname="argument data_source", value=data_source, expected_type=type_hints["data_source"])
                check_type(argname="argument record_wrapper_type", value=record_wrapper_type, expected_type=type_hints["record_wrapper_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if channel_name is not None:
                self._values["channel_name"] = channel_name
            if compression_type is not None:
                self._values["compression_type"] = compression_type
            if content_type is not None:
                self._values["content_type"] = content_type
            if data_source is not None:
                self._values["data_source"] = data_source
            if record_wrapper_type is not None:
                self._values["record_wrapper_type"] = record_wrapper_type

        @builtins.property
        def channel_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ChannelName property.

            Specify an array of string values to match this event if the actual value of ChannelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("channel_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def compression_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CompressionType property.

            Specify an array of string values to match this event if the actual value of CompressionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("compression_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def content_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ContentType property.

            Specify an array of string values to match this event if the actual value of ContentType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("content_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data_source(
            self,
        ) -> typing.Optional["SageMakerHyperParameterTuningJobStateChange.DataSource"]:
            '''(experimental) DataSource property.

            Specify an array of string values to match this event if the actual value of DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source")
            return typing.cast(typing.Optional["SageMakerHyperParameterTuningJobStateChange.DataSource"], result)

        @builtins.property
        def record_wrapper_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) RecordWrapperType property.

            Specify an array of string values to match this event if the actual value of RecordWrapperType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("record_wrapper_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TrainingJobDefinitionItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.TrainingJobStatusCounters",
        jsii_struct_bases=[],
        name_mapping={
            "completed": "completed",
            "in_progress": "inProgress",
            "non_retryable_error": "nonRetryableError",
            "retryable_error": "retryableError",
            "stopped": "stopped",
        },
    )
    class TrainingJobStatusCounters:
        def __init__(
            self,
            *,
            completed: typing.Optional[typing.Sequence[builtins.str]] = None,
            in_progress: typing.Optional[typing.Sequence[builtins.str]] = None,
            non_retryable_error: typing.Optional[typing.Sequence[builtins.str]] = None,
            retryable_error: typing.Optional[typing.Sequence[builtins.str]] = None,
            stopped: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for TrainingJobStatusCounters.

            :param completed: (experimental) Completed property. Specify an array of string values to match this event if the actual value of Completed is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param in_progress: (experimental) InProgress property. Specify an array of string values to match this event if the actual value of InProgress is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param non_retryable_error: (experimental) NonRetryableError property. Specify an array of string values to match this event if the actual value of NonRetryableError is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param retryable_error: (experimental) RetryableError property. Specify an array of string values to match this event if the actual value of RetryableError is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stopped: (experimental) Stopped property. Specify an array of string values to match this event if the actual value of Stopped is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                training_job_status_counters = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.TrainingJobStatusCounters(
                    completed=["completed"],
                    in_progress=["inProgress"],
                    non_retryable_error=["nonRetryableError"],
                    retryable_error=["retryableError"],
                    stopped=["stopped"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__aa81b12edd4a995963cff8b66e795e5e4b98cdfa6488b577cb365031b87fdd4e)
                check_type(argname="argument completed", value=completed, expected_type=type_hints["completed"])
                check_type(argname="argument in_progress", value=in_progress, expected_type=type_hints["in_progress"])
                check_type(argname="argument non_retryable_error", value=non_retryable_error, expected_type=type_hints["non_retryable_error"])
                check_type(argname="argument retryable_error", value=retryable_error, expected_type=type_hints["retryable_error"])
                check_type(argname="argument stopped", value=stopped, expected_type=type_hints["stopped"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if completed is not None:
                self._values["completed"] = completed
            if in_progress is not None:
                self._values["in_progress"] = in_progress
            if non_retryable_error is not None:
                self._values["non_retryable_error"] = non_retryable_error
            if retryable_error is not None:
                self._values["retryable_error"] = retryable_error
            if stopped is not None:
                self._values["stopped"] = stopped

        @builtins.property
        def completed(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Completed property.

            Specify an array of string values to match this event if the actual value of Completed is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("completed")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def in_progress(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InProgress property.

            Specify an array of string values to match this event if the actual value of InProgress is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("in_progress")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def non_retryable_error(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) NonRetryableError property.

            Specify an array of string values to match this event if the actual value of NonRetryableError is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("non_retryable_error")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def retryable_error(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) RetryableError property.

            Specify an array of string values to match this event if the actual value of RetryableError is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("retryable_error")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stopped(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Stopped property.

            Specify an array of string values to match this event if the actual value of Stopped is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stopped")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TrainingJobStatusCounters(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerHyperParameterTuningJobStateChange.VpcConfig",
        jsii_struct_bases=[],
        name_mapping={"security_group_ids": "securityGroupIds", "subnets": "subnets"},
    )
    class VpcConfig:
        def __init__(
            self,
            *,
            security_group_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
            subnets: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for VpcConfig.

            :param security_group_ids: (experimental) SecurityGroupIds property. Specify an array of string values to match this event if the actual value of SecurityGroupIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param subnets: (experimental) Subnets property. Specify an array of string values to match this event if the actual value of Subnets is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                vpc_config = sagemaker_events.SageMakerHyperParameterTuningJobStateChange.VpcConfig(
                    security_group_ids=["securityGroupIds"],
                    subnets=["subnets"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b2b979673503f9ad0cd8e7514d24abbb3f7014796eb631de207ab85e3f04157c)
                check_type(argname="argument security_group_ids", value=security_group_ids, expected_type=type_hints["security_group_ids"])
                check_type(argname="argument subnets", value=subnets, expected_type=type_hints["subnets"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if security_group_ids is not None:
                self._values["security_group_ids"] = security_group_ids
            if subnets is not None:
                self._values["subnets"] = subnets

        @builtins.property
        def security_group_ids(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SecurityGroupIds property.

            Specify an array of string values to match this event if the actual value of SecurityGroupIds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("security_group_ids")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def subnets(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Subnets property.

            Specify an array of string values to match this event if the actual value of Subnets is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("subnets")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "VpcConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SageMakerModelBuildingPipelineExecutionStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelBuildingPipelineExecutionStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerModelBuildingPipelineExecutionStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_model_building_pipeline_execution_status_change = sagemaker_events.SageMakerModelBuildingPipelineExecutionStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        current_pipeline_execution_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        execution_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        execution_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        pipeline_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        pipeline_execution_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        pipeline_execution_description: typing.Optional[typing.Sequence[builtins.str]] = None,
        pipeline_execution_display_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        previous_pipeline_execution_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker Model Building Pipeline Execution Status Change.

        :param current_pipeline_execution_status: (experimental) currentPipelineExecutionStatus property. Specify an array of string values to match this event if the actual value of currentPipelineExecutionStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param execution_end_time: (experimental) executionEndTime property. Specify an array of string values to match this event if the actual value of executionEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param execution_start_time: (experimental) executionStartTime property. Specify an array of string values to match this event if the actual value of executionStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pipeline_arn: (experimental) pipelineArn property. Specify an array of string values to match this event if the actual value of pipelineArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pipeline_execution_arn: (experimental) pipelineExecutionArn property. Specify an array of string values to match this event if the actual value of pipelineExecutionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pipeline_execution_description: (experimental) pipelineExecutionDescription property. Specify an array of string values to match this event if the actual value of pipelineExecutionDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pipeline_execution_display_name: (experimental) pipelineExecutionDisplayName property. Specify an array of string values to match this event if the actual value of pipelineExecutionDisplayName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param previous_pipeline_execution_status: (experimental) previousPipelineExecutionStatus property. Specify an array of string values to match this event if the actual value of previousPipelineExecutionStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerModelBuildingPipelineExecutionStatusChange.SageMakerModelBuildingPipelineExecutionStatusChangeProps(
            current_pipeline_execution_status=current_pipeline_execution_status,
            event_metadata=event_metadata,
            execution_end_time=execution_end_time,
            execution_start_time=execution_start_time,
            pipeline_arn=pipeline_arn,
            pipeline_execution_arn=pipeline_execution_arn,
            pipeline_execution_description=pipeline_execution_description,
            pipeline_execution_display_name=pipeline_execution_display_name,
            previous_pipeline_execution_status=previous_pipeline_execution_status,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelBuildingPipelineExecutionStatusChange.SageMakerModelBuildingPipelineExecutionStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "current_pipeline_execution_status": "currentPipelineExecutionStatus",
            "event_metadata": "eventMetadata",
            "execution_end_time": "executionEndTime",
            "execution_start_time": "executionStartTime",
            "pipeline_arn": "pipelineArn",
            "pipeline_execution_arn": "pipelineExecutionArn",
            "pipeline_execution_description": "pipelineExecutionDescription",
            "pipeline_execution_display_name": "pipelineExecutionDisplayName",
            "previous_pipeline_execution_status": "previousPipelineExecutionStatus",
        },
    )
    class SageMakerModelBuildingPipelineExecutionStatusChangeProps:
        def __init__(
            self,
            *,
            current_pipeline_execution_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            execution_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            execution_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            pipeline_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            pipeline_execution_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            pipeline_execution_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            pipeline_execution_display_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            previous_pipeline_execution_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerModelBuildingPipelineExecutionStatusChange event.

            :param current_pipeline_execution_status: (experimental) currentPipelineExecutionStatus property. Specify an array of string values to match this event if the actual value of currentPipelineExecutionStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param execution_end_time: (experimental) executionEndTime property. Specify an array of string values to match this event if the actual value of executionEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param execution_start_time: (experimental) executionStartTime property. Specify an array of string values to match this event if the actual value of executionStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline_arn: (experimental) pipelineArn property. Specify an array of string values to match this event if the actual value of pipelineArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline_execution_arn: (experimental) pipelineExecutionArn property. Specify an array of string values to match this event if the actual value of pipelineExecutionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline_execution_description: (experimental) pipelineExecutionDescription property. Specify an array of string values to match this event if the actual value of pipelineExecutionDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline_execution_display_name: (experimental) pipelineExecutionDisplayName property. Specify an array of string values to match this event if the actual value of pipelineExecutionDisplayName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param previous_pipeline_execution_status: (experimental) previousPipelineExecutionStatus property. Specify an array of string values to match this event if the actual value of previousPipelineExecutionStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_model_building_pipeline_execution_status_change_props = sagemaker_events.SageMakerModelBuildingPipelineExecutionStatusChange.SageMakerModelBuildingPipelineExecutionStatusChangeProps(
                    current_pipeline_execution_status=["currentPipelineExecutionStatus"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    execution_end_time=["executionEndTime"],
                    execution_start_time=["executionStartTime"],
                    pipeline_arn=["pipelineArn"],
                    pipeline_execution_arn=["pipelineExecutionArn"],
                    pipeline_execution_description=["pipelineExecutionDescription"],
                    pipeline_execution_display_name=["pipelineExecutionDisplayName"],
                    previous_pipeline_execution_status=["previousPipelineExecutionStatus"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8bac56b5bd5fe117c05fa6e59a58bbe12a6cbced21e2ac1882dfcb7c98b27e46)
                check_type(argname="argument current_pipeline_execution_status", value=current_pipeline_execution_status, expected_type=type_hints["current_pipeline_execution_status"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument execution_end_time", value=execution_end_time, expected_type=type_hints["execution_end_time"])
                check_type(argname="argument execution_start_time", value=execution_start_time, expected_type=type_hints["execution_start_time"])
                check_type(argname="argument pipeline_arn", value=pipeline_arn, expected_type=type_hints["pipeline_arn"])
                check_type(argname="argument pipeline_execution_arn", value=pipeline_execution_arn, expected_type=type_hints["pipeline_execution_arn"])
                check_type(argname="argument pipeline_execution_description", value=pipeline_execution_description, expected_type=type_hints["pipeline_execution_description"])
                check_type(argname="argument pipeline_execution_display_name", value=pipeline_execution_display_name, expected_type=type_hints["pipeline_execution_display_name"])
                check_type(argname="argument previous_pipeline_execution_status", value=previous_pipeline_execution_status, expected_type=type_hints["previous_pipeline_execution_status"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if current_pipeline_execution_status is not None:
                self._values["current_pipeline_execution_status"] = current_pipeline_execution_status
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if execution_end_time is not None:
                self._values["execution_end_time"] = execution_end_time
            if execution_start_time is not None:
                self._values["execution_start_time"] = execution_start_time
            if pipeline_arn is not None:
                self._values["pipeline_arn"] = pipeline_arn
            if pipeline_execution_arn is not None:
                self._values["pipeline_execution_arn"] = pipeline_execution_arn
            if pipeline_execution_description is not None:
                self._values["pipeline_execution_description"] = pipeline_execution_description
            if pipeline_execution_display_name is not None:
                self._values["pipeline_execution_display_name"] = pipeline_execution_display_name
            if previous_pipeline_execution_status is not None:
                self._values["previous_pipeline_execution_status"] = previous_pipeline_execution_status

        @builtins.property
        def current_pipeline_execution_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) currentPipelineExecutionStatus property.

            Specify an array of string values to match this event if the actual value of currentPipelineExecutionStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_pipeline_execution_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def execution_end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) executionEndTime property.

            Specify an array of string values to match this event if the actual value of executionEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("execution_end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def execution_start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) executionStartTime property.

            Specify an array of string values to match this event if the actual value of executionStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("execution_start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pipeline_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pipelineArn property.

            Specify an array of string values to match this event if the actual value of pipelineArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pipeline_execution_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pipelineExecutionArn property.

            Specify an array of string values to match this event if the actual value of pipelineExecutionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline_execution_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pipeline_execution_description(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pipelineExecutionDescription property.

            Specify an array of string values to match this event if the actual value of pipelineExecutionDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline_execution_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pipeline_execution_display_name(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pipelineExecutionDisplayName property.

            Specify an array of string values to match this event if the actual value of pipelineExecutionDisplayName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline_execution_display_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def previous_pipeline_execution_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) previousPipelineExecutionStatus property.

            Specify an array of string values to match this event if the actual value of previousPipelineExecutionStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("previous_pipeline_execution_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerModelBuildingPipelineExecutionStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SageMakerModelBuildingPipelineExecutionStepStatusChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelBuildingPipelineExecutionStepStatusChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerModelBuildingPipelineExecutionStepStatusChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_model_building_pipeline_execution_step_status_change = sagemaker_events.SageMakerModelBuildingPipelineExecutionStepStatusChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        cache_hit_result: typing.Optional[typing.Union["SageMakerModelBuildingPipelineExecutionStepStatusChange.CacheHitResult", typing.Dict[builtins.str, typing.Any]]] = None,
        current_step_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        failure_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
        metadata: typing.Optional[typing.Union["SageMakerModelBuildingPipelineExecutionStepStatusChange.Metadata", typing.Dict[builtins.str, typing.Any]]] = None,
        pipeline_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        pipeline_execution_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        previous_step_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        step_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        step_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        step_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        step_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker Model Building Pipeline Execution Step Status Change.

        :param cache_hit_result: (experimental) cacheHitResult property. Specify an array of string values to match this event if the actual value of cacheHitResult is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param current_step_status: (experimental) currentStepStatus property. Specify an array of string values to match this event if the actual value of currentStepStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param failure_reason: (experimental) failureReason property. Specify an array of string values to match this event if the actual value of failureReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param metadata: (experimental) metadata property. Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pipeline_arn: (experimental) pipelineArn property. Specify an array of string values to match this event if the actual value of pipelineArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param pipeline_execution_arn: (experimental) pipelineExecutionArn property. Specify an array of string values to match this event if the actual value of pipelineExecutionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param previous_step_status: (experimental) previousStepStatus property. Specify an array of string values to match this event if the actual value of previousStepStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param step_end_time: (experimental) stepEndTime property. Specify an array of string values to match this event if the actual value of stepEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param step_name: (experimental) stepName property. Specify an array of string values to match this event if the actual value of stepName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param step_start_time: (experimental) stepStartTime property. Specify an array of string values to match this event if the actual value of stepStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param step_type: (experimental) stepType property. Specify an array of string values to match this event if the actual value of stepType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerModelBuildingPipelineExecutionStepStatusChange.SageMakerModelBuildingPipelineExecutionStepStatusChangeProps(
            cache_hit_result=cache_hit_result,
            current_step_status=current_step_status,
            event_metadata=event_metadata,
            failure_reason=failure_reason,
            metadata=metadata,
            pipeline_arn=pipeline_arn,
            pipeline_execution_arn=pipeline_execution_arn,
            previous_step_status=previous_step_status,
            step_end_time=step_end_time,
            step_name=step_name,
            step_start_time=step_start_time,
            step_type=step_type,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelBuildingPipelineExecutionStepStatusChange.CacheHitResult",
        jsii_struct_bases=[],
        name_mapping={"source_pipeline_execution_arn": "sourcePipelineExecutionArn"},
    )
    class CacheHitResult:
        def __init__(
            self,
            *,
            source_pipeline_execution_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for CacheHitResult.

            :param source_pipeline_execution_arn: (experimental) sourcePipelineExecutionArn property. Specify an array of string values to match this event if the actual value of sourcePipelineExecutionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                cache_hit_result = sagemaker_events.SageMakerModelBuildingPipelineExecutionStepStatusChange.CacheHitResult(
                    source_pipeline_execution_arn=["sourcePipelineExecutionArn"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__05af31358f5fd9c727f733a71c7846ed96d3d86c89c8d999842f34fcbcd4fc9f)
                check_type(argname="argument source_pipeline_execution_arn", value=source_pipeline_execution_arn, expected_type=type_hints["source_pipeline_execution_arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if source_pipeline_execution_arn is not None:
                self._values["source_pipeline_execution_arn"] = source_pipeline_execution_arn

        @builtins.property
        def source_pipeline_execution_arn(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) sourcePipelineExecutionArn property.

            Specify an array of string values to match this event if the actual value of sourcePipelineExecutionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("source_pipeline_execution_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "CacheHitResult(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelBuildingPipelineExecutionStepStatusChange.Metadata",
        jsii_struct_bases=[],
        name_mapping={"processing_job": "processingJob"},
    )
    class Metadata:
        def __init__(
            self,
            *,
            processing_job: typing.Optional[typing.Union["SageMakerModelBuildingPipelineExecutionStepStatusChange.ProcessingJob", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for Metadata.

            :param processing_job: (experimental) processingJob property. Specify an array of string values to match this event if the actual value of processingJob is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                metadata = sagemaker_events.SageMakerModelBuildingPipelineExecutionStepStatusChange.Metadata(
                    processing_job=sagemaker_events.SageMakerModelBuildingPipelineExecutionStepStatusChange.ProcessingJob(
                        arn=["arn"]
                    )
                )
            '''
            if isinstance(processing_job, dict):
                processing_job = SageMakerModelBuildingPipelineExecutionStepStatusChange.ProcessingJob(**processing_job)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__0a9aaf26ca1016f3516161e5cce9bd4dfc00fae56f8f022cea6c2ec2532cde7f)
                check_type(argname="argument processing_job", value=processing_job, expected_type=type_hints["processing_job"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if processing_job is not None:
                self._values["processing_job"] = processing_job

        @builtins.property
        def processing_job(
            self,
        ) -> typing.Optional["SageMakerModelBuildingPipelineExecutionStepStatusChange.ProcessingJob"]:
            '''(experimental) processingJob property.

            Specify an array of string values to match this event if the actual value of processingJob is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("processing_job")
            return typing.cast(typing.Optional["SageMakerModelBuildingPipelineExecutionStepStatusChange.ProcessingJob"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Metadata(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelBuildingPipelineExecutionStepStatusChange.ProcessingJob",
        jsii_struct_bases=[],
        name_mapping={"arn": "arn"},
    )
    class ProcessingJob:
        def __init__(
            self,
            *,
            arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ProcessingJob.

            :param arn: (experimental) arn property. Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                processing_job = sagemaker_events.SageMakerModelBuildingPipelineExecutionStepStatusChange.ProcessingJob(
                    arn=["arn"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1232dc1f9fb22c422bb5980f2d297cfd047a3da21f0c6e63301cbe1a4ef358ad)
                check_type(argname="argument arn", value=arn, expected_type=type_hints["arn"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if arn is not None:
                self._values["arn"] = arn

        @builtins.property
        def arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) arn property.

            Specify an array of string values to match this event if the actual value of arn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ProcessingJob(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelBuildingPipelineExecutionStepStatusChange.SageMakerModelBuildingPipelineExecutionStepStatusChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "cache_hit_result": "cacheHitResult",
            "current_step_status": "currentStepStatus",
            "event_metadata": "eventMetadata",
            "failure_reason": "failureReason",
            "metadata": "metadata",
            "pipeline_arn": "pipelineArn",
            "pipeline_execution_arn": "pipelineExecutionArn",
            "previous_step_status": "previousStepStatus",
            "step_end_time": "stepEndTime",
            "step_name": "stepName",
            "step_start_time": "stepStartTime",
            "step_type": "stepType",
        },
    )
    class SageMakerModelBuildingPipelineExecutionStepStatusChangeProps:
        def __init__(
            self,
            *,
            cache_hit_result: typing.Optional[typing.Union["SageMakerModelBuildingPipelineExecutionStepStatusChange.CacheHitResult", typing.Dict[builtins.str, typing.Any]]] = None,
            current_step_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            failure_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
            metadata: typing.Optional[typing.Union["SageMakerModelBuildingPipelineExecutionStepStatusChange.Metadata", typing.Dict[builtins.str, typing.Any]]] = None,
            pipeline_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            pipeline_execution_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            previous_step_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            step_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            step_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            step_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            step_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerModelBuildingPipelineExecutionStepStatusChange event.

            :param cache_hit_result: (experimental) cacheHitResult property. Specify an array of string values to match this event if the actual value of cacheHitResult is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param current_step_status: (experimental) currentStepStatus property. Specify an array of string values to match this event if the actual value of currentStepStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param failure_reason: (experimental) failureReason property. Specify an array of string values to match this event if the actual value of failureReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param metadata: (experimental) metadata property. Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline_arn: (experimental) pipelineArn property. Specify an array of string values to match this event if the actual value of pipelineArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param pipeline_execution_arn: (experimental) pipelineExecutionArn property. Specify an array of string values to match this event if the actual value of pipelineExecutionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param previous_step_status: (experimental) previousStepStatus property. Specify an array of string values to match this event if the actual value of previousStepStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param step_end_time: (experimental) stepEndTime property. Specify an array of string values to match this event if the actual value of stepEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param step_name: (experimental) stepName property. Specify an array of string values to match this event if the actual value of stepName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param step_start_time: (experimental) stepStartTime property. Specify an array of string values to match this event if the actual value of stepStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param step_type: (experimental) stepType property. Specify an array of string values to match this event if the actual value of stepType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_model_building_pipeline_execution_step_status_change_props = sagemaker_events.SageMakerModelBuildingPipelineExecutionStepStatusChange.SageMakerModelBuildingPipelineExecutionStepStatusChangeProps(
                    cache_hit_result=sagemaker_events.SageMakerModelBuildingPipelineExecutionStepStatusChange.CacheHitResult(
                        source_pipeline_execution_arn=["sourcePipelineExecutionArn"]
                    ),
                    current_step_status=["currentStepStatus"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    failure_reason=["failureReason"],
                    metadata=sagemaker_events.SageMakerModelBuildingPipelineExecutionStepStatusChange.Metadata(
                        processing_job=sagemaker_events.SageMakerModelBuildingPipelineExecutionStepStatusChange.ProcessingJob(
                            arn=["arn"]
                        )
                    ),
                    pipeline_arn=["pipelineArn"],
                    pipeline_execution_arn=["pipelineExecutionArn"],
                    previous_step_status=["previousStepStatus"],
                    step_end_time=["stepEndTime"],
                    step_name=["stepName"],
                    step_start_time=["stepStartTime"],
                    step_type=["stepType"]
                )
            '''
            if isinstance(cache_hit_result, dict):
                cache_hit_result = SageMakerModelBuildingPipelineExecutionStepStatusChange.CacheHitResult(**cache_hit_result)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(metadata, dict):
                metadata = SageMakerModelBuildingPipelineExecutionStepStatusChange.Metadata(**metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fc7fc6bc97d4859e0dcaad6aa13171d5bf8a20a293abe502afe10f57907bb628)
                check_type(argname="argument cache_hit_result", value=cache_hit_result, expected_type=type_hints["cache_hit_result"])
                check_type(argname="argument current_step_status", value=current_step_status, expected_type=type_hints["current_step_status"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument failure_reason", value=failure_reason, expected_type=type_hints["failure_reason"])
                check_type(argname="argument metadata", value=metadata, expected_type=type_hints["metadata"])
                check_type(argname="argument pipeline_arn", value=pipeline_arn, expected_type=type_hints["pipeline_arn"])
                check_type(argname="argument pipeline_execution_arn", value=pipeline_execution_arn, expected_type=type_hints["pipeline_execution_arn"])
                check_type(argname="argument previous_step_status", value=previous_step_status, expected_type=type_hints["previous_step_status"])
                check_type(argname="argument step_end_time", value=step_end_time, expected_type=type_hints["step_end_time"])
                check_type(argname="argument step_name", value=step_name, expected_type=type_hints["step_name"])
                check_type(argname="argument step_start_time", value=step_start_time, expected_type=type_hints["step_start_time"])
                check_type(argname="argument step_type", value=step_type, expected_type=type_hints["step_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if cache_hit_result is not None:
                self._values["cache_hit_result"] = cache_hit_result
            if current_step_status is not None:
                self._values["current_step_status"] = current_step_status
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if failure_reason is not None:
                self._values["failure_reason"] = failure_reason
            if metadata is not None:
                self._values["metadata"] = metadata
            if pipeline_arn is not None:
                self._values["pipeline_arn"] = pipeline_arn
            if pipeline_execution_arn is not None:
                self._values["pipeline_execution_arn"] = pipeline_execution_arn
            if previous_step_status is not None:
                self._values["previous_step_status"] = previous_step_status
            if step_end_time is not None:
                self._values["step_end_time"] = step_end_time
            if step_name is not None:
                self._values["step_name"] = step_name
            if step_start_time is not None:
                self._values["step_start_time"] = step_start_time
            if step_type is not None:
                self._values["step_type"] = step_type

        @builtins.property
        def cache_hit_result(
            self,
        ) -> typing.Optional["SageMakerModelBuildingPipelineExecutionStepStatusChange.CacheHitResult"]:
            '''(experimental) cacheHitResult property.

            Specify an array of string values to match this event if the actual value of cacheHitResult is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("cache_hit_result")
            return typing.cast(typing.Optional["SageMakerModelBuildingPipelineExecutionStepStatusChange.CacheHitResult"], result)

        @builtins.property
        def current_step_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) currentStepStatus property.

            Specify an array of string values to match this event if the actual value of currentStepStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("current_step_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def failure_reason(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) failureReason property.

            Specify an array of string values to match this event if the actual value of failureReason is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("failure_reason")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def metadata(
            self,
        ) -> typing.Optional["SageMakerModelBuildingPipelineExecutionStepStatusChange.Metadata"]:
            '''(experimental) metadata property.

            Specify an array of string values to match this event if the actual value of metadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("metadata")
            return typing.cast(typing.Optional["SageMakerModelBuildingPipelineExecutionStepStatusChange.Metadata"], result)

        @builtins.property
        def pipeline_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pipelineArn property.

            Specify an array of string values to match this event if the actual value of pipelineArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def pipeline_execution_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) pipelineExecutionArn property.

            Specify an array of string values to match this event if the actual value of pipelineExecutionArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("pipeline_execution_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def previous_step_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) previousStepStatus property.

            Specify an array of string values to match this event if the actual value of previousStepStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("previous_step_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def step_end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stepEndTime property.

            Specify an array of string values to match this event if the actual value of stepEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("step_end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def step_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stepName property.

            Specify an array of string values to match this event if the actual value of stepName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("step_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def step_start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stepStartTime property.

            Specify an array of string values to match this event if the actual value of stepStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("step_start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def step_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) stepType property.

            Specify an array of string values to match this event if the actual value of stepType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("step_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerModelBuildingPipelineExecutionStepStatusChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SageMakerModelPackageStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelPackageStateChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerModelPackageStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_model_package_state_change = sagemaker_events.SageMakerModelPackageStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        certify_for_marketplace: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        model_package_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        model_package_description: typing.Optional[typing.Sequence[builtins.str]] = None,
        model_package_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        tags: typing.Optional[typing.Sequence[typing.Union["SageMakerModelPackageStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker Model Package State Change.

        :param certify_for_marketplace: (experimental) CertifyForMarketplace property. Specify an array of string values to match this event if the actual value of CertifyForMarketplace is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param model_package_arn: (experimental) ModelPackageArn property. Specify an array of string values to match this event if the actual value of ModelPackageArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param model_package_description: (experimental) ModelPackageDescription property. Specify an array of string values to match this event if the actual value of ModelPackageDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param model_package_name: (experimental) ModelPackageName property. Specify an array of string values to match this event if the actual value of ModelPackageName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerModelPackageStateChange.SageMakerModelPackageStateChangeProps(
            certify_for_marketplace=certify_for_marketplace,
            event_metadata=event_metadata,
            model_package_arn=model_package_arn,
            model_package_description=model_package_description,
            model_package_name=model_package_name,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelPackageStateChange.SageMakerModelPackageStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "certify_for_marketplace": "certifyForMarketplace",
            "event_metadata": "eventMetadata",
            "model_package_arn": "modelPackageArn",
            "model_package_description": "modelPackageDescription",
            "model_package_name": "modelPackageName",
            "tags": "tags",
        },
    )
    class SageMakerModelPackageStateChangeProps:
        def __init__(
            self,
            *,
            certify_for_marketplace: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            model_package_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            model_package_description: typing.Optional[typing.Sequence[builtins.str]] = None,
            model_package_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["SageMakerModelPackageStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerModelPackageStateChange event.

            :param certify_for_marketplace: (experimental) CertifyForMarketplace property. Specify an array of string values to match this event if the actual value of CertifyForMarketplace is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param model_package_arn: (experimental) ModelPackageArn property. Specify an array of string values to match this event if the actual value of ModelPackageArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param model_package_description: (experimental) ModelPackageDescription property. Specify an array of string values to match this event if the actual value of ModelPackageDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param model_package_name: (experimental) ModelPackageName property. Specify an array of string values to match this event if the actual value of ModelPackageName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_model_package_state_change_props = sagemaker_events.SageMakerModelPackageStateChange.SageMakerModelPackageStateChangeProps(
                    certify_for_marketplace=["certifyForMarketplace"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    model_package_arn=["modelPackageArn"],
                    model_package_description=["modelPackageDescription"],
                    model_package_name=["modelPackageName"],
                    tags=[sagemaker_events.SageMakerModelPackageStateChange.Tags(
                        key=["key"],
                        value=["value"]
                    )]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__903cec9433024298095077c261390db611d517f3b1ed33af5895d24a80142200)
                check_type(argname="argument certify_for_marketplace", value=certify_for_marketplace, expected_type=type_hints["certify_for_marketplace"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument model_package_arn", value=model_package_arn, expected_type=type_hints["model_package_arn"])
                check_type(argname="argument model_package_description", value=model_package_description, expected_type=type_hints["model_package_description"])
                check_type(argname="argument model_package_name", value=model_package_name, expected_type=type_hints["model_package_name"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if certify_for_marketplace is not None:
                self._values["certify_for_marketplace"] = certify_for_marketplace
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if model_package_arn is not None:
                self._values["model_package_arn"] = model_package_arn
            if model_package_description is not None:
                self._values["model_package_description"] = model_package_description
            if model_package_name is not None:
                self._values["model_package_name"] = model_package_name
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def certify_for_marketplace(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CertifyForMarketplace property.

            Specify an array of string values to match this event if the actual value of CertifyForMarketplace is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("certify_for_marketplace")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def model_package_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ModelPackageArn property.

            Specify an array of string values to match this event if the actual value of ModelPackageArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_package_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def model_package_description(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ModelPackageDescription property.

            Specify an array of string values to match this event if the actual value of ModelPackageDescription is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_package_description")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def model_package_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ModelPackageName property.

            Specify an array of string values to match this event if the actual value of ModelPackageName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_package_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["SageMakerModelPackageStateChange.Tags"]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["SageMakerModelPackageStateChange.Tags"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerModelPackageStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelPackageStateChange.Tags",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class Tags:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tags.

            :param key: (experimental) Key property. Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) Value property. Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                tags = sagemaker_events.SageMakerModelPackageStateChange.Tags(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__51ddc71566fb277b01edc2010ac06db7202f94b22c9e409f46d28203a4807478)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Key property.

            Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Value property.

            Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Tags(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SageMakerModelStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelStateChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerModelStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_model_state_change = sagemaker_events.SageMakerModelStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        execution_role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        model_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        model_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        primary_container: typing.Optional[typing.Union["SageMakerModelStateChange.PrimaryContainer", typing.Dict[builtins.str, typing.Any]]] = None,
        tags: typing.Optional[typing.Sequence[typing.Union["SageMakerModelStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker Model State Change.

        :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param execution_role_arn: (experimental) ExecutionRoleArn property. Specify an array of string values to match this event if the actual value of ExecutionRoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param model_arn: (experimental) ModelArn property. Specify an array of string values to match this event if the actual value of ModelArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param model_name: (experimental) ModelName property. Specify an array of string values to match this event if the actual value of ModelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param primary_container: (experimental) PrimaryContainer property. Specify an array of string values to match this event if the actual value of PrimaryContainer is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerModelStateChange.SageMakerModelStateChangeProps(
            creation_time=creation_time,
            event_metadata=event_metadata,
            execution_role_arn=execution_role_arn,
            model_arn=model_arn,
            model_name=model_name,
            primary_container=primary_container,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelStateChange.PrimaryContainer",
        jsii_struct_bases=[],
        name_mapping={
            "container_hostname": "containerHostname",
            "image": "image",
            "model_data_url": "modelDataUrl",
        },
    )
    class PrimaryContainer:
        def __init__(
            self,
            *,
            container_hostname: typing.Optional[typing.Sequence[builtins.str]] = None,
            image: typing.Optional[typing.Sequence[builtins.str]] = None,
            model_data_url: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for PrimaryContainer.

            :param container_hostname: (experimental) ContainerHostname property. Specify an array of string values to match this event if the actual value of ContainerHostname is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param image: (experimental) Image property. Specify an array of string values to match this event if the actual value of Image is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param model_data_url: (experimental) ModelDataUrl property. Specify an array of string values to match this event if the actual value of ModelDataUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                primary_container = sagemaker_events.SageMakerModelStateChange.PrimaryContainer(
                    container_hostname=["containerHostname"],
                    image=["image"],
                    model_data_url=["modelDataUrl"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__9faf336527bc7edfa459f8b49d3425bde28486d22ed50e235995683ee37de576)
                check_type(argname="argument container_hostname", value=container_hostname, expected_type=type_hints["container_hostname"])
                check_type(argname="argument image", value=image, expected_type=type_hints["image"])
                check_type(argname="argument model_data_url", value=model_data_url, expected_type=type_hints["model_data_url"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if container_hostname is not None:
                self._values["container_hostname"] = container_hostname
            if image is not None:
                self._values["image"] = image
            if model_data_url is not None:
                self._values["model_data_url"] = model_data_url

        @builtins.property
        def container_hostname(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ContainerHostname property.

            Specify an array of string values to match this event if the actual value of ContainerHostname is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("container_hostname")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def image(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Image property.

            Specify an array of string values to match this event if the actual value of Image is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("image")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def model_data_url(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ModelDataUrl property.

            Specify an array of string values to match this event if the actual value of ModelDataUrl is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_data_url")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "PrimaryContainer(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelStateChange.SageMakerModelStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "creation_time": "creationTime",
            "event_metadata": "eventMetadata",
            "execution_role_arn": "executionRoleArn",
            "model_arn": "modelArn",
            "model_name": "modelName",
            "primary_container": "primaryContainer",
            "tags": "tags",
        },
    )
    class SageMakerModelStateChangeProps:
        def __init__(
            self,
            *,
            creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            execution_role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            model_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            model_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            primary_container: typing.Optional[typing.Union["SageMakerModelStateChange.PrimaryContainer", typing.Dict[builtins.str, typing.Any]]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["SageMakerModelStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerModelStateChange event.

            :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param execution_role_arn: (experimental) ExecutionRoleArn property. Specify an array of string values to match this event if the actual value of ExecutionRoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param model_arn: (experimental) ModelArn property. Specify an array of string values to match this event if the actual value of ModelArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param model_name: (experimental) ModelName property. Specify an array of string values to match this event if the actual value of ModelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param primary_container: (experimental) PrimaryContainer property. Specify an array of string values to match this event if the actual value of PrimaryContainer is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_model_state_change_props = sagemaker_events.SageMakerModelStateChange.SageMakerModelStateChangeProps(
                    creation_time=["creationTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    execution_role_arn=["executionRoleArn"],
                    model_arn=["modelArn"],
                    model_name=["modelName"],
                    primary_container=sagemaker_events.SageMakerModelStateChange.PrimaryContainer(
                        container_hostname=["containerHostname"],
                        image=["image"],
                        model_data_url=["modelDataUrl"]
                    ),
                    tags=[sagemaker_events.SageMakerModelStateChange.Tags(
                        key=["key"],
                        value=["value"]
                    )]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(primary_container, dict):
                primary_container = SageMakerModelStateChange.PrimaryContainer(**primary_container)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e6d3aecd722396e495655685a3013ee1d6271da71f9bdaaa9816e88bcecebc44)
                check_type(argname="argument creation_time", value=creation_time, expected_type=type_hints["creation_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument execution_role_arn", value=execution_role_arn, expected_type=type_hints["execution_role_arn"])
                check_type(argname="argument model_arn", value=model_arn, expected_type=type_hints["model_arn"])
                check_type(argname="argument model_name", value=model_name, expected_type=type_hints["model_name"])
                check_type(argname="argument primary_container", value=primary_container, expected_type=type_hints["primary_container"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_time is not None:
                self._values["creation_time"] = creation_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if execution_role_arn is not None:
                self._values["execution_role_arn"] = execution_role_arn
            if model_arn is not None:
                self._values["model_arn"] = model_arn
            if model_name is not None:
                self._values["model_name"] = model_name
            if primary_container is not None:
                self._values["primary_container"] = primary_container
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def creation_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CreationTime property.

            Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def execution_role_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ExecutionRoleArn property.

            Specify an array of string values to match this event if the actual value of ExecutionRoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("execution_role_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def model_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ModelArn property.

            Specify an array of string values to match this event if the actual value of ModelArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def model_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ModelName property.

            Specify an array of string values to match this event if the actual value of ModelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def primary_container(
            self,
        ) -> typing.Optional["SageMakerModelStateChange.PrimaryContainer"]:
            '''(experimental) PrimaryContainer property.

            Specify an array of string values to match this event if the actual value of PrimaryContainer is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("primary_container")
            return typing.cast(typing.Optional["SageMakerModelStateChange.PrimaryContainer"], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["SageMakerModelStateChange.Tags"]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["SageMakerModelStateChange.Tags"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerModelStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerModelStateChange.Tags",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class Tags:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tags.

            :param key: (experimental) Key property. Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) Value property. Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                tags = sagemaker_events.SageMakerModelStateChange.Tags(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4f2b58ccffc5b6ba6a6e6462e34ad21b13ecec8821f421984b6cb3bc4eaa26dd)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Key property.

            Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Value property.

            Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Tags(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SageMakerNotebookInstanceStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerNotebookInstanceStateChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerNotebookInstanceStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_notebook_instance_state_change = sagemaker_events.SageMakerNotebookInstanceStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        notebook_instance_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        notebook_instance_lifecycle_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        notebook_instance_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        notebook_instance_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        tags: typing.Optional[typing.Sequence[typing.Union["SageMakerNotebookInstanceStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker Notebook Instance State Change.

        :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param instance_type: (experimental) InstanceType property. Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param last_modified_time: (experimental) LastModifiedTime property. Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notebook_instance_arn: (experimental) NotebookInstanceArn property. Specify an array of string values to match this event if the actual value of NotebookInstanceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notebook_instance_lifecycle_config_name: (experimental) NotebookInstanceLifecycleConfigName property. Specify an array of string values to match this event if the actual value of NotebookInstanceLifecycleConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notebook_instance_name: (experimental) NotebookInstanceName property. Specify an array of string values to match this event if the actual value of NotebookInstanceName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notebook_instance_status: (experimental) NotebookInstanceStatus property. Specify an array of string values to match this event if the actual value of NotebookInstanceStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param role_arn: (experimental) RoleArn property. Specify an array of string values to match this event if the actual value of RoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerNotebookInstanceStateChange.SageMakerNotebookInstanceStateChangeProps(
            creation_time=creation_time,
            event_metadata=event_metadata,
            instance_type=instance_type,
            last_modified_time=last_modified_time,
            notebook_instance_arn=notebook_instance_arn,
            notebook_instance_lifecycle_config_name=notebook_instance_lifecycle_config_name,
            notebook_instance_name=notebook_instance_name,
            notebook_instance_status=notebook_instance_status,
            role_arn=role_arn,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerNotebookInstanceStateChange.SageMakerNotebookInstanceStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "creation_time": "creationTime",
            "event_metadata": "eventMetadata",
            "instance_type": "instanceType",
            "last_modified_time": "lastModifiedTime",
            "notebook_instance_arn": "notebookInstanceArn",
            "notebook_instance_lifecycle_config_name": "notebookInstanceLifecycleConfigName",
            "notebook_instance_name": "notebookInstanceName",
            "notebook_instance_status": "notebookInstanceStatus",
            "role_arn": "roleArn",
            "tags": "tags",
        },
    )
    class SageMakerNotebookInstanceStateChangeProps:
        def __init__(
            self,
            *,
            creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            notebook_instance_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            notebook_instance_lifecycle_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            notebook_instance_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            notebook_instance_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["SageMakerNotebookInstanceStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerNotebookInstanceStateChange event.

            :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param instance_type: (experimental) InstanceType property. Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param last_modified_time: (experimental) LastModifiedTime property. Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notebook_instance_arn: (experimental) NotebookInstanceArn property. Specify an array of string values to match this event if the actual value of NotebookInstanceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notebook_instance_lifecycle_config_name: (experimental) NotebookInstanceLifecycleConfigName property. Specify an array of string values to match this event if the actual value of NotebookInstanceLifecycleConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notebook_instance_name: (experimental) NotebookInstanceName property. Specify an array of string values to match this event if the actual value of NotebookInstanceName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notebook_instance_status: (experimental) NotebookInstanceStatus property. Specify an array of string values to match this event if the actual value of NotebookInstanceStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param role_arn: (experimental) RoleArn property. Specify an array of string values to match this event if the actual value of RoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_notebook_instance_state_change_props = sagemaker_events.SageMakerNotebookInstanceStateChange.SageMakerNotebookInstanceStateChangeProps(
                    creation_time=["creationTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    instance_type=["instanceType"],
                    last_modified_time=["lastModifiedTime"],
                    notebook_instance_arn=["notebookInstanceArn"],
                    notebook_instance_lifecycle_config_name=["notebookInstanceLifecycleConfigName"],
                    notebook_instance_name=["notebookInstanceName"],
                    notebook_instance_status=["notebookInstanceStatus"],
                    role_arn=["roleArn"],
                    tags=[sagemaker_events.SageMakerNotebookInstanceStateChange.Tags(
                        key=["key"],
                        value=["value"]
                    )]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__8346ea103a02de17f382699127815d6e449090f812057886c9331409033da091)
                check_type(argname="argument creation_time", value=creation_time, expected_type=type_hints["creation_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument last_modified_time", value=last_modified_time, expected_type=type_hints["last_modified_time"])
                check_type(argname="argument notebook_instance_arn", value=notebook_instance_arn, expected_type=type_hints["notebook_instance_arn"])
                check_type(argname="argument notebook_instance_lifecycle_config_name", value=notebook_instance_lifecycle_config_name, expected_type=type_hints["notebook_instance_lifecycle_config_name"])
                check_type(argname="argument notebook_instance_name", value=notebook_instance_name, expected_type=type_hints["notebook_instance_name"])
                check_type(argname="argument notebook_instance_status", value=notebook_instance_status, expected_type=type_hints["notebook_instance_status"])
                check_type(argname="argument role_arn", value=role_arn, expected_type=type_hints["role_arn"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_time is not None:
                self._values["creation_time"] = creation_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if last_modified_time is not None:
                self._values["last_modified_time"] = last_modified_time
            if notebook_instance_arn is not None:
                self._values["notebook_instance_arn"] = notebook_instance_arn
            if notebook_instance_lifecycle_config_name is not None:
                self._values["notebook_instance_lifecycle_config_name"] = notebook_instance_lifecycle_config_name
            if notebook_instance_name is not None:
                self._values["notebook_instance_name"] = notebook_instance_name
            if notebook_instance_status is not None:
                self._values["notebook_instance_status"] = notebook_instance_status
            if role_arn is not None:
                self._values["role_arn"] = role_arn
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def creation_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CreationTime property.

            Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstanceType property.

            Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def last_modified_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LastModifiedTime property.

            Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_modified_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notebook_instance_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) NotebookInstanceArn property.

            Specify an array of string values to match this event if the actual value of NotebookInstanceArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notebook_instance_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notebook_instance_lifecycle_config_name(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) NotebookInstanceLifecycleConfigName property.

            Specify an array of string values to match this event if the actual value of NotebookInstanceLifecycleConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notebook_instance_lifecycle_config_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notebook_instance_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) NotebookInstanceName property.

            Specify an array of string values to match this event if the actual value of NotebookInstanceName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notebook_instance_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notebook_instance_status(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) NotebookInstanceStatus property.

            Specify an array of string values to match this event if the actual value of NotebookInstanceStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notebook_instance_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def role_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) RoleArn property.

            Specify an array of string values to match this event if the actual value of RoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("role_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["SageMakerNotebookInstanceStateChange.Tags"]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["SageMakerNotebookInstanceStateChange.Tags"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerNotebookInstanceStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerNotebookInstanceStateChange.Tags",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class Tags:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tags.

            :param key: (experimental) Key property. Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) Value property. Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                tags = sagemaker_events.SageMakerNotebookInstanceStateChange.Tags(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__7fea710b6f48a3458abc3f24f0a27883f9bcddda3bfca64bdfc154245f35640f)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Key property.

            Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Value property.

            Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Tags(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SageMakerNotebookLifecycleConfigStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerNotebookLifecycleConfigStateChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerNotebookLifecycleConfigStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_notebook_lifecycle_config_state_change = sagemaker_events.SageMakerNotebookLifecycleConfigStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        notebook_instance_lifecycle_config_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        notebook_instance_lifecycle_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        tags: typing.Optional[typing.Sequence[typing.Union["SageMakerNotebookLifecycleConfigStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker Notebook Lifecycle Config State Change.

        :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param last_modified_time: (experimental) LastModifiedTime property. Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notebook_instance_lifecycle_config_arn: (experimental) NotebookInstanceLifecycleConfigArn property. Specify an array of string values to match this event if the actual value of NotebookInstanceLifecycleConfigArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param notebook_instance_lifecycle_config_name: (experimental) NotebookInstanceLifecycleConfigName property. Specify an array of string values to match this event if the actual value of NotebookInstanceLifecycleConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerNotebookLifecycleConfigStateChange.SageMakerNotebookLifecycleConfigStateChangeProps(
            creation_time=creation_time,
            event_metadata=event_metadata,
            last_modified_time=last_modified_time,
            notebook_instance_lifecycle_config_arn=notebook_instance_lifecycle_config_arn,
            notebook_instance_lifecycle_config_name=notebook_instance_lifecycle_config_name,
            tags=tags,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerNotebookLifecycleConfigStateChange.SageMakerNotebookLifecycleConfigStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "creation_time": "creationTime",
            "event_metadata": "eventMetadata",
            "last_modified_time": "lastModifiedTime",
            "notebook_instance_lifecycle_config_arn": "notebookInstanceLifecycleConfigArn",
            "notebook_instance_lifecycle_config_name": "notebookInstanceLifecycleConfigName",
            "tags": "tags",
        },
    )
    class SageMakerNotebookLifecycleConfigStateChangeProps:
        def __init__(
            self,
            *,
            creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            notebook_instance_lifecycle_config_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            notebook_instance_lifecycle_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["SageMakerNotebookLifecycleConfigStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerNotebookLifecycleConfigStateChange event.

            :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param last_modified_time: (experimental) LastModifiedTime property. Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notebook_instance_lifecycle_config_arn: (experimental) NotebookInstanceLifecycleConfigArn property. Specify an array of string values to match this event if the actual value of NotebookInstanceLifecycleConfigArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param notebook_instance_lifecycle_config_name: (experimental) NotebookInstanceLifecycleConfigName property. Specify an array of string values to match this event if the actual value of NotebookInstanceLifecycleConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_notebook_lifecycle_config_state_change_props = sagemaker_events.SageMakerNotebookLifecycleConfigStateChange.SageMakerNotebookLifecycleConfigStateChangeProps(
                    creation_time=["creationTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    last_modified_time=["lastModifiedTime"],
                    notebook_instance_lifecycle_config_arn=["notebookInstanceLifecycleConfigArn"],
                    notebook_instance_lifecycle_config_name=["notebookInstanceLifecycleConfigName"],
                    tags=[sagemaker_events.SageMakerNotebookLifecycleConfigStateChange.Tags(
                        key=["key"],
                        value=["value"]
                    )]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b99ec7bf0d2599431707603d89e8b2e72b79a4bab46ac3f56cea0c79ed644fa3)
                check_type(argname="argument creation_time", value=creation_time, expected_type=type_hints["creation_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument last_modified_time", value=last_modified_time, expected_type=type_hints["last_modified_time"])
                check_type(argname="argument notebook_instance_lifecycle_config_arn", value=notebook_instance_lifecycle_config_arn, expected_type=type_hints["notebook_instance_lifecycle_config_arn"])
                check_type(argname="argument notebook_instance_lifecycle_config_name", value=notebook_instance_lifecycle_config_name, expected_type=type_hints["notebook_instance_lifecycle_config_name"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_time is not None:
                self._values["creation_time"] = creation_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if last_modified_time is not None:
                self._values["last_modified_time"] = last_modified_time
            if notebook_instance_lifecycle_config_arn is not None:
                self._values["notebook_instance_lifecycle_config_arn"] = notebook_instance_lifecycle_config_arn
            if notebook_instance_lifecycle_config_name is not None:
                self._values["notebook_instance_lifecycle_config_name"] = notebook_instance_lifecycle_config_name
            if tags is not None:
                self._values["tags"] = tags

        @builtins.property
        def creation_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CreationTime property.

            Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def last_modified_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LastModifiedTime property.

            Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_modified_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notebook_instance_lifecycle_config_arn(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) NotebookInstanceLifecycleConfigArn property.

            Specify an array of string values to match this event if the actual value of NotebookInstanceLifecycleConfigArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notebook_instance_lifecycle_config_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def notebook_instance_lifecycle_config_name(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) NotebookInstanceLifecycleConfigName property.

            Specify an array of string values to match this event if the actual value of NotebookInstanceLifecycleConfigName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("notebook_instance_lifecycle_config_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["SageMakerNotebookLifecycleConfigStateChange.Tags"]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["SageMakerNotebookLifecycleConfigStateChange.Tags"]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerNotebookLifecycleConfigStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerNotebookLifecycleConfigStateChange.Tags",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class Tags:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tags.

            :param key: (experimental) Key property. Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) Value property. Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                tags = sagemaker_events.SageMakerNotebookLifecycleConfigStateChange.Tags(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__01c7d0ad412271077fee7d9199abb53b18e14114a86ec97a4abd6a0f692e66a2)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Key property.

            Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Value property.

            Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Tags(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SageMakerTrainingJobStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTrainingJobStateChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerTrainingJobStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_training_job_state_change = sagemaker_events.SageMakerTrainingJobStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        algorithm_specification: typing.Optional[typing.Union["SageMakerTrainingJobStateChange.AlgorithmSpecification", typing.Dict[builtins.str, typing.Any]]] = None,
        creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        hyper_parameters: typing.Optional[typing.Sequence[builtins.str]] = None,
        input_data_config: typing.Optional[typing.Sequence[typing.Union["SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem", typing.Dict[builtins.str, typing.Any]]]] = None,
        last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        model_artifacts: typing.Optional[typing.Union["SageMakerTrainingJobStateChange.ModelArtifacts", typing.Dict[builtins.str, typing.Any]]] = None,
        output_data_config: typing.Optional[typing.Union["SageMakerTrainingJobStateChange.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        resource_config: typing.Optional[typing.Union["SageMakerTrainingJobStateChange.ResourceConfig", typing.Dict[builtins.str, typing.Any]]] = None,
        role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        secondary_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        secondary_status_transitions: typing.Optional[typing.Sequence[typing.Union["SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem1", typing.Dict[builtins.str, typing.Any]]]] = None,
        stopping_condition: typing.Optional[typing.Union["SageMakerTrainingJobStateChange.StoppingCondition", typing.Dict[builtins.str, typing.Any]]] = None,
        tags: typing.Optional[typing.Sequence[typing.Union["SageMakerTrainingJobStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
        training_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        training_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        training_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        training_job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        training_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker Training Job State Change.

        :param algorithm_specification: (experimental) AlgorithmSpecification property. Specify an array of string values to match this event if the actual value of AlgorithmSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param hyper_parameters: (experimental) HyperParameters property. Specify an array of string values to match this event if the actual value of HyperParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param input_data_config: (experimental) InputDataConfig property. Specify an array of string values to match this event if the actual value of InputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param last_modified_time: (experimental) LastModifiedTime property. Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param model_artifacts: (experimental) ModelArtifacts property. Specify an array of string values to match this event if the actual value of ModelArtifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param output_data_config: (experimental) OutputDataConfig property. Specify an array of string values to match this event if the actual value of OutputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param resource_config: (experimental) ResourceConfig property. Specify an array of string values to match this event if the actual value of ResourceConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param role_arn: (experimental) RoleArn property. Specify an array of string values to match this event if the actual value of RoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param secondary_status: (experimental) SecondaryStatus property. Specify an array of string values to match this event if the actual value of SecondaryStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param secondary_status_transitions: (experimental) SecondaryStatusTransitions property. Specify an array of string values to match this event if the actual value of SecondaryStatusTransitions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param stopping_condition: (experimental) StoppingCondition property. Specify an array of string values to match this event if the actual value of StoppingCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param training_end_time: (experimental) TrainingEndTime property. Specify an array of string values to match this event if the actual value of TrainingEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param training_job_arn: (experimental) TrainingJobArn property. Specify an array of string values to match this event if the actual value of TrainingJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param training_job_name: (experimental) TrainingJobName property. Specify an array of string values to match this event if the actual value of TrainingJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param training_job_status: (experimental) TrainingJobStatus property. Specify an array of string values to match this event if the actual value of TrainingJobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param training_start_time: (experimental) TrainingStartTime property. Specify an array of string values to match this event if the actual value of TrainingStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeProps(
            algorithm_specification=algorithm_specification,
            creation_time=creation_time,
            event_metadata=event_metadata,
            hyper_parameters=hyper_parameters,
            input_data_config=input_data_config,
            last_modified_time=last_modified_time,
            model_artifacts=model_artifacts,
            output_data_config=output_data_config,
            resource_config=resource_config,
            role_arn=role_arn,
            secondary_status=secondary_status,
            secondary_status_transitions=secondary_status_transitions,
            stopping_condition=stopping_condition,
            tags=tags,
            training_end_time=training_end_time,
            training_job_arn=training_job_arn,
            training_job_name=training_job_name,
            training_job_status=training_job_status,
            training_start_time=training_start_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTrainingJobStateChange.AlgorithmSpecification",
        jsii_struct_bases=[],
        name_mapping={
            "training_image": "trainingImage",
            "training_input_mode": "trainingInputMode",
        },
    )
    class AlgorithmSpecification:
        def __init__(
            self,
            *,
            training_image: typing.Optional[typing.Sequence[builtins.str]] = None,
            training_input_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for AlgorithmSpecification.

            :param training_image: (experimental) TrainingImage property. Specify an array of string values to match this event if the actual value of TrainingImage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_input_mode: (experimental) TrainingInputMode property. Specify an array of string values to match this event if the actual value of TrainingInputMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                algorithm_specification = sagemaker_events.SageMakerTrainingJobStateChange.AlgorithmSpecification(
                    training_image=["trainingImage"],
                    training_input_mode=["trainingInputMode"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__43f53214e1cbca6a5ab2a82a559714d1717a87d7bffbe160cf5701fddf956633)
                check_type(argname="argument training_image", value=training_image, expected_type=type_hints["training_image"])
                check_type(argname="argument training_input_mode", value=training_input_mode, expected_type=type_hints["training_input_mode"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if training_image is not None:
                self._values["training_image"] = training_image
            if training_input_mode is not None:
                self._values["training_input_mode"] = training_input_mode

        @builtins.property
        def training_image(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TrainingImage property.

            Specify an array of string values to match this event if the actual value of TrainingImage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_image")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def training_input_mode(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TrainingInputMode property.

            Specify an array of string values to match this event if the actual value of TrainingInputMode is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_input_mode")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "AlgorithmSpecification(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTrainingJobStateChange.DataSource",
        jsii_struct_bases=[],
        name_mapping={"s3_data_source": "s3DataSource"},
    )
    class DataSource:
        def __init__(
            self,
            *,
            s3_data_source: typing.Optional[typing.Union["SageMakerTrainingJobStateChange.S3DataSource", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for DataSource.

            :param s3_data_source: (experimental) S3DataSource property. Specify an array of string values to match this event if the actual value of S3DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                data_source = sagemaker_events.SageMakerTrainingJobStateChange.DataSource(
                    s3_data_source=sagemaker_events.SageMakerTrainingJobStateChange.S3DataSource(
                        s3_data_distribution_type=["s3DataDistributionType"],
                        s3_data_type=["s3DataType"],
                        s3_uri=["s3Uri"]
                    )
                )
            '''
            if isinstance(s3_data_source, dict):
                s3_data_source = SageMakerTrainingJobStateChange.S3DataSource(**s3_data_source)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__fb58727138a14450269c5dfbf63ddb73c60cf8b9f6a7ac184ed07c144c64feef)
                check_type(argname="argument s3_data_source", value=s3_data_source, expected_type=type_hints["s3_data_source"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_data_source is not None:
                self._values["s3_data_source"] = s3_data_source

        @builtins.property
        def s3_data_source(
            self,
        ) -> typing.Optional["SageMakerTrainingJobStateChange.S3DataSource"]:
            '''(experimental) S3DataSource property.

            Specify an array of string values to match this event if the actual value of S3DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_source")
            return typing.cast(typing.Optional["SageMakerTrainingJobStateChange.S3DataSource"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataSource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTrainingJobStateChange.ModelArtifacts",
        jsii_struct_bases=[],
        name_mapping={"s3_model_artifacts": "s3ModelArtifacts"},
    )
    class ModelArtifacts:
        def __init__(
            self,
            *,
            s3_model_artifacts: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ModelArtifacts.

            :param s3_model_artifacts: (experimental) S3ModelArtifacts property. Specify an array of string values to match this event if the actual value of S3ModelArtifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                model_artifacts = sagemaker_events.SageMakerTrainingJobStateChange.ModelArtifacts(
                    s3_model_artifacts=["s3ModelArtifacts"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__35c63987451d129309204268c89e3523e92b727fe85cf3b23aec136041d2e44b)
                check_type(argname="argument s3_model_artifacts", value=s3_model_artifacts, expected_type=type_hints["s3_model_artifacts"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_model_artifacts is not None:
                self._values["s3_model_artifacts"] = s3_model_artifacts

        @builtins.property
        def s3_model_artifacts(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) S3ModelArtifacts property.

            Specify an array of string values to match this event if the actual value of S3ModelArtifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_model_artifacts")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ModelArtifacts(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTrainingJobStateChange.OutputDataConfig",
        jsii_struct_bases=[],
        name_mapping={"s3_output_path": "s3OutputPath"},
    )
    class OutputDataConfig:
        def __init__(
            self,
            *,
            s3_output_path: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for OutputDataConfig.

            :param s3_output_path: (experimental) S3OutputPath property. Specify an array of string values to match this event if the actual value of S3OutputPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                output_data_config = sagemaker_events.SageMakerTrainingJobStateChange.OutputDataConfig(
                    s3_output_path=["s3OutputPath"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__5eb72babaa7b42bbfe25560f6d915c7152cf57d25e0c66ee7870eb247591a2c1)
                check_type(argname="argument s3_output_path", value=s3_output_path, expected_type=type_hints["s3_output_path"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_output_path is not None:
                self._values["s3_output_path"] = s3_output_path

        @builtins.property
        def s3_output_path(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) S3OutputPath property.

            Specify an array of string values to match this event if the actual value of S3OutputPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_output_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "OutputDataConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTrainingJobStateChange.ResourceConfig",
        jsii_struct_bases=[],
        name_mapping={
            "instance_count": "instanceCount",
            "instance_type": "instanceType",
            "volume_size_in_gb": "volumeSizeInGb",
        },
    )
    class ResourceConfig:
        def __init__(
            self,
            *,
            instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            volume_size_in_gb: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for ResourceConfig.

            :param instance_count: (experimental) InstanceCount property. Specify an array of string values to match this event if the actual value of InstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) InstanceType property. Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param volume_size_in_gb: (experimental) VolumeSizeInGB property. Specify an array of string values to match this event if the actual value of VolumeSizeInGB is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                resource_config = sagemaker_events.SageMakerTrainingJobStateChange.ResourceConfig(
                    instance_count=["instanceCount"],
                    instance_type=["instanceType"],
                    volume_size_in_gb=["volumeSizeInGb"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4ae20a94bd8f39ea65993889f58175d358b608c71976d9cb997a9e32b383f0e5)
                check_type(argname="argument instance_count", value=instance_count, expected_type=type_hints["instance_count"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
                check_type(argname="argument volume_size_in_gb", value=volume_size_in_gb, expected_type=type_hints["volume_size_in_gb"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if instance_count is not None:
                self._values["instance_count"] = instance_count
            if instance_type is not None:
                self._values["instance_type"] = instance_type
            if volume_size_in_gb is not None:
                self._values["volume_size_in_gb"] = volume_size_in_gb

        @builtins.property
        def instance_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstanceCount property.

            Specify an array of string values to match this event if the actual value of InstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstanceType property.

            Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def volume_size_in_gb(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) VolumeSizeInGB property.

            Specify an array of string values to match this event if the actual value of VolumeSizeInGB is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("volume_size_in_gb")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ResourceConfig(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTrainingJobStateChange.S3DataSource",
        jsii_struct_bases=[],
        name_mapping={
            "s3_data_distribution_type": "s3DataDistributionType",
            "s3_data_type": "s3DataType",
            "s3_uri": "s3Uri",
        },
    )
    class S3DataSource:
        def __init__(
            self,
            *,
            s3_data_distribution_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_data_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for S3DataSource.

            :param s3_data_distribution_type: (experimental) S3DataDistributionType property. Specify an array of string values to match this event if the actual value of S3DataDistributionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_data_type: (experimental) S3DataType property. Specify an array of string values to match this event if the actual value of S3DataType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_uri: (experimental) S3Uri property. Specify an array of string values to match this event if the actual value of S3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                s3_data_source = sagemaker_events.SageMakerTrainingJobStateChange.S3DataSource(
                    s3_data_distribution_type=["s3DataDistributionType"],
                    s3_data_type=["s3DataType"],
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__06e7706b4f2c08eedd32fe28ee91a1b62ab00a82ec32bf01aa2b04a8c7bd395d)
                check_type(argname="argument s3_data_distribution_type", value=s3_data_distribution_type, expected_type=type_hints["s3_data_distribution_type"])
                check_type(argname="argument s3_data_type", value=s3_data_type, expected_type=type_hints["s3_data_type"])
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_data_distribution_type is not None:
                self._values["s3_data_distribution_type"] = s3_data_distribution_type
            if s3_data_type is not None:
                self._values["s3_data_type"] = s3_data_type
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_data_distribution_type(
            self,
        ) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) S3DataDistributionType property.

            Specify an array of string values to match this event if the actual value of S3DataDistributionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_distribution_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_data_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) S3DataType property.

            Specify an array of string values to match this event if the actual value of S3DataType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) S3Uri property.

            Specify an array of string values to match this event if the actual value of S3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "S3DataSource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem",
        jsii_struct_bases=[],
        name_mapping={
            "channel_name": "channelName",
            "compression_type": "compressionType",
            "content_type": "contentType",
            "data_source": "dataSource",
            "record_wrapper_type": "recordWrapperType",
        },
    )
    class SageMakerTrainingJobStateChangeItem:
        def __init__(
            self,
            *,
            channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            compression_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            content_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            data_source: typing.Optional[typing.Union["SageMakerTrainingJobStateChange.DataSource", typing.Dict[builtins.str, typing.Any]]] = None,
            record_wrapper_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SageMakerTrainingJobStateChangeItem.

            :param channel_name: (experimental) ChannelName property. Specify an array of string values to match this event if the actual value of ChannelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param compression_type: (experimental) CompressionType property. Specify an array of string values to match this event if the actual value of CompressionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param content_type: (experimental) ContentType property. Specify an array of string values to match this event if the actual value of ContentType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source: (experimental) DataSource property. Specify an array of string values to match this event if the actual value of DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param record_wrapper_type: (experimental) RecordWrapperType property. Specify an array of string values to match this event if the actual value of RecordWrapperType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_training_job_state_change_item = sagemaker_events.SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem(
                    channel_name=["channelName"],
                    compression_type=["compressionType"],
                    content_type=["contentType"],
                    data_source=sagemaker_events.SageMakerTrainingJobStateChange.DataSource(
                        s3_data_source=sagemaker_events.SageMakerTrainingJobStateChange.S3DataSource(
                            s3_data_distribution_type=["s3DataDistributionType"],
                            s3_data_type=["s3DataType"],
                            s3_uri=["s3Uri"]
                        )
                    ),
                    record_wrapper_type=["recordWrapperType"]
                )
            '''
            if isinstance(data_source, dict):
                data_source = SageMakerTrainingJobStateChange.DataSource(**data_source)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__b8b043f531889403117210717ed1cefdefa99de656f142b2ddecf3d7475fc2f4)
                check_type(argname="argument channel_name", value=channel_name, expected_type=type_hints["channel_name"])
                check_type(argname="argument compression_type", value=compression_type, expected_type=type_hints["compression_type"])
                check_type(argname="argument content_type", value=content_type, expected_type=type_hints["content_type"])
                check_type(argname="argument data_source", value=data_source, expected_type=type_hints["data_source"])
                check_type(argname="argument record_wrapper_type", value=record_wrapper_type, expected_type=type_hints["record_wrapper_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if channel_name is not None:
                self._values["channel_name"] = channel_name
            if compression_type is not None:
                self._values["compression_type"] = compression_type
            if content_type is not None:
                self._values["content_type"] = content_type
            if data_source is not None:
                self._values["data_source"] = data_source
            if record_wrapper_type is not None:
                self._values["record_wrapper_type"] = record_wrapper_type

        @builtins.property
        def channel_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ChannelName property.

            Specify an array of string values to match this event if the actual value of ChannelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("channel_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def compression_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CompressionType property.

            Specify an array of string values to match this event if the actual value of CompressionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("compression_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def content_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ContentType property.

            Specify an array of string values to match this event if the actual value of ContentType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("content_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data_source(
            self,
        ) -> typing.Optional["SageMakerTrainingJobStateChange.DataSource"]:
            '''(experimental) DataSource property.

            Specify an array of string values to match this event if the actual value of DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source")
            return typing.cast(typing.Optional["SageMakerTrainingJobStateChange.DataSource"], result)

        @builtins.property
        def record_wrapper_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) RecordWrapperType property.

            Specify an array of string values to match this event if the actual value of RecordWrapperType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("record_wrapper_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerTrainingJobStateChangeItem(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem1",
        jsii_struct_bases=[],
        name_mapping={
            "start_time": "startTime",
            "status": "status",
            "status_message": "statusMessage",
        },
    )
    class SageMakerTrainingJobStateChangeItem1:
        def __init__(
            self,
            *,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            status: typing.Optional[typing.Sequence[builtins.str]] = None,
            status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for SageMakerTrainingJobStateChangeItem_1.

            :param start_time: (experimental) StartTime property. Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status: (experimental) Status property. Specify an array of string values to match this event if the actual value of Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param status_message: (experimental) StatusMessage property. Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_training_job_state_change_item1 = sagemaker_events.SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem1(
                    start_time=["startTime"],
                    status=["status"],
                    status_message=["statusMessage"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__da90dc864d06cec78b9db7ed59f25bdb62a7a3d0d1c18ca85a9abe1bb8f74fdd)
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument status", value=status, expected_type=type_hints["status"])
                check_type(argname="argument status_message", value=status_message, expected_type=type_hints["status_message"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if start_time is not None:
                self._values["start_time"] = start_time
            if status is not None:
                self._values["status"] = status
            if status_message is not None:
                self._values["status_message"] = status_message

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StartTime property.

            Specify an array of string values to match this event if the actual value of StartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Status property.

            Specify an array of string values to match this event if the actual value of Status is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def status_message(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) StatusMessage property.

            Specify an array of string values to match this event if the actual value of StatusMessage is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("status_message")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerTrainingJobStateChangeItem1(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "algorithm_specification": "algorithmSpecification",
            "creation_time": "creationTime",
            "event_metadata": "eventMetadata",
            "hyper_parameters": "hyperParameters",
            "input_data_config": "inputDataConfig",
            "last_modified_time": "lastModifiedTime",
            "model_artifacts": "modelArtifacts",
            "output_data_config": "outputDataConfig",
            "resource_config": "resourceConfig",
            "role_arn": "roleArn",
            "secondary_status": "secondaryStatus",
            "secondary_status_transitions": "secondaryStatusTransitions",
            "stopping_condition": "stoppingCondition",
            "tags": "tags",
            "training_end_time": "trainingEndTime",
            "training_job_arn": "trainingJobArn",
            "training_job_name": "trainingJobName",
            "training_job_status": "trainingJobStatus",
            "training_start_time": "trainingStartTime",
        },
    )
    class SageMakerTrainingJobStateChangeProps:
        def __init__(
            self,
            *,
            algorithm_specification: typing.Optional[typing.Union["SageMakerTrainingJobStateChange.AlgorithmSpecification", typing.Dict[builtins.str, typing.Any]]] = None,
            creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            hyper_parameters: typing.Optional[typing.Sequence[builtins.str]] = None,
            input_data_config: typing.Optional[typing.Sequence[typing.Union["SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem", typing.Dict[builtins.str, typing.Any]]]] = None,
            last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            model_artifacts: typing.Optional[typing.Union["SageMakerTrainingJobStateChange.ModelArtifacts", typing.Dict[builtins.str, typing.Any]]] = None,
            output_data_config: typing.Optional[typing.Union["SageMakerTrainingJobStateChange.OutputDataConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            resource_config: typing.Optional[typing.Union["SageMakerTrainingJobStateChange.ResourceConfig", typing.Dict[builtins.str, typing.Any]]] = None,
            role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            secondary_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            secondary_status_transitions: typing.Optional[typing.Sequence[typing.Union["SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem1", typing.Dict[builtins.str, typing.Any]]]] = None,
            stopping_condition: typing.Optional[typing.Union["SageMakerTrainingJobStateChange.StoppingCondition", typing.Dict[builtins.str, typing.Any]]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["SageMakerTrainingJobStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
            training_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            training_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            training_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            training_job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            training_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerTrainingJobStateChange event.

            :param algorithm_specification: (experimental) AlgorithmSpecification property. Specify an array of string values to match this event if the actual value of AlgorithmSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param hyper_parameters: (experimental) HyperParameters property. Specify an array of string values to match this event if the actual value of HyperParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param input_data_config: (experimental) InputDataConfig property. Specify an array of string values to match this event if the actual value of InputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param last_modified_time: (experimental) LastModifiedTime property. Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param model_artifacts: (experimental) ModelArtifacts property. Specify an array of string values to match this event if the actual value of ModelArtifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param output_data_config: (experimental) OutputDataConfig property. Specify an array of string values to match this event if the actual value of OutputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param resource_config: (experimental) ResourceConfig property. Specify an array of string values to match this event if the actual value of ResourceConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param role_arn: (experimental) RoleArn property. Specify an array of string values to match this event if the actual value of RoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param secondary_status: (experimental) SecondaryStatus property. Specify an array of string values to match this event if the actual value of SecondaryStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param secondary_status_transitions: (experimental) SecondaryStatusTransitions property. Specify an array of string values to match this event if the actual value of SecondaryStatusTransitions is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stopping_condition: (experimental) StoppingCondition property. Specify an array of string values to match this event if the actual value of StoppingCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_end_time: (experimental) TrainingEndTime property. Specify an array of string values to match this event if the actual value of TrainingEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_job_arn: (experimental) TrainingJobArn property. Specify an array of string values to match this event if the actual value of TrainingJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_job_name: (experimental) TrainingJobName property. Specify an array of string values to match this event if the actual value of TrainingJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_job_status: (experimental) TrainingJobStatus property. Specify an array of string values to match this event if the actual value of TrainingJobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param training_start_time: (experimental) TrainingStartTime property. Specify an array of string values to match this event if the actual value of TrainingStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_training_job_state_change_props = sagemaker_events.SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeProps(
                    algorithm_specification=sagemaker_events.SageMakerTrainingJobStateChange.AlgorithmSpecification(
                        training_image=["trainingImage"],
                        training_input_mode=["trainingInputMode"]
                    ),
                    creation_time=["creationTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    hyper_parameters=["hyperParameters"],
                    input_data_config=[sagemaker_events.SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem(
                        channel_name=["channelName"],
                        compression_type=["compressionType"],
                        content_type=["contentType"],
                        data_source=sagemaker_events.SageMakerTrainingJobStateChange.DataSource(
                            s3_data_source=sagemaker_events.SageMakerTrainingJobStateChange.S3DataSource(
                                s3_data_distribution_type=["s3DataDistributionType"],
                                s3_data_type=["s3DataType"],
                                s3_uri=["s3Uri"]
                            )
                        ),
                        record_wrapper_type=["recordWrapperType"]
                    )],
                    last_modified_time=["lastModifiedTime"],
                    model_artifacts=sagemaker_events.SageMakerTrainingJobStateChange.ModelArtifacts(
                        s3_model_artifacts=["s3ModelArtifacts"]
                    ),
                    output_data_config=sagemaker_events.SageMakerTrainingJobStateChange.OutputDataConfig(
                        s3_output_path=["s3OutputPath"]
                    ),
                    resource_config=sagemaker_events.SageMakerTrainingJobStateChange.ResourceConfig(
                        instance_count=["instanceCount"],
                        instance_type=["instanceType"],
                        volume_size_in_gb=["volumeSizeInGb"]
                    ),
                    role_arn=["roleArn"],
                    secondary_status=["secondaryStatus"],
                    secondary_status_transitions=[sagemaker_events.SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem1(
                        start_time=["startTime"],
                        status=["status"],
                        status_message=["statusMessage"]
                    )],
                    stopping_condition=sagemaker_events.SageMakerTrainingJobStateChange.StoppingCondition(
                        max_runtime_in_seconds=["maxRuntimeInSeconds"]
                    ),
                    tags=[sagemaker_events.SageMakerTrainingJobStateChange.Tags(
                        key=["key"],
                        value=["value"]
                    )],
                    training_end_time=["trainingEndTime"],
                    training_job_arn=["trainingJobArn"],
                    training_job_name=["trainingJobName"],
                    training_job_status=["trainingJobStatus"],
                    training_start_time=["trainingStartTime"]
                )
            '''
            if isinstance(algorithm_specification, dict):
                algorithm_specification = SageMakerTrainingJobStateChange.AlgorithmSpecification(**algorithm_specification)
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(model_artifacts, dict):
                model_artifacts = SageMakerTrainingJobStateChange.ModelArtifacts(**model_artifacts)
            if isinstance(output_data_config, dict):
                output_data_config = SageMakerTrainingJobStateChange.OutputDataConfig(**output_data_config)
            if isinstance(resource_config, dict):
                resource_config = SageMakerTrainingJobStateChange.ResourceConfig(**resource_config)
            if isinstance(stopping_condition, dict):
                stopping_condition = SageMakerTrainingJobStateChange.StoppingCondition(**stopping_condition)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__4bc020f96407de1e4bd1abc9ef1fc2849bd27d43407b5ab843ce1bb568b2a0fd)
                check_type(argname="argument algorithm_specification", value=algorithm_specification, expected_type=type_hints["algorithm_specification"])
                check_type(argname="argument creation_time", value=creation_time, expected_type=type_hints["creation_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument hyper_parameters", value=hyper_parameters, expected_type=type_hints["hyper_parameters"])
                check_type(argname="argument input_data_config", value=input_data_config, expected_type=type_hints["input_data_config"])
                check_type(argname="argument last_modified_time", value=last_modified_time, expected_type=type_hints["last_modified_time"])
                check_type(argname="argument model_artifacts", value=model_artifacts, expected_type=type_hints["model_artifacts"])
                check_type(argname="argument output_data_config", value=output_data_config, expected_type=type_hints["output_data_config"])
                check_type(argname="argument resource_config", value=resource_config, expected_type=type_hints["resource_config"])
                check_type(argname="argument role_arn", value=role_arn, expected_type=type_hints["role_arn"])
                check_type(argname="argument secondary_status", value=secondary_status, expected_type=type_hints["secondary_status"])
                check_type(argname="argument secondary_status_transitions", value=secondary_status_transitions, expected_type=type_hints["secondary_status_transitions"])
                check_type(argname="argument stopping_condition", value=stopping_condition, expected_type=type_hints["stopping_condition"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
                check_type(argname="argument training_end_time", value=training_end_time, expected_type=type_hints["training_end_time"])
                check_type(argname="argument training_job_arn", value=training_job_arn, expected_type=type_hints["training_job_arn"])
                check_type(argname="argument training_job_name", value=training_job_name, expected_type=type_hints["training_job_name"])
                check_type(argname="argument training_job_status", value=training_job_status, expected_type=type_hints["training_job_status"])
                check_type(argname="argument training_start_time", value=training_start_time, expected_type=type_hints["training_start_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if algorithm_specification is not None:
                self._values["algorithm_specification"] = algorithm_specification
            if creation_time is not None:
                self._values["creation_time"] = creation_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if hyper_parameters is not None:
                self._values["hyper_parameters"] = hyper_parameters
            if input_data_config is not None:
                self._values["input_data_config"] = input_data_config
            if last_modified_time is not None:
                self._values["last_modified_time"] = last_modified_time
            if model_artifacts is not None:
                self._values["model_artifacts"] = model_artifacts
            if output_data_config is not None:
                self._values["output_data_config"] = output_data_config
            if resource_config is not None:
                self._values["resource_config"] = resource_config
            if role_arn is not None:
                self._values["role_arn"] = role_arn
            if secondary_status is not None:
                self._values["secondary_status"] = secondary_status
            if secondary_status_transitions is not None:
                self._values["secondary_status_transitions"] = secondary_status_transitions
            if stopping_condition is not None:
                self._values["stopping_condition"] = stopping_condition
            if tags is not None:
                self._values["tags"] = tags
            if training_end_time is not None:
                self._values["training_end_time"] = training_end_time
            if training_job_arn is not None:
                self._values["training_job_arn"] = training_job_arn
            if training_job_name is not None:
                self._values["training_job_name"] = training_job_name
            if training_job_status is not None:
                self._values["training_job_status"] = training_job_status
            if training_start_time is not None:
                self._values["training_start_time"] = training_start_time

        @builtins.property
        def algorithm_specification(
            self,
        ) -> typing.Optional["SageMakerTrainingJobStateChange.AlgorithmSpecification"]:
            '''(experimental) AlgorithmSpecification property.

            Specify an array of string values to match this event if the actual value of AlgorithmSpecification is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("algorithm_specification")
            return typing.cast(typing.Optional["SageMakerTrainingJobStateChange.AlgorithmSpecification"], result)

        @builtins.property
        def creation_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CreationTime property.

            Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def hyper_parameters(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) HyperParameters property.

            Specify an array of string values to match this event if the actual value of HyperParameters is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("hyper_parameters")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def input_data_config(
            self,
        ) -> typing.Optional[typing.List["SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem"]]:
            '''(experimental) InputDataConfig property.

            Specify an array of string values to match this event if the actual value of InputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("input_data_config")
            return typing.cast(typing.Optional[typing.List["SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem"]], result)

        @builtins.property
        def last_modified_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) LastModifiedTime property.

            Specify an array of string values to match this event if the actual value of LastModifiedTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("last_modified_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def model_artifacts(
            self,
        ) -> typing.Optional["SageMakerTrainingJobStateChange.ModelArtifacts"]:
            '''(experimental) ModelArtifacts property.

            Specify an array of string values to match this event if the actual value of ModelArtifacts is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_artifacts")
            return typing.cast(typing.Optional["SageMakerTrainingJobStateChange.ModelArtifacts"], result)

        @builtins.property
        def output_data_config(
            self,
        ) -> typing.Optional["SageMakerTrainingJobStateChange.OutputDataConfig"]:
            '''(experimental) OutputDataConfig property.

            Specify an array of string values to match this event if the actual value of OutputDataConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("output_data_config")
            return typing.cast(typing.Optional["SageMakerTrainingJobStateChange.OutputDataConfig"], result)

        @builtins.property
        def resource_config(
            self,
        ) -> typing.Optional["SageMakerTrainingJobStateChange.ResourceConfig"]:
            '''(experimental) ResourceConfig property.

            Specify an array of string values to match this event if the actual value of ResourceConfig is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("resource_config")
            return typing.cast(typing.Optional["SageMakerTrainingJobStateChange.ResourceConfig"], result)

        @builtins.property
        def role_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) RoleArn property.

            Specify an array of string values to match this event if the actual value of RoleArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("role_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def secondary_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SecondaryStatus property.

            Specify an array of string values to match this event if the actual value of SecondaryStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("secondary_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def secondary_status_transitions(
            self,
        ) -> typing.Optional[typing.List["SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem1"]]:
            '''(experimental) SecondaryStatusTransitions property.

            Specify an array of string values to match this event if the actual value of SecondaryStatusTransitions is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("secondary_status_transitions")
            return typing.cast(typing.Optional[typing.List["SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem1"]], result)

        @builtins.property
        def stopping_condition(
            self,
        ) -> typing.Optional["SageMakerTrainingJobStateChange.StoppingCondition"]:
            '''(experimental) StoppingCondition property.

            Specify an array of string values to match this event if the actual value of StoppingCondition is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stopping_condition")
            return typing.cast(typing.Optional["SageMakerTrainingJobStateChange.StoppingCondition"], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["SageMakerTrainingJobStateChange.Tags"]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["SageMakerTrainingJobStateChange.Tags"]], result)

        @builtins.property
        def training_end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TrainingEndTime property.

            Specify an array of string values to match this event if the actual value of TrainingEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def training_job_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TrainingJobArn property.

            Specify an array of string values to match this event if the actual value of TrainingJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_job_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def training_job_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TrainingJobName property.

            Specify an array of string values to match this event if the actual value of TrainingJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_job_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def training_job_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TrainingJobStatus property.

            Specify an array of string values to match this event if the actual value of TrainingJobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_job_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def training_start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TrainingStartTime property.

            Specify an array of string values to match this event if the actual value of TrainingStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("training_start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerTrainingJobStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTrainingJobStateChange.StoppingCondition",
        jsii_struct_bases=[],
        name_mapping={"max_runtime_in_seconds": "maxRuntimeInSeconds"},
    )
    class StoppingCondition:
        def __init__(
            self,
            *,
            max_runtime_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for StoppingCondition.

            :param max_runtime_in_seconds: (experimental) MaxRuntimeInSeconds property. Specify an array of string values to match this event if the actual value of MaxRuntimeInSeconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                stopping_condition = sagemaker_events.SageMakerTrainingJobStateChange.StoppingCondition(
                    max_runtime_in_seconds=["maxRuntimeInSeconds"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__f7173621d8f207434fd7a93371119a5c8d67b13716d8d81de304188c4b9fa510)
                check_type(argname="argument max_runtime_in_seconds", value=max_runtime_in_seconds, expected_type=type_hints["max_runtime_in_seconds"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if max_runtime_in_seconds is not None:
                self._values["max_runtime_in_seconds"] = max_runtime_in_seconds

        @builtins.property
        def max_runtime_in_seconds(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) MaxRuntimeInSeconds property.

            Specify an array of string values to match this event if the actual value of MaxRuntimeInSeconds is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("max_runtime_in_seconds")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "StoppingCondition(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTrainingJobStateChange.Tags",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class Tags:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tags.

            :param key: (experimental) Key property. Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) Value property. Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                tags = sagemaker_events.SageMakerTrainingJobStateChange.Tags(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1c0c4842ed88d2024767c0a8888a4692c45dff1b2e6886de561b861b5f2dbe4e)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Key property.

            Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Value property.

            Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Tags(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


class SageMakerTransformJobStateChange(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTransformJobStateChange",
):
    '''(experimental) EventBridge event pattern for aws.sagemaker@SageMakerTransformJobStateChange.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
        
        sage_maker_transform_job_state_change = sagemaker_events.SageMakerTransformJobStateChange()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        model_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        tags: typing.Optional[typing.Sequence[typing.Union["SageMakerTransformJobStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
        transform_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        transform_input: typing.Optional[typing.Union["SageMakerTransformJobStateChange.TransformInput", typing.Dict[builtins.str, typing.Any]]] = None,
        transform_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        transform_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
        transform_job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        transform_output: typing.Optional[typing.Union["SageMakerTransformJobStateChange.TransformOutput", typing.Dict[builtins.str, typing.Any]]] = None,
        transform_resources: typing.Optional[typing.Union["SageMakerTransformJobStateChange.TransformResources", typing.Dict[builtins.str, typing.Any]]] = None,
        transform_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for SageMaker Transform Job State Change.

        :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param model_name: (experimental) ModelName property. Specify an array of string values to match this event if the actual value of ModelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transform_end_time: (experimental) TransformEndTime property. Specify an array of string values to match this event if the actual value of TransformEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transform_input: (experimental) TransformInput property. Specify an array of string values to match this event if the actual value of TransformInput is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transform_job_arn: (experimental) TransformJobArn property. Specify an array of string values to match this event if the actual value of TransformJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transform_job_name: (experimental) TransformJobName property. Specify an array of string values to match this event if the actual value of TransformJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transform_job_status: (experimental) TransformJobStatus property. Specify an array of string values to match this event if the actual value of TransformJobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transform_output: (experimental) TransformOutput property. Specify an array of string values to match this event if the actual value of TransformOutput is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transform_resources: (experimental) TransformResources property. Specify an array of string values to match this event if the actual value of TransformResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transform_start_time: (experimental) TransformStartTime property. Specify an array of string values to match this event if the actual value of TransformStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = SageMakerTransformJobStateChange.SageMakerTransformJobStateChangeProps(
            creation_time=creation_time,
            event_metadata=event_metadata,
            model_name=model_name,
            tags=tags,
            transform_end_time=transform_end_time,
            transform_input=transform_input,
            transform_job_arn=transform_job_arn,
            transform_job_name=transform_job_name,
            transform_job_status=transform_job_status,
            transform_output=transform_output,
            transform_resources=transform_resources,
            transform_start_time=transform_start_time,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTransformJobStateChange.DataSource",
        jsii_struct_bases=[],
        name_mapping={"s3_data_source": "s3DataSource"},
    )
    class DataSource:
        def __init__(
            self,
            *,
            s3_data_source: typing.Optional[typing.Union["SageMakerTransformJobStateChange.S3DataSource", typing.Dict[builtins.str, typing.Any]]] = None,
        ) -> None:
            '''(experimental) Type definition for DataSource.

            :param s3_data_source: (experimental) S3DataSource property. Specify an array of string values to match this event if the actual value of S3DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                data_source = sagemaker_events.SageMakerTransformJobStateChange.DataSource(
                    s3_data_source=sagemaker_events.SageMakerTransformJobStateChange.S3DataSource(
                        s3_data_type=["s3DataType"],
                        s3_uri=["s3Uri"]
                    )
                )
            '''
            if isinstance(s3_data_source, dict):
                s3_data_source = SageMakerTransformJobStateChange.S3DataSource(**s3_data_source)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__1115c3415061162cae2d80507ae1113667c0744ef9e431ba15dc41ae3855d0b5)
                check_type(argname="argument s3_data_source", value=s3_data_source, expected_type=type_hints["s3_data_source"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_data_source is not None:
                self._values["s3_data_source"] = s3_data_source

        @builtins.property
        def s3_data_source(
            self,
        ) -> typing.Optional["SageMakerTransformJobStateChange.S3DataSource"]:
            '''(experimental) S3DataSource property.

            Specify an array of string values to match this event if the actual value of S3DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_source")
            return typing.cast(typing.Optional["SageMakerTransformJobStateChange.S3DataSource"], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "DataSource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTransformJobStateChange.S3DataSource",
        jsii_struct_bases=[],
        name_mapping={"s3_data_type": "s3DataType", "s3_uri": "s3Uri"},
    )
    class S3DataSource:
        def __init__(
            self,
            *,
            s3_data_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for S3DataSource.

            :param s3_data_type: (experimental) S3DataType property. Specify an array of string values to match this event if the actual value of S3DataType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_uri: (experimental) S3Uri property. Specify an array of string values to match this event if the actual value of S3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                s3_data_source = sagemaker_events.SageMakerTransformJobStateChange.S3DataSource(
                    s3_data_type=["s3DataType"],
                    s3_uri=["s3Uri"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c5b70b1c818d1988773bb6861f0952348c490ccf9b625101aa74ffde3239240b)
                check_type(argname="argument s3_data_type", value=s3_data_type, expected_type=type_hints["s3_data_type"])
                check_type(argname="argument s3_uri", value=s3_uri, expected_type=type_hints["s3_uri"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if s3_data_type is not None:
                self._values["s3_data_type"] = s3_data_type
            if s3_uri is not None:
                self._values["s3_uri"] = s3_uri

        @builtins.property
        def s3_data_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) S3DataType property.

            Specify an array of string values to match this event if the actual value of S3DataType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_data_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_uri(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) S3Uri property.

            Specify an array of string values to match this event if the actual value of S3Uri is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_uri")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "S3DataSource(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTransformJobStateChange.SageMakerTransformJobStateChangeProps",
        jsii_struct_bases=[],
        name_mapping={
            "creation_time": "creationTime",
            "event_metadata": "eventMetadata",
            "model_name": "modelName",
            "tags": "tags",
            "transform_end_time": "transformEndTime",
            "transform_input": "transformInput",
            "transform_job_arn": "transformJobArn",
            "transform_job_name": "transformJobName",
            "transform_job_status": "transformJobStatus",
            "transform_output": "transformOutput",
            "transform_resources": "transformResources",
            "transform_start_time": "transformStartTime",
        },
    )
    class SageMakerTransformJobStateChangeProps:
        def __init__(
            self,
            *,
            creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            model_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            tags: typing.Optional[typing.Sequence[typing.Union["SageMakerTransformJobStateChange.Tags", typing.Dict[builtins.str, typing.Any]]]] = None,
            transform_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            transform_input: typing.Optional[typing.Union["SageMakerTransformJobStateChange.TransformInput", typing.Dict[builtins.str, typing.Any]]] = None,
            transform_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            transform_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
            transform_job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            transform_output: typing.Optional[typing.Union["SageMakerTransformJobStateChange.TransformOutput", typing.Dict[builtins.str, typing.Any]]] = None,
            transform_resources: typing.Optional[typing.Union["SageMakerTransformJobStateChange.TransformResources", typing.Dict[builtins.str, typing.Any]]] = None,
            transform_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.sagemaker@SageMakerTransformJobStateChange event.

            :param creation_time: (experimental) CreationTime property. Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param model_name: (experimental) ModelName property. Specify an array of string values to match this event if the actual value of ModelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param tags: (experimental) Tags property. Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_end_time: (experimental) TransformEndTime property. Specify an array of string values to match this event if the actual value of TransformEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_input: (experimental) TransformInput property. Specify an array of string values to match this event if the actual value of TransformInput is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_job_arn: (experimental) TransformJobArn property. Specify an array of string values to match this event if the actual value of TransformJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_job_name: (experimental) TransformJobName property. Specify an array of string values to match this event if the actual value of TransformJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_job_status: (experimental) TransformJobStatus property. Specify an array of string values to match this event if the actual value of TransformJobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_output: (experimental) TransformOutput property. Specify an array of string values to match this event if the actual value of TransformOutput is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_resources: (experimental) TransformResources property. Specify an array of string values to match this event if the actual value of TransformResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transform_start_time: (experimental) TransformStartTime property. Specify an array of string values to match this event if the actual value of TransformStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                sage_maker_transform_job_state_change_props = sagemaker_events.SageMakerTransformJobStateChange.SageMakerTransformJobStateChangeProps(
                    creation_time=["creationTime"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    model_name=["modelName"],
                    tags=[sagemaker_events.SageMakerTransformJobStateChange.Tags(
                        key=["key"],
                        value=["value"]
                    )],
                    transform_end_time=["transformEndTime"],
                    transform_input=sagemaker_events.SageMakerTransformJobStateChange.TransformInput(
                        compression_type=["compressionType"],
                        content_type=["contentType"],
                        data_source=sagemaker_events.SageMakerTransformJobStateChange.DataSource(
                            s3_data_source=sagemaker_events.SageMakerTransformJobStateChange.S3DataSource(
                                s3_data_type=["s3DataType"],
                                s3_uri=["s3Uri"]
                            )
                        ),
                        split_type=["splitType"]
                    ),
                    transform_job_arn=["transformJobArn"],
                    transform_job_name=["transformJobName"],
                    transform_job_status=["transformJobStatus"],
                    transform_output=sagemaker_events.SageMakerTransformJobStateChange.TransformOutput(
                        assemble_with=["assembleWith"],
                        s3_output_path=["s3OutputPath"]
                    ),
                    transform_resources=sagemaker_events.SageMakerTransformJobStateChange.TransformResources(
                        instance_count=["instanceCount"],
                        instance_type=["instanceType"]
                    ),
                    transform_start_time=["transformStartTime"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if isinstance(transform_input, dict):
                transform_input = SageMakerTransformJobStateChange.TransformInput(**transform_input)
            if isinstance(transform_output, dict):
                transform_output = SageMakerTransformJobStateChange.TransformOutput(**transform_output)
            if isinstance(transform_resources, dict):
                transform_resources = SageMakerTransformJobStateChange.TransformResources(**transform_resources)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__89b2812cf592ed3f1a60aca19c0f7277dd42764ca98eb280f5e391df0fa8f54b)
                check_type(argname="argument creation_time", value=creation_time, expected_type=type_hints["creation_time"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument model_name", value=model_name, expected_type=type_hints["model_name"])
                check_type(argname="argument tags", value=tags, expected_type=type_hints["tags"])
                check_type(argname="argument transform_end_time", value=transform_end_time, expected_type=type_hints["transform_end_time"])
                check_type(argname="argument transform_input", value=transform_input, expected_type=type_hints["transform_input"])
                check_type(argname="argument transform_job_arn", value=transform_job_arn, expected_type=type_hints["transform_job_arn"])
                check_type(argname="argument transform_job_name", value=transform_job_name, expected_type=type_hints["transform_job_name"])
                check_type(argname="argument transform_job_status", value=transform_job_status, expected_type=type_hints["transform_job_status"])
                check_type(argname="argument transform_output", value=transform_output, expected_type=type_hints["transform_output"])
                check_type(argname="argument transform_resources", value=transform_resources, expected_type=type_hints["transform_resources"])
                check_type(argname="argument transform_start_time", value=transform_start_time, expected_type=type_hints["transform_start_time"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if creation_time is not None:
                self._values["creation_time"] = creation_time
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if model_name is not None:
                self._values["model_name"] = model_name
            if tags is not None:
                self._values["tags"] = tags
            if transform_end_time is not None:
                self._values["transform_end_time"] = transform_end_time
            if transform_input is not None:
                self._values["transform_input"] = transform_input
            if transform_job_arn is not None:
                self._values["transform_job_arn"] = transform_job_arn
            if transform_job_name is not None:
                self._values["transform_job_name"] = transform_job_name
            if transform_job_status is not None:
                self._values["transform_job_status"] = transform_job_status
            if transform_output is not None:
                self._values["transform_output"] = transform_output
            if transform_resources is not None:
                self._values["transform_resources"] = transform_resources
            if transform_start_time is not None:
                self._values["transform_start_time"] = transform_start_time

        @builtins.property
        def creation_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CreationTime property.

            Specify an array of string values to match this event if the actual value of CreationTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("creation_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def model_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ModelName property.

            Specify an array of string values to match this event if the actual value of ModelName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("model_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def tags(
            self,
        ) -> typing.Optional[typing.List["SageMakerTransformJobStateChange.Tags"]]:
            '''(experimental) Tags property.

            Specify an array of string values to match this event if the actual value of Tags is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("tags")
            return typing.cast(typing.Optional[typing.List["SageMakerTransformJobStateChange.Tags"]], result)

        @builtins.property
        def transform_end_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TransformEndTime property.

            Specify an array of string values to match this event if the actual value of TransformEndTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_end_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def transform_input(
            self,
        ) -> typing.Optional["SageMakerTransformJobStateChange.TransformInput"]:
            '''(experimental) TransformInput property.

            Specify an array of string values to match this event if the actual value of TransformInput is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_input")
            return typing.cast(typing.Optional["SageMakerTransformJobStateChange.TransformInput"], result)

        @builtins.property
        def transform_job_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TransformJobArn property.

            Specify an array of string values to match this event if the actual value of TransformJobArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_job_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def transform_job_name(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TransformJobName property.

            Specify an array of string values to match this event if the actual value of TransformJobName is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_job_name")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def transform_job_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TransformJobStatus property.

            Specify an array of string values to match this event if the actual value of TransformJobStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_job_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def transform_output(
            self,
        ) -> typing.Optional["SageMakerTransformJobStateChange.TransformOutput"]:
            '''(experimental) TransformOutput property.

            Specify an array of string values to match this event if the actual value of TransformOutput is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_output")
            return typing.cast(typing.Optional["SageMakerTransformJobStateChange.TransformOutput"], result)

        @builtins.property
        def transform_resources(
            self,
        ) -> typing.Optional["SageMakerTransformJobStateChange.TransformResources"]:
            '''(experimental) TransformResources property.

            Specify an array of string values to match this event if the actual value of TransformResources is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_resources")
            return typing.cast(typing.Optional["SageMakerTransformJobStateChange.TransformResources"], result)

        @builtins.property
        def transform_start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) TransformStartTime property.

            Specify an array of string values to match this event if the actual value of TransformStartTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transform_start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "SageMakerTransformJobStateChangeProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTransformJobStateChange.Tags",
        jsii_struct_bases=[],
        name_mapping={"key": "key", "value": "value"},
    )
    class Tags:
        def __init__(
            self,
            *,
            key: typing.Optional[typing.Sequence[builtins.str]] = None,
            value: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for Tags.

            :param key: (experimental) Key property. Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param value: (experimental) Value property. Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                tags = sagemaker_events.SageMakerTransformJobStateChange.Tags(
                    key=["key"],
                    value=["value"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__ad6806547311611265f3b38c1d0e191e096af3c1de45e2db7d085e571afdadd7)
                check_type(argname="argument key", value=key, expected_type=type_hints["key"])
                check_type(argname="argument value", value=value, expected_type=type_hints["value"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if key is not None:
                self._values["key"] = key
            if value is not None:
                self._values["value"] = value

        @builtins.property
        def key(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Key property.

            Specify an array of string values to match this event if the actual value of Key is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("key")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def value(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) Value property.

            Specify an array of string values to match this event if the actual value of Value is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("value")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "Tags(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTransformJobStateChange.TransformInput",
        jsii_struct_bases=[],
        name_mapping={
            "compression_type": "compressionType",
            "content_type": "contentType",
            "data_source": "dataSource",
            "split_type": "splitType",
        },
    )
    class TransformInput:
        def __init__(
            self,
            *,
            compression_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            content_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            data_source: typing.Optional[typing.Union["SageMakerTransformJobStateChange.DataSource", typing.Dict[builtins.str, typing.Any]]] = None,
            split_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for TransformInput.

            :param compression_type: (experimental) CompressionType property. Specify an array of string values to match this event if the actual value of CompressionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param content_type: (experimental) ContentType property. Specify an array of string values to match this event if the actual value of ContentType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param data_source: (experimental) DataSource property. Specify an array of string values to match this event if the actual value of DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param split_type: (experimental) SplitType property. Specify an array of string values to match this event if the actual value of SplitType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                transform_input = sagemaker_events.SageMakerTransformJobStateChange.TransformInput(
                    compression_type=["compressionType"],
                    content_type=["contentType"],
                    data_source=sagemaker_events.SageMakerTransformJobStateChange.DataSource(
                        s3_data_source=sagemaker_events.SageMakerTransformJobStateChange.S3DataSource(
                            s3_data_type=["s3DataType"],
                            s3_uri=["s3Uri"]
                        )
                    ),
                    split_type=["splitType"]
                )
            '''
            if isinstance(data_source, dict):
                data_source = SageMakerTransformJobStateChange.DataSource(**data_source)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__3d90bd88ff5ff9945fdad5b899124862ea1a22345a7f95da2d9854051dd03328)
                check_type(argname="argument compression_type", value=compression_type, expected_type=type_hints["compression_type"])
                check_type(argname="argument content_type", value=content_type, expected_type=type_hints["content_type"])
                check_type(argname="argument data_source", value=data_source, expected_type=type_hints["data_source"])
                check_type(argname="argument split_type", value=split_type, expected_type=type_hints["split_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if compression_type is not None:
                self._values["compression_type"] = compression_type
            if content_type is not None:
                self._values["content_type"] = content_type
            if data_source is not None:
                self._values["data_source"] = data_source
            if split_type is not None:
                self._values["split_type"] = split_type

        @builtins.property
        def compression_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) CompressionType property.

            Specify an array of string values to match this event if the actual value of CompressionType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("compression_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def content_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) ContentType property.

            Specify an array of string values to match this event if the actual value of ContentType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("content_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def data_source(
            self,
        ) -> typing.Optional["SageMakerTransformJobStateChange.DataSource"]:
            '''(experimental) DataSource property.

            Specify an array of string values to match this event if the actual value of DataSource is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("data_source")
            return typing.cast(typing.Optional["SageMakerTransformJobStateChange.DataSource"], result)

        @builtins.property
        def split_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) SplitType property.

            Specify an array of string values to match this event if the actual value of SplitType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("split_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TransformInput(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTransformJobStateChange.TransformOutput",
        jsii_struct_bases=[],
        name_mapping={
            "assemble_with": "assembleWith",
            "s3_output_path": "s3OutputPath",
        },
    )
    class TransformOutput:
        def __init__(
            self,
            *,
            assemble_with: typing.Optional[typing.Sequence[builtins.str]] = None,
            s3_output_path: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for TransformOutput.

            :param assemble_with: (experimental) AssembleWith property. Specify an array of string values to match this event if the actual value of AssembleWith is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param s3_output_path: (experimental) S3OutputPath property. Specify an array of string values to match this event if the actual value of S3OutputPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                transform_output = sagemaker_events.SageMakerTransformJobStateChange.TransformOutput(
                    assemble_with=["assembleWith"],
                    s3_output_path=["s3OutputPath"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__e2a3e25960d483134f8f6d8bbe8f7429f2d1bd11c5a9821698b42ea733ef736f)
                check_type(argname="argument assemble_with", value=assemble_with, expected_type=type_hints["assemble_with"])
                check_type(argname="argument s3_output_path", value=s3_output_path, expected_type=type_hints["s3_output_path"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if assemble_with is not None:
                self._values["assemble_with"] = assemble_with
            if s3_output_path is not None:
                self._values["s3_output_path"] = s3_output_path

        @builtins.property
        def assemble_with(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) AssembleWith property.

            Specify an array of string values to match this event if the actual value of AssembleWith is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("assemble_with")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def s3_output_path(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) S3OutputPath property.

            Specify an array of string values to match this event if the actual value of S3OutputPath is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("s3_output_path")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TransformOutput(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_sagemaker.events.SageMakerTransformJobStateChange.TransformResources",
        jsii_struct_bases=[],
        name_mapping={
            "instance_count": "instanceCount",
            "instance_type": "instanceType",
        },
    )
    class TransformResources:
        def __init__(
            self,
            *,
            instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
            instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Type definition for TransformResources.

            :param instance_count: (experimental) InstanceCount property. Specify an array of string values to match this event if the actual value of InstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param instance_type: (experimental) InstanceType property. Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_sagemaker import events as sagemaker_events
                
                transform_resources = sagemaker_events.SageMakerTransformJobStateChange.TransformResources(
                    instance_count=["instanceCount"],
                    instance_type=["instanceType"]
                )
            '''
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__c680097388d2c44a19aa890d8d20d73381565c115c96978e39d0702fcdc05fb9)
                check_type(argname="argument instance_count", value=instance_count, expected_type=type_hints["instance_count"])
                check_type(argname="argument instance_type", value=instance_type, expected_type=type_hints["instance_type"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if instance_count is not None:
                self._values["instance_count"] = instance_count
            if instance_type is not None:
                self._values["instance_type"] = instance_type

        @builtins.property
        def instance_count(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstanceCount property.

            Specify an array of string values to match this event if the actual value of InstanceCount is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_count")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def instance_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) InstanceType property.

            Specify an array of string values to match this event if the actual value of InstanceType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("instance_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "TransformResources(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "AWSAPICallViaCloudTrail",
    "EndpointConfigEvents",
    "SageMakerAlgorithmStateChange",
    "SageMakerEndpointConfigStateChange",
    "SageMakerEndpointStateChange",
    "SageMakerGroundTruthLabelingJobTaskStatusChange",
    "SageMakerHyperParameterTuningJobStateChange",
    "SageMakerModelBuildingPipelineExecutionStatusChange",
    "SageMakerModelBuildingPipelineExecutionStepStatusChange",
    "SageMakerModelPackageStateChange",
    "SageMakerModelStateChange",
    "SageMakerNotebookInstanceStateChange",
    "SageMakerNotebookLifecycleConfigStateChange",
    "SageMakerTrainingJobStateChange",
    "SageMakerTransformJobStateChange",
]

publication.publish()

def _typecheckingstub__f61f8ef12ad0e858807b399b29395eab359e24077e842ff4d7224c64e2f3d867(
    *,
    aws_region: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_code: typing.Optional[typing.Sequence[builtins.str]] = None,
    error_message: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    event_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_source: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_version: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    request_parameters: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.RequestParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    response_elements: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ResponseElements, typing.Dict[builtins.str, typing.Any]]] = None,
    source_ip_address: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_agent: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_identity: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.UserIdentity, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a0ed15c03c82ac3b129bec9eb933a1ba90cf97d9aba465489f060a3fe544891(
    *,
    training_image: typing.Optional[typing.Sequence[builtins.str]] = None,
    training_input_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dc355425535b6bf79145caf578aa349a753f26a84a92e0abb9596d411425ea6d(
    *,
    creation_date: typing.Optional[typing.Sequence[builtins.str]] = None,
    mfa_authenticated: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e4106b023f8c8771ef1916912b1de1ece1b77c70da771aa81cb355680904c6e5(
    *,
    s3_data_source: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.S3DataSource, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__57702cd4b21da5aae7b63fa403fc1ac3d183a48a1378941623f7fd70de348899(
    *,
    s3_data_source: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.S3DataSource1, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fa303df54be486b2916ddb9d6a199252dba0bcb912fc2eedc07746a4a7168b77(
    *,
    eval_metric: typing.Optional[typing.Sequence[builtins.str]] = None,
    num_round: typing.Optional[typing.Sequence[builtins.str]] = None,
    objective: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2a2a0488d827cb3fac133659309cfd1a54eb9c45b9a3cc121b01a1f33b681c9c(
    *,
    remove_job_name_from_s3_output_path: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_output_path: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4363e84b18d7bdefad04ab001ac5db54a88b0bf9a4f6521c384c5ccef724f548(
    *,
    container_hostname: typing.Optional[typing.Sequence[builtins.str]] = None,
    image: typing.Optional[typing.Sequence[builtins.str]] = None,
    model_data_url: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0b8c55112733735b34e1d8081f24442fc153f03c3f77946a0317c20e48156f6c(
    *,
    algorithm_specification: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.AlgorithmSpecification, typing.Dict[builtins.str, typing.Any]]] = None,
    enable_inter_container_traffic_encryption: typing.Optional[typing.Sequence[builtins.str]] = None,
    enable_managed_spot_training: typing.Optional[typing.Sequence[builtins.str]] = None,
    enable_network_isolation: typing.Optional[typing.Sequence[builtins.str]] = None,
    endpoint_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    endpoint_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    execution_role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    hyper_parameters: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.HyperParameters, typing.Dict[builtins.str, typing.Any]]] = None,
    input_data_config: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.RequestParametersItem2, typing.Dict[builtins.str, typing.Any]]]] = None,
    model_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    output_data_config: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.OutputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    primary_container: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.PrimaryContainer, typing.Dict[builtins.str, typing.Any]]] = None,
    production_variants: typing.Optional[typing.Sequence[typing.Union[AWSAPICallViaCloudTrail.RequestParametersItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    resource_config: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.ResourceConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    stopping_condition: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.StoppingCondition, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Sequence[typing.Any]] = None,
    training_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    transform_input: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.TransformInput, typing.Dict[builtins.str, typing.Any]]] = None,
    transform_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    transform_output: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.TransformOutput, typing.Dict[builtins.str, typing.Any]]] = None,
    transform_resources: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.TransformResources, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8ba537fa22959b96074d142ce9fa2c2f2e351775d4e66279829d016c40b6ac47(
    *,
    initial_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    initial_variant_weight: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    model_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    variant_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d47cdc0a60321eea6c845332ccfff5bb96ccccf84b1c5efabd46aedacb7d00c9(
    *,
    channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    content_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    data_source: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.DataSource1, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e61df796362f3dd45bbd8cf3569bee7f8c119bf5c998ccea5176b01e31bea9be(
    *,
    instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    volume_size_in_gb: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__97fb69455d578f254d20e16c8a234be0ee4f7c1a027596eb2e93e35389b87066(
    *,
    endpoint_config_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    model_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    training_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    transform_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ee998a8aedcf329dc09553ec020a7d66da065124c2c3ef9feadb21c57f170dd7(
    *,
    s3_data_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fcf1e1ef05960173b2653295de48416bd448338cac85fb21c9f63cb67cb8e41b(
    *,
    s3_data_distribution_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_data_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eaf46a11d4a66b62828debf1c9cac86f0483694198ac056f2640a5b05d9c976e(
    *,
    attributes: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.Attributes, typing.Dict[builtins.str, typing.Any]]] = None,
    session_issuer: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionIssuer, typing.Dict[builtins.str, typing.Any]]] = None,
    web_id_federation_data: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fdc402c46ff2d8d75852be3ba14f88f1329e07ae1e606677021d2cc91344ea51(
    *,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
    user_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__351b2afe247a7e475a43130ff9b0bee99973d231731d29a9e35d4c6d1feb7bf8(
    *,
    max_runtime_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b4b3c3cdb4dcf85d438d1bd5a652f0fb8310e6f0c0ccae87bb838997f6eda56e(
    *,
    compression_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    content_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    data_source: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.DataSource, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2e95013c4114b3d52f34b82cb0b6569658ca1ace4e3f981645d4846d73cb7117(
    *,
    s3_output_path: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a09cf73f140a3bdbb78b4406d3ba56eb269e8b0da8e0b2e64a6b70d7e058be8(
    *,
    instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__24dc7f523f5804a8c36c95d281c42b6019fddcd7fa2024e08e774ceddc6eaa42(
    *,
    access_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    account_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    invoked_by: typing.Optional[typing.Sequence[builtins.str]] = None,
    principal_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    session_context: typing.Optional[typing.Union[AWSAPICallViaCloudTrail.SessionContext, typing.Dict[builtins.str, typing.Any]]] = None,
    type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89bc78d1a42c6f2ff82f20a6a7795085c79302c38cfa5dd975930ba03b128982(
    endpoint_config_ref: _aws_cdk_interfaces_aws_sagemaker_ceddda9d.IEndpointConfigRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e18690949b97ed59f68bcfd18dd8b27df0891d270b8f1430e9e16b1d219be7d4(
    *,
    algorithm_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    algorithm_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    algorithm_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    certify_for_marketplace: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[SageMakerAlgorithmStateChange.Tags, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2f1ef0e3299265996888fa7238d33feba339cfe0d221250992d481a1bdb438f9(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ec6a44dafc80f6ec02d3881f92f1baebaf27bb49a168abec7898390a992962aa(
    *,
    initial_instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    initial_variant_weight: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    model_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    variant_name: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f0ee228586d3c2c5114b8b787db51f818c9764bf6e113ae001eb44278cda69da(
    *,
    creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    endpoint_config_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    endpoint_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    production_variants: typing.Optional[typing.Sequence[typing.Union[SageMakerEndpointConfigStateChange.SageMakerEndpointConfigStateChangeItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[SageMakerEndpointConfigStateChange.Tags, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4083165630fcd44580fd87a930e9ad34cff2d57a3fbebe71dc8a86297c4aeda8(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ae0398ffa625c97ca91ee51c348b1fa40709707fa0f041d22e8da85aeebabf91(
    *,
    creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    endpoint_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    endpoint_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    endpoint_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    endpoint_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[SageMakerEndpointStateChange.Tags, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1766d224b589f890d657321901c78a8e61db549aaf96bcd478a04bbcd0af0745(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8bd2457ad1aef32425fb7763b97bbb115ce3a6321b17abcd77c1a9bbbb3f9692(
    *,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    labeling_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    state: typing.Optional[typing.Sequence[builtins.str]] = None,
    workteam_team_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d90257762f2e3f325a976e6052e6403bef9eafa5307d4c5f8caab4c5e32e876f(
    *,
    metric_definitions: typing.Optional[typing.Sequence[typing.Union[SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecificationItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    training_image: typing.Optional[typing.Sequence[builtins.str]] = None,
    training_input_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__441c33e42a23b726860151dcf9b8e92cde2042dad691d796dac9ed2982bc981b(
    *,
    name: typing.Optional[typing.Sequence[builtins.str]] = None,
    regex: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f27f5e3ff903e36e338c42f0f84365985ac94c44019fc31c1568e4653c631124(
    *,
    s3_data_source: typing.Optional[typing.Union[SageMakerHyperParameterTuningJobStateChange.S3DataSource, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dabbd9a55dc39c7dc7286eda156f6e88d913685f7e111c242207a538346820b9(
    *,
    failed: typing.Optional[typing.Sequence[builtins.str]] = None,
    pending: typing.Optional[typing.Sequence[builtins.str]] = None,
    succeeded: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__26c46152736bba524349a7f3afe155a619a44ed686a3c288dec10ff1e0edf778(
    *,
    kms_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_output_path: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ff46feb2c32f0fbe1a99dea95a7c111b4fd86d01c23f335037618fc8a950d7cb(
    *,
    instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    volume_kms_key_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    volume_size_in_gb: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f25172725ebecd413dc8e7daa0c5de4f0f2cc4c51f5b1c16f07b1d4b2e450132(
    *,
    s3_data_distribution_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_data_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__47c0e9849b02d493cdbfc592852be40c95ee3a11dfea127af4884d27644c6ec4(
    *,
    creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    hyper_parameter_tuning_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    hyper_parameter_tuning_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    hyper_parameter_tuning_job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    objective_status_counters: typing.Optional[typing.Union[SageMakerHyperParameterTuningJobStateChange.ObjectiveStatusCounters, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[SageMakerHyperParameterTuningJobStateChange.Tags, typing.Dict[builtins.str, typing.Any]]]] = None,
    training_job_definition: typing.Optional[typing.Union[SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinition, typing.Dict[builtins.str, typing.Any]]] = None,
    training_job_status_counters: typing.Optional[typing.Union[SageMakerHyperParameterTuningJobStateChange.TrainingJobStatusCounters, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8327c6042f63f32fad2be7f2b6546f32eef04700ac86d1703d510b98a4793538(
    *,
    max_runtime_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6a87badf3373bfd2eca44f85a6e8eecca83bf54e1c7f41d53f79be889bf88a47(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3fc13451368a1d2705b54288fa12a295c9fb58b10fd25a044cd375318049ce89(
    *,
    algorithm_specification: typing.Optional[typing.Union[SageMakerHyperParameterTuningJobStateChange.AlgorithmSpecification, typing.Dict[builtins.str, typing.Any]]] = None,
    input_data_config: typing.Optional[typing.Sequence[typing.Union[SageMakerHyperParameterTuningJobStateChange.TrainingJobDefinitionItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    output_data_config: typing.Optional[typing.Union[SageMakerHyperParameterTuningJobStateChange.OutputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    resource_config: typing.Optional[typing.Union[SageMakerHyperParameterTuningJobStateChange.ResourceConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    static_hyper_parameters: typing.Optional[typing.Union[SageMakerHyperParameterTuningJobStateChange.Tags, typing.Dict[builtins.str, typing.Any]]] = None,
    stopping_condition: typing.Optional[typing.Union[SageMakerHyperParameterTuningJobStateChange.StoppingCondition, typing.Dict[builtins.str, typing.Any]]] = None,
    vpc_config: typing.Optional[typing.Union[SageMakerHyperParameterTuningJobStateChange.VpcConfig, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a1ea70fe870402ea5e3d7c053056a088be44374ebc5e0aa5fda73faf0259f6b6(
    *,
    channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    compression_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    content_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    data_source: typing.Optional[typing.Union[SageMakerHyperParameterTuningJobStateChange.DataSource, typing.Dict[builtins.str, typing.Any]]] = None,
    record_wrapper_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__aa81b12edd4a995963cff8b66e795e5e4b98cdfa6488b577cb365031b87fdd4e(
    *,
    completed: typing.Optional[typing.Sequence[builtins.str]] = None,
    in_progress: typing.Optional[typing.Sequence[builtins.str]] = None,
    non_retryable_error: typing.Optional[typing.Sequence[builtins.str]] = None,
    retryable_error: typing.Optional[typing.Sequence[builtins.str]] = None,
    stopped: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b2b979673503f9ad0cd8e7514d24abbb3f7014796eb631de207ab85e3f04157c(
    *,
    security_group_ids: typing.Optional[typing.Sequence[builtins.str]] = None,
    subnets: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8bac56b5bd5fe117c05fa6e59a58bbe12a6cbced21e2ac1882dfcb7c98b27e46(
    *,
    current_pipeline_execution_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    execution_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    execution_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    pipeline_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    pipeline_execution_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    pipeline_execution_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    pipeline_execution_display_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    previous_pipeline_execution_status: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__05af31358f5fd9c727f733a71c7846ed96d3d86c89c8d999842f34fcbcd4fc9f(
    *,
    source_pipeline_execution_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a9aaf26ca1016f3516161e5cce9bd4dfc00fae56f8f022cea6c2ec2532cde7f(
    *,
    processing_job: typing.Optional[typing.Union[SageMakerModelBuildingPipelineExecutionStepStatusChange.ProcessingJob, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1232dc1f9fb22c422bb5980f2d297cfd047a3da21f0c6e63301cbe1a4ef358ad(
    *,
    arn: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc7fc6bc97d4859e0dcaad6aa13171d5bf8a20a293abe502afe10f57907bb628(
    *,
    cache_hit_result: typing.Optional[typing.Union[SageMakerModelBuildingPipelineExecutionStepStatusChange.CacheHitResult, typing.Dict[builtins.str, typing.Any]]] = None,
    current_step_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    failure_reason: typing.Optional[typing.Sequence[builtins.str]] = None,
    metadata: typing.Optional[typing.Union[SageMakerModelBuildingPipelineExecutionStepStatusChange.Metadata, typing.Dict[builtins.str, typing.Any]]] = None,
    pipeline_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    pipeline_execution_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    previous_step_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    step_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    step_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    step_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    step_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__903cec9433024298095077c261390db611d517f3b1ed33af5895d24a80142200(
    *,
    certify_for_marketplace: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    model_package_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    model_package_description: typing.Optional[typing.Sequence[builtins.str]] = None,
    model_package_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[SageMakerModelPackageStateChange.Tags, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__51ddc71566fb277b01edc2010ac06db7202f94b22c9e409f46d28203a4807478(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9faf336527bc7edfa459f8b49d3425bde28486d22ed50e235995683ee37de576(
    *,
    container_hostname: typing.Optional[typing.Sequence[builtins.str]] = None,
    image: typing.Optional[typing.Sequence[builtins.str]] = None,
    model_data_url: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e6d3aecd722396e495655685a3013ee1d6271da71f9bdaaa9816e88bcecebc44(
    *,
    creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    execution_role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    model_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    model_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    primary_container: typing.Optional[typing.Union[SageMakerModelStateChange.PrimaryContainer, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[SageMakerModelStateChange.Tags, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4f2b58ccffc5b6ba6a6e6462e34ad21b13ecec8821f421984b6cb3bc4eaa26dd(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8346ea103a02de17f382699127815d6e449090f812057886c9331409033da091(
    *,
    creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    notebook_instance_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    notebook_instance_lifecycle_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    notebook_instance_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    notebook_instance_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[SageMakerNotebookInstanceStateChange.Tags, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7fea710b6f48a3458abc3f24f0a27883f9bcddda3bfca64bdfc154245f35640f(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b99ec7bf0d2599431707603d89e8b2e72b79a4bab46ac3f56cea0c79ed644fa3(
    *,
    creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    notebook_instance_lifecycle_config_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    notebook_instance_lifecycle_config_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[SageMakerNotebookLifecycleConfigStateChange.Tags, typing.Dict[builtins.str, typing.Any]]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__01c7d0ad412271077fee7d9199abb53b18e14114a86ec97a4abd6a0f692e66a2(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__43f53214e1cbca6a5ab2a82a559714d1717a87d7bffbe160cf5701fddf956633(
    *,
    training_image: typing.Optional[typing.Sequence[builtins.str]] = None,
    training_input_mode: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb58727138a14450269c5dfbf63ddb73c60cf8b9f6a7ac184ed07c144c64feef(
    *,
    s3_data_source: typing.Optional[typing.Union[SageMakerTrainingJobStateChange.S3DataSource, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__35c63987451d129309204268c89e3523e92b727fe85cf3b23aec136041d2e44b(
    *,
    s3_model_artifacts: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5eb72babaa7b42bbfe25560f6d915c7152cf57d25e0c66ee7870eb247591a2c1(
    *,
    s3_output_path: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4ae20a94bd8f39ea65993889f58175d358b608c71976d9cb997a9e32b383f0e5(
    *,
    instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    volume_size_in_gb: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__06e7706b4f2c08eedd32fe28ee91a1b62ab00a82ec32bf01aa2b04a8c7bd395d(
    *,
    s3_data_distribution_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_data_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b8b043f531889403117210717ed1cefdefa99de656f142b2ddecf3d7475fc2f4(
    *,
    channel_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    compression_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    content_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    data_source: typing.Optional[typing.Union[SageMakerTrainingJobStateChange.DataSource, typing.Dict[builtins.str, typing.Any]]] = None,
    record_wrapper_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__da90dc864d06cec78b9db7ed59f25bdb62a7a3d0d1c18ca85a9abe1bb8f74fdd(
    *,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    status: typing.Optional[typing.Sequence[builtins.str]] = None,
    status_message: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__4bc020f96407de1e4bd1abc9ef1fc2849bd27d43407b5ab843ce1bb568b2a0fd(
    *,
    algorithm_specification: typing.Optional[typing.Union[SageMakerTrainingJobStateChange.AlgorithmSpecification, typing.Dict[builtins.str, typing.Any]]] = None,
    creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    hyper_parameters: typing.Optional[typing.Sequence[builtins.str]] = None,
    input_data_config: typing.Optional[typing.Sequence[typing.Union[SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem, typing.Dict[builtins.str, typing.Any]]]] = None,
    last_modified_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    model_artifacts: typing.Optional[typing.Union[SageMakerTrainingJobStateChange.ModelArtifacts, typing.Dict[builtins.str, typing.Any]]] = None,
    output_data_config: typing.Optional[typing.Union[SageMakerTrainingJobStateChange.OutputDataConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    resource_config: typing.Optional[typing.Union[SageMakerTrainingJobStateChange.ResourceConfig, typing.Dict[builtins.str, typing.Any]]] = None,
    role_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    secondary_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    secondary_status_transitions: typing.Optional[typing.Sequence[typing.Union[SageMakerTrainingJobStateChange.SageMakerTrainingJobStateChangeItem1, typing.Dict[builtins.str, typing.Any]]]] = None,
    stopping_condition: typing.Optional[typing.Union[SageMakerTrainingJobStateChange.StoppingCondition, typing.Dict[builtins.str, typing.Any]]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[SageMakerTrainingJobStateChange.Tags, typing.Dict[builtins.str, typing.Any]]]] = None,
    training_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    training_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    training_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    training_job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    training_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f7173621d8f207434fd7a93371119a5c8d67b13716d8d81de304188c4b9fa510(
    *,
    max_runtime_in_seconds: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1c0c4842ed88d2024767c0a8888a4692c45dff1b2e6886de561b861b5f2dbe4e(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1115c3415061162cae2d80507ae1113667c0744ef9e431ba15dc41ae3855d0b5(
    *,
    s3_data_source: typing.Optional[typing.Union[SageMakerTransformJobStateChange.S3DataSource, typing.Dict[builtins.str, typing.Any]]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c5b70b1c818d1988773bb6861f0952348c490ccf9b625101aa74ffde3239240b(
    *,
    s3_data_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_uri: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__89b2812cf592ed3f1a60aca19c0f7277dd42764ca98eb280f5e391df0fa8f54b(
    *,
    creation_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    model_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    tags: typing.Optional[typing.Sequence[typing.Union[SageMakerTransformJobStateChange.Tags, typing.Dict[builtins.str, typing.Any]]]] = None,
    transform_end_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    transform_input: typing.Optional[typing.Union[SageMakerTransformJobStateChange.TransformInput, typing.Dict[builtins.str, typing.Any]]] = None,
    transform_job_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    transform_job_name: typing.Optional[typing.Sequence[builtins.str]] = None,
    transform_job_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    transform_output: typing.Optional[typing.Union[SageMakerTransformJobStateChange.TransformOutput, typing.Dict[builtins.str, typing.Any]]] = None,
    transform_resources: typing.Optional[typing.Union[SageMakerTransformJobStateChange.TransformResources, typing.Dict[builtins.str, typing.Any]]] = None,
    transform_start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ad6806547311611265f3b38c1d0e191e096af3c1de45e2db7d085e571afdadd7(
    *,
    key: typing.Optional[typing.Sequence[builtins.str]] = None,
    value: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__3d90bd88ff5ff9945fdad5b899124862ea1a22345a7f95da2d9854051dd03328(
    *,
    compression_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    content_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    data_source: typing.Optional[typing.Union[SageMakerTransformJobStateChange.DataSource, typing.Dict[builtins.str, typing.Any]]] = None,
    split_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e2a3e25960d483134f8f6d8bbe8f7429f2d1bd11c5a9821698b42ea733ef736f(
    *,
    assemble_with: typing.Optional[typing.Sequence[builtins.str]] = None,
    s3_output_path: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c680097388d2c44a19aa890d8d20d73381565c115c96978e39d0702fcdc05fb9(
    *,
    instance_count: typing.Optional[typing.Sequence[builtins.str]] = None,
    instance_type: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
