from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.interfaces.aws_kinesisfirehose as _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d
import aws_cdk.interfaces.aws_kms as _aws_cdk_interfaces_aws_kms_ceddda9d
import aws_cdk.interfaces.aws_logs as _aws_cdk_interfaces_aws_logs_ceddda9d
import aws_cdk.interfaces.aws_s3 as _aws_cdk_interfaces_aws_s3_ceddda9d
import constructs as _constructs_77d1e7e8
from ...aws_logs import ILogsDelivery as _ILogsDelivery_0d3c9e29


class CfnInstanceConsoleLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnInstanceConsoleLogs",
):
    '''Builder for CfnInstanceLogsMixin to generate CONSOLE_LOGS for CfnInstance.

    :cloudformationResource: AWS::EC2::Instance
    :logType: CONSOLE_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        cfn_instance_console_logs = ec2_mixins.CfnInstanceConsoleLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceConsoleLogsRecordFields"]] = None,
    ) -> "CfnInstanceLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eaa7660e95a48978e229da9bcde4c80c25d1e02088e1f8aa35f71233fb7f968d)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnInstanceConsoleLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnInstanceLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnInstanceConsoleLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceConsoleLogsRecordFields"]] = None,
    ) -> "CfnInstanceLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce4d020df53e06cb91bc34c321bda99ab98a1441a22bbafd05408b090e4a4c89)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnInstanceConsoleLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnInstanceLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnInstanceConsoleLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceConsoleLogsRecordFields"]] = None,
    ) -> "CfnInstanceLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__51af58a2cae4965eb4f14ad8e79554f79aaf56e81878479ca3f7366d37f28d0b)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnInstanceConsoleLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnInstanceLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnInstanceConsoleLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceConsoleLogsRecordFields"]] = None,
    ) -> "CfnInstanceLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c4c8ca153f62a2d562a74f5047ede4c49a1a777f3c31a569ee9bce17f0932798)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnInstanceConsoleLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnInstanceLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnInstanceConsoleLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnInstanceConsoleLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceConsoleLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_instance_console_logs_dest_props = ec2_mixins.CfnInstanceConsoleLogsDestProps(
                record_fields=[ec2_mixins.CfnInstanceConsoleLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__80b9b83b6233b5778777b2d0f4f734f289742bfecc3c28d1553da83ed4f23f4b)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnInstanceConsoleLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnInstanceConsoleLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnInstanceConsoleLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnInstanceConsoleLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnInstanceConsoleLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnInstanceConsoleLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceConsoleLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_instance_console_logs_firehose_props = ec2_mixins.CfnInstanceConsoleLogsFirehoseProps(
                output_format=ec2_mixins.CfnInstanceConsoleLogsOutputFormat.Firehose.JSON,
                record_fields=[ec2_mixins.CfnInstanceConsoleLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6d3e83f0020e979a366dcb1f661af112ad4dfdab5349ae2c446435e227a45b8e)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnInstanceConsoleLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnInstanceConsoleLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnInstanceConsoleLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnInstanceConsoleLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnInstanceConsoleLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnInstanceConsoleLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnInstanceConsoleLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnInstanceConsoleLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceConsoleLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_instance_console_logs_log_group_props = ec2_mixins.CfnInstanceConsoleLogsLogGroupProps(
                output_format=ec2_mixins.CfnInstanceConsoleLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[ec2_mixins.CfnInstanceConsoleLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fd8747c951a89662c2ce13002ec1495eafd0b4cc41510a35a7434533da2787cd)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnInstanceConsoleLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnInstanceConsoleLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnInstanceConsoleLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnInstanceConsoleLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnInstanceConsoleLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnInstanceConsoleLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnInstanceConsoleLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnInstanceConsoleLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        cfn_instance_console_logs_output_format = ec2_mixins.CfnInstanceConsoleLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnInstanceConsoleLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnInstanceConsoleLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnInstanceConsoleLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnInstanceConsoleLogsRecordFields"
)
class CfnInstanceConsoleLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnInstanceConsoleLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnInstanceConsoleLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnInstanceConsoleLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnInstanceConsoleLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_instance_console_logs_s3_props = ec2_mixins.CfnInstanceConsoleLogsS3Props(
                encryption_key=key_ref,
                output_format=ec2_mixins.CfnInstanceConsoleLogsOutputFormat.S3.JSON,
                record_fields=[ec2_mixins.CfnInstanceConsoleLogsRecordFields.RESOURCE_ARN]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__509b792f4a1fe51be86b85a92e47864ca2123b17da1704edb0af98b538da7615)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(self) -> typing.Optional["CfnInstanceConsoleLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnInstanceConsoleLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnInstanceConsoleLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnInstanceConsoleLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnInstanceConsoleLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnInstanceLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnInstanceLogsMixin",
):
    '''Specifies an EC2 instance.

    If an Elastic IP address is attached to your instance, AWS CloudFormation reattaches the Elastic IP address after it updates the instance. For more information about updating stacks, see `AWS CloudFormation Stacks Updates <https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/using-cfn-updating-stacks.html>`_ .

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-instance.html
    :cloudformationResource: AWS::EC2::Instance
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_instance_logs_mixin = ec2_mixins.CfnInstanceLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::EC2::Instance``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6c93fe8f448360e1d4909ea281308d277495fab4873d61e15294f96ed66519f4)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__326e3717c25d818e3fe6c8250b55b6cadd09ff1d13591cf5a76798e9e51ab77e)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__eb7f4586095885982713c52d0cac1ae1a73a5a3f3ee9d56d51cf5a744fa77241)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="CONSOLE_LOGS")
    def CONSOLE_LOGS(cls) -> "CfnInstanceConsoleLogs":
        return typing.cast("CfnInstanceConsoleLogs", jsii.sget(cls, "CONSOLE_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnRouteServerPeerEventLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnRouteServerPeerEventLogs",
):
    '''Builder for CfnRouteServerPeerLogsMixin to generate EVENT_LOGS for CfnRouteServerPeer.

    :cloudformationResource: AWS::EC2::RouteServerPeer
    :logType: EVENT_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        cfn_route_server_peer_event_logs = ec2_mixins.CfnRouteServerPeerEventLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRouteServerPeerEventLogsRecordFields"]] = None,
    ) -> "CfnRouteServerPeerLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f1f82a0df048510e956bd207679526b8d25b241a8e6309a706b9a5db4de9c8c3)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnRouteServerPeerEventLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnRouteServerPeerLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnRouteServerPeerEventLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRouteServerPeerEventLogsRecordFields"]] = None,
    ) -> "CfnRouteServerPeerLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e62af65b07d05908bdf46d749244d1cc99dffcd32323e46cecdfbebcbeb947b9)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnRouteServerPeerEventLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnRouteServerPeerLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnRouteServerPeerEventLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRouteServerPeerEventLogsRecordFields"]] = None,
    ) -> "CfnRouteServerPeerLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b982f19ff649590805549ffc3f5e8f8bf05456543fc9b2e398f71eb61adc82a4)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnRouteServerPeerEventLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnRouteServerPeerLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnRouteServerPeerEventLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRouteServerPeerEventLogsRecordFields"]] = None,
    ) -> "CfnRouteServerPeerLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e5aa15c5a090e9206ad9c49e22bbcd6540feaba02aa8a94bb2f96441f7de6fe9)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnRouteServerPeerEventLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnRouteServerPeerLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnRouteServerPeerEventLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnRouteServerPeerEventLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnRouteServerPeerEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_route_server_peer_event_logs_dest_props = ec2_mixins.CfnRouteServerPeerEventLogsDestProps(
                record_fields=[ec2_mixins.CfnRouteServerPeerEventLogsRecordFields.STATUS]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__107261317e23c7b3ec0ebb67b00fa4d1e61a028c15a70ebc38dbb89ab5830c70)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRouteServerPeerEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRouteServerPeerEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRouteServerPeerEventLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnRouteServerPeerEventLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnRouteServerPeerEventLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnRouteServerPeerEventLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRouteServerPeerEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_route_server_peer_event_logs_firehose_props = ec2_mixins.CfnRouteServerPeerEventLogsFirehoseProps(
                output_format=ec2_mixins.CfnRouteServerPeerEventLogsOutputFormat.Firehose.JSON,
                record_fields=[ec2_mixins.CfnRouteServerPeerEventLogsRecordFields.STATUS]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1b7b0aa8e6897ee2528de92889164a23c5fc9c42e15c7cd0c878eb4886c3fb3c)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRouteServerPeerEventLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRouteServerPeerEventLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRouteServerPeerEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRouteServerPeerEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRouteServerPeerEventLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnRouteServerPeerEventLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnRouteServerPeerEventLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnRouteServerPeerEventLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRouteServerPeerEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_route_server_peer_event_logs_log_group_props = ec2_mixins.CfnRouteServerPeerEventLogsLogGroupProps(
                output_format=ec2_mixins.CfnRouteServerPeerEventLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[ec2_mixins.CfnRouteServerPeerEventLogsRecordFields.STATUS]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__25801079ac85d1e83417dcaafd631b33b2bb0e652550eee2750ae7399d218fd2)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRouteServerPeerEventLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRouteServerPeerEventLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRouteServerPeerEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRouteServerPeerEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRouteServerPeerEventLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnRouteServerPeerEventLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnRouteServerPeerEventLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnRouteServerPeerEventLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        cfn_route_server_peer_event_logs_output_format = ec2_mixins.CfnRouteServerPeerEventLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnRouteServerPeerEventLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnRouteServerPeerEventLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnRouteServerPeerEventLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnRouteServerPeerEventLogsRecordFields"
)
class CfnRouteServerPeerEventLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    STATUS = "STATUS"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    RESOURCE_ARN = "RESOURCE_ARN"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    TYPE = "TYPE"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnRouteServerPeerEventLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnRouteServerPeerEventLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnRouteServerPeerEventLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnRouteServerPeerEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_route_server_peer_event_logs_s3_props = ec2_mixins.CfnRouteServerPeerEventLogsS3Props(
                encryption_key=key_ref,
                output_format=ec2_mixins.CfnRouteServerPeerEventLogsOutputFormat.S3.JSON,
                record_fields=[ec2_mixins.CfnRouteServerPeerEventLogsRecordFields.STATUS]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2dab4233d78b8d9356c48b374736ae0afedb9a4d9649aefa0824fb297980eb38)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnRouteServerPeerEventLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnRouteServerPeerEventLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnRouteServerPeerEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnRouteServerPeerEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnRouteServerPeerEventLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnRouteServerPeerLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnRouteServerPeerLogsMixin",
):
    '''Specifies a BGP peer configuration for a route server endpoint.

    A route server peer is a session between a route server endpoint and the device deployed in AWS (such as a firewall appliance or other network security function running on an EC2 instance).

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-routeserverpeer.html
    :cloudformationResource: AWS::EC2::RouteServerPeer
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_route_server_peer_logs_mixin = ec2_mixins.CfnRouteServerPeerLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::EC2::RouteServerPeer``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__e887379c7ce461cf348e2d0a8886b52ad7923d6fee0347023e8e70995b5c98ad)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b53a309af28da1eec8b32e48fe86c145f2eda70f8ac9c3a10faefedb25aa2368)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8e3988d66ef777b3f2816b11e3632f39fd0e01a4920356b90f4e74fc630aba7b)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EVENT_LOGS")
    def EVENT_LOGS(cls) -> "CfnRouteServerPeerEventLogs":
        return typing.cast("CfnRouteServerPeerEventLogs", jsii.sget(cls, "EVENT_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnVPCLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPCLogsMixin",
):
    '''Specifies a virtual private cloud (VPC).

    A VPC must have an associated IPv4 CIDR block. You can specify an IPv4 CIDR block or an IPAM-allocated IPv4 CIDR block. To associate an IPv6 CIDR block with the VPC, see `AWS::EC2::VPCCidrBlock <https://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-vpccidrblock.html>`_ .

    For more information, see `Virtual private clouds (VPC) <https://docs.aws.amazon.com/vpc/latest/userguide/configure-your-vpc.html>`_ in the *Amazon VPC User Guide* .

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-vpc.html
    :cloudformationResource: AWS::EC2::VPC
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_vPCLogs_mixin = ec2_mixins.CfnVPCLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::EC2::VPC``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__c887737e6727e3b16b8ac6538e1fc7d512b67d7a6e88a3a8d55f6bdb1bc2cf69)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__2d340aa09c1d4740786b10583283e670e3385659d850c72e307cfce7f4b57111)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f2d89c70adb4839231da02fd8662b5c1a1aaff9a33627b917996c39b671375e5)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="ROUTE53_RESOLVER_QUERY_LOGS")
    def ROUTE53_RESOLVER_QUERY_LOGS(cls) -> "CfnVPCRoute53ResolverQueryLogs":
        return typing.cast("CfnVPCRoute53ResolverQueryLogs", jsii.sget(cls, "ROUTE53_RESOLVER_QUERY_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnVPCRoute53ResolverQueryLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPCRoute53ResolverQueryLogs",
):
    '''Builder for CfnVPCLogsMixin to generate ROUTE53_RESOLVER_QUERY_LOGS for CfnVPC.

    :cloudformationResource: AWS::EC2::VPC
    :logType: ROUTE53_RESOLVER_QUERY_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        cfn_vPCRoute53_resolver_query_logs = ec2_mixins.CfnVPCRoute53ResolverQueryLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
    ) -> "CfnVPCLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__af842ea6227ee375de460aad6584ada5201abe77391d3118a84dae29caed37b3)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        return typing.cast("CfnVPCLogsMixin", jsii.invoke(self, "toDestination", [destination]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnVPCRoute53ResolverQueryLogsOutputFormat.Firehose"] = None,
    ) -> "CfnVPCLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1ca4b568a71338f3c7febfbfdaa32660bcde709925defef7af2bf63e9dcff93e)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnVPCRoute53ResolverQueryLogsFirehoseProps(
            output_format=output_format
        )

        return typing.cast("CfnVPCLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnVPCRoute53ResolverQueryLogsOutputFormat.LogGroup"] = None,
    ) -> "CfnVPCLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__1db7e0342b08f126a3d7da6d9626995ea548898b70250c986a5d3b069704ed9b)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnVPCRoute53ResolverQueryLogsLogGroupProps(
            output_format=output_format
        )

        return typing.cast("CfnVPCLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnVPCRoute53ResolverQueryLogsOutputFormat.S3"] = None,
    ) -> "CfnVPCLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__996b4cc3fed52d55989f54f04abafdf6602b02765140574ab2fa594ce76048a8)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnVPCRoute53ResolverQueryLogsS3Props(
            encryption_key=encryption_key, output_format=output_format
        )

        return typing.cast("CfnVPCLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPCRoute53ResolverQueryLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnVPCRoute53ResolverQueryLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnVPCRoute53ResolverQueryLogsOutputFormat.Firehose"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_vPCRoute53_resolver_query_logs_firehose_props = ec2_mixins.CfnVPCRoute53ResolverQueryLogsFirehoseProps(
                output_format=ec2_mixins.CfnVPCRoute53ResolverQueryLogsOutputFormat.Firehose.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__a6649805de95076b56cef9c202a55e95e702501489d08de125a09c621b6754b5)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnVPCRoute53ResolverQueryLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnVPCRoute53ResolverQueryLogsOutputFormat.Firehose"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVPCRoute53ResolverQueryLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPCRoute53ResolverQueryLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnVPCRoute53ResolverQueryLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnVPCRoute53ResolverQueryLogsOutputFormat.LogGroup"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_vPCRoute53_resolver_query_logs_log_group_props = ec2_mixins.CfnVPCRoute53ResolverQueryLogsLogGroupProps(
                output_format=ec2_mixins.CfnVPCRoute53ResolverQueryLogsOutputFormat.LogGroup.PLAIN
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__b1c6c4c09d5da8a5800a6dad0e2a9cb07553a2de66d3d99466c4945caea891ff)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnVPCRoute53ResolverQueryLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnVPCRoute53ResolverQueryLogsOutputFormat.LogGroup"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVPCRoute53ResolverQueryLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnVPCRoute53ResolverQueryLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPCRoute53ResolverQueryLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnVPCRoute53ResolverQueryLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        cfn_vPCRoute53_resolver_query_logs_output_format = ec2_mixins.CfnVPCRoute53ResolverQueryLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPCRoute53ResolverQueryLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPCRoute53ResolverQueryLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPCRoute53ResolverQueryLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPCRoute53ResolverQueryLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={"encryption_key": "encryptionKey", "output_format": "outputFormat"},
)
class CfnVPCRoute53ResolverQueryLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnVPCRoute53ResolverQueryLogsOutputFormat.S3"] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_vPCRoute53_resolver_query_logs_s3_props = ec2_mixins.CfnVPCRoute53ResolverQueryLogsS3Props(
                encryption_key=key_ref,
                output_format=ec2_mixins.CfnVPCRoute53ResolverQueryLogsOutputFormat.S3.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0a073d716b768e140aef8c37029e6c3c957b9ccb1de8fd31e6e0f22e4a676515)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnVPCRoute53ResolverQueryLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnVPCRoute53ResolverQueryLogsOutputFormat.S3"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVPCRoute53ResolverQueryLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnVPNConnectionConnectionLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionConnectionLogs",
):
    '''Builder for CfnVPNConnectionLogsMixin to generate CONNECTION_LOGS for CfnVPNConnection.

    :cloudformationResource: AWS::EC2::VPNConnection
    :logType: CONNECTION_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        cfn_vPNConnection_connection_logs = ec2_mixins.CfnVPNConnectionConnectionLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionConnectionLogsRecordFields"]] = None,
    ) -> "CfnVPNConnectionLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__599cfcabc587635fb325339a4527928d6c498f411e1d6e71fd670bb2eea6c8c6)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnVPNConnectionConnectionLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnVPNConnectionLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnVPNConnectionConnectionLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionConnectionLogsRecordFields"]] = None,
    ) -> "CfnVPNConnectionLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__0714b7ed6595a643ea3885a2bedf04f9357303454c4affc9a3fdc10377c732f1)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnVPNConnectionConnectionLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnVPNConnectionLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnVPNConnectionConnectionLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionConnectionLogsRecordFields"]] = None,
    ) -> "CfnVPNConnectionLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__39bc7d8b12a17004e39a23a0d8bbd8a88236ef91b8537b8f147bddd516fda175)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnVPNConnectionConnectionLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnVPNConnectionLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnVPNConnectionConnectionLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionConnectionLogsRecordFields"]] = None,
    ) -> "CfnVPNConnectionLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d0b3873bd6c3a456c0da217041ae01157cc50e3d845dec1841c6ef1a016d16e6)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnVPNConnectionConnectionLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnVPNConnectionLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionConnectionLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnVPNConnectionConnectionLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionConnectionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_vPNConnection_connection_logs_dest_props = ec2_mixins.CfnVPNConnectionConnectionLogsDestProps(
                record_fields=[ec2_mixins.CfnVPNConnectionConnectionLogsRecordFields.TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fc4fa98757a4c4de867e1ac929c8d201e5ecf53d3337d3c88ae1ad72a593cba5)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnVPNConnectionConnectionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnVPNConnectionConnectionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVPNConnectionConnectionLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionConnectionLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnVPNConnectionConnectionLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnVPNConnectionConnectionLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionConnectionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_vPNConnection_connection_logs_firehose_props = ec2_mixins.CfnVPNConnectionConnectionLogsFirehoseProps(
                output_format=ec2_mixins.CfnVPNConnectionConnectionLogsOutputFormat.Firehose.JSON,
                record_fields=[ec2_mixins.CfnVPNConnectionConnectionLogsRecordFields.TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7d9c9499223b247def1f66e01ea577f7e387aac3e3d007ace3e304b218545c4d)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnVPNConnectionConnectionLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnVPNConnectionConnectionLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnVPNConnectionConnectionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnVPNConnectionConnectionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVPNConnectionConnectionLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionConnectionLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnVPNConnectionConnectionLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnVPNConnectionConnectionLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionConnectionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_vPNConnection_connection_logs_log_group_props = ec2_mixins.CfnVPNConnectionConnectionLogsLogGroupProps(
                output_format=ec2_mixins.CfnVPNConnectionConnectionLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[ec2_mixins.CfnVPNConnectionConnectionLogsRecordFields.TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__476826482540948f187a054c44511d6c11b2b0d42c5934120271ce9e57dcbb37)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnVPNConnectionConnectionLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnVPNConnectionConnectionLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnVPNConnectionConnectionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnVPNConnectionConnectionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVPNConnectionConnectionLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnVPNConnectionConnectionLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionConnectionLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnVPNConnectionConnectionLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        cfn_vPNConnection_connection_logs_output_format = ec2_mixins.CfnVPNConnectionConnectionLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionConnectionLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionConnectionLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionConnectionLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionConnectionLogsRecordFields"
)
class CfnVPNConnectionConnectionLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    TIMESTAMP = "TIMESTAMP"
    '''
    :stability: experimental
    '''
    DPD_ENABLED = "DPD_ENABLED"
    '''
    :stability: experimental
    '''
    NAT_T_DETECTED = "NAT_T_DETECTED"
    '''
    :stability: experimental
    '''
    IKE_PHASE1_STATE = "IKE_PHASE1_STATE"
    '''
    :stability: experimental
    '''
    IKE_PHASE2_STATE = "IKE_PHASE2_STATE"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''
    DETAILS = "DETAILS"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionConnectionLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnVPNConnectionConnectionLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnVPNConnectionConnectionLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionConnectionLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_vPNConnection_connection_logs_s3_props = ec2_mixins.CfnVPNConnectionConnectionLogsS3Props(
                encryption_key=key_ref,
                output_format=ec2_mixins.CfnVPNConnectionConnectionLogsOutputFormat.S3.JSON,
                record_fields=[ec2_mixins.CfnVPNConnectionConnectionLogsRecordFields.TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__83c29e98a0d4a1485e683a26017d2ad8a23836fdd7de166009f013131cd5ada1)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnVPNConnectionConnectionLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnVPNConnectionConnectionLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnVPNConnectionConnectionLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnVPNConnectionConnectionLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVPNConnectionConnectionLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnVPNConnectionEventLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionEventLogs",
):
    '''Builder for CfnVPNConnectionLogsMixin to generate EVENT_LOGS for CfnVPNConnection.

    :cloudformationResource: AWS::EC2::VPNConnection
    :logType: EVENT_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        cfn_vPNConnection_event_logs = ec2_mixins.CfnVPNConnectionEventLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
        *,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionEventLogsRecordFields"]] = None,
    ) -> "CfnVPNConnectionLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__70724ed9610c8939134c83f0793dc365a339a786dc1878b93558c614fac20aa9)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        props = CfnVPNConnectionEventLogsDestProps(record_fields=record_fields)

        return typing.cast("CfnVPNConnectionLogsMixin", jsii.invoke(self, "toDestination", [destination, props]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnVPNConnectionEventLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionEventLogsRecordFields"]] = None,
    ) -> "CfnVPNConnectionLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__dc8632c324459312ee0a9390bbc08e46022375cc1cf328bd0d787ea33834020a)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnVPNConnectionEventLogsFirehoseProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnVPNConnectionLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnVPNConnectionEventLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionEventLogsRecordFields"]] = None,
    ) -> "CfnVPNConnectionLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__451c99afcbc205eab7eea65b7e4d1a7dea586391acf5bb4e346cb6bb9fd4d292)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnVPNConnectionEventLogsLogGroupProps(
            output_format=output_format, record_fields=record_fields
        )

        return typing.cast("CfnVPNConnectionLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnVPNConnectionEventLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionEventLogsRecordFields"]] = None,
    ) -> "CfnVPNConnectionLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__317fbbc6872359002d35ad4f0480f2e397891ae2a57c1ef50d9db91437d7877a)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnVPNConnectionEventLogsS3Props(
            encryption_key=encryption_key,
            output_format=output_format,
            record_fields=record_fields,
        )

        return typing.cast("CfnVPNConnectionLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionEventLogsDestProps",
    jsii_struct_bases=[],
    name_mapping={"record_fields": "recordFields"},
)
class CfnVPNConnectionEventLogsDestProps:
    def __init__(
        self,
        *,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_vPNConnection_event_logs_dest_props = ec2_mixins.CfnVPNConnectionEventLogsDestProps(
                record_fields=[ec2_mixins.CfnVPNConnectionEventLogsRecordFields.TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__6259f8ec1ee5f15c9fcb8d06338cdb45875c7fa9797070e657bb9474a7681886)
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnVPNConnectionEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnVPNConnectionEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVPNConnectionEventLogsDestProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionEventLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnVPNConnectionEventLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnVPNConnectionEventLogsOutputFormat.Firehose"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_vPNConnection_event_logs_firehose_props = ec2_mixins.CfnVPNConnectionEventLogsFirehoseProps(
                output_format=ec2_mixins.CfnVPNConnectionEventLogsOutputFormat.Firehose.JSON,
                record_fields=[ec2_mixins.CfnVPNConnectionEventLogsRecordFields.TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__9cc75dc477a5cd1ec5d826c4590b72f683e49d6c83310f59ed310a7d5affeb3e)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnVPNConnectionEventLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnVPNConnectionEventLogsOutputFormat.Firehose"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnVPNConnectionEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnVPNConnectionEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVPNConnectionEventLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionEventLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat", "record_fields": "recordFields"},
)
class CfnVPNConnectionEventLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnVPNConnectionEventLogsOutputFormat.LogGroup"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_vPNConnection_event_logs_log_group_props = ec2_mixins.CfnVPNConnectionEventLogsLogGroupProps(
                output_format=ec2_mixins.CfnVPNConnectionEventLogsOutputFormat.LogGroup.PLAIN,
                record_fields=[ec2_mixins.CfnVPNConnectionEventLogsRecordFields.TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb9065195624425fa6f570e85a69eaa864dc03e959f541ea3f5f704f1056bd19)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnVPNConnectionEventLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnVPNConnectionEventLogsOutputFormat.LogGroup"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnVPNConnectionEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnVPNConnectionEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVPNConnectionEventLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnVPNConnectionEventLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionEventLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnVPNConnectionEventLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        cfn_vPNConnection_event_logs_output_format = ec2_mixins.CfnVPNConnectionEventLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionEventLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionEventLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionEventLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.enum(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionEventLogsRecordFields"
)
class CfnVPNConnectionEventLogsRecordFields(enum.Enum):
    '''
    :stability: experimental
    '''

    TIMESTAMP = "TIMESTAMP"
    '''
    :stability: experimental
    '''
    TYPE = "TYPE"
    '''
    :stability: experimental
    '''
    STATUS = "STATUS"
    '''
    :stability: experimental
    '''
    MESSAGE = "MESSAGE"
    '''
    :stability: experimental
    '''
    RESOURCE_ID = "RESOURCE_ID"
    '''
    :stability: experimental
    '''
    EVENT_TIMESTAMP = "EVENT_TIMESTAMP"
    '''
    :stability: experimental
    '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionEventLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={
        "encryption_key": "encryptionKey",
        "output_format": "outputFormat",
        "record_fields": "recordFields",
    },
)
class CfnVPNConnectionEventLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnVPNConnectionEventLogsOutputFormat.S3"] = None,
        record_fields: typing.Optional[typing.Sequence["CfnVPNConnectionEventLogsRecordFields"]] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        :param record_fields: (experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_vPNConnection_event_logs_s3_props = ec2_mixins.CfnVPNConnectionEventLogsS3Props(
                encryption_key=key_ref,
                output_format=ec2_mixins.CfnVPNConnectionEventLogsOutputFormat.S3.JSON,
                record_fields=[ec2_mixins.CfnVPNConnectionEventLogsRecordFields.TIMESTAMP]
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__7fe9f988f614cdbc2bef8858a2af1b86b27b258b8fec693387eba2ec4116727d)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
            check_type(argname="argument record_fields", value=record_fields, expected_type=type_hints["record_fields"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format
        if record_fields is not None:
            self._values["record_fields"] = record_fields

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnVPNConnectionEventLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnVPNConnectionEventLogsOutputFormat.S3"], result)

    @builtins.property
    def record_fields(
        self,
    ) -> typing.Optional[typing.List["CfnVPNConnectionEventLogsRecordFields"]]:
        '''(experimental) Record fields that can be provided to a log delivery.

        :stability: experimental
        '''
        result = self._values.get("record_fields")
        return typing.cast(typing.Optional[typing.List["CfnVPNConnectionEventLogsRecordFields"]], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVPNConnectionEventLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnVPNConnectionLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVPNConnectionLogsMixin",
):
    '''Specifies a VPN connection between a virtual private gateway and a VPN customer gateway or a transit gateway and a VPN customer gateway.

    To specify a VPN connection between a transit gateway and customer gateway, use the ``TransitGatewayId`` and ``CustomerGatewayId`` properties.

    To specify a VPN connection between a virtual private gateway and customer gateway, use the ``VpnGatewayId`` and ``CustomerGatewayId`` properties.

    For more information, see `AWS Site-to-Site VPN <https://docs.aws.amazon.com/vpn/latest/s2svpn/VPC_VPN.html>`_ in the *AWS Site-to-Site VPN User Guide* .

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-vpnconnection.html
    :cloudformationResource: AWS::EC2::VPNConnection
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_vPNConnection_logs_mixin = ec2_mixins.CfnVPNConnectionLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::EC2::VPNConnection``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ce9eac90a24fb3cdf1c98803227fb3bbe2a17fe078982123de1a2d76a7c2ce11)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__08bf6c65d68079aa41bf6ac20bf557fe4e3e4f206271bce9ec0c13d770c23dfa)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__f6109783d1dae3a50b20367a7f158e2dc9aeefa1cc9cc390e5b25713ecc06928)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="CONNECTION_LOGS")
    def CONNECTION_LOGS(cls) -> "CfnVPNConnectionConnectionLogs":
        return typing.cast("CfnVPNConnectionConnectionLogs", jsii.sget(cls, "CONNECTION_LOGS"))

    @jsii.python.classproperty
    @jsii.member(jsii_name="EVENT_LOGS")
    def EVENT_LOGS(cls) -> "CfnVPNConnectionEventLogs":
        return typing.cast("CfnVPNConnectionEventLogs", jsii.sget(cls, "EVENT_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


@jsii.implements(_constructs_77d1e7e8.IMixin)
class CfnVerifiedAccessInstanceLogsMixin(
    _aws_cdk_ceddda9d.Mixin,
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVerifiedAccessInstanceLogsMixin",
):
    '''An AWS Verified Access instance is a regional entity that evaluates application requests and grants access only when your security requirements are met.

    :see: http://docs.aws.amazon.com/AWSCloudFormation/latest/UserGuide/aws-resource-ec2-verifiedaccessinstance.html
    :cloudformationResource: AWS::EC2::VerifiedAccessInstance
    :mixin: true
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview import aws_logs as logs
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        # logs_delivery: logs.ILogsDelivery
        
        cfn_verified_access_instance_logs_mixin = ec2_mixins.CfnVerifiedAccessInstanceLogsMixin("logType", logs_delivery)
    '''

    def __init__(
        self,
        log_type: builtins.str,
        log_delivery: "_ILogsDelivery_0d3c9e29",
    ) -> None:
        '''Create a mixin to enable vended logs for ``AWS::EC2::VerifiedAccessInstance``.

        :param log_type: Type of logs that are getting vended.
        :param log_delivery: Object in charge of setting up the delivery source, delivery destination, and delivery connection.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ae07f22a595c607ca5dc2de34321c791f4032d11d08567466153bdcce2850c4e)
            check_type(argname="argument log_type", value=log_type, expected_type=type_hints["log_type"])
            check_type(argname="argument log_delivery", value=log_delivery, expected_type=type_hints["log_delivery"])
        jsii.create(self.__class__, self, [log_type, log_delivery])

    @jsii.member(jsii_name="applyTo")
    def apply_to(self, resource: "_constructs_77d1e7e8.IConstruct") -> None:
        '''Apply vended logs configuration to the construct.

        :param resource: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__54835a32a6afbd853ea00f897032ccf9dc2c7e46f0c0a90cbe1de91553b332e9)
            check_type(argname="argument resource", value=resource, expected_type=type_hints["resource"])
        return typing.cast(None, jsii.invoke(self, "applyTo", [resource]))

    @jsii.member(jsii_name="supports")
    def supports(self, construct: "_constructs_77d1e7e8.IConstruct") -> builtins.bool:
        '''Check if this mixin supports the given construct (has vendedLogs property).

        :param construct: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__594625c13a60e6edd827a5ac0320463c073cc340bdea3c1d85832b548bfdff4b)
            check_type(argname="argument construct", value=construct, expected_type=type_hints["construct"])
        return typing.cast(builtins.bool, jsii.invoke(self, "supports", [construct]))

    @jsii.python.classproperty
    @jsii.member(jsii_name="VERIFIED_ACCESS_LOGS")
    def VERIFIED_ACCESS_LOGS(cls) -> "CfnVerifiedAccessInstanceVerifiedAccessLogs":
        return typing.cast("CfnVerifiedAccessInstanceVerifiedAccessLogs", jsii.sget(cls, "VERIFIED_ACCESS_LOGS"))

    @builtins.property
    @jsii.member(jsii_name="logDelivery")
    def _log_delivery(self) -> "_ILogsDelivery_0d3c9e29":
        return typing.cast("_ILogsDelivery_0d3c9e29", jsii.get(self, "logDelivery"))

    @builtins.property
    @jsii.member(jsii_name="logType")
    def _log_type(self) -> builtins.str:
        return typing.cast(builtins.str, jsii.get(self, "logType"))


class CfnVerifiedAccessInstanceVerifiedAccessLogs(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVerifiedAccessInstanceVerifiedAccessLogs",
):
    '''Builder for CfnVerifiedAccessInstanceLogsMixin to generate VERIFIED_ACCESS_LOGS for CfnVerifiedAccessInstance.

    :cloudformationResource: AWS::EC2::VerifiedAccessInstance
    :logType: VERIFIED_ACCESS_LOGS
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        cfn_verified_access_instance_verified_access_logs = ec2_mixins.CfnVerifiedAccessInstanceVerifiedAccessLogs()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="toDestination")
    def to_destination(
        self,
        destination: "_aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef",
    ) -> "CfnVerifiedAccessInstanceLogsMixin":
        '''Delivers logs to a pre-created delivery destination.

        Supported destinations are S3, CWL, FH
        You are responsible for setting up the correct permissions for your delivery destination, toDestination() does not set up any permissions for you.
        Delivery destinations that are imported from another stack using CfnDeliveryDestination.fromDeliveryDestinationArn() or CfnDeliveryDestination.fromDeliveryDestinationName() are supported by toDestination().

        :param destination: -
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__d4ed6bb3c649dcd3578f1d0474233f7a840a602d2344ace9ff637d6a40c614c4)
            check_type(argname="argument destination", value=destination, expected_type=type_hints["destination"])
        return typing.cast("CfnVerifiedAccessInstanceLogsMixin", jsii.invoke(self, "toDestination", [destination]))

    @jsii.member(jsii_name="toFirehose")
    def to_firehose(
        self,
        delivery_stream: "_aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef",
        *,
        output_format: typing.Optional["CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.Firehose"] = None,
    ) -> "CfnVerifiedAccessInstanceLogsMixin":
        '''Send logs to a Firehose Delivery Stream.

        :param delivery_stream: -
        :param output_format: (experimental) Format for log output, options are json,plain,raw.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__5cd5cd84b9949f4da82e94244c44605acc59dd84c8be6388034af4dff989bb3d)
            check_type(argname="argument delivery_stream", value=delivery_stream, expected_type=type_hints["delivery_stream"])
        props = CfnVerifiedAccessInstanceVerifiedAccessLogsFirehoseProps(
            output_format=output_format
        )

        return typing.cast("CfnVerifiedAccessInstanceLogsMixin", jsii.invoke(self, "toFirehose", [delivery_stream, props]))

    @jsii.member(jsii_name="toLogGroup")
    def to_log_group(
        self,
        log_group: "_aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef",
        *,
        output_format: typing.Optional["CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.LogGroup"] = None,
    ) -> "CfnVerifiedAccessInstanceLogsMixin":
        '''Send logs to a CloudWatch Log Group.

        :param log_group: -
        :param output_format: (experimental) Format for log output, options are plain,json.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8631ddd54bc752fc1b1e80f6fbb0577c3bf6aa98d0f75b55b1cbfad5c494b201)
            check_type(argname="argument log_group", value=log_group, expected_type=type_hints["log_group"])
        props = CfnVerifiedAccessInstanceVerifiedAccessLogsLogGroupProps(
            output_format=output_format
        )

        return typing.cast("CfnVerifiedAccessInstanceLogsMixin", jsii.invoke(self, "toLogGroup", [log_group, props]))

    @jsii.member(jsii_name="toS3")
    def to_s3(
        self,
        bucket: "_aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef",
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.S3"] = None,
    ) -> "CfnVerifiedAccessInstanceLogsMixin":
        '''Send logs to an S3 Bucket.

        :param bucket: -
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__cb7a15fd7bacf91708ef6f0fa7c093ae4f43ae36c160360da34a13fb2f4ec45b)
            check_type(argname="argument bucket", value=bucket, expected_type=type_hints["bucket"])
        props = CfnVerifiedAccessInstanceVerifiedAccessLogsS3Props(
            encryption_key=encryption_key, output_format=output_format
        )

        return typing.cast("CfnVerifiedAccessInstanceLogsMixin", jsii.invoke(self, "toS3", [bucket, props]))


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsFirehoseProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnVerifiedAccessInstanceVerifiedAccessLogsFirehoseProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.Firehose"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_verified_access_instance_verified_access_logs_firehose_props = ec2_mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsFirehoseProps(
                output_format=ec2_mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.Firehose.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__fb2a1ba080a1c9e600d438a7246e09186adf5dd00f53e6883bcef64c36c0ee11)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.Firehose"]:
        '''(experimental) Format for log output, options are json,plain,raw.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.Firehose"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVerifiedAccessInstanceVerifiedAccessLogsFirehoseProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsLogGroupProps",
    jsii_struct_bases=[],
    name_mapping={"output_format": "outputFormat"},
)
class CfnVerifiedAccessInstanceVerifiedAccessLogsLogGroupProps:
    def __init__(
        self,
        *,
        output_format: typing.Optional["CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.LogGroup"] = None,
    ) -> None:
        '''
        :param output_format: (experimental) Format for log output, options are plain,json.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            
            cfn_verified_access_instance_verified_access_logs_log_group_props = ec2_mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsLogGroupProps(
                output_format=ec2_mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.LogGroup.PLAIN
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__ed6d38511e7f66043fa7d8c1d2d88ef232f1e92a015e0adad15854533d744eb0)
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.LogGroup"]:
        '''(experimental) Format for log output, options are plain,json.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.LogGroup"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVerifiedAccessInstanceVerifiedAccessLogsLogGroupProps(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


class CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat",
):
    '''(experimental) Output Format options for each destination of CfnVerifiedAccessInstanceVerifiedAccessLogs.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
        
        cfn_verified_access_instance_verified_access_logs_output_format = ec2_mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.Firehose"
    )
    class Firehose(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        RAW = "RAW"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.LogGroup"
    )
    class LogGroup(enum.Enum):
        '''
        :stability: experimental
        '''

        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        JSON = "JSON"
        '''
        :stability: experimental
        '''

    @jsii.enum(
        jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.S3"
    )
    class S3(enum.Enum):
        '''
        :stability: experimental
        '''

        JSON = "JSON"
        '''
        :stability: experimental
        '''
        PLAIN = "PLAIN"
        '''
        :stability: experimental
        '''
        W3C = "W3C"
        '''
        :stability: experimental
        '''
        PARQUET = "PARQUET"
        '''
        :stability: experimental
        '''


@jsii.data_type(
    jsii_type="@aws-cdk/mixins-preview.aws_ec2.mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsS3Props",
    jsii_struct_bases=[],
    name_mapping={"encryption_key": "encryptionKey", "output_format": "outputFormat"},
)
class CfnVerifiedAccessInstanceVerifiedAccessLogsS3Props:
    def __init__(
        self,
        *,
        encryption_key: typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"] = None,
        output_format: typing.Optional["CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.S3"] = None,
    ) -> None:
        '''
        :param encryption_key: (experimental) Encrpytion key for your delivery bucket.
        :param output_format: (experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        :exampleMetadata: fixture=_generated

        Example::

            # The code below shows an example of how to instantiate this type.
            # The values are placeholders you should change.
            from aws_cdk.mixins_preview.aws_ec2 import mixins as ec2_mixins
            from aws_cdk.interfaces import aws_kms as interfaces_kms
            
            # key_ref: interfaces_kms.IKeyRef
            
            cfn_verified_access_instance_verified_access_logs_s3_props = ec2_mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsS3Props(
                encryption_key=key_ref,
                output_format=ec2_mixins.CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.S3.JSON
            )
        '''
        if __debug__:
            type_hints = typing.get_type_hints(_typecheckingstub__8a05b40000e3643a394de1b32235176db2023581dfa8683abf0f6162daec24ee)
            check_type(argname="argument encryption_key", value=encryption_key, expected_type=type_hints["encryption_key"])
            check_type(argname="argument output_format", value=output_format, expected_type=type_hints["output_format"])
        self._values: typing.Dict[builtins.str, typing.Any] = {}
        if encryption_key is not None:
            self._values["encryption_key"] = encryption_key
        if output_format is not None:
            self._values["output_format"] = output_format

    @builtins.property
    def encryption_key(
        self,
    ) -> typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"]:
        '''(experimental) Encrpytion key for your delivery bucket.

        :stability: experimental
        '''
        result = self._values.get("encryption_key")
        return typing.cast(typing.Optional["_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef"], result)

    @builtins.property
    def output_format(
        self,
    ) -> typing.Optional["CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.S3"]:
        '''(experimental) Format for log output, options are json,plain,w3c,parquet.

        :stability: experimental
        '''
        result = self._values.get("output_format")
        return typing.cast(typing.Optional["CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.S3"], result)

    def __eq__(self, rhs: typing.Any) -> builtins.bool:
        return isinstance(rhs, self.__class__) and rhs._values == self._values

    def __ne__(self, rhs: typing.Any) -> builtins.bool:
        return not (rhs == self)

    def __repr__(self) -> str:
        return "CfnVerifiedAccessInstanceVerifiedAccessLogsS3Props(%s)" % ", ".join(
            k + "=" + repr(v) for k, v in self._values.items()
        )


__all__ = [
    "CfnInstanceConsoleLogs",
    "CfnInstanceConsoleLogsDestProps",
    "CfnInstanceConsoleLogsFirehoseProps",
    "CfnInstanceConsoleLogsLogGroupProps",
    "CfnInstanceConsoleLogsOutputFormat",
    "CfnInstanceConsoleLogsRecordFields",
    "CfnInstanceConsoleLogsS3Props",
    "CfnInstanceLogsMixin",
    "CfnRouteServerPeerEventLogs",
    "CfnRouteServerPeerEventLogsDestProps",
    "CfnRouteServerPeerEventLogsFirehoseProps",
    "CfnRouteServerPeerEventLogsLogGroupProps",
    "CfnRouteServerPeerEventLogsOutputFormat",
    "CfnRouteServerPeerEventLogsRecordFields",
    "CfnRouteServerPeerEventLogsS3Props",
    "CfnRouteServerPeerLogsMixin",
    "CfnVPCLogsMixin",
    "CfnVPCRoute53ResolverQueryLogs",
    "CfnVPCRoute53ResolverQueryLogsFirehoseProps",
    "CfnVPCRoute53ResolverQueryLogsLogGroupProps",
    "CfnVPCRoute53ResolverQueryLogsOutputFormat",
    "CfnVPCRoute53ResolverQueryLogsS3Props",
    "CfnVPNConnectionConnectionLogs",
    "CfnVPNConnectionConnectionLogsDestProps",
    "CfnVPNConnectionConnectionLogsFirehoseProps",
    "CfnVPNConnectionConnectionLogsLogGroupProps",
    "CfnVPNConnectionConnectionLogsOutputFormat",
    "CfnVPNConnectionConnectionLogsRecordFields",
    "CfnVPNConnectionConnectionLogsS3Props",
    "CfnVPNConnectionEventLogs",
    "CfnVPNConnectionEventLogsDestProps",
    "CfnVPNConnectionEventLogsFirehoseProps",
    "CfnVPNConnectionEventLogsLogGroupProps",
    "CfnVPNConnectionEventLogsOutputFormat",
    "CfnVPNConnectionEventLogsRecordFields",
    "CfnVPNConnectionEventLogsS3Props",
    "CfnVPNConnectionLogsMixin",
    "CfnVerifiedAccessInstanceLogsMixin",
    "CfnVerifiedAccessInstanceVerifiedAccessLogs",
    "CfnVerifiedAccessInstanceVerifiedAccessLogsFirehoseProps",
    "CfnVerifiedAccessInstanceVerifiedAccessLogsLogGroupProps",
    "CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat",
    "CfnVerifiedAccessInstanceVerifiedAccessLogsS3Props",
]

publication.publish()

def _typecheckingstub__eaa7660e95a48978e229da9bcde4c80c25d1e02088e1f8aa35f71233fb7f968d(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceConsoleLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce4d020df53e06cb91bc34c321bda99ab98a1441a22bbafd05408b090e4a4c89(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnInstanceConsoleLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceConsoleLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__51af58a2cae4965eb4f14ad8e79554f79aaf56e81878479ca3f7366d37f28d0b(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnInstanceConsoleLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceConsoleLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c4c8ca153f62a2d562a74f5047ede4c49a1a777f3c31a569ee9bce17f0932798(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnInstanceConsoleLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceConsoleLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__80b9b83b6233b5778777b2d0f4f734f289742bfecc3c28d1553da83ed4f23f4b(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceConsoleLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6d3e83f0020e979a366dcb1f661af112ad4dfdab5349ae2c446435e227a45b8e(
    *,
    output_format: typing.Optional[CfnInstanceConsoleLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceConsoleLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fd8747c951a89662c2ce13002ec1495eafd0b4cc41510a35a7434533da2787cd(
    *,
    output_format: typing.Optional[CfnInstanceConsoleLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceConsoleLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__509b792f4a1fe51be86b85a92e47864ca2123b17da1704edb0af98b538da7615(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnInstanceConsoleLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnInstanceConsoleLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6c93fe8f448360e1d4909ea281308d277495fab4873d61e15294f96ed66519f4(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__326e3717c25d818e3fe6c8250b55b6cadd09ff1d13591cf5a76798e9e51ab77e(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__eb7f4586095885982713c52d0cac1ae1a73a5a3f3ee9d56d51cf5a744fa77241(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f1f82a0df048510e956bd207679526b8d25b241a8e6309a706b9a5db4de9c8c3(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRouteServerPeerEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e62af65b07d05908bdf46d749244d1cc99dffcd32323e46cecdfbebcbeb947b9(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnRouteServerPeerEventLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRouteServerPeerEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b982f19ff649590805549ffc3f5e8f8bf05456543fc9b2e398f71eb61adc82a4(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnRouteServerPeerEventLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRouteServerPeerEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e5aa15c5a090e9206ad9c49e22bbcd6540feaba02aa8a94bb2f96441f7de6fe9(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnRouteServerPeerEventLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRouteServerPeerEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__107261317e23c7b3ec0ebb67b00fa4d1e61a028c15a70ebc38dbb89ab5830c70(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnRouteServerPeerEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1b7b0aa8e6897ee2528de92889164a23c5fc9c42e15c7cd0c878eb4886c3fb3c(
    *,
    output_format: typing.Optional[CfnRouteServerPeerEventLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRouteServerPeerEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__25801079ac85d1e83417dcaafd631b33b2bb0e652550eee2750ae7399d218fd2(
    *,
    output_format: typing.Optional[CfnRouteServerPeerEventLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRouteServerPeerEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2dab4233d78b8d9356c48b374736ae0afedb9a4d9649aefa0824fb297980eb38(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnRouteServerPeerEventLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnRouteServerPeerEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__e887379c7ce461cf348e2d0a8886b52ad7923d6fee0347023e8e70995b5c98ad(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b53a309af28da1eec8b32e48fe86c145f2eda70f8ac9c3a10faefedb25aa2368(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8e3988d66ef777b3f2816b11e3632f39fd0e01a4920356b90f4e74fc630aba7b(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__c887737e6727e3b16b8ac6538e1fc7d512b67d7a6e88a3a8d55f6bdb1bc2cf69(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__2d340aa09c1d4740786b10583283e670e3385659d850c72e307cfce7f4b57111(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f2d89c70adb4839231da02fd8662b5c1a1aaff9a33627b917996c39b671375e5(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__af842ea6227ee375de460aad6584ada5201abe77391d3118a84dae29caed37b3(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1ca4b568a71338f3c7febfbfdaa32660bcde709925defef7af2bf63e9dcff93e(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnVPCRoute53ResolverQueryLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__1db7e0342b08f126a3d7da6d9626995ea548898b70250c986a5d3b069704ed9b(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnVPCRoute53ResolverQueryLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__996b4cc3fed52d55989f54f04abafdf6602b02765140574ab2fa594ce76048a8(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnVPCRoute53ResolverQueryLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__a6649805de95076b56cef9c202a55e95e702501489d08de125a09c621b6754b5(
    *,
    output_format: typing.Optional[CfnVPCRoute53ResolverQueryLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__b1c6c4c09d5da8a5800a6dad0e2a9cb07553a2de66d3d99466c4945caea891ff(
    *,
    output_format: typing.Optional[CfnVPCRoute53ResolverQueryLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0a073d716b768e140aef8c37029e6c3c957b9ccb1de8fd31e6e0f22e4a676515(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnVPCRoute53ResolverQueryLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__599cfcabc587635fb325339a4527928d6c498f411e1d6e71fd670bb2eea6c8c6(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__0714b7ed6595a643ea3885a2bedf04f9357303454c4affc9a3fdc10377c732f1(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnVPNConnectionConnectionLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__39bc7d8b12a17004e39a23a0d8bbd8a88236ef91b8537b8f147bddd516fda175(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnVPNConnectionConnectionLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d0b3873bd6c3a456c0da217041ae01157cc50e3d845dec1841c6ef1a016d16e6(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnVPNConnectionConnectionLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fc4fa98757a4c4de867e1ac929c8d201e5ecf53d3337d3c88ae1ad72a593cba5(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7d9c9499223b247def1f66e01ea577f7e387aac3e3d007ace3e304b218545c4d(
    *,
    output_format: typing.Optional[CfnVPNConnectionConnectionLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__476826482540948f187a054c44511d6c11b2b0d42c5934120271ce9e57dcbb37(
    *,
    output_format: typing.Optional[CfnVPNConnectionConnectionLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__83c29e98a0d4a1485e683a26017d2ad8a23836fdd7de166009f013131cd5ada1(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnVPNConnectionConnectionLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionConnectionLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__70724ed9610c8939134c83f0793dc365a339a786dc1878b93558c614fac20aa9(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
    *,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__dc8632c324459312ee0a9390bbc08e46022375cc1cf328bd0d787ea33834020a(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnVPNConnectionEventLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__451c99afcbc205eab7eea65b7e4d1a7dea586391acf5bb4e346cb6bb9fd4d292(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnVPNConnectionEventLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__317fbbc6872359002d35ad4f0480f2e397891ae2a57c1ef50d9db91437d7877a(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnVPNConnectionEventLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__6259f8ec1ee5f15c9fcb8d06338cdb45875c7fa9797070e657bb9474a7681886(
    *,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__9cc75dc477a5cd1ec5d826c4590b72f683e49d6c83310f59ed310a7d5affeb3e(
    *,
    output_format: typing.Optional[CfnVPNConnectionEventLogsOutputFormat.Firehose] = None,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb9065195624425fa6f570e85a69eaa864dc03e959f541ea3f5f704f1056bd19(
    *,
    output_format: typing.Optional[CfnVPNConnectionEventLogsOutputFormat.LogGroup] = None,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__7fe9f988f614cdbc2bef8858a2af1b86b27b258b8fec693387eba2ec4116727d(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnVPNConnectionEventLogsOutputFormat.S3] = None,
    record_fields: typing.Optional[typing.Sequence[CfnVPNConnectionEventLogsRecordFields]] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ce9eac90a24fb3cdf1c98803227fb3bbe2a17fe078982123de1a2d76a7c2ce11(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__08bf6c65d68079aa41bf6ac20bf557fe4e3e4f206271bce9ec0c13d770c23dfa(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__f6109783d1dae3a50b20367a7f158e2dc9aeefa1cc9cc390e5b25713ecc06928(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ae07f22a595c607ca5dc2de34321c791f4032d11d08567466153bdcce2850c4e(
    log_type: builtins.str,
    log_delivery: _ILogsDelivery_0d3c9e29,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__54835a32a6afbd853ea00f897032ccf9dc2c7e46f0c0a90cbe1de91553b332e9(
    resource: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__594625c13a60e6edd827a5ac0320463c073cc340bdea3c1d85832b548bfdff4b(
    construct: _constructs_77d1e7e8.IConstruct,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__d4ed6bb3c649dcd3578f1d0474233f7a840a602d2344ace9ff637d6a40c614c4(
    destination: _aws_cdk_interfaces_aws_logs_ceddda9d.IDeliveryDestinationRef,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__5cd5cd84b9949f4da82e94244c44605acc59dd84c8be6388034af4dff989bb3d(
    delivery_stream: _aws_cdk_interfaces_aws_kinesisfirehose_ceddda9d.IDeliveryStreamRef,
    *,
    output_format: typing.Optional[CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8631ddd54bc752fc1b1e80f6fbb0577c3bf6aa98d0f75b55b1cbfad5c494b201(
    log_group: _aws_cdk_interfaces_aws_logs_ceddda9d.ILogGroupRef,
    *,
    output_format: typing.Optional[CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__cb7a15fd7bacf91708ef6f0fa7c093ae4f43ae36c160360da34a13fb2f4ec45b(
    bucket: _aws_cdk_interfaces_aws_s3_ceddda9d.IBucketRef,
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__fb2a1ba080a1c9e600d438a7246e09186adf5dd00f53e6883bcef64c36c0ee11(
    *,
    output_format: typing.Optional[CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.Firehose] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__ed6d38511e7f66043fa7d8c1d2d88ef232f1e92a015e0adad15854533d744eb0(
    *,
    output_format: typing.Optional[CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.LogGroup] = None,
) -> None:
    """Type checking stubs"""
    pass

def _typecheckingstub__8a05b40000e3643a394de1b32235176db2023581dfa8683abf0f6162daec24ee(
    *,
    encryption_key: typing.Optional[_aws_cdk_interfaces_aws_kms_ceddda9d.IKeyRef] = None,
    output_format: typing.Optional[CfnVerifiedAccessInstanceVerifiedAccessLogsOutputFormat.S3] = None,
) -> None:
    """Type checking stubs"""
    pass
