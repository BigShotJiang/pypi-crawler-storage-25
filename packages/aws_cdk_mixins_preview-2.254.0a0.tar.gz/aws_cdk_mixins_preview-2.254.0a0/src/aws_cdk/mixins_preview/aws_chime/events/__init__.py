from pkgutil import extend_path
__path__ = extend_path(__path__, __name__)

import abc
import builtins
import datetime
import enum
import typing

import jsii
import publication
import typing_extensions

import typeguard
from importlib.metadata import version as _metadata_package_version
TYPEGUARD_MAJOR_VERSION = int(_metadata_package_version('typeguard').split('.')[0])

def check_type(argname: str, value: object, expected_type: typing.Any) -> typing.Any:
    if TYPEGUARD_MAJOR_VERSION <= 2:
        return typeguard.check_type(argname=argname, value=value, expected_type=expected_type) # type:ignore
    else:
        if isinstance(value, jsii._reference_map.InterfaceDynamicProxy): # pyright: ignore [reportAttributeAccessIssue]
           pass
        else:
            if TYPEGUARD_MAJOR_VERSION == 3:
                typeguard.config.collection_check_strategy = typeguard.CollectionCheckStrategy.ALL_ITEMS # type:ignore
                typeguard.check_type(value=value, expected_type=expected_type) # type:ignore
            else:
                typeguard.check_type(value=value, expected_type=expected_type, collection_check_strategy=typeguard.CollectionCheckStrategy.ALL_ITEMS) # type:ignore

from ..._jsii import *

import aws_cdk as _aws_cdk_ceddda9d
import aws_cdk.aws_events as _aws_cdk_aws_events_ceddda9d


class ChimeVoiceConnectorStreamingStatus(
    metaclass=jsii.JSIIMeta,
    jsii_type="@aws-cdk/mixins-preview.aws_chime.events.ChimeVoiceConnectorStreamingStatus",
):
    '''(experimental) EventBridge event pattern for aws.chime@ChimeVoiceConnectorStreamingStatus.

    :stability: experimental
    :exampleMetadata: fixture=_generated

    Example::

        # The code below shows an example of how to instantiate this type.
        # The values are placeholders you should change.
        from aws_cdk.mixins_preview.aws_chime import events as chime_events
        
        chime_voice_connector_streaming_status = chime_events.ChimeVoiceConnectorStreamingStatus()
    '''

    def __init__(self) -> None:
        '''
        :stability: experimental
        '''
        jsii.create(self.__class__, self, [])

    @jsii.member(jsii_name="eventPattern")
    @builtins.classmethod
    def event_pattern(
        cls,
        *,
        call_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        direction: typing.Optional[typing.Sequence[builtins.str]] = None,
        event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
        invite_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
        media_type: typing.Optional[typing.Sequence[builtins.str]] = None,
        siprec_metadata: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_fragment_number: typing.Optional[typing.Sequence[builtins.str]] = None,
        start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
        stream_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
        streaming_status: typing.Optional[typing.Sequence[builtins.str]] = None,
        transaction_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        version: typing.Optional[typing.Sequence[builtins.str]] = None,
        voice_connector_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    ) -> "_aws_cdk_aws_events_ceddda9d.EventPattern":
        '''(experimental) EventBridge event pattern for Chime VoiceConnector Streaming Status.

        :param call_id: (experimental) callId property. Specify an array of string values to match this event if the actual value of callId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param direction: (experimental) direction property. Specify an array of string values to match this event if the actual value of direction is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param event_metadata: (experimental) EventBridge event metadata. Default: - -
        :param invite_headers: (experimental) inviteHeaders property. Specify an array of string values to match this event if the actual value of inviteHeaders is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param media_type: (experimental) mediaType property. Specify an array of string values to match this event if the actual value of mediaType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param siprec_metadata: (experimental) siprecMetadata property. Specify an array of string values to match this event if the actual value of siprecMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_fragment_number: (experimental) startFragmentNumber property. Specify an array of string values to match this event if the actual value of startFragmentNumber is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param stream_arn: (experimental) streamArn property. Specify an array of string values to match this event if the actual value of streamArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param streaming_status: (experimental) streamingStatus property. Specify an array of string values to match this event if the actual value of streamingStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param transaction_id: (experimental) transactionId property. Specify an array of string values to match this event if the actual value of transactionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
        :param voice_connector_id: (experimental) voiceConnectorId property. Specify an array of string values to match this event if the actual value of voiceConnectorId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

        :stability: experimental
        '''
        options = ChimeVoiceConnectorStreamingStatus.ChimeVoiceConnectorStreamingStatusProps(
            call_id=call_id,
            direction=direction,
            event_metadata=event_metadata,
            invite_headers=invite_headers,
            media_type=media_type,
            siprec_metadata=siprec_metadata,
            start_fragment_number=start_fragment_number,
            start_time=start_time,
            stream_arn=stream_arn,
            streaming_status=streaming_status,
            transaction_id=transaction_id,
            version=version,
            voice_connector_id=voice_connector_id,
        )

        return typing.cast("_aws_cdk_aws_events_ceddda9d.EventPattern", jsii.sinvoke(cls, "eventPattern", [options]))

    @jsii.data_type(
        jsii_type="@aws-cdk/mixins-preview.aws_chime.events.ChimeVoiceConnectorStreamingStatus.ChimeVoiceConnectorStreamingStatusProps",
        jsii_struct_bases=[],
        name_mapping={
            "call_id": "callId",
            "direction": "direction",
            "event_metadata": "eventMetadata",
            "invite_headers": "inviteHeaders",
            "media_type": "mediaType",
            "siprec_metadata": "siprecMetadata",
            "start_fragment_number": "startFragmentNumber",
            "start_time": "startTime",
            "stream_arn": "streamArn",
            "streaming_status": "streamingStatus",
            "transaction_id": "transactionId",
            "version": "version",
            "voice_connector_id": "voiceConnectorId",
        },
    )
    class ChimeVoiceConnectorStreamingStatusProps:
        def __init__(
            self,
            *,
            call_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            direction: typing.Optional[typing.Sequence[builtins.str]] = None,
            event_metadata: typing.Optional[typing.Union["_aws_cdk_ceddda9d.AWSEventMetadataProps", typing.Dict[builtins.str, typing.Any]]] = None,
            invite_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
            media_type: typing.Optional[typing.Sequence[builtins.str]] = None,
            siprec_metadata: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_fragment_number: typing.Optional[typing.Sequence[builtins.str]] = None,
            start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
            stream_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
            streaming_status: typing.Optional[typing.Sequence[builtins.str]] = None,
            transaction_id: typing.Optional[typing.Sequence[builtins.str]] = None,
            version: typing.Optional[typing.Sequence[builtins.str]] = None,
            voice_connector_id: typing.Optional[typing.Sequence[builtins.str]] = None,
        ) -> None:
            '''(experimental) Props type for aws.chime@ChimeVoiceConnectorStreamingStatus event.

            :param call_id: (experimental) callId property. Specify an array of string values to match this event if the actual value of callId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param direction: (experimental) direction property. Specify an array of string values to match this event if the actual value of direction is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param event_metadata: (experimental) EventBridge event metadata. Default: - -
            :param invite_headers: (experimental) inviteHeaders property. Specify an array of string values to match this event if the actual value of inviteHeaders is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param media_type: (experimental) mediaType property. Specify an array of string values to match this event if the actual value of mediaType is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param siprec_metadata: (experimental) siprecMetadata property. Specify an array of string values to match this event if the actual value of siprecMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_fragment_number: (experimental) startFragmentNumber property. Specify an array of string values to match this event if the actual value of startFragmentNumber is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param start_time: (experimental) startTime property. Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param stream_arn: (experimental) streamArn property. Specify an array of string values to match this event if the actual value of streamArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param streaming_status: (experimental) streamingStatus property. Specify an array of string values to match this event if the actual value of streamingStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param transaction_id: (experimental) transactionId property. Specify an array of string values to match this event if the actual value of transactionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param version: (experimental) version property. Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field
            :param voice_connector_id: (experimental) voiceConnectorId property. Specify an array of string values to match this event if the actual value of voiceConnectorId is one of the values in the array. Use one of the constructors on the ``aws_events.Match`` for more advanced matching options. Default: - Do not filter on this field

            :stability: experimental
            :exampleMetadata: fixture=_generated

            Example::

                from aws_cdk import AWSEventMetadataProps
                # The code below shows an example of how to instantiate this type.
                # The values are placeholders you should change.
                from aws_cdk.mixins_preview.aws_chime import events as chime_events
                
                chime_voice_connector_streaming_status_props = chime_events.ChimeVoiceConnectorStreamingStatus.ChimeVoiceConnectorStreamingStatusProps(
                    call_id=["callId"],
                    direction=["direction"],
                    event_metadata=AWSEventMetadataProps(
                        region=["region"],
                        resources=["resources"],
                        version=["version"]
                    ),
                    invite_headers={
                        "invite_headers_key": "inviteHeaders"
                    },
                    media_type=["mediaType"],
                    siprec_metadata=["siprecMetadata"],
                    start_fragment_number=["startFragmentNumber"],
                    start_time=["startTime"],
                    stream_arn=["streamArn"],
                    streaming_status=["streamingStatus"],
                    transaction_id=["transactionId"],
                    version=["version"],
                    voice_connector_id=["voiceConnectorId"]
                )
            '''
            if isinstance(event_metadata, dict):
                event_metadata = _aws_cdk_ceddda9d.AWSEventMetadataProps(**event_metadata)
            if __debug__:
                type_hints = typing.get_type_hints(_typecheckingstub__56c9199a5f05ffdfb6f249ed0c5f449f2ca07896be26deaa36cbbf2db4ffa1fc)
                check_type(argname="argument call_id", value=call_id, expected_type=type_hints["call_id"])
                check_type(argname="argument direction", value=direction, expected_type=type_hints["direction"])
                check_type(argname="argument event_metadata", value=event_metadata, expected_type=type_hints["event_metadata"])
                check_type(argname="argument invite_headers", value=invite_headers, expected_type=type_hints["invite_headers"])
                check_type(argname="argument media_type", value=media_type, expected_type=type_hints["media_type"])
                check_type(argname="argument siprec_metadata", value=siprec_metadata, expected_type=type_hints["siprec_metadata"])
                check_type(argname="argument start_fragment_number", value=start_fragment_number, expected_type=type_hints["start_fragment_number"])
                check_type(argname="argument start_time", value=start_time, expected_type=type_hints["start_time"])
                check_type(argname="argument stream_arn", value=stream_arn, expected_type=type_hints["stream_arn"])
                check_type(argname="argument streaming_status", value=streaming_status, expected_type=type_hints["streaming_status"])
                check_type(argname="argument transaction_id", value=transaction_id, expected_type=type_hints["transaction_id"])
                check_type(argname="argument version", value=version, expected_type=type_hints["version"])
                check_type(argname="argument voice_connector_id", value=voice_connector_id, expected_type=type_hints["voice_connector_id"])
            self._values: typing.Dict[builtins.str, typing.Any] = {}
            if call_id is not None:
                self._values["call_id"] = call_id
            if direction is not None:
                self._values["direction"] = direction
            if event_metadata is not None:
                self._values["event_metadata"] = event_metadata
            if invite_headers is not None:
                self._values["invite_headers"] = invite_headers
            if media_type is not None:
                self._values["media_type"] = media_type
            if siprec_metadata is not None:
                self._values["siprec_metadata"] = siprec_metadata
            if start_fragment_number is not None:
                self._values["start_fragment_number"] = start_fragment_number
            if start_time is not None:
                self._values["start_time"] = start_time
            if stream_arn is not None:
                self._values["stream_arn"] = stream_arn
            if streaming_status is not None:
                self._values["streaming_status"] = streaming_status
            if transaction_id is not None:
                self._values["transaction_id"] = transaction_id
            if version is not None:
                self._values["version"] = version
            if voice_connector_id is not None:
                self._values["voice_connector_id"] = voice_connector_id

        @builtins.property
        def call_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) callId property.

            Specify an array of string values to match this event if the actual value of callId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("call_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def direction(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) direction property.

            Specify an array of string values to match this event if the actual value of direction is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("direction")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def event_metadata(
            self,
        ) -> typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"]:
            '''(experimental) EventBridge event metadata.

            :default:

            -
            -

            :stability: experimental
            '''
            result = self._values.get("event_metadata")
            return typing.cast(typing.Optional["_aws_cdk_ceddda9d.AWSEventMetadataProps"], result)

        @builtins.property
        def invite_headers(
            self,
        ) -> typing.Optional[typing.Mapping[builtins.str, builtins.str]]:
            '''(experimental) inviteHeaders property.

            Specify an array of string values to match this event if the actual value of inviteHeaders is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("invite_headers")
            return typing.cast(typing.Optional[typing.Mapping[builtins.str, builtins.str]], result)

        @builtins.property
        def media_type(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) mediaType property.

            Specify an array of string values to match this event if the actual value of mediaType is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("media_type")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def siprec_metadata(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) siprecMetadata property.

            Specify an array of string values to match this event if the actual value of siprecMetadata is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("siprec_metadata")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_fragment_number(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startFragmentNumber property.

            Specify an array of string values to match this event if the actual value of startFragmentNumber is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_fragment_number")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def start_time(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) startTime property.

            Specify an array of string values to match this event if the actual value of startTime is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("start_time")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def stream_arn(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) streamArn property.

            Specify an array of string values to match this event if the actual value of streamArn is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("stream_arn")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def streaming_status(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) streamingStatus property.

            Specify an array of string values to match this event if the actual value of streamingStatus is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("streaming_status")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def transaction_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) transactionId property.

            Specify an array of string values to match this event if the actual value of transactionId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("transaction_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def version(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) version property.

            Specify an array of string values to match this event if the actual value of version is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("version")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        @builtins.property
        def voice_connector_id(self) -> typing.Optional[typing.List[builtins.str]]:
            '''(experimental) voiceConnectorId property.

            Specify an array of string values to match this event if the actual value of voiceConnectorId is one of the values in the array. Use one of the constructors on the ``aws_events.Match``  for more advanced matching options.

            :default: - Do not filter on this field

            :stability: experimental
            '''
            result = self._values.get("voice_connector_id")
            return typing.cast(typing.Optional[typing.List[builtins.str]], result)

        def __eq__(self, rhs: typing.Any) -> builtins.bool:
            return isinstance(rhs, self.__class__) and rhs._values == self._values

        def __ne__(self, rhs: typing.Any) -> builtins.bool:
            return not (rhs == self)

        def __repr__(self) -> str:
            return "ChimeVoiceConnectorStreamingStatusProps(%s)" % ", ".join(
                k + "=" + repr(v) for k, v in self._values.items()
            )


__all__ = [
    "ChimeVoiceConnectorStreamingStatus",
]

publication.publish()

def _typecheckingstub__56c9199a5f05ffdfb6f249ed0c5f449f2ca07896be26deaa36cbbf2db4ffa1fc(
    *,
    call_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    direction: typing.Optional[typing.Sequence[builtins.str]] = None,
    event_metadata: typing.Optional[typing.Union[_aws_cdk_ceddda9d.AWSEventMetadataProps, typing.Dict[builtins.str, typing.Any]]] = None,
    invite_headers: typing.Optional[typing.Mapping[builtins.str, builtins.str]] = None,
    media_type: typing.Optional[typing.Sequence[builtins.str]] = None,
    siprec_metadata: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_fragment_number: typing.Optional[typing.Sequence[builtins.str]] = None,
    start_time: typing.Optional[typing.Sequence[builtins.str]] = None,
    stream_arn: typing.Optional[typing.Sequence[builtins.str]] = None,
    streaming_status: typing.Optional[typing.Sequence[builtins.str]] = None,
    transaction_id: typing.Optional[typing.Sequence[builtins.str]] = None,
    version: typing.Optional[typing.Sequence[builtins.str]] = None,
    voice_connector_id: typing.Optional[typing.Sequence[builtins.str]] = None,
) -> None:
    """Type checking stubs"""
    pass
