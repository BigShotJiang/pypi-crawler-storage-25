# CDK Mixins

> **Note**: The core Mixins mechanism  is now GA  and available in `constructs` and `aws-cdk-lib` (`Mixins`, `Mixin`, `IMixin`, `MixinApplicator`, `ConstructSelector`).
> All service Mixins are now available in `aws-cdk-lib`.
> Please update your imports.
>
> This package continues to provide **Logs Delivery Mixins** and **EventBridge Event Facades**, which are still experimental.

<!--BEGIN STABILITY BANNER-->---


![cdk-constructs: Experimental](https://img.shields.io/badge/cdk--constructs-experimental-important.svg?style=for-the-badge)

> The APIs of higher level constructs in this module are experimental and under active development.
> They are subject to non-backward compatible changes or removal in any future version. These are
> not subject to the [Semantic Versioning](https://semver.org/) model and breaking changes will be
> announced in the release notes. This means that while you may use them, you may need to update
> your source code when upgrading to a newer version of this package.

---
<!--END STABILITY BANNER-->

CDK Mixins provide a new, advanced way to add functionality through composable abstractions.
Unlike traditional L2 constructs that bundle all features together, Mixins allow you to pick and choose exactly the capabilities you need for constructs.
Mixins can be applied during or after construct construction.
Mixins are an *addition*, *not* a replacement for construct properties.
By itself, they cannot change optionality of properties or change defaults.

## Usage and documentation

See the [documentation for CDK Mixins](https://docs.aws.amazon.com/cdk/api/v2/docs/aws-cdk-lib-readme.html#mixins) in  `aws-cdk-lib`.

### Built-in Mixins

### Logs Delivery

Configures vended logs delivery for supported resources to various destinations:

```python
import aws_cdk.mixins_preview.aws_cloudfront.mixins as cloudfront_mixins

# Create CloudFront distribution
# origin: s3.IBucket

distribution = cloudfront.Distribution(scope, "Distribution",
    default_behavior=cloudfront.BehaviorOptions(
        origin=origins.S3BucketOrigin.with_origin_access_control(origin)
    )
)

# Create log destination
log_group = logs.LogGroup(scope, "DeliveryLogGroup")

# Configure log delivery using the mixin
distribution.with(cloudfront_mixins.CfnDistributionLogsMixin.CONNECTION_LOGS.to_log_group(log_group,
    output_format=cloudfront_mixins.CfnDistributionConnectionLogsOutputFormat.LogGroup.JSON,
    record_fields=[cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CONNECTIONSTATUS, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.CLIENTIP, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.SERVERIP, cloudfront_mixins.CfnDistributionConnectionLogsRecordFields.TLSPROTOCOL
    ]
))
```

Configures vended logs delivery for supported resources when a pre-created destination is provided:

```python
import aws_cdk.mixins_preview.aws_cloudfront.mixins as cloudfront_mixins

# Create CloudFront distribution
# origin: s3.IBucket

distribution = cloudfront.Distribution(scope, "Distribution",
    default_behavior=cloudfront.BehaviorOptions(
        origin=origins.S3BucketOrigin.with_origin_access_control(origin)
    )
)

# Create destination bucket
dest_bucket = s3.Bucket(scope, "DeliveryBucket")
# Add permissions to bucket to facilitate log delivery
bucket_policy = s3.BucketPolicy(scope, "DeliveryBucketPolicy",
    bucket=dest_bucket,
    document=iam.PolicyDocument()
)
# Create S3 delivery destination for logs
destination = logs.CfnDeliveryDestination(scope, "Destination",
    destination_resource_arn=dest_bucket.bucket_arn,
    name="unique-destination-name",
    delivery_destination_type="S3"
)

distribution.with(cloudfront_mixins.CfnDistributionLogsMixin.CONNECTION_LOGS.to_destination(destination))
```

Vended Logs Configuration for Cross Account delivery (only supported for S3 and Firehose destinations)

```python
from aws_cdk import Environment, Environment
import aws_cdk.mixins_preview.aws_logs as log_destinations
import aws_cdk.mixins_preview.aws_cloudfront.mixins as cloudfront_mixins

# Create CloudFront distribution
# origin: s3.IBucket


destination_account = "123456789012"
source_account = "234567890123"
region = "us-east-1"

app = App()

dest_stack = Stack(app, "destination-stack",
    env=Environment(
        account=destination_account,
        region=region
    )
)

# Create destination bucket
dest_bucket = s3.Bucket(dest_stack, "DeliveryBucket")
log_destinations.S3DeliveryDestination(dest_stack, "Destination",
    bucket=dest_bucket,
    source_account_id=source_account
)

source_stack = Stack(app, "source-stack",
    env=Environment(
        account=source_account,
        region=region
    )
)
distribution = cloudfront.Distribution(source_stack, "Distribution",
    default_behavior=cloudfront.BehaviorOptions(
        origin=origins.S3BucketOrigin.with_origin_access_control(origin)
    )
)

destination = logs.CfnDeliveryDestination.from_delivery_destination_arn(source_stack, "Destination", "arn of Delivery Destination in destinationAccount")

distribution.with(cloudfront_mixins.CfnDistributionLogsMixin.CONNECTION_LOGS.to_destination(destination))
```

---


## EventBridge Event Patterns

CDK Mixins automatically generates typed EventBridge event patterns for AWS resources. These patterns come in two flavors: **resource-specific** and **standalone**.

### Resource-Specific Event Patterns

Resource-specific patterns are created by attaching a resource reference (e.g. an S3 bucket). The resource identifier is automatically injected into the event pattern, so calling a pattern method with no arguments still filters events to that specific resource. For example, an S3 `objectCreatedPattern()` will automatically include the bucket name in the pattern, meaning it only matches events from that particular bucket.

#### Event Patterns Basic Usage

```python
from aws_cdk.mixins_preview.aws_s3.events.ObjectType import ObjectType, ObjectType
from aws_cdk.mixins_preview.aws_s3.events import BucketEvents
import aws_cdk.aws_events as events
import aws_cdk.aws_events_targets as targets
# fn: lambda.Function


# Works with L2 constructs
my_bucket = s3.Bucket(scope, "Bucket")
bucket_events = BucketEvents.from_bucket(my_bucket)

events.Rule(scope, "Rule",
    event_pattern=bucket_events.object_created_pattern(
        object=ObjectType(key=events.Match.wildcard("uploads/*"))
    ),
    targets=[targets.LambdaFunction(fn)]
)

# Also works with L1 constructs
cfn_bucket = s3.CfnBucket(scope, "CfnBucket")
cfn_bucket_events = BucketEvents.from_bucket(cfn_bucket)

events.CfnRule(scope, "CfnRule",
    state="ENABLED",
    event_pattern=cfn_bucket_events.object_created_pattern(
        object=ObjectType(key=events.Match.wildcard("uploads/*"))
    ),
    targets=[events.CfnRule.TargetProperty(arn=fn.function_arn, id="L1")]
)
```

#### Event Pattern Features

```python
from aws_cdk.mixins_preview.aws_s3.events import BucketEvents


bucket_events = BucketEvents.from_bucket(bucket)

# Bucket name is automatically injected from the bucket reference
pattern = bucket_events.object_created_pattern()
```

**Event Metadata Support**: Control EventBridge pattern metadata

```python
from aws_cdk import AWSEventMetadataProps
from aws_cdk.mixins_preview.aws_s3.events import BucketEvents
import aws_cdk.aws_events as events


bucket_events = BucketEvents.from_bucket(bucket)

pattern = bucket_events.object_created_pattern(
    event_metadata=AWSEventMetadataProps(
        region=events.Match.prefix("us-"),
        version=["0"]
    )
)
```

### Standalone Event Patterns

Standalone patterns are not tied to any specific resource. They match events across all resources of that type. For example, a standalone `AWSAPICallViaCloudTrail.eventPattern()` will match CloudTrail API calls for all S3 buckets in the account, not just a specific one.

#### Event Patterns Basic Usage

```python
from aws_cdk import AWSEventMetadataProps, AWSEventMetadataProps
from aws_cdk.mixins_preview.aws_s3.events import AWSAPICallViaCloudTrail, ObjectCreated, ObjectDeleted
import aws_cdk.aws_events as events
import aws_cdk.aws_events_targets as targets

# fn: lambda.Function


# Works with L2 Rule
events.Rule(scope, "Rule",
    event_pattern=AWSAPICallViaCloudTrail.event_pattern(
        tls_details=AWSAPICallViaCloudTrail.TlsDetails(tls_version=["TLSv1.3"]),
        event_metadata=AWSEventMetadataProps(region=["us-east-1"])
    ),
    targets=[targets.LambdaFunction(fn)]
)

# Also works with L1 CfnRule
events.CfnRule(scope, "CfnRule",
    state="ENABLED",
    event_pattern=AWSAPICallViaCloudTrail.event_pattern(
        tls_details=AWSAPICallViaCloudTrail.TlsDetails(tls_version=["TLSv1.3"]),
        event_metadata=AWSEventMetadataProps(region=["us-east-1"])
    ),
    targets=[events.CfnRule.TargetProperty(arn=fn.function_arn, id="L1")]
)
```

#### Event Pattern Features

```python
from aws_cdk.mixins_preview.aws_s3.events import AWSAPICallViaCloudTrail


# Matches CloudTrail API calls across ALL S3 buckets
pattern = AWSAPICallViaCloudTrail.event_pattern()
```

**Event Metadata Support**: Control EventBridge pattern metadata

```python
from aws_cdk import AWSEventMetadataProps
from aws_cdk.mixins_preview.aws_s3.events import AWSAPICallViaCloudTrail
import aws_cdk.aws_events as events


pattern = AWSAPICallViaCloudTrail.event_pattern(
    event_metadata=AWSEventMetadataProps(
        region=events.Match.prefix("us-"),
        version=["0"]
    )
)
```

### Available Events

Event patterns are generated for EventBridge events available in the AWS Event Schema Registry. Common examples:

**S3 Events**:

* `ObjectCreated.eventPattern()` - Object creation events
* `ObjectDeleted.eventPattern()` - Object deletion events
* `ObjectTagsAdded.eventPattern()` - Object tagging events
* `AWSAPICallViaCloudTrail.eventPattern()` - CloudTrail API calls

Import events from service-specific modules:

```python
# Resource-specific (filters to a specific bucket)
from aws_cdk.mixins_preview.aws_s3.events import BucketEvents

# Standalone (matches across all buckets)
from aws_cdk.mixins_preview.aws_s3.events import AWSAPICallViaCloudTrail, ObjectCreated, ObjectDeleted
```
