"""Releases prompts module"""

