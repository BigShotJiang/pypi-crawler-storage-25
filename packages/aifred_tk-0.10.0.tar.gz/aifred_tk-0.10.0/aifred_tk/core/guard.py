"""Guard file utilities for recording AI-assisted changes."""

from pathlib import Path


def resolve_guard_file_path(configured: str | None = None) -> Path:
    """Return the path of the AI-assisted guard file.

    Resolution order:

    1. ``configured`` when explicitly set (e.g. from ``aifred_tk.ai_assisted_guard_file``).
    2. ``.git/commit-temp/ai-assisted`` when a ``.git`` directory exists in the current
       working directory (standard git repository layout).
    3. ``.aifred-tk/ai-assisted`` as the fallback for non-git environments.

    :param configured: Explicit path override from settings, or ``None`` for auto-detection.
    :type configured: str | None
    :return: Resolved :class:`~pathlib.Path` for the guard file.
    :rtype: Path
    """
    if configured:
        return Path(configured)
    if Path(".git").is_dir():
        return Path(".git/commit-temp/ai-assisted")
    return Path(".aifred-tk/ai-assisted")


def append_model_to_guard_file(model_name: str, guard_file: Path) -> None:
    """Append *model_name* as a new line to *guard_file*, creating it if needed.

    :param model_name: Identifier of the LLM that made the change, e.g. ``"ollama/gemma4:e4b"``.
    :type model_name: str
    :param guard_file: Path to the guard file to append to.
    :type guard_file: Path
    """
    guard_file.parent.mkdir(parents=True, exist_ok=True)
    with guard_file.open("a", encoding="utf-8") as fh:
        fh.write(model_name + "\n")
