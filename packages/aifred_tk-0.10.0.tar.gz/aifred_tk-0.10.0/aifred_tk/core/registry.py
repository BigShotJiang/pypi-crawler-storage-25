"""Plugin registry — the microkernel responsible for plugin lifecycle."""

import sys
from collections.abc import Callable
from importlib.metadata import EntryPoint, entry_points
from typing import Any

from dynaconf import Dynaconf
from loguru import logger

from aifred_tk.core.interfaces import Plugin, Tool
from aifred_tk.core.models import PluginLoadError, PluginNotFoundError, ToolNotFoundError

_ENTRY_POINT_GROUP = "aifred_tk.plugins"

PluginFactory = Callable[[Dynaconf], Plugin]


def _is_tool_enabled(settings: Dynaconf, tool_id: str) -> bool:
    """Return ``True`` when the tool is enabled in settings.

    Defaults to ``True`` when no explicit configuration is present.
    Uses dynaconf's double-underscore nested key syntax for safe access.

    :param settings: Active dynaconf settings instance.
    :type settings: Dynaconf
    :param tool_id: Tool identifier to look up.
    :type tool_id: str
    :return: Whether the tool should be exposed.
    :rtype: bool
    """
    try:
        key = f"TOOLS__{tool_id.upper()}__ENABLED"
        value: Any = settings.get(key, True)
        return bool(value)
    except Exception:
        return True


class PluginRegistry:
    """Microkernel registry that discovers, loads, and provides access to plugins.

    Usage::

        registry = PluginRegistry(settings)
        registry.load_plugins()
        tool = registry.get_tool("my_tool")
        result = tool.execute(tool.args_schema(message="hi"))
    """

    def __init__(self, settings: Dynaconf) -> None:
        """Initialise the registry with the active settings.

        :param settings: Active dynaconf settings instance.
        :type settings: Dynaconf
        """
        self._settings = settings
        self._plugins: dict[str, Plugin] = {}
        self._tools: dict[str, Tool] = {}

    def load_plugins(self) -> None:
        """Discover and load all plugins registered in the entry point group.

        Each entry point is expected to point to a factory callable with the
        signature ``create_plugin(settings: Dynaconf) -> Plugin``.

        Plugins that fail to load are logged as warnings and skipped; a single
        broken plugin does not prevent others from loading.
        """
        eps: list[EntryPoint] = list(entry_points(group=_ENTRY_POINT_GROUP))
        logger.debug("Discovered {} entry point(s) in group {!r}", len(eps), _ENTRY_POINT_GROUP)

        for ep in eps:
            self._load_entry_point(ep)

    def _load_entry_point(self, ep: EntryPoint) -> None:
        """Load a single entry point, registering its plugin and tools.

        :param ep: The entry point to load.
        :type ep: EntryPoint
        """
        try:
            factory: PluginFactory = ep.load()
            plugin: Plugin = factory(self._settings)
        except Exception as exc:
            err = PluginLoadError(ep.name, exc)
            logger.warning("Skipping plugin {!r}: {}", ep.name, err)
            print(f"[aifred-tk] warning: plugin {ep.name!r} failed to load: {err}", file=sys.stderr)
            return

        self._plugins[plugin.plugin_id] = plugin
        logger.debug("Loaded plugin {!r} ({})", plugin.plugin_id, plugin.name)

        for tool in plugin.get_tools():
            if _is_tool_enabled(self._settings, tool.tool_id):
                self._tools[tool.tool_id] = tool
                logger.debug("Registered tool {!r}", tool.tool_id)
            else:
                logger.debug("Tool {!r} is disabled — skipping", tool.tool_id)

    def get_all_tools(self) -> dict[str, Tool]:
        """Return all enabled tools indexed by tool ID.

        :return: Mapping of ``tool_id`` to :class:`~aifred_tk.core.interfaces.Tool`.
        :rtype: dict[str, Tool]
        """
        return dict(self._tools)

    def get_tool(self, tool_id: str) -> Tool:
        """Return a single enabled tool by its identifier.

        :param tool_id: The tool identifier to look up.
        :type tool_id: str
        :return: The matching :class:`~aifred_tk.core.interfaces.Tool` instance.
        :rtype: Tool
        :raises ToolNotFoundError: When the tool ID is unknown or disabled.
        """
        try:
            return self._tools[tool_id]
        except KeyError:
            raise ToolNotFoundError(tool_id) from None

    def get_plugin(self, plugin_id: str) -> Plugin:
        """Return a plugin by its identifier.

        :param plugin_id: The plugin identifier to look up.
        :type plugin_id: str
        :return: The matching :class:`~aifred_tk.core.interfaces.Plugin` instance.
        :rtype: Plugin
        :raises PluginNotFoundError: When the plugin ID is unknown.
        """
        try:
            return self._plugins[plugin_id]
        except KeyError:
            raise PluginNotFoundError(plugin_id) from None
