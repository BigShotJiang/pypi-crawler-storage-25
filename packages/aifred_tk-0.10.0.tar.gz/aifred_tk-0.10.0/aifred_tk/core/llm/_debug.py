"""Debug-aware agent runner and model-request hooks that trace LLM interactions via loguru."""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, Generic, TypeVar

from loguru import logger
from pydantic_ai.agent import AgentRunResult
from pydantic_ai.capabilities.hooks import Hooks
from pydantic_ai.messages import ModelMessage, ModelMessagesTypeAdapter, ModelResponse, UserContent
from pydantic_ai.models import ModelRequestContext
from pydantic_ai.tools import RunContext

from ._fallback import AgentRunner

_T = TypeVar("_T")


class DebugAgentRunner(Generic[_T]):
    """Agent runner wrapper that emits DEBUG-level traces for every LLM interaction.

    Wraps any :class:`~._fallback.AgentRunner` and emits :mod:`loguru` DEBUG
    messages for:

    - Agent initialisation — ``tool_id``, ``model_descriptor``, ``system_prompt``.
    - Each call — ``tool_id``, ``model_descriptor``, ``user_prompt``.
    - Each response — ``tool_id``, ``model_descriptor``, ``output``, ``usage``.

    Satisfies the :class:`~._fallback.AgentRunner` protocol and is transparent to
    callers; all arguments and return values are forwarded unchanged.

    :param inner: The underlying agent runner to delegate to.
    :type inner: AgentRunner[_T]
    :param tool_id: Snake-case tool identifier used as log context.
    :type tool_id: str
    :param model_descriptor: Human-readable model identifier (e.g. ``"openai/gpt-4o-mini"``).
    :type model_descriptor: str
    :param system_prompt: System prompt passed to the underlying agent.
    :type system_prompt: str
    """

    def __init__(
        self,
        inner: AgentRunner[_T],
        *,
        tool_id: str,
        model_descriptor: str,
        system_prompt: str,
    ) -> None:
        self._inner = inner
        self._tool_id = tool_id
        self._model_descriptor = model_descriptor
        logger.debug(
            "llm_init | tool={} model={} system_prompt={}",
            tool_id,
            model_descriptor,
            system_prompt,
        )

    def run_sync(
        self,
        user_prompt: str | Sequence[UserContent] | None = None,
        *,
        message_history: Sequence[ModelMessage] | None = None,
        **kwargs: Any,
    ) -> AgentRunResult[_T]:
        """Run the agent synchronously, tracing the call and response.

        :param user_prompt: User prompt text or content sequence.
        :param message_history: Prior conversation messages.
        :return: Agent run result forwarded from the inner runner.
        :rtype: AgentRunResult[_T]
        """
        logger.debug(
            "llm_call | tool={} model={} user_prompt={}",
            self._tool_id,
            self._model_descriptor,
            user_prompt,
        )
        result = self._inner.run_sync(user_prompt, message_history=message_history, **kwargs)
        logger.debug(
            "llm_response | tool={} model={} output={} usage={}",
            self._tool_id,
            self._model_descriptor,
            result.output,
            result.usage(),
        )
        return result

    async def run(
        self,
        user_prompt: str | Sequence[UserContent] | None = None,
        *,
        message_history: Sequence[ModelMessage] | None = None,
        **kwargs: Any,
    ) -> AgentRunResult[_T]:
        """Run the agent asynchronously, tracing the call and response.

        :param user_prompt: User prompt text or content sequence.
        :param message_history: Prior conversation messages.
        :return: Agent run result forwarded from the inner runner.
        :rtype: AgentRunResult[_T]
        """
        logger.debug(
            "llm_call | tool={} model={} user_prompt={}",
            self._tool_id,
            self._model_descriptor,
            user_prompt,
        )
        result = await self._inner.run(user_prompt, message_history=message_history, **kwargs)
        logger.debug(
            "llm_response | tool={} model={} output={} usage={}",
            self._tool_id,
            self._model_descriptor,
            result.output,
            result.usage(),
        )
        return result


def _make_debug_hooks(tool_id: str) -> Hooks:
    """Return a :class:`~pydantic_ai.capabilities.hooks.Hooks` instance that traces model payloads.

    Registers two hooks on the returned instance:

    - ``before_model_request`` — logs the full message array, output schema (as
      ``ToolDefinition.parameters_json_schema``), and output mode at DEBUG level.
    - ``after_model_request`` — logs the raw model response parts, model name, and
      finish reason at DEBUG level.

    Pass the returned :class:`~pydantic_ai.capabilities.hooks.Hooks` object as an element
    of the ``capabilities`` list when constructing a :class:`~pydantic_ai.Agent`.

    :param tool_id: Snake-case tool identifier included in every log message for context.
    :type tool_id: str
    :return: Configured :class:`~pydantic_ai.capabilities.hooks.Hooks` instance.
    :rtype: Hooks
    """
    hooks: Hooks = Hooks()

    @hooks.on.before_model_request
    async def _before(
        ctx: RunContext[Any], request_context: ModelRequestContext
    ) -> ModelRequestContext:
        params = request_context.model_request_parameters
        output_schema = [
            {"name": t.name, "schema": t.parameters_json_schema} for t in params.output_tools
        ]
        messages_json = ModelMessagesTypeAdapter.dump_json(request_context.messages).decode()
        logger.debug(
            "llm_payload | tool={} output_mode={} output_schema={} messages={}",
            tool_id,
            params.output_mode,
            output_schema,
            messages_json,
        )
        return request_context

    @hooks.on.after_model_request
    async def _after(
        ctx: RunContext[Any],
        *,
        request_context: ModelRequestContext,
        response: ModelResponse,
    ) -> ModelResponse:
        logger.debug(
            "llm_model_response | tool={} model={} finish_reason={} parts={}",
            tool_id,
            response.model_name,
            response.finish_reason,
            response.parts,
        )
        return response

    return hooks
