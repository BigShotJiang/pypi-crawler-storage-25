"""LLM resolution and pydantic-ai model factory for the aifred-tk core."""

from __future__ import annotations

from typing import Any, TypeVar, cast

from dynaconf import Dynaconf
from loguru import logger
from pydantic import TypeAdapter
from pydantic_ai import Agent
from pydantic_ai.models import Model
from pydantic_ai.settings import ModelSettings

from aifred_tk.core.models import ConfigurationError

from ._config import (
    AnthropicLlmConfig,
    FallbackLlmConfig,
    GoogleLlmConfig,
    LlmConfig,
    LlmInlineSetting,
    LlmRefSetting,
    OllamaLlmConfig,
    OpenAICompatLlmConfig,
    OpenAILlmConfig,
    PluginLlmSetting,
)
from ._debug import DebugAgentRunner, _make_debug_hooks
from ._fallback import AgentRunner, FallbackAgent

_T = TypeVar("_T")


def resolve_llm(setting: PluginLlmSetting, registry: dict[str, LlmConfig]) -> LlmConfig:
    """Resolve a plugin LLM setting to a concrete :data:`LlmConfig`.

    :param setting: Either a reference to a named LLM or an inline definition.
    :type setting: PluginLlmSetting
    :param registry: Named LLM configs parsed from the top-level ``llms`` settings block.
    :type registry: dict[str, LlmConfig]
    :return: Resolved LLM configuration.
    :rtype: LlmConfig
    :raises ConfigurationError: When a ref target is not present in the registry.
    """
    if isinstance(setting, LlmRefSetting):
        if setting.ref not in registry:
            raise ConfigurationError(
                f"LLM reference {setting.ref!r} not found in llms config; "
                f"available: {sorted(registry)}"
            )
        return registry[setting.ref]
    return _inline_to_config(setting)


def _inline_to_config(setting: LlmInlineSetting) -> LlmConfig:
    """Convert an inline LLM setting to a concrete :data:`LlmConfig`.

    :param setting: Inline LLM definition with all provider-specific fields.
    :type setting: LlmInlineSetting
    :return: Provider-specific LLM config instance.
    :rtype: LlmConfig
    :raises ConfigurationError: When the provider value is not supported.
    """
    match setting.provider:
        case "ollama":
            return OllamaLlmConfig(
                model=setting.model,
                host=setting.host,
                port=setting.port,
                context_size=setting.context_size,
                response_size=setting.response_size,
            )
        case "openai":
            return OpenAILlmConfig(
                model=setting.model,
                api_key=setting.api_key,
                base_url=setting.base_url,
                context_size=setting.context_size,
                response_size=setting.response_size,
            )
        case "anthropic":
            return AnthropicLlmConfig(
                model=setting.model,
                api_key=setting.api_key,
                context_size=setting.context_size,
                response_size=setting.response_size,
            )
        case "openai-compatible":
            return OpenAICompatLlmConfig(
                model=setting.model,
                base_url=setting.base_url or "",
                api_key=setting.api_key,
                context_size=setting.context_size,
                response_size=setting.response_size,
            )
        case "google":
            return GoogleLlmConfig(
                model=setting.model,
                api_key=setting.api_key,
                context_size=setting.context_size,
                response_size=setting.response_size,
            )
        case _:
            raise ConfigurationError(f"Unsupported provider: {setting.provider!r}")


def build_pydantic_ai_model(config: LlmConfig) -> Model:
    """Return a pydantic-ai :class:`~pydantic_ai.models.Model` for the given LLM configuration.

    Provider mapping:

    - ``ollama`` — :class:`~pydantic_ai.models.openai.OpenAIChatModel` pointed at the Ollama
      OpenAI-compatible endpoint (``http://<host>:<port>/v1``).
    - ``openai`` — :class:`~pydantic_ai.models.openai.OpenAIChatModel` with optional key/URL
      overrides; falls back to the ``OPENAI_API_KEY`` environment variable.
    - ``anthropic`` — :class:`~pydantic_ai.models.anthropic.AnthropicModel`; falls back to
      ``ANTHROPIC_API_KEY`` when no key is set.
    - ``openai-compatible`` — :class:`~pydantic_ai.models.openai.OpenAIChatModel` with a custom
      base URL for any Chat Completions-compatible endpoint.
    - ``google`` — :class:`~pydantic_ai.models.google.GoogleModel`; falls back to
      ``GOOGLE_API_KEY`` or ``GEMINI_API_KEY`` when no key is set.

    :param config: LLM configuration specifying the provider and connection details.
    :type config: LlmConfig
    :return: Configured pydantic-ai Model ready for use in an :class:`~pydantic_ai.Agent`.
    :rtype: pydantic_ai.models.Model
    """
    if isinstance(config, FallbackLlmConfig):
        raise ConfigurationError(
            "FallbackLlmConfig cannot be converted to a pydantic-ai Model directly; "
            "use build_agent_from_settings to obtain a FallbackAgent instead."
        )
    match config:
        case OllamaLlmConfig():
            try:
                from pydantic_ai.models.openai import OpenAIChatModel
                from pydantic_ai.providers.openai import OpenAIProvider
            except ImportError as exc:
                raise ConfigurationError(
                    "The 'openai' package is required for the Ollama provider. "
                    "Install it with: pip install 'aifred-tk[openai]'"
                ) from exc
            return OpenAIChatModel(
                config.model,
                provider=OpenAIProvider(base_url=f"http://{config.host}:{config.port}/v1"),
            )
        case OpenAILlmConfig():
            try:
                from pydantic_ai.models.openai import OpenAIChatModel
                from pydantic_ai.providers.openai import OpenAIProvider
            except ImportError as exc:
                raise ConfigurationError(
                    "The 'openai' package is required for the OpenAI provider. "
                    "Install it with: pip install 'aifred-tk[openai]'"
                ) from exc
            return OpenAIChatModel(
                config.model,
                provider=OpenAIProvider(base_url=config.base_url, api_key=config.api_key),
            )
        case AnthropicLlmConfig():
            try:
                from pydantic_ai.models.anthropic import AnthropicModel
                from pydantic_ai.providers.anthropic import AnthropicProvider
            except ImportError as exc:
                raise ConfigurationError(
                    "The 'anthropic' package is required for the Anthropic provider. "
                    "Install it with: pip install 'aifred-tk[anthropic]'"
                ) from exc
            return AnthropicModel(
                config.model,
                provider=AnthropicProvider(api_key=config.api_key),
            )
        case OpenAICompatLlmConfig():
            try:
                from pydantic_ai.models.openai import OpenAIChatModel
                from pydantic_ai.providers.openai import OpenAIProvider
            except ImportError as exc:
                raise ConfigurationError(
                    "The 'openai' package is required for the OpenAI-compatible provider. "
                    "Install it with: pip install 'aifred-tk[openai]'"
                ) from exc
            return OpenAIChatModel(
                config.model,
                provider=OpenAIProvider(base_url=config.base_url, api_key=config.api_key),
            )
        case GoogleLlmConfig():
            try:
                from pydantic_ai.models.google import GoogleModel
                from pydantic_ai.providers.google import GoogleProvider
            except ImportError as exc:
                raise ConfigurationError(
                    "The 'google-generativeai' package is required for the Google provider. "
                    "Install it with: pip install 'aifred-tk[google]'"
                ) from exc
            return GoogleModel(
                config.model,
                provider=GoogleProvider(api_key=config.api_key),
            )
        case _:
            raise ConfigurationError(f"Unsupported provider: {config!r}")


def build_model_settings(config: LlmConfig) -> ModelSettings | None:
    """Map an :data:`LlmConfig` to a pydantic-ai :class:`~pydantic_ai.settings.ModelSettings`.

    Mapping rules:

    - ``response_size`` — translated to ``max_tokens`` for all providers.
    - ``context_size`` — provider-specific; no standard pydantic-ai mapping exists:

      - *Ollama*: the target parameter is ``num_ctx`` in the Ollama API, but
        pydantic-ai's :class:`~pydantic_ai.models.openai.OpenAIModel` does not expose it.
        A warning is emitted and the value is not enforced; configure it server-side or
        via a custom HTTP client.
      - *OpenAI / Anthropic / openai-compatible*: context window is model-inherent and
        cannot be overridden via the API; the value is logged at DEBUG level and ignored.

    :param config: Resolved LLM configuration.
    :type config: LlmConfig
    :return: Populated :class:`~pydantic_ai.settings.ModelSettings`, or ``None`` when no
        applicable fields are set.
    :rtype: ModelSettings | None
    """
    if isinstance(config, FallbackLlmConfig):
        return None

    if config.context_size is not None:
        if isinstance(config, OllamaLlmConfig):
            logger.warning(
                "context_size={} for Ollama model {!r} is not enforced: pydantic-ai's "
                "OpenAI-compatible model does not expose num_ctx; configure it server-side.",
                config.context_size,
                config.model,
            )
        else:
            logger.debug(
                "context_size={} for {} model {!r} is ignored: context window is "
                "model-inherent and not configurable via the API.",
                config.context_size,
                config.provider,
                config.model,
            )

    if config.response_size is None:
        return None
    return ModelSettings(max_tokens=config.response_size)


def resolve_tool_llm(tool_key: str, settings: Dynaconf, llm_subkey: str = "llm") -> LlmConfig:
    """Resolve the LLM configuration for a tool from aggregated Dynaconf settings.

    Reads the top-level ``llms`` registry and the ``tools.<tool_key>.<llm_subkey>`` entry
    from *settings*, then delegates to :func:`resolve_llm` to produce a concrete
    :data:`LlmConfig`.

    :param tool_key: Snake-case tool identifier matching the ``tools`` settings block
        (e.g. ``"commit"``, ``"analyze_file"``).
    :type tool_key: str
    :param settings: Active Dynaconf settings instance.
    :type settings: Dynaconf
    :param llm_subkey: Key within the tool's settings block that holds the LLM definition.
        Defaults to ``"llm"``.
    :type llm_subkey: str
    :return: Resolved LLM configuration.
    :rtype: LlmConfig
    :raises ConfigurationError: When the tool's LLM setting is absent or references an
        unknown name.
    """
    llms_data: dict[str, Any] = dict(settings.get("LLMS", {}) or {})
    registry: dict[str, LlmConfig] = (
        TypeAdapter(dict[str, LlmConfig]).validate_python(llms_data) if llms_data else {}
    )

    llm_raw = settings.get(f"TOOLS__{tool_key.upper()}__{llm_subkey.upper()}")
    if not llm_raw:
        raise ConfigurationError(
            f"Missing tools.{tool_key}.{llm_subkey} configuration; "
            "define an LLM reference or inline definition."
        )

    llm_setting: PluginLlmSetting = TypeAdapter(PluginLlmSetting).validate_python(dict(llm_raw))
    return resolve_llm(llm_setting, registry)


def _build_agent_from_config(
    config: LlmConfig,
    output_type: type[_T],
    system_prompt: str,
    *,
    debug: bool = False,
    tool_key: str = "",
) -> AgentRunner[_T]:
    """Recursively build an :class:`~._fallback.AgentRunner` from a resolved :data:`LlmConfig`.

    For :class:`~._config.FallbackLlmConfig`, builds primary and fallback runners
    recursively and wraps them in a :class:`~._fallback.FallbackAgent`.  For all other
    configs, constructs a plain pydantic-ai :class:`~pydantic_ai.Agent`.

    When *debug* is ``True``, each leaf agent is wrapped in a
    :class:`~._debug.DebugAgentRunner` that traces calls and responses at DEBUG level.
    Fallback agents are never wrapped directly — their inner runners are wrapped
    individually so traces identify the exact model that handled each call.

    :param config: Resolved LLM configuration.
    :type config: LlmConfig
    :param output_type: Expected output type for the agent.
    :type output_type: type[_T]
    :param system_prompt: System prompt string for the agent.
    :type system_prompt: str
    :param debug: When ``True``, wrap leaf agents in :class:`~._debug.DebugAgentRunner`.
    :type debug: bool
    :param tool_key: Tool identifier forwarded to :class:`~._debug.DebugAgentRunner` for
        log context.
    :type tool_key: str
    :return: Configured agent runner.
    :rtype: AgentRunner[_T]
    """
    if isinstance(config, FallbackLlmConfig):
        primary = _build_agent_from_config(
            config.primary, output_type, system_prompt, debug=debug, tool_key=tool_key
        )
        fallback = _build_agent_from_config(
            config.fallback, output_type, system_prompt, debug=debug, tool_key=tool_key
        )
        return FallbackAgent(primary, fallback)
    model = build_pydantic_ai_model(config)
    model_settings = build_model_settings(config)
    capabilities = [_make_debug_hooks(tool_key)] if debug else []
    runner: AgentRunner[_T] = cast(
        AgentRunner[_T],
        Agent(
            model,
            output_type=output_type,
            system_prompt=system_prompt,
            model_settings=model_settings,
            capabilities=capabilities,
        ),
    )
    if debug:
        return DebugAgentRunner(
            runner,
            tool_id=tool_key,
            model_descriptor=f"{config.provider}/{config.model}",
            system_prompt=system_prompt,
        )
    return runner


def build_agent_from_settings(
    tool_key: str,
    settings: Dynaconf,
    *,
    output_type: type[_T],
    system_prompt: str,
    llm_subkey: str = "llm",
) -> AgentRunner[_T]:
    """Build an agent runner from aggregated settings for a tool.

    Resolves the LLM configuration for *tool_key* and constructs either a plain
    pydantic-ai :class:`~pydantic_ai.Agent` or a :class:`~._fallback.FallbackAgent`
    chain when the resolved config is a :class:`~._config.FallbackLlmConfig`.

    :param tool_key: Snake-case tool identifier matching the ``tools`` settings block
        (e.g. ``"commit"``, ``"analyze_file"``).
    :type tool_key: str
    :param settings: Active Dynaconf settings instance.
    :type settings: Dynaconf
    :param output_type: Expected output type for the agent (passed as ``output_type`` to
        :class:`~pydantic_ai.Agent`).
    :type output_type: type[_T]
    :param system_prompt: System prompt string for the agent.
    :type system_prompt: str
    :param llm_subkey: Key within the tool's settings block that holds the LLM definition.
        Defaults to ``"llm"``.
    :type llm_subkey: str
    :return: Configured agent runner, either a plain :class:`~pydantic_ai.Agent` or a
        :class:`~._fallback.FallbackAgent` chain.
    :rtype: AgentRunner[_T]
    :raises ConfigurationError: When the tool's LLM setting is absent or references an
        unknown name.
    """
    debug = bool(settings.get("AIFRED_TK__DEBUG", False))
    config = resolve_tool_llm(tool_key, settings, llm_subkey)
    return _build_agent_from_config(
        config, output_type, system_prompt, debug=debug, tool_key=tool_key
    )
