"""File analysis plugin providing the ``analyze_file`` tool.

The tool reads a file from disk, submits its contents together with a user-supplied
analysis prompt to an LLM agent, and returns the analysis result. Both the analysis
prompt and the file contents are structurally isolated from the agent's instruction
layer to mitigate prompt injection attacks.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Literal, cast

from dynaconf import Dynaconf
from loguru import logger
from pydantic import Field

from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs, ToolResult
from aifred_tk.core.llm import AgentRunner, build_agent_from_settings, resolve_tool_llm
from aifred_tk.core.llm._config import llm_config_display_name
from aifred_tk.core.paths import FileAccessError, sanitize_file_path

from ._agent import FILE_ANALYSIS_SYSTEM_PROMPT
from ._marker import MarkTextTool
from ._semantic_analysis import SemanticCodeAnalysisTool

_TOOL_ID = "analyze_file"
_MAX_FILE_BYTES = 1_048_576


class FileAnalysisArgs(ToolArgs):
    """Arguments accepted by :class:`FileAnalysisTool`.

    :param file_path: Absolute or relative path to the file to analyse.
    :param prompt: Short natural-language description of the desired analysis (max 500 chars).
    :param output_file: Optional path to write the analysis result. When ``None`` the result
        is returned directly to the caller.
    :param output_format: Format used when *output_file* is set. ``"markdown"`` (default)
        writes only the analysis text; ``"json"`` writes the full result dict as indented JSON.
    """

    file_path: str = Field(description="Path to the file to analyse.")
    prompt: str = Field(
        max_length=500,
        description=(
            "Short description of the desired analysis "
            "(e.g., 'briefly describe the functions', 'list all organisation names'). "
            "Maximum 10000 characters."
        ),
    )
    output_file: str | None = Field(
        None,
        description="Optional path to write the analysis result. Defaults to returning inline.",
    )
    output_format: Literal["markdown", "json"] = Field(
        "markdown",
        description=(
            "Format used when writing to output_file. "
            "'markdown' (default) writes only the analysis text; "
            "'json' writes the full result as indented JSON."
        ),
    )


class FileAnalysisTool(Tool):
    """Reads a file and uses an LLM agent to produce an analysis based on a user prompt.

    Both the analysis prompt and the file contents are wrapped in XML-style isolation
    markers before being forwarded to the agent, preventing the file contents from
    acting as instructions (prompt injection).
    """

    def __init__(self, settings: Dynaconf) -> None:
        """Initialise with the active settings.

        The pydantic-ai agent is built lazily on first :meth:`execute` call so that
        plugin registration succeeds even when no API key is present in the environment.

        :param settings: Active Dynaconf settings instance.
        :type settings: Dynaconf
        """
        self._settings = settings
        self._agent: AgentRunner[str] | None = None

    def _get_agent(self) -> AgentRunner[str]:
        """Return the agent runner, building it on first call.

        :return: Configured file analysis agent runner.
        :rtype: AgentRunner[str]
        """
        if self._agent is None:
            self._agent = build_agent_from_settings(
                _TOOL_ID,
                self._settings,
                output_type=str,
                system_prompt=FILE_ANALYSIS_SYSTEM_PROMPT,
            )
        return self._agent

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"analyze_file"``
        :rtype: str
        """
        return _TOOL_ID

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "File Analysis"

    @property
    def description(self) -> str:
        """Return the tool description shown in CLI help and MCP metadata.

        :return: Description string.
        :rtype: str
        """
        return (
            "Reads a file and uses an AI agent to analyse its contents based on a short prompt. "
            "Examples: 'briefly describe the code functions', 'list all organisation names'. "
            "The analysis result is returned to the caller or written to an optional output file."
        )

    @property
    def readonly(self) -> bool:
        """Return ``False``: this tool may write to an output file.

        :rtype: bool
        """
        return False

    @property
    def args_schema(self) -> type[FileAnalysisArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`FileAnalysisArgs` class.
        :rtype: type[FileAnalysisArgs]
        """
        return FileAnalysisArgs

    def execute(self, args: ToolArgs) -> ToolResult:
        """Read the target file and return an LLM-generated analysis.

        Validates the file path and size, reads the contents, then submits both the
        analysis prompt and the file contents to the agent using XML isolation markers
        to prevent prompt injection. If *output_file* is set the result is persisted
        to disk; otherwise it is returned inline.

        :param args: Validated :class:`FileAnalysisArgs` instance.
        :type args: ToolArgs
        :return: A :class:`ToolResult` with a ``status`` key in output: ``"ok"``,
            ``"written"``, or ``"error"``.
        :rtype: ToolResult
        """
        analysis_args = cast(FileAnalysisArgs, args)

        try:
            file_path = sanitize_file_path(analysis_args.file_path)
        except FileAccessError as exc:
            logger.warning("File access denied: {}", exc)
            return ToolResult(output={"status": "error", "message": str(exc)})

        file_size = file_path.stat().st_size
        if file_size > _MAX_FILE_BYTES:
            logger.error("File exceeds size limit ({} bytes): {}", _MAX_FILE_BYTES, file_path)
            return ToolResult(
                output={
                    "status": "error",
                    "message": (
                        f"File exceeds the {_MAX_FILE_BYTES // 1_048_576} MB size limit "
                        f"({file_size} bytes)."
                    ),
                }
            )

        try:
            file_content = file_path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.error("Failed to read file {}: {}", file_path, exc)
            return ToolResult(output={"status": "error", "message": f"Failed to read file: {exc}"})

        user_message = (
            f"<analysis_request>\n{analysis_args.prompt}\n</analysis_request>\n\n"
            f"<file_content>\n{file_content}\n</file_content>"
        )

        logger.debug("Invoking file analysis agent for: {}", file_path)
        try:
            run_result = self._get_agent().run_sync(user_message)
        except Exception as exc:
            logger.error("Agent error while analysing {}: {}", file_path, exc)
            return ToolResult(output={"status": "error", "message": f"Agent error: {exc}"})

        analysis: str = run_result.output.strip()
        logger.info("File analysis complete for: {}", file_path)

        if analysis_args.output_file is not None:
            output_path = Path(analysis_args.output_file)
            output_dict: dict[str, Any] = {
                "status": "written",
                "output_file": str(output_path),
                "analysis": analysis,
            }
            content = (
                json.dumps(output_dict, indent=2)
                if analysis_args.output_format == "json"
                else analysis
            )
            try:
                output_path.write_text(content, encoding="utf-8")
            except OSError as exc:
                logger.error("Failed to write output file {}: {}", output_path, exc)
                return ToolResult(
                    output={"status": "error", "message": f"Failed to write output file: {exc}"}
                )
            try:
                llm_name: str | None = llm_config_display_name(
                    resolve_tool_llm(_TOOL_ID, self._settings)
                )
            except Exception:
                llm_name = None
            return ToolResult(output=output_dict, made_changes=True, llm_name=llm_name)

        return ToolResult(output={"status": "ok", "analysis": analysis})


class FileAnalysisPlugin(Plugin):
    """Plugin that provides :class:`FileAnalysisTool` and :class:`SemanticCodeAnalysisTool`."""

    def __init__(self, settings: Dynaconf) -> None:
        """Initialise with the active settings.

        :param settings: Active Dynaconf settings instance.
        :type settings: Dynaconf
        """
        self._settings = settings

    @property
    def plugin_id(self) -> str:
        """Return the unique plugin identifier.

        :return: ``"file_analysis"``
        :rtype: str
        """
        return "file_analysis"

    @property
    def name(self) -> str:
        """Return the human-readable plugin name.

        :return: Display name string.
        :rtype: str
        """
        return "File Analysis"

    def get_tools(self) -> list[Tool]:
        """Return all tools provided by this plugin.

        :return: List containing :class:`FileAnalysisTool` and :class:`SemanticCodeAnalysisTool`.
        :rtype: list[Tool]
        """
        return [
            FileAnalysisTool(self._settings),
            SemanticCodeAnalysisTool(self._settings),
            MarkTextTool(self._settings),
        ]


def create_plugin(settings: Dynaconf) -> FileAnalysisPlugin:
    """Entry point factory for the file_analysis plugin.

    :param settings: Active Dynaconf settings instance.
    :type settings: Dynaconf
    :return: Initialised :class:`FileAnalysisPlugin` instance.
    :rtype: FileAnalysisPlugin
    """
    return FileAnalysisPlugin(settings)
