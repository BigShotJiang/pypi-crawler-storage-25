"""Translation plugin providing the ``translate_text`` tool.

The tool accepts either an inline text string or a file path, translates the content to the
requested language using an LLM agent, and returns the translated text. Structural elements
such as URLs, file paths, markup tags, technology names, and code spans are preserved by default.
Both the source text and configuration values are structurally isolated from the agent's
instruction layer via XML markers to mitigate prompt injection attacks.
"""

from __future__ import annotations

from typing import cast

from dynaconf import Dynaconf
from loguru import logger
from pydantic import Field, model_validator

from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs, ToolResult
from aifred_tk.core.llm import AgentRunner, build_agent_from_settings
from aifred_tk.core.paths import FileAccessError, sanitize_file_path

from ._agent import TRANSLATION_SYSTEM_PROMPT

_TOOL_ID = "translate_text"
_MAX_FILE_BYTES = 1_048_576
_MAX_TEXT_CHARS = 100_000


class TranslateTextArgs(ToolArgs):
    """Arguments accepted by :class:`TranslateTextTool`.

    Exactly one of *text* or *file_path* must be provided.

    :param text: Inline text to translate. Maximum 100,000 characters.
    :param file_path: Path to a UTF-8 text file whose contents will be translated.
    :param target_language: Name of the target language (e.g. ``"Spanish"``, ``"French"``).
    :param context: Optional domain or style hint to guide terminology and register
        (e.g. ``"legal document"``, ``"informal chat"``). Maximum 500 characters.
    """

    text: str | None = Field(
        None,
        max_length=_MAX_TEXT_CHARS,
        description=(
            f"Inline text to translate. "
            f"Mutually exclusive with file_path. Maximum {_MAX_TEXT_CHARS:,} characters."
        ),
    )
    file_path: str | None = Field(
        None,
        description=(
            "Path to a UTF-8 text file whose contents will be translated. "
            "Mutually exclusive with text."
        ),
    )
    target_language: str = Field(
        ...,
        description="Name of the target language (e.g. 'Spanish', 'French', 'Japanese').",
    )
    context: str | None = Field(
        None,
        max_length=500,
        description=(
            "Optional domain or style hint to guide terminology and register "
            "(e.g. 'legal document', 'informal chat'). Maximum 500 characters."
        ),
    )

    @model_validator(mode="after")
    def _validate_text_or_file_path(self) -> TranslateTextArgs:
        """Enforce that exactly one of *text* or *file_path* is provided.

        :raises ValueError: When both or neither are supplied.
        :return: The validated model instance.
        :rtype: TranslateTextArgs
        """
        has_text = self.text is not None
        has_file = self.file_path is not None
        if has_text and has_file:
            raise ValueError("Provide either 'text' or 'file_path', not both.")
        if not has_text and not has_file:
            raise ValueError("One of 'text' or 'file_path' is required.")
        return self


class TranslateTextTool(Tool):
    """Translates text to a target language using an LLM agent.

    Accepts either inline text or a file path. Structural elements (URLs, paths, tags,
    technology names, code spans) are preserved by default. An optional context string
    guides domain-specific terminology. The source text is wrapped in XML isolation
    markers to prevent prompt injection.
    """

    def __init__(self, settings: Dynaconf) -> None:
        """Initialise with the active settings.

        The pydantic-ai agent is built lazily on first :meth:`execute` call so that
        plugin registration succeeds even when no API key is present in the environment.

        :param settings: Active Dynaconf settings instance.
        :type settings: Dynaconf
        """
        self._settings = settings
        self._agent: AgentRunner[str] | None = None

    def _get_agent(self) -> AgentRunner[str]:
        """Return the agent runner, building it on first call.

        :return: Configured translation agent runner.
        :rtype: AgentRunner[str]
        """
        if self._agent is None:
            self._agent = build_agent_from_settings(
                _TOOL_ID,
                self._settings,
                output_type=str,
                system_prompt=TRANSLATION_SYSTEM_PROMPT,
            )
        return self._agent

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"translate_text"``
        :rtype: str
        """
        return _TOOL_ID

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "Translate Text"

    @property
    def description(self) -> str:
        """Return the tool description shown in CLI help and MCP metadata.

        :return: Description string.
        :rtype: str
        """
        return (
            "Translates text to a target language using an AI agent. "
            "Accepts either an inline text string or a path to a UTF-8 text file. "
            "By default preserves URLs, file paths, markup tags (HTML/XML/Markdown), "
            "technology names, and text enclosed in backticks or code fences. "
            "An optional context string guides domain-specific terminology and register."
        )

    @property
    def args_schema(self) -> type[TranslateTextArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`TranslateTextArgs` class.
        :rtype: type[TranslateTextArgs]
        """
        return TranslateTextArgs

    def execute(self, args: ToolArgs) -> ToolResult:
        """Translate the provided text or file contents to the target language.

        Resolves inline text or reads the file, wraps the content in XML isolation
        markers, and submits to the agent. Returns the translated text or an error dict.

        :param args: Validated :class:`TranslateTextArgs` instance.
        :type args: ToolArgs
        :return: A :class:`ToolResult` with ``status="ok"`` and ``translation`` key on success,
            or ``status="error"`` and ``message`` key on failure.
        :rtype: ToolResult
        """
        translate_args = cast(TranslateTextArgs, args)

        if translate_args.file_path is not None:
            try:
                path = sanitize_file_path(translate_args.file_path)
            except FileAccessError as exc:
                logger.warning("File access denied: {}", exc)
                return ToolResult(output={"status": "error", "message": str(exc)})

            file_size = path.stat().st_size
            if file_size > _MAX_FILE_BYTES:
                logger.error("File exceeds size limit ({} bytes): {}", _MAX_FILE_BYTES, path)
                return ToolResult(
                    output={
                        "status": "error",
                        "message": (
                            f"File exceeds the {_MAX_FILE_BYTES // 1_048_576} MB size limit "
                            f"({file_size} bytes)."
                        ),
                    }
                )

            try:
                content = path.read_text(encoding="utf-8", errors="replace")
            except OSError as exc:
                logger.error("Failed to read file {}: {}", path, exc)
                return ToolResult(
                    output={"status": "error", "message": f"Failed to read file: {exc}"}
                )
        else:
            content = translate_args.text or ""

        user_message = (
            f"<text_to_translate>\n{content}\n</text_to_translate>\n\n"
            f"<target_language>{translate_args.target_language}</target_language>"
        )
        if translate_args.context is not None:
            user_message += (
                f"\n\n<translation_context>{translate_args.context}</translation_context>"
            )

        logger.debug(
            "Invoking translation agent, target language: {!r}",
            translate_args.target_language,
        )
        try:
            run_result = self._get_agent().run_sync(user_message)
        except Exception as exc:
            logger.error("Agent error during translation: {}", exc)
            return ToolResult(output={"status": "error", "message": f"Agent error: {exc}"})

        translation: str = run_result.output.strip()
        logger.info("Translation complete, target language: {!r}", translate_args.target_language)
        return ToolResult(output={"status": "ok", "translation": translation})


class TranslationPlugin(Plugin):
    """Plugin that provides :class:`TranslateTextTool`."""

    def __init__(self, settings: Dynaconf) -> None:
        """Initialise with the active settings.

        :param settings: Active Dynaconf settings instance.
        :type settings: Dynaconf
        """
        self._settings = settings

    @property
    def plugin_id(self) -> str:
        """Return the unique plugin identifier.

        :return: ``"translation"``
        :rtype: str
        """
        return "translation"

    @property
    def name(self) -> str:
        """Return the human-readable plugin name.

        :return: Display name string.
        :rtype: str
        """
        return "Translation"

    def get_tools(self) -> list[Tool]:
        """Return all tools provided by this plugin.

        :return: List containing :class:`TranslateTextTool`.
        :rtype: list[Tool]
        """
        return [TranslateTextTool(self._settings)]


def create_plugin(settings: Dynaconf) -> TranslationPlugin:
    """Entry point factory for the translation plugin.

    :param settings: Active Dynaconf settings instance.
    :type settings: Dynaconf
    :return: Initialised :class:`TranslationPlugin` instance.
    :rtype: TranslationPlugin
    """
    return TranslationPlugin(settings)
