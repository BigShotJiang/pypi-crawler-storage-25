"""Markdown frontmatter plugin providing the ``get_markdown_frontmatter`` tool.

The tool reads a Markdown file, extracts its frontmatter using the ``python-frontmatter``
library, and returns the metadata in the requested format. It respects ``.aiignore`` rules.
"""

from __future__ import annotations

import json
from typing import Any, Literal, cast

import frontmatter
import tomli_w
import yaml
from dynaconf import Dynaconf
from loguru import logger
from pydantic import Field

from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs, ToolResult
from aifred_tk.core.paths import FileAccessError, sanitize_file_path

_TOOL_ID = "get_markdown_frontmatter"
_MAX_FILE_BYTES = 1_048_576


class FrontmatterArgs(ToolArgs):
    """Arguments accepted by :class:`GetFrontmatterTool`.

    :param file_path: Path to the markdown file.
    :param output_format: Output format for the metadata.
        ``"json"`` (default), ``"yaml"``, ``"toml"`` or ``"dict"``.
    """

    file_path: str = Field(description="Path to the markdown file.")
    output_format: Literal["json", "yaml", "toml", "dict"] = Field(
        "json",
        description="Output format for the metadata: 'json', 'yaml', 'toml', or 'dict'.",
    )


class GetFrontmatterTool(Tool):
    """Extracts and parses the frontmatter from a Markdown file."""

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"get_markdown_frontmatter"``
        :rtype: str
        """
        return _TOOL_ID

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "Get Markdown Frontmatter"

    @property
    def description(self) -> str:
        """Return the tool description.

        :return: Description string.
        :rtype: str
        """
        return (
            "Extracts and parses frontmatter (YAML, TOML, or JSON) from a Markdown file. "
            "Returns the metadata in the specified format (JSON, YAML, TOML, or raw dictionary)."
        )

    @property
    def args_schema(self) -> type[FrontmatterArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`FrontmatterArgs` class.
        :rtype: type[FrontmatterArgs]
        """
        return FrontmatterArgs

    def execute(self, args: ToolArgs) -> ToolResult:
        """Read the target file and return the extracted frontmatter.

        Validates the file path, checks if it is ignored by ``.aiignore``, reads the
        frontmatter using ``python-frontmatter``, and formats the output.

        :param args: Validated :class:`FrontmatterArgs` instance.
        :type args: ToolArgs
        :return: A :class:`ToolResult` with status and frontmatter content.
        :rtype: ToolResult
        """
        fm_args = cast(FrontmatterArgs, args)
        try:
            file_path = sanitize_file_path(fm_args.file_path)
        except FileAccessError as exc:
            logger.warning("File access denied: {}", exc)
            return ToolResult(output={"status": "error", "message": str(exc)})

        file_size = file_path.stat().st_size
        if file_size > _MAX_FILE_BYTES:
            logger.error("File exceeds size limit ({} bytes): {}", _MAX_FILE_BYTES, file_path)
            return ToolResult(
                output={
                    "status": "error",
                    "message": f"File exceeds size limit ({_MAX_FILE_BYTES} bytes).",
                }
            )

        try:
            file_content = file_path.read_text(encoding="utf-8", errors="replace")
            handlers = [
                frontmatter.YAMLHandler(),
                frontmatter.TOMLHandler(),
                frontmatter.JSONHandler(),
            ]
            handler = frontmatter.detect_format(file_content, handlers)
            post = frontmatter.loads(file_content, handler=handler)
            metadata = post.metadata
        except Exception as exc:
            logger.error("Failed to parse frontmatter from {}: {}", file_path, exc)
            return ToolResult(
                output={"status": "error", "message": f"Failed to parse frontmatter: {exc}"}
            )

        if not metadata:
            logger.info("No frontmatter found in: {}", file_path)
            return ToolResult(
                output={"status": "ok", "frontmatter": None, "message": "No frontmatter found."}
            )

        output_format = fm_args.output_format
        try:
            if output_format == "json":
                content: Any = json.dumps(metadata, indent=2)
            elif output_format == "yaml":
                content = yaml.dump(metadata, sort_keys=False)
            elif output_format == "toml":
                content = tomli_w.dumps(metadata)
            else:
                content = metadata

            return ToolResult(output={"status": "ok", "frontmatter": content})
        except Exception as exc:
            logger.error("Failed to format output as {}: {}", output_format, exc)
            return ToolResult(
                output={"status": "error", "message": f"Failed to format output: {exc}"}
            )


class MarkdownFrontmatterPlugin(Plugin):
    """Plugin that provides the :class:`GetFrontmatterTool`."""

    @property
    def plugin_id(self) -> str:
        """Return the unique plugin identifier.

        :return: ``"markdown_frontmatter"``
        :rtype: str
        """
        return "markdown_frontmatter"

    @property
    def name(self) -> str:
        """Return the human-readable plugin name.

        :return: Display name string.
        :rtype: str
        """
        return "Markdown Frontmatter"

    def get_tools(self) -> list[Tool]:
        """Return all tools provided by this plugin.

        :return: List containing :class:`GetFrontmatterTool`.
        :rtype: list[Tool]
        """
        return [GetFrontmatterTool()]


def create_plugin(settings: Dynaconf) -> MarkdownFrontmatterPlugin:
    """Entry point factory for the markdown_frontmatter plugin.

    :param settings: Active Dynaconf settings instance (unused but required by interface).
    :type settings: Dynaconf
    :return: Initialised :class:`MarkdownFrontmatterPlugin` instance.
    :rtype: MarkdownFrontmatterPlugin
    """
    return MarkdownFrontmatterPlugin()
