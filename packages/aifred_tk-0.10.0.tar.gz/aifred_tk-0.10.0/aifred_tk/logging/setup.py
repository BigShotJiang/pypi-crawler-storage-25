"""Loguru sink configuration for CLI and MCP runtime modes."""

import sys
from datetime import datetime
from pathlib import Path
from typing import Literal

from dynaconf import Dynaconf
from loguru import logger


def setup_logging(
    mode: Literal["cli", "mcp"],
    settings: Dynaconf,
    tool_id: str = "general",
) -> None:
    """Configure loguru sinks based on the runtime mode.

    In ``cli`` mode stdout logging is suppressed entirely to avoid
    contaminating tool output consumed by agents. In ``mcp`` mode a
    coloured stdout sink is added alongside the file sinks.

    Log files are written to the directory specified by
    ``settings.aifred_tk.log_dir`` and named
    ``<tool_id>_<timestamp>.log`` (plain text) and
    ``<tool_id>_<timestamp>.log.jsonl`` (JSON lines).

    :param mode: Runtime mode — either ``"cli"`` or ``"mcp"``.
    :type mode: str
    :param settings: Active dynaconf settings instance.
    :type settings: Dynaconf
    :param tool_id: Identifier used in log file names; defaults to
        ``"general"`` when no specific tool context is available.
    :type tool_id: str
    """
    logger.remove()

    log_dir = Path(settings.aifred_tk.log_dir)
    log_dir.mkdir(parents=True, exist_ok=True)

    timestamp = datetime.now().strftime("%Y%m%dT%H%M%S")
    base = log_dir / f"{tool_id}_{timestamp}"
    debug: bool = bool(settings.get("AIFRED_TK__DEBUG", False))
    level: str = "DEBUG" if debug else settings.aifred_tk.log_level

    logger.add(
        str(base) + ".log",
        level=level,
        rotation=None,
        enqueue=True,
        format="{time} | {level} | {name}:{function}:{line} - {message}",
    )

    logger.add(
        str(base) + ".log.jsonl",
        level=level,
        serialize=True,
        enqueue=True,
    )

    if mode == "mcp":
        logger.add(
            sys.stderr,
            level=level,
            colorize=True,
            format="<green>{time:HH:mm:ss}</green> | <level>{level:<8}</level> | {message}",
        )
