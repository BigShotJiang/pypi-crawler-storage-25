"""Unit tests for the translation plugin."""

from contextlib import nullcontext
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from pydantic import ValidationError

from aifred_tk.core.models import ConfigurationError
from aifred_tk.core.paths import FileAccessError
from aifred_tk.plugins.translation.plugin import (
    TranslateTextArgs,
    TranslateTextTool,
    TranslationPlugin,
    create_plugin,
)


def _make_agent(translation: str = "Hola, mundo!") -> MagicMock:
    run_result = MagicMock()
    run_result.output = translation
    agent = MagicMock()
    agent.run_sync.return_value = run_result
    return agent


class TestTranslateTextArgs:
    """Pydantic schema validation for TranslateTextArgs."""

    @pytest.mark.parametrize(
        "kwargs, expected_error",
        [
            ({"text": "Hello", "target_language": "Spanish"}, nullcontext()),
            ({"file_path": "/some/file.txt", "target_language": "French"}, nullcontext()),
            (
                {"text": "Hello", "file_path": "/some/file.txt", "target_language": "Spanish"},
                pytest.raises(ValidationError),
            ),
            ({"target_language": "Spanish"}, pytest.raises(ValidationError)),
            ({"text": "x" * 100_000, "target_language": "Spanish"}, nullcontext()),
            ({"text": "x" * 100_001, "target_language": "Spanish"}, pytest.raises(ValidationError)),
            (
                {"text": "Hi", "target_language": "Spanish", "context": "x" * 500},
                nullcontext(),
            ),
            (
                {"text": "Hi", "target_language": "Spanish", "context": "x" * 501},
                pytest.raises(ValidationError),
            ),
            ({"text": "Hi"}, pytest.raises(ValidationError)),
        ],
    )
    def test_args_validation(self, kwargs: dict[str, Any], expected_error: Any) -> None:
        """TranslateTextArgs enforces mutual exclusivity, required fields, and length limits."""
        with expected_error:
            args = TranslateTextArgs(**kwargs)
            assert args.target_language


class TestTranslateTextToolMetadata:
    """Metadata properties of TranslateTextTool."""

    @pytest.fixture()
    def tool(self) -> TranslateTextTool:
        """Return a TranslateTextTool with a mock settings object."""
        return TranslateTextTool(MagicMock())

    def test_tool_id(self, tool: TranslateTextTool) -> None:
        """tool_id must be 'translate_text'."""
        assert tool.tool_id == "translate_text"

    def test_name(self, tool: TranslateTextTool) -> None:
        """name must be non-empty."""
        assert tool.name

    def test_description(self, tool: TranslateTextTool) -> None:
        """description must be non-empty."""
        assert tool.description

    def test_args_schema(self, tool: TranslateTextTool) -> None:
        """args_schema must return TranslateTextArgs class."""
        assert tool.args_schema is TranslateTextArgs


class TestTranslateTextToolExecute:
    """execute() behaviour of TranslateTextTool."""

    def _make_tool(self, translation: str = "Hola, mundo!") -> TranslateTextTool:
        tool = TranslateTextTool(MagicMock())
        tool._agent = _make_agent(translation)
        return tool

    def test_inline_text_returns_translation(self) -> None:
        """execute() with inline text returns status=ok and translation key."""
        tool = self._make_tool("Hola, mundo!")
        result = tool.execute(TranslateTextArgs(text="Hello, world!", target_language="Spanish"))
        assert result.output["status"] == "ok"
        assert result.output["translation"] == "Hola, mundo!"

    def test_xml_isolation_markers_present(self) -> None:
        """execute() wraps source text in <text_to_translate> XML isolation markers."""
        tool = self._make_tool()
        tool.execute(TranslateTextArgs(text="Hello!", target_language="Spanish"))
        call_arg: str = tool._agent.run_sync.call_args[0][0]
        assert "<text_to_translate>" in call_arg
        assert "</text_to_translate>" in call_arg
        assert "Hello!" in call_arg

    def test_target_language_tag_present(self) -> None:
        """execute() includes <target_language> tag in the agent message."""
        tool = self._make_tool()
        tool.execute(TranslateTextArgs(text="Hi", target_language="French"))
        call_arg: str = tool._agent.run_sync.call_args[0][0]
        assert "<target_language>French</target_language>" in call_arg

    def test_context_tag_present_when_provided(self) -> None:
        """execute() includes <translation_context> tag when context is provided."""
        tool = self._make_tool()
        tool.execute(
            TranslateTextArgs(text="Hi", target_language="German", context="technical manual")
        )
        call_arg: str = tool._agent.run_sync.call_args[0][0]
        assert "<translation_context>technical manual</translation_context>" in call_arg

    def test_context_tag_absent_when_not_provided(self) -> None:
        """execute() omits <translation_context> tag when no context is given."""
        tool = self._make_tool()
        tool.execute(TranslateTextArgs(text="Hi", target_language="German"))
        call_arg: str = tool._agent.run_sync.call_args[0][0]
        assert "<translation_context>" not in call_arg

    def test_file_path_reads_file_content(self, tmp_path: Path) -> None:
        """execute() with file_path reads the file and translates its contents."""
        source_file = tmp_path / "source.txt"
        source_file.write_text("Good morning", encoding="utf-8")
        tool = self._make_tool("Buenos días")
        with patch(
            "aifred_tk.plugins.translation.plugin.sanitize_file_path",
            return_value=source_file,
        ):
            result = tool.execute(
                TranslateTextArgs(file_path=str(source_file), target_language="Spanish")
            )
        assert result.output["status"] == "ok"
        assert result.output["translation"] == "Buenos días"
        call_arg: str = tool._agent.run_sync.call_args[0][0]
        assert "Good morning" in call_arg

    def test_file_access_error_returns_error(self) -> None:
        """execute() returns status=error when sanitize_file_path raises FileAccessError."""
        tool = self._make_tool()
        with patch(
            "aifred_tk.plugins.translation.plugin.sanitize_file_path",
            side_effect=FileAccessError("access denied"),
        ):
            result = tool.execute(
                TranslateTextArgs(file_path="/forbidden/file.txt", target_language="Spanish")
            )
        assert result.output["status"] == "error"
        assert "access denied" in result.output["message"]

    def test_file_read_os_error_returns_error(self, tmp_path: Path) -> None:
        """execute() returns status=error when reading the file raises OSError."""
        source_file = tmp_path / "source.txt"
        source_file.write_text("content", encoding="utf-8")
        tool = self._make_tool()
        mock_path = MagicMock()
        mock_path.stat.return_value.st_size = 100
        mock_path.read_text.side_effect = OSError("disk error")
        with patch(
            "aifred_tk.plugins.translation.plugin.sanitize_file_path",
            return_value=mock_path,
        ):
            result = tool.execute(
                TranslateTextArgs(file_path=str(source_file), target_language="Spanish")
            )
        assert result.output["status"] == "error"
        assert "disk error" in result.output["message"]

    def test_file_exceeds_size_limit_returns_error(self, tmp_path: Path) -> None:
        """execute() returns status=error when the file exceeds _MAX_FILE_BYTES."""
        source_file = tmp_path / "large.txt"
        source_file.write_text("x", encoding="utf-8")
        tool = self._make_tool()
        mock_path = MagicMock()
        mock_path.stat.return_value.st_size = 1_048_577
        with patch(
            "aifred_tk.plugins.translation.plugin.sanitize_file_path",
            return_value=mock_path,
        ):
            result = tool.execute(
                TranslateTextArgs(file_path=str(source_file), target_language="Spanish")
            )
        assert result.output["status"] == "error"
        assert "size limit" in result.output["message"]

    def test_agent_exception_returns_error(self) -> None:
        """execute() returns status=error when the agent raises an exception."""
        tool = TranslateTextTool(MagicMock())
        agent = MagicMock()
        agent.run_sync.side_effect = RuntimeError("LLM unavailable")
        tool._agent = agent
        result = tool.execute(TranslateTextArgs(text="Hello", target_language="Spanish"))
        assert result.output["status"] == "error"
        assert "agent error" in result.output["message"].lower()

    def test_translation_output_is_stripped(self) -> None:
        """execute() strips leading/trailing whitespace from the agent output."""
        tool = self._make_tool("  Hola  \n")
        result = tool.execute(TranslateTextArgs(text="Hello", target_language="Spanish"))
        assert result.output["translation"] == "Hola"


class TestTranslationPlugin:
    """Plugin metadata and tool enumeration for TranslationPlugin."""

    @pytest.fixture()
    def plugin(self) -> TranslationPlugin:
        """Return a TranslationPlugin with a mock settings object."""
        return TranslationPlugin(MagicMock())

    def test_plugin_id(self, plugin: TranslationPlugin) -> None:
        """plugin_id must be 'translation'."""
        assert plugin.plugin_id == "translation"

    def test_name(self, plugin: TranslationPlugin) -> None:
        """name must be non-empty."""
        assert plugin.name

    def test_get_tools_returns_one_tool(self, plugin: TranslationPlugin) -> None:
        """get_tools must return exactly one tool."""
        assert len(plugin.get_tools()) == 1

    def test_get_tools_tool_id(self, plugin: TranslationPlugin) -> None:
        """The single tool must have tool_id 'translate_text'."""
        assert plugin.get_tools()[0].tool_id == "translate_text"


class TestCreatePlugin:
    """Factory function create_plugin."""

    def test_returns_plugin_instance(self) -> None:
        """create_plugin returns a TranslationPlugin without eager validation."""
        plugin = create_plugin(MagicMock())
        assert isinstance(plugin, TranslationPlugin)

    def test_raises_when_llm_not_configured_on_agent_build(self) -> None:
        """ConfigurationError is raised on first _get_agent() call when llm is absent."""
        settings = MagicMock()
        settings.get.side_effect = lambda key, *args: {} if key == "LLMS" else None
        plugin = create_plugin(settings)
        tool = plugin.get_tools()[0]
        with pytest.raises(ConfigurationError):
            tool._get_agent()  # type: ignore[union-attr]
