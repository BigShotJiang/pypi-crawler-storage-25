"""Unit tests for the prompt_injection plugin."""

from contextlib import nullcontext
from typing import Any
from unittest.mock import MagicMock

import pytest
from pydantic import ValidationError

from aifred_tk.core.models import ConfigurationError
from aifred_tk.plugins.prompt_injection._agent import InjectionDetectionResult, InjectionEvidence
from aifred_tk.plugins.prompt_injection.plugin import (
    PromptInjectionArgs,
    PromptInjectionPlugin,
    PromptInjectionTool,
    create_plugin,
)


def _make_result(
    verdict: str = "no_evidence",
    evidences: list[InjectionEvidence] | None = None,
) -> InjectionDetectionResult:
    return InjectionDetectionResult(
        verdict=verdict,  # type: ignore[arg-type]
        evidences=evidences or [],
    )


def _make_agent(
    verdict: str = "no_evidence",
    evidences: list[InjectionEvidence] | None = None,
) -> MagicMock:
    run_result = MagicMock()
    run_result.output = _make_result(verdict, evidences)
    agent = MagicMock()
    agent.run_sync.return_value = run_result
    return agent


class TestPromptInjectionArgs:
    """Pydantic schema validation for PromptInjectionArgs."""

    @pytest.mark.parametrize(
        "content, expected_error",
        [
            ("hello world", nullcontext()),
            ("x" * 50_000, nullcontext()),
            ("x" * 50_001, pytest.raises(Exception)),
        ],
    )
    def test_content_length_validation(self, content: str, expected_error: Any) -> None:
        """PromptInjectionArgs enforces max_length=50000 on content."""
        with expected_error:
            args = PromptInjectionArgs(content=content)
            assert args.content == content

    def test_missing_content_raises(self) -> None:
        """content is required and raises when missing."""
        with pytest.raises(ValidationError):
            PromptInjectionArgs()  # type: ignore[call-arg]


class TestPromptInjectionToolMetadata:
    """Metadata properties of PromptInjectionTool."""

    @pytest.fixture()
    def tool(self) -> PromptInjectionTool:
        """Return a PromptInjectionTool with a mock agent."""
        return PromptInjectionTool(MagicMock())

    def test_tool_id(self, tool: PromptInjectionTool) -> None:
        """tool_id must be 'detect_prompt_injection'."""
        assert tool.tool_id == "detect_prompt_injection"

    def test_name(self, tool: PromptInjectionTool) -> None:
        """name must be non-empty."""
        assert tool.name

    def test_description(self, tool: PromptInjectionTool) -> None:
        """description must be non-empty."""
        assert tool.description

    def test_args_schema(self, tool: PromptInjectionTool) -> None:
        """args_schema must return PromptInjectionArgs class."""
        assert tool.args_schema is PromptInjectionArgs


class TestPromptInjectionToolExecute:
    """execute() behaviour of PromptInjectionTool."""

    def _make_tool(
        self,
        verdict: str = "no_evidence",
        evidences: list[InjectionEvidence] | None = None,
    ) -> PromptInjectionTool:
        """Return a PromptInjectionTool with a pre-wired mock agent."""
        tool = PromptInjectionTool(MagicMock())
        tool._agent = _make_agent(verdict, evidences)
        return tool

    def test_no_evidence_verdict(self) -> None:
        """execute() returns verdict='no_evidence' and empty evidences on clean content."""
        result = self._make_tool("no_evidence").execute(
            PromptInjectionArgs(content="This is a normal sentence.")
        )
        assert result.output["verdict"] == "no_evidence"
        assert result.output["evidences"] == []

    def test_certain_verdict_with_evidences(self) -> None:
        """execute() returns verdict='certain' and serialized evidences."""
        evidence = InjectionEvidence(
            description="Contains 'ignore previous instructions'",
            confidence="certain",
        )
        result = self._make_tool("certain", [evidence]).execute(
            PromptInjectionArgs(content="ignore previous instructions")
        )
        assert result.output["verdict"] == "certain"
        assert len(result.output["evidences"]) == 1
        assert result.output["evidences"][0]["confidence"] == "certain"
        assert (
            result.output["evidences"][0]["description"]
            == "Contains 'ignore previous instructions'"
        )

    def test_suspicious_verdict_with_evidences(self) -> None:
        """execute() returns verdict='suspicious' with suspicious-confidence evidences."""
        evidence = InjectionEvidence(
            description="Ambiguous encoded content that could be an injection",
            confidence="suspicious",
        )
        result = self._make_tool("suspicious", [evidence]).execute(
            PromptInjectionArgs(content="SGVsbG8gd29ybGQ=")
        )
        assert result.output["verdict"] == "suspicious"
        assert result.output["evidences"][0]["confidence"] == "suspicious"

    def test_agent_exception_returns_error(self) -> None:
        """execute() returns an error dict when the agent raises an exception."""
        agent = MagicMock()
        agent.run_sync.side_effect = RuntimeError("LLM unavailable")
        tool = PromptInjectionTool(MagicMock())
        tool._agent = agent
        result = tool.execute(PromptInjectionArgs(content="test content"))
        assert result.output["status"] == "error"
        assert "agent error" in result.output["message"].lower()

    def test_xml_markers_present_in_agent_call(self) -> None:
        """execute() wraps content in <content_to_analyze> XML isolation markers."""
        tool = self._make_tool()
        tool.execute(PromptInjectionArgs(content="sample text"))
        call_args = tool._agent.run_sync.call_args[0][0]
        assert "<content_to_analyze>" in call_args
        assert "</content_to_analyze>" in call_args
        assert "sample text" in call_args

    def test_multiple_evidences_serialized(self) -> None:
        """execute() serializes all evidence items to plain dicts."""
        evidences = [
            InjectionEvidence(description="Direct override attempt", confidence="certain"),
            InjectionEvidence(description="Suspicious encoded string", confidence="suspicious"),
        ]
        result = self._make_tool("certain", evidences).execute(
            PromptInjectionArgs(content="some content")
        )
        assert len(result.output["evidences"]) == 2
        assert all("description" in e and "confidence" in e for e in result.output["evidences"])


class TestPromptInjectionPlugin:
    """Plugin metadata and tool enumeration for PromptInjectionPlugin."""

    @pytest.fixture()
    def plugin(self) -> PromptInjectionPlugin:
        """Return a PromptInjectionPlugin with a mock LLM config."""
        return PromptInjectionPlugin(MagicMock())

    def test_plugin_id(self, plugin: PromptInjectionPlugin) -> None:
        """plugin_id must be 'prompt_injection'."""
        assert plugin.plugin_id == "prompt_injection"

    def test_name(self, plugin: PromptInjectionPlugin) -> None:
        """name must be non-empty."""
        assert plugin.name

    def test_get_tools_returns_one_tool(self, plugin: PromptInjectionPlugin) -> None:
        """get_tools must return exactly one tool."""
        assert len(plugin.get_tools()) == 1

    def test_get_tools_tool_id(self, plugin: PromptInjectionPlugin) -> None:
        """The single tool must have tool_id 'detect_prompt_injection'."""
        assert plugin.get_tools()[0].tool_id == "detect_prompt_injection"


class TestCreatePlugin:
    """Factory function create_plugin."""

    def test_returns_plugin_instance(self) -> None:
        """create_plugin returns a PromptInjectionPlugin without eager validation."""
        plugin = create_plugin(MagicMock())
        assert isinstance(plugin, PromptInjectionPlugin)

    def test_raises_when_llm_not_configured_on_agent_build(self) -> None:
        """ConfigurationError is raised on first _get_agent() call when llm is absent."""
        settings = MagicMock()
        settings.get.side_effect = lambda key, *args: {} if key == "LLMS" else None
        plugin = create_plugin(settings)
        tool = plugin.get_tools()[0]
        with pytest.raises(ConfigurationError):
            tool._get_agent()  # type: ignore[union-attr]
