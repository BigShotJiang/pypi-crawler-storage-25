"""Unit tests for the file_analysis plugin."""

from contextlib import nullcontext
from pathlib import Path
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from pydantic import ValidationError

from aifred_tk.core.models import ConfigurationError
from aifred_tk.plugins.file_analysis._fast_analysis import FastPathAnalysisResult, FastPathSymbol
from aifred_tk.plugins.file_analysis._lsp import _infer_container_names, _range_contains
from aifred_tk.plugins.file_analysis._marker import MarkTextArgs, MarkTextTool
from aifred_tk.plugins.file_analysis._semantic_analysis import (
    SemanticAnalysisReport,
    SemanticCodeAnalysisArgs,
    SemanticCodeAnalysisTool,
    SymbolRecord,
    _extract_doc,
    _filter_fast_path_symbols,
    _is_local_symbol,
    _nest_records,
    _render_markdown,
)
from aifred_tk.plugins.file_analysis._symbol_agent import SymbolAnalysisResult
from aifred_tk.plugins.file_analysis.plugin import (
    FileAnalysisArgs,
    FileAnalysisPlugin,
    FileAnalysisTool,
    create_plugin,
)


def _make_agent(output: str = "Analysis result.") -> MagicMock:
    run_result = MagicMock()
    run_result.output = output
    agent = MagicMock()
    agent.run_sync.return_value = run_result
    return agent


class TestFileAnalysisArgs:
    """Pydantic schema validation for FileAnalysisArgs."""

    @pytest.mark.parametrize(
        "file_path, prompt, output_file, expected_error",
        [
            ("/tmp/file.txt", "describe functions", None, nullcontext()),
            ("/tmp/file.txt", "describe functions", "/tmp/out.txt", nullcontext()),
            ("/tmp/file.txt", "x" * 500, None, nullcontext()),
            ("/tmp/file.txt", "x" * 501, None, pytest.raises(Exception)),
        ],
    )
    def test_validation(
        self,
        file_path: str,
        prompt: str,
        output_file: str | None,
        expected_error: Any,
    ) -> None:
        """FileAnalysisArgs validates field constraints correctly."""
        with expected_error:
            args = FileAnalysisArgs(file_path=file_path, prompt=prompt, output_file=output_file)
            assert args.file_path == file_path
            assert args.prompt == prompt
            assert args.output_file == output_file

    def test_output_file_defaults_to_none(self) -> None:
        """output_file must default to None when not provided."""
        args = FileAnalysisArgs(file_path="/tmp/f.txt", prompt="describe it")
        assert args.output_file is None

    def test_missing_file_path_raises(self) -> None:
        """file_path is required and raises when missing."""
        with pytest.raises(ValidationError):
            FileAnalysisArgs(prompt="describe it")  # type: ignore[call-arg]

    def test_missing_prompt_raises(self) -> None:
        """prompt is required and raises when missing."""
        with pytest.raises(ValidationError):
            FileAnalysisArgs(file_path="/tmp/f.txt")  # type: ignore[call-arg]


class TestFileAnalysisToolMetadata:
    """Metadata properties of FileAnalysisTool."""

    @pytest.fixture()
    def tool(self) -> FileAnalysisTool:
        """Return a FileAnalysisTool with mock settings."""
        return FileAnalysisTool(MagicMock())

    def test_tool_id(self, tool: FileAnalysisTool) -> None:
        """tool_id must be 'analyze_file'."""
        assert tool.tool_id == "analyze_file"

    def test_name(self, tool: FileAnalysisTool) -> None:
        """name must be non-empty."""
        assert tool.name

    def test_description(self, tool: FileAnalysisTool) -> None:
        """description must be non-empty."""
        assert tool.description

    def test_args_schema(self, tool: FileAnalysisTool) -> None:
        """args_schema must return FileAnalysisArgs class."""
        assert tool.args_schema is FileAnalysisArgs


class TestFileAnalysisToolExecute:
    """execute() behaviour of FileAnalysisTool."""

    def _make_tool(self, output: str = "Analysis result.") -> FileAnalysisTool:
        tool = FileAnalysisTool(MagicMock())
        tool._agent = _make_agent(output)
        return tool

    def test_file_not_found_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the file does not exist."""
        tool = self._make_tool()
        result = tool.execute(
            FileAnalysisArgs(file_path=str(tmp_path / "missing.txt"), prompt="describe it")
        )
        assert result.output["status"] == "error"
        assert "not found" in result.output["message"].lower()

    def test_path_is_directory_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the path points to a directory."""
        tool = self._make_tool()
        result = tool.execute(FileAnalysisArgs(file_path=str(tmp_path), prompt="describe it"))
        assert result.output["status"] == "error"
        assert "not a regular file" in result.output["message"].lower()

    def test_file_exceeds_size_limit_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the file exceeds 1 MB."""
        large_file = tmp_path / "big.txt"
        large_file.write_bytes(b"x" * (1_048_576 + 1))
        tool = self._make_tool()
        result = tool.execute(FileAnalysisArgs(file_path=str(large_file), prompt="describe it"))
        assert result.output["status"] == "error"
        assert "size limit" in result.output["message"].lower()

    def test_happy_path_returns_analysis(self, tmp_path: Path) -> None:
        """execute() returns status 'ok' and the analysis text on success."""
        target = tmp_path / "code.py"
        target.write_text("def hello(): pass\n", encoding="utf-8")
        tool = self._make_tool("Defines a hello function.")
        result = tool.execute(FileAnalysisArgs(file_path=str(target), prompt="describe functions"))
        assert result.output["status"] == "ok"
        assert result.output["analysis"] == "Defines a hello function."

    def test_happy_path_with_output_file(self, tmp_path: Path) -> None:
        """execute() writes to output_file and returns status 'written'."""
        target = tmp_path / "code.py"
        target.write_text("def hello(): pass\n", encoding="utf-8")
        out = tmp_path / "result.txt"
        tool = self._make_tool("Defines a hello function.")
        result = tool.execute(
            FileAnalysisArgs(
                file_path=str(target),
                prompt="describe functions",
                output_file=str(out),
            )
        )
        assert result.output["status"] == "written"
        assert result.output["analysis"] == "Defines a hello function."
        assert out.read_text(encoding="utf-8") == "Defines a hello function."

    def test_ignored_file_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the file is listed in .aiignore."""
        (tmp_path / ".aiignore").write_text("secret.txt\n", encoding="utf-8")
        target = tmp_path / "secret.txt"
        target.write_text("sensitive\n", encoding="utf-8")
        tool = self._make_tool()
        result = tool.execute(FileAnalysisArgs(file_path=str(target), prompt="describe it"))
        assert result.output["status"] == "error"
        assert "ignored" in result.output["message"].lower()

    def test_agent_not_called_for_ignored_file(self, tmp_path: Path) -> None:
        """execute() must not invoke the agent when the file is ignored."""
        (tmp_path / ".aiignore").write_text("secret.txt\n", encoding="utf-8")
        target = tmp_path / "secret.txt"
        target.write_text("sensitive\n", encoding="utf-8")
        agent = _make_agent()
        tool = FileAnalysisTool(MagicMock())
        tool._agent = agent
        tool.execute(FileAnalysisArgs(file_path=str(target), prompt="describe it"))
        agent.run_sync.assert_not_called()

    def test_agent_exception_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the agent raises an exception."""
        target = tmp_path / "code.py"
        target.write_text("content\n", encoding="utf-8")
        agent = MagicMock()
        agent.run_sync.side_effect = RuntimeError("LLM unavailable")
        tool = FileAnalysisTool(MagicMock())
        tool._agent = agent
        result = tool.execute(FileAnalysisArgs(file_path=str(target), prompt="describe it"))
        assert result.output["status"] == "error"
        assert "agent error" in result.output["message"].lower()

    def test_xml_markers_present_in_agent_call(self, tmp_path: Path) -> None:
        """execute() wraps prompt and file content in XML isolation markers."""
        target = tmp_path / "doc.txt"
        target.write_text("secret content\n", encoding="utf-8")
        agent = _make_agent()
        tool = FileAnalysisTool(MagicMock())
        tool._agent = agent
        tool.execute(FileAnalysisArgs(file_path=str(target), prompt="list names"))
        call_args = agent.run_sync.call_args[0][0]
        assert "<analysis_request>" in call_args
        assert "</analysis_request>" in call_args
        assert "<file_content>" in call_args
        assert "</file_content>" in call_args
        assert "list names" in call_args
        assert "secret content" in call_args

    def test_output_file_write_failure_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when writing the output file fails."""
        target = tmp_path / "code.py"
        target.write_text("content\n", encoding="utf-8")
        tool = self._make_tool()
        with patch(
            "aifred_tk.plugins.file_analysis.plugin.Path.write_text",
            side_effect=OSError("disk full"),
        ):
            result = tool.execute(
                FileAnalysisArgs(
                    file_path=str(target),
                    prompt="describe it",
                    output_file=str(tmp_path / "out.txt"),
                )
            )
        assert result.output["status"] == "error"
        assert "output file" in result.output["message"].lower()


class TestFileAnalysisPlugin:
    """Plugin metadata and tool enumeration for FileAnalysisPlugin."""

    @pytest.fixture()
    def plugin(self) -> FileAnalysisPlugin:
        """Return a FileAnalysisPlugin with mock settings."""
        return FileAnalysisPlugin(MagicMock())

    def test_plugin_id(self, plugin: FileAnalysisPlugin) -> None:
        """plugin_id must be 'file_analysis'."""
        assert plugin.plugin_id == "file_analysis"

    def test_name(self, plugin: FileAnalysisPlugin) -> None:
        """name must be non-empty."""
        assert plugin.name

    def test_get_tools_returns_three_tools(self, plugin: FileAnalysisPlugin) -> None:
        """get_tools must return three tools."""
        assert len(plugin.get_tools()) == 3

    def test_get_tools_tool_ids(self, plugin: FileAnalysisPlugin) -> None:
        """The tools must have the expected tool_ids."""
        ids = {t.tool_id for t in plugin.get_tools()}
        assert ids == {"analyze_file", "semantic_code_analysis", "mark_text"}


class TestCreatePlugin:
    """Factory function create_plugin."""

    def test_returns_plugin_instance(self) -> None:
        """create_plugin returns a FileAnalysisPlugin without eager validation."""
        plugin = create_plugin(MagicMock())
        assert isinstance(plugin, FileAnalysisPlugin)

    def test_raises_when_llm_not_configured_on_agent_build(self) -> None:
        """ConfigurationError is raised on first _get_agent() call when llm is absent."""
        settings = MagicMock()
        settings.get.side_effect = lambda key, *args: {} if key == "LLMS" else None
        plugin = create_plugin(settings)
        tool = plugin.get_tools()[0]
        with pytest.raises(ConfigurationError):
            tool._get_agent()  # type: ignore[union-attr]


def _make_record(fqn: str, start_line: int = 1, end_line: int = 10) -> SymbolRecord:
    return SymbolRecord(
        fqn=fqn,
        kind="Function",
        start_line=start_line,
        end_line=end_line,
        start_col=0,
        end_col=0,
        analysis="desc",
        issues=[],
    )


class TestNestRecords:
    """Unit tests for the _nest_records() helper."""

    def test_top_level_symbols_with_no_dot_remain_at_root(self) -> None:
        """Symbols without dots in their FQN must stay at the top level."""
        records = [_make_record("func_a"), _make_record("func_b", start_line=5)]
        top = _nest_records(records)
        assert [r.fqn for r in top] == ["func_a", "func_b"]
        assert all(r.children == [] for r in top)

    def test_child_nested_under_parent(self) -> None:
        """A symbol with FQN 'Parent.child' must appear in Parent.children."""
        parent = _make_record("MyClass", start_line=1)
        child = _make_record("MyClass.method", start_line=3)
        top = _nest_records([child, parent])
        assert [r.fqn for r in top] == ["MyClass"]
        assert [r.fqn for r in top[0].children] == ["MyClass.method"]

    def test_multiple_children_sorted_by_start_line(self) -> None:
        """Children must be sorted by start_line ascending."""
        parent = _make_record("Cls", start_line=1)
        m1 = _make_record("Cls.z_method", start_line=10)
        m2 = _make_record("Cls.a_method", start_line=5)
        top = _nest_records([m1, m2, parent])
        assert [r.fqn for r in top[0].children] == ["Cls.a_method", "Cls.z_method"]

    def test_top_level_sorted_by_start_line(self) -> None:
        """Top-level symbols must be sorted by start_line ascending."""
        r1 = _make_record("beta", start_line=20)
        r2 = _make_record("alpha", start_line=1)
        top = _nest_records([r1, r2])
        assert [r.fqn for r in top] == ["alpha", "beta"]

    def test_orphan_child_promoted_to_top_level(self) -> None:
        """A symbol whose parent FQN is absent must fall back to top-level."""
        orphan = _make_record("Missing.child", start_line=1)
        top = _nest_records([orphan])
        assert [r.fqn for r in top] == ["Missing.child"]

    def test_deeply_nested_symbols(self) -> None:
        """Three-level nesting: grandparent > parent > child."""
        gp = _make_record("Outer", start_line=1)
        p = _make_record("Outer.Inner", start_line=2)
        c = _make_record("Outer.Inner.method", start_line=3)
        top = _nest_records([c, p, gp])
        assert [r.fqn for r in top] == ["Outer"]
        assert [r.fqn for r in top[0].children] == ["Outer.Inner"]
        assert [r.fqn for r in top[0].children[0].children] == ["Outer.Inner.method"]


class TestRenderMarkdown:
    """Unit tests for _render_markdown() with nested symbols."""

    def _make_report(self, symbols: list[SymbolRecord]) -> SemanticAnalysisReport:
        return SemanticAnalysisReport(
            file_path="src/foo.py",
            language="python",
            analyzed_at="2026-01-01T00:00:00+00:00",
            symbols=symbols,
            issues=[],
        )

    def test_top_level_symbol_uses_h3(self) -> None:
        """Top-level symbols must use '###' headings."""
        report = self._make_report([_make_record("my_func")])
        md = _render_markdown(report)
        assert "### `my_func`" in md

    def test_child_symbol_uses_h4(self) -> None:
        """Direct children must use '####' headings."""
        parent = _make_record("MyClass")
        child = _make_record("MyClass.method")
        parent.children.append(child)
        md = _render_markdown(self._make_report([parent]))
        assert "### `MyClass`" in md
        assert "#### `MyClass.method`" in md

    def test_grandchild_uses_h5(self) -> None:
        """Grandchildren must use '#####' headings."""
        gp = _make_record("Outer")
        p = _make_record("Outer.Inner")
        c = _make_record("Outer.Inner.m")
        p.children.append(c)
        gp.children.append(p)
        md = _render_markdown(self._make_report([gp]))
        assert "##### `Outer.Inner.m`" in md


class TestExtractDoc:
    """Unit tests for _extract_doc()."""

    def test_python_class_docstring(self) -> None:
        """Returns the docstring for a Python class."""
        source = 'class Foo:\n    """Does something."""\n    pass\n'
        assert _extract_doc(source, "python") == "Does something."

    def test_python_function_docstring(self) -> None:
        """Returns the docstring for a Python function."""
        source = 'def bar():\n    """Bar does bar."""\n    return 1\n'
        assert _extract_doc(source, "python") == "Bar does bar."

    def test_python_no_docstring_returns_none(self) -> None:
        """Returns None when the Python symbol has no docstring."""
        source = "class Empty:\n    pass\n"
        assert _extract_doc(source, "python") is None

    def test_python_syntax_error_returns_none(self) -> None:
        """Returns None on unparseable source without raising."""
        assert _extract_doc("class :(", "python") is None

    def test_non_python_block_comment(self) -> None:
        """Returns a block doc comment for non-Python languages."""
        source = "/** Does something. */\nclass Foo {}"
        assert _extract_doc(source, "typescript") == "/** Does something. */"

    def test_non_python_triple_slash_comment(self) -> None:
        """Returns a /// line doc comment block for Rust-style languages."""
        source = "/// Does something.\n/// More detail.\nfn foo() {}"
        result = _extract_doc(source, "rust")
        assert result is not None
        assert "/// Does something." in result

    def test_non_python_no_doc_returns_none(self) -> None:
        """Returns None when no doc comment is present for non-Python."""
        source = "class Foo { int x; }"
        assert _extract_doc(source, "java") is None


def _make_lsp_symbol(
    name: str, container: str = "", start: int = 0, end: int = 5, kind: int = 12
) -> dict[str, Any]:
    return {
        "name": name,
        "containerName": container,
        "kind": kind,
        "range": {
            "start": {"line": start, "character": 0},
            "end": {"line": end, "character": 0},
        },
    }


def _make_sym_run_result(analysis: str = "desc") -> MagicMock:
    r = MagicMock()
    r.output = SymbolAnalysisResult(analysis=analysis, issues=[])
    return r


class TestSemanticCodeAnalysisArgs:
    """Pydantic schema validation for SemanticCodeAnalysisArgs."""

    def test_max_retries_default(self) -> None:
        """max_retries defaults to 3."""
        args = SemanticCodeAnalysisArgs(file_path="/tmp/f.py", language="python", prompt="describe")
        assert args.max_retries == 3

    def test_local_symbols_only_defaults_to_true(self) -> None:
        """local_symbols_only must default to True."""
        args = SemanticCodeAnalysisArgs(file_path="/tmp/f.py", language="python", prompt="describe")
        assert args.local_symbols_only is True

    @pytest.mark.parametrize(
        "value,ctx",
        [
            (1, nullcontext()),
            (10, nullcontext()),
            (0, pytest.raises(Exception)),
            (11, pytest.raises(Exception)),
        ],
    )
    def test_max_retries_bounds(self, value: int, ctx: Any) -> None:
        """max_retries must be between 1 and 10 inclusive."""
        with ctx:
            args = SemanticCodeAnalysisArgs(
                file_path="/tmp/f.py", language="python", prompt="desc", max_retries=value
            )
            assert args.max_retries == value

    def test_excluded_symbol_kinds_defaults_to_empty(self) -> None:
        """excluded_symbol_kinds must default to an empty list."""
        args = SemanticCodeAnalysisArgs(file_path="/tmp/f.py", language="python", prompt="desc")
        assert args.excluded_symbol_kinds == []


class TestIsLocalSymbol:
    """Unit tests for the _is_local_symbol() helper."""

    def _sym(self, location: dict[str, Any] | None) -> dict[str, Any]:
        sym: dict[str, Any] = {
            "name": "foo",
            "containerName": "",
            "kind": 12,
            "range": {"start": {"line": 0, "character": 0}, "end": {"line": 5, "character": 0}},
        }
        if location is not None:
            sym["location"] = location
        return sym

    def test_no_location_returns_true(self, tmp_path: Path) -> None:
        """Symbol without location field is treated as local."""
        target = tmp_path / "src.py"
        assert _is_local_symbol(self._sym(None), target) is True

    def test_absolute_path_matches_returns_true(self, tmp_path: Path) -> None:
        """Symbol with absolutePath matching file_path is local."""
        target = tmp_path / "src.py"
        sym = self._sym({"absolutePath": str(target), "uri": "", "relativePath": "src.py"})
        assert _is_local_symbol(sym, target) is True

    def test_absolute_path_differs_returns_false(self, tmp_path: Path) -> None:
        """Symbol with absolutePath pointing elsewhere is not local."""
        target = tmp_path / "src.py"
        sym = self._sym(
            {"absolutePath": str(tmp_path / "other.py"), "uri": "", "relativePath": "other.py"}
        )
        assert _is_local_symbol(sym, target) is False

    def test_uri_matches_returns_true(self, tmp_path: Path) -> None:
        """Symbol with matching file:// URI is local."""
        target = tmp_path / "src.py"
        sym = self._sym({"uri": target.as_uri(), "relativePath": "src.py"})
        assert _is_local_symbol(sym, target) is True

    def test_uri_differs_returns_false(self, tmp_path: Path) -> None:
        """Symbol with non-matching file:// URI is not local."""
        target = tmp_path / "src.py"
        sym = self._sym({"uri": (tmp_path / "other.py").as_uri(), "relativePath": "other.py"})
        assert _is_local_symbol(sym, target) is False

    def test_non_file_uri_returns_true(self, tmp_path: Path) -> None:
        """Symbol with non-file URI falls back to True (cannot determine)."""
        target = tmp_path / "src.py"
        sym = self._sym({"uri": "untitled:Untitled-1", "relativePath": ""})
        assert _is_local_symbol(sym, target) is True


class TestLocalSymbolFiltering:
    """Integration tests for local_symbols_only filtering in SemanticCodeAnalysisTool."""

    def _make_tool(self, agent: MagicMock) -> SemanticCodeAnalysisTool:
        tool = SemanticCodeAnalysisTool(MagicMock())
        tool._agent = agent
        return tool

    def _run(
        self,
        tool: SemanticCodeAnalysisTool,
        tmp_path: Path,
        *,
        symbols: list[dict[str, Any]],
        local_symbols_only: bool = True,
    ) -> dict[str, Any]:
        src = tmp_path / "src.py"
        src.write_text("def my_func(): pass\n", encoding="utf-8")
        with patch(
            "aifred_tk.plugins.file_analysis._semantic_analysis.extract_symbols",
            return_value=symbols,
        ):
            return tool.execute(
                SemanticCodeAnalysisArgs(
                    file_path=str(src),
                    language="python",
                    prompt="describe",
                    local_symbols_only=local_symbols_only,
                )
            )

    def _local_sym(self, tmp_path: Path, name: str) -> dict[str, Any]:
        src = tmp_path / "src.py"
        sym = _make_lsp_symbol(name)
        sym["location"] = {"absolutePath": str(src), "uri": src.as_uri(), "relativePath": "src.py"}
        return sym

    def _external_sym(self, tmp_path: Path, name: str) -> dict[str, Any]:
        other = tmp_path / "other.py"
        sym = _make_lsp_symbol(name)
        sym["location"] = {
            "absolutePath": str(other),
            "uri": other.as_uri(),
            "relativePath": "other.py",
        }
        return sym

    @pytest.mark.parametrize(
        ("local_symbols_only", "expect_external"),
        [
            (True, False),
            (False, True),
        ],
    )
    def test_local_symbols_only_filter(
        self,
        tmp_path: Path,
        local_symbols_only: bool,
        expect_external: bool,
    ) -> None:
        """local_symbols_only controls whether external symbols appear in the report."""
        agent = MagicMock()
        agent.run_sync.return_value = _make_sym_run_result("ok")
        tool = self._make_tool(agent)
        symbols = [
            self._local_sym(tmp_path, "local_func"),
            self._external_sym(tmp_path, "ext_func"),
        ]

        result = self._run(tool, tmp_path, symbols=symbols, local_symbols_only=local_symbols_only)

        assert result.output["status"] == "ok"
        fqns = [s["fqn"] for s in result.output["report"]["symbols"]]
        assert "local_func" in fqns
        assert ("ext_func" in fqns) == expect_external

    def test_symbol_without_location_always_included(self, tmp_path: Path) -> None:
        """Symbols without a location field pass the filter regardless of the flag."""
        agent = MagicMock()
        agent.run_sync.return_value = _make_sym_run_result("ok")
        tool = self._make_tool(agent)
        symbols = [_make_lsp_symbol("no_location_func")]

        result = self._run(tool, tmp_path, symbols=symbols, local_symbols_only=True)

        assert result.output["status"] == "ok"
        fqns = [s["fqn"] for s in result.output["report"]["symbols"]]
        assert "no_location_func" in fqns

    def test_all_filtered_returns_error(self, tmp_path: Path) -> None:
        """When all symbols are external and local_symbols_only=True, returns 'error'."""
        tool = self._make_tool(MagicMock())
        symbols = [self._external_sym(tmp_path, "ext_func")]

        result = self._run(tool, tmp_path, symbols=symbols, local_symbols_only=True)

        assert result.output["status"] == "error"


class TestExcludedSymbolKindsFiltering:
    """Tests for excluded_symbol_kinds filtering in both LSP and fast paths."""

    _LSP_FUNCTION_KIND = 12
    _LSP_PROPERTY_KIND = 7

    def _make_tool(self, agent: MagicMock) -> SemanticCodeAnalysisTool:
        tool = SemanticCodeAnalysisTool(MagicMock())
        tool._agent = agent
        return tool

    def _run_lsp(
        self,
        tool: SemanticCodeAnalysisTool,
        tmp_path: Path,
        symbols: list[dict[str, Any]],
        excluded_symbol_kinds: list[str],
    ) -> dict[str, Any]:
        src = tmp_path / "src.py"
        src.write_text("def my_func(): pass\n", encoding="utf-8")
        with patch(
            "aifred_tk.plugins.file_analysis._semantic_analysis.extract_symbols",
            return_value=symbols,
        ):
            return tool.execute(
                SemanticCodeAnalysisArgs(
                    file_path=str(src),
                    language="python",
                    prompt="describe",
                    excluded_symbol_kinds=excluded_symbol_kinds,
                )
            )

    @pytest.mark.parametrize(
        ("excluded", "expect_function", "expect_property"),
        [
            ([], True, True),
            (["Property"], True, False),
            (["property"], True, False),
        ],
    )
    def test_lsp_excluded_kinds_are_skipped(
        self,
        tmp_path: Path,
        excluded: list[str],
        expect_function: bool,
        expect_property: bool,
    ) -> None:
        """excluded_symbol_kinds removes matching symbols from LSP path analysis."""
        agent = MagicMock()
        agent.run_sync.return_value = _make_sym_run_result("ok")
        tool = self._make_tool(agent)
        symbols = [
            _make_lsp_symbol("my_func", kind=self._LSP_FUNCTION_KIND),
            _make_lsp_symbol("my_prop", kind=self._LSP_PROPERTY_KIND),
        ]

        result = self._run_lsp(tool, tmp_path, symbols, excluded)

        assert result.output["status"] == "ok"
        fqns = [s["fqn"] for s in result.output["report"]["symbols"]]
        assert ("my_func" in fqns) == expect_function
        assert ("my_prop" in fqns) == expect_property

    def test_lsp_all_excluded_returns_error(self, tmp_path: Path) -> None:
        """When all symbols match excluded_symbol_kinds, execute() returns 'error'."""
        tool = self._make_tool(MagicMock())
        symbols = [_make_lsp_symbol("my_func", kind=self._LSP_FUNCTION_KIND)]

        result = self._run_lsp(tool, tmp_path, symbols, excluded_symbol_kinds=["Function"])

        assert result.output["status"] == "error"

    def test_fast_path_excludes_top_level_symbol(self, tmp_path: Path) -> None:
        """excluded_symbol_kinds drops matching top-level symbols in the fast path."""
        src = tmp_path / "tiny.py"
        src.write_text("x = 1\n", encoding="utf-8")
        fast_result = FastPathAnalysisResult(
            symbols=[
                FastPathSymbol(
                    fqn="x", kind="Variable", start_line=1, end_line=1, analysis="x", issues=[]
                ),
                FastPathSymbol(
                    fqn="my_func",
                    kind="Function",
                    start_line=2,
                    end_line=5,
                    analysis="f",
                    issues=[],
                ),
            ]
        )
        tool = SemanticCodeAnalysisTool(MagicMock())
        fast_agent = MagicMock()
        fast_agent.run_sync.return_value = MagicMock(output=fast_result)
        tool._fast_agent = fast_agent

        result = tool.execute(
            SemanticCodeAnalysisArgs(
                file_path=str(src),
                language="python",
                prompt="describe",
                fast_path_max_bytes=1_000_000,
                excluded_symbol_kinds=["variable"],
            )
        )

        assert result.output["status"] == "ok"
        fqns = [s["fqn"] for s in result.output["report"]["symbols"]]
        assert "x" not in fqns
        assert "my_func" in fqns

    def test_fast_path_excludes_child_symbol_recursively(self, tmp_path: Path) -> None:
        """excluded_symbol_kinds is applied recursively to nested fast-path symbols."""
        src = tmp_path / "tiny.py"
        src.write_text("class C:\n    x = 1\n", encoding="utf-8")
        prop_child = FastPathSymbol(
            fqn="C.x", kind="Property", start_line=2, end_line=2, analysis="prop", issues=[]
        )
        fast_result = FastPathAnalysisResult(
            symbols=[
                FastPathSymbol(
                    fqn="C",
                    kind="Class",
                    start_line=1,
                    end_line=2,
                    analysis="class",
                    issues=[],
                    children=[prop_child],
                )
            ]
        )
        tool = SemanticCodeAnalysisTool(MagicMock())
        fast_agent = MagicMock()
        fast_agent.run_sync.return_value = MagicMock(output=fast_result)
        tool._fast_agent = fast_agent

        result = tool.execute(
            SemanticCodeAnalysisArgs(
                file_path=str(src),
                language="python",
                prompt="describe",
                fast_path_max_bytes=1_000_000,
                excluded_symbol_kinds=["Property"],
            )
        )

        assert result.output["status"] == "ok"
        top = result.output["report"]["symbols"]
        assert len(top) == 1
        assert top[0]["fqn"] == "C"
        assert top[0]["children"] == []


class TestFilterFastPathSymbols:
    """Unit tests for the _filter_fast_path_symbols helper."""

    def _sym(
        self, fqn: str, kind: str, children: list[FastPathSymbol] | None = None
    ) -> FastPathSymbol:
        return FastPathSymbol(
            fqn=fqn,
            kind=kind,
            start_line=1,
            end_line=1,
            analysis="",
            issues=[],
            children=children or [],
        )

    def test_empty_excluded_returns_all(self) -> None:
        """An empty excluded set passes all symbols unchanged."""
        syms = [self._sym("f", "Function"), self._sym("x", "Variable")]
        result = _filter_fast_path_symbols(syms, frozenset())
        assert [s.fqn for s in result] == ["f", "x"]

    def test_excludes_matching_kind(self) -> None:
        """Symbols whose kind (lowercased) is in excluded_kinds are removed."""
        syms = [self._sym("f", "Function"), self._sym("x", "variable")]
        result = _filter_fast_path_symbols(syms, frozenset(["variable"]))
        assert [s.fqn for s in result] == ["f"]

    def test_excludes_children_recursively(self) -> None:
        """Child symbols matching excluded_kinds are removed from the nested tree."""
        child = self._sym("C.prop", "Property")
        parent = self._sym("C", "Class", children=[child])
        result = _filter_fast_path_symbols([parent], frozenset(["property"]))
        assert len(result) == 1
        assert result[0].fqn == "C"
        assert result[0].children == []

    def test_excludes_parent_drops_entire_subtree(self) -> None:
        """When the parent is excluded, its subtree is also dropped."""
        child = self._sym("C.method", "Method")
        parent = self._sym("C", "Class", children=[child])
        result = _filter_fast_path_symbols([parent], frozenset(["class"]))
        assert result == []


class TestSemanticCodeAnalysisToolResilience:
    """Retry and error-continuation behaviour of SemanticCodeAnalysisTool."""

    def _make_tool(self, agent: MagicMock) -> SemanticCodeAnalysisTool:
        tool = SemanticCodeAnalysisTool(MagicMock())
        tool._agent = agent
        return tool

    def _run(
        self,
        tool: SemanticCodeAnalysisTool,
        tmp_path: Path,
        *,
        symbols: list[dict[str, Any]],
        max_retries: int = 3,
    ) -> dict[str, Any]:
        (tmp_path / "src.py").write_text("def my_func(): pass\n", encoding="utf-8")
        with patch(
            "aifred_tk.plugins.file_analysis._semantic_analysis.extract_symbols",
            return_value=symbols,
        ):
            return tool.execute(
                SemanticCodeAnalysisArgs(
                    file_path=str(tmp_path / "src.py"),
                    language="python",
                    prompt="describe",
                    max_retries=max_retries,
                )
            )

    def test_retry_succeeds_on_second_attempt(self, tmp_path: Path) -> None:
        """Symbol is recorded normally when the LLM fails once then succeeds."""
        run_result = _make_sym_run_result("ok on retry")
        agent = MagicMock()
        agent.run_sync.side_effect = [RuntimeError("timeout"), run_result]
        tool = self._make_tool(agent)

        result = self._run(tool, tmp_path, symbols=[_make_lsp_symbol("my_func")])

        assert result.output["status"] == "ok"
        assert result.output["report"]["errors"] == []
        assert len(result.output["report"]["symbols"]) == 1
        assert result.output["report"]["symbols"][0]["error"] is None
        assert result.output["report"]["symbols"][0]["analysis"] == "ok on retry"
        assert agent.run_sync.call_count == 2

    def test_all_retries_exhausted_records_error_and_returns_ok(self, tmp_path: Path) -> None:
        """Status is 'ok' with errors populated when all retries for a symbol are exhausted."""
        agent = MagicMock()
        agent.run_sync.side_effect = RuntimeError("always fails")
        tool = self._make_tool(agent)

        result = self._run(tool, tmp_path, symbols=[_make_lsp_symbol("my_func")], max_retries=2)

        assert result.output["status"] == "ok"
        report = result.output["report"]
        assert len(report["errors"]) == 1
        assert "my_func" in report["errors"][0]
        assert report["symbols"][0]["error"] is not None
        assert report["symbols"][0]["analysis"] == ""
        assert agent.run_sync.call_count == 2

    def test_partial_failure_continues_remaining_symbols(self, tmp_path: Path) -> None:
        """Analysis continues when the first symbol fails; second symbol is recorded normally."""
        run_result = _make_sym_run_result("second ok")
        agent = MagicMock()
        agent.run_sync.side_effect = [
            RuntimeError("first fails"),
            RuntimeError("first fails"),
            run_result,
        ]
        tool = self._make_tool(agent)
        symbols = [
            _make_lsp_symbol("first_func", start=0, end=3),
            _make_lsp_symbol("second_func", start=4, end=7),
        ]

        result = self._run(tool, tmp_path, symbols=symbols, max_retries=2)

        assert result.output["status"] == "ok"
        report = result.output["report"]
        assert len(report["symbols"]) == 2
        assert len(report["errors"]) == 1
        successful = next(s for s in report["symbols"] if s["error"] is None)
        assert successful["analysis"] == "second ok"


def _make_raw_sym(name: str, start_line: int, end_line: int, container: str = "") -> dict[str, Any]:
    sym: dict[str, Any] = {
        "name": name,
        "kind": 5,
        "range": {
            "start": {"line": start_line, "character": 0},
            "end": {"line": end_line, "character": 0},
        },
    }
    if container:
        sym["containerName"] = container
    return sym


class TestRangeContains:
    """Unit tests for the _range_contains() helper."""

    @pytest.mark.parametrize(
        "outer_start,outer_end,inner_start,inner_end,expected",
        [
            ((0, 0), (10, 0), (1, 0), (5, 0), True),
            ((0, 0), (10, 0), (0, 0), (10, 0), False),
            ((5, 0), (10, 0), (0, 0), (3, 0), False),
            ((0, 0), (5, 0), (3, 0), (8, 0), False),
            ((0, 0), (10, 0), (0, 0), (5, 0), True),
            ((0, 0), (10, 0), (5, 0), (10, 0), True),
        ],
    )
    def test_containment(
        self,
        outer_start: tuple[int, int],
        outer_end: tuple[int, int],
        inner_start: tuple[int, int],
        inner_end: tuple[int, int],
        expected: bool,
    ) -> None:
        """_range_contains returns the correct result for various range pairs."""
        outer = {
            "start": {"line": outer_start[0], "character": outer_start[1]},
            "end": {"line": outer_end[0], "character": outer_end[1]},
        }
        inner = {
            "start": {"line": inner_start[0], "character": inner_start[1]},
            "end": {"line": inner_end[0], "character": inner_end[1]},
        }
        assert _range_contains(outer, inner) is expected  # type: ignore[arg-type]


class TestInferContainerNames:
    """Unit tests for _infer_container_names()."""

    def test_flat_symbols_unchanged(self) -> None:
        """Symbols with non-overlapping ranges get no containerName."""
        syms = [
            _make_raw_sym("func_a", 0, 5),
            _make_raw_sym("func_b", 6, 10),
        ]
        _infer_container_names(syms)  # type: ignore[arg-type]
        assert syms[0].get("containerName", "") == ""
        assert syms[1].get("containerName", "") == ""

    def test_method_inside_class_gets_container_name(self) -> None:
        """A method whose range is inside a class gets containerName = class name."""
        syms = [
            _make_raw_sym("MyClass", 0, 20),
            _make_raw_sym("method", 5, 10),
        ]
        _infer_container_names(syms)  # type: ignore[arg-type]
        assert syms[1].get("containerName") == "MyClass"
        assert syms[0].get("containerName", "") == ""

    def test_deep_nesting_assigns_full_fqn(self) -> None:
        """A method inside an inner class gets containerName = 'Outer.Inner'."""
        syms = [
            _make_raw_sym("Outer", 0, 30),
            _make_raw_sym("Inner", 5, 25),
            _make_raw_sym("method", 10, 15),
        ]
        _infer_container_names(syms)  # type: ignore[arg-type]
        assert syms[1].get("containerName") == "Outer"
        assert syms[2].get("containerName") == "Outer.Inner"

    def test_existing_container_name_not_overwritten(self) -> None:
        """Symbols that already have containerName are left unchanged."""
        syms = [
            _make_raw_sym("MyClass", 0, 20),
            _make_raw_sym("method", 5, 10, container="PreExisting"),
        ]
        _infer_container_names(syms)  # type: ignore[arg-type]
        assert syms[1].get("containerName") == "PreExisting"

    def test_symbol_without_range_skipped(self) -> None:
        """Symbols missing the range field do not cause errors."""
        sym_no_range: dict[str, Any] = {"name": "bare", "kind": 12}
        sym_with_range = _make_raw_sym("container", 0, 20)
        _infer_container_names([sym_no_range, sym_with_range])  # type: ignore[arg-type]
        assert sym_no_range.get("containerName", "") == ""

    def test_empty_list_is_noop(self) -> None:
        """Calling with an empty list does not raise."""
        _infer_container_names([])  # type: ignore[arg-type]

    def test_all_have_container_name_is_noop(self) -> None:
        """Early-exit when all symbols already have containerName."""
        syms = [
            _make_raw_sym("MyClass", 0, 20),
            _make_raw_sym("method", 5, 10, container="MyClass"),
        ]
        _infer_container_names(syms)  # type: ignore[arg-type]
        assert syms[1].get("containerName") == "MyClass"


def _make_fast_path_result(
    fqn: str = "my_func",
    kind: str = "Function",
    start_line: int = 1,
    end_line: int = 5,
    analysis: str = "does something",
    issues: list[str] | None = None,
    children: list[FastPathSymbol] | None = None,
) -> FastPathAnalysisResult:
    sym = FastPathSymbol(
        fqn=fqn,
        kind=kind,
        start_line=start_line,
        end_line=end_line,
        analysis=analysis,
        issues=issues or [],
        children=children or [],
    )
    return FastPathAnalysisResult(symbols=[sym])


class TestSemanticCodeAnalysisToolFastPath:
    """Fast-path (bypass LSP) behaviour of SemanticCodeAnalysisTool."""

    def _make_tool(self, fast_result: FastPathAnalysisResult) -> SemanticCodeAnalysisTool:
        tool = SemanticCodeAnalysisTool(MagicMock())
        fast_agent = MagicMock()
        run = MagicMock()
        run.output = fast_result
        fast_agent.run_sync.return_value = run
        tool._fast_agent = fast_agent
        return tool

    def test_fast_path_returns_ok_report(self, tmp_path: Path) -> None:
        """execute() with fast_path_max_bytes > file size returns a valid report."""
        src = tmp_path / "tiny.py"
        src.write_text("def f(): pass\n", encoding="utf-8")
        tool = self._make_tool(_make_fast_path_result())

        result = tool.execute(
            SemanticCodeAnalysisArgs(
                file_path=str(src),
                language="python",
                prompt="describe",
                fast_path_max_bytes=1_000_000,
            )
        )

        assert result.output["status"] == "ok"
        report = result.output["report"]
        assert report["language"] == "python"
        assert len(report["symbols"]) == 1
        assert report["symbols"][0]["fqn"] == "my_func"
        assert report["symbols"][0]["start_col"] == 0
        assert report["symbols"][0]["end_col"] == 0
        assert report["symbols"][0]["error"] is None

    def test_fast_path_not_taken_when_disabled(self, tmp_path: Path) -> None:
        """With fast_path_max_bytes=0, the fast-path agent must never be called."""
        src = tmp_path / "tiny.py"
        src.write_text("def f(): pass\n", encoding="utf-8")
        tool = SemanticCodeAnalysisTool(MagicMock())
        fast_agent = MagicMock()
        tool._fast_agent = fast_agent

        with patch(
            "aifred_tk.plugins.file_analysis._semantic_analysis.extract_symbols",
            return_value=[_make_lsp_symbol("f")],
        ):
            tool._agent = MagicMock()
            tool._agent.run_sync.return_value = _make_sym_run_result("lsp result")
            result = tool.execute(
                SemanticCodeAnalysisArgs(
                    file_path=str(src),
                    language="python",
                    prompt="describe",
                    fast_path_max_bytes=0,
                )
            )

        fast_agent.run_sync.assert_not_called()
        assert result.output["status"] == "ok"

    def test_fast_path_not_taken_when_file_too_large(self, tmp_path: Path) -> None:
        """Fast path is skipped when file size >= fast_path_max_bytes."""
        src = tmp_path / "large.py"
        src.write_text("x" * 100, encoding="utf-8")
        tool = SemanticCodeAnalysisTool(MagicMock())
        fast_agent = MagicMock()
        tool._fast_agent = fast_agent

        with patch(
            "aifred_tk.plugins.file_analysis._semantic_analysis.extract_symbols",
            return_value=[_make_lsp_symbol("x")],
        ):
            tool._agent = MagicMock()
            tool._agent.run_sync.return_value = _make_sym_run_result("lsp result")
            result = tool.execute(
                SemanticCodeAnalysisArgs(
                    file_path=str(src),
                    language="python",
                    prompt="describe",
                    fast_path_max_bytes=50,
                )
            )

        fast_agent.run_sync.assert_not_called()
        assert result.output["status"] == "ok"

    def test_fast_path_deduplicates_issues_recursively(self, tmp_path: Path) -> None:
        """Issues from nested children are deduplicated in the top-level report."""
        src = tmp_path / "code.py"
        src.write_text("class C:\n    def m(self): pass\n", encoding="utf-8")
        child = FastPathSymbol(
            fqn="C.m",
            kind="Method",
            start_line=2,
            end_line=2,
            analysis="a method",
            issues=["shared issue", "child issue"],
        )
        result = _make_fast_path_result(
            fqn="C",
            kind="Class",
            start_line=1,
            end_line=2,
            analysis="a class",
            issues=["shared issue"],
            children=[child],
        )
        tool = self._make_tool(result)

        output = tool.execute(
            SemanticCodeAnalysisArgs(
                file_path=str(src),
                language="python",
                prompt="find issues",
                fast_path_max_bytes=1_000_000,
            )
        )

        report = output.output["report"]
        assert report["issues"].count("shared issue") == 1
        assert "child issue" in report["issues"]

    def test_fast_path_agent_failure_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the fast-path agent raises."""
        src = tmp_path / "code.py"
        src.write_text("def f(): pass\n", encoding="utf-8")
        tool = SemanticCodeAnalysisTool(MagicMock())
        fast_agent = MagicMock()
        fast_agent.run_sync.side_effect = RuntimeError("LLM unavailable")
        tool._fast_agent = fast_agent

        result = tool.execute(
            SemanticCodeAnalysisArgs(
                file_path=str(src),
                language="python",
                prompt="describe",
                fast_path_max_bytes=1_000_000,
            )
        )

        assert result.output["status"] == "error"
        assert "fast-path" in result.output["message"].lower()

    def test_fast_path_passes_xml_wrapped_content(self, tmp_path: Path) -> None:
        """Fast-path agent receives file content wrapped in XML isolation tags."""
        src = tmp_path / "code.py"
        src.write_text("SECRET_CONTENT\n", encoding="utf-8")
        tool = self._make_tool(_make_fast_path_result())

        tool.execute(
            SemanticCodeAnalysisArgs(
                file_path=str(src),
                language="python",
                prompt="my prompt",
                fast_path_max_bytes=1_000_000,
            )
        )

        call_msg = tool._fast_agent.run_sync.call_args[0][0]
        assert "<analysis_request>" in call_msg
        assert "my prompt" in call_msg
        assert "<source>" in call_msg
        assert "SECRET_CONTENT" in call_msg

    def test_fast_path_args_defaults(self) -> None:
        """fast_path_max_bytes defaults to 0 (disabled)."""
        args = SemanticCodeAnalysisArgs(file_path="/tmp/f.py", language="python", prompt="desc")
        assert args.fast_path_max_bytes == 0

    @pytest.mark.parametrize("value", [-1])
    def test_fast_path_max_bytes_rejects_negative(self, value: int) -> None:
        """fast_path_max_bytes must be >= 0."""
        with pytest.raises(ValidationError):
            SemanticCodeAnalysisArgs(
                file_path="/tmp/f.py", language="python", prompt="desc", fast_path_max_bytes=value
            )


class TestSemanticCodeAnalysisToolOutputFormat:
    """Inline output_format handling for SemanticCodeAnalysisTool (no output_file)."""

    def _make_tool(self, agent: MagicMock) -> SemanticCodeAnalysisTool:
        tool = SemanticCodeAnalysisTool(MagicMock())
        tool._agent = agent
        return tool

    def _run(
        self,
        tool: SemanticCodeAnalysisTool,
        tmp_path: Path,
        *,
        output_format: str = "json",
    ) -> dict[str, Any] | str:
        src = tmp_path / "src.py"
        src.write_text("def my_func(): pass\n", encoding="utf-8")
        with patch(
            "aifred_tk.plugins.file_analysis._semantic_analysis.extract_symbols",
            return_value=[_make_lsp_symbol("my_func")],
        ):
            return tool.execute(
                SemanticCodeAnalysisArgs(
                    file_path=str(src),
                    language="python",
                    prompt="describe",
                    output_format=output_format,  # type: ignore[arg-type]
                )
            )

    @pytest.mark.parametrize(
        "output_format,expected_type,starts_with",
        [
            ("json", dict, None),
            ("markdown", str, "# Semantic Analysis:"),
            ("yaml", str, "file_path:"),
        ],
    )
    def test_inline_output_format(
        self,
        tmp_path: Path,
        output_format: str,
        expected_type: type,
        starts_with: str | None,
    ) -> None:
        """execute() with no output_file returns dict for json, raw markdown str for markdown."""
        agent = MagicMock()
        agent.run_sync.return_value = _make_sym_run_result("does something")
        tool = self._make_tool(agent)

        result = self._run(tool, tmp_path, output_format=output_format)

        assert isinstance(result.output, expected_type)
        if starts_with is not None:
            assert isinstance(result.output, str)
            assert result.output.startswith(starts_with)


class TestMarkTextArgs:
    """Pydantic schema validation for MarkTextArgs."""

    @pytest.mark.parametrize(
        "text, file_path, expected_error",
        [
            ("hello", None, nullcontext()),
            (None, "/tmp/file.txt", nullcontext()),
            ("hello", "/tmp/file.txt", pytest.raises(ValidationError)),
            (None, None, pytest.raises(ValidationError)),
        ],
    )
    def test_text_or_file_path_exclusion(
        self,
        text: str | None,
        file_path: str | None,
        expected_error: Any,
    ) -> None:
        """Exactly one of text or file_path must be provided."""
        with expected_error:
            MarkTextArgs(text=text, file_path=file_path, instructions="mark nouns")

    def test_instructions_required(self) -> None:
        """instructions is a required field."""
        with pytest.raises(ValidationError):
            MarkTextArgs(text="hello")  # type: ignore[call-arg]

    @pytest.mark.parametrize(
        "length, expected_error",
        [
            (500, nullcontext()),
            (501, pytest.raises(ValidationError)),
        ],
    )
    def test_instructions_max_length(self, length: int, expected_error: Any) -> None:
        """instructions must not exceed 500 characters."""
        with expected_error:
            MarkTextArgs(text="hello", instructions="x" * length)

    @pytest.mark.parametrize(
        "length, expected_error",
        [
            (100_000, nullcontext()),
            (100_001, pytest.raises(ValidationError)),
        ],
    )
    def test_text_max_length(self, length: int, expected_error: Any) -> None:
        """text must not exceed 100,000 characters."""
        with expected_error:
            MarkTextArgs(text="x" * length, instructions="mark nouns")

    @pytest.mark.parametrize(
        "length, expected_error",
        [
            (500, nullcontext()),
            (501, pytest.raises(ValidationError)),
        ],
    )
    def test_context_max_length(self, length: int, expected_error: Any) -> None:
        """context must not exceed 500 characters."""
        with expected_error:
            MarkTextArgs(text="hello", instructions="mark nouns", context="x" * length)

    def test_context_defaults_to_none(self) -> None:
        """context must default to None when not provided."""
        args = MarkTextArgs(text="hello", instructions="mark nouns")
        assert args.context is None


class TestMarkTextToolMetadata:
    """Tool metadata for MarkTextTool."""

    @pytest.fixture()
    def tool(self) -> MarkTextTool:
        """Return a MarkTextTool with mock settings."""
        return MarkTextTool(MagicMock())

    def test_tool_id(self, tool: MarkTextTool) -> None:
        """tool_id must be 'mark_text'."""
        assert tool.tool_id == "mark_text"

    def test_name(self, tool: MarkTextTool) -> None:
        """name must be non-empty."""
        assert tool.name

    def test_description(self, tool: MarkTextTool) -> None:
        """description must be non-empty."""
        assert tool.description

    def test_args_schema(self, tool: MarkTextTool) -> None:
        """args_schema must be MarkTextArgs."""
        assert tool.args_schema is MarkTextArgs


class TestMarkTextToolExecute:
    """execute() behaviour of MarkTextTool."""

    def _make_tool(self, output: str = "<marked>result</marked>") -> MarkTextTool:
        tool = MarkTextTool(MagicMock())
        tool._agent = _make_agent(output)
        return tool

    def test_inline_text_happy_path(self) -> None:
        """execute() returns status 'ok' and marked_text for inline text input."""
        tool = self._make_tool("<technological>Python</technological> service")
        result = tool.execute(
            MarkTextArgs(
                text="Python service",
                instructions="mark technology terms as technological",
            )
        )
        assert result.output["status"] == "ok"
        assert "marked_text" in result.output

    def test_file_path_happy_path(self, tmp_path: Path) -> None:
        """execute() returns status 'ok' and marked_text when given a file path."""
        target = tmp_path / "doc.txt"
        target.write_text("Python service\n", encoding="utf-8")
        tool = self._make_tool("<technological>Python</technological> service")
        result = tool.execute(
            MarkTextArgs(
                file_path=str(target),
                instructions="mark technology terms as technological",
            )
        )
        assert result.output["status"] == "ok"
        assert "marked_text" in result.output

    def test_file_not_found_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the file does not exist."""
        tool = self._make_tool()
        result = tool.execute(
            MarkTextArgs(file_path=str(tmp_path / "missing.txt"), instructions="mark nouns")
        )
        assert result.output["status"] == "error"
        assert "not found" in result.output["message"].lower()

    def test_file_is_directory_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the path points to a directory."""
        tool = self._make_tool()
        result = tool.execute(MarkTextArgs(file_path=str(tmp_path), instructions="mark nouns"))
        assert result.output["status"] == "error"
        assert "not a regular file" in result.output["message"].lower()

    def test_file_exceeds_size_limit_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the file exceeds 1 MB."""
        large_file = tmp_path / "big.txt"
        large_file.write_bytes(b"x" * (1_048_576 + 1))
        tool = self._make_tool()
        result = tool.execute(MarkTextArgs(file_path=str(large_file), instructions="mark nouns"))
        assert result.output["status"] == "error"
        assert "size limit" in result.output["message"].lower()

    def test_ignored_file_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the file is listed in .aiignore."""
        (tmp_path / ".aiignore").write_text("secret.txt\n", encoding="utf-8")
        target = tmp_path / "secret.txt"
        target.write_text("sensitive\n", encoding="utf-8")
        tool = self._make_tool()
        result = tool.execute(MarkTextArgs(file_path=str(target), instructions="mark nouns"))
        assert result.output["status"] == "error"
        assert "ignored" in result.output["message"].lower()

    def test_agent_not_called_for_ignored_file(self, tmp_path: Path) -> None:
        """execute() must not invoke the agent when the file is ignored."""
        (tmp_path / ".aiignore").write_text("secret.txt\n", encoding="utf-8")
        target = tmp_path / "secret.txt"
        target.write_text("sensitive\n", encoding="utf-8")
        agent = _make_agent()
        tool = MarkTextTool(MagicMock())
        tool._agent = agent
        tool.execute(MarkTextArgs(file_path=str(target), instructions="mark nouns"))
        agent.run_sync.assert_not_called()

    def test_agent_exception_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when the agent raises an exception."""
        target = tmp_path / "doc.txt"
        target.write_text("content\n", encoding="utf-8")
        agent = MagicMock()
        agent.run_sync.side_effect = RuntimeError("LLM unavailable")
        tool = MarkTextTool(MagicMock())
        tool._agent = agent
        result = tool.execute(MarkTextArgs(file_path=str(target), instructions="mark nouns"))
        assert result.output["status"] == "error"
        assert "agent error" in result.output["message"].lower()

    def test_xml_markers_present_in_agent_call(self, tmp_path: Path) -> None:
        """execute() wraps instructions and content in XML isolation markers."""
        target = tmp_path / "doc.txt"
        target.write_text("Python service\n", encoding="utf-8")
        agent = _make_agent()
        tool = MarkTextTool(MagicMock())
        tool._agent = agent
        tool.execute(
            MarkTextArgs(
                file_path=str(target),
                instructions="mark technology terms as technological",
            )
        )
        call_args = agent.run_sync.call_args[0][0]
        assert "<marking_instructions>" in call_args
        assert "</marking_instructions>" in call_args
        assert "<text_content>" in call_args
        assert "</text_content>" in call_args
        assert "mark technology terms as technological" in call_args
        assert "Python service" in call_args

    def test_context_tag_present_when_provided(self) -> None:
        """execute() includes <context> XML tags when context is provided."""
        agent = _make_agent()
        tool = MarkTextTool(MagicMock())
        tool._agent = agent
        tool.execute(
            MarkTextArgs(
                text="Python service",
                instructions="mark technology terms as technological",
                context="computing",
            )
        )
        call_args = agent.run_sync.call_args[0][0]
        assert "<context>" in call_args
        assert "computing" in call_args

    def test_context_tag_absent_when_not_provided(self) -> None:
        """execute() omits <context> XML tags when context is not provided."""
        agent = _make_agent()
        tool = MarkTextTool(MagicMock())
        tool._agent = agent
        tool.execute(
            MarkTextArgs(
                text="Python service",
                instructions="mark technology terms as technological",
            )
        )
        call_args = agent.run_sync.call_args[0][0]
        assert "<context>" not in call_args

    def test_read_failure_returns_error(self, tmp_path: Path) -> None:
        """execute() returns an error dict when reading the file raises OSError."""
        target = tmp_path / "doc.txt"
        target.write_text("content\n", encoding="utf-8")
        tool = self._make_tool()
        with patch("pathlib.Path.read_text", side_effect=OSError("disk error")):
            result = tool.execute(MarkTextArgs(file_path=str(target), instructions="mark nouns"))
        assert result.output["status"] == "error"
        assert "failed to read" in result.output["message"].lower()
