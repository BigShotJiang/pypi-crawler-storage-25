"""Unit tests for the PluginRegistry microkernel."""

from typing import Any
from unittest.mock import MagicMock

import pytest
from dynaconf import Dynaconf

from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs, ToolResult
from aifred_tk.core.models import PluginNotFoundError, ToolNotFoundError
from aifred_tk.core.registry import PluginRegistry


class TestPluginRegistryLoad:
    """Registry plugin loading and tool enumeration."""

    def test_loads_demo_plugin_via_mocked_entry_points(
        self,
        mock_entry_points: object,
        test_settings: Dynaconf,
    ) -> None:
        """Registry discovers and loads the fake plugin through entry points."""
        registry = PluginRegistry(test_settings)
        registry.load_plugins()

        tools = registry.get_all_tools()
        assert "fake_tool" in tools

    def test_disabled_tool_excluded_from_all_tools(
        self,
        mock_entry_points: object,
        disabled_tool_settings: Dynaconf,
    ) -> None:
        """Disabled tools must not appear in get_all_tools()."""
        registry = PluginRegistry(disabled_tool_settings)
        registry.load_plugins()

        assert "fake_tool" not in registry.get_all_tools()

    def test_broken_entry_point_skipped_gracefully(
        self,
        monkeypatch: pytest.MonkeyPatch,
        test_settings: Dynaconf,
    ) -> None:
        """A plugin that raises on load must be skipped without aborting others."""

        class _GoodArgs(ToolArgs):
            pass

        class _GoodTool(Tool):
            @property
            def tool_id(self) -> str:
                return "good_tool"

            @property
            def name(self) -> str:
                return "Good Tool"

            @property
            def description(self) -> str:
                return "A good tool."

            @property
            def args_schema(self) -> type[_GoodArgs]:
                return _GoodArgs

            def execute(self, args: ToolArgs) -> ToolResult:
                return ToolResult(output={})

        class _GoodPlugin(Plugin):
            @property
            def plugin_id(self) -> str:
                return "good"

            @property
            def name(self) -> str:
                return "Good Plugin"

            def get_tools(self) -> list[Tool]:
                return [_GoodTool()]

        def _create_good(_settings: Any) -> _GoodPlugin:
            return _GoodPlugin()

        bad_ep: MagicMock = MagicMock()
        bad_ep.name = "broken"
        bad_ep.load.side_effect = ImportError("intentional failure")

        good_ep: MagicMock = MagicMock()
        good_ep.name = "good"
        good_ep.load.return_value = _create_good

        monkeypatch.setattr(
            "aifred_tk.core.registry.entry_points",
            lambda group: [bad_ep, good_ep] if group == "aifred_tk.plugins" else [],
        )

        registry = PluginRegistry(test_settings)
        registry.load_plugins()

        assert "good_tool" in registry.get_all_tools()

    def test_load_plugins_idempotent_when_called_twice(
        self,
        mock_entry_points: object,
        test_settings: Dynaconf,
    ) -> None:
        """Calling load_plugins twice should not duplicate tools."""
        registry = PluginRegistry(test_settings)
        registry.load_plugins()
        registry.load_plugins()

        tools = registry.get_all_tools()
        assert list(tools.keys()).count("fake_tool") == 1


class TestPluginRegistryGetTool:
    """Registry tool and plugin retrieval."""

    def test_get_tool_returns_correct_tool(
        self,
        mock_entry_points: object,
        test_settings: Dynaconf,
    ) -> None:
        """get_tool returns the tool when its ID is known and enabled."""
        registry = PluginRegistry(test_settings)
        registry.load_plugins()

        tool = registry.get_tool("fake_tool")
        assert tool.tool_id == "fake_tool"

    def test_get_tool_raises_for_unknown_id(
        self,
        mock_entry_points: object,
        test_settings: Dynaconf,
    ) -> None:
        """get_tool raises ToolNotFoundError for an unknown tool ID."""
        registry = PluginRegistry(test_settings)
        registry.load_plugins()

        with pytest.raises(ToolNotFoundError):
            registry.get_tool("nonexistent_tool")

    def test_get_plugin_returns_correct_plugin(
        self,
        mock_entry_points: object,
        test_settings: Dynaconf,
    ) -> None:
        """get_plugin returns the plugin when its ID is known."""
        registry = PluginRegistry(test_settings)
        registry.load_plugins()

        plugin = registry.get_plugin("fake")
        assert plugin.plugin_id == "fake"

    def test_get_plugin_raises_for_unknown_id(
        self,
        mock_entry_points: object,
        test_settings: Dynaconf,
    ) -> None:
        """get_plugin raises PluginNotFoundError for an unknown plugin ID."""
        registry = PluginRegistry(test_settings)
        registry.load_plugins()

        with pytest.raises(PluginNotFoundError):
            registry.get_plugin("nonexistent_plugin")
