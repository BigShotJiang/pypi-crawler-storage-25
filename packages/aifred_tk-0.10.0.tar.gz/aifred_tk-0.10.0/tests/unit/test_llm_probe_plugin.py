"""Unit tests for the llm_probe plugin."""

from collections.abc import Generator
from contextlib import contextmanager
from typing import Any
from unittest.mock import MagicMock, patch

import pytest
from pydantic import ValidationError

from aifred_tk.core.models import ConfigurationError
from aifred_tk.plugins.llm_probe.plugin import (
    LlmProbeArgs,
    LlmProbePlugin,
    LlmProbeTool,
    create_plugin,
)


@contextmanager
def _mock_agent(output: str = "LLM response.") -> Generator[MagicMock, None, None]:
    run_result = MagicMock()
    run_result.output = output
    agent = MagicMock()
    agent.run_sync.return_value = run_result
    with (
        patch(
            "aifred_tk.plugins.llm_probe.plugin.resolve_tool_llm",
            return_value=MagicMock(response_size=None, context_size=None),
        ),
        patch(
            "aifred_tk.plugins.llm_probe.plugin.build_pydantic_ai_model",
            return_value=MagicMock(),
        ),
        patch("aifred_tk.plugins.llm_probe.plugin.Agent", return_value=agent),
    ):
        yield agent


class TestLlmProbeArgs:
    """Pydantic schema validation for LlmProbeArgs."""

    @pytest.mark.parametrize(
        "temperature, max_tokens, expected_error",
        [
            (None, None, None),
            (0.0, None, None),
            (2.0, None, None),
            (1.0, 100, None),
            (None, 1, None),
            (-0.1, None, ValidationError),
            (2.1, None, ValidationError),
            (None, 0, ValidationError),
        ],
    )
    def test_optional_field_validation(
        self,
        temperature: float | None,
        max_tokens: int | None,
        expected_error: type[Exception] | None,
    ) -> None:
        """LlmProbeArgs validates temperature and max_tokens constraints."""
        kwargs: dict[str, Any] = {
            "system_prompt": "You are helpful.",
            "user_prompt": "Hello!",
        }
        if temperature is not None:
            kwargs["temperature"] = temperature
        if max_tokens is not None:
            kwargs["max_tokens"] = max_tokens

        if expected_error:
            with pytest.raises(expected_error):
                LlmProbeArgs(**kwargs)
        else:
            args = LlmProbeArgs(**kwargs)
            assert args.system_prompt == "You are helpful."
            assert args.user_prompt == "Hello!"

    def test_missing_system_prompt_raises(self) -> None:
        """system_prompt is required."""
        with pytest.raises(ValidationError):
            LlmProbeArgs(user_prompt="Hello!")  # type: ignore[call-arg]

    def test_missing_user_prompt_raises(self) -> None:
        """user_prompt is required."""
        with pytest.raises(ValidationError):
            LlmProbeArgs(system_prompt="You are helpful.")  # type: ignore[call-arg]

    def test_optional_fields_default_to_none(self) -> None:
        """temperature and max_tokens default to None."""
        args = LlmProbeArgs(system_prompt="sys", user_prompt="usr")
        assert args.temperature is None
        assert args.max_tokens is None


class TestLlmProbeToolMetadata:
    """Metadata properties of LlmProbeTool."""

    @pytest.fixture()
    def tool(self) -> LlmProbeTool:
        """Return a LlmProbeTool with a mock LLM config."""
        return LlmProbeTool(MagicMock())

    def test_tool_id(self, tool: LlmProbeTool) -> None:
        """tool_id must be 'probe_llm'."""
        assert tool.tool_id == "probe_llm"

    def test_name(self, tool: LlmProbeTool) -> None:
        """name must be non-empty."""
        assert tool.name

    def test_description(self, tool: LlmProbeTool) -> None:
        """description must be non-empty."""
        assert tool.description

    def test_args_schema(self, tool: LlmProbeTool) -> None:
        """args_schema must return LlmProbeArgs class."""
        assert tool.args_schema is LlmProbeArgs


class TestLlmProbeToolExecute:
    """execute() behaviour of LlmProbeTool."""

    def test_happy_path_returns_response(self) -> None:
        """execute() returns the raw LLM response on success."""
        tool = LlmProbeTool(MagicMock())
        with _mock_agent("Hello, matey!"):
            result = tool.execute(LlmProbeArgs(system_prompt="You are a pirate.", user_prompt="Hi"))
        assert result.output == {"response": "Hello, matey!"}

    def test_agent_exception_returns_error(self) -> None:
        """execute() returns an error dict when the agent raises."""
        tool = LlmProbeTool(MagicMock())
        agent = MagicMock()
        agent.run_sync.side_effect = RuntimeError("LLM unavailable")
        with (
            patch(
                "aifred_tk.plugins.llm_probe.plugin.resolve_tool_llm",
                return_value=MagicMock(response_size=None, context_size=None),
            ),
            patch(
                "aifred_tk.plugins.llm_probe.plugin.build_pydantic_ai_model",
                return_value=MagicMock(),
            ),
            patch("aifred_tk.plugins.llm_probe.plugin.Agent", return_value=agent),
        ):
            result = tool.execute(LlmProbeArgs(system_prompt="sys", user_prompt="usr"))
        assert result.output["status"] == "error"
        assert "agent error" in result.output["message"].lower()

    @pytest.mark.parametrize(
        ("extra_kwargs", "expected_model_settings"),
        [
            ({"temperature": 0.5}, {"temperature": 0.5}),
            ({"max_tokens": 256}, {"max_tokens": 256}),
            ({}, None),
        ],
    )
    def test_model_settings_from_args(
        self,
        extra_kwargs: dict[str, Any],
        expected_model_settings: dict[str, Any] | None,
    ) -> None:
        """execute() passes model_settings reflecting optional arg values."""
        tool = LlmProbeTool(MagicMock())
        with _mock_agent() as agent:
            tool.execute(LlmProbeArgs(system_prompt="sys", user_prompt="usr", **extra_kwargs))
        _, call_kwargs = agent.run_sync.call_args
        assert call_kwargs.get("model_settings") == expected_model_settings

    def test_system_prompt_forwarded_to_agent(self) -> None:
        """execute() constructs the Agent with the given system_prompt."""
        tool = LlmProbeTool(MagicMock())
        with (
            patch(
                "aifred_tk.plugins.llm_probe.plugin.resolve_tool_llm",
                return_value=MagicMock(response_size=None, context_size=None),
            ),
            patch(
                "aifred_tk.plugins.llm_probe.plugin.build_pydantic_ai_model",
                return_value=MagicMock(),
            ),
            patch("aifred_tk.plugins.llm_probe.plugin.Agent") as mock_agent_cls,
        ):
            run_result = MagicMock()
            run_result.output = "ok"
            mock_agent_cls.return_value.run_sync.return_value = run_result
            tool.execute(LlmProbeArgs(system_prompt="Custom system.", user_prompt="usr"))

        _, agent_kwargs = mock_agent_cls.call_args
        assert agent_kwargs.get("system_prompt") == "Custom system."


class TestLlmProbePlugin:
    """Plugin metadata and tool enumeration for LlmProbePlugin."""

    @pytest.fixture()
    def plugin(self) -> LlmProbePlugin:
        """Return a LlmProbePlugin with a mock LLM config."""
        return LlmProbePlugin(MagicMock())

    def test_plugin_id(self, plugin: LlmProbePlugin) -> None:
        """plugin_id must be 'llm_probe'."""
        assert plugin.plugin_id == "llm_probe"

    def test_name(self, plugin: LlmProbePlugin) -> None:
        """name must be non-empty."""
        assert plugin.name

    def test_get_tools_returns_one_tool(self, plugin: LlmProbePlugin) -> None:
        """get_tools must return exactly one tool."""
        assert len(plugin.get_tools()) == 1

    def test_get_tools_tool_id(self, plugin: LlmProbePlugin) -> None:
        """The single tool must have tool_id 'probe_llm'."""
        assert plugin.get_tools()[0].tool_id == "probe_llm"


class TestCreatePlugin:
    """Factory function create_plugin."""

    def test_returns_plugin_instance(self) -> None:
        """create_plugin returns a LlmProbePlugin without eager validation."""
        plugin = create_plugin(MagicMock())
        assert isinstance(plugin, LlmProbePlugin)

    def test_raises_when_llm_not_configured_on_execute(self) -> None:
        """ConfigurationError is raised on execute() when llm is absent."""
        settings = MagicMock()
        settings.get.side_effect = lambda key, *args: {} if key == "LLMS" else None
        plugin = create_plugin(settings)
        tool = plugin.get_tools()[0]
        with pytest.raises(ConfigurationError):
            tool.execute(LlmProbeArgs(system_prompt="sys", user_prompt="usr"))
