"""Unit tests for the markdown_frontmatter plugin."""

from __future__ import annotations

import json
import tomllib
from collections.abc import Callable
from pathlib import Path
from typing import Any

import pytest
import yaml
from dynaconf import Dynaconf

from aifred_tk.plugins.markdown_frontmatter.plugin import (
    FrontmatterArgs,
    GetFrontmatterTool,
    create_plugin,
)


@pytest.fixture
def tool() -> GetFrontmatterTool:
    """Return a GetFrontmatterTool instance."""
    return GetFrontmatterTool()


def test_create_plugin() -> None:
    """Test plugin creation factory."""
    settings = Dynaconf()
    plugin = create_plugin(settings)
    assert plugin.plugin_id == "markdown_frontmatter"
    assert len(plugin.get_tools()) == 1
    assert isinstance(plugin.get_tools()[0], GetFrontmatterTool)


def test_get_frontmatter_yaml(tmp_path: Path, tool: GetFrontmatterTool) -> None:
    """Test extracting YAML frontmatter."""
    md_file = tmp_path / "test.md"
    content = """---
title: Test YAML
tags: [a, b]
---
# Content
"""
    md_file.write_text(content, encoding="utf-8")

    args = FrontmatterArgs(file_path=str(md_file), output_format="dict")
    result = tool.execute(args)

    assert result.output["status"] == "ok"
    assert result.output["frontmatter"] == {"title": "Test YAML", "tags": ["a", "b"]}


def test_get_frontmatter_toml(tmp_path: Path, tool: GetFrontmatterTool) -> None:
    """Test extracting TOML frontmatter."""
    md_file = tmp_path / "test.md"
    content = """+++
title = "Test TOML"
[extra]
key = "val"
+++
# Content
"""
    md_file.write_text(content, encoding="utf-8")

    args = FrontmatterArgs(file_path=str(md_file), output_format="dict")
    result = tool.execute(args)

    assert result.output["status"] == "ok"
    assert result.output["frontmatter"] == {"title": "Test TOML", "extra": {"key": "val"}}


@pytest.mark.parametrize(
    ("output_format", "parser"),
    [
        ("json", json.loads),
        ("yaml", yaml.safe_load),
        ("toml", tomllib.loads),
    ],
)
def test_output_format_roundtrip(
    tmp_path: Path,
    tool: GetFrontmatterTool,
    output_format: str,
    parser: Callable[[str], Any],
) -> None:
    """Serializing frontmatter and parsing it back must yield the original dict."""
    md_file = tmp_path / "test.md"
    md_file.write_text("---\nkey: value\n---\n", encoding="utf-8")

    args = FrontmatterArgs(file_path=str(md_file), output_format=output_format)
    result = tool.execute(args)

    assert result.output["status"] == "ok"
    assert parser(result.output["frontmatter"]) == {"key": "value"}


def test_get_frontmatter_no_frontmatter(tmp_path: Path, tool: GetFrontmatterTool) -> None:
    """Test file without frontmatter."""
    md_file = tmp_path / "test.md"
    md_file.write_text("# Only content", encoding="utf-8")

    args = FrontmatterArgs(file_path=str(md_file), output_format="dict")
    result = tool.execute(args)

    assert result.output["status"] == "ok"
    assert result.output["frontmatter"] is None
    assert "No frontmatter found" in result.output["message"]


def test_get_frontmatter_aiignore(tmp_path: Path, tool: GetFrontmatterTool) -> None:
    """Test that .aiignore is respected."""
    (tmp_path / ".aiignore").write_text("secret.md\n", encoding="utf-8")
    secret_file = tmp_path / "secret.md"
    secret_file.write_text("---\ntitle: Secret\n---\n", encoding="utf-8")

    args = FrontmatterArgs(file_path=str(secret_file), output_format="dict")
    result = tool.execute(args)

    assert result.output["status"] == "error"
    assert "ignored by .aiignore" in result.output["message"]


def test_get_frontmatter_file_not_found(tool: GetFrontmatterTool) -> None:
    """Test non-existent file."""
    args = FrontmatterArgs(file_path="non_existent.md", output_format="dict")
    result = tool.execute(args)

    assert result.output["status"] == "error"
    assert "File not found" in result.output["message"]
