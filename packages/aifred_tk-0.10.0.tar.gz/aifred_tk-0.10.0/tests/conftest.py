"""Shared fixtures for the aifred-tk test suite."""

from pathlib import Path
from typing import Any
from unittest.mock import MagicMock

import pytest
from dynaconf import Dynaconf
from pydantic import Field

from aifred_tk.core.interfaces import Plugin, Tool, ToolArgs, ToolResult


class _FakeArgs(ToolArgs):
    """Minimal args schema used by the test fake plugin."""

    msg: str = Field(..., description="A message")


class _FakeTool(Tool):
    """Minimal concrete tool for use in fixtures that need a real plugin."""

    @property
    def tool_id(self) -> str:
        """Return the unique tool identifier.

        :return: ``"fake_tool"``
        :rtype: str
        """
        return "fake_tool"

    @property
    def name(self) -> str:
        """Return the human-readable tool name.

        :return: Display name string.
        :rtype: str
        """
        return "Fake Tool"

    @property
    def description(self) -> str:
        """Return the tool description.

        :return: Description string.
        :rtype: str
        """
        return "A fake tool for testing."

    @property
    def args_schema(self) -> type[_FakeArgs]:
        """Return the Pydantic model class for argument validation.

        :return: :class:`_FakeArgs` class.
        :rtype: type[_FakeArgs]
        """
        return _FakeArgs

    def execute(self, args: ToolArgs) -> ToolResult:
        """Execute the tool (no-op).

        :param args: Validated args instance.
        :type args: ToolArgs
        :return: Empty result.
        :rtype: ToolResult
        """
        return ToolResult(output={})


class _FakePlugin(Plugin):
    """Minimal concrete plugin for use in fixtures."""

    @property
    def plugin_id(self) -> str:
        """Return the unique plugin identifier.

        :return: ``"fake"``
        :rtype: str
        """
        return "fake"

    @property
    def name(self) -> str:
        """Return the human-readable plugin name.

        :return: Display name string.
        :rtype: str
        """
        return "Fake Plugin"

    def get_tools(self) -> list[Tool]:
        """Return the single fake tool.

        :return: List containing :class:`_FakeTool`.
        :rtype: list[Tool]
        """
        return [_FakeTool()]


def _create_fake_plugin(_settings: Any) -> _FakePlugin:
    """Entry point factory for the fake test plugin.

    :param _settings: Settings instance (unused).
    :return: Initialised :class:`_FakePlugin` instance.
    :rtype: _FakePlugin
    """
    return _FakePlugin()


def _make_settings(tmp_path: Path, extra: str = "") -> Dynaconf:
    """Write a minimal settings YAML and return a Dynaconf instance.

    :param tmp_path: Temporary directory for the settings file and logs.
    :type tmp_path: Path
    :param extra: Additional YAML content appended to the base config.
    :type extra: str
    :return: Configured :class:`~dynaconf.Dynaconf` instance.
    :rtype: Dynaconf
    """
    log_dir = tmp_path / "logs"
    log_dir.mkdir(exist_ok=True)

    cfg = tmp_path / "settings.yml"
    cfg.write_text(f"aifred_tk:\n  log_dir: {log_dir}\n  log_level: DEBUG\n{extra}")

    from importlib.resources import files

    pkg_defaults = str(files("aifred_tk").joinpath("default_settings.yml"))
    return Dynaconf(
        settings_files=[pkg_defaults, str(cfg)],
        merge_enabled=True,
        load_dotenv=False,
    )


@pytest.fixture()
def test_settings(tmp_path: Path) -> Dynaconf:
    """Return a minimal Dynaconf settings instance for testing.

    Points ``aifred_tk.log_dir`` at the temporary directory so log files
    do not leak into the working tree during tests.

    :param tmp_path: pytest-provided temporary directory.
    :type tmp_path: Path
    :return: Configured :class:`~dynaconf.Dynaconf` instance.
    :rtype: Dynaconf
    """
    return _make_settings(tmp_path)


@pytest.fixture()
def mock_entry_points(monkeypatch: pytest.MonkeyPatch) -> MagicMock:
    """Patch ``importlib.metadata.entry_points`` to return the fake plugin.

    :param monkeypatch: pytest monkeypatch fixture.
    :type monkeypatch: pytest.MonkeyPatch
    :return: The mock entry point object.
    :rtype: MagicMock
    """
    ep: MagicMock = MagicMock()
    ep.name = "fake"
    ep.load.return_value = _create_fake_plugin

    def _fake_entry_points(group: str) -> list[Any]:
        if group == "aifred_tk.plugins":
            return [ep]
        return []

    monkeypatch.setattr(
        "aifred_tk.core.registry.entry_points",
        _fake_entry_points,
    )
    return ep


@pytest.fixture()
def disabled_tool_settings(tmp_path: Path) -> Dynaconf:
    """Return settings with ``fake_tool`` explicitly disabled.

    :param tmp_path: pytest-provided temporary directory.
    :type tmp_path: Path
    :return: Configured :class:`~dynaconf.Dynaconf` instance.
    :rtype: Dynaconf
    """
    return _make_settings(
        tmp_path,
        extra="tools:\n  fake_tool:\n    enabled: false\n",
    )
