"""Integration tests for MCP elicitation via FastMCP in-process client."""

from typing import Any

import pytest
from fastmcp import Client
from fastmcp.client.elicitation import ElicitResult
from fastmcp.exceptions import ToolError

from aifred_tk.mcp.server import build_mcp_server


@pytest.fixture()
def mcp_server(mock_entry_points: object, test_settings: object) -> object:
    """Return a FastMCP server with the fake plugin and aifred_elicit_choice tool.

    :param mock_entry_points: Entry point mock (side-effect only).
    :type mock_entry_points: object
    :param test_settings: Dynaconf settings.
    :type test_settings: object
    :return: Configured FastMCP server.
    :rtype: object
    """
    from dynaconf import Dynaconf

    settings: Dynaconf = test_settings  # type: ignore[assignment]
    return build_mcp_server(settings=settings)


class TestElicitChoiceMcpToolRegistration:
    """The aifred_elicit_choice tool must be present in the MCP tool list."""

    async def test_aifred_elicit_choice_in_tool_list(self, mcp_server: object) -> None:
        async with Client(mcp_server) as client:  # type: ignore[arg-type]
            tools = await client.list_tools()
            names = [t.name for t in tools]
            assert "aifred_elicit_choice" in names

    async def test_aifred_elicit_choice_has_expected_parameters(self, mcp_server: object) -> None:
        async with Client(mcp_server) as client:  # type: ignore[arg-type]
            tools = await client.list_tools()
            tool = next(t for t in tools if t.name == "aifred_elicit_choice")
            schema = tool.inputSchema
            props = schema.get("properties", {})
            assert "question" in props
            assert "choices" in props
            assert "allow_free_input" in props


class TestElicitChoiceMcpToolExecution:
    """The aifred_elicit_choice tool must correctly forward elicitation to the client."""

    async def test_returns_selected_option(self, mcp_server: object) -> None:
        """Selecting option index 0 returns the correct label."""

        async def handler(
            message: str, response_type: Any, params: Any, context: Any
        ) -> dict[str, Any]:
            # The handler receives the elicitation and returns opt_0
            return {"value": "opt_0"}

        async with Client(mcp_server, elicitation_handler=handler) as client:  # type: ignore[arg-type]
            result = await client.call_tool(
                "aifred_elicit_choice",
                {
                    "question": "Which colour?",
                    "choices": ["Red", "Green", "Blue"],
                },
            )
            assert result is not None
            import json

            content = json.loads(result.content[0].text)  # type: ignore[union-attr]
            assert content["selected_index"] == 0
            assert content["selected_label"] == "Red"
            assert content["free_text"] is None

    async def test_returns_correct_index_for_second_option(self, mcp_server: object) -> None:
        async def handler(
            message: str, response_type: Any, params: Any, context: Any
        ) -> dict[str, Any]:
            return {"value": "opt_1"}

        async with Client(mcp_server, elicitation_handler=handler) as client:  # type: ignore[arg-type]
            result = await client.call_tool(
                "aifred_elicit_choice",
                {"question": "Pick:", "choices": ["A", "B", "C"]},
            )
            import json

            content = json.loads(result.content[0].text)  # type: ignore[union-attr]
            assert content["selected_index"] == 1
            assert content["selected_label"] == "B"

    async def test_free_input_path(self, mcp_server: object) -> None:
        """When the user picks the free-input option, free_text is populated."""
        call_count = 0

        async def handler(
            message: str, response_type: Any, params: Any, context: Any
        ) -> dict[str, Any] | str:
            nonlocal call_count
            call_count += 1
            if call_count == 1:
                # First elicitation: user picks "Other (specify…)"
                return {"value": "__free__"}
            # Second elicitation: user types their custom text
            return {"value": "my custom answer"}

        async with Client(mcp_server, elicitation_handler=handler) as client:  # type: ignore[arg-type]
            result = await client.call_tool(
                "aifred_elicit_choice",
                {
                    "question": "Pick:",
                    "choices": ["A", "B"],
                    "allow_free_input": True,
                },
            )
            import json

            content = json.loads(result.content[0].text)  # type: ignore[union-attr]
            assert content["selected_index"] == -1
            assert content["selected_label"] is None
            assert content["free_text"] == "my custom answer"

    async def test_declined_elicitation_raises_error(self, mcp_server: object) -> None:
        """Declining the elicitation must surface as an error in the tool result."""

        async def handler(
            message: str, response_type: Any, params: Any, context: Any
        ) -> ElicitResult[Any]:
            return ElicitResult(action="decline")

        async with Client(mcp_server, elicitation_handler=handler) as client:  # type: ignore[arg-type]
            with pytest.raises(ToolError):
                await client.call_tool(
                    "aifred_elicit_choice",
                    {"question": "Pick:", "choices": ["A"]},
                )

    async def test_descriptions_and_examples_forwarded(self, mcp_server: object) -> None:
        """Descriptions and examples must be included in elicitation titles."""
        received_params: list[Any] = []

        async def handler(
            message: str, response_type: Any, params: Any, context: Any
        ) -> dict[str, Any]:
            received_params.append(params)
            return {"value": "opt_0"}

        async with Client(mcp_server, elicitation_handler=handler) as client:  # type: ignore[arg-type]
            await client.call_tool(
                "aifred_elicit_choice",
                {
                    "question": "Pick:",
                    "choices": ["Alpha"],
                    "descriptions": ["First option"],
                    "examples": ["foo"],
                },
            )

        assert received_params
        # The elicitation params contain the requestedSchema with our labels
        schema = received_params[0].requestedSchema
        props = schema.get("properties", {})
        assert "value" in props
        # The title should contain description and example
        one_of = props["value"].get("oneOf", [])
        if one_of:
            titles = [opt.get("title", "") for opt in one_of]
            assert any("First option" in t for t in titles)
            assert any("foo" in t for t in titles)
