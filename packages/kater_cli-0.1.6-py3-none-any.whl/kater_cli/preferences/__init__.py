"""Preferences module for Kater CLI."""

from kater_cli.preferences.preference_manager import PreferenceManager

__all__ = ["PreferenceManager"]
