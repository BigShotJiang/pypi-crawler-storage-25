"""Kater CLI entry point."""

import typer

from kater_cli.commands import (
    auth,
    dev,
    validate,
)
from kater_cli.commands import (
    compile as compile_cmd,
)
from kater_cli.commands import (
    run as run_cmd,
)
from kater_cli.commands.config import config_app
from kater_cli.commands.import_ import import_app
from kater_cli.commands.install import install
from kater_cli.commands.scaffold.app import scaffold_app

app = typer.Typer(
    name="kater",
    help="Kater command-line interface.",
    no_args_is_help=True,
)


def _run_build_command(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output."),
    fix: bool = typer.Option(False, "--fix", help="Auto-fix configuration issues where possible."),
) -> None:
    """Load the build command only when it is invoked."""
    from kater_cli.commands.build import build

    build(verbose=verbose, fix=fix)


# Register authentication commands at top level
app.command(name="signup", help="Create a Kater account and authenticate this CLI.")(auth.signup)
app.command(name="login", help="Log in to Kater via browser-based OAuth.")(auth.login)
app.command(name="logout", help="Log out and clear stored credentials.")(auth.logout)
app.command(name="status", help="Check authentication status.")(auth.status)

# Register install command (project initialization, no auth required)
app.command(name="install", help="Initialize a Kater project in the current directory.")(install)

# Register dev command (primary development workflow)
app.command(name="dev", help="Sync your local files to the Kater platform.")(dev.dev)

# Register config subcommand group
app.add_typer(config_app, name="config")

# Register import subcommand group
app.add_typer(import_app, name="import")

# Register scaffold subcommand group
app.add_typer(scaffold_app, name="scaffold")

# Register build command (configuration/theme validation)
app.command(name="build", help="Validate configuration and theme settings.")(_run_build_command)

# Register validate command
app.command(name="validate", help="Validate semantic layer schemas.")(validate.validate)

# Register compile command
app.command(name="compile", help="Compile a query template to SQL.")(compile_cmd.compile_query)

# Register run command
app.command(name="run", help="Execute a query and display results.")(run_cmd.run_query)


if __name__ == "__main__":
    app()
