"""Kater CLI package."""
