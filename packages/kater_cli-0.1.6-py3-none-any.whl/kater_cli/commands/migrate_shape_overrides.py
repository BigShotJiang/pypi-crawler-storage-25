"""Command for migrating combination_overrides to shape_overrides in YAML files."""

from pathlib import Path
from typing import Any, Dict, List, Tuple

import typer
import yaml
from rich.console import Console

console = Console()


def migrate_shape_overrides_command(file_path: str) -> None:
    """Migrate combination_overrides to shape_overrides in a YAML file.

    Args:
        file_path: Path to the YAML file to migrate

    Raises:
        FileNotFoundError: If the file doesn't exist
        yaml.YAMLError: If the file is not valid YAML
    """
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"File not found: {file_path}")

    console.print(f"Migrating {file_path}...")

    # Load the YAML file
    with open(path, "r") as f:
        data = yaml.safe_load(f)

    # Perform the migration
    migrated_data = rewrite_combination_overrides_to_shape_overrides(data)

    # Check if any changes were made
    if migrated_data == data:
        console.print("No combination_overrides found - no migration needed")
        return

    # Write the migrated data back to the file
    with open(path, "w") as f:
        yaml.dump(migrated_data, f, default_flow_style=False, sort_keys=False)

    console.print(f"✅ Successfully migrated {file_path}")


def rewrite_combination_overrides_to_shape_overrides(data: Dict[str, Any]) -> Dict[str, Any]:
    """Convert combination_overrides to shape_overrides format.

    Args:
        data: The parsed YAML data dictionary

    Returns:
        Modified dictionary with shape_overrides instead of combination_overrides
    """
    if "combination_overrides" not in data:
        return data

    # Create a copy to avoid modifying the original
    result = data.copy()

    # Extract and remove combination_overrides
    combination_overrides = result.pop("combination_overrides")

    # Convert to shape_overrides
    shape_overrides: List[Dict[str, Any]] = []

    for combo_override in combination_overrides:
        shape_override = _convert_single_override(combo_override)
        shape_overrides.append(shape_override)

    result["shape_overrides"] = shape_overrides

    return result


def _convert_single_override(combo_override: Dict[str, Any]) -> Dict[str, Any]:
    """Convert a single combination override to shape override format.

    Args:
        combo_override: Single combination override dictionary

    Returns:
        Converted shape override dictionary
    """
    combination_str = combo_override["combination"]

    # Parse the combination string to extract field slots and variables
    field_slots, variables = _parse_combination_string(combination_str)

    # Build the new shape string from field slots
    shape_str = ",".join(field_slots)

    # Build the shape override
    shape_override: Dict[str, Any] = {"shape": shape_str}

    # Add variables section if there are any
    if variables:
        shape_override["variables"] = variables

    # Copy over the config if present
    if "config" in combo_override:
        shape_override["config"] = combo_override["config"]

    return shape_override


def _parse_combination_string(combination_str: str) -> Tuple[List[str], Dict[str, str]]:
    """Parse a combination string into field slots and variables.

    Args:
        combination_str: The combination string to parse

    Returns:
        Tuple of (field_slots, variables)
    """
    field_slots: List[str] = []
    variables: Dict[str, str] = {}

    # Valid temporal timeframes that should use bracket syntax
    TEMPORAL_TIMEFRAMES = {
        "raw",
        "date",
        "day",
        "week",
        "month",
        "quarter",
        "year",
        "day_of_week",
        "hour",
    }

    # Split on commas and process each token
    for token in combination_str.split(","):
        token = token.strip()

        if "=" not in token:
            continue

        key, value = token.split("=", 1)
        key = key.strip()
        value = value.strip()

        # Check if this is a field slot (dimension, measure, calculation)
        if key in ("dimension", "measure", "calculation"):
            # Handle temporal dot suffixes -> bracket syntax
            # Only convert if the suffix is a known temporal timeframe
            if (
                "." in value
                and not value.startswith("var(")
                and not value.startswith("ref(")
                and "." not in value[: value.rfind(".")]
            ):
                # Check if the last part after the dot is a timeframe
                parts = value.rsplit(".", 1)
                if len(parts) == 2:
                    base_field, potential_timeframe = parts
                    if potential_timeframe in TEMPORAL_TIMEFRAMES:
                        value = f"{base_field}[{potential_timeframe}]"

            field_slots.append(f"{key}={value}")

        else:
            # This is a variable assignment
            variables[key] = value

    return field_slots, variables


# CLI integration - this would be added to the main CLI app
def main(file_path: str = typer.Argument(..., help="Path to YAML file to migrate")):
    """Migrate combination_overrides to shape_overrides in a YAML file."""
    try:
        migrate_shape_overrides_command(file_path)
    except FileNotFoundError as e:
        console.print(f"❌ Error: {e}", style="red")
        raise typer.Exit(1)
    except yaml.YAMLError as e:
        console.print(f"❌ YAML Error: {e}", style="red")
        raise typer.Exit(1)
    except Exception as e:
        console.print(f"❌ Unexpected error: {e}", style="red")
        raise typer.Exit(1)


if __name__ == "__main__":
    typer.run(main)
