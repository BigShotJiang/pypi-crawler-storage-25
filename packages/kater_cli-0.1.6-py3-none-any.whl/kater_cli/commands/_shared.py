"""Shared utilities for CLI commands.

Story 4.4 — `_StructuredRenderRequest`, `BatchRow`, `parse_run_args`,
`to_legacy_combination_string`, `display_batch_summary`, and
`format_truncated_key_id` were placed here per the option-(B) decision
documented in
`_bmad-output/epics/demo/patch/natural-key/stories/4-4-cli-structured-field-selections-and-rendered-query-key-id.md#why-the-sprint-status-yaml-file-targets-reference-typescript-paths`.
The sprint-status.yaml targets reference TypeScript-style modules
(`apps/cli/src/output/verbose_formatter.ts`, etc.) that do not match the
actual Python+typer CLI layout. Extending the existing `_shared.py` /
`run.py` / `commands/compile.py` keeps the surface area discoverable and
short helpers co-located.
"""

import json
import sys
from collections.abc import Sequence
from dataclasses import dataclass, field
from typing import Any, Literal, cast

import kater
import keyring
import typer
from kater.types.v1 import Connection
from rich.console import Console
from rich.table import Table

from kater_cli.auth.messages import REAUTH_MESSAGE
from kater_cli.auth.token_manager import CLI_ID_KEY
from kater_cli.commands._sdk_compat import (
    FieldModifier,
    FieldOccurrence,
    RenderedQueryFieldSelectionV1,
    RenderedQueryRequestPresentationV1,
    RenderedQueryRequestResultWindowV1,
    RenderedQueryRequestTemporalV1,
    RenderedQueryRequestV1,
    RuntimeFilterStateV2,
    RuntimeVariableValueV1,
)
from kater_cli.config import get_settings
from kater_cli.preferences.preference_manager import PreferenceManager
from kater_cli.prompts import prompt_selection

console = Console()
stderr_console = Console(stderr=True)


def get_cli_id() -> str | None:
    """Get CLI ID from keyring without creating a new one."""
    settings = get_settings()
    return keyring.get_password(settings.keyring_service, CLI_ID_KEY)


def fetch_connections(client: kater.Kater) -> list[Connection]:
    """Fetch all connections from the API."""
    try:
        return list(client.v1.connections.list_connections())
    except kater.AuthenticationError:
        console.print(f"[red]{REAUTH_MESSAGE}[/red]")
        raise typer.Exit(1)
    except kater.APIStatusError as e:
        console.print(f"[red]Error fetching connections: {e.message}[/red]")
        raise typer.Exit(1)


def resolve_connection_ids(
    client: kater.Kater,
    connection_names: list[str] | None,
) -> list[str] | None:
    """Resolve --connection names to connection IDs.

    Returns None if all connections should be validated.
    """
    if not connection_names:
        connections = fetch_connections(client)
        if not connections:
            console.print("[red]No connections found.[/red]")
            raise typer.Exit(1)

        if len(connections) == 1:
            return [connections[0].id]

        # Interactive mode: prompt user to select
        if sys.stdout.isatty():
            options: list[tuple[str, str]] = [
                ("__all__", "Validate all connections"),
            ]
            for conn in connections:
                options.append((conn.id, conn.description or conn.name))

            selected = prompt_selection(
                "Select connections to validate",
                options,
                prompt_text="Selection",
            )
            if selected == "__all__":
                return None
            return [selected]

        # Non-interactive: validate all
        return None

    # Resolve names to IDs
    connections = fetch_connections(client)
    conn_by_name = {c.name.lower(): c for c in connections}
    resolved_ids: list[str] = []

    for name in connection_names:
        conn = conn_by_name.get(name.lower())
        if conn is None:
            available = ", ".join(c.name for c in connections)
            console.print(
                f"[red]Connection '{name}' not found. Available connections: {available}[/red]"
            )
            raise typer.Exit(1)
        resolved_ids.append(conn.id)

    return resolved_ids


def resolve_single_connection(
    client: kater.Kater,
    connection_name: str | None,
) -> Connection:
    """Resolve a single connection for commands that operate on one connection.

    Priority order:
    1. --connection flag (explicit name)
    2. Only 1 connection exists -> auto-select
    3. Default connection via PreferenceManager
    4. Interactive prompt (if TTY)
    5. Error with available names (non-interactive, no default)
    """
    connections = fetch_connections(client)
    if not connections:
        console.print("[red]No connections found.[/red]")
        raise typer.Exit(1)

    conn_by_name = {c.name.lower(): c for c in connections}

    # 1. Explicit --connection flag
    if connection_name:
        conn = conn_by_name.get(connection_name.lower())
        if conn is None:
            available = ", ".join(c.name for c in connections)
            console.print(
                f"[red]Connection '{connection_name}' not found. "
                f"Available connections: {available}[/red]"
            )
            raise typer.Exit(1)
        return conn

    # 2. Only one connection -> auto-select
    if len(connections) == 1:
        return connections[0]

    # 3. Default connection from preferences
    prefs = PreferenceManager()
    default_id = prefs.get_default_connection_id()
    if default_id:
        for conn in connections:
            if conn.id == default_id:
                return conn

    # 4. Interactive prompt (if TTY)
    if sys.stdout.isatty():
        options: list[tuple[str, str]] = []
        for conn in connections:
            options.append((conn.id, conn.description or conn.name))

        selected_id = prompt_selection(
            "Select a connection",
            options,
            prompt_text="Selection",
        )
        for conn in connections:
            if conn.id == selected_id:
                return conn

    # 5. Non-interactive, no default -> error
    available = ", ".join(c.name for c in connections)
    console.print(
        f"[red]Multiple connections available: {available}. Use --connection to specify one.[/red]"
    )
    raise typer.Exit(1)


def parse_error_body(e: kater.BadRequestError) -> tuple[str | None, str | None]:
    """Extract the error code and message from a BadRequestError body."""
    raw_body: object | None = e.body
    body = cast(dict[str, Any], raw_body) if isinstance(raw_body, dict) else None
    if body is not None:
        return cast(str | None, body.get("code")), cast(str | None, body.get("message"))
    return None, None


def handle_api_error(e: kater.APIStatusError, *, context: str = "operation") -> None:
    """Handle common API errors with a configurable context label."""
    if isinstance(e, kater.AuthenticationError):
        console.print(f"[red]{REAUTH_MESSAGE}[/red]")
        raise typer.Exit(1)

    if isinstance(e, kater.BadRequestError):
        code, _ = parse_error_body(e)
        if code == "DEV_SESSION_NOT_FOUND":
            console.print(
                "[red]Dev session not found. Run `kater dev` first or use `--branch`.[/red]"
            )
            raise typer.Exit(1)
        if code == "FILE_SOURCE_CONFLICT":
            console.print(
                "[red]Cannot use both dev session and --branch. "
                "Stop `kater dev` or omit --branch.[/red]"
            )
            raise typer.Exit(1)

    if isinstance(e, kater.NotFoundError):
        console.print(f"[red]{e.message}[/red]")
        raise typer.Exit(1)

    console.print(f"[red]Unexpected error during {context}: {e.message}[/red]")
    raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Query-ref helpers
# ---------------------------------------------------------------------------


def bare_query_name(query: str) -> str:
    """Strip the q: prefix for file naming."""
    if query.startswith("q:"):
        return query[2:]
    return query


# ---------------------------------------------------------------------------
# Display helpers
# ---------------------------------------------------------------------------


def display_ref_fixes(ref_fixes: Sequence[Any]) -> None:
    """Display auto-fix summary using Rich output."""
    total_replacements = sum(len(fix.replacements) for fix in ref_fixes)
    total_files = len(ref_fixes)

    console.print(
        f"\n[green]✓[/green] Auto-fixed {total_replacements} ref(s) "
        f"across {total_files} file(s) due to renames:\n"
    )
    for fix in ref_fixes:
        for replacement in fix.replacements:
            console.print(
                f"  {replacement.file_path}:{replacement.line_number} "
                f"[red]{replacement.old_ref}[/red] → [green]{replacement.new_ref}[/green]"
            )


def display_compile_errors(errors: Sequence[Any]) -> None:
    """Display compilation errors in a formatted output."""
    count = len(errors)
    label = "error" if count == 1 else "errors"
    console.print(f"\n[red]✗[/red] Compilation failed ({count} {label})\n")

    for error in errors:
        location = ""
        file_val = getattr(error, "file", None)
        if file_val:
            location = f" {file_val}"
            line_val = getattr(error, "line", None)
            if line_val is not None:
                location += f":{line_val}"
                col_val = getattr(error, "column", None)
                if col_val is not None:
                    location += f":{col_val}"

        code = getattr(error, "code", "UNKNOWN")
        message = getattr(error, "message", str(error))
        remediation = getattr(error, "remediation", None)

        console.print(f"    [red][{code}]{location}[/red]")
        console.print(f"      {message}")
        if remediation:
            console.print(f"      [dim]→ {remediation}[/dim]")


def handle_compile_api_error(e: kater.APIStatusError) -> None:
    """Handle API errors for compile/run commands.

    Catches SCHEMA_PARSE_ERROR for custom display, then delegates to shared handler.
    """
    if isinstance(e, kater.BadRequestError):
        code, message = parse_error_body(e)
        if code == "SCHEMA_PARSE_ERROR" and message:
            console.print(f"\n[red]✗[/red] Schema parse error: {message}")
            raise typer.Exit(1)

    handle_api_error(e, context="compilation")


# ---------------------------------------------------------------------------
# Story 4.4 — structured render request, batch summary, key id formatting
# ---------------------------------------------------------------------------


def _empty_selected_fields() -> list[str]:
    return []


def _empty_field_name_list() -> list[tuple[str, str]]:
    return []


def _empty_variable_dict() -> dict[str, str]:
    return {}


def _empty_filter_state() -> list[dict[str, object]]:
    return []


def _empty_modifier_selection_list() -> list[dict[str, str]]:
    return []


# Story 6.1 — temporal grain values accepted by the ``--timeframe`` flag.
# Mirrors the PRD's CLI Reference (Target State) grammar.
_TIMEFRAME_GRAINS: frozenset[str] = frozenset(
    {
        "raw",
        "date",
        "day",
        "week",
        "month",
        "quarter",
        "year",
        "day_of_week",
        "hour",
    }
)


@dataclass(frozen=True)
class _StructuredRenderRequest:
    """Frozen dataclass mirroring the consumer-facing parts of RenderedQueryRequestV1.

    Story 4.4 — the CLI parses --shape / --field / --var / --filter /
    --variant / --as-of into this intermediate shape. During the migration
    window, the CLI converts this back to a legacy combination string for the
    existing /compiler/resolve + /compiler/execute call sites
    (see ``to_legacy_combination_string``).

    Story 6.1+ — ``timeframe_modifiers`` carries temporal grain choices that
    are folded into ``selected_fields`` before the render request is submitted.
    """

    selected_fields: list[str] = field(default_factory=_empty_selected_fields)
    selected_field_names: list[tuple[str, str]] = field(default_factory=_empty_field_name_list)
    variable_assignments: dict[str, str] = field(default_factory=_empty_variable_dict)
    filter_state: list[dict[str, object]] = field(default_factory=_empty_filter_state)
    timeframe_modifiers: list[dict[str, str]] = field(
        default_factory=_empty_modifier_selection_list
    )
    pinned_variant: str | None = None
    as_of: str | None = None
    legacy_combination: str | None = None
    auto_fix: bool = True

    @property
    def selected_field_ids(self) -> list[str]:
        """Backward-compatible alias for UUID-based field selection."""
        return self.selected_fields

    @property
    def timeframe_overrides(self) -> list[dict[str, str]]:
        """Backward-compatible alias for UUID timeframe modifiers."""
        return [
            {
                "source_kater_id": modifier["source_kater_id"],
                "active_timeframe": modifier["value"],
            }
            for modifier in self.timeframe_modifiers
        ]

    @property
    def is_empty(self) -> bool:
        """True when no consumer input was supplied (default-selection path)."""
        return (
            not self.selected_fields
            and not self.selected_field_names
            and not self.variable_assignments
            and not self.filter_state
            and not self.timeframe_modifiers
            and self.pinned_variant is None
            and self.as_of is None
        )


@dataclass(frozen=True)
class BatchRow:
    """One row in the batch-execution summary table.

    Story 4.4 — accumulated by the outer loop in run_query / compile_query;
    rendered by ``display_batch_summary`` at end-of-batch.
    """

    query_name: str
    shape_label: str | None
    status: Literal["ok", "fail"]
    row_count: int | None = None
    execution_time_ms: float | None = None
    cache_hit: bool | None = None
    sql_length: int | None = None
    rendered_query_key_id: str | None = None


def _split_filter_segments(segments: str) -> list[str]:
    """Split a filter segment string on top-level commas only.

    Story 4.4 — JSON arrays and objects in ``value=...`` segments contain
    commas. A naive ``str.split(",")`` would shred those values. This helper
    walks the string and only splits when bracket/brace/quote depth is zero.
    """
    parts: list[str] = []
    depth = 0
    in_string = False
    string_quote = ""
    buffer: list[str] = []
    for ch in segments:
        if in_string:
            buffer.append(ch)
            if ch == string_quote:
                in_string = False
            continue
        if ch in {'"', "'"}:
            in_string = True
            string_quote = ch
            buffer.append(ch)
            continue
        if ch in {"[", "{"}:
            depth += 1
        elif ch in {"]", "}"}:
            depth = max(depth - 1, 0)
        if ch == "," and depth == 0:
            parts.append("".join(buffer))
            buffer = []
        else:
            buffer.append(ch)
    if buffer:
        parts.append("".join(buffer))
    return parts


def _parse_filter_string(filter_arg: str) -> dict[str, object]:
    """Parse a --filter "name:enabled=<bool>,value=<json>" string.

    Both segments are optional. Examples:
    - "active_employees" → {"name": "active_employees", "enabled": True, "value": None}
    - "active_employees:enabled=false" → {"name": "active_employees", "enabled": False, "value": None}
    - "active_employees:value=active" → {"name": "active_employees", "enabled": True, "value": "active"}
    - "active_employees:enabled=true,value=active" → {"name": ..., "enabled": True, "value": "active"}
    """
    if ":" not in filter_arg:
        return {"name": filter_arg.strip(), "enabled": True, "value": None}

    name, segments = filter_arg.split(":", 1)
    parsed: dict[str, object] = {"name": name.strip(), "enabled": True, "value": None}

    for segment in _split_filter_segments(segments):
        segment = segment.strip()
        if not segment or "=" not in segment:
            continue
        key, value = segment.split("=", 1)
        key, value = key.strip(), value.strip()
        if key == "enabled":
            parsed["enabled"] = value.lower() in {"true", "1", "yes"}
        elif key == "value":
            try:
                parsed["value"] = json.loads(value)
            except (json.JSONDecodeError, ValueError):
                parsed["value"] = value

    return parsed


def _parse_timeframe_value(timeframe_arg: str) -> dict[str, str]:
    """Split one ``--timeframe <source_kater_id>=<grain>`` arg into a modifier draft.

    Raises:
        typer.BadParameter: When the value is missing ``=`` or the grain is
            not one of the accepted values.
    """
    if "=" not in timeframe_arg:
        raise typer.BadParameter(
            f"--timeframe must be '<source_kater_id>=<grain>'; got '{timeframe_arg}'"
        )
    source_kater_id, grain = timeframe_arg.split("=", 1)
    source_kater_id, grain = source_kater_id.strip(), grain.strip()
    if not source_kater_id:
        raise typer.BadParameter(
            f"--timeframe requires a non-empty source_kater_id; got '{timeframe_arg}'"
        )
    if grain not in _TIMEFRAME_GRAINS:
        accepted = ", ".join(sorted(_TIMEFRAME_GRAINS))
        raise typer.BadParameter(
            f"--timeframe grain '{grain}' is not valid. Accepted grains: {accepted}."
        )
    return {"source_kater_id": source_kater_id, "value": grain}


def _parse_selection_grammar(
    selection: str,
    *,
    allow_pinned_variant: bool,
) -> tuple[list[tuple[str, str]], dict[str, str], str | None]:
    """Parse legacy/name-based field selection grammar into structured pieces."""
    selected_field_names: list[tuple[str, str]] = []
    inline_variables: dict[str, str] = {}
    pinned_variant: str | None = None

    for chunk in selection.split(","):
        chunk = chunk.strip()
        if not chunk or "=" not in chunk:
            continue
        key, value = chunk.split("=", 1)
        key, value = key.strip(), value.strip()
        if key in {"dimension", "measure", "calculation"}:
            selected_field_names.append((key, value))
        elif allow_pinned_variant and key == "pinned_variant":
            pinned_variant = value
        else:
            inline_variables[key] = value

    return selected_field_names, inline_variables, pinned_variant


def _validate_timeframe_with_field(
    *,
    timeframes: list[str],
    fields: list[str],
    shape: str | None,
) -> None:
    """Guard ``--timeframe`` mutual-exclusion rules.

    ``--timeframe`` is the UUID-side temporal modifier shortcut. It is only
    valid with ``--field`` (UUID escape hatch). Structured shape configs carry
    modifier values on the field occurrence itself.
    """
    if not timeframes:
        return
    if shape:
        raise typer.BadParameter(
            "--timeframe and --shape are mutually exclusive; structured shapes carry "
            "modifier values on their field occurrences"
        )
    if not fields:
        raise typer.BadParameter(
            "--timeframe requires --field; structured shapes carry modifier values "
            "on their field occurrences"
        )


def parse_run_args(
    *,
    shape: str | None,
    fields: list[str],
    vars: list[str],
    filters: list[str],
    variant: str | None,
    as_of: str | None,
    combination: str | None,
    no_auto_fix: bool,
    timeframes: list[str] | None = None,
) -> _StructuredRenderRequest:
    """Parse the new CLI flags into a structured render request.

    Story 4.4 — handles mutual-exclusion checks, deprecation warnings for
    --combination, and grammar parsing for --shape and --filter.

    Story 6.1 — accepts a new ``timeframes`` keyword (the parsed
    ``--timeframe <source_kater_id>=<grain>`` flag values) and validates
    that ``--timeframe`` is only combined with ``--field``. Removes the
    ``_emit_field_unsupported_warning()`` call site since ``--field`` is now
    plumbed to the structured render endpoint.

    Raises:
        typer.BadParameter: When mutually exclusive flags are combined.
    """
    if shape and combination:
        raise typer.BadParameter("--shape and --combination are mutually exclusive")
    if shape and variant:
        raise typer.BadParameter(
            "--shape and --variant are mutually exclusive (--variant supplies the field set)"
        )
    if shape and fields:
        raise typer.BadParameter(
            "--shape and --field are mutually exclusive (--field is the UUID escape hatch)"
        )
    if variant and fields:
        raise typer.BadParameter("--variant and --field are mutually exclusive")

    timeframe_args: list[str] = list(timeframes or [])
    _validate_timeframe_with_field(timeframes=timeframe_args, fields=fields, shape=shape)

    timeframe_modifiers: list[dict[str, str]] = [
        _parse_timeframe_value(tf) for tf in timeframe_args
    ]

    selected_field_names: list[tuple[str, str]] = []
    inline_variables: dict[str, str] = {}
    pinned_variant_from_combo: str | None = None

    if combination:
        stderr_console.print(
            "[yellow]warning: --combination is deprecated; use --shape or --field instead.[/yellow]"
        )

    selection = shape or combination
    if selection:
        selected_field_names, inline_variables, pinned_variant_from_combo = (
            _parse_selection_grammar(
                selection,
                allow_pinned_variant=bool(combination),
            )
        )

    variable_assignments: dict[str, str] = dict(inline_variables)
    for var_arg in vars:
        if "=" not in var_arg:
            raise typer.BadParameter(f"--var must be name=value; got '{var_arg}'")
        name, value = var_arg.split("=", 1)
        name, value = name.strip(), value.strip()
        if name in inline_variables and inline_variables[name] != value:
            stderr_console.print(
                f"[yellow]warning: --var {name}={value} overrides inline --shape "
                f"value '{inline_variables[name]}'[/yellow]"
            )
        variable_assignments[name] = value

    filter_state: list[dict[str, object]] = []
    for filter_arg in filters:
        filter_state.append(_parse_filter_string(filter_arg))

    return _StructuredRenderRequest(
        selected_fields=list(fields),
        selected_field_names=selected_field_names,
        variable_assignments=variable_assignments,
        filter_state=filter_state,
        timeframe_modifiers=timeframe_modifiers,
        pinned_variant=variant or pinned_variant_from_combo,
        as_of=as_of,
        legacy_combination=combination,
        auto_fix=not no_auto_fix,
    )


def parse_compile_args(
    *,
    shape: str | None,
    fields: list[str],
    vars: list[str],
    filters: list[str],
    variant: str | None,
    as_of: str | None,
    combination: str | None,
    no_auto_fix: bool,
    timeframes: list[str] | None = None,
) -> _StructuredRenderRequest:
    """Thin alias for ``parse_run_args``; the parsing rules are identical for
    `kater run` and `kater compile`.

    Story 4.4 — kept as a separate symbol so call sites in `compile.py` read
    cleanly. If the parsing rules ever diverge between run and compile, this
    is the override point.

    Story 6.1 — forwards the new ``timeframes`` kwarg so a future
    ``kater compile`` migration (Story 6.2) inherits the same validation.
    """
    return parse_run_args(
        shape=shape,
        fields=fields,
        vars=vars,
        filters=filters,
        variant=variant,
        as_of=as_of,
        combination=combination,
        no_auto_fix=no_auto_fix,
        timeframes=timeframes,
    )


def build_rendered_query_request(
    *,
    structured: _StructuredRenderRequest,
    query_kater_id: str,
    connection_id: str,
    tenant_key: str,  # noqa: ARG001 — unused while route uses NO_TENANT_KEY (Story 2.2)
    source_branch: str | None = None,  # noqa: ARG001 — forwarded via header at call site
    cli_id: str | None = None,  # noqa: ARG001 — forwarded via header at call site
    legacy_combination: str | None = None,  # noqa: ARG001 — Story 3.5 envelope not in schema
) -> RenderedQueryRequestV1:
    """Project a parsed ``_StructuredRenderRequest`` onto a ``RenderedQueryRequestV1``.

    Story 6.1 — pure function with no side effects. The returned request
    body is the canonical input to ``client.v1.compiler.render(...)`` (or
    its compat equivalent ``submit_render(...)`` while the Stainless SDK
    regen is pending).

    The CLI does not have a local manifest reader, so name-based field
    selection through ``--shape`` cannot be projected onto selected field
    occurrences here; callers must route those requests through the existing
    resolve+execute path until the boundary adapter accepts name-based
    envelopes.
    The ``legacy_combination`` and ``source_branch`` / ``cli_id`` kwargs are
    accepted for forward compatibility — once Story 3.5 merges, the helper
    will populate the boundary envelope on the request body, and the
    transport-level kwargs will move into ``submit_render(...)`` headers.

    Args:
        structured: Parsed CLI flags (Story 4.4 dataclass).
        query_kater_id: UUID resolved via ``resolve_query_name_to_id(...)``.
        connection_id: UUID resolved via ``resolve_single_connection(...)``.
        tenant_key: ``--tenant`` value (currently consumed by the route's
            ``resolve_tenant_params(...)`` rather than the request body).
        source_branch: ``--branch`` value (forwarded as a query parameter at
            the submit site, not on the body).
        cli_id: dev-session id (forwarded via ``X-Kater-CLI-ID`` header at
            the submit site, not on the body).
        legacy_combination: Set only on the ``--combination`` deprecation
            path. Reserved for Story 3.5's boundary adapter envelope; the
            current schema does not accept it, so the dual-path fallback
            (resolve+execute) handles ``--combination`` requests until the
            adapter merges.

    Returns:
        A ``RenderedQueryRequestV1`` instance ready to submit.
    """
    timeframe_by_source = {
        modifier["source_kater_id"]: modifier["value"]
        for modifier in structured.timeframe_modifiers
    }

    def occurrence_for(field_id: str) -> FieldOccurrence:
        timeframe = timeframe_by_source.get(field_id)
        modifiers = (
            [] if timeframe in (None, "raw") else [FieldModifier(kind="timeframe", value=timeframe)]
        )
        return FieldOccurrence(source_kater_id=field_id, modifiers=modifiers)

    selected_fields = [occurrence_for(field_id) for field_id in structured.selected_fields]

    field_selection = RenderedQueryFieldSelectionV1(
        selected_fields=selected_fields,
    )

    variables: list[RuntimeVariableValueV1] = [
        RuntimeVariableValueV1(
            variable_kater_id=None,
            query_kater_id=query_kater_id,
            name=name,
            scope="query",
            value=value,
        )
        for name, value in structured.variable_assignments.items()
    ]

    filter_state: list[RuntimeFilterStateV2] = [
        RuntimeFilterStateV2.model_validate(item) for item in structured.filter_state
    ]

    return RenderedQueryRequestV1(
        connection_id=connection_id,
        query_kater_id=query_kater_id,
        pinned_variant=structured.pinned_variant,
        field_selection=field_selection,
        variables=variables,
        filter_state=filter_state,
        dashboard=None,
        presentation=RenderedQueryRequestPresentationV1(),
        result_window=RenderedQueryRequestResultWindowV1(),
        temporal=RenderedQueryRequestTemporalV1(timezone=None, as_of=structured.as_of),
    )


def to_legacy_combination_string(structured: _StructuredRenderRequest) -> str | None:
    """Serialize name-based structured input for legacy resolve fallbacks."""
    if structured.is_empty:
        return None

    parts = [f"{slot}={name}" for slot, name in structured.selected_field_names]
    for var_name, var_value in structured.variable_assignments.items():
        parts.append(f"{var_name}={var_value}")
    if structured.pinned_variant is not None:
        parts.append(f"pinned_variant={structured.pinned_variant}")

    return ",".join(parts) if parts else None


def format_shape_label(structured: _StructuredRenderRequest) -> str | None:
    """Produce a stable batch summary label for a parsed render request.

    Story 6.1 — replaces the legacy ``combo_str`` label that was previously
    threaded into ``BatchRow.shape_label``. The helper is pure and returns:

    - ``None`` for the default-selection path (no flags).
    - The original ``--shape`` string when ``--shape`` was provided
      (re-serialized from ``selected_field_names``).
    - A short composite ``"<uuid1[:8]>,<uuid2[:8]>"`` for ``--field`` UUIDs.
    - ``"variant=<name>"`` for ``--variant``.
    """
    if structured.is_empty:
        return None
    if structured.selected_field_names:
        # Re-serialize the shape grammar (matches what the user typed).
        parts = [f"{slot}={name}" for slot, name in structured.selected_field_names]
        for var_name, var_value in structured.variable_assignments.items():
            parts.append(f"{var_name}={var_value}")
        return ",".join(parts) if parts else None
    if structured.selected_fields:
        truncated = [fid[:8] for fid in structured.selected_fields]
        label = ",".join(truncated)
        if structured.timeframe_modifiers:
            label += " +modifiers"
        return label
    if structured.pinned_variant is not None:
        return f"variant={structured.pinned_variant}"
    return None


def format_truncated_key_id(key_id: str | None) -> str:
    """Truncate a rendered_query_key.key_id for display in TTY mode.

    Story 4.4 — preserves the full key when piped (``console.is_terminal == False``),
    truncates to first 16 hex chars + "…" when interactive.

    Format: ``rqk_v2:<64 hex>``. Truncation keeps the prefix and the first
    16 hex chars: ``rqk_v2:abc1234567890123…``.
    """
    if key_id is None:
        return "[dim]-[/dim]"
    is_terminal = getattr(console, "is_terminal", True)
    if not is_terminal:
        return key_id
    if ":" in key_id:
        prefix, hex_part = key_id.split(":", 1)
        if len(hex_part) > 16:
            return f"{prefix}:{hex_part[:16]}…"
    return key_id


def display_batch_summary(
    rows: list[BatchRow],
    *,
    mode: Literal["run", "compile"],
) -> None:
    """Print a Rich table summarizing per-row execution results.

    Story 4.4 — printed at end-of-batch when more than one execution
    happened. The single-execution case is covered by the per-iteration
    summary in ``_display_summary``.
    """
    if len(rows) <= 1:
        return

    table = Table(title="Batch Summary", show_header=True, header_style="bold")
    table.add_column("Query")
    table.add_column("Shape")
    table.add_column("Status")
    if mode == "run":
        table.add_column("Rows", justify="right")
        table.add_column("Time", justify="right")
        table.add_column("Cache")
    else:
        table.add_column("SQL Length", justify="right")
    table.add_column("Key ID")

    for row in rows:
        status_cell = "[green]✓[/green]" if row.status == "ok" else "[red]✗[/red]"
        shape_cell = row.shape_label or "[dim]default[/dim]"
        key_cell = format_truncated_key_id(row.rendered_query_key_id)

        if mode == "run":
            rows_cell = str(row.row_count) if row.row_count is not None else "-"
            time_cell = (
                f"{row.execution_time_ms:.0f}ms" if row.execution_time_ms is not None else "-"
            )
            cache_cell = "hit" if row.cache_hit else ("miss" if row.cache_hit is False else "-")
            table.add_row(
                row.query_name,
                shape_cell,
                status_cell,
                rows_cell,
                time_cell,
                cache_cell,
                key_cell,
            )
        else:
            sql_cell = f"{row.sql_length} chars" if row.sql_length is not None else "-"
            table.add_row(
                row.query_name,
                shape_cell,
                status_cell,
                sql_cell,
                key_cell,
            )

    console.print()
    console.print(table)
