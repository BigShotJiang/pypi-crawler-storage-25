"""Command for validating project configuration and theme settings.

``kater build`` checks that configuration is set up correctly for
frontend rendering: theme settings, chart theme, custom themes,
project structure, and resource files.

This is distinct from ``kater validate`` which checks model correctness
for SQL compilation.
"""

from pathlib import Path

import typer
import yaml
from kater_core.services.build_validator import (
    DEFAULT_THEME_NAME,
    KNOWN_PRESET_THEMES,
    BuildDiagnostic,
    BuildValidator,
)
from rich.console import Console

from kater_cli.commands._display import display_build_diagnostics
from kater_cli.repo import find_repo_root

console = Console()


def build(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output."),
    fix: bool = typer.Option(False, "--fix", help="Auto-fix configuration issues where possible."),
) -> None:
    """Validate project configuration and theme settings.

    Checks that themes, chart themes, custom themes, project structure,
    and LLM resource files are properly configured for frontend rendering.

    Use --fix to automatically repair common issues (invalid theme names,
    missing custom-theme directories).

    Examples:

        # Check configuration
        kater build

        # Check and auto-fix issues
        kater build --fix

        # Verbose output
        kater build -v
    """
    repo_root = find_repo_root()

    if fix:
        _run_auto_fixes(repo_root, verbose=verbose)

    # Gather file contents for validation
    diagnostics = _run_build_checks(repo_root, verbose=verbose)

    # Display results
    diag_dicts = [
        {
            "file": d.file,
            "line": d.line,
            "column": d.column,
            "code": d.code,
            "message": d.message,
            "severity": d.severity,
            "remediation": d.remediation,
        }
        for d in diagnostics
    ]
    display_build_diagnostics(diag_dicts, repo_root=repo_root)

    # Exit with error code if there are errors
    errors = [d for d in diagnostics if d.severity == "error"]
    if errors:
        raise typer.Exit(1)


def _run_build_checks(repo_root: Path, *, verbose: bool = False) -> list[BuildDiagnostic]:
    """Run all build validation checks against local files.

    Args:
        repo_root: Repository root directory.
        verbose: Whether to print verbose output.

    Returns:
        List of BuildDiagnostic items.
    """
    if verbose:
        console.print(f"[dim]Repository root: {repo_root}[/dim]")

    # Read file contents
    config_content = _read_optional(repo_root / "kater.config.yaml")

    # Discover custom themes
    custom_theme_dirs = _get_custom_theme_names(repo_root)
    custom_theme_css: dict[str, str | None] = {}
    custom_theme_chart_themes: dict[str, str | None] = {}
    for theme_name in custom_theme_dirs:
        css_path = repo_root / "theme" / "custom-themes" / theme_name / "kater-globals.css"
        chart_path = repo_root / "theme" / "custom-themes" / theme_name / "kater-chart-theme.yaml"
        custom_theme_css[theme_name] = _read_optional(css_path)
        custom_theme_chart_themes[theme_name] = _read_optional(chart_path)

    # Check directory existence
    has_theme_dir = (repo_root / "theme").is_dir()
    has_custom_themes_dir = (repo_root / "theme" / "custom-themes").is_dir()

    # Check resource files
    resources_dir = repo_root / "resources"
    existing_resource_files: list[str] = []
    if resources_dir.is_dir():
        existing_resource_files = sorted(
            str(path.relative_to(resources_dir)).replace("\\", "/")
            for path in resources_dir.rglob("*")
            if path.is_file()
        )

    # Run validator
    validator = BuildValidator()
    return validator.validate_all(
        config_content=config_content,
        custom_theme_dirs=custom_theme_dirs,
        custom_theme_css=custom_theme_css,
        custom_theme_chart_themes=custom_theme_chart_themes,
        has_theme_dir=has_theme_dir,
        has_custom_themes_dir=has_custom_themes_dir,
        existing_resource_files=existing_resource_files,
    )


# ---------------------------------------------------------------------------
# Auto-fix functions (moved from validate.py)
# ---------------------------------------------------------------------------


def _run_auto_fixes(repo_root: Path, *, verbose: bool = False) -> None:
    """Run all auto-fix operations.

    Args:
        repo_root: Repository root directory.
        verbose: Whether to print verbose output.
    """
    _ensure_kater_config_theme(repo_root, verbose=verbose)
    _ensure_custom_themes_dir(repo_root, verbose=verbose)


def _ensure_kater_config_theme(repo_root: Path, *, verbose: bool = False) -> None:
    """Ensure kater.config.yaml has a valid ``theme`` property.

    If the ``theme`` key is absent, injects ``theme: kater``.
    If the ``theme`` value is not a known preset or custom theme,
    replaces it with ``kater``. Idempotent.
    """
    config_path = repo_root / "kater.config.yaml"
    if not config_path.exists():
        return

    try:
        content = config_path.read_text(encoding="utf-8")
        data = yaml.safe_load(content)
    except (OSError, yaml.YAMLError):
        return

    if not isinstance(data, dict):
        return

    raw_theme: str | None = data.get("theme")  # type: ignore[reportUnknownMemberType]

    if "theme" not in data:
        data["theme"] = DEFAULT_THEME_NAME
        config_path.write_text(
            yaml.dump(data, default_flow_style=False, sort_keys=False),
            encoding="utf-8",
        )
        console.print(f"  [green]✓[/green] Added theme: {DEFAULT_THEME_NAME} to kater.config.yaml")
        if verbose:
            console.print(f"    [dim]{config_path}[/dim]")
        return

    if not isinstance(raw_theme, str) or not raw_theme.strip():
        return

    theme_name = raw_theme.strip()
    is_preset = theme_name in KNOWN_PRESET_THEMES
    custom_names = _get_custom_theme_names(repo_root)
    is_custom = theme_name in custom_names

    if is_preset or is_custom:
        return

    data["theme"] = DEFAULT_THEME_NAME
    config_path.write_text(
        yaml.dump(data, default_flow_style=False, sort_keys=False),
        encoding="utf-8",
    )
    console.print(
        f"  [green]✓[/green] Fixed theme in kater.config.yaml: "
        f"'{theme_name}' → '{DEFAULT_THEME_NAME}'"
    )
    if verbose:
        console.print(f"    [dim]{config_path}[/dim]")


def _ensure_custom_themes_dir(repo_root: Path, *, verbose: bool = False) -> None:
    """Ensure the ``theme/custom-themes/`` directory exists.

    Creates the directory (with a ``.gitkeep``) if missing. Idempotent.
    Only runs when the ``theme/`` parent directory already exists.
    """
    theme_dir = repo_root / "theme"
    if not theme_dir.is_dir():
        return

    custom_dir = theme_dir / "custom-themes"
    if custom_dir.is_dir():
        return

    custom_dir.mkdir(parents=True, exist_ok=True)
    (custom_dir / ".gitkeep").write_text("")
    console.print("  [green]✓[/green] Created theme/custom-themes/ directory")
    if verbose:
        console.print(f"    [dim]{custom_dir}[/dim]")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _read_optional(path: Path) -> str | None:
    """Read file content, returning None if file doesn't exist."""
    try:
        return path.read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return None


def _get_custom_theme_names(repo_root: Path) -> list[str]:
    """Return sorted list of custom theme directory names."""
    custom_dir = repo_root / "theme" / "custom-themes"
    if not custom_dir.is_dir():
        return []
    return sorted(d.name for d in custom_dir.iterdir() if d.is_dir())
