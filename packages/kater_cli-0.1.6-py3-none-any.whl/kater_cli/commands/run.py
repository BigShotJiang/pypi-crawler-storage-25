"""Command for executing a compiled query and displaying results."""

from typing import TYPE_CHECKING, Any, Optional, TypedDict, cast

import kater
import typer
from rich.console import Console
from rich.table import Table
from rich.text import Text

from kater_cli.auth.messages import AUTHENTICATION_FAILED_MESSAGE
from kater_cli.client import get_authenticated_client
from kater_cli.commands._capability_sampling import (
    CapabilitySampleResponse,
    submit_capability_sampling,
)
from kater_cli.commands._sdk_compat import (
    CompilerRenderResponse,
    RenderedQueryRequestV1,
    submit_render,
)
from kater_cli.commands._shared import (
    BatchRow,
    build_rendered_query_request,
    format_shape_label,
    bare_query_name,
    display_batch_summary,
    display_compile_errors,
    display_ref_fixes,
    format_truncated_key_id,
    get_cli_id,
    handle_compile_api_error,
    parse_run_args,
    resolve_single_connection,
    stderr_console,
    to_legacy_combination_string,
)
from kater_cli.commands.compile import resolve_query_args
from kater_cli.repo import find_repo_root, resolve_query_name_to_id

if TYPE_CHECKING:
    from kater.types.v1 import CompilerExecuteResponse

console = Console()


class PostQuerySummary(TypedDict):
    active_filters: int
    active_sorts: int
    available_filters: int
    available_sorts: int
    disabled_reasons: list[str]


def _structured_supports_render(structured: Any) -> bool:
    """Decide whether a parsed request can use the new render endpoint.

    Story 6.1 — UUID-only paths (``--field`` plus optional ``--timeframe``,
    ``--variant``, ``--var``, ``--filter``, ``--as-of``) submit through
    ``POST /api/v1/compiler/render``. Name-based paths (``--shape``,
    ``--combination``) fall back to the legacy resolve+execute call site
    until Story 1.4's resolver accepts a name-based envelope (Story 3.5
    boundary adapter; not yet merged).
    """
    selected_field_names: list[Any] = getattr(structured, "selected_field_names", None) or []
    return not selected_field_names


def _display_render_results(
    result: CompilerRenderResponse,
    *,
    limit: int | None = None,
    show_post_query: bool = False,
) -> None:
    """Display a render response as a Rich table.

    Story 6.1 — replaces the call to ``_display_execute_results`` on the
    structured render path. Reuses the same column-map → display-name
    projection and the same ``_display_summary(...)`` helper. The only
    difference is the input type (``CompilerRenderResponse`` from the
    structured render endpoint vs. ``CompilerExecuteResponse`` from the
    legacy execute call).
    """
    data = result.data or []
    column_map = result.column_map or []
    row_count = result.row_count or len(data)
    execution_time = result.execution_time_ms
    cache_hit = result.cache_hit
    rendered_query_key_id = getattr(getattr(result, "rendered_query_key", None), "key_id", None)
    post_query_refinements = getattr(result, "post_query_refinements", {})

    # Apply authored/default post-query state if requested
    if show_post_query and data:
        data = apply_authored_default_post_query_state(data, post_query_refinements)

    if not data:
        console.print("\n[dim]No rows returned.[/dim]")
        _display_summary(
            row_count=0,
            execution_time=execution_time,
            cache_hit=cache_hit,
            rendered_query_key_id=rendered_query_key_id,
        )
        return

    id_to_name: dict[str, str] = {}
    for col in column_map:
        if col.column_key is not None:
            id_to_name[col.column_key] = col.display_label or col.source_label or col.source_name

    raw_columns = list(data[0].keys())
    display_columns = [id_to_name.get(col, col) for col in raw_columns]

    table = Table(show_header=True, header_style="bold")
    for col_name in display_columns:
        table.add_column(col_name or "")

    display_data = data
    truncated = False
    if limit is not None and limit < len(data):
        display_data = data[:limit]
        truncated = True

    for row in display_data:
        table.add_row(*[str(v) if v is not None else "" for v in row.values()])

    console.print()
    console.print(table)

    if truncated:
        console.print(f"\n[dim]Showing {limit} of {row_count} rows (use --limit to adjust)[/dim]")

    _display_summary(
        row_count=row_count,
        execution_time=execution_time,
        cache_hit=cache_hit,
        rendered_query_key_id=rendered_query_key_id,
    )

    # Display post-query summary if requested
    if show_post_query:
        _display_post_query_summary(post_query_refinements)


def _display_execute_results(
    result: "CompilerExecuteResponse",
    *,
    limit: int | None = None,
) -> None:
    """Display query execution results as a Rich table.

    Story 4.4 — extracts ``rendered_query_key.key_id`` from the response
    (with ``getattr`` robustness for the SDK regeneration window) and threads
    it into ``_display_summary``.

    Story 6.1 — preserved during the transition for the ``--shape`` /
    ``--combination`` legacy fallback path. Story 7.5 removes this helper
    once the boundary adapter (Story 3.5) lands and every CLI invocation
    routes through ``_display_render_results``.
    """
    data = result.data or []
    column_map = result.column_map or []
    row_count = result.row_count or len(data)
    execution_time = result.execution_time_ms
    cache_hit = result.cache_hit
    rendered_query_key_id = getattr(getattr(result, "rendered_query_key", None), "key_id", None)

    if not data:
        console.print("\n[dim]No rows returned.[/dim]")
        _display_summary(
            row_count=0,
            execution_time=execution_time,
            cache_hit=cache_hit,
            rendered_query_key_id=rendered_query_key_id,
        )
        return

    id_to_name: dict[str, str] = {}
    for col in column_map:
        id_to_name[col.kater_id] = col.label or col.name

    raw_columns = list(data[0].keys())
    display_columns = [id_to_name.get(col, col) for col in raw_columns]

    table = Table(show_header=True, header_style="bold")
    for col_name in display_columns:
        table.add_column(col_name or "")

    display_data = data
    truncated = False
    if limit is not None and limit < len(data):
        display_data = data[:limit]
        truncated = True

    for row in display_data:
        table.add_row(*[str(v) if v is not None else "" for v in row.values()])

    console.print()
    console.print(table)

    if truncated:
        console.print(f"\n[dim]Showing {limit} of {row_count} rows (use --limit to adjust)[/dim]")

    _display_summary(
        row_count=row_count,
        execution_time=execution_time,
        cache_hit=cache_hit,
        rendered_query_key_id=rendered_query_key_id,
    )


def _display_summary(
    *,
    row_count: int,
    execution_time: float | None,
    cache_hit: bool | None,
    rendered_query_key_id: str | None = None,
) -> None:
    """Display execution summary line.

    Story 4.4 — extended to include ``rendered_query_key.key_id`` when present.
    Truncated to first 16 hex chars in TTY mode; full key when piped.
    """
    parts: list[str] = []
    row_label = "row" if row_count == 1 else "rows"
    parts.append(f"{row_count} {row_label}")
    if execution_time is not None:
        parts.append(f"{execution_time:.0f}ms")
    if cache_hit is not None:
        parts.append("cache hit" if cache_hit else "cache miss")
    if rendered_query_key_id is not None:
        parts.append(format_truncated_key_id(rendered_query_key_id))
    console.print(f"\n[dim]{' · '.join(parts)}[/dim]")


def apply_authored_default_post_query_state(
    data: list[dict[str, Any]], post_query_refinements: dict[str, Any]
) -> list[dict[str, Any]]:
    """
    Apply authored/default post-query state to result rows for CLI display.

    For V1 read-only support, this is a simplified implementation that
    would apply default-enabled filters and sorts from the post-query
    refinements metadata. For now, it returns the original data.

    Future enhancement: Implement actual filtering and sorting logic
    based on default_enabled flags in the refinements structure.
    """
    # V1: Return original data without transformation
    # TODO: Apply default-enabled filters and sorts
    return data


def format_post_query_summary(post_query_refinements: dict[str, Any]) -> PostQuerySummary:
    """
    Format a summary of available post-query refinements for CLI display.

    Returns a summary object with counts of active/available filters and sorts,
    plus any disabled diagnostics found in the post-query refinements metadata.
    """
    active_filters = 0
    active_sorts = 0
    available_filters = 0
    available_sorts = 0
    disabled_reasons: list[str] = []

    # Parse post-query refinements structure
    for refinement in post_query_refinements.values():
        if not isinstance(refinement, dict):
            continue
        refinement_dict = cast(dict[str, object], refinement)

        # Count filters
        raw_filters = refinement_dict.get("filters", [])
        if isinstance(raw_filters, list):
            filters = [
                cast(dict[str, object], item)
                for item in cast(list[object], raw_filters)
                if isinstance(item, dict)
            ]
            available_filters += len(filters)
            active_filters += sum(1 for item in filters if item.get("default_enabled") is True)

        # Count sorts
        raw_sorts = refinement_dict.get("sorts", [])
        if isinstance(raw_sorts, list):
            sorts = [
                cast(dict[str, object], item)
                for item in cast(list[object], raw_sorts)
                if isinstance(item, dict)
            ]
            available_sorts += len(sorts)
            active_sorts += sum(1 for item in sorts if item.get("default_enabled") is True)

        # Check for disabled diagnostics
        reason = refinement_dict.get("reason")
        if refinement_dict.get("disabled") is True and isinstance(reason, str):
            disabled_reasons.append(reason)

    return {
        "active_filters": active_filters,
        "active_sorts": active_sorts,
        "available_filters": available_filters,
        "available_sorts": available_sorts,
        "disabled_reasons": disabled_reasons,
    }


def _display_post_query_summary(post_query_refinements: dict[str, Any]) -> None:
    """Display post-query refinements summary for CLI output."""
    summary = format_post_query_summary(post_query_refinements)

    if (
        summary["available_filters"] == 0
        and summary["available_sorts"] == 0
        and len(summary["disabled_reasons"]) == 0
    ):
        return

    parts: list[str] = []

    if summary["available_filters"] > 0:
        parts.append(f"{summary['active_filters']}/{summary['available_filters']} filters active")

    if summary["available_sorts"] > 0:
        parts.append(f"{summary['active_sorts']}/{summary['available_sorts']} sorts active")

    if summary["disabled_reasons"]:
        parts.append(f"{len(summary['disabled_reasons'])} disabled")

    if parts:
        text = Text()
        text.append("Post-query: ", style="dim")
        text.append(" · ".join(parts), style="dim")

        if summary["disabled_reasons"]:
            text.append(f" ({', '.join(summary['disabled_reasons'])})", style="yellow")

        console.print(text)


def run_query(
    query: Optional[list[str]] = typer.Argument(
        None,
        help=(
            "Query name(s) or folder path(s). "
            "Examples: COMPLIANCE_OVERVIEW, topics/compliance/queries/"
        ),
    ),
    connection: str | None = typer.Option(
        None,
        "--connection",
        "-c",
        help="Connection name. Auto-selected if only one exists.",
    ),
    topic: str | None = typer.Option(
        None,
        "--topic",
        help="Topic name. Runs all queries within the specified topic.",
    ),
    branch: str | None = typer.Option(
        None,
        "--branch",
        "-b",
        help="Git branch to run from (alternative to running kater dev).",
    ),
    tenant: str = typer.Option(
        ...,
        "--tenant",
        "-t",
        help="Tenant key for multi-tenant execution. Use 'kater_global_tenant' for non-tenancy clients.",
    ),
    shape: str | None = typer.Option(
        None,
        "--shape",
        help=(
            "Field selection in name-based shape grammar "
            "(`dimension=name,measure=name,calculation=name`). "
            "Accepts inline scalar variable assignments. Example: "
            "'dimension=department,measure=compliance_rate,timeframe=month'."
        ),
    ),
    fields: list[str] = typer.Option(
        [],
        "--field",
        help=(
            "Adds an optional field by kater_id (UUID). Repeatable. "
            "Mutually exclusive with --shape; UUID escape hatch for tooling."
        ),
    ),
    timeframes: list[str] = typer.Option(
        [],
        "--timeframe",
        help=(
            "Sets a temporal modifier as '<source_kater_id>=<grain>'. "
            "Repeatable. Only valid with --field; structured shapes carry "
            "modifier values on their field occurrences. Grain is one of "
            "raw, date, day, week, month, quarter, year, day_of_week, hour."
        ),
    ),
    vars: list[str] = typer.Option(
        [],
        "--var",
        help=(
            "Sets a variable as 'name=value'. Repeatable. Combines with "
            "inline --shape variables; structured --var wins on conflict."
        ),
    ),
    filters: list[str] = typer.Option(
        [],
        "--filter",
        help=(
            "Sets a runtime filter as 'name:enabled=<bool>,value=<json>'. "
            "Both segments optional. Filters cannot be inlined in --shape."
        ),
    ),
    variant: str | None = typer.Option(
        None,
        "--variant",
        help="Selects a pinned variant. Mutually exclusive with --shape and --field.",
    ),
    as_of: str | None = typer.Option(
        None,
        "--as-of",
        help="ISO timestamp setting temporal.as_of for relative date filter normalization.",
    ),
    combination: str | None = typer.Option(
        None,
        "--combination",
        help="Deprecated legacy field-selection grammar. Use --shape or --field instead.",
    ),
    sample: int | None = typer.Option(
        None,
        "--sample",
        help="Auto-select N deterministic field selections per query via the backend sampling endpoint.",
    ),
    no_auto_fix: bool = typer.Option(
        False,
        "--no-auto-fix",
        help="Disable automatic ref fixing on renames.",
    ),
    limit: int | None = typer.Option(
        None,
        "--limit",
        "-n",
        help="Limit the number of rows displayed.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output."),
    show_post_query: bool = typer.Option(
        False,
        "--show-post-query",
        help="Display available post-query refinements and apply authored defaults to result rows.",
    ),
) -> None:
    """Execute a query template and display results.

    Resolves, compiles, and executes a query template, then displays
    the results as a table.

    Accepts multiple query names, folder paths, or --topic for batch execution.

    Examples:

        # Run with active dev session
        kater run COMPLIANCE_OVERVIEW

        # Run multiple queries
        kater run COMPLIANCE_OVERVIEW COMPLIANCE_TREND

        # Run all queries in a folder with sampling
        kater run topics/compliance/queries/ --sample=1

        # Run with a specific connection
        kater run COMPLIANCE_OVERVIEW -c snowflake_prod

        # Run with the new ergonomic shape grammar
        kater run COMPLIANCE_OVERVIEW --shape "dimension=department,measure=compliance_rate"

        # Inline variable inside the shape string
        kater run COMPLIANCE_OVERVIEW --shape "dimension=department,measure=compliance_rate,timeframe=month"

        # Same with explicit --var (recommended for non-scalar values)
        kater run COMPLIANCE_OVERVIEW \\
          --shape "dimension=department,measure=compliance_rate" \\
          --var timeframe=month

        # UUID escape hatch with explicit grain override
        kater run COMPLIANCE_OVERVIEW --field <uuid> --timeframe <uuid>=month

        # Runtime filter override
        kater run COMPLIANCE_OVERVIEW \\
          --shape "dimension=department,measure=compliance_rate" \\
          --filter "active_employees:enabled=true,value=active"

        # Pinned variant
        kater run COMPLIANCE_OVERVIEW --variant ytd_overview

        # Verbose output (prints rendered_query_key.key_id)
        kater run COMPLIANCE_OVERVIEW -v --shape "..."

        # Run from a git branch
        kater run COMPLIANCE_OVERVIEW --branch main

        # Run with tenant key
        kater run COMPLIANCE_OVERVIEW --tenant acme_corp

        # Limit displayed rows
        kater run COMPLIANCE_OVERVIEW --limit 10

    """
    structured = parse_run_args(
        shape=shape,
        fields=fields,
        vars=vars,
        filters=filters,
        variant=variant,
        as_of=as_of,
        combination=combination,
        no_auto_fix=no_auto_fix,
        timeframes=timeframes,
    )

    repo_root = find_repo_root()

    if verbose:
        console.print(f"[dim]Repository root: {repo_root}[/dim]")

    try:
        client = get_authenticated_client()

        # Resolve file source
        cli_id: str | None = None
        if branch:
            if verbose:
                console.print(f"[dim]Using branch: {branch}[/dim]")
        else:
            cli_id = get_cli_id()
            if cli_id is None:
                console.print(
                    "[red]No active dev session. Run `kater dev` or use `--branch <branch>`.[/red]"
                )
                raise typer.Exit(1)
            if verbose:
                console.print(f"[dim]Using dev session: {cli_id}[/dim]")

        # Resolve single connection
        conn = resolve_single_connection(client, connection)
        if verbose:
            console.print(f"[dim]Using connection: {conn.name}[/dim]")

        # Resolve query arguments into flat list
        query_names = resolve_query_args(repo_root, query, topic, conn.name)

        if verbose:
            console.print(f"[dim]Running {len(query_names)} query(ies)[/dim]")

        # Build shared SDK kwargs for file source
        source_kwargs: dict[str, Any] = {}
        if branch:
            source_kwargs["source"] = branch
        if cli_id:
            source_kwargs["x_kater_cli_id"] = cli_id

        failed_queries: list[str] = []
        batch_rows: list[BatchRow] = []

        # Story 6.1 — when the parsed request is name-free (no --shape, no
        # --combination), submit directly to the new structured render
        # endpoint. Name-based requests fall back to the legacy
        # resolve+execute path until Story 3.5's boundary adapter lands.
        use_render_endpoint = _structured_supports_render(structured) and sample is None

        for current_query in query_names:
            q_name = bare_query_name(current_query)
            query_id = str(resolve_query_name_to_id(repo_root, q_name, conn.name))

            if len(query_names) > 1:
                console.print(f"\n[bold]Running {current_query}...[/bold]")

            if sample is not None:
                _run_via_capability_sampling(
                    client=client,
                    query_id=query_id,
                    conn=conn,
                    branch=branch,
                    cli_id=cli_id,
                    n=sample,
                    current_query=current_query,
                    q_name=q_name,
                    query_names=query_names,
                    limit=limit,
                    verbose=verbose,
                    show_post_query=show_post_query,
                    failed_queries=failed_queries,
                    batch_rows=batch_rows,
                )
                continue

            if use_render_endpoint:
                _run_via_render_endpoint(
                    client=client,
                    structured=structured,
                    query_id=query_id,
                    conn=conn,
                    tenant=tenant,
                    branch=branch,
                    cli_id=cli_id,
                    current_query=current_query,
                    q_name=q_name,
                    query_names=query_names,
                    limit=limit,
                    verbose=verbose,
                    show_post_query=show_post_query,
                    failed_queries=failed_queries,
                    batch_rows=batch_rows,
                )
                continue

            # Legacy resolve+execute fallback (used for --shape, --combination).
            # Story 3.5 boundary adapter will let --shape and --combination
            # route through render too; this path is the AC6 dual-path
            # fallback documented in the story's Dev Notes.
            _run_via_legacy_resolve_execute(
                client=client,
                structured=structured,
                query_id=query_id,
                conn=conn,
                tenant=tenant,
                source_kwargs=source_kwargs,
                current_query=current_query,
                q_name=q_name,
                query_names=query_names,
                limit=limit,
                verbose=verbose,
                failed_queries=failed_queries,
                batch_rows=batch_rows,
            )

        display_batch_summary(batch_rows, mode="run")

        if failed_queries:
            console.print(
                f"\n[red]✗[/red] {len(failed_queries)} query(ies) failed: "
                + ", ".join(failed_queries)
            )
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except kater.APITimeoutError:
        console.print("[red]Request to Kater API timed out.[/red]")
        console.print("[dim]Please try again later.[/dim]")
        raise typer.Exit(1)
    except kater.APIConnectionError:
        console.print("[red]Could not connect to the Kater API.[/red]")
        console.print("[dim]Please check your internet connection and try again.[/dim]")
        raise typer.Exit(1)
    except kater.APIStatusError as e:
        handle_compile_api_error(e)
    except TypeError as e:
        if "authentication" in str(e).lower():
            console.print(f"[red]{AUTHENTICATION_FAILED_MESSAGE}[/red]")
            raise typer.Exit(1)
        raise


def _run_via_render_endpoint(
    *,
    client: kater.Kater,
    structured: Any,
    query_id: str,
    conn: Any,
    tenant: str,
    branch: str | None,
    cli_id: str | None,
    current_query: str,
    q_name: str,
    query_names: list[str],
    limit: int | None,
    verbose: bool,
    show_post_query: bool,
    failed_queries: list[str],
    batch_rows: list[BatchRow],
) -> None:
    """Submit one query via ``POST /api/v1/compiler/render``.

    Story 6.1 — the structured render call site. Replaces the legacy
    ``resolve + execute`` two-step pattern with a single render call. The
    request body is built by ``build_rendered_query_request(...)``.
    """
    if verbose:
        console.print("[dim]Rendering query (structured render endpoint)...[/dim]")

    rendered_query_request: RenderedQueryRequestV1 = build_rendered_query_request(
        structured=structured,
        query_kater_id=query_id,
        connection_id=conn.id,
        tenant_key=tenant,
        source_branch=branch,
        cli_id=cli_id,
        legacy_combination=None,
    )

    render_result = submit_render(
        client,
        request=rendered_query_request,
        source=branch,
        cli_id=cli_id,
    )

    render_key_id = getattr(
        getattr(render_result, "rendered_query_key", None),
        "key_id",
        None,
    )

    if render_result.success:
        shape_label = format_shape_label(structured)
        combo_label = f" [{shape_label}]" if shape_label else ""
        if len(query_names) > 1:
            console.print(f"[green]✓[/green] {q_name}{combo_label}")
        _display_render_results(render_result, limit=limit, show_post_query=show_post_query)
        batch_rows.append(
            BatchRow(
                query_name=current_query,
                shape_label=shape_label,
                status="ok",
                row_count=render_result.row_count,
                execution_time_ms=render_result.execution_time_ms,
                cache_hit=render_result.cache_hit,
                rendered_query_key_id=render_key_id,
            )
        )
    else:
        display_compile_errors(render_result.errors or [])
        failed_queries.append(current_query)
        batch_rows.append(
            BatchRow(
                query_name=current_query,
                shape_label=format_shape_label(structured),
                status="fail",
                rendered_query_key_id=render_key_id,
            )
        )


def _run_via_legacy_resolve_execute(
    *,
    client: kater.Kater,
    structured: Any,
    query_id: str,
    conn: Any,
    tenant: str,
    source_kwargs: dict[str, Any],
    current_query: str,
    q_name: str,
    query_names: list[str],
    limit: int | None,
    verbose: bool,
    failed_queries: list[str],
    batch_rows: list[BatchRow],
) -> None:
    """Submit one query via ``resolve + execute`` (legacy fallback path).

    Story 6.1 — kept alive while Story 3.5's boundary adapter is unmerged
    so ``--shape`` and ``--combination`` invocations still work. Story 7.5
    deletes this helper once the adapter ships and every invocation routes
    through ``_run_via_render_endpoint``.
    """
    combinations_to_run: list[str | None] = [to_legacy_combination_string(structured)]

    for combo_str in combinations_to_run:
        resolve_kwargs: dict[str, Any] = {}
        if combo_str:
            resolve_kwargs["combination"] = combo_str
        if structured.filter_state:
            resolve_kwargs["filter_state"] = structured.filter_state
        if structured.as_of:
            resolve_kwargs["as_of"] = structured.as_of
        resolve_kwargs["auto_fix"] = structured.auto_fix

        if verbose:
            console.print("[dim]Resolving query template...[/dim]")

        resolve_result = client.v1.compiler.resolve(
            connection_id=conn.id,
            query_id=query_id,
            **resolve_kwargs,
            **source_kwargs,
        )

        if verbose:
            resolved_key_id = getattr(
                getattr(resolve_result, "rendered_query_key", None),
                "key_id",
                None,
            )
            if resolved_key_id is not None:
                console.print(
                    f"[dim]Resolved key: {format_truncated_key_id(resolved_key_id)}[/dim]"
                )

        ref_fixes = getattr(resolve_result, "ref_fixes", None)
        if ref_fixes:
            display_ref_fixes(ref_fixes)

        if verbose:
            console.print("[dim]Executing query...[/dim]")

        execute_kwargs: dict[str, Any] = {
            "connection_id": conn.id,
            "resolved_query": resolve_result.resolved_query,
            "tenant_key": tenant,
            **source_kwargs,
        }

        execute_result = client.v1.compiler.execute(**execute_kwargs)

        execute_key_id = getattr(
            getattr(execute_result, "rendered_query_key", None),
            "key_id",
            None,
        )

        if execute_result.success:
            combo_label = f" [{combo_str}]" if combo_str else ""
            if len(query_names) > 1:
                console.print(f"[green]✓[/green] {q_name}{combo_label}")
            _display_execute_results(execute_result, limit=limit)
            batch_rows.append(
                BatchRow(
                    query_name=current_query,
                    shape_label=combo_str,
                    status="ok",
                    row_count=execute_result.row_count,
                    execution_time_ms=execute_result.execution_time_ms,
                    cache_hit=execute_result.cache_hit,
                    rendered_query_key_id=execute_key_id,
                )
            )
        else:
            display_compile_errors(execute_result.errors or [])
            failed_queries.append(current_query)
            batch_rows.append(
                BatchRow(
                    query_name=current_query,
                    shape_label=combo_str,
                    status="fail",
                    rendered_query_key_id=execute_key_id,
                )
            )


def _run_via_capability_sampling(
    *,
    client: kater.Kater,
    query_id: str,
    conn: Any,
    branch: str | None,
    cli_id: str | None,
    n: int,
    current_query: str,
    q_name: str,
    query_names: list[str],
    limit: int | None,
    verbose: bool,
    show_post_query: bool,
    failed_queries: list[str],
    batch_rows: list[BatchRow],
) -> None:
    """Submit a capability sampling request and render+execute each returned sample.

    Story 7.4 — ``kater run --sample N`` now drives the same backend
    deterministic sampling endpoint that ``kater compile --sample`` uses
    (Story 6.2). The backend returns an ordered list of
    ``RenderedQueryRequestV1``; we render each one and display its rows.
    Replaces the legacy ``client.v1.compiler.enumerate(...)`` + manual
    combination-rebuild loop.
    """
    if verbose:
        console.print(f"[dim]Requesting {n} capability-sampled selection(s) from backend...[/dim]")

    sample_response: CapabilitySampleResponse = submit_capability_sampling(
        client,
        query_kater_id=query_id,
        connection_id=conn.id,
        n=n,
        source=branch,
        cli_id=cli_id,
    )

    if sample_response.truncated:
        available = (
            sample_response.available
            if sample_response.available is not None
            else len(sample_response.samples)
        )
        stderr_console.print(
            f"[yellow]warning: --sample N truncated to {available} (requested {n})[/yellow]"
        )

    if verbose:
        console.print(f"[dim]Backend returned {len(sample_response.samples)} sample(s)[/dim]")

    for sample_request in sample_response.samples:
        render_result = submit_render(
            client,
            request=sample_request,
            source=branch,
            cli_id=cli_id,
        )

        sample_label = _format_sample_shape_label(sample_request)
        render_key_id = getattr(
            getattr(render_result, "rendered_query_key", None),
            "key_id",
            None,
        )

        ref_fixes = getattr(render_result, "ref_fixes", None)
        if ref_fixes:
            display_ref_fixes(ref_fixes)

        if render_result.success:
            combo_label = f" [{sample_label}]" if sample_label else ""
            if len(query_names) > 1:
                console.print(f"[green]✓[/green] {q_name}{combo_label}")
            _display_render_results(render_result, limit=limit, show_post_query=show_post_query)
            batch_rows.append(
                BatchRow(
                    query_name=current_query,
                    shape_label=sample_label,
                    status="ok",
                    row_count=render_result.row_count,
                    execution_time_ms=render_result.execution_time_ms,
                    cache_hit=render_result.cache_hit,
                    rendered_query_key_id=render_key_id,
                )
            )
        else:
            display_compile_errors(render_result.errors or [])
            failed_queries.append(current_query)
            batch_rows.append(
                BatchRow(
                    query_name=current_query,
                    shape_label=sample_label,
                    status="fail",
                    rendered_query_key_id=render_key_id,
                )
            )


def _format_sample_shape_label(request: RenderedQueryRequestV1) -> str | None:
    """Build a per-sample shape label from a backend-built render request.

    Mirrors ``compile.py``'s helper so batch summary rows look consistent
    between ``kater run --sample`` and ``kater compile --sample``.
    """
    if request.pinned_variant:
        return f"variant={request.pinned_variant}"

    selected_fields = list(request.field_selection.selected_fields)
    if selected_fields:
        truncated = [field.source_kater_id[:8] for field in selected_fields]
        label = ",".join(truncated)
        if any(field.modifiers for field in selected_fields):
            label += " +modifiers"
        return label

    return None
