"""Vendored compatibility module for the structured render endpoint.

Story 6.1 — when the Stainless Python SDK regen has not yet emitted
``client.v1.compiler.render(...)`` and ``kater.types.v1.RenderedQueryRequestV1``,
the CLI uses this module to talk to ``POST /api/v1/compiler/render`` directly
through ``client.post(...)``. AC13 fallback option (1).

The Pydantic models defined here mirror
``kater_core.schemas.v1.rendered_query_key.RenderedQueryRequestV1`` and the
route's ``RenderResponseModel`` exactly. They use ``extra="forbid"`` to match
the backend route. When the Stainless SDK regenerates and exposes
``client.v1.compiler.render(rendered_query_request=...)``, this module is
deleted and the call sites swap to the regenerated SDK (Story 7.6 audit
removes any compat module that survives).
"""

from typing import Any, cast

import kater
from kater._base_client import make_request_options
from pydantic import BaseModel, ConfigDict, Field

__all__ = [
    "CompilerRenderResponse",
    "FieldModifier",
    "FieldOccurrence",
    "RenderedQueryFieldSelectionV1",
    "RenderedQueryRequestDashboardV1",
    "RenderedQueryRequestPresentationV1",
    "RenderedQueryRequestResultWindowV1",
    "RenderedQueryRequestTemporalV1",
    "RenderedQueryRequestV1",
    "RuntimeFilterStateV2",
    "RuntimeVariableValueV1",
    "submit_render",
]


# ── Request-side types ────────────────────────────────────────────────


class RuntimeVariableValueV1(BaseModel):
    """Runtime variable value supplied in a ``RenderedQueryRequestV1``."""

    model_config = ConfigDict(extra="forbid")

    variable_kater_id: str | None
    query_kater_id: str
    name: str
    scope: str
    value: Any


class RuntimeFilterStateV2(BaseModel):
    """Runtime filter state entry supplied in a ``RenderedQueryRequestV1``."""

    model_config = ConfigDict(extra="allow")


class FieldModifier(BaseModel):
    """A normalized modifier applied to a source field occurrence."""

    model_config = ConfigDict(extra="forbid")

    kind: str
    value: str


class FieldOccurrence(BaseModel):
    """Semantic identity for an active output field."""

    model_config = ConfigDict(extra="forbid")

    source_kater_id: str
    modifiers: list[FieldModifier] = Field(default_factory=lambda: list[FieldModifier]())


def _empty_runtime_filter_state_list() -> list["RuntimeFilterStateV2"]:
    return []


def _empty_runtime_variable_list() -> list["RuntimeVariableValueV1"]:
    return []


def _empty_dict_str_any() -> dict[str, Any]:
    return {}


def _empty_dict_list() -> list[dict[str, Any]]:
    return []


class RenderedQueryFieldSelectionV1(BaseModel):
    """Structured field selection expressed as semantic field occurrences."""

    model_config = ConfigDict(extra="forbid")

    selected_fields: list[FieldOccurrence] = Field(default_factory=lambda: list[FieldOccurrence]())

    @property
    def selected_field_ids(self) -> list[str]:
        """Backward-compatible UUID view used by older CLI tests/callers."""
        return [field.source_kater_id for field in self.selected_fields]

    @property
    def timeframe_overrides(self) -> list["_LegacyTimeframeOverride"]:
        """Backward-compatible timeframe view derived from field modifiers."""
        overrides: list[_LegacyTimeframeOverride] = []
        for field in self.selected_fields:
            for modifier in field.modifiers:
                if modifier.kind == "timeframe":
                    overrides.append(
                        _LegacyTimeframeOverride(
                            source_kater_id=field.source_kater_id,
                            active_timeframe=modifier.value,
                        )
                    )
        return overrides


class _LegacyTimeframeOverride(BaseModel):
    """Compatibility shape for pre-field-occurrence CLI assertions."""

    model_config = ConfigDict(extra="forbid")

    source_kater_id: str
    active_timeframe: str


class RenderedQueryRequestDashboardV1(BaseModel):
    """Dashboard context block in ``RenderedQueryRequestV1``."""

    model_config = ConfigDict(extra="forbid")

    dashboard_kater_id: str | None = None
    widget_kater_id: str | None = None
    slot_name: str | None = None
    dashboard_filter_state: list[RuntimeFilterStateV2] = Field(
        default_factory=_empty_runtime_filter_state_list
    )


class RenderedQueryRequestPresentationV1(BaseModel):
    """Presentation config block in ``RenderedQueryRequestV1``."""

    model_config = ConfigDict(extra="forbid")

    display: dict[str, Any] = Field(default_factory=_empty_dict_str_any)
    chart: dict[str, Any] = Field(default_factory=_empty_dict_str_any)
    style: dict[str, Any] = Field(default_factory=_empty_dict_str_any)


class RenderedQueryRequestResultWindowV1(BaseModel):
    """Result window block in ``RenderedQueryRequestV1``."""

    model_config = ConfigDict(extra="forbid")

    sort_by: str | None = None
    sort_order: str | None = None
    cursor: str | None = None
    page_size: int | None = None


class RenderedQueryRequestTemporalV1(BaseModel):
    """Request clock block in ``RenderedQueryRequestV1``."""

    model_config = ConfigDict(extra="forbid")

    timezone: str | None = None
    as_of: str | None = None


class RenderedQueryRequestV1(BaseModel):
    """Consumer-facing request shape for ``POST /api/v1/compiler/render``."""

    model_config = ConfigDict(extra="forbid")

    connection_id: str
    query_kater_id: str
    pinned_variant: str | None = None
    field_selection: RenderedQueryFieldSelectionV1
    variables: list[RuntimeVariableValueV1] = Field(default_factory=_empty_runtime_variable_list)
    filter_state: list[RuntimeFilterStateV2] = Field(
        default_factory=_empty_runtime_filter_state_list
    )
    dashboard: RenderedQueryRequestDashboardV1 | None = None
    presentation: RenderedQueryRequestPresentationV1 = Field(
        default_factory=RenderedQueryRequestPresentationV1,
    )
    result_window: RenderedQueryRequestResultWindowV1 = Field(
        default_factory=RenderedQueryRequestResultWindowV1,
    )
    temporal: RenderedQueryRequestTemporalV1 = Field(
        default_factory=RenderedQueryRequestTemporalV1,
    )


# ── Response-side types ───────────────────────────────────────────────


class _ColumnMapEntry(BaseModel):
    model_config = ConfigDict(extra="allow")

    column_key: str | None = None
    source_kater_id: str | None = None
    modifiers: list[FieldModifier] = Field(default_factory=lambda: list[FieldModifier]())
    source_name: str
    source_label: str | None = None
    display_label: str | None = None
    field_type: str
    aggregation: str | None = None


class _CompilerErrorItem(BaseModel):
    model_config = ConfigDict(extra="allow")

    code: str | None = None
    message: str | None = None
    file: str | None = None
    line: int | None = None
    column: int | None = None
    remediation: str | None = None


class _RenderedQueryKeyV1(BaseModel):
    model_config = ConfigDict(extra="allow")

    key_id: str | None = None
    exact_cache_key_id: str | None = None
    aggregate_cache_key_id: str | None = None


def _empty_column_map_list() -> list["_ColumnMapEntry"]:
    return []


def _empty_error_list() -> list["_CompilerErrorItem"]:
    return []


class CompilerRenderResponse(BaseModel):
    """Response from ``POST /api/v1/compiler/render``."""

    model_config = ConfigDict(extra="allow")

    success: bool
    data: list[dict[str, Any]] = Field(default_factory=_empty_dict_list)
    column_map: list[_ColumnMapEntry] = Field(default_factory=_empty_column_map_list)
    widget_type: str | None = None
    config: dict[str, Any] = Field(default_factory=_empty_dict_str_any)
    style_config: dict[str, Any] = Field(default_factory=_empty_dict_str_any)
    auto_title: str | None = None
    auto_description: str | None = None
    sql: str | None = None
    errors: list[_CompilerErrorItem] = Field(default_factory=_empty_error_list)
    execution_time_ms: float = 0.0
    cache_hit: bool = False
    row_count: int = 0
    rendered_query_key: _RenderedQueryKeyV1 | None = None


# ── HTTP submission helper ────────────────────────────────────────────


def submit_render(
    client: kater.Kater,
    *,
    request: RenderedQueryRequestV1,
    source: str | None = None,
    cli_id: str | None = None,
) -> CompilerRenderResponse:
    """Submit a ``RenderedQueryRequestV1`` to ``POST /api/v1/compiler/render``.

    Story 6.1 — uses ``client.post(...)`` while the Stainless SDK regen is
    pending. When ``client.v1.compiler.render(...)`` ships, callers swap to it
    directly and this function (and module) are deleted.
    """
    extra_headers: dict[str, str] = {}
    if cli_id is not None:
        extra_headers["X-Kater-CLI-ID"] = cli_id

    query: dict[str, str] | None = {"source": source} if source is not None else None

    body = request.model_dump(mode="json", exclude_none=False)
    options = make_request_options(
        query=query,
        extra_headers=extra_headers if extra_headers else None,
    )
    response: CompilerRenderResponse = client.post(
        "/api/v1/compiler/render",
        body=cast(Any, body),
        cast_to=CompilerRenderResponse,
        options=options,
    )
    return response
