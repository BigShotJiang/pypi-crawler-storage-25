"""Authentication commands for the Kater CLI."""

import datetime
import webbrowser
from enum import Enum
from urllib.parse import parse_qsl, urlencode, urlsplit, urlunsplit

import typer
from rich.console import Console

from kater_cli.auth.messages import NOT_LOGGED_IN_MESSAGE
from kater_cli.auth.oauth import run_oauth_flow
from kater_cli.auth.token_manager import TokenManager
from kater_cli.config import get_settings

console = Console()


class SignupPlan(str, Enum):
    """Plan choices understood by the landing signup flow."""

    starter = "starter"
    pro = "pro"


class SignupBillingInterval(str, Enum):
    """Billing interval choices understood by the landing signup flow."""

    monthly = "monthly"
    yearly = "yearly"


def login() -> None:
    """Log in to Kater via browser-based OAuth."""
    token_manager = TokenManager()

    if token_manager.has_tokens():
        token_manager.clear_tokens()

    success = run_oauth_flow()
    if not success:
        raise typer.Exit(1)


def signup(
    plan: SignupPlan = typer.Option(
        SignupPlan.pro,
        "--plan",
        help="Plan to preselect on the signup page.",
    ),
    billing: SignupBillingInterval = typer.Option(
        SignupBillingInterval.yearly,
        "--billing",
        help="Billing interval to preselect on the signup page.",
    ),
    no_browser: bool = typer.Option(
        False,
        "--no-browser",
        help="Print the signup URL instead of opening the signup page.",
    ),
    skip_login: bool = typer.Option(
        False,
        "--skip-login",
        help="Open signup only, without authenticating this CLI afterwards.",
    ),
) -> None:
    """Create a Kater account through the browser and authenticate this CLI."""
    settings = get_settings()
    signup_url = _build_signup_url(settings.signup_url, plan, billing)

    console.print("Complete signup in your browser.")
    if no_browser:
        console.print(f"[dim]Sign up here: {signup_url}[/dim]")
    else:
        console.print(f"[dim]If your browser doesn't open, visit: {signup_url}[/dim]")
        webbrowser.open(signup_url)

    if skip_login:
        console.print("Run [bold cyan]kater login[/bold cyan] when you are ready to authenticate.")
        return

    should_login = typer.confirm("After signup is complete, log this CLI in now?", default=True)
    if not should_login:
        console.print("Run [bold cyan]kater login[/bold cyan] when you are ready to authenticate.")
        return

    token_manager = TokenManager()
    if token_manager.has_tokens():
        token_manager.clear_tokens()

    success = run_oauth_flow()
    if not success:
        raise typer.Exit(1)


def logout() -> None:
    """Log out and clear stored credentials."""
    token_manager = TokenManager()

    if not token_manager.has_tokens():
        console.print("[yellow]You are not logged in.[/yellow]")
        return

    token_manager.clear_tokens()
    console.print("[green]Successfully logged out.[/green]")


def status() -> None:
    """Check authentication status without making an API call."""
    token_manager = TokenManager()
    is_authenticated, expires_at = token_manager.get_token_status()

    if not is_authenticated:
        console.print("[yellow]Not logged in.[/yellow]")
        console.print(NOT_LOGGED_IN_MESSAGE)
        return

    console.print("[green]Logged in.[/green]")

    if expires_at:
        expires_dt = datetime.datetime.fromtimestamp(expires_at, tz=datetime.UTC)
        now = datetime.datetime.now(tz=datetime.UTC)

        if expires_dt <= now:
            console.print("[yellow]Token expired. Will refresh on next API call.[/yellow]")
        else:
            delta = expires_dt - now
            if delta.total_seconds() < 300:
                console.print(f"[yellow]Token expires soon ({_format_timedelta(delta)}).[/yellow]")
            else:
                console.print(f"Token expires in {_format_timedelta(delta)}.")


def _format_timedelta(delta: datetime.timedelta) -> str:
    """Format a timedelta for display."""
    total_seconds = int(delta.total_seconds())
    if total_seconds < 60:
        return f"{total_seconds}s"
    minutes = total_seconds // 60
    if minutes < 60:
        return f"{minutes}m"
    hours = minutes // 60
    remaining_minutes = minutes % 60
    if remaining_minutes:
        return f"{hours}h {remaining_minutes}m"
    return f"{hours}h"


def _build_signup_url(
    signup_url: str,
    plan: SignupPlan,
    billing: SignupBillingInterval,
) -> str:
    """Return a signup URL with CLI-selected plan and billing params."""
    parsed = urlsplit(signup_url)
    query = dict(parse_qsl(parsed.query, keep_blank_values=True))
    query["plan"] = plan.value
    query["billing"] = billing.value
    query["product_line"] = "cloud"
    return urlunsplit(
        (
            parsed.scheme,
            parsed.netloc,
            parsed.path,
            urlencode(query),
            parsed.fragment,
        )
    )
