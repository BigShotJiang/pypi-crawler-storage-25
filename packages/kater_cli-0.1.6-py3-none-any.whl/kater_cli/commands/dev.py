"""kater dev command - syncs local files to Kater platform.

Story: 3-5-kater-dev-command-entry-point
Orchestrates file sync, WebSocket connection, and file watching.
"""

import asyncio
import fnmatch
import logging  # noqa: TID251 - scopes internal service loggers after configuring structlog.
import random
from datetime import datetime
from pathlib import Path
from typing import Any, cast

import typer
import yaml
from kater_utils.logging import configure_logging
from rich.console import Console
from rich.panel import Panel
from rich.text import Text

from kater_cli.auth.messages import NOT_LOGGED_IN_MESSAGE, REAUTH_MESSAGE
from kater_cli.auth.token_manager import TokenManager, get_or_create_cli_id
from kater_cli.commands._display import display_build_result, display_validation_result
from kater_cli.config import get_settings
from kater_cli.repo import find_repo_root
from kater_cli.services.dev_file_watcher import DevFileWatcher
from kater_cli.services.file_sync import FileEntry, FileSyncService
from kater_cli.services.ws_dev_client import (
    AuthenticationError,
    SessionReadyTimeoutError,
    SessionSetupError,
    WsDevClient,
)

console = Console()

_INTERNAL_DEV_LOGGER_NAMES = (
    "kater_cli.services.ws_dev_client",
    "kater_cli.services.dev_file_watcher",
)
_SUPPRESS_INTERNAL_DEV_LOG_LEVEL = 100


class _InternalDevLogFilter(logging.Filter):
    """Drop internal dev transport logs from normal user-facing CLI output."""

    def filter(self, record: logging.LogRecord) -> bool:
        return not _is_internal_dev_logger_name(record.name)


def _is_internal_dev_logger_name(logger_name: str) -> bool:
    return any(
        logger_name == internal_name or logger_name.startswith(f"{internal_name}.")
        for internal_name in _INTERNAL_DEV_LOGGER_NAMES
    )


def _configure_internal_dev_loggers(*, verbose: bool) -> None:
    """Hide internal dev transport logs in normal CLI output."""
    log_level = logging.DEBUG if verbose else _SUPPRESS_INTERNAL_DEV_LOG_LEVEL
    for logger_name in _INTERNAL_DEV_LOGGER_NAMES:
        logging.getLogger(logger_name).setLevel(log_level)

    if verbose:
        return

    for handler in logging.getLogger().handlers:
        if not any(isinstance(existing, _InternalDevLogFilter) for existing in handler.filters):
            handler.addFilter(_InternalDevLogFilter())


_BANNER = """\

            #####
          #########
     ###################
   #######################
  #########################
  #########  ###  #########
   ########  ###  ########
    #######  ###  #######
      #####  ###  #####
      #################
      #################
      #################
       ###############
                          """

_QUOTES = [
    "Mass-emailing a CSV is not a data governance strategy, Greg.",
    "Our dashboard has 47 widgets. Nobody knows what 38 of them mean. Including the person who built them.",
    "The data pipeline is fine. The data pipeline is always fine.",
    "Debuggers don't solve problems. They just show them in slow motion.",
    "Sure...we can ship that by the target date with the features you requested...",
    "Stakeholder: 'Can we just add a small feature?' Narrator: It was not a small feature.",
    "Your data called. It's tired of living in 14 Google Sheets with conflicting numbers.",
    "Just deployed to prod on a Friday. Pray for me.",
    "'Works on my machine' is technically a valid deployment strategy if you ship the machine.",
    "The best error messages are the ones written by someone who's clearly been hurt before.",
    "We called the meeting to discuss why we have too many meetings. It ran 30 minutes over.",
    "SELECT * FROM motivation WHERE deadline = NOW(); -- 0 rows returned",
    "def meaning_of_life(): return 42  # reviewer approved without comment, which is suspicious",
    "Every great dish starts with quality ingredients. Every great insight starts with quality data.",
    'Gordon Ramsay voice: "This data is RAW!!!"',
]


def _print_banner() -> None:
    quote = random.choice(_QUOTES)  # noqa: S311
    content = Text.assemble(
        Text("  Welcome, developer.\n", style="bold #DF644A"),
        Text(_BANNER, style="bold white"),
    )
    console.print(Panel(content, border_style="#DF644A", padding=(0, 2), expand=False))
    console.print(Text(f'  "{quote}"', style="italic dim"))
    console.print()


# Must stay in sync with packages/components_core/src/theme/theme-registry.ts
_KNOWN_PRESET_THEMES = frozenset(
    {
        "kater",
        "shadcn",
        "solar-dusk",
        "modern-minimal",
        "seagreen",
        "caffeine",
        "darkmatter",
        "graphite",
        "vercel",
        "sage-garden",
        "twitter",
        "corporate",
        "notebook",
        "mono-currency",
        "spring",
    }
)

# Patterns for .kater/ artifacts that should NOT trigger file_sync.
# These are written by the server's write-back handler and must not loop back.
_KATER_ARTIFACT_PATTERNS = (
    "*/.kater/manifest.yaml",
    "*/.kater/dependency-graph.yaml",
    ".kater/manifest.yaml",
    ".kater/dependency-graph.yaml",
)


def _should_ignore_path(path: str) -> bool:
    """Check if a file path matches a .kater/ artifact that should not be synced.

    Prevents write-back loops: when the CLI writes .kater/manifest.yaml or
    .kater/dependency-graph.yaml to disk, the file watcher must NOT send
    those files back to the server.

    Args:
        path: Relative file path (POSIX format).

    Returns:
        True if the path should be ignored for file sync purposes.
    """
    return any(fnmatch.fnmatch(path, pattern) for pattern in _KATER_ARTIFACT_PATTERNS)


def _get_custom_theme_names(repo_root: Path) -> list[str]:
    """Return sorted list of custom theme directory names."""
    custom_dir = repo_root / "theme" / "custom-themes"
    if not custom_dir.is_dir():
        return []
    return sorted(d.name for d in custom_dir.iterdir() if d.is_dir())


def dev(
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable debug logging"),
) -> None:
    """Sync your local files to the Kater platform.

    Establishes a WebSocket connection to sync repository files,
    then watches for changes and syncs them in real-time.
    """
    # Configure structlog: DEBUG when verbose, WARNING otherwise.
    configure_logging(log_level="DEBUG" if verbose else "WARNING", json_logs=False)
    _configure_internal_dev_loggers(verbose=verbose)

    base_path = find_repo_root()

    # Get or create CLI identity
    cli_id = get_or_create_cli_id()
    console.print(f"[green]✓[/green] CLI ID: [bold]{cli_id}[/bold]")

    # Run the async event loop
    try:
        asyncio.run(_run_dev_session(base_path, cli_id, verbose))
    except AuthenticationError as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from None
    except (ConnectionError, SessionReadyTimeoutError, SessionSetupError) as exc:
        console.print(f"[red]{exc}[/red]")
        raise typer.Exit(1) from None
    except KeyboardInterrupt:
        console.print("\n[yellow]Disconnected from Kater[/yellow]")


async def _run_dev_session(
    base_path: Path,
    cli_id: str,
    verbose: bool,
) -> None:
    """Main async loop for dev session.

    Args:
        base_path: Repository root directory.
        cli_id: CLI identity string.
        verbose: Whether to enable debug logging.
    """
    settings = get_settings()

    # Single TokenManager instance for both initial token and background refresh.
    token_manager = TokenManager()
    had_tokens = token_manager.has_tokens()
    access_token = token_manager.get_access_token()
    if not access_token:
        if had_tokens:
            raise AuthenticationError(REAUTH_MESSAGE)
        raise AuthenticationError(NOT_LOGGED_IN_MESSAGE)

    file_sync = FileSyncService(base_path)
    ws_client = WsDevClient(
        settings.api_url,
        access_token,
        cli_id,
        token_provider=token_manager.get_access_token,
        token_refresher=token_manager.force_refresh_access_token,
    )
    file_watcher = DevFileWatcher(base_path, file_sync)

    # State for sync orchestration
    sync_state = {
        "connected": False,
        "cached_file_count": 0,
    }

    # Wire up callbacks
    def on_session_ready(received_cli_id: str, cached_count: int) -> None:
        sync_state["connected"] = True
        sync_state["cached_file_count"] = cached_count
        console.print("[green]✓[/green] Connected to Kater server")
        # Trigger sync decision in main loop
        asyncio.create_task(_perform_initial_sync(file_sync, ws_client, cached_count, verbose))

    def on_need_files(paths: list[str]) -> None:
        asyncio.create_task(_send_requested_files(file_sync, ws_client, paths))

    def on_sync_ack(
        status: str,
        path: str | None,
        file_count: int | None,
        content_changed: bool | None = None,
        content_changed_count: int | None = None,
    ) -> None:
        if file_count is not None:
            _print_sync_summary(file_count, sync_state["cached_file_count"], content_changed_count)

    def on_error(code: str, message: str) -> None:
        console.print(f"[red]Error ({code}): {message}[/red]")

    def on_file_changed(path: str, content: bytes, hash_: str) -> None:
        if _should_ignore_path(path):
            return
        asyncio.create_task(
            _handle_file_change(ws_client, path, content, hash_, verbose, base_path)
        )

    def on_file_deleted(path: str) -> None:
        if _should_ignore_path(path):
            return
        asyncio.create_task(_handle_file_delete(ws_client, path, verbose, base_path))

    def on_branch_switched(branch_name: str | None) -> None:
        asyncio.create_task(_handle_branch_switch(file_sync, ws_client, verbose, branch_name))

    def on_write_back(
        request_id: str,
        connection_folder: str,
        files: list[dict[str, str | bool]],
        suppress_paths: list[str] | None = None,
    ) -> None:
        # Register suppress_paths with the file watcher BEFORE writing files,
        # so the watcher ignores the filesystem events caused by write-back.
        if suppress_paths:
            file_watcher.suppress_paths(suppress_paths)
        asyncio.create_task(
            _handle_write_back(ws_client, base_path, request_id, connection_folder, files, verbose)
        )

    def on_validation_result(data: dict[str, Any]) -> None:
        display_validation_result(data, repo_root=base_path)

    def on_build_result(data: dict[str, Any]) -> None:
        display_build_result(data, repo_root=base_path)

    def on_reconnected() -> None:
        asyncio.create_task(
            _handle_branch_switch(file_sync, ws_client, verbose, file_watcher.get_branch_name())
        )

    # Set callbacks
    ws_client.on_session_ready = on_session_ready
    ws_client.on_need_files = on_need_files
    ws_client.on_sync_ack = on_sync_ack
    ws_client.on_error = on_error
    ws_client.on_write_back = on_write_back
    ws_client.on_validation_result = on_validation_result
    ws_client.on_build_result = on_build_result
    ws_client.on_reconnected = on_reconnected

    file_watcher.on_file_changed = on_file_changed
    file_watcher.on_file_deleted = on_file_deleted
    file_watcher.on_branch_switched = on_branch_switched

    # Start background token refresh to keep the token fresh for reconnections
    token_manager.start_background_refresh()

    try:
        # Connect and start receiving
        initial_branch_name = file_watcher.get_branch_name()
        await ws_client.connect()
        await ws_client.start()
        await ws_client.send_connect(branch_name=initial_branch_name, workspace_root=str(base_path))
        await ws_client.wait_for_session_ready()

        # Start file watcher
        await file_watcher.start()

        # Keep running until interrupted
        while True:
            if ws_client.fatal_error is not None:
                raise ws_client.fatal_error
            await asyncio.sleep(1)

    finally:
        token_manager.stop_background_refresh()
        await file_watcher.stop()
        await ws_client.stop()


async def _perform_initial_sync(
    file_sync: FileSyncService,
    ws_client: WsDevClient,
    cached_count: int,
    verbose: bool = False,
) -> None:
    """Perform initial sync based on cached file count.

    Args:
        file_sync: File sync service.
        ws_client: WebSocket client.
        cached_count: Number of files cached on server.
        verbose: Whether to enable debug logging.
    """
    if verbose:
        console.print("[dim]Performing initial sync...[/dim]")

    if cached_count == 0:
        # Full sync - send all files
        files = file_sync.scan_repo()
        total_bytes = sum(len(f["content"]) for f in files)
        console.print(f"[green]✓[/green] Synced {len(files)} files ({_format_bytes(total_bytes)})")
        await ws_client.send_full_sync(files)
    else:
        # Delta sync - send manifest only
        manifest = file_sync.get_file_manifest()
        await ws_client.send_delta_sync(manifest)

    # Print banner
    settings = get_settings()
    portal_url = f"{settings.resolved_app_url}/developer-portal"

    console.print()
    _print_banner()
    _print_theme_info(file_sync.root_path)
    console.print("  Your local files are now live on Kater.")
    console.print("  Any local changes will sync automatically.")
    console.print()
    console.print(f"  Open in Developer Portal: [link={portal_url}]{portal_url}[/link]")
    console.print()
    console.print("  Press Ctrl+C to disconnect (your files will stay cached on the server).")
    console.print()
    console.print("Watching for changes...")


async def _send_requested_files(
    file_sync: FileSyncService,
    ws_client: WsDevClient,
    paths: list[str],
) -> None:
    """Send files requested by server after delta sync.

    Args:
        file_sync: File sync service.
        ws_client: WebSocket client.
        paths: File paths requested by server.
    """
    for path in paths:
        try:
            entry = file_sync.read_and_hash_file(path)
            await ws_client.send_file_sync(entry)
        except FileNotFoundError:
            # File may have been deleted since manifest was sent
            pass


async def _handle_file_change(
    ws_client: WsDevClient,
    path: str,
    content: bytes,
    hash_: str,
    verbose: bool = False,
    repo_root: Path | None = None,
) -> None:
    """Handle file change from watcher.

    Args:
        ws_client: WebSocket client.
        path: Relative file path.
        content: File content.
        hash_: SHA-256 hash.
        verbose: Whether to enable debug logging.
        repo_root: Repository root for clickable file links.
    """
    entry: FileEntry = {"path": path, "content": content, "hash": hash_}
    await ws_client.send_file_sync(entry)
    _print_file_change(path, "Changed", repo_root)
    if verbose:
        console.print(f"    [dim]{len(content)} bytes[/dim]")


async def _handle_file_delete(
    ws_client: WsDevClient,
    path: str,
    verbose: bool = False,
    repo_root: Path | None = None,
) -> None:
    """Handle file deletion from watcher.

    Args:
        ws_client: WebSocket client.
        path: Relative file path.
        verbose: Whether to enable debug logging.
        repo_root: Repository root for clickable file links.
    """
    await ws_client.send_file_delete(path)
    _print_file_change(path, "Deleted", repo_root)


async def _handle_write_back(
    ws_client: WsDevClient,
    base_path: Path,
    request_id: str,
    connection_folder: str,
    files: list[dict[str, str | bool]],
    verbose: bool = False,
) -> None:
    """Handle write_back message by writing files to local filesystem.

    Args:
        ws_client: WebSocket client (for sending ack).
        base_path: Repository root directory.
        request_id: Write-back request ID for correlation.
        connection_folder: Connection folder prefix for file paths.
        files: List of dicts with 'path', 'content', and optional 'deleted' keys.
        verbose: Whether to enable debug logging.
    """
    changes_applied = 0
    files_written = 0
    files_deleted = 0
    success = True

    for file_info in files:
        file_path: str = str(file_info.get("path", ""))
        content: str = str(file_info.get("content", ""))
        deleted: bool = bool(file_info.get("deleted", False))

        if not file_path:
            continue

        # Build full path: base_path / connection_folder / file path
        full_path: Path
        if connection_folder:
            full_path = base_path / connection_folder / file_path
        else:
            full_path = base_path / file_path

        # Validate path doesn't escape repo root
        try:
            resolved: Path = full_path.resolve()
            resolved.relative_to(base_path.resolve())
        except ValueError:
            console.print(f"[red]Write-back path traversal rejected: {file_path}[/red]")
            success = False
            continue

        try:
            if deleted:
                if resolved.exists():
                    resolved.unlink()
                    stop_dir = (
                        (base_path / connection_folder).resolve()
                        if connection_folder
                        else base_path.resolve()
                    )
                    parent = resolved.parent
                    while parent != stop_dir:
                        try:
                            parent.rmdir()
                        except OSError:
                            break
                        parent = parent.parent
                files_deleted += 1
                changes_applied += 1
            else:
                resolved.parent.mkdir(parents=True, exist_ok=True)
                resolved.write_text(str(content))
                files_written += 1
                changes_applied += 1
        except OSError as e:
            console.print(f"[red]Write-back failed for {file_path}: {e}[/red]")
            success = False

    # Send acknowledgment
    await ws_client.send_write_ack(request_id, success, changes_applied)

    if changes_applied > 0:
        timestamp = datetime.now().strftime("%H:%M:%S")
        parts: list[str] = []
        if files_written > 0:
            parts.append(f"{files_written} written")
        if files_deleted > 0:
            parts.append(f"{files_deleted} deleted")
        detail = ", ".join(parts)
        console.print(f"  [{timestamp}] Write-back: {changes_applied} file(s) synced ({detail})")

        if verbose:
            for file_info in files:
                fp = str(file_info.get("path", ""))
                if not fp:
                    continue
                if file_info.get("deleted", False):
                    console.print(f"    [dim]Delete: {fp}[/dim]")
                else:
                    console.print(f"    [dim]Write: {fp}[/dim]")


async def _handle_branch_switch(
    file_sync: FileSyncService,
    ws_client: WsDevClient,
    verbose: bool = False,
    branch_name: str | None = None,
) -> None:
    """Handle branch switch by sending branch update and triggering delta sync.

    Args:
        file_sync: File sync service.
        ws_client: WebSocket client.
        verbose: Whether to enable debug logging.
        branch_name: New git branch name (if available).
    """
    console.print("[dim]Branch switch detected, syncing...[/dim]")
    if branch_name:
        await ws_client.send_branch_switch(branch_name)
    manifest = file_sync.get_file_manifest()
    if verbose:
        console.print(f"[dim]Sending delta sync with {len(manifest)} files[/dim]")
    await ws_client.send_delta_sync(manifest)


_DEFAULT_FALLBACK_THEME = "kater"


def _print_theme_info(repo_root: Path) -> None:
    """Print loaded theme name and theme files in the dev session banner."""
    config_path = repo_root / "kater.config.yaml"
    if not config_path.exists():
        return

    try:
        data = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        return

    if not isinstance(data, dict):
        return

    config = cast(dict[str, object], data)
    theme_name = config.get("theme")
    if not isinstance(theme_name, str) or not theme_name.strip():
        return

    theme_name = theme_name.strip()
    custom_names = _get_custom_theme_names(repo_root)
    is_preset = theme_name in _KNOWN_PRESET_THEMES
    is_custom = not is_preset and theme_name in custom_names

    # Print theme validity warnings right above "Loaded Theme:"
    theme_warnings: list[str] = []
    if not is_preset and not is_custom:
        config_link = f"[link=file://{config_path}]kater.config.yaml[/link]"
        theme_warnings.append(
            f"In {config_link}, theme '{theme_name}' is not a known preset "
            f"or custom theme. Falling back to preset '{_DEFAULT_FALLBACK_THEME}' theme."
        )

    if theme_warnings:
        for w in theme_warnings:
            console.print(f"  [bold yellow]WARNING:[/bold yellow] {w}")
        console.print(f"  Known presets: {', '.join(sorted(_KNOWN_PRESET_THEMES))}")
        if custom_names:
            console.print(f"  Known custom themes: {', '.join(custom_names)}")
        console.print("  Run [bold]kater build --fix[/bold] to auto-fix this.")
        console.print()

    # Determine effective theme and label (theme name links to kater.config.yaml)
    theme_link = f"[link=file://{config_path}][bold]{{name}}[/bold][/link]"
    if not is_preset and not is_custom:
        effective_theme = _DEFAULT_FALLBACK_THEME
        label = (
            f"{theme_link.format(name=_DEFAULT_FALLBACK_THEME)} "
            f"(preset, fallback since [red]'{theme_name}'[/red] not found)"
        )
    elif is_preset:
        effective_theme = theme_name
        label = f"{theme_link.format(name=theme_name)} (preset)"
    else:
        effective_theme = theme_name
        label = f"{theme_link.format(name=theme_name)} (custom)"

    console.print(f"  Loaded Theme: {label}")

    # List theme files
    config_link = f"[link=file://{config_path}]kater.config.yaml[/link]"
    console.print(f"    [dim]{config_link}[/dim]")

    if is_custom:
        custom_dir = repo_root / "theme" / "custom-themes" / effective_theme
        if custom_dir.is_dir():
            theme_files = sorted(
                str(f.relative_to(repo_root)) for f in custom_dir.rglob("*") if f.is_file()
            )
            for tf in theme_files:
                abs_path = repo_root / tf
                console.print(f"    [dim][link=file://{abs_path}]{tf}[/link][/dim]")

    # Show shared theme files
    shared_files = [
        repo_root / "theme" / "layout.yaml",
    ]
    for sf in shared_files:
        if sf.exists():
            rel = sf.relative_to(repo_root)
            console.print(f"    [dim][link=file://{sf}]{rel}[/link][/dim]")

    console.print()


def _print_file_change(path: str, action: str, repo_root: Path | None = None) -> None:
    """Print file change with timestamp.

    Args:
        path: Relative file path.
        action: Action type (Changed, Deleted).
        repo_root: Repository root for clickable file links.
    """
    timestamp = datetime.now().strftime("%H:%M:%S")
    if repo_root:
        abs_path = repo_root / path
        console.print(f"  [{timestamp}] {action}: [link=file://{abs_path}]{path}[/link]")
    else:
        console.print(f"  [{timestamp}] {action}: {path}")


def _print_sync_summary(
    file_count: int,
    cached_count: int,
    content_changed_count: int | None = None,
) -> None:
    """Print sync summary for delta sync.

    Args:
        file_count: Number of files synced.
        cached_count: Number of files that were already cached.
        content_changed_count: Number of files whose content actually changed (from sync_ack).
    """
    if cached_count > 0:
        if content_changed_count is not None:
            if content_changed_count == 0:
                console.print(
                    f"[green]✓[/green] Resuming session — synced {file_count} files "
                    f"[dim]— no changes[/dim]"
                )
            else:
                console.print(
                    f"[green]✓[/green] Resuming session — synced {file_count} files "
                    f"— {content_changed_count} changed"
                )
        else:
            # Fallback for old servers that don't send content_changed_count
            unchanged = max(0, cached_count - file_count)
            console.print(
                f"[green]✓[/green] Resuming session — synced {file_count} changed files, "
                f"{unchanged} unchanged"
            )


def _format_bytes(size: int) -> str:
    """Format byte size for display.

    Args:
        size: Size in bytes.

    Returns:
        Human-readable size string.
    """
    if size < 1024:
        return f"{size} B"
    elif size < 1024 * 1024:
        return f"{size / 1024:.1f} KB"
    else:
        return f"{size / (1024 * 1024):.1f} MB"
