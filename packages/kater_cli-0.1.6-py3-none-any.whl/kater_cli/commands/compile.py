"""Command for compiling a query template to SQL."""

from pathlib import Path
from typing import Any, Optional, cast

import kater
import typer
import yaml
from rich.console import Console
from kater.types.v1.compiler_compile_params import ResolvedQuery as CompileResolvedQuery

from kater_cli.auth.messages import AUTHENTICATION_FAILED_MESSAGE
from kater_cli.client import get_authenticated_client
from kater_cli.commands._capability_sampling import (
    CapabilitySampleResponse,
    submit_capability_sampling,
)
from kater_cli.commands._sdk_compat import (
    CompilerRenderResponse,
    RenderedQueryRequestV1,
    submit_render,
)
from kater_cli.commands._shared import (
    BatchRow,
    bare_query_name,
    build_rendered_query_request,
    display_batch_summary,
    display_compile_errors,
    display_ref_fixes,
    format_shape_label,
    format_truncated_key_id,
    get_cli_id,
    handle_compile_api_error,
    parse_compile_args,
    resolve_single_connection,
    stderr_console,
    to_legacy_combination_string,
)
from kater_cli.repo import (
    find_connection_folder_local,
    find_repo_root,
    find_topic_folder_local,
    resolve_query_name_to_id,
)

console = Console()


def _discover_topic_queries(repo_root: Path, connection_name: str, topic_name: str) -> list[str]:
    """Discover all query names within a topic's queries/ directory.

    Returns a list of query names extracted from the 'name' field in each YAML file.
    """
    try:
        connection_path = find_connection_folder_local(repo_root, connection_name)
    except FileNotFoundError:
        console.print(
            f"[red]No connection folder found for '{connection_name}' in {repo_root}.[/red]"
        )
        raise typer.Exit(1)

    try:
        topic_path = find_topic_folder_local(connection_path, topic_name)
    except FileNotFoundError:
        console.print(
            f"[red]No topic folder found for '{topic_name}' under {connection_path}.[/red]"
        )
        raise typer.Exit(1)

    queries_dir = topic_path / "queries"

    if not queries_dir.is_dir():
        console.print(f"[red]No queries directory found at {queries_dir}[/red]")
        raise typer.Exit(1)

    query_names: list[str] = []
    for yaml_file in sorted(queries_dir.rglob("*.yaml")):
        try:
            data = yaml.safe_load(yaml_file.read_text())
            if isinstance(data, dict) and "name" in data:
                query_names.append(str(data["name"]))  # type: ignore[reportUnknownArgumentType]
        except yaml.YAMLError:
            console.print(f"[yellow]Warning: Could not parse {yaml_file}[/yellow]")

    if not query_names:
        console.print(f"[red]No queries found in topic '{topic_name}'[/red]")
        raise typer.Exit(1)

    return query_names


def _discover_folder_queries(repo_root: Path, folder_path: str) -> list[str]:
    """Discover query names from YAML files under a folder path.

    Lists all .yaml files recursively, filters to files that parse as
    query schemas (have a 'name' field), and returns query names.

    Args:
        repo_root: Repository root directory.
        folder_path: Relative folder path (e.g., 'topics/compliance/queries/').

    Returns:
        List of query names found.
    """
    target_dir = repo_root / folder_path

    if not target_dir.is_dir():
        console.print(f"[red]Directory not found: {target_dir}[/red]")
        raise typer.Exit(1)

    query_names: list[str] = []
    for yaml_file in sorted(target_dir.rglob("*.yaml")):
        try:
            data = yaml.safe_load(yaml_file.read_text())
            if isinstance(data, dict) and "name" in data:
                query_names.append(str(data["name"]))  # type: ignore[reportUnknownArgumentType]
        except yaml.YAMLError:
            console.print(f"[yellow]Warning: Could not parse {yaml_file}[/yellow]")

    if not query_names:
        console.print(f"[red]No queries found under '{folder_path}'[/red]")
        raise typer.Exit(1)

    return query_names


def resolve_query_args(
    repo_root: Path,
    queries: list[str] | None,
    topic: str | None,
    connection_name: str,
) -> list[str]:
    """Resolve query arguments into a flat list of query names.

    Handles: single names, multiple names, folder paths, and --topic flag.
    """
    if topic:
        return _discover_topic_queries(repo_root, connection_name, topic)

    if not queries:
        console.print(
            "[red]Provide a query name, folder path, or use --topic to compile all queries in a topic.[/red]"
        )
        raise typer.Exit(1)

    all_names: list[str] = []
    for arg in queries:
        # Check if it's a folder path (ends with / or is an existing directory)
        if arg.endswith("/") or (repo_root / arg).is_dir():
            all_names.extend(_discover_folder_queries(repo_root, arg))
        else:
            all_names.append(arg)

    return all_names


def compile_query(
    query: Optional[list[str]] = typer.Argument(
        None,
        help=(
            "Query name(s) or folder path(s). "
            "Examples: COMPLIANCE_OVERVIEW, topics/compliance/queries/"
        ),
    ),
    connection: str | None = typer.Option(
        None,
        "--connection",
        "-c",
        help="Connection name. Auto-selected if only one exists.",
    ),
    topic: str | None = typer.Option(
        None,
        "--topic",
        help="Topic name. Compiles all queries within the specified topic.",
    ),
    branch: str | None = typer.Option(
        None,
        "--branch",
        "-b",
        help="Git branch to compile from (alternative to running kater dev).",
    ),
    tenant: str = typer.Option(
        ...,
        "--tenant",
        "-t",
        help="Tenant key for multi-tenant compilation. Use 'kater_global_tenant' for non-tenancy clients.",
    ),
    shape: str | None = typer.Option(
        None,
        "--shape",
        help=(
            "Field selection in name-based shape grammar "
            "(`dimension=name,measure=name,calculation=name`). "
            "Accepts inline scalar variable assignments. Example: "
            "'dimension=department,measure=compliance_rate,timeframe=month'."
        ),
    ),
    fields: list[str] = typer.Option(
        [],
        "--field",
        help=(
            "Adds an optional field by kater_id (UUID). Repeatable. "
            "Mutually exclusive with --shape; UUID escape hatch for tooling."
        ),
    ),
    timeframes: list[str] = typer.Option(
        [],
        "--timeframe",
        help=(
            "Sets a temporal modifier as '<source_kater_id>=<grain>'. "
            "Repeatable. Only valid with --field; structured shapes carry "
            "modifier values on their field occurrences. Grain is one of "
            "raw, date, day, week, month, quarter, year, day_of_week, hour."
        ),
    ),
    vars: list[str] = typer.Option(
        [],
        "--var",
        help=(
            "Sets a variable as 'name=value'. Repeatable. Combines with "
            "inline --shape variables; structured --var wins on conflict."
        ),
    ),
    filters: list[str] = typer.Option(
        [],
        "--filter",
        help=(
            "Sets a runtime filter as 'name:enabled=<bool>,value=<json>'. "
            "Both segments optional. Filters cannot be inlined in --shape."
        ),
    ),
    variant: str | None = typer.Option(
        None,
        "--variant",
        help="Selects a pinned variant. Mutually exclusive with --shape and --field.",
    ),
    as_of: str | None = typer.Option(
        None,
        "--as-of",
        help="ISO timestamp setting temporal.as_of for relative date filter normalization.",
    ),
    combination: str | None = typer.Option(
        None,
        "--combination",
        help="Deprecated legacy field-selection grammar. Use --shape or --field instead.",
    ),
    sample: int | None = typer.Option(
        None,
        "--sample",
        help=(
            "Render N capability-sampled selections per query. The backend's "
            "deterministic sampling rule chooses the selections."
        ),
    ),
    include_filter_variants: bool = typer.Option(
        False,
        "--include-filter-variants",
        help=(
            "When used with --sample, adds tier 8 (one optional filter "
            "toggled on at a time) to the sampled selections. See the PRD's "
            "deterministic sampling rule for details."
        ),
    ),
    include_variants: bool = typer.Option(
        False,
        "--include-variants",
        help=(
            "When used with --sample, adds one sample per pinned variant "
            "(variables and calculations from the variant, default fields "
            "otherwise) at the end of the sampled selections."
        ),
    ),
    no_auto_fix: bool = typer.Option(
        False,
        "--no-auto-fix",
        help="Disable automatic ref fixing on renames.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output."),
) -> None:
    """Compile a query template to SQL.

    Resolves a query template and compiles it to SQL.

    Accepts multiple query names, folder paths, or --topic for batch compilation.

    Examples:

        # Compile with active dev session
        kater compile COMPLIANCE_OVERVIEW

        # Compile multiple queries
        kater compile COMPLIANCE_OVERVIEW COMPLIANCE_TREND

        # Compile all queries in a folder
        kater compile topics/compliance/queries/

        # Compile all queries in a topic
        kater compile --topic compliance -c snowflake_prod

        # Compile with the new ergonomic shape grammar
        kater compile COMPLIANCE_OVERVIEW --shape "dimension=department,measure=compliance_rate"

        # Inline variable inside the shape string
        kater compile COMPLIANCE_OVERVIEW --shape "dimension=department,measure=compliance_rate,timeframe=month"

        # UUID escape hatch with explicit grain override
        kater compile COMPLIANCE_OVERVIEW --field <uuid> --timeframe <uuid>=month

        # Compile from a git branch
        kater compile COMPLIANCE_OVERVIEW --branch main

        # Compile with backend capability-sampled selections
        kater compile COMPLIANCE_OVERVIEW --sample 5

        # Sample including filter variants and pinned variants
        kater compile COMPLIANCE_OVERVIEW --sample 20 --include-filter-variants --include-variants

    """
    structured = parse_compile_args(
        shape=shape,
        fields=fields,
        vars=vars,
        filters=filters,
        variant=variant,
        as_of=as_of,
        combination=combination,
        no_auto_fix=no_auto_fix,
        timeframes=timeframes,
    )

    repo_root = find_repo_root()

    if verbose:
        console.print(f"[dim]Repository root: {repo_root}[/dim]")

    try:
        client = get_authenticated_client()

        # Resolve file source
        cli_id: str | None = None
        if branch:
            if verbose:
                console.print(f"[dim]Using branch: {branch}[/dim]")
        else:
            cli_id = get_cli_id()
            if cli_id is None:
                console.print(
                    "[red]No active dev session. Run `kater dev` or use `--branch <branch>`.[/red]"
                )
                raise typer.Exit(1)
            if verbose:
                console.print(f"[dim]Using dev session: {cli_id}[/dim]")

        # Resolve single connection
        conn = resolve_single_connection(client, connection)
        if verbose:
            console.print(f"[dim]Using connection: {conn.name}[/dim]")

        # Resolve query arguments into flat list
        query_names = resolve_query_args(repo_root, query, topic, conn.name)

        if verbose:
            console.print(f"[dim]Compiling {len(query_names)} query(ies)[/dim]")

        source_kwargs: dict[str, Any] = {}
        if branch:
            source_kwargs["source"] = branch
        if cli_id:
            source_kwargs["x_kater_cli_id"] = cli_id

        failed_queries: list[str] = []
        batch_rows: list[BatchRow] = []
        sample_count = sample
        if structured.legacy_combination is not None and sample is not None:
            stderr_console.print(
                "[yellow]warning: --sample is ignored when --combination is set[/yellow]"
            )
            sample_count = None

        # Decide which compile path to use:
        #   1. ``--sample N`` → backend capability sampling followed by render-per-sample.
        #   2. structured (--shape, --field, default) → single render call.

        for current_query in query_names:
            q_name = bare_query_name(current_query)
            query_id = str(resolve_query_name_to_id(repo_root, q_name, conn.name))

            if len(query_names) > 1:
                console.print(f"\n[bold]Compiling {current_query}...[/bold]")

            if structured.legacy_combination is not None:
                _run_compile_via_legacy_resolve_compile(
                    client=client,
                    structured=structured,
                    query_id=query_id,
                    conn=conn,
                    tenant=tenant,
                    source_kwargs=source_kwargs,
                    current_query=current_query,
                    q_name=q_name,
                    query_names=query_names,
                    verbose=verbose,
                    failed_queries=failed_queries,
                    batch_rows=batch_rows,
                )
                continue

            if sample_count is not None:
                _run_compile_via_capability_sampling(
                    client=client,
                    query_id=query_id,
                    conn=conn,
                    tenant=tenant,
                    branch=branch,
                    cli_id=cli_id,
                    n=sample_count,
                    include_filter_variants=include_filter_variants,
                    include_pinned_variants=include_variants,
                    current_query=current_query,
                    q_name=q_name,
                    query_names=query_names,
                    verbose=verbose,
                    failed_queries=failed_queries,
                    batch_rows=batch_rows,
                )
                continue

            _run_compile_via_render_endpoint(
                client=client,
                structured=structured,
                query_id=query_id,
                conn=conn,
                tenant=tenant,
                branch=branch,
                cli_id=cli_id,
                current_query=current_query,
                q_name=q_name,
                query_names=query_names,
                verbose=verbose,
                failed_queries=failed_queries,
                batch_rows=batch_rows,
            )

        display_batch_summary(batch_rows, mode="compile")

        if failed_queries:
            console.print(
                f"\n[red]✗[/red] {len(failed_queries)} query(ies) failed to compile: "
                + ", ".join(failed_queries)
            )
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except kater.APITimeoutError:
        console.print("[red]Request to Kater API timed out.[/red]")
        console.print("[dim]Please try again later.[/dim]")
        raise typer.Exit(1)
    except kater.APIConnectionError:
        console.print("[red]Could not connect to the Kater API.[/red]")
        console.print("[dim]Please check your internet connection and try again.[/dim]")
        raise typer.Exit(1)
    except kater.APIStatusError as e:
        handle_compile_api_error(e)
    except TypeError as e:
        if "authentication" in str(e).lower():
            console.print(f"[red]{AUTHENTICATION_FAILED_MESSAGE}[/red]")
            raise typer.Exit(1)
        raise


def _run_compile_via_legacy_resolve_compile(
    *,
    client: kater.Kater,
    structured: Any,
    query_id: str,
    conn: Any,
    tenant: str,
    source_kwargs: dict[str, Any],
    current_query: str,
    q_name: str,
    query_names: list[str],
    verbose: bool,
    failed_queries: list[str],
    batch_rows: list[BatchRow],
) -> None:
    """Submit one query through the legacy resolve + compile fallback."""
    combination = to_legacy_combination_string(structured)
    resolve_kwargs: dict[str, Any] = {}
    if combination:
        resolve_kwargs["combination"] = combination
    if structured.filter_state:
        resolve_kwargs["filter_state"] = structured.filter_state
    if structured.as_of:
        resolve_kwargs["as_of"] = structured.as_of
    resolve_kwargs["auto_fix"] = structured.auto_fix

    if verbose:
        console.print("[dim]Resolving query template...[/dim]")

    resolve_result = client.v1.compiler.resolve(
        connection_id=conn.id,
        query_id=query_id,
        **resolve_kwargs,
        **source_kwargs,
    )

    ref_fixes = getattr(resolve_result, "ref_fixes", None)
    if ref_fixes:
        display_ref_fixes(ref_fixes)

    if verbose:
        console.print("[dim]Compiling query...[/dim]")

    compile_result = client.v1.compiler.compile(
        connection_id=conn.id,
        resolved_query=cast(CompileResolvedQuery, resolve_result.resolved_query),
        tenant_key=tenant,
        **source_kwargs,
    )

    key_id = getattr(
        getattr(compile_result, "rendered_query_key", None),
        "key_id",
        None,
    )
    sql = getattr(compile_result, "sql", None)
    sql_length = len(sql) if sql else None
    shape_label = format_shape_label(structured)

    if verbose and key_id is not None:
        console.print(f"  [dim]Compiled key: {format_truncated_key_id(key_id)}[/dim]")

    if compile_result.success:
        combo_label = f" [{shape_label}]" if shape_label else ""
        if len(query_names) > 1:
            console.print(f"[green]✓[/green] {q_name}{combo_label}")
        batch_rows.append(
            BatchRow(
                query_name=current_query,
                shape_label=shape_label,
                status="ok",
                sql_length=sql_length,
                rendered_query_key_id=key_id,
            )
        )
    else:
        display_compile_errors(compile_result.errors or [])
        failed_queries.append(current_query)
        batch_rows.append(
            BatchRow(
                query_name=current_query,
                shape_label=shape_label,
                status="fail",
                sql_length=sql_length,
                rendered_query_key_id=key_id,
            )
        )


def _run_compile_via_render_endpoint(
    *,
    client: kater.Kater,
    structured: Any,
    query_id: str,
    conn: Any,
    tenant: str,
    branch: str | None,
    cli_id: str | None,
    current_query: str,
    q_name: str,
    query_names: list[str],
    verbose: bool,
    failed_queries: list[str],
    batch_rows: list[BatchRow],
) -> None:
    """Submit one query via ``POST /api/v1/compiler/render`` for kater compile.

    Story 6.2 — the structured render call site for compile. Mirrors
    Story 6.1's ``_run_via_render_endpoint(...)`` in run.py but consumes the
    response's ``sql`` field for compile-mode display instead of ``data``.
    """
    if verbose:
        console.print("[dim]Rendering query (structured render endpoint)...[/dim]")

    rendered_query_request: RenderedQueryRequestV1 = build_rendered_query_request(
        structured=structured,
        query_kater_id=query_id,
        connection_id=conn.id,
        tenant_key=tenant,
        source_branch=branch,
        cli_id=cli_id,
        legacy_combination=None,
    )

    render_result = submit_render(
        client,
        request=rendered_query_request,
        source=branch,
        cli_id=cli_id,
    )

    _display_compile_render_result(
        render_result=render_result,
        structured=structured,
        current_query=current_query,
        q_name=q_name,
        verbose=verbose,
        shape_label=format_shape_label(structured),
        failed_queries=failed_queries,
        batch_rows=batch_rows,
    )


def _run_compile_via_capability_sampling(
    *,
    client: kater.Kater,
    query_id: str,
    conn: Any,
    tenant: str,
    branch: str | None,
    cli_id: str | None,
    n: int,
    include_filter_variants: bool,
    include_pinned_variants: bool,
    current_query: str,
    q_name: str,
    query_names: list[str],
    verbose: bool,
    failed_queries: list[str],
    batch_rows: list[BatchRow],
) -> None:
    """Submit a capability sampling request and render each returned sample.

    Story 6.2 — replaces the legacy ``client.v1.compiler.enumerate(...) +
    combination-rebuild`` loop with a single backend sampling call followed
    by a render-per-sample iteration. The backend (Story 2.6) owns the
    deterministic sampling rule; the CLI only forwards inputs and renders
    the returned ordered list.
    """
    if verbose:
        console.print(f"[dim]Requesting {n} capability-sampled selection(s) from backend...[/dim]")

    sample_response: CapabilitySampleResponse = submit_capability_sampling(
        client,
        query_kater_id=query_id,
        connection_id=conn.id,
        n=n,
        include_filter_variants=include_filter_variants,
        include_pinned_variants=include_pinned_variants,
        source=branch,
        cli_id=cli_id,
    )

    if sample_response.truncated:
        available = (
            sample_response.available
            if sample_response.available is not None
            else len(sample_response.samples)
        )
        _print_sample_truncation_warning(requested=n, available=available)

    if verbose:
        console.print(f"[dim]Backend returned {len(sample_response.samples)} sample(s)[/dim]")

    for sample_request in sample_response.samples:
        # Each backend-built RenderedQueryRequestV1 maps onto the same
        # render endpoint as the structured path; the CLI does not rebuild
        # combination strings or otherwise inspect the request shape.
        # We must ensure the request carries the correct connection_id +
        # query_kater_id (the backend may or may not populate them; if it
        # does, we trust them).
        render_result = submit_render(
            client,
            request=sample_request,
            source=branch,
            cli_id=cli_id,
        )

        # Build a per-sample shape label from the backend-supplied selection.
        sample_label = _format_sample_shape_label(sample_request)

        _display_compile_render_result(
            render_result=render_result,
            structured=None,
            current_query=current_query,
            q_name=q_name,
            verbose=verbose,
            shape_label=sample_label,
            failed_queries=failed_queries,
            batch_rows=batch_rows,
        )


def _display_compile_render_result(
    *,
    render_result: CompilerRenderResponse,
    structured: Any,  # noqa: ARG001 — reserved for future shape-label refinements
    current_query: str,
    q_name: str,
    verbose: bool,
    shape_label: str | None,
    failed_queries: list[str],
    batch_rows: list[BatchRow],
) -> None:
    """Display a render response in compile-mode (sql + key id, no rows).

    Story 6.2 — shared by the structured render path and the capability
    sampling render-per-sample loop. Consumes ``render_result.sql`` and
    ``render_result.rendered_query_key.key_id``; ignores ``data`` /
    ``column_map`` / ``row_count`` (run-mode concerns).
    """
    render_key_id = getattr(
        getattr(render_result, "rendered_query_key", None),
        "key_id",
        None,
    )
    render_sql = getattr(render_result, "sql", None)
    sql_length = len(render_sql) if render_sql else None

    ref_fixes = getattr(render_result, "ref_fixes", None)
    if ref_fixes:
        display_ref_fixes(ref_fixes)

    if verbose and render_key_id is not None:
        console.print(f"  [dim]Compiled key: {format_truncated_key_id(render_key_id)}[/dim]")

    if render_result.success:
        combo_label = f" [{shape_label}]" if shape_label else ""
        console.print(f"\n[green]✓[/green] Compilation succeeded ({q_name}{combo_label})")
        if verbose and render_sql:
            console.print(f"  [dim]SQL length: {sql_length} chars[/dim]")
        batch_rows.append(
            BatchRow(
                query_name=current_query,
                shape_label=shape_label,
                status="ok",
                sql_length=sql_length,
                rendered_query_key_id=render_key_id,
            )
        )
    else:
        display_compile_errors(render_result.errors or [])
        failed_queries.append(current_query)
        batch_rows.append(
            BatchRow(
                query_name=current_query,
                shape_label=shape_label,
                status="fail",
                sql_length=sql_length,
                rendered_query_key_id=render_key_id,
            )
        )


def _print_sample_truncation_warning(*, requested: int, available: int) -> None:
    """Print a structured-shaped truncation warning to stderr.

    Story 6.2 — emitted when the backend returns fewer samples than the
    user requested. Matches the PRD's ``event="sample_truncated",
    available=<count>`` log shape.
    """
    stderr_console.print(
        f"[yellow]warning: --sample N truncated to {available} (requested {requested})[/yellow]"
    )


def _format_sample_shape_label(request: RenderedQueryRequestV1) -> str | None:
    """Build a per-sample shape label from a backend-built request.

    Story 6.2 — distinguishes batch rows for capability-sampled selections.
    Falls back to a UUID-truncated selected field summary when the
    request has no other identifying flag set.
    """
    if request.pinned_variant:
        return f"variant={request.pinned_variant}"

    selected_fields = list(request.field_selection.selected_fields)
    if selected_fields:
        truncated = [field.source_kater_id[:8] for field in selected_fields]
        label = ",".join(truncated)
        if any(field.modifiers for field in selected_fields):
            label += " +modifiers"
        return label

    return None
