"""Shared display formatters for build and validation results.

Provides structured, scannable terminal output for diagnostics from both
``kater validate`` (model correctness) and ``kater build`` (config/theme).
Used by the CLI commands and the ``kater dev`` callbacks.
"""

from datetime import datetime
from pathlib import Path
import textwrap
from typing import Any, cast

from rich.console import Console

console = Console()


# ---------------------------------------------------------------------------
# Timestamp parsing
# ---------------------------------------------------------------------------


def _parse_timestamp(iso_str: str) -> str:
    """Parse ISO timestamp to local HH:MM:SS for display."""
    if not iso_str:
        return datetime.now().strftime("%H:%M:%S")
    try:
        dt = datetime.fromisoformat(iso_str.replace("Z", "+00:00"))
        return dt.astimezone().strftime("%H:%M:%S")
    except (ValueError, OSError):
        return datetime.now().strftime("%H:%M:%S")


# ---------------------------------------------------------------------------
# Diagnostic rendering
# ---------------------------------------------------------------------------

_SEVERITY_COLORS: dict[str, str] = {
    "error": "red",
    "warning": "yellow",
    "warn": "yellow",
    "info": "blue",
}


def _normalize_label(label: str) -> str:
    """Convert internal labels to human-readable display labels."""
    return "warning" if label == "warn" else label


def _format_diagnostic_position(item: dict[str, Any]) -> str:
    """Format line and column metadata for compact display."""
    line = item.get("line")
    column = item.get("column")

    if line is None:
        return ""
    if column is None:
        return f"line {line}"
    return f"line {line}, column {column}"


def _display_file_path(file_str: str, connection_name: str | None = None) -> str:
    """Trim redundant connection prefixes from file paths."""
    if not file_str:
        return file_str

    if connection_name:
        prefix = f"{connection_name}/"
        if file_str.startswith(prefix):
            return file_str[len(prefix) :]

    return file_str


def _link_file_path(display_path: str, file_str: str, repo_root: Path | None) -> str:
    """Make a displayed path clickable when a repo root is available."""
    if not repo_root or not file_str:
        return display_path

    abs_path = repo_root / file_str
    return f"[link=file://{abs_path}]{display_path}[/link]"


def _wrap_with_indent(text: str, indent: str) -> str:
    """Wrap long lines while keeping a stable hanging indent."""
    console_width = getattr(console, "width", 100)
    if not isinstance(console_width, int) or console_width <= len(indent):
        console_width = 100

    return textwrap.fill(
        text,
        width=max(20, console_width - len(indent)),
        initial_indent=indent,
        subsequent_indent=indent,
        break_long_words=False,
        break_on_hyphens=False,
    )


def print_grouped_diagnostics(
    diagnostics: list[tuple[str, dict[str, Any]]],
    repo_root: Path | None = None,
    *,
    connection_name: str | None = None,
) -> None:
    """Print diagnostics grouped by file for scan-friendly terminal output."""
    grouped: dict[str, list[tuple[str, dict[str, Any]]]] = {}
    for label, item in diagnostics:
        file_str = str(item.get("file", ""))
        grouped.setdefault(file_str, []).append((label, item))

    for group_index, (file_str, items) in enumerate(grouped.items()):
        if group_index > 0:
            console.print()

        if file_str:
            display_path = _display_file_path(file_str, connection_name)
            linked_path = _link_file_path(display_path, file_str, repo_root)
            console.print(f"    [bold]{linked_path}[/bold]")

        for label, item in items:
            display_label = _normalize_label(label)
            color = _SEVERITY_COLORS.get(label, "white")
            code = str(item.get("code", ""))
            position = _format_diagnostic_position(item)

            metadata_parts = [f"[{color}]{display_label}[/{color}]"]
            if code:
                metadata_parts.append(f"[{color}]{code}[/{color}]")
            if position:
                metadata_parts.append(f"[dim]{position}[/dim]")

            console.print(f"      {'  '.join(metadata_parts)}")
            console.print(_wrap_with_indent(str(item.get("message", "")), "        "))

            remediation = item.get("remediation")
            if remediation:
                console.print(f"[dim]{_wrap_with_indent(f'→ {remediation}', '        ')}[/dim]")


def _safe_diagnostic_list(raw: object) -> list[dict[str, Any]]:
    """Extract list of diagnostic dicts, skipping malformed entries."""
    if not isinstance(raw, list):
        return []
    return [item for item in raw if isinstance(item, dict)]  # type: ignore[reportUnknownVariableType]


# ---------------------------------------------------------------------------
# Validation result display (model/SQL)
# ---------------------------------------------------------------------------


def display_validation_result(
    data: dict[str, Any],
    repo_root: Path | None = None,
) -> None:
    """Display a ``validation_result`` WebSocket message in the terminal.

    Shows a thin rule separator with timestamp, then per-connection
    summaries and diagnostics.

    Args:
        data: The validation_result message payload.
        repo_root: Repository root for clickable file links.
    """
    raw_connections: object = data.get("connections", [])
    if not isinstance(raw_connections, list):
        return
    connections: list[Any] = cast(list[Any], raw_connections)
    if not connections:
        return

    timestamp = data.get("timestamp", "")
    time_str = _parse_timestamp(str(timestamp))

    console.print()
    console.rule(
        f"[dim]kater validate[/dim]  [dim]{time_str}[/dim]",
        style="dim",
    )

    for conn in connections:
        if not isinstance(conn, dict):
            continue
        conn_dict: dict[str, Any] = cast(dict[str, Any], conn)
        name: str = str(conn_dict.get("connection_name", conn_dict.get("name", "unknown")))
        errors = _safe_diagnostic_list(conn_dict.get("errors", []))
        warnings = _safe_diagnostic_list(conn_dict.get("warnings", []))
        infos = _safe_diagnostic_list(conn_dict.get("info", []))

        if not errors and not warnings:
            # Pass line
            info_suffix = f"  [dim]({len(infos)} info)[/dim]" if infos else ""
            console.print(f"  [green]✓[/green] [bold]{name}[/bold]  passed{info_suffix}")
            # Show info diagnostics when connection passes
            if infos:
                print_grouped_diagnostics(
                    [("info", item) for item in infos],
                    repo_root,
                    connection_name=name,
                )
        else:
            # Fail line with counts
            parts: list[str] = []
            if errors:
                parts.append(f"{len(errors)} error{'s' if len(errors) != 1 else ''}")
            if warnings:
                parts.append(f"{len(warnings)} warning{'s' if len(warnings) != 1 else ''}")
            console.print(f"  [red]✗[/red] [bold]{name}[/bold]  {', '.join(parts)}")
            console.print()
            print_grouped_diagnostics(
                [("error", item) for item in errors] + [("warn", item) for item in warnings],
                repo_root,
                connection_name=name,
            )


# ---------------------------------------------------------------------------
# Build result display (config/theme)
# ---------------------------------------------------------------------------


def display_build_result(
    data: dict[str, Any],
    repo_root: Path | None = None,
) -> None:
    """Display a ``build_result`` WebSocket message in the terminal.

    Shows a thin rule separator with timestamp, then a flat summary
    and diagnostics.

    Args:
        data: The build_result message payload.
        repo_root: Repository root for clickable file links.
    """
    raw_diagnostics = _safe_diagnostic_list(data.get("diagnostics", []))

    timestamp = data.get("timestamp", "")
    time_str = _parse_timestamp(str(timestamp))

    console.print()
    console.rule(
        f"[dim]kater build[/dim]  [dim]{time_str}[/dim]",
        style="dim",
    )

    errors = [d for d in raw_diagnostics if d.get("severity") == "error"]
    warnings = [d for d in raw_diagnostics if d.get("severity") in ("warning", "warn")]
    infos = [d for d in raw_diagnostics if d.get("severity") == "info"]

    if not errors and not warnings:
        info_suffix = f"  [dim]({len(infos)} info)[/dim]" if infos else ""
        console.print(f"  [green]✓[/green] build passed{info_suffix}")
        if infos:
            print_grouped_diagnostics([("info", item) for item in infos], repo_root)
    else:
        parts: list[str] = []
        if errors:
            parts.append(f"{len(errors)} error{'s' if len(errors) != 1 else ''}")
        if warnings:
            parts.append(f"{len(warnings)} warning{'s' if len(warnings) != 1 else ''}")
        console.print(f"  [red]✗[/red] build failed  {', '.join(parts)}")
        console.print()
        print_grouped_diagnostics(
            [("error", item) for item in errors] + [("warn", item) for item in warnings],
            repo_root,
        )


# ---------------------------------------------------------------------------
# Standalone build diagnostics display (for kater build CLI)
# ---------------------------------------------------------------------------


def display_build_diagnostics(
    diagnostics: list[dict[str, Any]],
    repo_root: Path | None = None,
) -> None:
    """Display build diagnostics for the standalone ``kater build`` CLI command.

    Unlike ``display_build_result`` (which handles WebSocket messages),
    this formats diagnostics directly from BuildValidator output.

    Args:
        diagnostics: List of diagnostic dicts from BuildValidator.
        repo_root: Repository root for clickable file links.
    """
    errors = [d for d in diagnostics if d.get("severity") == "error"]
    warnings = [d for d in diagnostics if d.get("severity") in ("warning", "warn")]
    infos = [d for d in diagnostics if d.get("severity") == "info"]

    if not errors and not warnings and not infos:
        console.print("[green]✓[/green] Build passed: all checks passed")
        return

    if not errors and not warnings:
        console.print(f"[green]✓[/green] Build passed  [dim]({len(infos)} info)[/dim]")
        console.print()
        print_grouped_diagnostics([("info", item) for item in infos], repo_root)
        return

    parts: list[str] = []
    if errors:
        parts.append(f"{len(errors)} error{'s' if len(errors) != 1 else ''}")
    if warnings:
        parts.append(f"{len(warnings)} warning{'s' if len(warnings) != 1 else ''}")
    console.print(f"[red]✗[/red] Build failed: {', '.join(parts)}")
    console.print()

    print_grouped_diagnostics(
        [("error", item) for item in errors] + [("warn", item) for item in warnings],
        repo_root,
    )
    if infos:
        console.print()
        print_grouped_diagnostics([("info", item) for item in infos], repo_root)
