"""Command for validating semantic layer schemas."""

from pathlib import Path
from typing import Any

import kater
import typer
import yaml
from kater.types.v1.compiler_validate_response import CompilerValidateResponse
from rich.console import Console

from kater_cli.auth.messages import AUTHENTICATION_FAILED_MESSAGE
from kater_cli.client import get_authenticated_client
from kater_cli.commands._display import print_grouped_diagnostics
from kater_cli.commands._shared import (
    display_ref_fixes,
    get_cli_id,
    handle_api_error,
    parse_error_body,
    resolve_connection_ids,
)
from kater_cli.repo import find_connection_folder_local, find_repo_root, find_topic_folder_local

console = Console()


def _display_schema_parse_errors(message: str) -> None:
    """Display schema parse errors in a readable, copy-friendly format."""
    prefix = "Schema parsing failed: "
    content = message[len(prefix) :] if message.startswith(prefix) else message

    # Entries are separated by semicolons
    raw_entries = [entry.strip() for entry in content.split(";") if entry.strip()]

    count = len(raw_entries)
    label = "file" if count == 1 else "files"
    console.print(f"\n[red]✗[/red] Schema validation failed ({count} {label})\n")

    for entry in raw_entries:
        # Parse: "<filepath>: Schema validation failed for\n<filepath>: <details>"
        marker = ": Schema validation failed for"
        idx = entry.find(marker)
        if idx == -1:
            # Fallback: print the raw entry
            console.print(f"  {entry}")
            continue

        file_path = entry[:idx].strip()
        details = entry[idx + len(marker) :].strip()

        # Remove the repeated "filepath: " prefix from the pydantic output
        fp_prefix = file_path + ": "
        if details.startswith(fp_prefix):
            details = details[len(fp_prefix) :]
        elif details.startswith("\n") and details[1:].startswith(fp_prefix):
            details = details[1 + len(fp_prefix) :]

        console.print(f"  [bold]{file_path}[/bold]")
        for line in details.split("\n"):
            stripped = line.strip()
            if not stripped:
                continue
            if "For further information visit" in stripped:
                url = stripped.split("visit ")[-1] if "visit " in stripped else stripped
                console.print(f"    [dim]→ {url}[/dim]")
            else:
                console.print(f"    {stripped}")
        console.print()


def _handle_validate_api_error(e: kater.APIStatusError) -> None:
    """Handle API errors for the validate command.

    Catches SCHEMA_PARSE_ERROR for custom display, then delegates to shared handler.
    """
    if isinstance(e, kater.BadRequestError):
        code, message = parse_error_body(e)
        if code == "SCHEMA_PARSE_ERROR" and message:
            _display_schema_parse_errors(message)
            raise typer.Exit(1)

    handle_api_error(e, context="validation")


def _display_success(result: CompilerValidateResponse, connections_written: list[str]) -> None:
    """Display validation success output."""
    count = len(result.connection_results or [])
    label = "connection" if count == 1 else "connections"
    console.print(f"\n[green]✓[/green] Validation passed ({count} {label})")

    for name in connections_written:
        console.print(f"  {name}: [green]✓[/green] dependency-graph.yaml written")

    console.print("  [green]✓[/green] _admin/tenants.yaml written")
    console.print("  [green]✓[/green] _admin/tenant_groups.yaml written")


def _display_errors(result: CompilerValidateResponse) -> None:
    """Display validation error output, grouped by connection."""
    connection_results = result.connection_results or []
    total_errors = sum(len(cr.errors or []) for cr in connection_results)
    total_warnings = sum(len(cr.warnings or []) for cr in connection_results)

    parts: list[str] = []
    if total_errors:
        parts.append(f"{total_errors} error{'s' if total_errors != 1 else ''}")
    if total_warnings:
        parts.append(f"{total_warnings} warning{'s' if total_warnings != 1 else ''}")

    console.print(f"\n[red]✗[/red] Validation failed: {', '.join(parts)}")

    for cr in connection_results:
        conn_errors = cr.errors or []
        conn_warnings = cr.warnings or []
        if not conn_errors and not conn_warnings:
            continue

        console.print(f"\n  [bold]{cr.connection_name}:[/bold]")
        print_grouped_diagnostics(
            [
                (
                    "error",
                    {
                        "file": error.file or "",
                        "line": error.line,
                        "column": getattr(error, "column", None),
                        "code": error.code,
                        "message": error.message,
                        "remediation": error.remediation,
                    },
                )
                for error in conn_errors
            ]
            + [
                (
                    "warn",
                    {
                        "file": warning.file or "",
                        "line": warning.line,
                        "column": getattr(warning, "column", None),
                        "code": warning.code,
                        "message": warning.message,
                        "remediation": warning.remediation,
                    },
                )
                for warning in conn_warnings
            ],
            connection_name=cr.connection_name,
        )


def _write_tenant_schemas(client: kater.Kater, repo_root: Path) -> None:
    """Fetch and write tenant and tenant group schema YAML files."""
    admin_dir = repo_root / "_admin"
    admin_dir.mkdir(parents=True, exist_ok=True)

    # Fetch tenants schema as YAML
    tenants_response = client.v1.tenants.with_raw_response.get_tenants_schema(
        extra_headers={"Accept": "application/yaml"},
    )
    (admin_dir / "tenants.yaml").write_bytes(tenants_response.http_response.content)

    # Fetch tenant groups schema as YAML
    groups_response = client.v1.tenants.groups.with_raw_response.get_tenant_groups_schema(
        extra_headers={"Accept": "application/yaml"},
    )
    (admin_dir / "tenant_groups.yaml").write_bytes(groups_response.http_response.content)


def _validate_topic_structure(repo_root: Path, connection_name: str, topic_name: str) -> bool:
    """Validate a topic's directory structure and topic.yaml locally.

    Returns True if validation passes, False otherwise.
    """
    try:
        connection_path = find_connection_folder_local(repo_root, connection_name)
    except FileNotFoundError:
        console.print(
            f"[red]✗[/red] No connection folder found for '{connection_name}' in {repo_root}"
        )
        return False

    try:
        topic_path = find_topic_folder_local(connection_path, topic_name)
    except FileNotFoundError:
        console.print(f"[red]✗[/red] Topic '{topic_name}' not found under {connection_path}")
        return False

    if not topic_path.exists():
        console.print(f"[red]✗[/red] Topic '{topic_name}' not found at {topic_path}")
        return False

    # Check topic.yaml exists
    topic_yaml_path = topic_path / "topic.yaml"
    if not topic_yaml_path.exists():
        console.print(f"[red]✗[/red] Missing topic.yaml at {topic_yaml_path}")
        return False

    # Validate topic.yaml has required fields
    try:
        topic_data = yaml.safe_load(topic_yaml_path.read_text())
    except yaml.YAMLError as e:
        console.print(f"[red]✗[/red] Invalid YAML in {topic_yaml_path}: {e}")
        return False

    if not isinstance(topic_data, dict):
        console.print(
            f"[red]✗[/red] topic.yaml must be a YAML mapping, got {type(topic_data).__name__}"
        )
        return False

    missing_fields = [f for f in ("kater_id", "name") if f not in topic_data]
    if missing_fields:
        console.print(
            f"[red]✗[/red] topic.yaml missing required fields: {', '.join(missing_fields)}"
        )
        return False

    # Check required subdirectories
    expected_subdirs = ("queries", "query_views", "dashboards", "reportflows")
    missing_dirs = [d for d in expected_subdirs if not (topic_path / d).is_dir()]
    if missing_dirs:
        console.print(f"[yellow]![/yellow] Missing subdirectories: {', '.join(missing_dirs)}")

    # Validate all YAML files in subdirectories
    yaml_errors: list[str] = []
    for subdir in expected_subdirs:
        subdir_path = topic_path / subdir
        if not subdir_path.is_dir():
            continue
        for yaml_file in subdir_path.rglob("*.yaml"):
            try:
                yaml.safe_load(yaml_file.read_text())
            except yaml.YAMLError as e:
                yaml_errors.append(f"  {yaml_file.relative_to(repo_root)}: {e}")

    if yaml_errors:
        console.print("[red]✗[/red] YAML parse errors in topic artifacts:")
        for err in yaml_errors:
            console.print(err)
        return False

    console.print(f"[green]✓[/green] Topic '{topic_name}' structure is valid")
    return True


def validate(
    connection: list[str] | None = typer.Option(
        None,
        "--connection",
        "-c",
        help="Connection name(s) to validate. If omitted, validates all.",
    ),
    topic: str | None = typer.Option(
        None,
        "--topic",
        help="Topic name to validate. Checks topic.yaml and child artifacts locally.",
    ),
    branch: str | None = typer.Option(
        None,
        "--branch",
        "-b",
        help="Git branch to validate from (alternative to running kater dev).",
    ),
    no_auto_fix: bool = typer.Option(
        False,
        "--no-auto-fix",
        help="Disable automatic ref fixing on renames.",
    ),
    verbose: bool = typer.Option(False, "--verbose", "-v", help="Enable verbose output."),
) -> None:
    """Validate semantic layer schemas for errors and warnings.

    Checks all views, queries, and related schemas for correctness.
    On success, writes dependency graphs, manifests, and tenant schemas to the local repo.

    When --topic is specified, also performs local validation of the topic's
    directory structure and YAML files before running the API validation.

    Examples:

        # Validate with active dev session
        kater validate

        # Validate specific connections
        kater validate -c snowflake_prod -c postgres_dev

        # Validate a specific topic
        kater validate --topic compliance -c snowflake_prod

        # Validate from a git branch
        kater validate --branch main

        # Validate without auto-fixing renames
        kater validate --no-auto-fix
    """
    repo_root = find_repo_root()

    # Local topic validation when --topic is specified
    if topic:
        if not connection:
            console.print("[red]--topic requires --connection (-c) to be specified.[/red]")
            raise typer.Exit(1)
        for conn_name in connection:
            if not _validate_topic_structure(repo_root, conn_name, topic):
                raise typer.Exit(1)

    if verbose:
        console.print(f"[dim]Repository root: {repo_root}[/dim]")

    try:
        client = get_authenticated_client()

        # Resolve file source
        cli_id: str | None = None
        if branch:
            if verbose:
                console.print(f"[dim]Using branch: {branch}[/dim]")
        else:
            cli_id = get_cli_id()
            if cli_id is None:
                console.print(
                    "[red]No active dev session. Run `kater dev` or use `--branch <branch>`.[/red]"
                )
                raise typer.Exit(1)
            if verbose:
                console.print(f"[dim]Using dev session: {cli_id}[/dim]")

        # Resolve connections
        connection_ids = resolve_connection_ids(client, connection)

        if verbose:
            if connection_ids:
                console.print(f"[dim]Validating {len(connection_ids)} connection(s)[/dim]")
            else:
                console.print("[dim]Validating all connections[/dim]")

        # Call validate endpoint
        console.print("[dim]Validating schemas...[/dim]")
        validate_kwargs: dict[str, Any] = {}
        if branch:
            validate_kwargs["source"] = branch
        if connection_ids is not None:
            validate_kwargs["connection_ids"] = connection_ids
        if cli_id:
            validate_kwargs["x_kater_cli_id"] = cli_id
        validate_kwargs["extra_body"] = {"auto_fix": not no_auto_fix}
        result = client.v1.compiler.validate(**validate_kwargs)

        if result.success:
            # Display ref fix summaries (write-back handles file writes)
            written_names: list[str] = []
            for cr in result.connection_results or []:
                if cr.dependency_graph is not None:
                    written_names.append(cr.connection_name)

                ref_fixes = getattr(cr, "ref_fixes", None)
                if ref_fixes:
                    display_ref_fixes(ref_fixes)

            # Write tenant schemas (these are fetched separately, not from write-back)
            _write_tenant_schemas(client, repo_root)

            _display_success(result, written_names)
        else:
            _display_errors(result)
            raise typer.Exit(1)

    except typer.Exit:
        raise
    except kater.APITimeoutError:
        console.print("[red]Request to Kater API timed out.[/red]")
        console.print("[dim]Please try again later.[/dim]")
        raise typer.Exit(1)
    except kater.APIConnectionError:
        console.print("[red]Could not connect to the Kater API.[/red]")
        console.print("[dim]Please check your internet connection and try again.[/dim]")
        raise typer.Exit(1)
    except kater.APIStatusError as e:
        _handle_validate_api_error(e)
    except TypeError as e:
        if "authentication" in str(e).lower():
            console.print(f"[red]{AUTHENTICATION_FAILED_MESSAGE}[/red]")
            raise typer.Exit(1)
        raise
