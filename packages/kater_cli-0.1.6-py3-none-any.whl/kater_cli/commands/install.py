"""Command for initializing a Kater project in a local directory."""

import webbrowser
from pathlib import Path

import typer
from kater_utils.scaffold_templates import build_root_scaffold_items
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.rule import Rule
from rich.table import Table
from rich.text import Text

from kater_cli.config import get_settings

console = Console()

_BANNER = """\

            #####
          #########
     ###################
   #######################
  #########################
  #########  ###  #########
   ########  ###  ########
    #######  ###  #######
      #####  ###  #####
      #################
      #################
      #################
       ###############
                          """


def _titleize_slug(value: str) -> str:
    return value.replace("-", " ").replace("_", " ").title()


def _describe_resource_path(path: str) -> str:
    if path == "resources/CLI_COMMANDS.md":
        return "CLI command reference"
    if path == "resources/KATER_DSL_REFERENCE.md":
        return "Kater DSL reference"
    if path == "resources/WIDGET_CATEGORIES.md":
        return "Widget category reference"
    if path == "resources/AGENT_SYSTEM_PROMPT.md":
        return "Agent system prompt reference"
    if path == "resources/AGENT_QUERY_BUILDING_GUIDE.md":
        return "Agent query-building guide"
    if path == "resources/AGENT_DASHBOARD_BUILDING_GUIDE.md":
        return "Agent dashboard-building guide"
    if path == "resources/RUNTIME_QUERIES.md":
        return "Runtime query reference"
    if path == "resources/workflows/new_user_dashboard/START_HERE.md":
        return "New user dashboard workflow entry point"
    if path == "resources/workflows/new_user_dashboard/MASTER_WORKFLOW.md":
        return "New user dashboard master workflow"
    if path == "resources/workflows/new_user_dashboard/GUARDRAILS.md":
        return "New user dashboard workflow guardrails"
    if path == "resources/workflows/new_user_dashboard/IMPLEMENTATION_SPEC.md":
        return "New user dashboard implementation spec"
    if path == "resources/workflows/new_user_dashboard/references/example-map.md":
        return "New user dashboard example map"

    workflow_prefix = "resources/workflows/new_user_dashboard/"
    if path.startswith(f"{workflow_prefix}stages/"):
        stage_name = Path(path).stem.split("-", 1)[1]
        return f"New user dashboard stage: {_titleize_slug(stage_name)}"
    if path.startswith(f"{workflow_prefix}templates/"):
        template_name = Path(path).stem.removesuffix("-template")
        return f"New user dashboard template: {_titleize_slug(template_name)}"

    return ""


# Maps scaffold file paths to human-readable descriptions for the install preview table.
# Paths must match build_root_scaffold_items() output exactly.
# theme/custom-themes/.gitkeep is intentionally excluded — it's an internal placeholder
# and _print_file_preview() falls back to "" for unlisted paths.
_BASE_FILE_DESCRIPTIONS: dict[str, str] = {
    "kater.config.yaml": "Project configuration",
    "README.md": "Getting started guide",
    ".gitignore": "Runtime directory exclusions",
    ".kater/insights/trends/trend-change/definition.yaml": "Built-in trend insight definition",
    ".kater/insights/trends/trend-change/insight.py": "Built-in trend insight code",
    ".kater/insights/comparisons/top-bottom-gap/definition.yaml": (
        "Built-in comparison insight definition"
    ),
    ".kater/insights/comparisons/top-bottom-gap/insight.py": "Built-in comparison insight code",
    ".kater/insights/trends/trend-volatility/definition.yaml": (
        "Built-in volatility insight definition"
    ),
    ".kater/insights/trends/trend-volatility/insight.py": "Built-in volatility insight code",
    ".kater/insights/trends/current-vs-prior/definition.yaml": (
        "Built-in current-vs-prior insight definition"
    ),
    ".kater/insights/trends/current-vs-prior/insight.py": (
        "Built-in current-vs-prior insight code"
    ),
    ".kater/insights/comparisons/actual-vs-target/definition.yaml": (
        "Built-in actual-vs-target insight definition"
    ),
    ".kater/insights/comparisons/actual-vs-target/insight.py": (
        "Built-in actual-vs-target insight code"
    ),
    ".kater/insights/comparisons/segment-vs-benchmark/definition.yaml": (
        "Built-in segment-vs-benchmark insight definition"
    ),
    ".kater/insights/comparisons/segment-vs-benchmark/insight.py": (
        "Built-in segment-vs-benchmark insight code"
    ),
    ".kater/insights/distributions/largest-segment/definition.yaml": (
        "Built-in distribution insight definition"
    ),
    ".kater/insights/distributions/largest-segment/insight.py": (
        "Built-in distribution insight code"
    ),
    ".kater/insights/distributions/mix-shift/definition.yaml": (
        "Built-in mix-shift insight definition"
    ),
    ".kater/insights/distributions/mix-shift/insight.py": "Built-in mix-shift insight code",
    ".kater/insights/exceptions/threshold-breach/definition.yaml": (
        "Built-in threshold-breach insight definition"
    ),
    ".kater/insights/exceptions/threshold-breach/insight.py": (
        "Built-in threshold-breach insight code"
    ),
    ".kater/insights/exceptions/outlier-detection/definition.yaml": (
        "Built-in outlier-detection insight definition"
    ),
    ".kater/insights/exceptions/outlier-detection/insight.py": (
        "Built-in outlier-detection insight code"
    ),
    "theme/kater-chart-theme.yaml": "Chart color & style theme",
    "theme/kater-globals.css": "Theme CSS variables",
    "theme/layout.yaml": "Layout and branding config",
    "_admin/query_policy.yaml": "AI query modes & global limits",
    "_admin/integrations.yaml": "External integration config",
    "_admin/grants/access_filters.yaml": "Row-level security filters",
    "_admin/grants/access_grants.yaml": "Permission grants",
    "_admin/grants/attributes.yaml": "User & tenant attributes",
}


def _build_file_descriptions() -> dict[str, str]:
    descriptions = dict(_BASE_FILE_DESCRIPTIONS)
    for rel_path, _ in build_root_scaffold_items("description_seed"):
        if rel_path in descriptions or not rel_path.startswith("resources/"):
            continue
        description = _describe_resource_path(rel_path)
        if description:
            descriptions[rel_path] = description
    return descriptions


_FILE_DESCRIPTIONS = _build_file_descriptions()


def _print_banner() -> None:
    content = Text.assemble(
        Text("  Welcome to ", style="#DF644A"),
        Text("Kater!\n", style="bold #DF644A"),
        Text(_BANNER, style="bold white"),
    )
    console.print(Panel(content, border_style="#DF644A", padding=(0, 2), expand=False))
    console.print()


def _print_file_preview(items: list[tuple[str, str]], target_dir: Path) -> None:
    table = Table(
        show_header=True,
        header_style="bold dim",
        border_style="dim",
        box=None,
        padding=(0, 2, 0, 0),
    )
    table.add_column("File", no_wrap=True, min_width=38)
    table.add_column("Description", style="dim")
    table.add_column("", justify="right", no_wrap=True, min_width=14)

    for rel_path, _ in items:
        desc = _FILE_DESCRIPTIONS.get(rel_path, "")
        if (target_dir / rel_path).exists():
            table.add_row(
                f"[dim]{rel_path}[/dim]",
                f"[dim]{desc}[/dim]",
                "[yellow]already exists[/yellow]",
            )
        else:
            table.add_row(
                f"[green]{rel_path}[/green]",
                desc,
                "[dim green]will create[/dim green]",
            )

    console.print(table)


def install(
    path: str | None = typer.Option(
        None,
        "--path",
        "-p",
        help="Target directory. Defaults to current working directory.",
    ),
) -> None:
    """Initialize a Kater project in the current (or specified) directory."""
    settings = get_settings()

    # ── Banner ────────────────────────────────────────────────────────────────
    _print_banner()

    # ── Resolve target directory ──────────────────────────────────────────────
    target_dir = Path(path).resolve() if path else Path.cwd()

    console.print(f"  [dim]Directory:[/dim] [bold]{target_dir}[/bold]")
    console.print()

    confirmed = typer.confirm("Initialize Kater here?", default=True)
    if not confirmed:
        override = typer.prompt("Enter path")
        target_dir = Path(override).resolve()
        console.print()

    if not target_dir.exists():
        create = typer.confirm(f"Directory does not exist. Create {target_dir}?", default=True)
        if not create:
            raise typer.Exit(0)
        target_dir.mkdir(parents=True, exist_ok=True)

    if not target_dir.is_dir():
        console.print(f"\n[red]Error:[/red] Not a directory: {target_dir}")
        raise typer.Exit(1)

    if (target_dir / "kater.config.yaml").exists():
        console.print(
            f"\n[red]Error:[/red] [bold]{target_dir.name}[/bold] is already a Kater project "
            "(kater.config.yaml already exists)."
        )
        raise typer.Exit(1)

    # ── File preview ──────────────────────────────────────────────────────────
    items = build_root_scaffold_items(target_dir.name)
    new_items = [(p, c) for p, c in items if not (target_dir / p).exists()]

    console.print()
    console.print(Rule("[dim]Files to create[/dim]"))
    console.print()
    _print_file_preview(items, target_dir)
    console.print()

    if not new_items:
        console.print("[yellow]All files already exist — nothing to do.[/yellow]")
        raise typer.Exit(0)

    count = len(new_items)
    typer.confirm(
        f"Create {count} file{'s' if count != 1 else ''}?",
        default=True,
        abort=True,
    )
    console.print()

    # ── Scaffold with animated progress ───────────────────────────────────────
    created: list[str] = []

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        transient=False,
        console=console,
    ) as progress:
        task = progress.add_task("Installing...", total=len(new_items))

        for rel_path, content in new_items:
            progress.update(task, description=f"Creating [bold]{rel_path}[/bold]")
            dest = target_dir / rel_path
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(content, encoding="utf-8")
            created.append(rel_path)
            progress.advance(task)
            progress.print(f"  [green]✓[/green] {rel_path}")

        progress.update(task, description="[green bold]Done![/green bold]")

    # ── Success panel ─────────────────────────────────────────────────────────
    console.print()
    console.print(
        Panel(
            Text.assemble(
                Text("  Project:  ", style="dim"),
                Text(target_dir.name, style="bold"),
                "\n",
                Text("  Location: ", style="dim"),
                Text(str(target_dir), style=""),
                "\n\n",
                Text("  Next steps:\n", style="bold"),
                Text("  1. ", style="dim"),
                Text("Run "),
                Text("kater signup", style="bold cyan"),
                Text(" to create your account\n"),
                Text("  2. ", style="dim"),
                Text("Connect your data warehouse\n"),
                Text("  3. ", style="dim"),
                Text("Run "),
                Text("kater dev", style="bold cyan"),
                Text(" to sync your files"),
            ),
            title="[bold green]✓  Project ready![/bold green]",
            border_style="green",
            padding=(1, 2),
        )
    )

    # ── Browser prompt ────────────────────────────────────────────────────────
    console.print()
    open_browser = typer.confirm("Open browser to create your Kater account now?", default=True)
    if open_browser:
        console.print("[dim]Opening browser...[/dim]")
        webbrowser.open(settings.signup_url)
    else:
        console.print("[dim]Sign up later with:[/dim] kater signup")
