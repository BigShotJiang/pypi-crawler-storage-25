"""Command for importing tenants from warehouse or CSV."""

from pathlib import Path
from typing import Any, cast

import kater
import typer
from kater.types.v1 import Connection, ImportTenantsResponse
from rich.console import Console
from rich.panel import Panel

from kater_cli.auth.messages import REAUTH_MESSAGE
from kater_cli.client import get_authenticated_client
from kater_cli.preferences import PreferenceManager
from kater_cli.prompts import prompt_confirm, prompt_selection, prompt_text

console = Console()


def parse_fqn_table(fqn: str) -> tuple[str, str, str]:
    """Parse a fully qualified table name into (database, schema, table).

    Args:
        fqn: Fully qualified name in format "database.schema.table"

    Returns:
        Tuple of (database, schema, table)

    Raises:
        typer.BadParameter: If format is invalid
    """
    parts = fqn.split(".")
    if len(parts) != 3:
        raise typer.BadParameter(
            f"Invalid table format: '{fqn}'. Expected format: database.schema.table"
        )
    return parts[0], parts[1], parts[2]


def fetch_connections(client: kater.Kater) -> list[Connection]:
    """Fetch all connections from the API.

    Args:
        client: Authenticated API client

    Returns:
        List of Connection objects
    """
    try:
        return list(client.v1.connections.list_connections())
    except kater.AuthenticationError:
        console.print(f"[red]{REAUTH_MESSAGE}[/red]")
        raise typer.Exit(1)
    except kater.APIStatusError as e:
        console.print(f"[red]Error fetching connections: {e.message}[/red]")
        raise typer.Exit(1)


def select_connection(connections: list[Connection]) -> Connection:
    """Select a connection from the list, using default if available.

    Priority order:
    1. Single connection -> auto-select
    2. Valid default set -> use it (with message)
    3. Default invalid/missing -> interactive prompt

    Args:
        connections: List of available connections

    Returns:
        Selected Connection

    Raises:
        typer.Exit: If no connections available
    """
    if not connections:
        console.print("[red]No connections found. Run `kater create connection` first.[/red]")
        raise typer.Exit(1)

    # Priority 1: Single connection -> auto-select
    if len(connections) == 1:
        conn = connections[0]
        console.print(f"[dim]Using connection: {conn.name}[/dim]")
        return conn

    # Priority 2: Check for valid default connection
    pref_manager = PreferenceManager()
    default_id = pref_manager.get_default_connection_id()

    if default_id:
        for conn in connections:
            if str(conn.id) == default_id:
                console.print(f"[dim]Using default connection: {conn.name}[/dim]")
                return conn
        # Default connection not found in list - it may have been deleted
        console.print(
            "[yellow]Note: Default connection no longer exists. "
            "Run `kater config default-connection set` to update.[/yellow]"
        )

    # Priority 3: Interactive prompt
    options = [
        (conn.name, conn.description or conn.label or "No description") for conn in connections
    ]

    selected_name = prompt_selection(
        "Select a connection",
        options,
        prompt_text="Connection number",
    )

    # Find and return the selected connection
    for conn in connections:
        if conn.name == selected_name:
            console.print(
                "[dim]Tip: Run `kater config default-connection set` "
                "to set a default connection.[/dim]"
            )
            return conn

    # This shouldn't happen, but handle gracefully
    raise typer.Exit(1)


def display_import_result(result: ImportTenantsResponse) -> None:
    """Display the import result using Rich formatting.

    Args:
        result: ImportTenantsResponse from the API
    """
    content_lines = [
        f"[bold]Found:[/bold] {result.total_found} unique tenant keys",
        f"[green bold]Imported:[/green bold] {result.total_imported} new tenants",
        f"[blue]Updated:[/blue] {result.total_updated} existing tenants",
    ]

    # Show groups created if any
    if result.groups_created:
        groups_str = ", ".join(result.groups_created)
        content_lines.append(f"[blue]Groups created:[/blue] {groups_str}")

    # Show errors if any
    if result.errors:
        content_lines.append("")
        content_lines.append("[red bold]Errors:[/red bold]")
        for error in result.errors:
            content_lines.append(f"  [red]- {error.tenant_key}: {error.message}[/red]")

    console.print()
    console.print(
        Panel(
            "\n".join(content_lines),
            title="Import Results",
            border_style="green" if result.total_imported > 0 else "yellow",
        )
    )


def handle_api_error(e: kater.APIStatusError, operation: str = "import") -> None:
    """Handle common API error responses.

    Args:
        e: API status error
        operation: Description of the operation for error messages

    Raises:
        typer.Exit: Always raises after handling the error
    """
    if isinstance(e, kater.AuthenticationError):
        console.print(f"[red]{REAUTH_MESSAGE}[/red]")
        raise typer.Exit(1)

    if isinstance(e, kater.UnprocessableEntityError):
        console.print("[red]Validation error:[/red]")
        raw_body: object | None = e.body
        body = cast(dict[str, Any], raw_body) if isinstance(raw_body, dict) else None
        if body is not None and "detail" in body:
            for error in cast(list[dict[str, Any]], body["detail"]):
                loc_parts = cast(list[str], error.get("loc", []))
                loc = ".".join(str(x) for x in loc_parts) or "unknown"
                console.print(f"  [red]- {loc}: {error.get('msg', '')}[/red]")
        else:
            console.print(f"  [red]{e.message}[/red]")
        raise typer.Exit(1)

    console.print(f"[red]Unexpected error during {operation}: {e.message}[/red]")
    raise typer.Exit(1)


def tenants(
    table: str = typer.Option(
        None,
        "--table",
        "-t",
        help="Fully qualified table name (database.schema.table) to import tenants from.",
    ),
    csv: Path = typer.Option(
        None,
        "--csv",
        "-c",
        help="Path to CSV file containing tenant data.",
    ),
    tenant_key_column: str = typer.Option(
        None,
        "--tenant-key-column",
        "-k",
        help="Column name for tenant key (required for warehouse import).",
    ),
    tenant_name_column: str = typer.Option(
        None,
        "--tenant-name-column",
        "-n",
        help="Column name for tenant display name (optional).",
    ),
    group_names_column: str = typer.Option(
        None,
        "--group-names-column",
        "-g",
        help="Column name for tenant group names (optional).",
    ),
) -> None:
    """Import tenants from a warehouse table or CSV file.

    Examples:

        # Import from warehouse table
        kater import tenants --table "mydb.schema.tenants" --tenant-key-column tenant_id

        # Import from CSV file
        kater import tenants --csv "./tenants.csv"
    """
    # Validate mutual exclusivity
    if table and csv:
        console.print("[red]Cannot use both --table and --csv. Choose one import method.[/red]")
        raise typer.Exit(1)

    # If no flags provided, run guided interactive flow
    if not table and not csv:
        _run_guided_flow()
        return

    try:
        client = get_authenticated_client()

        if table:
            _import_from_warehouse(
                client,
                table,
                tenant_key_column,
                tenant_name_column,
                group_names_column,
            )
        else:
            _import_from_csv(client, csv)

    except typer.Exit:
        raise
    except kater.APITimeoutError:
        console.print("[red]Request to Kater API timed out.[/red]")
        console.print("[dim]Please try again later.[/dim]")
        raise typer.Exit(1)
    except kater.APIConnectionError:
        console.print("[red]Could not connect to the Kater API.[/red]")
        console.print("[dim]Please check your internet connection and try again.[/dim]")
        raise typer.Exit(1)
    except kater.APIStatusError as e:
        handle_api_error(e, "import")
    except Exception as e:
        console.print(f"[red]Error importing tenants: {e}[/red]")
        raise typer.Exit(1)


def _import_from_warehouse(
    client: kater.Kater,
    table: str,
    tenant_key_column: str | None,
    tenant_name_column: str | None,
    group_names_column: str | None,
) -> None:
    """Handle warehouse import flow (flag-based mode)."""
    # Validate required column
    if not tenant_key_column:
        console.print("[red]--tenant-key-column is required for warehouse import.[/red]")
        raise typer.Exit(1)

    # Parse FQN
    try:
        database, schema, table_name = parse_fqn_table(table)
    except typer.BadParameter as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    # Fetch and select connection
    console.print("[dim]Fetching connections...[/dim]")
    connections = fetch_connections(client)
    connection = select_connection(connections)

    # Execute import using shared function
    console.print(f"[dim]Importing tenants from {table}...[/dim]")
    _execute_warehouse_import(
        client,
        connection,
        database,
        schema,
        table_name,
        tenant_key_column,
        tenant_name_column,
        group_names_column,
    )


def _import_from_csv(client: kater.Kater, csv_path: Path) -> None:
    """Handle CSV import flow."""
    # Validate file exists
    if not csv_path.exists():
        console.print(f"[red]File not found: {csv_path}[/red]")
        raise typer.Exit(1)

    if not csv_path.is_file():
        console.print(f"[red]Not a file: {csv_path}[/red]")
        raise typer.Exit(1)

    console.print(f"[dim]Reading {csv_path.name}...[/dim]")

    with open(csv_path, "rb") as f:
        file_content = f.read()

    # Call API - Stainless SDK accepts (filename, bytes, mime_type) tuple
    console.print("[dim]Importing tenants from CSV...[/dim]")

    try:
        result = client.v1.tenants.import_from_csv(
            file=(csv_path.name, file_content, "text/csv"),
        )
        display_import_result(result)
    except kater.APIStatusError as e:
        handle_api_error(e, "CSV import")


def _run_guided_flow() -> None:
    """Run the interactive guided import flow."""
    console.print(
        Panel(
            "[bold]Import Tenants[/bold]\n\n"
            "Import tenant data into Kater from your warehouse or a CSV file.",
            border_style="blue",
        )
    )

    import_type = prompt_selection(
        "Import from",
        [
            ("warehouse", "Import from a warehouse table"),
            ("csv", "Import from a CSV file"),
        ],
        prompt_text="Selection",
    )

    try:
        client = get_authenticated_client()

        if import_type == "warehouse":
            _guided_warehouse_import(client)
        else:
            _guided_csv_import(client)
    except typer.Exit:
        raise
    except kater.APITimeoutError:
        console.print("[red]Request to Kater API timed out.[/red]")
        console.print("[dim]Please try again later.[/dim]")
        raise typer.Exit(1)
    except kater.APIConnectionError:
        console.print("[red]Could not connect to the Kater API.[/red]")
        console.print("[dim]Please check your internet connection and try again.[/dim]")
        raise typer.Exit(1)
    except kater.APIStatusError as e:
        handle_api_error(e, "import")
    except Exception as e:
        console.print(f"[red]Error importing tenants: {e}[/red]")
        raise typer.Exit(1)


def _guided_warehouse_import(client: kater.Kater) -> None:
    """Guided flow for warehouse import."""
    # Fetch and select connection
    console.print("\n[dim]Fetching connections...[/dim]")
    connections = fetch_connections(client)
    connection = select_connection(connections)

    # Prompt for table location
    console.print("\n[bold]Table Location[/bold]")
    database = prompt_text("Database")
    schema = prompt_text("Schema")
    table = prompt_text("Table")

    # Prompt for column mappings
    console.print("\n[bold]Column Mappings[/bold]")
    tenant_key_column = prompt_text("Tenant key column")
    tenant_name_column = prompt_text("Tenant name column (optional)", required=False)
    group_names_column = prompt_text("Group names column (optional)", required=False)

    # Display summary
    _display_warehouse_summary(
        connection,
        database,
        schema,
        table,
        tenant_key_column,
        tenant_name_column or None,
        group_names_column or None,
    )

    # Confirm
    if not prompt_confirm("\nProceed with import?", default=True):
        console.print("[yellow]Import cancelled.[/yellow]")
        raise typer.Exit(0)

    # Execute import
    _execute_warehouse_import(
        client,
        connection,
        database,
        schema,
        table,
        tenant_key_column,
        tenant_name_column or None,
        group_names_column or None,
    )


def _guided_csv_import(client: kater.Kater) -> None:
    """Guided flow for CSV import."""
    # Prompt for file path
    console.print("\n[bold]CSV File[/bold]")
    csv_path_str = prompt_text("Path to CSV file")
    csv_path = Path(csv_path_str).expanduser()

    # Validate file exists
    if not csv_path.exists():
        console.print(f"[red]File not found: {csv_path}[/red]")
        raise typer.Exit(1)

    if not csv_path.is_file():
        console.print(f"[red]Not a file: {csv_path}[/red]")
        raise typer.Exit(1)

    # Display summary
    console.print(
        Panel(
            f"[bold]File:[/bold] {csv_path.name}\n[bold]Path:[/bold] {csv_path}",
            title="Import Summary",
            border_style="green",
        )
    )

    # Confirm
    if not prompt_confirm("\nProceed with import?", default=True):
        console.print("[yellow]Import cancelled.[/yellow]")
        raise typer.Exit(0)

    # Execute import (reuse existing logic)
    _import_from_csv(client, csv_path)


def _display_warehouse_summary(
    connection: Connection,
    database: str,
    schema: str,
    table: str,
    tenant_key_column: str,
    tenant_name_column: str | None,
    group_names_column: str | None,
) -> None:
    """Display import configuration summary."""
    lines = [
        f"[bold]Source:[/bold] {database}.{schema}.{table}",
        f"[bold]Connection:[/bold] {connection.name}",
        f"[bold]Key column:[/bold] {tenant_key_column}",
    ]
    if tenant_name_column:
        lines.append(f"[bold]Name column:[/bold] {tenant_name_column}")
    if group_names_column:
        lines.append(f"[bold]Group column:[/bold] {group_names_column}")

    console.print(
        Panel(
            "\n".join(lines),
            title="Import Summary",
            border_style="green",
        )
    )


def _execute_warehouse_import(
    client: kater.Kater,
    connection: Connection,
    database: str,
    schema: str,
    table: str,
    tenant_key_column: str,
    tenant_name_column: str | None,
    group_names_column: str | None,
) -> None:
    """Execute the warehouse import API call."""
    console.print("\n[dim]Importing tenants...[/dim]")

    try:
        result = client.v1.tenants.import_from_warehouse(
            connection_id=connection.id,
            database=database,
            schema=schema,
            table=table,
            tenant_key_column=tenant_key_column,
            tenant_name_column=tenant_name_column,
            tenant_group_column=group_names_column,
        )
        display_import_result(result)
    except kater.APIStatusError as e:
        handle_api_error(e, "warehouse import")
