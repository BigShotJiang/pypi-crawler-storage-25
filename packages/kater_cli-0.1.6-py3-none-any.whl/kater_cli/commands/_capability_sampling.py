"""Vendored compatibility module for the capability sampling endpoint.

Story 6.2 — the redefined ``--sample N`` flag calls a backend deterministic
sampling rule (Story 2.6) rather than enumerating combinations and rebuilding
combination strings client-side. The backend endpoint receives
``(query_kater_id, n, include_filter_variants, include_pinned_variants)`` and
returns a list of ``RenderedQueryRequestV1`` plus a ``truncated`` flag.

This module mirrors ``_sdk_compat.py``'s structure: typed Pydantic
request/response models with a ``submit_capability_sampling(...)`` HTTP helper
that POSTs through ``client.post(...)`` while the Stainless Python SDK regen
is pending. AC13 fallback option (2).

The route path placeholder is ``/api/v1/compiler/capabilities/sample`` and is
documented in the helper docstring; if Story 2.6 chooses a different shape
(e.g. extends the capabilities endpoint with ``?sample=N``), the helper's
implementation is updated to match while the public interface stays fixed.

Story 7.6 audit removes this module once Stainless regenerates
``client.v1.compiler.capabilities.sample(...)``.
"""

from typing import Any, cast

import kater
from kater._base_client import make_request_options
from pydantic import BaseModel, ConfigDict, Field

from kater_cli.commands._sdk_compat import RenderedQueryRequestV1

__all__ = [
    "CapabilitySampleRequest",
    "CapabilitySampleResponse",
    "submit_capability_sampling",
]


# ── Request-side type ─────────────────────────────────────────────────


class CapabilitySampleRequest(BaseModel):
    """Request body for the capability sampling endpoint.

    Story 6.2 — submitted to ``POST /api/v1/compiler/capabilities/sample``.
    The backend's deterministic sampling rule (Story 2.6) consumes the
    fields and returns a list of ``RenderedQueryRequestV1`` plus a
    truncation flag.
    """

    model_config = ConfigDict(extra="forbid")

    query_kater_id: str
    connection_id: str
    n: int
    include_filter_variants: bool = False
    include_pinned_variants: bool = False


# ── Response-side type ────────────────────────────────────────────────


def _empty_request_list() -> list["RenderedQueryRequestV1"]:
    return []


class CapabilitySampleResponse(BaseModel):
    """Response from the capability sampling endpoint.

    Story 6.2 — ``samples`` carries the deterministic ordered list of
    sampled selections. ``truncated`` is True when fewer than the requested
    ``n`` samples are available; ``available`` documents the actual count.
    """

    model_config = ConfigDict(extra="allow")

    samples: list[RenderedQueryRequestV1] = Field(default_factory=_empty_request_list)
    truncated: bool = False
    available: int | None = None


# ── HTTP submission helper ────────────────────────────────────────────


def submit_capability_sampling(
    client: kater.Kater,
    *,
    query_kater_id: str,
    connection_id: str,
    n: int,
    include_filter_variants: bool = False,
    include_pinned_variants: bool = False,
    source: str | None = None,
    cli_id: str | None = None,
) -> CapabilitySampleResponse:
    """Submit a capability sampling request.

    Story 6.2 — POSTs to ``/api/v1/compiler/capabilities/sample`` (or whichever
    route Story 2.6 ultimately exposes). The backend's deterministic sampling
    rule decides which selections to return. This helper does not implement
    any sampling logic; it only forwards inputs and returns the typed
    response.

    Args:
        client: Authenticated kater client.
        query_kater_id: UUID of the query template.
        connection_id: UUID of the connection.
        n: Number of samples requested.
        include_filter_variants: Include tier-8 filter variants in the sample.
        include_pinned_variants: Include pinned-variant variants in the sample.
        source: Optional ``--branch`` value forwarded as the ``source`` query
            parameter (matches ``submit_render``'s convention).
        cli_id: Optional dev-session id forwarded via the
            ``X-Kater-CLI-ID`` header.

    Returns:
        A typed ``CapabilitySampleResponse`` with the deterministic ordered
        list of ``RenderedQueryRequestV1`` and a truncation flag.
    """
    request = CapabilitySampleRequest(
        query_kater_id=query_kater_id,
        connection_id=connection_id,
        n=n,
        include_filter_variants=include_filter_variants,
        include_pinned_variants=include_pinned_variants,
    )

    extra_headers: dict[str, str] = {}
    if cli_id is not None:
        extra_headers["X-Kater-CLI-ID"] = cli_id

    query: dict[str, str] | None = {"source": source} if source is not None else None

    body = request.model_dump(mode="json", exclude_none=False)
    options = make_request_options(
        query=query,
        extra_headers=extra_headers if extra_headers else None,
    )
    response: CapabilitySampleResponse = client.post(
        "/api/v1/compiler/capabilities/sample",
        body=cast(Any, body),
        cast_to=CapabilitySampleResponse,
        options=options,
    )
    return response
