"""CLI configuration settings."""

from functools import lru_cache
from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict

# Resolve .env relative to the CLI package root (apps/cli/.env),
# so it's loaded regardless of the user's CWD.
_CLI_ROOT = Path(__file__).resolve().parent.parent.parent  # src/kater_cli -> src -> apps/cli
_PACKAGE_ENV = _CLI_ROOT / ".env"


class CliSettings(BaseSettings):
    """Settings for the Kater CLI."""

    model_config = SettingsConfigDict(
        env_prefix="KATER_",
        env_file=(".env", str(_PACKAGE_ENV)),
        env_file_encoding="utf-8",
        extra="ignore",
    )

    # API configuration
    api_url: str = "https://api.kater.ai"

    # Web app URL (for clickable links in CLI output).
    # Defaults to http://localhost:5173 when api_url points to localhost,
    # otherwise https://app.kater.ai. Override via KATER_APP_URL.
    app_url: str | None = None

    @property
    def resolved_app_url(self) -> str:
        """Return app_url, falling back based on api_url environment."""
        if self.app_url is not None:
            return self.app_url
        if "localhost" in self.api_url or "127.0.0.1" in self.api_url:
            return "https://localhost:5173"
        return "https://app.kater.ai"

    # OAuth configuration (PropelAuth)
    oauth_auth_url: str = "https://auth.kater.ai/propelauth/oauth/authorize"
    oauth_token_url: str = "https://auth.kater.ai/propelauth/oauth/token"
    oauth_client_id: str = "35376b3c98499de36ad94ac575b5e38a"

    # Local callback server port
    oauth_callback_port: int = 9876

    # Keyring service name
    keyring_service: str = "kater-cli"

    # Signup URL (opened by `kater install` after scaffolding)
    signup_url: str = "https://kater.ai/signup?plan=pro&billing=yearly&product_line=cloud"


@lru_cache
def get_settings() -> CliSettings:
    """Get cached CLI settings singleton."""
    return CliSettings()
