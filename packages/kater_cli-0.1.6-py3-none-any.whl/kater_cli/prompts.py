"""Reusable Rich-based prompt utilities for interactive CLI input."""

from rich.console import Console
from rich.prompt import Confirm, Prompt
from rich.table import Table

console = Console()


def prompt_selection(
    title: str,
    options: list[tuple[str, str]],
    *,
    prompt_text: str = "Select an option",
) -> str:
    """Display a numbered list and prompt for selection.

    Args:
        title: Title to display above the options.
        options: List of (value, description) tuples.
        prompt_text: Text to show in the prompt.

    Returns:
        The selected option's value.
    """
    table = Table(show_header=False, box=None, padding=(0, 2))
    table.add_column("Number", style="cyan", width=4)
    table.add_column("Option", style="bold")
    table.add_column("Description", style="dim")

    for i, (value, description) in enumerate(options, 1):
        table.add_row(f"[{i}]", value, description)

    console.print()
    console.print(f"[bold]{title}[/bold]")
    console.print(table)
    console.print()

    while True:
        choice = Prompt.ask(prompt_text, default="1")
        try:
            index = int(choice) - 1
            if 0 <= index < len(options):
                return options[index][0]
            console.print(f"[red]Please enter a number between 1 and {len(options)}[/red]")
        except ValueError:
            console.print("[red]Please enter a valid number[/red]")


def prompt_text(
    prompt_text: str,
    *,
    default: str | None = None,
    password: bool = False,
    required: bool = True,
) -> str:
    """Prompt for text input.

    Args:
        prompt_text: The prompt to display.
        default: Default value if user presses Enter.
        password: If True, mask the input.
        required: If True, reject empty input.

    Returns:
        The entered text.
    """
    while True:
        value = Prompt.ask(prompt_text, default=default or "", password=password)
        if value or not required:
            return value
        console.print("[red]This field is required[/red]")


def prompt_confirm(
    prompt_text: str,
    *,
    default: bool = False,
) -> bool:
    """Prompt for yes/no confirmation.

    Args:
        prompt_text: The prompt to display.
        default: Default value if user presses Enter.

    Returns:
        True if confirmed, False otherwise.
    """
    return Confirm.ask(prompt_text, default=default)
