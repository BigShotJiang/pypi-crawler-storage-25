"""File sync service for scanning, hashing, and filtering repo files.

Story: 3-2-file-sync-service
Handles file operations for the `kater dev` command sync functionality.
"""

from pathlib import Path
from typing import TypedDict

import pathspec
from kater_utils import get_logger, hash_file, load_ignore_patterns

logger = get_logger(__name__)


class FileEntry(TypedDict):
    """Full file data for sync."""

    path: str  # Relative path from repo root
    content: bytes  # Raw file content
    hash: str  # SHA-256 hex digest


class FileManifestEntry(TypedDict):
    """File metadata for delta sync."""

    path: str  # Relative path from repo root
    hash: str  # SHA-256 hex digest


class FileSyncService:
    """Handles file scanning, hashing, and filtering for kater dev sync.

    This service provides:
    - scan_repo(): Full file scan with content and hashes
    - get_file_manifest(): Path and hash only for delta sync
    - read_and_hash_file(): Single file read with hash

    Respects .gitignore, .katerignore, and built-in exclusions.
    """

    def __init__(self, root_path: Path) -> None:
        """Initialize FileSyncService.

        Args:
            root_path: The repository root directory.
        """
        self.root_path = root_path.resolve()
        self._ignore_spec: pathspec.PathSpec | None = None

    def _compute_sha256(self, content: bytes) -> str:
        """Compute SHA-256 hash of content.

        Args:
            content: Raw file content as bytes.

        Returns:
            Lowercase hexadecimal SHA-256 digest.
        """
        return hash_file(content)

    def _load_ignore_patterns(self) -> pathspec.PathSpec:
        """Load ignore patterns from .gitignore and .katerignore.

        Combines:
        1. Built-in exclusions (always applied)
        2. .gitignore patterns (if exists)
        3. .katerignore patterns (if exists)

        Returns:
            Combined PathSpec for all ignore patterns.
        """
        return load_ignore_patterns(self.root_path)

    def _is_ignored(self, relative_path: str) -> bool:
        """Check if a path should be ignored (internal).

        Args:
            relative_path: Path relative to repo root (forward slashes).

        Returns:
            True if the path matches any ignore pattern.
        """
        if self._ignore_spec is None:
            self._ignore_spec = self._load_ignore_patterns()
        return self._ignore_spec.match_file(relative_path)

    def is_ignored(self, relative_path: str) -> bool:
        """Check if a path should be ignored.

        Public interface for checking if a file matches any ignore pattern
        (.gitignore, .katerignore, or built-in exclusions).

        Args:
            relative_path: Path relative to repo root (forward slashes).

        Returns:
            True if the path matches any ignore pattern.
        """
        return self._is_ignored(relative_path)

    def _validate_path(self, relative_path: str) -> Path:
        """Validate and resolve a relative path, preventing path traversal.

        Args:
            relative_path: Path relative to repo root.

        Returns:
            Resolved absolute path within repo root.

        Raises:
            ValueError: If path attempts to escape repo root.
        """
        # Resolve the full path and check it's within repo root
        file_path = (self.root_path / relative_path).resolve()

        # Security: ensure path is within repo root (prevent path traversal)
        try:
            file_path.relative_to(self.root_path)
        except ValueError:
            raise ValueError(f"Path traversal not allowed: {relative_path}") from None

        return file_path

    def read_and_hash_file(self, relative_path: str) -> FileEntry:
        """Read a single file and compute its hash.

        Args:
            relative_path: Path relative to repo root.

        Returns:
            FileEntry with path, content, and hash.

        Raises:
            FileNotFoundError: If file does not exist.
            ValueError: If path attempts to escape repo root.
        """
        file_path = self._validate_path(relative_path)
        if not file_path.exists():
            raise FileNotFoundError(f"File not found: {relative_path}")

        content = file_path.read_bytes()
        file_hash = self._compute_sha256(content)

        return FileEntry(
            path=relative_path,
            content=content,
            hash=file_hash,
        )

    def _iter_repo_files(self) -> list[tuple[str, Path]]:
        """Iterate over all non-ignored, non-symlink files in the repository.

        Returns:
            List of tuples (relative_path, absolute_path) for each valid file.
        """
        files: list[tuple[str, Path]] = []

        for file_path in self.root_path.rglob("*"):
            # Skip directories
            if not file_path.is_file():
                continue

            # Skip symlinks to avoid loops and reading outside repo
            if file_path.is_symlink():
                continue

            # Get relative path with forward slashes for cross-platform compatibility
            relative_path = file_path.relative_to(self.root_path).as_posix()

            if self._is_ignored(relative_path):
                continue

            files.append((relative_path, file_path))

        return files

    def scan_repo(self) -> list[FileEntry]:
        """Scan repository and return all included files with content.

        Walks the directory tree, reads all non-ignored files, and computes
        SHA-256 hashes. Symlinks are skipped for security.

        Returns:
            List of FileEntry for all non-ignored files.
        """
        entries: list[FileEntry] = []

        for relative_path, file_path in self._iter_repo_files():
            try:
                content = file_path.read_bytes()
                if not content:
                    continue  # Skip empty files (e.g. .gitkeep, __init__.py)
                file_hash = self._compute_sha256(content)
                entries.append(
                    FileEntry(
                        path=relative_path,
                        content=content,
                        hash=file_hash,
                    )
                )
            except Exception as e:
                logger.warning("failed_to_read_file", path=relative_path, error=str(e))
                continue

        return entries

    def get_file_manifest(self) -> list[FileManifestEntry]:
        """Get file manifest (paths and hashes only, no content).

        Used for delta sync to compare local files against server state.
        Symlinks are skipped for security.

        Returns:
            List of FileManifestEntry for delta sync.
        """
        entries: list[FileManifestEntry] = []

        for relative_path, file_path in self._iter_repo_files():
            try:
                content = file_path.read_bytes()
                if not content:
                    continue  # Skip empty files
                file_hash = self._compute_sha256(content)
                entries.append(
                    FileManifestEntry(
                        path=relative_path,
                        hash=file_hash,
                    )
                )
            except Exception as e:
                logger.warning("failed_to_read_file", path=relative_path, error=str(e))
                continue

        return entries
