"""WebSocket client for kater dev file sync.

Story: 3-3-websocket-dev-client
Handles WebSocket communication with the dev session endpoint.
"""

from __future__ import (
    annotations,  # noqa: TID251 — needed for TYPE_CHECKING guards and forward references; not a Pydantic model file
)

import asyncio
import base64
import json
from typing import TYPE_CHECKING, Any, Callable

import websockets
from kater_utils import get_logger
from rich.console import Console
from websockets.asyncio.client import ClientConnection
from websockets.exceptions import ConnectionClosed, InvalidStatus
from websockets.http11 import Response
from websockets.protocol import State

from kater_cli.auth.messages import REAUTH_MESSAGE

if TYPE_CHECKING:
    from kater_cli.services.file_sync import FileEntry, FileManifestEntry

logger = get_logger(__name__)


class AuthenticationError(Exception):
    """Raised when the server rejects the client's auth token."""


class SessionReadyTimeoutError(ConnectionError):
    """Raised when the websocket opens but the dev session is never confirmed."""


class SessionSetupError(ConnectionError):
    """Raised when the server rejects the post-connect dev session setup."""


# Message types - Client → Server
MSG_CONNECT = "connect"
MSG_FULL_SYNC = "full_sync"
MSG_DELTA_SYNC = "delta_sync"
MSG_FILE_SYNC = "file_sync"
MSG_FILE_DELETE = "file_delete"
MSG_BRANCH_SWITCH = "branch_switch"
MSG_PING = "ping"

# Message types - Client → Server (write-back protocol)
MSG_WRITE_ACK = "write_ack"

# Message types - Server → Client
MSG_SESSION_READY = "session_ready"
MSG_NEED_FILES = "need_files"
MSG_SYNC_ACK = "sync_ack"
MSG_WRITE_BACK = "write_back"
MSG_VALIDATION_RESULT = "validation_result"
MSG_BUILD_RESULT = "build_result"
MSG_ERROR = "error"
MSG_PONG = "pong"

# Reconnection settings
INITIAL_RECONNECT_DELAY = 1.0  # seconds
MAX_RECONNECT_DELAY = 30.0  # seconds
SESSION_READY_TIMEOUT_SECONDS = 10.0
KEEPALIVE_INTERVAL_SECONDS = 5.0

_SESSION_READY_TIMEOUT_MESSAGE = (
    "Timed out waiting for Kater to confirm the dev session (`session_ready`) after the "
    "websocket connected. Check the API logs; auth or session setup may have failed "
    "after the socket opened."
)


class WsDevClient:
    """WebSocket client for dev session file sync.

    Handles:
    - Authenticated WebSocket connections
    - File sync protocol messages
    - Automatic reconnection with exponential backoff
    - Callback-based message dispatching
    """

    def __init__(
        self,
        api_url: str,
        token: str,
        cli_id: str,
        token_provider: Callable[[], str | None] | None = None,
        token_refresher: Callable[[], str | None] | None = None,
    ) -> None:
        """Initialize WebSocket dev client.

        Args:
            api_url: API base URL (e.g., "https://app.kater.ai").
            token: Bearer token for authentication (used as fallback).
            cli_id: CLI identity for session.
            token_provider: Optional callable that returns a fresh token.
                If provided, called on each connect to get the latest token.
            token_refresher: Optional callable that force-refreshes auth and
                returns a replacement access token when the handshake token is
                rejected by the server.
        """
        self.api_url = api_url
        self.token = token
        self.cli_id = cli_id
        self._token_provider = token_provider
        self._token_refresher = token_refresher

        # Construct WebSocket URL
        self._ws_url = self._build_ws_url(api_url)

        # Connection state
        self._ws: ClientConnection | None = None
        self._reconnect_delay = INITIAL_RECONNECT_DELAY
        self._running = False
        self._receive_task: asyncio.Task[None] | None = None
        self._ping_task: asyncio.Task[None] | None = None
        self._branch_name: str | None = None
        self._workspace_root: str | None = None
        self._fatal_error: Exception | None = None
        self._session_ready_event = asyncio.Event()
        self._session_ready_timeout_task: asyncio.Task[None] | None = None

        # Callbacks - set by command layer
        self.on_session_ready: Callable[[str, int], None] | None = None
        self.on_need_files: Callable[[list[str]], None] | None = None
        self.on_sync_ack: (
            Callable[[str, str | None, int | None, bool | None, int | None], None] | None
        ) = None
        self.on_error: Callable[[str, str], None] | None = None
        self.on_pong: Callable[[], None] | None = None
        self.on_write_back: (
            Callable[[str, str, list[dict[str, Any]], list[str] | None], None] | None
        ) = None
        self.on_validation_result: Callable[[dict[str, Any]], None] | None = None
        self.on_build_result: Callable[[dict[str, Any]], None] | None = None
        self.on_reconnected: Callable[[], None] | None = None

    @staticmethod
    def _build_ws_url(api_url: str) -> str:
        """Build WebSocket URL from API URL.

        Args:
            api_url: HTTP(S) API URL.

        Returns:
            WebSocket URL for dev-session endpoint.
        """
        ws_url = api_url.replace("https://", "wss://").replace("http://", "ws://")
        return f"{ws_url.rstrip('/')}/ws/dev-session"

    def _format_connection_error(self) -> str:
        """Return a user-friendly API connection error for websocket startup failures."""
        base_message = "Could not connect to the Kater API."
        if "localhost" in self.api_url or "127.0.0.1" in self.api_url:
            return f"{base_message} Make sure the local API server is running at {self.api_url}."
        return base_message

    @property
    def is_connected(self) -> bool:
        """Check if WebSocket is connected."""
        return self._ws is not None and self._ws.state == State.OPEN

    @property
    def fatal_error(self) -> Exception | None:
        """Return the last unrecoverable receive/reconnect error, if any."""
        return self._fatal_error

    @property
    def is_running(self) -> bool:
        """Return whether the background receive loop should keep running."""
        return self._running

    def _get_connection_token(self) -> str:
        """Return the token that should be used for the next WebSocket connect."""
        if self._token_provider is None:
            return self.token

        fresh = self._token_provider()
        if not fresh:
            raise AuthenticationError(REAUTH_MESSAGE)

        self.token = fresh
        return fresh

    @staticmethod
    def _is_auth_status(response: Response) -> bool:
        """Return True when the handshake failed due to authentication."""
        return response.status_code in (401, 403)

    def _cancel_session_ready_timeout(self) -> None:
        """Cancel any in-flight session_ready timeout watchdog."""
        if self._session_ready_timeout_task is not None:
            self._session_ready_timeout_task.cancel()
            self._session_ready_timeout_task = None

    async def _handle_fatal_error(
        self,
        exc: Exception,
        *,
        code: str | None = None,
        emit_callback: bool = True,
    ) -> None:
        """Record a fatal error, notify the caller, and close the websocket."""
        if self._fatal_error is not None:
            return

        self._fatal_error = exc
        self._session_ready_event.set()
        self._cancel_session_ready_timeout()

        if emit_callback and code is not None and self.on_error is not None:
            self.on_error(code, str(exc))

        self._running = False

        if self._ws is not None:
            try:
                await self._ws.close(code=1011, reason=code or "fatal_error")
            except Exception:
                logger.warning(
                    "ws_close_after_fatal_error_failed",
                    error_type=type(exc).__name__,
                )
            finally:
                self._ws = None

    def _arm_session_ready_timeout(self, timeout: float = SESSION_READY_TIMEOUT_SECONDS) -> None:
        """Start a watchdog for the post-connect session_ready message."""
        self._cancel_session_ready_timeout()
        self._session_ready_event.clear()

        if not self._running:
            return

        self._session_ready_timeout_task = asyncio.create_task(
            self._session_ready_timeout_watchdog(timeout)
        )

    async def _session_ready_timeout_watchdog(self, timeout: float) -> None:
        """Fail loudly if the server never confirms the dev session."""
        try:
            await asyncio.sleep(timeout)
        except asyncio.CancelledError:
            return

        if self._session_ready_event.is_set() or self._fatal_error is not None or not self._running:
            return

        logger.warning("ws_session_ready_timeout", timeout=timeout, cli_id=self.cli_id)
        await self._handle_fatal_error(
            SessionReadyTimeoutError(_SESSION_READY_TIMEOUT_MESSAGE),
            code="session_ready_timeout",
        )

    async def wait_for_session_ready(
        self,
        timeout: float = SESSION_READY_TIMEOUT_SECONDS + 1.0,
    ) -> None:
        """Wait until the server confirms the dev session or a fatal error occurs."""
        try:
            await asyncio.wait_for(self._session_ready_event.wait(), timeout=timeout)
        except asyncio.TimeoutError:
            await self._handle_fatal_error(
                SessionReadyTimeoutError(_SESSION_READY_TIMEOUT_MESSAGE),
                code="session_ready_timeout",
            )

        if self._fatal_error is not None:
            raise self._fatal_error

    async def _connect_once(self, token: str, timeout: float) -> ClientConnection:
        """Open the WebSocket once with the provided token."""
        try:
            return await websockets.connect(
                self._ws_url,
                additional_headers={"Authorization": f"Bearer {token}"},
                open_timeout=timeout,
            )
        except InvalidStatus as exc:
            if self._is_auth_status(exc.response):
                logger.warning(
                    "ws_auth_rejected",
                    status_code=exc.response.status_code,
                    url=self._ws_url,
                )
                raise AuthenticationError(REAUTH_MESSAGE) from None
            raise ConnectionError(
                f"Failed to connect to Kater server ({exc.response.status_code})"
            ) from exc
        except OSError as exc:
            raise ConnectionError(self._format_connection_error()) from exc

    async def connect(self, timeout: float = 30.0) -> None:
        """Establish WebSocket connection with authorization.

        Args:
            timeout: Connection timeout in seconds (default 30s).

        Raises:
            AuthenticationError: If server rejects the token (403).
            ConnectionError: If connection fails for other reasons.
        """
        try:
            token = self._get_connection_token()
            self._ws = await self._connect_once(token, timeout)
        except AuthenticationError:
            if self._token_refresher is None:
                raise

            refreshed = self._token_refresher()
            if not refreshed:
                raise AuthenticationError(REAUTH_MESSAGE) from None

            logger.info("ws_retrying_with_refreshed_token")
            self.token = refreshed
            self._ws = await self._connect_once(refreshed, timeout)
        self._reconnect_delay = INITIAL_RECONNECT_DELAY
        logger.info("ws_connected", url=self._ws_url)

    async def disconnect(self, print_message: bool = True) -> None:
        """Close WebSocket connection cleanly.

        Args:
            print_message: If True, print disconnect message to console (AC5).
        """
        self._cancel_session_ready_timeout()
        self._session_ready_event.set()
        if self._ws:
            await self._ws.close(code=1000, reason="Client disconnect")
            self._ws = None
        logger.info("ws_disconnected")
        if print_message:
            from rich.console import Console

            Console().print("Disconnected. Your files are still cached on the server.")

    async def start(self) -> None:
        """Start the receive loop as a background task."""
        self._fatal_error = None
        self._session_ready_event.clear()
        self._running = True
        self._receive_task = asyncio.create_task(self._receive_loop())
        self._ping_task = asyncio.create_task(self._ping_loop())

    async def stop(self, print_message: bool = True) -> None:
        """Stop the receive loop and disconnect.

        Args:
            print_message: If True, print disconnect message to console.
        """
        self._running = False
        self._cancel_session_ready_timeout()
        self._session_ready_event.set()
        if self._receive_task:
            self._receive_task.cancel()
            try:
                await self._receive_task
            except asyncio.CancelledError:
                # Expected after explicit cancellation during graceful shutdown.
                pass
            self._receive_task = None
        if self._ping_task:
            self._ping_task.cancel()
            try:
                await self._ping_task
            except asyncio.CancelledError:
                # Expected after explicit cancellation during graceful shutdown.
                pass
            self._ping_task = None
        await self.disconnect(print_message=print_message)

    async def _send_json(self, data: dict[str, Any]) -> None:
        """Send JSON message over WebSocket.

        Args:
            data: Data to send as JSON.

        Raises:
            ConnectionError: If not connected or connection is not open.
        """
        if not self.is_connected:
            raise ConnectionError("WebSocket not connected")
        # _ws is guaranteed non-None here due to is_connected check
        await self._ws.send(json.dumps(data))  # type: ignore[union-attr]

    async def send_connect(
        self,
        branch_name: str | None = None,
        workspace_root: str | None = None,
    ) -> None:
        """Send connect message with cli_id, optional branch name, and workspace root."""
        self._branch_name = branch_name
        if workspace_root is not None:
            self._workspace_root = workspace_root
        msg: dict[str, Any] = {"type": MSG_CONNECT, "cli_id": self.cli_id}
        if branch_name is not None:
            msg["branch_name"] = branch_name
        if self._workspace_root is not None:
            msg["workspace_root"] = self._workspace_root
        self._arm_session_ready_timeout()
        await self._send_json(msg)
        logger.debug("ws_sent_connect", cli_id=self.cli_id, branch_name=branch_name)

    async def send_branch_switch(self, branch_name: str) -> None:
        """Send branch_switch message when git branch changes."""
        self._branch_name = branch_name
        await self._send_json({"type": MSG_BRANCH_SWITCH, "branch_name": branch_name})
        logger.debug("ws_sent_branch_switch", branch_name=branch_name)

    async def send_full_sync(self, files: list[FileEntry]) -> None:
        """Send full_sync message with all files.

        Args:
            files: List of FileEntry dicts with path, content, hash.
        """
        encoded_files = [
            {
                "path": f["path"],
                "content": base64.b64encode(f["content"]).decode("utf-8"),
                "hash": f["hash"],
            }
            for f in files
        ]
        await self._send_json({"type": MSG_FULL_SYNC, "files": encoded_files})
        logger.info("ws_sent_full_sync", file_count=len(files))

    async def send_delta_sync(self, manifest: list[FileManifestEntry]) -> None:
        """Send delta_sync message with file manifest.

        Args:
            manifest: List of FileManifestEntry dicts with path, hash.
        """
        await self._send_json({"type": MSG_DELTA_SYNC, "manifest": manifest})
        logger.info("ws_sent_delta_sync", file_count=len(manifest))

    async def send_file_sync(self, entry: FileEntry) -> None:
        """Send file_sync message for single file update.

        Args:
            entry: FileEntry with path, content, hash.
        """
        await self._send_json(
            {
                "type": MSG_FILE_SYNC,
                "path": entry["path"],
                "content": base64.b64encode(entry["content"]).decode("utf-8"),
                "hash": entry["hash"],
            }
        )
        logger.debug("ws_sent_file_sync", path=entry["path"])

    async def send_file_delete(self, path: str) -> None:
        """Send file_delete message.

        Args:
            path: Relative path of deleted file.
        """
        await self._send_json({"type": MSG_FILE_DELETE, "path": path})
        logger.debug("ws_sent_file_delete", path=path)

    async def send_write_ack(
        self,
        request_id: str,
        success: bool,
        files_written: int,
    ) -> None:
        """Send write_ack message confirming files were written.

        Args:
            request_id: The request_id from the write_back message.
            success: Whether all files were written successfully.
            files_written: Number of files successfully written.
        """
        await self._send_json(
            {
                "type": MSG_WRITE_ACK,
                "request_id": request_id,
                "success": success,
                "files_written": files_written,
            }
        )
        logger.debug(
            "ws_sent_write_ack",
            request_id=request_id,
            success=success,
            files_written=files_written,
        )

    async def send_ping(self) -> None:
        """Send ping message for keepalive."""
        await self._send_json({"type": MSG_PING})

    async def _ping_loop(self) -> None:
        """Send periodic keepalive pings while the client is running."""
        while self._running:
            try:
                await asyncio.sleep(KEEPALIVE_INTERVAL_SECONDS)
                if not self._running or not self.is_connected:
                    continue
                await self.send_ping()
            except asyncio.CancelledError:
                break
            except ConnectionError:
                logger.debug("ws_keepalive_skipped_no_connection", cli_id=self.cli_id)
            except Exception:
                logger.exception("ws_keepalive_failed", cli_id=self.cli_id)

    async def _receive_loop(self) -> None:
        """Async loop for receiving and dispatching messages."""
        while self._running:
            try:
                if not self._ws:
                    await self._reconnect_with_backoff()
                    continue

                raw = await self._ws.recv()
                data = json.loads(raw)
                await self._dispatch_message(data)

            except ConnectionClosed:
                logger.warning("ws_connection_lost")
                self._ws = None
                if self._running:
                    await self._reconnect_with_backoff()

            except json.JSONDecodeError:
                logger.warning("ws_invalid_json")
                continue

            except asyncio.CancelledError:
                break

            except Exception:
                logger.exception("ws_receive_error")
                if self._running:
                    await self._reconnect_with_backoff()

    async def _dispatch_message(self, data: dict[str, Any]) -> None:
        """Dispatch message to appropriate callback.

        Args:
            data: Parsed JSON message.
        """
        msg_type = data.get("type")

        if msg_type == MSG_SESSION_READY:
            self._cancel_session_ready_timeout()
            self._session_ready_event.set()
            if self.on_session_ready:
                self.on_session_ready(
                    data.get("cli_id", ""),
                    data.get("cached_file_count", 0),
                )

        elif msg_type == MSG_NEED_FILES:
            if self.on_need_files:
                self.on_need_files(data.get("paths", []))

        elif msg_type == MSG_SYNC_ACK:
            if self.on_sync_ack:
                self.on_sync_ack(
                    data.get("status", ""),
                    data.get("path"),
                    data.get("file_count"),
                    data.get("content_changed"),
                    data.get("content_changed_count"),
                )

        elif msg_type == MSG_ERROR:
            code = data.get("code", "unknown")
            message = data.get("message", "Unknown error")
            if self.on_error:
                self.on_error(code, message)
            if not self._session_ready_event.is_set():
                await self._handle_fatal_error(
                    SessionSetupError(
                        f"Dev session setup failed before Kater confirmed the session "
                        f"({code}): {message}"
                    ),
                    emit_callback=False,
                )

        elif msg_type == MSG_WRITE_BACK:
            if self.on_write_back:
                self.on_write_back(
                    data.get("request_id", ""),
                    data.get("connection_folder", ""),
                    data.get("files", []),
                    data.get("suppress_paths"),
                )

        elif msg_type == MSG_VALIDATION_RESULT:
            if self.on_validation_result:
                self.on_validation_result(data)

        elif msg_type == MSG_BUILD_RESULT:
            if self.on_build_result:
                self.on_build_result(data)

        elif msg_type == MSG_PONG:
            if self.on_pong:
                self.on_pong()

        else:
            logger.debug("ws_unknown_message_type", type=msg_type)

    async def _reconnect_with_backoff(self) -> bool:
        """Attempt reconnection with exponential backoff.

        Returns:
            True if reconnection succeeded, False otherwise.
        """
        console = Console(stderr=True)
        console.print("[yellow]Connection lost. Reconnecting...[/yellow]")
        logger.warning("ws_reconnecting", delay=self._reconnect_delay)

        while self._running:
            await asyncio.sleep(self._reconnect_delay)

            try:
                await self.connect()
                await self.send_connect(self._branch_name)
                console.print("[green]Reconnected to Kater[/green]")

                if self.on_reconnected:
                    self.on_reconnected()

                return True

            except AuthenticationError as exc:
                self._fatal_error = exc
                self._running = False
                logger.warning("ws_reconnect_auth_failed", message=str(exc))
                console.print(f"[red]{exc}[/red]")
                return False
            except Exception:
                logger.warning(
                    "ws_reconnect_failed",
                    delay=self._reconnect_delay,
                )
                # Exponential backoff with cap
                self._reconnect_delay = min(
                    self._reconnect_delay * 2,
                    MAX_RECONNECT_DELAY,
                )

        return False
