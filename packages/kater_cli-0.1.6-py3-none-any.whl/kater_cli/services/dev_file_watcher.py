"""File watcher for kater dev file sync.

Story: 3-4-file-watcher
Watches for file changes and branch switches to trigger sync.
"""

from __future__ import (
    annotations,  # noqa: TID251 — needed for TYPE_CHECKING guards and forward references; not a Pydantic model file
)

import asyncio
import subprocess
import time
from pathlib import Path
from typing import TYPE_CHECKING, Callable

import watchfiles
from kater_utils import get_logger
from watchfiles import Change

if TYPE_CHECKING:
    from kater_cli.services.file_sync import FileSyncService

logger = get_logger(__name__)

# Debounce time in milliseconds
DEBOUNCE_MS = 100


class DevFileWatcher:
    """Watches repository for file changes and branch switches.

    Handles:
    - File create/modify/delete events with debouncing
    - Hash comparison to suppress no-op events
    - .gitignore/.katerignore filtering
    - .git/HEAD monitoring for branch switches
    - Transient suppression of server-initiated write-back paths
    """

    def __init__(self, root_path: Path, file_sync: FileSyncService) -> None:
        """Initialize file watcher.

        Args:
            root_path: Repository root directory.
            file_sync: FileSyncService for ignore patterns and hashing.
        """
        self._root_path = root_path.resolve()
        self._file_sync = file_sync

        # State
        self._running = False
        self._watch_task: asyncio.Task[None] | None = None
        self._last_hashes: dict[str, str] = {}
        self._last_event_times: dict[str, float] = {}
        self._last_git_head: str | None = None

        # Cleanup threshold: prune event times older than 1 hour (in ms)
        self._event_time_ttl_ms: float = 60 * 60 * 1000

        # Cached git directory (resolved once, reused across calls)
        self._cached_git_dir: Path | None = None
        self._git_dir_resolved = False

        # Transient ignore set for server-initiated write-back paths.
        # Maps repo-relative path -> monotonic expiry time (ms).
        # Entries auto-expire after _SUPPRESS_TTL_MS so later user edits
        # to the same path are not silently swallowed.
        self._suppressed_paths: dict[str, float] = {}
        _SUPPRESS_TTL_MS = 5000  # 5 seconds
        self._suppress_ttl_ms = _SUPPRESS_TTL_MS

        # Callbacks - set by command layer
        self.on_file_changed: Callable[[str, bytes, str], None] | None = None
        self.on_file_deleted: Callable[[str], None] | None = None
        self.on_branch_switched: Callable[[str | None], None] | None = None

    # ------------------------------------------------------------------
    # Transient watcher suppression for server-initiated write-backs
    # ------------------------------------------------------------------

    def suppress_paths(self, paths: list[str]) -> None:
        """Register paths that should be temporarily ignored by the watcher.

        Called when the CLI receives a write_back message with suppress_paths.
        Each path expires after _suppress_ttl_ms to avoid masking later user edits.

        Args:
            paths: Repo-relative file paths to suppress.
        """
        expiry = time.monotonic() * 1000 + self._suppress_ttl_ms
        for p in paths:
            self._suppressed_paths[p] = expiry
        logger.debug(
            "watcher_paths_suppressed",
            path_count=len(paths),
            ttl_ms=self._suppress_ttl_ms,
        )

    def _is_suppressed(self, relative_path: str) -> bool:
        """Check if a path is in the transient suppress set and still valid.

        Expired entries are cleaned up lazily.
        """
        expiry = self._suppressed_paths.get(relative_path)
        if expiry is None:
            return False
        now = time.monotonic() * 1000
        if now < expiry:
            return True
        # Expired - remove
        del self._suppressed_paths[relative_path]
        return False

    def _resolve_git_dir(self) -> Path | None:
        """Resolve the git directory, walking up parent directories if needed.

        The result is cached after the first call since the git directory
        location does not change during a session.

        Handles:
        - Direct .git directory (normal repos)
        - .git file with gitdir: pointer (submodules)
        - Git dirs in parent directories (monorepo/submodule projects)

        Returns:
            Path to the .git directory, or None if not found.
        """
        if self._git_dir_resolved:
            return self._cached_git_dir

        current = self._root_path
        while True:
            dot_git = current / ".git"
            if dot_git.is_dir():
                self._cached_git_dir = dot_git
                self._git_dir_resolved = True
                logger.debug("git_dir_resolved", git_dir=str(dot_git))
                return dot_git
            if dot_git.is_file():
                try:
                    content = dot_git.read_text().strip()
                    if content.startswith("gitdir:"):
                        gitdir_path = content[len("gitdir:") :].strip()
                        resolved = (current / gitdir_path).resolve()
                        if resolved.is_dir():
                            self._cached_git_dir = resolved
                            self._git_dir_resolved = True
                            logger.debug(
                                "git_dir_resolved_submodule",
                                git_dir=str(resolved),
                                gitdir_pointer=str(dot_git),
                            )
                            return resolved
                        logger.debug(
                            "git_dir_broken_pointer",
                            dot_git=str(dot_git),
                            gitdir_target=str(resolved),
                        )
                except OSError as e:
                    logger.debug("git_dir_read_failed", dot_git=str(dot_git), error=str(e))
            parent = current.parent
            if parent == current:  # reached filesystem root
                self._cached_git_dir = None
                self._git_dir_resolved = True
                logger.debug("git_dir_not_found", root_path=str(self._root_path))
                return None
            current = parent

    def _read_git_head(self) -> str | None:
        """Read current .git/HEAD ref.

        Uses _resolve_git_dir() to find the git directory, which may be
        in a parent directory (e.g., when kater root != git root).

        Returns:
            The contents of .git/HEAD (e.g., 'ref: refs/heads/main'),
            or None if the git directory or HEAD file can't be found/read.
        """
        git_dir = self._resolve_git_dir()
        if git_dir is None:
            return None
        git_head = git_dir / "HEAD"
        if not git_head.exists():
            return None
        try:
            return git_head.read_text().strip()
        except OSError as e:
            logger.debug("git_head_read_failed", error=str(e))
            return None

    def get_branch_name(self) -> str | None:
        """Get the current short branch name from .git/HEAD.

        Returns:
            Short branch name (e.g., "main", "feature-xyz"),
            a truncated commit hash for detached HEAD state,
            or None if .git/HEAD cannot be read.
        """
        head = self._read_git_head()
        if head is None:
            return None
        if head.startswith("ref: refs/heads/"):
            return head[len("ref: refs/heads/") :]
        # Detached HEAD (common in submodules): try to resolve to a branch name
        branch = self._resolve_detached_head_branch(head)
        if branch is not None:
            return branch
        # Fallback: return shortened hash
        return head[:12]

    def _resolve_detached_head_branch(self, commit_hash: str) -> str | None:
        """Try to find a branch name that points at the given commit.

        Uses `git branch --points-at` to find branches whose tip matches
        the detached HEAD commit. Prefers local branches; skips HEAD pointers.

        Args:
            commit_hash: Full or partial commit hash from .git/HEAD.

        Returns:
            Branch name if found, None otherwise.
        """
        git_dir = self._resolve_git_dir()
        if git_dir is None:
            return None
        try:
            result = subprocess.run(
                ["git", "--git-dir", str(git_dir), "branch", "-a", "--points-at", commit_hash],
                capture_output=True,
                text=True,
                timeout=5,
            )
            if result.returncode != 0:
                return None
            for line in result.stdout.splitlines():
                name = line.strip().lstrip("* ")
                # Skip HEAD pointer lines like "remotes/origin/HEAD -> origin/main"
                if not name or "->" in name:
                    continue
                # Prefer local branches over remote-tracking ones
                if not name.startswith("remotes/"):
                    return name
            # Fall back to first remote branch (strip remotes/origin/ prefix)
            for line in result.stdout.splitlines():
                name = line.strip().lstrip("* ")
                if not name or "->" in name:
                    continue
                if name.startswith("remotes/origin/"):
                    return name[len("remotes/origin/") :]
        except (subprocess.TimeoutExpired, OSError) as e:
            logger.debug("resolve_detached_head_failed", error=str(e))
        return None

    def _check_branch_switch(self) -> bool:
        """Check if branch has changed since last check.

        Returns:
            True if the branch changed, False otherwise.
        """
        current_head = self._read_git_head()
        if current_head != self._last_git_head:
            self._last_git_head = current_head
            return True
        return False

    def _should_process(self, path: str) -> bool:
        """Check if event should be processed based on debounce timing.

        Args:
            path: Relative file path.

        Returns:
            True if event should be processed (past debounce window).
        """
        now = time.monotonic() * 1000  # Convert to ms
        last_time = self._last_event_times.get(path, 0)

        if now - last_time < DEBOUNCE_MS:
            return False  # Skip, too soon

        self._last_event_times[path] = now

        # Periodic cleanup: remove stale entries older than TTL
        # Only run cleanup occasionally to avoid overhead on every event
        if len(self._last_event_times) > 1000:
            self._prune_stale_event_times(now)

        return True

    def _prune_stale_event_times(self, now: float) -> None:
        """Remove event time entries older than TTL to prevent memory leaks."""
        stale_keys = [
            k for k, v in self._last_event_times.items() if now - v > self._event_time_ttl_ms
        ]
        for k in stale_keys:
            del self._last_event_times[k]

    def _hash_changed(self, relative_path: str) -> tuple[bool, bytes | None, str | None]:
        """Check if file content has changed since last sync.

        Args:
            relative_path: Path relative to repo root.

        Returns:
            Tuple of (changed: bool, content: bytes | None, hash: str | None).
            If changed is False, content and hash will be None.
        """
        try:
            entry = self._file_sync.read_and_hash_file(relative_path)
            new_hash = entry["hash"]
            old_hash = self._last_hashes.get(relative_path)

            if new_hash == old_hash:
                return (False, None, None)  # No change

            self._last_hashes[relative_path] = new_hash
            return (True, entry["content"], new_hash)

        except FileNotFoundError:
            # File was deleted between event and read
            return (False, None, None)
        except OSError as e:
            # Permission denied, I/O errors, etc.
            logger.warning("hash_check_failed", path=relative_path, error=str(e))
            return (False, None, None)

    async def _process_change(self, change_type: Change, path_str: str) -> None:
        """Process a single file change event.

        Args:
            change_type: The type of change (added, modified, deleted).
            path_str: Absolute path to the changed file.
        """
        path = Path(path_str)

        # Check for .git/HEAD change (branch switch detection)
        if path.name == "HEAD" and ".git" in path.parts:
            if self._check_branch_switch() and self.on_branch_switched:
                self.on_branch_switched(self.get_branch_name())
            return

        # Get relative path
        try:
            relative_path = path.relative_to(self._root_path).as_posix()
        except ValueError:
            # Path outside repo, skip
            return

        # Filter ignored files (using FileSyncService's ignore patterns)
        if self._file_sync.is_ignored(relative_path):
            return

        # Suppress server-initiated write-back paths (transient ignore set)
        if self._is_suppressed(relative_path):
            logger.debug("watcher_path_suppressed", path=relative_path)
            return

        # Debounce
        if not self._should_process(relative_path):
            return

        if change_type == Change.deleted:
            if self.on_file_deleted:
                self.on_file_deleted(relative_path)
            # Clean up both caches to prevent memory leaks
            self._last_hashes.pop(relative_path, None)
            self._last_event_times.pop(relative_path, None)
            return

        # Skip directories — only files can be hashed/synced
        if path.is_dir():
            return

        # For added/modified, check hash
        changed, content, file_hash = self._hash_changed(relative_path)
        if changed and self.on_file_changed and content is not None and file_hash is not None:
            self.on_file_changed(relative_path, content, file_hash)

    async def _watch_loop(self) -> None:
        """Main watch loop processing file changes."""
        try:
            async for changes in watchfiles.awatch(  # pyright: ignore[reportUnknownMemberType]
                self._root_path,
                rust_timeout=100,  # Check every 100ms
                debounce=50,  # Internal debounce (we add more)
            ):
                if not self._running:
                    break
                for change_type, path_str in changes:
                    await self._process_change(change_type, path_str)
        except asyncio.CancelledError:
            pass
        except Exception as e:
            logger.error("watch_loop_error", error=str(e))

    async def start(self) -> None:
        """Start the file watcher."""
        if self._watch_task is not None:
            return  # Already running

        self._running = True
        self._last_git_head = self._read_git_head()
        self._watch_task = asyncio.create_task(self._watch_loop())
        logger.info("dev_file_watcher_started", path=str(self._root_path))

    async def stop(self) -> None:
        """Stop the file watcher."""
        self._running = False
        if self._watch_task:
            self._watch_task.cancel()
            try:
                await self._watch_task
            except asyncio.CancelledError:
                pass
            self._watch_task = None
        logger.info("dev_file_watcher_stopped")
