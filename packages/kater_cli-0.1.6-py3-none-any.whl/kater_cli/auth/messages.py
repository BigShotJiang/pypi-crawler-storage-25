"""Shared user-facing authentication messages for the CLI."""

ACCOUNT_SIGNUP_MESSAGE = "If you don't have a Kater account, run `kater signup` to create one."
LOGIN_PAGE_SIGNUP_MESSAGE = (
    "If you don't have a Kater account, use the sign-up link on the login page."
)
NOT_LOGGED_IN_MESSAGE = (
    f"Not logged in. Run `kater login` to authenticate. {ACCOUNT_SIGNUP_MESSAGE}"
)
REAUTH_MESSAGE = "Session expired. Run `kater logout` then `kater login` to re-authenticate."
AUTHENTICATION_FAILED_MESSAGE = (
    f"Authentication failed. Run `kater login` to re-authenticate. {ACCOUNT_SIGNUP_MESSAGE}"
)
