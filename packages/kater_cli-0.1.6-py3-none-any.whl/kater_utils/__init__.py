"""Shared lightweight utilities for Kater CLI and server."""

from typing import TYPE_CHECKING, Any

from kater_utils.file_utils import (
    BUILTIN_EXCLUSIONS,
    hash_file,
    load_ignore_patterns,
)
from kater_utils.logging import (
    configure_logging,
    configure_logging_from_settings,
    get_logger,
)
from kater_utils.repo import (
    CONFIG_FILENAME,
    detect_kater_folder,
    find_kater_root_scanning_down,
    find_repo_root,
)

if TYPE_CHECKING:
    from kater_utils.scaffold_templates import (
        build_root_scaffold_items as build_root_scaffold_items,
    )
    from kater_utils.scaffold_templates import (
        get_optional_github_scaffold_paths as get_optional_github_scaffold_paths,
    )
    from kater_utils.scaffold_templates import (
        get_required_force_scaffold_paths as get_required_force_scaffold_paths,
    )
    from kater_utils.scaffold_templates import (
        get_resource_scaffold_paths as get_resource_scaffold_paths,
    )
    from kater_utils.scaffold_templates import (
        get_root_scaffold_paths as get_root_scaffold_paths,
    )

__all__ = [
    # Logging
    "configure_logging",
    "configure_logging_from_settings",
    "get_logger",
    # File utilities
    "BUILTIN_EXCLUSIONS",
    "hash_file",
    "load_ignore_patterns",
    # Repo detection
    "CONFIG_FILENAME",
    "detect_kater_folder",
    "find_kater_root_scanning_down",
    "find_repo_root",
    # Scaffold templates
    "build_root_scaffold_items",
    "get_root_scaffold_paths",
    "get_resource_scaffold_paths",
    "get_optional_github_scaffold_paths",
    "get_required_force_scaffold_paths",
]


def __getattr__(name: str) -> Any:
    """Lazy-load optional public API to avoid import-time scaffolding side effects."""
    if name in {
        "build_root_scaffold_items",
        "get_root_scaffold_paths",
        "get_resource_scaffold_paths",
        "get_optional_github_scaffold_paths",
        "get_required_force_scaffold_paths",
    }:
        from kater_utils import scaffold_templates

        return getattr(scaffold_templates, name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
