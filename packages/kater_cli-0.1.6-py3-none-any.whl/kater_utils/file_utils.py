"""Shared file utilities for ignore-pattern loading and content hashing.

Extracted from the CLI's FileSyncService so that both the CLI and the
language server can reuse the same logic without importing kater_cli.
"""

import hashlib
from pathlib import Path

import pathspec

from kater_utils.logging import get_logger

logger = get_logger(__name__)

# Built-in exclusions always applied regardless of .gitignore/.katerignore
# Using tuple for immutability
BUILTIN_EXCLUSIONS: tuple[str, ...] = (
    ".git*",  # .git/, .gitignore, .gitkeep, .gitattributes, .github/, etc.
    "node_modules/",
    "__pycache__/",
    ".venv/",
    ".env",
    ".env.*",  # .env.local, .env.development, etc.
    # Editor temp/swap files (atomic saves, vim, emacs, etc.)
    "*.tmp",
    "*.tmp.*",
    "*.swp",
    "*.swo",
    "*~",
    ".DS_Store",
)


def load_ignore_patterns(root_path: Path) -> pathspec.PathSpec:
    """Load ignore patterns from .gitignore and .katerignore.

    Combines:
    1. Built-in exclusions (always applied)
    2. .gitignore patterns (if exists)
    3. .katerignore patterns (if exists)

    Args:
        root_path: The repository root directory.

    Returns:
        Combined PathSpec for all ignore patterns.
    """
    patterns: list[str] = list(BUILTIN_EXCLUSIONS)

    # Load .gitignore
    gitignore_path = root_path / ".gitignore"
    if gitignore_path.exists():
        try:
            patterns.extend(gitignore_path.read_text(encoding="utf-8").splitlines())
        except Exception as e:
            logger.warning("failed_to_read_gitignore", error=str(e))

    # Load .katerignore (optional)
    katerignore_path = root_path / ".katerignore"
    if katerignore_path.exists():
        try:
            patterns.extend(katerignore_path.read_text(encoding="utf-8").splitlines())
        except Exception as e:
            logger.warning("failed_to_read_katerignore", error=str(e))

    return pathspec.PathSpec.from_lines("gitignore", patterns)


def hash_file(content: bytes) -> str:
    """Compute SHA-256 hash of file content.

    Args:
        content: Raw file content as bytes.

    Returns:
        Lowercase hexadecimal SHA-256 digest.
    """
    return hashlib.sha256(content).hexdigest()
