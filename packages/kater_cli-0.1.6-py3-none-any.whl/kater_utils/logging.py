"""Structured logging configuration for Kater applications.

This module provides a unified logging configuration using structlog.
All Kater Python apps should call configure_logging() at startup.

Usage:
    from kater_utils.logging import configure_logging, get_logger

    # At app startup
    configure_logging(log_level="INFO", json_logs=False)

    # In modules
    logger = get_logger(__name__)
    logger.info("event_name", key=value)
"""

import logging  # noqa: TID251 — this module configures stdlib logging for structlog integration
import re
import sys
from typing import Any

import structlog
from structlog.types import Processor
from structlog.typing import EventDict

try:
    from opentelemetry import trace as otel_trace
except ImportError:  # pragma: no cover - optional dependency until observability is enabled
    otel_trace = None

# Redact sensitive query parameters (token, key, secret) from log messages.
# Matches ?token=<value> or &token=<value> and replaces the value with [REDACTED].
_SENSITIVE_QS_RE = re.compile(
    r"([?&])(token|key|secret|password)=[^&\s\"']*",
    re.IGNORECASE,
)


class _SensitiveQueryParamFilter(logging.Filter):
    """Redact sensitive query-string values in log records.

    Prevents credentials (JWTs, API keys) passed as URL query parameters
    from appearing in server/proxy/access logs.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        if record.args:
            record.args = tuple(
                _SENSITIVE_QS_RE.sub(r"\1\2=[REDACTED]", str(a)) if isinstance(a, str) else a
                for a in record.args
            )
        if isinstance(record.msg, str):
            record.msg = _SENSITIVE_QS_RE.sub(r"\1\2=[REDACTED]", record.msg)
        return True


def get_logger(name: str | None = None) -> structlog.stdlib.BoundLogger:
    """Get a structlog logger instance.

    Args:
        name: Logger name, typically __name__

    Returns:
        Configured structlog logger
    """
    return structlog.get_logger(name)


def _add_otel_trace_context(
    logger: Any,
    method_name: str,
    event_dict: EventDict,
) -> EventDict:
    """Attach active OpenTelemetry trace identifiers to a log event when available."""
    del logger, method_name
    if otel_trace is None:
        return event_dict

    span = otel_trace.get_current_span()
    span_context = span.get_span_context()
    if not span_context.is_valid:
        return event_dict

    event_dict["trace_id"] = format(span_context.trace_id, "032x")
    event_dict["span_id"] = format(span_context.span_id, "016x")
    return event_dict


def configure_logging(
    *,
    log_level: str | int = "INFO",
    json_logs: bool = True,
    log_file: str | None = None,
    extra_processors: list[Processor] | None = None,
) -> None:
    """Configure structlog for the application.

    This configures both structlog and standard library logging so that
    third-party libraries using standard logging are also handled properly.

    Args:
        log_level: Logging level (DEBUG, INFO, WARNING, ERROR, or int)
        json_logs: If True, output JSON logs (production). If False, use
            colored console output (development).
        log_file: Optional file path to write logs to (in addition to stdout)

    Example:
        # Development
        configure_logging(log_level="DEBUG", json_logs=False)

        # Production
        configure_logging(log_level="INFO", json_logs=True)
    """
    # Convert string log level to int
    if isinstance(log_level, str):
        log_level = getattr(logging, log_level.upper(), logging.INFO)

    # Shared processors for all log entries
    shared_processors: list[Processor] = [
        structlog.contextvars.merge_contextvars,
        _add_otel_trace_context,
        *(extra_processors or []),
        structlog.stdlib.add_log_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.UnicodeDecoder(),
    ]

    if json_logs:
        # Production: JSON output
        shared_processors.append(structlog.processors.format_exc_info)
        renderer: Processor = structlog.processors.JSONRenderer()
    else:
        # Development: Colored console output
        shared_processors.append(structlog.dev.set_exc_info)
        renderer = structlog.dev.ConsoleRenderer(colors=True)

    # Configure structlog
    structlog.configure(
        processors=[
            *shared_processors,
            structlog.stdlib.ProcessorFormatter.wrap_for_formatter,
        ],
        logger_factory=structlog.stdlib.LoggerFactory(),
        wrapper_class=structlog.stdlib.BoundLogger,
        cache_logger_on_first_use=True,
    )

    # Create formatter for stdlib logging
    formatter = structlog.stdlib.ProcessorFormatter(
        foreign_pre_chain=shared_processors,
        processors=[
            structlog.stdlib.ProcessorFormatter.remove_processors_meta,
            renderer,
        ],
    )

    # Configure handlers
    handlers: list[logging.Handler] = []

    # Console handler (stdout)
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    handlers.append(console_handler)

    # Optional file handler
    if log_file:
        file_handler = logging.FileHandler(log_file)
        file_handler.setFormatter(formatter)
        handlers.append(file_handler)

    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)

    # Remove existing handlers and add new ones
    root_logger.handlers.clear()
    for handler in handlers:
        root_logger.addHandler(handler)

    # Override uvicorn's loggers so they respect our configured level.
    # Uvicorn sets its own handlers with propagate=False and level=INFO,
    # bypassing the root logger level entirely. We clear its handlers
    # and enable propagation so uvicorn logs route through structlog.
    sensitive_filter = _SensitiveQueryParamFilter()
    for uvicorn_logger_name in ("uvicorn", "uvicorn.error", "uvicorn.access"):
        uvicorn_logger = logging.getLogger(uvicorn_logger_name)
        uvicorn_logger.handlers.clear()
        uvicorn_logger.propagate = True
        uvicorn_logger.addFilter(sensitive_filter)

    # Quiet noisy third-party loggers
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("httpcore").setLevel(logging.WARNING)
    logging.getLogger("asyncio").setLevel(logging.WARNING)
    logging.getLogger("hatchet_sdk").setLevel(logging.WARNING)
    logging.getLogger("hatchet").setLevel(log_level)
    logging.getLogger("snowflake.connector").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.engine").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.pool").setLevel(logging.WARNING)
    logging.getLogger("sqlalchemy.dialects").setLevel(logging.WARNING)


def configure_logging_from_settings(settings: Any) -> None:
    """Configure logging using a settings object.

    Expects settings to have:
    - log_level_int: int (logging level as integer)
    - is_dev: bool (True for development mode)

    Args:
        settings: Settings object with log_level_int and is_dev attributes
    """
    configure_logging(
        log_level=settings.log_level_int,
        json_logs=not settings.is_dev,
        log_file=getattr(settings, "observability_log_file", None),
    )
