"""Kater repository root detection.

Provides find_repo_root() for walking up the directory tree to locate a
kater.config.yaml file. Unlike the CLI variant, this version returns None
on failure instead of raising typer.Exit, making it suitable for use by the
language server and other non-CLI consumers.
"""

from pathlib import Path

CONFIG_FILENAME = "kater.config.yaml"


def find_repo_root(start: Path | None = None) -> Path | None:
    """Walk up from start (or cwd) to find kater.config.yaml.

    Args:
        start: Directory to start searching from. Defaults to cwd.

    Returns:
        Path to the repo root directory containing kater.config.yaml,
        or None if not found in any parent directory.
    """
    current = (start or Path.cwd()).resolve()

    while True:
        if (current / CONFIG_FILENAME).exists():
            return current
        parent = current.parent
        if parent == current:
            break
        current = parent

    return None


def find_kater_root_scanning_down(start: Path) -> Path | None:
    """Scan immediate subdirectories of start for kater.config.yaml.

    Fallback for when VS Code or the CLI is opened at a monorepo root and
    the kater project lives in a subfolder. Only scans one level deep.

    Args:
        start: Directory to scan. Non-hidden immediate children are checked.

    Returns:
        Path to the first child directory containing kater.config.yaml,
        or None if not found.
    """
    try:
        for child in sorted(start.iterdir()):
            if (
                child.is_dir()
                and not child.name.startswith(".")
                and (child / CONFIG_FILENAME).exists()
            ):
                return child
    except OSError:
        pass
    return None


def detect_kater_folder(tree_paths: set[str]) -> str | None:
    """Scan a flat set of repo paths for kater.config.yaml to detect the kater subfolder.

    Returns the parent folder (e.g. 'kater') or None if kater is at root.
    Returns None if multiple kater.config.yaml files are found (ambiguous).
    """
    # Root-level config takes priority
    if "kater.config.yaml" in tree_paths:
        return None  # kater project is at the repo root
    # Look for configs in subdirectories
    matches = [p for p in tree_paths if p.endswith("/kater.config.yaml")]
    if len(matches) == 1:
        return matches[0].removesuffix("/kater.config.yaml")
    # Multiple matches or none found — default to root (null)
    return None
