"""Scaffold template content for Kater CLI project initialization."""

import textwrap
import uuid
from pathlib import Path
from typing import cast


def _inject_docstring(source: str, signature: str, docstring: str) -> str:
    """Insert a docstring immediately after a generated top-level function signature."""
    lines = [line.rstrip() for line in docstring.strip().splitlines()]
    block = "\n".join(
        [
            signature,
            '    """',
            *[f"    {line}" if line else "" for line in lines],
            '    """',
        ]
    )
    return source.replace(signature, block, 1)


def _build_definition_content(
    *,
    kater_id: str,
    name: str,
    description: str,
    inputs: list[str],
    params: list[str],
    input_comment: str,
    param_comment: str,
    input_comments: dict[str, str] | None = None,
    param_comments: dict[str, str] | None = None,
) -> str:
    """Build a commented YAML definition for a scaffolded insight."""
    input_comments = input_comments or {}
    param_comments = param_comments or {}
    lines = [
        f"kater_id: {kater_id}",
        f"name: {name}",
        f"description: {description}",
        "entrypoint: insight.py:run",
        f"# {input_comment}",
        "inputs:",
    ]
    for line in inputs:
        comment = input_comments.get(line)
        if comment is not None:
            lines.append(f"  # {comment}")
        lines.append(line)
    lines.extend(
        [
            f"# {param_comment}",
            "params:",
        ]
    )
    for line in params:
        comment = param_comments.get(line)
        if comment is not None:
            lines.append(f"  # {comment}")
        lines.append(line)
    lines.append("")
    return "\n".join(lines)


def _load_default_chart_theme_yaml() -> str:
    """Load the canonical chart-theme YAML verbatim.

    The single source of truth is
    ``packages/components_core/src/theme/kater-chart-theme.yaml``. This
    loader resolves it in two contexts without ever duplicating the content:

    1. **Installed wheel** — hatch ``force-include`` copies the YAML to
       ``kater_utils/assets/kater-chart-theme.yaml`` inside the wheel
       (see ``packages/utils/pyproject.toml`` and ``apps/cli/pyproject.toml``).
    2. **Editable / workspace install** — the module lives in the source
       tree at ``packages/utils/src/kater_utils/scaffold_templates.py``, so
       we walk up to ``packages/`` and read the file from
       ``components_core/src/theme/kater-chart-theme.yaml`` directly.

    Drift is impossible by construction: both contexts read the exact same
    file the TypeScript side uses as its source of truth. A guardrail test
    in ``packages/utils/tests/test_scaffold_templates.py`` additionally
    verifies the loaded content matches the canonical file.
    """
    module_dir = Path(__file__).resolve().parent

    bundled = module_dir / "assets" / "kater-chart-theme.yaml"
    if bundled.is_file():
        return bundled.read_text(encoding="utf-8")

    # Editable install: packages/utils/src/kater_utils/ → packages/
    packages_root = module_dir.parents[2]
    source = packages_root / "components_core" / "src" / "theme" / "kater-chart-theme.yaml"
    if source.is_file():
        return source.read_text(encoding="utf-8")

    raise FileNotFoundError(
        "Could not locate kater-chart-theme.yaml. Checked:\n"
        f"  - {bundled} (bundled wheel location)\n"
        f"  - {source} (editable install source). "
        "The file is required at import time for scaffold templates; ensure "
        "hatch force-include is configured to ship it with the wheel."
    )


def _load_root_resource_items() -> list[tuple[str, str]]:
    """Load canonical resources/ files for the root scaffold."""
    module_dir = Path(__file__).resolve().parent

    bundled_dir = module_dir / "assets" / "resources"
    if bundled_dir.is_dir():
        resources_dir = bundled_dir
    else:
        packages_root = module_dir.parents[2]
        resources_dir = packages_root / "core" / "src" / "kater_core" / "templates" / "resources"

    if not resources_dir.is_dir():
        raise FileNotFoundError(
            "Could not locate scaffold resources. Checked:\n"
            f"  - {bundled_dir} (bundled wheel location)\n"
            f"  - {resources_dir} (editable install source). "
            "The resource directory is required at import time for scaffold templates; "
            "ensure hatch force-include is configured to ship it with the wheel."
        )

    items: list[tuple[str, str]] = []
    for path in sorted(resources_dir.rglob("*")):
        if path.is_file():
            rel = path.relative_to(resources_dir)
            items.append((f"resources/{rel.as_posix()}", path.read_text(encoding="utf-8")))
    return items


SCAFFOLDED_README_TEMPLATE = """\
# {repository_name}

> Your Kater semantic layer repository. This repo contains your data model \
definitions, governance policies, and configuration — all managed as code.

## Quick Start

### 1. Clone and Initialize

```bash
git clone <repo-url>
cd {repository_name}
git submodule update --init --recursive
```

### 2. Explore the Sample Repository

Browse `__sample_client_repo/` for a complete working example of a Kater \
semantic layer with models, queries, dashboards, and governance.

### 3. Continue Onboarding

Return to Kater to complete the remaining setup steps:
- Connect your data warehouse
- Run schema sync to import your tables
- Start building your semantic layer

Visit [kater.ai/docs](https://kater.ai/docs) for complete documentation.

## Repository Structure

| Directory | Purpose |
| --- | --- |
| `_admin/` | Governance configuration (query policies, access grants) |
| `theme/` | UI layout config and custom theme assets |
| `resources/` | LLM reference documents (DSL specs, query guides, system prompts) |
| `__sample_client_repo/` | Reference implementation (git submodule) |
| `kater.config.yaml` | Project-level configuration |

### Directories NOT in This Repo

| Directory | Reason |
| --- | --- |
| `_admin/tenants/` | Generated at runtime by Kater. Read-only, stored locally. |

## Developer Workflow

### Making Changes

1. Create a feature branch
2. Edit model files (views, queries, measures, dimensions)
3. Push your branch and open a PR
4. Kater validates your changes automatically via webhooks
5. Merge to main — Kater syncs the updated configuration

## Governance (`_admin/`)

- `_admin/query_policy.yaml` — Controls query execution rules and limits
- `_admin/integrations.yaml` — External integration configuration
- `_admin/grants/` — Access control (filters, grants, attributes)

## Runtime Directories

The `_admin/tenants/` directory is generated at runtime by the Kater platform. \
It is stored locally, not committed to the repository, and is read-only from \
the client's perspective. It contains tenant configuration and tenant group \
definitions.

## Sample Repository

The `__sample_client_repo/` directory is a git submodule pointing to Kater's \
public sample repository. Use it as a reference for how to structure your \
semantic layer.

To initialize or update:

```bash
git submodule update --init --recursive
```

## Links / Documentation

- [Kater Documentation](https://kater.ai/docs)
- [Getting Started Guide](https://kater.ai/docs/getting-started)
- [Semantic Layer Reference](https://kater.ai/docs/semantic-layer)
- [Governance Guide](https://kater.ai/docs/governance)

## Support

Questions? Visit [kater.ai/docs](https://kater.ai/docs) or contact support.
"""

QUERY_POLICY_TEMPLATE = """\
kater_id: {kater_id}

# What can the AI do by default? (can be overridden per tenant group)
#   strict  — AI answers from pre-built queries/playbooks only
#   guided  — AI can also request reports and dashboards on behalf of the user (recommended)
#   free    — All guided capabilities, plus custom SQL and Python
default_mode: guided

modes:
  strict:
    description: 'AI answers from pre-built queries and playbooks only'
    llm_capabilities:
      write_custom_sql: false
      write_custom_python: false
      request_reports_on_behalf_of_user: false
      request_dashboards_on_behalf_of_user: false
      create_alert_on_behalf_of_user: false
      schedule_delivery_for_user: false

  guided:
    description: 'AI can request reports, dashboards, alerts, and deliveries on behalf of the user'
    llm_capabilities:
      write_custom_sql: false
      write_custom_python: false
      request_reports_on_behalf_of_user: true
      request_dashboards_on_behalf_of_user: true
      create_alert_on_behalf_of_user: true
      schedule_delivery_for_user: true

  free:
    description: 'Full capabilities including custom SQL and Python'
    llm_capabilities:
      write_custom_sql: true
      write_custom_python: true
      request_reports_on_behalf_of_user: true
      request_dashboards_on_behalf_of_user: true
      create_alert_on_behalf_of_user: true
      schedule_delivery_for_user: true

# Give different customer segments different AI freedom levels.
# Assign tenants to these groups in your tenant config.
# group_overrides:
#   - group: free_tier
#     mode: strict
#   - group: enterprise
#     mode: free

# Hard limits that apply to ALL modes — protects against runaway queries.
global_guardrails:
  max_query_rows: 100000
  max_query_timeout_seconds: 300

# Audit log retention (all query/event logging is on by default).
audit:
  retention_days: 90
"""

INTEGRATIONS_PLACEHOLDER = """\
# Integrations Configuration
# Define external integrations and data source connections.
# See: https://kater.ai/docs/governance/integrations
"""

GRANTS_ACCESS_FILTERS_PLACEHOLDER = """\
# Access Filters
# Define row-level security filters for tenant data isolation.
# See: https://kater.ai/docs/governance/access-filters
"""

GRANTS_ACCESS_GRANTS_PLACEHOLDER = """\
# Access Grants
# Define permission grants for users and roles.
# See: https://kater.ai/docs/governance/access-grants
"""

GRANTS_ATTRIBUTES_PLACEHOLDER = """\
# Attributes
# Define user and tenant attributes used in access policies.
# See: https://kater.ai/docs/governance/attributes
"""


def _build_trend_change_insight_python() -> str:
    source = (
        textwrap.dedent(
            """\
        from typing import Any

        import polars as pl


        def _active_threshold_checks(
            absolute_delta: float,
            relative_delta: float,
            params: dict[str, Any],
        ) -> bool:
            min_absolute_delta = float(params.get("min_absolute_delta", 0) or 0)
            min_relative_delta = float(params.get("min_relative_delta", 0) or 0)
            checks: list[bool] = []
            if min_absolute_delta > 0:
                checks.append(abs(absolute_delta) < min_absolute_delta)
            if min_relative_delta > 0:
                checks.append(abs(relative_delta) < min_relative_delta)
            return bool(checks) and all(checks)


        def _direction_from_delta(delta: float, directionality: str) -> str:
            if delta == 0:
                return "stable"
            improving_when_positive = directionality != "lower_is_better"
            if improving_when_positive:
                return "improving" if delta > 0 else "declining"
            return "improving" if delta < 0 else "declining"


        def _signal_rank(direction: str) -> int:
            if direction == "improving":
                return 1
            if direction == "stable":
                return 0
            return -1


        def _build_signal_record(
            *,
            series_value: str | None,
            compare_mode: str,
            direction: str,
            absolute_delta: float,
            relative_delta: float | None,
            earlier_period: object,
            later_period: object,
            earlier_value: float,
            later_value: float,
        ) -> dict[str, object]:
            return {
                "series": series_value,
                "compare_mode": compare_mode,
                "direction": direction,
                "absolute_delta": absolute_delta,
                "relative_delta": relative_delta,
                "earlier_period": earlier_period,
                "later_period": later_period,
                "earlier_value": earlier_value,
                "later_value": later_value,
                "rank": _signal_rank(direction),
            }


        def _summarize_group(
            frame: pl.DataFrame,
            *,
            period_column: str,
            value_column: str,
            series_column: str | None,
            params: dict[str, Any],
            follow_ups: list[Any],
        ) -> dict[str, Any]:
            series_value = None
            if series_column is not None and series_column in frame.columns and frame.height > 0:
                series_value = frame[series_column][0]

            compare_mode = str(params.get("compare_mode", "endpoints") or "endpoints")
            directionality = str(params.get("directionality", "higher_is_better") or "higher_is_better")
            reversal_threshold = float(params.get("reversal_threshold", 0) or 0)
            min_points = max(2, int(params.get("min_points", 2) or 2))

            ordered = frame.sort(period_column)
            if ordered.height < min_points:
                return {
                    "summary": {
                        "text": "Not enough points to assess the trend.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "compare_mode": compare_mode,
                        "directionality": directionality,
                        "points": ordered.height,
                    },
                    "signal": None,
                }

            values = [float(value) for value in ordered[value_column].to_list()]
            periods = ordered[period_column].to_list()

            if compare_mode == "adjacent" and len(values) >= 2:
                deltas = [current - previous for previous, current in zip(values, values[1:])]
                absolute_delta = deltas[-1]
                baseline = values[-2]
                relative_delta = abs(absolute_delta) / abs(baseline) if baseline else abs(absolute_delta)
                recent_sign = 0
                prior_sign = 0
                for delta in reversed(deltas[:-1]):
                    if abs(delta) >= reversal_threshold:
                        prior_sign = 1 if delta > 0 else -1
                        break
                if abs(absolute_delta) >= reversal_threshold:
                    recent_sign = 1 if absolute_delta > 0 else -1
                reversal = bool(prior_sign and recent_sign and prior_sign != recent_sign)
                instability = sum(
                    1
                    for previous, current in zip(deltas, deltas[1:])
                    if previous != 0 and current != 0 and (previous > 0) != (current > 0)
                ) >= 2
                start_value = values[-2]
                end_value = values[-1]
                start_period = periods[-2]
                end_period = periods[-1]
            else:
                absolute_delta = values[-1] - values[0]
                baseline = values[0]
                relative_delta = abs(absolute_delta) / abs(baseline) if baseline else abs(absolute_delta)
                reversal = False
                instability = False
                start_value = values[0]
                end_value = values[-1]
                start_period = periods[0]
                end_period = periods[-1]

            series_display = str(series_value) if series_value is not None else None
            direction = _direction_from_delta(absolute_delta, directionality)
            signal_record = _build_signal_record(
                series_value=series_display,
                compare_mode=compare_mode,
                direction=direction,
                absolute_delta=absolute_delta,
                relative_delta=relative_delta,
                earlier_period=start_period,
                later_period=end_period,
                earlier_value=start_value,
                later_value=end_value,
            )

            if _active_threshold_checks(absolute_delta, relative_delta, params):
                return {
                    "summary": {
                        "text": "Trend change is too small to flag.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "absolute_delta": absolute_delta,
                        "relative_delta": relative_delta,
                        "compare_mode": compare_mode,
                        "directionality": directionality,
                        "series": series_display,
                    },
                    "signal": signal_record,
                }

            unit_label = f" for {series_display}" if series_display else ""
            evidence = [
                {"label": "Start period", "value": str(start_period)},
                {"label": "End period", "value": str(end_period)},
                {"label": "Start value", "value": start_value},
                {"label": "End value", "value": end_value},
                {"label": "Delta", "value": absolute_delta},
                {"label": "Relative delta", "value": relative_delta},
            ]

            findings: list[dict[str, Any]] = []
            if reversal:
                findings.append(
                    {
                                "kind": "trend_reversal",
                                "summary": f"Trend reversed{unit_label} after a recent {('gain' if directionality != 'lower_is_better' else 'drop')}.",
                                "severity": "warning",
                                "evidence": evidence,
                                "details": [
                                    f"The last two comparable points moved from {start_value} to {end_value}."
                                ],
                                "follow_ups": follow_ups,
                                "metadata": {
                                    "absolute_delta": absolute_delta,
                                    "relative_delta": relative_delta,
                                    "compare_mode": compare_mode,
                                    "directionality": directionality,
                                    "direction": direction,
                                    "series": series_display,
                                },
                    }
                )
            elif instability:
                findings.append(
                    {
                                "kind": "trend_instability",
                                "summary": f"Trend movement is unstable{unit_label} across the observed window.",
                                "severity": "warning",
                                "evidence": evidence,
                                "details": [
                                    f"Observed oscillation between {start_period} and {end_period}."
                                ],
                                "follow_ups": follow_ups,
                                "metadata": {
                                    "absolute_delta": absolute_delta,
                                    "relative_delta": relative_delta,
                                    "compare_mode": compare_mode,
                                    "directionality": directionality,
                                    "direction": direction,
                                    "series": series_display,
                                },
                    }
                )
            elif direction == "improving":
                findings.append(
                    {
                                "kind": "trend_improvement",
                                "summary": f"Trend improved{unit_label} from {start_value} to {end_value}.",
                                "severity": "positive",
                                "evidence": evidence,
                                "details": [
                                    f"Observed movement from {start_period} to {end_period}."
                                ],
                                "follow_ups": follow_ups,
                                "metadata": {
                                    "absolute_delta": absolute_delta,
                                    "relative_delta": relative_delta,
                                    "compare_mode": compare_mode,
                                    "directionality": directionality,
                                    "direction": direction,
                                    "series": series_display,
                                },
                    }
                )
            elif direction == "declining":
                findings.append(
                    {
                                "kind": "trend_decline",
                                "summary": f"Trend declined{unit_label} from {start_value} to {end_value}.",
                                "severity": "warning",
                                "evidence": evidence,
                                "details": [
                                    f"Observed movement from {start_period} to {end_period}."
                                ],
                                "follow_ups": follow_ups,
                                "metadata": {
                                    "absolute_delta": absolute_delta,
                                    "relative_delta": relative_delta,
                                    "compare_mode": compare_mode,
                                    "directionality": directionality,
                                    "direction": direction,
                                    "series": series_display,
                                },
                    }
                )

            summary_text = (
                f"Trend improved{unit_label} across the observed window."
                if direction == "improving"
                else (
                    f"Trend declined{unit_label} across the observed window."
                    if direction == "declining"
                    else "Trend is stable across the observed window."
                )
            )
            if reversal:
                summary_text = f"Trend reversed{unit_label} after an earlier move."
            elif instability:
                summary_text = f"Trend movement is unstable{unit_label} across the observed window."

            return {
                "summary": {
                    "text": summary_text,
                    "severity": "warning" if direction == "declining" or reversal or instability else "positive",
                },
                "findings": findings,
                "metadata": {
                    "absolute_delta": absolute_delta,
                    "relative_delta": relative_delta,
                    "compare_mode": compare_mode,
                    "directionality": directionality,
                    "series": series_display,
                },
                "signal": signal_record,
            }


        def run(*, inputs, params):
            frame = inputs["current"]
            follow_ups = list(params.get("follow_ups", []))
            period_column = "period"
            value_column = "value"
            series_column = "series" if "series" in frame.columns else None
            min_absolute_delta = float(params.get("min_absolute_delta", 0) or 0)
            min_relative_delta = float(params.get("min_relative_delta", 0) or 0)
            if series_column is None:
                groups = [frame]
            else:
                groups = frame.partition_by(series_column, maintain_order=True)

            results = [
                _summarize_group(
                    group,
                    period_column=period_column,
                    value_column=value_column,
                    series_column=series_column,
                    params=params,
                    follow_ups=follow_ups,
                )
                for group in groups
            ]

            findings: list[dict[str, Any]] = []
            summary = None
            metadata: dict[str, Any] | None = None
            series_ids = [
                str(result["metadata"]["series"])
                for result in results
                if result["metadata"] is not None and result["metadata"].get("series") is not None
            ]
            for result in results:
                findings.extend(result["findings"])
                if summary is None and len(results) == 1:
                    summary = result["summary"]
                if metadata is None and len(results) == 1:
                    metadata = result["metadata"]

            if len(results) > 1:
                valid_signals = [
                    result["signal"]
                    for result in results
                    if result.get("signal") is not None
                ]
                cross_series_findings = []
                if len(valid_signals) >= 2:
                    sorted_signals = sorted(
                        valid_signals,
                        key=lambda signal: (
                            int(signal["rank"]),
                            int(signal["rank"]) * float(signal["relative_delta"] or 0.0),
                            int(signal["rank"]) * abs(float(signal["absolute_delta"])),
                        ),
                    )
                    laggard = sorted_signals[0]
                    leader = sorted_signals[-1]
                    signal_gap = float(leader["absolute_delta"]) - float(laggard["absolute_delta"])
                    relative_gap = (
                        float(leader["relative_delta"] or 0.0)
                        - float(laggard["relative_delta"] or 0.0)
                    )
                    materially_diverged = (
                        (min_absolute_delta > 0 and abs(signal_gap) >= min_absolute_delta)
                        or (min_relative_delta > 0 and abs(relative_gap) >= min_relative_delta)
                        or int(leader["rank"]) != int(laggard["rank"])
                    )

                    if leader["series"] != laggard["series"] and materially_diverged:
                        cross_series_findings.append(
                            {
                                "kind": "series_gap",
                                "summary": (
                                    f"{leader['series']} outperformed {laggard['series']} "
                                    "over the compared periods."
                                ),
                                "severity": "warning",
                                "evidence": [
                                    {"label": "Leader series", "value": str(leader["series"])},
                                    {"label": "Laggard series", "value": str(laggard["series"])},
                                    {"label": "Leader delta", "value": float(leader["absolute_delta"])},
                                    {"label": "Laggard delta", "value": float(laggard["absolute_delta"])},
                                ],
                                "details": [],
                                "follow_ups": follow_ups,
                                "metadata": {
                                    "leader": leader,
                                    "laggard": laggard,
                                    "signal_gap": signal_gap,
                                    "relative_gap": relative_gap,
                                },
                            }
                        )
                findings.extend(cross_series_findings)
                unique_series_ids = list(dict.fromkeys(series_ids))
                summary = {
                    "text": (
                        "Trend results span multiple series: "
                        + ", ".join(unique_series_ids)
                        if unique_series_ids
                        else "Trend results span multiple series."
                    ),
                    "severity": (
                        "warning"
                        if any(
                            finding.get("severity") in {"warning", "critical"}
                            for finding in findings
                        )
                        else "info"
                    ),
                }
                metadata = {
                    "compare_mode": str(params.get("compare_mode", "endpoints") or "endpoints"),
                    "directionality": str(
                        params.get("directionality", "higher_is_better") or "higher_is_better"
                    ),
                    "series": unique_series_ids,
                    "series_count": len(unique_series_ids),
                }
            elif summary is None:
                summary = {
                    "text": "Trend is stable across the observed window.",
                    "severity": "info",
                }
            if metadata is None:
                metadata = {
                    "compare_mode": str(params.get("compare_mode", "endpoints") or "endpoints"),
                    "directionality": str(
                        params.get("directionality", "higher_is_better") or "higher_is_better"
                    ),
                }

            return {
                "summary": summary,
                "findings": findings,
                "metadata": metadata,
            }
        """
        ).strip()
        + "\n"
    )
    return _inject_docstring(
        source,
        "def run(*, inputs, params):",
        """Analyze directional change across one time series or several parallel series.

Expected inputs:
- current: a table with period and value bindings, plus an optional series binding
  when several independent series should be evaluated together.

Key params:
- compare_mode: choose endpoint comparison or adjacent-period comparison.
- directionality: treat increases as better by default, or flip interpretation for
  lower-is-better metrics.
- min_points and threshold params: suppress weak or underspecified signals.

Returns a structured summary, zero or more findings, and metadata describing the
evaluated signal and any cross-series gap that was detected.
""",
    )


def _build_top_bottom_gap_insight_python() -> str:
    source = (
        textwrap.dedent(
            """\
        from typing import Any

        import polars as pl


        def _describe_labels(labels: list[Any]) -> str:
            values = [str(label) for label in labels]
            if not values:
                return "unknown"
            if len(values) == 1:
                return values[0]
            if len(values) == 2:
                return f"{values[0]} and {values[1]}"
            return ", ".join(values[:-1]) + f", and {values[-1]}"


        def _threshold_checks(absolute_gap: float, relative_gap: float, params: dict[str, Any]) -> bool:
            min_absolute_gap = float(params.get("min_absolute_gap", 0) or 0)
            min_relative_gap = float(params.get("min_relative_gap", 0) or 0)
            checks: list[bool] = []
            if min_absolute_gap > 0:
                checks.append(absolute_gap < min_absolute_gap)
            if min_relative_gap > 0:
                checks.append(relative_gap < min_relative_gap)
            return bool(checks) and all(checks)


        def run(*, inputs, params):
            frame = inputs["current"]
            follow_ups = list(params.get("follow_ups", []))
            label_column = "label"
            value_column = "value"
            ranking_direction = str(params.get("ranking_direction", "higher_is_better") or "higher_is_better")
            compare_window = max(1, int(params.get("compare_window", 1) or 1))
            min_rows = max(2, int(params.get("min_rows", 2) or 2))
            compare_mode = str(params.get("compare_mode", "group_average") or "group_average")
            required_rows = 2 if compare_mode == "edge_rows" else compare_window * 2

            ordered = frame.drop_nulls([value_column]).sort(
                value_column,
                descending=ranking_direction != "lower_is_better",
            )
            if ordered.height < max(min_rows, required_rows):
                return {
                    "summary": {
                        "text": "Not enough rows to compare top and bottom groups.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "compare_mode": compare_mode,
                        "compare_window": compare_window,
                        "ranking_direction": ranking_direction,
                    },
                }

            if compare_mode == "edge_rows":
                top_rows = ordered.head(1)
                bottom_rows = ordered.tail(1)
            else:
                top_rows = ordered.head(compare_window)
                bottom_rows = ordered.tail(compare_window)

            top_value = float(top_rows[value_column].mean())
            bottom_value = float(bottom_rows[value_column].mean())
            absolute_gap = abs(top_value - bottom_value)
            relative_gap = absolute_gap / abs(bottom_value) if bottom_value else absolute_gap
            top_labels = _describe_labels(top_rows[label_column].to_list())
            bottom_labels = _describe_labels(bottom_rows[label_column].to_list())

            if _threshold_checks(absolute_gap, relative_gap, params):
                return {
                    "summary": {
                        "text": "The ranked values form a tight cluster.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "compare_mode": compare_mode,
                        "compare_window": compare_window,
                        "ranking_direction": ranking_direction,
                        "top": top_labels,
                        "bottom": bottom_labels,
                        "absolute_gap": absolute_gap,
                        "relative_gap": relative_gap,
                    },
                }

            summary_text = (
                f"{top_labels} leads {bottom_labels} by {absolute_gap:.2f}."
                if absolute_gap > 0
                else f"{top_labels} and {bottom_labels} are evenly matched."
            )
            compared_rows_text = (
                "Compared one top row and one bottom row from the ranked result."
                if compare_mode == "edge_rows"
                else f"Compared {compare_window} row(s) from each end of the ranked result."
            )
            finding_summary = (
                f"{top_labels} is ahead of {bottom_labels} by {absolute_gap:.2f}."
                if absolute_gap > 0
                else f"{top_labels} and {bottom_labels} are tied."
            )

            return {
                "summary": {
                    "text": summary_text,
                    "severity": "warning",
                },
            "findings": [
                {
                                "kind": "top_bottom_gap",
                                "summary": finding_summary,
                                "severity": "warning",
                                "evidence": [
                                    {"label": "Top group", "value": top_labels},
                                    {"label": "Bottom group", "value": bottom_labels},
                                    {"label": "Top average", "value": top_value},
                                    {"label": "Bottom average", "value": bottom_value},
                                    {"label": "Absolute gap", "value": absolute_gap},
                                    {"label": "Relative gap", "value": relative_gap},
                                ],
                                "details": [compared_rows_text],
                                "follow_ups": follow_ups,
                                "metadata": {
                                    "compare_mode": compare_mode,
                                    "compare_window": compare_window,
                                    "ranking_direction": ranking_direction,
                                    "top": top_labels,
                                    "bottom": bottom_labels,
                                    "absolute_gap": absolute_gap,
                                    "relative_gap": relative_gap,
                                },
                }
            ],
                "metadata": {
                    "compare_mode": compare_mode,
                    "compare_window": compare_window,
                    "ranking_direction": ranking_direction,
                    "top": top_labels,
                    "bottom": bottom_labels,
                    "absolute_gap": absolute_gap,
                    "relative_gap": relative_gap,
                },
            }
        """
        ).strip()
        + "\n"
    )
    return _inject_docstring(
        source,
        "def run(*, inputs, params):",
        """Compare the top and bottom performers in a ranked result set.

Expected inputs:
- current: a table with label and value bindings representing the ranked rows to
  compare.

Key params:
- ranking_direction: decide whether higher or lower values should rank first.
- compare_window and compare_mode: choose edge-row comparison or windowed group
  averages.
- min_rows and gap thresholds: require enough rows and enough separation before a
  finding is emitted.

Returns a summary describing the observed spread, optional findings for material
gaps, and metadata naming the compared leaders and laggards.
""",
    )


def _build_largest_segment_insight_python() -> str:
    source = (
        textwrap.dedent(
            """\
        from typing import Any

        import polars as pl


        def _format_share(value: float) -> str:
            return f"{value:.1%}"


        def run(*, inputs, params):
            frame = inputs["current"]
            follow_ups = list(params.get("follow_ups", []))
            segment_column = "segment"
            value_column = "value"
            min_segments = max(2, int(params.get("min_segments", 2) or 2))
            dominance_share = float(params.get("dominance_share", 0.5) or 0.5)
            near_tie_delta = float(params.get("near_tie_delta", 0.05) or 0.05)
            normalize = bool(params.get("normalize", True))

            aggregated = (
                frame.group_by(segment_column)
                .agg(pl.col(value_column).sum().alias("value"))
                .sort("value", descending=True)
            )

            if aggregated.height < min_segments:
                return {
                    "summary": {
                        "text": "Not enough segments to assess concentration.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "min_segments": min_segments,
                        "normalize": normalize,
                    },
                }

            total_value = float(aggregated["value"].sum())
            if normalize:
                if total_value == 0:
                    aggregated = aggregated.with_columns(pl.lit(0.0).alias("share"))
                else:
                    aggregated = aggregated.with_columns((pl.col("value") / total_value).alias("share"))
            else:
                # normalize=False means the incoming values already represent share-like weights.
                aggregated = aggregated.with_columns(pl.col("value").alias("share"))

            ordered = aggregated.sort("share", descending=True)
            top_row = ordered.row(0, named=True)
            second_row = ordered.row(1, named=True) if ordered.height > 1 else None
            top_share = float(top_row["share"])
            second_share = float(second_row["share"]) if second_row is not None else 0.0
            share_gap = top_share - second_share
            top_segment = str(top_row[segment_column])
            second_segment = str(second_row[segment_column]) if second_row is not None else "the rest"

            findings: list[dict[str, Any]] = []
            if top_share >= dominance_share:
                findings.append(
                    {
                                "kind": "largest_segment_dominance",
                                "summary": f"{top_segment} dominates with {_format_share(top_share)} share.",
                                "severity": "warning",
                                "evidence": [
                                    {"label": "Top segment", "value": top_segment},
                                    {"label": "Top share", "value": top_share},
                                    {"label": "Second share", "value": second_share},
                                ],
                                "details": [
                                    f"Compared the top two segments after {'normalizing' if normalize else 'treating the values as pre-normalized shares'}."
                                ],
                                "follow_ups": follow_ups,
                                "metadata": {
                                    "normalize": normalize,
                                    "top_segment": top_segment,
                                    "second_segment": second_segment,
                                    "top_share": top_share,
                                    "second_share": second_share,
                                    "share_gap": share_gap,
                                },
                    }
                )

            if second_row is not None and share_gap <= near_tie_delta:
                findings.append(
                    {
                                "kind": "largest_segment_near_tie",
                                "summary": f"{top_segment} and {second_segment} are close at {_format_share(top_share)} and {_format_share(second_share)}.",
                                "severity": "warning",
                                "evidence": [
                                    {"label": "Top segment", "value": top_segment},
                                    {"label": "Second segment", "value": second_segment},
                                    {"label": "Top share", "value": top_share},
                                    {"label": "Second share", "value": second_share},
                                    {"label": "Share gap", "value": share_gap},
                                ],
                                "details": [
                                    f"The leading segments differ by only {_format_share(share_gap)}."
                                ],
                                "follow_ups": follow_ups,
                                "metadata": {
                                    "normalize": normalize,
                                    "top_segment": top_segment,
                                    "second_segment": second_segment,
                                    "top_share": top_share,
                                    "second_share": second_share,
                                    "share_gap": share_gap,
                                },
                    }
                )
            if findings:
                summary_text = (
                    f"{top_segment} dominates the distribution."
                    if top_share >= dominance_share
                    else f"{top_segment} and {second_segment} are nearly tied."
                )
            else:
                summary_text = "The distribution is balanced across the observed segments."

            return {
                "summary": {
                    "text": summary_text,
                    "severity": "warning" if findings else "positive",
                },
                "findings": findings,
                "metadata": {
                    "normalize": normalize,
                    "top_segment": top_segment,
                    "second_segment": second_segment,
                    "top_share": top_share,
                    "second_share": second_share,
                    "share_gap": share_gap,
                },
            }
        """
        ).strip()
        + "\n"
    )
    return _inject_docstring(
        source,
        "def run(*, inputs, params):",
        """Assess whether one segment clearly dominates a distribution.

Expected inputs:
- current: a table with segment and value bindings representing the distribution
  to evaluate.

Key params:
- min_segments: require a minimum number of segments before evaluation.
- dominance_share and near_tie_delta: control when leadership counts as dominant
  versus merely close.
- normalize: treat the input values as raw totals by default and convert them to
  shares before comparison.

Returns a summary, optional dominance or near-tie findings, and metadata with the
leading segment and evaluated shares.
""",
    )


def _build_pending_builtin_insight_python(insight_name: str) -> str:
    source = (
        textwrap.dedent(
            f"""\
        from typing import Any

        import polars as pl


        def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:
            return {{
                "summary": {{
                    "text": "{insight_name} scaffold is installed but the runtime logic is not implemented yet.",
                    "severity": "info",
                }},
                "findings": [],
                "metadata": {{
                    "status": "not_implemented",
                    "input_names": sorted(inputs.keys()),
                    "param_names": sorted(params.keys()),
                }},
            }}
        """
        ).strip()
        + "\n"
    )
    return _inject_docstring(
        source,
        "def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:",
        f"""Return a placeholder result for the {insight_name} built-in.

This scaffold is installed so discovery and invocation wiring can succeed even
before runtime logic exists. The returned payload always contains an
informational summary, no findings, and metadata listing the bound input and
parameter names that reached the insight entrypoint.
""",
    )


def _build_current_vs_prior_insight_python() -> str:
    source = (
        textwrap.dedent(
            """\
        from typing import Any

        import polars as pl


        _VALID_DIRECTIONALITY = {"higher_is_better", "lower_is_better"}
        _VALID_AGGREGATE_MODES = {"row_level", "overall"}


        def _build_row_lookup(
            frame: pl.DataFrame,
            value_column: str,
        ) -> tuple[dict[str, float], list[str], int]:
            lookup: dict[str, float] = {}
            duplicates: set[str] = set()
            null_key_count = 0
            for row in frame.iter_rows(named=True):
                key_value = row["key"]
                if key_value is None:
                    null_key_count += 1
                    continue
                key = str(key_value)
                if key in lookup:
                    duplicates.add(key)
                    continue
                lookup[key] = float(row[value_column])
            return lookup, sorted(duplicates), null_key_count


        def _relative_delta(absolute_delta: float, baseline: float) -> float:
            return absolute_delta / abs(baseline) if baseline else absolute_delta


        def _is_below_delta_threshold(
            absolute_delta: float,
            relative_delta: float,
            params: dict[str, Any],
        ) -> bool:
            min_absolute_delta = float(params.get("min_absolute_delta", 0) or 0)
            min_relative_delta = float(params.get("min_relative_delta", 0.05) or 0.05)
            checks: list[bool] = []
            if min_absolute_delta > 0:
                checks.append(absolute_delta < min_absolute_delta)
            if min_relative_delta > 0:
                checks.append(relative_delta < min_relative_delta)
            return bool(checks) and all(checks)


        def _impact_from_delta(raw_delta: float, directionality: str) -> str:
            improving_when_positive = directionality != "lower_is_better"
            if improving_when_positive:
                return "improving" if raw_delta > 0 else "worsening"
            return "improving" if raw_delta < 0 else "worsening"


        def _describe_change_summary(
            *,
            key: str,
            absolute_delta: float,
            raw_delta: float,
            impact: str,
            overall: bool,
        ) -> str:
            subject = "Overall current total" if overall else key
            if impact == "improving":
                if raw_delta > 0:
                    return f"{subject} improved by increasing {absolute_delta:.2f} versus the prior period."
                return f"{subject} improved by decreasing {absolute_delta:.2f} versus the prior period."
            if raw_delta > 0:
                return f"{subject} worsened by increasing {absolute_delta:.2f} versus the prior period."
            return f"{subject} worsened by decreasing {absolute_delta:.2f} versus the prior period."


        def _compare_current_vs_prior(
            *,
            key: str,
            current: float,
            prior: float,
            directionality: str,
            params: dict[str, Any],
            follow_ups: list[Any],
        ) -> dict[str, Any] | None:
            raw_delta = current - prior
            absolute_delta = round(abs(raw_delta), 4)
            relative_delta = round(_relative_delta(absolute_delta, prior), 4)
            if absolute_delta == 0 or _is_below_delta_threshold(absolute_delta, relative_delta, params):
                return None

            direction = "increase" if raw_delta > 0 else "decline"
            impact = _impact_from_delta(raw_delta, directionality)
            summary = (
                _describe_change_summary(
                    key=key,
                    absolute_delta=absolute_delta,
                    raw_delta=raw_delta,
                    impact=impact,
                    overall=False,
                )
            )

            return {
                        "kind": (
                            "current_vs_prior_increase" if raw_delta > 0 else "current_vs_prior_decline"
                        ),
                        "summary": summary,
                        "severity": "positive" if impact == "improving" else "warning",
                        "evidence": [
                            {"label": "Key", "value": key},
                            {"label": "Current", "value": current},
                            {"label": "Prior", "value": prior},
                            {"label": "Absolute delta", "value": absolute_delta},
                            {"label": "Relative delta", "value": relative_delta},
                        ],
                        "details": [],
                        "follow_ups": follow_ups,
                        "metadata": {
                            "key": key,
                            "current": current,
                            "prior": prior,
                            "absolute_delta": absolute_delta,
                            "relative_delta": relative_delta,
                            "direction": direction,
                            "impact": impact,
                            "directionality": directionality,
                        },
            }


        def _compare_overall_change(
            *,
            matched_keys: list[str],
            current: dict[str, float],
            prior: dict[str, float],
            directionality: str,
            params: dict[str, Any],
            follow_ups: list[Any],
        ) -> dict[str, Any] | None:
            current_total = round(sum(current[key] for key in matched_keys), 4)
            prior_total = round(sum(prior[key] for key in matched_keys), 4)
            raw_delta = current_total - prior_total
            absolute_delta = round(abs(raw_delta), 4)
            relative_delta = round(_relative_delta(absolute_delta, prior_total), 4)
            if absolute_delta == 0 or _is_below_delta_threshold(absolute_delta, relative_delta, params):
                return None

            direction = "increase" if raw_delta > 0 else "decline"
            impact = _impact_from_delta(raw_delta, directionality)
            summary = (
                _describe_change_summary(
                    key="overall",
                    absolute_delta=absolute_delta,
                    raw_delta=raw_delta,
                    impact=impact,
                    overall=True,
                ).replace(" versus the prior period.", " across matched keys.")
            )

            return {
                        "kind": (
                            "current_vs_prior_overall_increase"
                            if raw_delta > 0
                            else "current_vs_prior_overall_decline"
                        ),
                        "summary": summary,
                        "severity": "positive" if impact == "improving" else "warning",
                        "evidence": [
                            {"label": "Current total", "value": current_total},
                            {"label": "Prior total", "value": prior_total},
                            {"label": "Absolute delta", "value": absolute_delta},
                            {"label": "Relative delta", "value": relative_delta},
                        ],
                        "details": [],
                        "follow_ups": follow_ups,
                        "metadata": {
                            "current_total": current_total,
                            "prior_total": prior_total,
                            "absolute_delta": absolute_delta,
                            "relative_delta": relative_delta,
                            "direction": direction,
                            "impact": impact,
                            "directionality": directionality,
                            "matched_keys": matched_keys,
                        },
            }


        def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:
            follow_ups = list(params.get("follow_ups", []))
            current, duplicate_current_keys, null_current_key_count = _build_row_lookup(
                inputs["current"], "value"
            )
            prior, duplicate_prior_keys, null_prior_key_count = _build_row_lookup(
                inputs["prior"], "value"
            )
            directionality = str(params.get("directionality", "higher_is_better") or "higher_is_better")
            aggregate_mode = str(params.get("aggregate_mode", "row_level") or "row_level")
            if directionality not in _VALID_DIRECTIONALITY:
                return {
                    "summary": {
                        "text": f"Invalid directionality: {directionality}.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "directionality": directionality,
                        "aggregate_mode": aggregate_mode,
                        "status": "invalid_parameter",
                    },
                }
            if aggregate_mode not in _VALID_AGGREGATE_MODES:
                return {
                    "summary": {
                        "text": f"Invalid aggregate mode: {aggregate_mode}.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "directionality": directionality,
                        "aggregate_mode": aggregate_mode,
                        "status": "invalid_parameter",
                    },
                }
            if (
                duplicate_current_keys
                or duplicate_prior_keys
                or null_current_key_count
                or null_prior_key_count
            ):
                return {
                    "summary": {
                        "text": "Invalid keys were provided for current-versus-prior comparison.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "directionality": directionality,
                        "aggregate_mode": aggregate_mode,
                        "duplicate_current_keys": duplicate_current_keys,
                        "duplicate_prior_keys": duplicate_prior_keys,
                        "null_current_key_count": null_current_key_count,
                        "null_prior_key_count": null_prior_key_count,
                        "status": "invalid_input",
                    },
                }

            matched_keys = sorted(set(current) & set(prior))
            unmatched_current_keys = sorted(set(current) - set(prior))
            unmatched_prior_keys = sorted(set(prior) - set(current))

            findings = []
            increase_count = 0
            decline_count = 0
            improving_count = 0
            worsening_count = 0

            if aggregate_mode == "overall":
                finding = _compare_overall_change(
                    matched_keys=matched_keys,
                    current=current,
                    prior=prior,
                    directionality=directionality,
                    params=params,
                    follow_ups=follow_ups,
                )
                if finding is not None:
                    findings.append(finding)
            else:
                for key in matched_keys:
                    finding = _compare_current_vs_prior(
                        key=key,
                        current=current[key],
                        prior=prior[key],
                        directionality=directionality,
                        params=params,
                        follow_ups=follow_ups,
                    )
                    if finding is None:
                        continue
                    findings.append(finding)
                    if finding["metadata"]["direction"] == "increase":
                        increase_count += 1
                    else:
                        decline_count += 1
                    if finding["metadata"]["impact"] == "improving":
                        improving_count += 1
                    else:
                        worsening_count += 1

            if aggregate_mode == "overall" and findings:
                if findings[0]["metadata"]["direction"] == "increase":
                    increase_count = 1
                else:
                    decline_count = 1
                if findings[0]["metadata"]["impact"] == "improving":
                    improving_count = 1
                else:
                    worsening_count = 1

            if findings:
                if aggregate_mode == "overall":
                    summary = {
                        "text": findings[0]["summary"],
                        "severity": findings[0]["severity"],
                    }
                else:
                    summary_text = (
                        f"{improving_count} meaningful improvement(s) detected versus prior."
                        if improving_count and not worsening_count
                        else (
                            f"{worsening_count} meaningful worsening(s) detected versus prior."
                            if worsening_count and not improving_count
                            else f"Material current-versus-prior changes detected across {len(findings)} key(s)."
                        )
                    )
                    summary = {
                        "text": summary_text,
                        "severity": "warning" if worsening_count else "positive",
                    }
            else:
                summary = {
                    "text": "No material current-versus-prior changes detected.",
                    "severity": "info",
                }

            if unmatched_current_keys or unmatched_prior_keys:
                summary["text"] += (
                    " Unmatched rows were skipped: "
                    f"{len(unmatched_current_keys)} current-only, {len(unmatched_prior_keys)} prior-only."
                )

            return {
                "summary": summary,
                "findings": findings,
                "metadata": {
                    "directionality": directionality,
                    "aggregate_mode": aggregate_mode,
                    "matched_keys": matched_keys,
                    "matched_row_count": len(matched_keys),
                    "material_match_count": len(findings),
                    "increase_count": increase_count,
                    "decline_count": decline_count,
                    "improving_count": improving_count,
                    "worsening_count": worsening_count,
                    "unmatched_current_keys": unmatched_current_keys,
                    "unmatched_prior_keys": unmatched_prior_keys,
                },
            }
        """
        ).strip()
        + "\n"
    )
    return _inject_docstring(
        source,
        "def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:",
        """Compare a current snapshot against a prior snapshot keyed by the same entities.

Expected inputs:
- current: rows keyed by the present-period entity identifier and numeric value.
- prior: rows keyed by the matching prior-period entity identifier and numeric value.

Key params:
- min_absolute_delta and min_relative_delta: suppress weak row-level or aggregate
  movement.
- directionality: define whether increases or decreases count as improvement.
- aggregate_mode: choose row-level comparisons or a single overall aggregate delta.

Returns a structured summary, optional findings for meaningful movement, and
metadata describing matched rows, unmatched keys, and improvement versus worsening
counts.
""",
    )


def _build_actual_vs_target_insight_python() -> str:
    source = (
        textwrap.dedent(
            """\
        from typing import Any

        import polars as pl


        def _build_row_lookup(
            frame: pl.DataFrame,
            value_column: str,
        ) -> tuple[dict[str, float], list[str], int]:
            lookup: dict[str, float] = {}
            duplicates: set[str] = set()
            null_key_count = 0
            for row in frame.iter_rows(named=True):
                key_value = row["key"]
                if key_value is None:
                    null_key_count += 1
                    continue
                key = str(key_value)
                if key in lookup:
                    duplicates.add(key)
                    continue
                lookup[key] = float(row[value_column])
            return lookup, sorted(duplicates), null_key_count


        def _relative_gap(absolute_gap: float, baseline: float) -> float:
            return absolute_gap / abs(baseline) if baseline else absolute_gap


        def _is_below_gap_threshold(
            absolute_gap: float,
            relative_gap: float,
            params: dict[str, Any],
        ) -> bool:
            min_absolute_gap = float(params.get("min_absolute_gap", 0) or 0)
            min_relative_gap = float(params.get("min_relative_gap", 0.05) or 0.05)
            checks: list[bool] = []
            if min_absolute_gap > 0:
                checks.append(absolute_gap < min_absolute_gap)
            if min_relative_gap > 0:
                checks.append(relative_gap < min_relative_gap)
            return bool(checks) and all(checks)


        def _compare_against_target(
            *,
            key: str,
            actual: float,
            target: float,
            directionality: str,
            params: dict[str, Any],
            follow_ups: list[Any],
        ) -> dict[str, Any] | None:
            raw_gap = actual - target
            absolute_gap = round(abs(raw_gap), 4)
            relative_gap = round(_relative_gap(absolute_gap, target), 4)

            if absolute_gap == 0 or _is_below_gap_threshold(absolute_gap, relative_gap, params):
                return None

            beat_target = raw_gap < 0 if directionality == "lower_is_better" else raw_gap > 0
            direction = (
                "below_target"
                if directionality == "lower_is_better" and raw_gap < 0
                else (
                    "above_target"
                    if directionality != "lower_is_better" and raw_gap > 0
                    else (
                        "above_target"
                        if directionality == "lower_is_better"
                        else "below_target"
                    )
                )
            )
            kind = "actual_vs_target_beat_target" if beat_target else "actual_vs_target_shortfall"
            summary = (
                f"{key} is beating target by {absolute_gap:.2f}."
                if beat_target
                else f"{key} is trailing target by {absolute_gap:.2f}."
            )

            return {
                        "kind": kind,
                        "summary": summary,
                        "severity": "positive" if beat_target else "warning",
                        "evidence": [
                            {"label": "Key", "value": key},
                            {"label": "Actual", "value": actual},
                            {"label": "Target", "value": target},
                            {"label": "Absolute gap", "value": absolute_gap},
                            {"label": "Relative gap", "value": relative_gap},
                        ],
                        "details": [],
                        "follow_ups": follow_ups,
                        "metadata": {
                            "key": key,
                            "actual": actual,
                            "target": target,
                            "absolute_gap": absolute_gap,
                            "relative_gap": relative_gap,
                            "direction": direction,
                            "directionality": directionality,
                        },
            }


        def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:
            follow_ups = list(params.get("follow_ups", []))
            actuals, duplicate_actual_keys, null_actual_key_count = _build_row_lookup(
                inputs["actuals"], "actual"
            )
            targets, duplicate_target_keys, null_target_key_count = _build_row_lookup(
                inputs["targets"], "target"
            )
            directionality = str(params.get("directionality", "higher_is_better") or "higher_is_better")
            if (
                duplicate_actual_keys
                or duplicate_target_keys
                or null_actual_key_count
                or null_target_key_count
            ):
                return {
                    "summary": {
                        "text": "Invalid keys were provided for actual-versus-target comparison.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "directionality": directionality,
                        "duplicate_actual_keys": duplicate_actual_keys,
                        "duplicate_target_keys": duplicate_target_keys,
                        "null_actual_key_count": null_actual_key_count,
                        "null_target_key_count": null_target_key_count,
                        "status": "invalid_input",
                    },
                }
            matched_keys = sorted(set(actuals) & set(targets))
            unmatched_actual_keys = sorted(set(actuals) - set(targets))
            unmatched_target_keys = sorted(set(targets) - set(actuals))

            findings = []
            beat_target_count = 0
            shortfall_count = 0
            for key in matched_keys:
                finding = _compare_against_target(
                    key=key,
                    actual=actuals[key],
                    target=targets[key],
                    directionality=directionality,
                    params=params,
                    follow_ups=follow_ups,
                )
                if finding is None:
                    continue
                findings.append(finding)
                if finding["kind"] == "actual_vs_target_beat_target":
                    beat_target_count += 1
                else:
                    shortfall_count += 1

            if findings:
                summary_text = (
                    f"{shortfall_count} shortfall(s) detected versus target."
                    if shortfall_count and not beat_target_count
                    else (
                        f"{beat_target_count} key(s) materially beat target."
                        if beat_target_count and not shortfall_count
                        else f"Material target gaps detected across {len(findings)} key(s)."
                    )
                )
                summary = {
                    "text": summary_text,
                    "severity": "warning" if shortfall_count else "positive",
                }
            else:
                summary = {
                    "text": "No material actual-versus-target gaps detected.",
                    "severity": "info",
                }

            if unmatched_actual_keys or unmatched_target_keys:
                summary["text"] += (
                    " Unmatched rows were skipped: "
                    f"{len(unmatched_actual_keys)} actual-only, {len(unmatched_target_keys)} target-only."
                )

            return {
                "summary": summary,
                "findings": findings,
                "metadata": {
                    "directionality": directionality,
                    "matched_keys": matched_keys,
                    "matched_row_count": len(matched_keys),
                    "material_match_count": len(findings),
                    "beat_target_count": beat_target_count,
                    "shortfall_count": shortfall_count,
                    "unmatched_actual_keys": unmatched_actual_keys,
                    "unmatched_target_keys": unmatched_target_keys,
                },
            }
        """
        ).strip()
        + "\n"
    )
    return _inject_docstring(
        source,
        "def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:",
        """Evaluate actual performance against explicit target values.

Expected inputs:
- actuals: rows keyed by entity with the measured actual value.
- targets: rows keyed by the same entity with the target value to compare against.

Key params:
- min_absolute_gap and min_relative_gap: suppress small misses or overages.
- directionality: define whether being above or below target is considered
  favorable.

Returns a summary, optional findings for shortfalls or target beats, and metadata
covering matched rows, unmatched keys, and the material comparisons that remained
after thresholding.
""",
    )


def _build_segment_vs_benchmark_insight_python() -> str:
    source = (
        textwrap.dedent(
            """\
        from typing import Any

        import polars as pl


        def _build_row_lookup(
            frame: pl.DataFrame,
            value_column: str,
        ) -> tuple[dict[str, float], list[str], int]:
            lookup: dict[str, float] = {}
            duplicates: set[str] = set()
            null_key_count = 0
            for row in frame.iter_rows(named=True):
                key_value = row["key"]
                if key_value is None:
                    null_key_count += 1
                    continue
                key = str(key_value)
                if key in lookup:
                    duplicates.add(key)
                    continue
                lookup[key] = float(row[value_column])
            return lookup, sorted(duplicates), null_key_count


        def _relative_gap(absolute_gap: float, baseline: float) -> float:
            return absolute_gap / abs(baseline) if baseline else absolute_gap


        def _is_below_gap_threshold(
            absolute_gap: float,
            relative_gap: float,
            params: dict[str, Any],
        ) -> bool:
            min_absolute_gap = float(params.get("min_absolute_gap", 0) or 0)
            min_relative_gap = float(params.get("min_relative_gap", 0.05) or 0.05)
            checks: list[bool] = []
            if min_absolute_gap > 0:
                checks.append(absolute_gap < min_absolute_gap)
            if min_relative_gap > 0:
                checks.append(relative_gap < min_relative_gap)
            return bool(checks) and all(checks)


        def _compare_against_benchmark(
            *,
            key: str,
            segment_value: float,
            benchmark_value: float,
            directionality: str,
            params: dict[str, Any],
            follow_ups: list[Any],
        ) -> dict[str, Any] | None:
            raw_gap = segment_value - benchmark_value
            absolute_gap = round(abs(raw_gap), 4)
            relative_gap = round(_relative_gap(absolute_gap, benchmark_value), 4)

            if absolute_gap == 0 or _is_below_gap_threshold(absolute_gap, relative_gap, params):
                return None

            above_benchmark = raw_gap > 0
            kind = (
                "segment_vs_benchmark_above"
                if above_benchmark
                else "segment_vs_benchmark_below"
            )
            outperforming = raw_gap < 0 if directionality == "lower_is_better" else raw_gap > 0
            summary = (
                f"{key} is above benchmark by {absolute_gap:.2f}."
                if above_benchmark
                else f"{key} is below benchmark by {absolute_gap:.2f}."
            )

            return {
                        "kind": kind,
                        "summary": summary,
                        "severity": "positive" if outperforming else "warning",
                        "evidence": [
                            {"label": "Key", "value": key},
                            {"label": "Segment value", "value": segment_value},
                            {"label": "Benchmark value", "value": benchmark_value},
                            {"label": "Absolute gap", "value": absolute_gap},
                            {"label": "Relative gap", "value": relative_gap},
                        ],
                        "details": [],
                        "follow_ups": follow_ups,
                        "metadata": {
                            "key": key,
                            "segment_value": segment_value,
                            "benchmark_value": benchmark_value,
                            "absolute_gap": absolute_gap,
                            "relative_gap": relative_gap,
                            "direction": "above_benchmark" if above_benchmark else "below_benchmark",
                            "directionality": directionality,
                        },
            }


        def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:
            follow_ups = list(params.get("follow_ups", []))
            segment, duplicate_segment_keys, null_segment_key_count = _build_row_lookup(
                inputs["segment"], "value"
            )
            benchmark, duplicate_benchmark_keys, null_benchmark_key_count = _build_row_lookup(
                inputs["benchmark"], "value"
            )
            directionality = str(params.get("directionality", "higher_is_better") or "higher_is_better")
            if (
                duplicate_segment_keys
                or duplicate_benchmark_keys
                or null_segment_key_count
                or null_benchmark_key_count
            ):
                return {
                    "summary": {
                        "text": "Invalid keys were provided for segment-versus-benchmark comparison.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "directionality": directionality,
                        "duplicate_segment_keys": duplicate_segment_keys,
                        "duplicate_benchmark_keys": duplicate_benchmark_keys,
                        "null_segment_key_count": null_segment_key_count,
                        "null_benchmark_key_count": null_benchmark_key_count,
                        "status": "invalid_input",
                    },
                }
            matched_keys = sorted(set(segment) & set(benchmark))
            unmatched_segment_keys = sorted(set(segment) - set(benchmark))
            unmatched_benchmark_keys = sorted(set(benchmark) - set(segment))

            findings = []
            outperforming_count = 0
            underperforming_count = 0
            for key in matched_keys:
                finding = _compare_against_benchmark(
                    key=key,
                    segment_value=segment[key],
                    benchmark_value=benchmark[key],
                    directionality=directionality,
                    params=params,
                    follow_ups=follow_ups,
                )
                if finding is None:
                    continue
                findings.append(finding)
                if finding["severity"] == "positive":
                    outperforming_count += 1
                else:
                    underperforming_count += 1

            if findings:
                summary_text = (
                    f"{outperforming_count} key(s) are materially outperforming benchmark."
                    if outperforming_count and not underperforming_count
                    else (
                        f"{underperforming_count} key(s) are materially underperforming benchmark."
                        if underperforming_count and not outperforming_count
                        else f"Material benchmark gaps detected across {len(findings)} key(s)."
                    )
                )
                summary = {
                    "text": summary_text,
                    "severity": "warning" if underperforming_count else "positive",
                }
            else:
                summary = {
                    "text": "No material segment-versus-benchmark gaps detected.",
                    "severity": "info",
                }

            if unmatched_segment_keys or unmatched_benchmark_keys:
                summary["text"] += (
                    " Unmatched rows were skipped: "
                    f"{len(unmatched_segment_keys)} segment-only, {len(unmatched_benchmark_keys)} benchmark-only."
                )

            return {
                "summary": summary,
                "findings": findings,
                "metadata": {
                    "directionality": directionality,
                    "matched_keys": matched_keys,
                    "matched_row_count": len(matched_keys),
                    "material_match_count": len(findings),
                    "outperforming_count": outperforming_count,
                    "underperforming_count": underperforming_count,
                    "unmatched_segment_keys": unmatched_segment_keys,
                    "unmatched_benchmark_keys": unmatched_benchmark_keys,
                },
            }
        """
        ).strip()
        + "\n"
    )
    return _inject_docstring(
        source,
        "def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:",
        """Compare segment values against an explicit benchmark table.

Expected inputs:
- segment: rows keyed by the evaluated segment or entity with the measured value.
- benchmark: rows keyed the same way with the benchmark value for comparison.

Key params:
- min_absolute_gap and min_relative_gap: require meaningful separation.
- directionality: define whether higher or lower values should be interpreted as
  outperforming the benchmark.

Returns a summary, optional outperforming or underperforming findings, and
metadata describing matched rows, unmatched keys, and comparison counts.
""",
    )


def _build_mix_shift_insight_python() -> str:
    source = (
        textwrap.dedent(
            """\
        from typing import Any

        import polars as pl


        def _build_row_lookup(
            frame: pl.DataFrame,
            value_column: str,
        ) -> tuple[dict[str, float], list[str], int]:
            lookup: dict[str, float] = {}
            duplicates: set[str] = set()
            null_key_count = 0
            for row in frame.iter_rows(named=True):
                key_value = row["segment"]
                if key_value is None:
                    null_key_count += 1
                    continue
                key = str(key_value)
                if key in lookup:
                    duplicates.add(key)
                    continue
                lookup[key] = float(row[value_column])
            return lookup, sorted(duplicates), null_key_count


        def _normalize_segments(values: dict[str, float], normalize: bool) -> dict[str, float]:
            if not normalize:
                return {key: round(value, 4) for key, value in values.items()}
            total = sum(values.values())
            if total == 0:
                return {key: 0.0 for key in values}
            return {key: round(value / total, 4) for key, value in values.items()}


        def _compare_segment_share(
            *,
            segment: str,
            current_share: float,
            prior_share: float,
            min_share_delta: float,
            normalize: bool,
            follow_ups: list[Any],
        ) -> dict[str, Any] | None:
            raw_delta = current_share - prior_share
            absolute_share_delta = round(abs(raw_delta), 4)
            share_delta = round(raw_delta, 4)
            if absolute_share_delta == 0 or absolute_share_delta < min_share_delta:
                return None

            if normalize:
                summary = (
                    f"{segment} gained share by {absolute_share_delta:.2%}."
                    if raw_delta > 0
                    else f"{segment} lost share by {absolute_share_delta:.2%}."
                )
                kind = "mix_shift_share_gain" if raw_delta > 0 else "mix_shift_share_loss"
                evidence = [
                    {"label": "Segment", "value": segment},
                    {"label": "Current share", "value": current_share},
                    {"label": "Prior share", "value": prior_share},
                    {"label": "Share delta", "value": share_delta},
                ]
                metadata = {
                    "segment": segment,
                    "current_share": current_share,
                    "prior_share": prior_share,
                    "share_delta": share_delta,
                    "absolute_share_delta": absolute_share_delta,
                    "comparison_mode": "share",
                }
            else:
                summary = (
                    f"{segment} increased by {absolute_share_delta:.2f} units versus prior."
                    if raw_delta > 0
                    else f"{segment} decreased by {absolute_share_delta:.2f} units versus prior."
                )
                kind = "mix_shift_value_gain" if raw_delta > 0 else "mix_shift_value_loss"
                evidence = [
                    {"label": "Segment", "value": segment},
                    {"label": "Current value", "value": current_share},
                    {"label": "Prior value", "value": prior_share},
                    {"label": "Value delta", "value": share_delta},
                ]
                metadata = {
                    "segment": segment,
                    "current_value": current_share,
                    "prior_value": prior_share,
                    "value_delta": share_delta,
                    "absolute_value_delta": absolute_share_delta,
                    "comparison_mode": "value",
                }
            return {
                        "kind": kind,
                        "summary": summary,
                        "severity": "warning",
                        "evidence": evidence,
                        "details": [],
                        "follow_ups": follow_ups,
                        "metadata": metadata,
            }


        def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:
            follow_ups = list(params.get("follow_ups", []))
            current, duplicate_current_segments, null_current_segment_count = _build_row_lookup(
                inputs["current"], "value"
            )
            prior, duplicate_prior_segments, null_prior_segment_count = _build_row_lookup(
                inputs["prior"], "value"
            )
            normalize = bool(params.get("normalize", True))
            if (
                duplicate_current_segments
                or duplicate_prior_segments
                or null_current_segment_count
                or null_prior_segment_count
            ):
                return {
                    "summary": {
                        "text": "Invalid keys were provided for mix-shift comparison.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "normalize": normalize,
                        "duplicate_current_segments": duplicate_current_segments,
                        "duplicate_prior_segments": duplicate_prior_segments,
                        "null_current_segment_count": null_current_segment_count,
                        "null_prior_segment_count": null_prior_segment_count,
                        "status": "invalid_input",
                    },
                }

            current_shares = _normalize_segments(current, normalize)
            prior_shares = _normalize_segments(prior, normalize)
            matched_keys = sorted(set(current_shares) & set(prior_shares))
            evaluated_keys = sorted(set(current_shares) | set(prior_shares))
            unmatched_current_segments = sorted(set(current_shares) - set(prior_shares))
            unmatched_prior_segments = sorted(set(prior_shares) - set(current_shares))
            min_share_delta = float(params.get("min_share_delta", 0.05) or 0.05)
            min_value_delta = float(params.get("min_value_delta", 0.0) or 0.0)
            min_delta = min_share_delta if normalize else min_value_delta

            findings = []
            gain_count = 0
            loss_count = 0
            for key in evaluated_keys:
                finding = _compare_segment_share(
                    segment=key,
                    current_share=current_shares.get(key, 0.0),
                    prior_share=prior_shares.get(key, 0.0),
                    min_share_delta=min_delta,
                    normalize=normalize,
                    follow_ups=follow_ups,
                )
                if finding is None:
                    continue
                findings.append(finding)
                if finding["kind"] in {"mix_shift_share_gain", "mix_shift_value_gain"}:
                    gain_count += 1
                else:
                    loss_count += 1

            if findings:
                summary = {
                    "text": (
                        f"Material share shifts detected across {len(findings)} segment(s)."
                        if normalize
                        else f"Material value shifts detected across {len(findings)} segment(s)."
                    ),
                    "severity": "warning",
                }
            else:
                summary = {
                    "text": (
                        "No material share shifts detected."
                        if normalize
                        else "No material value shifts detected."
                    ),
                    "severity": "info",
                }

            if unmatched_current_segments or unmatched_prior_segments:
                summary["text"] += (
                    " Includes "
                    f"{len(unmatched_current_segments)} current-only and {len(unmatched_prior_segments)} prior-only segment(s)."
                )

            return {
                "summary": summary,
                "findings": findings,
                "metadata": {
                    "normalize": normalize,
                    "min_share_delta": min_share_delta,
                    "min_value_delta": min_value_delta,
                    "comparison_mode": "share" if normalize else "value",
                    "matched_segments": matched_keys,
                    "matched_row_count": len(matched_keys),
                    "evaluated_segments": evaluated_keys,
                    "evaluated_row_count": len(evaluated_keys),
                    "material_match_count": len(findings),
                    "gain_count": gain_count,
                    "loss_count": loss_count,
                    "unmatched_current_segments": unmatched_current_segments,
                    "unmatched_prior_segments": unmatched_prior_segments,
                    "current_total": round(sum(current.values()), 4),
                    "prior_total": round(sum(prior.values()), 4),
                },
            }
        """
        ).strip()
        + "\n"
    )
    source = _inject_docstring(
        source,
        "def _normalize_segments(values: dict[str, float], normalize: bool) -> dict[str, float]:",
        """Convert raw segment totals into the comparison units used by this insight.""",
    )
    return _inject_docstring(
        source,
        "def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:",
        """Measure how distribution share or raw segment values changed between snapshots.

Expected inputs:
- current: segment totals for the current snapshot.
- prior: segment totals for the prior snapshot.

Key params:
- normalize: compare share movement when true, or raw value movement when false.
- min_share_delta: minimum share movement required in normalized mode.
- min_value_delta: minimum raw-value movement required in value mode.

Returns a summary, optional gain or loss findings for material shifts, and
metadata describing matched segments, evaluated union segments, and current-only
or prior-only segments that were compared against a zero baseline.
""",
    )


def _build_threshold_breach_insight_python() -> str:
    source = (
        textwrap.dedent(
            """\
        from typing import Any

        import polars as pl


        def _coerce_threshold_frame(
            frame: pl.DataFrame,
            threshold_value: object,
        ) -> tuple[pl.DataFrame, str]:
            if threshold_value is not None:
                return (
                    frame.with_columns(pl.lit(float(threshold_value)).alias("__threshold_value")),
                    "param",
                )
            return (
                frame.with_columns(pl.col("threshold").cast(pl.Float64).alias("__threshold_value")),
                "column",
            )


        def _normalize_direction(raw_direction: object) -> str | None:
            direction = str(raw_direction or "above")
            if direction in {"above", "below"}:
                return direction
            return None


        def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:
            frame = inputs["current"]
            follow_ups = list(params.get("follow_ups", []))
            threshold_value = params.get("threshold_value")
            raw_direction = params.get("breach_direction", "above")
            direction = _normalize_direction(raw_direction)
            if direction is None:
                return {
                    "summary": {
                        "text": f"Invalid breach direction: {raw_direction}.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "direction": str(raw_direction),
                        "breach_count": 0,
                        "status": "invalid_parameter",
                    },
                }
            threshold_column_present = "threshold" in frame.columns
            if threshold_value is None and not threshold_column_present:
                return {
                    "summary": {
                        "text": "No threshold was provided for breach evaluation.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "direction": direction,
                        "breach_count": 0,
                        "threshold_source": "missing",
                    },
                }

            working, threshold_source = _coerce_threshold_frame(frame, threshold_value)
            comparator = (
                pl.col("value").cast(pl.Float64) < pl.col("__threshold_value")
                if direction == "below"
                else pl.col("value").cast(pl.Float64) > pl.col("__threshold_value")
            )
            breaches = working.filter(comparator)
            findings = [
                {
                        "kind": "threshold_breach",
                        "summary": (
                            f"{row['label']} fell below the configured threshold."
                            if direction == "below"
                            else f"{row['label']} exceeded the configured threshold."
                        ),
                        "severity": "warning",
                        "evidence": [
                            {"label": "Observed", "value": float(row["value"])},
                            {"label": "Threshold", "value": float(row["__threshold_value"])},
                        ],
                        "details": [],
                        "follow_ups": follow_ups,
                        "metadata": {
                            "label": str(row["label"]),
                            "observed": float(row["value"]),
                            "threshold": float(row["__threshold_value"]),
                            "direction": direction,
                        },
                }
                for row in breaches.iter_rows(named=True)
            ]
            if findings:
                summary = {
                    "text": f"{len(findings)} threshold breach(es) detected.",
                    "severity": "warning",
                }
            else:
                summary = {
                    "text": "No threshold breaches detected.",
                    "severity": "info",
                }

            return {
                "summary": summary,
                "findings": findings,
                "metadata": {
                    "direction": direction,
                    "breach_count": len(findings),
                    "threshold_source": threshold_source,
                },
            }
        """
        ).strip()
        + "\n"
    )
    source = _inject_docstring(
        source,
        "def _normalize_direction(raw_direction: object) -> str | None:",
        """Normalize the configured breach direction to a supported comparison mode.""",
    )
    return _inject_docstring(
        source,
        "def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:",
        """Flag rows whose values cross an explicit threshold.

Expected inputs:
- current: rows with label and value bindings, plus an optional threshold binding
  when the threshold varies by row.

Key params:
- threshold_value: a scalar fallback threshold when no threshold column is bound.
- breach_direction: decide whether breaches are values above or below the
  threshold.

Returns a summary, optional breach findings, and metadata describing the threshold
source and the rows that exceeded the configured limit.
""",
    )


def _build_outlier_detection_insight_python() -> str:
    source = (
        textwrap.dedent(
            """\
        import math
        from typing import Any

        import polars as pl


        _SUPPORTED_METHODS = {"z_score", "iqr"}
        _MIN_POINTS = 5


        def _sample_stddev(values: list[float], mean: float) -> float:
            if len(values) < 2:
                return 0.0
            variance = sum((value - mean) ** 2 for value in values) / (len(values) - 1)
            return variance ** 0.5


        def _quantile(sorted_values: list[float], quantile: float) -> float:
            if not sorted_values:
                return 0.0
            if len(sorted_values) == 1:
                return sorted_values[0]
            position = (len(sorted_values) - 1) * quantile
            lower_index = math.floor(position)
            upper_index = math.ceil(position)
            if lower_index == upper_index:
                return sorted_values[lower_index]
            lower_value = sorted_values[lower_index]
            upper_value = sorted_values[upper_index]
            weight = position - lower_index
            return lower_value + (upper_value - lower_value) * weight


        def _evaluate_against_peers(
            *,
            value: float,
            peer_values: list[float],
            method: str,
            sensitivity: float,
        ) -> dict[str, Any]:
            if method == "z_score":
                peer_mean = sum(peer_values) / len(peer_values)
                peer_stddev = _sample_stddev(peer_values, peer_mean)
                if peer_stddev == 0:
                    is_outlier = value != peer_mean
                    return {
                        "is_outlier": is_outlier,
                        "peer_mean": peer_mean,
                        "peer_stddev": peer_stddev,
                        "score": None,
                    }
                z_score = abs((value - peer_mean) / peer_stddev)
                return {
                    "is_outlier": z_score >= sensitivity,
                    "peer_mean": peer_mean,
                    "peer_stddev": peer_stddev,
                    "score": round(z_score, 4),
                }

            sorted_peers = sorted(peer_values)
            first_quartile = _quantile(sorted_peers, 0.25)
            third_quartile = _quantile(sorted_peers, 0.75)
            iqr = third_quartile - first_quartile
            lower_bound = first_quartile - (sensitivity * iqr)
            upper_bound = third_quartile + (sensitivity * iqr)
            return {
                "is_outlier": value < lower_bound or value > upper_bound,
                "first_quartile": round(first_quartile, 4),
                "third_quartile": round(third_quartile, 4),
                "iqr": round(iqr, 4),
                "lower_bound": round(lower_bound, 4),
                "upper_bound": round(upper_bound, 4),
            }


        def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:
            frame = inputs["current"]
            follow_ups = list(params.get("follow_ups", []))
            method = str(params.get("deviation_method", "z_score") or "z_score")
            raw_sensitivity = params.get("sensitivity")
            sensitivity = 2.0 if raw_sensitivity is None else float(raw_sensitivity)
            frame = frame.drop_nulls(["value"])
            points = frame.height
            if sensitivity < 0:
                return {
                    "summary": {
                        "text": f"Invalid sensitivity: {sensitivity}.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "method": method,
                        "sensitivity": sensitivity,
                        "points": points,
                        "outlier_count": 0,
                        "status": "invalid_parameter",
                    },
                }
            if method not in _SUPPORTED_METHODS:
                return {
                    "summary": {
                        "text": f"Invalid deviation method: {method}.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "method": method,
                        "sensitivity": sensitivity,
                        "points": points,
                        "outlier_count": 0,
                        "status": "invalid_parameter",
                        "supported_methods": sorted(_SUPPORTED_METHODS),
                    },
                }

            if points < _MIN_POINTS:
                return {
                    "summary": {
                        "text": "Not enough data points to detect outliers.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "method": method,
                        "sensitivity": sensitivity,
                        "points": points,
                        "min_points": _MIN_POINTS,
                        "outlier_count": 0,
                    },
                }

            rows = list(frame.iter_rows(named=True))
            values = [float(row["value"]) for row in rows]

            findings = []
            for index, row in enumerate(rows):
                value = float(row["value"])
                peer_values = values[:index] + values[index + 1 :]
                peer_assessment = _evaluate_against_peers(
                    value=value,
                    peer_values=peer_values,
                    method=method,
                    sensitivity=sensitivity,
                )
                if not peer_assessment["is_outlier"]:
                    continue
                evidence = [{"label": "Observed", "value": value}]
                metadata: dict[str, Any] = {
                    "label": str(row["label"]),
                    "value": value,
                    "method": method,
                }
                if method == "z_score":
                    evidence.append(
                        {"label": "Peer mean", "value": peer_assessment["peer_mean"]}
                    )
                    evidence.append(
                        {"label": "Peer stddev", "value": peer_assessment["peer_stddev"]}
                    )
                    if peer_assessment["score"] is not None:
                        evidence.append(
                            {"label": "Z-score", "value": peer_assessment["score"]}
                        )
                        metadata["z_score"] = peer_assessment["score"]
                    else:
                        metadata["z_score"] = None
                    metadata["peer_mean"] = peer_assessment["peer_mean"]
                    metadata["peer_stddev"] = peer_assessment["peer_stddev"]
                else:
                    evidence.extend(
                        [
                            {"label": "Lower bound", "value": peer_assessment["lower_bound"]},
                            {"label": "Upper bound", "value": peer_assessment["upper_bound"]},
                            {"label": "IQR", "value": peer_assessment["iqr"]},
                        ]
                    )
                    metadata["lower_bound"] = peer_assessment["lower_bound"]
                    metadata["upper_bound"] = peer_assessment["upper_bound"]
                    metadata["iqr"] = peer_assessment["iqr"]
                findings.append(
                    {
                                "kind": "outlier_detection",
                                "summary": f"{row['label']} is an outlier versus its peers.",
                                "severity": "warning",
                                "evidence": evidence,
                                "details": [],
                                "follow_ups": follow_ups,
                                "metadata": metadata,
                    }
                )

            summary = {
                "text": (
                    f"{len(findings)} outlier(s) detected across the peer group."
                    if findings
                    else "No outliers detected across the peer group."
                ),
                "severity": "warning" if findings else "info",
            }
            return {
                "summary": summary,
                "findings": findings,
                "metadata": {
                    "method": method,
                    "sensitivity": sensitivity,
                    "points": points,
                    "outlier_count": len(findings),
                },
            }
        """
        ).strip()
        + "\n"
    )
    return _inject_docstring(
        source,
        "def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:",
        """Detect rows whose values are materially far from their peers.

Expected inputs:
- current: a table with label and value bindings representing the peer group to
  evaluate.

Key params:
- deviation_method: choose z-score or IQR-based peer comparison.
- sensitivity: control how far from peers a row must be before it counts as an
  outlier.

Returns a summary, optional outlier findings, and metadata describing the peer
group size, chosen method, and how many outliers were detected.
""",
    )


def _build_trend_volatility_insight_python() -> str:
    source = (
        textwrap.dedent(
            """\
        from typing import Any

        import polars as pl


        def _count_direction_changes(deltas: list[float]) -> int:
            previous_sign = 0
            sign_changes = 0
            for delta in deltas:
                current_sign = 0
                if delta > 0:
                    current_sign = 1
                elif delta < 0:
                    current_sign = -1

                if current_sign == 0:
                    continue
                if previous_sign != 0 and current_sign != previous_sign:
                    sign_changes += 1
                previous_sign = current_sign
            return sign_changes


        def _analyze_group(
            frame: pl.DataFrame,
            *,
            min_points: int,
            volatility_threshold: float,
            sign_change_threshold: int,
            series_column: str | None,
            follow_ups: list[Any],
        ) -> dict[str, Any]:
            ordered = frame.sort("period")
            series_value = None
            if series_column is not None and series_column in ordered.columns and ordered.height > 0:
                series_value = str(ordered[series_column][0])

            if ordered.height < min_points:
                return {
                    "summary": {
                        "text": "Not enough points to assess volatility.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": {
                        "series": series_value,
                        "points": ordered.height,
                        "min_points": min_points,
                        "assessment": "insufficient_data",
                    },
                }

            values = [float(value) for value in ordered["value"].to_list()]
            deltas = [current - previous for previous, current in zip(values, values[1:])]
            abs_deltas = [abs(delta) for delta in deltas]
            max_delta = round(max(abs_deltas), 4)
            sign_changes = _count_direction_changes(deltas)
            metadata = {
                "series": series_value,
                "points": ordered.height,
                "min_points": min_points,
                "max_delta": max_delta,
                "sign_changes": sign_changes,
                "volatility_threshold": volatility_threshold,
                "sign_change_threshold": sign_change_threshold,
                "assessment": "assessed",
            }

            series_text = f" for {series_value}" if series_value else ""
            is_volatile = (
                max_delta >= volatility_threshold
                or sign_changes >= sign_change_threshold
            )
            if not is_volatile:
                return {
                    "summary": {
                        "text": f"The series is relatively steady{series_text} over the measured periods.",
                        "severity": "info",
                    },
                    "findings": [],
                    "metadata": metadata,
                }

            return {
                "summary": {
                    "text": f"The series is volatile{series_text} across the measured periods.",
                    "severity": "warning",
                },
                "findings": [
                    {
                        "kind": "trend_volatility",
                        "summary": f"The metric swings sharply{series_text} between adjacent periods.",
                        "severity": "warning",
                        "evidence": [
                            {"label": "Max adjacent delta", "value": max_delta},
                            {"label": "Direction changes", "value": sign_changes},
                        ],
                        "details": [],
                        "follow_ups": follow_ups,
                        "metadata": metadata,
                    }
                ],
                "metadata": metadata,
            }


        def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:
            frame = inputs["current"]
            follow_ups = list(params.get("follow_ups", []))
            min_points = max(2, int(params.get("min_points", 3) or 3))
            raw_volatility_threshold = params.get("volatility_threshold")
            volatility_threshold = (
                0.1 if raw_volatility_threshold is None else float(raw_volatility_threshold)
            )
            sign_change_threshold = max(1, int(params.get("sign_change_threshold", 2) or 2))
            series_column = "series" if "series" in frame.columns else None
            groups = (
                frame.partition_by(series_column, maintain_order=True)
                if series_column is not None
                else [frame]
            )
            results = [
                _analyze_group(
                    group,
                    min_points=min_points,
                    volatility_threshold=volatility_threshold,
                    sign_change_threshold=sign_change_threshold,
                    series_column=series_column,
                    follow_ups=follow_ups,
                )
                for group in groups
            ]

            if len(results) == 1:
                return results[0]

            findings = [finding for result in results for finding in result["findings"]]
            volatile_series = [
                str(result["metadata"]["series"])
                for result in results
                if result["metadata"].get("series") is not None and result["findings"]
            ]
            steady_series = [
                str(result["metadata"]["series"])
                for result in results
                if result["metadata"].get("series") is not None
                and result["metadata"].get("assessment") == "assessed"
                and not result["findings"]
            ]
            unassessed_series = [
                str(result["metadata"]["series"])
                for result in results
                if result["metadata"].get("series") is not None
                and result["metadata"].get("assessment") == "insufficient_data"
            ]
            all_series = [
                str(result["metadata"]["series"])
                for result in results
                if result["metadata"].get("series") is not None
            ]
            if volatile_series:
                summary = {
                    "text": (
                        "Volatility detected in multiple series: "
                        + ", ".join(volatile_series)
                        + "."
                    ),
                    "severity": "warning",
                }
            elif unassessed_series:
                summary = {
                    "text": (
                        "Volatility assessment is incomplete. Not enough points for: "
                        + ", ".join(unassessed_series)
                        + "."
                    ),
                    "severity": "info",
                }
            else:
                summary = {
                    "text": "All series are relatively steady over the measured periods.",
                    "severity": "info",
                }

            return {
                "summary": summary,
                "findings": findings,
                "metadata": {
                    "series": all_series,
                    "series_count": len(all_series),
                    "volatile_series": volatile_series,
                    "steady_series": steady_series,
                    "unassessed_series": unassessed_series,
                    "volatility_threshold": volatility_threshold,
                    "sign_change_threshold": sign_change_threshold,
                },
            }
        """
        ).strip()
        + "\n"
    )
    source = _inject_docstring(
        source,
        "def _count_direction_changes(deltas: list[float]) -> int:",
        """Count meaningful sign changes across adjacent deltas in a series.""",
    )
    return _inject_docstring(
        source,
        "def run(*, inputs: dict[str, pl.DataFrame], params: dict[str, Any]) -> dict[str, Any]:",
        """Assess whether a time series swings sharply between adjacent periods.

Expected inputs:
- current: a table with period and value bindings, plus an optional series binding
  when several independent series should be assessed together.

Key params:
- min_points: require enough observations before volatility is assessed.
- volatility_threshold: minimum adjacent swing magnitude that counts as material.
- sign_change_threshold: require repeated directional reversals before flagging a
  volatile pattern.

Returns a summary, optional volatility findings, and metadata describing which
series were volatile, steady, or left unassessed because of insufficient points.
""",
    )


def _build_pending_builtin_insight_paths(category: str, insight_id: str) -> tuple[str, str]:
    root = f".kater/insights/{category}/{insight_id}"
    return (f"{root}/definition.yaml", f"{root}/insight.py")


def _build_pending_builtin_insight_definition(spec: dict[str, object]) -> str:
    inputs = cast(list[str], spec["inputs"])
    params = cast(list[str], spec["params"])
    return _build_definition_content(
        kater_id=str(spec["kater_id"]),
        name=str(spec["name"]),
        description=str(spec["description"]),
        inputs=inputs,
        params=params,
        input_comment=str(
            spec.get(
                "input_comment",
                "Named result inputs and the column bindings this insight expects.",
            )
        ),
        param_comment=str(
            spec.get(
                "param_comment",
                "Runtime parameters that control thresholds, comparison behavior, or interpretation.",
            )
        ),
        input_comments=cast(dict[str, str], spec.get("input_comments", {})),
        param_comments=cast(dict[str, str], spec.get("param_comments", {})),
    )


def _build_pending_builtin_insight_scaffold_items(spec: dict[str, object]) -> list[tuple[str, str]]:
    definition_path, source_path = _build_pending_builtin_insight_paths(
        str(spec["category"]),
        str(spec["insight_id"]),
    )
    source = _build_pending_builtin_insight_python(str(spec["name"]))
    if str(spec["insight_id"]) == "trend-volatility":
        source = _build_trend_volatility_insight_python()
    if str(spec["insight_id"]) == "current-vs-prior":
        source = _build_current_vs_prior_insight_python()
    if str(spec["insight_id"]) == "actual-vs-target":
        source = _build_actual_vs_target_insight_python()
    if str(spec["insight_id"]) == "segment-vs-benchmark":
        source = _build_segment_vs_benchmark_insight_python()
    if str(spec["insight_id"]) == "mix-shift":
        source = _build_mix_shift_insight_python()
    if str(spec["insight_id"]) == "threshold-breach":
        source = _build_threshold_breach_insight_python()
    if str(spec["insight_id"]) == "outlier-detection":
        source = _build_outlier_detection_insight_python()
    return [
        (definition_path, _build_pending_builtin_insight_definition(spec)),
        (source_path, source),
    ]


NEW_BUILTIN_INSIGHT_SPECS: list[dict[str, object]] = [
    {
        "category": "trends",
        "insight_id": "trend-volatility",
        "kater_id": "ab6d4886-4512-444b-bbbe-d062ffc92c05",
        "name": "trend_volatility",
        "description": "Built-in trend volatility insight.",
        "inputs": [
            "  current:",
            "    required: true",
            "    bindings:",
            "      period:",
            "        type: date",
            "        column_constraints: [dimension]",
            "        required: true",
            "      value:",
            "        type: number",
            "        column_constraints: [measure, calculation]",
            "        required: true",
            "      series:",
            "        type: string",
            "        column_constraints: [dimension]",
            "        required: false",
        ],
        "params": [
            "  min_points:",
            "    type: integer",
            "    required: false",
            "    default: 3",
            "  volatility_threshold:",
            "    type: number",
            "    required: false",
            "    default: 0.1",
            "  sign_change_threshold:",
            "    type: integer",
            "    required: false",
            "    default: 2",
            "  follow_ups:",
            "    type: array",
            "    required: false",
        ],
        "input_comment": "Result tables and bound columns used to assess volatility across ordered periods.",
        "param_comment": "Parameters that control minimum coverage and how much movement counts as volatility.",
        "representative_input": "current",
        "representative_param": "volatility_threshold",
    },
    {
        "category": "trends",
        "insight_id": "current-vs-prior",
        "kater_id": "655ca52f-d67d-41e4-8a9c-8d55926f9d02",
        "name": "current_vs_prior",
        "description": "Built-in current-versus-prior comparison insight.",
        "inputs": [
            "  current:",
            "    required: true",
            "    bindings:",
            "      key:",
            "        type: string",
            "        column_constraints: [dimension]",
            "        required: true",
            "      value:",
            "        type: number",
            "        column_constraints: [measure, calculation]",
            "        required: true",
            "  prior:",
            "    required: true",
            "    bindings:",
            "      key:",
            "        type: string",
            "        column_constraints: [dimension]",
            "        required: true",
            "      value:",
            "        type: number",
            "        column_constraints: [measure, calculation]",
            "        required: true",
        ],
        "params": [
            "  min_absolute_delta:",
            "    type: number",
            "    required: false",
            "    default: 0",
            "  min_relative_delta:",
            "    type: number",
            "    required: false",
            "    default: 0.05",
            "  directionality:",
            "    type: string",
            "    required: false",
            "    default: higher_is_better",
            "  aggregate_mode:",
            "    type: string",
            "    required: false",
            "    default: row_level",
            "  follow_ups:",
            "    type: array",
            "    required: false",
        ],
        "input_comment": "Result tables and bound columns for the current snapshot and the prior comparison snapshot.",
        "param_comment": "Parameters that define minimum movement, directionality, and whether to compare row-level or aggregate deltas.",
        "input_comments": {
            "  current:": "Current-period rows keyed by the evaluated entity.",
            "  prior:": "Prior-period rows keyed to the same entities as current.",
        },
        "representative_input": "prior",
        "representative_param": "aggregate_mode",
    },
    {
        "category": "comparisons",
        "insight_id": "actual-vs-target",
        "kater_id": "51c24af0-3510-4530-b019-586b050ea5be",
        "name": "actual_vs_target",
        "description": "Built-in actual-versus-target comparison insight.",
        "inputs": [
            "  actuals:",
            "    required: true",
            "    bindings:",
            "      key:",
            "        type: string",
            "        column_constraints: [dimension]",
            "        required: true",
            "      actual:",
            "        type: number",
            "        column_constraints: [measure, calculation]",
            "        required: true",
            "  targets:",
            "    required: true",
            "    bindings:",
            "      key:",
            "        type: string",
            "        column_constraints: [dimension]",
            "        required: true",
            "      target:",
            "        type: number",
            "        column_constraints: [measure, calculation]",
            "        required: true",
        ],
        "params": [
            "  min_absolute_gap:",
            "    type: number",
            "    required: false",
            "    default: 0",
            "  min_relative_gap:",
            "    type: number",
            "    required: false",
            "    default: 0.05",
            "  directionality:",
            "    type: string",
            "    required: false",
            "    default: higher_is_better",
            "  follow_ups:",
            "    type: array",
            "    required: false",
        ],
        "input_comment": "Result tables and bound columns for observed actual values and their explicit targets.",
        "param_comment": "Parameters that suppress immaterial gaps and define whether being above target is favorable.",
        "input_comments": {
            "  actuals:": "Observed values to evaluate.",
            "  targets:": "Target values keyed to the same entities as actuals.",
        },
        "representative_input": "actuals",
        "representative_param": "min_relative_gap",
    },
    {
        "category": "comparisons",
        "insight_id": "segment-vs-benchmark",
        "kater_id": "bdb07273-8394-49e4-b8b5-9300ffbc1681",
        "name": "segment_vs_benchmark",
        "description": "Built-in segment-versus-benchmark comparison insight.",
        "inputs": [
            "  segment:",
            "    required: true",
            "    bindings:",
            "      key:",
            "        type: string",
            "        column_constraints: [dimension]",
            "        required: true",
            "      value:",
            "        type: number",
            "        column_constraints: [measure, calculation]",
            "        required: true",
            "  benchmark:",
            "    required: true",
            "    bindings:",
            "      key:",
            "        type: string",
            "        column_constraints: [dimension]",
            "        required: true",
            "      value:",
            "        type: number",
            "        column_constraints: [measure, calculation]",
            "        required: true",
        ],
        "params": [
            "  min_absolute_gap:",
            "    type: number",
            "    required: false",
            "    default: 0",
            "  min_relative_gap:",
            "    type: number",
            "    required: false",
            "    default: 0.05",
            "  directionality:",
            "    type: string",
            "    required: false",
            "    default: higher_is_better",
            "  follow_ups:",
            "    type: array",
            "    required: false",
        ],
        "input_comment": "Result tables and bound columns for evaluated segment values and the benchmark they should be compared against.",
        "param_comment": "Parameters that suppress small gaps and define whether higher or lower values count as outperforming.",
        "input_comments": {
            "  segment:": "Observed segment or entity values.",
            "  benchmark:": "Benchmark values keyed to the same segments or entities.",
        },
        "representative_input": "benchmark",
        "representative_param": "directionality",
    },
    {
        "category": "distributions",
        "insight_id": "mix-shift",
        "kater_id": "65068854-c55b-4bc0-81ba-614a6e5ffa92",
        "name": "mix_shift",
        "description": "Built-in mix-shift distribution insight.",
        "inputs": [
            "  current:",
            "    required: true",
            "    bindings:",
            "      segment:",
            "        type: string",
            "        column_constraints: [dimension]",
            "        required: true",
            "      value:",
            "        type: number",
            "        column_constraints: [measure, calculation]",
            "        required: true",
            "  prior:",
            "    required: true",
            "    bindings:",
            "      segment:",
            "        type: string",
            "        column_constraints: [dimension]",
            "        required: true",
            "      value:",
            "        type: number",
            "        column_constraints: [measure, calculation]",
            "        required: true",
        ],
        "params": [
            "  min_share_delta:",
            "    type: number",
            "    required: false",
            "    default: 0.05",
            "  min_value_delta:",
            "    type: number",
            "    required: false",
            "    default: 0",
            "  normalize:",
            "    type: boolean",
            "    required: false",
            "    default: true",
            "  follow_ups:",
            "    type: array",
            "    required: false",
        ],
        "input_comment": "Result tables and bound columns for the current and prior distributions being compared.",
        "param_comment": "Parameters that define whether to compare normalized share movement or raw-value movement.",
        "input_comments": {
            "  current:": "Current snapshot segment totals.",
            "  prior:": "Prior snapshot segment totals matched by segment name.",
        },
        "param_comments": {
            "  min_share_delta:": "Applied only when normalize is true.",
            "  min_value_delta:": "Applied only when normalize is false.",
            "  normalize:": "When true compare shares, otherwise compare raw values.",
            "  follow_ups:": "Optional caller-provided actions that may be attached to emitted findings.",
        },
        "representative_input": "prior",
        "representative_param": "min_share_delta",
    },
    {
        "category": "exceptions",
        "insight_id": "threshold-breach",
        "kater_id": "a554db02-0bea-4470-90dd-dddd84caaaf9",
        "name": "threshold_breach",
        "description": "Built-in threshold-breach exception insight.",
        "inputs": [
            "  current:",
            "    required: true",
            "    bindings:",
            "      label:",
            "        type: string",
            "        column_constraints: [dimension]",
            "        required: true",
            "      value:",
            "        type: number",
            "        column_constraints: [measure, calculation]",
            "        required: true",
            "      threshold:",
            "        type: number",
            "        column_constraints: [measure, calculation]",
            "        required: false",
        ],
        "params": [
            "  threshold_value:",
            "    type: number",
            "    required: false",
            "  breach_direction:",
            "    type: string",
            "    required: false",
            "    default: above",
            "  follow_ups:",
            "    type: array",
            "    required: false",
        ],
        "input_comment": "Result tables and bound columns used to test each row against a threshold.",
        "param_comment": "Parameters that define the fallback threshold and whether breaches are above or below it.",
        "param_comments": {
            "  threshold_value:": "Used when no threshold column is bound on the input table.",
            "  follow_ups:": "Optional caller-provided actions that may be attached to emitted findings.",
        },
        "representative_input": "current",
        "representative_param": "breach_direction",
    },
    {
        "category": "exceptions",
        "insight_id": "outlier-detection",
        "kater_id": "196fa8e6-3e78-4204-967a-9f8549cc48c9",
        "name": "outlier_detection",
        "description": "Built-in outlier-detection exception insight.",
        "inputs": [
            "  current:",
            "    required: true",
            "    bindings:",
            "      label:",
            "        type: string",
            "        column_constraints: [dimension]",
            "        required: true",
            "      value:",
            "        type: number",
            "        column_constraints: [measure, calculation]",
            "        required: true",
        ],
        "params": [
            "  deviation_method:",
            "    type: string",
            "    required: false",
            "    default: z_score",
            "  sensitivity:",
            "    type: number",
            "    required: false",
            "    default: 2.0",
            "  follow_ups:",
            "    type: array",
            "    required: false",
        ],
        "input_comment": "Result tables and bound columns representing the peer group used for outlier scoring.",
        "param_comment": "Parameters that define the deviation method and how aggressive the outlier threshold should be.",
        "representative_input": "current",
        "representative_param": "deviation_method",
    },
]

for _spec in NEW_BUILTIN_INSIGHT_SPECS:
    _definition_path, _source_path = _build_pending_builtin_insight_paths(
        str(_spec["category"]),
        str(_spec["insight_id"]),
    )
    _spec["definition_path"] = _definition_path
    _spec["source_path"] = _source_path


# Pre-generated from packages/components_core/src/theme/default-theme.json
# via serializeThemeConfigToCss(defaultTheme, { kind: 'runtime' }).
# Uses D1-scoped selectors with __SCOPE__ placeholder.
# The default theme is stable so this is safe to store as a static constant.
DEFAULT_KATER_GLOBALS_CSS = """\
:root {
  --kater-theme-name: 'kater';
}

[data-kater-theme][data-kater-scope="__SCOPE__"][data-kater-mode="light"] {
  --background: #f5f5f5;
  --foreground: #0a0a0a;
  --card: #f5f5f5;
  --card-foreground: #0a0a0a;
  --popover: #ebeef0;
  --popover-foreground: #0a0a0a;
  --primary: #007aa9;
  --primary-foreground: #f5f5f5;
  --secondary: #d4dfe3;
  --secondary-foreground: #384d55;
  --muted: #dcdcdc;
  --muted-foreground: #525252;
  --accent: #bacfd8;
  --accent-foreground: #076083;
  --destructive: #fecaca;
  --destructive-foreground: #0a0a0a;
  --border: #bdcbd1;
  --input: #ededed;
  --ring: #a3a3a3;
  --sidebar: #f5f5f5;
  --sidebar-foreground: #0a0a0a;
  --sidebar-primary: #e9e9e9;
  --sidebar-primary-foreground: #0f5570;
  --sidebar-accent: #bacfd8;
  --sidebar-accent-foreground: #0d5d7d;
  --sidebar-border: #bdcbd1;
  --sidebar-ring: #a3a3a3;
  --chart-1: #978ae0;
  --chart-2: #c27fd1;
  --chart-3: #c48d82;
  --chart-4: #7aa6c4;
  --chart-5: #77bd93;

  --font-family: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji';
  --font-sans: ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, 'Noto Sans', sans-serif, 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji';
  --font-serif: ui-serif, Georgia, Cambria, "Times New Roman", Times, serif;
  --font-mono: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;
  --font-size-base: 15px;

  --radius: 0.625rem;
  --spacing: 0.25rem;
  --tracking-normal: 0em;

  --shadow-color: #000000;
  --shadow-opacity: 0.1;
  --shadow-blur: 3px;
  --shadow-spread: 0px;
  --shadow-x: 0px;
  --shadow-y: 1px;
  --tw-shadow-color: rgba(0, 0, 0, 0.1);
}

[data-kater-theme][data-kater-scope="__SCOPE__"][data-kater-mode="dark"] {
  --background: #0e1113;
  --foreground: #f5f5f5;
  --card: #12181c;
  --card-foreground: #f5f5f5;
  --popover: #181F27;
  --popover-foreground: #f5f5f5;
  --primary: #bceeff;
  --primary-foreground: #222425;
  --secondary: #3c4449;
  --secondary-foreground: #e3e3e3;
  --muted: #27292b;
  --muted-foreground: #a3a3a3;
  --accent: #3c4449;
  --accent-foreground: #bceeff;
  --destructive: #991b1b;
  --destructive-foreground: #f5f5f5;
  --border: #283033;
  --input: #161a1d;
  --ring: #6993b0;
  --sidebar: #121617;
  --sidebar-foreground: #f5f5f5;
  --sidebar-primary: #1a1d1f;
  --sidebar-primary-foreground: #fafafa;
  --sidebar-accent: #3c4449;
  --sidebar-accent-foreground: #bceeff;
  --sidebar-border: #283033;
  --sidebar-ring: #6993b0;
  --chart-1: #7a72a8;
  --chart-2: #825b8a;
  --chart-3: #85564a;
  --chart-4: #3d627a;
  --chart-5: #356c49;

  --shadow-color: #000000;
  --shadow-opacity: 0.1;
  --shadow-blur: 3px;
  --shadow-spread: 0px;
  --shadow-x: 0px;
  --shadow-y: 1px;
  --tw-shadow-color: rgba(0, 0, 0, 0.1);
}
"""

# Loaded from packages/components_core/src/theme/kater-chart-theme.yaml — the
# single source of truth (also consumed by chart-theme-defaults.ts). Do NOT
# replace this with a hand-maintained string: the guardrail test in
# packages/utils/tests/test_scaffold_templates.py will fail if you do, and more
# importantly the scaffold output will silently drift from the theme builder.
DEFAULT_KATER_CHART_THEME_YAML = _load_default_chart_theme_yaml()

# Generated from LayoutConfig() Pydantic model defaults.
# See: packages/core/src/kater_core/schemas/layout_config.py
DEFAULT_LAYOUT_YAML = """\
# Kater Layout Configuration
# Controls tenant branding, page surfaces, and shared Kater components.

branding:
  app_name: ''
  logo: null
  favicon: null

appearance:
  page_background: null

pages:
  for_you:
    page_background:
      mode: solid
      color: null
    insight_card:
      surface: solid
      glass_strength: 0.8
    grainient:
      strength: 0.7
      colors:
        color1: var(--chart-1)
        color2: var(--chart-2)
        color3: var(--chart-3)
        color4: var(--chart-4)
"""

GITIGNORE_CONTENT = """\
# Kater runtime directories (auto-generated, not version controlled)
_admin/tenants/

# Kater compiled output (auto-generated, check in manifest and dependency-graph only)
.kater/compiled/
.kater/resolved/
!.kater/manifest.yaml
!.kater/dependency-graph.yaml
"""


_BUILTIN_INSIGHT_SCAFFOLD_ITEMS: list[tuple[str, str]] = [
    (
        ".kater/insights/trends/trend-change/definition.yaml",
        _build_definition_content(
            kater_id="ad0bd8e3-c556-47c4-a32d-c5085bb939de",
            name="trend_change",
            description="Built-in trend change insight.",
            inputs=[
                "  current:",
                "    required: true",
                "    bindings:",
                "      period:",
                "        type: date",
                "        column_constraints: [dimension]",
                "        required: true",
                "      value:",
                "        type: number",
                "        column_constraints: [measure, calculation]",
                "        required: true",
                "      series:",
                "        type: string",
                "        column_constraints: [dimension]",
                "        required: false",
            ],
            params=[
                "  compare_mode:",
                "    type: string",
                "    required: false",
                "    default: endpoints",
                "  directionality:",
                "    type: string",
                "    required: false",
                "    default: higher_is_better",
                "  min_points:",
                "    type: integer",
                "    required: false",
                "    default: 2",
                "  min_absolute_delta:",
                "    type: number",
                "    required: false",
                "    default: 0",
                "  min_relative_delta:",
                "    type: number",
                "    required: false",
                "    default: 0.05",
                "  reversal_threshold:",
                "    type: number",
                "    required: false",
                "    default: 0.03",
                "  follow_ups:",
                "    type: array",
                "    required: false",
            ],
            input_comment="Result tables and bound columns used to evaluate the trend.",
            param_comment="Parameters that define comparison mode, directionality, and signal thresholds.",
        ),
    ),
    (
        ".kater/insights/trends/trend-change/insight.py",
        _build_trend_change_insight_python(),
    ),
    *[
        item
        for spec in NEW_BUILTIN_INSIGHT_SPECS[:2]
        for item in _build_pending_builtin_insight_scaffold_items(spec)
    ],
    (
        ".kater/insights/comparisons/top-bottom-gap/definition.yaml",
        _build_definition_content(
            kater_id="70e6ca32-5781-415a-bffe-8b169f71fe4d",
            name="top_bottom_gap",
            description="Built-in top-versus-bottom comparison insight.",
            inputs=[
                "  current:",
                "    required: true",
                "    bindings:",
                "      label:",
                "        type: string",
                "        column_constraints: [dimension]",
                "        required: true",
                "      value:",
                "        type: number",
                "        column_constraints: [measure, calculation]",
                "        required: true",
            ],
            params=[
                "  ranking_direction:",
                "    type: string",
                "    required: false",
                "    default: higher_is_better",
                "  min_rows:",
                "    type: integer",
                "    required: false",
                "    default: 2",
                "  compare_window:",
                "    type: integer",
                "    required: false",
                "    default: 1",
                "  min_absolute_gap:",
                "    type: number",
                "    required: false",
                "    default: 0",
                "  min_relative_gap:",
                "    type: number",
                "    required: false",
                "    default: 0.1",
                "  compare_mode:",
                "    type: string",
                "    required: false",
                "    default: group_average",
                "  follow_ups:",
                "    type: array",
                "    required: false",
            ],
            input_comment="Result tables and bound columns used to rank the observed rows.",
            param_comment="Parameters that control ranking semantics, comparison windows, and gap thresholds.",
        ),
    ),
    (
        ".kater/insights/comparisons/top-bottom-gap/insight.py",
        _build_top_bottom_gap_insight_python(),
    ),
    *[
        item
        for spec in NEW_BUILTIN_INSIGHT_SPECS[2:4]
        for item in _build_pending_builtin_insight_scaffold_items(spec)
    ],
    (
        ".kater/insights/distributions/largest-segment/definition.yaml",
        _build_definition_content(
            kater_id="44c9d946-ee97-4c63-a82b-749ac1964608",
            name="largest_segment",
            description="Built-in largest-segment distribution insight.",
            inputs=[
                "  current:",
                "    required: true",
                "    bindings:",
                "      segment:",
                "        type: string",
                "        column_constraints: [dimension]",
                "        required: true",
                "      value:",
                "        type: number",
                "        column_constraints: [measure, calculation]",
                "        required: true",
            ],
            params=[
                "  min_segments:",
                "    type: integer",
                "    required: false",
                "    default: 2",
                "  dominance_share:",
                "    type: number",
                "    required: false",
                "    default: 0.5",
                "  near_tie_delta:",
                "    type: number",
                "    required: false",
                "    default: 0.05",
                "  normalize:",
                "    type: boolean",
                "    required: false",
                "    default: true",
                "  follow_ups:",
                "    type: array",
                "    required: false",
            ],
            input_comment="Result tables and bound columns used to evaluate the observed distribution.",
            param_comment="Parameters that control minimum coverage, dominance thresholds, and share normalization.",
        ),
    ),
    (
        ".kater/insights/distributions/largest-segment/insight.py",
        _build_largest_segment_insight_python(),
    ),
    *[
        item
        for spec in NEW_BUILTIN_INSIGHT_SPECS[4:]
        for item in _build_pending_builtin_insight_scaffold_items(spec)
    ],
]


def build_root_scaffold_items(project_name: str) -> list[tuple[str, str]]:
    """Build (path, content) pairs for root-level Kater scaffold files.

    Returns all files that belong at the repository root during initial setup,
    excluding git submodule entries (.gitmodules / __sample_client_repo).

    Args:
        project_name: The project name used in kater.config.yaml and README.md.

    Returns:
        List of (relative_path, file_content) tuples.
    """
    kater_config = f'''# Kater Configuration

# Active theme preset (matches a built-in preset or custom theme name)
theme: kater

# Project settings
project:
  name: "{project_name}"
  description: "Kater semantic layer configuration"

# Database connection (configured in Kater dashboard)
# database:
#   type: snowflake
#   default_schema: public

# Feature flags
features:
  # Enable AI-assisted query generation
  ai_assist: true
  # Enable semantic search
  semantic_search: true
'''

    return [
        ("kater.config.yaml", kater_config),
        ("README.md", SCAFFOLDED_README_TEMPLATE.format(repository_name=project_name)),
        ("_admin/query_policy.yaml", QUERY_POLICY_TEMPLATE.format(kater_id=str(uuid.uuid4()))),
        ("_admin/integrations.yaml", INTEGRATIONS_PLACEHOLDER),
        ("_admin/grants/access_filters.yaml", GRANTS_ACCESS_FILTERS_PLACEHOLDER),
        ("_admin/grants/access_grants.yaml", GRANTS_ACCESS_GRANTS_PLACEHOLDER),
        ("_admin/grants/attributes.yaml", GRANTS_ATTRIBUTES_PLACEHOLDER),
        (".gitignore", GITIGNORE_CONTENT),
        ("theme/layout.yaml", DEFAULT_LAYOUT_YAML),
        ("theme/kater-chart-theme.yaml", DEFAULT_KATER_CHART_THEME_YAML),
        ("theme/kater-globals.css", DEFAULT_KATER_GLOBALS_CSS),
        ("theme/custom-themes/.gitkeep", ""),
        *_load_root_resource_items(),
        *_BUILTIN_INSIGHT_SCAFFOLD_ITEMS,
    ]


def get_root_scaffold_paths(project_name: str = "scaffold-probe") -> set[str]:
    """Return the canonical path set for root scaffold files."""
    return {path for path, _ in build_root_scaffold_items(project_name)}


def get_resource_scaffold_paths(project_name: str = "scaffold-probe") -> set[str]:
    """Return the canonical subset of scaffold paths under resources/."""
    return {path for path in get_root_scaffold_paths(project_name) if path.startswith("resources/")}


def get_optional_github_scaffold_paths() -> set[str]:
    """Return GitHub-managed optional paths excluded from the canonical root scaffold."""
    return {".gitmodules", "__sample_client_repo"}


def get_required_force_scaffold_paths(project_name: str = "scaffold-probe") -> set[str]:
    """Return the canonical force-mode required path set."""
    return get_root_scaffold_paths(project_name)
