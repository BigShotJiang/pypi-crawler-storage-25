"""
Integration tests for the training pipeline and model.

This test suite provides comprehensive testing of the ContrastiveModel
and the training workflow.

"""

import importlib.util
import logging
import os
from unittest.mock import MagicMock, patch

import numpy as np
import pytest
import torch

from lamin_dataloader import BaseCollate, InMemoryCollection, TokenizedDataset
from torch.utils.data import DataLoader

from concept import ContrastiveModel

logger = logging.getLogger(__name__)

FLASH_ATTN_AVAILABLE = importlib.util.find_spec("flash_attn") is not None
IS_GITHUB_ACTIONS = os.environ.get("GITHUB_ACTIONS") == "true"
FLASH_ATTENTION_PARAMS = [
    False,
    pytest.param(
        True,
        marks=pytest.mark.skipif(not FLASH_ATTN_AVAILABLE, reason="flash_attn is not installed"),
    ),
]

def _mock_encode(
    self,
    tokens,
    values,
    src_key_padding_mask=None,
    seq_lengths=None,
    return_padded_embeddings=False,
):
    """
    Mock the _encode function to avoid complex transformer computations.
    Returns mock embeddings and cell embeddings with correct shapes.
    """
    batch_size = tokens.size(0)
    seq_len = tokens.size(1)
    device = tokens.device
    embs_padded = torch.randn(batch_size, seq_len, self.dim_model, device=device, dtype=torch.float32)
    cell_embs = embs_padded[:, 0, :]
    return embs_padded, cell_embs



@pytest.fixture
def mock_config():
    """Create a mock configuration for testing"""
    return {
        "flash_attention": False,  # Set to False to use regular transformer
        "dim_gene_embs": 64,
        "dim_model": 64,
        "num_head": 4,
        "dim_hid": 128,
        "nlayers": 2,
        "dropout": 0.1,
        "decoder_head": False,
        "mask_value": -1,
        "cls_value": -2,
        "mask_padding": False,
        "input_encoding": "rank_encoding",
        "pe_max_len": 1000,
        "mlm_loss_weight": 0.0,
        "cont_loss_weight": 1.0,
        "contrastive_loss": "multiclass",
        "logit_scale_init_value": 1.0,
        "per_view_normalization": False,
        "random_split": False,
        "loss_switch_step": 1000,
        "values_only_sanity_check": False,
        "data_loading_speed_sanity_check": False,
        "projection_dim": None,
        "training": {
            "masking_rate": 0.0,
            "lr": 1e-3,
            "weight_decay": 0.0,
            "optimizer_class": "AdamW",
            "scheduler": "warmup",
            "freeze_pretrained_vocabulary": None,
            "use_learnable_embs_freq": None,
            "warmup": 100,
            "max_steps": 1000,
            "min_lr": 0.0,
        },
    }


def test_model_initialization(mock_config, device):
    """Test that the model can be initialized with mock config"""
    model = ContrastiveModel(
        config=mock_config, pad_token_id=0, cls_token_id=1, vocab_sizes={"hsapiens": 100}, world_size=1, val_loader_names=[]
    )

    # Move model to device
    model = model.to(device)

    assert model is not None
    assert "hsapiens" in model.gene_token_encoder.learnable_embs
    assert model.dim_model == 64
    assert model.num_head == 4
    assert model.device.type == device.type


@pytest.mark.parametrize("flash_attention", FLASH_ATTENTION_PARAMS)
@pytest.mark.parametrize("use_pretrained_vocabulary", [False, True])
def test_training_step(mock_config, device, flash_attention, use_pretrained_vocabulary):
    """Test that the model can perform a training step"""
    # Update mock_config with parameterized flash_attention value
    vocab_size = 20
    mock_config["flash_attention"] = flash_attention
    mock_config["training"]["scheduler"] = None

    if use_pretrained_vocabulary:
        # Create a pretrained vocabulary with a known value and keep reference for later
        with torch.no_grad():
            pretrained_vocabulary = torch.ones(vocab_size, 256, requires_grad=False)
        mock_config["training"]["freeze_pretrained_vocabulary"] = True
        mock_config["training"]["use_learnable_embs_freq"] = 1.0
    else:
        pretrained_vocabulary = None

    model = ContrastiveModel(
        config=mock_config,
        cls_token_id=0,
        pad_token_id=1,
        vocab_sizes={"hsapiens": vocab_size},
        world_size=1,
        val_loader_names=["val_test"],
        pretrained_vocabularies={"hsapiens": pretrained_vocabulary} if pretrained_vocabulary is not None else None,
    )

    # Move model to device
    model = model.to(device)
    optimizer = ContrastiveModel.configure_optimizers(model)

    # Create mock batch data
    batch_size = 8
    seq_len = 20

    panel = torch.randint(2, vocab_size, (1, 10))
    panel = panel.repeat(batch_size, 1)

    # Create mock batch with paired data
    batch = {
        "tokens_1": torch.randint(2, vocab_size, (batch_size, seq_len)).to(device),
        "values_1": torch.randn(batch_size, seq_len).to(device),
        "panel_1": panel.to(device),
        "tokens_2": torch.randint(2, vocab_size, (batch_size, seq_len)).to(device),
        "values_2": torch.randn(batch_size, seq_len).to(device),
        "panel_2": panel.to(device),
        "dataset": torch.randint(0, 2, (batch_size,)).to(device),
        "panel_name_1": "test_panel_1",
        "panel_name_2": "test_panel_2",
        "seq_length_1": [seq_len] * batch_size,
        "seq_length_2": [seq_len] * batch_size,
        "species": ["hsapiens"] * batch_size,
        "_organism": "hsapiens",
        "_tissue": "brain",
    }

    # Test training step
    model.train()
    # Keep a copy of pretrained pretrained_embs tensor before backward if it is used
    if use_pretrained_vocabulary:
        pretrained_embed_before = model.gene_token_encoder.pretrained_embs["hsapiens"].weight.clone()
        # Capture a deepcopy of all model parameters before training step
    params_before = {name: param.clone().detach() for name, param in model.named_parameters()}

    with patch.object(model, "log_metric") as mock_log:
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
            loss = model.training_step(batch, batch_idx=0)

        call_args_list = [call.args[0] for call in mock_log.call_args_list]
        assert any(call == "train/loss" for call in call_args_list)
        assert any(call == "train/loss_cont" for call in call_args_list)

        assert isinstance(loss, torch.Tensor)
        assert loss.requires_grad
        assert not torch.isnan(loss)
        assert loss.device.type == device.type

        # Run backward on the loss
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()

        # Assert all trainable (requires_grad) parameters have been updated
        params_after = {name: param for name, param in model.named_parameters()}
        for name, before in params_before.items():
            param = params_after[name]
            if param.requires_grad:
                # Some params might be floating point, others ints, only check for float types
                if before.dtype.is_floating_point:
                    # Check that at least one element has changed
                    assert not torch.equal(before, param), f"Parameter {name} was not updated!"

        if use_pretrained_vocabulary:
            assert torch.equal(pretrained_embed_before, model.gene_token_encoder.pretrained_embs["hsapiens"].weight)


@pytest.mark.parametrize("flash_attention", FLASH_ATTENTION_PARAMS)
def test_validation_step(mock_config, device, flash_attention):
    """Test that the model can perform a validation step and calls model.log appropriately"""
    # Update mock_config with parameterized flash_attention value
    mock_config["flash_attention"] = flash_attention

    model = ContrastiveModel(
        config=mock_config, pad_token_id=0, cls_token_id=1, vocab_sizes={"hsapiens": 100}, world_size=1, val_loader_names=["test_val"]
    )

    # Move model to device
    model = model.to(device)

    # Create mock batch data
    batch_size = 8
    seq_len = 20

    panel = torch.randint(2, 100, (1, 10))
    panel = panel.repeat(batch_size, 1)

    batch = {
        "tokens_1": torch.randint(2, 100, (batch_size, seq_len)).to(device),
        "values_1": torch.randn(batch_size, seq_len).to(device),
        "panel_1": panel.to(device),
        "tokens_2": torch.randint(2, 100, (batch_size, seq_len)).to(device),
        "values_2": torch.randn(batch_size, seq_len).to(device),
        "panel_2": panel.to(device),
        "dataset": torch.randint(0, 2, (batch_size,)).to(device),
        "panel_name_1": "test_panel_1",
        "panel_name_2": "test_panel_2",
        "seq_length_1": [seq_len] * batch_size,
        "seq_length_2": [seq_len] * batch_size,
        "species": ["hsapiens"] * batch_size,
        "_organism": "hsapiens",
        "_tissue": "brain",
    }

    # Test validation step and check model.log calls
    model.eval()
    with torch.no_grad(), patch.object(model, "log_metric") as mock_log:
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
            model.validation_step(batch, batch_idx=0, dataloader_idx=0)

        call_args_list = [call.args[0] for call in mock_log.call_args_list]
        assert any(call == "val/test_val/loss" for call in call_args_list)
        assert any(call == "val/test_val/loss_cont" for call in call_args_list)


@pytest.mark.parametrize("flash_attention", FLASH_ATTENTION_PARAMS)
@pytest.mark.parametrize("seq_lengths_available", [True, False])
def test_predict_step(mock_config, device, flash_attention, seq_lengths_available):
    """Test that the model can perform a predict step"""
    # Update mock_config with parameterized flash_attention value
    mock_config["flash_attention"] = flash_attention

    model = ContrastiveModel(
        config=mock_config, pad_token_id=0, cls_token_id=1, vocab_sizes={"hsapiens": 100}, world_size=1, val_loader_names=["val_test"]
    )

    # Move model to device
    model = model.to(device)

    # Create mock batch data for prediction
    batch_size = 8
    seq_len = 20

    # Create mock batch for prediction (single view, not paired)
    batch = {
        "tokens": torch.randint(2, 100, (batch_size, seq_len)).to(device),
        "values": torch.randn(batch_size, seq_len).to(device),
        "dataset": torch.randint(0, 2, (batch_size,)).to(device),
        "panel_name": "test_panel",
        "seq_lengths": [seq_len] * batch_size if seq_lengths_available else None,
        "species": ["hsapiens"] * batch_size,
        "_organism": "hsapiens",
        "_tissue": "brain",
    }

    # Test predict step
    model.eval()
    with torch.no_grad():
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
            result = model.predict_step(batch, batch_idx=0)

    # Check that we get the expected keys
    expected_keys = ["pred", "cls_cell_emb", "context_sizes"]
    for key in expected_keys:
        assert key in result

    # Check output shapes
    assert result["cls_cell_emb"].shape == (batch_size, mock_config["dim_model"])
    assert isinstance(result["context_sizes"], tuple)
    assert len(result["context_sizes"]) == 2  # (context_size, nonzero_cnt)

    # Check that pred is None when decoder_head is False
    assert result["pred"] is None

    # Check that outputs are on the correct device
    assert result["cls_cell_emb"].device.type == device.type


@pytest.mark.parametrize(
    "batch_size,max_tokens,gene_sampling_strategy",
    [
        (8, 20, "random"),
        (8, 20, "top"),
        (8, 20, "random-nonzero"),
        (8, 20, "top-nonzero"),
        (1, 20, "top-nonzero"),
        (8, 2, "top-nonzero"),
        (8, 1, "top-nonzero"),
    ],
)
def test_predict_step_with_lamin_dataloader(
    mock_config, device, adata, tokenizer, batch_size, max_tokens, gene_sampling_strategy
):
    """Test predict_step using InMemory TokenizedDataset and
    BaseCollate from lamin_dataloader with different parameters"""

    # Create model
    model = ContrastiveModel(
        config=mock_config,
        pad_token_id=0,
        cls_token_id=1,
        vocab_sizes={"hsapiens": len(tokenizer.gene_mapping)},
        world_size=1,
        val_loader_names=[],
    )
    model = model.to(device)
    model.eval()

    model.set_active_species("hsapiens")

    # Create InMemory TokenizedDataset
    test_dataset = TokenizedDataset(collection=InMemoryCollection([adata]), tokenizer=tokenizer, normalization="raw")

    # Create BaseCollate with parameterized max_tokens
    collate_fn = BaseCollate(tokenizer.PAD_TOKEN, max_tokens=max_tokens, gene_sampling_strategy=gene_sampling_strategy)

    # Create DataLoader with parameterized batch_size
    dataloader = DataLoader(test_dataset, batch_size=batch_size, collate_fn=collate_fn, shuffle=False, drop_last=False)

    # Test predict_step with real data pipeline
    all_outputs = []
    with torch.no_grad():
        with torch.autocast(device_type=device.type, dtype=torch.bfloat16):
            for batch_idx, batch in enumerate(dataloader):
                # Move batch to device
                batch = {
                    key: value.to(device) if isinstance(value, torch.Tensor) else value for key, value in batch.items()
                }

                # Call predict_step
                output = model.predict_step(batch, batch_idx)
                all_outputs.append(output)

                # Verify output structure
                expected_keys = ["pred", "cls_cell_emb"]
                for key in expected_keys:
                    assert key in output, f"Missing key: {key}"

                # Verify output shapes
                actual_batch_size = batch["tokens"].shape[0]
                assert output["cls_cell_emb"].shape == (actual_batch_size, mock_config["dim_model"])

                # Only test first few batches to keep test fast
                if batch_idx >= 2:
                    break

    # Verify we got some outputs
    assert len(all_outputs) > 0, f"No outputs generated for batch_size={batch_size}, max_tokens={max_tokens}"

    # Test that we can concatenate all cell embeddings
    all_cls_embs = torch.cat([output["cls_cell_emb"] for output in all_outputs], dim=0)

    # Verify final shapes
    total_cells = sum(batch["tokens"].shape[0] for batch in list(dataloader)[:3])
    assert all_cls_embs.shape[0] == total_cells
    assert all_cls_embs.shape[1] == mock_config["dim_model"]


@pytest.mark.parametrize(
    "model_name",
    [
        "corpus40M-model30M",
        pytest.param(
            "corpus230M[human]-model170M",
            marks=pytest.mark.skipif(
                IS_GITHUB_ACTIONS,
                reason="large API integration model is too heavy for GitHub Actions",
            ),
        ),
    ],
)
@pytest.mark.parametrize("use_direct_paths", [False, True])
def test_api_integration(adata, model_name, use_direct_paths, tmp_path):
    """Integration test for scConcept class with real HuggingFace model

    Tests both loading methods:
    - use_direct_paths=False: Load using model_name (HuggingFace download)
    - use_direct_paths=True: Load using direct paths (bypasses HuggingFace download)
    """
    from pathlib import Path

    from concept import scConcept

    # Initialize scConcept
    cache_dir = str(tmp_path / "cache")
    sc_concept = scConcept(cache_dir=cache_dir)

    # Test model loading with either method
    if use_direct_paths:
        # Download model files to get paths for direct path testing
        model_dir = Path(sc_concept.cache_dir) / model_name
        model_dir.mkdir(parents=True, exist_ok=True)

        # Download files
        model_path, gene_mappings_path, config_path, panels_dir, pretrained_vocabulary_path = sc_concept._download_files_if_needed(
            model_name, model_dir
        )

        # Load using direct paths
        sc_concept = scConcept()
        logger.info(f"Loading model from {model_path}, {gene_mappings_path}, {config_path}, {panels_dir}")
        sc_concept.load_config_and_model(
            config=config_path,
            model_path=model_path,
            gene_mappings_path=gene_mappings_path,
            panels_dir=panels_dir,
            pretrained_vocabulary_path = pretrained_vocabulary_path
        )
    else:
        # Load using model_name (original method)
        sc_concept.load_config_and_model(model_name)

    # Verify model is loaded correctly
    assert sc_concept.model is not None
    assert sc_concept.tokenizer is not None
    assert sc_concept.device is not None
    assert sc_concept.cfg is not None

    # Test embedding extraction from AnnData
    batch_size = 4

    result = sc_concept.extract_embeddings(
        adata=adata,
        batch_size=batch_size,
    )

    # Verify result structure
    expected_keys = ["cls_cell_emb"]
    for key in expected_keys:
        assert key in result, f"Missing key: {key}"

    # Verify embedding shapes
    n_cells = adata.shape[0]
    assert result["cls_cell_emb"].shape == (n_cells, sc_concept.model.dim_model)

    # Verify embeddings are numpy arrays
    assert isinstance(result["cls_cell_emb"], np.ndarray)

    # Verify embeddings are not all zeros or NaNs
    assert not np.all(result["cls_cell_emb"] == 0)
    assert not np.any(np.isnan(result["cls_cell_emb"]))

    # Test training with pre-trained model (resuming/fine-tuning)
    # Store initial model state for comparison
    initial_state = {}
    for name, param in sc_concept.model.named_parameters():
        if param.requires_grad:
            initial_state[name] = param.data.clone()

    # Train for a few steps to verify training works
    # Use small max_steps and batch_size to keep test fast
    training_max_steps = 3
    training_batch_size = 8
    sc_concept.cfg.datamodule.dataset.train.panel_size_min = len(adata.var) // 2

    # Verify model is in eval mode before training
    assert not sc_concept.model.training, "Model should be in eval mode after loading"

    # Run training
    sc_concept.train(
        adata_list=adata, species="hsapiens", max_steps=training_max_steps, batch_size=training_batch_size
    )

    # Verify model is still valid after training
    assert sc_concept.model is not None

    # Verify that model parameters have changed (training occurred)
    # Check at least one parameter has changed
    parameters_changed = False
    for name, param in sc_concept.model.named_parameters():
        if param.requires_grad and name in initial_state:
            # Ensure both tensors are on the same device for comparison
            initial_param = initial_state[name].to(param.data.device)
            if not torch.equal(param.data, initial_param):
                parameters_changed = True
                break

    assert parameters_changed, "Model parameters should have changed after training"


@pytest.mark.parametrize("use_stored_adata", [False, True], ids=["in_memory", "stored"])
def test_anndatamodule_integration(adata, tokenizer, device, tmp_path, use_stored_adata):
    """Integration test for AnnDataModule with AnnData objects (in-memory or stored on disk).

    Tests that AnnDataModule can:
    - Initialize with AnnData objects (in-memory) or paths to h5ad files (stored)
    - Create train and test dataloaders
    - Iterate through dataloaders and produce valid batches
    - Handle collate functions properly
    """
    from concept.data import AnnDataModule

    # Create a simple panels file for testing
    panels_dir = tmp_path / "panels"
    panels_dir.mkdir()
    panel_file = panels_dir / "test_panel.csv"

    # Create a panel with some genes from adata
    import pandas as pd

    panel_genes = adata.var_names[:5].tolist()  # Use first 5 genes
    panel_df = pd.DataFrame({"Ensembl_ID": panel_genes})
    panel_df.to_csv(panel_file, index=False)

    # Build split: in-memory AnnData list or paths to stored h5ad files
    if use_stored_adata:
        adata_dir = tmp_path / "h5ads"
        adata_dir.mkdir()
        adata_path = adata_dir / "test_data.h5ad"
        adata.write(adata_path)
        split = {"paths": [str(adata_path)], "metadata": {"species": ["hsapiens"]}}
    else:
        split = {"paths": [adata], "metadata": {"species": ["hsapiens"]}}

    obs_keys = []  # No obs keys needed for basic test

    dataset_kwargs = {
        "train": {
            "split": split,
            "max_tokens": 20,
            "panel_selection": "mixed",
            "panel_selection_mixed_prob": 0.5,
            "panel_filter_regex": ".*",
            "panel_size_min": 5,
            "panel_size_max": 10,
            "panel_max_drop_rate": 0.1,
            "feature_max_drop_rate": 0.1,
        },
        "val": {
            "val_1": {
                "split": split,
                "max_tokens": 20,
                "panel_selection": "random",
                "panel_selection_mixed_prob": 0.5,
                "panel_filter_regex": ".*",
                "panel_size_min": 10,
                "panel_size_max": 10,
            }
        },
        "test": {
            "split": split,
            "max_tokens": 20,
        },
    }

    dataloader_kwargs = {
        "train": {
            "within_group_sampling": "dataset",
            "batch_size": 4,
            "shuffle": True,
            "drop_last": True,
            "num_samples": None,
            "num_workers": 2,
            "pin_memory": True,
        },
        "val": {
            "val_1": {
                "within_group_sampling": ["dataset", "tissue"] if use_stored_adata else "dataset",
                "batch_size": 4,
                "shuffle": True,
                "drop_last": True,
                "num_workers": 1,
                "pin_memory": False,
                "num_samples": 10,
            }
        },
        "test": {
            "batch_size": 4,
            "shuffle": False,
            "drop_last": False,
            "num_workers": 0,
        },
    }

    # Initialize AnnDataModule
    datamodule = AnnDataModule(
        panels_path=str(panels_dir),
        tokenizer=tokenizer,
        obs_keys=obs_keys,
        precomp_embs_key=None,
        normalization="raw",
        gene_sampling_strategy="top-nonzero",
        dataset_kwargs=dataset_kwargs,
        dataloader_kwargs=dataloader_kwargs,
        val_loader_names=dataloader_kwargs["val"].keys(),
    )

    # Test train dataloader
    train_loader = datamodule.train_dataloader()
    assert train_loader is not None

    # Iterate through train loader
    train_batches = []
    for batch_idx, batch in enumerate(train_loader):
        # Move batch to device
        batch = {key: value.to(device) if isinstance(value, torch.Tensor) else value for key, value in batch.items()}

        # Verify batch structure
        assert "tokens_1" in batch
        assert "values_1" in batch
        assert "tokens_2" in batch
        assert "values_2" in batch
        assert "panel_1" in batch
        assert "panel_2" in batch

        # Verify batch shapes
        batch_size = batch["tokens_1"].shape[0]
        assert batch_size <= 4  # Max batch size
        assert batch["values_1"].shape == batch["tokens_1"].shape
        assert batch["values_2"].shape == batch["tokens_2"].shape

        # Verify tensors are on correct device
        assert batch["tokens_1"].device.type == device.type
        assert batch["values_1"].device.type == device.type

        train_batches.append(batch)

        # Only test first 2 batches to keep test fast
        if batch_idx >= 1:
            break

    assert len(train_batches) > 0, "No train batches generated"

    # Test val dataloader
    val_loaders = datamodule.val_dataloader()
    assert val_loaders is not None
    assert isinstance(val_loaders, list)
    assert len(val_loaders) > 0, "No validation dataloaders generated"

    # Iterate through each validation dataloader
    val_batches = []
    for val_loader_idx, val_loader in enumerate(val_loaders):
        assert val_loader is not None

        # Iterate through validation loader
        for batch_idx, batch in enumerate(val_loader):
            # Move batch to device
            batch = {
                key: value.to(device) if isinstance(value, torch.Tensor) else value for key, value in batch.items()
            }

            # Verify batch structure (val loader uses split_input=True, similar to train)
            assert "tokens_1" in batch
            assert "values_1" in batch
            assert "tokens_2" in batch
            assert "values_2" in batch
            assert "panel_1" in batch
            assert "panel_2" in batch

            # Verify batch shapes
            batch_size = batch["tokens_1"].shape[0]
            assert batch_size <= 4  # Max batch size
            assert batch["values_1"].shape == batch["tokens_1"].shape
            assert batch["values_2"].shape == batch["tokens_2"].shape

            # Verify tensors are on correct device
            assert batch["tokens_1"].device.type == device.type
            assert batch["values_1"].device.type == device.type
            assert batch["tokens_2"].device.type == device.type
            assert batch["values_2"].device.type == device.type

            val_batches.append(batch)

            # Only test first 2 batches to keep test fast
            if batch_idx >= 1:
                break

    assert len(val_batches) > 0, "No validation batches generated"

    # Test test dataloader
    test_loader = datamodule.test_dataloader()
    assert test_loader is not None

    # Iterate through test loader
    test_batches = []
    for batch_idx, batch in enumerate(test_loader):
        # Move batch to device
        batch = {key: value.to(device) if isinstance(value, torch.Tensor) else value for key, value in batch.items()}

        # Verify batch structure (test loader doesn't split input)
        assert "tokens" in batch
        assert "values" in batch

        # Verify batch shapes
        batch_size = batch["tokens"].shape[0]
        assert batch_size <= 4  # Max batch size
        assert batch["values"].shape == batch["tokens"].shape

        # Verify tensors are on correct device
        assert batch["tokens"].device.type == device.type
        assert batch["values"].device.type == device.type

        test_batches.append(batch)

        # Only test first 2 batches to keep test fast
        if batch_idx >= 1:
            break

    assert len(test_batches) > 0, "No test batches generated"


def test_train_integration(train_config):
    """Integration test for train.py training pipeline

    Tests that the train() function can:
    - Load configuration and set up paths
    - Create datamodule with AnnData files
    - Initialize model and trainer
    - Run training for a few steps
    - Complete without errors
    """
    from contextlib import nullcontext
    from unittest.mock import MagicMock, patch

    from concept.train import train

    strategy_patch = nullcontext()
    if not torch.cuda.is_available():
        train_config.model.training.accelerator = "auto"
        strategy_patch = patch("concept.train.DDPStrategy", return_value="auto")

    # Mock wandb logger to avoid needing real credentials
    mock_logger = MagicMock()
    mock_logger.experiment = MagicMock()
    mock_logger.experiment.id = "test_run_id"
    mock_logger.experiment.config = MagicMock()

    # Mock rank_zero_only to always return 0 (single process)
    with strategy_patch:
        with patch("concept.train.rank_zero_only.rank", 0):
            with patch("concept.train.WandbLogger", return_value=mock_logger):
                # Run training
                train(train_config)


def test_train_fabric_integration(train_config):
    """Integration test for train_fabric.py FabricTrainer pipeline

    Tests that FabricTrainer can:
    - Load configuration and set up Fabric
    - Create datamodule with AnnData files
    - Initialize model and optimizer
    - Run training for a few steps
    - Complete without errors
    """
    from contextlib import nullcontext
    from unittest.mock import patch

    from concept.train_fabric import FabricTrainer

    strategy_patch = nullcontext()
    if not torch.cuda.is_available():
        train_config.model.training.accelerator = "auto"
        strategy_patch = patch("concept.train_fabric.DDPStrategy", return_value="auto")

    # train_config has wandb.enabled=False so no WandbLogger mock needed
    with strategy_patch:
        trainer = FabricTrainer(train_config)
        trainer.fit()


if __name__ == "__main__":
    pytest.main([__file__])
