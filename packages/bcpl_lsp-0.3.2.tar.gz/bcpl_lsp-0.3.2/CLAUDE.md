# BCPL LSP

Language Server Protocol implementation for Martin Richards' canonical BCPL.

## Build & Run

```bash
uv run bcpl-lsp --stdio          # Launch LSP server
.venv/bin/python -m pytest        # Run tests (uv run pytest hits system Python)
.venv/bin/python -m ruff check src/ tests/  # Lint
```

## Architecture

- `src/bcpl_lsp/parser/` — Lexer and recursive descent parser producing AST
- `src/bcpl_lsp/analysis/` — Symbol table, name resolution, diagnostics
- `src/bcpl_lsp/features/` — LSP feature handlers (completion, definition, etc.)
- `src/bcpl_lsp/workspace/` — Document state management, GET resolution
- `src/bcpl_lsp/server.py` — Main pygls server entry point

## Code Editing

When Serena MCP is available, use its symbolic tools for reading and editing code instead of reading entire files. Use `get_symbols_overview`, `find_symbol`, `replace_symbol_body`, `insert_after_symbol` etc. for precise, token-efficient operations.
- **Verify after `insert_after_symbol`** — it can corrupt surrounding code (e.g. inserting inside a dict literal). Always read the affected region after Serena insertions.

## BCPL Dialect

Targets Martin Richards' canonical BCPL with uppercase keywords (LET, IF, THEN, etc.).
- Header file extensions: `.b` (standard), `.h` (Cintcode system headers), `.bcpl` (rare), or extensionless (TRIPOS/PDP-11)
- `g/` directories contain system headers — each BCPL system (Cintcode, TRIPOS, etc.) has its own `g/`
- Block comments `/* ... */` do NOT nest (like C, unlike OCaml)
- `$( ... $)` are compound commands, NOT scope boundaries
- `/*<TAG ... /*TAG>*/` is a manual conditional compilation convention (not a language feature)
- Dots are valid in identifiers: `hash.table.size`, `t.link`
- `\=` is "not equal" operator
- `!` is vector indexing operator (not logical NOT)

## Testing

- Extension build: `cd editors/vscode && node esbuild.js` (must run from that directory)
- JS syntax check: `node -p "new (require('vm').Script)(require('fs').readFileSync('file.js','utf8'))"` (don't use `node -c $(cat)` — `$()` in template literals breaks bash)
- Test BCPL codebases at `/home/paul/projects/tripos/` (TRIPOS) for real-world validation
- Also test against `/home/paul/projects/BCPL/bcpl-81/` (Cintcode system with `.h` headers)
- `SimpleGetResolver` mock exists in 5 test files — update all when adding methods to `GetResolver`
- Quick parse check: `uv run python -c "from bcpl_lsp.workspace.indexer import WorkspaceIndex; ..."`
- Token class fields: `type`, `text`, `line`, `column`, `offset` (not `col` or `value`)
- `WorkspaceIndex` API: `ensure_parsed()`, `get_state()` (not `get_file_state()`)
