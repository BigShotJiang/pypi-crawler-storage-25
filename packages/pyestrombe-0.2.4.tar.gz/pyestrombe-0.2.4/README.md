# pyestrombe

Quick tool to show practical code in the terminal.

---

## install

```bash
pip install pyestrombe
```

---

## use

List everything available:

```bash
pyestrombe list
```

Print a snippet by **name** (the command is the filename without extension, compared case-insensitively):

```bash
pyestrombe editdistance
pyestrombe jaccard
pyestrombe pagerank
pyestrombe preprocessing
pyestrombe logicalbitwise
pyestrombe ngra
pyestrombe prac9
pyestrombe prac91
pyestrombe xmlcsv
```

If you still use numbered `m01.py`, `m02.py`, … under `modules/`, you can also run:

```bash
pyestrombe 1
pyestrombe 2
```

---

## structure

Snippets live as text files under `pyinspect_cli/modules/`, for example:

```
modules/
  editdistance.txt
  logicalbitwise.txt
  ngra.txt
  jaccard.txt
  pagerank.txt
  prac9.txt
  prac91.txt
  preprocessing.txt
  xmlcsv.txt
```

Add or rename `.txt` / `.text` files here; run `pyestrombe list` to see the current names.

---

## notes

* Made for exams (fast access)

---

done 👍
