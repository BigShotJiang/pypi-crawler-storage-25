# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.1.3] - 2026-05-10

### Fixed
- UI: Missing `api` variable definition causing `ReferenceError`.
- UI: Missing `function duration(a, b)` declaration causing `Illegal return statement`.
- UI: Status badges showing function source `() => t('statusCompleted')` instead of translated text.

## [0.1.1] - 2026-05-09

### Changed
- Improved README with correct install command, badges, `submit`, `ctx.log`/`ctx.flush` examples, lifespan and engine integration sections.

### Added
- `py.typed` marker for PEP 561 compliance.
- `LICENSE` (MIT).



### Added
- Linear async pipelines with `@step(retries, timeout)` decorator.
- Postgres persistence via SQLAlchemy 2 async (SQLite supported for testing).
- Automatic table creation on startup.
- In-process execution with `InProcessExecutor`.
- Pipeline controls: `start`, `submit`, `resume`, `retry_failed`, `restart_from_step`, `cancel`.
- `PipelineContext` with `get`, `set`, `flush`, `log`.
- FastAPI REST API and built-in dependency-free HTML developer UI.
- Structured step logs stored in `step_logs` table.
- Per-step `CancelScope` for immediate cancellation.
