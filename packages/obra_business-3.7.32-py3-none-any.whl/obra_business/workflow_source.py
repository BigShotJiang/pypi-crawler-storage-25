"""Canonical workflow-source helpers for business-domain compatibility."""

from __future__ import annotations

import json
from collections.abc import Mapping
from dataclasses import asdict
from pathlib import Path
from typing import Any

from obra.domains.business import BusinessDomain
from obra.workflow.artifact_model import WorkflowArtifactRecord
from obra.workflow.lifecycle import apply_workflow_lifecycle_projection
from obra.workflow.quality_loop import (
    collect_stage_quality_loop_issues,
    project_stage_quality_loop,
)
from obra.workflow.template_assets import (
    build_primary_stage_instruction_binding,
    normalize_template_bindings,
    serialize_template_bindings,
)

from obra_business.schemas.workflow import WorkflowDefinition

BUSINESS_DOMAIN_ID = "business"
CANONICAL_WORKFLOW_SOURCE_DIRNAME = ".obra-biz"
CANONICAL_WORKFLOW_SOURCE_FILENAME = "canonical-workflow-source.json"


def build_business_baseline_workflow_ref(
    workflow: WorkflowDefinition,
    *,
    workflow_dir: Path | None = None,
    provenance: str = "supplied",
    mission: str | None = None,
    source_kind: str = "definition_yaml",
) -> dict[str, Any]:
    """Build canonical baseline-workflow metadata for generalized derivation."""
    projected_definition = _project_business_workflow_definition(
        {
            "workflow_id": workflow.workflow_id,
            "title": workflow.title,
            "description": workflow.description,
            "version": workflow.version,
            "stages": [
                {
                    "id": stage.id,
                    "title": stage.name,
                    "purpose": stage.description,
                    "depends_on": list(stage.depends_on),
                    "quality_loop": dict(stage.quality_loop) if stage.quality_loop else None,
                    "inputs": _stage_inputs(workflow, stage.id, stage.depends_on),
                    "outputs": (
                        [workflow.output_document.name]
                        if stage.id == workflow.stages[-1].id
                        else [f"{stage.id}_output"]
                    ),
                    "rules": [
                        rule.id for rule in workflow.quality_rules if stage.id in rule.applies_to
                    ],
                    "quality_gates": [
                        rule.name for rule in workflow.quality_rules if stage.id in rule.applies_to
                    ],
                    "template_asset_bindings": (
                        [
                            _build_stage_instruction_binding(
                                stage_id=stage.id,
                                stage_title=stage.name,
                                workflow_version=workflow.version,
                            )
                        ]
                        if workflow_dir is not None
                        else []
                    ),
                }
                for stage in workflow.stages
            ],
        }
    )
    return {
        "target_artifact_type": "workflow_baseline",
        "target_artifact_id": workflow.workflow_id,
        "target_version_selector": workflow.version,
        "relationship_type": "derived_from",
        "metadata": {
            "domain_id": BUSINESS_DOMAIN_ID,
            "workflow_id": workflow.workflow_id,
            "title": workflow.title,
            "description": workflow.description,
            "version": workflow.version,
            "source_kind": source_kind,
            "baseline_provenance": provenance,
            "mission": mission or workflow.title,
            "stage_ids": [stage.id for stage in workflow.stages],
            "stages": list(projected_definition.get("stages", [])),
            "template_asset_bindings": [
                binding
                for stage in workflow.stages
                for binding in (
                    [
                        _build_stage_instruction_binding(
                            stage_id=stage.id,
                            stage_title=stage.name,
                            workflow_version=workflow.version,
                        )
                    ]
                    if workflow_dir is not None
                    else []
                )
            ],
            "rules": [rule.model_dump(mode="json") for rule in workflow.quality_rules],
            "rule_ids": [rule.id for rule in workflow.quality_rules],
            "quality_gates": [rule.name for rule in workflow.quality_rules],
            "quality_dimensions": list(projected_definition.get("quality_dimensions", [])),
            "lifecycle_capabilities": list(
                projected_definition.get("lifecycle_capabilities", [])
            ),
            "lifecycle": dict(projected_definition.get("lifecycle", {})),
            "input_document": workflow.input_document.model_dump(mode="json"),
            "output_document": workflow.output_document.model_dump(mode="json"),
        },
    }


def build_business_workflow_source_summary(
    *,
    workflow_definition: Mapping[str, Any],
    source_kind: str,
    source_provenance: str,
    source_definition: str,
    workflow_version: str | None = None,
    source_artifact: Mapping[str, Any] | None = None,
    workflow_derivation_request: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build additive compiled-plan metadata describing the canonical workflow source."""
    workflow_definition = _project_business_workflow_definition(workflow_definition)
    title = str(workflow_definition.get("title", "") or "").strip()
    description = str(workflow_definition.get("description", "") or "").strip()
    stages = workflow_definition.get("stages", [])
    stage_list = [stage for stage in stages if isinstance(stage, Mapping)]
    stage_names = [
        str(stage.get("title") or stage.get("name") or stage.get("id") or "").strip()
        for stage in stage_list
        if str(stage.get("title") or stage.get("name") or stage.get("id") or "").strip()
    ]
    resolved_workflow_version = (
        str(workflow_version or workflow_definition.get("version") or "").strip() or None
    )
    bindings_by_stage = normalize_template_bindings(
        workflow_definition,
        workflow_version=resolved_workflow_version,
    )
    if not any(bindings_by_stage.values()) and resolved_workflow_version is not None:
        generated_stage_bindings = _generated_stage_bindings(
            stage_list,
            workflow_version=resolved_workflow_version,
        )
        if generated_stage_bindings:
            bindings_by_stage = generated_stage_bindings
    first_inputs = _as_string_list(stage_list[0].get("inputs")) if stage_list else []
    last_outputs = _as_string_list(stage_list[-1].get("outputs")) if stage_list else []
    effective_domain_id = _resolve_effective_domain_id(
        workflow_definition=workflow_definition,
        source_artifact=source_artifact,
        workflow_derivation_request=workflow_derivation_request,
    )
    return {
        "workflow_source_kind": source_kind,
        "workflow_source_provenance": source_provenance,
        "workflow_source_summary": {
            "domain_id": effective_domain_id,
            "title": title,
            "description": description,
            "stage_titles": stage_names,
            "input_name": first_inputs[0] if first_inputs else "business workflow input",
            "input_format": "structured",
            "input_description": (
                "Business workflow input derived from the canonical workflow source."
            ),
            "input_required_fields": first_inputs,
            "output_name": last_outputs[0] if last_outputs else "business workflow output",
            "output_format": "structured",
            "output_description": (
                "Business workflow output derived from the canonical workflow source."
            ),
            "output_deliverables": last_outputs,
            "quality_dimensions": list(workflow_definition.get("quality_dimensions", [])),
            "lifecycle_capabilities": list(
                workflow_definition.get("lifecycle_capabilities", [])
            ),
            "lifecycle": dict(workflow_definition.get("lifecycle", {})),
            "template_asset_bindings": serialize_template_bindings(bindings_by_stage),
        },
        "workflow_source_artifact": dict(source_artifact or {}),
        "workflow_derivation_request": dict(workflow_derivation_request or {}),
        "source_definition": source_definition,
    }


def build_business_workflow_source_from_artifact(
    workflow_artifact: WorkflowArtifactRecord | Mapping[str, Any],
) -> dict[str, Any]:
    """Normalize an accepted W2 artifact into compile-ready business source metadata."""
    artifact = (
        _workflow_artifact_payload(workflow_artifact)
        if isinstance(workflow_artifact, WorkflowArtifactRecord)
        else dict(workflow_artifact)
    )
    metadata = artifact.get("metadata", {})
    if not isinstance(metadata, Mapping):
        metadata = {}
    workflow_definition = metadata.get("workflow_definition", {})
    if not isinstance(workflow_definition, Mapping):
        msg = "Workflow artifact metadata.workflow_definition is required for compilation"
        raise ValueError(msg)
    workflow_definition = _project_business_workflow_definition(workflow_definition)

    baseline_workflow_ref = (
        artifact.get("references", [{}])[0]
        if isinstance(artifact.get("references"), list) and artifact.get("references")
        else None
    )
    workflow_derivation_request = {
        "mission": str(workflow_definition.get("title") or artifact.get("title") or "").strip(),
        "domain_id": str(artifact.get("domain_id") or BUSINESS_DOMAIN_ID),
    }
    if isinstance(baseline_workflow_ref, Mapping) and baseline_workflow_ref:
        workflow_derivation_request["baseline_workflow_ref"] = dict(baseline_workflow_ref)

    source_artifact = {
        "artifact_type": artifact.get("artifact_type", "workflow_derived"),
        "artifact_id": artifact.get("artifact_id"),
        "version": artifact.get("version"),
        "domain_id": artifact.get("domain_id", BUSINESS_DOMAIN_ID),
        "title": artifact.get("title"),
        "description": artifact.get("description"),
        "synthesis_mode": workflow_definition.get("source_mode"),
        "quality_dimensions": list(workflow_definition.get("quality_dimensions", [])),
        "lifecycle_capabilities": list(
            workflow_definition.get("lifecycle_capabilities", [])
        ),
    }
    return {
        "workflow_definition": dict(workflow_definition),
        "workflow_source_kind": "workflow_derived",
        "workflow_source_provenance": str(
            workflow_definition.get("source_mode") or "synthesized"
        ),
        "workflow_source_artifact": source_artifact,
        "workflow_derivation_request": workflow_derivation_request,
        "source_definition": f"workflow_derived:{artifact.get('artifact_id', 'unknown')}",
    }


def build_business_workflow_source_payload(
    *,
    workflow_definition: Mapping[str, Any],
    source_kind: str,
    source_provenance: str,
    source_definition: str,
    workflow_version: str | None = None,
    source_artifact: Mapping[str, Any] | None = None,
    workflow_derivation_request: Mapping[str, Any] | None = None,
) -> dict[str, Any]:
    """Build the canonical workflow-source payload persisted for runtime execution."""
    normalized_definition = _project_business_workflow_definition(workflow_definition)
    payload = build_business_workflow_source_summary(
        workflow_definition=normalized_definition,
        source_kind=source_kind,
        source_provenance=source_provenance,
        source_definition=source_definition,
        workflow_version=workflow_version,
        source_artifact=source_artifact,
        workflow_derivation_request=workflow_derivation_request,
    )
    payload["workflow_definition"] = normalized_definition
    return payload


def canonical_workflow_source_path(workflow_dir: Path) -> Path:
    """Return the canonical workflow-source artifact path for a workflow directory."""
    return workflow_dir / CANONICAL_WORKFLOW_SOURCE_DIRNAME / CANONICAL_WORKFLOW_SOURCE_FILENAME


def write_business_workflow_source_payload(
    workflow_dir: Path,
    payload: Mapping[str, Any],
) -> Path:
    """Persist the canonical workflow-source payload used by delegated execution."""
    path = canonical_workflow_source_path(workflow_dir)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(dict(payload), indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def load_business_workflow_source_payload(workflow_dir: Path) -> dict[str, Any] | None:
    """Load the persisted canonical workflow-source payload when present."""
    path = canonical_workflow_source_path(workflow_dir)
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return None
    return payload if isinstance(payload, dict) else None


def _as_string_list(value: Any) -> list[str]:
    if isinstance(value, list):
        return [str(item).strip() for item in value if str(item).strip()]
    if isinstance(value, str) and value.strip():
        return [value.strip()]
    return []


def _resolve_effective_domain_id(
    *,
    workflow_definition: Mapping[str, Any] | None,
    source_artifact: Mapping[str, Any] | None,
    workflow_derivation_request: Mapping[str, Any] | None,
) -> str:
    # Studio compiles non-business-domain workflows through this same path. The
    # compiled WORKFLOW_PLAN.json is later read back by the gateway plan-context
    # loader; a hardcoded BUSINESS_DOMAIN_ID would manufacture a domain conflict
    # against software/etc launches.
    for candidate in (workflow_definition, source_artifact, workflow_derivation_request):
        if not isinstance(candidate, Mapping):
            continue
        raw = candidate.get("domain_id")
        if isinstance(raw, str) and raw.strip():
            return raw.strip()
    return BUSINESS_DOMAIN_ID


def _normalize_workflow_stage_quality_loops(
    workflow_definition: Mapping[str, Any],
) -> dict[str, Any]:
    """Reject legacy stage loop shorthand and preserve canonical quality_loop only."""
    normalized = dict(workflow_definition)
    raw_stages = normalized.get("stages")
    if not isinstance(raw_stages, list):
        return normalized

    stage_list: list[dict[str, Any]] = []
    for stage in raw_stages:
        if not isinstance(stage, Mapping):
            continue
        stage_dict = dict(stage)
        issues = collect_stage_quality_loop_issues(stage_dict)
        if issues:
            issue_message = str(
                issues[0].get("message")
                or issues[0].get("code")
                or "invalid stage quality_loop"
            )
            stage_id = str(stage_dict.get("id") or stage_dict.get("name") or "<unknown>")
            raise ValueError(f"Stage '{stage_id}': {issue_message}")
        stage_list.append(project_stage_quality_loop(stage_dict))

    normalized["stages"] = stage_list
    return normalized


def _project_business_workflow_definition(
    workflow_definition: Mapping[str, Any],
) -> dict[str, Any]:
    normalized_definition = _normalize_workflow_stage_quality_loops(workflow_definition)
    domain = BusinessDomain()
    domain_quality_dimensions = [
        {
            "id": dimension.id,
            "display_name": dimension.display_name,
            "description": dimension.description,
            "default_enabled": dimension.default_enabled,
        }
        for dimension in domain.get_quality_dimensions()
    ]
    return apply_workflow_lifecycle_projection(
        dict(normalized_definition),
        domain_lifecycle_policy=domain.get_lifecycle_policy(),
        domain_quality_dimensions=domain_quality_dimensions,
    )


def _stage_inputs(
    workflow: WorkflowDefinition,
    stage_id: str,
    depends_on: list[str],
) -> list[str]:
    if stage_id == "S0":
        return [workflow.input_document.name]
    if depends_on:
        return [f"{dependency}_output" for dependency in depends_on]
    return ["prior_stage_output"]


def _slugify(value: str) -> str:
    return "".join(char if char.isalnum() else "_" for char in value.lower()).strip("_")


def _build_stage_instruction_binding(
    *,
    stage_id: str,
    stage_title: str,
    workflow_version: str,
) -> dict[str, Any]:
    binding = build_primary_stage_instruction_binding(
        stage_id=stage_id,
        stage_title=stage_title,
        workflow_version=workflow_version,
        path_hint=str(Path("stages") / f"{stage_id}_{_slugify(stage_title)}.md"),
    )
    binding.adoption_metadata = {
        "source": "generated_business_stage_markdown",
        "requires_approval": False,
    }
    binding.materialization_metadata = {
        "path": str(Path("stages") / f"{stage_id}_{_slugify(stage_title)}.md"),
        "content_format": "markdown",
    }
    return binding.to_dict()


def _generated_stage_bindings(
    stages: list[Mapping[str, Any]],
    *,
    workflow_version: str,
) -> dict[str, list[Any]]:
    bindings: dict[str, list[dict[str, Any]]] = {}
    for stage in stages:
        stage_id = str(stage.get("id") or "").strip()
        stage_title = str(stage.get("title") or stage.get("name") or stage_id).strip()
        if not stage_id or not stage_title:
            continue
        bindings[stage_id] = [
            _build_stage_instruction_binding(
                stage_id=stage_id,
                stage_title=stage_title,
                workflow_version=workflow_version,
            )
        ]
    return normalize_template_bindings(
        {
            "stages": [
                {
                    "id": stage_id,
                    "template_asset_bindings": stage_bindings,
                }
                for stage_id, stage_bindings in bindings.items()
            ]
        },
        workflow_version=workflow_version,
    )


def _workflow_artifact_payload(workflow_artifact: WorkflowArtifactRecord) -> dict[str, Any]:
    return {
        "artifact_type": (
            workflow_artifact.artifact_type.value
            if workflow_artifact.artifact_type is not None
            else None
        ),
        "artifact_id": workflow_artifact.artifact_id,
        "version": workflow_artifact.version,
        "domain_id": workflow_artifact.domain_id,
        "title": workflow_artifact.title,
        "description": workflow_artifact.description,
        "references": [asdict(reference) for reference in workflow_artifact.references],
        "metadata": dict(workflow_artifact.metadata),
    }


__all__ = [
    "BUSINESS_DOMAIN_ID",
    "CANONICAL_WORKFLOW_SOURCE_DIRNAME",
    "CANONICAL_WORKFLOW_SOURCE_FILENAME",
    "build_business_workflow_source_payload",
    "build_business_baseline_workflow_ref",
    "build_business_workflow_source_from_artifact",
    "build_business_workflow_source_summary",
    "canonical_workflow_source_path",
    "load_business_workflow_source_payload",
    "write_business_workflow_source_payload",
]
