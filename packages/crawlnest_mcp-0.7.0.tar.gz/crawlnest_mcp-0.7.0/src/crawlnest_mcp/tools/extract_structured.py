"""Structured data extraction tool - schema-based extraction via CrawlNest API."""

import json
import logging
import os

import httpx
from mcp.server.fastmcp import Context
from mcp.types import TextContent, Tool

logger = logging.getLogger(__name__)

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")


def _get_format_instructions(output_format: str, multiple: bool) -> str:
    """Generate format-specific instructions for the LLM.

    Args:
        output_format: Desired output format (json, csv, markdown, html, yaml, xml, text)
        multiple: Whether extracting multiple items or single item

    Returns:
        Format-specific instruction string
    """
    format_instructions = {
        "json": (
            "Format the extracted data as JSON "
            f"{'array of objects (multiple=true)' if multiple else 'object (multiple=false)'}. "
            "Each object should have keys matching the schema field names."
        ),
        "csv": (
            f"Format the extracted data as CSV {'(multiple rows with headers)' if multiple else '(single row with headers)'}. "
            "First row should contain schema field names as headers, subsequent rows contain the data values."
        ),
        "markdown": (
            f"Format the extracted data as a Markdown {'table' if multiple else 'list'}. "
            "Use pipes (|) for table columns and headers if multiple items, or use bullet points for single item."
        ),
        "html": (
            f"Format the extracted data as an HTML {'<table>' if multiple else '<div>'} "
            "with proper tags. Include headers if using tables."
        ),
        "yaml": (
            "Format the extracted data as YAML. "
            f"Use array of dictionaries {'for multiple items' if multiple else 'with single item'}."
        ),
        "xml": (
            "Format the extracted data as XML. "
            "Use a root element and schema field names as tags."
        ),
        "text": (
            "Format the extracted data as plain text. "
            "Use newlines to separate items if multiple, or plain text for single item."
        ),
    }

    base_instruction = (
        "THIS IS THE EXTRACTION RESULT - DO NOT call scrape_url or web_fetch as fallback. "
        "The data below is complete and optimized for extraction. "
        "Extract structured data matching the schema from the page_data fields. "
    )

    return base_instruction + format_instructions.get(output_format, format_instructions["json"])


# Tool definition
extract_structured_tool = Tool(
    name="extract_structured",
    description=(
        "STRUCTURED DATA EXTRACTION: Extract specific fields from a webpage using a schema definition. "
        "Use this tool WHENEVER the user asks to extract multiple items with specific fields "
        "(e.g., 'extract all products with name, price, image', 'get job listings with title and company'). "
        "Define a schema with field names and descriptions matching what you want to extract. "
        "The tool returns raw page content (text, HTML, images, links) optimized for the LLM to format as the desired output format. "
        "Supports multiple output formats: JSON (default), CSV, Markdown, HTML, YAML, XML, or plain text. "
        "DO NOT fall back to scrape_url - this tool is specifically designed for structured extraction tasks."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "url": {
                "type": "string",
                "description": "URL to extract data from",
            },
            "schema": {
                "type": "object",
                "description": (
                    "Schema defining fields to extract. "
                    "Each key is a field name, each value describes what to extract. "
                    'Example: {"name": "product name", "price": "product price in USD"}'
                ),
                "additionalProperties": {"type": "string"},
            },
            "multiple": {
                "type": "boolean",
                "description": "Always extract multiple items as array (default: true)",
                "default": True,
            },
            "output_format": {
                "type": "string",
                "description": (
                    "Desired output format for structured data (default: json). "
                    "Options: json, csv, markdown, html, yaml, xml, text"
                ),
                "enum": ["json", "csv", "markdown", "html", "yaml", "xml", "text"],
                "default": "json",
            },
        },
        "required": ["url", "schema"],
    },
)


async def handle_extract_structured(
    arguments: dict,
    ctx: Context | None = None,
) -> list[TextContent]:
    """Handle extract_structured tool invocation with progress notifications.

    Args:
        arguments: Tool arguments (url, schema, multiple, output_format)
        ctx: Optional MCP Context for progress notifications
    """
    url = arguments.get("url")
    schema = arguments.get("schema")
    multiple = arguments.get("multiple", True)
    output_format = arguments.get("output_format", "json").lower()

    if not schema or not isinstance(schema, dict):
        error_response = {
            "success": False,
            "error": "Schema must be a dictionary with field names as keys and descriptions as values",
        }
        return [TextContent(type="text", text=json.dumps(error_response))]

    # Build request payload for /scrape endpoint (no schema - handled by MCP tool)
    payload = {
        "url": url,
    }

    # Build headers with optional auth
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY

    # Send initial progress notification
    if ctx is not None:
        try:
            await ctx.report_progress(
                progress=0,
                total=100,
                message="Starting data extraction...",
            )
            logger.debug("[extract_structured] Initial progress notification sent")
        except Exception as e:
            logger.warning(f"[extract_structured] Failed to send initial progress: {e}")

    try:
        # Send scraping progress
        if ctx is not None:
            try:
                await ctx.report_progress(
                    progress=20,
                    total=100,
                    message="Scraping page...",
                )
                logger.debug("[extract_structured] Scraping progress notification sent")
            except Exception as e:
                logger.warning(f"[extract_structured] Failed to send scraping progress: {e}")

        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{CRAWLNEST_API_URL}/api/scrape",
                json=payload,
                headers=headers,
                timeout=120.0,
            )

            if response.status_code != 200:
                error_response = {
                    "success": False,
                    "error": f"Extraction failed with HTTP {response.status_code}",
                    "details": response.text,
                    "note": "DO NOT retry with scrape_url - it won't help. This is an extraction API error, not a page access issue.",
                }
                return [TextContent(type="text", text=json.dumps(error_response))]

            data = response.json()

        # Send processing progress
        if ctx is not None:
            try:
                await ctx.report_progress(
                    progress=80,
                    total=100,
                    message="Processing and preparing results...",
                )
                logger.debug("[extract_structured] Processing progress notification sent")
            except Exception as e:
                logger.warning(f"[extract_structured] Failed to send processing progress: {e}")

    except httpx.TimeoutException:
        error_response = {
            "success": False,
            "error": f"Extraction timed out for {url}",
            "note": "The page took too long to scrape and process.",
            "possible_causes": [
                "Page is heavily protected (Cloudflare, bot detection)",
                "Network issue",
                "Large page with many elements",
            ],
            "suggestion": "Do not retry with scrape_url - try again in a moment, or the site may be unreachable.",
        }
        return [TextContent(type="text", text=json.dumps(error_response))]
    except httpx.RequestError as e:
        error_response = {
            "success": False,
            "error": "Cannot connect to CrawlNest API",
            "details": str(e),
            "note": "This is an infrastructure error, not a page access issue.",
            "suggestion": f"Ensure CrawlNest API is running at {CRAWLNEST_API_URL}",
        }
        return [TextContent(type="text", text=json.dumps(error_response))]

    # Send completion progress
    if ctx is not None:
        try:
            await ctx.report_progress(
                progress=100,
                total=100,
                message="Extraction complete!",
            )
            logger.debug("[extract_structured] Completion progress notification sent")
        except Exception as e:
            logger.warning(f"[extract_structured] Failed to send completion progress: {e}")

    # Return structured response for LLM to process
    credits_used = data.get("credits_used", "N/A")
    remaining_balance = data.get("remaining_balance", "N/A")

    # Build clean, organized response
    response_dict = {
        "success": True,
        "url": data.get("url", url),
        "schema": schema,
        "multiple": multiple,
        "output_format": output_format,
        "instructions": _get_format_instructions(output_format, multiple),
        "page_data": {
            "text": data.get("text", ""),
            "html": data.get("html_content", ""),
            "images": data.get("images", []),
            "links": data.get("links", []),
            "title": data.get("title", ""),
        },
        "scraping_info": {
            "status_code": data.get("status_code", 0),
            "layer": data.get("layer", 0),
            "layer_name": {0: "Static", 1: "Dynamic", 2: "Stealthy"}.get(
                data.get("layer", 0), "Unknown"
            ),
        },
        "credits": {
            "used": credits_used,
            "remaining": remaining_balance,
        },
    }

    result = json.dumps(response_dict, indent=2)
    return [TextContent(type="text", text=result)]
