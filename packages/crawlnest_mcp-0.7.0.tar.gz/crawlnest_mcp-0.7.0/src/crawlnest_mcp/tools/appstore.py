import json
import logging
import os

import httpx
from mcp.types import TextContent

logger = logging.getLogger(__name__)

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")

APPSTORE_API_BASE = f"{CRAWLNEST_API_URL}/api/appstore"


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY
    return headers


def _error_response(error: str, details: str | None = None) -> list[TextContent]:
    resp: dict = {"success": False, "error": error}
    if details:
        resp["details"] = details
    return [TextContent(type="text", text=json.dumps(resp))]


async def _post(endpoint: str, payload: dict, timeout: float = 120.0) -> list[TextContent]:
    """POST to an App Store API endpoint and return the response."""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{APPSTORE_API_BASE}/{endpoint}",
                json=payload,
                headers=_headers(),
                timeout=timeout,
            )

            if response.status_code != 200:
                return _error_response(
                    f"App Store API returned HTTP {response.status_code}",
                    details=response.text,
                )

            data = response.json()
            return [TextContent(type="text", text=json.dumps({"success": True, **data}))]

    except httpx.TimeoutException:
        return _error_response("Request timed out")
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API", details=str(e))


# --- Tool handlers ---


async def handle_appstore_app(arguments: dict) -> list[TextContent]:
    """Fetch app details by track ID or bundle ID."""
    app_id = arguments.get("app_id")
    if not app_id:
        return _error_response("app_id is required")

    payload: dict = {"app_id": app_id}
    logger.info(f"[appstore_app] app_id: {app_id}")
    return await _post("app", payload)


async def handle_appstore_search(arguments: dict) -> list[TextContent]:
    """Search App Store apps by keyword."""
    query = arguments.get("query")
    if not query:
        return _error_response("query is required")

    payload: dict = {"query": query}
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]
    if arguments.get("country"):
        payload["country"] = arguments["country"]

    logger.info(f"[appstore_search] query: {query}")
    return await _post("search", payload)


async def handle_appstore_charts(arguments: dict) -> list[TextContent]:
    """Fetch top charts by genre and country."""
    payload: dict = {}
    if arguments.get("chart_type"):
        payload["chart_type"] = arguments["chart_type"]
    if arguments.get("genre"):
        payload["genre"] = arguments["genre"]
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]
    if arguments.get("country"):
        payload["country"] = arguments["country"]

    logger.info(f"[appstore_charts] chart_type: {payload.get('chart_type', 'top_free')}")
    return await _post("charts", payload)


async def handle_appstore_reviews(arguments: dict) -> list[TextContent]:
    """Fetch app reviews with pagination."""
    app_id = arguments.get("app_id")
    if not app_id:
        return _error_response("app_id is required")

    payload: dict = {"app_id": app_id}
    if arguments.get("sort"):
        payload["sort"] = arguments["sort"]
    if arguments.get("count") is not None:
        payload["count"] = arguments["count"]
    if arguments.get("offset") is not None:
        payload["offset"] = arguments["offset"]
    if arguments.get("country"):
        payload["country"] = arguments["country"]

    logger.info(f"[appstore_reviews] app_id: {app_id}")
    return await _post("reviews", payload)


async def handle_appstore_developer(arguments: dict) -> list[TextContent]:
    """Fetch a developer's published apps."""
    developer_id = arguments.get("developer_id")
    if not developer_id:
        return _error_response("developer_id is required")

    payload: dict = {"developer_id": developer_id}
    if arguments.get("country"):
        payload["country"] = arguments["country"]

    logger.info(f"[appstore_developer] developer_id: {developer_id}")
    return await _post("developer", payload)


async def handle_appstore_privacy(arguments: dict) -> list[TextContent]:
    """Fetch app privacy labels."""
    app_id = arguments.get("app_id")
    if not app_id:
        return _error_response("app_id is required")

    payload: dict = {"app_id": app_id}
    if arguments.get("country"):
        payload["country"] = arguments["country"]

    logger.info(f"[appstore_privacy] app_id: {app_id}")
    return await _post("privacy", payload)


async def handle_appstore_ratings(arguments: dict) -> list[TextContent]:
    """Fetch rating breakdown with 5-star histogram."""
    app_id = arguments.get("app_id")
    if not app_id:
        return _error_response("app_id is required")

    payload: dict = {"app_id": app_id}
    if arguments.get("country"):
        payload["country"] = arguments["country"]

    logger.info(f"[appstore_ratings] app_id: {app_id}")
    return await _post("ratings", payload)


async def handle_appstore_in_app_purchases(arguments: dict) -> list[TextContent]:
    """Fetch top in-app purchases for an app."""
    app_id = arguments.get("app_id")
    if not app_id:
        return _error_response("app_id is required")

    payload: dict = {"app_id": app_id}
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]
    if arguments.get("country"):
        payload["country"] = arguments["country"]

    logger.info(f"[appstore_in_app_purchases] app_id: {app_id}")
    return await _post("in-app-purchases", payload)


async def handle_appstore_bulk(arguments: dict) -> list[TextContent]:
    """Bulk app lookup by multiple track IDs."""
    app_ids = arguments.get("app_ids")
    if not app_ids:
        return _error_response("app_ids is required")

    payload: dict = {"app_ids": app_ids}
    if arguments.get("country"):
        payload["country"] = arguments["country"]

    logger.info(f"[appstore_bulk] {len(app_ids)} apps")
    return await _post("app/bulk", payload)
