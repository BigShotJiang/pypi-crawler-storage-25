"""Crawl website tool - multi-page scraping with progress notifications."""

import asyncio
import json
import logging
import os

import httpx
from mcp.server.fastmcp import Context
from mcp.types import TextContent, Tool

logger = logging.getLogger(__name__)

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")

# Tool definition
crawl_website_tool = Tool(
    name="crawl_website",
    description=(
        "Crawl an entire website or subsection and extract content from multiple pages. "
        "Uses sitemap.xml for efficient URL discovery when available, otherwise follows HTML links. "
        "Supports up to 50 pages with real-time progress tracking. "
        "Useful for scraping blogs, documentation sites, or entire website sections."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "url": {
                "type": "string",
                "description": "Starting URL to crawl (e.g., https://example.com/blog)",
            },
            "max_pages": {
                "type": "integer",
                "description": "Maximum number of pages to crawl (default: 10, max: 50)",
                "default": 10,
            },
            "same_domain": {
                "type": "boolean",
                "description": "Only crawl pages on the same domain (default: true)",
                "default": True,
            },
            "include_pattern": {
                "type": "string",
                "description": "Optional regex pattern - only crawl URLs matching this pattern",
            },
            "exclude_pattern": {
                "type": "string",
                "description": "Optional regex pattern - skip URLs matching this pattern",
            },
        },
        "required": ["url"],
    },
)


async def handle_crawl_website(arguments: dict, ctx: Context | None = None) -> list[TextContent]:
    """Handle crawl_website tool invocation with progress tracking.

    Submits crawl to queue and polls for progress with live updates.
    This prevents MCP timeouts by keeping connection active.
    """
    url = arguments.get("url")
    max_pages = arguments.get("max_pages", 10)
    same_domain = arguments.get("same_domain", True)
    include_pattern = arguments.get("include_pattern")
    exclude_pattern = arguments.get("exclude_pattern")

    # Validate max_pages
    if max_pages > 50:
        error_response = {
            "success": False,
            "error": "max_pages cannot exceed 50 (to prevent excessive resource usage)",
            "url": url,
        }
        return [TextContent(type="text", text=json.dumps(error_response))]

    # Build request payload (use_sitemap always true for hybrid approach)
    payload = {
        "url": url,
        "max_pages": max_pages,
        "same_domain": same_domain,
        "use_sitemap": True,  # Always enabled for hybrid sitemap-first approach
    }

    if include_pattern:
        payload["include_pattern"] = include_pattern
    if exclude_pattern:
        payload["exclude_pattern"] = exclude_pattern

    # Build headers with API key
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY

    try:
        # Submit crawl to queue
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{CRAWLNEST_API_URL}/api/crawl/queue",
                json=payload,
                headers=headers,
                timeout=30.0,  # Submit should be fast
            )

            if response.status_code != 200:
                error_response = {
                    "success": False,
                    "error": f"Failed to submit crawl with HTTP {response.status_code}",
                    "details": response.text,
                    "url": url,
                }
                return [TextContent(type="text", text=json.dumps(error_response))]

            data = response.json()
            job_id = data.get("batch_id")
            total_urls = data.get("total_urls", max_pages)

            if not job_id:
                error_response = {
                    "success": False,
                    "error": "No job ID returned from API",
                    "url": url,
                }
                return [TextContent(type="text", text=json.dumps(error_response))]

        # Poll for completion with progress notifications
        max_wait_time = 600  # 10 minutes max
        poll_interval = 5  # Poll every 5 seconds
        elapsed = 0

        logger.info(
            f"[crawl_website] Starting poll loop: ctx={ctx is not None}, max_wait={max_wait_time}s, poll_interval={poll_interval}s"
        )

        while elapsed < max_wait_time:
            await asyncio.sleep(poll_interval)
            elapsed += poll_interval

            # Check status
            async with httpx.AsyncClient() as client:
                try:
                    status_response = await client.get(
                        f"{CRAWLNEST_API_URL}/api/crawl/queue/{job_id}",
                        headers=headers,
                        timeout=10.0,
                    )

                    if status_response.status_code != 200:
                        logger.error(f"Status check failed: HTTP {status_response.status_code}")
                        error_response = {
                            "success": False,
                            "error": f"Error checking crawl status with HTTP {status_response.status_code}",
                            "job_id": job_id,
                        }
                        return [TextContent(type="text", text=json.dumps(error_response))]

                    status = status_response.json()

                except Exception as e:
                    logger.error(f"Error checking status: {e}")
                    continue

            # Log progress to logger (not stderr - it breaks MCP protocol!)
            progress_msg = (
                f"Crawled {status.get('completed', 0)}/{status.get('total_urls', total_urls)} pages"
            )
            logger.info(f"[crawl_website] Progress: {progress_msg}")

            # Send progress notification to Claude Desktop (if ctx available)
            if ctx is not None:
                try:
                    await ctx.report_progress(
                        progress=status.get("completed", 0),
                        total=status.get("total_urls", total_urls),
                        message=progress_msg,
                    )
                    logger.debug(f"[crawl_website] Progress notification sent: {progress_msg}")
                except Exception as e:
                    logger.warning(f"[crawl_website] Failed to send progress via ctx: {e}")
            else:
                logger.debug("[crawl_website] ctx is None - progress notifications unavailable")

            # Check if crawl completed
            if status.get("status") == "completed":
                result = format_crawl_result(status)
                return [TextContent(type="text", text=result)]
            elif status.get("status") == "failed":
                error_response = {
                    "success": False,
                    "error": "Crawl failed",
                    "errors": status.get("errors", ["Unknown error"]),
                    "job_id": job_id,
                }
                return [TextContent(type="text", text=json.dumps(error_response))]

        # If we get here, polling timed out - return partial results
        return [TextContent(type="text", text=format_partial_result(status, job_id, max_wait_time))]

    except httpx.TimeoutException:
        error_response = {
            "success": False,
            "error": "Request timed out while crawling",
            "url": url,
        }
        return [TextContent(type="text", text=json.dumps(error_response))]
    except httpx.RequestError as e:
        error_response = {
            "success": False,
            "error": "Failed to connect to CrawlNest API",
            "details": str(e),
            "url": url,
        }
        return [TextContent(type="text", text=json.dumps(error_response))]
    except Exception as e:
        error_response = {
            "success": False,
            "error": "Unexpected error during crawl",
            "details": str(e),
            "url": url,
        }
        return [TextContent(type="text", text=json.dumps(error_response))]


def format_partial_result(data: dict, job_id: str, elapsed_seconds: int) -> str:
    """Format partial crawl results as JSON when polling timeout occurs."""
    pages = data.get("pages", [])
    response = {
        "success": True,
        "status": "partial",
        "note": "Crawl is still processing",
        "job_id": job_id,
        "elapsed_seconds": elapsed_seconds,
        "pages_completed": len(pages),
        "total_urls": data.get("total_urls"),
        "pages": pages,
    }
    return json.dumps(response)


def format_crawl_result(data: dict) -> str:
    """Format crawl response as readable markdown."""
    starting_url = data.get("starting_url", "")
    pages_crawled = data.get("pages_crawled", 0)
    pages = data.get("pages", [])

    # Credits info
    total_credits_used = data.get("total_credits_used", "N/A")
    remaining_balance = data.get("remaining_balance", "N/A")

    # Errors
    errors = data.get("errors", [])

    lines = [
        "# Website Crawl Results",
        "",
        f"**Starting URL**: {starting_url}",
        f"**Pages crawled**: {pages_crawled}",
        f"**Total credits used**: {total_credits_used}",
        f"**Remaining balance**: {remaining_balance}",
        "",
    ]

    if errors:
        lines.extend(
            [
                "## Errors",
                "",
            ]
        )
        for error in errors:
            lines.extend(
                [
                    f"- {error}",
                    "",
                ]
            )

    lines.extend(
        [
            "## Pages",
            "",
        ]
    )

    response = {
        "success": True,
        "status": "completed",
        "starting_url": starting_url,
        "pages_crawled": pages_crawled,
        "total_urls": data.get("total_urls", pages_crawled),
        "total_credits_used": total_credits_used,
        "errors": errors,
        "pages": [
            {
                "url": page.get("url", ""),
                "title": page.get("title", "Untitled"),
                "status_code": page.get("status_code", 0),
                "credits_used": page.get("credits_used", 0),
                "text_content": page.get("text_content", ""),
                "error": page.get("error"),
            }
            for page in pages
        ],
    }
    return json.dumps(response)
