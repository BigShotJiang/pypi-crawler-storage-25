import json
import logging
import os

import httpx

from mcp.types import TextContent

logger = logging.getLogger(__name__)

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")

HACKERNEWS_API_BASE = f"{CRAWLNEST_API_URL}/api/hackernews"


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY
    return headers


def _error_response(error: str, details: str | None = None, **kwargs) -> list[TextContent]:
    resp = {"success": False, "error": error}
    if details:
        resp["details"] = details
    resp.update(kwargs)
    return [TextContent(type="text", text=json.dumps(resp))]


async def _post(endpoint: str, payload: dict, timeout: float = 120.0) -> list[TextContent]:
    """Make a POST request to a Hacker News API endpoint and return the response."""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{HACKERNEWS_API_BASE}/{endpoint}",
                json=payload,
                headers=_headers(),
                timeout=timeout,
            )

            if response.status_code != 200:
                return _error_response(
                    f"Hacker News API returned HTTP {response.status_code}",
                    details=response.text,
                )

            data = response.json()
            return [TextContent(type="text", text=json.dumps({"success": True, **data}))]

    except httpx.TimeoutException:
        return _error_response("Request timed out")
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API", details=str(e))


# --- Tool handlers ---


async def handle_hn_story(arguments: dict) -> list[TextContent]:
    """Fetch a single story by ID."""
    story_id = arguments.get("story_id")
    if not story_id:
        return _error_response("story_id is required")
    logger.info(f"[hn_story] story_id: {story_id}")
    return await _post("story", {"story_id": story_id})


async def handle_hn_ranked_stories(arguments: dict) -> list[TextContent]:
    """Fetch stories with exact HN gravity ranking."""
    payload: dict = {
        "feed": arguments.get("feed", "top"),
        "limit": arguments.get("limit", 30),
    }
    if arguments.get("date"):
        payload["date"] = arguments["date"]
    if arguments.get("points_min") is not None:
        payload["points_min"] = arguments["points_min"]
    if arguments.get("next_cursor"):
        payload["next_cursor"] = arguments["next_cursor"]

    logger.info(f"[hn_ranked_stories] feed: {payload['feed']}, limit: {payload['limit']}")
    return await _post("ranked-stories", payload)


async def handle_hn_domain_stories(arguments: dict) -> list[TextContent]:
    """Fetch stories from a specific domain."""
    site = arguments.get("site")
    if not site:
        return _error_response("site is required")

    payload: dict = {"site": site, "limit": arguments.get("limit", 30)}
    if arguments.get("next_cursor"):
        payload["next_cursor"] = arguments["next_cursor"]

    logger.info(f"[hn_domain_stories] site: {site}, limit: {payload['limit']}")
    return await _post("domain-stories", payload)


async def handle_hn_latest_stories(arguments: dict) -> list[TextContent]:
    """Fetch story listings via Algolia."""
    payload: dict = {
        "feed": arguments.get("feed", "top"),
        "limit": arguments.get("limit", 30),
        "offset": arguments.get("offset", 0),
    }

    logger.info(f"[hn_latest_stories] feed: {payload['feed']}, limit: {payload['limit']}")
    return await _post("latest-stories", payload)


async def handle_hn_best_stories(arguments: dict) -> list[TextContent]:
    """Fetch most-upvoted stories in a time window."""
    payload: dict = {
        "hours": arguments.get("hours", 24),
        "limit": arguments.get("limit", 30),
    }
    if arguments.get("next_cursor"):
        payload["next_cursor"] = arguments["next_cursor"]

    logger.info(f"[hn_best_stories] hours: {payload['hours']}, limit: {payload['limit']}")
    return await _post("best-stories", payload)


async def handle_hn_search(arguments: dict) -> list[TextContent]:
    """Search stories/comments via Algolia."""
    query = arguments.get("query")
    if not query:
        return _error_response("query is required")

    payload: dict = {
        "query": query,
        "sort": arguments.get("sort", "relevance"),
        "limit": arguments.get("limit", 30),
        "page": arguments.get("page", 0),
    }
    if arguments.get("tags"):
        payload["tags"] = arguments["tags"]
    if arguments.get("points_min") is not None:
        payload["points_min"] = arguments["points_min"]
    if arguments.get("comments_min") is not None:
        payload["comments_min"] = arguments["comments_min"]
    if arguments.get("date_from"):
        payload["date_from"] = arguments["date_from"]
    if arguments.get("date_to"):
        payload["date_to"] = arguments["date_to"]
    if arguments.get("author"):
        payload["author"] = arguments["author"]

    logger.info(f"[hn_search] query: {query}, sort: {payload['sort']}")
    return await _post("search", payload)


async def handle_hn_comments(arguments: dict) -> list[TextContent]:
    """Fetch full comment tree for a story."""
    story_id = arguments.get("story_id")
    if not story_id:
        return _error_response("story_id is required")
    logger.info(f"[hn_comments] story_id: {story_id}")
    return await _post("comments", {"story_id": story_id})


async def handle_hn_comment_feed(arguments: dict) -> list[TextContent]:
    """Fetch comment feeds from HN."""
    payload: dict = {
        "feed": arguments.get("feed", "bestcomments"),
        "limit": arguments.get("limit", 30),
    }
    if arguments.get("hours") is not None:
        payload["hours"] = arguments["hours"]
    if arguments.get("next_cursor"):
        payload["next_cursor"] = arguments["next_cursor"]

    logger.info(f"[hn_comment_feed] feed: {payload['feed']}, limit: {payload['limit']}")
    return await _post("comment-feed", payload)


async def handle_hn_who_is_hiring(arguments: dict) -> list[TextContent]:
    """Fetch Who Is Hiring threads."""
    payload: dict = {"limit": arguments.get("limit", 30)}
    if arguments.get("thread_type"):
        payload["thread_type"] = arguments["thread_type"]
    if arguments.get("month_from"):
        payload["month_from"] = arguments["month_from"]
    if arguments.get("month_to"):
        payload["month_to"] = arguments["month_to"]
    if arguments.get("next_cursor"):
        payload["next_cursor"] = arguments["next_cursor"]

    logger.info(f"[hn_who_is_hiring] type: {payload.get('thread_type', 'all')}")
    return await _post("who-is-hiring", payload)


async def handle_hn_leaders(arguments: dict) -> list[TextContent]:
    """Fetch HN karma leaders."""
    logger.info("[hn_leaders] Fetching top 100 karma leaders")
    return await _post("leaders", {})


# --- User handlers ---


async def handle_hn_user(arguments: dict) -> list[TextContent]:
    """Fetch HN user profile."""
    username = arguments.get("username")
    if not username:
        return _error_response("username is required")
    logger.info(f"[hn_user] username: {username}")
    return await _post("user", {"username": username})


async def handle_hn_user_submissions(arguments: dict) -> list[TextContent]:
    """Fetch a user's submitted stories."""
    username = arguments.get("username")
    if not username:
        return _error_response("username is required")

    payload: dict = {"username": username, "limit": arguments.get("limit", 30)}
    if arguments.get("next_cursor"):
        payload["next_cursor"] = arguments["next_cursor"]

    logger.info(f"[hn_user_submissions] username: {username}")
    return await _post("user/submissions", payload)


async def handle_hn_user_threads(arguments: dict) -> list[TextContent]:
    """Fetch a user's comment threads."""
    username = arguments.get("username")
    if not username:
        return _error_response("username is required")

    payload: dict = {"username": username, "limit": arguments.get("limit", 30)}
    if arguments.get("next_cursor"):
        payload["next_cursor"] = arguments["next_cursor"]

    logger.info(f"[hn_user_threads] username: {username}")
    return await _post("user/threads", payload)


async def handle_hn_user_favorites(arguments: dict) -> list[TextContent]:
    """Fetch a user's favorited stories or comments."""
    username = arguments.get("username")
    if not username:
        return _error_response("username is required")

    payload: dict = {
        "username": username,
        "type": arguments.get("type", "stories"),
        "limit": arguments.get("limit", 30),
    }
    if arguments.get("next_cursor"):
        payload["next_cursor"] = arguments["next_cursor"]

    logger.info(f"[hn_user_favorites] username: {username}, type: {payload['type']}")
    return await _post("user/favorites", payload)


async def handle_hn_user_activity(arguments: dict) -> list[TextContent]:
    """Fetch a user's submissions and/or comments."""
    username = arguments.get("username")
    if not username:
        return _error_response("username is required")

    payload: dict = {
        "username": username,
        "type": arguments.get("type", "all"),
        "sort": arguments.get("sort", "date"),
        "limit": arguments.get("limit", 25),
        "page": arguments.get("page", 0),
    }

    logger.info(f"[hn_user_activity] username: {username}, type: {payload['type']}")
    return await _post("user/activity", payload)


# --- YC handlers ---


async def handle_hn_companies_search(arguments: dict) -> list[TextContent]:
    """Search YC company directory."""
    payload: dict = {
        "query": arguments.get("query", ""),
        "limit": arguments.get("limit", 20),
        "page": arguments.get("page", 0),
    }
    for key in ("batch", "industry", "tag", "region", "status"):
        if arguments.get(key):
            payload[key] = arguments[key]
    for key in ("is_hiring", "top_company", "nonprofit"):
        if arguments.get(key) is not None:
            payload[key] = arguments[key]

    logger.info(f"[hn_companies_search] query: {payload['query']}")
    return await _post("companies/search", payload)


async def handle_hn_company(arguments: dict) -> list[TextContent]:
    """Fetch a YC company page."""
    url = arguments.get("url")
    if not url:
        return _error_response("url is required")
    logger.info(f"[hn_company] url: {url}")
    return await _post("company", {"url": url})


async def handle_hn_startup_jobs(arguments: dict) -> list[TextContent]:
    """Fetch YC startup job listings."""
    payload: dict = {"limit": arguments.get("limit", 50)}
    if arguments.get("role"):
        payload["role"] = arguments["role"]
    if arguments.get("location"):
        payload["location"] = arguments["location"]

    logger.info(f"[hn_startup_jobs] role: {payload.get('role')}, location: {payload.get('location')}")
    return await _post("startup-jobs", payload)


async def handle_hn_startup_job_detail(arguments: dict) -> list[TextContent]:
    """Fetch full YC startup job detail."""
    url = arguments.get("url")
    if not url:
        return _error_response("url is required")
    logger.info(f"[hn_startup_job_detail] url: {url}")
    return await _post("startup-jobs/detail", {"url": url})


async def handle_hn_founders_search(arguments: dict) -> list[TextContent]:
    """Search YC founder directory."""
    payload: dict = {
        "query": arguments.get("query", ""),
        "limit": arguments.get("limit", 20),
        "page": arguments.get("page", 0),
    }
    for key in ("batch", "industry", "region", "title"):
        if arguments.get(key):
            payload[key] = arguments[key]
    if arguments.get("top_company") is not None:
        payload["top_company"] = arguments["top_company"]

    logger.info(f"[hn_founders_search] query: {payload['query']}")
    return await _post("founders/search", payload)


async def handle_hn_launches_search(arguments: dict) -> list[TextContent]:
    """Search YC Launch HN posts."""
    payload: dict = {
        "query": arguments.get("query", ""),
        "sort": arguments.get("sort", "relevance"),
        "limit": arguments.get("limit", 20),
        "page": arguments.get("page", 0),
    }
    for key in ("batch", "industry", "tag"):
        if arguments.get(key):
            payload[key] = arguments[key]

    logger.info(f"[hn_launches_search] query: {payload['query']}")
    return await _post("launches/search", payload)


async def handle_hn_launch_detail(arguments: dict) -> list[TextContent]:
    """Fetch full YC launch detail page."""
    url = arguments.get("url")
    if not url:
        return _error_response("url is required")
    logger.info(f"[hn_launch_detail] url: {url}")
    return await _post("launches/detail", {"url": url})
