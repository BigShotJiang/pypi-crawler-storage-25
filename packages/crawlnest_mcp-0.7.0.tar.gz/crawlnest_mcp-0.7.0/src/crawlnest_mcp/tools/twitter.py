import json
import logging
import os

import httpx
from mcp.types import TextContent

logger = logging.getLogger(__name__)

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")

TWITTER_API_BASE = f"{CRAWLNEST_API_URL}/api/twitter"


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY
    return headers


def _error_response(error: str, details: str | None = None, **kwargs) -> list[TextContent]:
    resp = {"success": False, "error": error}
    if details:
        resp["details"] = details
    resp.update(kwargs)
    return [TextContent(type="text", text=json.dumps(resp))]


async def _post(endpoint: str, payload: dict, timeout: float = 120.0) -> list[TextContent]:
    """Make a POST request to a Twitter API endpoint and return the response."""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{TWITTER_API_BASE}/{endpoint}",
                json=payload,
                headers=_headers(),
                timeout=timeout,
            )

            if response.status_code == 401:
                return _error_response(
                    "Twitter credentials missing or expired. "
                    "Save credentials via API or dashboard: "
                    "POST /api/twitter/credentials with auth_token and ct0.",
                    details=response.text,
                )

            if response.status_code != 200:
                return _error_response(
                    f"Twitter API returned HTTP {response.status_code}",
                    details=response.text,
                )

            data = response.json()
            return [TextContent(type="text", text=json.dumps({"success": True, **data}))]

    except httpx.TimeoutException:
        return _error_response("Request timed out")
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API", details=str(e))


# --- Tool handlers ---


async def handle_fetch_tweet(arguments: dict) -> list[TextContent]:
    """Fetch a single tweet by URL."""
    url = arguments.get("url")
    if not url:
        return _error_response("url is required")
    logger.info(f"[fetch_tweet] URL: {url}")
    return await _post("tweet", {"url": url})


async def handle_twitter_user_info(arguments: dict) -> list[TextContent]:
    """Fetch a Twitter user's profile info."""
    screen_name = arguments.get("screen_name")
    if not screen_name:
        return _error_response("screen_name is required")
    logger.info(f"[twitter_user_info] screen_name: {screen_name}")
    return await _post("user-info", {"screen_name": screen_name})


async def handle_twitter_search(arguments: dict) -> list[TextContent]:
    """Search tweets by query."""
    query = arguments.get("query")
    if not query:
        return _error_response("query is required")

    payload: dict = {"query": query}
    if arguments.get("filter"):
        payload["filter"] = arguments["filter"]
    if arguments.get("next_page_token"):
        payload["next_page_token"] = arguments["next_page_token"]

    logger.info(f"[twitter_search] query: {query}, filter: {payload.get('filter')}")
    return await _post("search", payload)


async def handle_twitter_trending(arguments: dict) -> list[TextContent]:
    """Fetch trending topics."""
    payload: dict = {}
    if arguments.get("global_trending") is not None:
        payload["global_trending"] = arguments["global_trending"]

    logger.info(f"[twitter_trending] global: {payload.get('global_trending', False)}")
    return await _post("trending", payload)


async def handle_twitter_news(_arguments: dict) -> list[TextContent]:
    """Fetch news timeline."""
    logger.info("[twitter_news] Fetching news timeline")
    return await _post("news", {})


async def handle_twitter_for_you(_arguments: dict) -> list[TextContent]:
    """Fetch For You explore timeline."""
    logger.info("[twitter_for_you] Fetching explore timeline")
    return await _post("for-you", {})


async def handle_twitter_home_timeline(arguments: dict) -> list[TextContent]:
    """Fetch home timeline."""
    payload: dict = {}
    if arguments.get("tab"):
        payload["tab"] = arguments["tab"]

    logger.info(f"[twitter_home_timeline] tab: {payload.get('tab', 'for_you')}")
    return await _post("home-timeline", payload)
