"""Product Hunt MCP tool handlers.

Each handler builds a payload, calls the CrawlNest API via _post(),
and formats the response through a dedicated formatter function.
Returns list[TextContent] with formatted plain text or Markdown (not JSON).
"""

import logging
import os
from collections.abc import Callable

import httpx
from mcp.types import TextContent

from ..formatters.producthunt import (
    format_categories_taxonomy,
    format_category_detail,
    format_collection_detail,
    format_collections_list,
    format_comments_tree,
    format_forum_thread_detail,
    format_forums_list,
    format_launches,
    format_leaderboard,
    format_makers,
    format_posts_list,
    format_product_detail,
    format_product_search,
    format_reviews,
    format_topic_detail,
    format_topics_list,
    format_user_profile,
    format_user_search,
)

logger = logging.getLogger(__name__)

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")
PH_API_BASE = f"{CRAWLNEST_API_URL}/api/producthunt"


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY
    return headers


def _error_response(error: str, details: str | None = None) -> list[TextContent]:
    """Plain text error — no JSON wrapping."""
    msg = f"Error: {error}"
    if details:
        msg += f" {details}"
    return [TextContent(type="text", text=msg)]


async def _post(
    endpoint: str,
    payload: dict,
    formatter: Callable[[dict], str],
    timeout: float = 120.0,
) -> list[TextContent]:
    """POST to PH API, format the response with the given formatter."""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{PH_API_BASE}/{endpoint}",
                json=payload,
                headers=_headers(),
                timeout=timeout,
            )

            if response.status_code != 200:
                return _error_response(
                    f"Product Hunt API returned HTTP {response.status_code}.",
                    details=response.text[:200] if response.text else None,
                )

            data = response.json()
            formatted = formatter(data)
            return [TextContent(type="text", text=formatted)]

    except httpx.TimeoutException:
        return _error_response("Request timed out.")
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API.", details=str(e))


# ---------------------------------------------------------------------------
# Tool handlers
# ---------------------------------------------------------------------------


async def handle_ph_product(arguments: dict) -> list[TextContent]:
    """Fetch product details by slug."""
    slug = arguments.get("slug")
    if not slug:
        return _error_response("slug is required")
    logger.info(f"[ph_product] slug: {slug}")
    return await _post("product", {"slug": slug}, format_product_detail)


async def handle_ph_launches(arguments: dict) -> list[TextContent]:
    """Fetch all launches for a product."""
    slug = arguments.get("slug")
    if not slug:
        return _error_response("slug is required")
    logger.info(f"[ph_launches] slug: {slug}")
    return await _post("launches", {"slug": slug}, format_launches)


async def handle_ph_makers(arguments: dict) -> list[TextContent]:
    """Fetch product makers/team."""
    slug = arguments.get("slug")
    if not slug:
        return _error_response("slug is required")
    logger.info(f"[ph_makers] slug: {slug}")
    return await _post("makers", {"slug": slug}, format_makers)


async def handle_ph_products(arguments: dict) -> list[TextContent]:
    """List products with optional filters."""
    payload: dict = {
        "order": arguments.get("order", "VOTES"),
        "first": arguments.get("first", 10),
    }
    for key in ("topic", "featured", "posted_after", "posted_before", "after"):
        if arguments.get(key) is not None:
            payload[key] = arguments[key]
    logger.info(f"[ph_products] order={payload['order']}, first={payload['first']}")
    return await _post("product/lists", payload, format_posts_list)


async def handle_ph_comments(arguments: dict) -> list[TextContent]:
    """Fetch threaded comments for a product."""
    post_slug = arguments.get("post_slug")
    if not post_slug:
        return _error_response("post_slug is required")
    payload: dict = {
        "post_slug": post_slug,
        "order": arguments.get("order", "VOTES_COUNT"),
        "first": arguments.get("first", 10),
    }
    if arguments.get("after"):
        payload["after"] = arguments["after"]
    logger.info(f"[ph_comments] post_slug: {post_slug}")
    return await _post("comments", payload, format_comments_tree)


async def handle_ph_topics(arguments: dict) -> list[TextContent]:
    """List topics with optional search."""
    payload: dict = {
        "order": arguments.get("order", "FOLLOWERS_COUNT"),
        "first": arguments.get("first", 10),
    }
    if arguments.get("query"):
        payload["query"] = arguments["query"]
    if arguments.get("after"):
        payload["after"] = arguments["after"]
    logger.info(f"[ph_topics] order={payload['order']}")
    return await _post("topics", payload, format_topics_list)


async def handle_ph_topic(arguments: dict) -> list[TextContent]:
    """Fetch a single topic with its products."""
    slug = arguments.get("slug")
    if not slug:
        return _error_response("slug is required")
    payload: dict = {
        "slug": slug,
        "posts_order": arguments.get("posts_order", "VOTES"),
        "first": arguments.get("first", 10),
    }
    if arguments.get("after"):
        payload["after"] = arguments["after"]
    logger.info(f"[ph_topic] slug: {slug}")
    return await _post("topic", payload, format_topic_detail)


async def handle_ph_collections(arguments: dict) -> list[TextContent]:
    """List curated collections."""
    payload: dict = {
        "order": arguments.get("order", "FEATURED_AT"),
        "first": arguments.get("first", 10),
    }
    for key in ("featured", "post_id", "user_id", "after"):
        if arguments.get(key) is not None:
            payload[key] = arguments[key]
    logger.info(f"[ph_collections] order={payload['order']}")
    return await _post("collections", payload, format_collections_list)


async def handle_ph_collection(arguments: dict) -> list[TextContent]:
    """Fetch a single collection with its products."""
    collection_id = arguments.get("id")
    if not collection_id:
        return _error_response("id is required")
    payload: dict = {
        "id": collection_id,
        "first": arguments.get("first", 10),
    }
    if arguments.get("after"):
        payload["after"] = arguments["after"]
    logger.info(f"[ph_collection] id: {collection_id}")
    return await _post("collection", payload, format_collection_detail)


async def handle_ph_reviews(arguments: dict) -> list[TextContent]:
    """Fetch product reviews with summary."""
    slug = arguments.get("slug")
    if not slug:
        return _error_response("slug is required")
    payload: dict = {
        "slug": slug,
        "filter": arguments.get("filter", "all"),
        "order": arguments.get("order", "informative"),
        "page": arguments.get("page", 1),
    }
    logger.info(f"[ph_reviews] slug: {slug}")
    return await _post("reviews", payload, format_reviews)


async def handle_ph_categories(arguments: dict) -> list[TextContent]:
    """Fetch full category taxonomy."""
    logger.info("[ph_categories] Fetching category taxonomy")
    return await _post("categories", {}, format_categories_taxonomy)


async def handle_ph_category(arguments: dict) -> list[TextContent]:
    """Fetch category detail with products."""
    slug = arguments.get("slug")
    if not slug:
        return _error_response("slug is required")
    payload: dict = {
        "slug": slug,
        "order": arguments.get("order", "top_reviews"),
        "page": arguments.get("page", 1),
    }
    if arguments.get("include_forums") is not None:
        payload["include_forums"] = arguments["include_forums"]
    if arguments.get("include_faqs") is not None:
        payload["include_faqs"] = arguments["include_faqs"]
    logger.info(f"[ph_category] slug: {slug}")
    return await _post("category", payload, format_category_detail)


async def handle_ph_forums(arguments: dict) -> list[TextContent]:
    """List forum threads."""
    payload: dict = {
        "order": arguments.get("order", "popular"),
        "window": arguments.get("window", "week"),
        "page": arguments.get("page", 1),
    }
    if arguments.get("forum_slug"):
        payload["forum_slug"] = arguments["forum_slug"]
    logger.info(f"[ph_forums] order={payload['order']}")
    return await _post("forums", payload, format_forums_list)


async def handle_ph_forum_thread(arguments: dict) -> list[TextContent]:
    """Fetch a single forum thread with comments."""
    forum_slug = arguments.get("forum_slug")
    thread_slug = arguments.get("thread_slug")
    if not forum_slug or not thread_slug:
        return _error_response("forum_slug and thread_slug are required")
    payload: dict = {
        "forum_slug": forum_slug,
        "thread_slug": thread_slug,
        "page": arguments.get("page", 1),
    }
    logger.info(f"[ph_forum_thread] {forum_slug}/{thread_slug}")
    return await _post("forum/thread", payload, format_forum_thread_detail)


async def handle_ph_leaderboard(arguments: dict) -> list[TextContent]:
    """Fetch ranked product leaderboard."""
    period = arguments.get("period")
    if not period:
        return _error_response("period is required (daily, weekly, monthly, yearly)")
    payload: dict = {
        "period": period,
        "filter": arguments.get("filter", "featured"),
    }
    if arguments.get("date"):
        payload["date"] = arguments["date"]
    logger.info(f"[ph_leaderboard] period: {period}")
    return await _post("leaderboard", payload, format_leaderboard)


async def handle_ph_search(arguments: dict) -> list[TextContent]:
    """Search products or launches by keyword."""
    query = arguments.get("query")
    if not query:
        return _error_response("query is required")
    payload: dict = {
        "query": query,
        "type": arguments.get("type", "products"),
        "page": arguments.get("page", 1),
    }
    if arguments.get("featured") is not None:
        payload["featured"] = arguments["featured"]
    if arguments.get("topics"):
        payload["topics"] = arguments["topics"]
    logger.info(f"[ph_search] query: {query}, type: {payload['type']}")
    return await _post("search", payload, format_product_search)


async def handle_ph_search_users(arguments: dict) -> list[TextContent]:
    """Search users by keyword."""
    query = arguments.get("query")
    if not query:
        return _error_response("query is required")
    payload: dict = {
        "query": query,
        "page": arguments.get("page", 1),
    }
    logger.info(f"[ph_search_users] query: {query}")
    return await _post("search/users", payload, format_user_search)


async def handle_ph_user(arguments: dict) -> list[TextContent]:
    """Fetch user profile with optional sections."""
    username = arguments.get("username")
    if not username:
        return _error_response("username is required")
    payload: dict = {"username": username}
    if arguments.get("include"):
        payload["include"] = arguments["include"]
    if arguments.get("page"):
        payload["page"] = arguments["page"]
    logger.info(f"[ph_user] username: {username}")
    return await _post("user", payload, format_user_profile)
