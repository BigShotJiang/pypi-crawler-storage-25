"""MCP tool handlers for image download."""

import json
import logging
import os

import httpx
from mcp.types import TextContent

logger = logging.getLogger(__name__)

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")

IMAGE_API_BASE = f"{CRAWLNEST_API_URL}/api/image"


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY
    return headers


def _error_response(error: str, details: str | None = None) -> list[TextContent]:
    resp: dict = {"success": False, "error": error}
    if details:
        resp["details"] = details
    return [TextContent(type="text", text=json.dumps(resp))]


async def handle_download_image(arguments: dict) -> list[TextContent]:
    """Get image metadata and URLs from a tweet or Reddit post.

    Returns metadata (not binary) since MCP is text-based.
    """
    url = arguments.get("url")
    platform = arguments.get("platform")
    if not url or not platform:
        return _error_response("url and platform are required")

    payload: dict = {"url": url, "platform": platform}

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{IMAGE_API_BASE}/metadata",
                json=payload,
                headers=_headers(),
                timeout=60.0,
            )
            if response.status_code != 200:
                return _error_response(
                    f"Image API returned HTTP {response.status_code}",
                    details=response.text,
                )
            data = response.json()
            return [TextContent(type="text", text=json.dumps({"success": True, **data}))]

    except httpx.TimeoutException:
        return _error_response("Request timed out")
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API", details=str(e))
