import json
import os

import httpx
from mcp.types import TextContent, Tool

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")

# Tool definition
scrape_url_tool = Tool(
    name="scrape_url",
    description=(
        "GENERAL PURPOSE: Scrape a web page to get raw content, images, links, and metadata. "
        "Use this tool for exploratory browsing, reading page content, or getting general information. "
        "Uses CrawlNest's multi-layer scraping with automatic anti-bot bypass. "
        "NOTE: For structured data extraction with specific fields (e.g., 'extract all products with name, price, image'), "
        "use extract_structured tool instead."
    ),
    inputSchema={
        "type": "object",
        "properties": {
            "url": {"type": "string", "description": "The URL to scrape"},
            "proxy": {"type": "string", "description": "Optional proxy URL"},
            "useragent": {"type": "string", "description": "Optional custom User-Agent"},
        },
        "required": ["url"],
    },
)


async def handle_scrape_url(arguments: dict) -> list[TextContent]:
    """Handle scrape_url tool invocation by calling CrawlNest API."""
    url = arguments.get("url")
    proxy = arguments.get("proxy")
    useragent = arguments.get("useragent")

    # Build request payload
    payload = {"url": url}
    if proxy:
        payload["proxy"] = proxy
    if useragent:
        payload["useragent"] = useragent

    # Build headers with optional auth (X-API-Key)
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{CRAWLNEST_API_URL}/api/scrape",
                json=payload,
                headers=headers,
                timeout=120.0,
            )

            if response.status_code != 200:
                error_response = {
                    "success": False,
                    "error": f"Failed to scrape URL with HTTP {response.status_code}",
                    "details": response.text,
                    "url": url,
                }
                return [TextContent(type="text", text=json.dumps(error_response))]

            data = response.json()

    except httpx.TimeoutException:
        error_response = {
            "success": False,
            "error": "Request timed out while scraping",
            "url": url,
        }
        return [TextContent(type="text", text=json.dumps(error_response))]
    except httpx.RequestError as e:
        error_response = {
            "success": False,
            "error": "Failed to connect to CrawlNest API",
            "details": str(e),
            "url": url,
        }
        return [TextContent(type="text", text=json.dumps(error_response))]

    # Format successful response
    result = format_scrape_result(data)
    return [TextContent(type="text", text=result)]


def format_scrape_result(data: dict) -> str:
    """Format scrape response as JSON."""
    response = {
        "success": True,
        "page": {
            "title": data.get("title", "Untitled"),
            "url": data.get("url", ""),
            "status_code": data.get("status_code", "unknown"),
            "text": data.get("text", ""),
            "metadata": {
                "description": data.get("metadata", {}).get("description", ""),
            },
            "images_count": len(data.get("images", [])),
            "links_count": len(data.get("links", [])),
            "images": data.get("images", []),
            "links": data.get("links", []),
        },
        "scraping_info": {
            "layer": data.get("layer", "unknown"),
            "tier": data.get("tier_name", "unknown"),
            "credits_used": data.get("credits_used"),
            "remaining_balance": data.get("remaining_balance"),
        },
    }
    return json.dumps(response)
