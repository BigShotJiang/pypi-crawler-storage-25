import json
import logging
import os

import httpx
from mcp.types import TextContent

logger = logging.getLogger(__name__)

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")

REDDIT_API_BASE = f"{CRAWLNEST_API_URL}/api/subreddit"


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY
    return headers


def _error_response(error: str, details: str | None = None, **kwargs) -> list[TextContent]:
    resp = {"success": False, "error": error}
    if details:
        resp["details"] = details
    resp.update(kwargs)
    return [TextContent(type="text", text=json.dumps(resp))]


async def _post(endpoint: str, payload: dict, timeout: float = 120.0) -> list[TextContent]:
    """Make a POST request to a Reddit API endpoint and return the response."""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{REDDIT_API_BASE}/{endpoint}",
                json=payload,
                headers=_headers(),
                timeout=timeout,
            )

            if response.status_code == 401:
                return _error_response(
                    "Reddit credentials missing or expired. "
                    "Save credentials via API or dashboard: "
                    "POST /api/subreddit/credentials with reddit_session.",
                    details=response.text,
                )

            if response.status_code != 200:
                return _error_response(
                    f"Reddit API returned HTTP {response.status_code}",
                    details=response.text,
                )

            data = response.json()
            return [TextContent(type="text", text=json.dumps({"success": True, **data}))]

    except httpx.TimeoutException:
        return _error_response("Request timed out")
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API", details=str(e))


# --- Tool handlers ---


async def handle_reddit_post(arguments: dict) -> list[TextContent]:
    """Fetch a Reddit post with optional comments."""
    url = arguments.get("url")
    if not url:
        return _error_response("url is required")

    payload: dict = {"url": url}
    if arguments.get("include_comments") is not None:
        payload["include_comments"] = arguments["include_comments"]
    if arguments.get("comment_depth") is not None:
        payload["comment_depth"] = arguments["comment_depth"]
    if arguments.get("comment_sort"):
        payload["comment_sort"] = arguments["comment_sort"]

    logger.info(f"[reddit_post] URL: {url}")
    return await _post("post", payload)


async def handle_reddit_community(arguments: dict) -> list[TextContent]:
    """Fetch posts from a subreddit."""
    subreddit = arguments.get("subreddit")
    if not subreddit:
        return _error_response("subreddit is required")

    payload: dict = {"subreddit": subreddit}
    for key in ("sort", "time_filter", "after"):
        if arguments.get(key):
            payload[key] = arguments[key]
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]

    logger.info(f"[reddit_community] r/{subreddit}, sort: {payload.get('sort')}")
    return await _post("community", payload)


async def handle_reddit_about(arguments: dict) -> list[TextContent]:
    """Fetch subreddit metadata."""
    subreddit = arguments.get("subreddit")
    if not subreddit:
        return _error_response("subreddit is required")

    logger.info(f"[reddit_about] r/{subreddit}")
    return await _post("about", {"subreddit": subreddit})


async def handle_reddit_search(arguments: dict) -> list[TextContent]:
    """Search across Reddit."""
    query = arguments.get("query")
    if not query:
        return _error_response("query is required")

    payload: dict = {"query": query}
    for key in ("category", "subreddit", "sort", "time_filter", "after"):
        if arguments.get(key):
            payload[key] = arguments[key]
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]

    logger.info(f"[reddit_search] query: {query}, category: {payload.get('category')}")
    return await _post("search", payload)


async def handle_reddit_explore(arguments: dict) -> list[TextContent]:
    """Discover subreddits (popular, new, default)."""
    payload: dict = {}
    if arguments.get("category"):
        payload["category"] = arguments["category"]
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]
    if arguments.get("after"):
        payload["after"] = arguments["after"]

    logger.info(f"[reddit_explore] category: {payload.get('category', 'popular')}")
    return await _post("explore", payload)


async def handle_reddit_popular(arguments: dict) -> list[TextContent]:
    """Fetch trending posts across Reddit."""
    payload: dict = {}
    for key in ("sort", "time_filter", "geo_filter", "after"):
        if arguments.get(key):
            payload[key] = arguments[key]
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]

    logger.info(f"[reddit_popular] sort: {payload.get('sort')}, geo: {payload.get('geo_filter')}")
    return await _post("popular", payload)


async def handle_reddit_feed(arguments: dict) -> list[TextContent]:
    """Fetch personalized Reddit feed (home or news)."""
    feed = arguments.get("feed")
    if not feed:
        return _error_response("feed is required (home or news)")

    payload: dict = {"feed": feed}
    for key in ("sort", "time_filter", "after"):
        if arguments.get(key):
            payload[key] = arguments[key]
    if arguments.get("use_cookies") is not None:
        payload["use_cookies"] = arguments["use_cookies"]
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]

    logger.info(f"[reddit_feed] feed: {feed}, cookies: {payload.get('use_cookies', False)}")
    return await _post("feed", payload)
