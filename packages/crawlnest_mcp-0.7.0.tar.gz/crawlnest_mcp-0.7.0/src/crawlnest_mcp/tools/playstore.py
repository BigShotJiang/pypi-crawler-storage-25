import json
import logging
import os

import httpx
from mcp.types import TextContent

logger = logging.getLogger(__name__)

CRAWLNEST_API_URL = os.getenv("CRAWLNEST_API_URL", "http://localhost:8000")
CRAWLNEST_API_KEY = os.getenv("CRAWLNEST_API_KEY", "")

PLAYSTORE_API_BASE = f"{CRAWLNEST_API_URL}/api/playstore"


def _headers() -> dict[str, str]:
    headers = {"Content-Type": "application/json"}
    if CRAWLNEST_API_KEY:
        headers["X-API-Key"] = CRAWLNEST_API_KEY
    return headers


def _error_response(error: str, details: str | None = None) -> list[TextContent]:
    resp: dict = {"success": False, "error": error}
    if details:
        resp["details"] = details
    return [TextContent(type="text", text=json.dumps(resp))]


async def _post(endpoint: str, payload: dict, timeout: float = 120.0) -> list[TextContent]:
    """POST to a Play Store API endpoint and return the response."""
    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{PLAYSTORE_API_BASE}/{endpoint}",
                json=payload,
                headers=_headers(),
                timeout=timeout,
            )

            if response.status_code != 200:
                return _error_response(
                    f"Play Store API returned HTTP {response.status_code}",
                    details=response.text,
                )

            data = response.json()
            return [TextContent(type="text", text=json.dumps({"success": True, **data}))]

    except httpx.TimeoutException:
        return _error_response("Request timed out")
    except httpx.RequestError as e:
        return _error_response("Failed to connect to CrawlNest API", details=str(e))


# --- Tool handlers ---


async def handle_playstore_app(arguments: dict) -> list[TextContent]:
    """Fetch app details by package ID."""
    package_id = arguments.get("package_id")
    if not package_id:
        return _error_response("package_id is required")

    payload: dict = {"package_id": package_id}
    if arguments.get("hl"):
        payload["hl"] = arguments["hl"]
    if arguments.get("gl"):
        payload["gl"] = arguments["gl"]

    logger.info(f"[playstore_app] package_id: {package_id}")
    return await _post("app", payload)


async def handle_playstore_search(arguments: dict) -> list[TextContent]:
    """Search Play Store apps by keyword."""
    query = arguments.get("query")
    if not query:
        return _error_response("query is required")

    payload: dict = {"query": query}
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]
    if arguments.get("hl"):
        payload["hl"] = arguments["hl"]
    if arguments.get("gl"):
        payload["gl"] = arguments["gl"]

    logger.info(f"[playstore_search] query: {query}")
    return await _post("search", payload)


async def handle_playstore_reviews(arguments: dict) -> list[TextContent]:
    """Fetch app reviews with pagination."""
    package_id = arguments.get("package_id")
    if not package_id:
        return _error_response("package_id is required")

    payload: dict = {"package_id": package_id}
    if arguments.get("sort"):
        payload["sort"] = arguments["sort"]
    if arguments.get("count") is not None:
        payload["count"] = arguments["count"]
    if arguments.get("filter_score") is not None:
        payload["filter_score"] = arguments["filter_score"]
    if arguments.get("pagination_token"):
        payload["pagination_token"] = arguments["pagination_token"]
    if arguments.get("hl"):
        payload["hl"] = arguments["hl"]
    if arguments.get("gl"):
        payload["gl"] = arguments["gl"]

    logger.info(f"[playstore_reviews] package_id: {package_id}")
    return await _post("reviews", payload)


async def handle_playstore_category(arguments: dict) -> list[TextContent]:
    """Browse apps by category or fetch category charts."""
    category = arguments.get("category")
    if not category:
        return _error_response("category is required")

    payload: dict = {"category": category}
    if arguments.get("chart_type"):
        payload["chart_type"] = arguments["chart_type"]
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]
    if arguments.get("hl"):
        payload["hl"] = arguments["hl"]
    if arguments.get("gl"):
        payload["gl"] = arguments["gl"]

    logger.info(f"[playstore_category] category: {category}")
    return await _post("category", payload)


async def handle_playstore_charts(arguments: dict) -> list[TextContent]:
    """Fetch global top charts."""
    payload: dict = {}
    if arguments.get("chart_type"):
        payload["chart_type"] = arguments["chart_type"]
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]
    if arguments.get("hl"):
        payload["hl"] = arguments["hl"]
    if arguments.get("gl"):
        payload["gl"] = arguments["gl"]

    logger.info(f"[playstore_charts] chart_type: {payload.get('chart_type', 'top_free')}")
    return await _post("charts", payload)


async def handle_playstore_developer(arguments: dict) -> list[TextContent]:
    """Fetch a developer's published apps."""
    developer_id = arguments.get("developer_id")
    if not developer_id:
        return _error_response("developer_id is required")

    payload: dict = {"developer_id": developer_id}
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]
    if arguments.get("hl"):
        payload["hl"] = arguments["hl"]
    if arguments.get("gl"):
        payload["gl"] = arguments["gl"]

    logger.info(f"[playstore_developer] developer_id: {developer_id}")
    return await _post("developer", payload)


async def handle_playstore_similar(arguments: dict) -> list[TextContent]:
    """Fetch similar apps for a given app."""
    package_id = arguments.get("package_id")
    if not package_id:
        return _error_response("package_id is required")

    payload: dict = {"package_id": package_id}
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]
    if arguments.get("hl"):
        payload["hl"] = arguments["hl"]
    if arguments.get("gl"):
        payload["gl"] = arguments["gl"]

    logger.info(f"[playstore_similar] package_id: {package_id}")
    return await _post("similar", payload)


async def handle_playstore_games(arguments: dict) -> list[TextContent]:
    """Fetch the Games explore page."""
    payload: dict = {}
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]
    if arguments.get("hl"):
        payload["hl"] = arguments["hl"]
    if arguments.get("gl"):
        payload["gl"] = arguments["gl"]

    logger.info("[playstore_games] Fetching games explore")
    return await _post("games", payload)


async def handle_playstore_device(arguments: dict) -> list[TextContent]:
    """Fetch apps filtered by device type."""
    device = arguments.get("device")
    if not device:
        return _error_response("device is required")

    payload: dict = {"device": device}
    if arguments.get("limit") is not None:
        payload["limit"] = arguments["limit"]
    if arguments.get("hl"):
        payload["hl"] = arguments["hl"]
    if arguments.get("gl"):
        payload["gl"] = arguments["gl"]

    logger.info(f"[playstore_device] device: {device}")
    return await _post("device", payload)
