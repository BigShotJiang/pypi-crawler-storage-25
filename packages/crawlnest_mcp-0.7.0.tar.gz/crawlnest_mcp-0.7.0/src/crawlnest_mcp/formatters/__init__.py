"""Shared MCP response formatting helpers.

Used by all service-specific formatters (producthunt, hackernews, reddit, twitter).
All functions are pure: dict/list in → str out. No I/O, no HTTP.
"""

from __future__ import annotations

import re


def format_number(n: int | float | None) -> str:
    """Format number with comma separators. None → '0'."""
    if n is None:
        return "0"
    if isinstance(n, float):
        return f"{n:,.1f}"
    return f"{n:,}"


def best_rank(obj: dict) -> str:
    """Pick the most granular non-null rank field. Returns '#3 today' or ''."""
    for field, label in [
        ("daily_rank", "today"),
        ("weekly_rank", "this week"),
        ("monthly_rank", "this month"),
        ("yearly_rank", "this year"),
        ("rank", ""),  # leaderboard entries use plain 'rank'
    ]:
        val = obj.get(field)
        if val:
            return f"#{val} {label}".strip()
    return ""


def topic_names(topics: list) -> str:
    """Extract comma-separated topic names from list of dicts or strings."""
    if not topics:
        return ""
    if isinstance(topics[0], dict):
        return ", ".join(t.get("name", "") for t in topics if t.get("name"))
    return ", ".join(str(t) for t in topics if t)


def pagination_hint(
    cursor: str | None = None,
    page: int | None = None,
    has_next_page: bool = False,
) -> str:
    """Generate a continuation hint for the LLM.

    Supports both cursor-based (GraphQL) and page-based (HTML scraping) pagination.
    Returns empty string when there is no next page.
    """
    if not has_next_page:
        return ""
    if cursor:
        return f'More results available. Use cursor="{cursor}" for next page.'
    if page is not None:
        return f"More results available. Use page={page + 1} for next page."
    return ""


def format_list_response(
    items: list[str],
    total: int | None = None,
    noun: str = "items",
    cursor: str | None = None,
    page: int | None = None,
    has_next_page: bool = False,
) -> str:
    """Standard listing wrapper: count header + --- separators + pagination hint."""
    showing = len(items)
    if not items:
        return f"No {noun} found."

    if total and total > showing:
        header = f"Found {format_number(total)} {noun} (showing {showing}):\n\n"
    else:
        header = f"Showing {showing} {noun}:\n\n"

    body = "\n\n---\n\n".join(items)

    hint = pagination_hint(cursor, page, has_next_page)
    footer = f"\n\n---\n\n{hint}" if hint else ""

    return header + body + footer


def format_error(message: str) -> str:
    """Standard plain-text error format."""
    return f"Error: {message}"


def html_to_markdown(html: str) -> str:
    """Convert HTML to clean markdown for LLM readability.

    Uses markdownify if available, falls back to regex-based stripping.
    Preserves bold, italic, links, and lists.
    """
    if not html or "<" not in html:
        return html or ""

    try:
        from markdownify import markdownify as md

        result = md(html, strip=["img", "script", "style"], heading_style="ATX")
        # Clean up excessive blank lines
        result = re.sub(r"\n{3,}", "\n\n", result)
        return result.strip()
    except ImportError:
        # Fallback: basic regex HTML stripping
        text = re.sub(r"<br\s*/?>", "\n", html)
        text = re.sub(r"<strong>(.*?)</strong>", r"**\1**", text)
        text = re.sub(r"<em>(.*?)</em>", r"*\1*", text)
        text = re.sub(r'<a[^>]*href="([^"]*)"[^>]*>(.*?)</a>', r"[\2](\1)", text)
        text = re.sub(r"<li[^>]*><p>(.*?)</p></li>", r"- \1", text)
        text = re.sub(r"<li[^>]*>(.*?)</li>", r"- \1", text)
        text = re.sub(r"<[^>]+>", "", text)
        text = re.sub(r"\n{3,}", "\n\n", text)
        return text.strip()


def render_comment_tree(
    comments: list[dict],
    depth: int = 0,
    max_depth: int = 3,
    author_field: str = "user_id",
    body_field: str = "body",
) -> list[str]:
    """Render recursive comment tree as indented lines.

    Full body preserved (no truncation) for sentiment analysis.
    Beyond max_depth, collapses with '+N more replies'.
    """
    lines: list[str] = []
    indent = "  " * depth

    for comment in comments:
        author = comment.get(author_field) or "unknown"
        votes = comment.get("votes_count", 0)
        date = (comment.get("created_at") or "")[:10]

        # Header line
        header = f"{indent}@{author} ({votes} votes)"
        if date:
            header += f" — {date}"
        lines.append(header)

        # Body lines — convert HTML to markdown, full text, indented
        raw_body = comment.get(body_field, "")
        if raw_body:
            body = html_to_markdown(raw_body)
            for body_line in body.split("\n"):
                lines.append(f"{indent}  {body_line}")

        # Replies
        replies = comment.get("replies", [])
        if replies and depth < max_depth:
            lines.append("")  # blank line before replies
            lines.extend(
                render_comment_tree(replies, depth + 1, max_depth, author_field, body_field)
            )
        elif replies:
            total_replies = comment.get("replies_total") or len(replies)
            lines.append(f"{indent}  +{total_replies} more replies")

        lines.append("")  # blank line after each comment

    return lines
