"""Product Hunt MCP response formatters.

All functions are pure: dict in → str out. No I/O, no HTTP.
No truncation — full content preserved for sentiment analysis.
"""

from __future__ import annotations

from . import (
    best_rank,
    format_error,
    format_list_response,
    format_number,
    html_to_markdown,
    pagination_hint,
    render_comment_tree,
    topic_names,
)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _post_item(post: dict) -> str:
    """Format a single PHPost for listing context (plain text)."""
    name = post.get("name", "Unknown")
    slug = post.get("slug") or ""
    tagline = post.get("tagline") or ""
    url = post.get("website") or post.get("url") or ""
    votes = format_number(post.get("votes_count", 0))
    comments = format_number(post.get("comments_count", 0))

    rank = best_rank(post)
    rank_part = f" | Rank: {rank}" if rank else ""

    # Reviews
    reviews_part = ""
    reviews_count = post.get("reviews_count")
    reviews_rating = post.get("reviews_rating")
    if reviews_count and reviews_rating:
        reviews_part = f" | Reviews: {reviews_rating}/5 ({format_number(reviews_count)})"

    topics = topic_names(post.get("topics", []))
    featured = (post.get("featured_at") or "")[:10]
    created = (post.get("created_at") or "")[:10]
    thumbnail = post.get("thumbnail_url") or ""
    makers = post.get("makers_count", 0)
    collections = post.get("collections_total")

    lines = [f"{name} — {tagline}"]
    if slug:
        lines.append(f"Slug: {slug}")
    if url:
        lines.append(f"URL: {url}")
    lines.append(f"Votes: {votes} | Comments: {comments}{reviews_part}{rank_part}")
    if topics:
        lines.append(f"Topics: {topics}")
    if makers:
        lines.append(f"Makers: {makers}")
    if collections:
        lines.append(f"Collections: {format_number(collections)}")
    if featured:
        lines.append(f"Featured: {featured}")
    elif created:
        lines.append(f"Created: {created}")
    if thumbnail:
        lines.append(f"Thumbnail: {thumbnail}")

    return "\n".join(lines)


def _star_rating(rating: int | float | None) -> str:
    """Convert numeric rating to star string."""
    if rating is None:
        return ""
    full = int(rating)
    return "★" * full + "☆" * (5 - full)


# ---------------------------------------------------------------------------
# 1. Product detail — Markdown
# ---------------------------------------------------------------------------


def format_product_detail(data: dict) -> str:
    """Format PHProductResponse as Markdown detail."""
    post = data.get("post")
    if not post:
        return format_error("Product not found.")

    name = post.get("name", "Unknown")
    slug = post.get("slug") or ""
    tagline = post.get("tagline") or ""
    website = post.get("website") or ""
    url = post.get("url") or ""
    thumbnail = post.get("thumbnail_url") or ""
    votes = format_number(post.get("votes_count", 0))
    comments = format_number(post.get("comments_count", 0))
    created = (post.get("created_at") or "")[:10]
    featured = (post.get("featured_at") or "")[:10]
    makers_count = post.get("makers_count", 0)
    collections = post.get("collections_total")

    lines = [f"# {name}"]
    if slug:
        lines.append(f"**Slug:** {slug}")
    lines.append(f"**Tagline:** {tagline}")

    if website:
        lines.append(f"**Website:** {website}")
    if url:
        lines.append(f"**Product Hunt URL:** {url}")

    # Metrics
    metrics = f"**Votes:** {votes} | **Comments:** {comments}"
    reviews_count = post.get("reviews_count")
    reviews_rating = post.get("reviews_rating")
    if reviews_count and reviews_rating:
        metrics += f" | **Reviews:** {reviews_rating}/5 ({format_number(reviews_count)} reviews)"
    lines.append(metrics)

    # All ranks
    ranks: list[str] = []
    for field, label in [("daily_rank", "Daily"), ("weekly_rank", "Weekly"),
                         ("monthly_rank", "Monthly"), ("yearly_rank", "Yearly")]:
        val = post.get(field)
        if val:
            ranks.append(f"{label}: #{val}")
    if ranks:
        lines.append(f"**Ranking:** {' | '.join(ranks)}")

    topics = topic_names(post.get("topics", []))
    if topics:
        lines.append(f"**Topics:** {topics}")

    # Maker info
    user = post.get("user")
    if user and user.get("username") and user["username"] != "[REDACTED]":
        lines.append(f"**Maker:** @{user['username']}")
    if makers_count:
        lines.append(f"**Makers Count:** {makers_count}")

    if collections:
        lines.append(f"**Collections:** {format_number(collections)}")

    if featured:
        lines.append(f"**Featured:** {featured}")
    if created:
        lines.append(f"**Created:** {created}")

    if thumbnail:
        lines.append(f"**Thumbnail:** {thumbnail}")

    # Product links (website, app store, etc.)
    product_links = post.get("product_links") or []
    if product_links:
        lines.append("\n## Links")
        for pl in product_links:
            pl_type = pl.get("type") or "Link"
            pl_url = pl.get("url") or ""
            if pl_url:
                lines.append(f"- {pl_type}: {pl_url}")

    # Media (screenshots, videos)
    media = post.get("media") or []
    if media:
        lines.append("\n## Media")
        for m in media:
            m_type = m.get("type") or "image"
            m_url = m.get("url") or ""
            video_url = m.get("video_url") or ""
            if video_url:
                lines.append(f"- {m_type}: {video_url}")
            elif m_url:
                lines.append(f"- {m_type}: {m_url}")

    # Description — full, no truncation
    description = post.get("description")
    if description:
        lines.append(f"\n## Description\n{description}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 2. Posts list — Plain text listing
# ---------------------------------------------------------------------------


def format_posts_list(data: dict) -> str:
    """Format PHPostsResponse as plain text listing."""
    posts = data.get("posts", [])
    total = data.get("total_count", len(posts))
    page_info = data.get("page_info") or {}
    cursor = page_info.get("end_cursor") if page_info.get("has_next_page") else None

    items = [_post_item(p) for p in posts]
    return format_list_response(
        items, total, "products",
        cursor=cursor, has_next_page=page_info.get("has_next_page", False),
    )


# ---------------------------------------------------------------------------
# 2b. Makers — Plain text listing
# ---------------------------------------------------------------------------


def format_makers(data: dict) -> str:
    """Format PHMakersResponse as plain text listing with launch slugs."""
    product_name = data.get("product_name") or "Unknown Product"
    makers = data.get("makers", [])
    total = data.get("total_count", len(makers))

    if not makers:
        return f"No makers found for \"{product_name}\"."

    items: list[str] = []
    for m in makers:
        username = m.get("username", "unknown")
        name = m.get("name") or ""
        headline = m.get("headline") or ""
        followers = format_number(m.get("followers_count"))

        lines = [f"@{username} — {name}"]
        if headline:
            lines.append(f"Headline: {headline}")
        lines.append(f"Followers: {followers}")

        launches = m.get("launches", [])
        if launches:
            launch_parts = [
                f"{l.get('name', '')} (slug: {l.get('slug', '')})"
                for l in launches
            ]
            lines.append(f"Launches: {', '.join(launch_parts)}")

        items.append("\n".join(lines))

    return format_list_response(items, total, f"makers of \"{product_name}\"")


# ---------------------------------------------------------------------------
# 2c. Launches — Plain text listing
# ---------------------------------------------------------------------------


def format_launches(data: dict) -> str:
    """Format PHLaunchesResponse as plain text listing."""
    product_name = data.get("product_name") or "Unknown Product"
    launches = data.get("launches", [])
    total = data.get("total_count", len(launches))
    has_next = data.get("has_next_page", False)

    if not launches:
        return f"No launches found for \"{product_name}\"."

    items: list[str] = []
    for l in launches:
        name = l.get("name", "Unknown")
        slug = l.get("slug", "")
        tagline = l.get("tagline") or ""
        score = format_number(l.get("score", 0))
        comments = format_number(l.get("comments_count", 0))
        daily = l.get("daily_rank")
        weekly = l.get("weekly_rank")
        created = (l.get("created_at") or "")[:10]
        featured = (l.get("featured_at") or "")[:10]

        lines = [f"{name} — {tagline}" if tagline else name]
        if slug:
            lines.append(f"Slug: {slug}")
        metrics = f"Score: {score} | Comments: {comments}"
        if daily:
            metrics += f" | Daily Rank: #{daily}"
        if weekly:
            metrics += f" | Weekly Rank: #{weekly}"
        lines.append(metrics)
        if featured:
            lines.append(f"Featured: {featured}")
        elif created:
            lines.append(f"Launched: {created}")

        items.append("\n".join(lines))

    header = f"Launches of \"{product_name}\" ({format_number(total)} total, showing {len(launches)}):\n\n"
    body = "\n\n---\n\n".join(items)

    footer = ""
    if has_next:
        footer = "\n\n---\n\nMore launches available on the next page."

    return header + body + footer


# ---------------------------------------------------------------------------
# 3. Comments tree — Indented plain text
# ---------------------------------------------------------------------------


def format_comments_tree(data: dict) -> str:
    """Format PHCommentsResponse as indented comment tree."""
    comments = data.get("comments", [])
    total = data.get("total_count", len(comments))
    page_info = data.get("page_info") or {}

    if not comments:
        return "No comments found."

    header = f"Comments ({format_number(total)} total, showing {len(comments)}):\n\n"

    # Render each top-level comment separated by ---
    sections: list[str] = []
    for comment in comments:
        tree_lines = render_comment_tree(
            [comment], depth=0, max_depth=3, author_field="user_id", body_field="body",
        )
        sections.append("\n".join(line for line in tree_lines if line is not None).strip())

    body = "\n\n---\n\n".join(sections)

    hint = pagination_hint(
        cursor=page_info.get("end_cursor"),
        has_next_page=page_info.get("has_next_page", False),
    )
    footer = f"\n\n---\n\n{hint}" if hint else ""

    return header + body + footer


# ---------------------------------------------------------------------------
# 4. Topics list — Plain text listing
# ---------------------------------------------------------------------------


def format_topics_list(data: dict) -> str:
    """Format PHTopicsResponse as plain text listing."""
    topics = data.get("topics", [])
    page_info = data.get("page_info") or {}

    items: list[str] = []
    for t in topics:
        name = t.get("name", "Unknown")
        slug = t.get("slug", "")
        followers = format_number(t.get("followers_count"))
        posts_count = format_number(t.get("posts_count"))
        desc = t.get("description") or ""
        url = t.get("url") or ""
        created = (t.get("created_at") or "")[:10]

        lines = [name, f"Slug: {slug}", f"Followers: {followers} | Products: {posts_count}"]
        if url:
            lines.append(f"URL: {url}")
        if desc:
            lines.append(f"Description: {desc}")
        if created:
            lines.append(f"Created: {created}")
        items.append("\n".join(lines))

    return format_list_response(
        items, len(topics), "topics",
        cursor=page_info.get("end_cursor") if page_info.get("has_next_page") else None,
        has_next_page=page_info.get("has_next_page", False),
    )


# ---------------------------------------------------------------------------
# 5. Topic detail — Markdown + listing
# ---------------------------------------------------------------------------


def format_topic_detail(data: dict) -> str:
    """Format PHTopicResponse as Markdown detail with products listing."""
    topic = data.get("topic")
    if not topic:
        return format_error("Topic not found.")

    name = topic.get("name", "Unknown")
    slug = topic.get("slug", "")
    desc = topic.get("description") or ""
    followers = format_number(topic.get("followers_count"))
    posts_count = format_number(topic.get("posts_count"))

    lines = [
        f"# {name}",
        f"**Slug:** {slug}",
        f"**Followers:** {followers} | **Products:** {posts_count}",
    ]
    if desc:
        lines.append(f"\n{desc}")

    # Products section
    posts = data.get("posts", [])
    if posts:
        lines.append("\n## Products\n")
        for p in posts:
            lines.append(_post_item(p))
            lines.append("")  # blank line between items

    page_info = data.get("page_info") or {}
    hint = pagination_hint(
        cursor=page_info.get("end_cursor"),
        has_next_page=page_info.get("has_next_page", False),
    )
    if hint:
        lines.append(f"\n---\n\n{hint}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 6. Collections list — Plain text listing
# ---------------------------------------------------------------------------


def format_collections_list(data: dict) -> str:
    """Format PHCollectionsResponse as plain text listing."""
    collections = data.get("collections", [])
    page_info = data.get("page_info") or {}

    items: list[str] = []
    for c in collections:
        cid = c.get("id") or ""
        name = c.get("name", "Unknown")
        username = c.get("username") or ""
        followers = format_number(c.get("followers_count"))
        desc = c.get("description") or ""
        url = c.get("url") or ""
        created = (c.get("created_at") or "")[:10]
        featured = (c.get("featured_at") or "")[:10]

        lines = [name]
        if cid:
            lines.append(f"ID: {cid}")
        if username:
            lines.append(f"By: @{username}")
        lines.append(f"Followers: {followers}")
        if url:
            lines.append(f"URL: {url}")
        if desc:
            lines.append(f"Description: {desc}")
        if featured:
            lines.append(f"Featured: {featured}")
        elif created:
            lines.append(f"Created: {created}")
        items.append("\n".join(lines))

    return format_list_response(
        items, len(collections), "collections",
        cursor=page_info.get("end_cursor") if page_info.get("has_next_page") else None,
        has_next_page=page_info.get("has_next_page", False),
    )


# ---------------------------------------------------------------------------
# 7. Collection detail — Markdown + listing
# ---------------------------------------------------------------------------


def format_collection_detail(data: dict) -> str:
    """Format PHCollectionResponse as Markdown detail with products."""
    collection = data.get("collection")
    if not collection:
        return format_error("Collection not found.")

    name = collection.get("name", "Unknown")
    username = collection.get("username") or ""
    followers = format_number(collection.get("followers_count"))
    desc = collection.get("description") or ""

    lines = [f"# {name}"]
    if username:
        lines.append(f"**By:** @{username}")
    lines.append(f"**Followers:** {followers}")
    if desc:
        lines.append(f"\n{desc}")

    posts = data.get("posts", [])
    if posts:
        lines.append("\n## Products\n")
        for p in posts:
            lines.append(_post_item(p))
            lines.append("")

    page_info = data.get("page_info") or {}
    hint = pagination_hint(
        cursor=page_info.get("end_cursor"),
        has_next_page=page_info.get("has_next_page", False),
    )
    if hint:
        lines.append(f"\n---\n\n{hint}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 8. Reviews — Markdown summary + listing
# ---------------------------------------------------------------------------


def format_reviews(data: dict) -> str:
    """Format PHReviewsResponse as Markdown with summary and full review bodies."""
    reviews = data.get("reviews", [])
    summary = data.get("summary") or {}
    total = data.get("total_count", len(reviews))
    page = data.get("page", 1)
    has_next = data.get("has_next_page", False)

    if not reviews and not summary:
        return "No reviews found."

    lines = [f"# Reviews ({format_number(total)} total)"]

    # AI Summary
    ai_summary = summary.get("ai_summary")
    if ai_summary:
        lines.append(f"\n## AI Summary\n{ai_summary}")

    # Aggregated pros/cons
    agg_pros = summary.get("aggregated_pros", [])
    if agg_pros:
        lines.append("\n## Aggregated Pros")
        for p in agg_pros:
            text = p.get("text") or p.get("pro", "")
            count = p.get("count", "")
            lines.append(f"- {text}" + (f" (mentioned {count} times)" if count else ""))

    agg_cons = summary.get("aggregated_cons", [])
    if agg_cons:
        lines.append("\n## Aggregated Cons")
        for c in agg_cons:
            text = c.get("text") or c.get("con", "")
            count = c.get("count", "")
            lines.append(f"- {text}" + (f" (mentioned {count} times)" if count else ""))

    # Individual reviews
    if reviews:
        lines.append("\n## Reviews\n")

    for review in reviews:
        rating = review.get("ratings", {})
        # Try overall rating or first available rating
        overall = None
        if isinstance(rating, dict):
            overall = rating.get("overall") or next(iter(rating.values()), None) if rating else None

        stars = _star_rating(overall) if overall else ""
        author = review.get("author_name") or "Anonymous"
        review_type = review.get("review_type") or ""
        date = review.get("date") or ""
        views = review.get("view_count")

        header_parts = [stars, f"by {author}"]
        if review_type:
            header_parts.append(f"({review_type})")
        if date:
            header_parts.append(f"— {date}")
        if views:
            header_parts.append(f"({format_number(views)} views)")
        lines.append(" ".join(p for p in header_parts if p))

        # Full body — no truncation, convert HTML to markdown
        raw_body = review.get("body") or ""
        if raw_body:
            lines.append(html_to_markdown(raw_body))

        pros = review.get("pros", [])
        if pros:
            lines.append(f"Pros: {', '.join(pros)}")

        cons = review.get("cons", [])
        if cons:
            lines.append(f"Cons: {', '.join(cons)}")

        # All ratings
        if isinstance(rating, dict) and len(rating) > 1:
            rating_parts = [f"{k}={v}" for k, v in rating.items() if v is not None]
            if rating_parts:
                lines.append(f"Ratings: {', '.join(rating_parts)}")

        lines.append("\n---\n")

    hint = pagination_hint(page=page, has_next_page=has_next)
    if hint:
        lines.append(hint)

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 9. Categories taxonomy — Indented tree
# ---------------------------------------------------------------------------


def format_categories_taxonomy(data: dict) -> str:
    """Format PHCategoriesResponse as indented taxonomy tree."""
    groups = data.get("groups", [])
    total = data.get("total_categories", 0)

    if not groups:
        return "No categories found."

    lines = [f"Product Hunt Categories ({format_number(total)} total):\n"]

    for group in groups:
        group_name = group.get("name", "Unknown Group")
        lines.append(group_name)

        for cat in group.get("categories", []):
            slug = cat.get("slug", "")
            name = cat.get("name", "")
            lines.append(f"  {slug} — {name}")

        lines.append("")  # blank line between groups

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 10. Category detail — Markdown + sections
# ---------------------------------------------------------------------------


def format_category_detail(data: dict) -> str:
    """Format PHCategoryResponse as Markdown with products, tags, FAQs, forums."""
    category = data.get("category")
    if not category:
        return format_error("Category not found.")

    name = category.get("name", "Unknown")
    slug = category.get("slug") or ""
    desc = category.get("description") or ""
    parent = category.get("parent_name") or ""
    total_products = category.get("total_products")
    total_reviews = category.get("total_reviews")
    ai_summary = category.get("ai_summary") or ""
    page = data.get("page", 1)
    has_next = data.get("has_next_page", False)

    lines = [f"# {name}"]
    if slug:
        lines.append(f"**Slug:** {slug}")
    if parent:
        lines.append(f"**Category Group:** {parent}")
    if total_products:
        lines.append(f"**Products:** {format_number(total_products)}")
    if total_reviews:
        lines.append(f"**Reviews:** {format_number(total_reviews)}")
    if desc:
        lines.append(f"\n{desc}")
    if ai_summary:
        lines.append(f"\n## AI Summary\n{ai_summary}")

    # Hero products
    hero = category.get("hero_products", [])
    if hero:
        lines.append("\n## Featured Products\n")
        for p in hero:
            entry = p.get("name", "")
            if p.get("tagline"):
                entry += f" — {p['tagline']}"
            if p.get("slug"):
                entry += f"\nSlug: {p['slug']}"
            if p.get("reviews_rating"):
                entry += f"\nRating: {p['reviews_rating']}/5"
                if p.get("reviews_count"):
                    entry += f" ({format_number(p['reviews_count'])} reviews)"
            lines.append(entry)

    # Products listing
    products = category.get("products", [])
    if products:
        lines.append("\n## Products\n")
        for p in products:
            name_p = p.get("name", "")
            slug_p = p.get("slug") or ""
            tagline_p = p.get("tagline") or ""
            rating = p.get("reviews_rating")
            reviews_c = p.get("reviews_count")

            entry = f"{name_p}"
            if tagline_p:
                entry += f" — {tagline_p}"
            if slug_p:
                entry += f"\nSlug: {slug_p}"
            if rating:
                entry += f"\nRating: {rating}/5"
                if reviews_c:
                    entry += f" ({format_number(reviews_c)} reviews)"

            tags = p.get("tags", [])
            if tags:
                entry += f"\nTags: {', '.join(tags)}"

            if p.get("is_top_product"):
                entry += "\n[Top Product]"

            lines.append(entry)
            lines.append("")

    # Tags
    tags_list = category.get("tags", [])
    if tags_list:
        tag_parts = [f"{t.get('name', '')} ({t.get('count', 0)})" for t in tags_list]
        lines.append(f"\n## Tags\n{', '.join(tag_parts)}")

    # Related categories
    related = category.get("related_categories", [])
    if related:
        lines.append(f"\n## Related Categories\n{', '.join(related)}")

    # FAQs
    faqs = category.get("faqs")
    if faqs:
        lines.append("\n## FAQs\n")
        for faq in faqs:
            lines.append(f"**Q:** {faq.get('question', '')}")
            answer = faq.get("answer") or ""
            if answer:
                lines.append(f"**A:** {answer}")
            lines.append("")

    # Forum threads
    forums = category.get("forum_threads")
    if forums:
        lines.append("\n## Forum Threads\n")
        for thread in forums:
            title = thread.get("title", "")
            author = thread.get("author_name") or ""
            votes = thread.get("votes_count", 0)
            comments_c = thread.get("comments_count", 0)
            lines.append(f"{title}")
            if author:
                lines.append(f"By: {author} | Votes: {votes} | Comments: {comments_c}")
            lines.append("")

    hint = pagination_hint(page=page, has_next_page=has_next)
    if hint:
        lines.append(f"\n---\n\n{hint}")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 11. Forums list — Plain text listing
# ---------------------------------------------------------------------------


def format_forums_list(data: dict) -> str:
    """Format PHForumsResponse as plain text listing."""
    threads = data.get("threads", [])
    topic_forums = data.get("topic_forums", [])
    page = data.get("page", 1)
    has_next = data.get("has_next_page", False)

    # Available forums header
    header_parts: list[str] = []
    if topic_forums:
        forum_names = [f.get("name", f.get("slug", "")) for f in topic_forums]
        header_parts.append(f"Available forums: {', '.join(forum_names)}\n")

    items: list[str] = []
    for t in threads:
        title = t.get("title", "Unknown")
        if t.get("pinned"):
            title += " [PINNED]"

        thread_slug = t.get("slug") or ""
        forum_slug = t.get("forum_slug") or ""
        author = t.get("author_username") or t.get("author_name") or ""
        date = (t.get("created_at") or "")[:10]
        featured = (t.get("featured_at") or "")[:10]
        votes = t.get("votes_count", 0)
        comments_c = t.get("comments_count", 0)
        preview = t.get("description_preview") or ""

        lines = [title]
        if forum_slug and thread_slug:
            lines.append(f"Forum: {forum_slug} | Thread slug: {thread_slug}")
        elif thread_slug:
            lines.append(f"Thread slug: {thread_slug}")
        if author:
            author_line = f"By: @{author}"
            if date:
                author_line += f" — {date}"
            lines.append(author_line)
        lines.append(f"Votes: {votes} | Comments: {comments_c}")
        if featured:
            lines.append(f"Featured: {featured}")
        if preview:
            lines.append(f"Preview: {preview}")
        items.append("\n".join(lines))

    prefix = "".join(header_parts)
    listing = format_list_response(
        items, len(threads), "threads",
        page=page, has_next_page=has_next,
    )
    return prefix + listing


# ---------------------------------------------------------------------------
# 12. Forum thread detail — Markdown + comment tree
# ---------------------------------------------------------------------------


def format_forum_thread_detail(data: dict) -> str:
    """Format PHForumThreadResponse as Markdown with comment tree."""
    thread = data.get("thread")
    if not thread:
        return format_error("Forum thread not found.")

    title = thread.get("title", "Unknown")
    thread_slug = thread.get("slug") or ""
    forum_slug = thread.get("forum_slug") or ""
    author = thread.get("author_username") or thread.get("author_name") or ""
    date = (thread.get("created_at") or "")[:10]
    featured = (thread.get("featured_at") or "")[:10]
    votes = thread.get("votes_count", 0)
    comments_c = thread.get("comments_count", 0)
    views = thread.get("page_views_count")
    raw_body = thread.get("body") or ""
    body = html_to_markdown(raw_body) if raw_body else ""

    lines = [f"# {title}"]
    if forum_slug and thread_slug:
        lines.append(f"**Forum:** {forum_slug} | **Thread slug:** {thread_slug}")
    if author:
        lines.append(f"**By:** @{author}")
    metrics = f"**Votes:** {votes} | **Comments:** {comments_c}"
    if views:
        metrics += f" | **Views:** {format_number(views)}"
    lines.append(metrics)
    if date:
        lines.append(f"**Date:** {date}")
    if featured:
        lines.append(f"**Featured:** {featured}")
    if thread.get("pinned"):
        lines.append("**[PINNED]**")

    if body:
        lines.append(f"\n{body}")

    # Comment tree
    comments = thread.get("comments", [])
    if comments:
        lines.append(f"\n## Comments ({len(comments)})\n")

        sections: list[str] = []
        for comment in comments:
            tree_lines = render_comment_tree(
                [comment], depth=0, max_depth=3,
                author_field="author_username", body_field="body",
            )
            sections.append("\n".join(line for line in tree_lines).strip())

        lines.append("\n\n---\n\n".join(sections))

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# 13. Leaderboard — Ranked listing
# ---------------------------------------------------------------------------


def format_leaderboard(data: dict) -> str:
    """Format PHLeaderboardResponse as ranked plain text listing."""
    entries = data.get("entries", [])
    period = data.get("period", "")
    date = data.get("date", "")

    if not entries:
        return "No leaderboard entries found."

    header = f"Product Hunt Leaderboard — {period}"
    if date:
        header += f" ({date})"
    header += f":\n\n"

    items: list[str] = []
    for entry in entries:
        rank = entry.get("rank", "?")
        name = entry.get("name", "Unknown")
        slug = entry.get("slug") or ""
        tagline = entry.get("tagline") or ""
        votes = format_number(entry.get("votes_count", 0))
        comments_c = entry.get("comments_count")
        thumbnail = entry.get("thumbnail_url") or ""

        line = f"#{rank}. {name}"
        if tagline:
            line += f" — {tagline}"
        if slug:
            line += f"\nSlug: {slug}"

        metrics = f"Votes: {votes}"
        if comments_c is not None:
            metrics += f" | Comments: {format_number(comments_c)}"
        line += f"\n{metrics}"

        topics = topic_names(entry.get("topics", []))
        if topics:
            line += f"\nTopics: {topics}"
        if thumbnail:
            line += f"\nThumbnail: {thumbnail}"

        items.append(line)

    return header + "\n\n---\n\n".join(items)


# ---------------------------------------------------------------------------
# 14. Product search — Plain text listing
# ---------------------------------------------------------------------------


def format_product_search(data: dict) -> str:
    """Format PHProductSearchResponse as plain text listing."""
    search_type = data.get("type", "products")
    query = data.get("query", "")
    page = data.get("page", 1)
    has_next = data.get("has_next_page", False)

    items: list[str] = []

    if search_type == "products":
        products = data.get("products", [])
        for p in products:
            name = p.get("name", "Unknown")
            slug = p.get("slug", "")
            tagline = p.get("tagline") or ""
            rating = p.get("reviews_rating")
            reviews_c = p.get("reviews_count")

            line = f"{name}"
            if tagline:
                line += f" — {tagline}"
            if slug:
                line += f"\nSlug: {slug}"
            if rating:
                line += f"\nRating: {rating}/5"
                if reviews_c:
                    line += f" ({format_number(reviews_c)} reviews)"
            if p.get("is_no_longer_online"):
                line += "\n[No longer online]"
            items.append(line)
    else:
        launches = data.get("launches", [])
        for l in launches:
            name = l.get("name", "Unknown")
            slug = l.get("slug") or ""
            tagline = l.get("tagline") or ""
            rating = l.get("reviews_rating")
            reviews_c = l.get("reviews_count")
            launch_list = l.get("launches", [])

            line = f"{name}"
            if tagline:
                line += f" — {tagline}"
            if slug:
                line += f"\nSlug: {slug}"
            if rating:
                line += f"\nRating: {rating}/5"
                if reviews_c:
                    line += f" ({format_number(reviews_c)} reviews)"
            if launch_list:
                line += "\nLaunches:"
                for launch in launch_list:
                    launch_name = launch.get("name", "")
                    launch_slug = launch.get("slug") or ""
                    launch_date = (launch.get("created_at") or "")[:10]
                    launch_entry = f"\n  - {launch_name}"
                    if launch_slug:
                        launch_entry += f" (slug: {launch_slug})"
                    if launch_date:
                        launch_entry += f" — {launch_date}"
                    line += launch_entry
            if l.get("is_no_longer_online"):
                line += "\n[No longer online]"
            items.append(line)

    # Topic aggregations
    aggregations = data.get("topic_aggregations", [])
    agg_footer = ""
    if aggregations:
        agg_parts = [f"{a.get('name', '')} ({a.get('count', 0)})" for a in aggregations]
        agg_footer = f"\nAvailable topic filters: {', '.join(agg_parts)}"

    listing = format_list_response(
        items, None, f"{search_type} for '{query}'",
        page=page, has_next_page=has_next,
    )
    return listing + agg_footer


# ---------------------------------------------------------------------------
# 15. User search — Plain text listing
# ---------------------------------------------------------------------------


def format_user_search(data: dict) -> str:
    """Format PHUserSearchResponse as plain text listing."""
    users = data.get("users", [])
    query = data.get("query", "")
    page = data.get("page", 1)
    has_next = data.get("has_next_page", False)

    items: list[str] = []
    for u in users:
        username = u.get("username", "unknown")
        name = u.get("name") or ""
        headline = u.get("headline") or ""
        followers = format_number(u.get("followers_count"))
        following = format_number(u.get("followings_count"))

        line = f"@{username}"
        if name:
            line += f" — {name}"
        if headline:
            line += f"\nHeadline: {headline}"
        line += f"\nFollowers: {followers} | Following: {following}"
        items.append(line)

    return format_list_response(
        items, None, f"users for '{query}'",
        page=page, has_next_page=has_next,
    )


# ---------------------------------------------------------------------------
# 16. User profile — Markdown + optional sections
# ---------------------------------------------------------------------------


def format_user_profile(data: dict) -> str:
    """Format PHUserResponse as Markdown with optional sections."""
    user = data.get("user")
    if not user:
        return format_error("User not found.")

    username = user.get("username") or "unknown"
    name = user.get("name") or ""
    headline = user.get("headline") or ""
    about = user.get("about") or ""
    work = user.get("work") or ""
    twitter = user.get("twitter_username") or ""
    avatar = user.get("avatar_url") or ""
    created = (user.get("created_at") or "")[:10]
    verified = user.get("is_account_verified")
    followers = format_number(user.get("followers_count"))
    following = format_number(user.get("followings_count"))
    products_c = format_number(user.get("products_count"))
    votes_c = format_number(user.get("votes_count"))
    reviews_c = format_number(user.get("reviews_count"))

    lines = [f"# @{username}"]
    if name:
        lines[0] += f" — {name}"
    if headline:
        lines.append(f"**Headline:** {headline}")
    if work:
        lines.append(f"**Work:** {work}")
    if twitter:
        lines.append(f"**Twitter:** @{twitter}")
    if user.get("is_maker"):
        lines.append("**Maker:** Yes")
    if verified:
        lines.append("**Verified:** Yes")
    lines.append(f"**Followers:** {followers} | **Following:** {following}")
    lines.append(f"**Products:** {products_c} | **Votes:** {votes_c} | **Reviews:** {reviews_c}")
    if created:
        lines.append(f"**Joined:** {created}")
    if avatar:
        lines.append(f"**Avatar:** {avatar}")

    if about:
        lines.append(f"\n{about}")

    # Products made
    products = data.get("products", [])
    if products:
        lines.append("\n## Products\n")
        for p in products:
            p_name = p.get("name", "")
            p_slug = p.get("slug") or ""
            p_tagline = p.get("tagline") or ""
            entry = p_name
            if p_tagline:
                entry += f" — {p_tagline}"
            if p_slug:
                entry += f" (slug: {p_slug})"
            lines.append(entry)

    # Social links
    social = data.get("social_links", [])
    if social:
        lines.append("\n## Social Links\n")
        for s in social:
            s_name = s.get("name") or s.get("kind", "Link")
            s_url = s.get("url") or ""
            if s_url:
                lines.append(f"{s_name}: {s_url}")

    # Optional sections — only rendered when not None
    page = data.get("page", 1)
    has_next = data.get("has_next_page", False)

    # Badges
    badges = data.get("badges")
    if badges is not None and badges:
        lines.append("\n## Badges\n")
        for b in badges:
            b_name = b.get("name", "")
            b_desc = b.get("description") or ""
            entry = b_name
            if b_desc:
                entry += f" — {b_desc}"
            lines.append(f"- {entry}")

    # Streak
    streak = data.get("streak")
    if streak is not None:
        emoji = streak.get("emoji") or ""
        duration = streak.get("duration", 0)
        if duration:
            lines.append(f"\n## Streak\n{emoji} {duration} days")

    # KittyCoin rankings
    kitty = data.get("kitty_rankings")
    if kitty is not None and kitty:
        lines.append("\n## KittyCoin Rankings\n")
        for k in kitty:
            period = k.get("period", "")
            rank_val = k.get("rank")
            value = k.get("value")
            entry = f"{period}: #{rank_val}" if rank_val else period
            if value:
                entry += f" ({format_number(value)} coins)"
            lines.append(f"- {entry}")

    # Activity
    activity = data.get("activity")
    if activity is not None and activity:
        lines.append("\n## Recent Activity\n")
        for a in activity:
            event_type = a.get("event_type") or ""
            target = a.get("target_name") or ""
            date = (a.get("occurred_at") or "")[:10]
            preview = a.get("body_preview") or ""

            entry = f"- {event_type}"
            if target:
                entry += f" on {target}"
            if date:
                entry += f" ({date})"
            lines.append(entry)
            if preview:
                lines.append(f"  {preview}")

    # Upvoted products
    upvotes = data.get("upvotes")
    if upvotes is not None and upvotes:
        lines.append("\n## Upvoted Products\n")
        for u in upvotes:
            entry = u.get("name", "")
            if u.get("tagline"):
                entry += f" — {u['tagline']}"
            if u.get("slug"):
                entry += f" (slug: {u['slug']})"
            votes = u.get("votes_count")
            if votes:
                entry += f" ({format_number(votes)} votes)"
            lines.append(entry)

    # Submitted products
    submitted = data.get("submitted")
    if submitted is not None and submitted:
        lines.append("\n## Submitted Products\n")
        for s in submitted:
            entry = s.get("name", "")
            if s.get("tagline"):
                entry += f" — {s['tagline']}"
            if s.get("slug"):
                entry += f" (slug: {s['slug']})"
            votes = s.get("votes_count")
            if votes:
                entry += f" ({format_number(votes)} votes)"
            lines.append(entry)

    # Tech stacks
    stacks = data.get("stacks")
    if stacks is not None and stacks:
        lines.append("\n## Tech Stack\n")
        for s in stacks:
            entry = s.get("product_name", "")
            if s.get("tagline"):
                entry += f" — {s['tagline']}"
            if s.get("product_slug"):
                entry += f" (slug: {s['product_slug']})"
            rating = s.get("reviews_rating")
            if rating:
                entry += f" (Rating: {rating}/5)"
            lines.append(entry)

    # Reviews
    reviews = data.get("reviews")
    if reviews is not None and reviews:
        lines.append("\n## Reviews\n")
        for r in reviews:
            product = r.get("product_name") or ""
            product_slug = r.get("product_slug") or ""
            rating = r.get("rating")
            raw_body = r.get("body") or ""
            date = (r.get("created_at") or "")[:10]

            header = _star_rating(rating) if rating else ""
            if product:
                header += f" for {product}"
                if product_slug:
                    header += f" (slug: {product_slug})"
            if date:
                header += f" — {date}"
            lines.append(header)
            if raw_body:
                lines.append(html_to_markdown(raw_body))
            lines.append("")

    # Collections
    collections = data.get("collections")
    if collections is not None and collections:
        lines.append("\n## Collections\n")
        for c in collections:
            entry = c.get("name", "")
            desc = c.get("description") or ""
            count = c.get("products_count")
            if count:
                entry += f" ({format_number(count)} products)"
            lines.append(entry)
            if desc:
                lines.append(f"  {desc}")

    # Forum threads
    forums = data.get("forums")
    if forums is not None and forums:
        lines.append("\n## Forum Threads\n")
        for f in forums:
            title = f.get("title", "")
            f_slug = f.get("slug") or ""
            votes = f.get("votes_count", 0)
            comments_c = f.get("comments_count", 0)
            entry = f"{title}"
            if f_slug:
                entry += f" (slug: {f_slug})"
            entry += f" (Votes: {votes} | Comments: {comments_c})"
            lines.append(entry)

    # Pagination for included sections
    hint = pagination_hint(page=page, has_next_page=has_next)
    if hint:
        lines.append(f"\n---\n\n{hint}")

    return "\n".join(lines)
